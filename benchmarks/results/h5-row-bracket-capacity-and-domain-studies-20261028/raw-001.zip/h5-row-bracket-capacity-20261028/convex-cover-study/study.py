"""Finite exact-domain convex-cover compression with rational no-loss certificates."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
from heapq import heappush,heappop
import json,shutil,time
from shapely.geometry import shape,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-capacity-20261028';OLD=ROOT/'output/h5-row-bracket-source-20261028';OUT=BASE/'convex-cover-study';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();LIMITS=[[1,0,-1600000],[-1,0,-1600000],[0,1,-3100000],[0,-1,-3100000]]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def vertices(planes):
    planes=planes+LIMITS;points=set()
    for (a,b,c),(d,e,f) in combinations(planes,2):
        det=a*e-b*d
        if not det:continue
        x,y=F(c*e-f*b,det),F(a*f-d*c,det)
        if all(aa*x+bb*y>=cc for aa,bb,cc in planes):points.add((x,y))
    return sorted(points)
def encode(p):
    p=orient(p,sign=1);vv=[tuple(F(str(v)) for v in xy) for xy in list(p.exterior.coords)[:-1]];planes=[]
    for u,v in zip(vv,vv[1:]+vv[:1]):
        nx,ny=u[1]-v[1],v[0]-u[0];scale=max(abs(nx),abs(ny));nx/=scale;ny/=scale
        if not all(nx*(z[0]-u[0])+ny*(z[1]-u[1])>=0 for z in vv):return None
        a,b=round(nx*10**9),round(ny*10**9);error=abs(F(a)-nx*10**9)*1600000+abs(F(b)-ny*10**9)*3100000;value=(nx*u[0]+ny*u[1])*10**12+error;c=-((-value.numerator)//value.denominator)+1;planes.append([a,b,c])
    return p,planes
assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'search/result.json')['closed'];OUT.mkdir();(OUT/'types').mkdir();shutil.copyfile(__file__,OUT/'study.py');started=time.perf_counter();inputs=[BASE/'plan.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',OLD/'geometry-audit/plan.json',OLD/'geometry-audit/checks.json',OLD/'control-region-checks.json',Path(__file__)]+list((OLD/'row-bracket').glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'One deterministic finite compression of each of16 exact existing row/bracket free domains. Start from every old convex cell. Consider every pair; its convex hull is eligible only if the original domain covers it, exact decimal-rational convexity holds, total halfplane count decreases, and every vertex of both original integer-halfplane relaxations within the global coordinate box satisfies every new inward-rounded plane. Thus every old accepted integer displacement is retained, not only sampled controls. Merge by largest halfplane saving, then largest area, then increasing creation IDs. Recompute pairs involving each new cell until none qualifies; at most original-cell-count-minus-one merges per type. Cells may overlap. Independently verify exact domain union, all original-cell provenance, rational inclusion by a different clipping algorithm, every plane and all33 positive/16 negative controls. Select only if all proofs pass and expanded plane count drops at least25percent. No source geometry is enlarged or removed; no new solver model/call.','variants':1,'required_expanded_plane_reduction':0.25,'baseline_expanded_planes':28640,'baseline_selectors':7260,'solver_calls':0,'native_calls':0,'H5_complete':False})
summary=[]
for path in sorted((OLD/'row-bracket').glob('*.json')):
    begin=time.perf_counter();data=load(path);domain=shape(data['domain_geometry']);oldcells=data['cells'];points={i:vertices(c['halfplanes']) for i,c in enumerate(oldcells)};live={i:{'polygon':shape(c['geometry']),'planes':c['halfplanes'],'origins':[i]} for i,c in enumerate(oldcells)};queue=[];nextid=len(live);merges=[];counts={'considered':0,'outside_domain':0,'nonconvex_rational':0,'no_plane_saving':0,'relaxation_vertex_lost':0,'eligible':0}
    def consider(i,j):
        i,j=sorted((i,j));counts['considered']+=1;a,b=live[i],live[j];g=unary_union([a['polygon'],b['polygon']]).convex_hull
        if not domain.covers(g):counts['outside_domain']+=1;return
        coded=encode(g)
        if coded is None:counts['nonconvex_rational']+=1;return
        g,planes=coded;saving=len(a['planes'])+len(b['planes'])-len(planes)
        if saving<1:counts['no_plane_saving']+=1;return
        origins=sorted(a['origins']+b['origins'])
        if not all(aa*x+bb*y>=cc for oi in origins for x,y in points[oi] for aa,bb,cc in planes):counts['relaxation_vertex_lost']+=1;return
        counts['eligible']+=1;heappush(queue,(-saving,-g.area,i,j,g,planes,origins))
    for i,j in combinations(list(live),2):consider(i,j)
    while queue:
        saving,area,i,j,g,planes,origins=heappop(queue)
        if i not in live or j not in live:continue
        del live[i];del live[j];new=nextid;nextid+=1;live[new]={'polygon':g,'planes':planes,'origins':origins};merges.append({'left':i,'right':j,'created':new,'plane_saving':-saving,'origins':origins})
        for other in list(live):
            if other!=new:consider(other,new)
    cells=[{'geometry':mapping(v['polygon']),'halfplanes':v['planes'],'original_cells':v['origins']} for i,v in sorted(live.items())];union_ok=unary_union([shape(c['geometry']) for c in cells]).equals(domain);record={'row_mode':data['row_mode'],'bracket_mode':data['bracket_mode'],'old_cells':len(oldcells),'cells':len(cells),'old_planes':sum(len(c['halfplanes']) for c in oldcells),'planes':sum(len(c['halfplanes']) for c in cells),'accepted_merges':len(merges),'domain_union_equal':union_ok,'all_old_rational_relaxations_retained':True,'seconds':time.perf_counter()-begin,**counts};write(OUT/'types'/path.name,{'cells':cells,'domain_geometry':data['domain_geometry'],'original_domain_sha256':digest(path),'merges':merges,'summary':record});summary.append(record);print(record,flush=True)
controls=load(OLD/'control-region-checks.json');positive=[]
for r in controls:
    d=load(OUT/'types'/f"{r['row_mode']:02d}-{r['bracket_mode']:02d}.json");x,y=r['delta_um'];positive.append({'control':r['control'],'row':r['row'],'bracket':r['bracket'],'accepted':any(all(a*x+b*y>=v for a,b,v in c['halfplanes']) for c in d['cells'])})
negative=[{'type':path.name,'zero_rejected':not any(all(v<=0 for a,b,v in c['halfplanes']) for c in load(path)['cells'])} for path in sorted((OUT/'types').glob('*.json'))];expanded_planes=sum(r['planes']*(10 if r['row_mode']==12 else 5) for r in summary);selectors=sum(r['cells']*(10 if r['row_mode']==12 else 5) for r in summary);eligible=all(r['domain_union_equal'] for r in summary) and all(r['accepted'] for r in positive) and all(r['zero_rejected'] for r in negative) and expanded_planes<=28640*.75
write(OUT/'positive-controls.json',positive);write(OUT/'negative-controls.json',negative);write(OUT/'summary.json',summary);write(OUT/'result.json',{'seconds':time.perf_counter()-started,'types':len(summary),'typed_cells':sum(r['cells'] for r in summary),'typed_planes':sum(r['planes'] for r in summary),'expanded_selectors':selectors,'expanded_planes':expanded_planes,'plane_reduction_fraction':1-expanded_planes/28640,'accepted_merges':sum(r['accepted_merges'] for r in summary),'all_original_geometric_domains_preserved':all(r['domain_union_equal'] for r in summary),'every_old_accepted_integer_displacement_retained':True,'positive_controls_accepted':sum(r['accepted'] for r in positive),'zero_controls_rejected':sum(r['zero_rejected'] for r in negative),'eligible_pending_independent_audit':eligible,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
