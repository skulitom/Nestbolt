"""Independent exact clipping proves no old displacement is lost by compression."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
from shapely.geometry import shape
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-capacity-20261028';OLD=ROOT/'output/h5-row-bracket-source-20261028';DATA=BASE/'convex-cover-study';OUT=DATA/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clipped(planes):
    polygon=[(F(-1600000),F(-3100000)),(F(1600000),F(-3100000)),(F(1600000),F(3100000)),(F(-1600000),F(3100000))]
    for a,b,c in planes:
        points=[]
        if not polygon:break
        for u,v in zip(polygon,polygon[1:]+polygon[:1]):
            f=a*u[0]+b*u[1]-c;g=a*v[0]+b*v[1]-c
            if f>=0:points.append(u)
            if (f<0 and g>=0) or (g<0 and f>=0):
                t=f/(f-g);points.append((u[0]+t*(v[0]-u[0]),u[1]+t*(v[1]-u[1])))
        polygon=[]
        for p in points:
            if not polygon or polygon[-1]!=p:polygon.append(p)
        if len(polygon)>1 and polygon[0]==polygon[-1]:polygon.pop()
    return polygon
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(DATA/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
counts={'types':0,'old_cells':0,'new_cells':0,'new_planes':0,'old_relaxation_vertices':0,'exact_vertex_plane_checks':0,'empty_old_relaxations':0};records=[];certificates={}
for path in sorted((DATA/'types').glob('*.json')):
    old=load(OLD/'row-bracket'/path.name);data=load(path);assert data['original_domain_sha256']==digest(OLD/'row-bracket'/path.name) and data['domain_geometry']==old['domain_geometry'];domain=shape(data['domain_geometry']);polys=[];seen=set();vertices=[]
    for ix,cell in enumerate(old['cells']):
        vv=clipped(cell['halfplanes']);vertices.append(vv);counts['old_relaxation_vertices']+=len(vv);counts['empty_old_relaxations']+=int(not vv)
        assert all(a*x+b*y>=c for x,y in vv for a,b,c in cell['halfplanes'])
    certificates[path.name]=[[[str(x),str(y)] for x,y in vv] for vv in vertices]
    for cell in data['cells']:
        g=shape(cell['geometry']);assert g.is_valid and not g.interiors and g.equals(g.convex_hull) and domain.covers(g);polys.append(g);vv=[tuple(F(str(v)) for v in xy) for xy in list(g.exterior.coords)[:-1]];assert len(vv)==len(cell['halfplanes']) and sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(vv,vv[1:]+vv[:1]))>0
        for (u,v),(a,b,c) in zip(zip(vv,vv[1:]+vv[:1]),cell['halfplanes']):
            nx,ny=u[1]-v[1],v[0]-u[0];scale=max(abs(nx),abs(ny));nx/=scale;ny/=scale;assert all(nx*(z[0]-u[0])+ny*(z[1]-u[1])>=0 for z in vv) and a==round(nx*10**9) and b==round(ny*10**9);target=(nx*u[0]+ny*u[1])*10**12;error=abs(a-10**9*nx)*1600000+abs(b-10**9*ny)*3100000;assert F(c)>target+error and F(c-1)<=target+error+1;counts['new_planes']+=1
        assert cell['original_cells'] and len(cell['original_cells'])==len(set(cell['original_cells']))
        for oi in cell['original_cells']:
            assert oi not in seen and 0<=oi<len(old['cells']);seen.add(oi);assert g.covers(shape(old['cells'][oi]['geometry']))
            for x,y in vertices[oi]:
                for a,b,c in cell['halfplanes']:assert a*x+b*y>=c;counts['exact_vertex_plane_checks']+=1
        counts['new_cells']+=1
    assert seen==set(range(len(old['cells']))) and unary_union(polys).equals(domain)
    live={i:[i] for i in range(len(old['cells']))};nextid=len(live)
    for m in data['merges']:
        assert m['created']==nextid and m['left'] in live and m['right'] in live and m['left']!=m['right'];provenance=sorted(live.pop(m['left'])+live.pop(m['right']));assert provenance==m['origins'] and m['plane_saving']>0;live[nextid]=provenance;nextid+=1
    assert [live[i] for i in sorted(live)]==[c['original_cells'] for c in data['cells']]
    planes=sum(len(c['halfplanes']) for c in data['cells']);s=data['summary'];assert s['old_cells']==len(old['cells']) and s['cells']==len(data['cells']) and s['planes']==planes and s['accepted_merges']==len(old['cells'])-len(data['cells'])==len(data['merges']) and s['domain_union_equal'];counts['old_cells']+=len(old['cells']);counts['types']+=1;records.append({'row_mode':old['row_mode'],'bracket_mode':old['bracket_mode'],'cells':len(data['cells']),'planes':planes,'all_old_relaxations_contained':True})
positives=[]
for c in load(OLD/'control-region-checks.json'):
    data=load(DATA/'types'/f"{c['row_mode']:02d}-{c['bracket_mode']:02d}.json");x,y=c['delta_um'];positives.append({'control':c['control'],'row':c['row'],'bracket':c['bracket'],'accepted':any(all(a*x+b*y>=v for a,b,v in cell['halfplanes']) for cell in data['cells'])})
negative=[{'type':path.name,'zero_rejected':not any(all(v<=0 for a,b,v in c['halfplanes']) for c in load(path)['cells'])} for path in sorted((DATA/'types').glob('*.json'))];assert positives==load(DATA/'positive-controls.json') and negative==load(DATA/'negative-controls.json') and all(r['accepted'] for r in positives) and all(r['zero_rejected'] for r in negative)
r=load(DATA/'result.json');expanded=sum(v['planes']*(10 if v['row_mode']==12 else 5) for v in records);selectors=sum(v['cells']*(10 if v['row_mode']==12 else 5) for v in records);assert r['expanded_planes']==expanded and r['expanded_selectors']==selectors and r['typed_cells']==counts['new_cells'] and r['typed_planes']==counts['new_planes'];eligible=expanded<=plan['baseline_expanded_planes']*(1-plan['required_expanded_plane_reduction']);assert r['eligible_pending_independent_audit']==eligible
write(OUT/'rational-relaxation-vertices.json',certificates);write(OUT/'types.json',records);write(OUT/'proof.json',{'statement':'Exact rational clipping of each old halfplane cell by the verified global displacement box reconstructs its full bounded continuous relaxation. Every resulting vertex satisfies every new halfplane of its assigned merged cell. Convexity therefore includes the entire old relaxation and, in particular, every old accepted integer displacement. Every old cell is assigned exactly once. New halfplanes point strictly inward with bounded exact coefficient-rounding error, and each new geometric cell lies in the unchanged source-free domain. Their union equals that domain. This proves no loss of old model placements and no loss of the prior original-source clearance guarantee.','selection':'The geometry proof passes but selection additionally requires the frozen25percent plane reduction;4.3994413407821176percent is insufficient. No compressed model or solver call follows.'})
inputs=[DATA/'plan.json',DATA/'result.json',DATA/'summary.json',DATA/'positive-controls.json',DATA/'negative-controls.json']+list((DATA/'types').glob('*.json'))+[OLD/'geometry-audit/plan.json',OLD/'geometry-audit/checks.json'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,**counts,'expanded_selectors':selectors,'expanded_planes':expanded,'plane_reduction_fraction':1-expanded/28640,'positive_controls_verified':len(positives),'negative_controls_verified':len(negative),'every_old_accepted_integer_displacement_preserved':True,'original_source_domains_unchanged':True,'eligible':eligible,'selected':False,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
