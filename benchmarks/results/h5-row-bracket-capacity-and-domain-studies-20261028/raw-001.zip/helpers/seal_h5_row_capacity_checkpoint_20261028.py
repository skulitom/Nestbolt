"""Seal the closed capacity search and both rejected finite domain studies."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-row-bracket-capacity-20261028';PUB=BASE/'publication';NAME='h5-row-bracket-capacity-and-domain-studies-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='0b84eb8937e0243239c30b6fcc19066c948fa980' and not git('diff','HEAD','--name-only')
for a in ['geometry-audit','capacity-audit','model-audit','source-bridge-audit','row-identity-audit','response-audit','convex-cover-study/audit','periodic-inventory/audit']:assert load(BASE/a/'checks.json')['passed']
response=load(BASE/'search/result.json');assert response['closed'] and response['solver_calls']==1 and response['status']=='UNKNOWN' and not response['has_solution'];model=load(BASE/'model-audit/checks.json');assert model['prior_variables_constraints_and_hints_byte_identical'] and model['all3_ancestor_models_fully_reverified'] and model['all10_capacity_sweeps_match_geometric_preflight']
convex=load(BASE/'convex-cover-study/audit/checks.json');periodic=load(BASE/'periodic-inventory/audit/checks.json');assert convex['every_old_accepted_integer_displacement_preserved'] and not convex['eligible'] and not convex['selected'];assert periodic['size_prefilter_failed'] and not periodic['selected']
prior=load(ROOT/'benchmarks/results/h5-movable-row-bracket-and-capacity-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];assert main=='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58';jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for p in BASE.rglob('*'):
    if p.is_file():add(BASE.name+'/'+p.relative_to(BASE).as_posix(),p)
helpers=set((ROOT/'output').glob('*row_capacity*20261028.py'));helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','verify_h5_row_capacity_archive_20261028.py',Path(__file__).name])
for p in helpers:add('helpers/'+p.name,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('capacity-audit/checks.json','capacity-containment-audit.json'),('capacity-audit/necessity-proof.json','capacity-necessity-proof.json'),('model/built.json','model-built.json'),('model-audit/checks.json','model-audit.json'),('model-audit/control-checks.json','model-controls.json'),('source-bridge-audit/checks.json','source-bridge-audit.json'),('row-identity-audit/checks.json','row-identity-audit.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json'),('convex-cover-study/result.json','convex-cover-result.json'),('convex-cover-study/audit/checks.json','convex-cover-audit.json'),('convex-cover-study/audit/proof.json','convex-cover-proof.json'),('periodic-inventory/result.json','periodic-inventory-result.json'),('periodic-inventory/audit/checks.json','periodic-inventory-audit.json')]:shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_prior_checkpoint':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40777420353,'main_all6_pass':True,'normal_atomic_push_ready_after_checkpoint_commit_and_fresh_ref_check':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False});write(OUT/'checks.json',{'passed':True,'full_target_originals':66,'mandatory_blocks':43,'first_sheet_originals':54,'fixed_short_originals':12,'closed_solver_calls':1,'solver_status':'UNKNOWN','source_valid66_count':0,'actual_or_global_infeasibility_claimed':False,'convex_cover_preserves_all_old_integer_displacements_but_fails_size_filter':True,'periodic_inventory_fails_size_and_has_unresolved_equality_discrepancies':True,'domain_replacements_selected':0,'valid64_preserved':True,'remaining_necessary_allocations':444,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
