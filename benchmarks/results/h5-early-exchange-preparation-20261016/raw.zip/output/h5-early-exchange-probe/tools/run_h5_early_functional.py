"""Preserve isolated functional/build outcomes; never share Cargo target caches."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parents[1]
out = root / 'output/h5-early-exchange-probe'
arm, name, *command = sys.argv[1:]
assert arm in ['baseline', 'candidate'] and command
workspace = out / arm
target = root / ('output/h5-early-exchange-' + arm + '-target')
log = out / (arm + '-' + name + '.log')
assert not log.exists()
source_paths = ['crates/core/src/sheets.rs', 'crates/core/src/sheets/vstrip.rs',
                'crates/core/src/sheets/vstrip/exchange.rs',
                'crates/core/src/separate/score.rs', 'crates/core/examples/exchange_probe.rs']
with zipfile.ZipFile(out / (arm + '-' + name + '-sources.zip'), 'x', zipfile.ZIP_DEFLATED) as archive:
    for path in source_paths:
        if (workspace / path).exists():
            archive.write(workspace / path, path)
if command[0] == 'cargo' and command[1] not in ['fmt']:
    if '--' in command:
        index = command.index('--')
        command[index:index] = ['--target-dir', str(target)]
    else:
        command += ['--target-dir', str(target)]
command = [sys.executable, str(root / 'output/ccd1.py'), *command]
started = datetime.now(timezone.utc).isoformat()
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=workspace, stdout=stream, stderr=subprocess.STDOUT)
record = {'arm': arm, 'name': name, 'command': command, 'started': started,
          'finished': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode,
          'scope': 'CCD1 functional/build verification only; no measured quality or speed claim',
          'log_sha256': sha256(log.read_bytes()).hexdigest()}
if result.returncode == 0 and name == 'observer-build':
    binary = out / ('nestbolt-' + arm + '-observer.exe')
    assert not binary.exists()
    shutil.copyfile(target / 'release/examples/exchange_probe.exe', binary)
    record['binary_sha256'] = sha256(binary.read_bytes()).hexdigest()
(out / (arm + '-' + name + '.json')).write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(record), flush=True)
print(log.read_text(encoding='utf-8', errors='replace')[-5000:])
raise SystemExit(result.returncode)
