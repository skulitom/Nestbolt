"""Fix a report-field assertion, preserving and rechecking completed outcomes."""
from hashlib import sha256
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
out = root/'output/h5-early-exchange-probe/public-checks-v1'
failure = json.loads((out/'failure.json').read_bytes())
assert failure['error'].endswith("KeyError: 'validation'\n")
assert not (out/'checks.json').exists()
original = root/'output/check_h5_early_public.py'
(out/'original-checker.py').write_bytes(original.read_bytes())
inventory = {p.relative_to(out).as_posix(): sha256(p.read_bytes()).hexdigest()
             for p in sorted(out.rglob('*')) if p.is_file()}
(out/'completed-before-repair.json').write_text(json.dumps(inventory, indent=2)+'\n', encoding='utf-8', newline='\n')
source = original.read_text(encoding='utf-8')
source = source.replace('out.mkdir(exist_ok=False)', "assert out.exists() and (out/'failure.json').exists()")
source = source.replace("    path.write_text(json.dumps(value, indent=2)+'\\n', encoding='utf-8', newline='\\n')", "    if path.name == 'plan.json' and path.exists():\n        assert load(path) == value\n        return\n    path.write_text(json.dumps(value, indent=2)+'\\n', encoding='utf-8', newline='\\n')")
source = source.replace("    shutil.copyfile(root / 'output/h5-exchange-probe/public-work-v7' / name, out / name)", "    assert (root / 'output/h5-exchange-probe/public-work-v7' / name).read_bytes() == (out / name).read_bytes()")
source = source.replace("shutil.copyfile(root / 'target/release/nestbolt.exe', cli)", "assert (root / 'target/release/nestbolt.exe').read_bytes() == cli.read_bytes()\nfor name, expected in load(out/'completed-before-repair.json').items():\n    assert digest(out/name) == expected")
source = source.replace("def run(command, name):\n    result", """def run(command, name):
    cached = [out/(name+'-command.json'), out/(name+'-stdout.json'), out/(name+'-stderr.log')]
    if any(p.exists() for p in cached):
        assert all(p.exists() for p in cached), 'Partial output must be investigated'
        record = load(cached[0])
        assert record['exit_code'] == 0 and record['command'] == list(map(str, command))
        return subprocess.CompletedProcess(list(map(str, command)), 0, cached[1].read_bytes(), cached[2].read_bytes())
    result""")
source = source.replace("load(folder/'cutting-report.json')['validation']['valid']", "load(folder/'cutting-report.json')['valid']")
source = source.replace("write(out/'progress.json'", "write(out/'progress-v2.json'")
source = source.replace("write(out/'failure.json'", "write(out/'failure-v2.json'")
target = root/'output/check_h5_early_public_v2.py'
assert not target.exists()
compile(source, str(target), 'exec')
target.write_text(source, encoding='utf-8', newline='\n')
(out/'checker-repair.json').write_text(json.dumps({
    'original_failure_retained': True, 'cause': 'The cutting report is already a Report with a top-level valid field, not a nested validation field.',
    'product_changed': False, 'completed_outcomes_reused_without_rerunning': True,
    'reuse': 'Verify every completed file hash, require all three process logs, zero exit status and the exact command before reading saved stdout/stderr.',
    'new_source_sha256': sha256(target.read_bytes()).hexdigest(),
}, indent=2)+'\n', encoding='utf-8', newline='\n')
print('Prepared a corrected assertion with verified reuse of completed functional outcomes.')
