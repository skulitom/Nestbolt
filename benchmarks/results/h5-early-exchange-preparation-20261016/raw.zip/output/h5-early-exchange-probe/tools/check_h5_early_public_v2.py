"""Authored fixed-work checks of the new public search path, on CCD1 only."""
from hashlib import sha256
from pathlib import Path
import copy
import json
import shutil
import subprocess
import traceback
import psutil

root = Path(__file__).resolve().parents[1]
probe = root / 'output/h5-early-exchange-probe'
out = probe / 'public-checks-v1'
assert out.exists() and (out/'failure.json').exists()
psutil.Process().cpu_affinity(list(range(16, 32)))
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(path, value):
    if path.name == 'plan.json' and path.exists():
        assert load(path) == value
        return
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')
for name in ['library.json', 'normal.json', 'common.json']:
    assert (root / 'output/h5-exchange-probe/public-work-v7' / name).read_bytes() == (out / name).read_bytes()
cli = out / 'nestbolt-validator.exe'
assert (root / 'target/release/nestbolt.exe').read_bytes() == cli.read_bytes()
for name, expected in load(out/'completed-before-repair.json').items():
    assert digest(out/name) == expected
binaries = {arm: probe / ('nestbolt-' + arm + '-observer.exe') for arm in ['baseline', 'candidate']}
for arm, path in binaries.items():
    assert digest(path) == load(probe / (arm + '-observer-build.json'))['binary_sha256']
assert digest(binaries['baseline']) != digest(binaries['candidate'])
guards = {str(p.relative_to(root)): digest(p) for p in [cli, *binaries.values(),
          out/'library.json', out/'normal.json', out/'common.json']}
write(out/'plan.json', {'scope': __doc__, 'seconds': 20, 'seeds': [0, 1],
    'arms': list(binaries), 'modes': ['normal', 'common'], 'candidate_common_replays': 2,
    'public_CLI_cross_checks': 4, 'guards': guards, 'held_out_geometry_read': False,
    'performance_measurement': False})

def run(command, name):
    cached = [out/(name+'-command.json'), out/(name+'-stdout.json'), out/(name+'-stderr.log')]
    if any(p.exists() for p in cached):
        assert all(p.exists() for p in cached), 'Partial output must be investigated'
        record = load(cached[0])
        assert record['exit_code'] == 0 and record['command'] == list(map(str, command))
        return subprocess.CompletedProcess(list(map(str, command)), 0, cached[1].read_bytes(), cached[2].read_bytes())
    result = subprocess.run(list(map(str, command)), capture_output=True, timeout=90)
    (out/(name+'-stdout.json')).write_bytes(result.stdout)
    (out/(name+'-stderr.log')).write_bytes(result.stderr)
    write(out/(name+'-command.json'), {'command': list(map(str, command)), 'exit_code': result.returncode})
    assert result.returncode == 0, (name, result.stderr.decode(errors='replace'))
    return result

def deterministic(result):
    result = copy.deepcopy(result)
    result.pop('elapsed_seconds')
    return result

records = []
try:
    for seed in [0, 1]:
        for mode in ['normal', 'common']:
            observed = {}
            for arm, binary in binaries.items():
                name = f'{arm}-{mode}-s{seed}'
                folder = out/name
                run([binary, out/'library.json', out/(mode+'.json'), folder, 20, seed, 'work'], name)
                result = load(folder/'search.json')
                assert result['repeatable'] and result['validation']['valid']
                assert len(result['layout']['placements']) == 24
                checked = json.loads(run([cli, 'validate', '--library', out/'library.json',
                    '--request', out/(mode+'.json'), '--layout', folder/'layout.json'], name+'-validate').stdout)
                assert checked['valid'] and checked['metrics'] == result['validation']['metrics']
                if mode == 'common':
                    assert result['riders'] == 0
                    assert load(folder/'cutting-report.json')['valid']
                if arm == 'baseline':
                    reference = out / (name+'-cli')
                    run([cli, 'nest', '--library', out/'library.json', '--request', out/(mode+'.json'),
                        '--out-dir', reference, '--seconds', 20, '--seed', seed,
                        '--repeatable', '--time-limit', 30], name+'-cli')
                    assert load(reference/'layout.json') == result['layout']
                    assert load(reference/'report.json')['validation'] == result['validation']
                elif mode == 'common':
                    replay = out/(name+'-replay')
                    run([binary, out/'library.json', out/(mode+'.json'), replay, 20, seed, 'work'], name+'-replay')
                    assert deterministic(load(replay/'search.json')) == deterministic(result)
                    assert load(replay/'cutting-report.json') == load(folder/'cutting-report.json')
                observed[arm] = result
                records.append({'arm': arm, 'mode': mode, 'seed': seed,
                    'repeatable': True, 'valid': True, 'stats': result['stats'],
                    'material': result['validation']['metrics']['normalized_material']})
                write(out/'progress-v2.json', records)
            if mode == 'normal':
                assert deterministic(observed['baseline']) == deterministic(observed['candidate'])
                assert observed['candidate']['stats'].get('directed_exchange_attempts', 0) == 0
    assert all(digest(root/path) == expected for path, expected in guards.items())
    write(out/'checks.json', {'all_checks_passed': True, 'observer_outcomes': 10,
        'CLI_cross_checks': 4, 'normal_full_result_exact_except_elapsed_wall': True,
        'common_candidate_replay_exact_except_elapsed_wall': True,
        'independent_metrics_exact': True, 'records': records,
        'guards_unchanged': True, 'held_out_geometry_read': False,
        'quality_or_speed_claim': False})
except BaseException:
    write(out/'failure-v2.json', {'error': traceback.format_exc(), 'records': records})
    raise
print(json.dumps({'all_checks_passed': True, 'records': records}))
