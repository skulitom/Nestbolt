"""Prepare a new isolated early-exchange candidate; preserve the rejected pilot."""
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
out = root / 'output/h5-early-exchange-probe'
out.mkdir(exist_ok=False)
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
chosen = [p for p in paths if p.startswith(('crates/', '.cargo/')) or p in
          ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'LICENSE', 'THIRD_PARTY_NOTICES')]
files = []
for name in chosen:
    source = root / name
    files.append({'path': name, 'sha256': sha256(source.read_bytes()).hexdigest()})
    for arm in ['baseline', 'candidate']:
        dest = out / arm / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)

old = root / 'output/h5-exchange-probe/workspace'
experimental = ['crates/core/src/sheets.rs', 'crates/core/src/sheets/vstrip.rs',
                'crates/core/src/sheets/vstrip/exchange.rs']
old_sources = []
for name in experimental:
    source = old / name
    dest = out / 'candidate' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    old_sources.append({'path': name, 'sha256': sha256(source.read_bytes()).hexdigest()})

path = out / 'candidate/crates/core/src/sheets/vstrip.rs'
text = path.read_text(encoding='utf-8')
before = '''                        let gaps = std::env::var_os("NESTBOLT_NO_FILL").is_none();
                        if (gaps && timed("fill", || self.fill_gaps(&strip, &mut sep, shape)) > 0)'''
after = '''                        // The feasible initial state is an opportunity even
                        // when one separator call later consumes exploration.
                        // Share the existing relocation budget; run before fill
                        // can short-circuit the ordinary relocation path.
                        let exchanged = if self.allow_exchange {
                            let exchange_until = (t + 1.2).min(budget);
                            timed("exchange", || {
                                self.directed_exchange(
                                    &strip,
                                    frozen,
                                    &mut sep,
                                    shape,
                                    exchange_until,
                                )
                            })?
                        } else {
                            0
                        };
                        let gaps = std::env::var_os("NESTBOLT_NO_FILL").is_none();
                        if exchanged > 0
                            || (gaps && timed("fill", || self.fill_gaps(&strip, &mut sep, shape)) > 0)'''
assert text.count(before) == 1
text = text.replace(before, after)
before = '''                        let exchanged = if self.allow_exchange {
                            let exchange_until = (started + 1.2).min(budget);
                            timed("exchange", || {
                                self.directed_exchange(
                                    &strip,
                                    frozen,
                                    &mut sep,
                                    shape,
                                    exchange_until,
                                )
                            })?
                        } else {
                            0
                        };
                        if exchanged > 0
                            || timed("relocate", || {
                                self.relocate(&strip, &mut sep, shape, budget)
                            })? > 0'''
after = '''                        if timed("relocate", || {
                            self.relocate(&strip, &mut sep, shape, budget)
                        })? > 0'''
assert text.count(before) == 1
text = text.replace(before, after)
path.write_text(text, encoding='utf-8', newline='\n')

driver = root / 'output/h5-exchange-probe/exchange_probe.rs'
for arm in ['baseline', 'candidate']:
    dest = out / arm / 'crates/core/examples/exchange_probe.rs'
    dest.parent.mkdir(parents=True, exist_ok=True)
    assert not dest.exists()
    shutil.copyfile(driver, dest)

record = {
    'baseline_product_commit': '7eba929420d218d04169c1fdf24481051c8afae5',
    'head_at_preparation': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'hypothesis': 'Try directed exchange at the first feasible window state, before fill/relocation can short-circuit it, sharing the existing ten-percent relocation budget and capped at 1.2 seconds; remove the unvisited late exchange hook.',
    'scope': 'Authored functional checks and builds on CCD1 only. No measured searches until the active H4 matrix finishes. No reserved inputs.',
    'production_files': files,
    'previous_candidate_source': old_sources,
    'driver_sha256': sha256(driver.read_bytes()).hexdigest(),
    'target_directories': {arm: str(root / ('output/h5-early-exchange-' + arm + '-target')) for arm in ['baseline', 'candidate']},
    'root_sources_unchanged': True,
    'measurement_started': False,
}
(out / 'preparation.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
print('Prepared two isolated workspaces with separate build directories.')
