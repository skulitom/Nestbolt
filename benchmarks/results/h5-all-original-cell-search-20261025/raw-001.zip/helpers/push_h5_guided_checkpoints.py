"""Normal main update after terminal prior CI, with exact receipts."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-guided-main-sync-20261025';OUT.mkdir()
def run(args,name):
    start=datetime.now(timezone.utc).isoformat();r=subprocess.run(args,cwd=ROOT,capture_output=True,text=True)
    row={'command':args,'started_at':start,'completed_at':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    with (OUT/(name+'.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(row,f,indent=2);f.write('\n')
    r.check_returncode();return r.stdout.strip()
ci=json.loads(run(['gh','run','view','40242602102','--json','databaseId,status,conclusion,headSha,jobs,url'],'prior-ci'))
assert ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
run(['git','fetch','origin','main'],'fetch');head=run(['git','rev-parse','HEAD'],'head-before');main=run(['git','rev-parse','origin/main'],'main-before')
assert head=='728b2db2e86c2d123920fdceb8e3e2c1bcf1f66e' and main=='613594568fb49a71abf0248aec218a6b12f63319' and ci['headSha']==main
assert run(['git','rev-list','--left-right','--count','origin/main...HEAD'],'ahead-before').split()==['0','10']
assert not run(['git','diff','HEAD','--name-only'],'tracked-before')
assert not run(['git','diff','--name-only','origin/main...HEAD','--','crates','scripts','web','Cargo.toml','Cargo.lock','.github','README.md','README.ja.md','README.zh-CN.md'],'production-and-readmes-before')
run(['git','push','origin','HEAD:main'],'push')
assert run(['git','ls-remote','origin','refs/heads/main'],'remote-main-after').split()[0]==head
assert run(['git','rev-parse','origin/main'],'tracking-main-after')==head
run(['gh','run','list','--repo','skulitom/Nestbolt','--branch','main','--commit',head,'--limit','10','--json','databaseId,name,status,conclusion,headSha,url,createdAt,updatedAt'],'new-ci-initial')
receipt={'source_head':head,'previous_main':main,'pushed_commits':10,'normal_fast_forward_push':True,'remote_main_verified':True,'previous_successful_ci':40242602102,
    'previous_ci_successful_jobs':6,'new_ci_pass_claimed':False,'production_and_readmes_unchanged':True,'H2_complete':False,'H5_complete':False,'completion_percent':60}
with (OUT/'receipt.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(receipt,flush=True)
