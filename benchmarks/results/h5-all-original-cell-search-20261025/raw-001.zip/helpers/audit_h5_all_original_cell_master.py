"""Full protobuf oracle for the original nine-coordinate guarded-cell model."""
from collections import Counter
from itertools import product
from ortools.sat import cp_model_pb2
from audit_h5_six_cog_guided_master import verify as verify_base
def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,atlas,added,new_pairs,witness,cells,cell_witness,six,remaining_plan,remaining,exclusion):
    new_parts=[0,1,2];modes=sum(len(spec['parts'][i]['queries']) for i in new_parts)
    domains=sum(len(queries[q]['domains']) for i in new_parts for q in spec['parts'][i]['queries'])
    planes=sum(len(d['halfplanes']) for i in new_parts for q in spec['parts'][i]['queries'] for d in queries[q]['domains'])
    uses=sum(len(c['physical_pairs']) for c in remaining_plan['cases']);flags=sum(len(c['physical_pairs'])*len(remaining[c['index']]['domains']) for c in remaining_plan['cases'])
    cellplanes=sum(len(c['physical_pairs'])*sum(len(d['halfplanes']) for d in remaining[c['index']]['domains']) for c in remaining_plan['cases'])
    nv=6+uses+flags;nc=2*modes+2*domains+planes+6*uses+2*flags+cellplanes+1
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.variables[-nv:];del prefix.constraints[-nc:]
    mapping,stats=verify_base(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,atlas,added,new_pairs,witness,cells,cell_witness,six)
    vi=len(prefix.variables);ci=len(prefix.constraints);positions=[];pairmodes=[]
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name);vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        coefficients=Counter()
        for v,c in terms:coefficients[v]+=c
        ids=sorted(v for v,c in coefficients.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(coefficients[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en)
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(literals):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend(literals);assert actual.constraints[ci]==p,(ci,literals);ci+=1
    for i in new_parts:
        p=mapping['parts'][i];allboxes=[d['coordinate_bounds'] for m in p['modes'] for d in queries[m['query']]['domains']];b=[min(d[k] for d in allboxes) if k<2 else max(d[k] for d in allboxes) for k in range(4)]
        x=var(f"original{i}-anchor-x",b[0],b[2]);y=var(f"original{i}-anchor-y",b[1],b[3]);positions.append({'part':i,'x':x,'y':y})
        for m in p['modes']:
            ds=queries[m['query']]['domains'];b=[min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)]
            linear([(x,1)],b[0],b[2],[m['active']]);linear([(y,1)],b[1],b[3],[m['active']])
            for row,selector in enumerate(m['domains']):
                d=ds[row];b=d['coordinate_bounds'];linear([(x,1)],b[0],b[2],[selector]);linear([(y,1)],b[1],b[3],[selector])
                for h in d['halfplanes']:linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[selector])
    positions+=mapping['simultaneous_cog_coordinates'];assert [p['part'] for p in positions]==list(range(9))
    expected_uses=set()
    for c in remaining_plan['cases']:
        ds=remaining[c['index']]['domains'];r=remaining[c['index']]['difference_bounds_units1000'];qa,qb=c['query_a'],c['query_b']
        for i,j in c['physical_pairs']:
            assert i<j and (i,j,qa,qb) not in expected_uses;expected_uses.add((i,j,qa,qb))
            a,b=positions[i],positions[j];ma=next(m for m in mapping['parts'][i]['modes'] if m['query']==qa);mb=next(m for m in mapping['parts'][j]['modes'] if m['query']==qb)
            active=var(f"original-pair{i}-{j}-case{c['index']}-active",0,1)
            boolean([-active-1,ma['active']]);boolean([-active-1,mb['active']]);boolean([active,-ma['active']-1,-mb['active']-1])
            linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[active]);linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[active]);choices=[]
            for d in ds:
                flag=var(f"original-pair{i}-{j}-case{c['index']}-cell{d['index']}",0,1);choices.append({'index':d['index'],'flag':flag});db=d['coordinate_bounds']
                linear([(b['x'],1),(a['x'],-1)],db[0],db[2],[flag]);linear([(b['y'],1),(a['y'],-1)],db[1],db[3],[flag])
                for h in d['halfplanes']:linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],-2**63,h['bound'],[flag])
            linear([(f['flag'],1) for f in choices]+[(active,-1)],0,0);pairmodes.append({'parts':[i,j],'case':c['index'],'query_a':qa,'query_b':qb,'active':active,'cells':choices})
    assert expected_uses=={(a['part'],b['part'],qa,qb) for a in spec['parts'] for b in spec['parts'] if a['part']<b['part'] for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet'] and [spec['queries'][qa]['profile'],spec['queries'][qb]['profile']]!=[9,9]}
    assert exclusion['fully_replayed_clause_tree'] and [p['part'] for p in exclusion['parts']]==list(range(9));nogood=[]
    for e in exclusion['parts']:
        p=mapping['parts'][e['part']];q=next(m for m in p['modes'] if m['query']==e['query']);assert e['item']==p['item'] and queries[e['query']]['domains'][e['domain_row']]['index']==e['domain_index'];nogood.append(-q['domains'][e['domain_row']]-1)
    boolean(nogood)
    assert vi==len(actual.variables) and ci==len(actual.constraints) and actual.solution_hint==prefix.solution_hint
    for a,b,active in product([0,1],repeat=3):assert bool((not active or a) and (not active or b) and (active or not a or not b))==(active==int(a and b))
    mapping['simultaneous_original_coordinates']=positions;mapping['remaining_original_cell_pairs']=pairmodes
    return mapping,{**stats,'variables':vi,'constraints':ci,'simultaneous_original_anchor_variables':18,'additional_original_domain_options':domains,'additional_domain_inward_halfplanes':planes,'additional_domain_axis_bounds':2*domains,
        'additional_query_axis_bounds':2*modes,'remaining_original_pair_mode_uses':uses,'remaining_pair_activation_flags':uses,'remaining_cell_flags':flags,'remaining_cell_halfplanes':cellplanes,
        'all36_physical_pairs_have_full_guarded_coordinates':True,'all_original_profile_modes_accounted_for':True,'all_original_pair_activation_truth_tables_checked':True,'certified_selected_combination_exclusions':1,
        'remaining_original_pairs_need_full_coordinate_validation':False,'original_geometry_and_native_validation_still_required':True,'hints':79,'optional_originals':0,'required_originals':66}
