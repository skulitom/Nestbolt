"""Preserve a representation-order failure; keep exact cell-safety checks."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-remaining-displacement-cells-20261025'
s=(ROOT/'output/audit_h5_remaining_displacement_cells.py').read_text(encoding='utf-8')
s=s.replace("OUT=BASE/'audit'","OUT=BASE/'audit-repaired'")
needle="obstacle=unary_union(enclosures) if enclosures else GeometryCollection();assert obstacle.equals(shape(original['outward_forbidden_union']))"
replacement="reconstructed=unary_union(enclosures) if enclosures else GeometryCollection();obstacle=shape(original['outward_forbidden_union']);assert reconstructed.equals(obstacle)"
assert needle in s;s=s.replace(needle,replacement)
with (ROOT/'output/audit_h5_remaining_displacement_cells_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (BASE/'audit/repair-record.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_failure_preserved':True,'failure':'Expanded selected forbidden geometry equals_exact assertion failed after reconstructing an equal union from reoriented enclosure polygons.',
        'repair':'Still reconstruct and verify the full original outward union by geometric equality. Recompute simplification from the recorded union ring ordering, because topology-preserving simplification can depend on that ordering. Keep zero-tolerance comparison to the selected recorded expanded geometry and all independent exact whole-cell safety certificates.',
        'original_construction_restarted':False,'solver_calls':0,'audit_safety_requirements_unchanged':True},f,indent=2);f.write('\n')
print('Prepared separate repaired audit; original failed audit and all geometry remain unchanged.')
