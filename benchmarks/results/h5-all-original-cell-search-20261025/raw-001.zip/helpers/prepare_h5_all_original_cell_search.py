"""Prepare a distinct complete nine-anchor model; no solver invocation here."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'output'
s=(R/'solve_h5_six_cog_guided_master.py').read_text(encoding='utf-8')
s=s.replace('h5-six-cog-guided-search-20261025/shared-search','h5-all-original-cell-search-20261025/shared-search').replace('from audit_h5_six_cog_guided_master import verify','from audit_h5_all_original_cell_master import verify')
needle="    pair_exclusions=load(PROOF/"
insert="""    remainingpath=ROOT/'output/h5-remaining-displacement-cells-20261025';assert load(remainingpath/'audit-repaired/checks.json')['passed'];remaining_plan=load(remainingpath/'plan.json');remaining={c['index']:load(remainingpath/'cases'/f"{c['index']:03d}"/'selected.json') for c in remaining_plan['cases']}
    exclusionpath=ROOT/'output/h5-six-cog-guided-search-20261025/conflict-proof-audit-completed';assert load(exclusionpath/'checks.json')['passed'];exclusion=load(exclusionpath/'certified-selected-combination-exclusion.json')
"""
assert needle in s;s=s.replace(needle,insert+needle)
s=s.replace("ROOT/'output/audit_h5_six_cog_guided_master.py',","ROOT/'output/audit_h5_all_original_cell_master.py',remainingpath/'plan.json',remainingpath/'audit-repaired/checks.json',exclusionpath/'checks.json',exclusionpath/'certified-selected-combination-exclusion.json',")
s=s.replace("    write(OUT/'plan.json',", "    inputs += [remainingpath/'cases'/f\"{c['index']:03d}\"/'selected.json' for c in remaining_plan['cases']]\n    write(OUT/'plan.json',",1)
a=s.index("        'method':");b=s.index("    start=time.perf_counter();",a)
s=s[:a]+"""        'method':'A new complete nine-anchor model. Retain the fully audited hinted six-cog master and every original domain, area, occupancy and exclusion constraint. Add the two bracket anchors and insert anchor, all selected-query and selected-domain bounds, and every source inward halfplane. For all 364 remaining same-sheet query/physical-pair uses, require exact AND activation and exactly one independently proved guarded displacement cell when active, with explicit whole difference bounds. Every one of the 36 physical moving-original pairs now has complete guarded coordinate separation. Include the independently certified prior nine-domain exclusion. All 66 originals remain mandatory: nine movable, 57 fixed. Keep 79 advisory cog hints, not fixed placements. The remaining-pair simplification adds only explicit constructive restrictions; a negative does not prove unrestricted impossibility. Independently reconstruct every protobuf field before one 45-second-cap/eight-worker/seed-zero call within the shared 60-second budget with two seconds reserve. Positive integer positions still require complete original geometry and native validation. Offline cell preparation is not a production-budget qualification; H5 remains open.'})
"""+s[b:]
marker="    mapping={'parts':parts"
insert="""    original_positions=[]
    for i in [0,1,2]:
        p=parts[i];boxes=[d['coordinate_bounds'] for m in p['modes'] for d in queries[m['query']]['domains']];b=[min(d[k] for d in boxes) if k<2 else max(d[k] for d in boxes) for k in range(4)]
        x=var(f'original{i}-anchor-x',b[0],b[2]);y=var(f'original{i}-anchor-y',b[1],b[3]);original_positions.append({'part':i,'x':x,'y':y})
        for m in p['modes']:
            ds=queries[m['query']]['domains'];b=[min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)]
            model.add_linear_constraint(vs[x],b[0],b[2]).only_enforce_if(vs[m['active']]);model.add_linear_constraint(vs[y],b[1],b[3]).only_enforce_if(vs[m['active']])
            for row,selector in enumerate(m['domains']):
                d=ds[row];b=d['coordinate_bounds'];model.add_linear_constraint(vs[x],b[0],b[2]).only_enforce_if(vs[selector]);model.add_linear_constraint(vs[y],b[1],b[3]).only_enforce_if(vs[selector])
                for h in d['halfplanes']:model.add_linear_constraint(vs[x]*h['a']+vs[y]*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[selector])
    original_positions+=cog_positions;remaining_pairs=[]
    for c in remaining_plan['cases']:
        ds=remaining[c['index']]['domains'];r=remaining[c['index']]['difference_bounds_units1000']
        for i,j in c['physical_pairs']:
            a,b=original_positions[i],original_positions[j];qa=next(m for m in parts[i]['modes'] if m['query']==c['query_a']);qb=next(m for m in parts[j]['modes'] if m['query']==c['query_b'])
            active=var(f"original-pair{i}-{j}-case{c['index']}-active",0,1)
            model.add_bool_or([vs[active].Not(),vs[qa['active']]]);model.add_bool_or([vs[active].Not(),vs[qb['active']]]);model.add_bool_or([vs[active],vs[qa['active']].Not(),vs[qb['active']].Not()])
            model.add_linear_constraint(vs[b['x']]-vs[a['x']],r[0],r[2]).only_enforce_if(vs[active]);model.add_linear_constraint(vs[b['y']]-vs[a['y']],r[1],r[3]).only_enforce_if(vs[active]);flags=[]
            for d in ds:
                flag=var(f"original-pair{i}-{j}-case{c['index']}-cell{d['index']}",0,1);flags.append({'index':d['index'],'flag':flag});rbox=d['coordinate_bounds']
                model.add_linear_constraint(vs[b['x']]-vs[a['x']],rbox[0],rbox[2]).only_enforce_if(vs[flag]);model.add_linear_constraint(vs[b['y']]-vs[a['y']],rbox[1],rbox[3]).only_enforce_if(vs[flag])
                for h in d['halfplanes']:model.add_linear_constraint((vs[b['x']]-vs[a['x']])*h['a']+(vs[b['y']]-vs[a['y']])*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[flag])
            linear([(f['flag'],1) for f in flags]+[(active,-1)],0,0);remaining_pairs.append({'parts':[i,j],'case':c['index'],'query_a':c['query_a'],'query_b':c['query_b'],'active':active,'cells':flags})
    banned=[]
    for e in exclusion['parts']:
        m=next(m for m in parts[e['part']]['modes'] if m['query']==e['query']);banned.append(vs[m['domains'][e['domain_row']]].Not())
    model.add_bool_or(banned)
"""
assert marker in s;s=s.replace(marker,insert+marker,1)
s=s.replace("'guarded_displacement_cell_pairs':cell_pairs};write", "'guarded_displacement_cell_pairs':cell_pairs,'simultaneous_original_coordinates':original_positions,'remaining_original_cell_pairs':remaining_pairs};write")
s=s.replace('new_pairs,witness,cells,cell_witness,six);','new_pairs,witness,cells,cell_witness,six,remaining_plan,remaining,exclusion);')
needle="        write(OUT/'guarded-cog-cell-selection.json',chosen_cells)"
extra="""
        write(OUT/'original-positions.json',[{'part':p['part'],'x_units':solver.value(vs[p['x']]),'y_units':solver.value(vs[p['y']])} for p in original_positions])
        write(OUT/'remaining-cell-selection.json',[{'parts':p['parts'],'case':p['case'],'active':bool(solver.value(vs[p['active']])),'chosen_cells':[c['index'] for c in p['cells'] if solver.value(vs[c['flag']])]} for p in remaining_pairs])
"""
assert needle in s;s=s.replace(needle,needle+extra)
s=s.replace("'has_necessary_domain_candidate':feasible,","'has_necessary_domain_candidate':feasible,'has_full_original_model_candidate':feasible,")
s=s.replace("A feasible assignment has full guarded original-cog anchors and still requires full guarded-coordinate validation of every original", "A feasible assignment has full guarded coordinates for all nine moving originals and still requires complete original geometry and native validation")
with (R/'solve_h5_all_original_cell_master.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared full original-coordinate guarded-cell model; no solver launched.')
