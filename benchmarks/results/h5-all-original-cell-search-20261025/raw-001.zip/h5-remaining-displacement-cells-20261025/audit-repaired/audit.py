"""Independently prove every retained remaining-pair displacement cell safe."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,math,shutil,time,traceback
from shapely.geometry import shape,GeometryCollection
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from audit_h5_cog_displacement_cells import intersect,decode,normal,separator,exact_gap
from audit_h5_full_original_joint_domains import check_planes
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-remaining-displacement-cells-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'audit-repaired'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert (BASE/'result.json').is_file();OUT.mkdir();(OUT/'certificates').mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    plan=load(BASE/'plan.json');result=load(BASE/'result.json');summary=load(BASE/'summary.json');spec=load(SOURCE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':240,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Reconstruct all ordered query pairs and physical pair/mode uses from original source parts. Check committed source provenance, exact union bounds, and independently rationally clip every complete source-clause failure polygon. Verify outward enclosures and every retained candidate selection. For all selected cells verify source-free-region containment, convexity, inset, integer box and sufficient inward rounding. Prove strict separation from every nonempty rational failure polygon with exact all-vertex projections and read every certificate back. Floating calculations may only nominate an axis; exact arithmetic decides safety. Explicit difference bounds remain required. Preserve all stricter padding, raw coverage losses and empty inset/grid discards. No solver or acceptance run.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-six-cog-guided-search-20261025/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in [SOURCE/'plan.json']+list((SOURCE/'queries').glob('*.json'))+list((SOURCE/'mutual').glob('*.json')):assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    assert result['completed_cases']==162 and result['pending_cases']==0 and not load(BASE/'pending-cases.json') and result['seconds']<240
    queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};expected={}
    for a,b in combinations(spec['parts'],2):
        for qa,qb in product(a['queries'],b['queries']):
            aa,bb=spec['queries'][qa],spec['queries'][qb]
            if aa['sheet']==bb['sheet'] and [aa['profile'],bb['profile']]!=[9,9]:expected.setdefault((qa,qb),[]).append([a['part'],b['part']])
    assert len(expected)==162 and sum(map(len,expected.values()))==364
    rows=[];failure_count=pair_count=plane_count=discard_count=zero_cases=0
    for index,(qa,qb) in enumerate(sorted(expected)):
        assert time.perf_counter()-start<240
        case=plan['cases'][index];record=summary[index];dest=BASE/'cases'/f'{index:03d}';original=load(dest/'source.json');data=load(dest/'selected.json');candidates=load(dest/'candidates.json')
        mi=next(m['index'] for m in spec['mutual_cases'] if m['profile_a']==spec['queries'][qa]['profile'] and m['profile_b']==spec['queries'][qb]['profile'])
        assert case=={'index':index,'query_a':qa,'query_b':qb,'sheet':spec['queries'][qa]['sheet'],'mutual_case':mi,'physical_pairs':expected[qa,qb]}==original['case']
        boxes=[]
        for q in [qa,qb]:
            bounds=[d['coordinate_bounds'] for d in queries[q]['domains']];boxes.append([min(b[k] for b in bounds) if k<2 else max(b[k] for b in bounds) for k in range(4)])
        a,b=boxes;r=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];assert boxes==original['anchor_union_bounds_units1000'] and r==original['difference_bounds_units1000']==data['difference_bounds_units1000']
        assert -1500000<=r[0]<=r[2]<=1500000 and -3000000<=r[1]<=r[3]<=3000000
        rectangle=[(F(r[0]),F(r[1])),(F(r[2]),F(r[1])),(F(r[2]),F(r[3])),(F(r[0]),F(r[3]))]
        mutual=load(SOURCE/'mutual'/f'{mi:03d}.json');assert len(original['source_failure_polygons'])==len(mutual['faces']);failures={};enclosures=[]
        for stored,face in zip(original['source_failure_polygons'],mutual['faces']):
            assert stored['source_face']==face['index'];points=rectangle.copy()
            for h in face['outside_halfplanes']:points=intersect(points,h['a'],h['b'],h['bound']-1)
            assert set(points)==set(decode(stored['vertices_units_rational'])) and stored['empty']==(not points);failure_count+=1
            if not points:continue
            enclosure=orient(shape(stored['outward_enclosure_mm']),sign=1);ep=[tuple(F(v)*1000 for v in p) for p in list(enclosure.exterior.coords)[:-1]]
            for i in range(len(ep)):
                n=normal(ep,i);limit=sum(n[k]*ep[i][k] for k in [0,1]);assert all(sum(n[k]*p[k] for k in [0,1])<=limit for p in points)
            failures[face['index']]=points;enclosures.append(enclosure)
        reconstructed=unary_union(enclosures) if enclosures else GeometryCollection();obstacle=shape(original['outward_forbidden_union']);assert reconstructed.equals(obstacle)
        valid=[c for c in candidates if c['complete_failure_union_covered']];eligible=[c for c in valid if c['allowed_cells']<=96]
        chosen=min(eligible,key=lambda c:c['tolerance_mm']) if eligible else min(valid,key=lambda c:(c['allowed_cells'],c['inward_halfplanes'],c['tolerance_mm']))
        assert chosen['candidate']==record['selected_candidate'] and chosen['tolerance_mm']==record['selected_tolerance_mm'] and (dest/'selected.json').read_bytes()==(dest/f"candidate-{chosen['candidate']}.json").read_bytes()
        assert [c['tolerance_mm'] for c in candidates]==[0,.001,.005][:len(candidates)]
        for c in candidates:
            if c['candidate']:assert candidates[c['candidate']-1].get('allowed_cells',10**9)>96
        tolerance=data['tolerance_mm'];expanded=obstacle if not tolerance else obstacle.simplify(tolerance,preserve_topology=True).buffer(2*tolerance,join_style='mitre')
        assert expanded.equals_exact(shape(data['outward_forbidden_union']),0) and (obstacle.is_empty or expanded.covers(obstacle))
        rect=shape(original['outward_difference_rectangle']);ep=[tuple(F(v)*1000 for v in p) for p in list(orient(rect,sign=1).exterior.coords)[:-1]]
        for i in range(len(ep)):
            n=normal(ep,i);limit=sum(n[k]*ep[i][k] for k in [0,1]);assert all(sum(n[k]*p[k] for k in [0,1])<=limit for p in rectangle)
        free=rect.difference(expanded);assert free.equals_exact(shape(data['free_region']),0)
        allfaces=data['domains']+data['discarded_faces'];assert sorted(d['index'] for d in allfaces)==list(range(data['raw_faces']))
        rawunion=unary_union([shape(d['raw_face']) for d in allfaces]) if allfaces else GeometryCollection();missing=free.difference(rawunion)
        assert missing.equals_exact(shape(data['raw_uncovered_region']),0) and missing.area==data['raw_uncovered_area_mm2']
        assert (rawunion.covers(free) if not free.is_empty else True)==data['raw_whole_region_covered']
        for d in data['discarded_faces']:
            inset=shape(d['raw_face']).buffer(-.000001,join_style='mitre');discard_count+=1
            if d['reason']=='empty conservative inset':assert inset.is_empty;continue
            assert d['reason']=='empty inward integer box' and inset.equals_exact(shape(d['inset_face']),0)
            a,b,c,e=map(F,inset.bounds);bb=[max(r[0],math.ceil(a*1000)),max(r[1],math.ceil(b*1000)),min(r[2],math.floor(c*1000)),min(r[3],math.floor(e*1000))];assert bb==d['coordinate_bounds'] and (bb[0]>bb[2] or bb[1]>bb[3])
        certificates=[];cellpoints={}
        for d in data['domains']:
            inset=shape(d['raw_face']).buffer(-.000001,join_style='mitre');assert inset.equals_exact(shape(d['inset_face']),0) and inset.equals(inset.convex_hull) and free.covers(inset)
            a,b,c,e=map(F,inset.bounds);bb=[max(r[0],math.ceil(a*1000)),max(r[1],math.ceil(b*1000)),min(r[2],math.floor(c*1000)),min(r[3],math.floor(e*1000))]
            assert bb==d['coordinate_bounds'] and bb[0]<=bb[2] and bb[1]<=bb[3];plane_count+=check_planes(inset,d['halfplanes'],True)
            points=[tuple(F(v)*1000 for v in p) for p in list(orient(inset,sign=1).exterior.coords)[:-1]];cellpoints[d['index']]=points
            for i in range(len(points)):
                n=normal(points,i);limit=sum(n[k]*points[i][k] for k in [0,1]);assert all(sum(n[k]*p[k] for k in [0,1])<=limit for p in points)
            for face,bad in failures.items():certificates.append({'cell':d['index'],'source_face':face,**separator(points,bad)})
        write(OUT/'certificates'/f'{index:03d}.json',certificates)
        for c in load(OUT/'certificates'/f'{index:03d}.json'):
            gap,sign=exact_gap(cellpoints[c['cell']],failures[c['source_face']],c);assert gap>0 and sign==c['sign'] and [gap.numerator,gap.denominator]==c['gap']
        pair_count+=len(certificates);zero_cases+=not data['domains']
        row={'case':case,'retained_cells':len(data['domains']),'discarded_faces':len(data['discarded_faces']),'nonempty_failure_regions':len(failures),'exact_separation_certificates':len(certificates),'selected_simplification_tolerance_mm':tolerance,'raw_coverage_loss_mm2':missing.area,'whole_raw_free_region_covered':data['raw_whole_region_covered']};rows.append(row)
        assert len(data['domains'])==record['selected_cells'] and len(data['domains'])*len(expected[qa,qb])==record['physical_cell_flags']
        if len(rows)%10==0:print({'audited_cases':len(rows),'exact_separations':pair_count,'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'case-checks.json',rows)
    checks={'passed':True,'seconds':time.perf_counter()-start,'cases':162,'physical_pair_mode_uses':364,'source_failure_polygons_rebuilt':failure_count,'selected_cells':sum(r['retained_cells'] for r in rows),'exact_inward_halfplanes_verified':plane_count,
        'exact_whole_cell_failure_region_separations':pair_count,'certificates_read_back':pair_count,'selected_discarded_faces_preserved':discard_count,'zero_cell_cases':zero_cases,'selected_simplified_cases':sum(r['selected_simplification_tolerance_mm']>0 for r in rows),
        'all_full_guarded_original_clauses_implied_for_integer_differences':True,'explicit_selected_query_difference_bounds_required':True,'constructive_restriction_not_unrestricted_exhaustion':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<240 and checks['selected_cells']==result['selected_cells'];write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
