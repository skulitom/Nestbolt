"""Construct guarded displacement cells for all non-cog/cog query pairs."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,math,shutil,time,traceback
from shapely.geometry import shape,mapping,MultiPoint,GeometryCollection
from shapely.ops import unary_union
from prepare_h5_cog_displacement_cells import clip,encoded,dyadic_corners
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-remaining-displacement-cells-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+240
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']}
    uses={}
    for a,b in combinations(spec['parts'],2):
        for qa,qb in product(a['queries'],b['queries']):
            left,right=spec['queries'][qa],spec['queries'][qb]
            if left['sheet']!=right['sheet'] or (left['profile']==right['profile']==9):continue
            uses.setdefault((qa,qb),[]).append([a['part'],b['part']])
    cases=[{'index':i,'query_a':qa,'query_b':qb,'sheet':spec['queries'][qa]['sheet'],'mutual_case':lookup[(spec['queries'][qa]['profile'],spec['queries'][qb]['profile'])],'physical_pairs':uses[qa,qb]} for i,(qa,qb) in enumerate(sorted(uses))]
    assert len(cases)==162 and sum(len(c['physical_pairs']) for c in cases)==364
    paths=[SOURCE/'plan.json',SOURCE/'audit/checks.json',ROOT/'output/prepare_h5_cog_displacement_cells.py',ROOT/'output/build_h5_strong_pair_domains.py',ROOT/'output/build_h5_full_original_joint_domains.py']
    paths+=[SOURCE/'queries'/f'{q:03d}.json' for q in queries]+[SOURCE/'mutual'/f'{m:03d}.json' for m in sorted({c['mutual_case'] for c in cases})]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'cases':cases,
        'construction_seconds':240,'maximum_total_raw_faces':200000,'per_geometry_merge_attempt_limit':10000,'coordinate_units_per_mm':1000,'normal_scale':10000000,
        'coordinate_maxima':[1500000,3000000],'allowed_face_inset_mm':.000001,'outward_forbidden_vertex_box_grid_mm':'2^-30','conditional_simplification_tolerances_mm':[.001,.005],
        'preferred_maximum_cells_per_case':96,'outward_simplification_padding_multiple':2,'solver_calls':0,
        'method':'Build all 162 non-cog/cog same-sheet ordered query pairs required by all 364 physical pair/mode uses. For each pair use the complete union bounding boxes of the source inward integer domains to bound anchorB-anchorA. Reconstruct every source-clause failure polygon exactly with rational clipping of projection<=bound-1, enclose its vertices in outward dyadic boxes and subtract their union from an outward difference rectangle. Retain all convex allowed faces and every inset/grid discard. First construct the unsimplified complement; only if it has more than 96 retained cells, additionally try outward topology-preserving simplification at .001 and then .005 mm, padded by twice that tolerance. Require whole failure-union coverage; choose the first candidate with at most 96 cells, otherwise the smallest fully covered candidate. Every candidate, loss and cap is retained. This is a stricter constructive subset, never a relaxed guard or exhaustive impossibility proof. No solver may use a selected cell until independent exact whole-cell/source-failure separation is proved. All nine moving originals, 57 fixed originals, source angles, stock and material target stay unchanged.'})
    assert load(SOURCE/'audit/checks.json')['passed'];records=[];total=0
    for case in cases:
        if time.perf_counter()>=deadline or total>=200000:break
        dest=OUT/'cases'/f"{case['index']:03d}";dest.mkdir();boxes=[]
        for qi in [case['query_a'],case['query_b']]:
            ds=queries[qi]['domains'];boxes.append([min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)])
        a,b=boxes;r=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];assert -1500000<=r[0]<=r[2]<=1500000 and -3000000<=r[1]<=r[3]<=3000000
        rectangle=[(F(r[0]),F(r[1])),(F(r[2]),F(r[1])),(F(r[2]),F(r[3])),(F(r[0]),F(r[3]))];rect=MultiPoint(dyadic_corners(rectangle)).convex_hull;assert rect.geom_type=='Polygon'
        mutual=load(SOURCE/'mutual'/f"{case['mutual_case']:03d}.json");bad=[];enclosures=[]
        for face in mutual['faces']:
            p=rectangle.copy()
            for h in face['outside_halfplanes']:p=clip(p,h['a'],h['b'],h['bound']-1)
            row={'source_face':face['index'],'vertices_units_rational':encoded(p),'empty':not p}
            if p:
                enclosure=MultiPoint(dyadic_corners(p)).convex_hull;assert enclosure.geom_type=='Polygon';enclosures.append(enclosure);row['outward_enclosure_mm']=mapping(enclosure)
            bad.append(row)
        obstacle=unary_union(enclosures) if enclosures else GeometryCollection()
        write(dest/'source.json',{'case':case,'anchor_union_bounds_units1000':boxes,'difference_bounds_units1000':r,'source_failure_polygons':bad,'outward_forbidden_union':mapping(obstacle),'outward_difference_rectangle':mapping(rect)})
        candidates=[]
        for ci,tolerance in enumerate([0,.001,.005]):
            if ci and candidates[-1].get('allowed_cells',10**9)<=96:break
            if time.perf_counter()>=deadline:break
            expanded=obstacle if not tolerance else obstacle.simplify(tolerance,preserve_topology=True).buffer(2*tolerance,join_style='mitre')
            covered=expanded.covers(obstacle) if not obstacle.is_empty else True
            if not covered:
                candidate={'candidate':ci,'tolerance_mm':tolerance,'complete_failure_union_covered':False,'uncovered':mapping(obstacle.difference(expanded))};write(dest/f'candidate-{ci}.json',candidate);candidates.append(candidate);continue
            free=rect.difference(expanded);faces,merge=convex_faces(free,deadline);total+=len(faces);domains=[];discarded=[]
            for i,raw in enumerate(faces):
                row={'index':i,'raw_face':mapping(raw)};inset=raw.buffer(-.000001,join_style='mitre')
                if inset.is_empty:row['reason']='empty conservative inset';discarded.append(row);continue
                assert inset.geom_type=='Polygon' and inset.equals(inset.convex_hull) and free.covers(inset)
                row['inset_face']=mapping(inset);a,b,c,d=map(F,inset.bounds);bounds=[max(r[0],math.ceil(a*1000)),max(r[1],math.ceil(b*1000)),min(r[2],math.floor(c*1000)),min(r[3],math.floor(d*1000))];row['coordinate_bounds']=bounds
                if bounds[0]>bounds[2] or bounds[1]>bounds[3]:row['reason']='empty inward integer box';discarded.append(row);continue
                row['halfplanes']=inequalities(inset,True);domains.append(row)
            covered_raw=unary_union(faces) if faces else GeometryCollection();missing=free.difference(covered_raw)
            short={'candidate':ci,'tolerance_mm':tolerance,'outward_padding_mm':2*tolerance,'complete_failure_union_covered':True,'raw_faces':len(faces),'allowed_cells':len(domains),'discarded_faces':len(discarded),'inward_halfplanes':sum(len(d['halfplanes']) for d in domains),
                'raw_uncovered_area_mm2':missing.area,'raw_whole_region_covered':covered_raw.covers(free) if not free.is_empty else True,**merge}
            write(dest/f'candidate-{ci}.json',{**short,'difference_bounds_units1000':r,'outward_forbidden_union':mapping(expanded),'free_region':mapping(free),'raw_uncovered_region':mapping(missing),'domains':domains,'discarded_faces':discarded});candidates.append(short)
        valid=[c for c in candidates if c['complete_failure_union_covered']];assert valid
        eligible=[c for c in valid if c['allowed_cells']<=96];chosen=min(eligible,key=lambda c:c['tolerance_mm']) if eligible else min(valid,key=lambda c:(c['allowed_cells'],c['inward_halfplanes'],c['tolerance_mm']))
        shutil.copyfile(dest/f"candidate-{chosen['candidate']}.json",dest/'selected.json');write(dest/'candidates.json',candidates)
        row={**case,'candidates':len(candidates),'selected_candidate':chosen['candidate'],'selected_tolerance_mm':chosen['tolerance_mm'],'selected_cells':chosen['allowed_cells'],'selected_halfplanes':chosen['inward_halfplanes'],'physical_cell_flags':chosen['allowed_cells']*len(case['physical_pairs']),'selected_raw_uncovered_area_mm2':chosen['raw_uncovered_area_mm2'],'selected_raw_whole_region_covered':chosen['raw_whole_region_covered']};records.append(row)
        if len(records)%10==0:print({'completed_cases':len(records),'cells':sum(c['selected_cells'] for c in records),'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'summary.json',records);write(OUT/'pending-cases.json',cases[len(records):])
    result={'seconds':time.perf_counter()-start,'planned_cases':162,'completed_cases':len(records),'pending_cases':162-len(records),'physical_pair_mode_uses':sum(len(c['physical_pairs']) for c in records),
        'selected_cells':sum(c['selected_cells'] for c in records),'selected_halfplanes':sum(c['selected_halfplanes'] for c in records),'physical_cell_flags':sum(c['physical_cell_flags'] for c in records),'raw_faces_all_candidates':total,
        'simplified_selected_cases':sum(c['selected_tolerance_mm']>0 for c in records),'selected_cases_with_raw_coverage_loss':sum(not c['selected_raw_whole_region_covered'] for c in records),'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
