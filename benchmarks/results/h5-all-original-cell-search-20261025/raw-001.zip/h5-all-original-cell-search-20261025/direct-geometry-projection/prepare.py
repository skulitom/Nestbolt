"""Remove only the older pair table; retain every direct geometric constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import copy,json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-all-original-cell-search-20261025';RUN=BASE/'shared-search';OUT=BASE/'direct-geometry-projection'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    paths=[RUN/'solve/model.pb',RUN/'solve/mapping.json',RUN/'solve/model-audit.json',BASE/'search-audit/checks.json']
    audit=load(paths[2]);assert audit['passed'] and load(paths[3])['passed'] and audit['all36_physical_pairs_have_full_guarded_coordinates'] and digest(paths[0])==audit['model_sha256']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,
        'method':'Project the fully audited direct original-coordinate model by deleting only the older domain-pair compatibility-table constraints and their private Boolean group variables. Keep all original domain selection, counts, source areas, copy order, coordinate bounds, inward halfplanes, 36 direct guarded pair representations, capacities and certified exclusions. Renumber remaining references exactly. The old table is no longer required to establish original pair safety because the retained direct cells already imply every full guarded source separation clause. This does not weaken the original clearance or material gate. Independently reconstruct the removed block from source and inverse-map every retained field before solver use. This preparation makes no solver call.'})
    old=cp_model_pb2.CpModelProto();old.ParseFromString(paths[0].read_bytes());mapping=load(paths[1])
    first=sum(len(p['modes'])+3 for p in mapping['parts'])+2+6
    domainvars={v for p in mapping['parts'] for m in p['modes'] for v in m['domains']};removed_vars=sorted({g['flag'] for g in mapping['groups']}-domainvars)
    last=first+len(mapping['groups'])+len(removed_vars);assert first==81 and last==7967 and len(removed_vars)==3395
    assert all(old.variables[v].domain==[0,1] and old.variables[v].name.startswith('pair') for v in removed_vars)
    removed=set(removed_vars);keep=[i for i in range(len(old.variables)) if i not in removed];forward={v:i for i,v in enumerate(keep)}
    new=cp_model_pb2.CpModelProto();new.CopyFrom(old);del new.variables[:];new.variables.extend(old.variables[i] for i in keep);del new.constraints[:]
    def literal(v):return forward[v] if v>=0 else -forward[-v-1]-1
    for i,c in enumerate(old.constraints):
        if first<=i<last:continue
        d=new.constraints.add();d.CopyFrom(c);d.enforcement_literal[:]=[literal(v) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
        if kind=='linear':d.linear.vars[:]=[forward[v] for v in c.linear.vars]
        else:assert kind in ['bool_or','at_most_one','exactly_one'];getattr(d,kind).literals[:]=[literal(v) for v in getattr(c,kind).literals]
    new.solution_hint.vars[:]=[forward[v] for v in old.solution_hint.vars]
    assert not old.assumptions and not old.search_strategy and not old.HasField('objective') and not old.HasField('floating_point_objective')
    (OUT/'model.pb').write_bytes(new.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(new),encoding='utf-8',newline='\n')
    newmap=copy.deepcopy(mapping);del newmap['groups']
    def remap(v,key=None):
        if isinstance(v,dict):return {k:remap(w,k) for k,w in v.items()}
        if isinstance(v,list):return [forward[w] for w in v] if key in ['domains','selectors'] else [remap(w) for w in v]
        return forward[v] if key in ['sheet','choice','active','occupied','flag','x','y'] else v
    newmap=remap(newmap);write(OUT/'mapping.json',newmap)
    write(OUT/'projection.json',{'removed_constraint_interval':[first,last],'removed_variable_indices':removed_vars,'retained_old_variable_indices':keep,'retained_old_constraint_indices':[i for i in range(len(old.constraints)) if not first<=i<last]})
    result={'seconds':time.perf_counter()-start,'source_variables':len(old.variables),'projected_variables':len(new.variables),'source_constraints':len(old.constraints),'projected_constraints':len(new.constraints),
        'removed_group_variables':len(removed_vars),'removed_table_constraints':last-first,'removed_table_group_literals':audit['conflict_group_literals'],'direct_original_anchor_variables':18,'direct_physical_pairs':36,'required_originals':66,'hints':len(new.solution_hint.vars),'model_sha256':digest(OUT/'model.pb'),'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
