"""Prove the table removal leaves every direct geometry constraint unchanged."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-all-original-cell-search-20261025';RUN=BASE/'shared-search';PREP=BASE/'direct-geometry-projection';OUT=PREP/'audit';GROUPS=ROOT/'output/h5-convex-domain-conflicts-20261025/groups'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in PREP.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Reconstruct every removed group definition and compatibility constraint directly from the original source group bitsets and original variable mapping. Prove deleted auxiliary variables occur in no retained constraint or hint. Check every retained variable and inverse-map every complete retained constraint to exact protobuf equality with the fully audited parent. Check all remaining model metadata and hint values. Reconstruct the full parent by reinserting the saved original block/auxiliaries; require exact protobuf equality. Verify the new mapping and import into the actual solver model, then export and compare every protobuf field. No solver invocation.'})
    for n,h in load(PREP/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    source=cp_model_pb2.CpModelProto();source.ParseFromString((RUN/'solve/model.pb').read_bytes());projected=cp_model_pb2.CpModelProto();projected.ParseFromString((PREP/'model.pb').read_bytes());meta=load(PREP/'projection.json');mapping=load(RUN/'solve/mapping.json');newmap=load(PREP/'mapping.json')
    assert text_format.Parse((PREP/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())==projected
    parent_audit=load(RUN/'solve/model-audit.json');assert digest(RUN/'solve/model.pb')==parent_audit['model_sha256'] and parent_audit['all36_physical_pairs_have_full_guarded_coordinates']
    for i,h in load(RUN/'solve/plan.json')['group_hashes'].items():assert digest(GROUPS/f'{int(i):03d}.json')==h
    cursor=sum(len(p['modes'])+3 for p in mapping['parts'])+8;first=cursor;used=[];literal_count=0
    def linear(terms):
        d=Counter()
        for v,c in terms:d[v]+=c
        p=cp_model_pb2.ConstraintProto();ids=sorted(v for v,c in d.items() if c);p.linear.vars.extend(ids);p.linear.coeffs.extend(d[v] for v in ids);p.linear.domain.extend([0,0]);return p
    for g in mapping['groups']:
        a,b=[mapping['parts'][i] for i in g['parts']];row=load(GROUPS/f"{g['case']:03d}.json");case=row['case'];group=next(x for x in row['groups'] if x['group']==g['group'])
        qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b']);da=[qa['domains'][i] for i in group['rows_a']];bits=bytes.fromhex(group['forbidden_b_hex']);forbidden=[qb['domains'][i] for i in range(case['rows_b']) if bits[i//8]&(1<<(7-i%8))];flag=g['flag']
        assert len(forbidden)==group['conflicts_per_a_row']
        if len(da)>1:assert source.constraints[cursor]==linear([(v,1) for v in da]+[(flag,-1)]);cursor+=1;used.append(flag)
        else:assert flag==da[0]
        expected=cp_model_pb2.ConstraintProto()
        if len(forbidden)==len(qb['domains']):expected.bool_or.literals.extend([-flag-1,-qb['active']-1]);literal_count+=2
        else:expected.at_most_one.literals.extend([flag]+forbidden);literal_count+=1+len(forbidden)
        assert source.constraints[cursor]==expected;cursor+=1
    assert [first,cursor]==meta['removed_constraint_interval']==[81,7967] and sorted(used)==meta['removed_variable_indices'] and len(set(used))==3395 and literal_count==1572932
    inverse=meta['retained_old_variable_indices'];removed=set(used);assert inverse==[i for i in range(len(source.variables)) if i not in removed]
    assert len(projected.variables)==len(inverse) and all(v==source.variables[i] for v,i in zip(projected.variables,inverse))
    kept=[i for i in range(len(source.constraints)) if not first<=i<cursor];assert kept==meta['retained_old_constraint_indices'] and len(projected.constraints)==len(kept)
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(projected);del restored.variables[:];restored.variables.extend(source.variables);del restored.constraints[:]
    def undo(v):return inverse[v] if v>=0 else -inverse[-v-1]-1
    reconstructed={}
    for c,oldindex in zip(projected.constraints,kept):
        d=cp_model_pb2.ConstraintProto();d.CopyFrom(c);d.enforcement_literal[:]=[undo(v) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
        if kind=='linear':d.linear.vars[:]=[inverse[v] for v in c.linear.vars]
        else:assert kind in ['bool_or','at_most_one','exactly_one'];getattr(d,kind).literals[:]=[undo(v) for v in getattr(c,kind).literals]
        assert d==source.constraints[oldindex];reconstructed[oldindex]=d
    for i in range(len(source.constraints)):restored.constraints.add().CopyFrom(source.constraints[i] if first<=i<cursor else reconstructed[i])
    restored.solution_hint.vars[:]=[inverse[v] for v in projected.solution_hint.vars];assert restored==source
    def undo_map(v,key=None):
        if isinstance(v,dict):return {k:undo_map(w,k) for k,w in v.items()}
        if isinstance(v,list):return [inverse[w] for w in v] if key in ['domains','selectors'] else [undo_map(w) for w in v]
        return inverse[v] if key in ['sheet','choice','active','occupied','flag','x','y'] else v
    recovered=undo_map(newmap);assert recovered=={k:v for k,v in mapping.items() if k!='groups'}
    model=cp_model.CpModel();assert model.proto.parse_text_format((PREP/'model.pbtxt').read_text());assert model.validate()=='';assert model.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    roundtrip=cp_model_pb2.CpModelProto();roundtrip.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert roundtrip==projected
    checks={'passed':True,'seconds':time.perf_counter()-start,'deleted_constraints_independently_reconstructed':cursor-first,'deleted_private_auxiliary_variables':len(removed),'removed_table_literals':literal_count,
        'all_retained_constraints_inverse_verified':len(kept),'all_retained_variables_inverse_verified':len(inverse),'original_parent_fully_reconstructed':True,'mapping_and79_hints_preserved':True,'actual_solver_import_export_verified':True,
        'all_original_domain_area_count_and_guarded_pair_constraints_unchanged':True,'required_originals':66,'movable_originals':9,'fixed_originals':57,'direct_pair_constraints':36,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
