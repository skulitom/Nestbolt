from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_first57_disjoint_model_20261104.py').read_text(encoding='utf-8')
s=s.replace("OUT=BASE/'model'","OUT=BASE/'model-factorized'")
s=s.replace("OUT.mkdir();","assert load(BASE/'interaction-factorization/audit/checks.json')['passed']\nOUT.mkdir();",1)
a=s.index('packing=[]');b=s.index('symmetry=[]',a)
s=s[:a]+'''packing=[]
first_members=set(groups[0]['components'])
factorized=[(g,g['group']==0) for g in groups]+[({'group':16,'components':[c['component'] for c in raw_components if c['component'] not in first_members]},True)]
for g,includes_fixed in factorized:
    fx,fy=(fixed_x,fixed_y) if includes_fixed else ([],[])
    ct=model.add_no_overlap_2d(fx+[intervals_x[i] for i in g['components']],fy+[intervals_y[i] for i in g['components']])
    packing.append({**g,'constraint':ct.index,'fixed_obstacles':len(fx)})
'''+s[b:]
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_first57_factorized_model_builder_20261104.py',ROOT/'output/build_h5_first57_disjoint_model_20261104.py',BASE/'interaction-factorization/audit/plan.json',BASE/'interaction-factorization/audit/checks.json',",1)
s=s.replace("'global_no_overlap_2d_constraints':16","'global_no_overlap_2d_constraints':17")
s=s.replace("Every one of16 different-owner pair-cover groups includes every fixed obstacle interval and one rigid component per owner.","All16 moving-pair groups retain their original interactions. Fixed obstacle intervals appear only in group0 and one additional group containing its8 complementary bracket pieces. Every moving/fixed interaction is preserved once, with21258 rectangle references instead of168208. These groups are recomputed inside this complete build process.")
s=s.replace("'full_physical_stock':True,'prior_positive_regions_consumed':False","'interaction_factorization':True,'fixed_obstacle_groups':2,'rectangle_references':21258,'full_physical_stock':True,'prior_positive_regions_consumed':False")
with (ROOT/'output/build_h5_first57_factorized_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
r=(ROOT/'output/run_h5_first57_disjoint_model_build_20261104.py').read_text(encoding='utf-8').replace('h5-first57-disjoint-model-process-20261104','h5-first57-factorized-model-process-20261104').replace('build_h5_first57_disjoint_model_20261104.py','build_h5_first57_factorized_model_20261104.py')
with (ROOT/'output/run_h5_first57_factorized_model_build_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(r)
