"""Exact interaction-cover factorization, with no new geometry or search."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
OUT=BASE/'interaction-factorization'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter()
assert load(BASE/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
groups=load(BASE/'pair-cover-groups.json');components=load(BASE/'components.json');boxes=load(OBS/'disjoint-mask-boxes.json')
all_components=set(range(len(components)));first=set(groups[0]['components']);remaining=sorted(all_components-first)
assert len(first)==16 and len(remaining)==8
assert len({components[i]['owner'] for i in remaining})==len(remaining)
factorized=[{**g,'includes_fixed_obstacles':g['group']==0} for g in groups]
factorized.append({'group':16,'components':remaining,'includes_fixed_obstacles':True})
pair_counts=[]
for a,b in combinations(range(24),2):
    if components[a]['owner']==components[b]['owner']:continue
    before=sum(a in g['components'] and b in g['components'] for g in groups)
    after=sum(a in g['components'] and b in g['components'] for g in factorized)
    assert after>=before>=4
    pair_counts.append({'components':[a,b],'before':before,'after':after})
fixed_counts=[]
for i in range(24):
    old=sum(i in g['components'] for g in groups)
    new=sum(g['includes_fixed_obstacles'] and i in g['components'] for g in factorized)
    assert old>=8 and new==1
    fixed_counts.append({'component':i,'old_fixed_groups':old,'new_fixed_groups':new})
old_refs=sum(len(boxes)+len(g['components']) for g in groups)
new_refs=sum((len(boxes) if g['includes_fixed_obstacles'] else 0)+len(g['components']) for g in factorized)
write(OUT/'groups.json',factorized);write(OUT/'moving-pair-cover.json',pair_counts);write(OUT/'fixed-pair-cover.json',fixed_counts)
inputs=[Path(__file__)]+[BASE/n for n in ['audit/plan.json','audit/checks.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[OBS/n for n in ['audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'The16 existing moving-pair groups remain intact, but fixed obstacles are included only in group0. Its16 components cover one piece of every owner. One new group contains all fixed obstacles and the8 complementary bracket pieces. Thus every moving-component/fixed-obstacle pair occurs exactly once, while all268 different-owner moving pairs retain their previous coverage. Fixed/fixed pairs are already universally disjoint by the exact source-cover partition audit. This is an exact interaction factorization of the source-safe model, reducing repeated fixed-obstacle references by8x. It changes propagation structure substantially; the previous call remains closed and cannot be rerun.',
    'independent_factorization_audit_required':True,'new_solver_calls':0})
checks={'prepared':True,'seconds':time.perf_counter()-started,'old_groups':16,'new_groups':17,'fixed_obstacle_groups_before':16,'fixed_obstacle_groups_after':2,
    'moving_pairs_retained':len(pair_counts),'moving_fixed_pair_classes_retained':len(fixed_counts),'fixed_boxes_per_group':len(boxes),
    'old_rectangle_references':old_refs,'new_rectangle_references':new_refs,'reference_reduction_percent':100*(1-new_refs/old_refs),
    'independent_factorization_audit_pending':True,'solver_calls':0}
write(OUT/'checks.json',checks);print(checks)
