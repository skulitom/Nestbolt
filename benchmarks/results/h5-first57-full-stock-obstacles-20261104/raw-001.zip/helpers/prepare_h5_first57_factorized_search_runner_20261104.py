from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/check_h5_first57_disjoint_candidate_20261104.py').read_text(encoding='utf-8')
s=s.replace("SEARCH=BASE/'search'","SEARCH=BASE/'search-factorized'").replace("BASE/'model/","BASE/'model-factorized/")
with (ROOT/'output/check_h5_first57_factorized_candidate_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_first57_disjoint_model_20261104.py').read_text(encoding='utf-8')
s=s.replace("MODEL = BASE / 'model'","MODEL = BASE / 'model-factorized'").replace("OUT = BASE / 'search'","OUT = BASE / 'search-factorized'")
s=s.replace('model-audit','factorized-model-audit').replace('check_h5_first57_disjoint_candidate_20261104','check_h5_first57_factorized_candidate_20261104')
with (ROOT/'output/run_h5_first57_factorized_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
