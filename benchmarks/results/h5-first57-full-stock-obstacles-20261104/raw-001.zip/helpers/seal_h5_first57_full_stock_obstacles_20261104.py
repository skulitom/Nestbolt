"""Seal the full-stock source geometry and two independently audited closed calls."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-first57-full-stock-obstacles-20261104';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104','h5-independent-cog-rows-and-expanded-domains-20261104','h5-expanded-joint-and-staged-row-constructions-20261104','h5-row-reductions-and-three-cog-allocation-20261104','h5-direct-short9-and-grouped-first57-20261104','h5-first57-necessary-capacities-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
assert load(OBS/'audit/checks.json')['passed']
for d in ['audit','model-audit','response-audit','interaction-factorization/audit','factorized-model-audit','factorized-response-audit']:assert load(BASE/d/'checks.json')['passed']
direct=load(BASE/'response-audit/checks.json');fact=load(BASE/'factorized-response-audit/checks.json')
for r in [direct,fact]:assert r['closed_solver_calls']==1 and r['solver_status']=='UNKNOWN' and r['assignments']==0 and r['algorithm_overrun_seconds']==r['shared_overrun_seconds']==0
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [BASE,OBS]+[ROOT/'output'/n for n in ['h5-first57-disjoint-obstacles-process-20261104','h5-first57-disjoint-movers-process-20261104','h5-first57-disjoint-model-process-20261104','h5-first57-factorized-model-process-20261104','h5-disjoint-assignment-reader-controls-20261104']]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_first57_disjoint*20261104.py','*h5_first57_factorized*20261104.py','*h5_first57_obstacle_factorization*20261104.py','*h5*disjoint*assignment_reader*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,'h5-first57-full-stock-obstacles-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(OBS/'audit/checks.json','obstacle-source-audit.json'),(BASE/'audit/checks.json','moving-source-audit.json'),
    (BASE/'model-audit/checks.json','direct-model-audit.json'),(BASE/'response-audit/checks.json','direct-response-audit.json'),
    (BASE/'model/final-preparation-charges.json','direct-preparation-charges.json'),
    (BASE/'interaction-factorization/audit/checks.json','interaction-factorization-audit.json'),
    (BASE/'factorized-model-audit/checks.json','factorized-model-audit.json'),(BASE/'factorized-response-audit/checks.json','factorized-response-audit.json'),
    (BASE/'model-factorized/final-preparation-charges.json','factorized-preparation-charges.json'),
    (ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/checks.json','assignment-reader-controls.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_models':[{'model':r['model_variables'],'status':r['solver_status'],'sha256':load(BASE/d/'checks.json')['model_sha256']} for r,d in [(direct,'model-audit'),(fact,'factorized-model-audit')]],
    'closed_calls_must_not_be_repeated':True,'all_source_geometry_and_model_audits_pass':True,'full66_assignment_obtained':False,
    'next_method':'Inspect necessary full-stock bracket domains below the older top-strip bound and reconcile earlier corner-channel experiments before a new bounded positive preflight. Test whether two fresh side-pocket bracket placements can be source-valid with fixed29 and all15 reference cogs, retaining complete identities and the actual gap/stock limits. If independently certified, those placements could reduce the remaining first57 orthogonal movers from16 to14; no such control or reduction is yet established. Preserve all failures and charge every used preparation before any fresh model. Alternatively seek a substantially smaller source-covered unary representation; do not retune or rerun either closed obstacle model.',
    'current_necessary_first57_site_choices':259,'older_fixed13_cog_frontier':{'site_choices':2,'count_distributions':3},'remaining_allocation_candidates':440,
    'new_side_pocket_preflight_prepared':False,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'full_physical_stock':True,'source_covering_obstacle_boxes':10497,'direct_model_variables':324,'direct_model_constraints':22065,
    'factorized_model_variables':324,'factorized_model_constraints':22066,'rectangle_references_before':168208,'rectangle_references_after':21258,
    'closed_solver_calls':2,'solver_statuses':['UNKNOWN','UNKNOWN'],'assignments':0,'factorized_solve_slice_overrun_seconds':fact['solve_slice_overrun_seconds'],
    'overall_algorithm_shared_overruns_seconds':0,'new_site_choices_excluded':0,'remaining_first57_site_choices':259,'remaining_allocation_candidates':440,
    'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-first57-full-stock-obstacles-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 full-stock obstacle packing:** [independent source/model/response audits]({link}) verify fresh full-physical-stock mover bounds and 10,497 disjoint source-covering obstacle rectangles. The direct 324-variable / 22,065-constraint model closes UNKNOWN after presolve. An exact interaction proof preserves all 268 moving-pair and 251,928 moving/fixed checks while reducing rectangle references by 87.4%. Its separately audited 324-variable / 22,066-constraint model reaches search but closes UNKNOWN after 2,005 branches, without an assignment. Preparation-inclusive algorithm/shared totals are 49.817690/49.892755 s and 56.082547/56.165577 s; both stay within 60/90 s. The second solve-slice overrun of 0.067821 s is retained. Both calls remain closed. The necessary frontier stays at 259 selections; all 440 whole-job allocations, full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [necessary domains and component capacities](../benchmarks/results/h5-first57-necessary-capacities-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [full-stock obstacle packing](../benchmarks/results/{NAME}.md).',1)
a='The direct 4/2/3 short sheet passes source checks in 0.297 s. Its grouped first57\ncall remains closed UNKNOWN. New exact continuous-source capacity proofs exclude\n196 of the 455 fixed-core twelve-cog selections, leaving 259. Stronger constraints\nor a meaningfully smaller construction remain to prepare before further search.'
b='The direct 4/2/3 short sheet passes source checks in 0.297 s. Two new full-stock\nobstacle models close UNKNOWN without a placement. Exact interaction factorization\nremoves 87.4% of rectangle references and reaches search, but full66 remains open.\nThe necessary capacity proofs still exclude 196 of the 455 fixed-core twelve-cog\nselections, leaving 259. Fresh side-pocket source controls remain to investigate.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
