from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/check_h5_first57_grouped_candidate_20261104.py'
s=source.read_text(encoding='utf-8').replace('h5-first57-grouped-integer-20261104','h5-first57-disjoint-movers-20261104')
with (ROOT/'output/check_h5_first57_disjoint_candidate_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
source=ROOT/'output/run_h5_first57_grouped_model_20261104.py'
s=source.read_text(encoding='utf-8').replace('h5-first57-grouped-integer-20261104','h5-first57-disjoint-movers-20261104')
s=s.replace('h5_grouped_model_assignment_reader_20261104','h5_disjoint_model_assignment_reader_20261104').replace('check_h5_first57_grouped_candidate_20261104','check_h5_first57_disjoint_candidate_20261104')
s=s.replace('geometry-audit','audit').replace('on a micrometre grid','on a 0.01 mm grid')
s=s.replace("    assert audit_checks['passed']","    assert audit_checks['passed']\n    assert load(ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/checks.json')['passed']",1)
s=s.replace("inputs = [Path(__file__),","inputs = [Path(__file__), ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/plan.json', ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/checks.json',",1)
with (ROOT/'output/run_h5_first57_disjoint_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
