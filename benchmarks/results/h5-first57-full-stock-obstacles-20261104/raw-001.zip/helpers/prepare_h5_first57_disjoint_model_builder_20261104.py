"""Compose the new fixed-obstacle model while retaining the audited rigid links."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/build_h5_first57_grouped_model_20261104.py'
target=ROOT/'output/build_h5_first57_disjoint_model_20261104.py'
old=source.read_text(encoding='utf-8')
header='''"""Full-stock first57 packing against source-covering disjoint obstacle boxes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-disjoint-movers-20261104';OUT=BASE/'model'
OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'
RID=ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
assert load(BASE/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');rectangles=load(BASE/'mode-rectangles.json')
raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json');obstacles=load(OBS/'disjoint-mask-boxes.json')
'''
owners=old[old.index('model=cp_model.CpModel()'):old.index('exact_three=linear')]
owners=owners.replace(",'regions':[],'mask_groups':[],'geometry_marginals':[]","")
presence='''exact_three=linear({i:1 for i in empty},3,3)
presence=[]
for mask in sorted({r[0] for r in obstacles}):
    sites=[i for i in range(15) if mask&(1<<i)]
    if mask&32768:
        presence.append({'mask':mask,'fixed':True,'sites':sites,'selector':None,'constraints':[]})
    else:
        p=model.new_bool_var(f'obstacle_mask_{mask}').index
        links=[linear({p:1,empty[i]:1},1,cp_model.INT_MAX) for i in sites]
        links.append(linear({p:1,**{empty[i]:1 for i in sites}},cp_model.INT_MIN,len(sites)))
        presence.append({'mask':mask,'fixed':False,'sites':sites,'selector':p,'constraints':links})
'''
components=old[old.index('components=[];intervals_x=[]'):old.index('packing=[]')]
fixed='''fixed_x=[];fixed_y=[];fixed_records=[];by_mask={r['mask']:r for r in presence}
for index,row in enumerate(obstacles):
    mask,left,bottom,right,top=row[:5];p=by_mask[mask]['selector'];cts=[]
    for axis,(a,b) in enumerate([(left,right),(bottom,top)]):
        name=f'obstacle_{index}_axis_{axis}'
        interval=model.new_interval_var(a,b-a,b,name) if p is None else model.new_optional_interval_var(a,b-a,b,var(p),name)
        cts.append(interval.index);(fixed_x if axis==0 else fixed_y).append(interval)
    fixed_records.append({'obstacle':index,'mask':mask,'bounds_grid':[left,bottom,right,top],'presence_selector':p,'interval_constraints':cts})
packing=[]
for g in groups:
    ct=model.add_no_overlap_2d(fixed_x+[intervals_x[i] for i in g['components']],fixed_y+[intervals_y[i] for i in g['components']])
    packing.append({**g,'constraint':ct.index,'fixed_obstacles':len(fixed_records)})
'''
sym=old[old.index('symmetry=[]'):old.index("mapping={'owners'")]
tail='''mapping={'owners':owners,'empty_site_selectors':empty,'exactly_three_empty_constraint':exact_three,'components':components,
    'obstacle_masks':presence,'fixed_obstacles':fixed_records,'packing_groups':packing,'symmetry_constraints':symmetry,
    'position_units_per_mm':100,'world_origin_mm':[0,0],'rectangle_gap_grid':gap,'full_physical_stock':True}
write(OUT/'mapping.json',mapping);elapsed=time.perf_counter()-started
charges={'fixed_source_mode_geometry_preparation_seconds':load(FIRST/'checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(SLOTS/'checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(RID/'checks.json')['seconds'],
    'direct_short9_and_inventory_complete_process_seconds':load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds'],
    'disjoint_source_obstacles_complete_process_seconds':load(ROOT/'output/h5-first57-disjoint-obstacles-process-20261104/process.json')['complete_process_seconds'],
    'full_stock_movers_complete_process_seconds':load(ROOT/'output/h5-first57-disjoint-movers-process-20261104/process.json')['complete_process_seconds'],
    'model_internal_seconds_pending_complete_process_charge':elapsed}
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),FIRST/'checks.json',SLOTS/'checks.json',RID/'checks.json',ROOT/'output/prepare_h5_first57_disjoint_model_builder_20261104.py',ROOT/'output/build_h5_first57_grouped_model_20261104.py']+[ROOT/'output'/n/'process.json' for n in ['h5-first57-direct-short9-process-20261104','h5-first57-disjoint-obstacles-process-20261104','h5-first57-disjoint-movers-process-20261104']]+[BASE/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json','instances.json','inventory.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[OBS/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]+[PRE/'plan.json',PRE/'audit/plan.json',PRE/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New full-stock positive obstacle construction. All16 orthogonal original parts have fresh full-stock bounds, rigid source-covering component rectangles and legal modes. Exactly three of the15 cog sites are empty. For each of43 obstacle masks, a shared presence literal is equivalent to at least one occupied named cog, or unconditional when the fixed-core bit is set. Each of10497 mutually interior-disjoint source-covering boxes has constant optional X/Y intervals. Every one of16 different-owner pair-cover groups includes every fixed obstacle interval and one rigid component per owner. All present obstacle intervals are geometrically disjoint by the independent source-cover audit. Moving-to-fixed and moving-to-moving separation follow from common right/top0.23mm expansions. This replaces31528 region selectors and129256 guarded planes with direct spatial packing; it also opens the full physical stock below the prior top-strip construction. No prior capacity pruning, hints or objective are consumed. Audit every model field and the complete preparation ledger before one bounded call.',
    'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'provisional_preparation_seconds':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'owners':16,'source_mode_selectors':96,'empty_site_selectors':15,'required_empty_sites':3,
    'shared_obstacle_masks':len(presence),'optional_obstacle_masks':sum(r['selector'] is not None for r in presence),
    'source_covering_disjoint_obstacles':len(obstacles),'obstacle_interval_constraints':2*len(obstacles),
    'rigid_components':24,'coordinate_mode_links':coordinate_links,'moving_interval_constraints':48,'interval_size_constraints':48,
    'global_no_overlap_2d_constraints':16,'same_family_symmetry_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),
    'full_physical_stock':True,'prior_positive_regions_consumed':False,'prior_capacity_results_consumed':False,
    'final_complete_process_ledger_pending':True,'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
assert elapsed<15
write(OUT/'checks.json',checks);print(checks)
'''
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(header+owners+presence+components+fixed+sym+tail)
runner=(ROOT/'output/run_h5_first57_grouped_model_build_20261104.py').read_text(encoding='utf-8')
runner=runner.replace('h5-first57-grouped-model-process-20261104','h5-first57-disjoint-model-process-20261104').replace('build_h5_first57_grouped_model_20261104.py','build_h5_first57_disjoint_model_20261104.py')
with (ROOT/'output/run_h5_first57_disjoint_model_build_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
