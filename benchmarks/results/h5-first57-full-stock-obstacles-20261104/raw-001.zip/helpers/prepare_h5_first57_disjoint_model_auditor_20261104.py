from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/audit_h5_first57_grouped_model_20261104.py').read_text(encoding='utf-8')
header='''"""Independent exhaustive readback of the disjoint-obstacle full-stock model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-disjoint-movers-20261104';MODEL=BASE/'model';OUT=BASE/'model-audit'
OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63);MAX=2**63-1
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,BASE/'audit',OBS,OBS/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes())
assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'}
mapping=load(MODEL/'mapping.json');modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json')
rectangles=load(BASE/'mode-rectangles.json');raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
obstacles=load(OBS/'disjoint-mask-boxes.json')
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,0] and mapping['rectangle_gap_grid']==23 and mapping['full_physical_stock']
assert len(mapping['owners'])==len(instances)==16
'''
helpers=old[old.index('used_v=set()'):old.index('mode_count=region_count')]
owners='mode_count=0\n'+old[old.index('for i,(o,instance)'):old.index("for o in mapping['owners']:")]
presence='''expected_masks=sorted({r[0] for r in obstacles});assert [r['mask'] for r in mapping['obstacle_masks']]==expected_masks
presence_constraints=0
for record in mapping['obstacle_masks']:
    mask=record['mask'];sites=[i for i in range(15) if mask&(1<<i)];assert record['sites']==sites and record['fixed']==bool(mask&32768)
    if record['fixed']:assert record['selector'] is None and record['constraints']==[]
    else:
        selector=record['selector'];variable(selector,f'obstacle_mask_{mask}',[0,1])
        assert len(record['constraints'])==len(sites)+1
        for ct,site in zip(record['constraints'][:-1],sites):linear(ct,{selector:1,empty[site]:1},1,MAX)
        linear(record['constraints'][-1],{selector:1,**{empty[s]:1 for s in sites}},MIN,len(sites));presence_constraints+=len(sites)+1
'''
components=old[old.index("assert len(mapping['components'])"):old.index("assert len(mapping['packing_groups'])")]
fixed='''by_mask={r['mask']:r for r in mapping['obstacle_masks']}
assert len(mapping['fixed_obstacles'])==len(obstacles)==10497
for i,(record,source) in enumerate(zip(mapping['fixed_obstacles'],obstacles)):
    mask,left,bottom,right,top=source[:5];presence=by_mask[mask]['selector']
    assert record['obstacle']==i and record['mask']==mask and record['bounds_grid']==[left,bottom,right,top] and record['presence_selector']==presence
    assert len(record['interval_constraints'])==2
    for axis,(a,b) in enumerate([(left,right),(bottom,top)]):
        index=record['interval_constraints'][axis];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
        assert {f.name for f,v in ct.ListFields()}=={'name','interval'}|({'enforcement_literal'} if presence is not None else set())
        assert ct.name==f'obstacle_{i}_axis_{axis}' and list(ct.enforcement_literal)==([] if presence is None else [presence])
        for expression,expected in [(ct.interval.start,a),(ct.interval.size,b-a),(ct.interval.end,b)]:
            assert not expression.vars and not expression.coeffs and expression.offset==expected
assert len(mapping['packing_groups'])==len(groups)==16
for actual,source in zip(mapping['packing_groups'],groups):
    assert {k:v for k,v in actual.items() if k not in ['constraint','fixed_obstacles']}==source and actual['fixed_obstacles']==10497
    index=actual['constraint'];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
    assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'}
    assert list(ct.no_overlap_2d.x_intervals)==[o['interval_constraints'][0] for o in mapping['fixed_obstacles']]+[mapping['components'][i]['interval_constraints'][0] for i in source['components']]
    assert list(ct.no_overlap_2d.y_intervals)==[o['interval_constraints'][1] for o in mapping['fixed_obstacles']]+[mapping['components'][i]['interval_constraints'][1] for i in source['components']]
'''
symmetry=old[old.index('expected_symmetry=[]'):old.index('assert len(p.variables)==35735')]
ledger=old[old.index("ledger=load(MODEL/'final-preparation-charges.json')"):old.index('inputs=[Path(__file__)]+[BASE/n')]
ledger=ledger.replace('h5-first57-grouped-model-process-20261104','h5-first57-disjoint-model-process-20261104')
tail='''assert len(p.variables)==324 and len(p.constraints)==22065 and mode_count==96 and links==640
inputs=[Path(__file__),ROOT/'output/prepare_h5_first57_disjoint_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_grouped_model_20261104.py']+[BASE/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json','instances.json','inventory.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[OBS/n for n in ['plan.json','audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json','final-preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'all_model_fields_exhaustively_verified':True,'variables_verified':len(used_v),'constraints_verified':len(used_c),
    'source_mode_selectors_verified':mode_count,'source_covering_fixed_boxes_verified':10497,'shared_mask_records_verified':43,'optional_mask_literals_verified':37,
    'mask_presence_constraints_verified':presence_constraints,'rigid_mode_coordinate_links_verified':links,'moving_intervals_verified':48,'fixed_intervals_verified':20994,
    'global_pair_cover_groups_verified':16,'full_physical_stock':True,'prior_positive_regions_consumed':False,'prior_capacity_results_consumed':False,
    'all66_inventory_geometry_audited':True,'preparation_seconds_charged':ledger['preparation_seconds_charged'],
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'maximum_calls':1,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
'''
with (ROOT/'output/audit_h5_first57_disjoint_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(header+helpers+owners+presence+components+fixed+symmetry+ledger+tail)
finalizer=(ROOT/'output/finalize_h5_first57_grouped_budget_20261104.py').read_text(encoding='utf-8')
finalizer=finalizer.replace('h5-first57-grouped-integer-20261104','h5-first57-disjoint-movers-20261104').replace('h5-first57-grouped-model-process-20261104','h5-first57-disjoint-model-process-20261104')
with (ROOT/'output/finalize_h5_first57_disjoint_budget_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(finalizer)
