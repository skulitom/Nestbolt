from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_first57_disjoint_model_20261104.py').read_text(encoding='utf-8')
s=s.replace("MODEL=BASE/'model';OUT=BASE/'model-audit'","MODEL=BASE/'model-factorized';OUT=BASE/'factorized-model-audit'")
s=s.replace('h5-first57-disjoint-model-process-20261104','h5-first57-factorized-model-process-20261104')
a=s.index("assert len(mapping['packing_groups'])");b=s.index('expected_symmetry=[]',a)
s=s[:a]+'''factorization=BASE/'interaction-factorization'
assert load(factorization/'audit/checks.json')['passed']
for name,h in load(factorization/'audit/plan.json')['inputs'].items():assert digest(ROOT/name)==h
factorized=load(factorization/'groups.json');assert len(mapping['packing_groups'])==len(factorized)==17
rectangle_references=0
for actual,source in zip(mapping['packing_groups'],factorized):
    fixed=mapping['fixed_obstacles'] if source['includes_fixed_obstacles'] else []
    assert {k:v for k,v in actual.items() if k not in ['constraint','fixed_obstacles']}=={k:v for k,v in source.items() if k!='includes_fixed_obstacles'}
    assert actual['fixed_obstacles']==len(fixed)
    index=actual['constraint'];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
    assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'}
    assert list(ct.no_overlap_2d.x_intervals)==[o['interval_constraints'][0] for o in fixed]+[mapping['components'][i]['interval_constraints'][0] for i in source['components']]
    assert list(ct.no_overlap_2d.y_intervals)==[o['interval_constraints'][1] for o in fixed]+[mapping['components'][i]['interval_constraints'][1] for i in source['components']]
    rectangle_references+=len(fixed)+len(source['components'])
assert rectangle_references==21258
'''+s[b:]
s=s.replace('len(p.constraints)==22065','len(p.constraints)==22066').replace("'global_pair_cover_groups_verified':16","'global_pair_cover_groups_verified':17,'fixed_obstacle_groups_verified':2,'rectangle_references_verified':21258")
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_first57_factorized_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_disjoint_model_20261104.py',factorization/'audit/plan.json',factorization/'audit/checks.json',factorization/'groups.json',",1)
with (ROOT/'output/audit_h5_first57_factorized_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
f=(ROOT/'output/finalize_h5_first57_disjoint_budget_20261104.py').read_text(encoding='utf-8')
f=f.replace("MODEL=BASE/'model'","MODEL=BASE/'model-factorized'").replace('h5-first57-disjoint-model-process-20261104','h5-first57-factorized-model-process-20261104')
with (ROOT/'output/finalize_h5_first57_factorized_budget_20261104.py').open('x',encoding='utf-8',newline='\n') as out:out.write(f)
