"""Independent interval sweep for every linear and rectangle packing constraint."""
from bisect import bisect_left
def disjoint(rectangles):
    events=[];active=[];neighbors=0
    for i,(a,b,c,d) in enumerate(rectangles):
        assert a<c and b<d
        events.append((a,1,b,d,i));events.append((c,0,b,d,i))
    events.sort()
    for count,(x,start,lo,hi,i) in enumerate(events,1):
        key=(lo,hi,i);at=bisect_left(active,key)
        if not start:
            assert at<len(active) and active[at]==key
            active.pop(at);continue
        if at:
            neighbors+=1
            if active[at-1][1]>lo:return False,neighbors,count
        if at<len(active):
            neighbors+=1
            if active[at][0]<hi:return False,neighbors,count
        active.insert(at,key)
    assert not active
    return True,neighbors,len(events)
def violations(model,values):
    assert len(values)==len(model.variables)
    variable_failures=[i for i,(v,x) in enumerate(zip(model.variables,values)) if not any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))]
    failed=[];active=inactive=neighbors=events=rectangle_count=0
    def expression(e):return e.offset+sum(c*values[i] for i,c in zip(e.vars,e.coeffs))
    def enabled(c):return all(values[i]==1 if i>=0 else values[-i-1]==0 for i in c.enforcement_literal)
    cache={}
    for i,c in enumerate(model.constraints):
        if not enabled(c):inactive+=1;continue
        active+=1;kind=c.WhichOneof('constraint')
        if kind=='linear':
            value=sum(k*values[v] for v,k in zip(c.linear.vars,c.linear.coeffs))
            good=any(a<=value<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='interval':
            start,size,end=map(expression,[c.interval.start,c.interval.size,c.interval.end])
            good=size>0 and start+size==end;cache[i]=(start,end)
        elif kind=='no_overlap_2d':
            rectangles=[]
            for x,y in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                xc,yc=model.constraints[x],model.constraints[y]
                assert xc.WhichOneof('constraint')==yc.WhichOneof('constraint')=='interval'
                if enabled(xc) and enabled(yc):
                    assert x in cache and y in cache
                    rectangles.append((cache[x][0],cache[y][0],cache[x][1],cache[y][1]))
            good,n,e=disjoint(rectangles);neighbors+=n;events+=e;rectangle_count+=len(rectangles)
        else:raise AssertionError('Unexpected constraint: '+str(kind))
        if not good:failed.append(i)
    return {'variable_failures':variable_failures,'failed_constraints':failed,'active_constraints':active,'inactive_constraints':inactive,
            'global_rectangle_neighbor_checks':neighbors,'global_rectangle_sweep_events':events,'active_rectangles_including_group_repetitions':rectangle_count}
