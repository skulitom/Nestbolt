from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_first57_disjoint_response_20261104.py').read_text(encoding='utf-8')
s=s.replace("MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'","MODEL=BASE/'model-factorized';SEARCH=BASE/'search-factorized';OUT=BASE/'factorized-response-audit'")
s=s.replace("BASE/'model-audit","BASE/'factorized-model-audit").replace("'audit','model-audit'","'audit','factorized-model-audit'")
s=s.replace('h5-first57-disjoint-model-process-20261104','h5-first57-factorized-model-process-20261104').replace('22065','22066')
s=s.replace("assert response.num_branches==response.num_conflicts==0\nassert 'Stopped after presolve.' in (SEARCH/'solver.log').read_text()","assert response.num_branches==2005 and response.num_conflicts==77\nassert 'Starting search at 11.10s' in (SEARCH/'solver.log').read_text()\nassert 'Stopped after presolve.' not in (SEARCH/'solver.log').read_text()")
s=s.replace("'stopped_after_presolve':True","'stopped_after_presolve':False,'search_started_after_solver_seconds':11.10")
with (ROOT/'output/audit_h5_first57_factorized_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
