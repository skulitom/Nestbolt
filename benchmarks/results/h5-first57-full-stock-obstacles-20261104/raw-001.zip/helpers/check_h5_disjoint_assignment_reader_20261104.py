"""Independent brute-force controls for the exact sweep and optional intervals."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,random,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from h5_disjoint_model_assignment_reader_20261104 import disjoint,violations
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-disjoint-assignment-reader-controls-20261104'
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();rng=random.Random(0)
cases=[[],[(0,0,1,1)],[(0,0,1,1),(1,0,2,1)],[(0,0,2,2),(1,1,3,3)],[(0,0,5,5),(1,1,2,2)],[(0,0,2,2),(0,2,2,4)]]
for count in range(1,101):
    rectangles=[]
    for _ in range(count):
        a,b=rng.randrange(-50,51),rng.randrange(-50,51);rectangles.append((a,b,a+rng.randrange(1,11),b+rng.randrange(1,11)))
    cases.append(rectangles)
for rectangles in cases:
    expected=all(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1] for a,b in combinations(rectangles,2))
    assert disjoint(rectangles)[0]==expected
model=cp_model.CpModel();presence=model.new_bool_var('present');x=model.new_int_var(0,5,'x')
ix=model.new_interval_var(x,2,x+2,'moving_x');iy=model.new_interval_var(0,2,2,'moving_y')
ox=model.new_optional_interval_var(1,2,3,presence,'obstacle_x');oy=model.new_optional_interval_var(1,2,3,presence,'obstacle_y')
ct=model.add_no_overlap_2d([ix,ox],[iy,oy])
proto=text_format.Parse(str(model.proto),cp_model_pb2.CpModelProto())
assert not violations(proto,[0,0])['failed_constraints']
assert violations(proto,[1,0])['failed_constraints']==[ct.index]
assert not violations(proto,[1,3])['failed_constraints']
assert violations(proto,[1,6])['variable_failures']==[x.index]
inputs=[Path(__file__),ROOT/'output/h5_disjoint_model_assignment_reader_20261104.py']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'brute_force_sweep_controls':len(cases),'optional_interval_controls':4,
    'same_coordinate_removals_before_insertions':True,'full_model_assignment_check_pending':True,'solver_calls':0})
print(json.loads((OUT/'checks.json').read_bytes()))
