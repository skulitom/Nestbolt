"""Fresh full-physical-stock source-covering moving rectangles and pair groups."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-disjoint-movers-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';PARTITION=ROOT/'output/h5-first57-necessary-rectangles-20261104/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def transform(p,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation_from_lower_left'])
    return [(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in p]
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),JOB,PIECES]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','inventory.json']]+[PARTITION/n for n in ['plan.json','checks.json','exact-source-partitions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Prepare original source-covering component rectangles afresh at0.01mm resolution, and exact inward anchor bounds over the full physical stock with0.025mm reserve. Do not consume the older construction strip bounds or prior integer regions. Recreate all16 moving identities and24 rigid components. Sixteen parity groups with one component per owner cover all268 distinct-owner component pairs. Both moving rectangles and fixed disjoint obstacle boxes receive the same right/top0.23mm expansion in the eventual model; complete original source and stock checks remain mandatory.',
    'coordinate_units_per_mm':100,'world_origin_mm':[0,0],'stock_reserve_mm':0.025,'right_top_extension_grid':23,
    'full_physical_stock':True,'prior_positive_regions_consumed':False,'prior_capacity_results_consumed':False,'preparation_cap_seconds':10,'maximum_process_seconds':20,'solver_calls':0})
assert load(PRE/'audit/checks.json')['passed'] and load(PARTITION/'checks.json')['passed']
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES);oldmodes=load(PRE/'family-modes.json')
stock=list(map(F,load(PRE/'plan.json')['source_stocks']['sheet-0']));margin=F('0.025')
modes={};rectangles={}
for family in ['bracket','insert']:
    modes[family]=[];rectangles[family]=[]
    for old in oldmodes[family]:
        mode={k:v for k,v in old.items() if k!='lower_left_bounds'}
        p=transform(parts[family]['geometry'][0]['outer'],mode)
        exact=[[stock[k]+margin-min(v[k] for v in p),stock[k+2]-margin-max(v[k] for v in p)] for k in range(2)]
        mode['exact_lower_left_bounds_mm']=[[str(a),str(b)] for a,b in exact]
        mode['integer_lower_left_bounds']=[[math.ceil(a*100),math.floor(b*100)] for a,b in exact]
        modes[family].append(mode)
        rs=[]
        for pi,piece in enumerate(canonical[family]):
            transformed=transform(piece,mode)
            rs.append({'piece':pi,'outward_offsets_grid':[math.floor(min(x for x,y in transformed)*100),math.floor(min(y for x,y in transformed)*100),math.ceil(max(x for x,y in transformed)*100),math.ceil(max(y for x,y in transformed)*100)]})
        rectangles[family].append({'mode':mode['mode'],'rectangles':rs})
inventory=load(PRE/'inventory.json');identities=inventory['moving16_orthogonal_identities']
instances=[{'identity':i,'mode_count':len(modes[i[0]])} for i in identities];components=[]
for owner,identity in enumerate(identities):
    for piece in range(len(canonical[identity[0]])):components.append({'component':len(components),'owner':owner,'identity':identity,'piece':piece})
bracket_owners=[o for o,i in enumerate(identities) if i[0]=='bracket'];labels={o:i+1 for i,o in enumerate(bracket_owners)}
groups=[]
for code in range(16):
    members=[c['component'] for c in components if c['identity'][0]=='insert' or c['piece']==((code&labels[c['owner']]).bit_count()%2)]
    assert len(members)==len(identities) and len({components[i]['owner'] for i in members})==len(members)
    groups.append({'group':code,'components':members})
certs=[]
for a,b in combinations(components,2):
    if a['owner']==b['owner']:continue
    witnesses=[g['group'] for g in groups if a['component'] in g['components'] and b['component'] in g['components']]
    assert len(witnesses)>=4
    certs.append({'components':[a['component'],b['component']],'groups':witnesses})
for name,data in [('family-modes.json',modes),('mode-rectangles.json',rectangles),('instances.json',instances),('components.json',components),('pair-cover-groups.json',groups),('pair-cover-certificates.json',certs),('inventory.json',inventory)]:write(OUT/name,data)
checks={'prepared':True,'seconds':time.perf_counter()-started,'legal_modes':sum(map(len,modes.values())),'moving_identities':len(identities),'rigid_components':len(components),'pair_cover_groups':len(groups),'different_owner_component_pairs':len(certs),
    'full_physical_stock_bounds':True,'previous_strip_bounds_reused':False,'source_geometry_audit_pending':True,'solver_calls':0,'H5_complete':False}
assert checks['seconds']<10
write(OUT/'checks.json',checks);print(checks)
