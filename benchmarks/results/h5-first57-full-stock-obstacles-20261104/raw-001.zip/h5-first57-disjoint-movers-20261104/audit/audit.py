"""Independent exact original-source full-stock and rectangle-cover audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-disjoint-movers-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';PARTITION=ROOT/'output/h5-first57-necessary-rectangles-20261104/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transformed(source,mode):
    angle=mode['rotation_radians'];co=F(math.cos(angle));si=F(math.sin(angle));mirror=-1 if mode['mirrored'] else 1
    tx,ty=map(F,mode['translation_from_lower_left'])
    return [(mirror*F(v[0])*co-F(v[1])*si+tx,mirror*F(v[0])*si+F(v[1])*co+ty) for v in source]
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for directory in [BASE,PARTITION]:
    for p,h in load(directory/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
assert load(PARTITION/'checks.json')['passed'] and load(PRE/'audit/checks.json')['passed']
partitions=load(PARTITION/'exact-source-partitions.json')
assert all(p['exact_partition_boundary_and_area'] for p in partitions) and {p['family'] for p in partitions}=={'bracket','insert','cog'}
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES);original=load(PRE/'family-modes.json')
modes=load(BASE/'family-modes.json');rectangles=load(BASE/'mode-rectangles.json')
stock=list(map(F,load(PRE/'plan.json')['source_stocks']['sheet-0']));reserve=F(1,40);mode_count=rect_count=corner_count=0
assert set(modes)==set(rectangles)=={'bracket','insert'}
for family in modes:
    assert len(modes[family])==len(rectangles[family])==len(original[family])
    for mode,old,rs in zip(modes[family],original[family],rectangles[family]):
        assert {k:v for k,v in mode.items() if k not in ['integer_lower_left_bounds','exact_lower_left_bounds_mm']}=={k:v for k,v in old.items() if k!='lower_left_bounds'}
        assert mode['rotation_degrees'] in parts[family]['rotations']['degrees'] and (not mode['mirrored'] or parts[family]['allow_mirror'])
        outer=transformed(parts[family]['geometry'][0]['outer'],mode)
        expected=[[stock[k]+reserve-min(v[k] for v in outer),stock[k+2]-reserve-max(v[k] for v in outer)] for k in range(2)]
        assert [[F(v) for v in r] for r in mode['exact_lower_left_bounds_mm']]==expected
        expected_grid=[[math.ceil(a*100),math.floor(b*100)] for a,b in expected]
        assert mode['integer_lower_left_bounds']==expected_grid and all(a<=b for a,b in expected_grid)
        for vertex in outer:
            for axis in range(2):
                assert stock[axis]+reserve<=vertex[axis]+F(expected_grid[axis][0],100)
                assert vertex[axis]+F(expected_grid[axis][1],100)<=stock[axis+2]-reserve
                corner_count+=2
        assert rs['mode']==mode['mode'] and len(rs['rectangles'])==len(canonical[family])
        for i,(row,piece) in enumerate(zip(rs['rectangles'],canonical[family])):
            assert row['piece']==i;poly=transformed(piece,mode)
            expected_box=[math.floor(min(p[0] for p in poly)*100),math.floor(min(p[1] for p in poly)*100),math.ceil(max(p[0] for p in poly)*100),math.ceil(max(p[1] for p in poly)*100)]
            assert row['outward_offsets_grid']==expected_box
            a,b,c,d=[F(v,100) for v in expected_box];assert a<c and b<d
            assert all(a<=x<=c and b<=y<=d for x,y in poly);rect_count+=1
        mode_count+=1
inventory=load(BASE/'inventory.json');assert inventory==load(PRE/'inventory.json')
sets={key:set(map(tuple,inventory[key])) for key in ['full66_identities','short9_identities','first57_identities','fixed29_identities','required_cog12_identities','moving16_orthogonal_identities']}
assert len(sets['full66_identities'])==66 and len(sets['short9_identities'])==9 and len(sets['first57_identities'])==57
assert sets['short9_identities'].isdisjoint(sets['first57_identities']) and sets['short9_identities']|sets['first57_identities']==sets['full66_identities']
chunks=[sets['fixed29_identities'],sets['required_cog12_identities'],sets['moving16_orthogonal_identities']]
assert list(map(len,chunks))==[29,12,16] and set.union(*chunks)==sets['first57_identities'] and all(a.isdisjoint(b) for a,b in combinations(chunks,2))
assert {('bracket',i) for i in [0,1,2,3,4,5,6,9]}|{('insert',i) for i in [6,7,15,16,17,18,19,20]}==sets['moving16_orthogonal_identities']
instances=load(BASE/'instances.json');components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json');certificates=load(BASE/'pair-cover-certificates.json')
identities=inventory['moving16_orthogonal_identities']
assert instances==[{'identity':i,'mode_count':len(modes[i[0]])} for i in identities]
expected_components=[]
for owner,identity in enumerate(identities):
    for piece in range(len(canonical[identity[0]])):expected_components.append({'component':len(expected_components),'owner':owner,'identity':identity,'piece':piece})
assert components==expected_components and len(components)==24 and len(groups)==16
for code,g in enumerate(groups):
    assert g['group']==code and len(g['components'])==16 and len(set(g['components']))==16
    assert {components[i]['owner'] for i in g['components']}==set(range(16))
expected_certificates=[]
for a,b in combinations(components,2):
    if a['owner']==b['owner']:continue
    witnesses=[g['group'] for g in groups if a['component'] in g['components'] and b['component'] in g['components']]
    assert len(witnesses)>=4
    expected_certificates.append({'components':[a['component'],b['component']],'groups':witnesses})
assert certificates==expected_certificates and len(certificates)==268
inputs=[Path(__file__),JOB,PIECES]+[PRE/n for n in ['plan.json','family-modes.json','inventory.json','audit/plan.json','audit/checks.json']]+[PARTITION/n for n in ['plan.json','checks.json','exact-source-partitions.json']]+[BASE/n for n in ['plan.json','checks.json','family-modes.json','mode-rectangles.json','instances.json','inventory.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Exact transformed original vertices lie in every source-covering component rectangle. Convexity and the previously exact-certified partition extend vertex containment to the entire filled source. Every permitted grid anchor keeps all original outer vertices at least0.025mm inside physical stock; the stock is convex, so all filled source follows. All66 identities partition into short9, fixed29, cog12 and moving16 exactly once. Each pair of source components from distinct moving originals occurs in at least four groups; each group includes exactly one component per owner. Enforcing disjoint interiors on rectangles expanded right/top by0.23mm gives at least0.23mm original-source L-infinity, hence Euclidean, separation. Same-owner component overlaps must not be constrained. These are positive construction implications and do not prove infeasibility or new exclusions.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'legal_source_modes_verified':mode_count,'source_covering_rectangles_verified':rect_count,
    'original_vertex_stock_inequalities_verified':corner_count,'full_physical_stock_bounds':True,'previous_strip_bounds_reused':False,
    'all66_identities_accounted_once':True,'moving16_identities_verified':True,'rigid_components':24,'groups':16,'different_owner_component_pairs_covered':268,
    'minimum_pair_group_multiplicity':min(len(r['groups']) for r in certificates),'source_stock_reserve_mm':0.025,'conditional_source_pair_clearance_mm':0.23,
    'new_model_prepared':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
