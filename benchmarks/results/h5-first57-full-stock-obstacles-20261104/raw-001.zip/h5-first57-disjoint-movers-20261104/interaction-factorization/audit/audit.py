from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-disjoint-movers-20261104';PRE=BASE/'interaction-factorization';OUT=PRE/'audit'
OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for n,h in load(PRE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(BASE/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['all_nonzero_cells_covered_exactly_once']
components=load(BASE/'components.json');old=load(BASE/'pair-cover-groups.json');new=load(PRE/'groups.json');nfixed=len(load(OBS/'disjoint-mask-boxes.json'))
expected={tuple(sorted((a['component'],b['component']))) for a,b in combinations(components,2) if a['owner']!=b['owner']}
def interactions(groups):
    pairs=set()
    for group in groups:
        members=group['components'];assert len(members)==len(set(members))
        assert len({components[i]['owner'] for i in members})==len(members)
        pairs.update(tuple(sorted(p)) for p in combinations(members,2))
    return pairs
assert interactions(old)==interactions(new)==expected and len(expected)==268
fixed_owners=[i for group in new if group['includes_fixed_obstacles'] for i in group['components']]
assert sorted(fixed_owners)==list(range(24))
assert [g['group'] for g in new]==list(range(17))
assert [{k:v for k,v in g.items() if k!='includes_fixed_obstacles'} for g in new[:16]]==old
assert [g['group'] for g in new if g['includes_fixed_obstacles']]==[0,16]
for r in load(PRE/'moving-pair-cover.json'):
    a,b=r['components'];assert (a,b) in expected
    assert r['before']==sum({a,b}<=set(g['components']) for g in old)
    assert r['after']==sum({a,b}<=set(g['components']) for g in new)
assert len(load(PRE/'moving-pair-cover.json'))==268
for i,r in enumerate(load(PRE/'fixed-pair-cover.json')):
    assert r=={'component':i,'old_fixed_groups':sum(i in g['components'] for g in old),'new_fixed_groups':1}
assert len(load(PRE/'fixed-pair-cover.json'))==24
before=sum(nfixed+len(g['components']) for g in old);after=sum((nfixed if g['includes_fixed_obstacles'] else 0)+len(g['components']) for g in new)
assert before==168208 and after==21258 and nfixed==10497
inputs=[Path(__file__),PRE/'plan.json',PRE/'checks.json',PRE/'groups.json',PRE/'moving-pair-cover.json',PRE/'fixed-pair-cover.json',BASE/'components.json',BASE/'pair-cover-groups.json',BASE/'audit/plan.json',BASE/'audit/checks.json',OBS/'audit/plan.json',OBS/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Expanding each NoOverlap2D group into all unordered active rectangle pairs gives exactly the same distinct-owner moving-pair set before and after. Every moving component occurs with all fixed obstacle boxes once after factorization, so all24*10497 moving/fixed pair requirements are preserved. Fixed/fixed pairs are universal tautologies by the independently verified disjoint source-cover partition. No group contains two components of one owner. Therefore feasible assignments, source coverage and clearance are unchanged, while fixed obstacle references decrease from16 to2 copies. The factorized groups must be recomputed inside the complete model-build process rather than importing an uncharged proposal calculation.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'moving_pair_set_identical':True,'different_owner_moving_pairs':268,'moving_fixed_pairs_retained':24*nfixed,
    'same_owner_pairs_introduced':0,'fixed_obstacle_copies_before':16,'fixed_obstacle_copies_after':2,'rectangle_references_before':before,'rectangle_references_after':after,
    'new_geometry_restrictions':0,'new_solver_calls':0}
write(OUT/'checks.json',checks);print(checks)
