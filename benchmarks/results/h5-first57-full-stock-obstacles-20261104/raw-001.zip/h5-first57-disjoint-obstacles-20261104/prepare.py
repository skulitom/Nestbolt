"""Source-covering staircase obstacles, partitioned into disjoint site-mask boxes."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
PARTITION=ROOT/'output/h5-first57-necessary-rectangles-20261104/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def transform(v,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    return [(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in v]
def clip(poly,level,lower):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[1]>=level if lower else a[1]<=level
        inb=b[1]>=level if lower else b[1]<=level
        if ina:result.append(a)
        if ina!=inb:result.append((a[0]+(b[0]-a[0])*(level-a[1])/(b[1]-a[1]),level))
    return result
def deadline():assert time.perf_counter()-started<35,'Declared preparation cap reached; no construction claim is certified.'
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),JOB,PIECES]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed29.json','source-cog-sites.json','family-modes.json','inventory.json']]+[PARTITION/n for n in ['plan.json','checks.json','exact-source-partitions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New positive construction representation, independent of the closed grouped-region model. Cover every exact rotated cog convex piece by horizontal-band bounding rectangles, with every source vertex level and every2mm level included. Merge overlapping X intervals within a band, translate to all15 source sites, round outward on a0.01mm grid and extend right/top by0.23mm. Cover each filled fixed-core source by its outward grid box, with the same extension. Partition the union into disjoint positive-area boxes carrying the OR of original source site bits. A box is present when any named cog is occupied or the fixed-core bit is set. A source-contained moving-part outer rectangle similarly extended right/top can avoid all present boxes through NoOverlap2D. This guarantees at least0.23mm axis clearance from the original fixed source. All fixed obstacle boxes have disjoint interiors, even if original source covers overlap. Source coverage and exact mask partition require independent audit before model use.',
    'coordinate_units_per_mm':100,'local_band_step_mm':2,'right_top_extension_grid_units':23,
    'preparation_cap_seconds':35,'maximum_process_seconds':50,'maximum_mask_cells':40000000,
    'fixed_core_mask_bit':15,'required_empty_cog_sites':3,'candidate_site_triples':455,
    'prior_capacity_results_consumed':False,'new_solver_calls':0,'whole_allocations_excluded':0})
assert load(PRE/'audit/checks.json')['passed'] and load(PARTITION/'checks.json')['passed']
canonical=load(PIECES);modes=load(PRE/'family-modes.json');mode=modes['cog'][0]
t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':mode['translation_from_lower_left']}
pieces=[transform(p,t) for p in canonical['cog']]
ymin=min(y for p in pieces for x,y in p);ymax=max(y for p in pieces for x,y in p)
cuts=sorted({y for p in pieces for x,y in p}|{F(2*i) for i in range(math.ceil(ymin/2),math.floor(ymax/2)+1)})
bands=[];slices=[]
for bi,(lo,hi) in enumerate(zip(cuts,cuts[1:])):
    intervals=[]
    for pi,p in enumerate(pieces):
        if max(y for x,y in p)<=lo or min(y for x,y in p)>=hi:continue
        clipped=clip(clip(p,lo,True),hi,False);assert clipped
        left=min(x for x,y in clipped);right=max(x for x,y in clipped)
        assert left<right
        intervals.append((left,right))
        slices.append({'piece':pi,'band':bi,'x_bounds_mm':[str(left),str(right)]})
    merged=[]
    for a,b in sorted(intervals):
        if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
        else:merged.append([a,b])
    assert merged
    bands.append({'band':bi,'y_bounds_mm':[str(lo),str(hi)],'x_intervals_mm':[[str(a),str(b)] for a,b in merged]})
write(OUT/'source-band-slices.json',slices);write(OUT/'normalized-cover-bands.json',bands)
obstacles=[];sites=load(PRE/'source-cog-sites.json')
for site,row in enumerate(sites):
    assert row['transform']['rotation_radians']==t['rotation_radians'] and row['transform']['mirrored']==t['mirrored']
    dx,dy=[F(row['transform']['translation'][k])-F(t['translation'][k]) for k in [0,1]]
    for band in bands:
        lo,hi=map(F,band['y_bounds_mm'])
        for ii,(a,b) in enumerate(band['x_intervals_mm']):
            r=[math.floor((F(a)+dx)*100),math.floor((lo+dy)*100),math.ceil((F(b)+dx)*100)+23,math.ceil((hi+dy)*100)+23]
            obstacles.append({'site_bit':site,'band':band['band'],'interval':ii,'bounds_grid':r})
    deadline()
parts={p['id']:p for p in load(JOB)['parts']}
for i,row in enumerate(load(PRE/'fixed29.json')):
    p=transform(parts[row['part_id']]['geometry'][0]['outer'],row['transform'])
    r=[math.floor(min(x for x,y in p)*100),math.floor(min(y for x,y in p)*100),math.ceil(max(x for x,y in p)*100)+23,math.ceil(max(y for x,y in p)*100)+23]
    obstacles.append({'site_bit':15,'fixed_owner':i,'bounds_grid':r})
write(OUT/'source-cover-obstacles.json',obstacles)
xs=np.array(sorted({v for r in obstacles for v in [r['bounds_grid'][0],r['bounds_grid'][2]]}),dtype=np.int64)
ys=np.array(sorted({v for r in obstacles for v in [r['bounds_grid'][1],r['bounds_grid'][3]]}),dtype=np.int64)
assert (len(xs)-1)*(len(ys)-1)<=40000000
xi={int(x):i for i,x in enumerate(xs)};yi={int(y):i for i,y in enumerate(ys)}
mask=np.zeros((len(ys)-1,len(xs)-1),dtype=np.uint16)
for r in obstacles:
    a,b,c,d=r['bounds_grid'];mask[yi[b]:yi[d],xi[a]:xi[c]]|=np.uint16(1<<r['site_bit'])
np.savez_compressed(OUT/'mask-classes.npz',xcuts_grid=xs,ycuts_grid=ys,mask=mask)
boxes=[];active={}
def close(key,span):
    m,xa,xb=key;ya,yb=span;boxes.append([m,int(xs[xa]),int(ys[ya]),int(xs[xb]),int(ys[yb]),xa,ya,xb,yb])
for y,row in enumerate(mask):
    starts=np.r_[0,np.flatnonzero(row[1:]!=row[:-1])+1];ends=np.r_[starts[1:],len(row)];current={}
    for xa,xb in zip(starts.tolist(),ends.tolist()):
        m=int(row[xa])
        if not m:continue
        key=(m,xa,xb);current[key]=[active[key][0] if key in active else y,y+1]
    for key,span in active.items():
        if key not in current:close(key,span)
    active=current
    if y%128==0:deadline()
for key,span in active.items():close(key,span)
boxes.sort();write(OUT/'disjoint-mask-boxes.json',boxes)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'source_convex_pieces':len(pieces),'source_piece_band_slices':len(slices),
    'normalized_bands':len(bands),'normalized_band_intervals':sum(len(b['x_intervals_mm']) for b in bands),
    'world_source_cover_rectangles':len(obstacles),'mask_cells':int(mask.size),'disjoint_obstacle_boxes':len(boxes),
    'unique_masks':len({b[0] for b in boxes}),'fixed_core_boxes':sum(bool(b[0]&32768) for b in boxes),
    'source_coverage_and_partition_audit_pending':True,'new_model_prepared':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
