"""Exact source-band coverage and independent per-bit event-count partition audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-disjoint-obstacles-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';PARTITION=ROOT/'output/h5-first57-necessary-rectangles-20261104/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transformed(p,t):
    theta=t['rotation_radians'];c=F(math.cos(theta));s=F(math.sin(theta));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    return [(m*F(v[0])*c-F(v[1])*s+tx,m*F(v[0])*s+F(v[1])*c+ty) for v in p]
def band_x_extrema(poly,lo,hi):
    points=[p for p in poly if lo<=p[1]<=hi]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if a[1]==b[1]:continue
        for y in (lo,hi):
            if min(a[1],b[1])<=y<=max(a[1],b[1]):
                points.append((a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]),y))
    assert points
    return min(x for x,y in points),max(x for x,y in points)
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for directory in [BASE,PARTITION]:
    for path,h in load(directory/'plan.json')['inputs'].items():assert digest(ROOT/path)==h,path
assert load(PARTITION/'checks.json')['passed'] and load(PARTITION/'exact-source-partitions.json')[2]['exact_partition_boundary_and_area']
mode=load(PRE/'family-modes.json')['cog'][0]
t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':mode['translation_from_lower_left']}
pieces=[transformed(p,t) for p in load(PIECES)['cog']]
lo=min(y for p in pieces for x,y in p);hi=max(y for p in pieces for x,y in p)
cuts=sorted({y for p in pieces for x,y in p}|{F(2*i) for i in range(math.ceil(lo/2),math.floor(hi/2)+1)})
bands=load(BASE/'normalized-cover-bands.json');assert len(bands)==len(cuts)-1
expected_slices=[];verified_intervals=0
for bi,(a,b) in enumerate(zip(cuts,cuts[1:])):
    claimed=bands[bi];assert claimed['band']==bi and list(map(F,claimed['y_bounds_mm']))==[a,b]
    spans=[]
    for pi,poly in enumerate(pieces):
        if max(y for x,y in poly)<=a or min(y for x,y in poly)>=b:continue
        left,right=band_x_extrema(poly,a,b);assert left<right
        spans.append((left,right));expected_slices.append({'piece':pi,'band':bi,'x_bounds_mm':[str(left),str(right)]})
    intervals=[list(map(F,r)) for r in claimed['x_intervals_mm']]
    assert intervals and all(x<y for x,y in intervals)
    assert all(intervals[i][1]<intervals[i+1][0] for i in range(len(intervals)-1))
    for x,y in spans:assert any(a<=x and y<=b for a,b in intervals)
    # Reconstruct the union by connected endpoint events rather than polygon clipping.
    events={}
    for x,y in spans:events[x]=events.get(x,0)+1;events[y]=events.get(y,0)-1
    expected=[];count=0;start=None
    for x,delta in sorted(events.items()):
        if count==0:start=x
        count+=delta
        if count==0:expected.append([start,x])
        assert count>=0
    assert count==0 and expected==intervals
    verified_intervals+=len(intervals)
assert load(BASE/'source-band-slices.json')==expected_slices
expected=[];sites=load(PRE/'source-cog-sites.json')
assert len(sites)==15
for site,row in enumerate(sites):
    assert row['transform']['rotation_radians']==t['rotation_radians'] and row['transform']['mirrored']==t['mirrored']
    dx,dy=[F(row['transform']['translation'][k])-F(t['translation'][k]) for k in [0,1]]
    for band in bands:
        ymin,ymax=map(F,band['y_bounds_mm'])
        for ii,pair in enumerate(band['x_intervals_mm']):
            xmin,xmax=map(F,pair)
            exact=[xmin+dx,ymin+dy,xmax+dx,ymax+dy]
            bounds=[math.floor(exact[0]*100),math.floor(exact[1]*100),math.ceil(exact[2]*100)+23,math.ceil(exact[3]*100)+23]
            assert F(bounds[0],100)<=exact[0] and F(bounds[1],100)<=exact[1] and F(bounds[2]-23,100)>=exact[2] and F(bounds[3]-23,100)>=exact[3]
            expected.append({'site_bit':site,'band':band['band'],'interval':ii,'bounds_grid':bounds})
parts={p['id']:p for p in load(JOB)['parts']}
for i,row in enumerate(load(PRE/'fixed29.json')):
    p=transformed(parts[row['part_id']]['geometry'][0]['outer'],row['transform']);assert len(p)==4
    bounds=[math.floor(min(x for x,y in p)*100),math.floor(min(y for x,y in p)*100),math.ceil(max(x for x,y in p)*100)+23,math.ceil(max(y for x,y in p)*100)+23]
    assert all(F(bounds[0],100)<=x<=F(bounds[2]-23,100) and F(bounds[1],100)<=y<=F(bounds[3]-23,100) for x,y in p)
    expected.append({'site_bit':15,'fixed_owner':i,'bounds_grid':bounds})
assert load(BASE/'source-cover-obstacles.json')==expected
xs=sorted({v for r in expected for v in [r['bounds_grid'][0],r['bounds_grid'][2]]})
ys=sorted({v for r in expected for v in [r['bounds_grid'][1],r['bounds_grid'][3]]})
xi={x:i for i,x in enumerate(xs)};yi={y:i for i,y in enumerate(ys)}
with np.load(BASE/'mask-classes.npz',allow_pickle=False) as data:
    assert set(data.files)=={'xcuts_grid','ycuts_grid','mask'} and data['xcuts_grid'].dtype==data['ycuts_grid'].dtype==np.dtype('int64')
    assert data['xcuts_grid'].tolist()==xs and data['ycuts_grid'].tolist()==ys
    mask=data['mask'];assert mask.shape==(len(ys)-1,len(xs)-1) and mask.dtype==np.dtype('uint16')
replay=np.zeros(mask.shape,dtype=np.uint16)
for bit in range(16):
    diff=np.zeros((len(ys),len(xs)),dtype=np.int32);events=0
    for r in expected:
        if r['site_bit']!=bit:continue
        a,b,c,d=r['bounds_grid'];xa,xb=xi[a],xi[c];ya,yb=yi[b],yi[d]
        assert xa<xb and ya<yb
        diff[ya,xa]+=1;diff[ya,xb]-=1;diff[yb,xa]-=1;diff[yb,xb]+=1;events+=1
    counts=np.cumsum(np.cumsum(diff,axis=0,dtype=np.int32),axis=1,dtype=np.int32)
    assert counts.min()>=0 and counts.max()<=events
    replay[counts[:-1,:-1]>0]|=np.uint16(1<<bit)
assert np.array_equal(replay,mask)
covered=np.zeros(mask.shape,dtype=np.uint8);boxes=load(BASE/'disjoint-mask-boxes.json')
for row in boxes:
    assert len(row)==9 and all(type(v) is int for v in row)
    m,a,b,c,d,xa,ya,xb,yb=row
    assert 0<m<65536 and 0<=xa<xb<len(xs) and 0<=ya<yb<len(ys)
    assert [a,b,c,d]==[xs[xa],ys[ya],xs[xb],ys[yb]] and np.all(mask[ya:yb,xa:xb]==m)
    covered[ya:yb,xa:xb]+=1
assert np.array_equal(covered,(mask>0).astype(np.uint8))
inputs=[Path(__file__),JOB,PIECES]+[PRE/n for n in ['family-modes.json','fixed29.json','source-cog-sites.json']]+[PARTITION/n for n in ['plan.json','checks.json','exact-source-partitions.json']]+[BASE/n for n in ['plan.json','checks.json','source-band-slices.json','normalized-cover-bands.json','source-cover-obstacles.json','mask-classes.npz','disjoint-mask-boxes.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'The audited exact source partition covers each filled cog. In every horizontal band, all vertices of its convex piece clipping are either original vertices or exact edge intersections with band boundaries; independently reconstructed X extrema fit one recorded interval. All bands cover the entire piece including their boundaries. Translation and outward grid rounding preserve coverage. Extension by[0,0.23]^2 covers the corresponding Minkowski dilation. Every positive-area original obstacle rectangle is exactly partitioned into arrangement cells; the closure of those cells also covers its boundary. A separate per-site integer event-count replay verifies every mask, and all nonzero cells belong exactly once to disjoint output boxes. For any twelve selected cogs plus fixed29, making precisely the boxes with a selected-site bit present gives their complete dilated source cover. If moving source outer components, likewise extended right/top by0.23mm, have disjoint interiors from all present boxes, original-source L-infinity separation is at least0.23mm, hence Euclidean separation is at least0.23mm. Future model audit must enforce these presence and rectangle constraints, original full stock domains and moving-to-moving separation. This is a conservative positive representation, not a continuous exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'source_piece_band_slices_verified':len(expected_slices),'normalized_bands_verified':len(bands),'merged_intervals_verified':verified_intervals,
    'world_source_cover_rectangles_verified':len(expected),'mask_cells_independently_verified':int(mask.size),'site_bit_fields_replayed':16,
    'disjoint_obstacle_boxes_verified':len(boxes),'unique_masks':len({b[0] for b in boxes}),'fixed_core_boxes':sum(bool(b[0]&32768) for b in boxes),
    'all_source_boundaries_covered':True,'all_nonzero_cells_covered_exactly_once':True,'positive_source_cover_certified':True,'conditional_clearance_mm':0.23,
    'new_model_prepared':False,'site_choices_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
