"""Independently restore the parent and reconstruct all relative-Y propagation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-relative-y-spacing-probe-20261026';PARENT=ROOT/'output/h5-eight-phase-balanced-probe-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';DATA=ROOT/'output/h5-relative-y-cog-spacing-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Restore every parent proto field exactly. Derive the whole relative-Y interval directly from all eight original stock domains and reconstruct its35-bin disjoint integer cover. Independently rebuild all210 Boolean variables, their difference intervals, six exact-one sums and13146 conditional spacing inequalities using the source-specific independently proved rectangles. Check every phase-pair/bin interval covers the actual source intersection, all copied records and exact final inventory. Prove unique extension of every parent witness and actual solver import/export. No solving or exclusion from the parent UNKNOWN.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for p in [PARENT/'model-audit/checks.json',PARENT/'response-audit/checks.json',SOURCE/'audit/checks.json',DATA/'audit/checks.json']:assert load(p)['passed']
assert load(PARENT/'search/000/result.json')['status']=='UNKNOWN'
parent=proto(PARENT/'models/000.pb');m=proto(BASE/'models/000.pb');nv,nc=len(parent.variables),len(parent.constraints);assert (nv,nc)==(233563,240227);restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[nv:];del restored.constraints[nc:];assert restored==parent
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json','spacing-constraints.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
s=load(SOURCE/'plan.json');flags=load(BASE/'profile-flags.json');phases=s['allowed_profiles'][5];assert s['allowed_profiles'][5:]==[phases]*4;domains=s['anchor_bounds_units1000'];low=min(domains[str(p)][1] for p in phases);high=max(domains[str(p)][3] for p in phases);lo,hi=low-high,high-low;bins=[[a,min(a+1999,hi)] for a in range(lo,hi+1,2000)];assert bins==load(DATA/'plan.json')['bins_units1000'] and len(bins)==35;rows=load(DATA/'bounds.json');vi,ci=nv,nc;selectors=[];constraints=[]
for pa,pb in product(phases,repeat=2):
    aa,bb=domains[str(pa)],domains[str(pb)];pairlo,pairhi=bb[1]-aa[3],bb[3]-aa[1]
    want=[(i,max(a,pairlo),min(b,pairhi)) for i,(a,b) in enumerate(bins) if max(a,pairlo)<=min(b,pairhi)]
    actual=[(r['bin'],*r['relative_y_units1000']) for r in rows if r['profiles']==[pa,pb]];assert actual==want
for a,b in combinations(range(5,9),2):
    ids=[]
    for ordinal,(low,high) in enumerate(bins):
        assert m.variables[vi]==cp_model_pb2.IntegerVariableProto(name=f'pair-{a}-{b}-relative-y-bin{ordinal}',domain=[0,1]);c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(vi);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([low,high]);assert c==m.constraints[ci];ci+=1;ids.append(vi);selectors.append({'parts':[a,b],'bin':ordinal,'variable':vi,'relative_y_units1000':[low,high]});vi+=1
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1]);assert c==m.constraints[ci];ci+=1
    for r in rows:
        pa,pb=r['profiles'];c=cp_model_pb2.ConstraintProto();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[r['bin']]]);c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([r['minimum_dx_units1000'],2**63-1]);assert c==m.constraints[ci];ci+=1;constraints.append({'parts':[a,b],'profiles':[pa,pb],'bin':r['bin'],'minimum_dx_units1000':r['minimum_dx_units1000']})
assert vi==len(m.variables)==233773 and ci==len(m.constraints)==253589 and selectors==load(BASE/'relative-y-selectors.json') and constraints==load(BASE/'relative-y-constraints.json')
expected={**load(PARENT/'inventory.json')[0],'variables':vi,'constraints':ci,'model_sha256':digest(BASE/'models/000.pb'),'relative_y_bin_selectors':210,'relative_y_bin_equalities':6,'relative_y_spacing_constraints':13146};assert load(BASE/'inventory.json')==[expected]
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb')) and proto(OUT/'roundtrip.pb')==m
write(OUT/'extension-proof.json',{'equivalent_source_coordinate_feasibility':True,'exact_parent_restoration':True,'statement':'Each parent integer cog pair difference belongs to exactly one complete relative-Y bin. Assign its flag1, all other flags0. Its chosen profiles further restrict the difference to the clipped interval certified by the independent whole forbidden-rectangle check. Cog x ordering and integer coordinates force the corresponding separation. Thus all new constraints hold for every parent source witness, and every new witness projects to the unchanged parent. No coordinates, source choices or profile counts are fixed. The prior UNKNOWN remains inconclusive.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'exact_parent_restoration':True,'relative_y_bins_per_pair':35,'relative_y_selectors':210,'relative_y_exact_one_equalities':6,'relative_y_spacing_constraints':13146,'source_rectangles_verified':len(rows),'all_original_coordinate_choices_preserved':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
