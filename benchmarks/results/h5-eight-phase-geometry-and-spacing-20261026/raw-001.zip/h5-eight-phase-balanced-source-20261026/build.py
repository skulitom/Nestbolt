"""Full guarded source for one orientation-type pattern with all mirror choices."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import product,combinations
import json,math,shutil,time
from shapely.geometry import MultiPoint,shape,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities
ROOT=Path(__file__).resolve().parents[1];PROFILES=ROOT/'output/h5-eight-phase-cog-screen-20261026';OLD=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';OUT=ROOT/'output/h5-eight-phase-balanced-source-20261026';EPS=.000001
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'mutual').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240;assert load(PROFILES/'audit-verified/checks.json')['passed'];profiles=load(PROFILES/'profiles.json');spec=load(ROOT/'output/h5-aligned-cog-profiles-20261026/plan.json');ids=spec['mandatory_second_sheet_originals'];items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');allowed=[[0,4],[2,6],[1,7],[3,5],[8,10]]+[[9,11,12,13,14,15,16,17]]*4;keys=sorted({(pa,pb) for a,b in combinations(range(9),2) for pa,pb in product(allowed[a],allowed[b])});assert len(keys)==184
reusable={};parent=ROOT/'output/h5-balanced-phase-choice-source-20261026'
assert load(parent/'audit/checks.json')['passed']
old_profiles=load(parent/'profiles.json');assert profiles[:12]==old_profiles
inputs=[PROFILES/'profiles.json',PROFILES/'plan.json',PROFILES/'audit-verified/checks.json',parent/'plan.json',parent/'profiles.json',parent/'audit/checks.json',ROOT/'output/h5-aligned-cog-profiles-20261026/plan.json',ROOT/'output/h5-source-orientation-construction-20261025/items.json',ROOT/'output/h5-source-orientation-construction-20261025/geometry.json',ROOT/'output/h5-eight-phase-band-search-20261026/audit/checks.json',ROOT/'output/h5-eight-phase-band-search-20261026/allocation.json']
assert load(inputs[-2])['passed'];allocation=load(inputs[-1]);totals={p:sum(r['count'] for r in allocation if r['profile']==p) for p in range(18)}
assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5])==(1,1,1,1) and sum(totals[p] for p in range(12,18))>=1
for c in load(parent/'plan.json')['mutual_cases']:
    key=(c['profile_a'],c['profile_b'])
    if key in keys:
        assert all(profiles[pi]==old_profiles[pi] for pi in key)
        reusable[key]=(parent/'mutual'/f"{c['index']:03d}.json",c)
inputs.extend(p for p,c in reusable.values());stock=spec['stock_bounds_rational'];st=[F(*v) for v in stock];pad=F(.0125)+F(EPS);bounds={}
for pi in sorted({p for options in allowed for p in options}):
    b=profiles[pi]['bounds'];bounds[pi]=[math.ceil((st[0]+pad-F(b[0]))*1000),math.ceil((st[1]+pad-F(b[1]))*1000),math.floor((st[2]-pad-F(b[2]))*1000),math.floor((st[3]-pad-F(b[3]))*1000)]
cases=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(keys)];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'parts':[{'part':i,'item':n,'family':items[n]['family'],'copy':items[n]['copy']} for i,n in enumerate(ids)],'allowed_profiles':allowed,'used_profiles':sorted(bounds),'anchor_bounds_units1000':bounds,'stock_bounds_rational':stock,'mutual_cases':cases,'first_sheet_checked_originals':spec['first_sheet_checked_originals'],'pending_first_sheet_originals':[28,29],'profile_count_groups':[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[1,7],'count':1},{'profiles':[3,5],'count':1},{'profiles':[8,10],'count':1},{'profiles':[9,11,12,13,14,15,16,17],'count':4}],'minimum_new_phase_cogs':1,'new_cog_profiles':[12,13,14,15,16,17],'construction_limit_seconds':240,'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Broaden the selected bracket orientation types to all mirror alternatives: one bracket each from0/4,2/6,1/7,3/5. The insert chooses8/10 and every cog independently chooses one of eight sampled angles56.25..72degrees, with at least one new profile12..17. All18 coordinates free in native-guarded short stock, no fixed cell/hint. Include all744 physical orientation modes across36 pairs. Reuse only matching original-profile collision cases; independently reconstruct all184 cases. Share identical plane literals and add independently verified band-cell links and cog-spacing implications before the only45second4worker seed0 call within60shared seconds. No unstrengthened model is called. Any negative is conditional on these profile-count groups, declared eight allowed cog angles with at least one new-phase cog, source guard and integer grid. All66 originals remain required.'});write(OUT/'profiles.json',profiles);summary=[]
for c in cases:
    assert time.perf_counter()<deadline;key=(c['profile_a'],c['profile_b'])
    if key in reusable:
        p,oldc=reusable[key];r=load(p);r['reused_source_case']=r['case'];r['case']=c;r['reused_source_sha256']=digest(p);r['reused_source_path']=p.relative_to(ROOT).as_posix();summary.append({**c,'reused':True,'faces':len(r['faces'])})
    else:
        a,b=[shape(profiles[k]['geometry']) for k in key];raw=raw_obstacle(a,b);guarded=expand(raw,.2125,.0001);faces,merge=convex_faces(guarded,deadline);records=[];expanded=[]
        for i,f in enumerate(faces):
            poly=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(list(f.exterior.coords)[:-1],[(-EPS,-EPS),(-EPS,EPS),(EPS,EPS),(EPS,-EPS)])]).convex_hull,sign=1);assert poly.covers(f);expanded.append(poly);records.append({'index':i,'raw_face':mapping(f),'expanded_face':mapping(poly),'outside_halfplanes':inequalities(poly,False)})
        assert unary_union(expanded).covers(guarded);r={'case':c,'raw_forbidden':mapping(raw),'expanded_forbidden':mapping(guarded),'merge':merge,'faces':records,'complete_forbidden_covered':True};summary.append({**c,'reused':False,'faces':len(records),**merge})
    assert r['complete_forbidden_covered'];write(OUT/'mutual'/f"{c['index']:03d}.json",r)
    if len(summary)%24==0:print({'geometry_cases':len(summary),'of':184,'seconds':time.perf_counter()-start},flush=True)
write(OUT/'case-summary.json',summary);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'mandatory_originals':9,'pair_cases':184,'cases_reused':sum(r['reused'] for r in summary),'cases_new':sum(not r['reused'] for r in summary),'guarded_faces':sum(r['faces'] for r in summary),'physical_pairs':36,'orientation_pair_modes':744,'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
