"""Full independent reconstruction of the necessary band model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-phase-band-model-20261026';SOURCE=ROOT/'output/h5-eight-phase-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Reconstruct every aggregate count variable, original-family domains and precise cell mappings directly from independently audited coefficients. Rebuild all three mandatory count equalities and63 band inequalities, add the complete sum for new profiles12..17 constrained to1..4 (at least one new-phase cog), require whole-proto equality with no extra fields, and check actual solver import/export. No solving.'})
for path in [BASE/'plan.json',SOURCE/'audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');expected=cp_model_pb2.CpModelProto();mapping=[]
for pi in range(18):
    data=load(SOURCE/'profiles'/f'{pi:03d}.json')
    for cell in data['cells']:
        i=len(expected.variables);expected.variables.add(name=f'p{pi}-cell{cell["index"]}',domain=[0,{'bracket':4,'insert':1,'cog':4}[data['family']]]);mapping.append({'variable':i,'profile':pi,'family':data['family'],'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
assert mapping==load(BASE/'mapping.json')
for family,count in [('bracket',4),('insert',1),('cog',4)]:
    c=expected.constraints.add();ids=[r['variable'] for r in mapping if r['family']==family];c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([count,count])
for band,cap in enumerate(load(SOURCE/'band-capacities.json')):
    c=expected.constraints.add();rows=[r for r in mapping if r['demands'][band]>0];c.linear.vars.extend(r['variable'] for r in rows);c.linear.coeffs.extend(r['demands'][band] for r in rows);c.linear.domain.extend([-2**63,cap])
c=expected.constraints.add();ids=[r['variable'] for r in mapping if r['profile']>=12];c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,4]);assert len(ids)==sum(len(load(SOURCE/'profiles'/f'{pi:03d}.json')['cells']) for pi in range(12,18))
model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes());assert model==expected and len(model.variables)==len(mapping) and len(model.constraints)==67;real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==model
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(mapping),'constraints':67,'original_family_count_equalities':3,'verified_band_inequalities':63,'new_phase_count_constraint_verified':True,'whole_model_reconstructed':True,'actual_import_export_verified':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
