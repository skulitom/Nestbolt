"""Create bounded eight-phase original-geometry screen and independent audit."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def replace(s,old,new):
    assert old in s,old
    return s.replace(old,new)

s=(ROOT/'output/screen_h5_mixed_cog_angles.py').read_text(encoding='utf-8')
s=replace(s,'Screen original cog pairs at two tooth phases','Screen original cog pairs at eight tooth phases')
s=replace(s,"PARENT=ROOT/'output/h5-aligned-cog-profiles-20261026'","PARENT=ROOT/'output/h5-mixed-cog-angle-screen-20261026'")
s=replace(s,"OUT=ROOT/'output/h5-mixed-cog-angle-screen-20261026'","OUT=ROOT/'output/h5-eight-phase-cog-screen-20261026'")
s=replace(s,'Polygon,LineString,shape,mapping','Polygon,LineString,box,shape,mapping')
begin=s.index('theta=old[');end=s.index('spec=load(PARENT/',begin)
s=s[:begin]+'''assert len(profiles)==12
cog_profiles=[9,12,13,14,11,15,16,17]
for k in [1,2,3,5,6,7]:
    theta=old['rotation_radians']+k*math.pi/80;co,si=math.cos(theta),math.sin(theta)
    rotated=[((x-cx)*co-(y-cy)*si,(x-cx)*si+(y-cy)*co) for x,y in pts]
    poly=Polygon(rotated);assert poly.is_valid
    profiles.append({**old,'index':len(profiles),'rotation_radians':theta,'rotation_hex':theta.hex(),'vertices':rotated,'bounds':list(poly.bounds),'geometry':mapping(poly)})
assert len(profiles)==18 and all(abs(profiles[pi]['rotation_radians']-(old['rotation_radians']+k*math.pi/80))<1e-15 for k,pi in enumerate(cog_profiles))
'''+s[end:]
s=replace(s,'for pi in [9,11]:','for pi in cog_profiles:')
s=replace(s,"ROOT/'output/h5-balanced-union-search-20261026/audit/checks.json',ROOT/'benchmarks/results/h5-aligned-profile-family-exclusions-20261026/checks.json'","ROOT/'output/h5-repeated-phase-exclusion-search-20261026/audit/checks.json',ROOT/'benchmarks/results/h5-two-phase-band-and-spacing-exclusions-20261026/checks.json'")
s=replace(s,"'cog_profiles':[9,11],'angles_degrees':[math.degrees(old['rotation_radians']),math.degrees(theta)]","'cog_profiles':cog_profiles,'angles_degrees':[math.degrees(profiles[pi]['rotation_radians']) for pi in cog_profiles]")
s=replace(s,"'half_tooth_radians':math.pi/20","'sample_step_radians':math.pi/80")
a=s.index("'method':'Check the actual");b=s.index("'})",a)
s=s[:a]+"""'method':'Check the actual80-vertex original and20 tooth pitches. Preserve all12 parent profiles byte-for-value and append six full-original rotations to sample the18degree tooth period every2.25degrees. Build all64 ordered cog collision envelopes with circumscribed128-gon clearance .2126mm. For the full stock-relative Y interval inspect boundary vertex heights and endpoints to select a compact grid pair; independently check its original outlines. Separately prove the complete nonnegative-X rectangle below an integer minimum spacing lies strictly inside the guarded forbidden region. That whole-rectangle containment, not the numeric boundary screen, establishes the spacing implication. No old two-angle conditional exclusion transfers to this changed angle set. This finite-angle screen has no solver call, no continuous-angle theorem and no full66-original acceptance claim.'"""+s[b:]
s=replace(s,'product([9,11],repeat=2)','product(cog_profiles,repeat=2)')
s=replace(s,"name=f'{pa:03d}-{pb:03d}';write", "D=math.floor(min(r['rightmost_forbidden_dx_mm'] for r in rows)*1000);rect=box(0,dylo/1000,(D-1)/1000,dyhi/1000);margin=guarded.boundary.distance(rect)\n    assert D>0 and guarded.contains(rect) and margin>1e-8\n    name=f'{pa:03d}-{pb:03d}';write")
s=replace(s,"'profiles':[pa,pb],'raw_forbidden'","'profiles':[pa,pb],'minimum_integer_dx_units1000':D,'forbidden_rectangle':mapping(rect),'rectangle_boundary_gap_mm':margin,'raw_forbidden'")
s=replace(s,"summaries.append({'profiles':[pa,pb]","summaries.append({'minimum_integer_dx_units1000':D,'rectangle_boundary_gap_mm':margin,'profiles':[pa,pb]")
s=replace(s,"'original_gap_mm':gap})","'original_gap_mm':gap})\n    print({'case':len(summaries),'of':64,'profiles':[pa,pb],'span_mm':bp.bounds[2]-ap.bounds[0],'seconds':time.perf_counter()-start},flush=True)")
s=replace(s,"'half_tooth_degrees':9.","'sample_step_degrees':2.25")
s=replace(s,"'parent_profiles_unchanged':11,'new_angle_degrees':math.degrees(theta),'new_width_mm':poly.bounds[2]-poly.bounds[0],'new_height_mm':poly.bounds[3]-poly.bounds[1],'ordered_pair_cases':4","'parent_profiles_unchanged':12,'new_profiles':6,'angles_degrees':[math.degrees(profiles[pi]['rotation_radians']) for pi in cog_profiles],'ordered_pair_cases':64,'whole_forbidden_rectangles':64,'minimum_rectangle_margin_mm':min(r['rectangle_boundary_gap_mm'] for r in summaries),'construction_budget_honored':time.perf_counter()<deadline")
s=replace(s,"print(load(OUT/'result.json'));print(summaries)","print(load(OUT/'result.json'),flush=True)")
with (ROOT/'output/screen_h5_eight_phase_cogs.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)

s=(ROOT/'output/audit_h5_mixed_cog_angle_screen.py').read_text(encoding='utf-8')
s=replace(s,"BASE=ROOT/'output/h5-mixed-cog-angle-screen-20261026'","BASE=ROOT/'output/h5-eight-phase-cog-screen-20261026'")
s=replace(s,'LineString,Point,shape','LineString,Point,box,shape')
s=replace(s,"start=time.perf_counter()","start=time.perf_counter();deadline=start+240")
s=replace(s,"'method':'Reconstruct all12","'audit_limit_seconds':240,'method':'Reconstruct all18")
s=replace(s,'including all source cutouts, using affine transforms. Check the20 repeated tooth patterns and half-pitch9degree rotation. For all four ordered cog choices','including all source cutouts, using affine transforms. Check20 repeated tooth patterns and the full period sampled every2.25degrees. For all64 ordered cog choices')
s=replace(s,'This is a numeric two-part screen, not an unrestricted packing exclusion or a full66-original validator call.','Additionally check strict containment of every full-height forbidden spacing rectangle, and independently derive its integer bound. This is a numeric two-part screen plus guarded-geometry spacing implications, not an unrestricted packing exclusion or a full66-original validator call.')
s=replace(s,"parent=load(ROOT/'output/h5-aligned-cog-profiles-20261026/profiles.json');assert len(profiles)==12 and profiles[:11]==parent","parent=load(ROOT/'output/h5-mixed-cog-angle-screen-20261026/profiles.json');assert len(profiles)==18 and profiles[:12]==parent")
s=replace(s,"job=load(JOB);families=", "cog_profiles=[9,12,13,14,11,15,16,17];assert s['cog_profiles']==cog_profiles and len(set(cog_profiles))==8\nfor k,pi in enumerate(cog_profiles):assert abs(profiles[pi]['rotation_radians']-(profiles[9]['rotation_radians']+k*math.pi/80))<1e-15\njob=load(JOB);families=")
s=replace(s,'for pi in [9,11]','for pi in cog_profiles')
s=replace(s,'product([9,11],repeat=2)','product(cog_profiles,repeat=2)')
s=replace(s,"    r=load(BASE/'pairs'", "    assert time.perf_counter()<deadline\n    r=load(BASE/'pairs'")
s=replace(s,"    checks.append({'profiles':[pa,pb]", "    D=math.floor(min(row['rightmost_forbidden_dx_mm'] for row in r['boundary_samples'])*1000);rect=box(0,lo/1000,(D-1)/1000,hi/1000);margin=guard.boundary.distance(rect)\n    assert D==r['minimum_integer_dx_units1000'] and rect.equals(shape(r['forbidden_rectangle'])) and guard.contains(rect) and margin>1e-8 and abs(margin-r['rectangle_boundary_gap_mm'])<1e-10\n    checks.append({'minimum_integer_dx_units1000':D,'rectangle_boundary_gap_mm':margin,'profiles':[pa,pb]")
s=replace(s,"'passed':True})\nwrite(OUT/'pair-checks.json'","'passed':True})\n    if len(checks)%8==0:print({'audited_pairs':len(checks),'seconds':time.perf_counter()-start},flush=True)\nwrite(OUT/'pair-checks.json'")
s=replace(s,"'profiles_reconstructed':12,'unchanged_parent_profiles':11","'profiles_reconstructed':18,'unchanged_parent_profiles':12")
s=replace(s,"'half_tooth_degrees':9,'ordered_collision_regions_reconstructed':4","'sample_step_degrees':2.25,'ordered_collision_regions_reconstructed':64,'full_height_forbidden_rectangles_checked':64,'minimum_rectangle_margin_mm':min(r['rectangle_boundary_gap_mm'] for r in checks),'audit_budget_honored':time.perf_counter()<deadline")
s=replace(s,"'grid_original_pairs_checked':4,'original_cutouts_preserved':8,'original_hole_vertices_preserved':1600","'grid_original_pairs_checked':64,'original_cutouts_preserved':128,'original_hole_vertices_preserved':25600")
with (ROOT/'output/audit_h5_eight_phase_cog_screen.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':2,'solver_calls':0})
