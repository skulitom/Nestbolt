"""Preserve and repair a generated quote before any geometry or solver work."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import ast,json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-eight-phase-screen-preflight-20261026';OUT.mkdir()
target=ROOT/'output/screen_h5_eight_phase_cogs.py'
for name in ['screen_h5_eight_phase_cogs.py','make_h5_eight_phase_screen_helpers.py']:
    shutil.copyfile(ROOT/'output'/name,OUT/name)
shutil.copyfile(__file__,OUT/'repair.py')
source=target.read_text(encoding='utf-8')
try:ast.parse(source)
except SyntaxError as e:failure={'type':'SyntaxError','message':e.msg,'line':e.lineno}
else:raise AssertionError('expected saved syntax failure')
assert not (ROOT/'output/h5-eight-phase-cog-screen-20261026').exists()
old="acceptance claim.''})";new="acceptance claim.'})";assert source.count(old)==1
fixed=source.replace(old,new);ast.parse(fixed)
ast.parse((ROOT/'output/audit_h5_eight_phase_cog_screen.py').read_text(encoding='utf-8'))
target.write_text(fixed,encoding='utf-8',newline='\n')
record={'utc':datetime.now(timezone.utc).isoformat(),'failure':failure,'cause':'Generator retained both its replacement closing quote and the original closing quote.','repair':'Remove only the duplicate quote; parse both generated helpers before execution.','original_sha256':sha256(source.encode()).hexdigest(),'repaired_sha256':sha256(target.read_bytes()).hexdigest(),'failed_geometry_calls':0,'solver_calls':0,'original_evidence_preserved':True}
with (OUT/'recovery.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
