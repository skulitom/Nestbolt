"""Retain the interrupted audit and run a separately named corrected audit."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-eight-phase-screen-preflight-20261026'
source=ROOT/'output/audit_h5_eight_phase_cog_screen.py';text=source.read_text(encoding='utf-8')
shutil.copyfile(source,OUT/'failed-audit.py');shutil.copyfile(__file__,OUT/'repair-audit.py')
assert "Point,box,shape" in text and "rect=box(" in text and "OUT=BASE/'audit'" in text
text=text.replace('Point,box,shape','Point,box as geometry_box,shape').replace('rect=box(','rect=geometry_box(').replace("OUT=BASE/'audit'","OUT=BASE/'audit-verified'")
ast.parse(text)
with (ROOT/'output/audit_h5_eight_phase_cog_screen_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
record={'utc':datetime.now(timezone.utc).isoformat(),'failure':'TypeError: list object is not callable at line81 of the first audit','cause':'The existing stock-bounds loop variable box shadows the newly imported rectangle constructor.','repair':'Alias the constructor as geometry_box and rerun the independent audit from scratch into audit-verified. Preserve the original partial audit and all geometry.','failed_audit_completed_cases':0,'solver_calls':0,'geometry_unchanged':True}
with (OUT/'audit-recovery.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
