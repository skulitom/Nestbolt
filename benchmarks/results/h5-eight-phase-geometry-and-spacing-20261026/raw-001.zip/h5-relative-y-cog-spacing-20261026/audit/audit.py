"""Independently check every relative-Y cell, boundary minimum and entire rectangle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import LineString,box,shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-relative-y-cog-spacing-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
def rightmost(g,y):
    values=[]
    for ring in rings(g):
        xy=list(ring.coords)
        for (x0,y0),(x1,y1) in zip(xy,xy[1:]):
            if y0==y1:
                if y==y0:values.extend([x0,x1])
            elif min(y0,y1)<=y<=max(y0,y1):values.append(x0+(x1-x0)*(y-y0)/(y1-y0))
    assert values;return max(values)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'audit_limit_seconds':240,'method':'Derive full global relative-Y and every profile-pair interval directly from source stock bounds. Reconstruct the disjoint complete2mm integer bins; verify every clipped pair/bin and no omissions. Analytic line-segment interpolation independently checks each boundary sample and integer threshold. Independently construct the entire forbidden rectangle and require strict containment in the actual source obstacle already covered by audited source faces. This whole-domain geometric check, not sampled minima alone, proves each implication. No solver.'})
s=load(BASE/'plan.json')
for n,h in s['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];source=load(SOURCE/'plan.json');phases=source['allowed_profiles'][5];assert source['allowed_profiles'][5:]==[phases]*4 and phases==s['phases'];bounds=source['anchor_bounds_units1000'];low=min(bounds[str(p)][1] for p in phases);high=max(bounds[str(p)][3] for p in phases);lo,hi=low-high,high-low;bins=[[a,min(a+1999,hi)] for a in range(lo,hi+1,2000)];assert s['global_relative_y_units1000']==[lo,hi] and s['bins_units1000']==bins
rows=load(BASE/'bounds.json');seen=set();covered=samples=0;checks=[];uniform={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in load(SOURCE/'audit/spacing-case-checks.json')};stronger=0;max_gain=0
for pa,pb in product(phases,repeat=2):
    assert time.perf_counter()<deadline
    case=next(c['index'] for c in source['mutual_cases'] if [c['profile_a'],c['profile_b']]==[pa,pb]);g=shape(load(SOURCE/'mutual'/f'{case:03d}.json')['expanded_forbidden']);aa,bb=bounds[str(pa)],bounds[str(pb)];pairlo,pairhi=bb[1]-aa[3],bb[3]-aa[1];following=pairlo
    for ordinal,(a,b) in enumerate(bins):
        a,b=max(a,pairlo),min(b,pairhi)
        if a>b:continue
        matching=[r for r in rows if r['profiles']==[pa,pb] and r['bin']==ordinal];assert len(matching)==1;r=matching[0];assert r['source_case']==case and r['relative_y_units1000']==[a,b] and a==following;following=b+1;covered+=b-a+1;seen.add((pa,pb,ordinal))
        ys=sorted({a/1000,b/1000}|{y for ring in rings(g) for x,y in ring.coords if a/1000<y<b/1000});assert ys==[row[0] for row in r['samples']]
        for y,x in r['samples']:assert abs(rightmost(g,y)-x)<1e-7;samples+=1
        D=math.floor(min(x for y,x in r['samples'])*1000);assert D==r['minimum_dx_units1000'] and D>=uniform[pa,pb]
        rectangle=box(0,a/1000,(D-1)/1000,b/1000) if a<b else LineString([(0,a/1000),((D-1)/1000,b/1000)]);margin=g.boundary.distance(rectangle)
        assert rectangle.equals(shape(r['forbidden_rectangle'])) and g.contains(rectangle) and margin>1e-8 and abs(margin-r['boundary_margin_mm'])<1e-10
        gain=D-uniform[pa,pb];stronger+=gain>0;max_gain=max(max_gain,gain);checks.append({'profiles':[pa,pb],'bin':ordinal,'minimum_dx_units1000':D,'rectangle_margin_mm':margin,'passed':True})
    assert following==pairhi+1
assert len(seen)==len(rows)==len(checks)
write(OUT/'case-checks.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'relative_y_bins':len(bins),'whole_rectangles_verified':len(checks),'pair_relative_y_integer_values_covered':covered,'analytic_boundary_samples_checked':samples,'stronger_than_uniform_bounds':stronger,'maximum_spacing_gain_mm':max_gain/1000,'minimum_rectangle_margin_mm':min(r['rectangle_margin_mm'] for r in checks),'all_source_relative_y_values_preserved':True,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
