"""Certify cog spacing separately for every complete 2 mm relative-Y bin."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import LineString,box,shape,mapping
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=ROOT/'output/h5-relative-y-cog-spacing-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');phases=spec['allowed_profiles'][5];assert spec['allowed_profiles'][5:]==[phases]*4
bounds=spec['anchor_bounds_units1000'];low=min(bounds[str(p)][1] for p in phases);high=max(bounds[str(p)][3] for p in phases);lo,hi=low-high,high-low;bins=[[i,min(i+1999,hi)] for i in range(lo,hi+1,2000)]
cases=[c for c in spec['mutual_cases'] if c['profile_a'] in phases and c['profile_b'] in phases];assert len(cases)==64
paths=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',SOURCE/'audit/spacing-case-checks.json']+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in cases]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'phases':phases,'global_relative_y_units1000':[lo,hi],'bins_units1000':bins,'construction_limit_seconds':240,'method':'Cover the entire integer relative-Y domain in disjoint2mm bins. For each ordered cog phase pair intersect each bin with its complete source stock-relative Y interval. Screen the rightmost guarded boundary at every vertex height and endpoint, set D=floor(minimumX*1000), then prove the entire rectangle X=0..(D-1)/1000 and the whole clipped continuous-Y interval strictly inside this actual source guarded obstacle. The whole-rectangle containment proves every integer source deltaX>=D when that phase pair and relative bin are selected. Existing full source geometry and face-coverage audit remains required. No solver or source restriction; prior UNKNOWN remains closed.'})
rows=[]
for c in cases:
    assert time.perf_counter()<deadline
    pa,pb=c['profile_a'],c['profile_b'];aa,bb=bounds[str(pa)],bounds[str(pb)];pairlo,pairhi=bb[1]-aa[3],bb[3]-aa[1];g=shape(load(SOURCE/'mutual'/f"{c['index']:03d}.json")['expanded_forbidden']);vertices=[y for ring in rings(g) for x,y in ring.coords]
    for ordinal,(a,b) in enumerate(bins):
        a,b=max(a,pairlo),min(b,pairhi)
        if a>b:continue
        ys=sorted({a/1000,b/1000}|{y for y in vertices if a/1000<y<b/1000});samples=[]
        for y in ys:
            cut=g.intersection(LineString([(-1000,y),(1000,y)]));assert not cut.is_empty;samples.append([y,cut.bounds[2]])
        D=math.floor(min(x for y,x in samples)*1000);rectangle=box(0,a/1000,(D-1)/1000,b/1000) if a<b else LineString([(0,a/1000),((D-1)/1000,b/1000)]);margin=g.boundary.distance(rectangle)
        assert D>0 and g.contains(rectangle) and margin>1e-8
        rows.append({'profiles':[pa,pb],'source_case':c['index'],'bin':ordinal,'relative_y_units1000':[a,b],'samples':samples,'minimum_dx_units1000':D,'forbidden_rectangle':mapping(rectangle),'boundary_margin_mm':margin})
write(OUT/'bounds.json',rows);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'phases':len(phases),'ordered_pairs':64,'relative_y_bins':len(bins),'certified_rectangles':len(rows),'minimum_spacing_mm':min(r['minimum_dx_units1000'] for r in rows)/1000,'maximum_spacing_mm':max(r['minimum_dx_units1000'] for r in rows)/1000,'minimum_rectangle_margin_mm':min(r['boundary_margin_mm'] for r in rows),'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
