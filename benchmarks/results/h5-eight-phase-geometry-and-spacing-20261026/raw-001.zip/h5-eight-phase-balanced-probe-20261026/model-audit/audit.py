"""Independent reconstruction of all source modes and shared plane clauses."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-phase-balanced-probe-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'model-audit'
DATA=ROOT/'output/h5-eight-phase-band-capacity-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct all coordinate/profile variables and stock/count constraints. Distinct bracket type slots are unordered. All four cog copies have identical eight-angle choices, so x sorting relabels their phase choices too. Verify all97920 phase/order combinations with at least one new profile12..17, without a separate phase order; reconstruct the at-least-one-new-profile constraint. For every one of744 modes, evaluate each source halfplane at four difference-box corners, account for every face, and independently reconstruct each shared plane by serialized complete linear fields. Rebuild every mode OR including its exact inactive-profile escape literals. Coordinate equivalence follows by setting shared literals from plane truth; all true shared flags imply the same original source planes. Independently reconstruct all1716 cell variables and interval implications,42 profile sums,63 exact band inequalities and390 source-proven cog spacing implications. Verify full stock-Y coverage, every coefficient and source-specific full-height rectangle proof. Require exact full proto fields and solver import/export; no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];bounds=s['anchor_bounds_units1000'];m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};vi=ci=0
def var(name,dom):
    global vi
    assert m.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=dom);vi+=1
def linear(terms,lo,hi,enforce=()):
    global ci
    c=cp_model_pb2.ConstraintProto();ids=sorted(v for v,k in terms.items() if k);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce);assert c==m.constraints[ci],ci;ci+=1
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in options),max(bounds[str(p)][axis+2] for p in options)])
flags={}
for i in range(9):
    flags[i]={}
    for p in allowed[i]:flags[i][p]=vi;var(f'p{i}-profile{p}',[0,1])
assert {str(i):{str(p):v for p,v in choices.items()} for i,choices in flags.items()}==load(BASE/'profile-flags.json')
for i in range(9):
    linear(dict.fromkeys(flags[i].values(),1),1,1)
    for p,v in flags[i].items():
        b=bounds[str(p)]
        for axis in range(2):linear({2*i+axis:1},b[axis],b[axis+2],[v])
for i in range(5,8):linear({2*i:1,2*(i+1):-1},-2**63,0)
linear({flags[i][pi]:1 for i in range(5,9) for pi in range(12,18)},1,4)
assert vi==60 and ci==97;assert len({p['copy'] for p in s['parts'][:4]})==4 and len({p['copy'] for p in s['parts'][5:]})==4 and all(p['family']=='bracket' for p in s['parts'][:4]) and all(p['family']=='cog' for p in s['parts'][5:]);data={(c['profile_a'],c['profile_b']):load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in s['mutual_cases']};unique={};rows=[];clauses=[];maps=[];taut=uses=0
for a,b in combinations(range(9),2):
    for pa,pb in product(allowed[a],allowed[b]):
        aa,bb=bounds[str(pa)],bounds[str(pb)];d=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];corners=list(product([d[0],d[2]],[d[1],d[3]]));active=[flags[a][pa],flags[b][pb]];fs=[]
        for face in data[pa,pb]['faces']:
            hs=face['outside_halfplanes'];values=[[h['a']*x+h['b']*y for x,y in corners] for h in hs]
            if any(min(v)>=h['bound'] for h,v in zip(hs,values)):fs.append({'face':face['index'],'tautological':True});taut+=1;continue
            live=[j for j,(h,v) in enumerate(zip(hs,values)) if max(v)>=h['bound']];efs=[]
            for j in live:
                h=hs[j];terms={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};ids=sorted(v for v,k in terms.items() if k);p=cp_model_pb2.LinearConstraintProto(vars=ids,coeffs=[terms[v] for v in ids],domain=[h['bound'],2**63-1]);key=p.SerializeToString()
                if key not in unique:
                    v=vi;unique[key]=v;var(f'pair-plane-{v}',[0,1]);linear(terms,h['bound'],2**63-1,[v]);rows.append({'flag':v,'parts':[a,b],'a':h['a'],'b':h['b'],'bound':h['bound']})
                efs.append(unique[key]);uses+=1
            clauses.append([-v-1 for v in active]+efs);fs.append({'face':face['index'],'live_edges':live,'shared_flags':efs})
        maps.append({'parts':[a,b],'profiles':[pa,pb],'active':active,'difference_bounds':d,'faces':fs})
for lits in clauses:
    c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend(lits);assert c==m.constraints[ci];ci+=1
assert len(maps)==744 and maps==load(BASE/'models/000-mapping.json') and rows==load(BASE/'shared-planes.json');r=load(BASE/'inventory.json')[0];assert r['shared_planes']==len(unique) and r['edge_uses']==uses and r['face_clauses']==len(clauses) and r['tautological_faces']==taut and r['parts']==list(range(9)) and r['originals']==[p['item'] for p in s['parts']] and r['solver_seconds']==45 and digest(BASE/'models/000.pb')==r['model_sha256']
base_nv,base_nc=vi,ci
assert load(DATA/'audit/checks.json')['passed'] and s['stock_bounds_rational']==load(DATA/'plan.json')['stock_bounds_rational']
selectors=[];groups=[];covered_values=0
for part,options in enumerate(allowed):
    for pi in options:
        datum=load(DATA/'profiles'/f'{pi:03d}.json');lo,hi=bounds[str(pi)][1::2];assert datum['y_bounds_units1000']==[lo,hi];following=lo;ids=[]
        for ordinal,cell in enumerate(datum['cells']):
            a,b=cell['y_bounds_units1000'];assert cell['index']==ordinal and a==following and b==min(a+999,hi);following=b+1;covered_values+=b-a+1
            v=vi;var(f'p{part}-profile{pi}-cell{ordinal}',[0,1]);linear({2*part+1:1},a,b,[v]);ids.append(v)
            selectors.append({'variable':v,'part':part,'profile':pi,'cell':ordinal,'y_bounds_units1000':[a,b],'demands':cell['band_lower_area_units']})
        assert following==hi+1;groups.append({'part':part,'profile':pi,'profile_flag':flags[part][pi],'cell_flags':ids})
for group in groups:
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([group['profile_flag']]+group['cell_flags']);c.linear.coeffs.extend([-1]+[1]*len(group['cell_flags']));c.linear.domain.extend([0,0]);assert c==m.constraints[ci];ci+=1
caps=load(DATA/'band-capacities.json');assert len(caps)==63
for band,cap in enumerate(caps):
    selected=[r for r in selectors if r['demands'][band]>0];c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(r['variable'] for r in selected);c.linear.coeffs.extend(r['demands'][band] for r in selected);c.linear.domain.extend([-2**63,cap]);assert c==m.constraints[ci];ci+=1
spacing=load(SOURCE/'audit/spacing-case-checks.json');lower={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in spacing};assert set(lower)==set(product([9,11,12,13,14,15,16,17],repeat=2)) and all(r['passed'] and r['source_rectangle_margin_mm']>1e-8 for r in spacing);common=min(lower.values());added=[]
for a,b in combinations(range(5,9),2):
    for pair,minimum in [(None,common)]+[(list(key),lower[key]) for key in product(allowed[a],allowed[b])]:
        c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([minimum,2**63-1])
        if pair:c.enforcement_literal.extend([flags[a][pair[0]],flags[b][pair[1]]])
        assert c==m.constraints[ci];ci+=1;added.append({'parts':[a,b],'profiles':pair,'minimum_dx_units1000':minimum})
assert selectors==load(BASE/'cell-selectors.json') and groups==load(BASE/'cell-groups.json') and added==load(BASE/'spacing-constraints.json')
assert len(selectors)==1716 and len(groups)==42 and len(added)==390 and vi==len(m.variables)==r['variables'] and ci==len(m.constraints)==r['constraints']
assert load(BASE/'strengthening.json')=={'base_variables':base_nv,'base_constraints':base_nc,'cell_selectors':1716,'profile_cell_equalities':42,'band_inequalities':63,'spacing_constraints':390,'base_model_called':False}
write(OUT/'source-extension-proof.json',{'equivalent_source_coordinate_feasibility':True,'statement':'A source placement selects exactly one original profile per copy and a unique integer-Y cell. Assign precisely those cell flags. Complete source faces enforce disjoint filled outers inside stock, so the independently verified per-cell band minima obey every capacity. All cog copies have identical angle sets and stock domains and can be relabelled with their profiles in x order. For each ordered profile pair, the source-specific whole forbidden rectangle contains every nonnegative integer deltaX below the threshold at every allowed relative Y, hence each spacing bound follows from the original clauses. Every coordinate/profile witness extends to these flags; conversely every new witness satisfies all original stock and collision clauses. No prior profile-count exclusion is transferred.','no_full66_layout_claim':True})
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
assert allowed[5:]==[[9,11,12,13,14,15,16,17]]*4 and s['minimum_new_phase_cogs']==1
symmetry_cases=0
for chosen in product([9,11,12,13,14,15,16,17],repeat=4):
    if not any(p>=12 for p in chosen):continue
    for ranks in permutations(range(4)):
        order=sorted(range(4),key=lambda i:ranks[i]);assigned=[chosen[i] for i in order]
        assert sorted(ranks[i] for i in order)==list(range(4)) and sorted(assigned)==sorted(chosen) and all(p in allowed[5+i] for i,p in enumerate(assigned));symmetry_cases+=1
assert symmetry_cases==97920
write(OUT/'cog-order-proof.json',{'cases_checked':symmetry_cases,'statement':'All four original cog copies have identical allowed choices and identical stock bounds for each choice. Sort by x and relabel each copy together with its chosen phase. Exact-one, at-least-one-new-profile, stock and every physical pair mode remain represented. No separate phase ordering is added.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'physical_modes_checked':744,'cell_selectors_checked':1716,'profile_cell_equalities_checked':42,'band_inequalities_checked':63,'spacing_constraints_checked':390,'complete_profile_y_values_covered':covered_values,'cell_band_coefficients_checked':1716*63,'source_edge_uses_verified':uses,'shared_planes_verified':len(unique),'all_source_faces_and_mode_clauses_verified':True,'sharing_preserves_source_coordinate_feasibility':True,'cog_phase_order_cases_checked':symmetry_cases,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
