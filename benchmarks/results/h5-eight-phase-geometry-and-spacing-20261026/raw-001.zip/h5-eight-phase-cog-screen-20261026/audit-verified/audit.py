"""Independently reconstruct original mixed-phase profiles, collision regions and pair placements."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
from fractions import Fraction as F
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,LineString,Point,box as geometry_box,shape
from shapely.affinity import affine_transform,translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-phase-cog-screen-20261026';OUT=BASE/'audit-verified';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
def rightmost(g,y):
    xs=[]
    for ring in rings(g):
        points=list(ring.coords)
        for (x0,y0),(x1,y1) in zip(points,points[1:]):
            if y0==y1:
                if y==y0:xs.extend([x0,x1])
            elif min(y0,y1)<=y<=max(y0,y1):xs.append(x0+(x1-x0)*(y-y0)/(y1-y0))
    assert xs;return max(xs)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'audit_limit_seconds':240,'method':'Reconstruct all18 original profiles, including all source cutouts, using affine transforms. Check20 repeated tooth patterns and the full period sampled every2.25degrees. For all64 ordered cog choices rebuild raw Minkowski regions from all unmerged original triangle-pair hulls and verify guard containment/separation. Independently sum every raw boundary segment with an explicit128-point circumscribed disk. Recompute every candidate boundary sample via line-segment interpolation without the builder slice helper; check its selection and rounded grid offsets. Independently place original filled outlines and all cutouts and check every pair and stock edge. Additionally check strict containment of every full-height forbidden spacing rectangle, and independently derive its integer bound. This is a numeric two-part screen plus guarded-geometry spacing implications, not an unrestricted packing exclusion or a full66-original validator call.'})
s=load(BASE/'plan.json')
for n,h in s['inputs'].items():assert digest(ROOT/n)==h,n
profiles=load(BASE/'profiles.json');parent=load(ROOT/'output/h5-mixed-cog-angle-screen-20261026/profiles.json');assert len(profiles)==18 and profiles[:12]==parent
cog_profiles=[9,12,13,14,11,15,16,17];assert s['cog_profiles']==cog_profiles and len(set(cog_profiles))==8
for k,pi in enumerate(cog_profiles):assert abs(profiles[pi]['rotation_radians']-(profiles[9]['rotation_radians']+k*math.pi/80))<1e-15
job=load(JOB);families={p['id']:p for p in job['parts']};cog=families['cog'];cx,cy=profiles[9]['original_center'];assert profiles[11]['index']==11 and profiles[11]['rotation_radians']==profiles[9]['rotation_radians']+math.pi/20
source=cog['geometry'][0];polar=[(math.hypot(x-cx,y-cy),math.atan2(y-cy,x-cx)) for x,y in source['outer']]
assert len(polar)==80 and len(source['holes'][0])==200
for i in range(20):
    for j in range(4):
        radius,angle=polar[4*i+j];r0,a0=polar[j]
        assert abs(radius-r0)<1e-6 and abs(math.remainder(angle-a0-i*math.tau/20,math.tau))<1e-8
assert sum(polar[i][0]>125 and polar[(i-1)%80][0]<125 for i in range(80))==20
geoms={};fulls={};errors=[]
for pi,p in enumerate(profiles):
    g=families[p['family']];t=p['rotation_radians'];co,si=math.cos(t),math.sin(t);mi=-1 if p['mirrored'] else 1
    assert not p['mirrored'] or g['allow_mirror']
    if p['family']=='cog':
        assert g['rotations']['kind']=='free';x,y=p['original_center'];tx,ty=-co*x+si*y,-si*x-co*y
    else:
        assert p['quarter_turn']*90. in g['rotations']['degrees'];rot=[(mi*x*co-y*si,mi*x*si+y*co) for x,y in g['geometry'][0]['outer']];tx,ty=-min(x for x,y in rot),-min(y for x,y in rot)
    f=affine_transform(Polygon(g['geometry'][0]['outer'],g['geometry'][0].get('holes',[])),[mi*co,-si,mi*si,co,tx,ty]);a=Polygon(f.exterior);saved=shape(p['geometry']);error=a.hausdorff_distance(saved)
    assert f.is_valid and saved.is_valid and error<1e-7 and len(f.interiors)==len(g['geometry'][0].get('holes',[])) and list(saved.bounds)==p['bounds'];errors.append(error);geoms[pi]=a;fulls[pi]=f
stock=[F(*v) for v in s['stock_bounds_rational']];pad=F(.0125)+F(.000001);bounds=s['anchor_bounds_units1000']
for pi in cog_profiles:
    b=profiles[pi]['bounds'];expected=[math.ceil((stock[0]+pad-F(b[0]))*1000),math.ceil((stock[1]+pad-F(b[1]))*1000),math.floor((stock[2]-pad-F(b[2]))*1000),math.floor((stock[3]-pad-F(b[3]))*1000)];assert expected==bounds[str(pi)]
tri={pi:list(shapely.constrained_delaunay_triangles(geoms[pi]).geoms) for pi in cog_profiles}
for pi in tri:assert unary_union(tri[pi]).symmetric_difference(geoms[pi]).area<1e-7
radius=(.2125+.0001)/math.cos(math.pi/128);disk=[(radius*math.cos(math.tau*i/128),radius*math.sin(math.tau*i/128)) for i in range(128)];minchord=min(Point(0,0).distance(LineString([a,b])) for a,b in zip(disk,disk[1:]+disk[:1]));assert minchord>=.2126-1e-14
hulls=samples=0;checks=[];required=(job['clearance']+3000*32*2**-23)/math.cos(.05)
for pa,pb in product(cog_profiles,repeat=2):
    assert time.perf_counter()<deadline
    r=load(BASE/'pairs'/f'{pa:03d}-{pb:03d}.json');assert r['profiles']==[pa,pb];pieces=[]
    for a,b in product(tri[pa],tri[pb]):
        pieces.append(MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull);hulls+=1
    raw=unary_union(pieces);savedraw=shape(r['raw_forbidden']);guard=shape(r['guarded_forbidden']);assert raw.hausdorff_distance(savedraw)<1e-7 and guard.covers(raw) and guard.boundary.distance(raw)>required
    pieces=[raw]
    for ring in rings(raw):
        xy=list(ring.coords)
        for a,b in zip(xy,xy[1:]):pieces.append(MultiPoint([(x+u,y+v) for x,y in [a,b] for u,v in disk]).convex_hull)
    rebuilt=unary_union(pieces);assert rebuilt.hausdorff_distance(guard)<1e-7 and rebuilt.symmetric_difference(guard).area<1e-6
    aa,bb=bounds[str(pa)],bounds[str(pb)];lo,hi=bb[1]-aa[3],bb[3]-aa[1];assert r['relative_y_bounds_units1000']==[lo,hi]
    ys=sorted({lo/1000,hi/1000,0.}|{y for ring in rings(guard) for x,y in ring.coords if lo/1000<=y<=hi/1000});assert ys==[v['dy_mm'] for v in r['boundary_samples']]
    for row in r['boundary_samples']:
        x=rightmost(guard,row['dy_mm']);assert abs(x-row['rightmost_forbidden_dx_mm'])<1e-7 and abs(x+profiles[pb]['bounds'][2]-profiles[pa]['bounds'][0]-row['pair_span_x_mm'])<1e-7;samples+=1
    assert r['chosen_sample']==min(r['boundary_samples'],key=lambda row:row['pair_span_x_mm']);dx,dy=r['grid_relative_units1000'];assert dy==max(lo,min(hi,round(r['chosen_sample']['dy_mm']*1000))) and dx==math.ceil((rightmost(guard,dy/1000)+.000002)*1000)
    a,b=r['grid_anchors_units1000'];assert b==[a[0]+dx,a[1]+dy] and a==[aa[0],max(aa[1],bb[1]-dy)]
    for p,anchor,box in [(pa,a,aa),(pb,b,bb)]:
        x,y=anchor;assert box[0]<=x<=box[2] and box[1]<=y<=box[3];full=translate(fulls[p],x/1000,y/1000);q=full.bounds;assert len(full.interiors)==1 and len(full.interiors[0].coords)-1==200 and min(q[0]-float(stock[0]),q[1]-float(stock[1]),float(stock[2])-q[2],float(stock[3])-q[3])>3000*32*2**-23
    ap,bp=translate(geoms[pa],a[0]/1000,a[1]/1000),translate(geoms[pb],b[0]/1000,b[1]/1000);gap=ap.distance(bp);assert not ap.intersects(bp) and gap>required and abs(gap-r['original_pair_gap_mm'])<1e-7 and abs(bp.bounds[2]-ap.bounds[0]-r['grid_pair_span_x_mm'])<1e-7
    D=math.floor(min(row['rightmost_forbidden_dx_mm'] for row in r['boundary_samples'])*1000);rect=geometry_box(0,lo/1000,(D-1)/1000,hi/1000);margin=guard.boundary.distance(rect)
    assert D==r['minimum_integer_dx_units1000'] and rect.equals(shape(r['forbidden_rectangle'])) and guard.contains(rect) and margin>1e-8 and abs(margin-r['rectangle_boundary_gap_mm'])<1e-10
    checks.append({'minimum_integer_dx_units1000':D,'rectangle_boundary_gap_mm':margin,'profiles':[pa,pb],'raw_guard_mm':guard.boundary.distance(raw),'original_pair_gap_mm':gap,'boundary_samples':len(ys),'passed':True})
    if len(checks)%8==0:print({'audited_pairs':len(checks),'seconds':time.perf_counter()-start},flush=True)
write(OUT/'pair-checks.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'profiles_reconstructed':18,'unchanged_parent_profiles':12,'max_original_profile_error_mm':max(errors),'tooth_count_verified':20,'sample_step_degrees':2.25,'ordered_collision_regions_reconstructed':64,'full_height_forbidden_rectangles_checked':64,'minimum_rectangle_margin_mm':min(r['rectangle_boundary_gap_mm'] for r in checks),'audit_budget_honored':time.perf_counter()<deadline,'unmerged_triangle_pair_hulls':hulls,'boundary_samples_checked':samples,'grid_original_pairs_checked':64,'original_cutouts_preserved':128,'original_hole_vertices_preserved':25600,'minimum_original_pair_gap_mm':min(r['original_pair_gap_mm'] for r in checks),'required_native_pair_gap_mm':required,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
