"""Read-only decomposition of the closed model to target the next formulation."""
from pathlib import Path
from collections import Counter
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-phase-balanced-probe-20261026';OUT=ROOT/'output/h5-eight-phase-model-cost-20261026';OUT.mkdir()
load=lambda p:json.loads(p.read_bytes())
planes=load(BASE/'shared-planes.json');modes=load(BASE/'models/000-mapping.json');counts=Counter()
for r in planes:counts['cog_cog_shared_planes' if min(r['parts'])>=5 else 'other_shared_planes']+=1
for r in modes:
    key='cog_cog' if min(r['parts'])>=5 else 'other';counts[key+'_physical_modes']+=1
    for f in r['faces']:counts[key+('_tautological_faces' if f.get('tautological') else '_live_face_clauses')]+=1
record={**counts,'total_shared_planes':len(planes),'solver_calls':0,'input_model_closed_status':load(BASE/'search/000/result.json')['status'],'next_research':'Consider a compact sufficient cog-pair formulation using complete relative-Y bins and a certified upper bound on the rightmost forbidden boundary throughout each bin. With globally x-ordered cogs, requiring dx beyond that upper bound is sufficient for separation. Every cog-bin rectangle to the right of the bound must be proven outside the original guarded collision envelope; sample maxima alone are insufficient. Keep all other source clauses and full original constraints. This changes conservative geometry, so any negative does not exclude the current full source family. Do not rerun or reseed the closed large models. First build/audit compact guard coverage, then predeclare a new bounded solve only if justified.'}
with (OUT/'cost.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
