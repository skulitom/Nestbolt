"""Create full balanced-bracket source geometry for all eight sampled cog angles."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
choices='[[0,4],[2,6],[1,7],[3,5],[8,10]]+[[9,11,12,13,14,15,16,17]]*4'
s=(ROOT/'output/build_h5_balanced_phase_choice_strip.py').read_text(encoding='utf-8')
s=rep(s,'h5-mixed-cog-angle-screen-20261026','h5-eight-phase-cog-screen-20261026')
s=rep(s,"OUT=ROOT/'output/h5-balanced-phase-choice-source-20261026'","OUT=ROOT/'output/h5-eight-phase-balanced-source-20261026'")
s=rep(s,"PROFILES/'audit/checks.json'","PROFILES/'audit-verified/checks.json'")
s=rep(s,'[[0,4],[2,6],[1,7],[3,5],[8,10],[9,11],[9,11],[9,11],[9,11]]',choices)
s=rep(s,'assert len(keys)==64','assert len(keys)==184')
a=s.index('reusable={}');b=s.index("stock=spec['stock_bounds_rational']",a)
s=s[:a]+'''reusable={};parent=ROOT/'output/h5-balanced-phase-choice-source-20261026'
assert load(parent/'audit/checks.json')['passed']
old_profiles=load(parent/'profiles.json');assert profiles[:12]==old_profiles
inputs=[PROFILES/'profiles.json',PROFILES/'plan.json',PROFILES/'audit-verified/checks.json',parent/'plan.json',parent/'profiles.json',parent/'audit/checks.json',ROOT/'output/h5-aligned-cog-profiles-20261026/plan.json',ROOT/'output/h5-source-orientation-construction-20261025/items.json',ROOT/'output/h5-source-orientation-construction-20261025/geometry.json',ROOT/'output/h5-eight-phase-band-search-20261026/audit/checks.json',ROOT/'output/h5-eight-phase-band-search-20261026/allocation.json']
assert load(inputs[-2])['passed'];allocation=load(inputs[-1]);totals={p:sum(r['count'] for r in allocation if r['profile']==p) for p in range(18)}
assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5])==(1,1,1,1) and sum(totals[p] for p in range(12,18))>=1
for c in load(parent/'plan.json')['mutual_cases']:
    key=(c['profile_a'],c['profile_b'])
    if key in keys:
        assert all(profiles[pi]==old_profiles[pi] for pi in key)
        reusable[key]=(parent/'mutual'/f"{c['index']:03d}.json",c)
inputs.extend(p for p,c in reusable.values());'''+s[b:]
s=rep(s,"{'profiles':[9,11],'count':4}","{'profiles':[9,11,12,13,14,15,16,17],'count':4}")
s=rep(s,"'minimum_new_phase_cogs':1","'minimum_new_phase_cogs':1,'new_cog_profiles':[12,13,14,15,16,17]")
s=rep(s,'every cog independently chooses56.25degree9 or65.25degree11, with at least one11.','every cog independently chooses one of eight sampled angles56.25..72degrees, with at least one new profile12..17.')
s=rep(s,'all144 physical orientation modes','all744 physical orientation modes')
s=rep(s,'reconstruct all64 cases','reconstruct all184 cases')
s=rep(s,'An unfactored model may be prepared/audited but remains uncalled; share identical plane literals before the one45second4worker seed0 call within60shared seconds.','Share identical plane literals and add independently verified band-cell links and cog-spacing implications before the only45second4worker seed0 call within60shared seconds. No unstrengthened model is called.')
s=rep(s,'declared two allowed cog angles','declared eight allowed cog angles')
s=rep(s,"'pair_cases':64","'pair_cases':184")
s=rep(s,"'orientation_pair_modes':144","'orientation_pair_modes':744,'construction_budget_honored':time.perf_counter()<deadline")
s=rep(s,"write(OUT/'mutual'/f\"{c['index']:03d}.json\",r)","write(OUT/'mutual'/f\"{c['index']:03d}.json\",r)\n    if len(summary)%24==0:print({'geometry_cases':len(summary),'of':184,'seconds':time.perf_counter()-start},flush=True)")
ast.parse(s)
with (ROOT/'output/build_h5_eight_phase_balanced_source.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)

s=(ROOT/'output/audit_h5_balanced_phase_choice_geometry.py').read_text(encoding='utf-8')
s=rep(s,'h5-balanced-phase-choice-source-20261026','h5-eight-phase-balanced-source-20261026')
s=rep(s,'start=time.perf_counter();write','start=time.perf_counter();deadline=start+240;write')
s=rep(s,"'method':'Independently","'audit_limit_seconds':240,'method':'Independently")
s=rep(s,'and144 orientation modes','and744 orientation modes')
s=rep(s,"'h5-mixed-cog-rotations-and-capacity-20261026']","'h5-mixed-cog-rotations-and-capacity-20261026','h5-two-phase-band-and-spacing-exclusions-20261026']")
s=rep(s,"'h5-mixed-cog-exclusion-search']","'h5-mixed-cog-exclusion-search','h5-eight-phase-']")
s=rep(s,'[[0,4],[2,6],[1,7],[3,5],[8,10],[9,11],[9,11],[9,11],[9,11]]',choices)
s=rep(s,"assert spec['minimum_new_phase_cogs']==1;","assert spec['minimum_new_phase_cogs']==1 and spec['new_cog_profiles']==list(range(12,18));")
s=rep(s,"for c in spec['mutual_cases']:\n","for c in spec['mutual_cases']:\n    assert time.perf_counter()<deadline\n")
s=rep(s,"'passed':True})\nfor p,options", "'passed':True})\n    if len(details)%24==0:print({'audited_cases':len(details),'of':184,'seconds':time.perf_counter()-start},flush=True)\nfor p,options")
s=rep(s,'len(needed)==64','len(needed)==184')
s=rep(s,'))==144','))==744')
s=rep(s,"'physical_orientation_modes':144","'physical_orientation_modes':744,'audit_budget_honored':time.perf_counter()<deadline")
ast.parse(s)
with (ROOT/'output/audit_h5_eight_phase_balanced_geometry.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':2,'all_helpers_parse':True,'solver_calls':0})
