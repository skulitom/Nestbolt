"""Create a single strengthened eight-phase model and an independent full auditor."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)

s=(ROOT/'output/prepare_h5_balanced_phase_choice_model.py').read_text(encoding='utf-8')
s=rep(s,'h5-balanced-phase-choice-source-20261026','h5-eight-phase-balanced-source-20261026')
s=rep(s,'h5-balanced-phase-choice-probe-20261026','h5-eight-phase-balanced-probe-20261026')
s=rep(s,"load=lambda p:","DATA=ROOT/'output/h5-eight-phase-band-capacity-20261026'\nload=lambda p:")
s=rep(s,"for p in SOURCE.rglob('*') if p.is_file()","for p in list(SOURCE.rglob('*'))+list(DATA.rglob('*')) if p.is_file()")
s=rep(s,'all144 declared','all744 declared')
s=rep(s,'18 original coordinates and18 profile flags','18 original coordinates and42 profile flags')
s=rep(s,'identical allowed9/11 choices','identical eight-angle choices')
s=rep(s,'Require at least one11;','Require at least one new profile12..17;')
s=rep(s,'36 conditional stock bounds','84 conditional stock bounds')
s=rep(s,'make49 base constraints','make97 base constraints')
s=rep(s,'Independent complete geometric-clause, sharing and actual-import audit before one45second4worker seed0 call in60shared seconds.','Add complete independently audited vertical-cell channeling for every allowed choice, all63 necessary band bounds, and390 source-proven spacing implications (6 universal and384 conditional). No intermediate model is called. Independent complete reconstruction and actual import precede exactly one45second4worker seed0 call within60shared seconds. A negative is conditional on the balanced bracket composition, declared8angles, guards and micrometre grid.')
s=rep(s,'linear({flags[i][11]:1 for i in range(5,9)},1,4)','linear({flags[i][pi]:1 for i in range(5,9) for pi in range(12,18)},1,4)')
s=rep(s,'len(m.variables)==36 and len(m.constraints)==49','len(m.variables)==60 and len(m.constraints)==97')
needle="p=OUT/'models/000.pb';"
append='''base_nv,base_nc=len(m.variables),len(m.constraints)
assert load(DATA/'audit/checks.json')['passed'] and s['stock_bounds_rational']==load(DATA/'plan.json')['stock_bounds_rational']
selectors=[];groups=[]
for i,options in enumerate(allowed):
    for pi in options:
        datum=load(DATA/'profiles'/f'{pi:03d}.json');ids=[]
        for cell in datum['cells']:
            v=len(m.variables);m.variables.add(name=f'p{i}-profile{pi}-cell{cell["index"]}',domain=[0,1]);c=m.constraints.add();c.enforcement_literal.append(v);c.linear.vars.append(2*i+1);c.linear.coeffs.append(1);c.linear.domain.extend(cell['y_bounds_units1000']);ids.append(v)
            selectors.append({'variable':v,'part':i,'profile':pi,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
        groups.append({'part':i,'profile':pi,'profile_flag':flags[i][pi],'cell_flags':ids})
for group in groups:
    c=m.constraints.add();c.linear.vars.extend([group['profile_flag']]+group['cell_flags']);c.linear.coeffs.extend([-1]+[1]*len(group['cell_flags']));c.linear.domain.extend([0,0])
for band,capacity in enumerate(load(DATA/'band-capacities.json')):
    rows=[r for r in selectors if r['demands'][band]];c=m.constraints.add();c.linear.vars.extend(r['variable'] for r in rows);c.linear.coeffs.extend(r['demands'][band] for r in rows);c.linear.domain.extend([-2**63,capacity])
spacing=load(SOURCE/'audit/spacing-case-checks.json');lower={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in spacing};assert len(lower)==64 and all(r['passed'] for r in spacing);common=min(lower.values());added=[]
for a,b in combinations(range(5,9),2):
    for pair,minimum in [(None,common)]+[(list(key),lower[key]) for key in product(allowed[a],allowed[b])]:
        c=m.constraints.add();c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([minimum,2**63-1])
        if pair:c.enforcement_literal.extend([flags[a][pair[0]],flags[b][pair[1]]])
        added.append({'parts':[a,b],'profiles':pair,'minimum_dx_units1000':minimum})
assert len(selectors)==1716 and len(groups)==42 and len(added)==390
write(OUT/'cell-selectors.json',selectors);write(OUT/'cell-groups.json',groups);write(OUT/'spacing-constraints.json',added);write(OUT/'strengthening.json',{'base_variables':base_nv,'base_constraints':base_nc,'cell_selectors':1716,'profile_cell_equalities':42,'band_inequalities':63,'spacing_constraints':390,'base_model_called':False})
'''
s=rep(s,needle,append+needle)
ast.parse(s)
with (ROOT/'output/prepare_h5_eight_phase_balanced_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)

s=(ROOT/'output/audit_h5_balanced_phase_choice_model.py').read_text(encoding='utf-8')
s=rep(s,'h5-balanced-phase-choice-source-20261026','h5-eight-phase-balanced-source-20261026')
s=rep(s,'h5-balanced-phase-choice-probe-20261026','h5-eight-phase-balanced-probe-20261026')
s=rep(s,"load=lambda p:","DATA=ROOT/'output/h5-eight-phase-band-capacity-20261026'\nload=lambda p:")
s=rep(s,'identical allowed9/11 choices','identical eight-angle choices')
s=rep(s,'all360 phase/order combinations with at least one11','all97920 phase/order combinations with at least one new profile12..17')
s=rep(s,'at-least-one11 constraint','at-least-one-new-profile constraint')
s=rep(s,'one of144 modes','one of744 modes')
s=rep(s,'Require exact full proto fields and solver import/export; no solving.','Independently reconstruct all1716 cell variables and interval implications,42 profile sums,63 exact band inequalities and390 source-proven cog spacing implications. Verify full stock-Y coverage, every coefficient and source-specific full-height rectangle proof. Require exact full proto fields and solver import/export; no solving.')
s=rep(s,'linear({flags[i][11]:1 for i in range(5,9)},1,4)','linear({flags[i][pi]:1 for i in range(5,9) for pi in range(12,18)},1,4)')
s=rep(s,'assert vi==36 and ci==49','assert vi==60 and ci==97')
s=rep(s,'assert len(maps)==144','assert len(maps)==744')
s=rep(s,'assert vi==len(m.variables)==r[\'variables\'] and ci==len(m.constraints)==r[\'constraints\'] and ', 'assert ')
needle='real=cp_model.CpModel();'
append='''base_nv,base_nc=vi,ci
assert load(DATA/'audit/checks.json')['passed'] and s['stock_bounds_rational']==load(DATA/'plan.json')['stock_bounds_rational']
selectors=[];groups=[];covered_values=0
for part,options in enumerate(allowed):
    for pi in options:
        datum=load(DATA/'profiles'/f'{pi:03d}.json');lo,hi=bounds[str(pi)][1::2];assert datum['y_bounds_units1000']==[lo,hi];following=lo;ids=[]
        for ordinal,cell in enumerate(datum['cells']):
            a,b=cell['y_bounds_units1000'];assert cell['index']==ordinal and a==following and b==min(a+999,hi);following=b+1;covered_values+=b-a+1
            v=vi;var(f'p{part}-profile{pi}-cell{ordinal}',[0,1]);linear({2*part+1:1},a,b,[v]);ids.append(v)
            selectors.append({'variable':v,'part':part,'profile':pi,'cell':ordinal,'y_bounds_units1000':[a,b],'demands':cell['band_lower_area_units']})
        assert following==hi+1;groups.append({'part':part,'profile':pi,'profile_flag':flags[part][pi],'cell_flags':ids})
for group in groups:
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([group['profile_flag']]+group['cell_flags']);c.linear.coeffs.extend([-1]+[1]*len(group['cell_flags']));c.linear.domain.extend([0,0]);assert c==m.constraints[ci];ci+=1
caps=load(DATA/'band-capacities.json');assert len(caps)==63
for band,cap in enumerate(caps):
    selected=[r for r in selectors if r['demands'][band]>0];c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(r['variable'] for r in selected);c.linear.coeffs.extend(r['demands'][band] for r in selected);c.linear.domain.extend([-2**63,cap]);assert c==m.constraints[ci];ci+=1
spacing=load(SOURCE/'audit/spacing-case-checks.json');lower={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in spacing};assert set(lower)==set(product([9,11,12,13,14,15,16,17],repeat=2)) and all(r['passed'] and r['source_rectangle_margin_mm']>1e-8 for r in spacing);common=min(lower.values());added=[]
for a,b in combinations(range(5,9),2):
    for pair,minimum in [(None,common)]+[(list(key),lower[key]) for key in product(allowed[a],allowed[b])]:
        c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([minimum,2**63-1])
        if pair:c.enforcement_literal.extend([flags[a][pair[0]],flags[b][pair[1]]])
        assert c==m.constraints[ci];ci+=1;added.append({'parts':[a,b],'profiles':pair,'minimum_dx_units1000':minimum})
assert selectors==load(BASE/'cell-selectors.json') and groups==load(BASE/'cell-groups.json') and added==load(BASE/'spacing-constraints.json')
assert len(selectors)==1716 and len(groups)==42 and len(added)==390 and vi==len(m.variables)==r['variables'] and ci==len(m.constraints)==r['constraints']
assert load(BASE/'strengthening.json')=={'base_variables':base_nv,'base_constraints':base_nc,'cell_selectors':1716,'profile_cell_equalities':42,'band_inequalities':63,'spacing_constraints':390,'base_model_called':False}
write(OUT/'source-extension-proof.json',{'equivalent_source_coordinate_feasibility':True,'statement':'A source placement selects exactly one original profile per copy and a unique integer-Y cell. Assign precisely those cell flags. Complete source faces enforce disjoint filled outers inside stock, so the independently verified per-cell band minima obey every capacity. All cog copies have identical angle sets and stock domains and can be relabelled with their profiles in x order. For each ordered profile pair, the source-specific whole forbidden rectangle contains every nonnegative integer deltaX below the threshold at every allowed relative Y, hence each spacing bound follows from the original clauses. Every coordinate/profile witness extends to these flags; conversely every new witness satisfies all original stock and collision clauses. No prior profile-count exclusion is transferred.','no_full66_layout_claim':True})
'''
s=rep(s,needle,append+needle)
s=rep(s,'allowed[5:]==[[9,11]]*4','allowed[5:]==[[9,11,12,13,14,15,16,17]]*4')
s=rep(s,'product([9,11],repeat=4)','product([9,11,12,13,14,15,16,17],repeat=4)')
s=rep(s,'if 11 not in chosen:continue','if not any(p>=12 for p in chosen):continue')
s=rep(s,'symmetry_cases==360','symmetry_cases==97920')
s=rep(s,'at-least-one11','at-least-one-new-profile')
s=rep(s,"'physical_modes_checked':144","'physical_modes_checked':744,'cell_selectors_checked':1716,'profile_cell_equalities_checked':42,'band_inequalities_checked':63,'spacing_constraints_checked':390,'complete_profile_y_values_covered':covered_values,'cell_band_coefficients_checked':1716*63")
ast.parse(s)
with (ROOT/'output/audit_h5_eight_phase_balanced_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)

for name in ['run_h5_repeated_spacing_probe.py','audit_h5_repeated_spacing_response.py']:
    s=(ROOT/'output'/name).read_text(encoding='utf-8')
    s=rep(s,'h5-repeated-spacing-probe-20261026','h5-eight-phase-balanced-probe-20261026')
    if name.startswith('audit'):
        s=rep(s,'h5-repeated-bracket-phase-source-20261026','h5-eight-phase-balanced-source-20261026')
        s=rep(s,'h5-mixed-cog-band-capacity-20261026','h5-eight-phase-band-capacity-20261026')
        s=rep(s,'declared both declared cog angles','eight declared cog angles')
        s=rep(s,'selected[5:].count(11)>=1','any(p>=12 for p in selected[5:])')
        s=rep(s,' and sol[4]<=sol[6]','')
    ast.parse(s)
    out=name.replace('repeated_spacing','eight_phase_balanced')
    with (ROOT/'output'/out).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':4,'all_helpers_parse':True,'solver_calls':0})
