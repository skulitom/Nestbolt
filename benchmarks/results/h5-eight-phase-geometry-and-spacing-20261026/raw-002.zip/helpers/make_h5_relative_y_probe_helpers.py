from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
for name in ['run_h5_eight_phase_balanced_probe.py','audit_h5_eight_phase_balanced_response.py']:
    s=(ROOT/'output'/name).read_text(encoding='utf-8');old="BASE=ROOT/'output/h5-eight-phase-balanced-probe-20261026'";assert old in s;s=s.replace(old,"BASE=ROOT/'output/h5-relative-y-spacing-probe-20261026'");ast.parse(s)
    with (ROOT/'output'/name.replace('eight_phase_balanced','relative_y_spacing')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':2,'all_helpers_parse':True})
