"""Add source-specific full-rectangle spacing verification before the audit runs."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'output/audit_h5_eight_phase_balanced_geometry.py'
s=p.read_text(encoding='utf-8')
assert not (ROOT/'output/h5-eight-phase-balanced-source-20261026/audit').exists()
s=s.replace('Polygon,MultiPoint,shape','Polygon,MultiPoint,box,shape')
needle="load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()"
assert needle in s;s=s.replace(needle,needle+"\nSCREEN=ROOT/'output/h5-eight-phase-cog-screen-20261026'")
needle="for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents"
assert needle in s;s=s.replace(needle,"for p in list(BASE.rglob('*'))+list((SCREEN/'pairs').glob('*.json'))+[SCREEN/'profiles.json',SCREEN/'plan.json',SCREEN/'audit-verified/checks.json'] if p.is_file() and OUT not in p.parents")
s=s.replace('No solving, omitted item, old fixed-pose capacity or complete-layout claim.','For every cog case also independently reconstruct the proposed full-height forbidden spacing rectangle and verify strict containment directly in this source obstacle; its full face coverage therefore preserves the implication. No solving, omitted item, old fixed-pose capacity or complete-layout claim.')
needle="needed=sorted({"
assert needle in s;s=s.replace(needle,"assert load(SCREEN/'audit-verified/checks.json')['passed'] and profiles==load(SCREEN/'profiles.json')\nspacing_checks=[]\nneeded=sorted({")
needle="    for f in data['faces']:"
assert needle in s;s=s.replace(needle,"""    pa,pb=c['profile_a'],c['profile_b']
    if profiles[pa]['family']==profiles[pb]['family']=='cog':
        screen=load(SCREEN/'pairs'/f'{pa:03d}-{pb:03d}.json');aa,bb=[spec['anchor_bounds_units1000'][str(pi)] for pi in [pa,pb]];lo,hi=bb[1]-aa[3],bb[3]-aa[1]
        assert screen['relative_y_bounds_units1000']==[lo,hi]
        D=screen['minimum_integer_dx_units1000'];rectangle=box(0,lo/1000,(D-1)/1000,hi/1000)
        assert rectangle.equals(shape(screen['forbidden_rectangle'])) and expanded.contains(rectangle) and expanded.boundary.distance(rectangle)>1e-8
        spacing_checks.append({'profiles':[pa,pb],'minimum_integer_dx_units1000':D,'source_rectangle_margin_mm':expanded.boundary.distance(rectangle),'passed':True})
    for f in data['faces']:""")
needle="write(OUT/'case-checks.json',details);"
assert needle in s;s=s.replace(needle,"assert len(spacing_checks)==64 and {tuple(r['profiles']) for r in spacing_checks}==set(product([9,11,12,13,14,15,16,17],repeat=2))\nwrite(OUT/'spacing-case-checks.json',spacing_checks);"+needle)
s=s.replace("'profile_reconstructions':len(geoms)","'source_forbidden_spacing_rectangles_checked':len(spacing_checks),'profile_reconstructions':len(geoms)")
ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n');print({'audit_extended_before_execution':True})
