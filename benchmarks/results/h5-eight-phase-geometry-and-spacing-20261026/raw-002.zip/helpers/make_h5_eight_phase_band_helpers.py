"""Prepare new exact-capacity helpers; no old exclusion or solver call is reused."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)

for kind in ['build','audit']:
    source=ROOT/f'output/{kind}_h5_mixed_cog_band_capacity.py'
    s=source.read_text(encoding='utf-8')
    s=rep(s,'h5-mixed-cog-angle-screen-20261026','h5-eight-phase-cog-screen-20261026')
    s=rep(s,'h5-mixed-cog-band-capacity-20261026','h5-eight-phase-band-capacity-20261026')
    if kind=='build':
        s=rep(s,"SOURCE/'audit/checks.json'","SOURCE/'audit-verified/checks.json'")
        s=rep(s,"ROOT/'output/h5-balanced-union-search-20261026/audit/checks.json'","ROOT/'output/h5-repeated-phase-exclusion-search-20261026/audit/checks.json'")
        s=rep(s,'range(12)','range(18)')
        s=rep(s,'the reconstructed56.25degree or65.25degree source angles','eight reconstructed source angles spanning one18degree tooth period in2.25degree steps')
        s=rep(s,'the two declared cog angles','the eight declared cog angles')
        s=rep(s,"'all_profiles_complete':len(rows)==12","'all_profiles_complete':len(rows)==18,'construction_budget_honored':time.perf_counter()<deadline")
    else:
        s=rep(s,'Reconstruct all12','Reconstruct all18')
        s=rep(s,'Recompute all44667 minima','Recompute every cell/band minimum')
        s=rep(s,"start=time.perf_counter();write","start=time.perf_counter();deadline=start+240;write")
        s=rep(s,"'method':'Reconstruct","'audit_limit_seconds':240,'method':'Reconstruct")
        s=rep(s,'for p in profiles:\n','for p in profiles:\n    assert time.perf_counter()<deadline\n')
        s=rep(s,'assert checked==44667 and cell_count==709;','assert len(profiles)==18 and checked==63*cell_count;')
        s=rep(s,'Two declared cog orientations','Eight declared cog orientations')
        s=rep(s,'Both56.25degree and65.25degree cog profiles are included; all fixed-angle conditional exclusions are omitted.','The full20tooth period is sampled at2.25degree increments,56.25 through72degrees; all prior two-angle conditional exclusions are omitted.')
        s=rep(s,"'original_profiles_reconstructed':12,'complete_vertical_cells_verified':709,'exact_band_coefficients_recomputed':44667","'original_profiles_reconstructed':18,'complete_vertical_cells_verified':cell_count,'exact_band_coefficients_recomputed':checked,'audit_budget_honored':time.perf_counter()<deadline")
    ast.parse(s)
    with (ROOT/f'output/{kind}_h5_eight_phase_band_capacity.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)

names=['prepare_h5_mixed_cog_band_model.py','audit_h5_mixed_cog_band_model.py','run_h5_mixed_cog_band_model.py','audit_h5_mixed_cog_band_response.py']
for name in names:
    s=(ROOT/'output'/name).read_text(encoding='utf-8')
    s=rep(s,'h5-mixed-cog-band-','h5-eight-phase-band-')
    if name=='prepare_h5_mixed_cog_band_model.py':
        s=rep(s,'Require at least one cog in new profile11, while all four cogs choose9/11.','Require at least one cog in a newly added profile12..17, while all four cogs choose among eight audited source angles.')
        s=rep(s,'two-phase scope','eight-angle scope')
        s=rep(s,"r['profile']==11","r['profile']>=12")
    elif name=='audit_h5_mixed_cog_band_model.py':
        s=rep(s,'all709 aggregate count variables','every aggregate count variable')
        s=rep(s,'complete profile11 sum','complete sum for new profiles12..17')
        s=rep(s,'range(12)','range(18)')
        s=rep(s,"r['profile']==11","r['profile']>=12")
        s=rep(s,'assert len(ids)==34',"assert len(ids)==sum(len(load(SOURCE/'profiles'/f'{pi:03d}.json')['cells']) for pi in range(12,18))")
        s=rep(s,'len(model.variables)==709','len(model.variables)==len(mapping)')
        s=rep(s,"'variables':709","'variables':len(mapping)")
    elif name=='run_h5_mixed_cog_band_model.py':
        s=rep(s,'independently audited709-variable/66-constraint model','independently audited expanded-eight-angle model with67constraints')
        s=rep(s,'two-phase56.25/65.25degree guarded-source geometry','the eight declared cog angles56.25..72degrees with guarded source geometry')
    else:
        s=rep(s,'two declared cog angles','eight declared cog angles')
        s=rep(s,'len(s)==709','len(s)==len(mapping)')
        s=rep(s,"r['profile']==11","r['profile']>=12")
        s=rep(s,'range(12)','range(18)')
    ast.parse(s)
    out=ROOT/'output'/name.replace('mixed_cog','eight_phase')
    with out.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':6,'all_helpers_parse':True,'solver_calls':0})
