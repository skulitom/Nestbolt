"""Append proven relative-Y spacing propagation to the closed eight-phase model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-eight-phase-balanced-probe-20261026';DATA=ROOT/'output/h5-relative-y-cog-spacing-20261026';OUT=ROOT/'output/h5-relative-y-spacing-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN' and load(DATA/'audit/checks.json')['passed']
paths=[PARENT/n for n in ['plan.json','models/000.pb','models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json','spacing-constraints.json','inventory.json','model-audit/checks.json','model-audit/source-extension-proof.json','response-audit/checks.json','search/000/result.json','search/000/response.pb']]+[p for p in DATA.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Preserve the complete closed233563-variable/240227-constraint model and its UNKNOWN result. For each of six physical cog pairs add35 exact-one relative-Y bin flags covering every permitted integer difference, with conditional full interval constraints. For each independently certified nonempty phase-pair/bin intersection add its necessary X separation, conditional on both existing phase flags and the new bin flag. No source coordinate or angle is fixed. Full stock domains already imply the clipped phase-pair interval. The whole forbidden-rectangle proof therefore makes all added separations valid; every parent witness extends uniquely to the relative bins. One new45solver/60shared4worker seed0 call after complete independent model/import audit. No restart/reseed/extension or inference from UNKNOWN.'})
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'models/000.pb').read_bytes());nv,nc=len(m.variables),len(m.constraints);assert (nv,nc)==(233563,240227)
flags=load(PARENT/'profile-flags.json');spec=load(DATA/'plan.json');rows=load(DATA/'bounds.json');selectors=[];constraints=[]
for a,b in combinations(range(5,9),2):
    ids=[]
    for i,(lo,hi) in enumerate(spec['bins_units1000']):
        v=len(m.variables);m.variables.add(name=f'pair-{a}-{b}-relative-y-bin{i}',domain=[0,1]);c=m.constraints.add();c.enforcement_literal.append(v);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([lo,hi]);ids.append(v);selectors.append({'parts':[a,b],'bin':i,'variable':v,'relative_y_units1000':[lo,hi]})
    c=m.constraints.add();c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1])
    for r in rows:
        pa,pb=r['profiles'];c=m.constraints.add();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[r['bin']]]);c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([r['minimum_dx_units1000'],2**63-1]);constraints.append({'parts':[a,b],'profiles':[pa,pb],'bin':r['bin'],'minimum_dx_units1000':r['minimum_dx_units1000']})
assert len(selectors)==210 and len(constraints)==13146 and len(m.variables)==233773 and len(m.constraints)==253589
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json','spacing-constraints.json']:shutil.copyfile(PARENT/n,OUT/n)
write(OUT/'relative-y-selectors.json',selectors);write(OUT/'relative-y-constraints.json',constraints)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
r={**load(PARENT/'inventory.json')[0],'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'relative_y_bin_selectors':210,'relative_y_bin_equalities':6,'relative_y_spacing_constraints':13146};write(OUT/'inventory.json',[r]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**r,'solver_calls':0});print(load(OUT/'prepared.json'))
