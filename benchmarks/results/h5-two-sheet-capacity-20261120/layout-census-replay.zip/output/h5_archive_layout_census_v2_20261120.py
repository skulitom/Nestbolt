"""Read the saved native mechanical layouts and compare their material with the original target."""
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "benchmarks/results"
OUT = ROOT / "output/h5-archive-layout-census-v2-20261120"
original = json.loads((RESULTS / "h5-common-development-20261015T142414Z/results.json").read_bytes())
requests = {}
for record in original["rows"]:
    if record["arm"] == "bonus" and record["job"].startswith("m-mechanical-"):
        with ZipFile(RESULTS / "h5-common-development-20261015T142414Z" / record["archive"]) as archive:
            request = json.loads(archive.read("request.json"))
        requests[record["job"], record["kerf_mm"]] = {k: request.get(k) for k in ["parts", "sheets", "spacing_mm", "edge_spacing_mm", "mode"]}
jobs = {r["job"]: r["job_sha256"] for r in original["rows"] if r["job"].startswith("m-mechanical-")}
assert len(jobs) == 2
source = defaultdict(list)
for row in original["rows"]:
    if row["job"] in jobs and row["arm"] == "normal":
        source[row["job"], row["kerf_mm"]].append(row["metrics"]["material_area"])
targets = {k: median(v)*1.01 for k,v in source.items()}
assert all(len(v) == 3 for v in source.values()) and len(targets) == 4
scope = json.loads((OUT / "scope.json").read_bytes())
layouts, ignored = defaultdict(dict), Counter()
for name in scope:
    p = RESULTS / name
    with ZipFile(p) as z:
        members = set(z.namelist())
        if not {"case.json", "request.json", "nested/layout.json", "validate-stdout.json"} <= members:
            ignored["missing native output fields"] += 1
            continue
        case = json.loads(z.read("case.json"))
        req = json.loads(z.read("request.json"))
        common = req.get("common_line")
        if case.get("status") != "valid" or not common or case.get("job_sha256") != jobs.get(case.get("job")):
            ignored["different input, mode or validation status"] += 1
            continue
        key = (case["job"], common["kerf_mm"])
        assert key in targets and case["kerf_mm"] == key[1]
        assert {k:req.get(k) for k in requests[key]} == requests[key], name
        validation = json.loads(z.read("validate-stdout.json"))
        metrics = case.get("metrics", validation["metrics"])
        if metrics.get("requested_parts") not in (66,178) or metrics.get("placed_parts") != metrics["requested_parts"]:
            ignored["different inventory"] += 1
            continue
        validation = json.loads(z.read("validate-stdout.json"))
        assert validation["valid"]
        raw_layout = z.read("nested/layout.json")
        for file in ["nested/layout.json","validate-stdout.json","request.json"]:
            if file in case.get("artifacts",{}):
                assert sha256(z.read(file)).hexdigest() == case["artifacts"][file]
        positions = json.loads(raw_layout)["placements"]
        ids = {(row["part_id"],row["copy_index"]) for row in positions}
        assert len(positions) == len(ids) == metrics["requested_parts"]
        material = metrics["material_area"]
        assert abs(validation["metrics"]["material_area"] - material) < 1e-5
        layout_hash = sha256(raw_layout).hexdigest()
        unique = layouts[key]
        if layout_hash in unique:
            assert abs(unique[layout_hash]["material_mm2"]-material) < 1e-5
            unique[layout_hash]["copies"] += 1
        else:
            unique[layout_hash] = dict(archive=name, layout_sha256=layout_hash, material_mm2=material, copies=1)
summary = []
for (job,kerf), by_hash in sorted(layouts.items()):
    rows = list(by_hash.values())
    best = min(rows,key=lambda row:row["material_mm2"])
    limit = targets[job,kerf]
    summary.append(dict(job=job,kerf_mm=kerf,archive_count=sum(r["copies"] for r in rows),
                        distinct_saved_layouts=len(rows), target_mm2=limit,best=best,
                        best_above_target_percent=(best["material_mm2"]/limit-1)*100,
                        layouts_within_target=sum(r["material_mm2"]<=limit for r in rows)))
print(json.dumps(summary))
(OUT/"results.json").write_text(json.dumps(dict(cases=summary,ignored=ignored,files_scanned=len(scope)),
                                          indent=2)+"\n",encoding="utf-8",newline="\n")
