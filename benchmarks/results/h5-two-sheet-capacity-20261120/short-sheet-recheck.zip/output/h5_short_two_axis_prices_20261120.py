"""Two-axis section bound for unrestricted short-sheet rotations."""
import json
from fractions import Fraction
from math import ceil, floor
from pathlib import Path
import sys
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "benchmarks/results/h5-two-sheet-capacity-20261120"
sys.path.insert(0, str(EVIDENCE))
from screen import JOB, geometry, read, rectangle_profile

names = ["bracket", "insert"]
limits = (313, 1487)
remaining = read(EVIDENCE / "cog-results.json")["remaining"]
assert len(remaining) == 418
maxima = [q for q in remaining if not any(q != r and all(a <= b for a, b in zip(q, r)) for r in remaining)]
assert len(maxima) == 33
_, areas, modes = geometry(read(EVIDENCE / "plan.json"))
heights = sorted({h for name in names for mode in modes[name] for h in mode})
assert all(h % 5 == 0 for h in heights)
diameter = 282
assert read(EVIDENCE / "cog-results.json")["certificates"]
cog_area = int(areas["cog"])
rows, columns, values, rhs = [], [], [], []
next_var = 0


def variables(n):
    global next_var
    result = list(range(next_var, next_var + n))
    next_var += n
    return result


def inequality(terms, bound=0):
    for var, coefficient in terms:
        if coefficient:
            rows.append(len(rhs))
            columns.append(var)
            values.append(coefficient)
    rhs.append(bound)


axes = []
for limit in limits:
    p = dict(zip(heights, variables(len(heights))))
    slope, offset, cap = variables(3)
    axes.append((p, slope, offset, cap))
    best = variables(limit//5+1)
    for t, v in enumerate(best):
        if t:
            inequality([(best[t-1], 1), (v, -1)])
        for h in heights:
            if h//5 <= t:
                inequality([(best[t-h//5], 1), (p[h], 1), (v, -1)])
        residual = limit - 5*t
        for k in {0, min(15, residual//diameter), min(15, ceil(residual/diameter)), 15}:
            inequality([(v, 1), (slope, min(residual, diameter*k)), (offset, -k), (cap, -1)])
cost_vars = variables(3)
for f, name in enumerate(names):
    for orientation in (0, 1):
        terms = [(cost_vars[f], 1)]
        for axis, (p, _, _, _) in enumerate(axes):
            terms.extend((p[h], -w) for h, w in modes[name][orientation ^ axis].items())
        inequality(terms)
terms = [(cost_vars[2], 1)]
for _, slope, offset, _ in axes:
    terms.extend([(slope, -cog_area), (offset, diameter)])
inequality(terms)
inequality([(axis[3], limits[1-j]) for j, axis in enumerate(axes)], sum(limits))
matrix = coo_matrix((values, (rows, columns)), shape=(len(rhs), next_var)).tocsr()


def exact_axis(h_limit, weights, slope, offset):
    best = [0]*(h_limit//5+1)
    for h, pay in zip(heights, weights):
        size = h//5
        for t in range(size, len(best)):
            best[t] = max(best[t], best[t-size]+pay)
    return max(v + slope*min(h_limit-5*t, diameter*k) - offset*k
               for t,v in enumerate(best) for k in range(16))


certificates = []
for q in maxima:
    obj = [0]*next_var
    for var, count in zip(cost_vars, q):
        obj[var] = -count
    lp = linprog(obj, A_ub=matrix, b_ub=rhs, method="highs", options={"threads": 1})
    assert lp.success, lp.message
    exact = []
    for j, (p, m, b, cap) in enumerate(axes):
        weights = [max(0, floor(1e6*lp.x[p[h]])) for h in heights]
        slope = max(0, floor(1e6*lp.x[m]))
        offset = max(0, ceil(1e6*lp.x[b]))
        peak = exact_axis(limits[j], weights, slope, offset)
        exact.append(dict(weights=dict(zip(heights, weights)), slope=slope, offset=offset, peak=peak))
    costs = []
    for name in names:
        costs.append(min(sum(exact[j]["weights"][h]*w for j in (0,1)
                             for h,w in modes[name][o^j].items()) for o in (0,1)))
    costs.append(sum(axis["slope"]*cog_area-axis["offset"]*diameter for axis in exact))
    budget = sum(limits[1-j]*axis["peak"] for j,axis in enumerate(exact))
    certificates.append(dict(short_counts=q, axes=exact, costs=costs, budget=budget))
excluded, survivors = [], []
for q in remaining:
    for i,c in enumerate(certificates):
        excess = sum(n*v for n,v in zip(q, c["costs"])) - c["budget"]
        if excess > 0:
            excluded.append(dict(short_counts=q, certificate=i, excess=excess))
            break
    else:
        survivors.append(q)
out = ROOT / "output/h5-short-two-axis-prices-20261120"
with (out / "results.json").open("x",encoding="utf-8",newline="\n") as stream:
    json.dump(dict(heights=heights,certificates=certificates,excluded=excluded,remaining=survivors),
              stream,separators=(",",":"))
    stream.write("\n")
print("excluded",len(excluded),"remaining",len(survivors))
