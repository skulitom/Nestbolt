from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8').replace('h5-direct-pose-audit-process-20261107','h5-fifteen-cog-source-audit-process-20261107').replace('audit_h5_direct_pose_model_20261107.py','audit_h5_fifteen_cog_source_20261107.py')
with (ROOT/'output/run_h5_fifteen_cog_source_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
