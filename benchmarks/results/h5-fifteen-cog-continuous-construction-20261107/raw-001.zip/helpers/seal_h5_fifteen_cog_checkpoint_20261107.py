from pathlib import Path
import json,shutil,re
def readable(s):
    for gate in ['H2','H5']:s=s.replace(gate,gate[0]+'\u200b'+gate[1])
    s=re.sub(r'(?<=\d)(?=[A-Za-z])|(?<=[A-Za-z])(?=\d)',' ',s)
    return s.replace('\u200b','')
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-fifteen-cog-continuous-construction-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-fifteen-cog-direct-model-20261107';F=ROOT/'output/h5-fifteen-cog-checkpoint-20261107';D=ROOT/'output/h5-fifteen-cog-source-20261107'","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-four-column-continuous-search-20261107'","front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==31","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F,D]+[ROOT/'output'/n for n in ['h5-fifteen-cog-source-preparation-process-20261107','h5-fifteen-cog-source-audit-process-20261107','h5-fifteen-cog-initializer-process-20261107','h5-fifteen-cog-model-audit-process-20261107','h5-fifteen-cog-response-audit-process-20261107','h5-four-column-direct-main-sync-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*fifteen*cog*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_fifteen_cog_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py','push_h5_four_column_direct_checkpoint_20261107.py','make_h5_four_column_direct_push_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(D/'audit/checks.json','source-audit.json'),(D/'audit/exact-contact-readback.json','exact-contact-pitches.json'),(D/'allocation-readback.json','allocation-readback.json'),(D/'source-contact-pitches.json','contact-pitches.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/candidate-geometry-readback.json','candidate-geometry-readback.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/seed-descent-controls.json','seed-descent-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'audit/physical-mode-controls.json','physical-mode-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/mode-selection-controls.json','mode-selection-controls.json'),(BASE/'response-audit/round-reconciliation.json','round-reconciliation.json'),(BASE/'response-audit/round-00-collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json'),(ROOT/'output/h5-four-column-direct-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for folder in ['source-preparation','source-audit','initializer','model-audit','response-audit']:copies.append((ROOT/'output'/('h5-fifteen-cog-'+folder+'-process-20261107')/'process.json',folder+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Fifteen-cog continuous construction — 2026-11-07

The new 24-mover model closes after three bounded calls without a valid full
layout. Its best objective candidate is from the **first call**, and still has
**31 overlapping source pairs**, totaling **7,052.327596 mm²**. All fixed-part
clearances and stock edges pass. Later calls increase source overlap and are
retained. Four fixed arrangements and all 440 whole allocations remain;
H2/H5 stay open at **60% completed milestone weight**. No native call,
allocation exclusion or release follows.

## Historical allocation and fresh source construction

[The source audit]({NAME}/source-audit.json) reconciles all 4,576 original
allocation rows and the 440 still unexcluded. The eight-bracket/five-insert
short-sheet allocation is historical, and remains unexcluded in the current
ledger. Earlier finite-angle optimization and necessary relaxations remain
closed. This construction changes the actual original-outline model to allow
all fifteen cog angles to vary continuously, together with the positions and
legal modes of four brackets and five inserts. It does not claim a new allocation.

The source-only recipe uses eighteen frames in three columns by six rows and
eleven turned side inserts. Four two-bracket/one-insert modules plus a turned
right insert give thirteen short-sheet originals. Every source identity is
accounted for; holes remain preserved and filled outers enforce noPIH.
All42 fixed originals pass source checks. Independent exact rational readback
checks882 cog contact sections and confirms both261.766mm pitches at the
source-derived6.75degree phase. A centered5×3 cog grid gives a valid57-original
control, checked across1,024pairs,228stock edges and73holes/7,952vertices.
Nine companions remain unplaced at this stage. This control does not improve
the retained64-part partial or establish a full66 result.

All24movers remain free in the subsequent model. The source audit verifies
67owner/mode bindings and388 source stock-corner controls. All15 cog angles
span the full circle, with conservative all-angle radius bounds. Source-only
preparation charges the entire failed-plus-corrected predecessor2.988826s and
the complete new0.434939s stage: **3.423765s** before initialization. No optimized
ancestor or selected orientation is consumed.

## Complete initializer and model

The single deterministic initializer constructs cog-minus-companion obstacles
from original convex pieces with a0.23mm square clearance allowance. These
floating obstacles only propose finite starting positions; they are never
model constraints or exclusion certificates. Candidate vertices, free-region
representative points and a declared9×9 domain grid are considered. All12 modes
have empty conditional free regions against this one fixed cog seed, leaving
648bracket and324insert grid candidates; this says nothing about moving cogs.

Greedy source scoring places four brackets then five inserts. [Independent
replay]({NAME}/model-audit.json) verifies every one of **4,212 trials** and its
declared tie order. The seed has14 failing source pairs and no stock failures.
The initializer/model stage takes2.422507s, so total preparation is
**5.846273s**. Both failing seed geometry and every trial are preserved.

The model has **63continuous parameters,15continuous angles and276moving
pairs**. It equally weights original filled-outline overlap and certified
clearance-outline overlap. Hard source-center bounds protect all42fixed parts
and stock throughout every legal mode; no soft fixed-domain penalty is used.
Controls cover67full scores and owner/mode bindings,44dynamic vectors,
56scalar/batched gradient comparisons,126central-coordinate derivatives,
three projected descent steps and nine deliberate corruptions. All pass.

[Physical equivalence controls]({NAME}/physical-mode-audit.json) verify81mode
pairs. Four insert orientations reduce to two distinct filled outlines,
giving57physical owner options and33distinct single-owner neighbors.
Actual output retains the selected legal transform and original holes.

## Three calls, all closed

The frozen pipeline allows18seconds for the initial vector and at most two
14second calls for new physical mode vectors. Later calls select the lowest
full-objective unvisited neighbor of the best retained candidate. A proposal
need not improve before optimization; the global best is tracked separately.
There are no random restarts, repeated physical vectors or extensions.

[Response replay]({NAME}/response-audit.json) checks all **268saved points,
312evaluation counters and65orientation trials**, including skipped equivalent
vectors and selected clamps. Each call stops on time with no numerical return.
Every response reconstructs all66originals and checks1,456same-sheet pairs,
264stock edges and90holes/10,026vertices.

| Call | Failed source pairs | Original overlap (mm²) | Best retained call |
|---|---:|---:|---:|
| 0 | 31 | 7,052.327596 | 0 |
| 1 | 33 | 8,926.544924 | 0 |
| 2 | 31 | 7,597.606704 | 0 |

All failures are moving–moving positive overlaps; fixed–fixed and fixed–moving
pairs pass. The lower objective does not establish validity, and the increase
from14seed failures to31best-candidate failures is retained.

Preparation-inclusive algorithm/shared totals are **54.483481/54.554720s**,
within60/90s. Optimizer slice overruns of0.079476,0.133826 and0.007139s remain
recorded. Peak aggregate committed memory is94,134,272bytes; all five search
processes close. The declared three-call maximum closes the pipeline even
though time remains. No continuation or reset clock is permitted.

## Next scope and repository

[The next source review]({NAME}/next-step.json) concerns the historical
six-bracket/nine-insert short allocation, also unexcluded in the current ledger.
With the same source-derived fixed29 core, it changes the remaining mix to
six brackets, one insert and fifteen cogs:22movers,59continuous parameters and
231moving pairs. A new source construction, complete deterministic initializer
and original-outline model must be checked before any new bounded call. The
allocation and older unrestricted-angle necessary models are explicitly
historical; no first-allocation or first-free-angle claim is made. No successor
is prepared, and this proposal cannot reopen any closed search.

Main **52313564** was pushed normally after all six preceding CI jobs passed,
preserving52remote file blobs. Fresh [main CI](https://github.com/skulitom/Nestbolt/actions/runs/42354518901)
is live at review, so this checkpoint awaits the ordinary push gate. Production,
README, release assets and reservedH2vectors are unchanged. Full66 source and
native checks, material validation, production parity and the unchanged H5
matrix remain required. All raw evidence and hash-bound dependencies are
archived, including the valid partials, invalid seeds and all closed calls.

[Checkpoint audit]({NAME}/checkpoint-audit.json), [closed process]({NAME}/closed-search-process.json),
[archive readback]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json).
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(readable(report))
entry='**2026-11-07 H5 fifteen-cog continuous construction:** [independent source/model/response audits]({link}) reconcile all4,576allocation rows and440survivors, verify a source-valid57part control,882exact contact sections and388stock-corner controls. One complete initializer replays4,212trials; the24mover/63parameter model checks67owner-mode bindings,126central derivatives and81physical-mode equivalences. Three unique physical-vector calls and65orientation trials close at the declared limit; all268saved points and312evaluation counters replay. The first call remains best:31source overlaps totaling7,052.327596mm², with all fixed-part and stock checks passing. Both later worse candidates and all slice overruns remain preserved. Complete preparation is5.846273s and algorithm/shared totals54.483481/54.554720s; every process closes. No native call or allocation exclusion follows. Next assess the historical six-bracket/nine-insert short allocation with a newly checked22mover/all15continuous-angle original model; no successor is prepared and no closed call may resume. Four fixed arrangements and440allocations remain; H2/H5 stay at60%. Previous checkpoint52313564 reached main after all six prior checks passed, preserving52remote files; fresh CI is live. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+readable(entry.format(link=link))+'\n')
path=ROOT/'docs/STATUS.md';s=path.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a);intro=f'''Latest H5 evidence: [fifteen-cog continuous construction](../benchmarks/results/{NAME}.md).
Current-ledger readback, a valid57part source control, the complete24mover model
and all three bounded responses pass independent audits. No valid full66 layout
results: the first call remains best, with31overlapping pairs totaling7,052.327596mm².
All fixed-part clearances and stock edges pass. Later worse candidates, all268
saved points,65orientation trials and all slice overruns are preserved.
Preparation-inclusive algorithm/shared totals are54.483481/54.554720s; every
process is closed and no continuation is allowed. Next assess the historical
six-bracket/nine-insert short allocation, changing the remaining mix to six
brackets, one insert and fifteen continuous-angle cogs. No successor source
geometry, initializer or model is prepared. Four fixed arrangements and440
allocations remain; H2/H5 stay open at60% completed milestone weight.
Main52313564 was pushed after all six prior checks passed, preserving52remote
files; fresh CI is live. This checkpoint awaits the ordinary push gate.
Full66source/native/material checks, production parity and the unchanged H5
matrix remain required. No release qualifies.
''';path.write_text(s[:a]+readable(intro)+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
