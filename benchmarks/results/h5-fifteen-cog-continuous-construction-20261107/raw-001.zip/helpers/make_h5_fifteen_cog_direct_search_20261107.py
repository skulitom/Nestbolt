from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_four_column_direct_search_20261107.py').read_text(encoding='utf-8')
changes={
 'h5-four-column-direct-model-20261107':'h5-fifteen-cog-direct-model-20261107',
 'h5-four-column-source-domains-20261107':'h5-fifteen-cog-source-20261107',
 'h5_four_column_direct_model_20261107':'h5_fifteen_cog_direct_model_20261107',
 'h5_four_column_direct_readback_20261107':'h5_fifteen_cog_direct_readback_20261107',
 'h5-four-column-initializer-process-20261107':'h5-fifteen-cog-initializer-process-20261107',
 'physical-mode-audit/checks.json':'audit/physical-mode-controls.json',
 "lib['identities'][:27]":"lib['identities'][:9]",
 'range(90)':'range(63)',
 "'parameters':90":"'parameters':63",
 "source['same_sheet_pairs']==1632":"source['same_sheet_pairs']==1456",
 "'weighted_free_region_penalty_mm2':details['weighted_free_region_penalty_mm2'],":'',
 "'optimizer_slice_seconds':[16,12,12]":"'optimizer_slice_seconds':[18,14,14]",
 "One finite new39-mover/90parameter pipeline. Optimizeinitialsource vectoronceforatmost16s. Thenatmosttwomorecalls,12seach":"One finite new24-mover/63parameter/all15continuousangle pipeline. Optimizeinitialsource vectoronceforatmost18s. Thenatmosttwomorecalls,14seach",
 'Hardworldstockbounds;wholecertifiedfreeunion squared-distanceweight4;741original+clearancepairs.':'Hard source-center bounds independently protect fixed42 and stock;276original+clearance moving pairs with equal weights. All15 cog angles remain continuous. Historical allocation and finite-angle predecessors stay closed; this source-only initializer does not consume any optimized ancestor.',
}
for old,new in changes.items():assert old in s,old;s=s.replace(old,new)
with (ROOT/'output/run_h5_fifteen_cog_direct_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
