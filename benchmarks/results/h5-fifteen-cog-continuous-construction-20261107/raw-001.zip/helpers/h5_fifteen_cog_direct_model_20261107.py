"""Dynamic source-center model; fixed core is separated by hard source bounds."""
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_direct_pose_model_20261107 import transformed,boundary_gradient
from h5_mixed_direct_pose_20261107 import source_pose,source_rows,owner_shapes,pair_energy

def compile_model(library,modes,values):
    assert len(modes)==24 and len(values)==63
    owners=[];bounds=[]
    for i,(identity,mi) in enumerate(zip(library['identities'],modes)):
        mode=library['family_modes'][identity[0]][mi];assert mode['mode']==mi;free=identity[0]=='cog'
        bounds.extend(mode['center_bounds_mm'])
        owners.append({'owner':i,'identity':identity,'mode':mi,'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'source_center':library['families'][identity[0]]['source_center'],'angle_coordinate':48+i-9 if free else None,'angle_scale_mm':library['angle_scale_mm'] if free else None})
    bounds.extend(library['angle_bounds'])
    return {'families':library['families'],'owners':owners,'pairs':library['pairs'],'fixed_source_rows':library['fixed_source_rows'],'parameters':63,'bounds':bounds,'initial':np.clip(values,np.asarray(bounds)[:,0],np.asarray(bounds)[:,1]).tolist(),'objective_weights':{'original_area':1,'clearance_area':1}}

class Objective:
    def __init__(self,model):
        self.model=model;self.left=np.asarray([p[0] for p in model['pairs']]);self.right=np.asarray([p[1] for p in model['pairs']])
    def geometry(self,values,lines=True):
        result=[]
        for kind in ['original','clearance']:
            entries=[]
            for o in self.model['owners']:
                v=transformed(self.model['families'][o['identity'][0]][kind],source_pose(o,values))
                entries.append((v,Polygon(v),shapely.linestrings(np.stack([v,np.roll(v,-1,axis=0)],axis=1)) if lines else None,[float(values[2*o['owner']]),float(values[2*o['owner']+1])]))
            result.append(entries)
        return result
    def evaluate(self,values,details=False):
        g=np.zeros(63);levels=[];records=[];shared=0.;segments=0
        for kind,entries in zip(['original','clearance'],self.geometry(values)):
            shapes=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]));levels.append(float(np.sum(areas)))
            for index in np.flatnonzero(areas>0):
                i,j=self.model['pairs'][index]
                if details:records.append({'kind':kind,'owners':[i,j],'area_mm2':float(areas[index])})
                for own,other in [(i,j),(j,i)]:
                    v,poly,lines,pivot=entries[own];gg,n,coincident=boundary_gradient(v,lines,entries[other][1],pivot);g[2*own:2*own+2]+=gg[:2];o=self.model['owners'][own]
                    if o['angle_coordinate'] is not None:g[o['angle_coordinate']]+=gg[2]/o['angle_scale_mm']
                    shared+=coincident;segments+=n
        total=sum(levels);assert np.isfinite(total) and np.all(np.isfinite(g))
        if details:return total,g,{'original_overlap_area_mm2':levels[0],'clearance_overlap_area_mm2':levels[1],'positive_terms':records,'clipped_segments':segments,'coincident_boundary_length_mm':shared}
        return total,g
    def score(self,values):
        total=0.
        for entries in self.geometry(values,False):
            shapes=np.asarray([e[1] for e in entries],dtype=object);total+=float(np.sum(shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]))))
        return total
