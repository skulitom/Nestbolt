from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_four_column_direct_response_20261107.py').read_text(encoding='utf-8')
changes={
 'h5-four-column-direct-model-20261107':'h5-fifteen-cog-direct-model-20261107',
 'h5-four-column-source-domains-20261107':'h5-fifteen-cog-source-20261107',
 'h5_four_column_direct_model_20261107':'h5_fifteen_cog_direct_model_20261107',
 'h5_four_column_direct_readback_20261107':'h5_fifteen_cog_direct_readback_20261107',
 'h5-four-column-initializer-process-20261107':'h5-fifteen-cog-initializer-process-20261107',
 'physical-mode-audit/checks.json':'audit/physical-mode-controls.json',
 "lib['identities'][:27]":"lib['identities'][:9]",
 'range(90)':'range(63)',
 "opened_optimizer['parameters']==90":"opened_optimizer['parameters']==63",
 'len(evaluated)+len(skipped)==113':'len(evaluated)+len(skipped)==43',
 "assert response['status']=='TIME_STOP' and response['numerical_result'] is None and response['closed']":"assert response['status'] in ['TIME_STOP','RETURNED'] and response['closed'];assert (response['numerical_result'] is None)==(response['status']=='TIME_STOP')",
 'values[78+i-27]':'values[48+i-9]',
 'if i>=27 else':'if i>=9 else',
 "source['same_sheet_pairs']==1632":"source['same_sheet_pairs']==1456",
 'len(moving_pairs)==741':'len(moving_pairs)==276',
 "and all(p['passed'] for p in fixed_pairs)":"and all(p['passed'] for p in fixed_pairs+mixed_pairs)",
 "'free_region_outside_owners':len(details['free_region_violations']),'weighted_free_region_penalty_mm2':details['weighted_free_region_penalty_mm2'],":'',
 "and trials_total==result['mode_trials']==149":"and trials_total==result['mode_trials']",
 "'method':'Replayall149distinctphysicalmode trials,skippedequivalences,selectedclampsandfullmodelbindings. Verifyallthreeuniquephysicalvectors,all240savedpoints/271evaluations,90coordinategradients,globalcandidateaccountingandoriginalsourceposes. Reconstructall66originalsaftereachcall,including741movingpairs andfixed-movingcollisions;separatetheactualfixedintersectionsfromtheregion-distanceheuristic. Preservealltime-stops,sliceoverrunsandcompletepreparationwithinoriginalcaps. No solver/nativecallinaudit,no exclusion,andclosedthreecalllimitcannotbeextended.'":"'method':'Replay everydistinctphysicalmode trial,skippedequivalence,selectedclampandfullmodelbinding. Verifyallthreeuniquephysicalvectors,every savedpoint/evaluationcounter,63coordinategradients,globalcandidateaccountingand independently reconstructed originalsourceposes. Replayall66originalsaftereachcall:1456same-sheetpairs,264stockedges,90holes/10026holevertices. All276movingpairs are scored;fixed-fixed andfixed-movingpairs mustallpassbecauseharddomainsprotectthem. Preserveevery numerical/time-stop outcome,sliceoverrunandcompletepreparation withinoriginalcaps. No solver/nativecallinaudit,no exclusion,andclosedthreecalllimitcannotbeextended.'",
}
for old,new in changes.items():assert old in s,old;s=s.replace(old,new)
with (ROOT/'output/audit_h5_fifteen_cog_direct_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8').replace('h5-direct-pose-audit-process-20261107','h5-fifteen-cog-response-audit-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]","stages=[('audit','audit_h5_fifteen_cog_direct_response_20261107.py',90)]")
with (ROOT/'output/run_h5_fifteen_cog_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
