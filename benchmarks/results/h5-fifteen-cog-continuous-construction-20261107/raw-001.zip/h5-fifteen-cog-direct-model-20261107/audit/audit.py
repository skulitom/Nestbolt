from pathlib import Path
from hashlib import sha256
from itertools import product
import json,math,time,copy,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.affinity import translate
from h5_fifteen_cog_direct_model_20261107 import compile_model,Objective
from h5_fifteen_cog_direct_readback_20261107 import verify
from h5_four_column_physical_modes_20261107 import family_classes,physical_key
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-fifteen-cog-source-20261107';BASE=ROOT/'output/h5-fifteen-cog-direct-model-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(SOURCE/'library.json');checked=load(SOURCE/'audit/checks.json');assert checked['passed'] and digest(SOURCE/'library.json')==checked['library_sha256'];saved=load(BASE/'initial-mode-values.json');modes=saved['modes'];values=np.asarray(saved['values']);model=load(BASE/'model.json');assert model==compile_model(lib,modes,values) and verify(model,lib,modes,values);job=load(JOB);radius=lib['angle_scale_mm'];angle=lib['cog_seed'][0]['angle_radians'];parts=load(Q/'partitions.json')
def vertices(family,mi,xy,points,theta=0.):
    mode=lib['family_modes'][family][mi];theta=theta if family=='cog' else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx=xy[0]-(sign*px*c-py*s);ty=xy[1]-(sign*px*s+py*c);vv=np.array([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in points])
    if np.sum(vv[:,0]*np.roll(vv[:,1],-1)-vv[:,1]*np.roll(vv[:,0],-1))<0:vv=vv[::-1]
    return vv
def independent_shapes(family,mi,xy,theta=0.):return [Polygon(vertices(family,mi,xy,lib['families'][family][kind],theta)) for kind in ['original','clearance']]
def independent_pair_score(polys,placed):return sum(p.intersection(other[k]).area for k,p in enumerate(polys) for other in placed)
orth=load(BASE/'contact-candidates.json');geometries=load(BASE/'candidate-geometry.json');square=np.array(list(product([-.23,.23],repeat=2)));cogpieces=[vertices('cog',0,[0,0],p,angle) for p in parts['cog']['pieces']];geometry_controls=[];candidate_counts={}
for family in ['bracket','insert']:
    for mode in lib['family_modes'][family]:
        mi=mode['mode'];pieces=[vertices(family,mi,[0,0],p) for p in parts[family]['pieces']];hulls=[]
        for a,b in product(cogpieces,pieces):
            diff=(a[:,None,:]-b[None,:,:]).reshape(-1,2);hulls.append(MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
        template=shapely.union_all(hulls);bb=mode['center_bounds_mm'];domain=box(bb[0][0],bb[1][0],bb[0][1],bb[1][1]);blocked=shapely.union_all([translate(template,*seed['center']) for seed in lib['cog_seed']]).intersection(domain);free=domain.difference(blocked);record=next(g for g in geometries if g['family']==family and g['mode']==mi)
        assert record['piece_pair_hulls']==len(hulls) and record['certified_constraint'] is False
        for name,geom in [('template',template),('blocked',blocked),('free',free)]:assert geom.equals_exact(shape(record[name]),1e-8),(family,mi,name)
        points=set(map(tuple,shapely.get_coordinates(blocked)))|set(map(tuple,shapely.get_coordinates(free)))
        for geometry in shapely.get_parts(free):
            if not geometry.is_empty:points.add(tuple(geometry.representative_point().coords[0]))
        for xi,yi in product(range(9),repeat=2):points.add((bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])))
        centers=[list(p) for p in sorted({(min(max(x,bb[0][0]),bb[0][1]),min(max(y,bb[1][0]),bb[1][1])) for x,y in points},key=lambda p:(p[1],p[0]))];assert orth[family][mi]=={'mode':mi,'centers':centers} and record['candidate_centers']==len(centers);geometry_controls.append({'family':family,'mode':mi,'source_piece_hulls':len(hulls),'candidates':len(centers),'conditional_free_area_mm2':free.area,'allocation_excluded':False})
    candidate_counts[family]=sum(len(o['centers']) for o in orth[family])
write(OUT/'candidate-geometry-readback.json',geometry_controls)
placed=[]
for seed in lib['cog_seed']:
    i=seed['owner'];assert modes[i]==0 and values[2*i:2*i+2].tolist()==seed['center'] and values[48+i-9]==radius*seed['angle_radians'];placed.append(independent_shapes('cog',0,seed['center'],seed['angle_radians']))
records=load(BASE/'initializer-trials.json');assert [r['owner'] for r in records]==list(range(9));trials=0;total=0.
for r in records:
    i=r['owner'];identity=lib['identities'][i];family=identity[0];assert r['identity']==identity;expected=[]
    for option in orth[family]:
        for xy in option['centers']:
            value=independent_pair_score(independent_shapes(family,option['mode'],xy),placed);actual=r['candidates'][len(expected)];assert actual['mode']==option['mode'] and actual['center']==xy and abs(actual['score_mm2']-value)<1e-7;expected.append(actual);trials+=1
    best=min(expected,key=lambda t:(t['score_mm2'],t['mode'],t['center'][1],t['center'][0]));assert len(r['candidates'])==len(expected) and best==r['selected'] and modes[i]==best['mode'] and values[2*i:2*i+2].tolist()==best['center'];placed.append(independent_shapes(family,modes[i],best['center']));total+=best['score_mm2']
assert trials==4212
def source_rows(mm,x):
    rows=lib['fixed_source_rows'].copy()
    for i,o in enumerate(mm['owners']):
        family=o['identity'][0];mode=lib['family_modes'][family][o['mode']];theta=x[48+i-9]/radius if family=='cog' else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];rows.append({'part_id':family,'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[x[2*i]-(sign*px*c-py*s),x[2*i+1]-(sign*px*s+py*c)]}})
    return rows
rows=source_rows(model,values.tolist());assert rows==load(BASE/'seed-source66.json');source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert source==load(BASE/'seed-source-checks.json') and source['stock_failures']==0 and source['pair_failures']==14 and source['same_sheet_pairs']==1456 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
obj=Objective(model);energy,g,details=obj.evaluate(values,True);assert load(BASE/'initial-objective.json')=={'energy_mm2':energy,'gradient':g.tolist(),**details} and abs(total-energy)<1e-7
def independent_energy(mm,x):
    ps=[independent_shapes(o['identity'][0],o['mode'],x[2*i:2*i+2],x[48+i-9]/radius if i>=9 else 0.) for i,o in enumerate(mm['owners'])];return sum(ps[i][k].intersection(ps[j][k]).area for i,j in lib['pairs'] for k in [0,1])
bindings=0;vectors=1;scorecases=0
for i,identity in enumerate(lib['identities']):
    for mode in lib['family_modes'][identity[0]]:
        chosen=modes.copy();chosen[i]=mode['mode'];mm=compile_model(lib,chosen,values);assert verify(mm,lib,chosen,values);bindings+=1;vectors+=chosen!=modes;actual=Objective(mm).score(mm['initial']);assert abs(actual-independent_energy(mm,mm['initial']))<1e-6;scorecases+=1
assert bindings==67 and vectors==44
reference=np.zeros(63);gradient_cases=0
for entries in obj.geometry(values):
    for i,j in lib['pairs']:
        if entries[i][1].intersection(entries[j][1]).area<=0:continue
        for own,other in [(i,j),(j,i)]:
            gg,_,_=moving_boundary_gradient(entries[own][1],entries[other][1],entries[own][3]);reference[2*own:2*own+2]+=gg[:2]
            if own>=9:reference[48+own-9]+=gg[2]/radius
            gradient_cases+=1
assert np.max(np.abs(reference-g))<1e-7
derivatives=[]
for variation in [0,1]:
    chosen=modes.copy()
    if variation:chosen[:9]=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen[:9])]
    mm=compile_model(lib,chosen,values);bounds=np.asarray(mm['bounds']);margin=.03+np.arange(63)*.00037;point=np.clip(np.asarray(mm['initial'])+.137*np.sin(np.arange(63)*2**.5+.2+variation),bounds[:,0]+margin,bounds[:,1]-margin);val,gg=Objective(mm).evaluate(point);assert abs(val-independent_energy(mm,point))<1e-6;errors=[]
    for k in range(63):
        plus=point.copy();minus=point.copy();plus[k]+=1e-4;minus[k]-=1e-4;numeric=(independent_energy(mm,plus)-independent_energy(mm,minus))/2e-4;error=abs(numeric-gg[k]);assert error<.02+3e-6*abs(gg[k]),(variation,k,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':63,'maximum_absolute_error':max(errors)})
write(OUT/'derivative-controls.json',derivatives);directions=[];bounds=np.asarray(model['bounds'])
for step in [1e-7,1e-6,1e-5]:
    point=np.clip(values-step*g,bounds[:,0],bounds[:,1]);after=independent_energy(model,point);assert after<energy;directions.append({'step':step,'before':energy,'after':after})
write(OUT/'seed-descent-controls.json',directions);classes=family_classes(lib);assert classes=={'bracket':list(range(8)),'insert':[0,1,0,1],'cog':[0]};physical_cases=0
for family,options in lib['family_modes'].items():
    for left,right in product(options,options):
        a=independent_shapes(family,left['mode'],[0,0])[0];b=independent_shapes(family,right['mode'],[0,0])[0];assert (a.symmetric_difference(b).area<1e-8)==(classes[family][left['mode']]==classes[family][right['mode']]);physical_cases+=1
keys=set();key=physical_key(lib,classes,modes);equivalent=0
for i,identity in enumerate(lib['identities'][:9]):
    for mode in lib['family_modes'][identity[0]]:
        if mode['mode']==modes[i]:continue
        candidate=modes.copy();candidate[i]=mode['mode'];new=physical_key(lib,classes,candidate)
        if new==key:equivalent+=1
        else:keys.add(new)
assert len(keys)==33 and equivalent==5;write(OUT/'physical-mode-controls.json',{'passed':True,'family_classes':classes,'physical_equivalence_pair_controls':physical_cases,'source_owner_options':67,'physical_owner_options':57,'unique_single_owner_physical_neighbors':len(keys),'raw_current_equivalents':equivalent})
negatives=[]
for kind in ['mode','mirror','pivot','angle','stock','coordinate','pair','parameter_count','weight']:
    mm=copy.deepcopy(model)
    if kind=='mode':mm['owners'][0]['rotation_radians']+=.01
    elif kind=='mirror':mm['owners'][0]['mirrored']=not mm['owners'][0]['mirrored']
    elif kind=='pivot':mm['owners'][0]['source_center'][0]+=1
    elif kind=='angle':mm['owners'][9]['angle_coordinate']=49
    elif kind=='stock':mm['bounds'][0][0]+=1
    elif kind=='coordinate':mm['initial'][0]+=1
    elif kind=='pair':mm['pairs'].pop()
    elif kind=='parameter_count':mm['parameters']=62
    else:mm['objective_weights']['original_area']=3
    caught=False
    try:verify(mm,lib,modes,values)
    except AssertionError:caught=True
    assert caught;negatives.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',negatives);controls=load(Q/'audit/optimizer-controls.json');provenance=load(Q/'audit/tool-provenance.json');assert controls['passed']
for name,r in provenance['tool_files'].items():assert digest(ROOT/name)==r['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',provenance);prep=load(ROOT/'output/h5-fifteen-cog-initializer-process-20261107/prepare.json');assert prep['passed'] and prep['job']['closed'];charge=checked['complete_preparation_seconds']+prep['complete_seconds'];inputs=[Path(__file__),JOB,ROOT/'output/h5-fifteen-cog-initializer-process-20261107/prepare.json']+[ROOT/'output'/n for n in ['h5_fifteen_cog_direct_model_20261107.py','h5_fifteen_cog_direct_readback_20261107.py','h5_four_column_physical_modes_20261107.py','h5_direct_pose_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_original_overlap_gradient_v2_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/checks.json']]+[BASE/n for n in ['plan.json','checks.json','model.json','candidate-geometry.json','contact-candidates.json','initializer-trials.json','initial-mode-values.json','initial-objective.json','seed-source66.json','seed-source-checks.json']]+[Q/n for n in ['partitions.json','audit/optimizer-controls.json','audit/tool-provenance.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent source-center transforms, all12 candidate obstacle geometries, every finite trial and selection, all66source checks, all67owner-mode bindings/276pairs/63parameters, scalar gradient oracle,126central derivatives,3descent controls,81physical-equivalence cases and9corruptions. The source audit separately verifies fixed42 and every hard stock mode. Conditional seed obstacles have no exclusion authority. Verification only;no optimizer.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_trials_verified':trials,'candidate_geometry_modes':12,'source_owner_mode_bindings':bindings,'dynamic_mode_vectors':vectors,'independent_full_score_controls':scorecases,'scalar_batched_gradient_controls':gradient_cases,'independent_central_coordinates':126,'seed_descent_controls':3,'physical_equivalence_controls':physical_cases,'corruption_controls':9,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_same_sheet_pairs':source['same_sheet_pairs'],'source_valid66':source['valid'],'initial_objective_mm2':energy,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'complete_preparation_seconds':charge,'model_sha256':digest(BASE/'model.json'),'source_optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
