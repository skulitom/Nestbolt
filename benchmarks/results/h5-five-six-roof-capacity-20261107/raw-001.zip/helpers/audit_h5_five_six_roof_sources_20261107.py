"""Independent frame recipes, actual-source contacts and all16 partials."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-five-six-roof-sources-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def world(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);return np.array(parts[r['part_id']]['geometry'][0]['outer'])@np.array([[c,s],[-s,c]])+t['translation']
def distance(p,q):
    def directed(a,b):
        d=np.roll(b,-1,axis=0)-b;v=a[:,None,:]-b[None,:,:];t=np.clip((v*d[None,:,:]).sum(2)/(d*d).sum(1)[None,:],0,1);v-=t[:,:,None]*d[None,:,:];return float(np.sqrt((v*v).sum(2).min()))
    return min(directed(p,q),directed(q,p))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently derive source frame dimensions and both declared roof/block recipes. Reconstruct original polygons by matrix transforms, check every pool pair and frame contact with direct vertex-to-segment distances plus filled intersections, then all stock edges. Replay all16 complete original-source44 outputs, source identities, remaining identities and holes. Bind the unchanged verified short sheet and original analytic phase/pitch. No pool count becomes a packing upper bound, and no solver runs.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};recipe=load(SOURCE/'source-recipe.json');d=load(SOURCE/'cog-derivation.json');origin=recipe['origin'];gap=recipe['gap_mm'];stocks=recipe['source_stocks'];required=recipe['required_pair_gap_mm'];guard=recipe['stock_guard_mm'];fv=parts['frame']['geometry'][0]['outer'];fw=max(v[0] for v in fv)-min(v[0] for v in fv);fh=max(v[1] for v in fv)-min(v[1] for v in fv);row1=origin[1]+3*fw+3*gap;row2=row1+fw+gap;highest=row2+fw;lower=row2+fh;radius=d['radius_upper_mm'];pitch=d['axis_pitch_mm'];theta=d['rotation_radians'];c,s=math.cos(theta),math.sin(theta);center=np.array(d['source_center']);rot=np.array([[c,s],[-s,c]]);short=load(SHORT/'short12-source.json');base=[r for r in load(SOURCE/'fixed27-source.json') if r['sheet_id']=='sheet-0'];assert audit(job,short,stocks,required,guard)['valid'];allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};results=[];contact_count=0;holes=0;fullpairs=0;minimum=math.inf
for turned in [5,6]:
    folder=BASE/f'turned-{turned}';roof=load(folder/'roof-source.json');sites=load(folder/'sites.json');checks=load(folder/'pool-checks.json');assert len(roof)==6 and [r['copy_index'] for r in roof]==list(range(12,18));assert sum(r['transform']['rotation_radians']==math.pi/2 for r in roof)==turned
    x=origin[0]
    for i,r in enumerate(roof):
        ist=i<3 or turned==6 or i<5;angle=math.pi/2 if ist else 0.;xy=[origin[0]+i*(fh+gap),row1] if i<3 else [x,row2]
        if i>=3:x+=(fh if ist else fw)+gap
        assert r['transform']['rotation_radians']==angle and not r['transform']['mirrored'];assert np.allclose(world(r).min(0),xy,rtol=0,atol=1e-10)
    right=x-gap;blocks=[(4,2,origin[0]+radius,highest+gap+radius),(1,6,right+gap+radius,row1+radius)] if turned==6 else [(3,2,origin[0]+radius,highest+gap+radius),(1,3,origin[0]+radius+3*pitch,lower+gap+radius),(1,6,right+gap+radius,row1+radius)]
    expected=[(block,[xx,yy],[x0+xx*pitch,y0+yy*pitch]) for block,(nx,ny,x0,y0) in enumerate(blocks) for yy in range(ny) for xx in range(nx)];assert len(expected)==len(sites)
    for site,(block,grid,xy) in zip(sites,expected):assert site['block']==block and site['grid']==grid and site['center']==xy
    pv=[(np.array(parts['cog']['geometry'][0]['outer'])-center)@rot+site['center'] for site in sites];pp=list(map(Polygon,pv));frames=base+roof;ff=list(map(world,frames));fp=list(map(Polygon,ff))
    for rec in checks['pairs']:
        i,j=rec['sites'];a=pp[i].intersection(pp[j]).area;g=0. if a>0 else distance(pv[i],pv[j]);assert abs(a-rec['overlap_area_mm2'])<1e-7 and abs(g-rec['gap_mm'])<1e-8 and rec['passed']==(g+1e-7>=required);contact_count+=1
        if rec['passed']:minimum=min(minimum,g)
    for rec in checks['frames']:
        i=rec['site'];j=next(n for n,r in enumerate(frames) if r['copy_index']==rec['frame_copy']);a=pp[i].intersection(fp[j]).area;g=0. if a>0 else distance(pv[i],ff[j]);assert abs(a-rec['overlap_area_mm2'])<1e-7 and abs(g-rec['gap_mm'])<1e-8 and rec['passed']==(g+1e-7>=required);contact_count+=1
    for rec in checks['stock']:
        b=pp[rec['site']].bounds;st=stocks['sheet-0'];assert np.allclose(b,rec['bounds'],rtol=0,atol=1e-10);assert rec['passed']==(b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard)
    cases=load(folder/'cases.json');assert [r['omitted_site'] for r in cases]==(list(range(15)) if turned==5 else [None]);valid=0
    for case in cases:
        rows=load(folder/(case['case']+'-source.json'));saved=load(folder/(case['case']+'-checks.json'));assert rows[:18]==frames and rows[-12:]==short;chosen=[site for site in sites if site['site']!=case['omitted_site']]
        for i,(r,site) in enumerate(zip(rows[18:32],chosen)):
            assert r['part_id']=='cog' and r['copy_index']==i and r['transform']['rotation_radians']==theta and not r['transform']['mirrored'];assert np.allclose(world(r),pv[site['site']],rtol=0,atol=1e-10)
        ids={(r['part_id'],r['copy_index']) for r in rows};assert len(ids)==44 and list(map(list,sorted(allids-ids)))==load(BASE/'remaining-identities.json');fresh=audit(job,rows,stocks,required,guard);assert fresh==saved and fresh['valid']==case['source_valid44'];valid+=fresh['valid'];holes+=sum(len(parts[r['part_id']]['geometry'][0]['holes']) for r in rows);fullpairs+=fresh['same_sheet_pairs']
    results.append({'turned_frames':turned,'site_count':len(sites),'cases':len(cases),'source_valid44':valid})
assert [r['source_valid44'] for r in results]==[15,1];process=load(ROOT/'output/h5-five-six-roof-sources-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'patterns':results,'pool_contacts_independently_verified':contact_count,'minimum_passing_cog_pair_gap_mm':minimum,'source44_cases_verified':16,'valid_source44_cases':16,'same_sheet_pairs_across_cases':fullpairs,'original_holes_across_cases':holes,'remaining_brackets_per_case':6,'remaining_inserts_per_case':16,'complete_preparation_seconds_if_consumed':charge,'changed_frames_require_new_obstacle_masks':True,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
