"""Declared five/six-turned roof constructions with one short-sheet cog."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-five-six-roof-sources-20261107';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';PRIOR=ROOT/'output/h5-roof-component-area-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def normalized_frame(index,theta,xy):
    c,s=math.cos(theta),math.sin(theta);v=[(x*c-y*s,x*s+y*c) for x,y in frame]
    return {'part_id':'frame','copy_index':index,'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':False,'translation':[xy[k]-min(p[k] for p in v) for k in range(2)]}}
def cog(index,xy):return {'part_id':'cog','copy_index':index,'sheet_id':'sheet-0','transform':{'rotation_radians':phase,'mirrored':False,'translation':[xy[0]-(cx*cs-cy*sn),xy[1]-(cx*sn+cy*cs)]}}
def shape(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];return Polygon([(x*c-y*s+tx,x*s+y*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']])
OUT.mkdir();began=time.perf_counter();prior=load(PRIOR/'audit/checks.json');assert prior['passed'];assert load(SHORT/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed']
inputs=[Path(__file__),JOB,PRIOR/'audit/checks.json',SHORT/'short12-source.json',SHORT/'audit/checks.json',SOURCE/'source-recipe.json',SOURCE/'cog-derivation.json',SOURCE/'fixed27-source.json',SOURCE/'audit/checks.json',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Keep twelve source base frames and the audited short6bracket/5insert/1cog. Derive two different six-upper-frame orientation multisets: three turned frames in the first row, then two turned plus one unturned (count5) or three turned(count6). Retain the one source-derived6.75degree cog phase and axis pitch without a sweep. Count6 uses4x2 cog sites above the highest roof plus1x6 sites right of the roof starting above the base, giving14sites. Count5 uses3x2 above highest roof,1x3 in the fourth column above the lower unturned frame, and1x6 right of the second roof row, giving15sites; check every14-of15 subset. Source dimensions/gap/radius determine coordinates, not saved optimized states. Preserve all failures without phase/pitch adjustments. These fixed-source variants do not resume a closed optimizer. Broader historical all-frame models exist; neither class is claimed globally untested.','turned_counts':[5,6],'proposed_site_counts':[15,14],'declared_source44_cases':16,'inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'preparation_internal_cap_seconds':18,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'old_two_turned_obstacle_masks_reused':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};recipe=load(SOURCE/'source-recipe.json');deriv=load(SOURCE/'cog-derivation.json');short=load(SHORT/'short12-source.json');base=[r for r in load(SOURCE/'fixed27-source.json') if r['sheet_id']=='sheet-0'];assert len(base)==12 and len(short)==12
origin=recipe['origin'];gap=recipe['gap_mm'];stocks=recipe['source_stocks'];required=recipe['required_pair_gap_mm'];guard=recipe['stock_guard_mm'];frame=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in frame)-min(p[0] for p in frame);fh=max(p[1] for p in frame)-min(p[1] for p in frame);radius=deriv['radius_upper_mm'];pitch=deriv['axis_pitch_mm'];phase=deriv['rotation_radians'];cx,cy=deriv['source_center'];cs,sn=math.cos(phase),math.sin(phase);row1=origin[1]+3*fw+3*gap;row2=row1+fw+gap;highest=row2+fw;lower=row2+fh;allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};results=[]
for turned in [5,6]:
    folder=OUT/f'turned-{turned}';folder.mkdir();roof=[normalized_frame(12+i,math.pi/2,[origin[0]+i*(fh+gap),row1]) for i in range(3)];x=origin[0]
    for i in range(3):
        isturned=turned==6 or i<2;roof.append(normalized_frame(15+i,math.pi/2 if isturned else 0.,[x,row2]));x+=(fh if isturned else fw)+gap
    right=x-gap;blocks=[(4,2,origin[0]+radius,highest+gap+radius),(1,6,right+gap+radius,row1+radius)] if turned==6 else [(3,2,origin[0]+radius,highest+gap+radius),(1,3,origin[0]+radius+3*pitch,lower+gap+radius),(1,6,right+gap+radius,row1+radius)]
    sites=[]
    for block,(nx,ny,x0,y0) in enumerate(blocks):
        for yy in range(ny):
            for xx in range(nx):sites.append({'site':len(sites),'block':block,'grid':[xx,yy],'center':[x0+xx*pitch,y0+yy*pitch]})
    frames=base+roof;polys=[shape(cog(i,s['center'])) for i,s in enumerate(sites)];fp=list(map(shape,frames));pairchecks=[];framechecks=[];stockchecks=[]
    for i,j in combinations(range(len(sites)),2):
        distance=polys[i].distance(polys[j]);pairchecks.append({'sites':[i,j],'gap_mm':distance,'overlap_area_mm2':polys[i].intersection(polys[j]).area,'passed':distance+1e-7>=required})
    for i,p in enumerate(polys):
        for j,f in enumerate(fp):
            distance=p.distance(f);framechecks.append({'site':i,'frame_copy':frames[j]['copy_index'],'gap_mm':distance,'overlap_area_mm2':p.intersection(f).area,'passed':distance+1e-7>=required})
        b=p.bounds;s=stocks['sheet-0'];stockchecks.append({'site':i,'bounds':list(b),'passed':b[0]>=s[0]+guard and b[1]>=s[1]+guard and b[2]<=s[2]-guard and b[3]<=s[3]-guard})
    write(folder/'roof-source.json',roof);write(folder/'sites.json',sites);write(folder/'pool-checks.json',{'pairs':pairchecks,'frames':framechecks,'stock':stockchecks,'anonymous_sites_not_extra_source_copies':True,'pool_count_not_packing_capacity':True});cases=[]
    for omission in (list(range(15)) if turned==5 else [None]):
        selected=[s for s in sites if s['site']!=omission];assert len(selected)==14;rows=frames+[cog(i,s['center']) for i,s in enumerate(selected)]+short;used={(r['part_id'],r['copy_index']) for r in rows};remaining=sorted(allids-used);assert len(rows)==len(used)==44 and len(remaining)==22 and sum(f=='bracket' for f,i in remaining)==6 and sum(f=='insert' for f,i in remaining)==16
        check=audit(job,rows,stocks,required,guard);case=f'omit-{omission:02d}' if omission is not None else 'all14';write(folder/(case+'-source.json'),rows);write(folder/(case+'-checks.json'),check);cases.append({'case':case,'omitted_site':omission,'source_valid44':check['valid'],'pair_failures':check['pair_failures'],'stock_failures':check['stock_failures']});assert time.perf_counter()-began<18
    write(folder/'cases.json',cases);write(folder/'recipe.json',{'roof_row1_y':row1,'roof_row2_y':row2,'highest_roof_y':highest,'lower_unturned_top_y':lower if turned==5 else None,'roof_right_x':right,'blocks':[list(b) for b in blocks],'gap_mm':gap,'phase_radians':phase,'axis_pitch_mm':pitch,'radius_upper_mm':radius})
    results.append({'turned_roof_frames':turned,'source44_cases':len(cases),'source44_valid_cases':sum(r['source_valid44'] for r in cases),'anonymous_sites':len(sites),'failed_pool_pairs':sum(not r['passed'] for r in pairchecks),'failed_site_frame_pairs':sum(not r['passed'] for r in framechecks),'failed_stock_sites':sum(not r['passed'] for r in stockchecks)})
write(OUT/'remaining-identities.json',remaining);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'patterns':results,'source44_cases':16,'valid_source44_cases':sum(r['source44_valid_cases'] for r in results),'independent_audit_pending':True,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
