"""Preserve source-valid partials and exact fixed-core capacity exclusions."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-five-six-roof-capacity-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-five-six-inventory-bound-20261107';F=BASE/'audit';D=ROOT/'output/h5-five-six-roof-covers-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-roof-transfer-capacity-exclusions-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['fixed_first32_cases']==16 and front['five_turned_inventory_exclusions']==15 and front['six_turned_short_bracket_exclusions']==1 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-five-six-roof-sources-20261107',ROOT/'output/h5-roof-transfer-main-sync-20261107']+[ROOT/'output'/('h5-five-six-'+n+'-process-20261107') for n in ['roof-sources','roof-sources-audit','roof-covers','roof-covers-audit','inventory-bound','inventory-bound-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_five_six*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_five_six_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
S=ROOT/'output/h5-five-six-roof-sources-20261107'
copies=[(S/'plan.json','source-plan.json'),(S/'audit/checks.json','source-audit.json'),(D/'plan.json','cover-plan.json'),(D/'audit/checks.json','cover-audit.json'),(D/'audit/class-controls.json','continuous-class-controls.json'),(D/'audit/capacity-results.json','fixed44-capacities.json'),(BASE/'plan.json','inventory-plan.json'),(F/'checks.json','inventory-audit.json'),(F/'capacity-results.json','fixed32-capacities.json'),(ROOT/'output/h5-roof-transfer-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for n in ['roof-sources','roof-sources-audit','roof-covers','roof-covers-audit','inventory-bound','inventory-bound-audit']:
    copies.append((ROOT/'output'/('h5-five-six-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42407459619','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='66192d0d0862eb2f30c974c305376437df252e97'
write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
write(OUT/'next-step.json',{'status':'all16_exact_fixed_first32_cores_excluded','proposal':'Transfer one cog to the valid short6/5/1 with the earlier one-turned and three-turned upper-frame pools. For one-turned, validate every14-of15 subset. For three-turned, screen every14-of16 subset against all independently recomputed source pool contacts, retaining every witnessed failure; expected candidate empty pairs are[3,7],[3,15],[7,14],[14,15], not assumed valid. Validate every surviving44part source placement before any capacity model. Reuse one-turned complete bracket masks only after exact geometry/domain/mode equality, then extract NEW one-empty covers; derive all four previously absent insert masks. Three-turned requires entirely fresh world obstacles and all12mode masks. Necessary bounds alone never establish feasibility.','source_short_inventory':[6,5,1],'first_sheet_inventory':[18,6,16,14],'inherited_preparation_seconds':front['complete_preparation_seconds_if_consumed'],'charge_all_new_preparation':True,'complete_model_prepared':False,'optimizer_calls':0,'all_old_calls_remain_closed':True,'current_fixed_first32_remaining':0,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'H5_complete':False})
report=f'''# Five- and six-turned upper-frame capacity — 2026-11-07

**Sixteen source-valid 44-part partial layouts cannot extend to all 66 parts.**
The stronger result also rules out their exact eighteen-frame/fourteen-cog
first-sheet cores when every other original part can move between sheets.
No whole allocation or orientation class is excluded. H2/H5 remain open at
**60% completed milestone weight**; the preserved valid 64-part layout remains best.

[Source construction]({NAME}/source-plan.json) retains twelve turned base
frames and the valid short sheet containing six brackets, five inserts and
one cog. The six upper frames use either five or six quarter-turns. Their
coordinates derive from original source dimensions, the declared gap and the
existing charged 6.75-degree cog phase and source axis pitch. No phase/pitch
sweep or saved optimized placement is used. Five turned frames yield fifteen
cog sites and fifteen choices of fourteen; six turned frames yield fourteen
sites and one choice.

[Independent source replay]({NAME}/source-audit.json) verifies all sixteen
44-part partials, **718 pool contacts, 8,992 same-sheet pairs and 896 original
holes** across cases. Minimum passing cog gap is **0.301548 mm**. Each partial
still needs six brackets and sixteen inserts; partial validity is not a full
job result.

Changed geometry requires [fresh necessary-center covers]({NAME}/cover-plan.json).
Only the independently audited local cog inner rectangles are reused; every
world obstacle and mask is rebuilt. Eight bracket modes and four insert modes
use full physical stock domains. Closed cover boxes include every boundary
point and open interval that avoids fixed-frame conflict and permits the
declared zero/one empty cog site. Two source rectangular components cover
each L-shaped bracket; one covers each insert. Their swept occupied regions
are clipped to outward stock bounds and have definitely occupied fixed
source interiors removed.

[Independent exact readback]({NAME}/cover-audit.json) verifies **2,269 source
inner rectangles, 20 component bounds, 24 fresh mode masks and 70,912,992
continuous classes**. Separate signed-corner prefix counts classify every
continuous class; a separate interval-event sweep checks **48 exact
union-difference areas**. Conservative source body-area rounding is bounded
by 0.049153 mm²; lower bounds use 39,999 mm² per bracket and 19,799 per insert.

| Upper turned frames | Exact cases | Combined occupied area at most (mm²) | Bracket capacity at most |
|---|---:|---:|---:|
| Five | 15 | 370,518.393503 | 5 |
| Six | 1 | 520,032.836202 | 0 |

The remaining six brackets and sixteen inserts require **556,778 mm²**.
[All sixteen fixed 44-part layouts are excluded]({NAME}/fixed44-capacities.json).

[A broader inventory relaxation]({NAME}/inventory-plan.json) keeps only the
exact eighteen frames and fourteen cogs on the first sheet, releases all
twelve brackets, twenty-one inserts and the last cog, then ignores that last
cog entirely. The existing independently verified material definition and
target bound the entire second sheet's usable area by **465,326.048858 mm²**;
three or more sheets exceed the material target. All brackets and inserts
still require at least **895,767 mm²**.

[Independent inventory readback]({NAME}/inventory-audit.json) finds that the
fifteen five-turned cores remain short by at least **59,922.557639 mm²** even
under this relaxation. The six-turned core permits no first-sheet bracket,
so all twelve must fit on the short sheet: their lower area exceeds that
sheet by **14,661.951142 mm²**. [Every exact first32 core is excluded]({NAME}/fixed32-capacities.json).
Changing only the companion inventory cannot rescue these geometries.

| Bounded stage | Complete preparation (s) | Separate audit (s) |
|---|---:|---:|
| Source partials | 0.895462 | 1.070807 |
| Fresh covers and component capacity | 10.078285 | 16.112959 |
| Released companion inventory | 0.173062 | 0.253429 |

The [source]({NAME}/roof-sources-process.json), [cover]({NAME}/roof-covers-process.json)
and [inventory]({NAME}/inventory-bound-process.json) preparations plus all
inherited work total **30.001913 s** if consumed by a successor. Their separate
[source]({NAME}/roof-sources-audit-process.json), [cover]({NAME}/roof-covers-audit-process.json)
and [inventory]({NAME}/inventory-bound-audit-process.json) audits pass. All six
Job Objects close three processes under unchanged 2 GiB, CCD1 and single-thread
controls. No optimizer, retry or extension is opened.

[Next]({NAME}/next-step.json), validate one-cog transfers for the earlier
one-turned and three-turned source pools. The latter's two collided pool pairs
must both be removed before source replay; no candidate validity is assumed.
Old masks may be reused only for exactly matching geometry and modes; missing
insert masks and changed-world obstacles must be rebuilt.

Four earlier fixed arrangements and 440 whole-job allocation candidates
remain. Full66 source/native/material acceptance, product integration,
UI/CLI/MCP parity and the original H5 matrix remain required.

[Main and the working branch reached 66192d0d]({NAME}/prior-main-push-receipt.json)
by ordinary atomic fast-forward after all six prior checks passed and 52
protected files were verified. [Fresh CI]({NAME}/main-ci-at-review.json) records
**{success} passed / {live} live jobs**. This checkpoint awaits the next
ordinary push gate. Product code, README and releases remain unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve all evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 five-/six-turned upper-frame capacity:** [source and independent capacity audits]({{link}}) verify sixteen source-valid44 partials, 718 pool contacts and 8,992 same-sheet pairs. Rebuilt world obstacles and24 fresh mode masks cover70,912,992 continuous classes; independent rational/source checks and48 union-difference areas exclude all16 fixed44 layouts. Releasing all12 brackets,21 inserts and the last cog still excludes every exact18frame/14cog first-sheet core: five-turned cases lack at least59,922.557639 mm² combined area; six-turned forces all12 brackets onto a short sheet too small by14,661.951142 mm². No whole orientation class or allocation is excluded. No optimizer runs; consumed preparation totals30.001913 s and all bounded processes close. Next validate one-cog transfers for the earlier one-/three-turned pools, preserving all failed source choices and deriving any absent/changed covers. Four earlier arrangements and440 allocations remain, valid64 remains best, and H2/H5 stay open at60%. Main66192d0d has{success} passed/{live} live CI jobs; this checkpoint awaits the ordinary push gate. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [five-/six-turned upper-frame capacity](../benchmarks/results/{NAME}.md).
Sixteen source-valid44 partials are independently checked. Fresh necessary
covers verify70,912,992 continuous classes and48 exact occupied-area bounds;
all16 fixed layouts cannot extend to66. Even releasing every bracket, insert
and the last cog rules out these exact18frame/14cog first-sheet cores.
Five-turned cases lack at least59,922.557639 mm² combined area; six-turned
forces all12 brackets onto a short sheet too small by14,661.951142 mm².
No whole allocation or orientation class is excluded. No optimizer runs;
valid64 remains best. Consumed preparation totals30.001913 s. Next validate
one-cog transfers for the earlier one-/three-turned pools, preserving source
failures and rebuilding missing or changed geometry covers. Four earlier
arrangements and440 allocations remain. H2/H5 stay open at60%. Main66192d0d
has{success} passed/{live} live CI jobs; this checkpoint awaits the ordinary
push gate. Product and releases remain unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings)})
