"""Distinguish new direct-pair conflicts, propagate counts and recompute full areas."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-pair-source-20261109';DIRECT=ROOT/'output/h5-direct-overlay-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-direct-restriction-fixed-point-20261109';PREVIOUS=ROOT/'benchmarks/results/h5-pair-capacity-conflicts-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';OUT=ROOT/'output/h5-direct-pair-frontier-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(ROOT/'output/h5-all-direct-pair-batches-20261109/checks.json')['passed']
OUT.mkdir();began=time.perf_counter();batches=load(BASE/'batches.json');inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',BASE/'batches.json',BASE/'audit/plan.json',BASE/'audit/checks.json',ROOT/'output/h5-all-direct-pair-batches-20261109/checks.json',PRE/'audit/plan.json',PRE/'audit/checks.json'];processes=[];cost=load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed'];results=[]
for label,charge in [('h5-direct-pair-source',True),('h5-direct-pair-source-audit',False)]+[(f'h5-direct-pair-batch-{i:02d}'+suffix,suffix=='') for i in range(64) for suffix in ['', '-audit']]:
    folder=ROOT/'output'/(label+'-process-20261109');p=load(folder/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    if charge:cost+=p['complete_seconds']
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':charge});inputs.extend([folder/'process.json',folder/'opened.json'])
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-source.json');source=load(DIRECT/f'choice-{case:02d}-queries.json');old=load(PARENT/f'choice-{case:02d}-frontier.json');regions_source=load(PRE/f'choice-{case:02d}.json');graph=ROOT/source['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8;original=[int.from_bytes(raw[p*width:(p+1)*width],'little') for p in range(len(nodes))]
    prior=[0]*len(nodes);prior_edges=set()
    for edge in load(PREVIOUS/f'choice-{case:02d}-new-edges.json'):
        a,b=edge['left_current_position'],edge['right_current_position'];assert (a,b) not in prior_edges and not original[a]&(1<<b);prior_edges.add((a,b));prior[a]|=1<<b;prior[b]|=1<<a
    new=[0]*len(nodes);proofs={};seen=set();pair_count=failed=raw_known=prior_known=0
    for batch in batches:
        if batch['refinement_index']!=case:continue
        folder=BASE/f"pair-batch-{batch['batch_index']:02d}";audit=load(folder/'audit/checks.json');rows=load(folder/'query-results.json');assert audit['passed'] and len(rows)==batch['pair_count']==audit['complete_pairs'];assert [[r['left_query'],r['right_query']] for r in rows]==batch['pairs']
        inputs.extend([folder/'query-results.json',folder/'audit/checks.json',folder/'audit/plan.json'])
        for row in rows:
            q,r=row['left_query'],row['right_query'];assert (q,r) not in seen;seen.add((q,r));pair_count+=1
            if not row['failing_area_indices']:continue
            failed+=1;left=data['current_query_targets'][q];right=data['current_query_targets'][r];assert len(left)==len(right)==1 and left!=right;a,b=sorted((left[0],right[0]))
            if original[a]&(1<<b):assert original[b]&(1<<a);raw_known+=1;continue
            if prior[a]&(1<<b):assert prior[b]&(1<<a);prior_known+=1;continue
            assert (a,b) not in proofs;new[a]|=1<<b;new[b]|=1<<a;proofs[a,b]={'left_current_position':a,'right_current_position':b,'batch_index':batch['batch_index'],'left_query':q,'right_query':r}
    assert pair_count==data['pairs'] and failed==raw_known+prior_known+len(proofs)
    overlay=sorted(prior_edges|set(proofs));write(OUT/f'choice-{case:02d}-new-edges.json',[proofs[key] for key in sorted(proofs)]);write(OUT/f'choice-{case:02d}-edge-overlay.json',[list(edge) for edge in overlay])
    active=old['remaining_current_positions'];mask=sum(1<<p for p in active);cliques=[[int(v,16) for v in family] for family in source['root_clique_masks_hex']];rounds=[]
    for step in range(8):
        removed=[]
        for p in active:
            if not mask&(1<<p):continue
            allowed=mask&~(original[p]|prior[p]|new[p]|(1<<p));upper=[sum(bool(group&allowed) for group in family) for family in cliques];required=[8-int(nodes[p]['family']==f) for f in [0,1]]
            if any(a<b for a,b in zip(upper,required)):removed.append({'current_position':p,'upper':upper,'required':required})
        rounds.append({'pass_index':step,'removed':removed});mask&=~sum(1<<r['current_position'] for r in removed)
        if not removed:break
    retained=[p for p in active if mask&(1<<p)];counts=[sum(bool(group&mask) for group in family) for family in cliques];regions=[set(),set()]
    for row in regions_source['node_regions']:
        if mask&(1<<row['current_position']):regions[row['family']].update(map(tuple,row['regions_um']))
    regions=[sorted(group) for group in regions];areas=vertical_areas(*regions,regions_source['fixed_forbidden_clearance_regions_um']);required=[319992000000,158392000000,478384000000];fails=[f for f in range(3) if areas[f]<required[f]]
    summary={'refinement_index':case,'empty_sites':source['empty_sites'],'complete_declared_pairs':pair_count,'incompatible_query_pairs':failed,'already_original_graph_conflicts':raw_known,'already_previous_overlay_conflicts':prior_known,'new_unique_conflict_edges':len(proofs),'cumulative_overlay_edges':len(overlay),'input_nodes':len(active),'remaining_nodes':len(retained),'remaining_nodes_by_family':[sum(nodes[p]['family']==f for p in retained) for f in [0,1]],'clique_exclusions':len(active)-len(retained),'global_clique_upper_counts':counts,'family_and_joint_area_upper_um2':areas,'required_global_area_um2':required,'failing_area_indices':fails,'scope_excluded':bool(fails) or any(n<8 for n in counts),'clique_fixed_point':not rounds[-1]['removed']}
    write(OUT/f'choice-{case:02d}-frontier.json',{**summary,'input_active_positions':active,'remaining_current_positions':retained,'clique_rounds':rounds,'family_component_regions_um':[[list(r) for r in family] for family in regions]});results.append(summary)
    inputs.extend([BASE/f'choice-{case:02d}-source.json',DIRECT/f'choice-{case:02d}-queries.json',PARENT/f'choice-{case:02d}-frontier.json',PREVIOUS/f'choice-{case:02d}-new-edges.json',PRE/f'choice-{case:02d}.json',graph/'nodes.json',graph/'conflicts.bin'])
write(OUT/'case-results.json',results);write(OUT/'process-summary.json',processes)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Reconcile every frozen direct pair and exact singleton target. Distinguish original conflicts, prior14306overlay conflicts and genuinely new symmetric edges. Preserve complete cumulative overlay separately. Apply at most eight simultaneous root-clique passes and recompute all global occupied-envelope areas.','maximum_clique_passes':8,'complete_preparation_seconds_before_this_stage':cost,'optimizer_calls':0})
checks={'prepared':True,'complete_declared_pairs':sum(r['complete_declared_pairs'] for r in results),'incompatible_query_pairs':sum(r['incompatible_query_pairs'] for r in results),'new_unique_conflict_edges':sum(r['new_unique_conflict_edges'] for r in results),'cumulative_overlay_edges':sum(r['cumulative_overlay_edges'] for r in results),'clique_exclusions':sum(r['clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'provisional_scope_exclusions':sum(r['scope_excluded'] for r in results),'seconds':time.perf_counter()-began,'independent_audit_pending':True,'optimizer_calls':0};write(OUT/'checks.json',checks);print(checks);print(results)
