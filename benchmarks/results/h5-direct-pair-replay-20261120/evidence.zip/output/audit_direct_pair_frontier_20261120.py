"""Replay direct-pair evidence against original graph positions, geometry and time receipts."""
import hashlib
import json
from pathlib import Path

from h5_horizontal_segment_areas_20261109 import horizontal_segment_areas

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output"
RESULTS = ROOT / "benchmarks/results"
FRONT = OUTPUT / "h5-direct-pair-frontier-20261109"
SOURCE = OUTPUT / "h5-direct-pair-source-20261109"
PARENT = RESULTS / "h5-direct-restriction-fixed-point-20261109"
PRIOR = RESULTS / "h5-pair-capacity-conflicts-20261109"
UNIT_AREA = (39_999_000_000, 19_799_000_000)
bindings = {}


def read(path):
    return json.loads(path.read_bytes())


def bind(path, expected=None):
    key = path.relative_to(ROOT).as_posix()
    if key not in bindings:
        with path.open("rb") as stream:
            bindings[key] = hashlib.file_digest(stream, "sha256").hexdigest()
    if expected is not None:
        assert bindings[key] == expected, key


def bound_read(path):
    bind(path)
    return read(path)


def receipt(folder):
    data = bound_read(folder / "process.json")
    job = data["job"]
    assert data["passed"] and data["closed"] and job["closed"]
    assert job["active_processes"] == job["error_code"] == job["reason_code"] == 0
    return data["complete_seconds"]


def check_case(case, batches, geometry, stock):
    stem = f"choice-{case:02d}"
    source = bound_read(SOURCE / f"{stem}-source.json")
    data = bound_read(OUTPUT / f"h5-fixed29-complete-row-preflight-20261109/{stem}.json")
    graph = ROOT / data["graph"]
    nodes = bound_read(graph / "nodes.json")
    raw_path = graph / "conflicts.bin"
    bind(raw_path)
    raw = raw_path.read_bytes()
    width = (len(nodes) + 7) // 8
    assert len(raw) == len(nodes) * width
    active = bound_read(PARENT / f"{stem}-frontier.json")["remaining_current_positions"]
    prior = {(e["left_current_position"], e["right_current_position"])
             for e in bound_read(PRIOR / f"{stem}-new-edges.json")}
    positions = source["query_positions"]
    declared, novel, original_hits, prior_hits = set(), {}, 0, 0
    for batch in batches:
        if batch["refinement_index"] != case:
            continue
        index = batch["batch_index"]
        folder = SOURCE / f"pair-batch-{index:02d}"
        check = bound_read(folder / "audit/checks.json")
        result_path = folder / "query-results.json"
        key = result_path.relative_to(ROOT).as_posix()
        bind(result_path, bound_read(folder / "audit/plan.json")["inputs"][key])
        rows = read(result_path)
        assert check["passed"] and check["batch_index"] == index and check["refinement_index"] == case
        assert check["original_physical_records"] == source["physical_records"]
        assert len(rows) == check["complete_pairs"] == len(batch["pairs"])
        assert check["conditional_area_bounds"] == len(rows) * 3
        failures = 0
        for (q, r), row in zip(batch["pairs"], rows):
            assert (q, r) == (row["left_query"], row["right_query"]) and (q, r) not in declared
            declared.add((q, r))
            a, b = sorted((positions[q], positions[r]))
            assert source["current_query_targets"][q] == [positions[q]]
            assert source["current_query_targets"][r] == [positions[r]] and a != b
            families = [nodes[a]["family"], nodes[b]["family"]]
            required = [area * (8 - families.count(f)) for f, area in enumerate(UNIT_AREA)]
            required.append(sum(required))
            upper = row["family_and_joint_area_upper_um2"]
            failed = [f for f in range(3) if upper[f] < required[f]]
            assert required == row["required_area_um2"] and failed == row["failing_area_indices"]
            if failed:
                failures += 1
                original = bool(raw[a * width + b // 8] & (1 << (b % 8)))
                assert original == bool(raw[b * width + a // 8] & (1 << (a % 8)))
                if original:
                    original_hits += 1
                    assert (a, b) not in prior
                elif (a, b) in prior:
                    prior_hits += 1
                else:
                    assert (a, b) not in novel
                    novel[a, b] = (index, q, r)
        assert failures == check["verified_incompatible_query_pairs"]
    assert len(declared) == source["pairs"]
    proofs = bound_read(FRONT / f"{stem}-new-edges.json")
    assert len(proofs) == len(novel)
    assert [(p["left_current_position"], p["right_current_position"], p["batch_index"],
             p["left_query"], p["right_query"]) for p in proofs] == [
                 (*edge, *novel[edge]) for edge in sorted(novel)]
    overlay = prior.union(novel)
    assert bound_read(FRONT / f"{stem}-edge-overlay.json") == [list(edge) for edge in sorted(overlay)]
    cliques = [[sum(1 << p for p in group) for group in family]
               for family in bound_read(graph / "root-covers.json")]
    neighbors = [int.from_bytes(raw[p * width:(p + 1) * width], "little") | (1 << p)
                 for p in range(len(nodes))]
    for a, b in overlay:
        neighbors[a] |= 1 << b
        neighbors[b] |= 1 << a
    saved = bound_read(FRONT / f"{stem}-frontier.json")
    remaining = active.copy()
    assert saved["input_active_positions"] == active
    for index, step in enumerate(saved["clique_rounds"]):
        mask = sum(1 << p for p in remaining)
        removed = []
        for p in remaining:
            available = mask & ~neighbors[p]
            upper = [sum(bool(c & available) for c in family) for family in cliques]
            needed = [8 - int(f == nodes[p]["family"]) for f in (0, 1)]
            if any(u < n for u, n in zip(upper, needed)):
                removed.append(dict(current_position=p, upper=upper, required=needed))
        assert step == dict(pass_index=index, removed=removed)
        excluded = {r["current_position"] for r in removed}
        remaining = [p for p in remaining if p not in excluded]
        assert bool(removed) == (index < len(saved["clique_rounds"]) - 1)
    assert remaining == saved["remaining_current_positions"] and saved["clique_fixed_point"]
    counts = [sum(bool(c & mask) for c in group) for group in cliques]
    covers = bound_read(OUTPUT / f"h5-fixed29-clearance-domains-20261108/{stem}-covers.json")
    regions = [set(), set()]
    for p in remaining:
        node = nodes[p]
        for box in covers[p]["remaining_closed_anchor_boxes_um"]:
            for piece in geometry[node["geometry"]]["all_alias_component_outer_rectangles_um"]:
                rect = (max(stock[0], box[0] + piece[0]), max(stock[1], box[1] + piece[1]),
                        min(stock[2], box[2] + piece[2]), min(stock[3], box[3] + piece[3]))
                if rect[0] < rect[2] and rect[1] < rect[3]:
                    regions[node["family"]].add(rect)
    rectangles = [[list(rect) for rect in sorted(group)] for group in regions]
    assert rectangles == saved["family_component_regions_um"]
    upper = horizontal_segment_areas(*rectangles, data["fixed_forbidden_clearance_regions_um"])
    required = [8 * area for area in UNIT_AREA] + [8 * sum(UNIT_AREA)]
    failed = [f for f in range(3) if upper[f] < required[f]]
    summary = dict(refinement_index=case, empty_sites=data["empty_sites"],
                   complete_declared_pairs=len(declared),
                   incompatible_query_pairs=original_hits + prior_hits + len(novel),
                   already_original_graph_conflicts=original_hits, already_previous_overlay_conflicts=prior_hits,
                   new_unique_conflict_edges=len(novel), cumulative_overlay_edges=len(overlay),
                   input_nodes=len(active), remaining_nodes=len(remaining),
                   remaining_nodes_by_family=[sum(nodes[p]["family"] == f for p in remaining) for f in (0, 1)],
                   clique_exclusions=len(active) - len(remaining), global_clique_upper_counts=counts,
                   family_and_joint_area_upper_um2=upper, required_global_area_um2=required,
                   failing_area_indices=failed, scope_excluded=bool(failed) or min(counts) < 8,
                   clique_fixed_point=True)
    assert all(saved[k] == v for k, v in summary.items())
    return summary


def main():
    plan = bound_read(FRONT / "plan.json")
    for key, expected in plan["inputs"].items():
        bind(ROOT / key, expected)
    batches = bound_read(SOURCE / "batches.json")
    assert [b["batch_index"] for b in batches] == list(range(64))
    assert bound_read(SOURCE / "audit/checks.json")["passed"]
    base = OUTPUT / "h5-four-fixed29-current-areas-v3-20261108"
    geometry = bound_read(base / "geometries.json")
    stock = bound_read(base / "stock-cover.json")["outward_stock_rectangle_um"]
    cases = [check_case(c, batches, geometry, stock) for c in (1, 9)]
    assert cases == bound_read(FRONT / "case-results.json")
    processes = bound_read(FRONT / "process-summary.json")
    stages = ["h5-direct-pair-source"] + [f"h5-direct-pair-batch-{i:02d}" for i in range(64)]
    assert [p["stage"] for p in processes] == [s + suffix for s in stages for suffix in ("", "-audit")]
    seconds = bound_read(PARENT / "checks.json")["complete_preparation_seconds_if_consumed"]
    for p in processes:
        elapsed = receipt(OUTPUT / (p["stage"] + "-process-20261109"))
        charged = p["stage"] in stages
        assert p["charged"] == charged and p["complete_seconds"] == elapsed
        if charged:
            seconds += elapsed
    assert abs(seconds - plan["complete_preparation_seconds_before_this_stage"]) < 1e-8
    seconds += receipt(OUTPUT / "h5-direct-pair-frontier-process-20261120")
    bind(Path(__file__).resolve())
    bind(OUTPUT / "h5_horizontal_segment_areas_20261109.py")
    report = dict(passed=True, cases=cases, batch_count=len(batches), complete_preparation_seconds=seconds,
                  conditional_area_bounds=3 * sum(r["complete_declared_pairs"] for r in cases),
                  optimizer_calls=0, H5_complete=False)
    dest = FRONT / "audit"
    dest.mkdir()
    for name, value in [("checks", report), ("inputs", bindings)]:
        (dest / f"{name}.json").write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
