"""Freeze a fresh complete pair pilot on the audited direct-graph fixed point."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,time
from h5_pair_capacity_bitsets_20261109 import physical_columns,weight_planes,pair_areas
ROOT=Path(__file__).resolve().parents[1];DIRECT=ROOT/'output/h5-direct-overlay-reference-20261109';CURRENT=ROOT/'output/h5-direct-restriction-loop-20261109/round-01';PARENT=ROOT/'benchmarks/results/h5-direct-restriction-fixed-point-20261109';OUT=ROOT/'output/h5-direct-pair-source-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PARENT/'archive-checks.json')['passed'] and load(PARENT/'checks.json')['joint_conditional_clique_fixed_point'] and load(CURRENT/'audit/checks.json')['joint_fixed_point']
for label in ['h5-direct-restriction-round-01-audit','h5-direct-restriction-frontier-audit']:
    process=load(ROOT/'output'/(label+'-process-20261109')/'process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),ROOT/'output/h5_pair_capacity_bitsets_20261109.py',PARENT/'archive-checks.json',PARENT/'checks.json',CURRENT/'audit/plan.json',CURRENT/'audit/checks.json',ROOT/'output/h5-direct-restriction-frontier-20261109/audit/plan.json',ROOT/'output/h5-direct-restriction-frontier-20261109/audit/checks.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'];cases=[];batches=[]
for label in ['h5-pair-capacity-controls','h5-direct-overlay-controls']:
    folder=ROOT/'output'/(label+'-20261109');assert load(folder/'checks.json')['passed'];inputs.extend([folder/'checks.json',folder/'source-bindings.json'])
    for name,h in load(folder/'source-bindings.json').items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
for case in [1,9]:
    data=load(DIRECT/f'choice-{case:02d}-queries.json');front=load(PARENT/f'choice-{case:02d}-frontier.json');active=set(front['remaining_current_positions']);rows=load(CURRENT/f'choice-{case:02d}-queries.json');maps=[{int(k,16):int(v,16) for k,v in family} for family in load(CURRENT/f'choice-{case:02d}-signatures.json')];count=len(data['query_positions']);full=(1<<count)-1
    assert [r['current_position'] for r in rows]==data['query_positions'] and data['query_targets']==[[p] for p in data['query_positions']]
    masks=[[],[]];weights=[];pieces=[]
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index']!=case:continue
        path=ROOT/piece['folder']/'atoms.json';inputs.append(path);records=load(path);pieces.append({'path':path.relative_to(ROOT).as_posix(),'offset':len(weights),'count':len(records)})
        for b,i,weight in records:
            masks[0].append(full^maps[0][int(b,16)]);masks[1].append(full^maps[1][int(i,16)]);weights.append(weight)
    columns=[physical_columns(values,count) for values in masks];planes=weight_planes(weights);width=(len(weights)+7)//8
    for family in [0,1]:
        with (OUT/f'choice-{case:02d}-family-{family}-columns.bin').open('xb') as f:
            for column in columns[family]:f.write(column.to_bytes(width,'little'))
    for q in range(count):assert pair_areas(columns[0][q],columns[1][q],columns[0][q],columns[1][q],planes)==rows[q]['family_and_joint_area_upper_um2']
    targets=[[p] if p in active else [] for p in data['query_positions']];eligible=[q for q in range(count) if targets[q]];anchors=[];rankings=[]
    for family in [0,1]:
        required=data['required_by_reference_family_um2'][family];ordered=sorted((q for q in eligible if data['query_families'][q]==family),key=lambda q:(min(Fraction(a,r) for a,r in zip(rows[q]['family_and_joint_area_upper_um2'],required)),q));chosen=ordered[:16];assert len(chosen)==16;anchors.extend(chosen);rankings.append(chosen)
    anchors=sorted(anchors);anchor_set=set(anchors);pairs=[]
    for anchor in anchors:
        current=[sorted([anchor,q]) for q in eligible if q!=anchor and not(q in anchor_set and q<anchor)]
        pairs.extend(current);batches.append({'batch_index':len(batches),'refinement_index':case,'anchor_query':anchor,'pairs':current,'pair_count':len(current),'hard_cap_seconds':30,'audit_hard_cap_seconds':30})
    assert len(pairs)==len(set(map(tuple,pairs)))==32*len(eligible)-528
    record={'refinement_index':case,'query_count':count,'physical_records':len(weights),'column_bytes':width,'weights':weights,'physical_pieces':pieces,'query_families':data['query_families'],'query_positions':data['query_positions'],'current_query_targets':targets,'eligible_queries':eligible,'anchors':anchors,'anchors_by_family':rankings,'pairs':len(pairs),'anchor_selection':'Sixteen current direct references per family with smallest exact minimum audited single-area/required ratio, query-index tie; every other eligible current direct reference as partner; duplicate anchor pairs removed. All targets singleton and distinct.'}
    write(OUT/f'choice-{case:02d}-source.json',record);cases.append({'refinement_index':case,'queries':count,'eligible_queries':len(eligible),'current_targets':len(active),'physical_records':len(weights),'anchors':len(anchors),'complete_declared_pairs':len(pairs),'single_bounds_replayed':3*count})
    inputs.extend([DIRECT/f'choice-{case:02d}-queries.json',PARENT/f'choice-{case:02d}-frontier.json',CURRENT/f'choice-{case:02d}-queries.json',CURRENT/f'choice-{case:02d}-signatures.json'])
write(OUT/'batches.json',batches);write(OUT/'case-results.json',cases)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Fresh finite pair pilot on the complete direct-query graph with its certified14306-edge overlay and audited8343 fixed-point mask. Transpose all current direct physical covers and reproduce every single-reference bound before any pair evaluation. Freeze balanced anchors and complete current partners. Prior6650-query pair pilot retained as historical evidence; current input rows/masks differ.','inherited_numeric_preparation_seconds':load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed'],'scope_frozen_before_pair_evaluation':True,'pair_batches':len(batches),'producer_cap_seconds':30,'audit_cap_seconds':30,'optimizer_calls':0})
checks={'passed':True,'complete_queries':sum(r['queries'] for r in cases),'current_targets':sum(r['current_targets'] for r in cases),'physical_records':sum(r['physical_records'] for r in cases),'single_area_bounds_replayed':sum(r['single_bounds_replayed'] for r in cases),'declared_pair_batches':len(batches),'declared_pair_queries':sum(r['complete_declared_pairs'] for r in cases),'source_pair_bounds_evaluated':0,'seconds':time.perf_counter()-began,'H5_complete':False};write(OUT/'checks.json',checks);print(checks);print(cases)
