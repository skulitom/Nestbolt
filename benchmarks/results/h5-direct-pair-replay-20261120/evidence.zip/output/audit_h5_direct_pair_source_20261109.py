"""Independently verify current direct covers, all targets and the frozen pair scope."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,time,numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-pair-source-20261109';DIRECT=ROOT/'output/h5-direct-overlay-reference-20261109';CURRENT=ROOT/'output/h5-direct-restriction-loop-20261109/round-01';PARENT=ROOT/'benchmarks/results/h5-direct-restriction-fixed-point-20261109';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-direct-pair-source-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={};seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
verify(plan['inputs']);verify(load(CURRENT/'audit/plan.json')['inputs']);verify(load(ROOT/'output/h5-direct-restriction-frontier-20261109/audit/plan.json')['inputs'])
expected_batches=[];membership=physical_total=targets_total=pairs_total=0
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-source.json');direct=load(DIRECT/f'choice-{case:02d}-queries.json');rows=load(CURRENT/f'choice-{case:02d}-queries.json');active=set(load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions']);qcount=len(direct['query_positions']);full=(1<<qcount)-1;maps=[{int(k,16):int(v,16) for k,v in values} for values in load(CURRENT/f'choice-{case:02d}-signatures.json')];weights=[];expected_masks=[[],[]];pieces=[]
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index']!=case:continue
        path=ROOT/piece['folder']/'atoms.json';records=load(path);pieces.append({'path':path.relative_to(ROOT).as_posix(),'offset':len(weights),'count':len(records)})
        for b,i,w in records:weights.append(w);expected_masks[0].append(full-maps[0][int(b,16)]);expected_masks[1].append(full-maps[1][int(i,16)])
    assert data['query_count']==qcount and data['physical_records']==len(weights) and data['weights']==weights and data['physical_pieces']==pieces
    width=(len(weights)+7)//8;assert data['column_bytes']==width
    for family in [0,1]:
        path=BASE/f'choice-{case:02d}-family-{family}-columns.bin';raw=path.read_bytes();assert len(raw)==qcount*width;array=np.frombuffer(raw,dtype=np.uint8).reshape(qcount,width);bits=np.unpackbits(array,axis=1,bitorder='little');assert not bits[:,len(weights):].any()
        recovered=np.packbits(bits[:,:len(weights)],axis=0,bitorder='little').T.copy();assert [int.from_bytes(row.tobytes(),'little') for row in recovered]==expected_masks[family];membership+=qcount*len(weights);bindings[path.relative_to(ROOT).as_posix()]=sha256(raw).hexdigest();del bits,recovered
    assert direct['query_targets']==[[p] for p in direct['query_positions']] and data['query_positions']==direct['query_positions'] and data['query_families']==direct['query_families']
    targets=[[p] if p in active else [] for p in direct['query_positions']];assert data['current_query_targets']==targets;flat=[p for values in targets for p in values];assert len(flat)==len(set(flat)) and set(flat)==active
    eligible=[q for q,values in enumerate(targets) if values];assert data['eligible_queries']==eligible
    anchors=[];rankings=[]
    for family in [0,1]:
        ranked=[]
        for q in eligible:
            if direct['query_families'][q]!=family:continue
            ratios=[Fraction(rows[q]['family_and_joint_area_upper_um2'][f],direct['required_by_reference_family_um2'][family][f]) for f in range(3)];ranked.append((min(ratios),q))
        selected=[q for _,q in sorted(ranked)[:16]];assert len(selected)==16;anchors.extend(selected);rankings.append(selected)
    anchors.sort();assert data['anchors']==anchors and data['anchors_by_family']==rankings
    unique=set()
    for anchor in anchors:
        current=[]
        for other in eligible:
            if other==anchor or other in anchors and other<anchor:continue
            pair=tuple(sorted((anchor,other)));assert pair not in unique and targets[anchor][0]!=targets[other][0];unique.add(pair);current.append(list(pair))
        expected_batches.append({'batch_index':len(expected_batches),'refinement_index':case,'anchor_query':anchor,'pairs':current,'pair_count':len(current),'hard_cap_seconds':30,'audit_hard_cap_seconds':30})
    assert len(unique)==data['pairs'];pairs_total+=len(unique);targets_total+=len(flat);physical_total+=len(weights)
assert load(BASE/'batches.json')==expected_batches and len(expected_batches)==64 and pairs_total==265920 and targets_total==8343 and physical_total==151597
for p in [Path(__file__),process_path,process_path.parent/'opened.json']+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Inverse complete physical transpose, zero-padding check, exact original physical mask/weight/order reconstruction. Independently reconstruct every direct current target and balanced exact-rational anchor ranking, every distinct partner pair and complete frozen batch scope; verify current fixed-point proof bindings.'})
checks={'passed':True,'membership_bits_verified':membership,'physical_records':physical_total,'current_targets':targets_total,'declared_pair_batches':len(expected_batches),'declared_pair_queries':pairs_total,'source_pair_bounds_evaluated':0,'complete_preparation_seconds_if_consumed':plan['inherited_numeric_preparation_seconds']+process['complete_seconds'],'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
