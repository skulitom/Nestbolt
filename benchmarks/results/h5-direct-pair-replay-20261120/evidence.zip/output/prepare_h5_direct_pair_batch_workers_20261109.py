"""Generate isolated once-only workers from the unchanged audited pair algorithms."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(path,text):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
for audit in [False,True]:
    stem='audit' if audit else 'build';old=ROOT/'output'/f'{stem}_h5_pair_capacity_batch_20261109.py';text=old.read_text(encoding='utf-8')
    substitutions=[('h5-pair-capacity-source-20261109','h5-direct-pair-source-20261109'),('h5-pair-capacity-source-audit-process-20261109','h5-direct-pair-source-audit-process-20261109')] if not audit else [('h5-pair-capacity-source-20261109','h5-direct-pair-source-20261109'),('h5-pair-capacity-batch-','h5-direct-pair-batch-'),('output/h5-combined-reference-20261109','output/h5-direct-restriction-loop-20261109'),("f'round-00/choice-","f'round-01/choice-")]
    for before,after in substitutions:assert before in text,before;text=text.replace(before,after)
    save(ROOT/'output'/f'{stem}_h5_direct_pair_batch_20261109.py',text)
template=(ROOT/'output/run_h5_pair_capacity_batch_00_stage_20261109.py').read_text(encoding='utf-8')
for index in range(64):
    for audit in [False,True]:
        suffix='-audit' if audit else '';file_suffix='_audit' if audit else '';stem='audit' if audit else 'build'
        text=template.replace('build_h5_pair_capacity_batch_20261109.py',f'{stem}_h5_direct_pair_batch_20261109.py').replace('h5-pair-capacity-batch-00-process-20261109',f'h5-direct-pair-batch-{index:02d}{suffix}-process-20261109').replace("str(SCRIPT),'0'",f"str(SCRIPT),'{index}'")
        save(ROOT/'output'/f'run_h5_direct_pair_batch_{index:02d}{file_suffix}_stage_20261109.py',text)
admin=(ROOT/'output/run_h5_remaining_pair_batches_20261109.py').read_text(encoding='utf-8')
for before,after in [('h5-all-pair-capacity-batches-20261109','h5-all-direct-pair-batches-20261109'),('h5-pair-capacity-batch-','h5-direct-pair-batch-'),('run_h5_pair_capacity_batch_','run_h5_direct_pair_batch_'),('h5-pair-capacity-source-20261109','h5-direct-pair-source-20261109')]:assert before in admin,before;admin=admin.replace(before,after)
save(ROOT/'output/run_h5_remaining_direct_pair_batches_20261109.py',admin)
print({'workers':2,'wrappers':128,'admin_drivers':1,'stages_opened':0})
