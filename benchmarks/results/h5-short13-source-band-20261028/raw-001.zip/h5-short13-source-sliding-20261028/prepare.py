"""Prepare all13 short-sheet source movers, with one deterministic geometry-selected start."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import shape,box,mapping
from shapely.affinity import affine_transform
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-cog-transfer-20261028';OUT=ROOT/'output/h5-short13-source-sliding-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'free').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();geom.EPS=.0126
assert load(BASE/'result-audit/checks.json')['passed'];modes=load(BASE/'modes.json');shapes=[shape(m['geometry']) for m in modes];assert len(modes)==46
paths=[BASE/n for n in ['plan.json','modes.json','fixed9.json','search/attempts.json','result-audit/prefix-readbacks.json','result-audit/checks.json','preflight/checks.json','obstacle-pairs.json']]+[ROOT/'output/h5-short13-necessary-model-20261028/response-audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',Path(geom.__file__)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'search_seconds':60,'shared_seconds':90,'maximum_runs':1,'retry_permitted':False,'initial_grid_x_points':31,'initial_grid_y_points':5,'initial_selection_seconds':20,'initial_source_prefixes':635,'maximum_positional_stages':8,'per_stage_maxiter':1000,'per_stage_maxfun':2500,'random_restarts':0,'continuous_minimization_starts':1,'required_pair_gap_mm':.21170867250963943,'construction_extra_mm':geom.EPS,'stock_guard_mm':3000*32*2**-23,
 'method':'A new actual-source13-mover construction: all7 brackets,5 inserts and1 cog move on the short stock. None of the previous9 fixed originals remains fixed. Reuse36 declared source cog phases, all8 bracket modes and2 insert outer classes with exact source-configuration obstacles. From each of the635 independently source-valid12-part prefixes, evaluate the missing insert in both modes on a31x5 whole-stock anchor grid; select one least-penalty initial state, with an initial-selection cap20seconds inside the shared60-second search. Existing-prefix source-obstacle penalty must be numerically zero. Run one joint26-coordinate L-BFGS/mode descent from that selected state, at most8 stages, no random restart or external optimizer rerun. The old fixed-neighbor enumeration and all-angle necessary model remain closed. Every original remains mandatory. A source13 candidate still requires independent original-ring/stock readback; it is not a full66 or H5 witness. No native call.'})
for i,g in enumerate(shapes):
    a,b,c,d=g.bounds;free=box(6.5+geom.EPS-a,6.5+geom.EPS-b,1493.5-geom.EPS-c,319.4269023299994-geom.EPS-d);write(OUT/'free'/f'{i:02d}.json',mapping(free))
oldpairs={tuple(p) for p in load(BASE/'obstacle-pairs.json')};pairs=[];reused=created=0
for i in range(46):
    for j in range(i,46):
        if i<36 and j<36:continue
        if (i,j) in oldpairs:g=shape(load(BASE/'obstacles'/f'{i:02d}-{j:02d}.json'));reused+=1
        elif (j,i) in oldpairs:g=affine_transform(shape(load(BASE/'obstacles'/f'{j:02d}-{i:02d}.json')),[-1,0,0,-1,0,0]);reused+=1
        else:g=geom.obstacle(shapes[i],shapes[j],.21170867250963943);created+=1
        assert g.is_valid and not g.is_empty;write(OUT/'obstacles'/f'{i:02d}-{j:02d}.json',mapping(g));pairs.append([i,j])
fixed=load(BASE/'fixed9.json');attempts=load(BASE/'search/attempts.json');prefixes=load(BASE/'result-audit/prefix-readbacks.json');items=[{'family':'bracket','copy_index':i,'allowed_modes':list(range(36,44))} for i in range(7)]+[{'family':'insert','copy_index':i,'allowed_modes':[44,45]} for i in range(5)]+[{'family':'cog','copy_index':14,'allowed_modes':list(range(36))}]
lookup={(r['family'],r['copy_index']):i for i,r in enumerate(items)}
def placement(mi,xy,copy):
    m=modes[mi];return {'part_id':m['family'],'copy_index':copy,'transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in range(2)]}}
bank=[]
for index,p in enumerate(prefixes):
    a=attempts[p['attempt']];rows=fixed+[placement(a['bracket_mode'],a['bracket_anchor'],6),placement(a['cog_mode'],a['cog_anchor'],14),placement(p['insert_mode'],p['insert_anchor'],3)];anchors=[None]*13;selected=[None]*13
    for row in rows:
        i=lookup[row['part_id'],row['copy_index']];t=row['transform'];mi=next(j for j,m in enumerate(modes) if m['family']==row['part_id'] and m['mirrored']==t['mirrored'] and abs(m['angle']-t['rotation_radians'])<1e-12);selected[i]=mi;anchors[i]=[t['translation'][k]-modes[mi]['source_translation_offset'][k] for k in range(2)]
    assert [i for i,x in enumerate(anchors) if x is None]==[11];bank.append({'prefix':index,'modes':selected,'anchors':anchors})
assert len(bank)==635 and len(items)==13 and created==36 and reused==379
write(OUT/'prefix-bank.json',bank);write(OUT/'modes.json',modes);write(OUT/'moving.json',items);write(OUT/'obstacle-pairs.json',pairs)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_modes':46,'all13_originals_free':True,'source_valid_prefixes':len(bank),'reused_pair_obstacles':reused,'new_bracket_pair_obstacles':created,'total_pair_obstacles':len(pairs),'unused_cog_cog_obstacles_omitted':True,'initial_grid_candidates':635*2*31*5,'search_opened':False,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
