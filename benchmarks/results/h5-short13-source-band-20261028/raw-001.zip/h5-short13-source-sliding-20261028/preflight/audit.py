"""Independent source geometry, reuse provenance and analytic-gradient checks before search."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,Point,shape
from shapely.affinity import translate,affine_transform
from h5_short13_source_objective import SourceObjective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-source-sliding-20261028';OLD=ROOT/'output/h5-short-cog-transfer-20261028';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
obj=SourceObjective(BASE);job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};shapes=[];required=plan['required_pair_gap_mm'];provenance={};oldpairs={tuple(v) for v in load(OLD/'obstacle-pairs.json')}
for i,m in enumerate(obj.modes):
    c,s=math.cos(m['angle']),math.sin(m['angle']);sign=-1 if m['mirrored'] else 1;tx,ty=m['source_translation_offset'];g=Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[m['family']]['geometry'][0]['outer']]);assert g.equals_exact(shape(m['geometry']),1e-10) and g.is_valid;shapes.append(g)
    a,b,c,d=g.bounds;assert list(obj.free[i].bounds)==[6.5+.0126-a,6.5+.0126-b,1493.5-.0126-c,319.4269023299994-.0126-d]
pair_samples=0
for i,j in load(BASE/'obstacle-pairs.json'):
    saved=obj.obstacles[i*46+j]
    if (i,j) in oldpairs or (j,i) in oldpairs:
        oi,oj=(i,j) if (i,j) in oldpairs else (j,i);p=OLD/'obstacles'/f'{oi:02d}-{oj:02d}.json';provenance[p.relative_to(ROOT).as_posix()]=digest(p);prior=shape(load(p));prior=prior if (oi,oj)==(i,j) else affine_transform(prior,[-1,0,0,-1,0,0]);assert saved.equals_exact(prior,0)
    for xy in [(-500,-400),(-280,0),(-130,95),(0,0),(130,-95),(280,0),(500,400),(0,320),(0,-320)]:
        gap=shapes[i].distance(translate(shapes[j],*xy));inside=saved.covers(Point(*xy));assert inside or gap>required;assert gap>required or inside;pair_samples+=1
write(OUT/'reused-inputs.json',provenance)
bank=load(BASE/'prefix-bank.json');keep=[i for i in range(13) if i!=11];prefix_scores=[]
for state in bank:
    value,_,_=obj.evaluate_points([state['anchors'][i] for i in keep],[state['modes'][i] for i in keep]);assert value<1e-8;prefix_scores.append(value)
state=bank[0];modes=state['modes'].copy();modes[11]=44;xy=[v if v is not None else [749.873,101.397] for v in state['anchors']];x=np.asarray(xy).reshape(-1)+.013*np.sin(np.arange(26)+1);value,gradient,diag=obj.evaluate(x,modes);h=1e-5;errors=[]
for k in range(26):
    a=x.copy();b=x.copy();a[k]+=h;b[k]-=h;numeric=(obj.evaluate(a,modes)[0]-obj.evaluate(b,modes)[0])/(2*h);errors.append(abs(numeric-gradient[k]));assert errors[-1]<.003
extra_checks=[]
for mi in [44,45]:
    b=obj.free[mi].bounds;grid=np.asarray([[b[0],b[1]],[(b[0]+b[2])/2,(b[1]+b[3])/2],[b[2],b[3]]]);scores=obj.extra_penalties([state['anchors'][i] for i in keep],[state['modes'][i] for i in keep],mi,grid)
    for a,score in zip(grid,scores):
        z=np.asarray(xy);z[11]=a;ms=state['modes'].copy();ms[11]=mi;full=obj.evaluate(z.reshape(-1),ms)[0];assert abs(full-score)<1e-7;extra_checks.append(float(abs(full-score)))
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_source_modes':46,'source_pair_samples':pair_samples,'reused_pair_obstacles_byte_geometry_equal':len(provenance),'source12_prefixes_with_zero_penalty':len(bank),'maximum_prefix_penalty':max(prefix_scores),'gradient_components_checked':26,'maximum_gradient_error':max(errors),'batched_insert_score_checks':len(extra_checks),'maximum_batch_score_error':max(extra_checks),'all13_originals_free_and_mandatory':True,'search_opened':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
