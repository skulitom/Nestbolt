"""One bounded all-source13-mover search, from one deterministic best grid insertion."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-source-sliding-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class Budget(Exception):pass
def child():
    import numpy as np
    import scipy
    from scipy.optimize import minimize
    from h5_short13_source_objective import SourceObjective
    assert load(BASE/'preflight/checks.json')['passed'];obj=SourceObjective(BASE);bank=load(BASE/'prefix-bank.json');keep=[i for i in range(13) if i!=11];grids={}
    for mi in [44,45]:
        b=obj.free[mi].bounds;grids[mi]=np.asarray([[x,y] for x in np.linspace(b[0],b[2],31) for y in np.linspace(b[1],b[3],5)])
    start=time.perf_counter();deadline=start+60;initial_deadline=start+20;initial=None;grid_scores=[];grid_candidates=0
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'search_seconds':60,'initial_selection_seconds':20,'initial_grid_candidates':196850,'continuous_minimization_starts':1,'maximum_stages':8,'random_restarts':0,'scipy_version':scipy.__version__,'numpy_version':np.__version__,'native_calls':0})
    for state in bank:
        if time.perf_counter()>=initial_deadline:break
        xy=[state['anchors'][i] for i in keep];ms=[state['modes'][i] for i in keep]
        for mi in [44,45]:
            scores=obj.extra_penalties(xy,ms,mi,grids[mi]);grid_candidates+=len(scores);k=int(np.argmin(scores));value=float(scores[k]);grid_scores.append({'prefix':state['prefix'],'extra_mode':mi,'best_grid_index':k,'best_score':value})
            if initial is None or value<initial['value']:
                full_xy=[a if a is not None else grids[mi][k].tolist() for a in state['anchors']];full_modes=state['modes'].copy();full_modes[11]=mi;full_value,_,diag=obj.evaluate(np.asarray(full_xy).reshape(-1),full_modes);assert abs(full_value-value)<1e-7;initial={'prefix':state['prefix'],'extra_mode':mi,'grid_index':k,'value':full_value,'anchors':full_xy,'modes':full_modes,'diagnostics':diag}
    assert initial is not None;selection_seconds=time.perf_counter()-start;write(OUT/'initial-grid-scores.json',grid_scores);write(OUT/'initial-state.json',initial)
    modes=initial['modes'].copy();x=np.asarray(initial['anchors']).reshape(-1);best=None;calls=0;stages=[];trials=[];changes=[];improvements=[]
    def evaluate(z,mi,kind):
        nonlocal calls,best
        if time.perf_counter()>=deadline:raise Budget()
        value,gradient,diag=obj.evaluate(z,mi);calls+=1
        if best is None or value<best['value']:
            best={'value':float(value),'anchors':np.asarray(z).reshape(-1,2).tolist(),'modes':list(mi),'evaluation':calls,'seconds':time.perf_counter()-start,'diagnostics':diag};improvements.append({'evaluation':calls,'seconds':best['seconds'],'value':float(value),'kind':kind,**diag})
        return value,gradient,diag
    status='STAGE_LIMIT'
    try:
        value,_,_=evaluate(x,modes,'initial')
        for stage in range(8):
            if value<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            before=time.perf_counter();before_value=value;stage_modes=list(modes)
            def fun(z):v,g,_=evaluate(z,stage_modes,f'position-{stage}');return v,g
            result=minimize(fun,x,jac=True,method='L-BFGS-B',options={'maxiter':1000,'maxfun':2500,'maxls':20,'ftol':1e-12,'gtol':1e-6});x=np.asarray(result.x);value,_,diag=evaluate(x,modes,f'position-{stage}-returned');stages.append({'stage':stage,'seconds':time.perf_counter()-before,'start_value':before_value,'returned_value':float(value),'success':bool(result.success),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev)})
            if value<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            accepted=0
            for i,item in enumerate(obj.moving):
                old=modes[i];chosen=old;chosen_value=value
                for alternative in item['allowed_modes']:
                    if alternative==old:continue
                    trial=list(modes);trial[i]=alternative;v,_,_=evaluate(x,trial,f'mode-{stage}-{i}');trials.append({'stage':stage,'item':i,'from_mode':old,'alternative':alternative,'value':float(v)})
                    if v<chosen_value-1e-8:chosen,chosen_value=alternative,v
                if chosen!=old:changes.append({'stage':stage,'item':i,'from_mode':old,'to_mode':chosen,'before_value':float(value),'after_value':float(chosen_value)});modes[i]=chosen;value=chosen_value;accepted+=1
            if value<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            if accepted==0 and result.success:status='LOCAL_STATIONARY';break
    except Budget:status='TIME_LIMIT'
    if best is None:best={'value':initial['value'],'anchors':initial['anchors'],'modes':initial['modes'],'evaluation':0,'seconds':selection_seconds,'diagnostics':initial['diagnostics']}
    elapsed=time.perf_counter()-start;write(OUT/'best.json',best);write(OUT/'best-source13.json',obj.placements(best['anchors'],best['modes']));write(OUT/'position-stages.json',stages);write(OUT/'mode-trials.json',trials);write(OUT/'accepted-mode-changes.json',changes);write(OUT/'improvements.json',improvements)
    write(OUT/'result.json',{'status':status,'closed':True,'search_seconds':elapsed,'initial_selection_seconds':selection_seconds,'initial_grid_candidates_evaluated':grid_candidates,'initial_prefix_mode_batches':len(grid_scores),'initial_bank_complete':grid_candidates==196850,'selected_initial_prefix':initial['prefix'],'initial_value':initial['value'],'continuous_minimization_starts':1,'random_restarts':0,'positional_stages_returned':len(stages),'objective_evaluations':calls,'mode_trials':len(trials),'accepted_mode_changes':len(changes),'best_value':best['value'],'best_diagnostics':best['diagnostics'],'all13_originals_free_and_mandatory':True,'source_readback_required':True,'source_valid_claimed':False,'full66_witness':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents};inputs['output/h5_short13_source_objective.py']=digest(ROOT/'output/h5_short13_source_objective.py');write(OUT/'plan.json',{'inputs':inputs,'search_seconds':60,'shared_seconds':90,'maximum_runs':1,'retry_permitted':False,'continuous_minimization_starts':1,'random_restarts':0});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed response; call closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
