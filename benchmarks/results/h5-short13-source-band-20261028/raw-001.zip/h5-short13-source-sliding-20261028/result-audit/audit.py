"""Replay the initial insertion scores, then independently read every original of the result."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
import numpy as np
from h5_short13_source_objective import SourceObjective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-source-sliding-20261028';SEARCH=BASE/'search';OUT=BASE/'result-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(SEARCH/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(BASE/'preflight/reused-inputs.json').items():assert digest(ROOT/n)==h,n
assert load(BASE/'preflight/checks.json')['passed'];plan=load(BASE/'plan.json');result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');best=load(SEARCH/'best.json');initial=load(SEARCH/'initial-state.json');bank=load(BASE/'prefix-bank.json');scores=load(SEARCH/'initial-grid-scores.json');obj=SourceObjective(BASE)
assert result['closed'] and result['continuous_minimization_starts']==1 and result['random_restarts']==0 and result['search_seconds']<60 and process['seconds']<90 and process['exit_code']==0 and not process['timeout']
assert result['initial_bank_complete'] and len(scores)==1270 and result['initial_grid_candidates_evaluated']==196850
keep=[i for i in range(13) if i!=11];grids={}
for mi in [44,45]:
    b=obj.free[mi].bounds;grids[mi]=np.asarray([[x,y] for x in np.linspace(b[0],b[2],31) for y in np.linspace(b[1],b[3],5)])
selected=0;global_min=float('inf')
for k,state in enumerate(bank):
    xy=[state['anchors'][i] for i in keep];ms=[state['modes'][i] for i in keep]
    for j,mi in enumerate([44,45]):
        got=obj.extra_penalties(xy,ms,mi,grids[mi]);which=int(np.argmin(got));v=float(got[which]);saved=scores[2*k+j];assert saved=={'prefix':k,'extra_mode':mi,'best_grid_index':which,'best_score':v};global_min=min(global_min,v);selected+=len(got)
assert abs(initial['value']-global_min)<1e-7 and initial['prefix']==result['selected_initial_prefix']
value,_,diag=obj.evaluate(np.asarray(best['anchors']).reshape(-1),best['modes']);assert value==best['value']==result['best_value'] and diag==best['diagnostics']==result['best_diagnostics'];rows=load(SEARCH/'best-source13.json');assert rows==obj.placements(best['anchors'],best['modes'])
assert len(load(SEARCH/'position-stages.json'))==result['positional_stages_returned']<=8 and len(load(SEARCH/'mode-trials.json'))==result['mode_trials'] and len(load(SEARCH/'accepted-mode-changes.json'))==result['accepted_mode_changes']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');expected=[('bracket',i) for i in range(7)]+[('insert',i) for i in range(5)]+[('cog',14)];read=audit(job,rows,{'sheet-1':[6.5,6.5,1493.5,319.4269023299994]},plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected);write(OUT/'source13-readback.json',read);write(OUT/'failed-pairs.json',[p for p in read['pairs'] if not p['passed']]);write(OUT/'failed-stock.json',[p for p in read['stock'] if not p['passed']])
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'initial_grid_candidates_replayed':selected,'initial_source_prefixes':len(bank),'selected_initial_prefix':initial['prefix'],'initial_value':initial['value'],'status':result['status'],'search_seconds':result['search_seconds'],'shared_seconds':process['seconds'],'objective_evaluations':result['objective_evaluations'],'positional_stages':result['positional_stages_returned'],'mode_trials':result['mode_trials'],'accepted_mode_changes':result['accepted_mode_changes'],'source_summary':{k:v for k,v in read.items() if k not in ['pairs','stock']},'source13_valid':read['valid'],'all13_free_and_mandatory':True,'closed_search_not_restarted':True,'infeasibility_claimed':False,'full66_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
