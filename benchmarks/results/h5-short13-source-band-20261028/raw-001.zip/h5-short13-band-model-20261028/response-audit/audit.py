"""Read the closed mixed-separation response; fully verify optional constraints if assigned."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
from itertools import combinations
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-band-model-20261028';SEARCH=BASE/'search'
GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json')
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90
assert result['closed'] and result['solver_calls']==1 and opened['maximum_calls']==1
assert digest(SEARCH/'model.pb')==digest(BASE/'model.pb')==load(BASE/'model-audit/checks.json')['model_sha256']
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes())
status=cp_model_pb2.CpSolverStatus.Name(response.status)
assert status==result['status'] and status in ['UNKNOWN','FEASIBLE','OPTIMAL','INFEASIBLE']
assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts']
assert bool(response.solution)==result['has_solution']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters())
assert params.max_time_in_seconds==60 and params.num_search_workers==4 and list(params.ignore_subsolvers)==['fj']
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log
printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1))
assert abs(printed-Decimal(str(response.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes())
checked=active_intervals=0;allocation=None
if response.solution:
    sol=list(response.solution);assert len(sol)==len(model.variables)==18640
    for v,value in zip(model.variables,sol):assert any(a<=value<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    def literal(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def present(ct):return all(literal(v) for v in ct.enforcement_literal)
    intervals={i:(expr(ct.interval.start),expr(ct.interval.end),expr(ct.interval.size),present(ct)) for i,ct in enumerate(model.constraints) if ct.WhichOneof('constraint')=='interval'}
    active_intervals=sum(v[3] for v in intervals.values())
    for i,ct in enumerate(model.constraints):
        checked+=1
        if not present(ct):continue
        kind=ct.WhichOneof('constraint')
        if kind=='linear':
            value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs))
            assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='lin_max':assert expr(ct.lin_max.target)==max(expr(e) for e in ct.lin_max.exprs)
        elif kind=='bool_or':assert any(literal(v) for v in ct.bool_or.literals)
        elif kind=='exactly_one':assert sum(literal(v) for v in ct.exactly_one.literals)==1
        elif kind=='table':
            assert not ct.table.negated;tuple_value=tuple(expr(e) for e in ct.table.exprs);width=len(tuple_value)
            assert tuple_value in {tuple(ct.table.values[j:j+width]) for j in range(0,len(ct.table.values),width)}
        elif kind=='interval':a,b,size,on=intervals[i];assert a+size==b and size>0 and on
        elif kind=='no_overlap_2d':
            rects=[]
            for x,y in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
                assert intervals[x][3]==intervals[y][3]
                if intervals[x][3]:rects.append((*intervals[x][:2],*intervals[y][:2]))
            for a,b in combinations(rects,2):assert a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2]
        elif kind=='cumulative':
            events={}
            for ix,dem in zip(ct.cumulative.intervals,ct.cumulative.demands):
                a,b,size,on=intervals[ix]
                if not on:continue
                d=expr(dem);events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
            amount=0;cap=expr(ct.cumulative.capacity)
            for point in sorted(events):amount+=events[point];assert 0<=amount<=cap
        else:raise AssertionError(kind)
    assert load(SEARCH/'assignment.json')=={v.name:value for v,value in zip(model.variables,sol)}
    mapping=load(BASE/'mapping.json');variants={v['id']:v for v in load(GEO/'variants.json')};poses=[]
    allocation={family:0 for family in ['bracket','insert','cog']}
    for record in mapping['items']:
        selected=[o for o in record['options'] if sol[o['selector']]];assert len(selected)==1
        choice=selected[0];family=record['family'];copy=record['index'] if family=='bracket' else record['index']-7 if family=='insert' else 14
        allocation[family]+=1
        poses.append({'index':record['index'],'family':family,'copy_index':copy,'sheet':1,'variant':choice['variant'],
            'anchor_um':[sol[v] for v in record['coordinates']],
            'anchor_kind':variants[choice['variant']]['anchor'],
            'cog_source_angle_unselected':family=='cog','source_geometry_validated':False})
    assert allocation=={'bracket':7,'insert':5,'cog':1}
    write(OUT/'all13-necessary-poses.json',poses);write(OUT/'allocation.json',allocation)
else:assert not (SEARCH/'assignment.json').exists()
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'closed':True,
    'solver_calls':1,'search_started':'Starting search at' in log,'presolve_closed_model':'Problem closed by presolve.' in log,
    'returned_branches':response.num_branches,'returned_conflicts':response.num_conflicts,
    'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],
    'shared_process_seconds':process['seconds'],'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],
    'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'fj_excluded_in_parameters':True,
    'fj_excluded_in_search_log':'1 ignored subsolver: [fj]' in log,'all13_required':True,
    'has_necessary_assignment':bool(response.solution),'assignment_constraints_verified':checked,
    'active_optional_intervals_verified':active_intervals,'allocation':allocation,
    'actual_cog_angles_selected':False,'source_geometry_validated':False,'native_calls':0,
    'short_7_5_1_excluded':status=='INFEASIBLE','full66_exclusion_claimed':False,'H5_complete':False})
print(load(OUT/'checks.json'))
