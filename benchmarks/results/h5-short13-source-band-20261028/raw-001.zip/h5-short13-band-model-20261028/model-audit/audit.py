"""Byte-identical base plus independent full readback of every band-area extension."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-band-model-20261028';OLD=ROOT/'output/h5-short13-necessary-model-20261028';AREA=ROOT/'output/h5-cog-band-area-20261028';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'model-audit/checks.json')['passed'] and load(AREA/'audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes());old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model.pb').read_bytes())
assert not p.HasField('objective') and not p.HasField('floating_point_objective') and not p.solution_hint.vars and not p.assumptions and not p.search_strategy
vi,ci=len(old.variables),len(old.constraints);assert (vi,ci)==(12197,15458)
assert all(a.SerializeToString()==b.SerializeToString() for a,b in zip(old.variables,p.variables)) and all(a.SerializeToString()==b.SerializeToString() for a,b in zip(old.constraints,p.constraints))
mp=load(BASE/'mapping.json');orig=load(OLD/'mapping.json');assert {k:v for k,v in mp.items() if k!='extension'}==orig;ex=mp['extension'];assert ex['old_counts']==[vi,ci];g=load(AREA/'geometry.json');LOW=-9223372036854775808;HIGH=9223372036854775807
def variable(ix,name,domain):
    global vi
    assert ix==vi and p.variables[ix].name==name and list(p.variables[ix].domain)==domain;vi+=1
def expr(e,co,offset=0):assert dict(zip(e.vars,e.coeffs))=={k:v for k,v in co.items() if v} and e.offset==offset
def linear(ix,co,domain,enforcement=[]):
    global ci
    assert ix==ci;ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==enforcement and dict(zip(ct.linear.vars,ct.linear.coeffs))==co and list(ct.linear.domain)==domain;ci+=1
def maximum(ix,target,exprs):
    global ci
    assert ix==ci;ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='lin_max' and not ct.enforcement_literal;expr(ct.lin_max.target,*target);assert len(ct.lin_max.exprs)==len(exprs)
    for e,expected in zip(ct.lin_max.exprs,exprs):expr(e,*expected)
    ci+=1
cg=mp['items'][12]['coordinates'][1];assert len(ex['bins'])==35
for i,((lo,hi),r) in enumerate(zip(g['center_bins_um'],ex['bins'])):
    assert r['bin']==i;z=r['selector'];variable(z,f'cog_ybin_{i}',[0,1]);assert len(r['constraints'])==2;linear(r['constraints'][0],{cg:1},[lo,HIGH],[z]);linear(r['constraints'][1],{cg:1},[LOW,hi],[z])
assert ex['bin_exactly_one']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal and list(ct.exactly_one.literals)==[r['selector'] for r in ex['bins']];ci+=1
source_rects=[r for r in orig['rectangles'] if orig['items'][r['item']]['family']!='cog'];assert len(source_rects)==178 and len(ex['bands'])==10;heights=0
for bi,((a,b),band) in enumerate(zip(g['bands_um'],ex['bands'])):
    assert band['band']==bi and len(band['rectangles'])==178;terms={r['selector']:g['records'][i*10+bi]['source_area_lower_um2'] for i,r in enumerate(ex['bins'])}
    def term(v,w):terms[v]=terms.get(v,0)+w
    for k,(r,saved) in enumerate(zip(source_rects,band['rectangles'])):
        base={'item':r['item'],'variant':r['variant'],'component':r['component'],'presence':r['presence'],'rectangle_um':r['bounds_um']};assert {q:saved[q] for q in base}==base and saved['full_band']==(bi==0);x,ry,xx,rt=r['bounds_um'];w,h=xx-x,rt-ry;z=r['presence']
        if bi==0:assert saved=={**base,'full_band':True};term(z,w*h);continue
        y=mp['items'][r['item']]['coordinates'][1];yl,yh=list(p.variables[y].domain);assert len(saved['variables'])==4 and len(saved['constraints'])==5;low,high,height,on=saved['variables'];stem=f'band_{bi}_rect_{k}'
        for ix,suffix,domain in [(low,'low',[max(a,yl+ry),max(a,yh+ry)]),(high,'high',[min(b,yl+rt),min(b,yh+rt)]),(height,'height',[0,h]),(on,'on',[0,h])]:variable(ix,stem+'_'+suffix,domain)
        c=saved['constraints'];maximum(c[0],({low:1},0),[({y:1},ry),({},a)]);maximum(c[1],({high:-1},0),[({y:-1},-rt),({},-b)]);maximum(c[2],({height:1},0),[({high:1,low:-1},0),({},0)]);linear(c[3],{on:1,height:-1},[0,0],[z]);linear(c[4],{on:1},[0,0],[-z-1]);term(on,w);heights+=1
    linear(band['capacity_constraint'],{v:c for v,c in terms.items() if c},[LOW,g['stock_width_um']*(b-a)])
assert vi==len(p.variables) and ci==len(p.constraints)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'prior_variables_byte_identical':len(old.variables),'prior_constraints_byte_identical':len(old.constraints),'added_variables_verified':vi-len(old.variables),'added_constraints_verified':ci-len(old.constraints),'complete_center_bins':35,'exact_selected_rectangle_band_heights':heights,'whole_stock_rectangle_areas':178,'area_capacity_constraints':10,'all13_required':True,'all_real_cog_angles_retained':True,'every_original_mode_preserved':True,'no_objective_hints_or_assumptions':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
