"""Strict extension of the closed necessary model with exact band-area necessities."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-short13-necessary-model-20261028';GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';AREA=ROOT/'output/h5-cog-band-area-20261028';OUT=ROOT/'output/h5-short13-band-model-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(AREA/'audit/checks.json')['passed'] and load(OLD/'model-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[OLD/n for n in ['model.pb','model.pbtxt','mapping.json','model-audit/checks.json']]+[GEO/n for n in ['variants.json','stock.json']]+[AREA/n for n in ['plan.json','geometry.json','audit/checks.json','audit/necessity-proof.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'ignore_subsolvers':['fj'],'method':'Keep every variable and constraint of the audited closed all-free short13 model unchanged. Add a complete exactly-one partition of cog Y into35 integer bins. For each of10 fixed horizontal bands, sum the audited all-angle original-cog area lower bound and the exact areas of the selected disjoint source-contained noncog rectangles intersecting the band, and cap by relaxed stock width times band height. Every noncog area uses exact min/max intersection heights and optional-mode activation; the full-stock band directly uses full source-contained rectangle areas. This is a material geometric strengthening, not a retry of the previous model. Every angle and every original mode remains covered. Audit the full extension before the sole bounded call. No source/native/H5 claim follows from a necessary assignment.'})
m=cp_model.CpModel();assert m.proto.parse_text_format((OLD/'model.pbtxt').read_text(encoding='utf-8'));oldn=[len(m.proto.variables),len(m.proto.constraints)];mp=load(OLD/'mapping.json');g=load(AREA/'geometry.json');cy=m.get_int_var_from_proto_index(mp['items'][12]['coordinates'][1]);zs=[];binmap=[]
for i,(lo,hi) in enumerate(g['center_bins_um']):
    z=m.new_bool_var(f'cog_ybin_{i}');zs.append(z);cts=[m.add(cy>=lo),m.add(cy<=hi)]
    for ct in cts:ct.only_enforce_if(z)
    binmap.append({'bin':i,'selector':z.index,'constraints':[c.index for c in cts]})
one=m.add_exactly_one(zs);bands=[]
for bi,(a,b) in enumerate(g['bands_um']):
    terms=[g['records'][i*10+bi]['source_area_lower_um2']*z for i,z in enumerate(zs)];rects=[]
    for r in mp['rectangles']:
        if mp['items'][r['item']]['family']=='cog':continue
        assert r['kind']=='coarse';i=r['item'];yix=mp['items'][i]['coordinates'][1];y=m.get_int_var_from_proto_index(yix);z=m.get_bool_var_from_proto_index(r['presence']);x,ry,xx,rt=r['bounds_um'];w=xx-x;h=rt-ry
        rec={'item':i,'variant':r['variant'],'component':r['component'],'presence':z.index,'rectangle_um':r['bounds_um']}
        if bi==0:terms.append(w*h*z);rec['full_band']=True
        else:
            k=len(rects);yl,yh=list(m.proto.variables[yix].domain);stem=f'band_{bi}_rect_{k}'
            low=m.new_int_var(max(a,yl+ry),max(a,yh+ry),stem+'_low');high=m.new_int_var(min(b,yl+rt),min(b,yh+rt),stem+'_high');height=m.new_int_var(0,h,stem+'_height');on=m.new_int_var(0,h,stem+'_on')
            cs=[m.add_max_equality(low,[y+ry,a]),m.add_min_equality(high,[y+rt,b]),m.add_max_equality(height,[high-low,0]),m.add(on==height).only_enforce_if(z),m.add(on==0).only_enforce_if(~z)]
            rec.update({'full_band':False,'variables':[v.index for v in [low,high,height,on]],'constraints':[c.index for c in cs]});terms.append(w*on)
        rects.append(rec)
    cap=m.add(sum(terms)<=g['stock_width_um']*(b-a));bands.append({'band':bi,'rectangles':rects,'capacity_constraint':cap.index})
assert m.validate()=='' and m.export_to_file(str(OUT/'model.pb')) and m.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{**mp,'extension':{'old_counts':oldn,'bins':binmap,'bin_exactly_one':one.index,'bands':bands}})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(m.proto.variables),'constraints':len(m.proto.constraints),'prior_variables':oldn[0],'prior_constraints':oldn[1],'added_variables':len(m.proto.variables)-oldn[0],'added_constraints':len(m.proto.constraints)-oldn[1],'all13_required':True,'all_real_cog_angles':True,'exact_source_band_constraints':10,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
