"""Independent rational triangle-cap proof and original-polygon corroboration."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-band-area-20261028';OUT=BASE/'audit';GEO=ROOT/'output/h5-short13-necessary-geometry-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def signed_area(poly):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1]))/2 if poly else F(0)
def triangle_cap(tri,cut,below):
    # A triangle clipped by one horizontal line; crossing points are sorted
    # by edge traversal, independently of the producer's whole-polygon clip.
    poly=[];prev=tri[-1];prev_d=(prev[1]-cut)*(1 if below else -1)
    for cur in tri:
        d=(cur[1]-cut)*(1 if below else -1)
        if (d<=0)!=(prev_d<=0):
            t=prev_d/(prev_d-d);poly.append((prev[0]+t*(cur[0]-prev[0]),prev[1]+t*(cur[1]-prev[1])))
        if d<=0:poly.append(cur)
        prev,prev_d=cur,d
    return signed_area(poly)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
extra=[ROOT/'output/h5-rotation-independent-geometry-20261026/original-cog-proof.json',ROOT/'output/h5-short13-source-sliding-20261028/prefix-bank.json',ROOT/'output/h5-short13-source-sliding-20261028/modes.json',ROOT/'output/h5-short13-source-sliding-20261028/preflight/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in extra+[BASE/'plan.json',BASE/'geometry.json',BASE/'prepared.json']}})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(extra[-1])['passed'];g=load(BASE/'geometry.json');old=load(extra[0]);job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');outer=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];v=[(F(x)*1000,F(y)*1000) for x,y in outer];A=abs(signed_area(v));assert A==F(*g['original_filled_area_um2']) and math.floor(A)==g['original_filled_area_floor_um2']
center=old['center'];centered=[((F(x)-F(center[0]))*1000,(F(y)-F(center[1]))*1000) for x,y in outer];assert centered==[(F(*x)*1000,F(*y)*1000) for x,y in old['centered_vertices_rational']]
assert len(centered)==80 and max(x*x+y*y for x,y in centered)<=140001**2 and g['outer_radius_um']==140003 and (140003-140001)**2>2
faces=g['outer_faces'];ps=[(F(*x),F(*y)) for x,y in g['outer_vertices_rational_um']];assert len(ps)==len(faces)==64
for i,(nx,ny,d) in enumerate(faces):
    s=d//140003;assert d==140003*s and (s-1)**2<nx*nx+ny*ny<=s*s
    assert all(nx*x+ny*y<=d for x,y in ps)
    for x,y in [ps[i-1],ps[i]]:assert nx*x+ny*y==d
for i,(a,b) in enumerate(zip(ps,ps[1:]+ps[:1])):
    assert a[0]*b[1]-a[1]*b[0]>0
    c=ps[(i+2)%64];assert (b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])>0
assert signed_area(ps)==F(*g['outer_area_um2'])
stock=load(GEO/'stock.json');assert g['stock_width_um']==stock['capacity_um'][0]==1487040
lower=F(*stock['relaxed_bounds_rational'][1])*1000;upper=F(*stock['relaxed_bounds_rational'][3])*1000
assert g['relaxed_stock_band_um']==[math.floor(lower),math.ceil(upper)]==g['bands_um'][0]
bands=g['bands_um'];assert bands==load(BASE/'plan.json')['bands_um'] and len(bands)==10 and len(set(tuple(b) for b in bands))==10 and all(6480<=a<b<=319447 for a,b in bands)
domain=next(d['bounds_um'] for d in load(GEO/'domains.json') if d['variant']==12);bins=g['center_bins_um'];assert bins==[[lo,min(lo+999,domain[3])] for lo in range(domain[1],domain[3]+1,1000)] and len(bins)==35
strips=next(v for v in load(GEO/'variants.json') if v['id']==12)['source_capacity_rectangles_um'];assert len(strips)==16
for i,(x,y,xx,yy) in enumerate(strips):
    assert x<xx and y<yy and max(u*u+w*w for u in [x,xx] for w in [y,yy])<109113**2
    if i:assert strips[i-1][3]<y
assert len(g['records'])==350;triangles=[[(F(0),F(0)),a,b] for a,b in zip(ps,ps[1:]+ps[:1])];gains=[];caps_checked=0
for i,(lo,hi) in enumerate(bins):
    for j,(a,b) in enumerate(bands):
        r=g['records'][i*10+j];assert r['center_bin']==i and r['band']==j
        caps=[sum(triangle_cap(t,c,below) for t in triangles) for c,below in [(a-lo,True),(b-hi,False)]]
        assert all(z>=0 for z in caps) and caps==[F(*r['lower_cap_area_um2']),F(*r['upper_cap_area_um2'])];caps_checked+=128
        cap=max(0,math.floor(A)-sum(math.ceil(z) for z in caps));assert cap==r['source_minus_caps_lower_um2']
        knots=sorted({lo,hi}|{z for x,y,xx,yy in strips for z in [a-y,a-yy,b-y,b-yy] if lo<=z<=hi})
        values=[sum((xx-x)*max(0,min(cy+yy,b)-max(cy+y,a)) for x,y,xx,yy in strips) for cy in knots];oldmin=min(values);assert oldmin==r['prior_strips_minimum_um2']
        lb=math.floor(A) if j==0 else max(cap,oldmin);assert lb==r['source_area_lower_um2'] and lb-oldmin==r['gain_over_prior_strips_um2'];gains.append(lb-oldmin)
rows=[];modes=load(extra[2]);minimum=float('inf');source_checks=0
for state in load(extra[1]):
    mi=state['modes'][12];cx,cy=state['anchors'][12];m=modes[mi];assert m['family']=='cog' and not m['mirrored'];c,s=math.cos(m['angle']),math.sin(m['angle']);p=Polygon([((c*(x-center[0])-s*(y-center[1])+cx)*1000,(s*(x-center[0])+c*(y-center[1])+cy)*1000) for x,y in outer]);assert p.is_valid
    yc=math.floor(cy*1000);bi=next(i for i,(lo,hi) in enumerate(bins) if lo<=yc<=hi);margins=[]
    for j,(a,b) in enumerate(bands):
        actual=p.intersection(box(-1000000,a,3000000,b)).area;lb=g['records'][bi*10+j]['source_area_lower_um2'];delta=actual-lb;assert delta>=-0.01;margins.append(delta);minimum=min(minimum,delta);source_checks+=1
    rows.append({'prefix':state['prefix'],'center_y_um':yc,'center_bin':bi,'actual_minus_lower_um2':margins})
write(OUT/'known-source-band-checks.json',rows)
write(OUT/'necessity-proof.json',{'all_real_angles':True,'integer_center_bins_complete':True,'argument':'Exact original vertices are at radius at most140001um; their convex combinations (including the filled polygon) are within that disk. Rotation preserves radius; moving the reference to the floored center adds a vector of norm strictly below sqrt(2), yielding radius less than140003um. Every listed integer-normal halfplane contains that radius disk by the verified Cauchy bound d>=R*sqrt(nx^2+ny^2). Their independently verified convex polygon encloses the source for every angle. For centerY in[lo,hi], source area below band a is no greater than polygon area below a-lo, and source area above b is no greater than polygon area above b-hi, by monotonicity. Subtract both outward-rounded caps from the inward-rounded source area; max with zero is a valid integer lower bound. Existing source strips are disjoint and contained; their band-area sum is piecewise linear in centerY and reaches its minimum at a checked endpoint or breakpoint. Taking the maximum of the two valid lower bounds remains necessary. The full relaxed-stock band directly contains every valid source placement, so the exact inward-rounded full area applies there. This argument never treats the outer polygon as filled collision geometry. Original-polygon samples corroborate the proof but do not establish angle completeness.','capacity_rule':'All disjoint original filled sources inside relaxed stock must have total band intersection area at most stock width times band height. Add each noncog source-contained rectangle intersection area once, and one cog lower bound for its complete Y bin. Source holes are reserved by PIH OFF.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_vertices_verified':80,'outer_facets_verified':64,'exact_triangle_caps_verified':caps_checked,'center_bins_verified':35,'band_bounds_verified':350,'strictly_stronger_bounds':sum(g>0 for g in gains),'maximum_gain_mm2':max(gains)/1000000,'source_prefixes_corroborated':len(rows),'original_source_band_checks':source_checks,'minimum_actual_minus_lower_um2':minimum,'sampling_not_used_as_all_angle_proof':True,'outer_polygon_not_used_as_source_collision_geometry':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
