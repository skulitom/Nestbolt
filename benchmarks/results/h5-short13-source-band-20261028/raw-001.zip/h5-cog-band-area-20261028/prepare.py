"""Exact all-angle source-area lower bounds in predeclared horizontal bands."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime, timezone
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-cog-band-area-20261028'
GEO=ROOT/'output/h5-short13-necessary-geometry-20261028'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(ps):return abs(sum(x*v-y*u for (x,y),(u,v) in zip(ps,ps[1:]+ps[:1])))/2 if ps else F(0)
def clip(ps,y,below):
    out=[]
    for a,b in zip(ps,ps[1:]+ps[:1]):
        ai=(a[1]<=y) if below else (a[1]>=y)
        bi=(b[1]<=y) if below else (b[1]>=y)
        if ai:out.append(a)
        if ai!=bi:out.append((a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]),F(y)))
    return out
def rat(x):return [x.numerator,x.denominator]
def strips_min(rs,a,b,lo,hi):
    ys={lo,hi}
    for x,y,xx,yy in rs:
        ys.update(t for t in [a-y,a-yy,b-y,b-yy] if lo<=t<=hi)
    return min(sum((xx-x)*max(0,min(cy+yy,b)-max(cy+y,a)) for x,y,xx,yy in rs) for cy in ys)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    inputs=[ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-global-short-frontier-20261026/area-proof.json',ROOT/'output/h5-cog-flat-edge-support-20261026/support-proof.json',ROOT/'output/h5-cog-flat-edge-support-20261026/audit/checks.json']+[GEO/n for n in ['variants.json','domains.json','stock.json','audit/checks.json']]
    assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
    bands=[[6480,319447],[6480,215000],[110000,319447],[50000,275000],[70000,250000],[100000,220000],[6480,175000],[150000,319447],[6480,125000],[200000,319447]]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'bands_um':bands,'center_bin_step_um':1000,'outer_facets':64,'normal_scale':1000000,'method':'For every real cog rotation and every integer floored center, all original filled-source points lie strictly inside the audited radius140003um disk. An exact rational circumscribed polygon bounds area outside each band from above. Subtract separately rounded-up worst-endpoint lower and upper caps from rounded-down exact filled-source area. Compare with the minimum area of existing disjoint source-contained strips across the complete center bin. The larger lower bound remains necessary. For the full relaxed-stock band, source containment directly supplies the full source area. This outer polygon is used only to bound missing area; it is never a filled-source collision substitute. All calculations determining bounds use exact rational arithmetic. No solver call or layout claim.'})
    job=load(inputs[0]);outer=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];A=area([(F(x),F(y)) for x,y in outer])*1000000
    assert A==F(*load(inputs[1])['filled_source_areas_rational']['cog'])*1000000
    R=load(inputs[2])['rounded_center_vertex_radius_upper_um'];assert R==140003
    faces=[]
    for k in range(64):
        nx=round(1000000*math.cos(2*math.pi*k/64));ny=round(1000000*math.sin(2*math.pi*k/64));q=nx*nx+ny*ny;s=math.isqrt(q);s+=s*s<q
        faces.append([nx,ny,R*s])
    ps=[]
    for (nx,ny,d),(mx,my,e) in zip(faces,faces[1:]+faces[:1]):
        det=nx*my-ny*mx;assert det>0
        ps.append((F(d*my-ny*e,det),F(nx*e-d*mx,det)))
    assert all(nx*x+ny*y<=d for x,y in ps for nx,ny,d in faces)
    cog=next(v for v in load(GEO/'variants.json') if v['family']=='cog');domain=next(d for d in load(GEO/'domains.json') if d['variant']==12)['bounds_um'];yl,yh=domain[1],domain[3];bins=[[lo,min(lo+999,yh)] for lo in range(yl,yh+1,1000)]
    records=[]
    for k,(lo,hi) in enumerate(bins):
        for bi,(a,b) in enumerate(bands):
            lower=area(clip(ps,a-lo,True));upper=area(clip(ps,b-hi,False));cap=max(0,math.floor(A)-math.ceil(lower)-math.ceil(upper));old=strips_min(cog['source_capacity_rectangles_um'],a,b,lo,hi)
            lb=math.floor(A) if bi==0 else max(cap,old)
            records.append({'center_bin':k,'band':bi,'lower_cap_area_um2':rat(lower),'upper_cap_area_um2':rat(upper),'source_minus_caps_lower_um2':cap,'prior_strips_minimum_um2':old,'source_area_lower_um2':lb,'gain_over_prior_strips_um2':lb-old})
    write(OUT/'geometry.json',{'original_filled_area_um2':rat(A),'original_filled_area_floor_um2':math.floor(A),'outer_radius_um':R,'outer_faces':faces,'outer_vertices_rational_um':[[rat(x),rat(y)] for x,y in ps],'outer_area_um2':rat(area(ps)),'center_bins_um':bins,'bands_um':bands,'stock_width_um':1487040,'relaxed_stock_band_um':[6480,319447],'records':records})
    write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'center_bins':len(bins),'bands':len(bands),'bounds':len(records),'strictly_stronger_bounds':sum(r['gain_over_prior_strips_um2']>0 for r in records),'maximum_gain_mm2':max(r['gain_over_prior_strips_um2'] for r in records)/1000000,'full_source_area_mm2':float(A/1000000),'all_real_angles':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
if __name__=='__main__':main()
