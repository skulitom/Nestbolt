"""Seal the failed all-source search and audited all-angle band-area strengthening."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-short13-source-band-20261028';OUT=ROOT/'benchmarks/results'/NAME
SOURCE=ROOT/'output/h5-short13-source-sliding-20261028';AREA=ROOT/'output/h5-cog-band-area-20261028';MODEL=ROOT/'output/h5-short13-band-model-20261028';PUB=MODEL/'publication'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='27a29f95c7308673e250dac5087d6b7a8947e8ea' and not git('diff','HEAD','--name-only')
for p in [SOURCE/'preflight/checks.json',SOURCE/'result-audit/checks.json',AREA/'audit/checks.json',MODEL/'model-audit/checks.json',MODEL/'response-audit/checks.json']:assert load(p)['passed']
sr=load(SOURCE/'result-audit/checks.json');ar=load(AREA/'audit/checks.json');mr=load(MODEL/'model-audit/checks.json');rr=load(MODEL/'response-audit/checks.json')
assert not sr['source13_valid'] and sr['source_summary']['pair_failures']==15 and sr['source_summary']['stock_failures']==2
assert rr['status']=='UNKNOWN' and not rr['has_necessary_assignment'] and rr['closed']
old=load(ROOT/'benchmarks/results/h5-short13-necessary-20261028/publication-review.json');production=source_digest();assert production==old['production_digest'];readmes={n:digest(ROOT/n) for n in old['current_readmes']};assert readmes==old['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[x['tag_name'] for x in load(PUB/'studio-releases.json')]};assert all(up[k]==old[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='390fb2d30ba4637a59577b81f38952920f7c06dc';jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];bindings={};seen=set()
def add(name,p):
    members[name]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [SOURCE,AREA,MODEL]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for n,h in load(SOURCE/'preflight/reused-inputs.json').items():
    p=ROOT/n;assert digest(p)==h;bindings[n]=h;add('source-inputs/'+n,p)
helpers=['prepare_h5_short13_source_sliding.py','h5_short13_source_objective.py','audit_h5_short13_source_preflight.py','run_h5_short13_source_sliding.py','audit_h5_short13_source_result.py','prepare_h5_cog_band_area_20261028.py','audit_h5_cog_band_area_20261028.py','build_h5_short13_band_model_20261028.py','audit_h5_short13_band_model_20261028.py','run_h5_short13_band_model_20261028.py','audit_h5_short13_band_response_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(SOURCE/'preflight/checks.json','source-preflight.json'),(SOURCE/'search/result.json','source-search-result.json'),(SOURCE/'result-audit/checks.json','source-result-checks.json'),(AREA/'prepared.json','band-geometry-prepared.json'),(AREA/'audit/checks.json','band-geometry-checks.json'),(AREA/'audit/necessity-proof.json','band-area-proof.json'),(MODEL/'built.json','band-model-built.json'),(MODEL/'model-audit/checks.json','band-model-checks.json'),(MODEL/'search/result.json','band-solver-result.json'),(MODEL/'response-audit/checks.json','band-response-checks.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40676201231,'main_all6_pass':True,'normal_push_authorized_after_fresh_live_run_check':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'source_preflight_and_result_audits_passed':True,'source13_valid':False,'source13_pair_failures':15,'source13_stock_failures':2,'exact_band_geometry_verified':True,'band_bounds_verified':350,'stronger_band_bounds':275,'full_model_variables_verified':mr['variables_verified'],'full_model_constraints_verified':mr['constraints_verified'],'band_solver_status':'UNKNOWN','source_search_calls':1,'band_solver_calls':1,'both_searches_closed':True,'short_7_5_1_excluded':False,'full66_witness':False,'native_calls':0,'main_all6_pass':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='Both new searches are closed. Do not rerun, reseed or extend the all-source13 local search or the all-angle short13 band-area necessary model. The source search freed all13 positions but its result has15 original-pair failures and2 stock failures. Exact all-angle source-area bounds strengthen275 of350 bin/band cases, but the single strengthened necessary call returns UNKNOWN without an assignment. No source13 witness or count exclusion exists. Next derive certified per-mode horizontal separations by projecting the audited actual-source mixed forbidden regions across each complete relative-Y domain, preserving boundary cases and all allowed angles; establish material strengthening before another feasibility call. Alternatively change the complete source construction structurally. Keep the original66 parts, PIH OFF, material metric and gap/stock guards. The best current valid layout remains64 originals with two brackets missing. Only a complete independently source-valid66 may proceed to native and full H5 matrix validation. Main390fb2d3 now passes all six jobs; this checkpoint and the queued27a29f95 may be normally pushed together after fresh ancestry, remote-reference and no-live-run checks. H2 keeps the explicit original-gate decision and22 unopened reserved vectors. No release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Short-sheet source search and cog band-area bounds — 2026-10-28

The allocation of **seven brackets, five inserts and one cog** remains unresolved.
A new search with all 13 original shapes free fails the independent geometry
check. A separate, stronger necessary model accounts for the cog's original
filled area and returns **UNKNOWN**. Neither result is a feasible placement or
an impossibility proof. Both calls are closed.

## Original-source construction

All seven brackets, five inserts and the cog move; none of the previous nine
fixed neighbors stays fixed. The declared modes cover all eight bracket modes,
both insert outer classes and 36 cog phases. The geometry includes 415 source
pair obstacles: 379 exactly reused and 36 new bracket-pair obstacles. Preflight
checks verify 46 original modes, 3,735 original-shape pair samples, all 635 valid
12-part starting prefixes and 26 analytic-gradient components.

Both insert classes are evaluated on a 31 by 5 grid for every prefix: all
196,850 candidates are retained and independently replayed. The single selected
start uses prefix 258. One continuous position stage performs 123 objective
evaluations and 89 mode trials, with no accepted mode change or random restart.
It closes at a local minimum after {sr['search_seconds']:.6f} search seconds and
{sr['shared_seconds']:.6f} shared seconds. The final source readback checks all
13 originals, 78 pairs, 52 stock edges and 27 holes with 3,372 hole vertices.
**Fifteen pairs and two stock bounds fail.** The worst extra stock clearance is
−2.014812 mm. All raw failed placements, checks and logs are preserved.

## Exact area bounds for every cog angle

The original filled outer has area 50,062.718938 mm². Exact rational arithmetic
verifies all 80 source vertices lie within a 140.001 mm radius; allowing center
flooring gives a strict 140.003 mm bound. A 64-facet rational polygon encloses
that circle. It supplies upper bounds on area outside each horizontal band;
it is never substituted for the cog's filled collision geometry.

For each of 35 complete integer center-Y bins and 10 predeclared bands, subtract
outward-rounded lower and upper cap areas from inward-rounded original area.
Compare this with the minimum contribution of the old disjoint source strips,
and retain the larger valid lower bound. The full-stock band uses the full
source area directly. These are necessary bounds for every real rotation.

The independent audit recomputes 44,800 exact clipped-triangle caps and all
350 bounds. **275 bounds improve**, by up to 16,232.704661 mm². All 6,350
original-polygon band checks across the 635 valid prefixes agree. These samples
corroborate the exact proof; they do not establish angle completeness.

## Audited stronger model and closed result

All 12,197 prior variables and 15,458 constraints are preserved byte for byte.
The extension links the cog to exactly one complete Y bin and adds ten band
capacity constraints. Each sums the cog bound and the exact intersections of
selected source-contained noncog rectangles with that band. All 1,602 optional
intersection-height calculations and 178 whole-stock rectangle areas are
independently checked. Every original remains mandatory, all allowed modes
remain available, and there are no fixed poses, hints or objectives.

The complete model has **18,640 variables and 23,549 constraints**. Its sole
60-second call, with four workers and `fj` excluded, returns UNKNOWN after
67,352 branches and 40,926 conflicts. Solver wall time is 60.117023 seconds,
returned call time 60.120701 seconds, and shared time 61.081026 seconds. The
small soft overruns are retained. The independent response reader verifies
the model bytes, parameters, counters, status and absence of an assignment.

There is no short-sheet count exclusion, full valid 66-part layout, native
validation or H5 completion. The best current valid construction still has
64 originals with two brackets missing. Next investigate a stronger exact
structural projection or a different complete source construction; these
searches will not be repeated or extended.

## Publication

Main `390fb2d3` now passes all six jobs in
[CI 40676201231](https://github.com/skulitom/Nestbolt/actions/runs/40676201231).
The queued necessary-model checkpoint and this evidence can be pushed together
after a fresh remote and live-run check. Production, READMEs and Sparrow/Studio
heads and releases are unchanged. H2 and H5 remain open at **60% completed
milestone weight**; all 22 reserved H2 vectors remain unopened. No new release
qualifies.

[Source audit]({NAME}/source-result-checks.json),
[exact band audit]({NAME}/band-geometry-checks.json),
[necessity proof]({NAME}/band-area-proof.json),
[full model audit]({NAME}/band-model-checks.json),
[closed response]({NAME}/band-response-checks.json),
[publication review]({NAME}/publication-review.json),
[next step]({NAME}/next-step.json),
[byte-verified archive]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including the original job, all reused obstacles, input
bindings, helper dependencies, exact proofs, model protobufs and raw failures.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 all-source short13 and band-area bounds, 2026-10-28:** [the evidence]({link})
retains one new search with all 13 original placements free. All 196,850 initial
grid scores are replayed; the sole local call closes after 123 evaluations in
2.218165 search / 5.856514 shared seconds. The original-shape audit finds 15 pair
failures and two stock failures. A separate exact all-angle cog-area proof
strengthens 275 of 350 band bounds; 44,800 rational triangle caps and 6,350
known-source band checks pass. The audited stronger model preserves the prior
model byte for byte and totals 18,640 variables / 23,549 constraints. Its sole
bounded call returns UNKNOWN after 67,352 branches / 40,926 conflicts in
60.120701 returned / 61.081026 shared seconds; the small soft overrun is retained.
Both searches are closed. No source13 witness, count exclusion, full66 or native
pass exists. Next derive a stronger exact structural projection or change the
complete source construction. Main390fb2d3 now passes all six CI jobs, enabling
the queued checkpoint push after fresh remote/live-run checks. Production,
READMEs and upstream releases are unchanged. H2/H5 remain open at 60%; all 22
reserved vectors remain unopened, and no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'main_all6_pass':True,'completion_percent':60})
