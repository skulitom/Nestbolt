"""Original-source configuration penalty for thirteen movable short-sheet originals."""
from pathlib import Path
import json
import numpy as np
import shapely
from shapely.geometry import shape,Polygon
from shapely.affinity import affine_transform
class SourceObjective:
    def __init__(self,base):
        base=Path(base);load=lambda p:json.loads(p.read_bytes());self.modes=load(base/'modes.json');self.moving=load(base/'moving.json');self.count=len(self.modes);self.free=np.asarray([shape(load(base/'free'/f'{i:02d}.json')) for i in range(self.count)],dtype=object)
        saved={(i,j):shape(load(base/'obstacles'/f'{i:02d}-{j:02d}.json')) for i,j in load(base/'obstacle-pairs.json')};self.obstacles=np.asarray([Polygon() if i<36 and j<36 else saved[i,j] if i<=j else affine_transform(saved[j,i],[-1,0,0,-1,0,0]) for i in range(self.count) for j in range(self.count)],dtype=object);self.boundaries=shapely.boundary(self.obstacles)
    def evaluate_points(self,xy,modes):
        xy=np.asarray(xy,dtype=float).reshape(-1,2);modes=np.asarray(modes,dtype=int);assert np.sum(modes<36)<=1;left,right=np.triu_indices(len(xy),1);delta=xy[right]-xy[left];points=shapely.points(delta);indices=modes[left]*self.count+modes[right];inside=shapely.contains(self.obstacles[indices],points);gradient=np.zeros_like(xy);pair_cost=max_pair=0.
        if np.any(inside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(points[inside],self.boundaries[indices[inside]]),1));difference=delta[inside]-nearest;pair_cost=float(np.sum(difference*difference));max_pair=float(np.max(np.linalg.norm(difference,axis=1)));np.add.at(gradient,right[inside],2*difference);np.add.at(gradient,left[inside],-2*difference)
        anchors=shapely.points(xy);outside=~shapely.covers(self.free[modes],anchors);stock_cost=max_stock=0.
        if np.any(outside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(anchors[outside],self.free[modes[outside]]),1));difference=xy[outside]-nearest;stock_cost=float(np.sum(difference*difference));max_stock=float(np.max(np.linalg.norm(difference,axis=1)));gradient[outside]+=8*difference
        return pair_cost+4*stock_cost,gradient.reshape(-1),{'pair_penalty_mm2':pair_cost,'stock_penalty_mm2':stock_cost,'overlapping_configuration_pairs':int(np.sum(inside)),'anchors_outside_stock_regions':int(np.sum(outside)),'maximum_pair_depth_mm':max_pair,'maximum_stock_depth_mm':max_stock}
    def evaluate(self,flat,modes):
        assert len(modes)==13 and all(mi in item['allowed_modes'] for item,mi in zip(self.moving,modes));return self.evaluate_points(flat,modes)
    def extra_penalties(self,prefix_xy,prefix_modes,mode,anchors):
        xy=np.asarray(prefix_xy);anchors=np.asarray(anchors);indices=np.tile(np.asarray(prefix_modes)*self.count+mode,len(anchors));delta=(anchors[:,None,:]-xy[None,:,:]).reshape(-1,2);points=shapely.points(delta);inside=shapely.contains(self.obstacles[indices],points);costs=np.zeros(len(delta))
        if np.any(inside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(points[inside],self.boundaries[indices[inside]]),1));difference=delta[inside]-nearest;costs[inside]=np.sum(difference*difference,axis=1)
        return costs.reshape(len(anchors),len(xy)).sum(axis=1)
    def placements(self,anchors,modes):
        rows=[]
        for item,mi,xy in zip(self.moving,modes,np.asarray(anchors).reshape(-1,2)):
            assert mi in item['allowed_modes'];m=self.modes[mi];rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[float(xy[k]+m['source_translation_offset'][k]) for k in range(2)]}})
        return rows
