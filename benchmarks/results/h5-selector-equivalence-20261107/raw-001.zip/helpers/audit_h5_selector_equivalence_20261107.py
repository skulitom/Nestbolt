"""Finite validation-only equivalence and ABBA timing of selector bookkeeping."""
from pathlib import Path
from hashlib import sha256
import copy,json,time,os,gc
import h5_two_center_neighbors_20261107 as original
import h5_indexed_two_center_neighbors_20261107 as indexed
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selector-equivalence-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';E=V/'search/epoch-01'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def fingerprint(v):return sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
BASE.mkdir();start=time.perf_counter()
paths=[Path(__file__),ROOT/'output/h5_two_center_neighbors_20261107.py',ROOT/'output/h5_indexed_two_center_neighbors_20261107.py',ROOT/'output/prepare_h5_selector_equivalence_helpers_20261107.py',A/'library.json',A/'initial-state.json',A/'objective-identity.json',B/'regions.json',V/'audit/selection-replay/checks.json',V/'response-audit/checks.json',V/'response-audit/epoch-01-selection/checks.json',V/'selector-profile/checks.json',V/'runtime-bindings.json',V/'closed-problems.json',E/'opened.json',E/'weight-transition.json']
names=['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json']
paths += [parent/name for parent in [V,E] for name in names]
assert load(V/'response-audit/checks.json')['passed'] and load(V/'audit/selection-replay/checks.json')['passed']
for name,h in load(V/'runtime-bindings.json').items():assert digest(ROOT/name)==h
write(BASE/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Only pair-loss array gathering and invocation-local complete-key reuse differ. In both independently audited original-source and recorded runtime contexts, run a fixed original/indexed/indexed/original sequence with full uncached calculation; require exact returned output each time. Separately compare full old/new output under changed weights and an added identity discriminator. Check the original cache path, six stale-cache mutations, six synthetic and one real deadline in each cached/full path, and direct digest recomputation for every raw record. No new geometry search, initializer, model or optimizer. Timing is validation-only selector work, before I/O/group/model/source costs, with two samples per variant/context and no significance claim.','timing_order':['original','indexed','indexed','original'],'context_order':['source','runtime'],'synthetic_deadline_checkpoints':[1,4,225,226,12000,23644],'real_deadline_seconds':.05,'optimizer_calls':0,'validation_only':True,'new_source_state_prepared':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');opened=load(E/'opened.json')
source=[lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,{r['key'] for r in load(V/'closed-problems.json')}]
runtime=[lib,opened['incoming_modes'],opened['incoming_values'],load(E/'weight-transition.json')['after'],identity,regions,set(opened['visited_keys'])]
expected_source=tuple(load(V/n) for n in names);expected_runtime=tuple(load(E/n) for n in names);times=[];exact=[]
for label,args,expected in [('source',source,expected_source),('runtime',runtime,expected_runtime)]:
    records,aliases,trials,selections=expected;assert len(records)==23419 and len(trials)==9102
    for index,variant in enumerate(['original','indexed','indexed','original']):
        gc.collect();before=time.perf_counter();actual=getattr(original if variant=='original' else indexed,'neighbors')(*args,deadline=before+45,cached_trials=None);seconds=time.perf_counter()-before
        assert actual==expected,(label,variant,index);times.append({'context':label,'sequence':index,'variant':variant,'full_uncached_selector_seconds':seconds,'exact_output':True});del actual
        print(times[-1],flush=True)
    expected_digest=fingerprint(expected);exact.append({'context':label,'complete_output_sha256':expected_digest,'proposals':len(records),'trials':len(trials),'independently_audited_reference':True,'all_four_repetitions_exact':True})
    # Recompute the canonical digest directly, without calling either key helper.
    for row in records:
        key=fingerprint({'physical':row['physical_key'],'weights':args[3],'objective_identity':args[4]});assert key==row['key']
write(BASE/'timings.json',times);write(BASE/'exact-output-controls.json',exact)
mutations=[]
for kind in ['weights','identity']:
    args=copy.deepcopy(runtime)
    if kind=='weights':args[3]=[w*1.125 for w in args[3]]
    else:args[4]['validation_discriminator']='key-isolation-control-only'
    before=time.perf_counter();expected=original.neighbors(*args,deadline=before+45,cached_trials=None);actual=indexed.neighbors(*args,deadline=time.perf_counter()+45,cached_trials=None);assert actual==expected
    assert all(a['key']!=b['key'] for a,b in zip(actual[0],expected_runtime[0]))
    for row in actual[0]:assert row['key']==fingerprint({'physical':row['physical_key'],'weights':args[3],'objective_identity':args[4]})
    for rows,name in zip(actual,names):write(BASE/(kind+'-'+name),rows)
    mutations.append({'context_change':kind,'complete_output_exact':True,'independent_digest_checks':23419,'all_keys_changed':True,'output_sha256':fingerprint(actual),'validation_only':True});del actual,expected
write(BASE/'key-context-controls.json',mutations)
cache={'context':indexed.cache_context(*source[:6]),'trials':expected_source[2]}
actual=indexed.neighbors(*source,deadline=time.perf_counter()+30,cached_trials=cache);assert actual==expected_source;del actual
# Count cache misses separately from every timing sample; restore the function.
counter=[0];key_function=indexed.problem_key
def counted(*args):counter[0]+=1;return key_function(*args)
indexed.problem_key=counted
try:actual=indexed.neighbors(*source,deadline=time.perf_counter()+30,cached_trials=cache);assert actual==expected_source
finally:indexed.problem_key=key_function
assert counter[0]==2854;del actual
stale=[]
for kind,index in [('coordinates',2),('modes',1),('weights',3),('library',0),('identity',4),('regions',5)]:
    args=copy.deepcopy(source)
    if kind=='coordinates':args[index][0]+=1
    elif kind=='modes':args[index][0]=(args[index][0]+1)%10
    elif kind=='weights':args[index][0]+=.25
    elif kind=='library':args[index]['stock_guard_mm']+=.001
    elif kind=='identity':args[index]['version']+='-stale'
    else:args[index]['policy']['coefficient']=2.
    try:indexed.neighbors(*args,deadline=time.perf_counter()+5,cached_trials=cache)
    except AssertionError:stale.append({'case':kind,'rejected':True})
    else:raise AssertionError('Stale source trials accepted')
write(BASE/'cache-controls.json',{'passed':True,'cached_source_output_exact':True,'problem_digest_calls_in_counted_control':counter[0],'raw_proposals':23419,'scope':'Cache is recreated on every invocation; only complete physical-vector digests are reused within unchanged weights and identity. This does not cache or omit any geometry score.','stale_source_trial_rejections':stale})
class Clock:
    def __init__(self,stop):self.stop=stop;self.calls=0
    def __call__(self):self.calls+=1;return 1. if self.calls>=self.stop else 0.
def prefix(e):
    assert not e['complete'] and e['status']=='SELECTION_DEADLINE' and e['selected_proposal'] is None and e['optimizer_calls']==0
    for field,rows in zip(['records','aliases','trials','selections'],expected_source):assert e[field]==rows[:len(e[field])]
    assert e['observed']>=e['deadline'] and e['overrun_seconds']==e['observed']-e['deadline']
deadlines=[]
for flavor,cached in [('cached',cache),('full',None)]:
    for stop in [1,4,225,226,12000,23644]:
        timer=Clock(stop)
        try:indexed.neighbors(*source,deadline=1.,clock=timer,cached_trials=cached)
        except indexed.SelectionDeadline as exc:
            e=exc.evidence;prefix(e);assert timer.calls==stop;write(BASE/f'{flavor}-deadline-{stop:05d}.json',e);deadlines.append({'flavor':flavor,'stop':stop,'stage':e['stage'],'trials':len(e['trials']),'records':len(e['records']),'selected_proposal':None})
        else:raise AssertionError('Deadline failed')
    before=time.perf_counter()
    try:indexed.neighbors(*source,deadline=before+.05,cached_trials=cached)
    except indexed.SelectionDeadline as exc:
        e=exc.evidence;prefix(e);write(BASE/f'{flavor}-deadline-real.json',e);deadlines.append({'flavor':flavor,'stop':'real','stage':e['stage'],'overrun_seconds':e['overrun_seconds'],'elapsed_seconds':time.perf_counter()-before,'trials':len(e['trials']),'records':len(e['records']),'selected_proposal':None})
    else:raise AssertionError('Real deadline failed')
write(BASE/'deadline-controls.json',{'passed':True,'cases':deadlines,'count':len(deadlines),'partial_output_exact_prefix':True,'no_partial_candidate':True})
summary=[]
for context in ['source','runtime']:
    old=[r['full_uncached_selector_seconds'] for r in times if r['context']==context and r['variant']=='original'];new=[r['full_uncached_selector_seconds'] for r in times if r['context']==context and r['variant']=='indexed']
    summary.append({'context':context,'original_seconds':old,'indexed_seconds':new,'original_mean_seconds':sum(old)/2,'indexed_mean_seconds':sum(new)/2,'observed_mean_reduction_fraction':1-sum(new)/sum(old),'samples_per_variant':2,'statistical_significance_claimed':False})
write(BASE/'checks.json',{'passed':True,'complete_seconds':time.perf_counter()-start,'timed_full_selector_calls':8,'timing_contexts':summary,'exact_reference_records_across_two_contexts':2*(23419+9102),'complete_mutated_contexts':2,'independent_digest_checks':4*23419,'stale_source_cache_rejections':len(stale),'deadline_controls':len(deadlines),'digest_calls_per_complete_selector':counter[0],'new_source_state_prepared':False,'new_model_prepared':False,'optimizer_calls':0,'closed_search_resumed':False,'H5_complete':False,'validation_only':True,'no_preparation_cost_removed':True})
print(load(BASE/'checks.json'),flush=True)
