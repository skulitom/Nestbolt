"""Prepare bounded combined checkpoint push and exact staged-byte verification."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_two_center_construction_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-two-center-construction-main-sync-20261107':'h5-selector-equivalence-main-sync-20261107',
    "prefixes=('benchmarks/results/h5-two-center-construction-20261107',)":"prefixes=('benchmarks/results/h5-two-center-construction-20261107','benchmarks/results/h5-selector-equivalence-20261107')",
    "['h5-two-center-construction-20261107']":"['h5-two-center-construction-20261107','h5-selector-equivalence-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
compile(source,'push_h5_selector_equivalence_checkpoints_20261107.py','exec')
with (ROOT/'output/push_h5_selector_equivalence_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
for old,new in [('verify_h5_two_center_construction_checkpoint_20261107.py','verify_h5_selector_equivalence_checkpoint_20261107.py'),('verify_h5_two_center_construction_staged_20261107.py','verify_h5_selector_equivalence_staged_20261107.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-two-center-construction-20261107','h5-selector-equivalence-20261107').replace('h5-two-center-construction-staged-checks-20261107.json','h5-selector-equivalence-staged-checks-20261107.json')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Combined push, archive verifier and staged verifier prepared; no push performed.')
