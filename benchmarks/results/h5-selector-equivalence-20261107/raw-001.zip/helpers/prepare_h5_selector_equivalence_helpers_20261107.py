"""Version computation-only selector changes; leave frozen search helpers intact."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/h5_two_center_neighbors_20261107.py').read_text(encoding='utf-8')
changes={
    '    def emit(selected):':'    pair_i=np.asarray([i for i,j in pairs],dtype=np.intp);pair_j=np.asarray([j for i,j in pairs],dtype=np.intp)\n    # Local to this invocation: weights and identity cannot leak across calls.\n    key_cache={}\n    def emit(selected):',
    "losses=np.asarray([matrix[i,j] for i,j in pairs]);aux=":"losses=matrix[pair_i,pair_j];aux=",
    "physical=list(physical_key(library,classes,chosen));key=problem_key(physical,weights,identity)":"physical=list(physical_key(library,classes,chosen));physical_tuple=tuple(physical)\n        if physical_tuple not in key_cache:key_cache[physical_tuple]=problem_key(physical,weights,identity)\n        key=key_cache[physical_tuple]",
}
for a,b in changes.items():assert source.count(a)==1,a;source=source.replace(a,b)
compile(source,'h5_indexed_two_center_neighbors_20261107.py','exec')
with (ROOT/'output/h5_indexed_two_center_neighbors_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('Separate indexed selector prepared. No call or candidate created.')
