"""Preserve computation-only selector equivalence; never claim a packing result."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-selector-equivalence-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-selector-equivalence-20261107';F=BASE;D=BASE",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-two-center-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['timed_full_selector_calls']==8 and front['deadline_controls']==14 and front['optimizer_calls']==0 and not front['new_source_state_prepared']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-selector-equivalence-process-20261107']",
    "['*h5*mixed*mode*20261107.py']":"['*h5*selector*equivalence*20261107.py','h5_indexed_two_center_neighbors_20261107.py','prepare_h5_selector_equivalence_push_20261107.py','push_h5_selector_equivalence_checkpoints_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_selector_equivalence_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "for name,h in load(F/'source-bindings.json').items():":"for name,h in load(F/'plan.json')['inputs'].items():",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','runtime-coverage-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
V=ROOT/'output/h5-two-center-preflight-20261107';runtime=load(V/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
for name in ['plan.json','checks.json','timings.json','exact-output-controls.json','key-context-controls.json','cache-controls.json','deadline-controls.json','main-ci-at-review.json']:shutil.copyfile(BASE/name,OUT/('equivalence-audit.json' if name=='checks.json' else name))
shutil.copyfile(ROOT/'output/h5-selector-equivalence-process-20261107/process.json',OUT/'process.json')
shutil.copyfile(PARENT/'closed-problems.json',OUT/'closed-problems.json')
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k!='passed'}})
process=load(OUT/'process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
write(OUT/'next-step.json',{'status':'fresh_original_source_initializer_preflight_required','finding':'A separately versioned selector retains exact full output in the two independently audited source/runtime contexts, both timing repetitions and changed-weight/identity controls. All14deadline and6stale-source-cache controls pass. Invocation-local problem-digest work falls from23419to2854calls. Timing samples are diagnostic, before I/O/group/model/source costs. No initializer or optimizer was prepared.',
    'requirements':['Freshly reconstruct only from original unoptimized A/W geometry, coordinates, angles and weights. Preserve all18closed complete objective/physical-mode/weight identities. Do not seed from runtime, optimized winners, mutated-key controls or audit outputs.','Retain the entire33.769462099531665soriginal-source preparation cost and charge all new construction. Reusing unchanged source trials requires exact cache-context/source bindings; changed runtime values require full geometry recalculation. A local digest cache never authorizes reuse of geometry scores.','Retain the111physical owner/mode choices, two distinct centers,9102nominal centers,23419raw proposals,2854physical vectors,528area terms,15coefficient1auxiliary terms and continuous15cog angles. Rebuild and independently read the chosen source model, score and scalar gradient after all18exclusions.','Preserve all partial evidence and choose no candidate after interruption or absent strict improvement. Measure complete preparation/serialization/model work before freezing a finite60/90scontract with source reserve. Do not extend any prior count or deadline.','Faster bookkeeping does not establish a valid layout or H5credit and does not reopen any closed key. Full66source validity, native/material evidence, production integration/parity and the unchanged H5matrix remain necessary.'],
    'source_only_preparation_seconds_before_new_work':33.769462099531665,'closed_problem_keys':18,'replacement_selector_preflight_passed':True,'new_source_state_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
ci=load(BASE/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
timing_rows='\n'.join(f"| {r['context']} | {r['original_seconds'][0]:.6f}, {r['original_seconds'][1]:.6f} | {r['indexed_seconds'][0]:.6f}, {r['indexed_seconds'][1]:.6f} | {100*r['observed_mean_reduction_fraction']:.2f}% |" for r in front['timing_contexts'])
dead=load(BASE/'deadline-controls.json');real=[r for r in dead['cases'] if r['stop']=='real'];assert len(real)==2
report=f'''# Selector computation equivalence — 2026-11-07

Two computation-only changes pass complete equivalence checks: gather pair losses
with precomputed NumPy indices, and calculate each complete problem digest once
per physical vector within a single invocation. Geometry, objectives, proposal
order, exclusions and deadline checkpoints are unchanged. **No new source state,
model or optimizer call is prepared.** H2/H5 remain open at **60% completed
milestone weight**; this is a selector implementation result, not a valid packing.

## Complete equivalence and bounded timing

[The frozen validation plan]({NAME}/plan.json) checks the original unoptimized
source context and the already audited closed runtime context. Each uses the
fixed original/indexed/indexed/original order with full uncached geometry scoring.
All eight complete outputs are exactly equal to their independently audited
references: **9,102 centers, 23,419 proposals and 111 owner/mode selections** per
call, including every score component, key, exclusion, alias and raw coordinate.
The two references retain all **65,042 independently reconstructed scores** from
their earlier audits; equality here is checked against those exact records.

[Timing samples]({NAME}/timings.json) measure only the complete uncached selector,
before serialization, key grouping, model readback and source checks. Both
implementations use the same CPU mask and one BLAS thread. There are only two
samples per implementation/context; no statistical significance or production
packing improvement is claimed.

| Context | Original selector (s) | Indexed selector (s) | Observed mean reduction |
| --- | ---: | ---: | ---: |
{timing_rows}

[A separate counted control]({NAME}/cache-controls.json) verifies **2,854 digest
calls instead of 23,419**, while preserving every raw proposal. The cache is local
to each invocation's unchanged weights and objective identity. It does not cache
geometry and cannot carry results across calls. Pair-loss gathering retains the
exact existing 528-pair order and all sums/dot products.

[Changed-context controls]({NAME}/key-context-controls.json) compare full original
and indexed output after changing all weights and, separately, adding an identity
discriminator. Every key changes and independently matches canonical JSON/SHA-256.
The mutated contexts are validation only. Across the four contexts, **93,676 raw
problem digests** are recomputed directly without either key helper. Repeated
calls, the original-source trial-cache path and all six stale trial-cache
rejections pass. No new optimizer identity is consumed by these controls.

[Fourteen deadline controls]({NAME}/deadline-controls.json) cover six synthetic
checkpoints and a real 0.05 s deadline in each cached/full path. Every preserved
record is an exact prefix of the complete reference; interruption yields no
selected proposal. Real cooperative overruns are {real[0]['overrun_seconds']:.6f}
and {real[1]['overrun_seconds']:.6f} s, retained explicitly. The unchanged key-grouping
implementation and its existing four deadline controls remain bound through
the preceding source preflight; this change does not modify grouping.

The separate [bounded validation process]({NAME}/process.json) closes normally in
**{process['complete_seconds']:.6f} s**, below its 300 s/2 GiB limits, with peak
aggregate committed memory of {process['job']['peak_job_committed_memory']:,} bytes.
All descendants close and optimizer calls remain zero.

## Next source preflight and unchanged acceptance

[Next]({NAME}/next-step.json), reconstruct an initializer from the original A/W
source under all [eighteen closed identities]({NAME}/closed-problems.json), preserving
the full **33.769462 s** preparation charge plus new work. Audit the selected model,
full score and scalar gradient before freezing any new finite search contract.
The current runtime and mutated validation contexts cannot seed that work.

The last construction still has **50 failed source pairs** and no valid full66
layout. Faster bookkeeping does not establish material savings, exclude an
allocation or reopen a problem. Four earlier arrangements and all 440 allocation
candidates remain unresolved. Full source/native/material validity, production
integration and the original H5 matrix remain required. README claims and releases
are unchanged.

The closed construction checkpoint is committed as **e90bc056**. Main remains
**8dc99684** at review, with {success} passed CI jobs and {live} live jobs in the
[retained snapshot]({NAME}/main-ci-at-review.json). Both checkpoints await the
ordinary push gate; no CI run is cancelled.

[Archive verification]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 selector equivalence:** [complete computation-only validation]({{link}}) verifies precomputed pair indexing and invocation-local problem digests against the independently audited source/runtime pools. All eight full selector outputs exactly match their references, including 9,102 center trials and 23,419 proposals per call. Two changed-context controls preserve exact old/new output and change every key correctly; 93,676 digests replay independently. Digest calls fall from 23,419 to 2,854 without omitting geometry. Cached/full paths, six stale-cache rejections and fourteen deadline controls pass with no partial candidate. Fixed alternating timing samples are reported without a statistical or packing claim. The bounded process closes in {process["complete_seconds"]:.6f} s with zero optimizers. Next reconstruct an original-source initializer under all eighteen closed keys, preserving 33.769462 s preparation plus new work. No successor state, model or search is prepared. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. e90bc056 and this checkpoint await the ordinary main push gate; CI has {success} passed and {live} live jobs at review. Product code, README and releases remain unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [selector computation equivalence](../benchmarks/results/{NAME}.md).
Precomputed pair indexing and invocation-local digest reuse preserve every score,
key and raw proposal in the independently audited source/runtime contexts. Eight
complete alternating comparison runs agree exactly; digest work falls from 23,419
to 2,854 calls. Two changed-context controls, 93,676 independent digests, six stale
trial-cache rejections and fourteen deadline cases pass. Timing samples are
reported without a statistical or packing claim. All processes close with zero
optimizers. Next reconstruct a fresh original-source initializer under all eighteen
closed identities, retaining 33.769462 s preparation plus new work. No successor
state, model or new search is prepared. The previous construction remains invalid
with 50 failed source pairs. Four arrangements and 440 allocations remain;
H2/H5 stay open at 60%. Main is 8dc99684 with {success} passed and {live} live CI jobs at review;
e90bc056 and this checkpoint await the ordinary push gate. Product code, README
and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
