"""Reconstruct every saved candidate, audit its entire conflict graph, and check the selected original job."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,itertools,json,math,shutil,subprocess,sys,traceback
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-saved-placement-selection-20261018';OUT=RUN/'audit';CASE='m-mechanical-large-plates-k0.2-s0-candidate'
BEAM=ROOT/'output/h5-outline-beam-20261018'/CASE;CATALOG=ROOT/'output/h5-angle-pattern-placement-20261018'/CASE
OBS=ROOT/'output/h5-terminal-repair-observer-20261018';SPACE=ROOT/'output/h5-native-partial-spacing-recovery-20261018'/CASE
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(RUN/'plan.json');result=load(RUN/'result.json');pool=load(RUN/'candidates.json');model=load(RUN/'model.json');job=load(RUN/'job.json');layout=load(RUN/'selected-layout.json');selected=load(RUN/'selected-indices.json')
    try:
        for p,h in plan['sources'].items():assert digest(ROOT/p)==h
        assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
        parts={p['id']:p for p in job['parts']};original={k:np.asarray(p['geometry'][0]['outer']) for k,p in parts.items()};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];height=load(RUN/'conditional-target.json')['required_used_height_mm']
        warm=load(SPACE/'fixture.json')['partial'];terminal=load(OBS/'audit/best/layout.json');frames=load(CATALOG/'frames.json');patterns=load(CATALOG/'patterns.json');templates=load(BEAM/'templates.json')
        needed={p['source']['candidate_id'] for p in pool if p['source']['kind']=='beam-candidate'};events={}
        with gzip.open(BEAM/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                row=json.loads(line)
                if row['kind']=='candidate' and row['id'] in needed:events[row['id']]=row
        assert set(events)==needed;geoms=[];provenance=Counter();all_bounds=[]
        for i,p in enumerate(pool):
            assert p['index']==i;s=p['source'];kind=s['kind'];provenance[kind]+=1
            if kind in ['zero-loss-partial','rejected-terminal']:
                expected=copy.deepcopy((warm if kind=='zero-loss-partial' else terminal)['placements'][s['placement']]);expected.pop('copy_index')
            elif kind=='frame-catalog':
                block=frames[s['configuration']]['placed'][s['placement']];pattern=patterns[block['pattern']];assert len(pattern['members'])==1;member=pattern['members'][0];t=copy.deepcopy(member['transform']);x,y=t['translation']
                if block['rotated']:t['rotation_radians']+=math.pi/2;x,y=pattern['height']-y,x
                t['translation']=[m['left']+edge+1e-4+block['x']+x,m['bottom']+edge+1e-4+block['y']+y];expected={'part_id':member['part_id'],'sheet_id':f"sheet-{block['bin']}",'transform':t}
            else:
                assert kind=='beam-candidate';event=events[s['candidate_id']];assert event['valid'];block=event['block'];member=templates[block['template']]['members'][s['member']];t=copy.deepcopy(member['transform'])
                t['translation']=[t['translation'][0]+block['x']+m['left']+edge+1e-4,t['translation'][1]+block['y']+m['bottom']+edge+1e-4];expected={'part_id':member['part_id'],'sheet_id':f"sheet-{block['sheet']}",'transform':t}
            assert expected==p['placement'],i
            placement=p['placement'];t=placement['transform'];part=parts[placement['part_id']];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);mirror=-1. if t['mirrored'] else 1.
            vertices=original[placement['part_id']]@np.array([[mirror*c,mirror*s],[-s,c]])+np.asarray(t['translation']);g=Polygon(vertices);assert g.is_valid;geoms.append(g)
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(theta-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            a,b,c,d=g.bounds;h=stock['height'] if placement['sheet_id']=='sheet-0' else height;assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
            all_bounds.append(g.bounds)
        with gzip.open(RUN/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:recorded={tuple(json.loads(line)) for line in f}
        actual=set();bounds=np.asarray(all_bounds);sheets=np.asarray([p['placement']['sheet_id'] for p in pool]);near=0;total=0;gs=np.asarray(geoms,dtype=object)
        # Exhaustive pair enumeration with a separately implemented bounding-box
        # lower distance bound, followed by original-polygon distances. No STRtree.
        for i,g in enumerate(geoms):
            js=np.arange(i+1,len(pool));js=js[sheets[js]==sheets[i]];total+=len(js)
            dx=np.maximum(0,np.maximum(bounds[js,0]-bounds[i,2],bounds[i,0]-bounds[js,2]));dy=np.maximum(0,np.maximum(bounds[js,1]-bounds[i,3],bounds[i,1]-bounds[js,3]));js=js[np.hypot(dx,dy)<=job['clearance']+1e-7];near+=len(js)
            distances=shapely.distance(g,gs[js])
            actual.update((i,int(j)) for j,d in zip(js,distances) if d<job['clearance']-1e-7)
        assert actual==recorded,(len(actual-recorded),len(recorded-actual));assert len(actual)==model['conflict_edges']
        chosen=set(selected);assert len(chosen)==len(selected) and all(not(i in chosen and j in chosen) for i,j in actual)
        counts=Counter();pairs=[]
        assert len(layout['placements'])==len(selected)
        for i,p in zip(selected,layout['placements']):
            expected=copy.deepcopy(pool[i]['placement']);expected['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;assert p==expected
        missing=Counter({p['id']:p['quantity'] for p in job['parts']})-counts;assert dict(missing)==result['missing'] and counts['frame']==parts['frame']['quantity']
        assert all(counts[k]<=p['quantity'] for k,p in parts.items())
        for i,j in itertools.combinations(selected,2):
            if sheets[i]!=sheets[j]:continue
            a,b=geoms[i],geoms[j];distance=a.distance(b);overlap=a.intersection(b).area;assert distance>=job['clearance']-1e-7 and overlap<=1e-7;pairs.append({'a':i,'b':j,'distance_mm':distance,'overlap_mm2':overlap})
        with gzip.open(OUT/'selected-pairs.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for p in pairs:f.write(json.dumps(p)+'\n')
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
        command=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(RUN/'selected-layout.json')]
        cp=subprocess.run(command,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'public-command.json',{'command':command,'exit_code':cp.returncode});public=json.loads(cp.stdout)
        assert public['valid']==(not missing)
        codes=Counter(v['code'] for v in public['violations'])
        if missing:assert set(codes)=={'quantity'},codes
        checks={'complete':True,'source_and_candidate_provenance_exact':True,'candidates_checked':len(pool),'candidate_origins':dict(provenance),'all_same_sheet_candidate_pairs_enumerated':total,'candidate_pairs_geometrically_checked':near,'conflict_edges_verified':len(actual),
            'selected_pairs_checked':len(pairs),'selected_geometry_valid':True,'public_original_job_valid':public['valid'],'public_violation_codes':dict(codes),'missing':dict(missing),'complete_target_witness':not missing,'solver_status':result['status'],'solver_seconds':result['seconds'],'production_digest':source_digest(),'new_native_searches':0,'H5_complete':False}
        write(OUT/'checks.json',checks);print(json.dumps(checks),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
