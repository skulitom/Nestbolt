"""Jointly select compatible saved actual-outline placements; finite offline construction only."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,importlib.util,itertools,json,math,shutil,subprocess,time,traceback
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_array
from shapely.geometry import Polygon
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1];CASE='m-mechanical-large-plates-k0.2-s0-candidate'
BEAM=ROOT/'output/h5-outline-beam-20261018'/CASE;CATALOG=ROOT/'output/h5-angle-pattern-placement-20261018'/CASE
OBS=ROOT/'output/h5-terminal-repair-observer-20261018';SPACE=ROOT/'output/h5-native-partial-spacing-recovery-20261018'/CASE
OUT=ROOT/'output/h5-saved-placement-selection-20261018';CAP=4000;SOLVER_SECONDS=120.;TOL=1e-7
spec=importlib.util.spec_from_file_location('base',ROOT/'output/construct_h5_pattern_layouts.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'select.py');start=time.perf_counter();job=load(BEAM/'job.json');target=load(BEAM/'conditional-target.json');fixture=load(SPACE/'fixture.json')
    sourcepaths=[BEAM/'job.json',BEAM/'templates.json',BEAM/'candidates.jsonl.gz',BEAM/'conditional-target.json',CATALOG/'frames.json',CATALOG/'patterns.json',OBS/'audit/best/layout.json',SPACE/'fixture.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'case':CASE,'sources':{str(p.relative_to(ROOT)):digest(p) for p in sourcepaths},
        'method':'Take the known zero-native-loss partial first, then in-bound retained terminal poses, all 25 previously generated frame configurations, and each member of every valid saved beam candidate. Deduplicate by part/sheet/mirror and transforms rounded only for candidate identity (12 angle digits, 10 translation digits); retain original coordinates. Cap at the first 4000 unique candidates. Build conflicts from actual filled outer contours at unchanged clearance and original sheet targets. Select binary candidates jointly with at most each original family quantity, exactly all frames, and filled area at least the known incomplete partial. Maximize covered original filled area. The saved partial is checked as a feasible discrete-model certificate before solving. Preserve any timeout or incomplete result; no global feasibility/infeasibility claim follows from a finite candidate pool. All quantities and independent original-geometry validation are required for a full witness.',
        'candidate_cap':CAP,'MILP_seconds_cap':SOLVER_SECONDS,'acceptance_tolerance_mm':TOL,'native_calls':0,'quality_runs':0,'production_budget_changed':False,'H5_complete':False})
    for name in ['job.json','library.json','request.json','conditional-target.json']:shutil.copyfile(BEAM/name,OUT/name)
    try:
        parts={p['id']:p for p in job['parts']};families=list(parts);stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];height=target['required_used_height_mm']
        areas={k:Polygon(p['geometry'][0]['outer']).area for k,p in parts.items()};pool=[];geoms=[];keys={};omitted=Counter();warm=[]
        def polygon(p):
            t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);vertices=[]
            for x,y in parts[p['part_id']]['geometry'][0]['outer']:
                if t['mirrored']:x=-x
                vertices.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
            return Polygon(vertices)
        def add(p,source):
            p=copy.deepcopy(p);p.pop('copy_index',None);t=p['transform'];part=parts[p['part_id']];g=polygon(p);assert g.is_valid and not g.is_empty
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else height;assert p['sheet_id'] in ['sheet-0','sheet-1']
            if a<m['left']+edge-TOL or b<m['bottom']+edge-TOL or c>stock['width']-m['right']-edge+TOL or d>h-m['top']-edge+TOL:omitted['outside_target']+=1;return None
            key=(p['part_id'],p['sheet_id'],t['mirrored'],round(t['rotation_radians']%math.tau,12),*(round(x,10) for x in t['translation']))
            if key in keys:omitted['equivalent_key']+=1;return keys[key]
            if len(pool)>=CAP:omitted['candidate_cap']+=1;return None
            i=len(pool);keys[key]=i;pool.append({'index':i,'placement':p,'source':source,'filled_area_mm2':areas[p['part_id']]});geoms.append(g);return i
        for i,p in enumerate(fixture['partial']['placements']):warm.append(add(p,{'kind':'zero-loss-partial','placement':i}))
        assert None not in warm and len(set(warm))==len(warm)==63
        for i,p in enumerate(load(OBS/'audit/best/layout.json')['placements']):add(p,{'kind':'rejected-terminal','placement':i})
        patterns=load(CATALOG/'patterns.json');frames=load(CATALOG/'frames.json')
        for k,frame in enumerate(frames):
            frame_layout=base.layout_of(job,patterns,frame['placed'])
            for i,p in enumerate(frame_layout['placements']):add(p,{'kind':'frame-catalog','configuration':k,'placement':i})
        templates=load(BEAM/'templates.json');beam_count=0
        with gzip.open(BEAM/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                row=json.loads(line)
                if row['kind']!='candidate' or not row['valid']:continue
                beam_count+=1;b=row['block'];template=templates[b['template']];assert template['template_id']==b['template']
                for i,member in enumerate(template['members']):
                    t=copy.deepcopy(member['transform']);t['translation']=[t['translation'][0]+b['x']+m['left']+edge+1e-4,t['translation'][1]+b['y']+m['bottom']+edge+1e-4]
                    add({'part_id':member['part_id'],'sheet_id':f"sheet-{b['sheet']}",'transform':t},{'kind':'beam-candidate','candidate_id':row['id'],'member':i})
        write(OUT/'candidates.json',pool);write(OUT/'warm-indices.json',warm);n=len(pool);conflicts=[];queried=0
        for sheet in ['sheet-0','sheet-1']:
            ids=[i for i,p in enumerate(pool) if p['placement']['sheet_id']==sheet];shapes=[geoms[i] for i in ids];tree=STRtree(shapes)
            for local,g in enumerate(shapes):
                for other in tree.query(g,predicate='dwithin',distance=job['clearance']+TOL):
                    j=int(other)
                    if j<=local:continue
                    queried+=1;i1,i2=ids[local],ids[j];distance=g.distance(shapes[j])
                    if distance<job['clearance']-TOL:conflicts.append((i1,i2))
        conflicts.sort();assert len(conflicts)==len(set(conflicts));warmset=set(warm);assert all(not (i in warmset and j in warmset) for i,j in conflicts)
        with gzip.open(OUT/'conflicts.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for pair in conflicts:f.write(json.dumps(pair)+'\n')
        rowidx=[];colidx=[];data=[];lower=[];upper=[]
        for i,j in conflicts:
            r=len(lower);rowidx.extend([r,r]);colidx.extend([i,j]);data.extend([1.,1.]);lower.append(-np.inf);upper.append(1.)
        for family in families:
            r=len(lower);indices=[i for i,p in enumerate(pool) if p['placement']['part_id']==family]
            rowidx.extend([r]*len(indices));colidx.extend(indices);data.extend([1.]*len(indices));qty=parts[family]['quantity'];lower.append(float(qty) if family=='frame' else 0.);upper.append(float(qty))
        candidate_areas=np.asarray([p['filled_area_mm2'] for p in pool]);total_area=sum(areas[k]*p['quantity'] for k,p in parts.items());warm_area=float(candidate_areas[warm].sum());r=len(lower)
        rowidx.extend([r]*n);colidx.extend(range(n));data.extend((candidate_areas/total_area).tolist());lower.append((warm_area-1e-6)/total_area);upper.append(np.inf)
        matrix=coo_array((np.asarray(data),(np.asarray(rowidx,dtype=np.int32),np.asarray(colidx,dtype=np.int32))),shape=(len(lower),n)).tocsc();matrix.indices=matrix.indices.astype(np.int32);matrix.indptr=matrix.indptr.astype(np.int32)
        w=np.zeros(n);w[warm]=1.;values=matrix@w;assert np.all(values>=np.asarray(lower)-1e-9) and np.all(values<=np.asarray(upper)+1e-9)
        write(OUT/'model.json',{'candidates':n,'source_beam_candidates':beam_count,'frame_configurations':len(frames),'candidate_counts':dict(Counter((p['placement']['part_id'] for p in pool))),
            'omitted':dict(omitted),'near_pairs_evaluated':queried,'conflict_edges':len(conflicts),'constraints':len(lower),'matrix_nonzeros':matrix.nnz,'known_partial_candidates':len(warm),'known_partial_area_mm2':warm_area,'required_total_area_mm2':total_area,'warm_model_certificate_passes':True,'preparation_seconds':time.perf_counter()-start})
        print((OUT/'model.json').read_text(encoding='utf-8'),flush=True);solve_start=time.perf_counter()
        result=milp(c=-candidate_areas/total_area,integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(matrix,np.asarray(lower),np.asarray(upper)),options={'time_limit':SOLVER_SECONDS,'mip_rel_gap':0.})
        record={'status':int(result.status),'success':bool(result.success),'message':result.message,'seconds':time.perf_counter()-solve_start,'has_incumbent':result.x is not None,
            'objective':None if result.fun is None else float(result.fun),'mip_gap':None if getattr(result,'mip_gap',None) is None else float(result.mip_gap),'mip_node_count':None if getattr(result,'mip_node_count',None) is None else int(result.mip_node_count),'mip_dual_bound':None if getattr(result,'mip_dual_bound',None) is None else float(result.mip_dual_bound)}
        if result.x is not None:
            x=np.rint(result.x);assert np.max(np.abs(x-result.x))<1e-6;values=matrix@x;assert np.all(values>=np.asarray(lower)-1e-8) and np.all(values<=np.asarray(upper)+1e-8)
            chosen=np.flatnonzero(x).tolist();write(OUT/'solver-values.json',result.x.tolist())
        else:chosen=warm
        count=Counter();layout={'version':1,'units':'mm','sheets':fixture['partial']['sheets'],'placements':[]}
        for i in chosen:
            p=copy.deepcopy(pool[i]['placement']);p['copy_index']=count[p['part_id']];count[p['part_id']]+=1;layout['placements'].append(p)
        write(OUT/'selected-indices.json',chosen);write(OUT/'selected-layout.json',layout);missing=Counter({p['id']:p['quantity'] for p in job['parts']})-count
        record.update({'selected_from':'MILP incumbent' if result.x is not None else 'unchanged known partial fallback','placed':dict(count),'missing':dict(missing),'filled_area_mm2':float(candidate_areas[chosen].sum()),'complete_original_inventory':not missing,'geometry_acceptance_pending':True})
        write(OUT/'result.json',record);print(json.dumps(record),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
