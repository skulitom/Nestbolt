"""Independent rational component bounds and exact occupied-area subtraction."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from collections import Counter,defaultdict
from bisect import bisect_left
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-component-area-20261107';OUT=BASE/'audit';COVER=ROOT/'output/h5-roof-two-empty-covers-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';INSERT=ROOT/'output/h5-roof-coupled-covers-20261107';SOURCE=ROOT/'output/h5-roof-one-short-cog-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def pose(p,t):
    c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;matrix=((m*c,-s),(m*s,c));translation=list(map(Q,t['translation']));return [tuple(sum(matrix[k][j]*Q(v[j]) for j in range(2))+translation[k] for k in range(2)) for v in p]
def sweep(region,obstacles):
    if not region:return (0,0)
    rects=region+obstacles;ys=sorted({r[k] for r in rects for k in [1,3]});events=defaultdict(list)
    for kind,rows in enumerate([region,obstacles]):
        for a,b,c,e in rows:events[a].append((kind,b,e,1));events[c].append((kind,b,e,-1))
    counts=np.zeros((2,len(ys)-1),dtype=np.int32);heights=np.diff(ys);xs=sorted(events);total=0;before=0
    for i,x in enumerate(xs):
        for kind,a,b,change in events[x]:counts[kind,bisect_left(ys,a):bisect_left(ys,b)]+=change
        assert counts.min()>=0
        if i+1<len(xs):
            width=xs[i+1]-x;covered=counts[0]>0;available=covered&(counts[1]==0);before+=width*int(heights[covered].sum());total+=width*int(heights[available].sum())
    assert not np.any(counts);return total,before
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for old in [COVER/'audit',BRACKET/'audit',INSERT/'audit',SOURCE/'audit']:
    assert load(old/'checks.json')['passed']
    for p,h in load(old/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),JOB]+[p for p in BASE.iterdir() if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile audited complete source masks, center covers, source-contained obstacles and valid44 geometry. Independently verify the original L partition as two rectangles sharing only a boundary and matching its exact filled area. Check every transformed component vertex against outward rational bounds and the outward stock relaxation. Reconstruct all component-swept regions and occupied obstacle lists for the seven exact site choices. Independently compute region union minus fixed-inner union by one-dimensional signed interval events with a vertical count vector, rather than producer2D prefix grids. Apply audited lower original areas to disjoint remaining bodies. No solver or geometry-library area operation.','process_cap_seconds':20,'optimizer_calls':0,'retry_permitted':False})
assert sweep([[0,0,3,3]],[[1,1,2,2]])==(8,9);assert sweep([[0,0,3,3]],[[1,1,2,2],[1,1,2,2]])==(8,9);assert sweep([[0,0,3,3]],[[3,0,4,3]])==(9,9)
job=load(JOB);parts={p['id']:p for p in job['parts']};br=parts['bracket']['geometry'][0]['outer'];iv=parts['insert']['geometry'][0]['outer'];assert br==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]];components={'bracket':[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]],'insert':[iv]};assert area(br)==sum(area(p) for p in components['bracket'])==40000;assert max(v[1] for v in components['bracket'][0])==min(v[1] for v in components['bracket'][1])==75;assert area(iv)==19800
source_bounds=load(BASE/'source-component-bounds.json');assert len(source_bounds)==12;bounds={};covers={};count=0
for r in source_bounds:
    family,mode=r['family'],r['mode'];assert r['source_components']==components[family];old=load(COVER/family/f'mode-{mode:02d}.json');assert r['source_pose']==old['geometry']['pose'];expected=[]
    for component in components[family]:
        p=pose(component,r['source_pose']);b=[math.floor(min(v[0] for v in p)*1000)-1,math.floor(min(v[1] for v in p)*1000)-1,math.ceil(max(v[0] for v in p)*1000)+1,math.ceil(max(v[1] for v in p)*1000)+1];assert all(Q(b[0],1000)<v[0]<Q(b[2],1000) and Q(b[1],1000)<v[1]<Q(b[3],1000) for v in p);expected.append(b);count+=1
    assert expected==r['outward_component_bounds_um'];bounds[family,mode]=expected;covers[family,mode]=old['cover']
stock=load(BASE/'stock-cover.json');sb=stock['outward_stock_rectangle_um'];physical=list(map(Q,stock['physical_stock_mm']));assert all(Q(sb[k],1000)<physical[k] for k in [0,1]) and all(Q(sb[k],1000)>physical[k] for k in [2,3]);assert sb==[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(physical)]
sources=load(BRACKET/'turned-2/source-inner-rectangles.json');cases=load(COVER/'audit/retained-cases.json');assert len(cases)==7;results=[]
for case in cases:
    saved=load(BASE/(case['case']+'-capacity.json'));assert saved['empty_sites']==case['empty_sites'];allowed=sum(1<<i for i in case['empty_sites']);obstacles=[r['bounds_um'] for r in sources if r['site_bit']==16 or not(allowed&(1<<r['site_bit']))];assert obstacles==saved['source_inner_obstacles_um'];assert len({r['site_bit'] for r in sources if r['site_bit']==16 or not(allowed&(1<<r['site_bit']))})==15;assert load(SOURCE/(case['case']+'-checks.json'))['valid'];regions={};after={};before={}
    for family,n in [('bracket',8),('insert',4)]:
        expected=[]
        for mode in range(n):
            for label,l,b,r,t,*_ in covers[family,mode]:
                if label&~allowed:continue
                for a,c,d,e in bounds[family,mode]:
                    rect=[max(l+a,sb[0]),max(b+c,sb[1]),min(r+d,sb[2]),min(t+e,sb[3])]
                    if rect[0]<rect[2] and rect[1]<rect[3]:expected.append(rect)
        expected=list(map(list,sorted(set(map(tuple,expected)))));assert expected==saved['occupied_component_regions_um'][family];regions[family]=expected;after[family],before[family]=sweep(expected,obstacles);assert after[family]==saved['family_area_after_fixed_subtraction_um2'][family] and before[family]==saved['family_area_before_fixed_subtraction_um2'][family]
    combined=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));assert combined==saved['combined_component_regions_um'];actual,initial=sweep(combined,obstacles);assert actual==saved['combined_area_upper_um2'] and initial==saved['combined_area_before_fixed_subtraction_um2'];bc=after['bracket']//(39999*10**6);ic=after['insert']//(19799*10**6);assert bc==saved['provisional_bracket_capacity'] and ic==saved['provisional_insert_capacity'];assert actual<556778*10**6 and saved['provisional_excluded'];results.append({'case':case['case'],'empty_sites':case['empty_sites'],'maximum_brackets':bc,'maximum_inserts':ic,'occupied_area_upper_mm2':actual/1e6,'required_area_lower_mm2':556778,'area_shortfall_mm2':556778-actual/1e6,'exact_fixed44_excluded':True,'whole_allocation_excluded':False})
process=load(ROOT/'output/h5-roof-component-area-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];assert load(COVER/'audit/checks.json')['fixed44_cases_excluded']==113
write(OUT/'capacity-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_component_bounds_verified':count,'modes_verified':12,'exact_union_difference_areas_verified':21,'fixed44_cases_newly_excluded':7,'fixed44_cases_excluded_total':120,'fixed44_cases_remaining':0,'largest_combined_area_upper_mm2':max(r['occupied_area_upper_mm2'] for r in results),'smallest_area_shortfall_mm2':min(r['area_shortfall_mm2'] for r in results),'complete_preparation_seconds_if_consumed':charge,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
