"""Independent complete two-empty covers and all120 exact occupied unions."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from bisect import bisect_left
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-two-empty-covers-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-roof-one-short-cog-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';INSERT=ROOT/'output/h5-roof-coupled-covers-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def union_area(rects):
    if not rects:return 0
    xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});d=np.zeros((len(ys),len(xs)),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    covered=np.cumsum(np.cumsum(d,0),1)[:-1,:-1]>0;return int(np.sum(covered*np.diff(ys)[:,None]*np.diff(xs)[None,:],dtype=np.int64))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for old in [BRACKET/'audit',INSERT/'audit',SOURCE/'audit']:
    assert load(old/'checks.json')['passed']
    for p,h in load(old/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile every immutable input of prior independent source/full-mask audits. Independently classify each full matrix with a Python integer bit-count lookup, verify every new labeled rectangle and exact once-only coverage of every eligible point/interval class. Reconstruct all120 family and combined occupied rectangles from source-mode bounds and each empty pair. Recompute every area using an independent signed two-dimensional count grid, rather than the producer interval sweep. Reconcile source44 membership and required remaining identities. All negative conclusions concern only these exact fixed44 cases.','process_cap_seconds':30,'optimizer_calls':0,'retry_permitted':False})
lookup=np.array([not(n&65536) and n.bit_count()<=2 for n in range(131072)],dtype=np.bool_);families={'bracket':load(BRACKET/'bracket-geometries.json'),'insert':load(INSERT/'geometries.json')};covers={};records=[]
for family,geometries in families.items():
    assert len(geometries)==(8 if family=='bracket' else 4);covers[family]={};oldbase=BRACKET/'turned-2' if family=='bracket' else INSERT
    for g in geometries:
        mode=g['mode'];record=load(BASE/family/f'mode-{mode:02d}.json');assert record['family']==family and record['geometry']==g;path=ROOT/record['source_mask_file'];assert path==oldbase/f'mode-{mode:02d}-classes.npz' and digest(path)==record['source_mask_sha256']
        with np.load(path,allow_pickle=False) as saved:xs=saved['xcuts_um'];ys=saved['ycuts_um'];mask=saved['mask']
        assert mask.dtype==np.uint32 and mask.max()<131072 and mask.shape==(2*len(ys)-1,2*len(xs)-1);eligible=lookup[mask];covered=np.zeros(mask.shape,dtype=np.bool_)
        for label,a,b,c,e,xa,ya,xb,yb in record['cover']:
            assert 0<=xa<=xb<mask.shape[1] and 0<=ya<=yb<mask.shape[0] and lookup[label];assert [a,b,c,e]==[int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2])];assert np.all(mask[ya:yb+1,xa:xb+1]==label) and not np.any(covered[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
        assert np.array_equal(covered,eligible);covers[family][mode]=record['cover'];records.append({'family':family,'mode':mode,'continuous_classes':int(mask.size),'retained_classes':int(eligible.sum()),'cover_boxes':len(record['cover']),'all_continuous_classes_and_unique_coverage_verified':True})
assert union_area([[0,0,2,2],[1,1,3,3]])==7;source_cases=load(SOURCE/'cases.json');assert [tuple(r['empty_sites']) for r in source_cases]==list(combinations(range(16),2));remaining=load(SOURCE/'remaining-identities.json');assert len(remaining)==22 and sum(r[0]=='bracket' for r in remaining)==6 and sum(r[0]=='insert' for r in remaining)==16
assert load(BRACKET/'audit/checks.json')['bracket_area_error_bound_mm2']<1 and load(INSERT/'audit/checks.json')['insert_area_error_bound_mm2']<1;results=[]
for source in source_cases:
    assert source['source_valid44'];case=source['case'];empty=source['empty_sites'];allowed=sum(1<<i for i in empty);saved=load(BASE/(case+'-capacity.json'));assert saved['case']==case and saved['empty_sites']==empty;rects={};areas={}
    for family,geometries in families.items():
        rr=[]
        for g in geometries:
            a,b,c,e=g['outer_bounds_um']
            for label,l,bot,r,top,*_ in covers[family][g['mode']]:
                if label&~allowed==0:rr.append([l+a,bot+b,r+c,top+e])
        rects[family]=list(map(list,sorted(set(map(tuple,rr)))));assert rects[family]==saved['occupied_rectangles_um'][family];areas[family]=union_area(rects[family]);assert areas[family]==saved[family+'_area_upper_um2']
    joint=list(map(list,sorted(set(map(tuple,rects['bracket']))|set(map(tuple,rects['insert'])))));assert joint==saved['combined_rectangles_um'];combined=union_area(joint);assert combined==saved['combined_area_upper_um2'];bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);small=combined<(6*39999+16*19799)*10**6;excluded=bc<6 or ic<16 or small;assert bc==saved['provisional_bracket_capacity'] and ic==saved['provisional_insert_capacity'] and small==saved['provisional_combined_exclusion'] and excluded==saved['provisional_excluded'];results.append({'case':case,'empty_sites':empty,'maximum_brackets_from_cover':bc,'maximum_inserts_from_cover':ic,'combined_area_upper_mm2':combined/1e6,'required_area_lower_mm2':556778,'bracket_bound_excludes':bc<6,'insert_bound_excludes':ic<16,'combined_area_bound_excludes':small,'exact_fixed44_excluded':excluded,'whole_allocation_excluded':False})
assert sum(r['continuous_classes'] for r in records)==prepared['continuous_classes'] and sum(r['retained_classes'] for r in records)==prepared['retained_classes'];excluded=sum(r['exact_fixed44_excluded'] for r in results);assert excluded==prepared['provisional_total_exclusions']==113;retained=[r for r in results if not r['exact_fixed44_excluded']];assert len(retained)==7;process=load(ROOT/'output/h5-roof-two-empty-covers-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'class-controls.json',records);write(OUT/'capacity-results.json',results);write(OUT/'retained-cases.json',retained);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'modes_verified':12,'continuous_classes_verified':prepared['continuous_classes'],'retained_classes_verified':prepared['retained_classes'],'cover_boxes_verified':sum(r['cover_boxes'] for r in records),'fixed44_cases':120,'fixed44_cases_excluded':excluded,'fixed44_cases_unresolved':7,'bracket_exclusions':3,'insert_exclusions':0,'combined_area_exclusions':113,'complete_preparation_seconds_if_consumed':charge,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
