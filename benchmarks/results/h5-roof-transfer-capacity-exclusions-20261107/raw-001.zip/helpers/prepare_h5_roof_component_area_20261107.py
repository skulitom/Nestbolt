"""Sharper source component sweeps minus definitely occupied fixed geometry."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from bisect import bisect_left
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-two-empty-covers-20261107';OUT=ROOT/'output/h5-roof-component-area-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';INSERT=ROOT/'output/h5-roof-coupled-covers-20261107';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def posed(p,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation']);return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in p]
def bound(p):return [math.floor(min(v[0] for v in p)*1000)-1,math.floor(min(v[1] for v in p)*1000)-1,math.ceil(max(v[0] for v in p)*1000)+1,math.ceil(max(v[1] for v in p)*1000)+1]
def clip(r):
    a,b,c,d=[max(r[0],stockbox[0]),max(r[1],stockbox[1]),min(r[2],stockbox[2]),min(r[3],stockbox[3])];return [a,b,c,d] if a<c and b<d else None
def difference_area(region,obstacles):
    rects=region+obstacles;xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});assert len(xs)*len(ys)<40000000
    def grid(rows):
        d=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for a,b,c,e in rows:
            i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
        return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]>0
    covered=grid(region);blocked=grid(obstacles);weight=np.diff(ys)[:,None]*np.diff(xs)[None,:];return int(np.sum(weight*(covered&~blocked),dtype=np.int64)),int(np.sum(weight*covered,dtype=np.int64))
OUT.mkdir();began=time.perf_counter();prior=load(BASE/'audit/checks.json');assert prior['passed'];cases=load(BASE/'audit/retained-cases.json');assert len(cases)==7;job=load(JOB);parts={p['id']:p for p in job['parts']}
inputs=[Path(__file__),JOB,BASE/'audit/checks.json',BASE/'audit/retained-cases.json',BRACKET/'audit/checks.json',INSERT/'audit/checks.json',BRACKET/'turned-2/source-inner-rectangles.json',SOURCE/'source-recipe.json']+[BASE/family/f'mode-{i:02d}.json' for family,n in [('bracket',8),('insert',4)] for i in range(n)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For seven cases surviving whole-outline bounding boxes, sweep outward source-component bounds over every eligible necessary center box. Bracket has two exact source rectangles whose union is the filled L; insert has one. Intersect the resulting occupied union with an outward stock rectangle and remove the union of source-contained inner rectangles belonging to mandatory frames and the fourteen retained cog sites. Every possible companion body remains covered, while definitely occupied fixed interiors cannot be used. Compute exact integer union-minus-union area per family and combined, with independent sweep audit required. Only the exact fixed44 cases may be excluded.','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'preparation_internal_cap_seconds':18,'memory_bytes':2**31,'maximum_grid_cells':40000000,'combined_area_lower_mm2':556778,'optimizer_calls':0,'retry_permitted':False})
components={'bracket':[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]],'insert':[parts['insert']['geometry'][0]['outer']]};assert parts['bracket']['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]]
stock=load(SOURCE/'source-recipe.json')['source_stocks']['sheet-0'];stockbox=[math.floor(F(v)*1000)-1 if k<2 else math.ceil(F(v)*1000)+1 for k,v in enumerate(stock)];geometries={};covers={};proofs=[]
for family,n in [('bracket',8),('insert',4)]:
    geometries[family]={};covers[family]={}
    for i in range(n):
        rec=load(BASE/family/f'mode-{i:02d}.json');g=rec['geometry'];boxes=[bound(posed(p,g['pose'])) for p in components[family]];geometries[family][i]=boxes;covers[family][i]=rec['cover'];proofs.append({'family':family,'mode':i,'source_pose':g['pose'],'source_components':components[family],'outward_component_bounds_um':boxes})
write(OUT/'source-component-bounds.json',proofs);write(OUT/'stock-cover.json',{'outward_stock_rectangle_um':stockbox,'physical_stock_mm':stock});sources=load(BRACKET/'turned-2/source-inner-rectangles.json');results=[]
for case in cases:
    allowed=sum(1<<i for i in case['empty_sites']);obstacles=[r['bounds_um'] for r in sources if r['site_bit']==16 or not(allowed&(1<<r['site_bit']))];regions={};areas={};before={}
    for family,n in [('bracket',8),('insert',4)]:
        rects=[]
        for i in range(n):
            for label,l,b,r,t,*_ in covers[family][i]:
                if label&~allowed:continue
                for a,c,d,e in geometries[family][i]:
                    box=clip([l+a,b+c,r+d,t+e])
                    if box:rects.append(box)
        regions[family]=list(map(list,sorted(set(map(tuple,rects)))));areas[family],before[family]=difference_area(regions[family],obstacles)
    joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));combined,combined_before=difference_area(joint,obstacles);bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);small=combined<556778*10**6;excluded=bc<6 or ic<16 or small
    result={'case':case['case'],'empty_sites':case['empty_sites'],'source_inner_obstacles_um':obstacles,'occupied_component_regions_um':regions,'combined_component_regions_um':joint,'family_area_before_fixed_subtraction_um2':before,'family_area_after_fixed_subtraction_um2':areas,'combined_area_before_fixed_subtraction_um2':combined_before,'combined_area_upper_um2':combined,'combined_area_upper_mm2':combined/1e6,'provisional_bracket_capacity':bc,'provisional_insert_capacity':ic,'combined_required_area_lower_mm2':556778,'provisional_combined_exclusion':small,'provisional_excluded':excluded,'independent_audit_pending':True,'fixed_case_excluded':False};write(OUT/(case['case']+'-capacity.json'),result);results.append({k:v for k,v in result.items() if not('obstacles' in k or 'regions' in k)});assert time.perf_counter()-began<18
write(OUT/'case-summary.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':7,'source_component_mode_bounds':len(proofs),'provisional_exclusions':sum(r['provisional_excluded'] for r in results),'provisional_unresolved':sum(not r['provisional_excluded'] for r in results),'largest_combined_area_mm2':max(r['combined_area_upper_mm2'] for r in results),'independent_audit_pending':True,'whole_allocations_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
