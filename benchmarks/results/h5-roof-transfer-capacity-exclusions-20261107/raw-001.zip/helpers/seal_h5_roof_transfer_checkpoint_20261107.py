"""Archive all120 fixed-transfer exclusions, without a global packing claim."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-roof-transfer-capacity-exclusions-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-roof-component-area-20261107';F=BASE/'audit';D=ROOT/'output/h5-roof-two-empty-covers-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-coupled-roof-bound-and-cog-transfer-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['fixed44_cases_excluded_total']==120 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-orientation-main-sync-20261107']+[ROOT/'output'/('h5-roof-'+n+'-process-20261107') for n in ['two-empty-covers','two-empty-covers-audit','component-area','component-area-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_roof_two_empty*20261107.py','*h5_roof_component_area*20261107.py','*h5_roof_transfer*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_roof_transfer_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
copies=[(D/'plan.json','two-empty-cover-plan.json'),(D/'audit/checks.json','two-empty-cover-audit.json'),(D/'audit/class-controls.json','continuous-class-controls.json'),(D/'audit/capacity-results.json','all120-capacities.json'),(D/'audit/retained-cases.json','seven-earlier-survivors.json'),(BASE/'plan.json','component-area-plan.json'),(BASE/'source-component-bounds.json','source-component-bounds.json'),(BASE/'stock-cover.json','stock-cover.json'),(F/'checks.json','component-area-audit.json'),(F/'capacity-results.json','final-seven-capacities.json'),(ROOT/'output/h5-orientation-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for n in ['two-empty-covers','two-empty-covers-audit','component-area','component-area-audit']:copies.append((ROOT/'output'/('h5-roof-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime);ci=json.loads(subprocess.check_output(['gh','run','view','42405388174','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='be9c79d648839c0e0c93598d45442b4f7252eb32';write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
write(OUT/'next-step.json',{'status':'all120_exact_transfer_cases_excluded','proposal':'Change the six upper frame orientations/arrangement while preserving the source-valid short6/5/1. Assess two new source-derived patterns with five and six turned upper frames. Keep twelve turned base frames. First roof row is three turned frames; second is two turned plus one unturned for count5, or three turned for count6. Derive all bounds and centers from source dimensions, gap, existing charged analytic cog phase and axis pitch; no optimized points. For count6 propose four cog columns by two rows above the highest roof and one six-row column right of the roof from its bottom. For count5 propose three columns by two rows above the highest roof, a fourth column by three rows above the lower unturned frame, and one six-row column right of the whole roof from its bottom. Thus count6 proposes14sites and count5 proposes15sites with every14-of15 choice. Every actual source pair/stock/identity must pass before a necessary-cover or complete model. Preserve failures without adjusting the declared phase or pitch; a pool count is not a packing upper bound.','historical_scope':'Selected39-owner closed calls used0 or4 turned upper frames. Source patterns1,2,3 and the current14-of16 variants are closed for their exact geometries, not entire classes. Broader historical all-frame models exist; do not claim5/6 globally untested.','source_short_inventory':[6,5,1],'first_sheet_inventory':[18,6,16,14],'inherited_preparation_seconds':front['complete_preparation_seconds_if_consumed'],'charge_all_new_preparation':True,'old_two_turned_source_masks_not_valid_for_new_frames':True,'complete_model_prepared':False,'optimizer_calls':0,'all_old_calls_remain_closed':True,'old120_cases_remaining':0,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'H5_complete':False})
report=f'''# One-cog transfer: fixed-layout capacity exclusions — 2026-11-07

**All 120 exact one-cog-transfer layouts are now excluded** as completions to
66 parts. The previously verified 44-part partials remain valid, but their
remaining space cannot hold six brackets and sixteen inserts. No optimizer
runs and no whole allocation or orientation class is excluded. H2/H5 remain
open at **60% completed milestone weight**; the preserved valid 64-part layout
remains best.

[Complete two-empty-site covers]({NAME}/two-empty-cover-plan.json) reuse the
independently audited full bit-mask matrices for the source frame/cog pool.
They do not reuse the earlier retained covers, which allowed only one empty
site. All eight bracket and four insert modes include every continuous
boundary point and open interval with no fixed-frame conflict and at most two
cog conflicts. Each of the 120 empty pairs selects its eligible labels.

[Independent readback]({NAME}/two-empty-cover-audit.json) reconciles every prior
source/mask audit input, then verifies **26,070,912 continuous classes** and
exactly once-only coverage of the **5,483,907 retained classes** by **2,225
closed boxes**. A separate integer bit-count classification checks the
producer's bit operations. Every family and combined occupied union for all
120 cases is recomputed using two-dimensional count grids instead of the
producer's interval sweep.

The conservative remaining-body requirement is **556,778 mm²**:
six times39,999 plus sixteen times19,799. [The first area screen]({NAME}/all120-capacities.json)
excludes **113 cases**, including three already excluded by bracket count.
All insert-only bounds remain above the required sixteen. Seven cases survive
this necessary screen; a passing bound is not feasibility.

[The tighter construction]({NAME}/component-area-plan.json) sweeps the two
original rectangular components of each L-shaped bracket over every eligible
center box. Inserts retain their single component. The resulting occupied
union is clipped to an outward-relaxed stock rectangle. Source-contained
rectangles belonging to the eighteen fixed frames and fourteen occupied cog
sites are then removed: valid companion bodies cannot occupy those interiors.
This covers every possible companion placement while reducing the earlier
whole-bounding-box overestimate.

[Independent source and area readback]({NAME}/component-area-audit.json) verifies
**20 transformed component bounds across 12 modes**, the exact source L
partition, outward stock containment and all selected fixed obstacles. It
reconstructs every occupied region and checks **21 exact union-minus-union
areas** with one-dimensional signed interval events, separately from the
producer's two-dimensional prefix grids. Overlap, duplicate-obstacle and
boundary-touch controls pass. Original holes remain preserved and are not
nesting space.

| Empty cog sites | Available occupied area at most (mm²) | Required (mm²) |
|---|---:|---:|
| 0, 7 | 426,561.493588 | 556,778 |
| 0, 14 | 466,620.516415 | 556,778 |
| 3, 13 | 435,318.836582 | 556,778 |
| 7, 12 | 418,232.634983 | 556,778 |
| 7, 13 | 439,333.553550 | 556,778 |
| 7, 14 | 437,872.214797 | 556,778 |
| 12, 14 | 458,291.657810 | 556,778 |

[All seven final proofs]({NAME}/final-seven-capacities.json) exclude their exact
fixed 44-part layouts. Even the largest remaining area is short by
**90,157.483585 mm²**. Together with the preceding 113, no case in this finite
120-layout construction remains. The source-valid short sheet containing six
brackets, five inserts and one cog remains usable in a different construction.

[Complete cover preparation]({NAME}/two-empty-covers-process.json) takes
**1.175224 s**, with its separate [audit]({NAME}/two-empty-covers-audit-process.json)
at **1.379273 s**. [Component-area preparation]({NAME}/component-area-process.json)
takes **0.572615 s**, and its [audit]({NAME}/component-area-audit-process.json)
**0.640942 s**. Retaining all **17.107266 s** prior preparation gives
**18.855104 s** if consumed by a successor. Each bounded Job Object closes all
three processes under the unchanged 2 GiB and CPU/thread controls. No failed
or closed solver is repeated, reseeded or extended.

[Next]({NAME}/next-step.json), assess source-derived roof arrangements with
five and six turned upper frames while retaining the valid one-cog short sheet.
Each proposed source pool must pass complete pair, stock and identity checks
before any necessary-cover or complete model. Changed frame geometry invalidates
the old obstacle masks; those cannot be reused as if the frames were unchanged.
The selected historical 39-owner calls used zero or four turned upper frames,
but broader models exist, so no class is claimed globally untested.

Four earlier fixed arrangements and all 440 whole-job allocations remain.
Full 66-part source/native/material validation, product integration,
UI/CLI/MCP parity and the original H5 matrix still need completion.

[Main be9c79d6 contains both earlier checkpoints]({NAME}/prior-main-push-receipt.json),
pushed ordinarily after all six prior checks passed with 52 protected files
intact. [Fresh CI]({NAME}/main-ci-at-review.json) has **{success} passed / {live} live jobs**.
The coupled-transfer checkpoint and this evidence await the next ordinary push.
Product code, README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve all evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 one-cog-transfer fixed-layout exclusions:** [complete cover and area audits]({{link}}) verify 26,070,912 continuous classes, 5,483,907 retained classes and 2,225 boxes for all 120 two-empty-site choices. The first coupled bound excludes 113. Source-component sweeps and subtraction of definitely occupied fixed interiors exclude the final seven after 20 rational component bounds and 21 independently recomputed union-difference areas. Their largest remaining area is 466,620.516415 mm² against 556,778 required. All 120 exact fixed 44-part layouts therefore fail completion; no whole allocation or orientation class is excluded. The valid short 6/5/1 remains available and no optimizer runs. Total consumed preparation is 18.855104 s; all bounded processes close. Next assess source-derived five-/six-turned upper-frame patterns with the valid one-cog short sheet, validating every new source pool before any model and rebuilding obstacles for changed frames. Four earlier arrangements and 440 allocations remain; the valid 64-part result remains best. H2/H5 stay open at 60%. Main be9c79d6 has {success} passed / {live} live CI jobs; this and the prior coupled-transfer checkpoint await the ordinary push gate. Product and release state is unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [one-cog-transfer fixed-layout exclusions](../benchmarks/results/{NAME}.md).
Complete two-empty-site covers verify 26,070,912 continuous classes and exclude
113 of the 120 exact fixed 44-part layouts. Source-component occupied regions,
with definitely occupied fixed interiors removed, exclude the final seven.
Their largest available area is 466,620.516415 mm² versus 556,778 required.
The valid short 6/5/1 remains usable, but all 120 current first-sheet choices
are closed. No whole allocation or orientation class is excluded. No optimizer
runs and the valid 64-part result remains best. Consumed preparation totals
18.855104 s; all processes close. Next assess source-derived upper-frame
patterns with five and six turned frames, checking every new source pool
before any model and rebuilding obstacles when frames change. Four earlier
arrangements and 440 allocations remain. H2/H5 stay open at 60%. Main be9c79d6
has {success} passed / {live} live CI jobs; this and the prior coupled-transfer
checkpoint await the ordinary push gate. Product and releases are unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings)})
