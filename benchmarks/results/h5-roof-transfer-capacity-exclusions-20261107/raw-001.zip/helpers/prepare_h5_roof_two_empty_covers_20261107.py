"""Complete two-empty-site covers, using immutable audited full masks."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,time,os
import numpy as np
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-roof-two-empty-covers-20261107';SOURCE=ROOT/'output/h5-roof-one-short-cog-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';INSERT=ROOT/'output/h5-roof-coupled-covers-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def union_area(rects):
    xs=sorted({r[k] for r in rects for k in [0,2]});total=0
    for a,b in zip(xs,xs[1:]):
        intervals=sorted((r[1],r[3]) for r in rects if r[0]<b and a<r[2]);length=0;hi=None
        for lo,end in intervals:
            if hi is None or lo>hi:length+=end-lo;hi=end
            elif end>hi:length+=end-hi;hi=end
        total+=(b-a)*length
    return total
OUT.mkdir();began=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']);sourceaudit=load(SOURCE/'audit/checks.json');assert sourceaudit['passed'] and sourceaudit['source44_valid_cases']==120
inputs=[Path(__file__),SOURCE/'plan.json',SOURCE/'cases.json',SOURCE/'remaining-identities.json',SOURCE/'audit/checks.json',BRACKET/'audit/checks.json',INSERT/'audit/checks.json',BRACKET/'bracket-geometries.json',INSERT/'geometries.json',ROOT/'output/h5_checked_affinity_20261107.py']+[BRACKET/'turned-2'/f'mode-{i:02d}-classes.npz' for i in range(8)]+[INSERT/f'mode-{i:02d}-classes.npz' for i in range(4)]
assert load(BRACKET/'audit/checks.json')['passed'] and load(INSERT/'audit/checks.json')['passed']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reuse complete independently audited full source bit-mask matrices, not their old one-empty-site covers. For all8 bracket and4 insert modes retain every point/interval class whose label has no fixed-frame bit and at most two cog bits. Run-length boxes preserve the entire eligible continuous domain. For each of all120 two-empty-site choices, select labels contained in its two-bit mask, expand center covers by outward source bounds and compute exact occupied rectangle unions for each family and both together. The fixed source44 includes a valid short6/5/1; first-sheet companions require6brackets+16inserts. These are necessary, not sufficient, placement regions. Independent full coverage and exact union readback required before exclusions. No optimizer or new source coordinate is generated.','inherited_numeric_preparation_seconds':sourceaudit['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'required_brackets':6,'required_inserts':16,'bracket_area_lower_mm2':39999,'insert_area_lower_mm2':19799,'combined_area_lower_mm2':556778,'preparation_internal_cap_seconds':18,'process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
geometry={'bracket':load(BRACKET/'bracket-geometries.json'),'insert':load(INSERT/'geometries.json')};covers={};records=[]
for family,geometries in geometry.items():
    folder=OUT/family;folder.mkdir();base=BRACKET/'turned-2' if family=='bracket' else INSERT;covers[family]={}
    for g in geometries:
        mode=g['mode']
        with np.load(base/f'mode-{mode:02d}-classes.npz',allow_pickle=False) as saved:xs=saved['xcuts_um'];ys=saved['ycuts_um'];mask=saved['mask']
        assert mask.dtype==np.uint32 and mask.shape==(2*len(ys)-1,2*len(xs)-1);boxes=[];active={}
        def close(key,span):
            label,xa,xb=key;ya,yb=span;boxes.append([label,int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
        for yi,row in enumerate(mask):
            once=row&(row-1);legal=((row&65536)==0)&((once&(once-1))==0);labels=np.where(legal,row,np.uint32(131071));starts=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1];ends=np.r_[starts[1:]-1,len(labels)-1];current={}
            for xa,xb in zip(starts.tolist(),ends.tolist()):
                label=int(labels[xa])
                if label==131071:continue
                key=(label,xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
            for key,span in active.items():
                if key not in current:close(key,span)
            active=current
        for key,span in active.items():close(key,span)
        boxes.sort();covers[family][mode]=boxes;write(folder/f'mode-{mode:02d}.json',{'family':family,'geometry':g,'source_mask_file':(base/f'mode-{mode:02d}-classes.npz').relative_to(ROOT).as_posix(),'source_mask_sha256':digest(base/f'mode-{mode:02d}-classes.npz'),'cover':boxes});records.append({'family':family,'mode':mode,'all_classes':int(mask.size),'retained_classes':sum((r[7]-r[5]+1)*(r[8]-r[6]+1) for r in boxes),'cover_boxes':len(boxes),'retained_labels':len({r[0] for r in boxes})});assert time.perf_counter()-began<18
results=[]
for empty in combinations(range(16),2):
    case=f'empty-{empty[0]:02d}-{empty[1]:02d}';allowed=sum(1<<i for i in empty);rects={};areas={}
    for family,geometries in geometry.items():
        current=[]
        for g in geometries:
            a,b,c,e=g['outer_bounds_um']
            for label,l,bot,r,top,*_ in covers[family][g['mode']]:
                if label&~allowed==0:current.append([l+a,bot+b,r+c,top+e])
        rects[family]=sorted(set(map(tuple,current)));areas[family]=union_area(rects[family])
    joint=sorted(set(rects['bracket'])|set(rects['insert']));combined=union_area(joint);bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);small=combined<556778*10**6;excluded=bc<6 or ic<16 or small
    record={'case':case,'empty_sites':list(empty),'occupied_rectangles_um':rects,'combined_rectangles_um':joint,'bracket_area_upper_um2':areas['bracket'],'insert_area_upper_um2':areas['insert'],'combined_area_upper_um2':combined,'combined_area_upper_mm2':combined/1e6,'provisional_bracket_capacity':bc,'provisional_insert_capacity':ic,'combined_required_area_lower_mm2':556778,'provisional_bracket_exclusion':bc<6,'provisional_insert_exclusion':ic<16,'provisional_combined_exclusion':small,'provisional_excluded':excluded,'independent_audit_pending':True,'fixed_case_excluded':False};write(OUT/(case+'-capacity.json'),record);results.append({k:v for k,v in record.items() if 'rectangles' not in k});assert time.perf_counter()-began<18
write(OUT/'mode-summary.json',records);write(OUT/'case-summary.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'modes':12,'continuous_classes':sum(r['all_classes'] for r in records),'retained_classes':sum(r['retained_classes'] for r in records),'cover_boxes':sum(r['cover_boxes'] for r in records),'cases':120,'provisional_bracket_exclusions':sum(r['provisional_bracket_exclusion'] for r in results),'provisional_insert_exclusions':sum(r['provisional_insert_exclusion'] for r in results),'provisional_combined_exclusions':sum(r['provisional_combined_exclusion'] for r in results),'provisional_total_exclusions':sum(r['provisional_excluded'] for r in results),'provisional_unresolved':sum(not r['provisional_excluded'] for r in results),'largest_combined_area_mm2':max(r['combined_area_upper_mm2'] for r in results),'independent_audit_pending':True,'whole_allocations_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
