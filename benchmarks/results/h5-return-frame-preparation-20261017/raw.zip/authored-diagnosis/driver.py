"""Preserve failed qualification and trace the authored exchange without changing search decisions."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,traceback
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-return-frame-probe-20261017'
saved=probe/'build-v2-failure';saved.mkdir()
for name in ['format-v2.log','core-tests-v2.log','progress-v2.json','build-failure-v2.json']:
    shutil.copyfile(probe/name,saved/name)
shutil.copyfile(root/'output/build_h5_return_frame_v2.py',saved/'driver.py')
rel='crates/core/src/sheets/vstrip/exchange.rs'
shutil.copyfile(probe/'candidate'/rel,saved/'exchange.rs')
out=probe/'authored-diagnosis';out.mkdir()
workspace=out/'workspace';shutil.copytree(probe/'candidate',workspace)
path=workspace/rel;s=path.read_text(encoding='utf-8');original=s
def insert(needle,text):
    global s
    assert s.count(needle)==1,needle
    s=s.replace(needle,text+needle)
insert('                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());',
'''                    eprintln!("FRAME proposal incoming_id={} incoming_old={:?} incoming_here={:?} victims={:?}", incoming_item.external_id(), incoming_old, proposal.incoming, victims.iter().map(|(_,i,p)|(i.external_id(),p)).collect::<Vec<_>>());
''')
insert('                    for ((_, victim, _), pose) in victims.iter().zip(returned) {',
'''                    eprintln!("FRAME returned={returned:?}");
''')
insert('                    if receiver_tracker.total_loss() > 0.0 {',
'''                    eprintln!("FRAME receiver_loss={}",receiver_tracker.total_loss());
''')
insert('                    if source_tracker.total_loss() > 0.0',
'''                    eprintln!("FRAME source_loss={} deadline={} now={}",source_tracker.total_loss(),self.last_step(until),self.clock.now());
''')
insert('                    if !report.valid {',
'''                    eprintln!("FRAME report={report:?} before_material={}",before.material_area);
''')
path.write_text(s,encoding='utf-8',newline='\n')
target=root/'output/h5-return-frame-diagnostic-target-20261017'
command=['cargo','test','--locked','-p','nestbolt-core','--lib','directed_exchange_uses_the_rotated_return_gap','--target-dir',str(target),'--','--nocapture']
plan={'command':command,'source_before_sha256':sha256(original.encode()).hexdigest(),'instrumented_source_sha256':sha256(path.read_bytes()).hexdigest(),
      'search_decisions_changed':False,'wall_performance_claim':False,'only_authored_test':True,'expected_assertion_failure_preserved':True}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'driver.py')
with (out/'trace.log').open('xb') as stream:p=subprocess.run(command,cwd=workspace,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
(out/'result.json').write_text(json.dumps({'exit_code':p.returncode,'trace_sha256':sha256((out/'trace.log').read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'diagnostic_exit_code':p.returncode,'log':str(out/'trace.log')}))
