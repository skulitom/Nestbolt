"""Seal the separately tested complete-set eligibility candidate, without integration."""
from pathlib import Path
from hashlib import sha256
import json
import shutil
import sys
import zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-return-frame-probe-20261017'
out=root/'benchmarks/results/h5-return-frame-preparation-20261017'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
plan=load(probe/'preparation.json');build=load(probe/'build-v2.json');public=load(probe/'public-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed']
assert '90 passed; 0 failed; 0 ignored' in (probe/'core-tests-v3.log').read_text(encoding='utf-8')
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path']==plan['changed_file']):
            assert digest(probe/arm/row['path'])==row['sha256']
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
assert digest(probe/'candidate'/plan['changed_file'])==build['source_sha256']
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert 'Ran 5 tests' in (probe/'pilot-harness-tests.log').read_text(encoding='utf-8')
assert (probe/'pilot-harness-tests.log').read_text(encoding='utf-8').rstrip().endswith('OK')
for row in plan['new_candidate_files']:assert digest(probe/'candidate'/row['path'])==row['sha256']
repair=load(probe/'type-repair.json')
for name,expected in repair['preserved_files'].items():assert digest(probe/'build-v1-failure'/name)==expected
assert load(probe/'build-v1-failure/build-failure.json')['stages'][-1]['exit_code']==101
import difflib
before=(Path(plan['old_probe'])/'candidate'/plan['changed_file']).read_text(encoding='utf-8')
after=(probe/'candidate'/plan['changed_file']).read_text(encoding='utf-8')
assert after[after.index('#[cfg(test)]'):].startswith(before[before.index('#[cfg(test)]'):].rsplit('\n}',1)[0])
(probe/'candidate-final.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='complete-set-candidate',tofile='return-frame-candidate')),encoding='utf-8',newline='\n')
assert (probe/'candidate'/plan['changed_file']).read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(probe/'build-v2-failure/exchange.rs').read_text(encoding='utf-8').split('#[cfg(test)]')[0]
assert load(probe/'material-guard-review.json')['material_limit_changed'] is False
assert load(probe/'authored-diagnosis/result.json')['exit_code']==101
assert digest(probe/'authored-diagnosis/trace.log')==load(probe/'material-guard-review.json')['trace_sha256']
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_return_frame.py','build_h5_return_frame.py','build_h5_return_frame_v2.py','build_h5_return_frame_v3.py','diagnose_return_frame_attempt.py',
             'correct_return_frame_fallback_assertion.py','review_return_frame_guard.py','update_return_frame_sealer.py',
             'repair_return_frame_types.py','prepare_return_frame_checks.py','check_h5_return_frame_public.py',
             'check_h5_return_frame_harness.py','prepare_return_frame_sealer.py','seal_h5_return_frame.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/paired-runner.py']=root/'scripts/h5_return_frame_pilot.py'
inventory={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':90,'strict_lint_pass':True,
    'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,
    'candidate_common_repeatable':True,'independent_validation_passed':True,'pilot_harness_tests':5,
    'production_source_digest':source_digest(),'production_files_unchanged':True,
    'candidate_exchange_source_sha256':build['source_sha256'],'binaries':build['binaries'],
    'all_85_previous_tests_and_five_new_frame_tests_pass':True,'original_type_error_preserved':True,
    'measured_search_started':False,'H5_complete':False,'integrated':False,'completed_weight_percent':60})
for name in ['preparation.json','build-v2.json','candidate.patch','candidate-final.patch','pilot-method.json','type-repair.json','fallback-assertion-review.json','material-guard-review.json']:shutil.copyfile(probe/name,out/name)
(out.parent/(out.name+'.md')).write_text("# Reciprocal return-frame preparation — 2026-10-17\n\n**90 optimized core tests, strict lint, ten authored observer outcomes and four\npublic CLI comparisons pass.** Five unchanged adversarial paired-harness checks\nalso pass. Production remains unchanged; this is an isolated experiment.\n\n[Four completed diagnostic traces](h5-complete-stage-diagnosis-20261017.md)\nobserved all 23 attempted complete exchanges repair the receiving sheet and\nthen fail return-sheet repair. Those traces did not record poses, so they do\nnot establish that any mechanical failure was caused by rotation. A separate\n[authored witness](h5-return-frame-witness-20261017.md) verifies a legal rotated\nreturn with identical independently measured material; the translation-only\nversion collides. The witness's original mistaken material assertion remains\npreserved with its original reports and a review, without rerunning validation.\n\nThe candidate changes only initial return poses for complete two/three-part\ngroups. It maps each pose through incoming-before × inverse(incoming-here),\nincluding permitted reflections, only when every returned part permits its\nresulting orientation. Otherwise the whole group uses the previous translation.\nEqual incoming frames retain exactly the previous arithmetic. The separator\ncan subsequently move each part independently. Single-part fallbacks, complete\nset eligibility, proposal ranking/caps, both repairs, independent whole-job\ngeometry/material validation, rollback and deadlines remain unchanged.\n\nAll 85 previous tests remain. Five new tests cover the rotated-gap witness,\nan actual successful exchange, permitted reflection and relative positions,\nwhole-group fallback when rotation or reflection is forbidden, and strict\nincumbent preservation when floating-point movement increases charged material. The initial\nbuild failed because two helper annotations used Item instead of Arc<Item>;\nits source, logs and driver are retained. The repair changes only those types.\n\nThe next suite passed 87 tests and failed two. A focused authored trace shows\nboth sheets repair and validate, but charged material rises from\n19,500.000100 to 19,500.000800 mm²; the strict guard correctly refuses it.\nThat exact fixture now explicitly tests rejection and unchanged state. A\nseparate ceiling strip fixes the receiver envelope for the successful exchange\ntest, retaining every original success assertion. The other failure came from\nthe test reassociating floating-point arithmetic; it now requires exact equality\nwith the promised original x+to-from calculation. No runtime change, tolerance\nrelaxation, new seed or altered development input accompanies either correction.\nBoth failed builds, all source versions and the diagnostic trace remain.\n\nNormal-mode public results match baseline exactly apart from elapsed wall time;\ncandidate common-mode replays match, and public validation metrics and counts\nare exact. The original baseline observer is reused byte-identically. Every\narchive member, CRC, source and executable hash is checked. No quality claim\nfollows from these authored checks.\n\nThe separately committed 72-outcome pilot retains four development jobs, two\nkerfs, three seeds and three arms, 60-second budgets, rotating arm order and\neight physical CCD0 cores. Blocks, scoring, per-case handling and measurement\nfunctions are AST-identical to the previous pilot. It cannot close the full\n13-job H5 gate or change the +1% material limit. H2/H5 remain open at 60%.\n",encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in ['h5-return-frame-preparation-20261017','h5-return-frame-pilot-20261017']:
        f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'members':len(inventory),'bytes':archive.stat().st_size,'sha256':digest(archive)}))
