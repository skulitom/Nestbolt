from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'output/seal_h5_return_frame.py';s=p.read_text(encoding='utf-8')
s=s.replace('89 passed','90 passed').replace("'optimized_core_passed':89","'optimized_core_passed':90").replace("probe/'core-tests-v2.log'","probe/'core-tests-v3.log'")
s=s.replace("'all_85_previous_tests_and_four_new_frame_tests_pass'","'all_85_previous_tests_and_five_new_frame_tests_pass'")
s=s.replace("'build_h5_return_frame_v2.py',", "'build_h5_return_frame_v2.py','build_h5_return_frame_v3.py','diagnose_return_frame_attempt.py',\n             'correct_return_frame_fallback_assertion.py','review_return_frame_guard.py','update_return_frame_sealer.py',")
s=s.replace("'type-repair.json']:shutil", "'type-repair.json','fallback-assertion-review.json','material-guard-review.json']:shutil")
s=s.replace('**89 optimized core tests','**90 optimized core tests').replace('All 85 previous tests remain. Four new tests cover','All 85 previous tests remain. Five new tests cover')
s=s.replace('an actual successful exchange, permitted reflection and relative positions,\\nand whole-group fallback when rotation or reflection is forbidden.', 'an actual successful exchange, permitted reflection and relative positions,\\nwhole-group fallback when rotation or reflection is forbidden, and strict\\nincumbent preservation when floating-point movement increases charged material.')
s=s.replace('The repair changes only those types.\\n', 'The repair changes only those types.\\n\\nThe next suite passed 87 tests and failed two. A focused authored trace shows\\nboth sheets repair and validate, but charged material rises from\\n19,500.000100 to 19,500.000800 mm²; the strict guard correctly refuses it.\\nThat exact fixture now explicitly tests rejection and unchanged state. A\\nseparate ceiling strip fixes the receiver envelope for the successful exchange\\ntest, retaining every original success assertion. The other failure came from\\nthe test reassociating floating-point arithmetic; it now requires exact equality\\nwith the promised original x+to-from calculation. No runtime change, tolerance\\nrelaxation, new seed or altered development input accompanies either correction.\\nBoth failed builds, all source versions and the diagnostic trace remain.\\n')
s=s.replace("out.mkdir()", """assert (probe/'candidate'/plan['changed_file']).read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(probe/'build-v2-failure/exchange.rs').read_text(encoding='utf-8').split('#[cfg(test)]')[0]
assert load(probe/'material-guard-review.json')['material_limit_changed'] is False
assert load(probe/'authored-diagnosis/result.json')['exit_code']==101
assert digest(probe/'authored-diagnosis/trace.log')==load(probe/'material-guard-review.json')['trace_sha256']
out.mkdir()""")
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Updated sealer for all original failures, precise fixture review and 90 required tests.')
