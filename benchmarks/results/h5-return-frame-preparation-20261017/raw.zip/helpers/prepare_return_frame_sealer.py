from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/seal_h5_complete_sets.py').read_text(encoding='utf-8')
s=s.replace('h5-complete-set','h5-return-frame').replace('85 passed','89 passed').replace("'optimized_core_passed':85","'optimized_core_passed':89")
s=s.replace("probe/'core-tests.log'","probe/'core-tests-v2.log'")
start=s.index("for name in ['prepare_h5_complete_sets.py'")
end=s.index("inventory=",start)
s=s[:start]+'''for name in ['prepare_h5_return_frame.py','build_h5_return_frame.py','build_h5_return_frame_v2.py',
             'repair_return_frame_types.py','prepare_return_frame_checks.py','check_h5_return_frame_public.py',
             'check_h5_return_frame_harness.py','prepare_return_frame_sealer.py','seal_h5_return_frame.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/paired-runner.py']=root/'scripts/h5_return_frame_pilot.py'
'''+s[end:]
s=s.replace("'equal_and_larger_return_area_authored_exchanges_pass':True,", "'all_85_previous_tests_and_four_new_frame_tests_pass':True,'original_type_error_preserved':True,")
start=s.index("(out.parent/(out.name+'.md')).write_text(")
end=s.index("with (root/'.gitattributes')",start)
doc='''# Reciprocal return-frame preparation — 2026-10-17

**89 optimized core tests, strict lint, ten authored observer outcomes and four
public CLI comparisons pass.** Five unchanged adversarial paired-harness checks
also pass. Production remains unchanged; this is an isolated experiment.

[Four completed diagnostic traces](h5-complete-stage-diagnosis-20261017.md)
observed all 23 attempted complete exchanges repair the receiving sheet and
then fail return-sheet repair. Those traces did not record poses, so they do
not establish that any mechanical failure was caused by rotation. A separate
[authored witness](h5-return-frame-witness-20261017.md) verifies a legal rotated
return with identical independently measured material; the translation-only
version collides. The witness's original mistaken material assertion remains
preserved with its original reports and a review, without rerunning validation.

The candidate changes only initial return poses for complete two/three-part
groups. It maps each pose through incoming-before × inverse(incoming-here),
including permitted reflections, only when every returned part permits its
resulting orientation. Otherwise the whole group uses the previous translation.
Equal incoming frames retain exactly the previous arithmetic. The separator
can subsequently move each part independently. Single-part fallbacks, complete
set eligibility, proposal ranking/caps, both repairs, independent whole-job
geometry/material validation, rollback and deadlines remain unchanged.

All 85 previous tests remain. Four new tests cover the rotated-gap witness,
an actual successful exchange, permitted reflection and relative positions,
and whole-group fallback when rotation or reflection is forbidden. The initial
build failed because two helper annotations used Item instead of Arc<Item>;
its source, logs and driver are retained. The repair changes only those types.

Normal-mode public results match baseline exactly apart from elapsed wall time;
candidate common-mode replays match, and public validation metrics and counts
are exact. The original baseline observer is reused byte-identically. Every
archive member, CRC, source and executable hash is checked. No quality claim
follows from these authored checks.

The separately committed 72-outcome pilot retains four development jobs, two
kerfs, three seeds and three arms, 60-second budgets, rotating arm order and
eight physical CCD0 cores. Blocks, scoring, per-case handling and measurement
functions are AST-identical to the previous pilot. It cannot close the full
13-job H5 gate or change the +1% material limit. H2/H5 remain open at 60%.
'''
s=s[:start]+"(out.parent/(out.name+'.md')).write_text("+repr(doc)+",encoding='utf-8',newline='\\n')\n"+s[end:]
s=s.replace("out.mkdir()", """for row in plan['new_candidate_files']:assert digest(probe/'candidate'/row['path'])==row['sha256']
repair=load(probe/'type-repair.json')
for name,expected in repair['preserved_files'].items():assert digest(probe/'build-v1-failure'/name)==expected
assert load(probe/'build-v1-failure/build-failure.json')['stages'][-1]['exit_code']==101
import difflib
before=(Path(plan['old_probe'])/'candidate'/plan['changed_file']).read_text(encoding='utf-8')
after=(probe/'candidate'/plan['changed_file']).read_text(encoding='utf-8')
(probe/'candidate-final.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='complete-set-candidate',tofile='return-frame-candidate')),encoding='utf-8',newline='\\n')
out.mkdir()""")
s=s.replace("'candidate.patch','pilot-method.json'", "'candidate.patch','candidate-final.patch','pilot-method.json','type-repair.json'")
compile(s,'seal_h5_return_frame.py','exec')
(root/'output/seal_h5_return_frame.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared candidate sealer; no checks assumed and no evidence sealed yet.')
