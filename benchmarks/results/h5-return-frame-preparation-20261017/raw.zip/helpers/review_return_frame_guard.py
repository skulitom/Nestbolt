"""Keep strict material rejection and add a distinct envelope-stable integration fixture."""
from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-return-frame-probe-20261017'
trace=(probe/'authored-diagnosis/trace.log').read_text(encoding='utf-8')
assert 'material_area: 19500.0008' in trace and 'before_material=19500.000099999997' in trace
assert 'FRAME source_loss=0 ' in trace and 'authored exchange seed=0' in trace
assert json.loads((probe/'authored-diagnosis/result.json').read_bytes())['exit_code']==101
path=probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs';before=path.read_bytes();s=before.decode()
start=s.index('    #[test]\n    fn directed_exchange_uses_the_rotated_return_gap()')
end=s.index('    #[test]\n    fn return_frame_preserves_permitted_reflection',start)
original=s[start:end]
guard='''    #[test]
    fn return_frame_keeps_incumbent_when_roundoff_increases_charged_material() {
        let (mut job, before) = return_frame_witness();
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        let (moved, _, stats) = exercise(&job, &before, 0, true, false, 0);
        // This exact authored attempt repairs both sheets but raises charged
        // material by 0.0007 mm2. The strict guard must retain the incumbent;
        // exercise also requires exact internal-state preservation on failure.
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

'''
success=original.replace('let (mut job, before) = return_frame_witness();','let (mut job, mut before) = return_frame_witness();')
needle='        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);'
assert success.count(needle)==1
success=success.replace(needle,'''        // A separate fixed top strip controls this sheet's occupied height.
        // It isolates successful frame use from the original fixture's strict
        // floating-point material rejection, which has its own test above.
        job.parts.push(rectangle("ceiling", 94.0, 1.0));
        before.placements.push(Placement {
            part_id: "ceiling".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 97.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
'''+needle)
s=s[:start]+guard+success+s[end:];path.write_text(s,encoding='utf-8',newline='\n')
record={'before_source_sha256':sha256(before).hexdigest(),'after_source_sha256':sha256(path.read_bytes()).hexdigest(),
        'trace_sha256':sha256((probe/'authored-diagnosis/trace.log').read_bytes()).hexdigest(),
        'first_proposal':{'receiver_loss':0,'return_sheet_loss':0,'independently_valid':True,'before_material_mm2':19500.000099999997,'after_material_mm2':19500.0008},
        'original_failing_source_and_results_preserved':True,
        'original_fixture_retained_as_strict_rejection_test':True,
        'separate_success_fixture':'Same authored layout with a distinct 94x1 mm ceiling on receiver at (2,97), making a persistent sheet envelope. Every previous successful-exchange assertion remains.',
        'runtime_change':False,'material_limit_changed':False,'frozen_jobs_changed':False,'additional_tests_now':5}
(probe/'material-guard-review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,probe/'review-material-guard.py')
driver=(root/'output/build_h5_return_frame_v2.py').read_text(encoding='utf-8').replace("label+'-v2.log'","label+'-v3.log'").replace("out/'progress-v2.json'","out/'progress-v3.json'").replace("out/'build-failure-v2.json'","out/'build-failure-v3.json'")
(root/'output/build_h5_return_frame_v3.py').write_text(driver,encoding='utf-8',newline='\n')
print(json.dumps(record))
