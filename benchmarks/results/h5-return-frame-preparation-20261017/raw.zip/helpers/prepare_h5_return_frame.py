"""Isolated reciprocal return-frame initialization, with legal translation fallback."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib
import json
import shutil
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
out=root/'output/h5-return-frame-probe-20261017';out.mkdir()
old=root/'output/h5-complete-set-probe-20261017'
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
before=path.read_text(encoding='utf-8')
assert sha256(path.read_bytes()).hexdigest()=='bdf31c479b78844075b90333ad33bff79aa50e10d60a0df229fd0411995ed291'
text=before;start=text.index('                    let (from_x, from_y) = proposal.incoming.translation();')
end=text.index('                    self.clock',start)
text=text[:start]+'''                    let returned = if victims.len() == 1 {
                        vec![convert_sample_to_closest_feasible(incoming_old, &victims[0].1)]
                    } else {
                        return_group_poses(&victims, proposal.incoming, incoming_old)
                    };
                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        next_source.place_item(victim, pose);
                    }
'''+text[end:]
marker="impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {"
assert text.count(marker)==1
text=text.replace(marker,(root/'output/return_frame_helper.rs').read_text(encoding='utf-8')+'\n'+marker)
closing=text.rindex('\n}')
text=text[:closing]+'\n'+(root/'output/return_frame_tests.rs').read_text(encoding='utf-8')+text[closing:]
path.write_text(text,encoding='utf-8',newline='\n')
new_files=[]
for name in ['job','before']:
    p=out/'candidate/examples'/('return-frame-'+name+'.json')
    shutil.copyfile(root/'benchmarks/results/h5-return-frame-witness-20261017'/(name+'.json'),p)
    new_files.append({'path':p.relative_to(out/'candidate').as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()})
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='rejected-complete-set',tofile='return-frame-candidate')),encoding='utf-8',newline='\n')
files={arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']}
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),'changed_file':rel,
    'production_digest':source_digest(),'old_source_files':files,'new_candidate_files':new_files,
    'target':str(root/'output/h5-return-frame-target-20261017'),
    'baseline_observer_sha256':sha256((out/'baseline-observer.exe').read_bytes()).hexdigest(),
    'evidence':{'diagnosis':'benchmarks/results/h5-complete-stage-diagnosis-20261017/verification.json',
                'witness':'benchmarks/results/h5-return-frame-witness-20261017/review.json'},
    'only_search_policy_change':'Initialize complete return groups with incoming-before * inverse(incoming-here) when every member permits its orientation; otherwise preserve the exact old translation. Equal frames retain exact old arithmetic. Both repairs and all geometry/material/deadline guards unchanged.',
    'test_change':'Four additional tests: independent quarter-turn witness, actual directed exchange, permitted reflection/relative geometry, and whole-group fallback for forbidden orientations. All old tests retained.',
    'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
build=(root/'output/build_h5_complete_sets.py').read_text(encoding='utf-8').replace('h5-complete-set-probe-20261017','h5-return-frame-probe-20261017')
needle="    assert digest(out/'baseline-observer.exe')==plan['baseline_observer_sha256']"
assert needle in build
build=build.replace(needle,needle+"\n    for row in plan['new_candidate_files']:assert digest(out/'candidate'/row['path'])==row['sha256']")
(root/'output/build_h5_return_frame.py').write_text(build,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'new_tests':4,'production_digest':plan['production_digest']}))
