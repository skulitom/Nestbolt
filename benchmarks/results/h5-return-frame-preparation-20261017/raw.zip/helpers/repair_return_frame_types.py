from pathlib import Path
from hashlib import sha256
import json, shutil

root=Path(__file__).resolve().parents[1]
out=root/'output/h5-return-frame-probe-20261017'
saved=out/'build-v1-failure'; saved.mkdir()
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs'
for name in ['format.log','core-tests.log','progress.json','build-failure.json']:
    shutil.copyfile(out/name,saved/name)
for name in ['build_h5_return_frame.py','return_frame_helper.rs','return_frame_tests.rs']:
    shutil.copyfile(root/'output'/name,saved/name)
shutil.copyfile(path,saved/'exchange.rs')
before=path.read_bytes()
text=before.decode('utf-8')
assert text.count('(PItemKey, Item, DTransformation)')==2
text=text.replace('(PItemKey, Item, DTransformation)','(PItemKey, std::sync::Arc<Item>, DTransformation)')
path.write_text(text,encoding='utf-8',newline='\n')
driver=(root/'output/build_h5_return_frame.py').read_text(encoding='utf-8')
driver=driver.replace("label+'.log'","label+'-v2.log'").replace("out/'progress.json'","out/'progress-v2.json'").replace("out/'build-failure.json'","out/'build-failure-v2.json'")
(root/'output/build_h5_return_frame_v2.py').write_text(driver,encoding='utf-8',newline='\n')
record={'reason':'Pinned Jagua placed items share Arc<Item>; helper and test annotations incorrectly required owned Item. Only these two annotations changed. No algorithm or test assertion change.',
        'before_sha256':sha256(before).hexdigest(),'after_sha256':sha256(path.read_bytes()).hexdigest(),
        'preserved_files':{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(saved.iterdir())},'original_build_failed':True,'measured_search_started':False}
(out/'type-repair.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'repair-types.py')
print(json.dumps(record))
