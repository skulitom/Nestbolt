"""Prepare unchanged authored checks and matched pilot for return-frame initialization."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-return-frame-probe-20261017'
old='h5-complete-set';new='h5-return-frame'
for src,dst in [('check_h5_complete_sets_public.py','check_h5_return_frame_public.py'),('check_h5_complete_set_harness.py','check_h5_return_frame_harness.py')]:
    s=(root/'output'/src).read_text(encoding='utf-8').replace(old,new).replace('h5_complete_set_pilot','h5_return_frame_pilot')
    p=root/'output'/dst;assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
reference=root/'scripts/h5_complete_set_pilot.py'
original=reference.read_text(encoding='utf-8')
s=original.replace(old,new)
s=s.replace('The candidate can return the complete actual obstruction set regardless of combined filled area, keeping', 'The candidate initializes complete return groups in the reciprocal incoming frame when all orientations permit it, keeping')
s=s.replace('Isolated complete-set eligibility candidate','Isolated reciprocal return-frame candidate')
s=s.replace('h5-obstruction-stage-diagnosis-20261017','h5-complete-stage-diagnosis-20261017').replace('h5_obstruction_stage_diagnosis.py','h5_complete_stage_diagnosis.py')
s=s.replace('h5-area-witness-20261017','h5-return-frame-witness-20261017')
s=s.replace('h5-obstruction-set-recovered-pilot-20261016','h5-complete-set-pilot-20261017')
names=['blocks','summarize','case','measure']
def body(t,n):return ast.dump(next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n),include_attributes=False)
for n in names:assert body(original,n)==body(s,n),n
target=root/'scripts/h5_return_frame_pilot.py';assert not target.exists()
compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
record={'reference':reference.relative_to(root).as_posix(),'reference_sha256':sha256(reference.read_bytes()).hexdigest(),
        'runner':target.relative_to(root).as_posix(),'runner_sha256':sha256(target.read_bytes()).hexdigest(),
        'unchanged_function_AST':names,'thresholds_geometry_and_budgets_unchanged':True,
        'prerequisites':'Completed complete-set stage diagnosis, return-frame witness, new functional checks, completed H4 recovery and scale.'}
(probe/'pilot-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
