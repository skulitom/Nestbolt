"""Read saved development outcomes only; compare filled-outer area with ordinary material."""
from pathlib import Path
from hashlib import sha256
import json,zipfile,statistics
root=Path(__file__).resolve().parents[1];out=root/'benchmarks/results/h5-complete-set-pilot-20261017'
result=json.loads((out/'results.json').read_bytes());rows=[]
def area(r):return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(r,r[1:]+r[:1])))/2
for name in ['m-mechanical-large-plates','m-mechanical-panel-hardware']:
    for kerf in [0.2,1.5]:
        records=[r for r in result['records'] if r['job']==name and r['kerf_mm']==kerf and r['arm']=='normal']
        assert len(records)==3 and all(r['status']=='valid' for r in records)
        r=records[0];archive=out/r['archive'];assert sha256(archive.read_bytes()).hexdigest()==r['archive_sha256']
        with zipfile.ZipFile(archive) as z:job=json.loads(z.read('nested/job.json'))
        assert all(len(p['geometry'])==1 for p in job['parts'])
        outer=sum(p['quantity']*area(p['geometry'][0]['outer']) for p in job['parts'])
        holes=sum(p['quantity']*sum(area(h) for h in p['geometry'][0]['holes']) for p in job['parts'])
        normal=statistics.median(r['metrics']['material_area'] for r in records)
        rows.append({'job':name,'kerf':kerf,'filled_outer_area_mm2':outer,'hole_area_mm2':holes,'ordinary_median_material_mm2':normal,
                     'area_bound_vs_ordinary_percent':100*(outer/normal-1),'area_bound_proves_original_limit_impossible':outer>normal*1.01,
                     'archive':r['archive'],'archive_sha256':r['archive_sha256']})
record={'scope':__doc__,'note':'Simple outer-area bound excludes clearance and packing losses; a lower value does not prove feasibility. Original quantities and filled outer rings only.',
        'results_sha256':sha256((out/'results.json').read_bytes()).hexdigest(),'records':rows,'new_searches':0}
(root/'output/h5-global-area-bound-20261017.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
