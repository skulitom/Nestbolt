from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
import shutil
import subprocess
import sys
import traceback
root=Path(__file__).resolve().parents[1];out=root/'output/h5-return-frame-probe-20261017'
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(out/'preparation.json');records=[]
def guards():
    assert source_digest()==plan['production_digest']
    for arm,rows in plan['old_source_files'].items():
        for row in rows:
            assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
            if not (arm=='candidate' and row['path']==plan['changed_file']):
                assert digest(out/arm/row['path'])==row['sha256']
    assert digest(out/'baseline-observer.exe')==plan['baseline_observer_sha256']
    for row in plan['new_candidate_files']:assert digest(out/'candidate'/row['path'])==row['sha256']
def run(label,args):
    guards();started=datetime.now(timezone.utc).isoformat()
    with (out/(label+'.log')).open('xb') as f:
        p=subprocess.run(args,cwd=out/'candidate',stdout=f,stderr=subprocess.STDOUT,timeout=1800)
    row={'label':label,'command':list(map(str,args)),'exit_code':p.returncode,'started':started,
        'finished':datetime.now(timezone.utc).isoformat(),'log_sha256':digest(out/(label+'.log'))}
    records.append(row);write(out/'progress.json',records);print(json.dumps(row),flush=True)
    assert p.returncode==0,label
try:
    run('format',['cargo','fmt','--all'])
    run('core-tests',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',plan['target']])
    run('clippy',['cargo','clippy','--locked','-p','nestbolt-core','--lib','--example','exchange_probe','--target-dir',plan['target'],'--','-D','warnings'])
    run('observer',['cargo','build','--release','--locked','-p','nestbolt-core','--example','exchange_probe','--target-dir',plan['target']])
    guards();shutil.copyfile(Path(plan['target'])/'release/examples/exchange_probe.exe',out/'candidate-observer.exe')
    write(out/'build-v2.json',{'all_checks_passed':True,'stages':records,'production_unchanged':True,
        'source_sha256':digest(out/'candidate'/plan['changed_file']),
        'binaries':{arm:digest(out/(arm+'-observer.exe')) for arm in ['baseline','candidate']},
        'baseline_reused_byte_identical':True,'measured_search_started':False})
except BaseException:
    write(out/'build-failure.json',{'error':traceback.format_exc(),'stages':records});raise
