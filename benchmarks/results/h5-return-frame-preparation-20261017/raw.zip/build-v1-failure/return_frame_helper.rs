// Only choose the reciprocal frame when every returned part permits it. The
// separator can still move the parts independently; this is an initial pose.
fn return_group_poses(
    victims: &[(PItemKey, Item, DTransformation)],
    incoming_here: DTransformation,
    incoming_before: DTransformation,
) -> Vec<DTransformation> {
    let (from_x, from_y) = incoming_here.translation();
    let (to_x, to_y) = incoming_before.translation();
    let translated = || {
        victims
            .iter()
            .map(|(_, _, previous)| {
                let (x, y) = previous.translation();
                DTransformation::new(
                    previous.rotation(),
                    (x + to_x - from_x, y + to_y - from_y),
                )
                .with_reflection(previous.reflected)
            })
            .collect()
    };
    // Keep the previous arithmetic exactly when the two frames already agree.
    if incoming_here.rotation() == incoming_before.rotation()
        && incoming_here.reflected == incoming_before.reflected
    {
        return translated();
    }
    let frame = incoming_here
        .compose()
        .inverse()
        .transform(&incoming_before.compose());
    let aligned: Option<Vec<_>> = victims
        .iter()
        .map(|(_, victim, previous)| {
            let pose = previous.compose().transform(&frame).decompose();
            victim.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect();
    aligned.unwrap_or_else(translated)
}

