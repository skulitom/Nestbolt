"""Read back the one closed strip calls without interpreting UNKNOWN as failure."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-aligned-nine-strip-probe-20261026';RUN=BASE/'search';SOURCE=ROOT/'output/h5-aligned-nine-strip-source-20261026';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Check all immutable model/source hashes, complete one-pattern inventory, exactly one opened call per pattern, actual models, exact parameters and response statuses. Record solver soft overruns and shared time. For every positive independently evaluate all returned variables and active constraints, each original stock-bound anchor and every full guarded face for all36 physical pairs, including faces removed only by interval proofs. Negatives are limited to the prescribed orientations; UNKNOWN supports no exclusion. No solver/native call or full66-target claim.'})
for path in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');budget=load(RUN/'budget.json');process=load(RUN/'process.json');census=load(RUN/'census.json');rows=load(BASE/'inventory.json');assert len(rows)==1 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==45 and budget['workers']==4 and budget['seed']==0 and budget['shared_seconds']==60 and budget['deadline_perf_counter']==budget['start_perf_counter']+60
assert not process['timeout'] and process['exit_code']==0 and process['seconds']<=60 and not census['pending_pairs'] and len(census['results'])==census['solver_calls']==len(list(RUN.rglob('opened.json')))==1
verified=[];negative=[];unknown=[];checked=variables=faces=0
for row,result in zip(rows,census['results']):
    i=row['index'];folder=RUN/f'{i:03d}';saved=load(folder/'result.json');opened=load(folder/'opened.json');assert saved==result and opened['maximum_calls']==saved['solver_calls']==1 and opened['pair']==saved['pair']==i and saved['parts']==list(range(9));model=proto(folder/'model.pb');assert model==proto(BASE/'models'/f'{i:03d}.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=45,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==45
    response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==saved['status'] and abs(response.wall_time-saved['seconds'])<.2 and saved['seconds']<=saved['stage_seconds'] and saved['solver_soft_overshoot_seconds']==max(0,saved['seconds']-45);solution=list(response.solution)
    if saved['status'] in ['UNKNOWN','INFEASIBLE']:
        assert not solution and saved['original_coordinates_units1000'] is None;(negative if saved['status']=='INFEASIBLE' else unknown).append({'pattern':i,'profile_pattern':row['profile_pattern'],'status':saved['status'],'model_sha256':digest(folder/'model.pb'),'response_sha256':digest(folder/'response.pb'),'scope':'Only these nine original parts and prescribed orientations in the guarded short second sheet.'});continue
    assert saved['status'] in ['OPTIMAL','FEASIBLE'] and len(solution)==len(model.variables) and solution[:18]==saved['original_coordinates_units1000']
    for v,n in zip(model.variables,solution):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]));variables+=1
    def truth(v):return bool(solution[v]) if v>=0 else not bool(solution[-v-1])
    for c in model.constraints:
        if not all(truth(v) for v in c.enforcement_literal):continue
        if c.WhichOneof('constraint')=='linear':n=sum(solution[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert c.WhichOneof('constraint')=='bool_or' and any(truth(v) for v in c.bool_or.literals)
        checked+=1
    for j,pi in enumerate(row['profile_pattern']):
        b=spec['anchor_bounds_units1000'][str(pi)];x,y=solution[2*j:2*j+2];assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
    for a,b in combinations(range(9),2):
        case=next(c['index'] for c in spec['mutual_cases'] if [c['profile_a'],c['profile_b']]==[row['profile_pattern'][a],row['profile_pattern'][b]]);dx,dy=solution[2*b]-solution[2*a],solution[2*b+1]-solution[2*a+1]
        for face in load(SOURCE/'mutual'/f'{case:03d}.json')['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in face['outside_halfplanes']);faces+=1
    verified.append({'pattern':i,'status':saved['status'],'parts':[{**p,'profile':pi,'anchor_units1000':solution[2*j:2*j+2]} for j,(p,pi) in enumerate(zip(spec['parts'],row['profile_pattern']))],'nine_original_source_witness':True,'full66_target_witness':False})
assert len(verified)+len(negative)+len(unknown)==1 and census['counts']=={s:sum(r['status']==s for r in census['results']) for s in census['counts']};write(OUT/'verified-strip-witnesses.json',verified);write(OUT/'conditional-negative-patterns.json',negative);write(OUT/'unknown-patterns.json',unknown)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'positive_strip_source_witnesses':len(verified),'conditional_negative_patterns':len(negative),'unknown_patterns':len(unknown),'actual_shared_seconds':process['seconds'],'shared_budget_honored':True,'all_positive_variables_checked':variables,'positive_active_constraints_checked':checked,'full_source_pair_faces_checked':faces,'solver_soft_limit_overruns':sum(r['solver_soft_overshoot_seconds']>0 for r in census['results']),'max_solver_soft_overrun_seconds':max(r['solver_soft_overshoot_seconds'] for r in census['results']),'completed_calls_closed_no_retry':True,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
