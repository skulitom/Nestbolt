"""Coordinate models for the one predeclared nine-original strip constructions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-aligned-nine-strip-source-20261026';OUT=ROOT/'output/h5-aligned-nine-strip-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');data={c['index']:load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in spec['mutual_cases']};cases={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in SOURCE.rglob('*') if p.is_file()},'method':'Exactly one predeclared prescribed-orientation strip constructions, each with nine mandatory originals and18 free integer coordinates. Every original guarded pair face is preserved by exact whole-difference-box tautology and impossible-edge elimination; surviving faces use singleton planes or complete one-sided edge disjunctions. No part is optional, no coordinate is locked, no copy sorting, objective or hint is added. Independent complete model and real import audit before the single declared45second call per pattern, four workers seed0, inside60shared seconds.'});rows=[]
for index,pattern in enumerate(spec['orientation_patterns']):
    model=cp_model_pb2.CpModelProto();bounds=[spec['anchor_bounds_units1000'][str(pi)] for pi in pattern]
    for i,b in enumerate(bounds):
        for axis in range(2):model.variables.add(name=f'p{i}-'+('xy'[axis]),domain=[b[axis],b[axis+2]])
    def linear(a,b,h,flag=None):
        terms=sorted((v,k) for v,k in [(2*a,-h['a']),(2*a+1,-h['b']),(2*b,h['a']),(2*b+1,h['b'])] if k);c=model.constraints.add();c.linear.vars.extend(v for v,k in terms);c.linear.coeffs.extend(k for v,k in terms);c.linear.domain.extend([h['bound'],2**63-1])
        if flag is not None:c.enforcement_literal.append(flag)
    pairs=[];taut=single=impossible=disj=0
    for ia,ib in combinations(range(9),2):
        case=cases[pattern[ia],pattern[ib]];ba,bb=bounds[ia],bounds[ib];delta=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];records=[]
        for face in data[case]['faces']:
            planes=face['outside_halfplanes'];ranges=[(h['a']*delta[0 if h['a']>=0 else 2]+h['b']*delta[1 if h['b']>=0 else 3],h['a']*delta[2 if h['a']>=0 else 0]+h['b']*delta[3 if h['b']>=0 else 1]) for h in planes]
            if any(lo>=h['bound'] for h,(lo,hi) in zip(planes,ranges)):taut+=1;records.append({'face':face['index'],'tautological':True});continue
            live=[j for j,(h,(lo,hi)) in enumerate(zip(planes,ranges)) if hi>=h['bound']];flags=[]
            if len(live)==1:linear(ia,ib,planes[live[0]]);single+=1
            else:
                for j in live:
                    flag=len(model.variables);flags.append(flag);model.variables.add(name=f'p{ia}-{ib}-f{face["index"]}-e{j}',domain=[0,1]);linear(ia,ib,planes[j],flag)
                model.constraints.add().bool_or.literals.extend(flags)
                if not live:impossible+=1
                else:disj+=1
            records.append({'face':face['index'],'live_edges':live,'flags':flags})
        pairs.append({'parts':[ia,ib],'case':case,'difference_bounds':delta,'faces':records})
    p=OUT/'models'/f'{index:03d}.pb';p.write_bytes(model.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');write(OUT/'models'/f'{index:03d}-mapping.json',pairs);rows.append({'index':index,'parts':list(range(9)),'originals':[p['item'] for p in spec['parts']],'profile_pattern':pattern,'variables':len(model.variables),'constraints':len(model.constraints),'solver_seconds':45.0,'model_sha256':digest(p),'tautological_faces':taut,'singleton_faces':single,'impossible_faces':impossible,'disjunctive_faces':disj})
write(OUT/'inventory.json',rows);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'models':1,'coordinate_variables_per_model':18,'full_physical_pairs_per_model':36,'solver_calls':0});print(load(OUT/'prepared.json'));print([{k:r[k] for k in ['index','variables','constraints','tautological_faces','singleton_faces','impossible_faces','disjunctive_faces']} for r in rows])
