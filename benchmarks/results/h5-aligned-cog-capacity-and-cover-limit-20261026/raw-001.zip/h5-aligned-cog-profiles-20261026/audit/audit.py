"""Audit all original profiles and the support-angle screening independently."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,shape
from shapely.affinity import affine_transform,rotate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-aligned-cog-profiles-20261026';SCREEN=ROOT/'output/h5-cog-rotation-support-20261026';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify source hashes, all66 identity obligations, allowed transforms and unchanged ten profiles. Independently rotate full original shapes including holes and compare saved outer bounds/vertices. Recompute all251 support-screen candidates using Shapely rotation of original polygons. Check extrema/height/width at every saved support interval midpoint and endpoints; validate each interval support formula against all80 vertices. Screening is numeric geometry for selecting a new angle, not a packing proof. No solver.'})
spec=load(BASE/'plan.json')
for n,h in spec['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);families={p['id']:p for p in job['parts']};profiles=load(BASE/'profiles.json');parent=load(ROOT/'output/h5-second-strip-four-cogs-source-20261026/profiles.json');assert len(profiles)==11 and all(profiles[i]==parent[i] for i in range(11) if i!=9);assert profiles[9]['rotation_radians']==5*math.pi/16 and profiles[9]['rotation_hex']==(5*math.pi/16).hex();errors=[]
for p in profiles:
    g=families[p['family']];angle=p['rotation_radians'];co,si=math.cos(angle),math.sin(angle);mi=-1 if p['mirrored'] else 1;assert not p['mirrored'] or g['allow_mirror']
    if p['family']=='cog':assert g['rotations']['kind']=='free';cx,cy=p['original_center'];tx,ty=-co*cx+si*cy,-si*cx-co*cy
    else:
        assert p['quarter_turn']*90. in g['rotations']['degrees'];pts=[(mi*x*co-y*si,mi*x*si+y*co) for x,y in g['geometry'][0]['outer']];tx,ty=-min(x for x,y in pts),-min(y for x,y in pts)
    full=affine_transform(Polygon(g['geometry'][0]['outer'],g['geometry'][0].get('holes',[])),[mi*co,-si,mi*si,co,tx,ty]);outer=Polygon(full.exterior);saved=shape(p['geometry']);err=outer.hausdorff_distance(saved);assert full.is_valid and saved.is_valid and err<1e-7 and len(full.interiors)==len(g['geometry'][0].get('holes',[])) and list(saved.bounds)==p['bounds'];errors.append(err)
cog=Polygon(families['cog']['geometry'][0]['outer']);rows=load(SCREEN/'candidate-angles.json');maximum_error=0
for r in rows:
    b=rotate(cog,r['angle_radians'],origin=(0,0),use_radians=True).bounds;w,h=b[2]-b[0],b[3]-b[1];e=max(abs(w-r['width_mm']),abs(h-r['height_mm']));assert e<1e-7;maximum_error=max(maximum_error,e);assert abs(max(w,h)-r['maximum_side_mm'])<1e-7 and abs(w*h-r['area_mm2'])<1e-5
assert len(rows)==251;choices=load(SCREEN/'choices.json')
for name,field in [('minimum_max_side','maximum_side_mm'),('minimum_height','height_mm'),('minimum_area','area_mm2')]:assert choices[name]==min(rows,key=lambda r:r[field])
interval_checks=0
for r in load(SCREEN/'support-intervals.json'):
    lo,hi=r['bounds_radians'];a,b=r['width_cos_sin'];c,d=r['height_cos_sin']
    for t in [lo,(lo+hi)/2,hi]:
        bb=rotate(cog,t,origin=(0,0),use_radians=True).bounds;co,si=math.cos(t),math.sin(t);assert abs(bb[2]-bb[0]-(a*co+b*si))<1e-7 and abs(bb[3]-bb[1]-(c*co+d*si))<1e-7;interval_checks+=1
ids=spec['first_sheet_checked_originals']+spec['mandatory_second_sheet_originals']+spec['pending_first_sheet_originals'];assert sorted(ids)==list(range(66)) and spec['required_original_counts']=={'bracket':4,'insert':1,'cog':4};assert spec['stock_bounds_rational']==load(ROOT/'output/h5-second-strip-four-cogs-source-20261026/plan.json')['stock_bounds_rational']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'profiles_reconstructed':11,'unchanged_profiles_verified':10,'maximum_original_profile_error_mm':max(errors),'screen_candidates_recomputed':251,'support_interval_samples_checked':interval_checks,'maximum_screen_dimension_error_mm':maximum_error,'all66_identity_obligations_preserved':True,'original_cog_outer_vertices':80,'original_cog_hole_vertices':200,'solver_calls':0,'packing_claim':False,'H5_complete':False});print(load(OUT/'checks.json'))
