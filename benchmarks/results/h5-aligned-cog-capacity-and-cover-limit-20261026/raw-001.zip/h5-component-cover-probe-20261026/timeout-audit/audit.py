"""Preserve a watchdog termination without inventing a solver result or budget pass."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time,subprocess
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-component-cover-probe-20261026';RUN=BASE/'search';OUT=BASE/'timeout-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Audit the single opened model/parameters and outer watchdog termination. Preserve the missing terminal solver response,60second watchdog and measured shutdown overhead. Check the specific runner has no live Python process. Do not label this UNKNOWN, INFEASIBLE or a budget pass. No retry or native call.'})
for path in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');folder=RUN/'000';opened=load(folder/'opened.json');assert proc['timeout'] and proc['seconds']>=60 and budget['shared_seconds']==60 and budget['deadline_perf_counter']==budget['start_perf_counter']+60 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==45 and budget['workers']==4 and budget['seed']==0 and opened['maximum_calls']==1 and opened['pair']==0 and opened['seconds_limit']==45
assert len(list(RUN.rglob('opened.json')))==1 and not any((p).exists() for p in [RUN/'census.json',folder/'result.json',folder/'response.pb'])
m=cp_model_pb2.CpModelProto();m.ParseFromString((folder/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((BASE/'models/000.pb').read_bytes());assert m==expected and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=45,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256']
command="@(Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -like '*run_h5_component_cover_probe.py*' } | Select-Object ProcessId,ParentProcessId) | ConvertTo-Json -Compress"
p=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,check=True);live=json.loads(p.stdout or '[]');assert live==[];write(OUT/'runner-process-check.json',{'utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'matching_processes':live})
log=(folder/'solver.log').read_text();assert 'Starting search at' in log and 'CpSolverResponse summary:' not in log
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'opened_calls':1,'closed_calls':1,'controller_status':'WATCHDOG_TIMEOUT','terminal_solver_status':None,'solver_response_available':False,'solver_soft_limit_seconds':45,'shared_watchdog_seconds':60,'controller_elapsed_seconds':proc['seconds'],'controller_shutdown_overshoot_seconds':proc['seconds']-60,'shared_budget_pass_claimed':False,'no_live_runner_processes':True,'retry_permitted':False,'native_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
