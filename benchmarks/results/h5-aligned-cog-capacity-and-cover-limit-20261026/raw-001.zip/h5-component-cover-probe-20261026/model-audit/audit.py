"""Reconstruct every original coordinate, optional interval and global non-overlap constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-component-cover-probe-20261026';SOURCE=ROOT/'output/h5-aligned-component-covers-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct every original anchor domain, exact-one orientation choice, conditional original stock box and identical-copy ordering. Rebuild every interval start/size/end directly from audited cover rectangles and require all2652 intervals to appear in one complete1326-rectangle NoOverlap2D. Optional rectangles share exactly the required original profile flag; every original is mandatory. Require no other fields and actual solver import/export. Cover conservativity comes from the independent triangle-square and coverage audit, not solver status. No solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');allowed=spec['allowed_profiles'];ps={i:load(SOURCE/'profiles'/f'{i:03d}.json') for i in range(11)};m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};vi=ci=0
def var(name,dom):
    global vi
    assert m.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=dom);vi+=1
def lin(terms,lo,hi,enforce=()):
    global ci
    c=cp_model_pb2.ConstraintProto();ids=sorted(v for v,a in terms.items() if a);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce);assert m.constraints[ci]==c,ci;ci+=1
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(ps[p]['anchor_bounds_units1000'][axis] for p in options),max(ps[p]['anchor_bounds_units1000'][axis+2] for p in options)])
flags={}
for i,options in enumerate(allowed):
    if len(options)==1:continue
    flags[i]={}
    for p in options:flags[i][p]=vi;var(f'p{i}-profile{p}',[0,1])
assert {str(i):{str(p):v for p,v in choices.items()} for i,choices in flags.items()}==load(BASE/'profile-flags.json')
for i,choices in flags.items():
    lin(dict.fromkeys(choices.values(),1),1,1)
    for p,v in choices.items():
        b=ps[p]['anchor_bounds_units1000']
        for axis in range(2):lin({2*i+axis:1},b[axis],b[axis+2],[v])
for i in range(3):
    terms={}
    for p in range(8):terms[flags[i][p]]=p;terms[flags[i+1][p]]=-p
    lin(terms,-2**63,0)
for i in range(5,8):lin({2*i:1,2*(i+1):-1},-2**63,0)
assert ci==79;xs=[];ys=[];rectangles=[]
for i,options in enumerate(allowed):
    for p in options:
        active=[flags[i][p]] if i in flags else []
        for j,box in enumerate(ps[p]['rectangles_units1000']):
            indexes=[]
            for axis in range(2):
                c=cp_model_pb2.ConstraintProto(name=f'p{i}-q{p}-r{j}-'+('xy'[axis]));c.enforcement_literal.extend(active);c.interval.start.CopyFrom(cp_model_pb2.LinearExpressionProto(vars=[2*i+axis],coeffs=[1],offset=box[axis]));c.interval.size.offset=box[axis+2]-box[axis];c.interval.end.CopyFrom(cp_model_pb2.LinearExpressionProto(vars=[2*i+axis],coeffs=[1],offset=box[axis+2]));assert m.constraints[ci]==c,ci;indexes.append(ci);ci+=1
            xs.append(indexes[0]);ys.append(indexes[1]);rectangles.append({'part':i,'profile':p,'rectangle':j,'offsets_units1000':box,'active_profiles':active,'interval_constraints':indexes})
c=cp_model_pb2.ConstraintProto();c.no_overlap_2d.x_intervals.extend(xs);c.no_overlap_2d.y_intervals.extend(ys);assert m.constraints[ci]==c;ci+=1
row=load(BASE/'inventory.json')[0];assert len(rectangles)==1326 and rectangles==load(BASE/'rectangles.json') and vi==len(m.variables)==row['variables']==52 and ci==len(m.constraints)==row['constraints']==2732 and row['parts']==list(range(9)) and row['originals']==spec['mandatory_originals'] and row['solver_seconds']==45 and digest(BASE/'models/000.pb')==row['model_sha256']
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'mandatory_originals':9,'optional_profile_rectangles':1326,'intervals_checked':2652,'all_fields_and_coverage_mapping_verified':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
