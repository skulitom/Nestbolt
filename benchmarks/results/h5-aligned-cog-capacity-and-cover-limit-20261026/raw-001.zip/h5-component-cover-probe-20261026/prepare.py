"""Pack conservative original-shape rectangle covers with shared anchors."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-aligned-component-covers-20261026';OUT=ROOT/'output/h5-component-cover-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');allowed=spec['allowed_profiles'];profiles={i:load(SOURCE/'profiles'/f'{i:03d}.json') for i in range(11)}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in SOURCE.rglob('*') if p.is_file()},'method':'18 free original anchor coordinates,34 one-hot profile flags: each bracket chooses8 approved profiles, insert chooses2, four cogs retain56.25degrees. Every optional rectangle start is its original anchor plus its exact saved integer offset; fixed positive sizes form1326 rectangles and2652 interval constraints. A single global NoOverlap2D retains all active rectangles, including same-part rectangles independently proved interior-disjoint. Original profile stock boxes are conditionally enforced; guarded covers may extend beyond stock while original outlines retain their original stock guard. Sort identical bracket profile numbers and cog x anchors only. No optional original, changed count, hints or coordinate locks. One45second4worker seed0 call in60shared seconds after complete audit. A positive needs original-shape verification; negative/UNKNOWN makes no unrestricted packing claim.'})
m=cp_model_pb2.CpModelProto();flags={}
for i,options in enumerate(allowed):
    bs=[profiles[p]['anchor_bounds_units1000'] for p in options]
    for axis in range(2):m.variables.add(name=f'p{i}-'+('xy'[axis]),domain=[min(b[axis] for b in bs),max(b[axis+2] for b in bs)])
for i,options in enumerate(allowed):
    if len(options)==1:continue
    flags[i]={}
    for p in options:flags[i][p]=len(m.variables);m.variables.add(name=f'p{i}-profile{p}',domain=[0,1])
def lin(terms,lo,hi,enforce=()):
    c=m.constraints.add();ids=sorted(v for v,a in terms.items() if a);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce)
for i,choices in flags.items():
    lin({v:1 for v in choices.values()},1,1)
    for p,v in choices.items():
        b=profiles[p]['anchor_bounds_units1000']
        for axis in range(2):lin({2*i+axis:1},b[axis],b[axis+2],[v])
for i in range(3):lin({**{flags[i][p]:p for p in allowed[i]},**{flags[i+1][p]:-p for p in allowed[i+1]}},-2**63,0)
for i in range(5,8):lin({2*i:1,2*(i+1):-1},-2**63,0)
linear_constraints=len(m.constraints);rectangles=[];xs=[];ys=[]
for i,options in enumerate(allowed):
    for p in options:
        active=[flags[i][p]] if i in flags else []
        for j,r in enumerate(profiles[p]['rectangles_units1000']):
            indexes=[]
            for axis in range(2):
                indexes.append(len(m.constraints));c=m.constraints.add(name=f'p{i}-q{p}-r{j}-'+('xy'[axis]));c.enforcement_literal.extend(active);iv=c.interval;iv.start.vars.append(2*i+axis);iv.start.coeffs.append(1);iv.start.offset=r[axis];iv.size.offset=r[axis+2]-r[axis];iv.end.vars.append(2*i+axis);iv.end.coeffs.append(1);iv.end.offset=r[axis+2]
            xs.append(indexes[0]);ys.append(indexes[1]);rectangles.append({'part':i,'profile':p,'rectangle':j,'offsets_units1000':r,'active_profiles':active,'interval_constraints':indexes})
c=m.constraints.add();c.no_overlap_2d.x_intervals.extend(xs);c.no_overlap_2d.y_intervals.extend(ys)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'rectangles.json',rectangles);write(OUT/'profile-flags.json',flags);row={'index':0,'parts':list(range(9)),'originals':spec['mandatory_originals'],'variables':len(m.variables),'constraints':len(m.constraints),'linear_constraints':linear_constraints,'rectangles':len(rectangles),'solver_seconds':45.,'model_sha256':digest(p)};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**row,'solver_calls':0});print(load(OUT/'prepared.json'))
