"""Enumerate original cog support events before choosing a new source angle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import MultiPoint
ROOT=Path(__file__).resolve().parents[1];JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SOURCE=ROOT/'output/h5-all-bracket-strip-source-20261026';OUT=ROOT/'output/h5-cog-rotation-support-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'inspect.py');start=time.perf_counter();job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');assert part['rotations']['kind']=='free' and not part['allow_mirror'];old=load(SOURCE/'profiles.json')[9];center=old['original_center'];pts=[(x-center[0],y-center[1]) for x,y in part['geometry'][0]['outer']];hull=list(MultiPoint(pts).convex_hull.exterior.coords)[:-1];tau=2*math.pi
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,SOURCE/'profiles.json',SOURCE/'plan.json',ROOT/'output/h5-shared-bracket-strip-probe-20261026/response-audit/checks.json']},'method':'Geometric screening only, no solver. Enumerate all support-switch angles from exact original convex hull edges over0..2pi, covering x/y maxima and minima. Between switches each bounding width/height is one sinusoid. Add all width/height stationary points, width=height crossings, and area stationary points. Evaluate the actual80 original vertices at every candidate. Choose a minimum maximum-side candidate, and separately report minimum height and area. Floating computations support angle selection only, not a formal global packing exclusion. Keep the original80 vertices and200-vertex hole; do not substitute a circle or a simplified shape.'})
events={0.,tau}
for p,q in zip(hull,hull[1:]+hull[:1]):
    phi=math.atan2(q[1]-p[1],q[0]-p[0])
    for offset in [0,math.pi/2,math.pi,3*math.pi/2]:events.add((-phi+offset)%tau)
events=sorted(events)
def dims(t):
    co,si=math.cos(t),math.sin(t);xs=[co*x-si*y for x,y in pts];ys=[si*x+co*y for x,y in pts];return max(xs)-min(xs),max(ys)-min(ys)
def roots(base,period,lo,hi):return [v for k in range(math.floor((lo-base)/period)-1,math.ceil((hi-base)/period)+2) if lo<(v:=base+k*period)<hi]
candidates=set(events);intervals=[]
for lo,hi in zip(events,events[1:]):
    if hi-lo<1e-14:continue
    mid=(lo+hi)/2;co,si=math.cos(mid),math.sin(mid);xi=[co*x-si*y for x,y in pts];yi=[si*x+co*y for x,y in pts];imax,imin=max(range(len(pts)),key=xi.__getitem__),min(range(len(pts)),key=xi.__getitem__);jmax,jmin=max(range(len(pts)),key=yi.__getitem__),min(range(len(pts)),key=yi.__getitem__)
    a=pts[imax][0]-pts[imin][0];b=pts[imin][1]-pts[imax][1];c=pts[jmax][1]-pts[jmin][1];d=pts[jmax][0]-pts[jmin][0]
    points=roots(math.atan2(b,a),math.pi,lo,hi)+roots(math.atan2(d,c),math.pi,lo,hi)+roots(math.atan2(-(a-c),b-d),math.pi,lo,hi)+roots(math.atan2(a*d+b*c,a*c-b*d)/2,math.pi/2,lo,hi)
    candidates.update(points);intervals.append({'bounds_radians':[lo,hi],'support_vertex_indices':[imax,imin,jmax,jmin],'width_cos_sin':[a,b],'height_cos_sin':[c,d],'stationary_or_crossing_angles':points})
rows=[{'angle_radians':t,'angle_degrees':math.degrees(t),'width_mm':(wh:=dims(t))[0],'height_mm':wh[1],'maximum_side_mm':max(wh),'area_mm2':wh[0]*wh[1]} for t in sorted(candidates)]
choices={k:min(rows,key=lambda r:r[field]) for k,field in [('minimum_max_side','maximum_side_mm'),('minimum_height','height_mm'),('minimum_area','area_mm2')]};oldwh=dims(old['rotation_radians']);best=choices['minimum_max_side'];height=float(load(SOURCE/'plan.json')['stock_bounds_rational'][3][0]/load(SOURCE/'plan.json')['stock_bounds_rational'][3][1])-6.5
write(OUT/'support-events.json',events);write(OUT/'support-intervals.json',intervals);write(OUT/'candidate-angles.json',rows);write(OUT/'choices.json',choices)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'original_outer_vertices':len(pts),'original_hole_vertices':len(part['geometry'][0]['holes'][0]),'hull_vertices':len(hull),'support_intervals':len(intervals),'candidate_angles':len(rows),'old_angle_radians':old['rotation_radians'],'old_width_mm':oldwh[0],'old_height_mm':oldwh[1],'selected_angle_radians':best['angle_radians'],'selected_angle_degrees':best['angle_degrees'],'selected_width_mm':best['width_mm'],'selected_height_mm':best['height_mm'],'height_reduction_mm':oldwh[1]-best['height_mm'],'short_sheet_usable_height_mm':height,'old_vertical_travel_mm':height-oldwh[1],'selected_vertical_travel_mm':height-best['height_mm'],'solver_calls':0,'packing_claim':False,'H5_complete':False});print(load(OUT/'result.json'))
