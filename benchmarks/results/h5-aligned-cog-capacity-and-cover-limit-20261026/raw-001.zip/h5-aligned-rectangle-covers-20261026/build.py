"""Conservative disjoint rectangle covers for original guarded profiles."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
from fractions import Fraction as F
import json,math,shutil,time
from shapely.geometry import Polygon,MultiPoint,box,shape,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-aligned-cog-profiles-20261026';OUT=ROOT/'output/h5-aligned-rectangle-covers-20261026';PAD=.1063
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'profiles').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');assert load(SOURCE/'audit/checks.json')['passed'];st=[F(*v) for v in spec['stock_bounds_rational']];stockpad=F(.0125)+F(.000001)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',ROOT/'output/h5-aligned-nine-strip-probe-20261026/response-audit/checks.json']},'guard_square_halfside_mm':PAD,'maximum_row_height_units1000':4000,'required_counts':{'bracket':4,'insert':1,'cog':4},'mandatory_originals':[21,22,25,26,37,53,63,64,65],'first_sheet_checked_originals':spec['first_sheet_checked_originals'],'pending_first_sheet_originals':[28,29],'allowed_profiles':[list(range(8)) for _ in range(4)]+[[8,10]]+[[9] for _ in range(4)],'stock_bounds_rational':spec['stock_bounds_rational'],'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Sufficient rectangle-cover construction, not a necessary relaxation. Dilate each full original filled-outer profile by a square of halfside0.1063mm, explicitly unioning its boundary segment Minkowski sums. Partition that guarded shape into at-most4mm horizontal rows, adding floor/ceil vertex-y events. Enclose each row intersection in outward-rounded integer x bounds; merge adjacent identical spans. The union of rectangles must cover the entire guarded polygon; rectangles within one profile have disjoint interiors. Global NoOverlap2D can then pack all mandatory pieces using shared original anchors and optional profile flags. Any positive must pass full-original/native-guard checks. A cover-model negative excludes only these covers; it does not prove original packing impossible.'});summary=[]
for p in profiles:
    raw=shape(p['geometry']);pts=list(raw.exterior.coords);square=[(-PAD,-PAD),(-PAD,PAD),(PAD,-PAD),(PAD,PAD)];pieces=[raw]
    for a,b in zip(pts,pts[1:]):pieces.append(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product([a,b],square)]).convex_hull)
    guarded=unary_union(pieces);assert guarded.geom_type=='Polygon' and guarded.covers(raw) and guarded.boundary.distance(raw)> .10629999;gb=guarded.bounds;lo=math.floor(gb[1]*1000-1e-6);hi=math.ceil(gb[3]*1000+1e-6);events={lo,hi}|set(range(lo,hi,4000))
    for x,y in guarded.exterior.coords:events.update([math.floor(y*1000-1e-6),math.ceil(y*1000+1e-6)])
    events=sorted(v for v in events if lo<=v<=hi);rects=[]
    for y0,y1 in zip(events,events[1:]):
        g=guarded.intersection(box(gb[0]-1,y0/1000,gb[2]+1,y1/1000))
        if g.is_empty:continue
        b=g.bounds;x0=math.floor(b[0]*1000-1e-6);x1=math.ceil(b[2]*1000+1e-6);assert x0<x1 and y0<y1
        if rects and rects[-1][0]==x0 and rects[-1][2]==x1 and rects[-1][3]==y0:rects[-1][3]=y1
        else:rects.append([x0,y0,x1,y1])
    union=unary_union([box(*(v/1000 for v in r)) for r in rects]);assert union.covers(guarded) and sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)/1e6-union.area<1e-6
    b=p['bounds'];bounds=[math.ceil((st[0]+stockpad-F(b[0]))*1000),math.ceil((st[1]+stockpad-F(b[1]))*1000),math.floor((st[2]-stockpad-F(b[2]))*1000),math.floor((st[3]-stockpad-F(b[3]))*1000)]
    write(OUT/'profiles'/f"{p['index']:03d}.json",{'profile':p['index'],'family':p['family'],'guarded':mapping(guarded),'rectangles_units1000':rects,'anchor_bounds_units1000':bounds,'original_area_mm2':raw.area,'guarded_area_mm2':guarded.area,'cover_area_mm2':union.area});summary.append({'profile':p['index'],'family':p['family'],'rectangles':len(rects),'cover_excess_over_guarded_mm2':union.area-guarded.area,'minimum_cover_boundary_gap_mm':union.boundary.distance(raw)})
write(OUT/'summary.json',summary);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'profile_rectangles':sum(r['rectangles'] for r in summary),'optional_model_rectangles':4*sum(r['rectangles'] for r in summary[:8])+summary[8]['rectangles']+summary[10]['rectangles']+4*summary[9]['rectangles'],'profiles':11,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'));print(summary)
