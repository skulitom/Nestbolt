from pathlib import Path
from collections import Counter
import math,itertools,json
from shapely.geometry import Polygon,LineString,shape
from shapely.affinity import affine_transform
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;OUT=ROOT/'output/h5-aligned-stagger-20261018';SRC=ROOT/'output/h5-minimum-contact-grids-20261018'

def main():
    plan=base.load(OUT/'plan.json');job=base.load(OUT/'job.json');patterns=base.load(OUT/'patterns.json');assert len(patterns)==72
    for name,h in plan['input_hashes'].items():assert base.digest(ROOT/name)==h
    cog=Polygon(next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer']);original=shape(base.load(SRC/'obstacles/0.0.json'));angle=plan['angle_radians'];c,s=math.cos(angle),math.sin(angle);cx,cy=cog.centroid.coords[0];pitch=plan['pitch_x_mm'];pairs=0;mind=math.inf;error=0.
    # Independent rays in the original, unrotated exclusion polygon.
    for p in patterns.values():
        ct=p['construction'];fraction=ct['fraction'];cols=ct['columns'];n=ct['count'];values=[]
        for k in range(-cols+1,cols):
            for sign in [-1,1]:
                x=(k+sign*fraction)*pitch
                a=(c*x-s*(-1000),s*x+c*(-1000));b=(c*x-s*1000,s*x+c*1000)
                # angle rotates original -> placed, so use inverse for rays.
                a=(c*x+s*(-1000),-s*x+c*(-1000));b=(c*x+s*1000,-s*x+c*1000)
                cross=original.intersection(LineString([a,b]));rot=affine_transform(cross,[c,-s,s,c,0,0])
                if not cross.is_empty:values.extend([abs(rot.bounds[1]),abs(rot.bounds[3])])
        dy=max(values)+.0001;error=max(error,abs(dy-ct['pitch_y_mm']));assert abs(dy-ct['pitch_y_mm'])<1e-8
        gs=[]
        for i in range(n):
            row,col=divmod(i,cols);x=(col+(fraction if row%2 else 0))*pitch;y=row*dy
            gs.append(affine_transform(cog,[c,-s,s,c,x-c*cx+s*cy,y-s*cx-c*cy]))
        xmin=min(g.bounds[0] for g in gs);ymin=min(g.bounds[1] for g in gs);gs=[affine_transform(g,[1,0,0,1,-xmin,-ymin]) for g in gs]
        for g,m in zip(gs,p['members']):
            assert m['part_id']=='cog' and not m['transform']['mirrored'] and m['transform']['rotation_radians']==angle
            assert g.hausdorff_distance(base.gap.pose(cog,m['transform']))<1e-8
        bounds=(max(g.bounds[2] for g in gs),max(g.bounds[3] for g in gs));assert abs(bounds[0]-p['width'])<1e-8 and abs(bounds[1]-p['height'])<1e-8
        for a,b in itertools.combinations(gs,2):pairs+=1;d=a.distance(b);mind=min(mind,d);assert a.disjoint(b) and d>=job['clearance']
    # Recompute every nondominated rectangle and its declared tie break.
    expected=[]
    for n in sorted({len(p['members']) for p in patterns.values()}):
        choices=sorted([p for p in patterns.values() if len(p['members'])==n],key=lambda p:p['id']);seen=set()
        for p in choices:
            key=tuple(round(p[k],8) for k in ['width','height'])
            if key in seen:continue
            seen.add(key)
            dominated=any(q['width']<=p['width']+1e-9 and q['height']<=p['height']+1e-9 and (q['width']<p['width']-1e-9 or q['height']<p['height']-1e-9) for q in choices)
            if not dominated:expected.append(p['id'])
    assert expected==base.load(OUT/'pareto.json');result={'components':72,'original_pair_checks':pairs,'minimum_distance_mm':mind,'maximum_ray_pitch_error_mm':error,'independent_unrotated_rays':True,'all_unrounded_transforms_verified':True,'all_pareto_selections_verified':True,'full_target_witness':False};base.write(OUT/'audit.json',result);print(json.dumps(result))

if __name__=='__main__':main()
