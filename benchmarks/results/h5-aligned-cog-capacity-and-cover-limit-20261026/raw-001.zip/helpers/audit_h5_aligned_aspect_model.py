"""Independent protobuf inventory/domain/constraint audit before the bounded solve."""
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
import json,math
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-aligned-aspect-cpsat-20261018';load=lambda p:json.loads(p.read_bytes())
MIN=-9223372036854775808;MAX=9223372036854775807
def main():
    plan=load(OUT/'plan.json');mp=load(OUT/'mapping.json');patterns=load(OUT/'patterns.json');job=load(OUT/'job.json');target=load(OUT/'conditional-target.json');proto=text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto());vars={v.name:(i,list(v.domain)) for i,v in enumerate(proto.variables)};assert len(vars)==len(proto.variables)
    for name,h in plan['input_hashes'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
    assert not proto.HasField('objective') and not proto.HasField('floating_point_objective') and not proto.HasField('solution_hint')
    st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=plan['block_gap_mm'];scale=plan['scale_per_mm'];width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4];W=math.floor((width+g)*scale);Hs=[math.floor((h+g)*scale) for h in heights];T=sum(Hs);assert (W,Hs,T)==(mp['W'],mp['Hs'],mp['T']) and width==plan['width_mm'] and heights==plan['height_limits_mm']
    expected=Counter();expected_names=set();intervals={};keys=defaultdict(list);areas=[];sources=[];recipes=[[15,0,0],[10,5,0],[9,6,0],[12,3,0],[5,5,5]];assert recipes==plan['recipes']
    def var(name,domain):
        expected_names.add(name);i,d=vars[name];assert d==domain,(name,d,domain);return i
    def expr(e):return (tuple(sorted(zip(e.vars,e.coeffs))),e.offset)
    def lin(en,terms,domain):return ('linear',tuple(en),tuple(sorted((k,v) for k,v in terms.items() if v)),tuple(domain))
    def tab(columns,rows):return ('table',tuple(columns),tuple(sorted(tuple(row) for row in rows)))
    ri=var('recipe',[0,4]);assert ri==mp['recipe_var'];mixes=sorted(n for n,p in patterns.items() if Counter(m['part_id'] for m in p['members'])==Counter(bracket=2,insert=1));assert mixes==plan['bracket_patterns'] and len(mixes)==3
    assert [p['family'] for p in mp['items']]==['frame']*18+['mix']*6+['insert']*15+['cog']*3
    for i,item in enumerate(mp['items']):
        assert item['item']==i;family=item['family'];slot=item['slot'];assert slot==(i-39 if family=='cog' else None);choices=[]
        if family=='cog':names=[n for n in plan['aligned_patterns'] if len(patterns[n]['members']) in {r[slot] for r in recipes}]
        else:names=mixes if family=='mix' else [family]
        if family=='cog' and any(r[slot]==0 for r in recipes):choices.append({'pattern':None,'rotated':False,'w':0,'h':0,'area':0,'count':0})
        for name in names:
            p=patterns[name]
            for rot in [False,True]:
                w,h=(p['height'],p['width']) if rot else (p['width'],p['height']);wi=math.ceil((w+g)*scale);hi=math.ceil((h+g)*scale)
                if wi<=W and hi<=max(Hs):choices.append({'pattern':name,'rotated':rot,'w':wi,'h':hi,'area':wi*hi,'count':len(p['members']) if family=='cog' else None})
        for j,ch in enumerate(choices):ch['choice']=j
        assert choices==item['choices'];domains={'kind':[0,len(choices)-1],'x':[0,W],'y':[0,T],'xe':[0,W],'ye':[0,T],'sheet':[0,1],'key':[0,T*(W+1)+W],'sourcearea':[0,max(c['area'] for c in choices)]}
        for field in ['w','h','area']:domains[field]=[min(c[field] for c in choices),max(c[field] for c in choices)]
        if choices[0]['pattern'] is None:domains['present']=[0,1]
        v={name:var(f'{name}-{i}',domain) for name,domain in domains.items()};assert v==item['vars'];areas.append(v['area']);sources.append(v['sourcearea'])
        expected[tab([v[k] for k in ['kind','w','h','area']],[[ch[k] for k in ['choice','w','h','area']] for ch in choices])]+=1
        expected[lin([],{v['key']:1,v['y']:-(W+1),v['x']:-1},[0,0])]+=1
        expected[lin([-v['sheet']-1],{v['ye']:1},[MIN,Hs[0]])]+=1;expected[lin([v['sheet']],{v['y']:1},[Hs[0],MAX])]+=1
        expected[lin([-v['sheet']-1],{v['sourcearea']:1},[0,0])]+=1;expected[lin([v['sheet']],{v['sourcearea']:1,v['area']:-1},[0,0])]+=1
        if family=='cog':
            rows=[(rj,ch['choice']) for rj,r in enumerate(recipes) for ch in choices if ch['count']==r[slot]];expected[tab([ri,v['kind']],rows)]+=1
            for rj,r in enumerate(recipes):
                allowed=[ch for ch in choices if ch['count']==r[slot]];assert allowed
                for ch in allowed:
                    actual=Counter() if ch['pattern'] is None else Counter(m['part_id'] for m in patterns[ch['pattern']]['members'])
                    assert actual==(Counter(cog=r[slot]) if r[slot] else Counter())
        else:keys[family].append(v['key'])
        enforcement=[]
        if 'present' in v:
            pi=v['present'];enforcement=[pi];expected[lin([pi],{v['kind']:1},[MIN,-1,1,MAX])]+=1;expected[lin([-pi-1],{v['kind']:1},[0,0])]+=1
            for name in ['x','y','xe','ye','sheet']:expected[lin([-pi-1],{v[name]:1},[0,0])]+=1
        for axis,start,size,end in [('x','x','w','xe'),('y','y','h','ye')]:intervals[f'i{axis}-{i}']=(tuple(enforcement),(((v[start],1),),0),(((v[size],1),),0),(((v[end],1),),0))
    required=Counter({p['id']:p['quantity'] for p in job['parts']})
    for r in recipes:assert Counter(frame=18,bracket=12,insert=21,cog=sum(r))==required
    for seq in keys.values():
        for a,b in zip(seq,seq[1:]):expected[lin([],{a:1,b:-1},[MIN,0])]+=1
    expected[lin([],{a:1 for a in areas},[MIN,W*T])]+=1;expected[lin([],{a:1 for a in sources},[MIN,W*Hs[1]])]+=1;expected[lin([],{**{a:1 for a in areas},**{a:-1 for a in sources}},[MIN,W*Hs[0]])]+=1
    found=Counter();ids={};overlaps=[]
    for ci,c in enumerate(proto.constraints):
        kind=c.WhichOneof('constraint')
        if kind=='linear':found[lin(c.enforcement_literal,dict(zip(c.linear.vars,c.linear.coeffs)),c.linear.domain)]+=1
        elif kind=='table':
            assert not c.enforcement_literal and not c.table.negated and not c.table.vars;columns=[]
            for ex in c.table.exprs:assert len(ex.vars)==1 and list(ex.coeffs)==[1] and ex.offset==0;columns.append(ex.vars[0])
            count=len(columns);rows=[tuple(c.table.values[j:j+count]) for j in range(0,len(c.table.values),count)];found[tab(columns,rows)]+=1
        elif kind=='interval':
            assert c.name not in ids;ids[c.name]=ci;assert (tuple(c.enforcement_literal),expr(c.interval.start),expr(c.interval.size),expr(c.interval.end))==intervals[c.name]
        elif kind=='no_overlap_2d':assert not c.enforcement_literal;overlaps.append(c.no_overlap_2d)
        else:raise AssertionError(kind)
    assert found==expected,(found-expected,expected-found);assert set(vars)==expected_names and set(ids)==set(intervals) and len(overlaps)==1
    assert list(overlaps[0].x_intervals)==[ids[f'ix-{i}'] for i in range(42)] and list(overlaps[0].y_intervals)==[ids[f'iy-{i}'] for i in range(42)]
    params=text_format.Parse((OUT/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params.max_time_in_seconds==120 and params.num_search_workers==8 and params.random_seed==0
    result={'variables':len(proto.variables),'constraints':len(proto.constraints),'rectangles':42,'choices':136,'all_variable_domains_and_constraints_verified':True,'all_recipes_require_exact_original_inventory':True,'all_six_bracket_slots_have_all_three_aspects':True,'strip_boundary_cannot_be_crossed':True,'outward_sizes_inward_capacities':True,'only_interchangeable_copy_symmetry':True,'no_objective_or_hint':True,'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()}
    with (OUT/'model-audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
