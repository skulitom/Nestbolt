"""Build, verify and solve one expanded conditional frame-completion model."""
from datetime import datetime, timezone
import gzip, json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, load, write, digest

SRC = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
DIAG = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = ROOT / 'output/h5-insert-aligned-frame-completion-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'solve.py')
    assert load(SRC / 'audit/checks.json')['all_new_cliques_valid_and_complete']
    paths = [SRC / n for n in ['plan.json', 'audit/checks.json', 'candidates.json', 'mapping.json',
                              'old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']]
    paths += [DIAG / 'selected-indices.json', DIAG / 'audit/checks.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in paths},
        'seconds_limit': 30, 'workers': 8, 'seed': 0,
        'method': 'Use every independently audited compatible original core pose plus all240 new insert-aligned frame poses. Keep the21 fixed insert poses, require12 brackets and15 cogs, maximize frames16..18, retain all original and new conflicts. Give a complete feasible16-frame hint. One call, no retry.',
        'scope': 'Only this fixed insert arrangement and expanded finite core pool. Partial frames still fail the original job. A full candidate requires independent original geometry, CLI and native-margin checks.',
        'native_packing_calls': 0, 'quality_runs': 0})
    pool = load(SRC / 'candidates.json')
    mapping = load(SRC / 'mapping.json')
    ids = mapping['candidates']
    fixed = mapping['fixed_insert_candidates']
    local = {i: j for j, i in enumerate(ids)}
    cliques = []
    for name in ['old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']:
        with gzip.open(SRC / name, 'rt', encoding='utf-8') as f:
            cliques.extend(json.loads(line) for line in f)
    rows = sorted({tuple(sorted(row)) for row in cliques})
    seed = set(load(DIAG / 'selected-indices.json'))
    assert seed - set(fixed) <= set(ids)
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:
        model.add_at_most_one(variables[local[i]] for i in row)
    families = {f: [j for j, i in enumerate(ids) if pool[i]['placement']['part_id'] == f]
                for f in ['frame', 'bracket', 'cog']}
    for f, lo, hi in [('frame', 16, 18), ('bracket', 12, 12), ('cog', 15, 15)]:
        model.add_linear_constraint(sum(variables[j] for j in families[f]), lo, hi)
    model.maximize(sum(variables[j] for j in families['frame']))
    hint = [int(i in seed) for i in ids]
    for j, value in enumerate(hint):
        model.add_hint(variables[j], value)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    expected = cp_model_pb2.CpModelProto()
    for i in ids:
        v = expected.variables.add()
        v.name = f'p{i}'
        v.domain.extend([0, 1])
    indexed_rows = {tuple(sorted(local[i] for i in row)) for row in cliques}
    for row in sorted(indexed_rows):
        expected.constraints.add().at_most_one.literals.extend(row)
    for f, lo, hi in [('frame', 16, 18), ('bracket', 12, 12), ('cog', 15, 15)]:
        c = expected.constraints.add().linear
        c.vars.extend(families[f])
        c.coeffs.extend([1] * len(families[f]))
        c.domain.extend([lo, hi])
    expected.objective.vars.extend(families['frame'])
    expected.objective.coeffs.extend([-1] * len(families['frame']))
    expected.objective.scaling_factor = -1
    expected.solution_hint.vars.extend(range(len(ids)))
    expected.solution_hint.values.extend(hint)
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    for c in actual.constraints:
        if c.WhichOneof('constraint') == 'at_most_one':
            assert sum(hint[j] for j in c.at_most_one.literals) <= 1
        else:
            value = sum(co * hint[j] for j, co in zip(c.linear.vars, c.linear.coeffs))
            assert c.linear.domain[0] <= value <= c.linear.domain[1]
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_insert_candidates': fixed, 'complete_hint': hint})
    write(OUT / 'model-audit.json', {
        'all_model_fields_independently_reconstructed': True, 'complete_hint_exactly_feasible': True,
        'variables': len(ids), 'constraints': len(actual.constraints),
        'family_variables': {f: len(v) for f, v in families.items()},
        'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 30
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen = sorted(set(fixed) | {i for j, i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))})
            count = sum(pool[i]['placement']['part_id'] == 'frame' for i in chosen)
            r = {'index': len(records), 'selected_indices': chosen, 'frames': count,
                 'seconds': self.wall_time, 'objective': self.objective_value, 'best_bound': self.best_objective_bound}
            assert count == r['objective']
            write(OUT / f"incumbent-{r['index']}.json", r)
            records.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'selected_indices'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 30})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.OPTIMAL, cp_model.FEASIBLE]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(records),
              'feasible': feasible, 'response_stats': solver.response_stats(),
              'full_target_witness': False, 'native_margin_qualified': False}
    if feasible:
        chosen = sorted(set(fixed) | {i for j, i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))})
        write(OUT / 'selected-indices.json', chosen)
        count = sum(pool[i]['placement']['part_id'] == 'frame' for i in chosen)
        result.update(frames=count, missing_frames=18 - count, best_bound=solver.best_objective_bound,
                      full_inventory_candidate=count == 18)
    else:
        assert not records
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    main()
