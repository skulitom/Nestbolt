from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Patch
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-aligned-pockets-20261018';load=lambda p:json.loads(p.read_bytes())
job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};patterns=load(RUN/'components.json');names=['rows-26-bracket-bottom-left','rows-27-bracket-bottom-left'];colors={'cog':'#d89248','insert':'#4c8a78','bracket':'#547e9c'}
fig,axes=plt.subplots(1,2,figsize=(13,5.4));fig.subplots_adjust(top=.78,bottom=.18,wspace=.12)
for ax,name in zip(axes,names):
    p=patterns[name]
    for member in p['members']:
        t=member['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;x,y=t['translation'];points=[(m*a*c-b*s+x,m*a*s+b*c+y) for a,b in parts[member['part_id']]['geometry'][0]['outer']];ax.add_patch(Polygon(points,facecolor=colors[member['part_id']],edgecolor='#263a45',linewidth=.5))
    ax.add_patch(Rectangle((0,0),p['width'],p['height'],fill=False,linestyle='--',edgecolor='#536575'));ax.set_aspect('equal');ax.set_xlim(-15,1502);ax.set_ylim(-20,825);ax.tick_params(labelsize=8);extra=len(p['members'])-15;ax.set_title(f'15 cogs'+(f' + {extra} inserts' if extra else '')+f"\n{p['width']:.2f} × {p['height']:.2f} mm",fontsize=12);ax.set_xlabel('mm',fontsize=9)
fig.suptitle('Staggered cog rows recover three insert spaces',fontsize=16,y=.97);fig.text(.5,.88,'Original outlines; minimum component gap ≥ 0.2251 mm. Full 66-part job remains unqualified.',ha='center',fontsize=10.5);fig.legend(handles=[Patch(color=colors[k],label=k.capitalize()) for k in ['cog','insert']],loc='lower center',bbox_to_anchor=(.5,.035),ncol=2,frameon=False);fig.savefig(RUN/'comparison.png',dpi=160,bbox_inches='tight');plt.close(fig)
