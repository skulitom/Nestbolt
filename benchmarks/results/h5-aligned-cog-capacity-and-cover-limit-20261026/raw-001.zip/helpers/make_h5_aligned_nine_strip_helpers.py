from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def make(src,dst,changes):
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in changes:assert old in s,(src,old);s=s.replace(old,new)
    compile(s,dst,'exec')
    if (ROOT/'output'/dst).exists():
        assert (ROOT/'output'/dst).read_text(encoding='utf-8')==s
        return
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
path=[('h5-eight-part-strip-source-20261026','h5-aligned-nine-strip-source-20261026'),('h5-eight-part-strip-probe-repaired-20261026','h5-aligned-nine-strip-probe-20261026')]
make('audit_h5_eight_part_strip_geometry_repaired.py','audit_h5_aligned_nine_strip_geometry.py',path[:1]+[("OUT=BASE/'audit-repaired'","OUT=BASE/'audit'"),
("['h5-three-free-brackets-search','h5-eight-part-band-search','h5-insert36-cog53-exchange']","['h5-aligned-cog-profiles','h5-aligned-cog-band-search']"),
('[21,22,25,26,53,63,64,65]','[21,22,25,26,37,53,63,64,65]'),('[[5,5,6,7,9,9,9,9]]','[[4,5,5,6,10,9,9,9,9]]'),('==8 and all','==9 and all'),('[28,29,37]','[28,29]'),('range(8)','range(9)'),('len(list(combinations(row,2)))==28','len(list(combinations(row,2)))==36'),("'mandatory_originals_per_pattern':8,'physical_pairs_checked':28","'mandatory_originals_per_pattern':9,'physical_pairs_checked':36"),('all eight original IDs','all nine original IDs'),('all28 physical pairs','all36 physical pairs')])
for src,dst in [('prepare_h5_eight_part_strip_model_repaired.py','prepare_h5_aligned_nine_strip_model.py'),('audit_h5_eight_part_strip_model_repaired.py','audit_h5_aligned_nine_strip_model.py'),('audit_h5_eight_part_strip_response_repaired.py','audit_h5_aligned_nine_strip_response.py')]:
    changes=path+[('range(8)','range(9)')]
    if 'response' not in src:changes +=[("SOURCE/'audit-repaired/checks.json'","SOURCE/'audit/checks.json'")]
    if src.startswith('prepare'):changes +=[("'coordinate_variables_per_model':16,'full_physical_pairs_per_model':28","'coordinate_variables_per_model':18,'full_physical_pairs_per_model':36"),('eight mandatory originals and16','nine mandatory originals and18')]
    elif 'model' in src:changes += [('16 exact','18 exact'),('all28_original_pairs_preserved','all36_original_pairs_preserved')]
    else:changes +=[('solution[:16]','solution[:18]'),('eight original','nine original'),('eight_original_source_witness','nine_original_source_witness')]
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in changes:assert old in s,(src,old);s=s.replace(old,new)
    s=s.replace('eight-original','nine-original').replace('all28','all36')
    compile(s,dst,'exec')
    if (ROOT/'output'/dst).exists():
        assert (ROOT/'output'/dst).read_text(encoding='utf-8')==s
        continue
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
make('run_h5_eight_part_strip_probe_repaired.py','run_h5_aligned_nine_strip_probe.py',path[1:]+[('eight-original','nine-original')])
