"""Independent source-event, geometry, filtering and complete new-edge checks."""
from itertools import combinations, product
import gzip, json, math, shutil, time
import numpy as np
import shapely
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, load, write, digest

RUN = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
OUT = RUN / 'audit'

def readrows(path):
    with gzip.open(path, 'rt', encoding='utf-8') as f:
        return [json.loads(line) for line in f]

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    start = time.perf_counter()
    for p, h in load(RUN / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(RUN / 'candidates.json')
    original = load(SRC / 'candidates.json')
    nold = len(original)
    assert nold == 9059 and pool[:nold] == original
    job = load(SRC / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    mapping = load(RUN / 'mapping.json')
    fixed = set(mapping['fixed_insert_candidates'])
    stock, clearance = job['stocks'][0], job['clearance']
    m, edge = stock['margins'], job['edge_clearance']
    target = load(SRC / 'conditional-target.json')
    gs = np.asarray([shape(parts[p['placement']['part_id']], p['placement']['transform']) for p in pool], dtype=object)
    bounds = shapely.bounds(gs)
    sheets = np.asarray([p['placement']['sheet_id'] for p in pool])
    # Derive every contact coordinate and event in declaration order from original outlines.
    expected_events = []
    expected_axes = []
    for sheet in ['sheet-0', 'sheet-1']:
        anchors = sorted(i for i in fixed if sheets[i] == sheet)
        height = stock['height'] if sheet == 'sheet-0' else target['required_used_height_mm']
        for angle in [0.0, math.pi / 2]:
            raw = shape(parts['frame'], {'rotation_radians': angle, 'translation': [0, 0], 'mirrored': False})
            bx, by, ex, ey = raw.bounds
            w, h = ex - bx, ey - by
            lo_x = m['left'] + edge + 0.0001
            hi_x = stock['width'] - m['right'] - edge - w - 0.0001
            lo_y = m['bottom'] + edge + 0.0001
            hi_y = height - m['top'] - edge - h - 0.0001
            if hi_x < lo_x or hi_y < lo_y:
                expected_axes.append({'sheet': sheet, 'angle': angle, 'infeasible_stock_dimensions': True})
                continue
            xx = [lo_x, hi_x]
            yy = [lo_y, hi_y]
            for i in anchors:
                a, b, c, d = gs[i].bounds
                xx += [a - w - (clearance + 0.001), c + (clearance + 0.001)]
                yy += [b - h - (clearance + 0.001), d + (clearance + 0.001)]
            xx = sorted(set(x for x in xx if lo_x <= x <= hi_x))
            yy = sorted(set(y for y in yy if lo_y <= y <= hi_y))
            expected_axes.append({'sheet': sheet, 'angle': angle, 'x_contacts': xx, 'y_contacts': yy})
            for x, y in product(xx, yy):
                placement = {'part_id': 'frame', 'sheet_id': sheet,
                             'transform': {'rotation_radians': angle, 'translation': [x - bx, y - by], 'mirrored': False}}
                expected_events.append((placement, x, y, anchors))
    assert load(RUN / 'axes.json') == expected_axes
    events = load(RUN / 'source-events.json')
    assert len(events) == len(expected_events)
    additions = []
    for number, (r, (p, x, y, anchors)) in enumerate(zip(events, expected_events)):
        assert r['sheet'] == p['sheet_id'] and r['angle'] == p['transform']['rotation_radians']
        assert r['x'] == x and r['y'] == y
        g = shape(parts['frame'], p['transform'])
        conflicts = [i for i in anchors if g.distance(gs[i]) < clearance - 1e-7]
        if conflicts:
            assert r == {'sheet': p['sheet_id'], 'angle': p['transform']['rotation_radians'],
                         'x': x, 'y': y, 'added': False, 'reason': 'fixed_insert_conflict', 'blockers': conflicts}
            continue
        i = r['candidate']
        assert pool[i]['placement'] == p
        if r['added']:
            assert i == nold + len(additions)
            assert pool[i]['source'] == {'kind': 'fixed-insert-contact-grid', 'event': number}
            additions.append(i)
        else:
            assert r['reason'] == 'exact_duplicate' and i < nold + len(additions)
        a, b, c, d = g.bounds
        assert g.is_valid and abs(g.area - 157500) < 1e-6
        assert a >= m['left'] + edge - 1e-7 and b >= m['bottom'] + edge - 1e-7
        assert c <= stock['width'] - m['right'] - edge + 1e-7 and d <= stock['height'] - m['top'] - edge + 1e-7
    assert additions == mapping['new_frame_candidates'] == list(range(nold, len(pool)))
    # Independent direct-geometry fixed-insert filter of all original core poses.
    expected_old = []
    filter_pairs = 0
    for i in range(nold):
        if pool[i]['placement']['part_id'] == 'insert':
            continue
        anchors = np.asarray([j for j in sorted(fixed) if sheets[j] == sheets[i]], dtype=int)
        filter_pairs += len(anchors)
        if not np.any(shapely.distance(gs[i], gs[anchors]) < clearance - 1e-7):
            expected_old.append(i)
    assert expected_old == mapping['original_eligible']
    ids = sorted(expected_old + additions)
    assert ids == mapping['candidates']
    old_set = set(expected_old)
    original_cliques = readrows(OLD / 'cliques.jsonl.gz') + readrows(SRC / 'new-cliques.jsonl.gz')
    projected = sorted({tuple(sorted(set(c) & old_set)) for c in original_cliques if len(set(c) & old_set) > 1})
    assert [list(r) for r in projected] == readrows(RUN / 'old-projected-cliques.jsonl.gz')
    adjacency = [0] * len(pool)
    for row in projected:
        mask = sum(1 << i for i in row)
        for i in row:
            adjacency[i] |= mask ^ (1 << i)
    exact_edges = set()
    all_pairs = near_pairs = 0
    for i in additions:
        js = np.asarray([j for j in ids if j < i and sheets[j] == sheets[i]], dtype=int)
        all_pairs += len(js)
        dx = np.maximum(0, np.maximum(bounds[js, 0] - bounds[i, 2], bounds[i, 0] - bounds[js, 2]))
        dy = np.maximum(0, np.maximum(bounds[js, 1] - bounds[i, 3], bounds[i, 1] - bounds[js, 3]))
        js = js[np.hypot(dx, dy) <= clearance + 1e-7]
        near_pairs += len(js)
        for j in js[shapely.distance(gs[i], gs[js]) < clearance - 1e-7]:
            j = int(j)
            exact_edges.add((j, i))
            adjacency[i] |= 1 << j
            adjacency[j] |= 1 << i
    saved_edges = readrows(RUN / 'new-conflicts.jsonl.gz')
    assert len(saved_edges) == len(exact_edges) and set(map(tuple, saved_edges)) == exact_edges
    covered = set()
    new_cliques = readrows(RUN / 'new-cliques.jsonl.gz')
    eligible = set(ids)
    for row in new_cliques:
        assert len(row) == len(set(row)) and set(row) <= eligible
        mask = sum(1 << i for i in row)
        assert all(not((mask ^ (1 << i)) & ~adjacency[i]) for i in row)
        for a, b in combinations(sorted(row), 2):
            if b >= nold:
                covered.add((a, b))
    assert covered == exact_edges
    check = {'all_original_poses_preserved_exactly': True,
             'all_contact_events_independently_reconstructed': len(events),
             'new_frame_poses_checked': len(additions), 'original_core_insert_filter_pairs': filter_pairs,
             'all_fixed_insert_filters_match_original_geometry': True,
             'new_same_sheet_pairs_exhaustively_examined': all_pairs, 'near_pair_distances_checked': near_pairs,
             'exact_new_conflicts': len(exact_edges), 'all_new_cliques_valid_and_complete': True,
             'new_cliques': len(new_cliques), 'eligible_core_poses': len(ids),
             'seconds': time.perf_counter() - start, 'full_target_witness': False}
    write(OUT / 'checks.json', check)
    print(json.dumps(check), flush=True)

if __name__ == '__main__':
    main()
