"""Fill real inter-part gaps inside ragged cog component bounds."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,math,time,gzip,copy,itertools,shutil,traceback
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
from shapely.ops import unary_union
import construct_h5_outline_beam as beam
base=beam.base;gap=beam.gap;ROOT=base.ROOT;load=base.load;write=base.write
SRC=ROOT/'output/h5-aligned-truncated-20261018';OLD=ROOT/'output/h5-cog-lattices-20261018';OUT=ROOT/'output/h5-aligned-pockets-20261018'
class PocketPlacer(beam.Placement):
    def rank(self,tid,x,y,corner):
        p=self.templates[tid];return ((self.heights[0]-y-p['height']) if 'top' in corner else y,(self.width-x-p['width']) if 'right' in corner else x,tid,x,y)
    def points(self,state,tid,corner):
        free=self.allowed[(tid,0)]
        if free.is_empty:return []
        forbidden=[affine_transform(self.forbidden(p['template'],tid),[1,0,0,1,p['x'],p['y']]) for p in state['placed']]
        if forbidden:free=free.difference(unary_union(forbidden))
        points=[]
        for p in gap.polygons(free):
            for ring in [p.exterior,*p.interiors]:points.extend(list(ring.coords)[:-1])
            r=p.representative_point();points.append((r.x,r.y))
        ordered=sorted(set(points),key=lambda xy:self.rank(tid,*xy,corner));selected=[]
        for x,y in ordered:
            if any(abs(x-a)<1e-4 and abs(y-b)<1e-4 for a,b in selected):continue
            selected.append((x,y))
            if len(selected)==3:break
        return selected

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'fill.py');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};selected=load(SRC/'selection.json');original=load(SRC/'patterns.json');prior=load(OLD/'all-patterns.json')
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'inputs':{str(p.relative_to(ROOT)):base.digest(p) for p in [SRC/'job.json',SRC/'patterns.json',SRC/'selection.json',OLD/'all-patterns.json']},
          'orders':[['insert','bracket'],['bracket','insert']],'corners':['bottom-left','bottom-right','top-left','top-right'],'seconds_limit':120,'clearance_mm':.225,'contacts_per_orientation':3,'addition_cap_per_component':12,
          'method':'For each of 28 contact-aligned truncated components, retain every cog pose and its original bounding rectangle. Try two family orders and four corner priorities. Candidate original inserts/brackets use all allowed quarter turns/reflections, with conservative Minkowski exclusions against every cog and previous addition. Keep three distinct boundary/interior contacts nearest the named corner per orientation. Select the first fitting family and nearest valid contact. Stop when nothing fits, all original quantities are consumed, twelve additions are reached, or total diagnostic limit expires. No part holes are opened. For each row-count family select the completed component whose remainder, covered by dense two-bracket/one-insert patterns plus original singles, has least total padded rectangle area; this is only a finite candidate ranking.'}
    write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    singles={k:base.pattern(k,[base.member(k)],shapes) for k in ['bracket','insert']}
    for k in ['bracket','insert']:
        if parts[k]['allow_mirror']:singles[k+'-mirror']=base.pattern(k+'-mirror',[base.member(k,base.transform(mirrored=True))],shapes)
    mix=min((n for n,p in prior.items() if Counter(m['part_id'] for m in p['members'])==Counter(bracket=2,insert=1)),key=lambda n:(prior[n]['width']*prior[n]['height'],n))
    components={};cases=[];t0=time.perf_counter();expired=False
    for si,s in enumerate(selected):
        p=original[s['pattern']];placer=PocketPlacer(job,singles,p['width'],[p['height'],0]);placer.clearance=.225;byfamily={k:[t['template_id'] for t in placer.templates if t['members'][0]['part_id']==k] for k in ['insert','bracket']};fixed={};start={'id':0,'placed':[]}
        for member in p['members']:
            t=member['transform'];key=(t['rotation_radians'],t['mirrored']);zero={**t,'translation':[0.,0.]};g=gap.pose(shapes['cog'],zero);x0,y0,*_=g.bounds
            if key not in fixed:
                q=base.pattern('fixed-cog',[base.member('cog',zero)],shapes);q.update(template_id=len(placer.templates),outer_geometries=[gap.pose(shapes['cog'],q['members'][0]['transform'])]);fixed[key]=q['template_id'];placer.templates.append(q)
            start['placed'].append({'template':fixed[key],'x':t['translation'][0]+x0,'y':t['translation'][1]+y0,'sheet':0})
        write(OUT/f'templates-{si}.json',[{k:v for k,v in t.items() if k!='outer_geometries'} for t in placer.templates])
        for order,corner in itertools.product(plan['orders'],plan['corners']):
            if time.perf_counter()-t0>=plan['seconds_limit']:expired=True;break
            name=f'rows-{si}-{order[0]}-{corner}';folder=OUT/name;folder.mkdir();state=copy.deepcopy(start);members=copy.deepcopy(p['members']);remaining={k:parts[k]['quantity'] for k in order};transitions=[];attempts=0
            with gzip.open(folder/'candidates.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                while len(transitions)<plan['addition_cap_per_component']:
                    choice=None
                    for family in order:
                        if not remaining[family]:continue
                        candidates=[]
                        for tid in byfamily[family]:
                            if time.perf_counter()-t0>=plan['seconds_limit']:expired=True;break
                            points=placer.points(state,tid,corner)
                            if not points:log.write(json.dumps({'kind':'empty','step':len(transitions),'family':family,'template':tid})+'\n')
                            for x,y in points:
                                b={'template':tid,'x':x,'y':y,'sheet':0};valid=placer.valid_addition(state,b);attempts+=1;rank=placer.rank(tid,x,y,corner);log.write(json.dumps({'kind':'candidate','step':len(transitions),'family':family,'block':b,'valid':valid,'rank':rank})+'\n')
                                if valid:candidates.append((rank,b))
                        if expired:break
                        if candidates:choice=(family,min(candidates,key=lambda c:c[0])[1]);break
                    if choice is None or expired:break
                    family,b=choice;member=copy.deepcopy(placer.templates[b['template']]['members'][0]);member['transform']['translation'][0]+=b['x'];member['transform']['translation'][1]+=b['y'];members.append(member);state['placed'].append(b);remaining[family]-=1;transitions.append({'member':member,'block':b});log.write(json.dumps({'kind':'accepted','step':len(transitions),'member':member,'block':b})+'\n')
            # Keep the original group's coordinate origin and bounds exactly.
            compound={**copy.deepcopy(p),'id':name,'members':members,'area':sum(shapes[m['part_id']].area for m in members),'source_pattern':p['id'],'row_family':si}
            components[name]=compound;write(folder/'component.json',compound);write(folder/'transitions.json',transitions);inv=Counter(m['part_id'] for m in members);left=Counter({k:p['quantity'] for k,p in parts.items()})-inv
            recipe=Counter({name:1,'frame':left['frame']});pairs=min(left['bracket']//2,left['insert']);recipe[mix]=pairs;left['bracket']-=2*pairs;left['insert']-=pairs;left['frame']=0
            for k,n in left.items():
                if n:recipe[k]+=n
            allp={**prior,**components};area=sum((allp[n]['width']+.225)*(allp[n]['height']+.225)*v for n,v in recipe.items());case={'id':name,'row_family':si,'source':s['pattern'],'order':order,'corner':corner,'additions':len(transitions),'inventory':dict(inv),'attempts':attempts,'expired':expired,'recipe':dict(recipe),'padded_area_mm2':area};write(folder/'result.json',case);cases.append(case)
            if expired:break
        if expired:break
    recipes=[]
    for si in range(len(selected)):
        choices=[c for c in cases if c['row_family']==si and not c['expired']]
        if choices:recipes.append(min(choices,key=lambda c:(c['padded_area_mm2'],sum(c['recipe'].values()),c['id'])))
    write(OUT/'components.json',components);write(OUT/'selected-recipes.json',recipes);result={'seconds':time.perf_counter()-t0,'expired':expired,'cases':cases,'selected':recipes,'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps({'seconds':result['seconds'],'expired':expired,'cases':len(cases),'selected':recipes}),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
