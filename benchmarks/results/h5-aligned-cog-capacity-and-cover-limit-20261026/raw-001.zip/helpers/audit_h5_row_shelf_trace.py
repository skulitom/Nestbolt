from pathlib import Path
from collections import Counter
import json,gzip,math,itertools
from shapely.geometry import box
from shapely.ops import unary_union
from shapely.geometry import Polygon
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;OUT=ROOT/'output/h5-five-row-shelves-20261018';load=audit.load
def main():
    plan=load(OUT/'plan.json');patterns=load(OUT/'patterns.json');job=load(OUT/'job.json');recipes=load(OUT/'recipes.json');frames=load(OUT/'frames.json');required=Counter({p['id']:p['quantity'] for p in job['parts']});areas={p['id']:Polygon(p['geometry'][0]['outer']).area for p in job['parts']};fullarea=sum(areas[k]*n for k,n in required.items());retained=load(OUT/'retained.json');wanted={r['attempt']:r for r in retained};best=-math.inf;maximum=0
    for name,h in plan['source_hashes'].items():assert audit.digest(ROOT/name)==h
    assert len(recipes)==5246 and len(frames)==24
    for r in recipes:assert Counter(m['part_id'] for n in r['items']+['frame']*18 for m in patterns[n]['members'])==required
    eligible=load(OUT/'eligible-frames.json');filtered=load(OUT/'filtered-prefixes.json');expected_filtered=[];g=plan['gap_mm'];W=plan['width_mm']+g;Hs=[h+g for h in plan['heights_mm']];free_errors=[];frame_pairs=0
    for fi,frame in enumerate(frames):
        assert sum(frame['counts'])==18 and len(frame['counts'])==len(frame['rotations'])==5
        padded=[];physical=[];y=0.;blocks=[]
        for rot,qty in zip(frame['rotations'],frame['counts']):
            w,h=(350.,450.) if rot else (450.,350.);assert qty<=math.floor(W/(w+g))
            for col in range(qty):blocks.append({'pattern':'frame','bin':0,'x':col*(w+g),'y':y,'rotated':rot,'rect':[col*(w+g),y,w+g,h+g]})
            y+=h+g
        assert blocks==frame['placed'] and y<=Hs[0]
        for b in blocks:
            x,y,w,h=b['rect'];padded.append(box(x,y,x+w,y+h));assert x>=0 and y>=0 and x+w<=W+1e-8 and y+h<=Hs[0]+1e-8
        for a,b in itertools.combinations(padded,2):frame_pairs+=1;assert a.intersection(b).area<1e-6
        leftover=box(0,0,W,Hs[0]).difference(unary_union(padded));saved=unary_union([box(x,y,x+w,y+h) for x,y,w,h in frame['free']]);error=leftover.symmetric_difference(saved).area;assert error<1e-6;free_errors.append(error)
    for ri,r in enumerate(recipes):
        p=patterns[r['component']];expect=[]
        for fi,frame in enumerate(frames):
            spaces=frame['free']+[[0,0,W,Hs[1]]];fits=any(w>=pw-1e-8 and h>=ph-1e-8 for x,y,w,h in spaces for pw,ph in [(p['width']+g,p['height']+g),(p['height']+g,p['width']+g)])
            if fits:expect.append(fi)
            else:expected_filtered.append([ri,fi])
        assert expect==eligible[ri]
    assert expected_filtered==filtered and len(filtered)==35107
    keys=((ri,fi,sort,fit) for ri,fs in enumerate(eligible) for fi in fs for sort in plan['sorts'] for fit in plan['fits'])
    n=0
    with gzip.open(OUT/'attempts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);n+=1;assert row['attempt']==n;key=(row['recipe'],row['frame'],row['sort'],row['fit']);assert key==next(keys);assert row['sort'] in plan['sorts'] and row['fit'] in plan['fits'] and 0<=row['frame']<24
            r=recipes[row['recipe']];unplaced=Counter(row['unplaced']);assert not unplaced-Counter(r['items']);missing=Counter(m['part_id'] for name in row['unplaced'] for m in patterns[name]['members']);assert dict(missing)==row['missing'];assert row['count']==sum(required.values())-sum(missing.values());area=fullarea-sum(areas[k]*qty for k,qty in missing.items());assert abs(area-row['filled_area_mm2'])<1e-6;best=max(best,area);maximum=max(maximum,row['count'])
            if n in wanted:
                r=wanted[n];assert all(row[k]==r[k] for k in row);counts=Counter(m['part_id'] for b in r['blocks'] for m in patterns[b['pattern']]['members']);assert counts+missing==required
    assert next(keys,None) is not None
    prior=ROOT/'output/h5-pocket-aspect-rectangles-20261018'
    for name in ['patterns.json','recipes.json','job.json','conditional-target.json']:assert (OUT/name).read_bytes()==(prior/name).read_bytes()
    result=load(OUT/'result.json');assert n==result['attempts']==1028981 and plan['maximum_attempts']==1089564 and result['expired'] and not result['complete'];assert abs(best-result['best_filled_area_mm2'])<1e-6 and maximum==result['maximum_count'];out={'attempts':n,'distinct_configuration_keys':n,'unattempted_after_limit':plan['maximum_attempts']-n,'exact_inventory_recipes':len(recipes),'all_missing_counts_and_filled_areas_verified':True,'retained_records_match_trace':True,'retained_geometry_covered_by_original_vertex_backfill_audit':True,'every_rejected_arrangement_geometry_audited':False,'fixed_frame_pair_checks':frame_pairs,'maximum_free_union_error_mm2':max(free_errors),'all_prefix_rectangle_filters_verified':len(filtered),'all_recipe_and_pattern_bytes_unchanged':True,'full_target_witness':False};audit.write(OUT/'trace-audit.json',out);print(json.dumps(out))
if __name__=='__main__':main()
