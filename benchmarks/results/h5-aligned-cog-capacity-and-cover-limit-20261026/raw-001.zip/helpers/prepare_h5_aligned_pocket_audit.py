from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_ragged_geometry.py').read_text(encoding='utf-8')
s=s.replace("RAG=ROOT/'output/h5-ragged-cogs-20261018';POCKET=ROOT/'output/h5-ragged-pockets-20261018'","RAG=ROOT/'output/h5-aligned-truncated-20261018';POCKET=ROOT/'output/h5-aligned-pockets-20261018'")
s=s.replace("variants=load(RAG/'variants.json');",'')
start=s.index('    assert len(variants)==54');end=s.index('    cpairs=0;',start)
s=s[:start]+'''    assert len(original)==28
    source=load(ROOT/'output/h5-aligned-stagger-20261018/patterns.json');sourceplan=load(ROOT/'output/h5-aligned-stagger-20261018/plan.json')
    assert {(p['construction']['count'],p['construction']['columns'],p['construction']['fraction']) for p in original.values()}==set(itertools.product(range(9,16),[4,5],[0,.5]))
    for p in original.values():
        ct=p['construction'];prior=source[ct['source_pattern']];angle=sourceplan['angle_radians'];dx=sourceplan['pitch_x_mm'];dy=prior['construction']['pitch_y_mm'];c,s=math.cos(angle),math.sin(angle);raw=[]
        for i in range(ct['count']):
            row,col=divmod(i,ct['columns']);raw.append({'rotation_radians':angle,'translation':[(col+(ct['fraction'] if row%2 else 0))*dx-c*cx+s*cy,row*dy-s*cx-c*cy],'mirrored':False})
        gs=[shape(parts['cog'],t) for t in raw];x0=min(g.bounds[0] for g in gs);y0=min(g.bounds[1] for g in gs)
        for t,m in zip(raw,p['members']):t['translation'][0]-=x0;t['translation'][1]-=y0;assert m=={'part_id':'cog','transform':t}
        count,mind=check_members(parts,p['members'],job['clearance'],p['width'],p['height']);pairs+=count;minimum=min(minimum,mind)
    assert pairs==1904==load(RAG/'result.json')['original_pair_checks'];components=load(POCKET/'components.json');cases=load(POCKET/'result.json')['cases'];assert len(cases)==224
'''+s[end:]
s=s.replace("['width']+.22","['width']+.225").replace("['height']+.22","['height']+.225")
with (ROOT/'output/audit_h5_aligned_pockets.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared original-vertex audit of all truncated rows, fills and candidate additions.')
