from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import json,math,time,shutil,traceback
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-aligned-aspect-cpsat-20261018';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert not (OUT/'solver.log').exists();audit=load(OUT/'model-audit.json');assert audit['model_sha256']==sha256((OUT/'model.pbtxt').read_bytes()).hexdigest();shutil.copyfile(__file__,OUT/'solve.py');plan=load(OUT/'plan.json');mp=load(OUT/'mapping.json');patterns=load(OUT/'patterns.json');job=load(OUT/'job.json')
    model=cp_model.CpModel();assert model.proto.parse_text_format((OUT/'model.pbtxt').read_text());model.rebuild_constant_map();assert model.validate()=='';solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((OUT/'parameters.pbtxt').read_text());write(OUT/'started.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':audit['model_sha256'],'audit_sha256':sha256((OUT/'model-audit.json').read_bytes()).hexdigest()})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda msg:(log.write(msg+'\n'),log.flush());t0=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-t0
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE];result={'status':solver.status_name(status),'seconds':elapsed,'feasible':feasible,'response_stats':solver.response_stats(),'model_sha256':audit['model_sha256']}
    if feasible:
        def value(index):return solver.value(model.get_int_var_from_proto_index(index))
        selected=[]
        for item in mp['items']:
            v=item['vars'];ch=item['choices'][value(v['kind'])]
            if ch['pattern'] is None:continue
            sheet=value(v['sheet']);selected.append({'item':item['item'],**ch,'sheet':sheet,'x':value(v['x'])/plan['scale_per_mm'],'y':(value(v['y'])-(mp['Hs'][0] if sheet else 0))/plan['scale_per_mm']})
        write(OUT/'selection.json',selected);counts=Counter();placements=[];st=job['stocks'][0];origin=[st['margins']['left']+job['edge_clearance']+.0001,st['margins']['bottom']+job['edge_clearance']+.0001]
        for b in selected:
            p=patterns[b['pattern']]
            for member in p['members']:
                t=json.loads(json.dumps(member['transform']));x,y=t['translation']
                if b['rotated']:t['rotation_radians']+=math.pi/2;x,y=p['height']-y,x
                t['translation']=[origin[0]+b['x']+x,origin[1]+b['y']+y];family=member['part_id'];placements.append({'part_id':family,'copy_index':counts[family],'sheet_id':f"sheet-{b['sheet']}",'transform':t});counts[family]+=1
        write(OUT/'layout.json',{'version':1,'units':'mm','sheets':load(OUT/'original.json')['sheets'],'placements':placements});result['counts']=dict(counts);result['recipe']=value(mp['recipe_var']);write(OUT/'solution-variables.json',[value(i) for i in range(len(model.proto.variables))])
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'solve-failure.txt').exists():(OUT/'solve-failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
