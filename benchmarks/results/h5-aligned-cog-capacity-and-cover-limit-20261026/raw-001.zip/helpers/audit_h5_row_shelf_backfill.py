"""Independent original-vertex audit of eight retained lattice continuations."""
from pathlib import Path
from collections import Counter
import json,math,itertools,gzip,subprocess,sys
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;SRC=ROOT/'output/h5-five-row-shelves-20261018';RUN=ROOT/'output/h5-five-row-backfill-20261018';load=audit.load;write=audit.write;shape=audit.shape
def main():
    out=RUN/'audit';out.mkdir();job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};required=Counter({k:p['quantity'] for k,p in parts.items()});st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];target=load(RUN/'conditional-target.json');records=[];allpairs=0;allcandidates=0
    for name,h in load(RUN/'plan.json')['inputs'].items():assert audit.digest(ROOT/name)==h
    templates=load(RUN/'templates.json');selection=load(RUN/'selection.json');patterns=load(SRC/'patterns.json')
    # Reconstruct initial block placements directly, without the producer's
    # layout conversion routine, and retain actual saved additions unchanged.
    for result,selected in zip(load(RUN/'results.json')['cases'],selection['selected']):
        folder=RUN/f"partial-{result['partial']:02d}";initial=load(folder/'initial.json');layout=load(folder/'layout.json');counts=Counter();reconstructed=[]
        for b in selected['attempt']['blocks']:
            p=patterns[b['pattern']]
            for member in p['members']:
                t=json.loads(json.dumps(member['transform']));x,y=t['translation']
                if b['rotated']:t['rotation_radians']+=math.pi/2;x,y=p['height']-y,x
                t['translation']=[m['left']+e+1e-4+b['x']+x,m['bottom']+e+1e-4+b['y']+y];family=member['part_id'];reconstructed.append({'part_id':family,'copy_index':counts[family],'sheet_id':f"sheet-{b['bin']}",'transform':t});counts[family]+=1
        assert initial['placements']==reconstructed and layout['placements'][:len(reconstructed)]==reconstructed
        geoms={};seen=set();tops={};pairs=0;minimum=math.inf
        for p in layout['placements']:
            key=(p['part_id'],p['copy_index']);assert key not in seen;seen.add(key);part=parts[p['part_id']];t=p['transform'];assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            g=shape(part,t);top=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];x0,y0,x1,y1=g.bounds
            assert g.is_valid and x0>=m['left']+e-1e-7 and y0>=m['bottom']+e-1e-7 and x1<=st['width']-m['right']-e+1e-7 and y1<=top-m['top']-e+1e-7
            geoms.setdefault(p['sheet_id'],[]).append(g);tops[p['sheet_id']]=max(y1,tops.get(p['sheet_id'],0))
        for gs in geoms.values():
            for a,b in itertools.combinations(gs,2):pairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
        missing=required-Counter(p['part_id'] for p in layout['placements']);assert dict(missing)==result['missing'];charged=st['width']*(st['height']+tops['sheet-1']+m['top']+e);assert charged<=target['target_material_mm2']+1e-6
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert audit.digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
        command=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(folder/'layout.json')];r=subprocess.run(command,capture_output=True,timeout=60);(out/f"partial-{result['partial']}-stdout.json").write_bytes(r.stdout);(out/f"partial-{result['partial']}-stderr.log").write_bytes(r.stderr);public=json.loads(r.stdout)
        assert public['valid']==(not missing);assert not missing or (public['violations'] and all(v['code']=='quantity' for v in public['violations']))
        write(out/f"partial-{result['partial']}-command.json",{'command':command,'exit_code':r.returncode})
        # Check every proposed candidate against its actual initial plus accepted
        # prefix. Empty-region claims are conservative producer observations.
        current=list(initial['placements']);candidates=0
        with gzip.open(folder/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                event=json.loads(line)
                if event['kind']=='accepted':current.append(load(folder/'transitions.json')[event['step']-1]['addition']);continue
                if event['kind']!='candidate':continue
                b=event['block'];template=templates[b['template']];assert len(template['members'])==1;member=template['members'][0];t=json.loads(json.dumps(member['transform']));t['translation'][0]+=b['x']+m['left']+e+1e-4;t['translation'][1]+=b['y']+m['bottom']+e+1e-4;g=shape(parts[member['part_id']],t);sheet=f"sheet-{b['sheet']}";top=st['height'] if b['sheet']==0 else target['required_used_height_mm'];x0,y0,x1,y1=g.bounds
                good=x0>=m['left']+e-1e-7 and y0>=m['bottom']+e-1e-7 and x1<=st['width']-m['right']-e+1e-7 and y1<=top-m['top']-e+1e-7
                for p in current:
                    if p['sheet_id']==sheet:
                        fixed=shape(parts[p['part_id']],p['transform']);good=good and g.disjoint(fixed) and g.distance(fixed)>=job['clearance']-1e-7
                assert good==event['valid'];candidates+=1
        assert current==layout['placements'] and candidates==result['candidate_attempts'];allpairs+=pairs;allcandidates+=candidates;records.append({'partial':result['partial'],'pairs':pairs,'candidates':candidates,'minimum_distance_mm':minimum,'missing':dict(missing),'charged_material_mm2':charged,'public_valid':public['valid'],'public_only_quantity_failure':bool(missing)})
    write(out/'checks.json',{'cases':records,'filled_outer_pairs':allpairs,'candidate_additions_independently_verified':allcandidates,'all_initial_placements_reconstructed_exact':True,'all_selected_placements_preserved_exact':True,'empty_region_infeasibility_not_claimed':True,'no_complete_witness':not any(r['public_valid'] for r in records)})
    print(json.dumps(load(out/'checks.json')))
if __name__=='__main__':main()
