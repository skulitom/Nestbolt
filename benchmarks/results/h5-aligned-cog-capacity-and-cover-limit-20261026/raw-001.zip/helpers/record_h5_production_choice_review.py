"""Read-only production-policy checkpoint after the cover watchdog termination."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-production-choice-review-20261026';OUT.mkdir()
paths=['crates/core/src/sheets.rs','crates/core/src/common_line/search.rs'];sources={p:(ROOT/p).read_text(encoding='utf-8') for p in paths}
assert 'optimize_with_part_in_hole(job, options, true, progress)' in sources[paths[0]]
assert 'optimize_with_areas(\n        collision,\n        options,\n        false,' in sources[paths[0]]
assert 'let search_budget = if bonus.is_some() {\n        budget * 0.9' in sources[paths[0]]
assert 'm <= baseline_material * 1.01' in sources[paths[1]]
record={'utc':datetime.now(timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_hashes':{p:sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},'findings':['Ordinary optimize explicitly enables the hole-rider pre-pass; common-line bonus optimization explicitly disables it.','The common-line search receives90% of its budget, then the translation bonus uses the remaining budget.','The translation bonus material ceiling is1.01 times its own independently valid starting layout, not the external equal-spacing ordinary benchmark.','An ordinary hole-rider layout cannot be used as a valid common-line fallback while retaining the required part-in-hole-off geometry.','This review identifies no safe production shortcut that closes the external H5 material gate. Changing the ordinary comparison or enabling riders in common-line mode would not satisfy the existing requirement.'],'production_changes':False,'benchmark_runs':0,'H5_complete':False}
with (OUT/'review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
