from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'output/backfill_h5_cog_lattices.py').read_text(encoding='utf-8')
text=text.replace("SRC=ROOT/'output/h5-cog-lattices-20261018';OUT=ROOT/'output/h5-cog-lattice-backfill-20261018'","SRC=ROOT/'output/h5-aligned-aspect-rectangles-20261018';OUT=ROOT/'output/h5-aligned-aspect-backfill-20261018'")
text=text.replace("['attempts.jsonl.gz','all-patterns.json','job.json','result.json','conditional-target.json']","['attempts.jsonl.gz','patterns.json','job.json','result.json','conditional-target.json','retained.json']")
text=text.replace('Keep the greatest filled-area partial for each frame configuration and per-sheet cog inventory, with earliest attempt breaking ties. Rank these distinct groups by filled area then placed count then first attempt. Continue the first eight only.','Use all eight distinct greatest-filled-area partials retained by the fully completed aligned/aspect rectangle sweep, in their saved order. Preserve original inventory and poses.')
text=text.replace("'construction_clearance_mm':.22","'construction_clearance_mm':.225")
start=text.index("    write(OUT/'plan.json',plan);patterns=")
end=text.index("    parts={p['id']:p for p in job['parts']}",start)
text=text[:start]+'''    write(OUT/'plan.json',plan);patterns=load(SRC/'patterns.json');job=load(SRC/'job.json');target=load(SRC/'conditional-target.json')
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    retained=load(SRC/'retained.json');assert len(retained)==8
    selected=[((r['filled_area_mm2'],r['count'],-r['attempt']),r['attempt'],r) for r in retained]
    write(OUT/'selection.json',{'selected':[{'source_attempt':i,'attempt':r} for _,i,r in selected]})
'''+text[end:]
with (ROOT/'output/backfill_h5_aligned_aspects.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(ROOT/'output/audit_h5_lattice_backfill.py').read_text(encoding='utf-8').replace("SRC=ROOT/'output/h5-cog-lattices-20261018';RUN=ROOT/'output/h5-cog-lattice-backfill-20261018'","SRC=ROOT/'output/h5-aligned-aspect-rectangles-20261018';RUN=ROOT/'output/h5-aligned-aspect-backfill-20261018'").replace("SRC/'all-patterns.json'","SRC/'patterns.json'")
text=text.replace("assert not public['valid'] and public['violations'] and all(v['code']=='quantity' for v in public['violations'])","assert public['valid']==(not missing);assert not missing or (public['violations'] and all(v['code']=='quantity' for v in public['violations']))\n        write(out/f\"partial-{result['partial']}-command.json\",{'command':command,'exit_code':r.returncode})")
text=text.replace("'public_only_quantity_failure':True","'public_valid':public['valid'],'public_only_quantity_failure':bool(missing)")
text=text.replace("'no_complete_witness':True","'no_complete_witness':not any(r['public_valid'] for r in records)")
with (ROOT/'output/audit_h5_aligned_aspect_backfill.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared fresh actual-outline continuation and original-vertex audit.')
