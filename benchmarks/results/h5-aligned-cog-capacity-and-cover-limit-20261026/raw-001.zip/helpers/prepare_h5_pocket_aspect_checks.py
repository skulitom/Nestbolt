from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('backfill_h5_aligned_aspects.py','backfill_h5_pocket_aspects.py'),('audit_h5_aligned_aspect_backfill.py','audit_h5_pocket_aspect_backfill.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-aligned-aspect-rectangles-20261018','h5-pocket-aspect-rectangles-20261018').replace('h5-aligned-aspect-backfill-20261018','h5-pocket-aspect-backfill-20261018')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_aligned_rectangle_trace.py').read_text(encoding='utf-8').replace('h5-aligned-aspect-rectangles-20261018','h5-pocket-aspect-rectangles-20261018').replace("plan['source_hashes']","plan['inputs']").replace('len(recipes)==364','len(recipes)==5246').replace('==109200','==1573800')
s=s.replace('seen=set();best=', 'best=').replace("assert key not in seen;seen.add(key);", "index=n-1;expected=(index//300,(index%300)//12,plan['sorts'][(index%12)//3],plan['fits'][index%3]);assert key==expected;")
s=s.replace("'distinct_configuration_keys':len(seen)","'distinct_configuration_keys':n")
s=s.replace("result=load(OUT/'result.json');",'''components=load(ROOT/'output/h5-aligned-pockets-20261018/components.json');omitted=load(OUT/'omitted-equivalents.json')
    for row in omitted:
        a=components[row['case']];b=components[row['same_rectangle_and_inventory_as']];assert (a['width'],a['height'],Counter(m['part_id'] for m in a['members']))==(b['width'],b['height'],Counter(m['part_id'] for m in b['members']))
    prefixpairs=0;minimum=math.inf;parts={p['id']:p for p in job['parts']}
    for name,p in patterns.items():
        if not name.startswith('prefix-'):continue
        gs=[audit.shape(parts[m['part_id']],m['transform']) for m in p['members']]
        for i,a in enumerate(gs):
            assert a.bounds[0]>=-1e-7 and a.bounds[1]>=-1e-7 and a.bounds[2]<=p['width']+1e-7 and a.bounds[3]<=p['height']+1e-7
            for b in gs[i+1:]:prefixpairs+=1;distance=a.distance(b);minimum=min(minimum,distance);assert a.disjoint(b) and distance>=job['clearance']
    assert prefixpairs==66
    result=load(OUT/'result.json');''')
s=s.replace("'full_target_witness':False}","'prefix_component_pairs':prefixpairs,'prefix_minimum_distance_mm':minimum,'omitted_rectangle_equivalents_verified':len(omitted),'full_target_witness':False}")
with (ROOT/'output/audit_h5_pocket_rectangle_trace.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared original-geometry continuation and complete trace/prefix audits.')
