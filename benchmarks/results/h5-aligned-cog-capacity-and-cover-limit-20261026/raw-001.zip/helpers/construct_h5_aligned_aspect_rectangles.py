"""Finite frame-column sweep with aligned cogs and all bracket aspect multisets."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import copy,itertools,json,math,time,gzip,shutil,traceback
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;SRC=ROOT/'output/h5-aligned-aspect-cpsat-20261018';OUT=ROOT/'output/h5-aligned-aspect-rectangles-20261018';load=base.load;write=base.write
def main():
    assert (SRC/'result.json').exists();OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');patterns=load(SRC/'patterns.json');job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');cpplan=load(SRC/'plan.json');g=cpplan['block_gap_mm'];width=cpplan['width_mm'];heights=cpplan['height_limits_mm'];mixes=cpplan['bracket_patterns'];names=cpplan['aligned_patterns'];parts={p['id']:p for p in job['parts']}
    frames=base.frame_configs(patterns['frame'],18,width,heights[0],g);cogrecipes=[]
    for counts in cpplan['recipes']:
        options=[[n for n in names if len(patterns[n]['members'])==count] for count in counts if count]
        for seq in itertools.product(*options):
            if seq not in cogrecipes:cogrecipes.append(seq)
    mixcounts=[(a,b,6-a-b) for a in range(7) for b in range(7-a)];recipes=[];required=Counter({p['id']:p['quantity'] for p in job['parts']})
    for cogs,mc in itertools.product(cogrecipes,mixcounts):
        items=list(cogs)+[n for n,qty in zip(mixes,mc) for _ in range(qty)]+['insert']*15;counts=Counter(m['part_id'] for n in items+['frame']*18 for m in patterns[n]['members']);assert counts==required;recipes.append({'cogs':list(cogs),'mix_counts':list(mc),'items':items})
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'source_hashes':{str((SRC/n).relative_to(ROOT)):base.digest(SRC/n) for n in ['patterns.json','plan.json','job.json','conditional-target.json','model-audit.json','geometry-audit.json']},'frame_allocations':len(frames),'cog_decompositions':len(cogrecipes),'bracket_aspect_multisets':len(mixcounts),'inventory_recipes':len(recipes),'sorts':['area','long','short','filled'],'fits':['short','area','bottom'],'seconds_limit':120,'maximum_attempts':len(frames)*len(recipes)*12,'retained_distinct_partials':8,'method':'Finite deterministic rectangle construction, using all retained frame-column allocations and every multiset of six bracket groups across all three aspect variants. New aligned square/staggered cog decompositions and original fifteen remaining inserts. Three placement scores and four ordering keys. Save compact records of every attempted recipe; retain eight distinct greatest-filled-area partials or stop at first complete original inventory. This heuristic deliberately restricts frame positions, so failure is not infeasibility. Audit retained actual geometry separately. No native benchmark or gate rerun.'};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json','patterns.json']:shutil.copyfile(SRC/n,OUT/n)
    write(OUT/'frames.json',frames);write(OUT/'recipes.json',recipes);retained=[];seen=set();attempts=0;expired=False;complete=False;t0=time.perf_counter();maxcount=0
    with gzip.open(OUT/'attempts.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
        for ri,r in enumerate(recipes):
            for fi,frame in enumerate(frames):
                for sort,fit in itertools.product(plan['sorts'],plan['fits']):
                    if time.perf_counter()-t0>=120:expired=True;break
                    blocks,left=base.pack(r['items'],patterns,[frame['free'],[(0,0,width+g,heights[1]+g)]],sort,fit,g);blocks=frame['placed']+blocks;counts=Counter(m['part_id'] for b in blocks for m in patterns[b['pattern']]['members']);missing=required-counts;area=sum(patterns[b['pattern']]['area'] for b in blocks);attempts+=1;maxcount=max(maxcount,sum(counts.values()));row={'attempt':attempts,'recipe':ri,'frame':fi,'sort':sort,'fit':fit,'count':sum(counts.values()),'filled_area_mm2':area,'missing':dict(missing),'unplaced':left};log.write(json.dumps(row,separators=(',',':'))+'\n')
                    assert counts+Counter(m['part_id'] for n in left for m in patterns[n]['members'])==required
                    rank=(area,sum(counts.values()),-attempts)
                    if not left or len(retained)<8 or rank>retained[-1]['rank']:
                        key=json.dumps(blocks,sort_keys=True,separators=(',',':'))
                        if key not in seen:
                            seen.add(key);retained.append({'rank':rank,**row,'blocks':blocks});retained.sort(key=lambda r:r['rank'],reverse=True);retained=retained[:8]
                    if not left:complete=True;break
                if complete or expired:break
            if complete or expired:break
    for i,r in enumerate(retained):write(OUT/f'partial-{i}.json',base.layout_of(job,patterns,r['blocks']))
    write(OUT/'retained.json',retained);result={'seconds':time.perf_counter()-t0,'attempts':attempts,'maximum_attempts':plan['maximum_attempts'],'expired':expired,'complete':complete,'maximum_count':maxcount,'best_count':retained[0]['count'],'best_filled_area_mm2':retained[0]['filled_area_mm2'],'best_missing':retained[0]['missing'],'retained':len(retained),'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
