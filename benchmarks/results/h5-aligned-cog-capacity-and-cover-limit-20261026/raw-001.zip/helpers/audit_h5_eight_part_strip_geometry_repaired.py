"""Reconstruct every used profile and all raw collision regions independently."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations,product
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,shape
from shapely.affinity import affine_transform
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-part-strip-source-20261026';OUT=BASE/'audit-repaired';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct used profiles from original job outer vertices and approved transforms; verify all eight original IDs and exact conservative stock boxes. Rebuild every raw Minkowski collision region from the union of all unmerged original triangle-pair vertex-difference hulls, without builder geometry helpers. Verify complete coverage of each raw region by its guarded obstacle, positive boundary separation above the native guard, and whole-obstacle coverage by stored convex faces. Recompute every outside-plane coefficient and rational rounding bound independently. Exhaustively check all28 physical pairs in the sole declared pattern. No solving, omitted item, old fixed-pose capacity or complete-layout claim.'})
spec=load(BASE/'plan.json');profiles=load(BASE/'profiles.json');job=load(JOB);families={p['id']:p for p in job['parts']};items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');known=set()
for name in ['h5-thirteen-part-selection-and-sheet-exclusion-20261026','h5-seven-part-obstruction-and-broader-source-20261026']:
    m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
for n,h in spec['inputs'].items():
    assert digest(ROOT/n)==h,n
    if not any(k in n for k in ['h5-three-free-brackets-search','h5-eight-part-band-search','h5-insert36-cog53-exchange']):assert h in known,n
assert [p['item'] for p in spec['parts']]==[21,22,25,26,53,63,64,65]
assert spec['orientation_patterns']==[[5,5,6,7,9,9,9,9]]
assert len(set(p['item'] for p in spec['parts']))==8 and all(p['family']==items[p['item']]['family'] and p['copy']==items[p['item']]['copy'] for p in spec['parts']);assert spec['maximum_calls']==1 and spec['per_pattern_solver_seconds']==45 and spec['shared_solver_seconds']==60 and spec['solver_workers']==4 and spec['solver_seed']==0
first=spec['first_sheet_checked_originals'];ids=[p['item'] for p in spec['parts']];assert len(first)==55 and len(set(first+ids+[28,29,37]))==66 and sorted(first+ids+[28,29,37])==list(range(66));assert spec['pending_first_sheet_originals']==[28,29,37]
geoms={};triangles={};errors=[];stock=[F(*v) for v in spec['stock_bounds_rational']]
assert spec['stock_bounds_rational']==load(ROOT/'output/h5-source-orientation-construction-20261025/geometry.json')['stock_bounds_rational'][1]
for pi in spec['used_profiles']:
    p=profiles[pi];g=families[p['family']];assert not p['mirrored'] or g['allow_mirror'];angle=p['rotation_radians'];co,si=math.cos(angle),math.sin(angle);mi=-1 if p['mirrored'] else 1
    if p['family']=='cog':assert g['rotations']['kind']=='free';cx,cy=p['original_center'];tx,ty=-co*cx+si*cy,-si*cx-co*cy
    else:
        assert g['rotations']['kind']=='list' and p['quarter_turn']*90. in g['rotations']['degrees'];pts=[(mi*x*co-y*si,mi*x*si+y*co) for x,y in g['geometry'][0]['outer']];tx,ty=-min(x for x,y in pts),-min(y for x,y in pts)
    raw=affine_transform(Polygon(g['geometry'][0]['outer']),[mi*co,-si,mi*si,co,tx,ty]);saved=shape(p['geometry']);error=raw.hausdorff_distance(saved);assert error<1e-7 and raw.is_valid and saved.is_valid;errors.append(error);geoms[pi]=raw;triangles[pi]=list(shapely.constrained_delaunay_triangles(raw).geoms);assert unary_union(triangles[pi]).symmetric_difference(raw).area<1e-7
    b=saved.bounds;assert list(b)==p['bounds'];pad=F(.0125)+F(.000001);bounds=[math.ceil((stock[0]+pad-F(b[0]))*1000),math.ceil((stock[1]+pad-F(b[1]))*1000),math.floor((stock[2]-pad-F(b[2]))*1000),math.floor((stock[3]-pad-F(b[3]))*1000)];assert bounds==spec['anchor_bounds_units1000'][str(pi)]
    rb=raw.bounds;gaps=[bounds[0]/1000+rb[0]-float(stock[0]),bounds[1]/1000+rb[1]-float(stock[1]),float(stock[2])-bounds[2]/1000-rb[2],float(stock[3])-bounds[3]/1000-rb[3]];assert min(gaps)>3000*32*2**-23
needed=sorted({(r[a],r[b]) for r in spec['orientation_patterns'] for a,b in combinations(range(8),2)});assert needed==[(c['profile_a'],c['profile_b']) for c in spec['mutual_cases']];hulls=planes=faces=0;details=[];gap=(job['clearance']+3000*32*2**-23)/math.cos(.05)
for c in spec['mutual_cases']:
    data=load(BASE/'mutual'/f"{c['index']:03d}.json");assert data['case']==c;pieces=[]
    for a,b in product(triangles[c['profile_a']],triangles[c['profile_b']]):pieces.append(MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull);hulls+=1
    raw=unary_union(pieces);stored=shape(data['raw_forbidden']);error=raw.hausdorff_distance(stored);assert error<1e-7;expanded=shape(data['expanded_forbidden']);assert expanded.covers(raw) and expanded.boundary.distance(raw)>gap;face_polys=[]
    for f in data['faces']:
        poly=shape(f['expanded_face']);original=shape(f['raw_face']);assert poly.covers(original) and poly.equals(poly.convex_hull);face_polys.append(poly);coords=list(orient(poly,sign=1).exterior.coords);expected=[]
        for p,q in zip(coords,coords[1:]):
            x,y=map(F,p);u,v=map(F,q);a,b=v-y,x-u
            if not a and not b:continue
            norm=max(abs(a),abs(b));a/=norm;b/=norm;d=a*x+b*y;A,B=round(a*10**7),round(b*10**7);err=abs(F(A)-a*10**7)*1500000+abs(F(B)-b*10**7)*3000000+1;bound=math.ceil(d*1000*10**7+err);expected.append({'edge':[list(p),list(q)],'a':A,'b':B,'bound':bound,'sense':'ge','coefficient_error_bound':[err.numerator,err.denominator]});planes+=1
        assert expected==f['outside_halfplanes'];faces+=1
    assert unary_union(face_polys).covers(expanded) and data['complete_forbidden_covered'];details.append({'case':c['index'],'raw_error_mm':error,'guarded_boundary_separation_mm':expanded.boundary.distance(raw),'faces':len(face_polys),'passed':True})
for row in spec['orientation_patterns']:
    for p,pi in zip(spec['parts'],row):assert p['family']==profiles[pi]['family']
    assert len(list(combinations(row,2)))==28
write(OUT/'case-checks.json',details);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'patterns':1,'mandatory_originals_per_pattern':8,'physical_pairs_checked':28,'profile_reconstructions':len(geoms),'max_original_profile_error_mm':max(errors),'independent_raw_collision_cases':len(details),'unmerged_triangle_pair_hulls':hulls,'full_guarded_faces':faces,'outside_planes_exactly_reconstructed':planes,'minimum_guarded_raw_separation_mm':min(r['guarded_boundary_separation_mm'] for r in details),'required_native_pair_gap_mm':gap,'all_stock_bounds_native_guarded':True,'old_second_sheet_fixed_poses_released':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
