from pathlib import Path
from collections import Counter
import json,gzip,math
from shapely.geometry import Polygon
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;OUT=ROOT/'output/h5-pocket-aspect-rectangles-20261018';load=audit.load
def main():
    plan=load(OUT/'plan.json');patterns=load(OUT/'patterns.json');job=load(OUT/'job.json');recipes=load(OUT/'recipes.json');frames=load(OUT/'frames.json');required=Counter({p['id']:p['quantity'] for p in job['parts']});areas={p['id']:Polygon(p['geometry'][0]['outer']).area for p in job['parts']};fullarea=sum(areas[k]*n for k,n in required.items());retained=load(OUT/'retained.json');wanted={r['attempt']:r for r in retained};best=-math.inf;maximum=0
    for name,h in plan['inputs'].items():assert audit.digest(ROOT/name)==h
    assert len(recipes)==5246 and len(frames)==25
    for r in recipes:assert Counter(m['part_id'] for n in r['items']+['frame']*18 for m in patterns[n]['members'])==required
    n=0
    with gzip.open(OUT/'attempts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);n+=1;assert row['attempt']==n;key=(row['recipe'],row['frame'],row['sort'],row['fit']);index=n-1;expected=(index//300,(index%300)//12,plan['sorts'][(index%12)//3],plan['fits'][index%3]);assert key==expected;assert row['sort'] in plan['sorts'] and row['fit'] in plan['fits'] and 0<=row['frame']<25
            r=recipes[row['recipe']];unplaced=Counter(row['unplaced']);assert not unplaced-Counter(r['items']);missing=Counter(m['part_id'] for name in row['unplaced'] for m in patterns[name]['members']);assert dict(missing)==row['missing'];assert row['count']==sum(required.values())-sum(missing.values());area=fullarea-sum(areas[k]*qty for k,qty in missing.items());assert abs(area-row['filled_area_mm2'])<1e-6;best=max(best,area);maximum=max(maximum,row['count'])
            if n in wanted:
                r=wanted[n];assert all(row[k]==r[k] for k in row);counts=Counter(m['part_id'] for b in r['blocks'] for m in patterns[b['pattern']]['members']);assert counts+missing==required
    components=load(ROOT/'output/h5-aligned-pockets-20261018/components.json');omitted=load(OUT/'omitted-equivalents.json')
    for row in omitted:
        a=components[row['case']];b=components[row['same_rectangle_and_inventory_as']];assert (a['width'],a['height'],Counter(m['part_id'] for m in a['members']))==(b['width'],b['height'],Counter(m['part_id'] for m in b['members']))
    prefixpairs=0;minimum=math.inf;parts={p['id']:p for p in job['parts']}
    for name,p in patterns.items():
        if not name.startswith('prefix-'):continue
        gs=[audit.shape(parts[m['part_id']],m['transform']) for m in p['members']]
        for i,a in enumerate(gs):
            assert a.bounds[0]>=-1e-7 and a.bounds[1]>=-1e-7 and a.bounds[2]<=p['width']+1e-7 and a.bounds[3]<=p['height']+1e-7
            for b in gs[i+1:]:prefixpairs+=1;distance=a.distance(b);minimum=min(minimum,distance);assert a.disjoint(b) and distance>=job['clearance']
    assert prefixpairs==66
    result=load(OUT/'result.json');assert n==plan['maximum_attempts']==1573800 and not result['expired'] and not result['complete'];assert abs(best-result['best_filled_area_mm2'])<1e-6 and maximum==result['maximum_count'];out={'attempts':n,'distinct_configuration_keys':n,'exact_inventory_recipes':len(recipes),'all_missing_counts_and_filled_areas_verified':True,'retained_records_match_trace':True,'retained_geometry_covered_by_original_vertex_backfill_audit':True,'every_rejected_arrangement_geometry_audited':False,'prefix_component_pairs':prefixpairs,'prefix_minimum_distance_mm':minimum,'omitted_rectangle_equivalents_verified':len(omitted),'full_target_witness':False};audit.write(OUT/'trace-audit.json',out);print(json.dumps(out))
if __name__=='__main__':main()
