from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('backfill_h5_pocket_aspects.py','backfill_h5_row_shelves.py'),('audit_h5_pocket_aspect_backfill.py','audit_h5_row_shelf_backfill.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-pocket-aspect-rectangles-20261018','h5-five-row-shelves-20261018').replace('h5-pocket-aspect-backfill-20261018','h5-five-row-backfill-20261018')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_pocket_rectangle_trace.py').read_text(encoding='utf-8').replace('h5-pocket-aspect-rectangles-20261018','h5-five-row-shelves-20261018').replace("plan['inputs']","plan['source_hashes']").replace('len(frames)==25','len(frames)==24').replace("row['frame']<25","row['frame']<24").replace('==1573800','==1089564')
s=s.replace('import json,gzip,math','import json,gzip,math,itertools\nfrom shapely.geometry import box\nfrom shapely.ops import unary_union')
s=s.replace("n=0\n    with gzip.open",'''eligible=load(OUT/'eligible-frames.json');filtered=load(OUT/'filtered-prefixes.json');expected_filtered=[];g=plan['gap_mm'];W=plan['width_mm']+g;Hs=[h+g for h in plan['heights_mm']];free_errors=[];frame_pairs=0
    for fi,frame in enumerate(frames):
        assert sum(frame['counts'])==18 and len(frame['counts'])==len(frame['rotations'])==5
        padded=[];physical=[];y=0.;blocks=[]
        for rot,qty in zip(frame['rotations'],frame['counts']):
            w,h=(350.,450.) if rot else (450.,350.);assert qty<=math.floor(W/(w+g))
            for col in range(qty):blocks.append({'pattern':'frame','bin':0,'x':col*(w+g),'y':y,'rotated':rot,'rect':[col*(w+g),y,w+g,h+g]})
            y+=h+g
        assert blocks==frame['placed'] and y<=Hs[0]
        for b in blocks:
            x,y,w,h=b['rect'];padded.append(box(x,y,x+w,y+h));assert x>=0 and y>=0 and x+w<=W+1e-8 and y+h<=Hs[0]+1e-8
        for a,b in itertools.combinations(padded,2):frame_pairs+=1;assert a.intersection(b).area<1e-6
        leftover=box(0,0,W,Hs[0]).difference(unary_union(padded));saved=unary_union([box(x,y,x+w,y+h) for x,y,w,h in frame['free']]);error=leftover.symmetric_difference(saved).area;assert error<1e-6;free_errors.append(error)
    for ri,r in enumerate(recipes):
        p=patterns[r['component']];expect=[]
        for fi,frame in enumerate(frames):
            spaces=frame['free']+[[0,0,W,Hs[1]]];fits=any(w>=pw-1e-8 and h>=ph-1e-8 for x,y,w,h in spaces for pw,ph in [(p['width']+g,p['height']+g),(p['height']+g,p['width']+g)])
            if fits:expect.append(fi)
            else:expected_filtered.append([ri,fi])
        assert expect==eligible[ri]
    assert expected_filtered==filtered and len(filtered)==35107
    keys=((ri,fi,sort,fit) for ri,fs in enumerate(eligible) for fi in fs for sort in plan['sorts'] for fit in plan['fits'])
    n=0
    with gzip.open''')
s=s.replace("index=n-1;expected=(index//300,(index%300)//12,plan['sorts'][(index%12)//3],plan['fits'][index%3]);assert key==expected;","assert key==next(keys);")
a=s.index("    components=load(ROOT/");b=s.index("    result=load(OUT/'result.json');",a)
s=s[:a]+'''    assert next(keys,None) is None
    prior=ROOT/'output/h5-pocket-aspect-rectangles-20261018'
    for name in ['patterns.json','recipes.json','job.json','conditional-target.json']:assert (OUT/name).read_bytes()==(prior/name).read_bytes()
'''+s[b:]
s=s.replace("'prefix_component_pairs':prefixpairs,'prefix_minimum_distance_mm':minimum,'omitted_rectangle_equivalents_verified':len(omitted),","'fixed_frame_pair_checks':frame_pairs,'maximum_free_union_error_mm2':max(free_errors),'all_prefix_rectangle_filters_verified':len(filtered),'all_recipe_and_pattern_bytes_unchanged':True,")
with (ROOT/'output/audit_h5_row_shelf_trace.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared row-shelf continuation and independent free-space/trace verification.')
