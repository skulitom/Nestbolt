"""Independent original-vertex checks for staggered components and pocket fills."""
from pathlib import Path
from collections import Counter
import json,math,itertools,gzip
from shapely.geometry import Polygon
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;RAG=ROOT/'output/h5-ragged-cogs-20261018';POCKET=ROOT/'output/h5-ragged-pockets-20261018';load=audit.load;write=audit.write;shape=audit.shape
def check_members(parts,members,clearance,width,height):
    gs=[];minimum=math.inf
    for m in members:
        p=parts[m['part_id']];t=m['transform'];assert not t['mirrored'] or p['allow_mirror']
        if p['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in p['rotations']['degrees'])
        g=shape(p,t);assert g.is_valid and g.area>0 and g.bounds[0]>=-1e-7 and g.bounds[1]>=-1e-7 and g.bounds[2]<=width+1e-7 and g.bounds[3]<=height+1e-7;gs.append(g)
    pairs=0
    for a,b in itertools.combinations(gs,2):pairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=clearance-1e-7
    return pairs,minimum
def main():
    out=POCKET/'audit';out.mkdir();job=load(RAG/'job.json');parts={p['id']:p for p in job['parts']};original=load(RAG/'patterns.json');variants=load(RAG/'variants.json');plan=load(RAG/'plan.json');pplan=load(POCKET/'plan.json');cog=Polygon(parts['cog']['geometry'][0]['outer']);cx,cy=cog.centroid.coords[0];pairs=0;minimum=math.inf
    for p in [plan,pplan]:
        for name,h in p['inputs'].items():assert audit.digest(ROOT/name)==h
    assert len(variants)==54 and len(original)==324
    assert {(v['base'],v['phase'],v['offset_adjustment']) for v in variants}==set(itertools.product(plan['base_angles_degrees'],plan['row_phase_degrees'],plan['half_pitch_offsets_mm']))
    for v in variants:
        for name,rows in zip(v['patterns'],plan['row_counts']):
            p=original[name];raw=[]
            for ri,n in enumerate(rows):
                theta=math.radians(v['base']+(ri%2)*v['phase']);c,s=math.cos(theta),math.sin(theta)
                for col in range(n):raw.append({'rotation_radians':theta,'translation':[col*v['pitch'][0]+(ri%2)*v['row_shift']-c*cx+s*cy,ri*v['pitch'][1]-s*cx-c*cy],'mirrored':False})
            gs=[shape(parts['cog'],t) for t in raw];x0=min(g.bounds[0] for g in gs);y0=min(g.bounds[1] for g in gs)
            for t,m in zip(raw,p['members']):t['translation'][0]-=x0;t['translation'][1]-=y0;assert m=={'part_id':'cog','transform':t}
            count,mind=check_members(parts,p['members'],job['clearance'],p['width'],p['height']);pairs+=count;minimum=min(minimum,mind)
    assert pairs==load(RAG/'result.json')['pair_checks'];components=load(POCKET/'components.json');cases=load(POCKET/'result.json')['cases'];assert len(cases)==48
    cpairs=0;cmind=math.inf;attempts=0;additions=0;required=Counter({k:p['quantity'] for k,p in parts.items()});old=load(ROOT/'output/h5-cog-lattices-20261018/all-patterns.json');allp={**old,**components}
    for case in cases:
        p=components[case['id']];source=original[p['source_pattern']];n=len(source['members']);assert p['members'][:n]==source['members'] and p['width']==source['width'] and p['height']==source['height'];c,d=check_members(parts,p['members'],job['clearance'],p['width'],p['height']);cpairs+=c;cmind=min(cmind,d)
        assert Counter(m['part_id'] for m in p['members'])==Counter(case['inventory']);assert Counter(m['part_id'] for name,qty in case['recipe'].items() for _ in range(qty) for m in allp[name]['members'])==required
        area=sum((allp[name]['width']+.22)*(allp[name]['height']+.22)*qty for name,qty in case['recipe'].items());assert area==case['padded_area_mm2']
        current=list(source['members']);templates=load(POCKET/f"templates-{case['row_family']}.json");seen=0
        with gzip.open(POCKET/case['id']/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                e=json.loads(line)
                if e['kind']=='accepted':current.append(e['member']);continue
                if e['kind']!='candidate':continue
                b=e['block'];member=json.loads(json.dumps(templates[b['template']]['members'][0]));member['transform']['translation'][0]+=b['x'];member['transform']['translation'][1]+=b['y'];g=shape(parts[member['part_id']],member['transform']);x0,y0,x1,y1=g.bounds;valid=x0>=-1e-7 and y0>=-1e-7 and x1<=p['width']+1e-7 and y1<=p['height']+1e-7
                for m in current:
                    fixed=shape(parts[m['part_id']],m['transform']);valid=valid and g.disjoint(fixed) and g.distance(fixed)>=job['clearance']-1e-7
                assert valid==e['valid'];seen+=1
        assert current==p['members'] and seen==case['attempts'];attempts+=seen;additions+=len(p['members'])-n
    recipes=load(POCKET/'selected-recipes.json')
    for si,r in enumerate(recipes):assert r==min((c for c in cases if c['row_family']==si and not c['expired']),key=lambda c:(c['padded_area_mm2'],sum(c['recipe'].values()),c['id']))
    result={'staggered_components':len(original),'staggered_pair_checks':pairs,'staggered_minimum_distance_mm':minimum,'all_transforms_reconstructed_exact':True,'pocket_components':len(components),'pocket_pair_checks':cpairs,'pocket_minimum_distance_mm':cmind,'pocket_candidate_checks':attempts,'accepted_additions_total':additions,'all_original_cog_poses_and_bounds_preserved':True,'all_recipes_exact_original_inventory':True,'all_ranking_areas_recomputed':True,'no_full_target_witness_from_component_checks':True};write(out/'checks.json',result);print(json.dumps(result))
if __name__=='__main__':main()
