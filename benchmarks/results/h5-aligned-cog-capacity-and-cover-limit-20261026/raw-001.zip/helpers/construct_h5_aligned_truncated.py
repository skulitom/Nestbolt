"""Original uniform rows with trailing vacant cells for mixed-part components."""
from pathlib import Path
from datetime import datetime,timezone
import math,itertools,json,time,shutil
from shapely.geometry import Polygon
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;SRC=ROOT/'output/h5-aligned-stagger-20261018';OLD=ROOT/'output/h5-aligned-aspect-cpsat-20261018';OUT=ROOT/'output/h5-aligned-truncated-20261018';load=base.load;write=base.write
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};prior=load(SRC/'patterns.json');priorplan=load(SRC/'plan.json');angle=priorplan['angle_radians'];dx=priorplan['pitch_x_mm'];c,s=math.cos(angle),math.sin(angle);cx,cy=shapes['cog'].centroid.coords[0]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'inputs':{str((SRC/n).relative_to(ROOT)):base.digest(SRC/n) for n in ['plan.json','patterns.json','audit.json','job.json']},'counts':list(range(9,16)),'columns':[4,5],'offset_fractions':[0,.5],'seconds_limit':60,'method':'Retain the audited contact-aligned angle and horizontal/vertical pitches for square and half-offset uniform rows, with four or five columns. For each 9 through 15 original cogs, leave the trailing last-row cells vacant. Preserve actual source geometry and validate every pair. The follow-up may fill those vacant cells with original inserts or brackets without enlarging the cog component bounds. No full layout, native clearance or quality claim.'};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(OLD/n,OUT/n)
    t0=time.perf_counter();patterns={};selection=[];pairs=0;minimum=math.inf
    for n,cols,fi in itertools.product(plan['counts'],plan['columns'],[0,4]):
        assert time.perf_counter()-t0<60;source=prior[f'aligned-f{fi}-n15-c{cols}'];dy=source['construction']['pitch_y_mm'];fraction=fi/8;members=[]
        for i in range(n):
            row,col=divmod(i,cols);x=(col+(fraction if row%2 else 0))*dx;y=row*dy;members.append(base.member('cog',base.transform(angle,x-c*cx+s*cy,y-s*cx-c*cy)))
        name=f'truncated-f{fi}-n{n}-c{cols}';p=base.pattern(name,members,shapes);p['construction']={'source_pattern':source['id'],'count':n,'columns':cols,'fraction':fraction};gs=[base.gap.pose(shapes['cog'],m['transform']) for m in p['members']]
        for a,b in itertools.combinations(gs,2):pairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']
        patterns[name]=p;selection.append({'pattern':name,'width_mm':p['width'],'height_mm':p['height']})
    write(OUT/'patterns.json',patterns);write(OUT/'selection.json',selection);result={'seconds':time.perf_counter()-t0,'components':len(patterns),'original_pair_checks':pairs,'minimum_distance_mm':minimum,'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result))
if __name__=='__main__':main()
