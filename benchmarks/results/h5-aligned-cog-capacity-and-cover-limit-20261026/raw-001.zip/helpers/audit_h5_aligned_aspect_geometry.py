"""Original-vertex component checks and conditional full-witness validation."""
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
import math,itertools,json,subprocess
import audit_h5_cog_lattices as original
ROOT=original.ROOT;OUT=ROOT/'output/h5-aligned-aspect-cpsat-20261018';load=original.load;write=original.write
def main():
    job=load(OUT/'job.json');parts={p['id']:p for p in job['parts']};patterns=load(OUT/'patterns.json');pairs=0;minimum=math.inf
    for p in patterns.values():
        gs=[]
        for m in p['members']:
            part=parts[m['part_id']];t=m['transform'];assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            g=original.shape(part,t);assert g.is_valid and g.area>0 and min(g.bounds[:2])>=-1e-7 and g.bounds[2]<=p['width']+1e-7 and g.bounds[3]<=p['height']+1e-7;gs.append(g)
        assert abs(sum(g.area for g in gs)-p['area'])<1e-6
        for a,b in itertools.combinations(gs,2):pairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
    result={'components':len(patterns),'component_pairs':pairs,'minimum_component_distance_mm':minimum,'all_original_allowed_orientations_and_bounds_verified':True,'native_margin_qualified':False}
    outcome=load(OUT/'result.json');result['solver_status']=outcome['status'];result['full_target_witness']=False
    if outcome['feasible']:
        layout=load(OUT/'layout.json');target=load(OUT/'conditional-target.json');selection=load(OUT/'selection.json');assert layout['sheets']==load(OUT/'original.json')['sheets'];counts=Counter(p['part_id'] for p in layout['placements']);assert counts==Counter({p['id']:p['quantity'] for p in job['parts']})
        for k,n in counts.items():assert sorted(p['copy_index'] for p in layout['placements'] if p['part_id']==k)==list(range(n))
        gs=defaultdict(list);tops={};st=job['stocks'][0];m=st['margins'];e=job['edge_clearance']
        for p in layout['placements']:
            g=original.shape(parts[p['part_id']],p['transform']);x0,y0,x1,y1=g.bounds;upper=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert x0>=m['left']+e-1e-7 and y0>=m['bottom']+e-1e-7 and x1<=st['width']-m['right']-e+1e-7 and y1<=upper-m['top']-e+1e-7;gs[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops.get(p['sheet_id'],0),y1)
        lp=0;lm=math.inf
        for group in gs.values():
            for a,b in itertools.combinations(group,2):lp+=1;d=a.distance(b);lm=min(lm,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
        charged=st['width']*(st['height']+tops['sheet-1']+m['top']+e);assert charged<=target['target_material_mm2']+1e-6
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert original.digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';cmd=[str(cli),'validate','--library',str(OUT/'library.json'),'--request',str(OUT/'request.json'),'--layout',str(OUT/'layout.json')];r=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/'cli-stdout.json').write_bytes(r.stdout);(OUT/'cli-stderr.log').write_bytes(r.stderr);write(OUT/'cli-command.json',{'command':cmd,'exit_code':r.returncode});report=json.loads(r.stdout);assert r.returncode==0 and report['valid'],report
        result.update(full_target_witness=True,parts=sum(counts.values()),layout_pairs=lp,minimum_layout_distance_mm=lm,charged_material_mm2=charged,target_material_mm2=target['target_material_mm2'],frozen_cli_valid=True)
    write(OUT/'geometry-audit.json',result);print(json.dumps(result))
if __name__=='__main__':main()
