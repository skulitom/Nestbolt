"""Add exact frame contacts with the diagnostic full insert arrangement."""
from collections import Counter
from datetime import datetime, timezone
import copy, gzip, heapq, itertools, json, math, shutil, time
import numpy as np
import shapely
from shapely.strtree import STRtree
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, load, write, digest
from census_h5_one_part_moves import bits

DIAG = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
TOL = 1e-7

def key(p):
    t = p['transform']
    return (p['part_id'], p['sheet_id'], t['mirrored'],
            float(t['rotation_radians']).hex(), *(float(x).hex() for x in t['translation']))

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'build.py')
    sources = [DIAG / n for n in ['selected-indices.json', 'audit/checks.json']]
    sources += [SRC / n for n in ['candidates.json', 'job.json', 'conditional-target.json', 'new-cliques.jsonl.gz']]
    sources += [OLD / 'cliques.jsonl.gz']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'generation': 'Preserve all 9059 original poses and indexes. Fix the audited final 21-insert diagnostic arrangement. For frame orientations0/90, construct every cross-product of feasible x/y contacts with each fixed insert bounding rectangle or the usable stock boundary. Offset insert contacts by clearance+0.001mm and stock contacts by0.0001mm. Keep exact unrounded transforms and deduplicate only exact transform identities. Retain only new frames compatible with the fixed inserts.',
        'original_core_pool': 'Restore every original compatible frame/bracket/cog pose, including those previously removed by dominance. Adding new frame choices can invalidate earlier dominance relations.',
        'graph': 'Conditional on these21 fixed inserts only. Preserve every original conflict among compatible old core poses; compute every new-frame/eligible-old-core and new/new conflict from original filled outlines. Compress new edges for at most10 seconds, then retain every residual pair. Independently audit all new pairs and clique coverage before solving.',
        'maximum_contact_events': 2 * (2 * 21 + 2) ** 2,
        'clique_seconds_limit': 10, 'selection_seconds_limit': 30,
        'selection': 'One changed model with all12 brackets and15 cogs, maximizing frames16..18 from the exact feasible diagnostic seed. Eight workers, seed0, no retry.',
        'scope': 'Finite conditional construction only. This graph cannot be reused with movable inserts. Original full-job quantities and material target remain unchanged.',
        'native_packing_calls': 0, 'quality_runs': 0})
    start = time.perf_counter()
    pool = copy.deepcopy(load(SRC / 'candidates.json'))
    assert len(pool) == 9059
    old_count = len(pool)
    job = load(SRC / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    target = load(SRC / 'conditional-target.json')
    seed = set(load(DIAG / 'selected-indices.json'))
    fixed = {i for i in seed if pool[i]['placement']['part_id'] == 'insert'}
    stock = job['stocks'][0]
    m, edge = stock['margins'], job['edge_clearance']
    gap = job['clearance'] + 0.001
    geoms = [shape(parts[p['placement']['part_id']], p['placement']['transform']) for p in pool]
    keys = {key(p['placement']): i for i, p in enumerate(pool)}
    assert len(keys) == len(pool)
    events = []
    axes = []
    for sheet in ['sheet-0', 'sheet-1']:
        fixed_here = [i for i in sorted(fixed) if pool[i]['placement']['sheet_id'] == sheet]
        height = stock['height'] if sheet == 'sheet-0' else target['required_used_height_mm']
        for angle in [0.0, math.pi / 2]:
            raw = shape(parts['frame'], {'rotation_radians': angle, 'translation': [0, 0], 'mirrored': False})
            x0, y0, x1, y1 = raw.bounds
            width, tall = x1 - x0, y1 - y0
            left, right = m['left'] + edge + 0.0001, stock['width'] - m['right'] - edge - width - 0.0001
            bottom, top = m['bottom'] + edge + 0.0001, height - m['top'] - edge - tall - 0.0001
            if right < left or top < bottom:
                axes.append({'sheet': sheet, 'angle': angle, 'infeasible_stock_dimensions': True})
                continue
            xs, ys = {left, right}, {bottom, top}
            for i in fixed_here:
                a, b, c, d = geoms[i].bounds
                xs.update([a - width - gap, c + gap])
                ys.update([b - tall - gap, d + gap])
            xs = sorted(x for x in xs if left <= x <= right)
            ys = sorted(y for y in ys if bottom <= y <= top)
            axes.append({'sheet': sheet, 'angle': angle, 'x_contacts': xs, 'y_contacts': ys})
            for x, y in itertools.product(xs, ys):
                p = {'part_id': 'frame', 'sheet_id': sheet,
                     'transform': {'rotation_radians': angle, 'translation': [x - x0, y - y0], 'mirrored': False}}
                g = shape(parts['frame'], p['transform'])
                collision = [i for i in fixed_here if g.distance(geoms[i]) < job['clearance'] - TOL]
                event = {'sheet': sheet, 'angle': angle, 'x': x, 'y': y}
                if collision:
                    event.update(added=False, reason='fixed_insert_conflict', blockers=collision)
                elif key(p) in keys:
                    event.update(added=False, reason='exact_duplicate', candidate=keys[key(p)])
                else:
                    i = len(pool)
                    keys[key(p)] = i
                    pool.append({'index': i, 'placement': p,
                                 'source': {'kind': 'fixed-insert-contact-grid', 'event': len(events)},
                                 'filled_area_mm2': 157500.0})
                    geoms.append(g)
                    event.update(added=True, candidate=i)
                events.append(event)
    assert len(events) <= load(OUT / 'plan.json')['maximum_contact_events']
    original_cliques = []
    blocked = set()
    for path in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            for line in f:
                c = set(json.loads(line))
                assert len(c & fixed) <= 1
                original_cliques.append(c)
                if c & fixed:
                    blocked |= c - fixed
    eligible_old = {i for i in range(old_count) if pool[i]['placement']['part_id'] != 'insert' and i not in blocked}
    new_ids = set(range(old_count, len(pool)))
    ids = sorted(eligible_old | new_ids)
    old_rows = sorted({tuple(sorted(c & eligible_old)) for c in original_cliques if len(c & eligible_old) > 1})
    adjacency = [0] * len(pool)
    for row in old_rows:
        mask = sum(1 << i for i in row)
        for i in row:
            adjacency[i] |= mask ^ (1 << i)
    new_adjacency = [0] * len(pool)
    edges = []
    distance_checks = 0
    gs = np.asarray(geoms, dtype=object)
    for sheet in ['sheet-0', 'sheet-1']:
        relevant = np.asarray([i for i in ids if pool[i]['placement']['sheet_id'] == sheet], dtype=int)
        fresh = np.asarray([i for i in sorted(new_ids) if pool[i]['placement']['sheet_id'] == sheet], dtype=int)
        if not len(fresh):
            continue
        tree = STRtree(gs[relevant])
        pairs = tree.query(gs[fresh], predicate='dwithin', distance=job['clearance'] + TOL)
        a, b = relevant[pairs[1]], fresh[pairs[0]]
        take = a < b
        a, b = a[take], b[take]
        distance_checks += len(a)
        conflict = shapely.distance(gs[a], gs[b]) < job['clearance'] - TOL
        for i, j in zip(a[conflict], b[conflict]):
            i, j = int(i), int(j)
            edges.append((i, j))
            adjacency[i] |= 1 << j
            adjacency[j] |= 1 << i
            new_adjacency[i] |= 1 << j
            new_adjacency[j] |= 1 << i
    edges.sort()
    assert len(edges) == len(set(edges))
    remaining = new_adjacency.copy()
    heap = [(-a.bit_count(), i) for i, a in enumerate(remaining) if a]
    heapq.heapify(heap)
    new_cliques = []
    covered = 0
    compress_start = time.perf_counter()
    while heap and time.perf_counter() - compress_start < 10:
        degree, i = heapq.heappop(heap)
        if -degree != remaining[i].bit_count() or not remaining[i]:
            continue
        choices = remaining[i]
        clique = [i]
        mask = 1 << i
        while choices:
            sample = list(itertools.islice(bits(choices), 16))
            j = max(sample, key=lambda v: ((adjacency[v] & choices).bit_count(), -v))
            clique.append(j)
            mask |= 1 << j
            choices &= adjacency[j]
        assert all(not((mask ^ (1 << j)) & ~adjacency[j]) for j in clique)
        new_cliques.append(clique)
        for j in clique:
            before = remaining[j].bit_count()
            remaining[j] &= ~mask
            covered += before - remaining[j].bit_count()
            if remaining[j]:
                heapq.heappush(heap, (-remaining[j].bit_count(), j))
    compressed = len(new_cliques)
    residual = 0
    for i, mask in enumerate(remaining):
        for j in bits(mask & ~((1 << (i + 1)) - 1)):
            new_cliques.append([i, j])
            residual += 1
    assert covered // 2 + residual == len(edges)
    for name, rows in [('new-conflicts.jsonl.gz', edges), ('new-cliques.jsonl.gz', new_cliques),
                       ('old-projected-cliques.jsonl.gz', old_rows)]:
        with gzip.open(OUT / name, 'xt', encoding='utf-8', newline='\n') as f:
            for row in rows:
                f.write(json.dumps(row) + '\n')
    write(OUT / 'candidates.json', pool)
    write(OUT / 'source-events.json', events)
    write(OUT / 'axes.json', axes)
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_insert_candidates': sorted(fixed),
                               'original_eligible': sorted(eligible_old), 'new_frame_candidates': sorted(new_ids)})
    result = {'original_candidates_preserved': old_count, 'new_frames': len(new_ids),
              'contact_events': len(events), 'event_outcomes': dict(Counter(e.get('reason', 'added') for e in events)),
              'eligible_old_core': len(eligible_old), 'eligible_total_core': len(ids),
              'old_projected_cliques': len(old_rows), 'new_edges': len(edges),
              'near_pair_distances': distance_checks, 'new_compressed_cliques': compressed,
              'residual_pair_constraints': residual, 'compression_limit_reached': bool(heap),
              'seconds': time.perf_counter() - start, 'full_target_witness': False}
    write(OUT / 'generation.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
