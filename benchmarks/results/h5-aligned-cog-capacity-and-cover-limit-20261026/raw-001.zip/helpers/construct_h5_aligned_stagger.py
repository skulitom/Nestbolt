"""Finite uniform-row components from the independently verified contact angle."""
from pathlib import Path
from datetime import datetime,timezone
import json,math,itertools,time,shutil,traceback
from shapely.geometry import Polygon,LineString,mapping
from shapely.affinity import affine_transform
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;OUT=ROOT/'output/h5-aligned-stagger-20261018';SRC=ROOT/'output/h5-minimum-contact-grids-20261018'
load=base.load;write=base.write;gap=base.gap

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()}
    phase=next(p for p in load(SRC/'phases.json') if p['phase']==0);angle=phase['angles_radians'][0];pitch=phase['pitch_mm'];fractions=[i/8 for i in range(8)];grids=[[15,5],[15,4],[12,4],[10,5],[9,3],[6,3],[5,5],[3,3],[1,1]]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'input_hashes':{str((SRC/n).relative_to(ROOT)):base.digest(SRC/n) for n in ['job.json','phases.json','audit.json']},'row_offset_fractions':fractions,'grids':grids,'angle_radians':angle,'pitch_x_mm':pitch,'construction_clearance_mm':.225,'pitch_increment_mm':.0001,'seconds_limit':60,
          'method':'All rows have the declared column count, except a possible trailing incomplete row. Alternate row offsets are zero and fraction times the verified horizontal pitch. For each fraction and column count derive the vertical pitch from the greatest absolute vertical extent of the actual same-orientation NFP at every cross-row horizontal difference, including both row directions and all column differences. Validate every original member pair including nonadjacent rows. No symmetry assumption. Retain all components and the nondominated bounding rectangles per count. This is component construction, not whole-job qualification.'}
    write(OUT/'plan.json',plan);shutil.copyfile(SRC/'job.json',OUT/'job.json');t0=time.perf_counter();cog=shapes['cog'];cx,cy=cog.centroid.coords[0];c,s=math.cos(angle),math.sin(angle)
    centered=affine_transform(cog,[c,-s,s,c,-c*cx+s*cy,-s*cx-c*cy]);forbidden=gap.obstacle(centered,centered,.225);write(OUT/'obstacle.json',mapping(forbidden));patterns={};derivations=[];pairs=0;minimum=math.inf;expired=False
    for fi,fraction in enumerate(fractions):
        for n,cols in grids:
            if time.perf_counter()-t0>60:expired=True;break
            offsets=sorted({(d+sign*fraction)*pitch for d in range(-cols+1,cols) for sign in [-1,1]});extents=[]
            for x in offsets:
                cross=forbidden.intersection(LineString([(x,-1000),(x,1000)]))
                if not cross.is_empty:extents.append({'x':x,'ymin':cross.bounds[1],'ymax':cross.bounds[3]})
            dy=max(abs(v[k]) for v in extents for k in ['ymin','ymax'])+.0001;members=[]
            for i in range(n):
                row,col=divmod(i,cols);x=(col+(fraction if row%2 else 0))*pitch;y=row*dy;members.append(base.member('cog',base.transform(angle,x-c*cx+s*cy,y-s*cx-c*cy)))
            name=f'aligned-f{fi}-n{n}-c{cols}';p=base.pattern(name,members,shapes);geoms=[gap.pose(cog,m['transform']) for m in p['members']];bad=[];local=math.inf
            for i,j in itertools.combinations(range(n),2):
                pairs+=1;d=geoms[i].distance(geoms[j]);local=min(local,d);minimum=min(minimum,d)
                if not geoms[i].disjoint(geoms[j]) or d<job['clearance']:bad.append({'pair':[i,j],'distance':d,'overlap_area':geoms[i].intersection(geoms[j]).area})
            p['construction']={'fraction':fraction,'count':n,'columns':cols,'pitch_y_mm':dy,'minimum_distance_mm':local if math.isfinite(local) else None,'violations':bad};patterns[name]=p;derivations.append({'pattern':name,'offsets':offsets,'extents':extents})
        if expired:break
    pareto=[]
    for n in sorted({n for n,_ in grids}):
        choices=[p for p in patterns.values() if len(p['members'])==n and not p['construction']['violations']];seen=set()
        for p in sorted(choices,key=lambda p:p['id']):
            # Conservative dedup of bounding summaries only; exact original members retained.
            k=(round(p['width'],8),round(p['height'],8))
            if k in seen:continue
            seen.add(k)
            if not any(q['width']<=p['width']+1e-9 and q['height']<=p['height']+1e-9 and (q['width']<p['width']-1e-9 or q['height']<p['height']-1e-9) for q in choices):pareto.append(p['id'])
    write(OUT/'patterns.json',patterns);write(OUT/'derivations.json',derivations);write(OUT/'pareto.json',pareto)
    result={'seconds':time.perf_counter()-t0,'expired':expired,'components':len(patterns),'pair_checks':pairs,'valid_components':sum(not p['construction']['violations'] for p in patterns.values()),'minimum_distance_mm':minimum,'pareto':[{'pattern':n,'count':len(patterns[n]['members']),'width_mm':patterns[n]['width'],'height_mm':patterns[n]['height'],'area_mm2':patterns[n]['width']*patterns[n]['height']} for n in pareto],'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
