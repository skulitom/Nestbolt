from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/fill_h5_ragged_pockets.py').read_text(encoding='utf-8')
s=s.replace("SRC=ROOT/'output/h5-ragged-cogs-20261018'","SRC=ROOT/'output/h5-aligned-truncated-20261018'").replace("OUT=ROOT/'output/h5-ragged-pockets-20261018'","OUT=ROOT/'output/h5-aligned-pockets-20261018'")
s=s.replace('each of six selected ragged components','each of 28 contact-aligned truncated components').replace("'clearance_mm':.22","'clearance_mm':.225").replace('placer.clearance=.22','placer.clearance=.225').replace("['width']+.22","['width']+.225").replace("['height']+.22","['height']+.225")
with (ROOT/'output/fill_h5_aligned_pockets.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared 28 original component continuations, two family orders and four corners.')
