"""Finite frame-column sweep with aligned cogs and all bracket aspect multisets."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import copy,itertools,json,math,time,gzip,shutil,traceback
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;SRC=ROOT/'output/h5-pocket-aspect-rectangles-20261018';OUT=ROOT/'output/h5-five-row-shelves-20261018';load=base.load;write=base.write
def main():
    assert (SRC/'trace-audit.json').exists();OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');patterns=load(SRC/'patterns.json');job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');oldplan=load(SRC/'plan.json');g=oldplan['gap_mm'];width=oldplan['width_mm'];heights=oldplan['heights_mm'];recipes=load(SRC/'recipes.json');required=Counter({p['id']:p['quantity'] for p in job['parts']});unit=patterns['frame'];frames=[];seenframes=set()
    for rotations in itertools.product([False,True],repeat=5):
        dims=[(unit['height'],unit['width']) if r else (unit['width'],unit['height']) for r in rotations];capacities=[int((width+g)//(w+g)) for w,h in dims]
        if sum(capacities)<18 or sum(h+g for w,h in dims)-g>heights[0]:continue
        for method in ['left','right','balanced']:
            counts=[1]*5
            for _ in range(13):
                available=[i for i in range(5) if counts[i]<capacities[i]]
                if method=='left':i=available[0]
                elif method=='right':i=available[-1]
                else:i=min(available,key=lambda j:((counts[j]+1)*(dims[j][0]+g),j))
                counts[i]+=1
            key=(rotations,tuple(counts))
            if key in seenframes:continue
            seenframes.add(key);blocks=[];y=0
            for row,((w,h),qty,rot) in enumerate(zip(dims,counts,rotations)):
                for col in range(qty):blocks.append({'pattern':'frame','bin':0,'x':col*(w+g),'y':y,'rotated':rot,'rect':[col*(w+g),y,w+g,h+g]})
                y+=h+g
            free=[(0,0,width+g,heights[0]+g)]
            for block in blocks:free=base.subtract(free,block['rect'])
            frames.append({'rotations':rotations,'counts':counts,'method':method,'placed':blocks,'free':free})
    eligible=[];filtered=[]
    for ri,r in enumerate(recipes):
        p=patterns[r['component']];keep=[]
        for fi,frame in enumerate(frames):
            spaces=frame['free']+[(0,0,width+g,heights[1]+g)]
            fits=any(pw<=w+1e-8 and ph<=h+1e-8 for x,y,w,h in spaces for pw,ph in [(p['width']+g,p['height']+g),(p['height']+g,p['width']+g)])
            if fits:keep.append(fi)
            else:filtered.append([ri,fi])
        eligible.append(keep)
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'source_hashes':{str((SRC/n).relative_to(ROOT)):base.digest(SRC/n) for n in ['patterns.json','recipes.json','job.json','conditional-target.json','trace-audit.json']},'frame_allocations':len(frames),'inventory_recipes':len(recipes),'sorts':['area','long','short','filled'],'fits':['short','area','bottom'],'seconds_limit':120,'maximum_attempts':sum(len(x) for x in eligible)*12,'unfiltered_maximum_attempts':len(frames)*len(recipes)*12,'rectangle_prefix_rejections':len(filtered),'retained_distinct_partials':8,'gap_mm':g,'width_mm':width,'heights_mm':heights,'method':'Change frame topology from columns to five horizontal shelves, the minimum possible row count for eighteen whole frames at original stock width (at most four per row). Enumerate all 32 quarter-turn row choices; retain those with enough capacity and height, then use left, right and balanced original-count allocations and deduplicate exact row/rotation counts. All 5246 original pocket/aspect inventory recipes remain byte-identical. Skip a recipe/frame pair only when its mandatory pocket rectangle fits none of the exact free rectangles after fixed frames on either original target sheet, under either quarter turn. Record every such restricted-prefix rejection. Same four sort keys, three placement scores, 120-second total cap and eight retained distinct partials. Higher-row-count shelves, arbitrary frame translations and original-outline feasibility remain unproven.'};write(OUT/'plan.json',plan);write(OUT/'eligible-frames.json',eligible);write(OUT/'filtered-prefixes.json',filtered)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json','patterns.json']:shutil.copyfile(SRC/n,OUT/n)
    write(OUT/'frames.json',frames);write(OUT/'recipes.json',recipes);retained=[];seen=set();attempts=0;expired=False;complete=False;t0=time.perf_counter();maxcount=0
    with gzip.open(OUT/'attempts.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
        for ri,r in enumerate(recipes):
            for fi in eligible[ri]:
                frame=frames[fi]
                for sort,fit in itertools.product(plan['sorts'],plan['fits']):
                    if time.perf_counter()-t0>=120:expired=True;break
                    blocks,left=base.pack(r['items'],patterns,[frame['free'],[(0,0,width+g,heights[1]+g)]],sort,fit,g);blocks=frame['placed']+blocks;counts=Counter(m['part_id'] for b in blocks for m in patterns[b['pattern']]['members']);missing=required-counts;area=sum(patterns[b['pattern']]['area'] for b in blocks);attempts+=1;maxcount=max(maxcount,sum(counts.values()));row={'attempt':attempts,'recipe':ri,'frame':fi,'sort':sort,'fit':fit,'count':sum(counts.values()),'filled_area_mm2':area,'missing':dict(missing),'unplaced':left};log.write(json.dumps(row,separators=(',',':'))+'\n')
                    assert counts+Counter(m['part_id'] for n in left for m in patterns[n]['members'])==required
                    rank=(area,sum(counts.values()),-attempts)
                    if not left or len(retained)<8 or rank>retained[-1]['rank']:
                        key=json.dumps(blocks,sort_keys=True,separators=(',',':'))
                        if key not in seen:
                            seen.add(key);retained.append({'rank':rank,**row,'blocks':blocks});retained.sort(key=lambda r:r['rank'],reverse=True);retained=retained[:8]
                    if not left:complete=True;break
                if complete or expired:break
            if complete or expired:break
    for i,r in enumerate(retained):write(OUT/f'partial-{i}.json',base.layout_of(job,patterns,r['blocks']))
    write(OUT/'retained.json',retained);result={'seconds':time.perf_counter()-t0,'attempts':attempts,'maximum_attempts':plan['maximum_attempts'],'expired':expired,'complete':complete,'maximum_count':maxcount,'best_count':retained[0]['count'],'best_filled_area_mm2':retained[0]['filled_area_mm2'],'best_missing':retained[0]['missing'],'retained':len(retained),'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
