"""Read-only geometry novelty census for the next finite candidate-pool experiment."""
from pathlib import Path
from collections import Counter
import json
import audit_h5_cog_lattices as audit
import construct_h5_pattern_layouts as base
ROOT=audit.ROOT;OUT=ROOT/'output/h5-five-row-shelves-20261018';OLD=ROOT/'output/h5-contact-placement-selection-20261018';load=audit.load
def main():
    job=load(OUT/'job.json');parts={p['id']:p for p in job['parts']};prior=load(OLD/'candidates.json');roots=[ROOT/'output'/n for n in ['h5-aligned-aspect-backfill-20261018','h5-pocket-aspect-backfill-20261018','h5-five-row-backfill-20261018']]
    def sig(p):
        g=audit.shape(parts[p['part_id']],p['transform']);return (p['part_id'],p['sheet_id'],tuple(sorted((round(x,4),round(y,4)) for x,y in list(g.exterior.coords)[:-1])))
    old={sig(r['placement']) for r in prior};new={};records=[]
    for root in roots:
        before=len(new);events=0
        for row in load(root/'results.json')['cases']:
            path=root/f"partial-{row['partial']:02d}"/'layout.json'
            for p in load(path)['placements']:
                k=sig(p);events+=1
                if k not in old and k not in new:new[k]={'source':str(path.relative_to(ROOT)),'placement':p}
        records.append({'source':root.name,'placement_events':events,'new_signatures_not_seen_in_prior_pool_or_previous_sources':len(new)-before})
    patterns=load(OUT/'patterns.json');before=len(new)
    for fi,frame in enumerate(load(OUT/'frames.json')):
        for p in base.layout_of(job,patterns,frame['placed'])['placements']:
            k=sig(p)
            if k not in old and k not in new:new[k]={'source':f'frame-allocation-{fi}','placement':p}
    result={'prior_pool_entries':len(prior),'prior_quantized_geometry_signatures':len(old),'signature_coordinate_quantum_mm':.0001,'quantization_for_diagnostic_identity_only_original_coordinates_unchanged':True,'sources':records,'additional_frame_only_signatures':len(new)-before,'new_signatures_total':len(new),'new_by_family':dict(Counter(k[0] for k in new)),'new_graph_or_solve_performed':False,'scope':'Geometry novelty only. New transforms retain original coordinates; no feasibility, compatibility, native-margin or quality claim. The next construction must independently validate candidates and their entire conflict graph.'};audit.write(OUT/'pose-novelty.json',result);print(json.dumps(result))
if __name__=='__main__':main()
