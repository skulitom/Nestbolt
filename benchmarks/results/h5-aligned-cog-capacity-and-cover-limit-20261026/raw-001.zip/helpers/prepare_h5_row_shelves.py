from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/construct_h5_aligned_aspect_rectangles.py').read_text(encoding='utf-8')
s=s.replace("SRC=ROOT/'output/h5-aligned-aspect-cpsat-20261018';OUT=ROOT/'output/h5-aligned-aspect-rectangles-20261018'","SRC=ROOT/'output/h5-pocket-aspect-rectangles-20261018';OUT=ROOT/'output/h5-five-row-shelves-20261018'")
a=s.index('    assert (SRC/');b=s.index('    for n in [',a)
s=s[:a]+'''    assert (SRC/'trace-audit.json').exists();OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');patterns=load(SRC/'patterns.json');job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');oldplan=load(SRC/'plan.json');g=oldplan['gap_mm'];width=oldplan['width_mm'];heights=oldplan['heights_mm'];recipes=load(SRC/'recipes.json');required=Counter({p['id']:p['quantity'] for p in job['parts']});unit=patterns['frame'];frames=[];seenframes=set()
    for rotations in itertools.product([False,True],repeat=5):
        dims=[(unit['height'],unit['width']) if r else (unit['width'],unit['height']) for r in rotations];capacities=[int((width+g)//(w+g)) for w,h in dims]
        if sum(capacities)<18 or sum(h+g for w,h in dims)-g>heights[0]:continue
        for method in ['left','right','balanced']:
            counts=[1]*5
            for _ in range(13):
                available=[i for i in range(5) if counts[i]<capacities[i]]
                if method=='left':i=available[0]
                elif method=='right':i=available[-1]
                else:i=min(available,key=lambda j:((counts[j]+1)*(dims[j][0]+g),j))
                counts[i]+=1
            key=(rotations,tuple(counts))
            if key in seenframes:continue
            seenframes.add(key);blocks=[];y=0
            for row,((w,h),qty,rot) in enumerate(zip(dims,counts,rotations)):
                for col in range(qty):blocks.append({'pattern':'frame','bin':0,'x':col*(w+g),'y':y,'rotated':rot,'rect':[col*(w+g),y,w+g,h+g]})
                y+=h+g
            free=[(0,0,width+g,heights[0]+g)]
            for block in blocks:free=base.subtract(free,block['rect'])
            frames.append({'rotations':rotations,'counts':counts,'method':method,'placed':blocks,'free':free})
    eligible=[];filtered=[]
    for ri,r in enumerate(recipes):
        p=patterns[r['component']];keep=[]
        for fi,frame in enumerate(frames):
            spaces=frame['free']+[(0,0,width+g,heights[1]+g)]
            fits=any(pw<=w+1e-8 and ph<=h+1e-8 for x,y,w,h in spaces for pw,ph in [(p['width']+g,p['height']+g),(p['height']+g,p['width']+g)])
            if fits:keep.append(fi)
            else:filtered.append([ri,fi])
        eligible.append(keep)
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'source_hashes':{str((SRC/n).relative_to(ROOT)):base.digest(SRC/n) for n in ['patterns.json','recipes.json','job.json','conditional-target.json','trace-audit.json']},'frame_allocations':len(frames),'inventory_recipes':len(recipes),'sorts':['area','long','short','filled'],'fits':['short','area','bottom'],'seconds_limit':120,'maximum_attempts':sum(len(x) for x in eligible)*12,'unfiltered_maximum_attempts':len(frames)*len(recipes)*12,'rectangle_prefix_rejections':len(filtered),'retained_distinct_partials':8,'gap_mm':g,'width_mm':width,'heights_mm':heights,'method':'Change frame topology from columns to five horizontal shelves, the minimum possible row count for eighteen whole frames at original stock width (at most four per row). Enumerate all 32 quarter-turn row choices; retain those with enough capacity and height, then use left, right and balanced original-count allocations and deduplicate exact row/rotation counts. All 5246 original pocket/aspect inventory recipes remain byte-identical. Skip a recipe/frame pair only when its mandatory pocket rectangle fits none of the exact free rectangles after fixed frames on either original target sheet, under either quarter turn. Record every such restricted-prefix rejection. Same four sort keys, three placement scores, 120-second total cap and eight retained distinct partials. Higher-row-count shelves, arbitrary frame translations and original-outline feasibility remain unproven.'};write(OUT/'plan.json',plan);write(OUT/'eligible-frames.json',eligible);write(OUT/'filtered-prefixes.json',filtered)
'''+s[b:]
s=s.replace("for fi,frame in enumerate(frames):\n                for sort,fit", "for fi in eligible[ri]:\n                frame=frames[fi]\n                for sort,fit")
with (ROOT/'output/construct_h5_five_row_shelves.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared bounded five-row comparison with byte-identical pocket recipes.')
