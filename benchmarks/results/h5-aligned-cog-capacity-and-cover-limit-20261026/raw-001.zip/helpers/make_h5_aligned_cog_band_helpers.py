"""Generate fresh-angle band construction/audits with explicit new counts."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
paths=[('h5-second-strip-four-cogs-source-20261026','h5-aligned-cog-profiles-20261026'),('h5-second-strip-band-capacity-20261026','h5-aligned-cog-band-capacity-20261026'),('h5-second-strip-band-model-20261026','h5-aligned-cog-band-model-20261026')]
def make(src,dst,changes):
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in changes:assert old in s,(src,old);s=s.replace(old,new)
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
make('build_h5_second_strip_band_capacity.py','build_h5_aligned_cog_band_capacity.py',paths[:2]+[("'bracket':4,'insert':2,'cog':4","'bracket':4,'insert':1,'cog':4"),('h5-second-strip-four-cogs-probes-20261026/response-audit/checks.json','h5-shared-bracket-strip-probe-20261026/response-audit/checks.json'),('four original brackets, two inserts and four cogs','four original brackets, one insert and four cogs'),('cogs the current source angle','cogs the independently reconstructed56.25degree source angle')])
make('audit_h5_second_strip_band_capacity.py','audit_h5_aligned_cog_band_capacity.py',paths[:2]+[("'bracket':4,'insert':2,'cog':4","'bracket':4,'insert':1,'cog':4"),('42399','42525'),('673','675'),('ten mandatory originals','nine mandatory originals'),('The three closed prescribed-orientation source models are contained in this necessary family allocation.','Only the new56.25degree cog profile is included; old-angle source exclusions do not transfer.')])
make('prepare_h5_second_strip_band_model.py','prepare_h5_aligned_cog_band_model.py',paths[1:]+[('four brackets,two inserts,four cogs','four brackets,one insert,four cogs')])
make('audit_h5_second_strip_band_model.py','audit_h5_aligned_cog_band_model.py',paths[1:]+[('673','675'),("'bracket':4,'insert':2,'cog':4","'bracket':4,'insert':1,'cog':4"),("('insert',2)","('insert',1)")])
modelpaths=[('h5-nine-part-band-model-20261026','h5-aligned-cog-band-model-20261026'),('h5-nine-part-band-search-20261026','h5-aligned-cog-band-search-20261026')]
make('run_h5_nine_part_band_model.py','run_h5_aligned_cog_band_model.py',modelpaths+[('673-variable','675-variable'),('fixed-angle guarded-source geometry','new56.25degree guarded-source geometry')])
make('audit_h5_nine_part_band_response.py','audit_h5_aligned_cog_band_response.py',modelpaths+[('h5-second-strip-band-capacity-20261026','h5-aligned-cog-band-capacity-20261026'),("load(MODEL/'plan.json')['required_original_counts']","load(DATA/'plan.json')['required_original_counts']"),('len(s)==673','len(s)==675')])
