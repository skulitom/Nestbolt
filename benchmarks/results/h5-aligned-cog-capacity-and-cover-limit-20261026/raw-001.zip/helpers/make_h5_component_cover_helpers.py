"""Keep disjoint row components instead of filling gaps between cog teeth."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_aligned_rectangle_covers.py').read_text(encoding='utf-8').replace('h5-aligned-rectangle-covers-20261026','h5-aligned-component-covers-20261026')
old="""        b=g.bounds;x0=math.floor(b[0]*1000-1e-6);x1=math.ceil(b[2]*1000+1e-6);assert x0<x1 and y0<y1
        if rects and rects[-1][0]==x0 and rects[-1][2]==x1 and rects[-1][3]==y0:rects[-1][3]=y1
        else:rects.append([x0,y0,x1,y1])"""
new="""        pieces=list(g.geoms) if hasattr(g,'geoms') else [g];spans=[]
        while pieces:
            piece=pieces.pop()
            if hasattr(piece,'geoms'):pieces.extend(piece.geoms);continue
            if piece.is_empty:continue
            b=piece.bounds;x0=math.floor(b[0]*1000-1e-6);x1=math.ceil(b[2]*1000+1e-6);assert x0<x1 and y0<y1;spans.append([x0,x1])
        merged=[]
        for x0,x1 in sorted(spans):
            if merged and merged[-1][1]>=x0:merged[-1][1]=max(merged[-1][1],x1)
            else:merged.append([x0,x1])
        recent={(r[0],r[2]):i for i,r in enumerate(rects) if r[3]==y0}
        for x0,x1 in merged:
            if (x0,x1) in recent:rects[recent[x0,x1]][3]=y1
            else:rects.append([x0,y0,x1,y1])"""
assert old in s;s=s.replace(old,new).replace('Enclose each row intersection in outward-rounded integer x bounds; merge adjacent identical spans.','Enclose each connected component of a row intersection in outward-rounded integer x bounds; merge overlapping x spans and vertically adjacent identical spans. This preserves gaps between disconnected tooth tips instead of filling the entire row width.')
compile(s,'build_h5_aligned_component_covers.py','exec')
with (ROOT/'output/build_h5_aligned_component_covers.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_aligned_rectangle_covers.py').read_text(encoding='utf-8').replace('h5-aligned-rectangle-covers-20261026','h5-aligned-component-covers-20261026')
with (ROOT/'output/audit_h5_aligned_component_covers.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
