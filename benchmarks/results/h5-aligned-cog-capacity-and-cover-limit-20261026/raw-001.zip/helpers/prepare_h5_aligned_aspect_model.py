"""All original inventory, aligned cog groups, independently selectable bracket aspects."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,sys
import ortools
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-aligned-aspect-cpsat-20261018';SRC=ROOT/'output/h5-cog-lattices-20261018';ALIGNED=ROOT/'output/h5-aligned-stagger-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');old=load(SRC/'all-patterns.json');aligned=load(ALIGNED/'patterns.json');chosen=load(ALIGNED/'pareto.json');audit=load(ALIGNED/'audit.json');assert audit['original_pair_checks']==3080
    mixes=sorted(n for n,p in old.items() if Counter(m['part_id'] for m in p['members'])==Counter(bracket=2,insert=1));assert len(mixes)==3
    patterns={k:old[k] for k in ['frame','insert']+mixes};patterns.update({k:aligned[k] for k in chosen});write(OUT/'patterns.json',patterns)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    job=load(OUT/'job.json');target=load(OUT/'conditional-target.json');assert digest(OUT/'job.json')==digest(ALIGNED/'job.json');st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=.225;scale=1000
    width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4];W=math.floor((width+g)*scale);Hs=[math.floor((h+g)*scale) for h in heights];T=sum(Hs)
    recipes=[[15,0,0],[10,5,0],[9,6,0],[12,3,0],[5,5,5]]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'input_hashes':{str(p.relative_to(ROOT)):digest(p) for p in [SRC/'all-patterns.json',ALIGNED/'patterns.json',ALIGNED/'pareto.json',ALIGNED/'audit.json']+[OUT/n for n in ['job.json','library.json','request.json','original.json','conditional-target.json']]},'scale_per_mm':scale,'block_gap_mm':g,'width_mm':width,'height_limits_mm':heights,'recipes':recipes,'bracket_patterns':mixes,'aligned_patterns':chosen,'seconds_limit':120,'seed':0,'workers':8,'python':sys.version,'ortools':ortools.__version__,
          'method':'Eighteen freely positioned frame rectangles, six independent two-bracket/one-insert slots each choosing any of three retained aspect variants, fifteen inserts and three cog-group slots selected by one of five exact-15 decompositions. Each cog slot may choose any audited nondominated aligned square or staggered component with its required count. Every rectangle has both quarter-turn choices. Shared x/y/width/height variables avoid duplicated position variables per shape. Two stock strips are stacked vertically in the model; a sheet Boolean prevents every present interval from crossing the strip boundary. Optional zero-size cog slots are absent. One NoOverlap2D covers both strips. Tables bind exact outward-rounded dimensions and precomputed areas; total and per-strip rectangle-area bounds are necessary consequences. Only identical frame/bracket-slot/insert copies are ordered by y/x. No objective or hint. Original target, quantities and allowed original rotations unchanged.',
          'scope':'Finite offline construction. Failure or UNKNOWN is not unrestricted infeasibility; a feasible rectangle selection must pass original filled-outer geometry, frozen CLI and material target checks before it is a witness. Native qualification and full gate remain separate.'};write(OUT/'plan.json',plan)
    model=cp_model.CpModel();recipe=model.new_int_var(0,4,'recipe');metadata=[];xints=[];yints=[];allareas=[];sourceareas=[];keys=defaultdict(list)
    slots=[('frame',None)]*18+[('mix',None)]*6+[('insert',None)]*15+[('cog',i) for i in range(3)]
    for i,(family,slot) in enumerate(slots):
        if family=='frame':names=['frame']
        elif family=='mix':names=mixes
        elif family=='insert':names=['insert']
        else:names=[n for n in chosen if len(patterns[n]['members']) in {r[slot] for r in recipes}]
        choices=[]
        if family=='cog' and any(r[slot]==0 for r in recipes):choices.append({'pattern':None,'rotated':False,'w':0,'h':0,'area':0,'count':0})
        for n in names:
            p=patterns[n]
            for rot in [False,True]:
                w,h=(p['height'],p['width']) if rot else (p['width'],p['height']);wi=math.ceil((w+g)*scale);hi=math.ceil((h+g)*scale)
                if wi>W or hi>max(Hs):continue
                choices.append({'pattern':n,'rotated':rot,'w':wi,'h':hi,'area':wi*hi,'count':len(p['members']) if family=='cog' else None})
        for j,ch in enumerate(choices):ch['choice']=j
        spec={'item':i,'family':family,'slot':slot,'choices':choices};v={}
        def new(name,lo,hi):
            value=model.new_int_var(lo,hi,f'{name}-{i}');v[name]=value;return value
        kind=new('kind',0,len(choices)-1);x=new('x',0,W);y=new('y',0,T);w=new('w',min(ch['w'] for ch in choices),max(ch['w'] for ch in choices));h=new('h',min(ch['h'] for ch in choices),max(ch['h'] for ch in choices));xe=new('xe',0,W);ye=new('ye',0,T);area=new('area',min(ch['area'] for ch in choices),max(ch['area'] for ch in choices));sourcearea=new('sourcearea',0,max(ch['area'] for ch in choices));sheet=new('sheet',0,1);key=new('key',0,T*(W+1)+W)
        model.add_allowed_assignments([kind,w,h,area],[(ch['choice'],ch['w'],ch['h'],ch['area']) for ch in choices]);model.add(key==y*(W+1)+x)
        model.add(ye<=Hs[0]).only_enforce_if(sheet.Not());model.add(y>=Hs[0]).only_enforce_if(sheet);model.add(sourcearea==0).only_enforce_if(sheet.Not());model.add(sourcearea==area).only_enforce_if(sheet)
        present=None
        if family=='cog':
            model.add_allowed_assignments([recipe,kind],[(ri,ch['choice']) for ri,r in enumerate(recipes) for ch in choices if ch['count']==r[slot]])
            if any(ch['pattern'] is None for ch in choices):
                present=new('present',0,1);model.add(kind!=0).only_enforce_if(present);model.add(kind==0).only_enforce_if(present.Not())
                for value in [x,y,xe,ye,sheet]:model.add(value==0).only_enforce_if(present.Not())
        else:keys[family].append(key)
        if present is None:
            ix=model.new_interval_var(x,w,xe,f'ix-{i}');iy=model.new_interval_var(y,h,ye,f'iy-{i}')
        else:
            ix=model.new_optional_interval_var(x,w,xe,present,f'ix-{i}');iy=model.new_optional_interval_var(y,h,ye,present,f'iy-{i}')
        xints.append(ix);yints.append(iy);allareas.append(area);sourceareas.append(sourcearea);spec['vars']={k:val.index for k,val in v.items()};metadata.append(spec)
    for group in keys.values():
        for a,b in zip(group,group[1:]):model.add(a<=b)
    model.add_no_overlap_2d(xints,yints);model.add(sum(allareas)<=W*T);model.add(sum(sourceareas)<=W*Hs[1]);model.add(sum(allareas)-sum(sourceareas)<=W*Hs[0])
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',{'W':W,'Hs':Hs,'T':T,'recipe_var':recipe.index,'items':metadata})
    params=cp_model.CpSolver().parameters;params.max_time_in_seconds=120;params.num_search_workers=8;params.random_seed=0;params.log_search_progress=True;params.log_to_stdout=False;(OUT/'parameters.pbtxt').write_text(str(params),encoding='utf-8',newline='\n')
    print(json.dumps({'model_sha256':digest(OUT/'model.pbtxt'),'items':len(metadata),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'rectangle_intervals':len(xints),'choices':sum(len(m['choices']) for m in metadata)}))

if __name__=='__main__':main()
