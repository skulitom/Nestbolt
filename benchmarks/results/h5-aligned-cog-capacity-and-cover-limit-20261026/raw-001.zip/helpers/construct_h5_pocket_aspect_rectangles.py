"""Finite whole-inventory sweep of contact-aligned pocket components."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import itertools,json,math,time,gzip,shutil,traceback
from shapely.geometry import Polygon
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;POCKET=ROOT/'output/h5-aligned-pockets-20261018';OLD=ROOT/'output/h5-cog-lattices-20261018';ALIGNED=ROOT/'output/h5-aligned-stagger-20261018';OUT=ROOT/'output/h5-pocket-aspect-rectangles-20261018';load=base.load;write=base.write
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');job=load(POCKET/'job.json');target=load(POCKET/'conditional-target.json');parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};prior=load(OLD/'all-patterns.json');components=load(POCKET/'components.json');patterns={**{k:prior[k] for k in parts},**components};mixes=sorted(n for n,p in prior.items() if Counter(m['part_id'] for m in p['members'])==Counter(bracket=2,insert=1));patterns.update({n:prior[n] for n in mixes});alignedplan=load(ALIGNED/'plan.json');angle=alignedplan['angle_radians'];pitch=alignedplan['pitch_x_mm'];c,s=math.cos(angle),math.sin(angle);cx,cy=shapes['cog'].centroid.coords[0];small={};prefixpairs=0
    for n in range(1,7):
        small[n]=[]
        for cols in sorted({min(n,3),min(n,5)}):
            members=[]
            for i in range(n):
                row,col=divmod(i,cols);members.append(base.member('cog',base.transform(angle,col*pitch-c*cx+s*cy,row*pitch-s*cx-c*cy)))
            name=f'prefix-n{n}-c{cols}';p=base.pattern(name,members,shapes);patterns[name]=p;small[n].append(name);gs=[base.gap.pose(shapes['cog'],m['transform']) for m in p['members']]
            for a,b in itertools.combinations(gs,2):prefixpairs+=1;assert a.disjoint(b) and a.distance(b)>=job['clearance']
    st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=.225;width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4];frames=base.frame_configs(patterns['frame'],18,width,heights[0],g);required=Counter({p['id']:p['quantity'] for p in job['parts']});picked={};duplicates=[]
    for case in sorted(load(POCKET/'result.json')['cases'],key=lambda c:c['id']):
        p=components[case['id']];key=(p['width'],p['height'],tuple(sorted(case['inventory'].items())))
        if key in picked:duplicates.append({'case':case['id'],'same_rectangle_and_inventory_as':picked[key]['id']})
        else:picked[key]=case
    recipes=[]
    for case in picked.values():
        p=components[case['id']];remaining=required-Counter(m['part_id'] for m in p['members']);nc=remaining['cog'];cogoptions=[['cog']*nc]+([[n] for n in small[nc]] if nc else []);nm=min(remaining['bracket']//2,remaining['insert'])
        for cogseq,a,b in itertools.product(cogoptions,range(nm+1),range(nm+1)):
            if a+b>nm:continue
            counts=[a,b,nm-a-b];items=[case['id']]+list(cogseq)+[n for n,qty in zip(mixes,counts) for _ in range(qty)]+['insert']*(remaining['insert']-nm)+['bracket']*(remaining['bracket']-2*nm)
            assert Counter(m['part_id'] for n in items+['frame']*18 for m in patterns[n]['members'])==required
            recipes.append({'component':case['id'],'cogs':list(cogseq),'mix_counts':counts,'items':items})
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'inputs':{str(p.relative_to(ROOT)):base.digest(p) for p in [POCKET/'plan.json',POCKET/'components.json',POCKET/'result.json',POCKET/'audit/checks.json',OLD/'all-patterns.json',ALIGNED/'plan.json']},'gap_mm':g,'width_mm':width,'heights_mm':heights,'frame_allocations':len(frames),'pocket_components':len(components),'distinct_rectangle_inventory_components':len(picked),'rectangle_equivalent_cases_omitted':len(duplicates),'inventory_recipes':len(recipes),'prefix_component_pair_checks':prefixpairs,'sorts':['area','long','short','filled'],'fits':['short','area','bottom'],'seconds_limit':120,'maximum_attempts':len(frames)*len(recipes)*12,'retained_distinct_partials':8,'method':'Finite whole-original-inventory rectangle construction with the audited mixed cog/pocket components. Cases with exact equal bounding dimensions and member counts are equivalent only for this rectangle search; retain the lexicographically first and record omitted original cases. Remaining cogs may be original singles or verified contact-aligned square prefixes with up to three or five columns. Every multiset of remaining bracket pairs across all three aspect variants is included. Original source sheet target and fixed frame allocations stay unchanged. Stop at the first complete inventory or predeclared total cap; retain eight distinct greatest-filled-area partials. Actual outlines of retained layouts still require separate validation; no infeasibility claim.'};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(POCKET/n,OUT/n)
    write(OUT/'patterns.json',patterns);write(OUT/'frames.json',frames);write(OUT/'recipes.json',recipes);write(OUT/'omitted-equivalents.json',duplicates);retained=[];seen=set();attempts=0;expired=False;complete=False;maxcount=0;t0=time.perf_counter()
    with gzip.open(OUT/'attempts.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
        for ri,r in enumerate(recipes):
            for fi,frame in enumerate(frames):
                for sort,fit in itertools.product(plan['sorts'],plan['fits']):
                    if time.perf_counter()-t0>=120:expired=True;break
                    blocks,left=base.pack(r['items'],patterns,[frame['free'],[(0,0,width+g,heights[1]+g)]],sort,fit,g);blocks=frame['placed']+blocks;counts=Counter(m['part_id'] for b in blocks for m in patterns[b['pattern']]['members']);missing=required-counts;area=sum(patterns[b['pattern']]['area'] for b in blocks);attempts+=1;maxcount=max(maxcount,sum(counts.values()));row={'attempt':attempts,'recipe':ri,'frame':fi,'sort':sort,'fit':fit,'count':sum(counts.values()),'filled_area_mm2':area,'missing':dict(missing),'unplaced':left};log.write(json.dumps(row,separators=(',',':'))+'\n');assert counts+Counter(m['part_id'] for n in left for m in patterns[n]['members'])==required;rank=(area,sum(counts.values()),-attempts)
                    if not left or len(retained)<8 or rank>retained[-1]['rank']:
                        key=json.dumps(blocks,sort_keys=True,separators=(',',':'))
                        if key not in seen:seen.add(key);retained.append({'rank':rank,**row,'blocks':blocks});retained.sort(key=lambda r:r['rank'],reverse=True);retained=retained[:8]
                    if not left:complete=True;break
                if complete or expired:break
            if complete or expired:break
    for i,r in enumerate(retained):write(OUT/f'partial-{i}.json',base.layout_of(job,patterns,r['blocks']))
    write(OUT/'retained.json',retained);result={'seconds':time.perf_counter()-t0,'attempts':attempts,'maximum_attempts':plan['maximum_attempts'],'expired':expired,'complete':complete,'maximum_count':maxcount,'best_count':retained[0]['count'],'best_filled_area_mm2':retained[0]['filled_area_mm2'],'best_missing':retained[0]['missing'],'retained':len(retained),'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
