"""Verify covers via independent original-triangle square sums and exact rectangle arithmetic."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
from fractions import Fraction as F
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-aligned-component-covers-20261026';SOURCE=ROOT/'output/h5-aligned-cog-profiles-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently form each guarded original polygon from the union of unmerged triangle plus square vertex hulls. Verify original coverage and boundary separation above half the native pair guard. Check rectangle integer dimensions, exact pairwise disjoint interiors within each profile, whole guarded-shape coverage, and original stock anchor bounds. Quantities, all66 IDs and approved profile choices remain. Positive cover packing implies original clearance because each cover contains a dilation by more than half the required pair gap. No solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
spec=load(BASE/'plan.json');assert load(SOURCE/'audit/checks.json')['passed'];ps=load(SOURCE/'profiles.json');stock=[F(*v) for v in spec['stock_bounds_rational']];pad=spec['guard_square_halfside_mm'];assert pad==.1063;gap=(.2+3000*32*2**-23)/math.cos(.05);details=[];pairs=hulls=0
for p in ps:
    row=load(BASE/'profiles'/f"{p['index']:03d}.json");assert row['profile']==p['index'] and row['family']==p['family'];raw=shape(p['geometry']);tris=list(shapely.constrained_delaunay_triangles(raw).geoms);assert unary_union(tris).symmetric_difference(raw).area<1e-8
    squares=[(-pad,-pad),(-pad,pad),(pad,-pad),(pad,pad)];parts=[]
    for t in tris:parts.append(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(list(t.exterior.coords)[:-1],squares)]).convex_hull);hulls+=1
    independent=unary_union(parts);saved=shape(row['guarded']);assert independent.hausdorff_distance(saved)<1e-7 and saved.covers(raw) and saved.boundary.distance(raw)>gap/2;rects=row['rectangles_units1000']
    for r in rects:assert len(r)==4 and all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3]
    for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    cover=unary_union([box(*(v/1000 for v in r)) for r in rects]);assert cover.covers(saved) and cover.boundary.distance(raw)>gap/2 and abs(cover.area-sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)/1e6)<1e-6
    b=p['bounds'];margin=F(.0125)+F(.000001);expect=[math.ceil((stock[0]+margin-F(b[0]))*1000),math.ceil((stock[1]+margin-F(b[1]))*1000),math.floor((stock[2]-margin-F(b[2]))*1000),math.floor((stock[3]-margin-F(b[3]))*1000)];assert expect==row['anchor_bounds_units1000'];details.append({'profile':p['index'],'rectangles':len(rects),'guard_gap_mm':saved.boundary.distance(raw),'cover_gap_mm':cover.boundary.distance(raw),'passed':True})
assert sorted(spec['first_sheet_checked_originals']+spec['mandatory_originals']+spec['pending_first_sheet_originals'])==list(range(66));assert spec['allowed_profiles']==[list(range(8)) for _ in range(4)]+[[8,10]]+[[9] for _ in range(4)]
write(OUT/'profile-checks.json',details);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_profiles':11,'triangle_square_hulls':hulls,'exact_internal_rectangle_pairs_checked':pairs,'whole_guarded_coverage_verified':True,'required_native_pair_gap_mm':gap,'minimum_doubled_cover_boundary_gap_mm':2*min(d['cover_gap_mm'] for d in details),'all66_identity_obligations_preserved':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
