"""Fresh full-original collision geometry for the aligned-cog nine-part sheet."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import product,combinations
import json,math,shutil,time
from shapely.geometry import Polygon,MultiPoint,shape,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';PROFILES=ROOT/'output/h5-aligned-cog-profiles-20261026';BAND=ROOT/'output/h5-aligned-cog-band-search-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=ROOT/'output/h5-aligned-nine-strip-source-20261026';EPS=.000001
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'mutual').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
assert load(PROFILES/'audit/checks.json')['passed'] and load(BAND/'audit/checks.json')['passed'];profiles=load(PROFILES/'profiles.json');spec=load(PROFILES/'plan.json');items=load(SRC/'items.json');ids=spec['mandatory_second_sheet_originals'];assert ids==[21,22,25,26,37,53,63,64,65];pattern=[4,5,5,6,10,9,9,9,9];allocated=sorted(r['profile'] for r in load(BAND/'allocation.json') for _ in range(r['count']));assert allocated==sorted(pattern);used=sorted(set(pattern));pairs=sorted({(pattern[a],pattern[b]) for a,b in combinations(range(9),2)})
old={(c['profile_a'],c['profile_b']):c for c in load(PARENT/'plan.json')['mutual_cases'] if c['profile_a']!=9 and c['profile_b']!=9};cases=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(pairs)];stock=spec['stock_bounds_rational'];st=[F(*v) for v in stock];pad=F(.0125)+F(EPS);bounds={}
for pi in used:
    b=profiles[pi]['bounds'];bounds[pi]=[math.ceil((st[0]+pad-F(b[0]))*1000),math.ceil((st[1]+pad-F(b[1]))*1000),math.floor((st[2]-pad-F(b[2]))*1000),math.floor((st[3]-pad-F(b[3]))*1000)]
paths=[PROFILES/'profiles.json',PROFILES/'plan.json',PROFILES/'audit/checks.json',BAND/'allocation.json',BAND/'audit/checks.json',PARENT/'plan.json',PARENT/'profiles.json',PARENT/'audit/checks.json',SRC/'items.json',SRC/'geometry.json']+[PARENT/'mutual'/f"{old[p]['index']:03d}.json" for p in pairs if p in old]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'parts':[{'part':i,'item':n,'family':items[n]['family'],'copy':items[n]['copy']} for i,n in enumerate(ids)],'orientation_patterns':[pattern],'used_profiles':used,'anchor_bounds_units1000':bounds,'stock_bounds_rational':stock,'mutual_cases':cases,'first_sheet_checked_originals':spec['first_sheet_checked_originals'],'pending_first_sheet_originals':[28,29],'construction_limit_seconds':240,'construction_clearance_mm':.2125,'clearance_envelope_extra_mm':.0001,'face_square_padding_mm':EPS,'extra_stock_margin_mm':.0125,'maximum_calls':1,'per_pattern_solver_seconds':45,'shared_solver_seconds':60,'solver_workers':4,'solver_seed':0,'method':'New9-original coordinate construction at the independently reconstructed56.25degree cog angle. Profiles4/5/5/6/10/9/9/9/9 come from the audited necessary allocation; all18 coordinates remain free throughout full guarded target stock, with no band-cell locks or hints. Rebuild every collision case involving the new cog angle and the horizontal insert; reuse only unchanged bracket/bracket cases verified from original geometry. All36 pair clauses retained. One45second4worker seed0 call within60shared seconds after geometry/model audits. A source positive still requires full original geometry, first-sheet28/29 placement, all66 native/material checks, production budget and H5 matrix.'});write(OUT/'profiles.json',profiles);summary=[]
for c in cases:
    assert time.perf_counter()<deadline;key=(c['profile_a'],c['profile_b'])
    if key in old:
        p=PARENT/'mutual'/f"{old[key]['index']:03d}.json";r=load(p);r['reused_source_case']=r['case'];r['case']=c;r['reused_source_sha256']=digest(p);summary.append({**c,'reused':True,'faces':len(r['faces'])})
    else:
        a,b=[shape(profiles[k]['geometry']) for k in key];raw=raw_obstacle(a,b);guarded=expand(raw,.2125,.0001);faces,merge=convex_faces(guarded,deadline);records=[];expanded=[]
        for i,f in enumerate(faces):
            poly=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(list(f.exterior.coords)[:-1],[(-EPS,-EPS),(-EPS,EPS),(EPS,EPS),(EPS,-EPS)])]).convex_hull,sign=1);assert poly.covers(f);expanded.append(poly);records.append({'index':i,'raw_face':mapping(f),'expanded_face':mapping(poly),'outside_halfplanes':inequalities(poly,False)})
        assert unary_union(expanded).covers(guarded);r={'case':c,'raw_forbidden':mapping(raw),'expanded_forbidden':mapping(guarded),'merge':merge,'faces':records,'complete_forbidden_covered':True};summary.append({**c,'reused':False,'faces':len(records),**merge})
    assert r['complete_forbidden_covered'];write(OUT/'mutual'/f"{c['index']:03d}.json",r)
write(OUT/'case-summary.json',summary);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'patterns':1,'mandatory_sheet_originals':9,'pair_cases':len(cases),'cases_reused':sum(r['reused'] for r in summary),'cases_new':sum(not r['reused'] for r in summary),'full_guarded_faces':sum(r['faces'] for r in summary),'physical_pairs':36,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
