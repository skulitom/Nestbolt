"""Exact per-original projection profiles of the verified disjoint source strips."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-source-strips-20261026'
OUT=ROOT/'output/h5-strip-capacity-profiles-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'source-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[BASE/'rectangles.json',BASE/'source-audit/checks.json',BASE/'capacity-audit/checks.json',
        ROOT/'output/h5-global-source-cells-20261026/domains.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0,
    'method':'For each mandatory original and each axis, sweep every integer endpoint of its verified disjoint source rectangles. Sum occupied lengths on the perpendicular axis, merge adjacent slabs with exactly equal demand, and retain positive profile intervals. These profiles reproduce both781-rectangle cumulative constraints exactly for every possible whole-part translation. They do not reproduce NoOverlap2D or replace full-source validation. A new staged solver may use these exact profiles with the old65-rectangle non-overlap and no initial source-pair disjunctions, adding source cuts only for actual new violations.'})
rs=load(BASE/'rectangles.json');profiles=[]
for axis,field,capacity in [(0,'height_um',2987000),(1,'width_um',1487000)]:
    by_part=[]
    for part in range(57):
        rects=[r for r in rs if r['part_index']==part];assert rects
        events={}
        for r in rects:
            lo,hi=r['bounds_um'][axis],r['bounds_um'][axis+2]
            events[lo]=events.get(lo,0)+r[field];events[hi]=events.get(hi,0)-r[field]
        points=sorted(events);active=0;segments=[]
        for lo,hi in zip(points,points[1:]):
            active+=events[lo]
            if active==0:continue
            assert active>0
            if segments and segments[-1]['end_um']==lo and segments[-1]['demand_um']==active:
                segments[-1]['end_um']=hi
            else:segments.append({'start_um':lo,'end_um':hi,'demand_um':active})
        active+=events[points[-1]];assert active==0
        by_part.append({'part_index':part,'original':rects[0]['original'],'family':rects[0]['family'],
                        'mode':rects[0]['mode'],'intervals':segments})
    profiles.append({'axis':axis,'capacity_um':capacity,'parts':by_part})
write(OUT/'profiles.json',profiles)
counts=[sum(len(p['intervals']) for p in axis['parts']) for axis in profiles]
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_rectangles':len(rs),
    'all57_originals_each_axis':True,'profile_intervals_by_axis':counts,'total_profile_intervals':sum(counts),
    'unaggregated_projection_intervals':2*len(rs),'exact_integer_projection_aggregation':True,
    'no_full_source_fit_claimed':True,'solver_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
