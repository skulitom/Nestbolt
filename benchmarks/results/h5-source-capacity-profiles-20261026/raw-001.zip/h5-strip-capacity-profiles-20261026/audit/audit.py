"""Independently check every slab by direct source-rectangle summation, not a sweep."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-profiles-20261026'
SOURCE=ROOT/'output/h5-cog-source-strips-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
rects=load(SOURCE/'rectangles.json');profiles=load(BASE/'profiles.json');ds=load(ROOT/'output/h5-global-source-cells-20261026/domains.json')
assert len(profiles)==2;slabs=intervals=0;areas=[]
for axis,profile in enumerate(profiles):
    assert profile['axis']==axis and profile['capacity_um']==[2987000,1487000][axis]
    assert [p['part_index'] for p in profile['parts']]==list(range(57))
    for p in profile['parts']:
        part=p['part_index'];d=ds[part]
        assert all(p[n]==d[n] for n in ['original','family','mode'])
        rs=[r for r in rects if r['part_index']==part];segments=p['intervals'];intervals+=len(segments)
        points=sorted({v for r in rs for v in [r['bounds_um'][axis],r['bounds_um'][axis+2]]} |
                      {v for s in segments for v in [s['start_um'],s['end_um']]})
        for s in segments:assert all(type(v) is int for v in s.values()) and s['start_um']<s['end_um'] and s['demand_um']>0
        for a,b in zip(segments,segments[1:]):
            assert a['end_um']<=b['start_um']
            assert a['end_um']!=b['start_um'] or a['demand_um']!=b['demand_um']
        for a,b in zip(points,points[1:]):
            mid2=a+b
            wanted=sum(r[['height_um','width_um'][axis]] for r in rs if 2*r['bounds_um'][axis]<=mid2<2*r['bounds_um'][axis+2])
            actual=sum(s['demand_um'] for s in segments if 2*s['start_um']<=mid2<2*s['end_um'])
            assert wanted==actual;slabs+=1
        area=sum((s['end_um']-s['start_um'])*s['demand_um'] for s in segments)
        assert area==sum(r['width_um']*r['height_um'] for r in rs);areas.append(area)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_rectangles':len(rects),
    'original_axis_profiles_verified':114,'profile_intervals_verified':intervals,
    'integer_event_slabs_verified':slabs,'integrated_source_areas_verified':len(areas),
    'arbitrary_whole_part_translations_preserve_profile_equivalence':True,
    'both_full_781_rectangle_cumulative_constraints_reproduced_exactly':True,
    'full_source_readback_still_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
