"""Declare one different staged capacity search and check the initial model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_profile_source_model import build
from h5_profile_source_model_audit import verify
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-global-source-cells-20261026'
OUT=ROOT/'output/h5-profile-source-cuts-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(ROOT/'output/h5-strip-capacity-profiles-20261026/audit/checks.json')['passed']
assert load(ROOT/'output/h5-cog-strip-model-20261026/response-audit/checks.json')['closed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=load(ROOT/'output/h5-lazy-source-cuts-20261026/plan.json')['inputs'].copy()
for n in ['h5_profile_source_model.py','h5_profile_source_model_audit.py',
          'h5-cog-source-strips-20261026/rectangles.json','h5-cog-source-strips-20261026/source-audit/checks.json',
          'h5-strip-capacity-profiles-20261026/profiles.json','h5-strip-capacity-profiles-20261026/audit/checks.json',
          'h5-constructed-necessary-source-seed-20261026/anchors-um.json',
          'h5-cog-strip-model-20261026/response-audit/checks.json']:
    p=ROOT/'output'/n;inputs[p.relative_to(ROOT).as_posix()]=digest(p)
for n,h in inputs.items():assert digest(ROOT/n)==h,n
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,
    'total_search_seconds':60,'shared_seconds':90,'maximum_rounds':4,'first_solve_cap_seconds':30,
    'later_solve_cap_seconds':8,'mandatory_first_originals':57,'fixed_short_originals':9,
    'initial_source_pair_cuts':0,'profile_intervals':1218,'objective':None,'non_cog_hints':90,
    'ignored_subsolvers':['fj'],'random_restarts':0,'stop_on_unknown_or_infeasible':True,
    'repeat_unchanged_model':False,
    'method':'Different staged model:114 full-stock coordinates, the old65-source-rectangle non-overlap and both old cumulative constraints,47 copy orders, and two exact781/437 interval source-strip capacity constraints. The expensive additional781-rectangle global non-overlap and all initial source-cell selectors are absent. Keep90 non-cog hints without fixing any original. The initial model has1400 constraints. Ignore the fj worker that overran the previous closed call. One pipeline permits at most4 rounds within60 algorithm/90 shared seconds; first solve30 seconds, later8, each also limited by remaining algorithm time. Reconstruct all66 original rings after each candidate; add all newly failing source-pair disjunctions. Stop UNKNOWN/INFEASIBLE, stock/short failures, inconsistent/no new cuts, round/deadline. Never repeat an unchanged model. No necessary assignment qualifies as a full source/native/material witness.'})
ds=load(GEO/'domains.json');pairs=load(GEO/'pairs.json');rects=load(GEO/'inner-rectangles/rectangles.json');groups=load(GEO/'inner-rectangles/identical-source-groups.json')
model,mapping=build(ds,pairs,rects,groups,[])
assert model.export_to_file(str(OUT/'initial-model.pb')) and model.export_to_file(str(OUT/'initial-model.pbtxt'))
write(OUT/'initial-mapping.json',mapping);raw=cp_model_pb2.CpModelProto();raw.ParseFromString((OUT/'initial-model.pb').read_bytes())
check=verify(raw,ds,pairs,rects,groups,[],mapping);assert check['variables_verified']==114 and check['constraints_verified']==1400
write(OUT/'checks.json',{**check,'seconds':time.perf_counter()-start,'initial_model_sha256':digest(OUT/'initial-model.pb'),'solver_calls':0,'all66_required':True,'H5_complete':False})
print(load(OUT/'checks.json'))
