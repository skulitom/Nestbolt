"""Bounded constraint generation; every candidate contains all original parts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-profile-source-cuts-20261026';GEO=ROOT/'output/h5-global-source-cells-20261026';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    started=time.perf_counter();deadline=started+60
    from h5_legacy64_source_readback import audit
    for n,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    ds=load(GEO/'domains.json');pairs=load(GEO/'pairs.json');modes=load(ROOT/'output/h5-legacy57-sliding-source-20261026/modes.json');short=load(GEO/'fixed-short-placements.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];lookup={(d['family'],d['copy_index']):i for i,d in enumerate(ds)};pair_indices={(p['left'],p['right']):k for k,p in enumerate(pairs)};assert sorted(list(lookup)+[(p['part_id'],p['copy_index']) for p in short])==sorted(expected);guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]};active=set();rounds=[];status='ROUND_LIMIT';source_valid=False
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'algorithm_seconds':60,'shared_seconds':90,'maximum_rounds':4,'first_solve_cap_seconds':30,'later_solve_cap_seconds':8,'all57_first_originals_required':True,'fixed_short_originals':9,'all66_identities_accounted':True})
    for index in range(4):
        remaining=deadline-time.perf_counter()
        if remaining<=.5:status='ALGORITHM_TIME_LIMIT';break
        folder=OUT/f'round-{index:02d}';folder.mkdir();write(folder/'request.json',{'round':index,'pair_indices':sorted(active),'solver_cap_seconds':30 if index==0 else 8,'deadline_perf_counter':deadline,'changed_model_required':index>0});before=time.perf_counter()
        try:
            p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(ROOT/'output/h5_profile_source_round.py'),str(folder)],cwd=ROOT,capture_output=True,timeout=max(.1,deadline-time.perf_counter()));(folder/'stdout.txt').write_bytes(p.stdout);(folder/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-before,'exit_code':p.returncode,'timeout':False}
        except subprocess.TimeoutExpired as e:(folder/'stdout.txt').write_bytes(e.stdout or b'');(folder/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-before,'timeout':True}
        write(folder/'process.json',process)
        if process['timeout'] or process.get('exit_code')!=0 or not (folder/'result.json').exists():status='ROUND_PROCESS_STOP';rounds.append({'round':index,'source_pair_cuts':len(active),'process':process,'no_completed_response':True});break
        result=load(folder/'result.json');record={'round':index,**result,'process_seconds':process['seconds']};rounds.append(record)
        if not result['has_solution']:status=result['status'];break
        anchors=load(folder/'anchors-um.json');rows=[]
        for d,xy in zip(ds,anchors):
            m=modes[d['mode']];rows.append({'part_id':d['family'],'copy_index':d['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]/1000+m['source_translation_offset'][k] for k in range(2)]}})
        rows+=short;source=audit(job,rows,stocks,required,guard,expected);write(folder/'all66-candidate.json',rows);write(folder/'source-readback.json',source);record.update({'source_valid':source['valid'],'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures']})
        if source['valid']:status='SOURCE_VALID_CANDIDATE';source_valid=True;write(folder/'cuts-added.json',[]);break
        if source['stock_failures']:status='SOURCE_STOCK_FAILURE';write(folder/'cuts-added.json',[]);break
        failures=[r for r in source['pairs'] if not r['passed']];new=set();already=[];short_failures=[]
        for fail in failures:
            a,b=map(tuple,fail['keys'])
            if a not in lookup or b not in lookup:short_failures.append(fail);continue
            pair=tuple(sorted([lookup[a],lookup[b]]));cut=pair_indices[pair]
            if cut in active:already.append(cut)
            else:new.add(cut)
        if already or short_failures:status='SOURCE_CUT_INCONSISTENCY';write(folder/'cut-inconsistency.json',{'already_constrained':already,'short_failures':short_failures});write(folder/'cuts-added.json',[]);break
        write(folder/'cuts-added.json',sorted(new));record['new_source_pair_cuts']=len(new)
        if not new:status='NO_NEW_CUT';break
        active.update(new);print({'round':index,'status':result['status'],'source_pair_failures':source['pair_failures'],'new_cuts':len(new),'seconds':time.perf_counter()-started},flush=True)
    write(OUT/'result.json',{'status':status,'closed':True,'algorithm_seconds':time.perf_counter()-started,'algorithm_soft_overrun_seconds':max(0.,time.perf_counter()-deadline),'rounds':rounds,'rounds_attempted':len(rounds),'solver_calls':sum(r.get('solver_calls',0) for r in rounds),'source_pair_cuts_accumulated':len(active),'full_source_valid_candidate':source_valid,'all66_required_each':True,'unchanged_model_retries':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()};inputs.update(load(BASE/'plan.json')['inputs'])
    for p in [ROOT/'output/h5_profile_source_round.py',ROOT/'output/run_h5_profile_source_search.py']:inputs[p.relative_to(ROOT).as_posix()]=digest(p)
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'algorithm_seconds':60,'shared_seconds':90,'maximum_rounds':4,'maximum_pipeline_calls':1,'retry_permitted':False});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:(OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed response; pipeline remains closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
