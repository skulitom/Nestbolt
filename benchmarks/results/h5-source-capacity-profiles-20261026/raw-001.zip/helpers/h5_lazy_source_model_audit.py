"""Independent serialized-constraint reader; does not call the model builder."""
def verify(proto,domains,pairs,rectangles,groups,pair_indices,mapping):
    assert len(domains)==57 and len(rectangles)==65 and not proto.HasField('objective') and not proto.HasField('floating_point_objective') and not proto.solution_hint.vars
    vi=ci=0;halfplanes=0
    for d,xy in zip(domains,mapping['coordinate_indices']):
        assert xy==[vi,vi+1]
        for k,axis in enumerate(['x','y']):v=proto.variables[vi];assert v.name==f'{axis}_{d["original"]}' and list(v.domain)==[d['lower_um'][k],d['upper_um'][k]];vi+=1
    assert [r['pair_index'] for r in mapping['pairs']]==pair_indices
    for pair_index,record in zip(pair_indices,mapping['pairs']):
        p=pairs[pair_index];i,j=p['left'],p['right'];selectors=list(range(vi,vi+len(p['cells'])));assert record['selector_indices']==selectors
        for c in range(len(p['cells'])):v=proto.variables[vi];assert v.name==f'pair_{i}_{j}_cell_{c}' and list(v.domain)==[0,1];vi+=1
        ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal and list(ct.exactly_one.literals)==selectors;ci+=1
        for cell,z,indices in zip(p['cells'],selectors,record['cell_constraint_indices']):
            assert indices==list(range(ci,ci+len(cell['faces'])))
            for nx,ny,rhs in cell['faces']:
                ct=proto.constraints[ci];xi,yi=mapping['coordinate_indices'][i];xj,yj=mapping['coordinate_indices'][j];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==[z] and dict(zip(ct.linear.vars,ct.linear.coeffs))=={k:v for k,v in [(xi,-nx),(yi,-ny),(xj,nx),(yj,ny)] if v} and list(ct.linear.domain)==[rhs,9223372036854775807];ci+=1;halfplanes+=1
    assert vi==len(proto.variables);xints=[];yints=[]
    def expr(e,var,offset):assert dict(zip(e.vars,e.coeffs))==({var:1} if var is not None else {}) and e.offset==offset
    for k,(r,record) in enumerate(zip(rectangles,mapping['rectangles'])):
        assert record['rectangle_index']==k and record['interval_indices']==[ci,ci+1];i=r['part_index'];b=r['bounds_um']
        for axis,length in [(0,r['width_um']),(1,r['height_um'])]:
            ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and not ct.enforcement_literal;expr(ct.interval.start,mapping['coordinate_indices'][i][axis],b[axis]);expr(ct.interval.size,None,length);expr(ct.interval.end,mapping['coordinate_indices'][i][axis],b[axis]+length);(xints if axis==0 else yints).append(ci);ci+=1
    assert len(xints)==len(yints)==65 and mapping['no_overlap_2d_constraint']==ci;ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='no_overlap_2d' and not ct.enforcement_literal and list(ct.no_overlap_2d.x_intervals)==xints and list(ct.no_overlap_2d.y_intervals)==yints;ci+=1
    assert mapping['cumulative_constraint_indices']==[ci,ci+1]
    for intervals,field,capacity in [(xints,'height_um',2987000),(yints,'width_um',1487000)]:
        ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal and list(ct.cumulative.intervals)==intervals;expr(ct.cumulative.capacity,None,capacity);assert len(ct.cumulative.demands)==65
        for d,r in zip(ct.cumulative.demands,rectangles):expr(d,None,r[field])
        ci+=1
    expected=[(a,b) for g in groups for a,b in zip(g['part_indices'],g['part_indices'][1:])];assert len(expected)==len(mapping['symmetry'])==47
    for (i,j),r in zip(expected,mapping['symmetry']):
        assert r['parts']==[i,j] and r['constraint_index']==ci;ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='linear' and not ct.enforcement_literal and dict(zip(ct.linear.vars,ct.linear.coeffs))=={mapping['coordinate_indices'][i][1]:1,mapping['coordinate_indices'][j][1]:-1} and list(ct.linear.domain)==[-9223372036854775808,0];ci+=1
    assert ci==len(proto.constraints)
    return {'passed':True,'variables_verified':vi,'constraints_verified':ci,'all57_originals_required':True,'source_pair_disjunctions_verified':len(pair_indices),'integer_halfplanes_verified':halfplanes,'source_rectangles_verified':65,'no_objective_or_hints':True}
