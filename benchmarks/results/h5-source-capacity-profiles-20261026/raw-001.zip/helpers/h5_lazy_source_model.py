"""Pure builder for mandatory source rectangles plus an explicit set of source-pair cuts."""
from ortools.sat.python import cp_model
def build(domains,pairs,rectangles,groups,pair_indices):
    assert pair_indices==sorted(set(pair_indices)) and all(0<=i<len(pairs) for i in pair_indices)
    model=cp_model.CpModel();coords=[];records=[]
    for d in domains:coords.append([model.new_int_var(d['lower_um'][k],d['upper_um'][k],f'{axis}_{d["original"]}') for k,axis in enumerate(['x','y'])])
    for pair_index in pair_indices:
        p=pairs[pair_index];assert p['kind']=='convex_cell_disjunction';i,j=p['left'],p['right'];selectors=[model.new_bool_var(f'pair_{i}_{j}_cell_{c}') for c in range(len(p['cells']))];model.add_exactly_one(selectors);entry={'pair_index':pair_index,'selector_indices':[v.index for v in selectors],'cell_constraint_indices':[]}
        for cell,z in zip(p['cells'],selectors):
            indices=[]
            for nx,ny,rhs in cell['faces']:
                ct=model.add(nx*(coords[j][0]-coords[i][0])+ny*(coords[j][1]-coords[i][1])>=rhs);ct.only_enforce_if(z);indices.append(ct.index)
            entry['cell_constraint_indices'].append(indices)
        records.append(entry)
    rectangle_records=[];x_intervals=[];y_intervals=[]
    for k,r in enumerate(rectangles):
        i=r['part_index'];b=r['bounds_um'];x=model.new_fixed_size_interval_var(coords[i][0]+b[0],r['width_um'],f'inner_x_{k}');y=model.new_fixed_size_interval_var(coords[i][1]+b[1],r['height_um'],f'inner_y_{k}');x_intervals.append(x);y_intervals.append(y);rectangle_records.append({'rectangle_index':k,'interval_indices':[x.index,y.index]})
    nonoverlap=model.add_no_overlap_2d(x_intervals,y_intervals);cumulative_x=model.add_cumulative(x_intervals,[r['height_um'] for r in rectangles],2987000);cumulative_y=model.add_cumulative(y_intervals,[r['width_um'] for r in rectangles],1487000);symmetry=[]
    for g in groups:
        indices=g['part_indices']
        for i,j in zip(indices,indices[1:]):ct=model.add(coords[i][1]<=coords[j][1]);symmetry.append({'parts':[i,j],'constraint_index':ct.index})
    assert model.validate()==''
    return model,{'coordinate_indices':[[v.index for v in xy] for xy in coords],'pairs':records,'rectangles':rectangle_records,'no_overlap_2d_constraint':nonoverlap.index,'cumulative_constraint_indices':[cumulative_x.index,cumulative_y.index],'symmetry':symmetry}
