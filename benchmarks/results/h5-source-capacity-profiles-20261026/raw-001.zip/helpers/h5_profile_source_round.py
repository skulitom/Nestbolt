"""One explicitly changed necessary/source-cut model; no retry inside a round."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,sys,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from h5_profile_source_model import build
from h5_profile_source_model_audit import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-profile-source-cuts-20261026';GEO=ROOT/'output/h5-global-source-cells-20261026';OUT=Path(sys.argv[1]);load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=time.perf_counter();request=load(OUT/'request.json')
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
ds=load(GEO/'domains.json');pairs=load(GEO/'pairs.json');rects=load(GEO/'inner-rectangles/rectangles.json');groups=load(GEO/'inner-rectangles/identical-source-groups.json');model,mapping=build(ds,pairs,rects,groups,request['pair_indices']);assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mapping);raw=cp_model_pb2.CpModelProto();raw.ParseFromString((OUT/'model.pb').read_bytes());checked=verify(raw,ds,pairs,rects,groups,request['pair_indices'],mapping);write(OUT/'model-checks.json',{**checked,'model_sha256':digest(OUT/'model.pb')})
if request['round']==0:assert digest(OUT/'model.pb')==load(BASE/'checks.json')['initial_model_sha256']
budget=min(request['solver_cap_seconds'],request['deadline_perf_counter']-time.perf_counter()-.4)
if budget<=0:
    write(OUT/'result.json',{'status':'ALGORITHM_BUDGET_EXHAUSTED','solver_calls':0,'closed':True,'has_solution':False,'round_seconds':time.perf_counter()-started});raise SystemExit()
solver=cp_model.CpSolver();params={'max_time_in_seconds':budget,'num_search_workers':4,'random_seed':0,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False,'ignore_subsolvers':['fj']}
for k,v in params.items():
    if isinstance(v,list):getattr(solver.parameters,k).extend(v)
    else:setattr(solver.parameters,k,v)
(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'round':request['round'],'source_pair_cuts':len(request['pair_indices']),'model_sha256':digest(OUT/'model.pb'),'maximum_calls':1,'solver_budget_seconds':budget,'parameters':params})
with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
    solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());t=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-t
response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString())
if response.solution:
    assert len(response.solution)==len(raw.variables);write(OUT/'assignment.json',{v.name:int(value) for v,value in zip(raw.variables,response.solution)});write(OUT/'anchors-um.json',[[int(response.solution[v]) for v in xy] for xy in mapping['coordinate_indices']])
write(OUT/'result.json',{'status':solver.status_name(status),'solver_calls':1,'closed':True,'has_solution':bool(response.solution),'solver_budget_seconds':budget,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':elapsed,'solver_soft_overrun_seconds':max(0.,response.wall_time-budget),'returned_soft_overrun_seconds':max(0.,elapsed-budget),'returned_branches':response.num_branches,'returned_conflicts':response.num_conflicts,'round_seconds':time.perf_counter()-started,'variables':len(raw.variables),'constraints':len(raw.constraints),'source_pair_cuts':len(request['pair_indices']),'source_layout_claimed':False})
