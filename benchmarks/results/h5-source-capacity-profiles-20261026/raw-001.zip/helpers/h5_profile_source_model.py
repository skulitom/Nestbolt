"""Necessary source profiles with deferred source-pair constraints and movable hints."""
from pathlib import Path
import json
from h5_lazy_source_model import build as base_build
ROOT=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(p.read_bytes())
def build(domains,pairs,rectangles,groups,pair_indices):
    model,mapping=base_build(domains,pairs,rectangles,groups,pair_indices)
    mapping['profile_base_constraints']=len(model.proto.constraints)
    strips=load(ROOT/'output/h5-cog-source-strips-20261026/rectangles.json')
    profiles=load(ROOT/'output/h5-strip-capacity-profiles-20261026/profiles.json')
    basis=[[(r['part_index'],r['bounds_um'][0],r['bounds_um'][2],r['height_um']) for r in strips],
           [(p['part_index'],r['start_um'],r['end_um'],r['demand_um']) for p in profiles[1]['parts'] for r in p['intervals']]]
    mapping['profiles']=[]
    for axis,rows in enumerate(basis):
        ivs=[];records=[]
        for k,(i,lo,hi,demand) in enumerate(rows):
            v=model.get_int_var_from_proto_index(mapping['coordinate_indices'][i][axis])
            iv=model.new_fixed_size_interval_var(v+lo,hi-lo,f'profile_{axis}_{k}')
            ivs.append(iv);records.append({'part_index':i,'start_um':lo,'end_um':hi,'demand_um':demand,'interval_index':iv.index})
        ct=model.add_cumulative(ivs,[r[3] for r in rows],[2987000,1487000][axis])
        mapping['profiles'].append({'axis':axis,'records':records,'cumulative_constraint_index':ct.index})
    anchors=load(ROOT/'output/h5-constructed-necessary-source-seed-20261026/anchors-um.json')
    for i,d in enumerate(domains):
        if d['family']!='cog':
            for axis,v in enumerate(mapping['coordinate_indices'][i]):model.add_hint(model.get_int_var_from_proto_index(v),anchors[i][axis])
    assert model.validate()==''
    return model,mapping
