"""Independent serialized reader for old geometry, exact profiles and partial hints."""
from pathlib import Path
import json
from ortools.sat import cp_model_pb2
from h5_lazy_source_model_audit import verify as base_verify
ROOT=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(p.read_bytes())
def verify(proto,domains,pairs,rectangles,groups,pair_indices,mapping):
    anchors=load(ROOT/'output/h5-constructed-necessary-source-seed-20261026/anchors-um.json')
    hints=[(v,anchors[i][a]) for i,d in enumerate(domains) if d['family']!='cog' for a,v in enumerate(mapping['coordinate_indices'][i])]
    assert len(hints)==90 and list(zip(proto.solution_hint.vars,proto.solution_hint.values))==hints
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(proto)
    ci=mapping['profile_base_constraints'];del prefix.constraints[ci:];prefix.ClearField('solution_hint')
    result=base_verify(prefix,domains,pairs,rectangles,groups,pair_indices,mapping)
    strips=load(ROOT/'output/h5-cog-source-strips-20261026/rectangles.json')
    profiles=load(ROOT/'output/h5-strip-capacity-profiles-20261026/profiles.json')
    expected=[[(r['part_index'],r['bounds_um'][0],r['bounds_um'][2],r['height_um']) for r in strips],
              [(p['part_index'],r['start_um'],r['end_um'],r['demand_um']) for p in profiles[1]['parts'] for r in p['intervals']]]
    assert list(map(len,expected))==[781,437] and len(mapping['profiles'])==2
    def expr(e,var,offset):assert dict(zip(e.vars,e.coeffs))==({var:1} if var is not None else {}) and e.offset==offset
    for axis,(rows,mp) in enumerate(zip(expected,mapping['profiles'])):
        assert mp['axis']==axis and len(mp['records'])==len(rows);indices=[]
        for k,((i,lo,hi,demand),record) in enumerate(zip(rows,mp['records'])):
            assert record=={'part_index':i,'start_um':lo,'end_um':hi,'demand_um':demand,'interval_index':ci}
            ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and not ct.enforcement_literal and ct.name==f'profile_{axis}_{k}'
            v=mapping['coordinate_indices'][i][axis];expr(ct.interval.start,v,lo);expr(ct.interval.size,None,hi-lo);expr(ct.interval.end,v,hi)
            indices.append(ci);ci+=1
        assert mp['cumulative_constraint_index']==ci
        ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal
        assert list(ct.cumulative.intervals)==indices and len(ct.cumulative.demands)==len(rows)
        expr(ct.cumulative.capacity,None,[2987000,1487000][axis])
        for d,row in zip(ct.cumulative.demands,rows):expr(d,None,row[3])
        ci+=1
    assert ci==len(proto.constraints)
    result.pop('no_objective_or_hints')
    return {**result,'constraints_verified':ci,'profile_intervals_verified':1218,
            'additional_cumulative_constraints_verified':2,'non_cog_hints_verified':90,
            'whole_stock_coordinates_unchanged':True,'first_originals_fixed':0,
            'no_additional_strip_no_overlap':True,'no_objective':True}
