"""Constructive CP model with independent source-mode anchor coordinates."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staggered25-source-regions-20261028';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'control/checks.json')['passed']
inputs=[BASE/'plan.json',BASE/'audit/checks.json',BASE/'control/plan.json',BASE/'control/checks.json',BASE/'control/moving15.json',BASE/'modes.json',BASE/'fixed41.json']
inputs+=sorted((BASE/'free').glob('*.json'))+sorted((BASE/'relative').glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'solver_seconds':60,'shared_process_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_calls':1,'retry_permitted':False,
    'method':'Build the source-placement prefix for the changed staggered core. All25 movers are mandatory:15 phase7 cogs, brackets5/6/9 in all8 modes, inserts13..19 in2 outer classes. Every mover has independent micrometre X/Y anchors and chooses an audited convex free cell rebuilt against26 fixed first-sheet originals. Each of300 mover pairs chooses an audited allowed-displacement cell. Same-family X ordering removes identical-copy relabelings. The source56 control hints only15 cogs; all10 bracket/insert originals remain unplaced and mandatory. This prefix is not solved separately: append the independently proved source-rectangle capacity constraints, audit the complete model, then allow only that complete formulation one60-second call within90seconds shared. No lattice or fixed mover coordinate, resumed old search or actual/global infeasibility claim.'})
model=cp_model.CpModel();modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)}
relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)}
items=[];vars_by_index={};hints={};control={(r['family'],r['copy_index']):r for r in load(BASE/'control/moving15.json')}
def variable(name,lo,hi,boolean=False):
    v=model.new_bool_var(name) if boolean else model.new_int_var(lo,hi,name);vars_by_index[v.index]=v;return v
def add_linear(expr,lo=None,hi=None,enforce=None):
    ct=model.add(expr>=lo) if hi is None else model.add(expr<=hi) if lo is None else model.add_linear_constraint(expr,lo,hi)
    if enforce is not None:ct.only_enforce_if(enforce)
    return ct.index
def hint(index,value):assert index not in hints;hints[index]=int(value)
def cell_for(cells,x,y):
    return next(i for i,c in enumerate(cells) if all(a*x+b*y>=v for a,b,v in c['halfplanes']))
for family,copies,allowed in [('cog',range(15),[0]),('bracket',[5,6,9],list(range(1,9))),('insert',range(13,20),[9,10])]:
    for copy in copies:
        i=len(items);x=variable(f'x_{i}',0,1500000);y=variable(f'y_{i}',0,3000000);options=[]
        for mode in allowed:
            mv=variable(f'mode_{i}_{mode}',0,1,True);selectors=[variable(f'free_{i}_{mode}_{k}',0,1,True) for k in range(len(free[mode]))]
            choice=add_linear(sum(selectors)-mv,0,0);plane_indices=[]
            for cell,sv in zip(free[mode],selectors):
                plane_indices.append([add_linear(a*x+b*y,lo=c,enforce=sv) for a,b,c in cell['halfplanes']])
            options.append({'mode':mode,'selector':mv.index,'cells':[v.index for v in selectors],'choice_constraint':choice,'plane_constraints':plane_indices})
        mode_choice=model.add_exactly_one(vars_by_index[o['selector']] for o in options).index
        item={'index':i,'family':family,'copy_index':copy,'x':x.index,'y':y.index,'options':options,'mode_choice_constraint':mode_choice};items.append(item)
        if (family,copy) in control:
            row=control[family,copy];hint(x.index,row['anchor_um'][0]);hint(y.index,row['anchor_um'][1]);selected=cell_for(free[row['mode']],*row['anchor_um'])
            for o in options:
                hint(o['selector'],o['mode']==row['mode'])
                for k,index in enumerate(o['cells']):hint(index,o['mode']==row['mode'] and k==selected)
pairs=[]
for left,right in combinations(items,2):
    x1,y1=vars_by_index[left['x']],vars_by_index[left['y']];x2,y2=vars_by_index[right['x']],vars_by_index[right['y']];groups=[]
    for oa in left['options']:
        for ob in right['options']:
            a,b=oa['mode'],ob['mode'];sign=1 if a<=b else -1;cells=relative[min(a,b),max(a,b)]
            ss=[variable(f'pair_{left["index"]}_{right["index"]}_{a}_{b}_{k}',0,1,True) for k in range(len(cells))]
            va,vb=vars_by_index[oa['selector']],vars_by_index[ob['selector']]
            choice=[add_linear(sum(ss)-va,hi=0),add_linear(sum(ss)-vb,hi=0),add_linear(sum(ss)-va-vb,lo=-1)]
            pc=[]
            for cell,v in zip(cells,ss):pc.append([add_linear(sign*(aa*(x2-x1)+bb*(y2-y1)),lo=cc,enforce=v) for aa,bb,cc in cell['halfplanes']])
            groups.append({'left_mode':a,'right_mode':b,'cells':[v.index for v in ss],'choice_constraints':choice,'plane_constraints':pc})
            ka,kb=(left['family'],left['copy_index']),(right['family'],right['copy_index'])
            if ka in control and kb in control:
                ca,cb=control[ka],control[kb];active=(ca['mode'],cb['mode'])==(a,b)
                selected=cell_for(cells,*[sign*(cb['anchor_um'][k]-ca['anchor_um'][k]) for k in [0,1]]) if active else None
                for k,v in enumerate(ss):hint(v.index,active and k==selected)
    pairs.append({'left':left['index'],'right':right['index'],'groups':groups})
order=[]
for family in ['cog','bracket','insert']:
    group=[i for i in items if i['family']==family]
    for a,b in zip(group,group[1:]):order.append({'left':a['index'],'right':b['index'],'constraint':add_linear(vars_by_index[a['x']]-vars_by_index[b['x']],hi=0)})
for ix,value in sorted(hints.items()):model.add_hint(vars_by_index[ix],value)
assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));assert model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'pairs':pairs,'orders':order,'coordinate_scale':1000})
write(OUT/'hint-values.json',{str(k):v for k,v in sorted(hints.items())})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'mandatory_originals':25,'unordered_mover_pairs':len(pairs),'mode_pair_groups':sum(len(p['groups']) for p in pairs),'hints':len(hints),
    'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
