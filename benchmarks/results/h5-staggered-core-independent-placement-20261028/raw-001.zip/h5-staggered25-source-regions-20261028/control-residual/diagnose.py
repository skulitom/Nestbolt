"""Characterize the saved control's residual source regions; no search."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,shape,mapping
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staggered25-source-regions-20261028';OUT=BASE/'control-residual'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py');started=time.perf_counter()
inputs=[BASE/'control/source56.json',BASE/'control/checks.json',BASE/'modes.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',Path(geom.__file__)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_regions':10,'maximum_seconds':60,'maximum_runs':1,'retry_permitted':False,
    'method':'Inspect the saved source56 control after the sole full model closed UNKNOWN. Rebuild the10 non-cog source-mode free regions against all41 fixed first-sheet originals, including15 cogs. Record the exact conservative regions, area, bounds and connected components without choosing a new placement, moving a part or launching a solver. Empty conservative regions do not prove actual placement impossible; this only characterizes this one saved partial control. Independent clearance containment and source-stock checks must validate these diagnostics.'})
assert load(BASE/'control/checks.json')['passed'] and load(BASE/'capacity/response-audit/checks.json')['status']=='UNKNOWN'
job=load(inputs[-2]);parts={p['id']:p for p in job['parts']};fixed=[];geom.EPS=.0126
for r in load(BASE/'control/source56.json'):
    if r['sheet_id']!='sheet-0':continue
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    fixed.append(Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']]))
assert len(fixed)==41;rows=[]
for mode in load(BASE/'modes.json')[1:]:
    assert time.perf_counter()-started<60;g=geom.regions(shape(mode['geometry']),fixed,job['stocks'][0],job['edge_clearance'],.21170867250963943)
    assert g.is_valid;write(OUT/f"mode-{mode['index']:02d}.json",mapping(g));polys=geom.polygons(g)
    rows.append({'mode':mode['index'],'family':mode['family'],'empty':g.is_empty,'area_mm2':g.area,'components':len(polys),'bounds':None if g.is_empty else list(g.bounds)})
write(OUT/'regions-summary.json',rows);write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'regions':10,'empty_bracket_modes':sum(r['empty'] for r in rows if r['family']=='bracket'),'empty_insert_modes':sum(r['empty'] for r in rows if r['family']=='insert'),'solver_calls':0,'native_calls':0,'actual_or_global_infeasibility_claimed':False})
print(load(OUT/'result.json'));print(rows)
