"""Rebuild source free regions for the staggered 26-part first-sheet core."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-staggered25-source-regions-20261028'
OLD=ROOT/'output/h5-free23-source-regions-20261028';STAG=ROOT/'output/h5-staggered-frame-bracket-core-repaired-20261026'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from fractions import Fraction as F
    from shapely.geometry import Polygon,shape,mapping
    from shapely.geometry.polygon import orient
    from shapely.ops import unary_union
    import diagnose_h5_concave_gaps as geom
    from h5_legacy64_source_readback import audit
    start=time.perf_counter();geom.EPS=.0126;required=.21170867250963943;guard=.011444091796875
    job=load(JOB);parts={p['id']:p for p in job['parts']};rows=load(STAG/'placements.json');inv=load(STAG/'audit/next-neighborhood.json')
    assert rows==inv['fixed_first_placements']+inv['fixed_short_placements']
    assert len(rows)==41 and len(inv['fixed_first_placements'])==26
    expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};keys={(p['part_id'],p['copy_index']) for p in rows}
    remaining=expected-keys;assert remaining=={('bracket',i) for i in [5,6,9]}|{('insert',i) for i in range(13,20)}|{('cog',i) for i in range(15)}
    readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},required,guard,keys)
    write(OUT/'fixed-source-readback.json',readback);assert readback['valid']
    write(OUT/'fixed41.json',rows);write(OUT/'remaining.json',[{'family':p,'copy_index':i} for p,i in sorted(remaining)])
    def world(r):
        t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        return Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']])
    fixed=[world(r) for r in rows if r['sheet_id']=='sheet-0'];modes=load(OLD/'modes.json');shutil.copyfile(OLD/'modes.json',OUT/'modes.json')
    records=[];planes=0
    for i,m in enumerate(modes):
        free=geom.regions(shape(m['geometry']),fixed,job['stocks'][0],job['edge_clearance'],required)
        assert free.is_valid and not free.is_empty
        write(OUT/'source-free'/f'{i:02d}.json',mapping(free));cells=[]
        pieces=[p for q in geom.polygons(free) for p in geom.convex_pieces(q)];assert unary_union(pieces).equals(free)
        for p in pieces:
            p=orient(p,sign=1);points=list(p.exterior.coords)[:-1];hp=[]
            for a,b in zip(points,points[1:]+points[:1]):
                px,py=map(lambda v:F(str(v)),a);qx,qy=map(lambda v:F(str(v)),b);nx,ny=py-qy,qx-px;scale=max(abs(nx),abs(ny));nx/=scale;ny/=scale
                aa=round(nx*10**9);bb=round(ny*10**9);error=abs(F(aa)-nx*10**9)*1600000+abs(F(bb)-ny*10**9)*3100000
                target=(nx*px+ny*py)*10**12+error;cc=-((-target.numerator)//target.denominator)+1;hp.append([aa,bb,cc]);planes+=1
            cells.append({'geometry':mapping(p),'halfplanes':hp})
        write(OUT/'free'/f'{i:02d}.json',{'cells':cells,'domain_geometry':mapping(free)})
        records.append({'mode':i,'cells':len(cells),'halfplanes':sum(len(c['halfplanes']) for c in cells),'area_mm2':free.area})
    reused={}
    for p in sorted((OLD/'relative').glob('*.json')):shutil.copyfile(p,OUT/'relative'/p.name);reused[p.relative_to(ROOT).as_posix()]=digest(p)
    assert len(reused)==66;write(OUT/'reused-relative-cells.json',reused);write(OUT/'cells-summary.json',records)
    write(OUT/'result.json',{'status':'COMPLETE','closed':True,'seconds':time.perf_counter()-start,'source_modes':11,'fixed_originals':41,
        'fixed_first_originals':26,'fixed_short_originals':15,'mandatory_movers':25,'new_free_domains':11,'new_free_cells':sum(r['cells'] for r in records),
        'new_free_halfplanes':planes,'unchanged_intrinsic_relative_domains':66,'source_fixed_pairs':readback['same_sheet_pairs'],
        'source_fixed_holes':readback['cutouts'],'solver_calls':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();[(OUT/n).mkdir() for n in ['free','source-free','relative']];shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[JOB,STAG/'plan.json',STAG/'placements.json',STAG/'audit/checks.json',STAG/'audit/next-neighborhood.json',OLD/'plan.json',OLD/'modes.json',OLD/'audit/checks.json',
        ROOT/'output/h5-free23-capacity-20261028/geometry-audit-corrected/checks.json',ROOT/'output/h5-free23-capacity-20261028/mode-rectangles.json',
        ROOT/'output/diagnose_h5_concave_gaps.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'benchmarks/results/h5-seven-bracket-source-and-bound-20261028/updated-allocations.json']
    inputs+=sorted((OLD/'relative').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_preparation_seconds':120,'maximum_runs':1,'retry_permitted':False,
        'method':'Revalidate the original-source staggered core of26 first-sheet originals (18 frames,3 brackets,5 inserts) and15 short-sheet originals (6 brackets,9 inserts) at the unchanged target. Preserve all25 remaining originals as mandatory: brackets5,6,9; inserts13..19; cogs0..14. Rebuild every owner-dependent free region against the changed26 first-sheet poses. Reuse byte-identical11 source modes and66 intrinsic relative-cell domains only because source transforms, required gap, construction margin and bounded coordinate range agree exactly. The old2000-pose finite pool and closed free23 calls are not resumed. Every mover will have independently positioned micrometre X/Y anchors; phase7 cog mode is a constructive subset, brackets retain all8 modes and inserts both outer classes. Before declaring any search audit original-source clearance, all integer halfplanes, a source-valid partial control and new fixed-core capacity rectangles. Empty conservative regions or a later no-result response support no actual or global infeasibility claim. No optimizer/native call in preparation.',
        'required_pair_gap_mm':.21170867250963943,'construction_extra_margin_mm':.0126,'stock_guard_mm':.011444091796875,
        'coordinate_grid_um':1,'absolute_coordinate_bounds_um':[1600000,3100000],'target_gross_material_mm2':4988890.353494999})
    start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=120)
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'Closed without final result; retain diagnostics.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
