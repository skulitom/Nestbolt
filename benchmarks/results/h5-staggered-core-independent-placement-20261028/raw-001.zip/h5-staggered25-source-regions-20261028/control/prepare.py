"""Source-valid cog control and newly contained fixed-core rectangles."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box,shape
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staggered25-source-regions-20261028';OUT=BASE/'control';CAP=BASE/'capacity'
OLD=ROOT/'output/h5-free23-capacity-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();CAP.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
assert load(BASE/'audit/checks.json')['passed'] and load(OLD/'geometry-audit-corrected/checks.json')['passed']
inputs=[BASE/'plan.json',BASE/'fixed41.json',BASE/'modes.json',BASE/'remaining.json',BASE/'audit/checks.json',OLD/'mode-rectangles.json',OLD/'geometry-audit-corrected/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'No optimization. Place fifteen phase7 original cogs in a5-column/3-row aligned control at258.90mm pitch, bounding lower-left6.525,2168.100mm, then round each independent center anchor to1um. Relabel identical cogs by X,Y to obey the future copy ordering. Keep all41 source-valid core/short originals unchanged. Independently check all original source pairs/edges/holes and each occupied integer free/relative cell. The other ten originals remain mandatory and unplaced; this56-original control is not a full witness or improvement on the previous64.'})
fixed=load(BASE/'fixed41.json');modes=load(BASE/'modes.json');g=shape(modes[0]['geometry']);records=[];rows=list(fixed)
for col in range(5):
    for row in range(3):
        xy=[round(1000*(6.525-g.bounds[0]+col*258.90)),round(1000*(2168.100-g.bounds[1]+row*258.90))];copy=len(records)
        records.append({'family':'cog','copy_index':copy,'mode':0,'anchor_um':xy});m=modes[0]
        rows.append({'part_id':'cog','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':False,'translation':[xy[k]/1000+m['source_translation_offset'][k] for k in [0,1]]}})
def matches(p,x,y):return [i for i,c in enumerate(load(p)['cells']) if all(a*x+b*y>=v for a,b,v in c['halfplanes'])]
free=[];pairs=[]
for r in records:
    cells=matches(BASE/'free/00.json',*r['anchor_um']);assert cells,r;free.append({'key':['cog',r['copy_index']],'mode':0,'cell':cells[0]})
for a,b in combinations(records,2):
    cells=matches(BASE/'relative/00-00.json',*[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]]);assert cells,(a,b)
    pairs.append({'keys':[['cog',a['copy_index']],['cog',b['copy_index']]],'cell':cells[0]})
job=load(inputs[-2]);expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};missing={('bracket',i) for i in [5,6,9]}|{('insert',i) for i in range(13,20)}
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,expected-missing)
write(OUT/'source-readback.json',readback);assert readback['valid'];write(OUT/'source56.json',rows);write(OUT/'moving15.json',records);write(OUT/'free.json',free);write(OUT/'pairs.json',pairs)
write(OUT/'checks.json',{'passed':True,'source_originals':56,'moving_originals':15,'unchanged_fixed_originals':41,'occupied_integer_free_cells':len(free),
    'occupied_integer_relative_cells':len(pairs),'source_pairs_verified':readback['same_sheet_pairs'],'source_stock_edges':readback['stock_edges'],'source_holes':readback['cutouts'],'hole_vertices':readback['hole_vertices'],
    'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'unplaced_originals':[list(k) for k in sorted(missing)],'solver_calls':0,'native_calls':0,'H5_complete':False})
write(CAP/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs+[OUT/'moving15.json',OUT/'checks.json']},
    'method':'Reuse byte-identical11 source-mode contained rectangles and their grid inventory. Rebuild constant rectangles for all26 fixed first-sheet originals: one per frame/insert, two per L bracket, total29 components. Transform actual source rectangle pieces at actual saved poses and round inward2um. Independently verify exact source-edge separation/inside parity, intra-owner disjoint interiors and the source56 control capacity sweeps. Original stock capacities1487000/2987000um, no extra gap demand or bounding-box exclusion.'})
for n in ['mode-rectangles.json','cog-grid-inventory.json']:shutil.copyfile(OLD/n,CAP/n)
parts={p['id']:p for p in job['parts']};fixed_rows=[]
for r in fixed:
    if r['sheet_id']!='sheet-0':continue
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    pieces=[parts[r['part_id']]['geometry'][0]['outer']] if r['part_id']!='bracket' else [[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]]
    rectangles=[]
    for p in pieces:
        poly=Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in p]);x0,y0,x1,y1=poly.bounds
        rr=[math.ceil(x0*1000)+2,math.ceil(y0*1000)+2,math.floor(x1*1000)-2,math.floor(y1*1000)-2];assert poly.contains(box(*[v/1000 for v in rr]));rectangles.append(rr)
    fixed_rows.append({'key':[r['part_id'],r['copy_index']],'rectangles_um':rectangles})
assert len(fixed_rows)==26 and sum(len(r['rectangles_um']) for r in fixed_rows)==29
write(CAP/'fixed-rectangles.json',fixed_rows);write(CAP/'prepared.json',{'seconds':time.perf_counter()-started,'source_modes':11,'fixed_first_originals':26,'fixed_components':29,'reused_mode_rectangles_byte_identical':True,'solver_calls':0,'native_calls':0})
print(load(OUT/'checks.json'));print(load(CAP/'prepared.json'))
