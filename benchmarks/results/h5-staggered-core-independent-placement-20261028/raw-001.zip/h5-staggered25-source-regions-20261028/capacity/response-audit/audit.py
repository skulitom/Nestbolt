"""Read the sole independent-position response without broadening its claims."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-staggered25-source-regions-20261028';BASE=OLD/'capacity';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
ma=load(BASE/'model-audit/checks.json');assert ma['passed']
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json')
assert not process['timeout'] and process['exit_code']==0 and process['seconds']<90
assert result['solver_calls']==1 and result['closed'] and opened['maximum_calls']==1
assert opened['model_audit_sha256']==digest(BASE/'model-audit/checks.json') and opened['geometry_audit_sha256']==digest(BASE/'geometry-audit/checks.json')
assert opened['partial_control_sha256']==digest(OLD/'control/checks.json')
assert digest(SEARCH/'model.pb')==digest(MODEL/'model.pb')==ma['model_sha256']==opened['model_sha256']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert params.max_time_in_seconds==60 and params.num_search_workers==4 and params.random_seed==0 and params.stop_after_first_solution
assert list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
assert {f.name for f,v in params.ListFields()}==set(opened['parameters'])
p=cp_model_pb2.CpModelProto();p.ParseFromString((SEARCH/'model.pb').read_bytes())
r=cp_model_pb2.CpSolverResponse();r.ParseFromString((SEARCH/'response.pb').read_bytes())
status=cp_model_pb2.CpSolverStatus.Name(r.status);assert status==result['status'] and status in ['UNKNOWN','FEASIBLE','OPTIMAL','INFEASIBLE']
assert r.wall_time==result['solver_wall_seconds'] and r.num_branches==result['returned_response_branches'] and r.num_conflicts==result['returned_response_conflicts']
assert bool(r.solution)==result['has_solution']==(status in ['FEASIBLE','OPTIMAL'])
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log
printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1))
assert abs(printed-Decimal(str(r.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
assert result['returned_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-60) and result['solver_soft_overrun_seconds']==max(0.,r.wall_time-60)
variables=constraints=inactive=0
if r.solution:
    sol=list(r.solution);assert len(sol)==len(p.variables)==47272 and sol==load(SEARCH/'assignment.json')
    for v,x in zip(p.variables,sol):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]));variables+=1
    def truth(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def expression(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    for ct in p.constraints:
        constraints+=1
        if not all(truth(v) for v in ct.enforcement_literal):inactive+=1;continue
        if ct.WhichOneof('constraint')=='linear':
            value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif ct.WhichOneof('constraint')=='exactly_one':assert sum(truth(v) for v in ct.exactly_one.literals)==1
        elif ct.WhichOneof('constraint')=='interval':
            assert expression(ct.interval.start)+expression(ct.interval.size)==expression(ct.interval.end) and expression(ct.interval.size)>0
        elif ct.WhichOneof('constraint')=='cumulative':
            events={}
            for ix,demand in zip(ct.cumulative.intervals,ct.cumulative.demands):
                interval=p.constraints[ix]
                if not all(truth(v) for v in interval.enforcement_literal):continue
                begin=expression(interval.interval.start);end=expression(interval.interval.end);amount=expression(demand)
                events[begin]=events.get(begin,0)+amount;events[end]=events.get(end,0)-amount
            total=0;capacity=expression(ct.cumulative.capacity)
            for where,delta in sorted(events.items()):total+=delta;assert 0<=total<=capacity
            assert total==0
        else:raise AssertionError(ct.WhichOneof('constraint'))
    mapping=load(OLD/'model/mapping.json');modes=load(OLD/'modes.json');poses=[];rows=load(OLD/'fixed41.json')
    for item in mapping['items']:
        selected=[o for o in item['options'] if sol[o['selector']]];assert len(selected)==1;m=modes[selected[0]['mode']]
        xy=[sol[item['x']],sol[item['y']]];poses.append({'family':item['family'],'copy_index':item['copy_index'],'mode':m['index'],'anchor_um':xy})
        rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],
            'mirrored':m['mirrored'],'translation':[xy[k]/1000+m['source_translation_offset'][k] for k in [0,1]]}})
    assert len(rows)==66;write(OUT/'selected-poses.json',poses);write(OUT/'source66-candidate.json',rows)
else:assert not (SEARCH/'assignment.json').exists()
inputs=[MODEL/'plan.json',OLD/'model/mapping.json',BASE/'model-audit/checks.json',BASE/'geometry-audit/checks.json',OLD/'control/checks.json']+list(SEARCH.glob('*'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs if p.is_file()}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'closed':True,'solver_calls':1,
    'returned_branches':r.num_branches,'returned_conflicts':r.num_conflicts,'solver_wall_seconds':r.wall_time,
    'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],
    'solution_variables_verified':variables,'solution_constraints_verified':constraints,'solution_inactive_constraints':inactive,
    'has_source66_candidate':bool(r.solution),'source_geometry_validated':False,'actual_or_global_infeasibility_claimed':False,
    'remaining_necessary_allocations':444,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
