"""Audit the complete original prefix and every new source-capacity constraint."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-staggered25-source-regions-20261028';BASE=OLD/'capacity';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
geo=load(BASE/'geometry-audit/checks.json');assert geo['passed'] and geo['seconds']>=0 and geo['new_constraints_necessary']
prior=load(OLD/'model-audit/checks.json');assert prior['passed']
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes())
assert digest(OLD/'model/model.pb')==prior['model_sha256']==digest(MODEL/'baseline.pb')
assert {f.name for f,v in p.ListFields()}=={f.name for f,v in old.ListFields()}=={'variables','constraints','solution_hint'}
assert list(p.variables)==list(old.variables) and p.solution_hint==old.solution_hint
assert list(p.constraints[:len(old.constraints)])==list(old.constraints)
mapping=load(MODEL/'capacity-mapping.json');original=load(OLD/'model/mapping.json');rectangles=load(BASE/'mode-rectangles.json');fixed=load(BASE/'fixed-rectangles.json')
assert mapping['original_variables']==len(old.variables)==47272 and mapping['original_constraints']==len(old.constraints)==170594
assert mapping['capacity_width_um']==1487000 and mapping['capacity_height_um']==2987000
expected=[({'fixed_key':r['key'],'source_rectangle':k},rect,None,None,None) for r in fixed for k,rect in enumerate(r['rectangles_um'])]
for item in original['items']:
    for option in item['options']:
        for k,rect in enumerate(rectangles[option['mode']]['rectangles_um']):expected.append(({'item_index':item['index'],'mode':option['mode'],'source_rectangle':k},rect,item['x'],item['y'],option['selector']))
components=mapping['components'];assert len(components)==len(expected)==1471;visited=set();hint=dict(zip(p.solution_hint.vars,p.solution_hint.values));active=[];inactive=unknown=0
def expr(e,variable,offset):
    assert e.offset==offset and list(e.vars)==([] if variable is None else [variable]) and list(e.coeffs)==([] if variable is None else [1])
    assert {f.name for f,v in e.ListFields()}<= {'vars','coeffs','offset'}
for k,(row,(owner,rect,x,y,present)) in enumerate(zip(components,expected)):
    assert row=={'index':k,**owner,'rectangle_um':rect,'presence_variable':present,'x_interval':len(old.constraints)+2*k,'y_interval':len(old.constraints)+2*k+1}
    for axis,var in [(0,x),(1,y)]:
        ix=row['x_interval' if axis==0 else 'y_interval'];assert ix not in visited;visited.add(ix);ct=p.constraints[ix]
        assert ct.WhichOneof('constraint')=='interval' and ct.name==f'capacity_{"x" if axis==0 else "y"}_{k}'
        assert {f.name for f,v in ct.ListFields()}<= {'name','interval','enforcement_literal'}
        assert list(ct.enforcement_literal)==([] if present is None else [present])
        assert {f.name for f,v in ct.interval.ListFields()}=={'start','size','end'}
        expr(ct.interval.start,var,rect[axis]);expr(ct.interval.end,var,rect[axis+2]);expr(ct.interval.size,None,rect[axis+2]-rect[axis])
    if present is not None and present not in hint:unknown+=1;continue
    if present is not None and not hint[present]:inactive+=1;continue
    dx=0 if x is None else hint[x];dy=0 if y is None else hint[y]
    active.append([rect[0]+dx,rect[1]+dy,rect[2]+dx,rect[3]+dy])
sweeps=[]
for axis,capacity,key in [(0,2987000,'x_cumulative'),(1,1487000,'y_cumulative')]:
    ix=mapping[key];assert ix not in visited;visited.add(ix);ct=p.constraints[ix]
    assert {f.name for f,v in ct.ListFields()}=={'cumulative'} and ct.WhichOneof('constraint')=='cumulative'
    cum=ct.cumulative;assert {f.name for f,v in cum.ListFields()}=={'capacity','intervals','demands'}
    assert list(cum.intervals)==[r['x_interval' if axis==0 else 'y_interval'] for r in components];expr(cum.capacity,None,capacity)
    assert len(cum.demands)==len(components)
    for r,e in zip(components,cum.demands):expr(e,None,r['rectangle_um'][3-axis]-r['rectangle_um'][1-axis])
    events={}
    for r in active:
        begin,end=r[axis],r[axis+2];demand=r[3-axis]-r[1-axis];events[begin]=events.get(begin,0)+demand;events[end]=events.get(end,0)-demand
    current=maximum=0;states=[]
    for where,delta in sorted(events.items()):current+=delta;assert 0<=current<=capacity;maximum=max(maximum,current);states.append([where,current])
    assert current==0;sweeps.append({'axis':axis,'capacity_um':capacity,'maximum_demand_um':maximum,'slack_um':capacity-maximum,'events':states})
assert visited==set(range(len(old.constraints),len(p.constraints))) and len(p.constraints)==173538
assert sweeps==load(BASE/'geometry-audit/partial-control-sweeps.json')
built=load(MODEL/'built.json');assert built['model_sha256']==digest(MODEL/'model.pb') and built['mapping_sha256']==digest(MODEL/'capacity-mapping.json')
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'original_variables_identical':len(old.variables),'original_constraints_identical':len(old.constraints),
    'hint_values_identical':len(hint),'added_intervals_verified':2942,'added_cumulatives_verified':2,'source_rectangle_options_verified':1471,
    'mandatory_originals':25,'independent_position_variables':50,'total_constraints_verified':len(p.constraints),'active_partial_control_components':len(active),
    'inactive_partial_control_components':inactive,'components_for_unplaced_modes':unknown,'partial_control_capacity_slack_um':[r['slack_um'] for r in sweeps],
    'new_constraints_necessary':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'capacity-mapping.json'),'plan_sha256':digest(MODEL/'plan.json'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
