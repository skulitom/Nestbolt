"""Append necessary source-rectangle capacity constraints to the original model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-staggered25-source-regions-20261028';BASE=OLD/'capacity';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
audit=load(BASE/'geometry-audit/checks.json');assert audit['passed'] and audit['seconds']>=0 and audit['new_constraints_necessary']
assert load(OLD/'model-audit/checks.json')['passed']
inputs=[BASE/'plan.json',BASE/'mode-rectangles.json',BASE/'fixed-rectangles.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',
    BASE/'geometry-audit/necessity-proof.json',OLD/'model/model.pb',OLD/'model/model.pbtxt',OLD/'model/mapping.json',OLD/'model/plan.json',
    OLD/'model-audit/checks.json',OLD/'control/moving15.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'solver_seconds':60,'shared_process_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_calls':1,'retry_permitted':False,
    'method':'Complete the changed staggered25 source-placement formulation before its sole call. Preserve every audited prefix variable, constraint and hint. Add optional X/Y intervals for each source-contained rectangle of each selected mover mode, plus29 constant rectangles from26 fixed first-sheet originals, and necessary X/Y stock capacities2987000/1487000um. Independent source-edge and capacity proofs cover these constraints. All25 originals remain mandatory with50 independent coordinates; no lattice, fixed mover coordinates or bounding-box exclusion. Audit every appended interval/demand/presence and the source56 control before one60-second four-worker seed0 call inside90seconds shared. No continuation/reseed of any prior closed search, including the old staggered2000-pose finite pool. A no-result response proves no actual/global infeasibility; all66 originals must pass original-source readback before native validation.'})
model=cp_model.CpModel();assert model.proto.parse_text_format((OLD/'model/model.pbtxt').read_text())
assert model.export_to_file(str(OUT/'baseline.pb'));assert digest(OUT/'baseline.pb')==digest(OLD/'model/model.pb')
original_variables=len(model.proto.variables);original_constraints=len(model.proto.constraints);components=[];xs=[];ys=[];widths=[];heights=[]
mode_rows=load(BASE/'mode-rectangles.json');mapping=load(OLD/'model/mapping.json')
def record(owner,rect,x,y,present=None):
    k=len(components);a,b,c,d=rect;w,h=c-a,d-b
    if present is None:
        ix=model.new_fixed_size_interval_var(x+a,w,f'capacity_x_{k}');iy=model.new_fixed_size_interval_var(y+b,h,f'capacity_y_{k}')
    else:
        ix=model.new_optional_fixed_size_interval_var(x+a,w,present,f'capacity_x_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,h,present,f'capacity_y_{k}')
    xs.append(ix);ys.append(iy);widths.append(w);heights.append(h)
    components.append({'index':k,**owner,'rectangle_um':rect,'presence_variable':None if present is None else present.index,'x_interval':ix.index,'y_interval':iy.index})
for row in load(BASE/'fixed-rectangles.json'):
    for k,rect in enumerate(row['rectangles_um']):record({'fixed_key':row['key'],'source_rectangle':k},rect,0,0)
for item in mapping['items']:
    x=model.get_int_var_from_proto_index(item['x']);y=model.get_int_var_from_proto_index(item['y'])
    for option in item['options']:
        present=model.get_int_var_from_proto_index(option['selector'])
        for rectangle,rect in enumerate(mode_rows[option['mode']]['rectangles_um']):record({'item_index':item['index'],'mode':option['mode'],'source_rectangle':rectangle},rect,x,y,present)
xcap=model.add_cumulative(xs,heights,2987000);ycap=model.add_cumulative(ys,widths,1487000)
assert len(model.proto.variables)==original_variables and model.validate()==''
assert model.export_to_file(str(OUT/'model.pb'));assert model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'capacity-mapping.json',{'components':components,'x_cumulative':xcap.index,'y_cumulative':ycap.index,
    'original_variables':original_variables,'original_constraints':original_constraints,'capacity_width_um':1487000,'capacity_height_um':2987000})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'unchanged_prefix_variables':original_variables,'unchanged_prefix_constraints':original_constraints,'source_rectangle_options':len(components),
    'added_intervals':2*len(components),'added_cumulatives':2,'mandatory_originals':25,'independent_position_variables':50,
    'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'capacity-mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
