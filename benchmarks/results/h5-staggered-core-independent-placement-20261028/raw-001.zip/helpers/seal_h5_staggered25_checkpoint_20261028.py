"""Seal the changed-core independent placement search and source controls."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-staggered25-source-regions-20261028';CAP=BASE/'capacity';PUB=BASE/'publication'
NAME='h5-staggered-core-independent-placement-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='116b16d7924e370b1cd3b7273a4a75f4b92210be' and not git('diff','HEAD','--name-only')
geo=load(BASE/'audit/checks.json');control=load(BASE/'control/checks.json');cg=load(CAP/'geometry-audit/checks.json');prefix=load(BASE/'model-audit/checks.json');model=load(CAP/'model-audit/checks.json');response=load(CAP/'response-audit/checks.json');residual=load(BASE/'control-residual/audit/checks.json')
assert all(r['passed'] for r in [geo,control,cg,prefix,model,response,residual]);assert response['status']=='UNKNOWN' and response['closed']
assert model['mandatory_originals']==25 and control['source_originals']==56 and geo['fixed_neighbour_checks']==286
prior=load(ROOT/'benchmarks/results/h5-source-capacity-and-core-height-20261028/publication-review.json')
production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='d71c9c85257ba1500139e6bff62937f21fcfbf89'
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for p in BASE.rglob('*'):
    if p.is_file():add(BASE.name+'/'+p.relative_to(BASE).as_posix(),p)
helpers=['prepare_h5_staggered25_regions_20261028.py','audit_h5_staggered25_regions_20261028.py','prepare_h5_staggered25_control_capacity_20261028.py',
    'audit_h5_staggered25_capacity_rectangles_20261028.py','build_h5_staggered25_model_20261028.py','audit_h5_staggered25_model_20261028.py',
    'build_h5_staggered25_capacity_model_20261028.py','audit_h5_staggered25_capacity_model_20261028.py','run_h5_staggered25_capacity_model_20261028.py',
    'audit_h5_staggered25_capacity_response_20261028.py','diagnose_h5_staggered25_control_20261028.py','audit_h5_staggered25_residual_20261028.py',
    'pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
for n in ['checks.json','next-step.json','height-bound-audit.json']:
    p=ROOT/'benchmarks/results/h5-source-capacity-and-core-height-20261028'/n;key=p.relative_to(ROOT).as_posix();bindings[key]=digest(p);add('source-inputs/'+key,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for p,n in [(BASE/'audit/checks.json','source-region-audit.json'),(BASE/'control/checks.json','source-control-audit.json'),(BASE/'control/source56.json','source56.json'),
    (CAP/'geometry-audit/checks.json','capacity-geometry-audit.json'),(CAP/'geometry-audit/necessity-proof.json','capacity-necessity-proof.json'),
    (BASE/'model-audit/checks.json','placement-model-audit.json'),(CAP/'model-audit/checks.json','complete-model-audit.json'),(CAP/'response-audit/checks.json','response-audit.json'),
    (BASE/'control-residual/regions-summary.json','residual-regions.json'),(BASE/'control-residual/audit/checks.json','residual-region-audit.json'),(PUB/'main-ci-jobs.json','prior-main-ci.json')]:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_verified_commit':head,
    'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40728382102,'main_all6_pass':True,
    'normal_push_pending_fresh_ref_guards':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':7,'solver_status':'UNKNOWN','search_closed':True,'solver_calls':1,'source56_control_valid':True,
    'all25_movers_mandatory':True,'all66_originals_accounted_once':True,'previous_source64_preserved':True,'remaining_necessary_allocations':444,
    'full66_witness':False,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The independent staggered25 model is CLOSED UNKNOWN after its sole60-second call (82996 returned branches,13173 conflicts); preserve the0.0769154s returned soft overrun. No restart, reseed or extended call. Source41 core and source56 control are valid; the best earlier64 remains preserved. The residual diagnostic has empty conservative bracket regions in all8 modes for this one fixed cog control; this is not an actual/source/global exclusion. Do not keep the15 cogs fixed and expect greedy bracket insertion to solve the remaining packet. Next change the26-part core construction itself: review existing orthogonal-source rectangle decomposition helpers and previous mixed-core attempts, then formulate height minimization with all18 frames,3 brackets and5 inserts independently movable, all legal quarter/mirror modes, plus unchanged actual short15 (6 brackets,9 inserts). Unlike the earlier29-part frame/insert height call, this composition includes3 L brackets and moves the saved staggered anchors; its existing core reaches2167.875mm. Use complete filled source L geometry with correctly partitioned expanded rectangles (do not create overlapping same-owner padded components), exact source coverage and a fully valid current-core hint. Account explicitly for the25 remaining first-sheet originals and keep the current material target. Audit the entire model and source guards before declaring one bounded call; a partial core result never establishes full66 success. Rebuild owner-dependent regions only if a materially better source-valid core results. Existing fixed-core calls, finite-pose pools and29-part height call remain closed. No native/full H5 matrix without all66 source validity; preserve444 necessary allocations, the unchanged H2 gate and22 unopened reserved vectors. Main d71c9c85 CI40728382102 now has allsix jobs passing; push both verified queued checkpoints normally after fresh refs/live-run guards. No release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Independent placement around the staggered core — 2026-10-28

The changed-core construction passes its geometry and serialized-model checks,
but its sole search closes **UNKNOWN**. No complete 66-part placement or
infeasibility result follows. H2/H5 remain open at **60% completed milestone
weight**, and the previous valid64 remains the best partial layout.

The saved staggered arrangement contains 18 frames, three brackets and five
inserts on the first sheet, plus six brackets and nine inserts on the short
sheet. Independent original-source readback reconfirms these 41 parts, 430
same-sheet pairs, 164 stock edges and all 59 holes. All 25 remaining originals
are mandatory: brackets 5, 6 and 9; inserts 13–19; cogs 0–14. The gross material
target remains 4,988,890.353495 mm². Part-in-hole remains off.

Every fixed-neighbour placement region is rebuilt against the changed 26-part
first-sheet core. Only the exact unchanged source modes and 66 intrinsic pair
displacement domains are reused. The independent reader verifies 286 fixed
neighbour relations, 13,299 Minkowski hulls, all 77 domains, 1,153 convex cells
and 4,163 conservative integer halfplanes. The cog phase of 7° is a constructive
subset; brackets retain all eight legal modes and inserts both outer classes.
The old staggered 2,000-pose finite-pool exclusion is not resumed or broadened.

A positive control places fifteen cogs in three aligned rows at 258.90 mm pitch
above the fixed core, with independent anchors rounded to one micrometre.
Original-source verification passes **925 pairs, 224 stock edges and 74 holes /
8,074 hole vertices**, plus 15 occupied free cells and 105 relative cells.
Minimum gap is 0.224800281 mm and extra stock clearance 0.024800286 mm.
This is a 56-part control only; three brackets and seven inserts remain unplaced.

The placement model has **47,272 variables and 170,594 constraints**, including
50 independent coordinates, all 300 mover pairs, 1,287 mode-pair groups and
13,245 valid partial hints. It imposes no lattice or fixed mover coordinates.
The independent reader accounts for every variable, constraint and hint, and
checks all 66 copy identities across fixed and moving inventories.

Necessary source capacities add 2,942 interval constraints and two cumulatives,
for **173,538 total constraints**. The source proof checks 139 contained
rectangles, 7,592 source segments and 4,197 same-owner component pairs. Fixed
L brackets use two strictly contained components each; no bounding-box exclusion
is substituted for their source geometry. All 1,471 rectangle options and the
complete unchanged model prefix are audited. The valid control has 1,409 active
components and X/Y capacity slack of 107,517 / 7,024 µm.

Only the complete formulation is solved, once, with four workers, seed zero,
a 60-second solver limit and 90-second shared-process limit. It returns
**UNKNOWN**, 82,996 returned branches and 13,173 conflicts. Solver time is
60.052929 s, returned time 60.076915 s and shared time 61.555241 s. The returned
soft overrun of **0.076915 s** is retained. The response, parameters, model hashes,
log and timings are independently read back. There is no assignment to validate
and no native call.

A separate bounded diagnostic keeps this control fixed and constructs the ten
non-cog free regions. All eight bracket regions are empty under the conservative
construction; both insert regions are nonempty. An independent oracle checks
their source-clearance containment against 82 neighbour relations and 2,410
Minkowski hulls. Empty conservative regions are **not** an actual placement
exclusion. They do show why this particular control does not directly supply
the missing brackets through this construction.

The next step changes the core construction: independently move all 18 frames,
three L brackets and five inserts to reduce their current 2,167.875 mm top.
This differs from the closed height search for the 18-frame/11-insert core.
Review prior mixed-core attempts first, retain the actual short15 allocation,
prove coverage of correctly partitioned expanded L geometry, and validate the
entire model plus the saved positive core before any new bounded call. A better
partial core would still leave all 25 other originals as explicit obligations.

Main d71c9c85 now has **all six jobs passing** in run 40728382102. The previously
verified capacity/height commit 116b16d7 and this checkpoint may be pushed after
fresh remote-reference and live-run guards. Production and all READMEs are
unchanged. Sparrow remains 6f7b9d35 / v0.3.0; Studio remains c0bb9e86 without a
release. No stop rule fires, no reserved H2 vector is evaluated, and no new
release qualifies.

Evidence: [source regions]({NAME}/source-region-audit.json),
[source control]({NAME}/source-control-audit.json),
[complete model]({NAME}/complete-model-audit.json),
[response]({NAME}/response-audit.json),
[residual regions]({NAME}/residual-region-audit.json),
[next construction]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive contains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all source inputs, helpers, models and closed-call
records. Earlier evidence and failed attempts remain preserved.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 changed-core independent placement, 2026-10-28:** [the evidence]({link})
revalidates the staggered41 source core and a56-part cog control, rebuilds all
owner-dependent regions, and audits all25 mandatory movers /50 independent
coordinates. Necessary source-rectangle capacities bring the model to173,538
constraints. Its sole bounded call closes UNKNOWN; the0.076915s returned soft
overrun is retained. The saved control has no conservative bracket-insertion
region, which is not an actual/global exclusion. Next review and optimize the
26-part core composition itself (18 frames,3 brackets,5 inserts), with source
L geometry and the actual short15 preserved. Existing searches stay closed.
The best valid64,444-count frontier, H2 gate and22 unopened reserved vectors
remain unchanged. Main d71c9c85 now has allsix CI jobs passing; push verified
queued checkpoints after fresh guards. Production/READMEs and upstream releases
are unchanged. H2/H5 remain open at60%; no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'main_all6_pass':True,'completion_percent':60})
