from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-frontier-clique-consistency-20261104'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
selected=load(BR/'audit/mandatory-eight-clique-choices.json')
assert len(selected)==38 and len({r['choice_index'] for r in selected})==38
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');assert load(BR/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='conflict'];assert len(functions)==1
exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_consistency_helpers_20261104.py',BR/'audit/mandatory-eight-clique-choices.json',BR/'audit/remaining-fixed29-choices.json',HELPER,SOURCE/'geometry-domains.json',BR/'audit/plan.json',BR/'audit/checks.json']+[BR/f"choice-{selected[i]['choice_index']:02d}.json" for i in range(len(selected))]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Process all38 choices whose independently complete frontier audit has exactly eight bracket cliques. Every valid eight-bracket packing chooses one node from each of eight certified cliques. Repeatedly remove any active node that conflicts strictly with every currently active node of another mandatory clique. Preserve the complete ordered elimination trace and every exact source-inner overlap witness. An empty mandatory clique is a continuous contradiction only after independent replay. Otherwise no exclusion follows.',
    'preparation_cap_seconds':15,'maximum_process_seconds':25,'solver_calls':0,'native_calls':0})
records=[]
for i in range(len(selected)):
    br=load(BR/f"choice-{selected[i]['choice_index']:02d}.json");nodes=br['nodes'];assert br['bracket_capacity_upper_bound']==8
    active=[set(g['nodes']) for g in br['cliques']];trace=[];cache={};rounds=0
    def proof(a,b):
        key=(a,b)
        if key not in cache:cache[key]=conflict(nodes[a],nodes[b])
        return cache[key]
    while all(active):
        changed=False;rounds+=1
        for own in range(8):
            for node in sorted(active[own]):
                for other in range(8):
                    if other==own:continue
                    targets=sorted(active[other])
                    if targets and all(proof(node,b) is not None for b in targets):
                        trace.append({'node':node,'own_clique':own,'other_clique':other,'targets':[[b,*proof(node,b)] for b in targets]})
                        active[own].remove(node);changed=True;break
                if not active[own]:break
            if not all(active):break
        if not changed:break
    result={'source_choice_index':selected[i]['choice_index'],'empty_sites':br['empty_sites'],'ordered_removals':trace,'remaining_cliques':[sorted(g) for g in active],'rounds':rounds,'diagnostic_excluded':not all(active)}
    write(OUT/f'choice-{i:02d}.json',result);records.append({'empty_sites':br['empty_sites'],'removed_nodes':len(trace),'remaining_counts':[len(g) for g in active],'rounds':rounds,'diagnostic_excluded':not all(active)});print(records[-1],flush=True);assert time.perf_counter()-started<15
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':records,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
