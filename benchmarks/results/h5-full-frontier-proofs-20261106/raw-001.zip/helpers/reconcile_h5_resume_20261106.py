from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-resume-reconciliation-20261106'
BASE='f8ba0d955ddcc9e1fa34ae112777cace0b264f91';REMOTE='bb27a0fef77c6e481cef6919b0a77f6fc590a5c3'
def command(*args):return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert command('git','branch','--show-current')=='codex/v1-1-shop-files' and not command('git','diff','HEAD','--name-only')
local=command('git','rev-parse','HEAD');assert local==command('git','rev-parse','b5ddb644')
assert command('git','rev-parse','origin/main')==REMOTE
remote_paths=command('git','diff','--name-only',BASE+'..'+REMOTE).splitlines()
local_paths=command('git','diff','--name-only',BASE+'..'+local).splitlines()
assert len(remote_paths)==52 and not set(remote_paths)&set(local_paths)
remote_blobs={p:command('git','rev-parse',REMOTE+':'+p) for p in remote_paths}
local_blobs={p:command('git','rev-parse',local+':'+p) for p in local_paths}
ci=json.loads(command('gh','run','view','42094099320','--json','databaseId,status,conclusion,headSha,jobs,url'))
assert ci['headSha']==REMOTE and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
OUT.mkdir();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'script':Path(__file__).relative_to(ROOT).as_posix(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'base':BASE,'local':local,'remote':REMOTE})
write(OUT/'remote-main-ci.json',ci);write(OUT/'remote-files.json',remote_blobs);write(OUT/'local-files.json',local_blobs)
r=subprocess.run(['git','merge','--no-edit','origin/main'],cwd=ROOT,capture_output=True)
(OUT/'merge-stdout.txt').write_bytes(r.stdout);(OUT/'merge-stderr.txt').write_bytes(r.stderr);assert r.returncode==0,r.stderr
merged=command('git','rev-parse','HEAD')
for commit in [local,REMOTE]:subprocess.run(['git','merge-base','--is-ancestor',commit,merged],cwd=ROOT,check=True)
for files in [remote_blobs,local_blobs]:
    for p,h in files.items():assert command('git','rev-parse',merged+':'+p)==h,p
assert not command('git','diff','HEAD','--name-only')
record={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'merge_commit':merged,'local_parent':local,'remote_parent':REMOTE,'remote_files_preserved':len(remote_blobs),'local_files_preserved':len(local_blobs),'conflicts':0,'remote_main_all_six_pass':True,'remote_main_CI':42094099320,'product_core_changed':False,'push_performed':False}
write(OUT/'checks.json',record);print(record)
