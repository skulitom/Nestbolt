from pathlib import Path
O=Path(__file__).resolve().parent
for kind in ['prepare','audit','run']:
    old=f'{kind}_h5_mandatory_clique_consistency_20261104.py';s=(O/old).read_text(encoding='utf-8')
    s=s.replace('h5-first57-mandatory-clique-consistency','h5-first57-frontier-clique-consistency').replace('h5-first57-local-conflict-covers','h5-first57-full-frontier-cliques')
    s=s.replace('prepare_h5_mandatory_clique_consistency_20261104.py','prepare_h5_frontier_clique_consistency_20261104.py')
    if kind!='run':
        marker="load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()\n"
        s=s.replace(marker,marker+"""selected=load(BR/'audit/mandatory-eight-clique-choices.json')
assert len(selected)==38 and len({r['choice_index'] for r in selected})==38
""")
        s=s.replace('for i in range(3)','for i in range(len(selected))')
        s=s.replace("BR/f'choice-{i:02d}.json'",'BR/f"choice-{selected[i][\'choice_index\']:02d}.json"')
        s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_consistency_helpers_20261104.py',BR/'audit/mandatory-eight-clique-choices.json',BR/'audit/remaining-fixed29-choices.json',")
        s=s.replace("assert data['empty_sites']==br['empty_sites']","assert data['empty_sites']==br['empty_sites']==selected[i]['empty_sites']")
        s=s.replace("'empty_sites':br['empty_sites'],'ordered_removals'","'source_choice_index':selected[i]['choice_index'],'empty_sites':br['empty_sites'],'ordered_removals'")
        if kind=='audit':
            marker="inputs=[Path(__file__),"
            at=s.index(marker)
            s=s[:at]+"""prior=load(BR/'audit/remaining-fixed29-choices.json');assert len(prior)==105
excluded={tuple(r['empty_sites']) for r in records if r['excluded']}
remaining=[r for r in prior if tuple(r['empty_sites']) not in excluded]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'consistent-mandatory-choices.json',[{'consistency_index':i,**selected[i]} for i,r in enumerate(records) if not r['excluded']])
"""+s[at:]
            s=s.replace("'whole_allocations_excluded':0","'previous_fixed29_choices_excluded':350,'remaining_fixed29_choices':len(remaining),'total_fixed29_choices_excluded':350+len(excluded),'whole_allocations_excluded':0")
        else:
            s=s.replace("'method':'","'method':'Process all38 choices whose independently complete frontier audit has exactly eight bracket cliques. ")
    with (O/f'{kind}_h5_frontier_clique_consistency_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared complete38-choice mandatory-clique consistency and independent elimination replay.')
