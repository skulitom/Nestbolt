from pathlib import Path
O=Path(__file__).resolve().parent
for kind in ['prepare','audit','run']:
    old=f'{kind}_h5_local_conflict_covers_20261104.py';s=(O/old).read_text(encoding='utf-8')
    s=s.replace('h5-first57-local-conflict-covers','h5-first57-full-frontier-cliques')
    s=s.replace('prepare_h5_local_conflict_covers_20261104.py','prepare_h5_full_frontier_cliques_20261104.py')
    if kind=='run':
        s=s.replace('35','45').replace("print(stdout.decode(errors='replace'))","print(stdout.decode(errors='replace').splitlines()[-1:] if stdout else '')")
    else:
        marker="load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()\n"
        assert marker in s
        s=s.replace(marker,marker+"""FRONTIER=ROOT/'output/h5-first57-joint-clique-distributions-20261104/audit'
assert load(FRONTIER/'checks.json')['passed']
frontier=load(FRONTIER/'remaining-fixed29-choices.json')
selected=[r['empty_sites'] for r in frontier]
assert len(selected)==len(set(map(tuple,selected)))==256
""")
        s=s.replace("inputs=[Path(__file__)]","inputs=[Path(__file__),ROOT/'output/prepare_h5_full_frontier_clique_helpers_20261104.py',FRONTIER/'plan.json',FRONTIER/'checks.json',FRONTIER/'remaining-fixed29-choices.json']")
        s=s.replace("inputs=[Path(__file__),BASE","inputs=[Path(__file__),ROOT/'output/prepare_h5_full_frontier_clique_helpers_20261104.py',FRONTIER/'plan.json',FRONTIER/'checks.json',FRONTIER/'remaining-fixed29-choices.json',BASE")
        s=s.replace('enumerate([[0,4,14],[5,11,13],[5,11,14]])','enumerate(selected)')
        s=s.replace('For the three declared fixed29/cog choices','For all256 independently retained fixed29/cog choices')
        s=s.replace("'choices':[[0,4,14],[5,11,13],[5,11,14]]","'choices':selected")
        s=s.replace("'preparation_cap_seconds':25,'maximum_process_seconds':35","'preparation_cap_seconds':35,'maximum_process_seconds':45")
        s=s.replace('time.perf_counter()-started<25','time.perf_counter()-started<35').replace('range(3)]+','range(256)]+')
        if kind=='audit':
            marker="inputs=[Path(__file__),"
            at=s.index(marker)
            s=s[:at]+"""excluded={tuple(r['empty_sites']) for r in checks if r['excluded']}
remaining=[r for r in frontier if tuple(r['empty_sites']) not in excluded]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'mandatory-eight-clique-choices.json',[{'choice_index':i,'empty_sites':r['empty_sites'],'nodes':r['nodes']} for i,r in enumerate(checks) if r['every_clique_mandatory_for_eight_brackets']])
"""+s[at:]
            s=s.replace("'whole_allocations_excluded':0","'previous_fixed29_choices_excluded':199,'remaining_fixed29_choices':len(remaining),'total_fixed29_choices_excluded':199+len(excluded),'whole_allocations_excluded':0")
    with (O/f'{kind}_h5_full_frontier_cliques_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared complete256-choice bracket clique proof and independent replay under frozen35/45s preparation caps.')
