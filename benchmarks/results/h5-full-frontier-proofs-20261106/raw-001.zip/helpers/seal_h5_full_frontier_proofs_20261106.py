from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-full-frontier-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
FULL=ROOT/'output/h5-first57-full-frontier-cliques-20261104'
CONSISTENT=ROOT/'output/h5-first57-frontier-clique-consistency-20261104'
SYNC=ROOT/'output/h5-resume-reconciliation-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
full=load(FULL/'audit/checks.json');consistent=load(CONSISTENT/'audit/checks.json')
assert full['passed'] and full['new_site_choices_excluded']==151 and full['remaining_fixed29_choices']==105
assert consistent['passed'] and consistent['new_site_choices_excluded']==18 and consistent['remaining_fixed29_choices']==87
assert len(load(CONSISTENT/'audit/consistent-mandatory-choices.json'))==20
assert load(SYNC/'checks.json')['passed'] and load(SYNC/'checks.json')['remote_files_preserved']==52
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py';tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
folders=[FULL,CONSISTENT,SYNC]+[ROOT/'output'/f'h5-first57-{stem}-process-20261104' for stem in ['full-frontier-cliques','frontier-clique-consistency']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_full_frontier*20261104.py','*h5_frontier*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,
    'h5-full-frontier-proofs-report-20261106.md','reconcile_h5_resume_20261106.py',
    'prepare_h5_local_conflict_covers_20261104.py','audit_h5_local_conflict_covers_20261104.py',
    'prepare_h5_mandatory_clique_consistency_20261104.py','audit_h5_mandatory_clique_consistency_20261104.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(FULL/'audit/checks.json','full-frontier-audit.json'),(CONSISTENT/'audit/checks.json','consistency-audit.json'),
    (CONSISTENT/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(CONSISTENT/'audit/consistent-mandatory-choices.json','consistent-mandatory-choices.json'),
    (SYNC/'checks.json','reconciliation.json'),(SYNC/'remote-main-ci.json','remote-main-ci.json')]:shutil.copyfile(source,OUT/name)
processes=[load(folder/'process.json') for folder in folders[-2:]]
assert all(p['exit_code']==0 and p['closed'] and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
write(OUT/'process-ledger.json',{'complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),'processes':processes,'independent_audit_seconds':[full['seconds'],consistent['seconds']],'placement_solver_calls':0,'native_calls':0})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'remaining_fixed29_choices':87,'total_fixed29_choices_excluded':368,'mandatory_eight_clique_survivors':20,'larger_clique_bound_survivors':67,
    'next_method':'Apply source-certified insert-cell pruning against all eight remaining mandatory bracket cliques for each of the20 consistency survivors. Independently verify complete continuous insert coverage and every removed-cell/clique certificate. Construct insert conflict cliques; a bound below eight excludes the choice. For larger bounds, enumerate every eight-of-k selection only within a frozen bounded process, retaining incomplete or unresolved cases. Every final continuous exclusion requires independent ordered-removal replay for all selections. No prior placement model may be rerun.',
    'survivor_mapping':'output/h5-first57-frontier-clique-consistency-20261104/audit/consistent-mandatory-choices.json',
    'bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104','bracket_consistency':'output/h5-first57-frontier-clique-consistency-20261104',
    'insert_proof_example':'output/prepare_h5_consistent_insert_bounds_20261104.py','joint_proof_example':'output/prepare_h5_joint_clique_distributions_20261104.py',
    'new_followup_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'new_continuous_choices_excluded':169,'remaining_fixed29_choices':87,'total_fixed29_choices_excluded':368,'original_fixed29_choices':455,
    'full_frontier_cells':43535,'full_frontier_pair_certificates':1027915,'consistency_removals':4711,'consistency_pair_certificates':60792,
    'remote_files_preserved':52,'placement_solver_calls':0,'native_calls':0,'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-full-frontier-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 complete frontier proof and resumed reconciliation:** [the saved pre-pause audits]({link}) exclude 151 of 256 fixed29/cog choices through complete continuous bracket-clique bounds (43,535 cells and 1,027,915 strict source-inner pair certificates). Mandatory-clique consistency excludes another 18 of the 38 eight-clique choices (4,711 ordered removals, 60,792 pair certificates). The frontier is now 87, with 368 of 455 choices excluded; 20 have mandatory eight-clique survivors for the next insert proof. Complete preparation is 22.574358 + 0.752594 s, with no overruns, placement solver calls or native calls. All 52 remote README/comparison/navigation files from main bb27a0fe are preserved in the conflict-free reconciliation; all six main checks and Pages pass. Whole allocations remain 440 and H2/H5 remain open at 60%. No closed run was repeated.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
s=s.replace('# Status — 2026-11-04','# Status — 2026-11-06',1)
a='Repository reconciliation preserves main\'s new ornament example and README.'
b='Repository reconciliation preserves main\'s ornament example, agent setup,\nLightBurn/offcut comparison and shared site navigation, including all 52 files\nadded or updated during the pause.'
assert s.count(a)==1;s=s.replace(a,b,1)
a='Latest H5 evidence: [mandatory-clique continuous exclusions](../benchmarks/results/h5-mandatory-clique-exclusions-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [complete frontier proof](../benchmarks/results/{NAME}.md).',1)
a='contradictions. The broader fixed29 frontier now has 256 choices (199 of 455\nexcluded). Extending the complete bracket-clique bound to those survivors is\nnext. All prior calls stay closed.'
b='contradictions. Extending the complete bracket-clique proof excludes another\n151 choices; mandatory consistency excludes 18 more. The broader fixed29\nfrontier now has 87 choices (368 of 455 excluded). Insert pruning for the\n20 surviving eight-clique choices is next. All prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
