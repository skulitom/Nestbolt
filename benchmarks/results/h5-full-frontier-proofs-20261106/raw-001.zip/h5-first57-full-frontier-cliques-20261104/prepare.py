"""Exact source-inner conflict cliques over a complete continuous anchor cover."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-full-frontier-cliques-20261104'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
FRONTIER=ROOT/'output/h5-first57-joint-clique-distributions-20261104/audit'
assert load(FRONTIER/'checks.json')['passed']
frontier=load(FRONTIER/'remaining-fixed29-choices.json')
selected=[r['empty_sites'] for r in frontier]
assert len(selected)==len(set(map(tuple,selected)))==256
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [SOURCE,COVER]:assert load(base/'audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/prepare_h5_full_frontier_clique_helpers_20261104.py',FRONTIER/'plan.json',FRONTIER/'checks.json',FRONTIER/'remaining-fixed29-choices.json']+[b/n for b in [SOURCE,COVER] for n in ['audit/plan.json','audit/checks.json']]+[SOURCE/'geometry-domains.json']+[COVER/f'geometry-{g:02d}-cover.json' for g in range(8)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'For all256 independently retained fixed29/cog choices, subdivide every eligible continuous necessary bracket anchor box into closed Cartesian cells of width/height at most50mm. Declare two nodes conflicting only when a pair of complete source-inner rectangles overlaps strictly for every pair of anchors. Require every node to conflict with itself. Construct deterministic greedy clique partitions of the conflict graph; every clique can contain at most one actual bracket. An independent complete-cover and exact pair-inequality audit is required before using a clique-count upper bound.',
    'choices':selected,'maximum_cell_extent_um':50000,'required_brackets':8,
    'preparation_cap_seconds':35,'maximum_process_seconds':45,'solver_calls':0,'native_calls':0})
geometry=load(SOURCE/'geometry-domains.json');covers=[load(COVER/f'geometry-{g:02d}-cover.json') for g in range(8)]
def intervals(a,b):
    points=list(range(a,b,50000))+[b]
    if len(points)==1:points.insert(0,a)
    return list(zip(points,points[1:]))
def conflict(a,b):
    ax,ay,az,aw=a['bounds_um'];bx,by,bz,bw=b['bounds_um']
    for ai,(u,v,w,z) in enumerate(geometry[a['geometry']]['inner_rectangles_um']):
        for bi,(p,q,r,s) in enumerate(geometry[b['geometry']]['inner_rectangles_um']):
            if az+u<bx+r and bz+p<ax+w and aw+v<by+s and bw+q<ay+z:return [ai,bi]
    return None
def first_fit(order,adj):
    groups=[];masks=[]
    for v in order:
        possible=[i for i,m in enumerate(masks) if m&~adj[v]==0]
        if possible:
            i=max(possible,key=lambda i:(masks[i].bit_count(),-i));groups[i].append(v);masks[i]|=1<<v
        else:groups.append([v]);masks.append(1<<v)
    return groups
def saturation_cover(adj):
    n=len(adj);groups=[];masks=[];unassigned=set(range(n))
    while unassigned:
        v=max(unassigned,key=lambda v:(sum(bool(m&~adj[v]) for m in masks),n-adj[v].bit_count(),-v))
        possible=[i for i,m in enumerate(masks) if m&~adj[v]==0]
        if possible:
            i=max(possible,key=lambda i:(len(groups[i]),-i));groups[i].append(v);masks[i]|=1<<v
        else:groups.append([v]);masks.append(1<<v)
        unassigned.remove(v)
    return groups
summaries=[]
for choice,empty in enumerate(selected):
    bits=sum(1<<i for i in empty);nodes=[]
    for gid,cover in enumerate(covers):
        for ri,(mask,x,y,z,w,*_) in enumerate(cover):
            if mask&~bits:continue
            for xi,(l,r) in enumerate(intervals(x,z)):
                for yi,(b,t) in enumerate(intervals(y,w)):
                    nodes.append({'node':len(nodes),'geometry':gid,'cover_box':ri,'cell':[xi,yi],'bounds_um':[l,b,r,t]})
    n=len(nodes);adj=[1<<i for i in range(n)];self_cert=[]
    for i,a in enumerate(nodes):
        proof=conflict(a,a);assert proof is not None;self_cert.append(proof)
        for j in range(i):
            if conflict(a,nodes[j]) is not None:adj[i]|=1<<j;adj[j]|=1<<i
    orders=[list(range(n)),list(reversed(range(n))),sorted(range(n),key=lambda v:(adj[v].bit_count(),v)),sorted(range(n),key=lambda v:(-adj[v].bit_count(),v))]
    attempts=[first_fit(order,adj) for order in orders]+[saturation_cover(adj)]
    best=min(range(len(attempts)),key=lambda i:(len(attempts[i]),i));groups=attempts[best]
    cert=[]
    for group in groups:
        pairs=[]
        for k,a in enumerate(group):
            for b in group[k+1:]:
                proof=conflict(nodes[a],nodes[b]);assert proof is not None;pairs.append([a,b,*proof])
        cert.append({'nodes':group,'strict_overlap_certificates':pairs})
    write(OUT/f'choice-{choice:02d}.json',{'empty_sites':empty,'nodes':nodes,'self_certificates':self_cert,'candidate_cover_counts':[len(g) for g in attempts],
        'selected_cover':best,'cliques':cert,'bracket_capacity_upper_bound':len(groups),'diagnostic_excluded':len(groups)<8})
    row={'empty_sites':empty,'nodes':n,'candidate_cover_counts':[len(g) for g in attempts],'upper_bound':len(groups),'diagnostic_excluded':len(groups)<8}
    summaries.append(row);print(row,flush=True);assert time.perf_counter()-started<35
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
