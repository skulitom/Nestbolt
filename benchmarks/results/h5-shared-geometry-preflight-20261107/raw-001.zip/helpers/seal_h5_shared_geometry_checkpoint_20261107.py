"""Archive exact shared-row selector equivalence, timing and deadline controls."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-shared-geometry-preflight-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-shared-geometry-preflight-20261107';F=BASE;D=BASE",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-tiered-source-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['timed_calls']==20 and front['optimizer_calls']==0 and front['actual_latest_geometry_constructions']==2342",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-shared-geometry-preflight-process-20261107',ROOT/'output/h5-tiered-source-main-sync-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*shared*geometry*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_shared_geometry_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json')":"load(F/'plan.json')['inputs']",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(ROOT/'output/h5-two-center-preflight-20261107/runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
for name in ['checks','plan','timings','complete-tier-controls','geometry-reuse-controls','changed-context-controls','twenty-one-key-control','deadline-controls','different-best-fallback-controls','snapshot-isolation-controls','stale-cache-controls','policy-controls','main-ci-at-review']:
    shutil.copyfile(BASE/(name+'.json'),OUT/('selector-audit.json' if name=='checks' else name+'.json'))
shutil.copyfile(ROOT/'output/h5-shared-geometry-preflight-process-20261107/process.json',OUT/'preflight-process.json')
shutil.copyfile(ROOT/'output/h5-tiered-source-main-sync-20261107/receipt.json',OUT/'prior-main-push-receipt.json')
shutil.copyfile(PARENT/'closed-problems.json',OUT/'closed-problems.json')
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k!='passed'}})
process=load(OUT/'preflight-process.json');assert process['passed'] and process['job']['closed'] and process['job']['active_processes']==0
ci=load(OUT/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'next-step.json',{'status':'shared_row_original_source_and_budget_preflight_required',
'finding':'The shared-row selector preserves every complete primary/extended field in the original-source and earlier closed-runtime contexts, and every primary field in the latest independently audited runtime context. Changed-context, constructor count, snapshot, cache and deadline controls pass. The twenty fixed-order full-selector timings are retained; two samples per variant do not establish stable runtime or packing validity.',
'proposal':'Prepare a fresh original-source primary-tier initializer under all21closed keys, with exact source payload/context checks, and independently verify its full model and original-source output. Retain every preparation cost and combine measured shared-selector/output/model/source costs before freezing any new finite search contract. No optimized or validation state may seed that model. No new initializer or search is prepared by this checkpoint.',
'requirements':['Keep all21closed objective/physical-mode/weight keys and previous finite pipeline stops. Faster code cannot reopen any old problem or extend its deadline/count.','Preserve the invocation-local immutable raw-row cache and copy before owner masking. Keep nominal modes and exact float keys, all9102trials/111modes,5911primary/23419extended proposals,2854keys,528weighted areas,15auxiliary terms,33movers/15angles and strict1e-6improvement.','Use only original unoptimized A/W source data for future initialization; retain37.6806913993787s source preparation plus all new work. Changed runtime geometry must recalculate in a fresh invocation.','Measure and independently verify full source preparation, model/output/source costs and complete finite60/90s2GiB budget. Timing improvements do not promise a second optimizer call or permit a partial tier to select.','H5 still requires full66source validity, native/material evidence, production parity and its original matrix. Four fixed arrangements and440allocation candidates remain unresolved.'],
'closed_problem_keys':21,'source_only_preparation_seconds_before_new_work':37.6806913993787,'shared_row_selector_prepared':True,'new_source_state_prepared':False,'new_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
table='\n'.join(f"| {r['context']} | {r['tier']} | {r['old_mean_seconds']:.6f} | {r['shared_mean_seconds']:.6f} | {r['observed_mean_seconds_saved']:.6f} |" for r in front['timing_summary'])
report=f'''# Shared geometry selector preflight — 2026-11-07

The separate selector reuses identical center geometry and raw intersection rows
inside **one unchanged invocation**. Complete outputs match the independently
audited references exactly. It has made **no optimizer call** and supplies no new
packing result. H2/H5 remain open at **60% completed milestone weight**; the last
construction still has 51 failing source pairs.

The cache key retains the exact family, nominal mode, angle and center float bit
patterns. Raw arrays are read-only. Each owner receives a copied row before its own
self-intersection column is zeroed; owner-dependent auxiliary calculations remain
unchanged. Deep-copied input/context snapshots and public result isolation remain.
There is no cache shared between invocations or changed runtime contexts.

[Complete equivalence]({NAME}/complete-tier-controls.json) covers all 5,911 primary
and 23,419 extended proposals in the original-source and earlier closed-runtime
contexts, plus all 5,911 primary proposals in the latest closed runtime. The latest
runtime's unmeasured full extension is not claimed independently audited here.
All 2,854 key minima, raw scores, 9,102 center trials, 111 physical mode choices,
aliases, ranks, exclusion fields and canonical sequence IDs match. Independent
score references cover **80,055 center/proposal scores** across the declared scopes.

[Constructor observation]({NAME}/geometry-reuse-controls.json) confirms the new
implementation builds exactly **2,342** distinct center geometries in the latest
runtime context, matching keys reconstructed from the 9,102 recorded trials.
The corresponding old calculation has 9,066 unique owner/mode centers. No constructor
instrumentation is used in timed calls. [Three changed-context controls]({NAME}/changed-context-controls.json)
vary coordinates/angle, weights and nominal mode in successive invocations; every
primary field still matches the original implementation.

[All twenty-one closures]({NAME}/twenty-one-key-control.json) remain excluded.
[Twenty-six synthetic and three real deadlines]({NAME}/deadline-controls.json) cover
cached/uncached primary and extension phases. An incomplete primary selects nothing;
an incomplete or ungrouped extension retains only the completed primary choice.
[Two different-best cases]({NAME}/different-best-fallback-controls.json) confirm
that a better partial-extension proposal cannot displace that primary choice.
[Snapshot and one-shot controls]({NAME}/snapshot-isolation-controls.json),
[six stale-cache rejections]({NAME}/stale-cache-controls.json) and
[membership/no-candidate policies]({NAME}/policy-controls.json) pass.

[Full selector plus grouping times]({NAME}/timings.json), in seconds:

| Context | Tier | Previous mean | Shared-row mean | Observed saving |
| --- | --- | ---: | ---: | ---: |
{table}

Each row uses the fixed old/shared/shared/old order, with two samples per variant.
Input/context/public copies, cache creation, complete geometry/scoring and grouping
are timed. Output serialization and source/model verification remain outside these
measurements. The observations do not establish stable runtime or statistical
significance. The [bounded preflight]({NAME}/preflight-process.json) closes normally
in {process['complete_seconds']:.6f} s, with peak committed memory
{process['job']['peak_job_committed_memory']:,} bytes under its 600 s / 2 GiB cap.

[Next]({NAME}/next-step.json), prepare and independently validate an original-source
initializer under all twenty-one closed keys, charging the retained 37.680691 s plus
every new preparation cost. Assess actual preparation/output/model/source costs
before freezing a fresh finite contract. No initializer, search contract, native
call or allocation exclusion is prepared here. Four arrangements and all 440
allocation candidates remain unresolved.

The two preceding tier checkpoints reached main **ddf2310d** after all six preceding
CI checks passed, preserving 52 protected files. [The receipt]({NAME}/prior-main-push-receipt.json)
and [current CI snapshot]({NAME}/main-ci-at-review.json) are retained
({success} passed, {live} live at review). Product code, README and releases remain
unchanged. This evidence checkpoint awaits the next ordinary push gate.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 shared geometry selector preflight:** [complete equivalence and bounded timing evidence]({{link}}) verifies all primary/extended outputs in source and earlier runtime contexts, plus primary outputs in the latest independently audited runtime. All 2,854 key minima per tier and references for 80,055 scores remain bound. The implementation constructs exactly 2,342 distinct latest-context geometries, with copied owner-specific rows and unchanged auxiliary terms. Three changed-context cases, 26 synthetic / 3 real deadlines, two different-best fallbacks, isolation, one-shot extension, six stale caches and membership policies pass. Twenty fixed-order timings preserve full selector cost and variability without a packing claim. Next prepare and independently audit an original-source initializer and budget under all 21 closed keys; retain 37.680691 s prior preparation plus new work. No new optimizer call, initializer or search is prepared. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. The two prior checkpoints reached main ddf2310d after all six previous checks passed, preserving 52 files. Fresh CI has {success} passed / {live} live at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [shared geometry selector preflight](../benchmarks/results/{NAME}.md).
The invocation-local raw-row cache preserves every complete primary/extended field
in source and earlier runtime contexts, plus primary fields in the latest runtime.
All 2,854 key minima per tier and references for 80,055 scores are retained. Actual
latest-context shape construction falls to 2,342 exact geometries. Changed-context,
deadline, fallback, isolation, stale-cache and membership controls pass. Twenty
fixed-order whole-selector timings are recorded without a packing claim.
Next independently prepare an original-source initializer and budget under all 21
closed keys, retaining 37.680691 s prior preparation plus new work. No initializer
or search is prepared. The last layout remains invalid with 51 failed pairs.
Four arrangements and 440 allocations remain; H2/H5 stay at 60%. The prior two
checkpoints reached main ddf2310d after all six previous checks passed, preserving
52 files. Fresh CI has {success} passed / {live} live jobs at review. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
