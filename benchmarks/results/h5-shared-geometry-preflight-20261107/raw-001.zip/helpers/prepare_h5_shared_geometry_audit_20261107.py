"""Freeze full-output ABBA comparison and inherited tier/timeout isolation controls."""
from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_tiered_preflight_20261107.py').read_text(encoding='utf-8')
def change(a,b):
    global s
    assert a in s,a
    s=s.replace(a,b)
change('from h5_tiered_neighbors_20261107 import primary,SelectionDeadline','from h5_shared_geometry_neighbors_20261107 import primary,SelectionDeadline')
change('from h5_tiered_selection_20261107 import select','from h5_shared_geometry_selection_20261107 import select\nfrom h5_tiered_selection_20261107 import select as old_select')
change("OUT=ROOT/'output/h5-tiered-selector-preflight-20261107'","OUT=ROOT/'output/h5-shared-geometry-preflight-20261107'")
change("P=ROOT/'benchmarks/results/h5-indexed-source-construction-20261107'","P=ROOT/'benchmarks/results/h5-tiered-source-construction-20261107';Z=ROOT/'output/h5-tiered-source-preflight-20261107'")
change("inputs=[Path(__file__),", "inputs=[Path(__file__),ROOT/'output/prepare_h5_shared_geometry_helpers_20261107.py',ROOT/'output/h5_shared_geometry_neighbors_20261107.py',ROOT/'output/h5_shared_geometry_selection_20261107.py',ROOT/'output/h5_shared_geometry_timing_controls_20261107.py',")
change("write(OUT/'plan.json'", "inputs+=[Z/n for n in ['search/epoch-01/opened.json','search/epoch-01/weight-transition.json','search/epoch-01/neighbors.json','search/epoch-01/owner-aliases.json','search/epoch-01/center-trials.json','search/epoch-01/center-selections.json','response-audit/checks.json','response-audit/epoch-01-selection/checks.json','response-audit/epoch-01-selection/proposal-score-controls.json','shared-center-diagnostic/checks.json']]\nassert load(Z/'response-audit/checks.json')['passed'] and load(Z/'response-audit/epoch-01-selection/checks.json')['passed']\nwrite(OUT/'plan.json'")
start=s.index("'method':'Complete first-center");end=s.index(",'primary_deadline_checkpoints'",start)
method='Invocation-local shared exact raw geometry rows keyed by family, nominal mode, angle and center float bit patterns. Copy before owner-specific masking; do not change auxiliary calculations, scoring, ranking, tier membership, snapshots or deadline placement. Fixed old/shared/shared/old timing for primary and extended tiers on independently checked source and earlier runtime full references, plus primary only on the latest independently checked runtime reference. Verify every key minimum, actual2342shape constructions, three changed successive contexts, all21closed source keys, six stale caches, snapshot isolation, one-shot extension,26cached/full synthetic deadlines and three real deadlines, plus two different-best fallback cases. No optimizer, source initializer or search.'
s=s[:start]+"'method':"+repr(method)+",'timing_order':['old','shared','shared','old']"+s[end:]
change('assert len(actual_closed)==19','assert len(actual_closed)==21')
start=s.index('timings=[];controls=[];contexts={}');end=s.index("one,first_choice,first_groups,first_minima,full_choice,full_groups,full_minima,oracle=contexts['source']",start)
s=s[:start]+(O/'h5_shared_geometry_timing_controls_20261107.py').read_text(encoding='utf-8')+'\n'+s[end:]
change("'nineteen-key-control.json'","'twenty-one-key-control.json'")
change("'closed_keys':19","'closed_keys':21")
start=s.index('timing_summary=[]');s=s[:start]+'''timing_summary=[]
for label,tier in [('source','primary'),('source','extended'),('runtime','primary'),('runtime','extended'),('latest_runtime','primary')]:
    old=[r['selector_and_grouping_seconds'] for r in timings if r['context']==label and r['tier']==tier and r['kind']=='old'];new=[r['selector_and_grouping_seconds'] for r in timings if r['context']==label and r['tier']==tier and r['kind']=='shared'];assert len(old)==len(new)==2
    timing_summary.append({'context':label,'tier':tier,'old_seconds':old,'shared_seconds':new,'old_mean_seconds':sum(old)/2,'shared_mean_seconds':sum(new)/2,'observed_mean_seconds_saved':(sum(old)-sum(new))/2,'samples_per_variant':2,'statistical_significance_claimed':False})
assert len(timings)==20
write(OUT/'checks.json',{'passed':True,'complete_seconds':time.perf_counter()-started,'complete_full_validation_contexts':2,'additional_primary_validation_contexts':1,'timed_calls':len(timings),'timing_summary':timing_summary,'raw_scores_bound_to_independent_references':80055,'primary_records_per_context':5911,'extended_records_per_full_context':23419,'key_minima_per_tier':2854,'twenty_one_closed_keys_checked':True,'actual_latest_geometry_constructions':2342,'changed_context_controls':3,'synthetic_deadline_cases':26,'real_deadline_cases':3,'different_best_fallback_cases':2,'snapshot_isolation_passed':True,'one_shot_extension_passed':True,'stale_cache_rejections':len(stale),'policy_tiers':2,'mixed_tier_rejected':True,'optimizer_calls':0,'new_source_state_prepared':False,'new_search_contract_prepared':False,'prior_closed_pipelines_resumed':False,'validation_only':True,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
'''
with (O/'audit_h5_shared_geometry_preflight_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_tiered_preflight_stage_20261107.py').read_text(encoding='utf-8').replace('audit_h5_tiered_preflight','audit_h5_shared_geometry_preflight').replace('h5-tiered-{stage}','h5-shared-geometry-{stage}')
with (O/'run_h5_shared_geometry_preflight_stage_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
