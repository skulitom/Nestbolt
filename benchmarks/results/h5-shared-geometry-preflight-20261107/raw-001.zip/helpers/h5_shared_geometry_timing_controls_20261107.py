# Full timed equivalence against two independently checked full contexts and one primary context.
zopen=load(Z/'search/epoch-01/opened.json');latest_args=[lib,zopen['incoming_modes'],zopen['incoming_values'],load(Z/'search/epoch-01/weight-transition.json')['after'],identity,regions,set(zopen['visited_keys'])]
latest_primary=load(Z/'search/epoch-01/neighbors.json');latest_aux=tuple(load(Z/'search/epoch-01'/n) for n in ['owner-aliases.json','center-trials.json','center-selections.json'])
timings=[];controls=[];contexts={}
cases=[('source',source_args,source_full,source_aux,V/'audit/selection-replay/proposal-score-controls.json',True),('runtime',runtime_args,runtime_full,runtime_aux,X/'response-audit/epoch-01-partial-reference/proposal-score-controls.json',True),('latest_runtime',latest_args,latest_primary,latest_aux,Z/'response-audit/epoch-01-selection/proposal-score-controls.json',False)]
for label,args,reference,aux,oracle_path,has_full in cases:
    one=first_subset(reference,aux[2]) if has_full else reference
    assert len(one)==5911 and tuple(r['sequence'] for r in one)==PRIMARY_SEQUENCES
    oracle_rows=load(oracle_path);oracle={r['sequence']:r['augmented_objective_mm2'] for r in oracle_rows};maximum=0.
    for a,b in zip(reference,oracle_rows):
        assert a['sequence']==b['sequence']
        for field in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2','unweighted_objective_mm2']:
            error=abs(a[field]-b[field]);maximum=max(maximum,error);assert error<1e-6
    first_choice,first_groups,first_minima,first_near=independent_choice(one,oracle)
    assert dict(Counter(map(len,first_groups.values())))=={562:1,33:78,1:2775}
    full_choice=full_groups=full_minima=None;full_near=[]
    if has_full:
        full_choice,full_groups,full_minima,full_near=independent_choice(reference,oracle)
        assert dict(Counter(map(len,full_groups.values())))=={2179:1,130:78,4:2775}
    contexts[label]=(one,first_choice,first_groups,first_minima,full_choice,full_groups,full_minima,oracle)
    for tier in ['primary','extended'] if has_full else ['primary']:
        for sequence,kind in enumerate(['old','shared','shared','old']):
            gc.collect();before=time.perf_counter();fn=old_select if kind=='old' else select
            result=fn(*args,primary_deadline=before+45,extension_deadline=before+45 if tier=='extended' else None,cached_trials=None);elapsed=time.perf_counter()-before
            assert result['primary']=={'records':one,'selection':first_choice,'groups':first_groups,'minima':first_minima} and tuple(result[n] for n in ['aliases','trials','selections'])==aux
            if tier=='extended':assert result['status']=='EXTENDED_COMPLETE' and result['extended']=={'records':reference,'selection':full_choice,'groups':full_groups,'minima':full_minima} and result['selected_proposal']==full_choice['accepted_choice']
            else:assert result['status']=='PRIMARY_COMPLETE' and result['selected_proposal']==first_choice['accepted_choice'] and result['extended'] is None
            timings.append({'context':label,'tier':tier,'sequence':sequence,'kind':kind,'selector_and_grouping_seconds':elapsed,'exact_output':True});print(timings[-1],flush=True);del result
    write(OUT/(label+'-primary-records.json'),one);write(OUT/(label+'-primary-minima.json'),first_minima);write(OUT/(label+'-primary-choice.json'),first_choice);write(OUT/(label+'-near-ties.json'),{'primary':first_near,'extended':full_near})
    controls.append({'context':label,'primary_records':5911,'extended_records':23419 if has_full else None,'key_minima_per_tier':2854,'primary_complete_sha256':fingerprint(one),'extended_complete_sha256':fingerprint(reference) if has_full else None,'independent_score_reference_max_error_mm2':maximum,'primary_near_ties':len(first_near),'extended_near_ties':len(full_near) if has_full else None,'full_extension_independently_checked':has_full,'all_ABBA_outputs_exact':True})
write(OUT/'timings.json',timings);write(OUT/'complete-tier-controls.json',controls)

# Count the actual geometry constructor calls without instrumenting the timed runs.
import h5_shared_geometry_neighbors_20261107 as shared_module
from h5_bracket_augmented_objective_20261107 import compile_model
original_constructor=shared_module.owner_shapes;constructed=[]
def observed_shapes(library,family,mi,center,angle):
    constructed.append((family,mi,float(angle).hex(),tuple(float(v).hex() for v in center)))
    return original_constructor(library,family,mi,center,angle)
shared_module.owner_shapes=observed_shapes
try:result=select(*latest_args,primary_deadline=time.perf_counter()+45,cached_trials=None)
finally:shared_module.owner_shapes=original_constructor
assert result['status']=='PRIMARY_COMPLETE' and result['primary']['records']==latest_primary and len(constructed)==len(set(constructed))==2342
model=compile_model(lib,latest_args[1],latest_args[2],latest_args[3],identity);expected_keys=set()
for row in latest_aux[1]:
    i=row['owner'];family=lib['identities'][i][0];angle=latest_args[2][model['owners'][i]['angle_coordinate']]/lib['angle_scale_mm'] if family=='cog' else 0.
    expected_keys.add((family,row['mode'],float(angle).hex(),tuple(float(v).hex() for v in row['center'])))
assert set(constructed)==expected_keys
write(OUT/'geometry-reuse-controls.json',{'passed':True,'independent_context':'latest_runtime','nominal_trials':9102,'unique_owner_mode_centers':9066,'actual_shape_constructions':len(constructed),'exact_expected_keys':True,'all_primary_outputs_exact':True,'raw_rows_copy_before_owner_masking_covered_by_all_scores':True,'instrumentation_used_in_timings':False});del result

# Distinct successive invocations must not retain raw rows from a previous context.
mutated=[]
for kind in ['coordinates_and_angle','weights','nominal_mode']:
    args=copy.deepcopy(source_args)
    if kind=='coordinates_and_angle':
        m=compile_model(*[args[k] for k in [0,1,2,3,4]])
        for k in [0,80]:
            lo,hi=m['bounds'][k];args[2][k]=lo+(hi-lo)/3.7
            assert args[2][k]!=source_args[2][k]
    elif kind=='weights':args[3][0]+=.25
    else:args[1][0]=(args[1][0]+1)%10
    old=old_select(*args,primary_deadline=time.perf_counter()+45,cached_trials=None);new=select(*args,primary_deadline=time.perf_counter()+45,cached_trials=None)
    assert old==new and new['status']=='PRIMARY_COMPLETE'
    mutated.append({'context_change':kind,'all_primary_fields_exact':True,'center_trials':9102,'raw_proposals':5911,'keys':2854,'new_global_cache_created':False});del old,new
write(OUT/'changed-context-controls.json',{'passed':True,'cases':mutated})
