"""Complete tier equivalence, isolation, fallback and bounded timing controls."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,json,time,gc,os
from h5_indexed_two_center_neighbors_20261107 import neighbors as old_neighbors,cache_context
from h5_two_center_key_choice_20261107 import choose as old_choose
from h5_shared_geometry_neighbors_20261107 import primary,SelectionDeadline
from h5_tiered_key_choice_20261107 import choose,PRIMARY_SEQUENCES
from h5_shared_geometry_selection_20261107 import select
from h5_tiered_selection_20261107 import select as old_select
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-shared-geometry-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';X=ROOT/'output/h5-indexed-source-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-tiered-source-construction-20261107';Z=ROOT/'output/h5-tiered-source-preflight-20261107'
PRIMARY_SET=set(PRIMARY_SEQUENCES)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def fingerprint(v):return sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def rank(r):return r['augmented_objective_mm2'],tuple(r['modes']),len(r['changes']),tuple(map(tuple,r['changes'])),tuple(map(tuple,r['centers'])),r['sequence']
def independent_choice(rows,oracle):
    grouped={}
    for row in rows:grouped.setdefault(row['key'],[]).append(row)
    minima=[];near=[];groups={}
    for key,members in sorted(grouped.items()):
        r=sorted(members,key=rank)[0];o=sorted(members,key=lambda a:(oracle[a['sequence']],rank(a)[1:]))[0];gap=oracle[r['sequence']]-oracle[o['sequence']];assert gap<=1e-6;minima.append(r);groups[key]=[a['sequence'] for a in members]
        if r['sequence']!=o['sequence']:near.append({'key':key,'recorded':r['sequence'],'independent':o['sequence'],'gap_mm2':gap})
    def minimum(a):return sorted(a,key=rank)[0] if a else None
    eligible=[r for r in minima if not r['excluded']];best=minimum(eligible);single=minimum([r for r in rows if not r['excluded'] and len(r['changes'])==1]);joint=minimum([r for r in rows if not r['excluded'] and len(r['changes'])==2]);baseline=rows[0]['augmented_objective_mm2'];improves=best is not None and best['augmented_objective_mm2']<baseline-1e-6
    if best is not None:assert oracle[best['sequence']]-min(oracle[r['sequence']] for r in rows if not r['excluded'])<=1e-6
    return {'best_single':single,'best_joint':joint,'best_admissible':best,'current_score':baseline,'strictly_improves_current':improves,'accepted_choice':best if improves else None,'raw_proposals':len(rows),'distinct_keys':len(groups),'excluded_keys':sum(r['excluded'] for r in minima),'excluded_raw_proposals':sum(r['excluded'] for r in rows)},groups,minima,near
def first_subset(full,selections):
    centers={(s['owner'],s['mode']):s['selected'][0]['center'] for s in selections}
    rows=[r for r in full if all(c==centers[i,m] for (i,m),c in zip(r['changes'],r['centers']))]
    assert len(rows)==5911 and tuple(r['sequence'] for r in rows)==PRIMARY_SEQUENCES
    singles=[r for r in rows if len(r['changes'])==1];assert len(singles)==111 and Counter(r['changes'][0][0] for r in singles)=={i:(10 if i<6 else 3 if i<18 else 1) for i in range(33)}
    return rows
OUT.mkdir();started=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(P/'archive-checks.json')['passed'] and load(V/'audit/selection-replay/checks.json')['passed'] and load(X/'response-audit/epoch-01-partial-reference/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/prepare_h5_shared_geometry_helpers_20261107.py',ROOT/'output/h5_shared_geometry_neighbors_20261107.py',ROOT/'output/h5_shared_geometry_selection_20261107.py',ROOT/'output/h5_shared_geometry_timing_controls_20261107.py',P/'next-step.json',P/'archive-checks.json',P/'closed-problems.json']+[ROOT/'output'/n for n in ['prepare_h5_tiered_helpers_20261107.py','h5_tiered_neighbors_20261107.py','h5_tiered_key_choice_20261107.py','h5_tiered_selection_20261107.py','h5_indexed_two_center_neighbors_20261107.py','h5_two_center_key_choice_20261107.py']]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json']+[V/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','closed-problems.json','runtime-bindings.json','audit/selection-replay/checks.json','audit/selection-replay/proposal-score-controls.json','audit/inherited-source-domains.json']]+[X/n for n in ['search/epoch-01/opened.json','search/epoch-01/partial-selection.json','search/epoch-01/weight-transition.json','outcome-diagnostic/validation-full-neighbors.json','response-audit/epoch-01-partial-reference/checks.json','response-audit/epoch-01-partial-reference/proposal-score-controls.json']]
inputs+=[Z/n for n in ['search/epoch-01/opened.json','search/epoch-01/weight-transition.json','search/epoch-01/neighbors.json','search/epoch-01/owner-aliases.json','search/epoch-01/center-trials.json','search/epoch-01/center-selections.json','response-audit/checks.json','response-audit/epoch-01-selection/checks.json','response-audit/epoch-01-selection/proposal-score-controls.json','shared-center-diagnostic/checks.json']]
assert load(Z/'response-audit/checks.json')['passed'] and load(Z/'response-audit/epoch-01-selection/checks.json')['passed']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Invocation-local shared exact raw geometry rows keyed by family, nominal mode, angle and center float bit patterns. Copy before owner-specific masking; do not change auxiliary calculations, scoring, ranking, tier membership, snapshots or deadline placement. Fixed old/shared/shared/old timing for primary and extended tiers on independently checked source and earlier runtime full references, plus primary only on the latest independently checked runtime reference. Verify every key minimum, actual2342shape constructions, three changed successive contexts, all21closed source keys, six stale caches, snapshot isolation, one-shot extension,26cached/full synthetic deadlines and three real deadlines, plus two different-best fallback cases. No optimizer, source initializer or search.','timing_order':['old','shared','shared','old'],'primary_deadline_checkpoints':[1,4,225,1000,6136,6137,6140],'extension_deadline_checkpoints':[6141,6142,10000,23650,23651,23654],'real_primary_seconds':.05,'real_extension_seconds':.05,'maximum_process_seconds':600,'memory_bytes':2**31,'validation_only':True,'optimizer_calls':0,'new_source_state_prepared':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');opened=load(X/'search/epoch-01/opened.json');captured=load(X/'search/epoch-01/partial-selection.json');actual_closed={r['key'] for r in load(P/'closed-problems.json')};assert len(actual_closed)==21
for name,h in load(V/'runtime-bindings.json').items():assert digest(ROOT/name)==h
source_args=[lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,{r['key'] for r in load(V/'closed-problems.json')}]
runtime_args=[lib,opened['incoming_modes'],opened['incoming_values'],load(X/'search/epoch-01/weight-transition.json')['after'],identity,regions,set(opened['visited_keys'])]
source_full=load(V/'neighbors.json');source_aux=tuple(load(V/n) for n in ['owner-aliases.json','center-trials.json','center-selections.json']);runtime_full=load(X/'outcome-diagnostic/validation-full-neighbors.json');runtime_aux=tuple(captured[n] for n in ['aliases','trials','selections'])
# Full timed equivalence against two independently checked full contexts and one primary context.
zopen=load(Z/'search/epoch-01/opened.json');latest_args=[lib,zopen['incoming_modes'],zopen['incoming_values'],load(Z/'search/epoch-01/weight-transition.json')['after'],identity,regions,set(zopen['visited_keys'])]
latest_primary=load(Z/'search/epoch-01/neighbors.json');latest_aux=tuple(load(Z/'search/epoch-01'/n) for n in ['owner-aliases.json','center-trials.json','center-selections.json'])
timings=[];controls=[];contexts={}
cases=[('source',source_args,source_full,source_aux,V/'audit/selection-replay/proposal-score-controls.json',True),('runtime',runtime_args,runtime_full,runtime_aux,X/'response-audit/epoch-01-partial-reference/proposal-score-controls.json',True),('latest_runtime',latest_args,latest_primary,latest_aux,Z/'response-audit/epoch-01-selection/proposal-score-controls.json',False)]
for label,args,reference,aux,oracle_path,has_full in cases:
    one=first_subset(reference,aux[2]) if has_full else reference
    assert len(one)==5911 and tuple(r['sequence'] for r in one)==PRIMARY_SEQUENCES
    oracle_rows=load(oracle_path);oracle={r['sequence']:r['augmented_objective_mm2'] for r in oracle_rows};maximum=0.
    for a,b in zip(reference,oracle_rows):
        assert a['sequence']==b['sequence']
        for field in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2','unweighted_objective_mm2']:
            error=abs(a[field]-b[field]);maximum=max(maximum,error);assert error<1e-6
    first_choice,first_groups,first_minima,first_near=independent_choice(one,oracle)
    assert dict(Counter(map(len,first_groups.values())))=={562:1,33:78,1:2775}
    full_choice=full_groups=full_minima=None;full_near=[]
    if has_full:
        full_choice,full_groups,full_minima,full_near=independent_choice(reference,oracle)
        assert dict(Counter(map(len,full_groups.values())))=={2179:1,130:78,4:2775}
    contexts[label]=(one,first_choice,first_groups,first_minima,full_choice,full_groups,full_minima,oracle)
    for tier in ['primary','extended'] if has_full else ['primary']:
        for sequence,kind in enumerate(['old','shared','shared','old']):
            gc.collect();before=time.perf_counter();fn=old_select if kind=='old' else select
            result=fn(*args,primary_deadline=before+45,extension_deadline=before+45 if tier=='extended' else None,cached_trials=None);elapsed=time.perf_counter()-before
            assert result['primary']=={'records':one,'selection':first_choice,'groups':first_groups,'minima':first_minima} and tuple(result[n] for n in ['aliases','trials','selections'])==aux
            if tier=='extended':assert result['status']=='EXTENDED_COMPLETE' and result['extended']=={'records':reference,'selection':full_choice,'groups':full_groups,'minima':full_minima} and result['selected_proposal']==full_choice['accepted_choice']
            else:assert result['status']=='PRIMARY_COMPLETE' and result['selected_proposal']==first_choice['accepted_choice'] and result['extended'] is None
            timings.append({'context':label,'tier':tier,'sequence':sequence,'kind':kind,'selector_and_grouping_seconds':elapsed,'exact_output':True});print(timings[-1],flush=True);del result
    write(OUT/(label+'-primary-records.json'),one);write(OUT/(label+'-primary-minima.json'),first_minima);write(OUT/(label+'-primary-choice.json'),first_choice);write(OUT/(label+'-near-ties.json'),{'primary':first_near,'extended':full_near})
    controls.append({'context':label,'primary_records':5911,'extended_records':23419 if has_full else None,'key_minima_per_tier':2854,'primary_complete_sha256':fingerprint(one),'extended_complete_sha256':fingerprint(reference) if has_full else None,'independent_score_reference_max_error_mm2':maximum,'primary_near_ties':len(first_near),'extended_near_ties':len(full_near) if has_full else None,'full_extension_independently_checked':has_full,'all_ABBA_outputs_exact':True})
write(OUT/'timings.json',timings);write(OUT/'complete-tier-controls.json',controls)

# Count the actual geometry constructor calls without instrumenting the timed runs.
import h5_shared_geometry_neighbors_20261107 as shared_module
from h5_bracket_augmented_objective_20261107 import compile_model
original_constructor=shared_module.owner_shapes;constructed=[]
def observed_shapes(library,family,mi,center,angle):
    constructed.append((family,mi,float(angle).hex(),tuple(float(v).hex() for v in center)))
    return original_constructor(library,family,mi,center,angle)
shared_module.owner_shapes=observed_shapes
try:result=select(*latest_args,primary_deadline=time.perf_counter()+45,cached_trials=None)
finally:shared_module.owner_shapes=original_constructor
assert result['status']=='PRIMARY_COMPLETE' and result['primary']['records']==latest_primary and len(constructed)==len(set(constructed))==2342
model=compile_model(lib,latest_args[1],latest_args[2],latest_args[3],identity);expected_keys=set()
for row in latest_aux[1]:
    i=row['owner'];family=lib['identities'][i][0];angle=latest_args[2][model['owners'][i]['angle_coordinate']]/lib['angle_scale_mm'] if family=='cog' else 0.
    expected_keys.add((family,row['mode'],float(angle).hex(),tuple(float(v).hex() for v in row['center'])))
assert set(constructed)==expected_keys
write(OUT/'geometry-reuse-controls.json',{'passed':True,'independent_context':'latest_runtime','nominal_trials':9102,'unique_owner_mode_centers':9066,'actual_shape_constructions':len(constructed),'exact_expected_keys':True,'all_primary_outputs_exact':True,'raw_rows_copy_before_owner_masking_covered_by_all_scores':True,'instrumentation_used_in_timings':False});del result

# Distinct successive invocations must not retain raw rows from a previous context.
mutated=[]
for kind in ['coordinates_and_angle','weights','nominal_mode']:
    args=copy.deepcopy(source_args)
    if kind=='coordinates_and_angle':
        m=compile_model(*[args[k] for k in [0,1,2,3,4]])
        for k in [0,80]:
            lo,hi=m['bounds'][k];args[2][k]=lo+(hi-lo)/3.7
            assert args[2][k]!=source_args[2][k]
    elif kind=='weights':args[3][0]+=.25
    else:args[1][0]=(args[1][0]+1)%10
    old=old_select(*args,primary_deadline=time.perf_counter()+45,cached_trials=None);new=select(*args,primary_deadline=time.perf_counter()+45,cached_trials=None)
    assert old==new and new['status']=='PRIMARY_COMPLETE'
    mutated.append({'context_change':kind,'all_primary_fields_exact':True,'center_trials':9102,'raw_proposals':5911,'keys':2854,'new_global_cache_created':False});del old,new
write(OUT/'changed-context-controls.json',{'passed':True,'cases':mutated})

one,first_choice,first_groups,first_minima,full_choice,full_groups,full_minima,oracle=contexts['source'];extra=[r for r in source_full if r['sequence'] not in PRIMARY_SET];assert len(extra)==17508
cache={'context':cache_context(*source_args[:6]),'trials':source_aux[1]}
# Actual closure scope is tested, but this validation result is never a source seed.
args=copy.deepcopy(source_args);args[6]=actual_closed.copy();expected_full=[{**r,'excluded':r['key'] in actual_closed,'exclusion_reason':'closed_objective_problem' if r['key'] in actual_closed else None} for r in source_full];expected_one=first_subset(expected_full,source_aux[2]);c19=select(*args,primary_deadline=time.perf_counter()+30,extension_deadline=time.perf_counter()+30,cached_trials=cache)
assert c19['status']=='EXTENDED_COMPLETE' and c19['primary']['records']==expected_one and c19['extended']['records']==expected_full and c19['selected_proposal']['key'] not in actual_closed
write(OUT/'twenty-one-key-control.json',{'passed':True,'closed_keys':21,'primary_excluded':sum(r['excluded'] for r in expected_one),'extended_excluded':sum(r['excluded'] for r in expected_full),'selected_key_excluded':False,'validation_only':True,'new_source_state_prepared':False});del c19
class Clock:
    def __init__(self,stop):self.stop=stop;self.calls=0
    def __call__(self):self.calls+=1;return 1. if self.calls>=self.stop else 0.
deadlines=[]
def check_partial(r,full,primary_rows,aux,expected_choice):
    assert r['optimizer_calls']==0 and r['partial']['selected_proposal'] is None
    e=r['partial']
    if r['completed_tier'] is None:
        assert r['status']=='NO_COMPLETE_PRIMARY' and r['selected_proposal'] is None
        if e['status']=='SELECTION_DEADLINE':assert not e['primary_complete'] and e['records']==primary_rows[:len(e['records'])]
    else:
        assert r['status']=='PRIMARY_ONLY_EXTENSION_DEADLINE' and r['completed_tier']=='primary' and r['selected_proposal']==expected_choice['accepted_choice'] and r['extended'] is None
        if e['status']=='SELECTION_DEADLINE':
            secondary=[a for a in full if a['sequence'] not in PRIMARY_SET];assert e['primary_complete'] and e['primary_records']==primary_rows and e['records']==secondary[:len(e['records'])]
        else:assert r['unselected_complete_extension_records']==full
    if e['status']=='SELECTION_DEADLINE':
        for field,expected in zip(['aliases','trials','selections'],aux):assert e[field]==expected[:len(e[field])]
    assert e['observed']>=e['deadline'] and e['overrun_seconds']==e['observed']-e['deadline']
for flavor,cached in [('cached',cache),('full',None)]:
    for stop in [1,4,225,1000,6136,6137,6140,6141,6142,10000,23650,23651,23654]:
        timer=Clock(stop);r=select(*source_args,primary_deadline=1.,extension_deadline=1.,clock=timer,cached_trials=cached);assert timer.calls==stop;check_partial(r,source_full,one,source_aux,first_choice)
        assert (r['completed_tier'] is None)==(stop<=6140)
        write(OUT/f'{flavor}-deadline-{stop:05d}.json',r);deadlines.append({'flavor':flavor,'checkpoint':stop,'status':r['status'],'completed_tier':r['completed_tier'],'partial_stage':r['partial']['stage'],'selected_from_complete_primary':r['completed_tier']=='primary'});del r
    before=time.perf_counter();r=select(*source_args,primary_deadline=before+.05,extension_deadline=None,cached_trials=cached);check_partial(r,source_full,one,source_aux,first_choice);assert r['completed_tier'] is None;write(OUT/f'{flavor}-real-primary.json',r);deadlines.append({'flavor':flavor,'checkpoint':'real_primary','completed_tier':None,'overrun_seconds':r['partial']['overrun_seconds']});del r
    print({'deadline_path_completed':flavor},flush=True)
class ExtensionClock:
    def __init__(self):self.calls=0;self.start=None
    def __call__(self):
        self.calls+=1
        if self.calls<=6140:return 0.
        if self.start is None:self.start=time.perf_counter()
        return time.perf_counter()-self.start
timer=ExtensionClock();r=select(*source_args,primary_deadline=1.,extension_deadline=.05,clock=timer,cached_trials=cache);check_partial(r,source_full,one,source_aux,first_choice);assert r['completed_tier']=='primary';write(OUT/'real-extension.json',r);deadlines.append({'flavor':'cached','checkpoint':'real_extension','completed_tier':'primary','overrun_seconds':r['partial']['overrun_seconds']});del r
write(OUT/'deadline-controls.json',{'passed':True,'cases':deadlines,'count':len(deadlines)})
# A control with a genuinely different and better extension choice tests fallback.
first_map={r['key']:r for r in first_minima};improved=[r for r in full_minima if r['key'] not in actual_closed and first_map[r['key']]['augmented_objective_mm2']<source_full[0]['augmented_objective_mm2']-1e-6 and r['augmented_objective_mm2']<first_map[r['key']]['augmented_objective_mm2']-1e-6]
target=min(improved,key=rank);assert target['key']=='c5377062d401eee4096c025fbad01d75bdff1b19f983c40d0b8f06ab95093e2f' and target['sequence']==22625 and first_map[target['key']]['sequence']==22619
control_keys=actual_closed|({r['key'] for r in source_full}-{target['key']});cf=[{**r,'excluded':r['key'] in control_keys,'exclusion_reason':'closed_objective_problem' if r['key'] in control_keys else None} for r in source_full];cp=first_subset(cf,source_aux[2]);pc,_,_,_=independent_choice(cp,oracle);fc,_,_,_=independent_choice(cf,oracle);assert pc['accepted_choice']!=fc['accepted_choice'];args=copy.deepcopy(source_args);args[6]=control_keys
complete=select(*args,primary_deadline=time.perf_counter()+30,extension_deadline=time.perf_counter()+30,cached_trials=cache);assert complete['status']=='EXTENDED_COMPLETE' and complete['selected_proposal']==fc['accepted_choice'];del complete
after_better=6142+[r['sequence'] for r in extra].index(22625)+1;different_controls=[]
for stop in [after_better,23654]:
    timer=Clock(stop);r=select(*args,primary_deadline=1.,extension_deadline=1.,clock=timer,cached_trials=cache);check_partial(r,cf,cp,source_aux,pc);assert r['selected_proposal']==pc['accepted_choice'] and r['selected_proposal']!=fc['accepted_choice']
    if stop==after_better:assert any(a['sequence']==22625 for a in r['partial']['records'])
    write(OUT/f'different-best-deadline-{stop}.json',r);different_controls.append({'stop':stop,'primary_sequence':22619,'better_extension_sequence':22625,'chosen_sequence':r['selected_proposal']['sequence'],'partial_better_candidate_discarded':True});del r
write(OUT/'different-best-fallback-controls.json',{'passed':True,'validation_only':True,'complete_extension_selects_better':True,'cases':different_controls})
# Private snapshots cannot be changed through caller inputs or published views.
args=copy.deepcopy(source_args);local_cache=copy.deepcopy(cache);pool=primary(*args,deadline=time.perf_counter()+30,cached_trials=local_cache)
args[0]['stock_guard_mm']+=1;args[1][0]=0;args[2][0]+=1;args[3][0]+=1;args[4]['version']+='-mutated';args[5]['policy']['coefficient']=2.;args[6].update(r['key'] for r in source_full);local_cache['trials'][0]['center'][0]+=1
pool.primary[0]['augmented_objective_mm2']+=1;pool.trials[0]['center'][0]+=1;pool.selections[0]['selected'][0]['center'][0]+=1
assert pool.extend(time.perf_counter()+30)==source_full
try:pool.extend(time.perf_counter()+30)
except AssertionError:pass
else:raise AssertionError('Completed extension resumed')
pool=primary(*source_args,deadline=time.perf_counter()+30,cached_trials=cache)
try:pool.extend(1.,clock=Clock(1))
except SelectionDeadline:pass
else:raise AssertionError('Expected interrupted extension')
try:pool.extend(time.perf_counter()+30)
except AssertionError:pass
else:raise AssertionError('Interrupted extension resumed')
write(OUT/'snapshot-isolation-controls.json',{'passed':True,'caller_library_modes_values_weights_identity_regions_closed_keys_isolated':True,'caller_source_cache_isolated':True,'public_primary_trial_and_selection_views_isolated':True,'completed_extension_cannot_resume':True,'interrupted_extension_cannot_resume':True})
stale=[]
for kind,index in [('coordinates',2),('modes',1),('weights',3),('library',0),('identity',4),('regions',5)]:
    args=copy.deepcopy(source_args)
    if kind=='coordinates':args[index][0]+=1
    elif kind=='modes':args[index][0]=(args[index][0]+1)%10
    elif kind=='weights':args[index][0]+=.25
    elif kind=='library':args[index]['stock_guard_mm']+=.001
    elif kind=='identity':args[index]['version']+='-stale'
    else:args[index]['policy']['coefficient']=2.
    try:primary(*args,deadline=time.perf_counter()+5,cached_trials=cache)
    except AssertionError:stale.append({'case':kind,'rejected':True})
    else:raise AssertionError('Stale source cache accepted')
write(OUT/'stale-cache-controls.json',{'passed':True,'cases':stale})
policies=[]
for tier,rows in [('primary',one),('extended',source_full)]:
    allclosed=[{**r,'excluded':True,'exclusion_reason':'closed_objective_problem'} for r in rows];c,_,_=choose(allclosed,tier,deadline=time.perf_counter()+5);assert c['accepted_choice'] is None
    zero=copy.deepcopy(rows);c,_,_=choose(zero,tier,deadline=time.perf_counter()+5);zero[0]['augmented_objective_mm2']=c['best_admissible']['augmented_objective_mm2'];c,_,_=choose(zero,tier,deadline=time.perf_counter()+5);assert c['accepted_choice'] is None
    for bad in [rows[:-1],list(reversed(rows))]:
        try:choose(bad,tier,deadline=time.perf_counter()+5)
        except AssertionError:pass
        else:raise AssertionError('Incomplete or reordered tier accepted')
    policies.append({'tier':tier,'all_closed_no_candidate':True,'zero_margin_no_candidate':True,'partial_rejected':True,'reordered_rejected':True})
try:choose(source_full[:5911],'primary',deadline=time.perf_counter()+5)
except AssertionError:pass
else:raise AssertionError('Mixed tier accepted as primary')
write(OUT/'policy-controls.json',{'passed':True,'tiers':policies,'mixed_tier_rejected':True})
timing_summary=[]
for label,tier in [('source','primary'),('source','extended'),('runtime','primary'),('runtime','extended'),('latest_runtime','primary')]:
    old=[r['selector_and_grouping_seconds'] for r in timings if r['context']==label and r['tier']==tier and r['kind']=='old'];new=[r['selector_and_grouping_seconds'] for r in timings if r['context']==label and r['tier']==tier and r['kind']=='shared'];assert len(old)==len(new)==2
    timing_summary.append({'context':label,'tier':tier,'old_seconds':old,'shared_seconds':new,'old_mean_seconds':sum(old)/2,'shared_mean_seconds':sum(new)/2,'observed_mean_seconds_saved':(sum(old)-sum(new))/2,'samples_per_variant':2,'statistical_significance_claimed':False})
assert len(timings)==20
write(OUT/'checks.json',{'passed':True,'complete_seconds':time.perf_counter()-started,'complete_full_validation_contexts':2,'additional_primary_validation_contexts':1,'timed_calls':len(timings),'timing_summary':timing_summary,'raw_scores_bound_to_independent_references':80055,'primary_records_per_context':5911,'extended_records_per_full_context':23419,'key_minima_per_tier':2854,'twenty_one_closed_keys_checked':True,'actual_latest_geometry_constructions':2342,'changed_context_controls':3,'synthetic_deadline_cases':26,'real_deadline_cases':3,'different_best_fallback_cases':2,'snapshot_isolation_passed':True,'one_shot_extension_passed':True,'stale_cache_rejections':len(stale),'policy_tiers':2,'mixed_tier_rejected':True,'optimizer_calls':0,'new_source_state_prepared':False,'new_search_contract_prepared':False,'prior_closed_pipelines_resumed':False,'validation_only':True,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
