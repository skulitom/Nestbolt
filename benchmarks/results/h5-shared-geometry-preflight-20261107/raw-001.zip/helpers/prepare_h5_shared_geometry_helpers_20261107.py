"""Version an invocation-local cache of exact center geometry and raw area rows."""
from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'h5_tiered_neighbors_20261107.py').read_text(encoding='utf-8')
a="    options={}\n    checkpoint('after-baseline')"
b="""    # Cache lifetime is exactly this deep-copied, unchanged invocation.
    # Nominal modes and float bit patterns are retained; physical aliases are not keys.
    center_cache={};right_shapes=[np.asarray([s[level] for s in shapes],dtype=object) for level in range(2)]
    def center_rows(family,mi,centers,angle):
        keys=[(family,mi,float(angle).hex(),tuple(float(v).hex() for v in c)) for c in centers]
        assert len(keys)==len(set(keys))
        missing=[k for k,key in enumerate(keys) if key not in center_cache]
        if missing:
            new_shapes=[owner_shapes(library,family,mi,centers[k],angle) for k in missing]
            raw=np.zeros((len(missing),count))
            for level in range(2):
                left=np.asarray([s[level] for s in new_shapes],dtype=object)
                raw+=shapely.area(shapely.intersection(left[:,None],right_shapes[level][None,:]))
            for index,k in enumerate(missing):
                row=raw[index].copy();row.setflags(write=False)
                center_cache[keys[k]]=(new_shapes[index],row)
        candidate_shapes=[center_cache[key][0] for key in keys]
        # np.stack copies raw rows before the caller masks its own column.
        losses=np.stack([center_cache[key][1] for key in keys])
        return candidate_shapes,losses
    options={}
    checkpoint('after-baseline')"""
assert a in s;s=s.replace(a,b)
a="""            candidate_shapes=[owner_shapes(library,family,mi,c,angle) for c in candidate_centers];losses=np.zeros((len(candidate_centers),count));auxiliary=np.zeros_like(losses)
            for level in range(2):
                left=np.asarray([s[level] for s in candidate_shapes],dtype=object);right=np.asarray([s[level] for s in shapes],dtype=object);losses+=shapely.area(shapely.intersection(left[:,None],right[None,:]))"""
b="""            candidate_shapes,losses=center_rows(family,mi,candidate_centers,angle);auxiliary=np.zeros_like(losses)"""
assert a in s;s=s.replace(a,b)
with (O/'h5_shared_geometry_neighbors_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'h5_tiered_selection_20261107.py').read_text(encoding='utf-8').replace('from h5_tiered_neighbors_20261107','from h5_shared_geometry_neighbors_20261107')
with (O/'h5_shared_geometry_selection_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
