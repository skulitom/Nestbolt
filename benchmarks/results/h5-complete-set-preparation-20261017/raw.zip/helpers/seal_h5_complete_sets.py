"""Seal the separately tested complete-set eligibility candidate, without integration."""
from pathlib import Path
from hashlib import sha256
import json
import shutil
import sys
import zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-complete-set-probe-20261017'
out=root/'benchmarks/results/h5-complete-set-preparation-20261017'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
plan=load(probe/'preparation.json');build=load(probe/'build-v2.json');public=load(probe/'public-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed']
assert '85 passed; 0 failed; 0 ignored' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path']==plan['changed_file']):
            assert digest(probe/arm/row['path'])==row['sha256']
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
assert digest(probe/'candidate'/plan['changed_file'])==build['source_sha256']
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert 'Ran 5 tests' in (probe/'pilot-harness-tests.log').read_text(encoding='utf-8')
assert (probe/'pilot-harness-tests.log').read_text(encoding='utf-8').rstrip().endswith('OK')
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_complete_sets.py','build_h5_complete_sets.py','prepare_h5_complete_set_checks.py',
             'check_h5_complete_sets_public.py','prepare_h5_complete_set_pilot.py','check_h5_complete_set_harness.py','seal_h5_complete_sets.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/paired-runner.py']=root/'scripts/h5_complete_set_pilot.py'
inventory={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':85,'strict_lint_pass':True,
    'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,
    'candidate_common_repeatable':True,'independent_validation_passed':True,'pilot_harness_tests':5,
    'production_source_digest':source_digest(),'production_files_unchanged':True,
    'candidate_exchange_source_sha256':build['source_sha256'],'binaries':build['binaries'],
    'equal_and_larger_return_area_authored_exchanges_pass':True,
    'measured_search_started':False,'H5_complete':False,'integrated':False,'completed_weight_percent':60})
for name in ['preparation.json','build-v2.json','candidate.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
(out.parent/(out.name+'.md')).write_text('''# Complete-set eligibility preparation — 2026-10-17

**85 optimized core tests, strict lint, ten authored observer outcomes and four
public CLI comparisons pass.** Five existing paired-harness checks also pass;
the blocks, scoring, per-case validation and measurement functions are unchanged.
No production integration or development performance claim.

[Four diagnostic traces](h5-obstruction-stage-diagnosis-20261017.md) found 620
complete blocker-set samples excluded by the smaller-area heuristic and no
complete sets attempted. A separately [validated authored witness](h5-area-witness-20261017.md)
shows that a larger combined return area can preserve physical material use.
The initial witness with the wrong charged axis remains as a failed assertion.

This isolated candidate removes only the combined-area eligibility filter for
complete two/three-blocker sets. Single-victim fallbacks retain their original
filter. Actual collisions, at most three blockers, six proposals, ranking,
both-sheet repair, final independent geometry/quantity/material checks, rollback,
the early opportunity, shared ten-percent budget and 1.2-second cap remain.

Authored tests now require equal and larger return areas to succeed where both
sheets have space at exactly unchanged material. An impossible return still
must leave the incumbent untouched; attempting it is now allowed. This replaces
two assertions specific to the removed heuristic. Existing disabled/expired,
frozen/mirrored, failed-repair, defects and two/three-part tests remain passing.
The complete patch and every original source hash are retained.

Ordinary public results match baseline exactly apart from elapsed wall time;
common-mode candidate replays match, with exact independent metrics and counts.
The original baseline observer is reused byte-identically; only the candidate
is rebuilt in a unique target. Production and the old failed candidate remain
unchanged. All source/binary/log/public-result archive members and CRC verify.

A separately committed matched 72-outcome pilot will compare the same four jobs,
two kerfs, three seeds and three arms at 60 seconds on eight physical CCD0 cores.
It cannot replace the full 13-job H5 gate or relax the original +1% material
limit. Every failure remains evidence. H2/H5 remain open; completion is 60%.
''',encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in ['h5-complete-set-preparation-20261017','h5-complete-set-pilot-20261017']:
        f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'members':len(inventory),'bytes':archive.stat().st_size,'sha256':digest(archive)}))
