"""Keep the paired method unchanged for the complete-set eligibility experiment."""
from pathlib import Path
from hashlib import sha256
import ast
import json
root=Path(__file__).resolve().parents[1]
old=root/'output/h5_obstruction_set_recovered_pilot.py'
original=old.read_text(encoding='utf-8')
s=original.replace('output/h5-obstruction-set-probe','output/h5-complete-set-probe-20261017')
s=s.replace('h5-obstruction-set-preparation-20261016','h5-complete-set-preparation-20261017')
s=s.replace("PROBE/'fixture-repair.json'", "PROBE/'preparation.json'")
s=s.replace('complete smaller actual obstruction set','complete actual obstruction set regardless of combined filled area')
s=s.replace('Isolated complete-obstruction-set candidate','Isolated complete-set eligibility candidate')
s=s.replace("'only_prerequisite_and_evidence_paths_changed': True", "'paired_case_blocks_summary_measurement_method_unchanged': True")
s=s.replace("'previous_failed_pilot': 'benchmarks/results/h5-early-exchange-pilot-20261016/results.json'", "'previous_failed_pilot': 'benchmarks/results/h5-obstruction-set-recovered-pilot-20261016/results.json'")
s=s.replace("    paths.extend(ROOT/row['path'] for row, _ in load_cases())", """    paths.extend([ROOT/'benchmarks/results/h5-obstruction-stage-diagnosis-20261017/verification.json',
                  ROOT/'benchmarks/results/h5-area-witness-20261017/review.json',
                  ROOT/'benchmarks/results/h5-obstruction-set-recovered-pilot-20261016/verification.json'])
    paths.extend(ROOT/row['path'] for row, _ in load_cases())""")
s=s.replace("    import h4_preview_matrix as h4", """    diagnostic = ROOT/'benchmarks/results/h5-obstruction-stage-diagnosis-20261017'
    assert load(diagnostic/'verification.json')['all_original_archives_and_traces_verified']
    try:
        arguments = psutil.Process(load(diagnostic/'opened.json')['pid']).cmdline()
    except psutil.NoSuchProcess:
        arguments = []
    assert not any('h5_obstruction_stage_diagnosis.py' in arg for arg in arguments), 'Diagnostic is still running'
    import h4_preview_matrix as h4""")
names=['blocks','summarize','case','measure']
def body(text,name):
    return ast.dump(next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
for name in names:assert body(original,name)==body(s,name),name
target=root/'scripts/h5_complete_set_pilot.py';assert not target.exists()
compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
record={'reference':str(old.relative_to(root)),'reference_sha256':sha256(old.read_bytes()).hexdigest(),
        'runner':str(target.relative_to(root)),'runner_sha256':sha256(target.read_bytes()).hexdigest(),
        'unchanged_function_AST':names,'thresholds_geometry_and_budgets_unchanged':True}
(root/'output/h5-complete-set-probe-20261017/pilot-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
