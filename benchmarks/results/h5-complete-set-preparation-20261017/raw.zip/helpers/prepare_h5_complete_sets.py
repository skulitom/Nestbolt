"""One isolated change: complete obstruction sets need not reduce filled part area."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib
import json
import shutil
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
out=root/'output/h5-complete-set-probe-20261017';out.mkdir(exist_ok=False)
old=root/'output/h5-obstruction-set-probe'
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
rel='crates/core/src/sheets/vstrip/exchange.rs'
path=out/'candidate'/rel
before=path.read_text(encoding='utf-8');text=before
def change(a,b):
    global text
    assert text.count(a)==1,a
    text=text.replace(a,b)
change('''//! Isolated experiment: return a smaller actual obstruction while inserting a
//! last-sheet part, repair both sheets, then check the whole original job.''','''//! Isolated experiment: return complete actual obstruction sets while inserting
//! a last-sheet part, repair both sheets, then check the whole original job.''')
change('''        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one would leave one or two known collisions to repair.
        // Keep the original single-victim alternatives as a fallback.''','''        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one leaves known collisions. Returned filled area can
        // increase while last-sheet height and material stay unchanged. Both
        // repairs and the whole-job material guard still control acceptance.
        // Keep the original smaller single-victim alternatives as a fallback.''')
change('if blocked.len() > 1 && area < incoming.area() {','if blocked.len() > 1 {')
change('''    fn directed_exchange_refuses_larger_return_parts() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchange_attempts, 0);
    }''','''    fn directed_exchange_rejects_returns_that_cannot_fit() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
    }''')
change('''    fn obstruction_set_refuses_net_area_increase_without_mutation() {
        let (job, layout) = obstruction_set_fixture(3, 30.0);
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
    }''','''    fn complete_sets_can_return_equal_or_greater_area_at_the_same_material() {
        // The independently validated witness retains a 33 mm charged height:
        // a 2550/2700 mm2 incoming part can trade for three 900 mm2 squares.
        // Their relative positions fit in the otherwise empty return sheet.
        for incoming_width in [85.0, 90.0] {
            let (mut job, mut layout) = obstruction_set_fixture(3, 30.0);
            for part in &mut job.parts {
                for polygon in &mut part.geometry {
                    for point in &mut polygon.outer {
                        point.swap(0, 1);
                    }
                }
            }
            job.parts[2] = rectangle("incoming", incoming_width, 30.0);
            for part in &mut layout.placements {
                part.transform.translation.swap(0, 1);
            }
            let original = validate(&job, &layout).unwrap();
            assert!(original.valid);
            assert_eq!(original.metrics.unwrap().material_area, 13300.0);
            let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
            assert_eq!(moved, 1);
            assert_eq!(after.placements.iter().filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1").count(), 3);
            assert!(after.placements.iter().any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0"));
        }
    }''')
path.write_text(text,encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='rejected-atomic-set',tofile='complete-set-candidate')),encoding='utf-8',newline='\n')
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
assert sha256((out/'baseline-observer.exe').read_bytes()).hexdigest()=='a381ae63b3163ffb3a8c89953c789d17178f0221412f37a8709f9a38d026a517'
source_files={arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']}
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),'changed_file':rel,
    'production_digest':source_digest(),'old_source_files':source_files,
    'target':str(root/'output/h5-complete-set-target-20261017'),
    'baseline_observer_sha256':sha256((out/'baseline-observer.exe').read_bytes()).hexdigest(),
    'evidence':{'diagnosis':'benchmarks/results/h5-obstruction-stage-diagnosis-20261017/verification.json',
        'witness':'benchmarks/results/h5-area-witness-20261017/height-preserving/checks.json'},
    'only_search_policy_change':'Allow complete sets of two/three actual blockers regardless of their combined area; unchanged one-part fallback, six-proposal ordering/cap and both-sheet repair/final validity/material/deadline guards.',
    'test_adaptation':'Replace heuristic-specific zero-attempt/area-rejection assertions with original no-mutation infeasible-return check and concrete equal/greater-area witness. Existing source-repair, stock, mirror, frozen and disabled tests retained.',
    'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'candidate_prepared':str(out),'production_unchanged':True,'measured_search_started':False}))
