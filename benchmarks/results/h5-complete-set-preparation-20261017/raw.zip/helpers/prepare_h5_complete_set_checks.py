from pathlib import Path
root=Path(__file__).resolve().parents[1]
original=(root/'output/check_h5_obstruction_public.py').read_text(encoding='utf-8')
source=original.replace("probe=root/'output/h5-obstruction-set-probe'", "probe=root/'output/h5-complete-set-probe-20261017'")
assert source!=original and source.replace('h5-complete-set-probe-20261017','h5-obstruction-set-probe')==original
target=root/'output/check_h5_complete_sets_public.py'
assert not target.exists()
target.write_text(source,encoding='utf-8',newline='\n')
