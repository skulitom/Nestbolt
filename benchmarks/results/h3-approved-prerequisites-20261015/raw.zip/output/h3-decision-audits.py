from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
PYTHON = ROOT/'.cache/shop-venv/Scripts/python.exe'
out = ROOT/'benchmarks/results/h3-decision-audit-driver-20261015'
out.mkdir(exist_ok=False)
records=[]

def stage(name, command, pattern, timeout=900):
    before=set((ROOT/'benchmarks/results').glob(pattern))
    started=time.perf_counter()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run(list(map(str,command)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                              creationflags=subprocess.CREATE_NO_WINDOW,timeout=timeout)
    paths=sorted(set((ROOT/'benchmarks/results').glob(pattern))-before)
    record={'name':name,'command':list(map(str,command)),'exit_code':result.returncode,
            'wall_seconds':time.perf_counter()-started,'paths':[p.relative_to(ROOT).as_posix() for p in paths],
            'log_sha256':sha256((out/(name+'.log')).read_bytes()).hexdigest()}
    records.append(record)
    (out/'progress.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(record),flush=True)
    assert result.returncode==0, name
    return paths

# Finish all optimized CLI builds before any guarded diagnostics start.
stage('release-binaries',[sys.executable,ROOT/'output/ccd1.py','cargo','build','--release','--locked','-p','nestbolt-cli','-p','nestbolt-mcp'],'__none__')
reader,=stage('reader',[PYTHON,ROOT/'scripts/h3_reader_audit.py'],'h3-reader-*.json')
stage('geometry',[PYTHON,ROOT/'scripts/h3_geometry_audit.py',reader],'h3-geometry-*.json')
stage('text-repairs',[PYTHON,ROOT/'scripts/h3_text_cache_audit.py'],'h3-text-cache-*.json')
writer,=stage('writer',[PYTHON,ROOT/'scripts/h3_writer_audit.py'],'h3-writer-*.json')
stage('unit-geometry',[PYTHON,ROOT/'scripts/h3_unit_geometry_audit.py',writer],'h3-unit-geometry-*.json')
stage('reviewed-prerequisites',[PYTHON,ROOT/'scripts/h3_reviewed_prerequisites.py'],'h3-reviewed-prerequisites-*')
print('Fresh training and repaired-input audits finished',flush=True)
