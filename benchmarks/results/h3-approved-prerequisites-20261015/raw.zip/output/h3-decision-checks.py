from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parents[1]
out = ROOT/'benchmarks/results/h3-decision-checks-20261015'
out.mkdir(exist_ok=False)
commands = [
    ('format', ['cargo', 'fmt', '--all']),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--locked']),
    ('cli-release', ['cargo', 'test', '--release', '-p', 'nestbolt-cli', '--test', 'features', '--locked']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('release', ['cargo', 'build', '--release', '--locked', '-p', 'nestbolt-cli', '-p', 'nestbolt-mcp', '-p', 'nestbolt-core', '--example', 'lightburn_inspect', '--example', 'lightburn_roundtrip']),
    ('web', [sys.executable, 'scripts/build_web.py', '--test']),
]
records = []
for name, command in commands:
    started = time.perf_counter()
    with (out/(name+'.log')).open('wb') as log:
        code = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW).returncode
    records.append({'name':name,'command':command,'exit_code':code,'wall_seconds':time.perf_counter()-started,
        'log_sha256':sha256((out/(name+'.log')).read_bytes()).hexdigest()})
    (out/'progress.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(records[-1]),flush=True)
    if code:
        sys.exit(code)
print('All decision checks passed',flush=True)
