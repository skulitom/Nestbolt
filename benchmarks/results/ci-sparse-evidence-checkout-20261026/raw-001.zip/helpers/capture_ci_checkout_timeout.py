from pathlib import Path
from datetime import datetime, timezone
import base64, hashlib, json, subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/ci-checkout-timeout-20261026'
OUT.mkdir()
def write(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def capture(name,args):
    p=subprocess.run(args,cwd=ROOT,capture_output=True)
    (OUT/name).write_bytes(p.stdout)
    write(name+'.receipt.json',{'args':args,'utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'bytes':len(p.stdout),'sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode('utf-8',errors='replace')})
    assert p.returncode==0,name
    return p.stdout
job=json.loads(capture('job.json',['gh','api','repos/skulitom/Nestbolt/actions/jobs/121864514559']))
check=job['check_run_url'].split('api.github.com/')[1]
capture('check.json',['gh','api',check])
capture('annotations.json',['gh','api',check+'/annotations'])
capture('logs.log',['gh','api','repos/skulitom/Nestbolt/actions/jobs/121864514559/logs'])
pin='d23441a48e516b6c34aea4fa41551a30e30af803'
for name in ['README.md','src/git-source-provider.ts','src/git-command-manager.ts']:
    raw=capture(name.replace('/','-')+'.response.json',['gh','api',f'repos/actions/checkout/contents/{name}?ref={pin}'])
    (OUT/name.replace('/','-')).write_bytes(base64.b64decode(json.loads(raw)['content']))
steps=[{'name':s['name'],'started_at':s['started_at'],'completed_at':s['completed_at'],'conclusion':s['conclusion']} for s in job['steps']]
write('step-times.json',steps)
print(json.dumps({'status':job['status'],'conclusion':job['conclusion'],'steps':steps},indent=2))
