"""Verify actual Git selection, byte identity and existing CI Python checks."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/ci-sparse-checkout-20261026';OUT.mkdir()
CHECKOUT=OUT/'checkout';records=[]
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,cwd=ROOT,input=None):
    t=time.monotonic();p=subprocess.run(args,cwd=cwd,input=input,capture_output=True)
    n=f'command-{len(records):03d}';(OUT/(n+'.stdout')).write_bytes(p.stdout);(OUT/(n+'.stderr')).write_bytes(p.stderr)
    records.append({'args':args,'cwd':str(cwd),'seconds':time.monotonic()-t,'returncode':p.returncode,'stdout':n+'.stdout','stderr':n+'.stderr'})
    write(n+'.json',records[-1]);assert p.returncode==0,records[-1]
    return p.stdout
workflow=(ROOT/'.github/workflows/ci.yml').read_text(encoding='utf-8')
pattern='/*\n!/benchmarks/results/**/*.zip\n'
assert workflow.count('sparse-checkout-cone-mode: false')==4
assert workflow.count('sparse-checkout: |\n            /*\n            !/benchmarks/results/**/*.zip')==4
head=run(['git','rev-parse','HEAD']).decode().strip()
tree=run(['git','ls-tree','-rlz',head]);entries=[]
for line in tree.split(b'\0'):
    if not line:continue
    meta,path=line.split(b'\t',1);mode,kind,oid,size=meta.split();path=path.decode()
    entries.append({'path':path,'bytes':int(size),'oid':oid.decode(),'mode':mode.decode()})
omitted=[e for e in entries if e['path'].startswith('benchmarks/results/') and e['path'].endswith('.zip')]
expected=[e for e in entries if e not in omitted]
run(['git','clone','--shared','--no-checkout',str(ROOT),str(CHECKOUT)])
# The same non-cone patterns that the pinned checkout action writes before checkout.
run(['git','sparse-checkout','set','--no-cone','--stdin'],CHECKOUT,pattern.encode())
run(['git','checkout','--detach',head],CHECKOUT)
included=0
for e in entries:
    p=CHECKOUT/e['path'];exclude=e in omitted
    assert p.exists()!=exclude,e['path']
    if not exclude:
        data=p.read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        # Git may honor attributes such as LF conversion; compare Git's clean representation.
        if oid!=e['oid']:
            oid=run(['git','hash-object','--path='+e['path'],e['path']],CHECKOUT).decode().strip()
        assert oid==e['oid'],e['path'];included+=1
write('selection.json',{'source_head':head,'all_tracked_files':len(entries),'all_tracked_bytes':sum(e['bytes'] for e in entries),
 'included_files':included,'included_bytes':sum(e['bytes'] for e in expected),'omitted_archives':len(omitted),
 'omitted_bytes':sum(e['bytes'] for e in omitted),'all_other_files_present_and_git_blob_identical':True,'patterns':pattern,'omitted':omitted})
# Capture the Python imports reachable from the ordinary CI entry points.
queue=['check','build_web','smoke','lbf','notices','maker_setup','maker_freeze','test_maker_geometry']
commands=[]
tree=ast.parse((ROOT/'scripts/check.py').read_text(encoding='utf-8'))
for node in ast.walk(tree):
    if isinstance(node,ast.List) and node.elts and isinstance(node.elts[0],ast.Attribute) and ast.unparse(node.elts[0])=='sys.executable':
        tail=[ast.literal_eval(e) for e in node.elts[1:]]
        if tail[0] in ['scripts/smoke.py','scripts/build_web.py'] and tail[1:]!=['--verify-only']:continue
        commands.append([sys.executable,*tail]);queue.append(Path(tail[0]).stem)
seen=set();references=[]
while queue:
    module=queue.pop();p=ROOT/'scripts'/(module+'.py')
    if module in seen or not p.exists():continue
    seen.add(module);src=p.read_text(encoding='utf-8')
    for i,line in enumerate(src.splitlines(),1):
        if 'benchmarks/results' in line or 'raw.zip' in line:references.append({'file':p.relative_to(ROOT).as_posix(),'line':i,'text':line})
    for n in ast.walk(ast.parse(src)):
        if isinstance(n,ast.ImportFrom) and n.module:queue.append(n.module.split('.')[0])
        if isinstance(n,ast.Import):queue.extend(a.name.split('.')[0] for a in n.names)
write('dependency-review.json',{'python_modules':sorted(seen),'historical_result_references':references,'existing_python_CI_commands':commands})
for cmd in commands:
    print('Checking',cmd[1],flush=True);run(cmd,CHECKOUT)
write('checks.json',{'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,
 'selected_files_git_blob_identical':included,'omitted_archives':len(omitted),'omitted_bytes':sum(e['bytes'] for e in omitted),
 'existing_python_CI_commands_passed':len(commands),'workflow_checkout_steps_verified':4,
 'hosted_native_browser_smoke_and_maker_rebuild_pending':True,'records':records})
print(json.dumps({k:v for k,v in json.loads((OUT/'checks.json').read_bytes()).items() if k!='records'}))
