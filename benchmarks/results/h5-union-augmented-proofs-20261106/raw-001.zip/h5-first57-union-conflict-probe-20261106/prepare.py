"""Probe an exact stronger pair predicate on the32 existing joint graph witnesses."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-union-conflict-probe-20261106'
BASE=ROOT/'output/h5-first57-joint-optional-trees-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def union_covers(box,rectangles):
    """All rectangles are OPEN; the target box is CLOSED, including degenerate axes."""
    xmin,ymin,xmax,ymax=box
    boundaries=sorted({xmin,xmax}|{r[a] for r in rectangles for a in [0,2] if xmin<=r[a]<=xmax})
    samples=sorted({2*x for x in boundaries}|{a+b for a,b in zip(boundaries,boundaries[1:])})
    columns=[]
    for x in samples:
        active=[i for i,r in enumerate(rectangles) if 2*r[0]<x<2*r[2]]
        intervals=sorted((rectangles[i][1],rectangles[i][3]) for i in active)
        merged=[]
        for lo,hi in intervals:
            if merged and lo<merged[-1][1]:
                merged[-1][1]=max(merged[-1][1],hi)
            else:merged.append([lo,hi])
        spanning=next((r for r in merged if r[0]<ymin and ymax<r[1]),None)
        if spanning is None:return None
        columns.append({'x_twice':x,'active_rectangles':active,'spanning_open_y_interval':spanning})
    return columns
def source_pair(a,b,geometry):
    box=[b['bounds_um'][0]-a['bounds_um'][2],b['bounds_um'][1]-a['bounds_um'][3],
         b['bounds_um'][2]-a['bounds_um'][0],b['bounds_um'][3]-a['bounds_um'][1]]
    rectangles=[]
    for ra in geometry[a['geometry']]['inner_rectangles_um']:
        for rb in geometry[b['geometry']]['inner_rectangles_um']:
            rectangles.append([ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]])
    single=any(r[0]<box[0] and r[1]<box[1] and box[2]<r[2] and box[3]<r[3] for r in rectangles)
    return box,rectangles,single
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(BASE/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json');witnesses=load(BASE/'audit/joint-graph-witnesses.json');assert len(witnesses)==32
inputs=[Path(__file__),BASE/'audit/plan.json',BASE/'audit/checks.json',BASE/'audit/joint-graph-witnesses.json',SOURCE/'geometry-domains.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'preparation_cap_seconds':5,'maximum_process_seconds':10,'repeat_permitted':False,
    'method':'For every pair in all32 audited joint necessary graph witnesses, derive the closed relative-anchor rectangle and the union of all open source-inner component collision rectangles. Sweep all X boundary and open interval classes exactly, merging open Y intervals only across strict overlaps. A whole closed target interval must lie strictly inside one connected open union component. Save every stronger certificate and all deterministic boundary controls. A conflicted witness is invalid in the stronger relaxation but does not exclude its whole arrangement.'})
axis=list(combinations([-1,0,1,2],2));rectangles=[[x0,y0,x1,y1] for x0,x1 in axis for y0,y1 in axis]
controls=[{'box':[0,0,1,1],'rectangles':[]}]+[{'box':[0,0,1,1],'rectangles':[r]} for r in rectangles]
controls += [{'box':[0,0,1,1],'rectangles':[a,b]} for a,b in combinations(rectangles,2)]
hand=[
    ([0,0,10,10],[[-1,-1,6,11],[4,-1,11,11]],True),
    ([0,0,10,10],[[-1,-1,5,11],[5,-1,11,11]],False),
    ([0,0,10,10],[[-1,-1,11,5],[-1,5,11,11]],False),
    ([0,0,10,10],[[0,-1,11,11]],False),
    ([0,0,0,10],[[-1,-1,1,6],[-1,4,1,11]],True),
    ([0,0,10,0],[[-1,-1,6,1],[4,-1,11,1]],True),
    ([0,0,0,0],[[-1,-1,0,1],[0,-1,1,1]],False),
    ([0,0,0,0],[[-1,-1,1,1]],True)]
controls += [{'box':b,'rectangles':r,'expected':e} for b,r,e in hand]
for row in controls:
    row['diagnostic_covered']=union_covers(row['box'],row['rectangles']) is not None
    if 'expected' in row:assert row['diagnostic_covered']==row['expected']
write(OUT/'boundary-controls.json',controls)
summaries=[]
for wi,witness in enumerate(witnesses):
    cells=witness['bracket_cells']+witness['insert_cells'];assert len(cells)==16
    edges=[]
    for a,b in combinations(range(16),2):
        box,rectangles,single=source_pair(cells[a],cells[b],geometry)
        assert not single
        certificate=union_covers(box,rectangles)
        if certificate is not None:
            edges.append({'pair':[a,b],'relative_anchor_box_um':box,'open_collision_rectangles_um':rectangles,'columns':certificate})
    row={'source_witness_index':wi,'empty_sites':witness['source_selection']['empty_sites'],
         'complete_pairs':120,'new_conflict_edges':edges,'whole_arrangement_excluded':False}
    write(OUT/f'witness-{wi:02d}.json',row)
    summaries.append({'empty_sites':row['empty_sites'],'new_conflict_edges':len(edges),'witness_ruled_out_by_stronger_graph':bool(edges)})
    assert time.perf_counter()-started<5
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'controls':len(controls),
    'witnesses':summaries,'complete_pairs':3840,'new_pair_conflicts':sum(r['new_conflict_edges'] for r in summaries),
    'witnesses_with_new_conflicts':sum(r['witness_ruled_out_by_stronger_graph'] for r in summaries),
    'independent_audit_pending':True,'whole_arrangements_excluded':0,'remaining_fixed29_choices':52,
    'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
print({'seconds':time.perf_counter()-started,'new_pair_conflicts':sum(r['new_conflict_edges'] for r in summaries),
       'witnesses_with_new_conflicts':sum(r['witness_ruled_out_by_stronger_graph'] for r in summaries)})
