"""Add only certified stronger source-inner conflicts; incomplete scans remain explicit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations_with_replacement
import ast,json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-union-conflict-edges-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
FRONTIER=ROOT/'output/h5-first57-joint-optional-trees-20261106'
PROBE=ROOT/'output/h5-first57-union-conflict-probe-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
HELPER=ROOT/'output/prepare_h5_union_conflict_probe_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for p in [BR/'audit/checks.json',INS/'audit/checks.json',FRONTIER/'audit/checks.json',PROBE/'audit-v2/checks.json']:assert load(p)['passed']
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(INS/'audit/joint-candidates.json') if tuple(r['empty_sites']) in remaining];assert len(selection)==52
geometry=load(SOURCE/'geometry-domains.json')
function=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='union_covers']
assert len(function)==1;exec(compile(ast.Module(body=function,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json',INS/'audit/joint-candidates.json',FRONTIER/'audit/remaining-fixed29-choices.json',
        PROBE/'audit-v2/plan.json',PROBE/'audit-v2/checks.json']+[b/n for b in [BR,INS,FRONTIER] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]+[INS/f"choice-{r['insert_choice_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'per_case_scan_cutoff_seconds':0.35,'per_case_complete_cap_seconds':0.40,
    'global_scan_cutoff_seconds':25,'preparation_cap_seconds':30,'maximum_process_seconds':40,
    'method':'Retain all original complete bracket/insert cells. Enumerate geometry template pairs and vector-filter relative boxes that lie strictly inside the collision-union envelope but inside no single component rectangle. Check each retained pair with the boundary-aware exact union predicate. Save only genuinely added pair edges. Each edge must pass independent source replay before use. A cutoff keeps its certified prefix and records an incomplete scan; absence of an added edge never proves compatibility. The new graph remains a necessary relaxation even with an incomplete set of additional conflicts.',
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,'whole_arrangement_exclusions':0})
templates={}
for ga,gb in combinations_with_replacement(range(10),2):
    rects=[[a[0]-b[2],a[1]-b[3],a[2]-b[0],a[3]-b[1]]
           for a in geometry[ga]['inner_rectangles_um'] for b in geometry[gb]['inner_rectangles_um']]
    templates[(ga,gb)]=rects
summaries=[]
for choice,row in enumerate(selection):
    case_started=time.perf_counter();deadline=min(started+25,case_started+0.35)
    br=load(BR/f"choice-{row['choice_index']:02d}.json");ins=load(INS/f"choice-{row['insert_choice_index']:02d}.json")
    assert br['empty_sites']==ins['empty_sites']==row['empty_sites']
    nodes=br['nodes']+ins['nodes'];bounds=np.array([n['bounds_um'] for n in nodes],dtype=np.int64)
    groups={g:np.array([i for i,n in enumerate(nodes) if n['geometry']==g],dtype=np.int64) for g in range(10)}
    edges=[];checked=0;scanned_templates=0;complete=True
    for (ga,gb),rects in templates.items():
        if time.perf_counter()>=deadline:complete=False;break
        ia,ib=groups[ga],groups[gb]
        if not len(ia) or not len(ib):scanned_templates+=1;continue
        a,b=bounds[ia],bounds[ib]
        lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3]
        ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1]
        eligible=(lx>min(r[0] for r in rects))&(ly>min(r[1] for r in rects))&(ux<max(r[2] for r in rects))&(uy<max(r[3] for r in rects))
        for x,y,z,w in rects:eligible &= ~((x<lx)&(y<ly)&(ux<z)&(uy<w))
        if ga==gb:eligible &= ia[:,None]<ib[None,:]
        for ai,bi in zip(*np.nonzero(eligible)):
            if checked%32==0 and time.perf_counter()>=deadline:complete=False;break
            checked+=1
            box=[int(lx[ai,bi]),int(ly[ai,bi]),int(ux[ai,bi]),int(uy[ai,bi])]
            if union_covers(box,rects) is not None:edges.append(sorted([int(ia[ai]),int(ib[bi])]))
        if not complete:break
        scanned_templates+=1
    edges.sort();assert len(edges)==len(set(map(tuple,edges)))
    elapsed=time.perf_counter()-case_started
    result={'source_selection':row,'empty_sites':row['empty_sites'],'original_bracket_node_count':len(br['nodes']),
        'total_nodes':len(nodes),'candidate_pairs_checked':checked,'geometry_templates_completed':scanned_templates,
        'all_eligible_pairs_checked':complete,'added_conflict_edges':edges,'case_seconds':elapsed,
        'case_complete_cap_overrun_seconds':max(0,elapsed-0.40),'whole_arrangement_excluded':False}
    write(OUT/f'choice-{choice:02d}.json',result)
    summaries.append({k:v for k,v in result.items() if k not in ['source_selection','added_conflict_edges']}|{'added_conflict_edges':len(edges)})
    assert time.perf_counter()-started<30
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,
    'added_conflict_edges':sum(r['added_conflict_edges'] for r in summaries),
    'choices_with_added_conflicts':sum(r['added_conflict_edges']>0 for r in summaries),
    'complete_scans':sum(r['all_eligible_pairs_checked'] for r in summaries),'independent_audit_pending':True,
    'whole_arrangements_excluded':0,'remaining_fixed29_choices':52,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
print({'seconds':time.perf_counter()-started,'added_conflict_edges':sum(r['added_conflict_edges'] for r in summaries),
    'choices_with_added_conflicts':sum(r['added_conflict_edges']>0 for r in summaries),
    'complete_scans':sum(r['all_eligible_pairs_checked'] for r in summaries)})
