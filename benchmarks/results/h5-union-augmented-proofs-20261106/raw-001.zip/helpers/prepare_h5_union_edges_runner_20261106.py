from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_optional_bracket_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('optional-bracket-trees','union-conflict-edges').replace('prepare_h5_optional_bracket_trees','prepare_h5_union_conflict_edges').replace('50','40')
with (O/'run_h5_union_conflict_edges_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
