"""Generate a distinct joint model from audited source plus certified new constraints."""
from pathlib import Path
O=Path(__file__).resolve().parent
source=O/'prepare_h5_joint_optional_trees_20261106.py'
s=source.read_text(encoding='utf-8')
s=s.replace('import ast,json,time,shutil','import ast,json,time,shutil\nimport numpy as np')
s=s.replace("OUT=ROOT/'output/h5-first57-joint-optional-trees-20261106'","OUT=ROOT/'output/h5-first57-union-augmented-trees-20261106'")
s=s.replace("KNOWN=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'","AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'")
a="""for b in [BR,INS,FRONTIER,KNOWN]:assert load(b/'audit/checks.json')['passed']
known=load(KNOWN/'audit/necessary-graph-witnesses.json');assert len(known)==1
known_empty=known[0]['source_selection']['empty_sites'];assert known_empty==[4,9,14]
selection=[r for r in load(INS/'audit/joint-candidates.json') if r['empty_sites']!=known_empty];assert len(selection)==62"""
b="""for b in [BR,INS,FRONTIER,AUG]:assert load(b/'audit/checks.json')['passed']
selection=[r['source_selection']|{'augmentation_index':r['augmentation_index']} for r in load(AUG/'audit/stronger-model-candidates.json')]
assert len(selection)==52"""
assert a in s;s=s.replace(a,b)
s=s.replace("KNOWN/'audit/necessary-graph-witnesses.json'","AUG/'audit/stronger-model-candidates.json'")
s=s.replace('[BR,INS,FRONTIER,KNOWN]','[BR,INS,FRONTIER,AUG]')
s=s.replace("inputs=[Path(__file__),HELPER,","inputs=[Path(__file__),ROOT/'output/prepare_h5_augmented_tree_helpers_20261106.py',ROOT/'output/prepare_h5_joint_optional_trees_20261106.py',HELPER,")
a='+[INS/f"choice-{r[\'insert_choice_index\']:02d}.json" for r in selection]'
assert a in s;s=s.replace(a,a+'+[AUG/f"choice-{r[\'augmentation_index\']:02d}.json" for r in selection]')
s=s.replace("'selection':selection,'known_joint_witness_not_researched':known_empty,","'selection':selection,'every_case_has_new_source_certified_constraints':True,")
start=s.index("    'method':");end=s.index('\nsummaries=[]',start)
s=s[:start]+"""    'method':'New joint necessary model for all52 remaining cases, each strengthened by independently certified union-coverage source conflicts. Preserve every complete bracket/insert cell, all original single-component conflict edges, and every certified added edge. NumPy integer comparisons rebuild the original graph without geometry approximation. Additional edges are read from frozen audited files; no absent edge is interpreted as physical compatibility. The existing complete two-family propagation and optional-clique proof tree remains, with fresh unchanged0.70/0.75-second case cutoffs,1500 nodes and50/55/65 global caps. Every open branch is preserved. The previously known joint witness is now eligible only because this arrangement has genuinely new certified constraints. No prior bounded process is extended or repeated.'})
""" + s[end:]
a="""    universe=(1<<len(nodes))-1;compatible={n:0 for n in range(len(nodes))};graph_complete=True
    for a in range(len(nodes)):
        if time.perf_counter()>=deadline:graph_complete=False;break
        for b in range(a+1,len(nodes)):
            if conflict(nodes[a],nodes[b]) is None:
                compatible[a]|=1<<b;compatible[b]|=1<<a"""
b="""    augmentation=load(AUG/f"choice-{row['augmentation_index']:02d}.json")
    assert augmentation['empty_sites']==row['empty_sites'] and augmentation['added_conflict_edges']
    n=len(nodes);universe=(1<<n)-1;graph_complete=True
    bounds=np.array([v['bounds_um'] for v in nodes],dtype=np.int64)
    by_geometry={g:np.array([i for i,v in enumerate(nodes) if v['geometry']==g],dtype=np.int64) for g in range(10)}
    blocked=np.eye(n,dtype=bool)
    for ga in range(10):
        if not graph_complete:break
        for gb in range(ga,10):
            if time.perf_counter()>=deadline:graph_complete=False;break
            ia,ib=by_geometry[ga],by_geometry[gb]
            if not len(ia) or not len(ib):continue
            a,b=bounds[ia],bounds[ib]
            lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3]
            ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1]
            clashes=np.zeros((len(ia),len(ib)),dtype=bool)
            for ra in geometry[ga]['inner_rectangles_um']:
                for rb in geometry[gb]['inner_rectangles_um']:
                    clashes |= ((ra[0]-rb[2]<lx)&(ra[1]-rb[3]<ly)&(ux<ra[2]-rb[0])&(uy<ra[3]-rb[1]))
            blocked[np.ix_(ia,ib)] |= clashes
            blocked[np.ix_(ib,ia)] |= clashes.T
    for a,b in augmentation['added_conflict_edges']:blocked[a,b]=blocked[b,a]=True
    packed=np.packbits(~blocked,axis=1,bitorder='little')
    compatible={i:int.from_bytes(packed[i].tobytes(),'little')&universe for i in range(n)}"""
assert a in s;s=s.replace(a,b)
s=s.replace("'graph_complete':graph_complete,'root':root,","'graph_complete':graph_complete,'added_source_conflict_edges':len(augmentation['added_conflict_edges']),'root':root,")
s=s.replace("'known_joint_witness_preserved_without_search':known_empty,","'every_case_has_new_source_certified_constraints':True,")
with (O/'prepare_h5_union_augmented_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_joint_optional_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('joint-optional-trees','union-augmented-trees').replace('prepare_h5_joint_optional_trees','prepare_h5_union_augmented_trees')
with (O/'run_h5_union_augmented_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a new52-case augmented necessary graph with fresh frozen limits.')
