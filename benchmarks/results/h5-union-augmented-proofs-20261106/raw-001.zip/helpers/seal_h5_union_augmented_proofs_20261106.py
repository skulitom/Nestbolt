from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-union-augmented-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
PROBE=ROOT/'output/h5-first57-union-conflict-probe-20261106'
EDGE=ROOT/'output/h5-first57-union-conflict-edges-20261106'
BASE=ROOT/'output/h5-first57-union-augmented-trees-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
pa=load(PROBE/'audit-v2/checks.json');ea=load(EDGE/'audit/checks.json');audit=load(BASE/'audit/checks.json')
assert all(a['passed'] for a in [pa,ea,audit])
assert pa['new_pair_conflicts_verified']==44 and ea['added_source_conflict_edges_verified']==22639
assert audit['new_fixed29_choices_excluded']==13 and audit['remaining_fixed29_choices']==39
assert audit['tree_records_verified']==20162 and audit['total_joint_graph_witnesses']==27 and len(audit['budget_limited_cases'])==12
process_folders=[ROOT/'output'/f'h5-first57-{n}-process-20261106' for n in ['union-conflict-probe','union-conflict-edges','union-augmented-trees']]
processes=[load(p/'process.json') for p in process_folders]
assert all(p['closed'] and p['exit_code']==0 and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert ea['case_complete_cap_overrun_seconds']==audit['case_complete_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106','h5-deferred-conflict-tree-20261106','h5-optional-bracket-trees-20261106','h5-joint-optional-trees-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [PROBE,EDGE,BASE]+process_folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_union*20261106.py','*h5_augmented_tree*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-union-augmented-proofs-report-20261106.md','h5-union-conflict-audit-failure-20261106.json']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(PROBE/'audit-v2/checks.json','probe-audit.json'),(EDGE/'audit/checks.json','edge-audit.json'),(BASE/'audit/checks.json','tree-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/joint-graph-witnesses.json','joint-graph-witnesses.json'),(ROOT/'output/h5-union-conflict-audit-failure-20261106.json','audit-failure.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'new_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),
    'processes':processes,'successful_independent_audit_seconds':[pa['seconds'],ea['seconds'],audit['seconds']],
    'failed_count_audit_preserved':True,'failed_audit_duration_not_measured':True,
    'scan_limited_cases':7,'tree_limited_cases':12,'all_processes_closed':True,
    'case_complete_cap_overrun_seconds':0,'placement_solver_calls':0,'native_calls':0,
    'full_construction_60_90_budget_claimed':False})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'current_augmented_tree_process_closed':True,
    'remaining_fixed29_choices':39,'total_fixed29_choices_excluded':416,'joint_graph_witnesses':27,'limited_joint_cases':12,
    'next_method':'Assess stronger fixed-obstacle pruning from original-source convex cog pieces. For a source-certified moving inner rectangle and a convex source cog piece, the open interior of their exact Minkowski collision polygon is a guaranteed overlap region for the moving anchor. Prove a complete closed anchor cell strictly inside one such convex polygon by exact rational corner/halfplane checks, and remove it only when that cog site is present in the arrangement. Preserve every unproved cell and all source-mode aliases, proving coverage of the remaining continuous domain. Reuse only independently certified original piece partitions and exact binary64 source transforms; do not treat floating polygon containment as proof. First measure certified removed cells on the39 survivors. Only genuinely stronger source domains justify a fresh bounded model; do not repeat any unchanged closed model. Preserve all consumed preparation for a later construction budget.',
    'survivors':'output/h5-first57-union-augmented-trees-20261106/audit/remaining-fixed29-choices.json',
    'joint_witnesses':'output/h5-first57-union-augmented-trees-20261106/audit/joint-graph-witnesses.json',
    'source_inner_geometry':'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json',
    'exact_source_partition':'output/h5-first57-necessary-rectangles-20261104/audit/exact-source-partitions.json',
    'source_cog_sites':'output/h5-first57-direct-short9-20261104/source-cog-sites.json',
    'source_geometry_helpers':['output/prepare_h5_first57_necessary_rectangles_20261104.py','output/audit_h5_first57_necessary_rectangles_20261104.py','output/prepare_h5_full_stock_source_polygons_20261104.py','output/audit_h5_full_stock_source_polygons_20261104.py'],
    'bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104','insert_geometry':'output/h5-first57-broader-insert-covers-20261106',
    'new_source_polygon_pruning_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded':13,'remaining_fixed29_choices':39,'total_fixed29_choices_excluded':416,'original_fixed29_choices':455,
    'boundary_controls_verified':675,'probe_new_pair_conflicts':44,'new_source_conflict_edges_verified':22639,
    **{k:audit[k] for k in ['tree_records_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks','strict_source_inner_pair_evaluations']},
    'joint_graph_witnesses':27,'limited_joint_cases':12,'failed_audit_preserved':True,'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-union-augmented-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 exact union-augmented proofs:** [independent source and tree replay]({link}) verifies 22,639 additional source-inner conflicts across all 52 cases, preserving every continuous candidate cell. The stronger joint model has 20,162 audited records, 8,830 mandatory covers and 551,955 ordered removals. Thirteen complete trees exclude fixed29/cog choices, leaving 39 (416 of 455 excluded): 27 necessary graph witnesses and 12 cutoff cases. The initial probe audit count error and corrected separate audit are preserved; all 675 boundary controls pass. Seven partial edge scans supply only verified prefixes, with no augmentation-completeness claim. Complete preparation processes take 0.259107, 12.011483 and 18.865523 s; complete-case/process caps pass. No placement solver/native call or full construction budget claim is made. Next assess exact whole-cell collision proofs against original convex cog pieces; every current bounded process stays closed. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%; the pending push still awaits the live Windows native check and aggregate success.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [joint bracket/insert trees](../benchmarks/results/h5-joint-optional-trees-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [exact union-augmented proofs](../benchmarks/results/{NAME}.md).',1)
a='There are 52 remaining choices (403 of 455 excluded): 32 necessary joint graph\nwitnesses and 20 cutoff cases. Exact union-based source-inner pair conflicts\nare the next method to assess. All prior calls and bounded processes stay closed.'
b='Exact component-union conflicts strengthen every remaining case; augmented\njoint trees exclude thirteen more. There are 39 remaining choices (416 of 455\nexcluded): 27 necessary joint graph witnesses and 12 cutoff cases. Whole-cell\ncollision proofs against original cog polygons are next. All prior calls and\nbounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
