from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_joint_optional_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('from itertools import combinations','from itertools import combinations,product')
s=s.replace('import json,time,shutil','import ast,json,time,shutil')
s=s.replace("BASE=ROOT/'output/h5-first57-joint-optional-trees-20261106'","BASE=ROOT/'output/h5-first57-union-augmented-trees-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-optional-bracket-trees-20261106';KNOWN=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'","FRONTIER=ROOT/'output/h5-first57-joint-optional-trees-20261106';AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'")
s=s.replace('h5-first57-joint-optional-trees-process-20261106','h5-first57-union-augmented-trees-process-20261106')
s=s.replace("KNOWN/'audit/necessary-graph-witnesses.json'","AUG/'audit/stronger-model-candidates.json'")
s=s.replace("KNOWN/'audit'","AUG/'audit'").replace('[BR,INS,FRONTIER,KNOWN]','[BR,INS,FRONTIER,AUG]')
s=s.replace("inputs={Path(__file__),BASE/'plan.json'","inputs={Path(__file__),ROOT/'output/prepare_h5_augmented_tree_audit_20261106.py',ROOT/'output/audit_h5_joint_optional_trees_20261106.py',ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py',FRONTIER/'audit/remaining-fixed29-choices.json',BASE/'plan.json'")
start=s.index('all_candidates=load(');end=s.index('def exact_conflict',start)
s=s[:start]+"""selection=[r['source_selection']|{'augmentation_index':r['augmentation_index']} for r in load(AUG/'audit/stronger-model-candidates.json')]
assert len(selection)==52
plan=load(BASE/'plan.json');assert plan['selection']==selection
assert plan['every_case_has_new_source_certified_constraints']
assert plan['per_case_search_cutoff_seconds']==0.70 and plan['maximum_expanded_nodes_per_case']==1500
geometry=load(SOURCE/'geometry-domains.json');results=[];excluded=[];witnesses=[];total_evaluations=0
total_added=0;point_checks=[0]
helper=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
functions=[n for n in ast.parse(helper.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['classes','covered']]
assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(helper),'exec'))
""" + s[end:]
a="""    evaluated=[0]
    @lru_cache(maxsize=None)
    def conflict(a,b):
        evaluated[0]+=1;return exact_conflict(nodes[a],nodes[b])"""
b="""    apath=AUG/f"choice-{row['augmentation_index']:02d}.json";inputs.add(apath);augmentation=load(apath)
    assert augmentation['empty_sites']==row['empty_sites'] and augmentation['added_conflict_edges']
    edges=set(map(tuple,augmentation['added_conflict_edges']))
    assert data['added_source_conflict_edges']==len(edges)==len(augmentation['added_conflict_edges'])
    for a,b in edges:
        assert 0<=a<b<len(nodes) and not exact_conflict(nodes[a],nodes[b])
        left,right=nodes[a],nodes[b]
        box=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]+[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
        rectangles=[[ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]]
                    for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um'])]
        assert covered(box,rectangles)
    total_added+=len(edges)
    evaluated=[0]
    @lru_cache(maxsize=None)
    def conflict(a,b):
        evaluated[0]+=1
        return exact_conflict(nodes[a],nodes[b]) or tuple(sorted((a,b))) in edges"""
assert a in s;s=s.replace(a,b)
start=s.index('# Re-map and directly recheck');end=s.index("prior=load(INS/'audit/remaining-fixed29-choices.json')",start)
s=s[:start]+s[end:]
s=s.replace("prior=load(INS/'audit/remaining-fixed29-choices.json');assert len(prior)==63","prior=load(FRONTIER/'audit/remaining-fixed29-choices.json');assert len(prior)==52")
s=s.replace("The prior joint witness is re-mapped to the complete new covers and rechecked without search.","Every case has added constraints independently replayed through all Cartesian boundary classes of open source-inner collision unions. Full root source covers remain unchanged; this is a genuinely stronger graph, including the former known-witness case.")
s=s.replace("'new_joint_graph_witnesses':len(witnesses)-1","'new_joint_graph_witnesses':len(witnesses)")
s=s.replace("'prior_joint_witness_rechecked_without_search':1,","'added_source_conflict_edges_verified':total_added,'union_boundary_class_checks':point_checks[0],")
s=s.replace("'previous_fixed29_choices_excluded':392","'previous_fixed29_choices_excluded':403").replace("'total_fixed29_choices_excluded':392+len(removed)","'total_fixed29_choices_excluded':403+len(removed)")
with (O/'audit_h5_union_augmented_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent source-union and complete augmented-tree replay.')
