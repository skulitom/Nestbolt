from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json
O=Path(__file__).resolve().parent
source=O/'audit_h5_union_conflict_probe_20261106.py'
failure={'utc_recorded':datetime.now(timezone.utc).isoformat(),'failed_audit':source.name,
    'failed_audit_sha256':sha256(source.read_bytes()).hexdigest(),'observed_exit':'AssertionError',
    'assertion':'len(controls)==711','actual_controls':675,
    'reason':'Clerical count error in the independent audit: 36 rectangles give630 distinct unordered pairs, so1 empty+36 singles+630 pairs+8 hand cases=675. Preparation was correct and remains closed.',
    'preserved_failed_audit_directory':'output/h5-first57-union-conflict-probe-20261106/audit',
    'repair':'Correct only the expected control counts and use a separate audit-v2 output directory. Re-audit the unchanged prepared evidence; do not rerun preparation.'}
with (O/'h5-union-conflict-audit-failure-20261106.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=source.read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
s=s.replace('len(controls)==711','len(controls)==675').replace('controls[:703]','controls[:667]')
s=s.replace("inputs={Path(__file__),BASE/'plan.json'","inputs={Path(__file__),ROOT/'output/audit_h5_union_conflict_probe_20261106.py',ROOT/'output/prepare_h5_union_conflict_audit_v2_20261106.py',ROOT/'output/h5-union-conflict-audit-failure-20261106.json',BASE/'plan.json'")
with (O/'audit_h5_union_conflict_probe_v2_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(failure)
