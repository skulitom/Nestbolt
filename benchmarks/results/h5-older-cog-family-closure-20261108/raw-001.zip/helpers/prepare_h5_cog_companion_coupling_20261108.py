"""Complete companion cover filtering conditional on each remaining cog cell."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-companion-coupling-20261108';OLD=ROOT/'output/h5-three-cog-frame-support-20261108';M=ROOT/'output/h5-one-three-covers-20261107';HULL=ROOT/'output/h5-cog-hull-stock-20261108';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==3 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',OLD/'support-vertex-proof.json',M/'geometries.json',M/'audit/checks.json',HULL/'hull-support.json',G/'geometry.json',G/'audit/checks.json']+[OLD/(r['key']+'.npz') for r in cases]+[M/'turned-3'/f'geometry-{gi:02d}.json' for gi in range(12)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For every remaining complete continuous cog-center cell C, retain a complete conditional set of companion-mode center boxes B from the independently certified original mode covers. A box may be removed only when EVERY combination of c in C and b in B yields a source collision. The relative center closure C-B is tested against each source-contained component rectangle: either the moving109mm disk intersects it throughout, or an actual signed-axis support vertex exists inside it throughout. These are necessary conditions independent of cog angle. Preserve all original boundary-class boxes and every box lacking a whole-product witness. Deduplicate identical retained-box signatures to enable exact conditional occupied-region area bounds later. This stage makes no core exclusion or feasible-pose claim.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
geometries=load(M/'geometries.json');assert len(geometries)==12;offsets=load(OLD/'support-vertex-proof.json')['signed_axis_support_vertex_offset_rectangles_um'];domain=load(HULL/'hull-support.json')['necessary_stock_center_domain_um'];h=2500;results=[];inventories=[]
for case in cases:
    key=case['key'];assert case['turned_frames']==3;allowed=sum(1<<i for i in case['omitted_sites']);boxes=[]
    for g in geometries:
        for index,row in enumerate(load(M/'turned-3'/f"geometry-{g['geometry']:02d}.json")['cover']):
            if row[0]&~allowed:continue
            boxes.append({'geometry':g['geometry'],'family':g['family'],'cover_index':index,'cover':row})
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];ys,xs=np.nonzero(old)
    cl=np.maximum(xs*h,domain[0]);cr=np.minimum((xs+1)*h,domain[2]);cb=np.maximum(ys*h,domain[1]);ct=np.minimum((ys+1)*h,domain[3]);witness=np.zeros((len(xs),len(boxes)),dtype=np.uint8)
    for bi,box in enumerate(boxes):
        _,l,b,r,t,*_=box['cover'];rl,rb,rr,rt=cl-r,cb-t,cr-l,ct-b;g=geometries[box['geometry']]
        for ci,(a,c,d,e) in enumerate(g['inner_components_um']):
            dx=np.maximum(0,np.maximum(a-rl,rr-d));dy=np.maximum(0,np.maximum(c-rb,rt-e));bad=(witness[:,bi]==0)&(dx*dx+dy*dy<109000**2);witness[bad,bi]=1+ci*5
            for direction,(ox0,oy0,ox1,oy1) in enumerate(offsets):
                bad=(witness[:,bi]==0)&(rl+ox0>a)&(rr+ox1<d)&(rb+oy0>c)&(rt+oy1<e);witness[bad,bi]=2+ci*5+direction
    signatures,inverse,counts=np.unique(np.packbits(witness==0,axis=1,bitorder='little'),axis=0,return_inverse=True,return_counts=True);np.savez_compressed(OUT/(key+'.npz'),source_y=ys,source_x=xs,collision_witness=witness,retained_box_signatures=signatures,cell_signature=inverse,signature_cell_counts=counts);inventories.append({'key':key,'boxes':boxes});results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'continuous_center_cells':len(xs),'original_companion_cover_boxes':len(boxes),'conditional_cell_box_pairs':int(witness.size),'collision_pairs_excluded':int((witness>0).sum()),'distinct_retained_cover_signatures':len(signatures),'minimum_retained_boxes':int((witness==0).sum(1).min()),'maximum_retained_boxes':int((witness==0).sum(1).max()),'exact_first32_excluded':False})
write(OUT/'companion-boxes.json',inventories);write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':3,'conditional_cell_box_pairs':sum(r['conditional_cell_box_pairs'] for r in results),'collision_pairs_excluded':sum(r['collision_pairs_excluded'] for r in results),'distinct_retained_cover_signatures':sum(r['distinct_retained_cover_signatures'] for r in results),'core_exclusions_claimed':0,'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
