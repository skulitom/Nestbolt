"""Exact orthogonal rectangle-union complements in circular cell neighborhoods."""
import numpy as np

def horizontal_exact(rects, y, x, stock, stripes, h):
    total = 0
    for dy, w in stripes:
        l = max(stock[0], (x - w) * h)
        r = min(stock[2], (x + w + 1) * h)
        b = max(stock[1], (y + dy) * h)
        t = min(stock[3], (y + dy + 1) * h)
        if l >= r or b >= t:
            continue
        hit = rects[(rects[:, 0] < r) & (rects[:, 2] > l) & (rects[:, 1] < t) & (rects[:, 3] > b)]
        cuts = sorted({b, t, *np.maximum(b, hit[:, 1]).tolist(), *np.minimum(t, hit[:, 3]).tolist()})
        for bottom, top in zip(cuts, cuts[1:]):
            active = hit[(hit[:, 1] <= bottom) & (hit[:, 3] >= top)]
            intervals = sorted(((max(l, int(a)), min(r, int(c))) for a, _, c, _ in active))
            covered = 0
            end = l
            for a, c in intervals:
                if c > end:
                    covered += c - max(a, end)
                    end = c
            total += (r - l - covered) * (top - bottom)
    return total

def vertical_exact(rects, y, x, stock, stripes, h):
    total = 0
    for dx, w in stripes:
        left = max(stock[0], (x + dx) * h)
        right = min(stock[2], (x + dx + 1) * h)
        bottom = max(stock[1], (y - w) * h)
        top = min(stock[3], (y + w + 1) * h)
        if left >= right or bottom >= top:
            continue
        rows = rects[(rects[:, 0] < right) & (rects[:, 2] > left) & (rects[:, 1] < top) & (rects[:, 3] > bottom)]
        cuts = np.unique(np.r_[left, right, np.maximum(rows[:, 0], left), np.minimum(rows[:, 2], right)])
        for l, r in zip(cuts, cuts[1:]):
            active = rows[(rows[:, 0] <= l) & (rows[:, 2] >= r)]
            events = {bottom: 0, top: 0}
            for _, b, _, t in active:
                b = max(int(b), bottom)
                t = min(int(t), top)
                events[b] = events.get(b, 0) + 1
                events[t] = events.get(t, 0) - 1
            previous = bottom
            depth = 0
            uncovered = 0
            for coordinate, change in sorted(events.items()):
                if depth == 0:
                    uncovered += coordinate - previous
                depth += change
                assert depth >= 0
                previous = coordinate
            assert depth == 0
            total += int(r - l) * uncovered
    return total
