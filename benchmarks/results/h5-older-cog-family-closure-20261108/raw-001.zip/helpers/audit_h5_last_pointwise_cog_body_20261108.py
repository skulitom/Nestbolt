"""Independent vertical exact complement readback for the final older fixed core."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from h5_exact_circular_complement_20261108 import vertical_exact
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-last-pointwise-cog-body-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-pointwise-companion-capacity-20261108';COV=ROOT/'output/h5-pointwise-companion-covers-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108';KERNEL=ROOT/'output/h5-eight-cog-complement-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',COV/'audit',M/'audit',SCOPE,KERNEL/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'cell-results.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct each complete pointwise source component sweep independently from audited covers. Derive vertical neighborhood stripes from direct closed-cell minimum distances; integrate exact complement areas with vertical signed-y-event sweeps rather than producer horizontal interval merging. Bind the original all-angle source outer/body proof, use ONLY fixed-source F for the disjointness argument, and use companion capacity BEFORE common-cog subtraction. Reconcile every original retained inventory, full-body deficit and center cell without double-counting cog material.'})
cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==1;case=cases[0];key=case['key'];assert key=='t3-omit-14-15';stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];geometries=load(M/'geometries.json');fixed=load(M/'turned-3'/(case['case']+'-capacity.json'))['fixed_inner_obstacles_um'];scope=next(r for r in load(SCOPE/'remaining-core-scopes.json') if r['turned_frames']==3 and r['case']==case['case']);cells={(r['cell_y'],r['cell_x']):r for r in load(COV/(key+'-covers.json'))};capacities={(r['cell_y'],r['cell_x']):r for r in load(OLD/(key+'-capacities.json'))};saved=load(BASE/'cell-results.json');stripes=[];h=2500;radius=140001
for dx in range(-58,59):
    ys=[]
    for dy in range(-58,59):
        d=min((x-min(h,max(0,x)))**2+(y-min(h,max(0,y)))**2 for x in [dx*h,(dx+1)*h] for y in [dy*h,(dy+1)*h])
        if d<=radius**2:ys.append(dy)
    if ys:assert ys==list(range(min(ys),max(ys)+1)) and min(ys)==-max(ys);stripes.append((dx,max(ys)))
assert sum(2*w+1 for _,w in stripes)==10301
with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'];ys,xs=np.nonzero(domain)
assert len(xs)==len(saved)==22;remaining=domain.copy();records=[]
for y,x,savedrow in zip(ys,xs,saved):
    cell=cells[int(y),int(x)];capacity=capacities[int(y),int(x)];region=set()
    for mode in cell['modes']:
        for l,b,r,t in mode['remaining_closed_center_boxes_um']:
            for a,c,d,e in geometries[mode['geometry']]['outer_component_bounds_um']:
                q=(max(l+a,stock[0]),max(b+c,stock[1]),min(r+d,stock[2]),min(t+e,stock[3]))
                if q[0]<q[2] and q[1]<q[3]:region.add(q)
    outside=vertical_exact(np.array(sorted(region)+list(map(tuple,fixed)),dtype=np.int64),int(y),int(x),stock,stripes,h);forced=max(0,50000*10**6-outside);upper=capacity['joint_area_before_common_cog_um2'];required=min(scope['necessary_splits_if_last_cog_first'][ii]['first_companion_area_lower_um2'] for ii in capacity['remaining_inventory_indices']);good=forced<=upper-required;remaining[y,x]=good;row={'cell_y':int(y),'cell_x':int(x),'outside_cog_area_upper_um2':outside,'compulsory_cog_area_lower_um2':forced,'fixed_only_companion_area_upper_um2':upper,'required_companion_area_lower_um2':required,'area_deficit_um2':required-upper+forced,'excluded':not good};assert row==savedrow;records.append(row)
with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:assert np.array_equal(z['remaining_center_cells'],remaining)
row={'key':key,'turned_frames':3,'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':22,'body_area_excluded_center_cells':22-int(remaining.sum()),'remaining_center_cells':int(remaining.sum()),'minimum_area_deficit_um2':min(r['area_deficit_um2'] for r in records),'provisional_exact_first32_excluded':not bool(remaining.any())};assert load(BASE/'case-results.json')==[row];result={**row,'exact_first32_excluded':not bool(remaining.any())};process=load(ROOT/'output/h5-last-pointwise-cog-body-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'case-results.json',[result]);write(OUT/'remaining-cases.json',[] if result['exact_first32_excluded'] else [result]);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':1,'exact_orthogonal_complement_queries':22,'body_area_excluded_center_cells':22-int(remaining.sum()),'remaining_center_cells':int(remaining.sum()),'minimum_full_body_area_deficit_mm2':row['minimum_area_deficit_um2']/1e6,'additional_exact_first32_cases_excluded':int(result['exact_first32_excluded']),'exact_first32_cases_remaining':int(not result['exact_first32_excluded']),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
