"""Exact conditional source-body conservation in complete circular cell neighborhoods."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-coupled-cog-body-20261108';OLD=ROOT/'output/h5-coupled-companion-areas-20261108';COV=ROOT/'output/h5-cog-companion-coupling-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108';KERNEL=ROOT/'output/h5-eight-cog-complement-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==3 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',OLD/'conditional-groups.json',COV/'companion-boxes.json',COV/'audit/checks.json',M/'geometries.json',M/'stock-cover.json',M/'audit/checks.json',SCOPE/'remaining-core-scopes.json',SCOPE/'checks.json',KERNEL/'kernel-stripes.json',KERNEL/'audit/checks.json']+[p for r in cases for p in [OLD/(r['key']+'.npz'),COV/(r['key']+'.npz'),M/'turned-3'/(r['case']+'-capacity.json')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each surviving cog center cell use its complete conditional companion-envelope union U_C from retained original-mode covers. R_C=U_C minus fixed-source inner F has the already audited exact area upper. A valid cog has filled area>=50000mm2 and cannot occupy F. Bound its area outside R_C by EXACT integer area of its full circular cell neighborhood in outward stock minus(U_C union F). Horizontally sweep every neighborhood row, split at every clipped rectangle y endpoint, and merge x intervals; no whole-cell complement overestimate remains. The circular neighborhood still covers every exact source angle and every point of the continuous center cell. Subtract compulsory cog occupancy from the conditional companion area and test the minimum area of EVERY inventory surviving the conditional family bounds.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];geometries=load(M/'geometries.json');boxesbykey={r['key']:r['boxes'] for r in load(COV/'companion-boxes.json')};groupsbykey={r['key']:r['groups'] for r in load(OLD/'conditional-groups.json')};scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};stripes=load(KERNEL/'kernel-stripes.json')['horizontal_stripes'];h=2500;results=[];regionrecords=[]
def complement_area(rects,y,x):
    total=0
    for dy,w in stripes:
        l=max(stock[0],(x-w)*h);r=min(stock[2],(x+w+1)*h);b=max(stock[1],(y+dy)*h);t=min(stock[3],(y+dy+1)*h)
        if l>=r or b>=t:continue
        hit=rects[(rects[:,0]<r)&(rects[:,2]>l)&(rects[:,1]<t)&(rects[:,3]>b)];cuts=sorted({b,t,*np.maximum(b,hit[:,1]).tolist(),*np.minimum(t,hit[:,3]).tolist()})
        for bottom,top in zip(cuts,cuts[1:]):
            active=hit[(hit[:,1]<=bottom)&(hit[:,3]>=top)];intervals=sorted((max(l,int(a)),min(r,int(c))) for a,_,c,_ in active);covered=0;end=l
            for a,c in intervals:
                if c>end:covered+=c-max(a,end);end=c
            total+=(r-l-covered)*(top-bottom)
    return total
for case in cases:
    key=case['key'];boxes=boxesbykey[key];groups=groupsbykey[key];scope=scopes[key];data=load(M/'turned-3'/(case['case']+'-capacity.json'));regioncache={}
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'];ys,xs=np.nonzero(domain)
    with np.load(COV/(key+'.npz'),allow_pickle=False) as z:indices=z['cell_signature'][domain[z['source_y'],z['source_x']]]
    assert len(indices)==len(xs);outside=np.zeros(len(xs),dtype=np.int64);upper=np.zeros(len(xs),dtype=np.int64);required=np.zeros(len(xs),dtype=np.int64)
    for si in np.unique(indices):
        group=groups[int(si)];assert group['remaining_inventory_indices'];region=set()
        for bi in group['retained_box_indices']:
            box=boxes[bi];_,l,b,r,t,*_=box['cover']
            for a,c,d,e in geometries[box['geometry']]['outer_component_bounds_um']:
                q=(max(l+a,stock[0]),max(b+c,stock[1]),min(r+d,stock[2]),min(t+e,stock[3]))
                if q[0]<q[2] and q[1]<q[3]:region.add(q)
        region=sorted(region);rects=np.array(region+list(map(tuple,data['fixed_inner_obstacles_um'])),dtype=np.int64);regioncache[int(si)]=[list(v) for v in region];positions=np.flatnonzero(indices==si);upper[positions]=group['combined_area_upper_um2'];required[positions]=min(scope['necessary_splits_if_last_cog_first'][ii]['first_companion_area_lower_um2'] for ii in group['remaining_inventory_indices'])
        for index in positions:outside[index]=complement_area(rects,int(ys[index]),int(xs[index]))
    forced=np.maximum(0,50000*10**6-outside);allowed=upper-forced>=required;remaining=domain.copy();remaining[ys,xs]=allowed;np.savez_compressed(OUT/(key+'.npz'),source_y=ys,source_x=xs,cover_signature=indices,outside_cog_area_upper_um2=outside,forced_companion_overlap_lower_um2=forced,conditional_companion_area_upper_um2=upper,required_companion_area_lower_um2=required,remaining_center_cells=remaining);regionrecords.append({'key':key,'conditional_regions':[{'signature':si,'regions_um':regioncache[si]} for si in sorted(regioncache)]});results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(xs),'conditional_regions_used':len(regioncache),'body_area_excluded_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'maximum_outside_cog_area_upper_um2':int(outside.max()),'provisional_exact_first32_excluded':not bool(allowed.any())})
write(OUT/'conditional-regions.json',regionrecords);write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':3,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
