"""Independent original-source support theorem and vertex-box corner witnesses."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-three-cog-frame-support-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-three-cog-exact-complement-20261108';HULL=ROOT/'output/h5-cog-hull-stock-20261108';OUTER=ROOT/'output/h5-free-cog-complement-20261108';CENTERS=ROOT/'output/h5-eight-core-centers-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',HULL/'audit',OUTER/'audit',CENTERS/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'support-vertex-proof.json',BASE/'support-regions.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Recheck exact original convex hull supporting halfplanes and every original vertex outer radius about the SAME source center. The hull support function maximum is attained by an ORIGINAL vertex, whose transverse coordinate satisfies radius squared minus support squared. Derive all four signed-axis offset boxes from axis/perpendicular vectors, not producer interval formulas. Independently verify the actual source frame inner rectangles by rational corner containment. Every excluded cell must have all16 center/offset box corner sums strictly within its witnessed frame inner rectangle. Reconcile every saved region, source identity and remaining cell. Strict-boundary, endpoint escape and sign controls prevent applying an infinite supporting plane to a finite frame.'})
parts={p['id']:p for p in load(JOB)['parts']};points=[tuple(map(Q,p)) for p in parts['cog']['geometry'][0]['outer']];record=load(BASE/'support-vertex-proof.json');hullrecord=load(HULL/'hull-support.json');outer=load(OUTER/'source-outer-bound.json');center=tuple(map(Q,record['source_center']));assert center==tuple(map(Q,hullrecord['source_center']))==tuple(map(Q,outer['source_center']));s=record['source_support_lower_um'];r=record['source_outer_radius_um'];b=record['transverse_upper_um'];assert (s,r,b)==(139000,140001,16712) and (b-1)**2<r*r-s*s<=b*b and record['squared_transverse_upper_um2']==r*r-s*s;hull=[tuple(map(Q,p)) for p in hullrecord['source_hull_vertices']];assert set(hull)<=set(points)
for a,z in zip(hull,hull[1:]+hull[:1]):
    value=cross(a,z,center);assert value>0 and all(cross(a,z,p)>=0 for p in points);assert value*value>=Q(s,1000)**2*sum((z[k]-a[k])**2 for k in range(2))
for p in points:assert sum((p[k]-center[k])**2 for k in range(2))<=Q(r,1000)**2
axes=[(1,0),(-1,0),(0,1),(0,-1)];offsets=[]
for dx,dy in axes:
    corners=[(along*dx-transverse*dy,along*dy+transverse*dx) for along,transverse in product([s,r],[-b,b])];offsets.append([min(p[0] for p in corners),min(p[1] for p in corners),max(p[0] for p in corners),max(p[1] for p in corners)])
assert offsets==record['signed_axis_support_vertex_offset_rectangles_um'];assert record['hull_disk_is_not_used_as_filled_body'];domain=hullrecord['necessary_stock_center_domain_um'];geometries={r['key']:r for r in load(CENTERS/'geometries.json')};regions={r['key']:r['regions'] for r in load(BASE/'support-regions.json')};cases=load(OLD/'audit/remaining-cases.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==len(regions)==3;framechecks=0;results=[];h=2500
def strictly_inside(point,box):return box[0]<point[0]<box[2] and box[1]<point[1]<box[3]
fixture=[0,0,350000,450000];assert strictly_inside((1,1),fixture) and not strictly_inside((0,1),fixture) and not strictly_inside((1,450001),fixture);assert offsets[0][0]==-offsets[1][2] and offsets[2][1]==-offsets[3][3]
for case in cases:
    key=case['key'];geometry=geometries[key];frames=geometry['frame_inner_rectangles'];rows={tuple([r['part_id'],r['copy_index']]):r for r in geometry['source_fixed_first32']};assert len(frames)==18
    for frame in frames:
        t=rows[tuple(frame['identity'])]['transform'];assert not t['mirrored'];c,sn=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));tx,ty=map(Q,t['translation']);p=[(Q(x)*c-Q(y)*sn+tx,Q(x)*sn+Q(y)*c+ty) for x,y in parts['frame']['geometry'][0]['outer']]
        if sum(a[0]*z[1]-a[1]*z[0] for a,z in zip(p,p[1:]+p[:1]))<0:p=p[::-1]
        l,bb,u,t=map(lambda n:Q(n,1000),frame['bounds_um']);pad=Q(1,10**6);assert all(cross(a,z,q)>0 for a,z in zip(p,p[1:]+p[:1]) for q in product([l-pad,u+pad],[bb-pad,t+pad]));framechecks+=1
    regionlist=regions[key];assert len(regionlist)==72 and {(v['frame_index'],v['signed_axis']) for v in regionlist}==set(product(range(18),range(4)))
    for region in regionlist:
        frame=frames[region['frame_index']];assert frame['identity']==region['frame_identity'];l,bb,u,t=frame['bounds_um'];a,c,d,e=offsets[region['signed_axis']];assert region['open_center_rectangle_um']==[l-a,bb-c,u-d,t-e]
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];ys,xs=np.nonzero(old)
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        assert np.array_equal(z['source_y'],ys) and np.array_equal(z['source_x'],xs);witness=z['support_witness'];assert witness.shape==xs.shape and np.all((witness>=-1)&(witness<72));remaining=old.copy();remaining[ys,xs]=witness<0;assert np.array_equal(remaining,z['remaining_center_cells'])
    for i in np.unique(witness[witness>=0]):
        mask=witness==i;sy,sx=ys[mask],xs[mask];l=np.maximum(sx*h,domain[0]);u=np.minimum((sx+1)*h,domain[2]);bb=np.maximum(sy*h,domain[1]);t=np.minimum((sy+1)*h,domain[3]);region=regionlist[int(i)];a,c,d,e=frames[region['frame_index']]['bounds_um'];ox0,oy0,ox1,oy1=offsets[region['signed_axis']]
        for x,y in product([l,u],[bb,t]):
            for ox,oy in product([ox0,ox1],[oy0,oy1]):assert np.all((x+ox>a)&(x+ox<d)&(y+oy>c)&(y+oy<e))
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(xs),'support_collision_cells_excluded':int((witness>=0).sum()),'remaining_center_cells':int((witness<0).sum()),'provisional_exact_first32_excluded':not bool((witness<0).any())};assert row==saved[key];results.append({**row,'exact_first32_excluded':not bool((witness<0).any())})
process=load(ROOT/'output/h5-three-cog-frame-support-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':3,'actual_source_frame_rectangles_verified':framechecks,'source_hull_halfplanes_reverified':len(hull),'source_outer_vertices_reverified':len(points),'signed_axis_support_regions_verified':216,'support_transverse_upper_mm':b/1000,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'support_collision_cells_excluded':sum(r['support_collision_cells_excluded'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'additional_exact_first32_cases_excluded':3-len(remaining),'exact_first32_cases_remaining':len(remaining),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
