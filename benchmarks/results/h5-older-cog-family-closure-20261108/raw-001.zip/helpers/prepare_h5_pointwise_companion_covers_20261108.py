"""Pointwise complete conditional center covers, including every collision boundary."""
from pathlib import Path
from hashlib import sha256
from math import isqrt
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pointwise-companion-covers-20261108';OLD=ROOT/'output/h5-coupled-cog-body-20261108';COV=ROOT/'output/h5-cog-companion-coupling-20261108';AREAS=ROOT/'output/h5-coupled-companion-areas-20261108';SUPPORT=ROOT/'output/h5-three-cog-frame-support-20261108';M=ROOT/'output/h5-one-three-covers-20261107';HULL=ROOT/'output/h5-cog-hull-stock-20261108';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==2 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',COV/'companion-boxes.json',COV/'audit/checks.json',AREAS/'conditional-groups.json',AREAS/'audit/checks.json',SUPPORT/'support-vertex-proof.json',SUPPORT/'audit/checks.json',M/'geometries.json',M/'audit/checks.json',HULL/'hull-support.json',G/'geometry.json',G/'audit/checks.json']+[p for r in cases for p in [OLD/(r['key']+'.npz'),COV/(r['key']+'.npz')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each remaining continuous cog cell C, derive22 source rectangles strictly in the universal109mm inner disk, then intersect their translations over every c in C to obtain compulsory filled cog rectangles. For every original companion inner component, rectangle overlap gives an OPEN forbidden center rectangle. Also derive finite-component support-vertex forbidden rectangles from the independently certified support-offset boxes. Subtract their union from every original conditional closed companion center box, splitting boxes rather than discarding only wholly blocked boxes. Preserve every boundary point, line and closed rectangle exactly. This yields complete conditional pointwise necessary covers; no source angle or center is sampled and no core exclusion is claimed until areas/inventories are independently checked.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
radius=109000;cuts=list(range(-100000,100001,10000));cuts=[-108000]+cuts+[108000];source_rects=[]
for b,t in zip(cuts,cuts[1:]):
    x=isqrt(radius*radius-max(b*b,t*t))-1;assert x>0 and x*x+max(b*b,t*t)<radius*radius;source_rects.append([-x,b,x,t])
assert len(source_rects)==22;write(OUT/'source-inner-disk-rectangles.json',{'radius_um':radius,'strict_source_rectangles_um':source_rects});geometries=load(M/'geometries.json');offsets=load(SUPPORT/'support-vertex-proof.json')['signed_axis_support_vertex_offset_rectangles_um'];domain=load(HULL/'hull-support.json')['necessary_stock_center_domain_um'];boxesbykey={r['key']:r['boxes'] for r in load(COV/'companion-boxes.json')};groupsbykey={r['key']:r['groups'] for r in load(AREAS/'conditional-groups.json')};h=2500;results=[]
def subtract(box,forbidden):
    l,b,r,t=box;a,c,d,e=forbidden
    if r<=a or l>=d or t<=c or b>=e:return [box]
    pieces=[]
    if l<=a:pieces.append((l,b,min(r,a),t))
    if r>=d:pieces.append((max(l,d),b,r,t))
    ml,mr=max(l,a),min(r,d)
    if ml<=mr:
        if b<=c:pieces.append((ml,b,mr,min(t,c)))
        if t>=e:pieces.append((ml,max(b,e),mr,t))
    return pieces
for case in cases:
    key=case['key'];boxes=boxesbykey[key];groups=groupsbykey[key]
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domainmask=z['remaining_center_cells'];ys,xs=np.nonzero(domainmask)
    with np.load(COV/(key+'.npz'),allow_pickle=False) as z:signatures=z['cell_signature'][domainmask[z['source_y'],z['source_x']]]
    cellrecords=[];pieces_total=0
    for y,x,si in zip(ys,xs,signatures):
        cbox=[max(int(x)*h,domain[0]),max(int(y)*h,domain[1]),min((int(x)+1)*h,domain[2]),min((int(y)+1)*h,domain[3])];cl,cb,cr,ct=cbox;common=[]
        for a,b,r,t in source_rects:
            q=(cr+a,ct+b,cl+r,cb+t)
            if q[0]<q[2] and q[1]<q[3]:common.append(q)
        modes=[];selected=groups[int(si)]['retained_box_indices']
        for g in geometries:
            original=sorted({tuple(boxes[bi]['cover'][1:5]) for bi in selected if boxes[bi]['geometry']==g['geometry']});forbidden=set()
            for a,b,r,t in g['inner_components_um']:
                for l,c,d,e in common:forbidden.add((l-r,c-t,d-a,e-b))
                for ox0,oy0,ox1,oy1 in offsets:
                    q=(cr+ox1-r,ct+oy1-t,cl+ox0-a,cb+oy0-b)
                    if q[0]<q[2] and q[1]<q[3]:forbidden.add(q)
            forbidden=sorted(forbidden);pieces=original
            for rectangle in forbidden:pieces=sorted({p for box in pieces for p in subtract(box,rectangle)})
            pieces_total+=len(pieces);modes.append({'geometry':g['geometry'],'original_center_boxes_um':[list(v) for v in original],'open_forbidden_center_rectangles_um':[list(v) for v in forbidden],'remaining_closed_center_boxes_um':[list(v) for v in pieces]})
        cellrecords.append({'cell_y':int(y),'cell_x':int(x),'prior_signature':int(si),'stock_clipped_cog_cell_um':cbox,'common_filled_cog_rectangles_um':[list(v) for v in common],'modes':modes})
    write(OUT/(key+'-covers.json'),cellrecords);results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'continuous_cog_cells':len(xs),'conditional_mode_covers':len(xs)*12,'remaining_closed_companion_boxes':pieces_total,'boundary_classes_preserved':True,'exact_first32_excluded':False})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':2,'continuous_cog_cells':sum(r['continuous_cog_cells'] for r in results),'conditional_mode_covers':sum(r['conditional_mode_covers'] for r in results),'remaining_closed_companion_boxes':sum(r['remaining_closed_companion_boxes'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
