"""Independent all-pair relative-corner witnesses and complete mode-cover audit."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-companion-coupling-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-three-cog-frame-support-20261108';M=ROOT/'output/h5-one-three-covers-20261107';HULL=ROOT/'output/h5-cog-hull-stock-20261108';G=ROOT/'output/h5-free-cog-geometry-v2-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',M/'audit',G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'companion-boxes.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct every retained source mode cover from its actual original omitted-site mask, preserving all boundary classes. Recheck source component inner rectangles using exact rational posed-source corner containment. For each nonzero conditional cell/box collision witness, independently evaluate the full16 combinations of cog-cell and companion-box corners; disk witnesses use exact nearest-point squared distances, support witnesses use all4 support-offset corners strictly inside the actual companion component. Every zero-witness box is retained. Decode each bit signature, verify all cells map to exactly their retained boxes, and verify every signature is used. No sampled source angle or chosen companion center is substituted.'})
geometries=load(M/'geometries.json');parts={p['id']:p for p in load(JOB)['parts']};modepairs={'bracket':set(),'insert':set()};componentchecks=0
for g in geometries:
    t=g['source_pose'];modepairs[g['family']].add((t['rotation_radians'],t['mirrored']));c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;tx,ty=map(Q,t['translation'])
    for component,box in zip(g['source_components'],g['inner_components_um']):
        p=[(sign*Q(x)*c-Q(y)*s+tx,sign*Q(x)*s+Q(y)*c+ty) for x,y in component]
        if sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))<0:p=p[::-1]
        l,b,r,t=map(lambda n:Q(n,1000),box);pad=Q(1,10**6);assert all(cross(a,z,q)>0 for a,z in zip(p,p[1:]+p[:1]) for q in product([l-pad,r+pad],[b-pad,t+pad]));componentchecks+=1
assert len(modepairs['bracket'])==8 and len(modepairs['insert'])==4;assert min(Q(r['segment_distance_squared']) for r in load(G/'geometry.json')['source_disk_edge_certificates'])>109**2;offsets=load(OLD/'support-vertex-proof.json')['signed_axis_support_vertex_offset_rectangles_um'];domain=load(HULL/'hull-support.json')['necessary_stock_center_domain_um'];cases=load(OLD/'audit/remaining-cases.json');inventories={r['key']:r['boxes'] for r in load(BASE/'companion-boxes.json')};saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==len(inventories)==3;results=[];h=2500
for case in cases:
    key=case['key'];allowed=sum(1<<i for i in case['omitted_sites']);boxes=[]
    for g in geometries:
        for index,row in enumerate(load(M/'turned-3'/f"geometry-{g['geometry']:02d}.json")['cover']):
            if row[0]&~allowed==0:boxes.append({'geometry':g['geometry'],'family':g['family'],'cover_index':index,'cover':row})
    assert boxes==inventories[key]
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:ys,xs=np.nonzero(z['remaining_center_cells'])
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        assert np.array_equal(z['source_y'],ys) and np.array_equal(z['source_x'],xs);witness=z['collision_witness'];assert witness.shape==(len(xs),len(boxes));signatures=z['retained_box_signatures'];inverse=z['cell_signature'];counts=z['signature_cell_counts'];decoded=np.unpackbits(signatures,axis=1,bitorder='little');assert not decoded[:,len(boxes):].any();decoded=decoded[:,:len(boxes)].astype(bool);assert np.array_equal(decoded[inverse],witness==0) and len(set(inverse.tolist()))==len(signatures) and np.array_equal(np.bincount(inverse,minlength=len(signatures)),counts) and np.all(counts>0);assert len({row.tobytes() for row in signatures})==len(signatures)
    for bi,box in enumerate(boxes):
        _,l,b,r,t,*_=box['cover'];components=geometries[box['geometry']]['inner_components_um'];assert np.all(witness[:,bi]<=5*len(components))
        for code in np.unique(witness[:,bi][witness[:,bi]>0]):
            selected=witness[:,bi]==code;sy,sx=ys[selected],xs[selected];cl=np.maximum(sx*h,domain[0]);cr=np.minimum((sx+1)*h,domain[2]);cb=np.maximum(sy*h,domain[1]);ct=np.minimum((sy+1)*h,domain[3]);ci,kind=divmod(int(code)-1,5);a,c,d,e=components[ci]
            for cx,cy in product([cl,cr],[cb,ct]):
                for px,py in product([l,r],[b,t]):
                    rx,ry=cx-px,cy-py
                    if kind==0:assert np.all((rx-np.clip(rx,a,d))**2+(ry-np.clip(ry,c,e))**2<109000**2)
                    else:
                        ox0,oy0,ox1,oy1=offsets[kind-1]
                        for ox,oy in product([ox0,ox1],[oy0,oy1]):assert np.all((rx+ox>a)&(rx+ox<d)&(ry+oy>c)&(ry+oy<e))
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'continuous_center_cells':len(xs),'original_companion_cover_boxes':len(boxes),'conditional_cell_box_pairs':int(witness.size),'collision_pairs_excluded':int((witness>0).sum()),'distinct_retained_cover_signatures':len(signatures),'minimum_retained_boxes':int((witness==0).sum(1).min()),'maximum_retained_boxes':int((witness==0).sum(1).max()),'exact_first32_excluded':False};assert row==saved[key];results.append(row)
process=load(ROOT/'output/h5-cog-companion-coupling-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'case-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':3,'original_companion_modes_verified':12,'source_component_inner_rectangles_verified':componentchecks,'conditional_cell_box_pairs_verified':sum(r['conditional_cell_box_pairs'] for r in results),'collision_pairs_excluded':sum(r['collision_pairs_excluded'] for r in results),'distinct_retained_cover_signatures':sum(r['distinct_retained_cover_signatures'] for r in results),'source_center_cells_preserved':sum(r['continuous_center_cells'] for r in results),'core_exclusions_claimed':0,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
