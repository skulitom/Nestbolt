"""Independent vertical signed-event conditional complement-area audit."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-coupled-cog-body-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-coupled-companion-areas-20261108';COV=ROOT/'output/h5-cog-companion-coupling-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108';KERNEL=ROOT/'output/h5-eight-cog-complement-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',COV/'audit',M/'audit',SCOPE,KERNEL/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'conditional-regions.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Bind the audited full original source-body, source-angle neighborhood, conditional covers, areas and every necessary inventory. Reconstruct every used conditional U_C from its original source mode components and selected boxes. Independently derive VERTICAL circular neighborhood stripes from minimum distances between closed cell rectangles. For every surviving center cell, sweep columns, split at all rectangle x endpoints and use signed y events to integrate uncovered outward-stock area exactly. This is orthogonal to producer horizontal merging and uses no producer area/cell weights. Verify all conditional capacities, inventory minima, compulsory cog occupancy and complete survivor masks.'})
stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];geometries=load(M/'geometries.json');boxesbykey={r['key']:r['boxes'] for r in load(COV/'companion-boxes.json')};groupsbykey={r['key']:r['groups'] for r in load(OLD/'conditional-groups.json')};scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};savedregions={r['key']:{g['signature']:g['regions_um'] for g in r['conditional_regions']} for r in load(BASE/'conditional-regions.json')};h=2500;radius=140001;stripes=[];kernelcount=0
for dx in range(-58,59):
    included=[]
    for dy in range(-58,59):
        distance=min((x-min(h,max(0,x)))**2+(y-min(h,max(0,y)))**2 for x in [dx*h,(dx+1)*h] for y in [dy*h,(dy+1)*h])
        if distance<=radius**2:included.append(dy)
    if included:assert included==list(range(min(included),max(included)+1)) and min(included)==-max(included);stripes.append((dx,max(included)));kernelcount+=len(included)
assert kernelcount==load(KERNEL/'kernel-stripes.json')['covered_target_cells']==10301
def exact_outside(rects,y,x):
    total=0
    for dx,w in stripes:
        left=max(stock[0],(x+dx)*h);right=min(stock[2],(x+dx+1)*h);bottom=max(stock[1],(y-w)*h);top=min(stock[3],(y+w+1)*h)
        if left>=right or bottom>=top:continue
        rows=rects[(rects[:,0]<right)&(rects[:,2]>left)&(rects[:,1]<top)&(rects[:,3]>bottom)];cuts=np.unique(np.r_[left,right,np.maximum(rows[:,0],left),np.minimum(rows[:,2],right)])
        for l,r in zip(cuts,cuts[1:]):
            active=rows[(rows[:,0]<=l)&(rows[:,2]>=r)];events={bottom:0,top:0}
            for _,b,_,t in active:
                b=max(int(b),bottom);t=min(int(t),top);events[b]=events.get(b,0)+1;events[t]=events.get(t,0)-1
            previous=bottom;depth=0;uncovered=0
            for coordinate,change in sorted(events.items()):
                if depth==0:uncovered+=coordinate-previous
                depth+=change;assert depth>=0;previous=coordinate
            assert depth==0;total+=int(r-l)*uncovered
    return total
cases=load(OLD/'audit/remaining-cases.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==3;results=[];regioncount=0
for case in cases:
    key=case['key'];boxes=boxesbykey[key];groups=groupsbykey[key];scope=scopes[key];data=load(M/'turned-3'/(case['case']+'-capacity.json'));cache={}
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'];ys,xs=np.nonzero(domain)
    with np.load(COV/(key+'.npz'),allow_pickle=False) as z:indices=z['cell_signature'][domain[z['source_y'],z['source_x']]]
    outside=[];uppers=[];requireds=[]
    for y,x,si in zip(ys,xs,indices):
        si=int(si);group=groups[si]
        if si not in cache:
            region=set()
            for bi in group['retained_box_indices']:
                box=boxes[bi];bounds=box['cover'][1:5]
                for component in geometries[box['geometry']]['outer_component_bounds_um']:
                    q=[bounds[k]+component[k] for k in range(4)];q=(max(q[0],stock[0]),max(q[1],stock[1]),min(q[2],stock[2]),min(q[3],stock[3]))
                    if q[0]<q[2] and q[1]<q[3]:region.add(q)
            region=sorted(region);assert [list(v) for v in region]==savedregions[key][si];cache[si]=np.array(region+list(map(tuple,data['fixed_inner_obstacles_um'])),dtype=np.int64);regioncount+=1
        outside.append(exact_outside(cache[si],int(y),int(x)));uppers.append(group['combined_area_upper_um2']);assert group['remaining_inventory_indices'];requireds.append(min(scope['necessary_splits_if_last_cog_first'][ii]['first_companion_area_lower_um2'] for ii in group['remaining_inventory_indices']))
    assert set(cache)==set(savedregions[key]);outside=np.array(outside,dtype=np.int64);upper=np.array(uppers,dtype=np.int64);required=np.array(requireds,dtype=np.int64);forced=np.maximum(0,50000*10**6-outside);allowed=forced<=upper-required;remaining=domain.copy();remaining[ys,xs]=allowed
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        for name,value in [('source_y',ys),('source_x',xs),('cover_signature',indices),('outside_cog_area_upper_um2',outside),('forced_companion_overlap_lower_um2',forced),('conditional_companion_area_upper_um2',upper),('required_companion_area_lower_um2',required),('remaining_center_cells',remaining)]:assert np.array_equal(z[name],value),(key,name)
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(xs),'conditional_regions_used':len(cache),'body_area_excluded_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'maximum_outside_cog_area_upper_um2':int(outside.max()),'provisional_exact_first32_excluded':not bool(allowed.any())};assert row==saved[key];results.append({**row,'exact_first32_excluded':not bool(allowed.any())})
process=load(ROOT/'output/h5-coupled-cog-body-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':3,'conditional_source_regions_verified':regioncount,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'exact_orthogonal_complement_queries':sum(r['input_center_cells'] for r in results),'body_area_excluded_center_cells':sum(r['body_area_excluded_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'additional_exact_first32_cases_excluded':3-len(remaining),'exact_first32_cases_remaining':len(remaining),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
