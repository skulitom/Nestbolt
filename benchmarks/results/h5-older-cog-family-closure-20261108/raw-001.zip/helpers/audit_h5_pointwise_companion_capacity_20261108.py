"""Independent exact swept-region, compulsory material and whole-inventory audit."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pointwise-companion-capacity-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-pointwise-companion-covers-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',M/'audit',SCOPE]:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*-capacities.json'))+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently rebuild every original component sweep over every pointwise conditional box. Use direct rectangle/cell-edge tests and boolean union slices, not signed corner prefixes, to compute exact areas before and after compulsory common cog material. Parent audits prove that common material belongs to the moving source at ALL centers/angles in the cell. Verify exact family/joint area bounds, monotonicity against the earlier source world, EVERY original necessary inventory and every complete center-cell survivor. Keep fixed-only and fixed-plus-cog capacities separate to prevent invalid later double subtraction.'})
geometries=load(M/'geometries.json');stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};cases=load(OLD/'audit/case-results.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==2;results=[];areacount=0;inventorycount=0
for case in cases:
    key=case['key'];scope=scopes[key];data=load(M/'turned-3'/(case['case']+'-capacity.json'));cells=load(OLD/(key+'-covers.json'));savedrows=load(BASE/(key+'-capacities.json'));assert len(cells)==len(savedrows);records=[];remaining=np.zeros((1200,600),dtype=bool)
    for cell,savedrow in zip(cells,savedrows):
        regions={'bracket':set(),'insert':set()}
        for mode in cell['modes']:
            g=geometries[mode['geometry']]
            for bounds in mode['remaining_closed_center_boxes_um']:
                for component in g['outer_component_bounds_um']:
                    q=[bounds[k]+component[k] for k in range(4)];q=(max(q[0],stock[0]),max(q[1],stock[1]),min(q[2],stock[2]),min(q[3],stock[3]))
                    if q[0]<q[2] and q[1]<q[3]:regions[g['family']].add(q)
        fixed=data['fixed_inner_obstacles_um'];common=cell['common_filled_cog_rectangles_um'];rectangles=np.array(list(regions['bracket'])+list(regions['insert'])+list(map(tuple,fixed))+list(map(tuple,common)),dtype=np.int64);xs=np.unique(rectangles[:,[0,2]]);ys=np.unique(rectangles[:,[1,3]]);weights=np.diff(ys)[:,None]*np.diff(xs)[None,:]
        def direct(rows):
            mask=np.zeros(weights.shape,dtype=bool)
            for a,b,c,d in rows:
                xi=np.flatnonzero((xs[:-1]>=a)&(xs[1:]<=c));yi=np.flatnonzero((ys[:-1]>=b)&(ys[1:]<=d))
                if len(xi) and len(yi):mask[yi[0]:yi[-1]+1,xi[0]:xi[-1]+1]=True
            return mask
        clear=~direct(fixed);withoutcog=clear&~direct(common);family={f:direct(regions[f]) for f in regions};joint=family['bracket']|family['insert'];before={f:int(weights[family[f]&clear].sum()) for f in family};after={f:int(weights[family[f]&withoutcog].sum()) for f in family};jointbefore=int(weights[joint&clear].sum());jointafter=int(weights[joint&withoutcog].sum());assert jointafter<=jointbefore<=data['combined_area_upper_um2'] and all(after[f]<=before[f]<=data['family_occupied_area_upper_um2'][f] for f in family);areacount+=6;possible=[]
        for ii,split in enumerate(scope['necessary_splits_if_last_cog_first']):
            needed={'bracket':(12-split['short_brackets'])*39999*10**6,'insert':(21-split['short_inserts'])*19799*10**6};assert sum(needed.values())==split['first_companion_area_lower_um2'];inventorycount+=1
            if all(needed[f]<=after[f] for f in family) and sum(needed.values())<=jointafter:possible.append(ii)
        row={'cell_y':cell['cell_y'],'cell_x':cell['cell_x'],'prior_signature':cell['prior_signature'],'family_area_before_common_cog_um2':before,'joint_area_before_common_cog_um2':jointbefore,'family_area_after_common_cog_um2':after,'joint_area_after_common_cog_um2':jointafter,'remaining_inventory_indices':possible,'inventory_excluded':not bool(possible)};assert row==savedrow;records.append(row);remaining[cell['cell_y'],cell['cell_x']]=bool(possible)
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:assert np.array_equal(remaining,z['remaining_center_cells'])
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(cells),'inventory_excluded_center_cells':len(cells)-int(remaining.sum()),'remaining_center_cells':int(remaining.sum()),'maximum_joint_area_before_common_cog_um2':max(r['joint_area_before_common_cog_um2'] for r in records),'maximum_joint_area_after_common_cog_um2':max(r['joint_area_after_common_cog_um2'] for r in records),'provisional_exact_first32_excluded':not bool(remaining.any())};assert row==saved[key];results.append({**row,'exact_first32_excluded':not bool(remaining.any())})
process=load(ROOT/'output/h5-pointwise-companion-capacity-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':2,'exact_conditional_area_bounds_verified':areacount,'original_whole_inventory_tests_verified':inventorycount,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'inventory_excluded_center_cells':sum(r['inventory_excluded_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'additional_exact_first32_cases_excluded':2-len(remaining),'exact_first32_cases_remaining':len(remaining),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
