"""Exact conditional companion capacity for every complete retained-cover signature."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-coupled-companion-areas-20261108';OLD=ROOT/'output/h5-cog-companion-coupling-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/case-results.json');assert len(cases)==3 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/case-results.json',OLD/'companion-boxes.json',M/'geometries.json',M/'stock-cover.json',M/'audit/checks.json',SCOPE/'remaining-core-scopes.json',SCOPE/'checks.json']+[p for r in cases for p in [OLD/(r['key']+'.npz'),M/'turned-3'/(r['case']+'-capacity.json')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Every cog center cell has an independently certified complete conditional cover of possible companion-mode centers. For each distinct retained-box signature, sweep every original companion component outer bound over its retained center box, clip to outward stock, and take exact unions minus mandatory fixed-source inner obstacles. Compute bracket, insert and joint occupied-area upper bounds with integer rectangle-boundary grids. Test EVERY previously necessary whole-part inventory using conservative source areas39999/19799mm2. A cog center cell is excluded only if its complete conditional cover cannot fit any inventory. No moving-cog body subtraction is used in this stage. Reconstruct the unfiltered source areas exactly as positive controls.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
geometries=load(M/'geometries.json');stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];inventories={r['key']:r['boxes'] for r in load(OLD/'companion-boxes.json')};scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};results=[];allgroups=[];grid_sizes=[]
for case in cases:
    key=case['key'];boxes=inventories[key];data=load(M/'turned-3'/(case['case']+'-capacity.json'));scope=scopes[key];bybox=[]
    for box in boxes:
        _,l,b,r,t,*_=box['cover'];rects=[]
        for a,c,d,e in geometries[box['geometry']]['outer_component_bounds_um']:
            q=[max(l+a,stock[0]),max(b+c,stock[1]),min(r+d,stock[2]),min(t+e,stock[3])]
            if q[0]<q[2] and q[1]<q[3]:rects.append(tuple(q))
        bybox.append(rects)
    full={family:sorted({r for box,rects in zip(boxes,bybox) if box['family']==family for r in rects}) for family in ['bracket','insert']};assert all([list(v) for v in full[f]]==data['occupied_component_regions_um'][f] for f in full);fixed=data['fixed_inner_obstacles_um'];allrects=data['combined_regions_um']+fixed;xs=sorted({r[k] for r in allrects for k in [0,2]});ys=sorted({r[k] for r in allrects for k in [1,3]});xi={x:i for i,x in enumerate(xs)};yi={y:i for i,y in enumerate(ys)};grid_sizes.append([key,len(ys)-1,len(xs)-1]);assert len(xs)*len(ys)<4000000
    def mask(rectangles):
        diff=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for a,b,c,d in rectangles:diff[yi[b],xi[a]]+=1;diff[yi[d],xi[a]]-=1;diff[yi[b],xi[c]]-=1;diff[yi[d],xi[c]]+=1
        return diff.cumsum(0,dtype=np.int32).cumsum(1,dtype=np.int32)[:-1,:-1]>0
    weights=np.diff(np.array(ys,dtype=np.int64))[:,None]*np.diff(np.array(xs,dtype=np.int64))[None,:];weights[mask(fixed)]=0
    original={f:mask(full[f]) for f in full};assert {f:int(weights[original[f]].sum()) for f in full}==data['family_occupied_area_upper_um2'] and int(weights[original['bracket']|original['insert']].sum())==data['combined_area_upper_um2']
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:ysource=z['source_y'];xsource=z['source_x'];inverse=z['cell_signature'];signatures=np.unpackbits(z['retained_box_signatures'],axis=1,bitorder='little')[:,:len(boxes)].astype(bool)
    groups=[];viable=[]
    for si,keep in enumerate(signatures):
        selected=np.flatnonzero(keep).tolist();regions={f:sorted({r for bi in selected if boxes[bi]['family']==f for r in bybox[bi]}) for f in full};masks={f:mask(regions[f]) for f in full};areas={f:int(weights[masks[f]].sum()) for f in full};joint=int(weights[masks['bracket']|masks['insert']].sum());remaining=[]
        for ii,split in enumerate(scope['necessary_splits_if_last_cog_first']):
            nb,ni=12-split['short_brackets'],21-split['short_inserts'];assert nb*39999*10**6+ni*19799*10**6==split['first_companion_area_lower_um2']
            if nb*39999*10**6<=areas['bracket'] and ni*19799*10**6<=areas['insert'] and split['first_companion_area_lower_um2']<=joint:remaining.append(ii)
        viable.append(bool(remaining));groups.append({'signature':si,'retained_box_indices':selected,'family_area_upper_um2':areas,'combined_area_upper_um2':joint,'remaining_inventory_indices':remaining,'whole_inventory_excluded':not bool(remaining)})
    viable=np.array(viable,dtype=bool);cellgood=viable[inverse];remaining=np.zeros((1200,600),dtype=bool);remaining[ysource,xsource]=cellgood;np.savez_compressed(OUT/(key+'.npz'),source_y=ysource,source_x=xsource,signature_viable=viable,remaining_center_cells=remaining);allgroups.append({'key':key,'groups':groups});results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(xsource),'input_cover_signatures':len(signatures),'inventory_excluded_signatures':int((~viable).sum()),'inventory_excluded_center_cells':int((~cellgood).sum()),'remaining_center_cells':int(cellgood.sum()),'maximum_conditional_companion_area_upper_um2':max(g['combined_area_upper_um2'] for g in groups),'provisional_exact_first32_excluded':not bool(cellgood.any())})
write(OUT/'conditional-groups.json',allgroups);write(OUT/'grid-sizes.json',grid_sizes);write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':3,'conditional_area_signatures':sum(r['input_cover_signatures'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
