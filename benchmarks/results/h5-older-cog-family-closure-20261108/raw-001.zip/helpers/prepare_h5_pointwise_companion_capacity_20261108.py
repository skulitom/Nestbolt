"""Exact capacities after complete pointwise source-collision cover subtraction."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pointwise-companion-capacity-20261108';OLD=ROOT/'output/h5-pointwise-companion-covers-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/case-results.json');assert len(cases)==2 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/case-results.json',M/'geometries.json',M/'stock-cover.json',M/'audit/checks.json',SCOPE/'remaining-core-scopes.json',SCOPE/'checks.json']+[p for r in cases for p in [OLD/(r['key']+'-covers.json'),M/'turned-3'/(r['case']+'-capacity.json')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Sweep original companion component outer bounds over every independently certified pointwise conditional closed center box. Compute exact family/joint union areas on integer boundary grids. Subtract mandatory fixed-source inner rectangles, and separately subtract their union with the common source cog rectangles certified for every point/angle in this cog cell. Valid companions cannot occupy either fixed material or that compulsory filled cog material. Test every necessary original whole-part inventory using conservative39999/19799mm2 component areas. Keep both before/after-common-body capacities explicitly; do not later use common cog material as if disjoint from the cog in a full-body conservation proof. No whole original layout or optimizer.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
geometries=load(M/'geometries.json');stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};results=[];gridmax=0
for case in cases:
    key=case['key'];scope=scopes[key];data=load(M/'turned-3'/(case['case']+'-capacity.json'));cells=load(OLD/(key+'-covers.json'));records=[];remaining=np.zeros((1200,600),dtype=bool)
    for cell in cells:
        regions={'bracket':set(),'insert':set()}
        for mode in cell['modes']:
            g=geometries[mode['geometry']]
            for l,b,r,t in mode['remaining_closed_center_boxes_um']:
                for a,c,d,e in g['outer_component_bounds_um']:
                    q=(max(l+a,stock[0]),max(b+c,stock[1]),min(r+d,stock[2]),min(t+e,stock[3]))
                    if q[0]<q[2] and q[1]<q[3]:regions[g['family']].add(q)
        regions={f:sorted(v) for f,v in regions.items()};fixed=data['fixed_inner_obstacles_um'];common=cell['common_filled_cog_rectangles_um'];allrects=regions['bracket']+regions['insert']+list(map(tuple,fixed))+list(map(tuple,common));xs=sorted({r[k] for r in allrects for k in [0,2]});ys=sorted({r[k] for r in allrects for k in [1,3]});xi={v:i for i,v in enumerate(xs)};yi={v:i for i,v in enumerate(ys)};gridmax=max(gridmax,len(xs)*len(ys));assert gridmax<4000000
        def mask(rows):
            diff=np.zeros((len(ys),len(xs)),dtype=np.int32)
            for a,b,c,d in rows:diff[yi[b],xi[a]]+=1;diff[yi[d],xi[a]]-=1;diff[yi[b],xi[c]]-=1;diff[yi[d],xi[c]]+=1
            return diff.cumsum(0,dtype=np.int32).cumsum(1,dtype=np.int32)[:-1,:-1]>0
        weights=np.diff(np.array(ys,dtype=np.int64))[:,None]*np.diff(np.array(xs,dtype=np.int64))[None,:];fixedmask=mask(fixed);commonmask=mask(common);family={f:mask(regions[f]) for f in regions};joint=family['bracket']|family['insert'];before={f:int(weights[family[f]&~fixedmask].sum()) for f in family};after={f:int(weights[family[f]&~fixedmask&~commonmask].sum()) for f in family};jointbefore=int(weights[joint&~fixedmask].sum());jointafter=int(weights[joint&~fixedmask&~commonmask].sum());assert jointafter<=jointbefore<=data['combined_area_upper_um2'];possible=[]
        for ii,split in enumerate(scope['necessary_splits_if_last_cog_first']):
            rb=(12-split['short_brackets'])*39999*10**6;ri=(21-split['short_inserts'])*19799*10**6;assert rb+ri==split['first_companion_area_lower_um2']
            if rb<=after['bracket'] and ri<=after['insert'] and rb+ri<=jointafter:possible.append(ii)
        remaining[cell['cell_y'],cell['cell_x']]=bool(possible);records.append({'cell_y':cell['cell_y'],'cell_x':cell['cell_x'],'prior_signature':cell['prior_signature'],'family_area_before_common_cog_um2':before,'joint_area_before_common_cog_um2':jointbefore,'family_area_after_common_cog_um2':after,'joint_area_after_common_cog_um2':jointafter,'remaining_inventory_indices':possible,'inventory_excluded':not bool(possible)})
    write(OUT/(key+'-capacities.json'),records);np.savez_compressed(OUT/(key+'.npz'),remaining_center_cells=remaining);results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(cells),'inventory_excluded_center_cells':len(cells)-int(remaining.sum()),'remaining_center_cells':int(remaining.sum()),'maximum_joint_area_before_common_cog_um2':max(r['joint_area_before_common_cog_um2'] for r in records),'maximum_joint_area_after_common_cog_um2':max(r['joint_area_after_common_cog_um2'] for r in records),'provisional_exact_first32_excluded':not bool(remaining.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':2,'maximum_exact_grid_size':gridmax,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
