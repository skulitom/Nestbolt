"""Independent direct exact-region union masks and all-inventory capacity audit."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-coupled-companion-areas-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-cog-companion-coupling-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',M/'audit',SCOPE]:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'conditional-groups.json',BASE/'grid-sizes.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently reconstruct every conditional component sweep from the original retained mode/box signature and source-certified outer components, with outward-stock clipping. Build exact coordinate cells at every region/obstacle boundary; fill rectangle unions by direct cell-edge interval tests and boolean slices, not producer signed corner prefixes. Subtract fixed-source inner obstacles and compute all family/joint areas. Reproduce every original unfiltered area as control. Independently enumerate every necessary whole-part inventory and reconcile all signature choices, cell mappings, exclusions and survivors. The complete conditional covers apply to every source angle and every point of each center cell.'})
geometries=load(M/'geometries.json');stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];inventories={r['key']:r['boxes'] for r in load(OLD/'companion-boxes.json')};scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};cases=load(OLD/'audit/case-results.json');saved={r['key']:r for r in load(BASE/'case-results.json')};savedgroups={r['key']:r['groups'] for r in load(BASE/'conditional-groups.json')};assert len(cases)==len(saved)==len(savedgroups)==3;results=[];inventorychecks=0;areasverified=0
for case in cases:
    key=case['key'];boxes=inventories[key];data=load(M/'turned-3'/(case['case']+'-capacity.json'));scope=scopes[key];bybox=[]
    for box in boxes:
        bounds=box['cover'][1:5];rects=[]
        for component in geometries[box['geometry']]['outer_component_bounds_um']:
            q=[bounds[k]+component[k] for k in range(4)];q=[max(q[0],stock[0]),max(q[1],stock[1]),min(q[2],stock[2]),min(q[3],stock[3])]
            if q[0]<q[2] and q[1]<q[3]:rects.append(tuple(q))
        bybox.append(rects)
    full={f:sorted({r for bi,box in enumerate(boxes) if box['family']==f for r in bybox[bi]}) for f in ['bracket','insert']};assert all([list(v) for v in full[f]]==data['occupied_component_regions_um'][f] for f in full);rects=data['combined_regions_um']+data['fixed_inner_obstacles_um'];xs=np.unique(np.array(rects,dtype=np.int64)[:,[0,2]]);ys=np.unique(np.array(rects,dtype=np.int64)[:,[1,3]]);width=xs[1:]-xs[:-1];height=ys[1:]-ys[:-1]
    def direct(rows):
        mask=np.zeros((len(height),len(width)),dtype=bool)
        for a,b,c,d in rows:
            xi=np.flatnonzero((xs[:-1]>=a)&(xs[1:]<=c));yi=np.flatnonzero((ys[:-1]>=b)&(ys[1:]<=d))
            if len(xi) and len(yi):mask[yi[0]:yi[-1]+1,xi[0]:xi[-1]+1]=True
        return mask
    available=~direct(data['fixed_inner_obstacles_um']);weights=height[:,None]*width[None,:];original={f:direct(full[f]) for f in full};assert {f:int(weights[original[f]&available].sum()) for f in full}==data['family_occupied_area_upper_um2'] and int(weights[(original['bracket']|original['insert'])&available].sum())==data['combined_area_upper_um2']
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:ysource=z['source_y'];xsource=z['source_x'];inverse=z['cell_signature'];signatures=np.unpackbits(z['retained_box_signatures'],axis=1,bitorder='little')[:,:len(boxes)].astype(bool)
    assert len(signatures)==len(savedgroups[key]);viable=[];groups=[]
    for si,keep in enumerate(signatures):
        chosen=np.flatnonzero(keep).tolist();regions={f:sorted({r for bi in chosen if boxes[bi]['family']==f for r in bybox[bi]}) for f in full};masks={f:direct(regions[f]) for f in full};areas={f:int(weights[masks[f]&available].sum()) for f in full};joint=int(weights[(masks['bracket']|masks['insert'])&available].sum());areasverified+=3;remaining=[]
        for ii,split in enumerate(scope['necessary_splits_if_last_cog_first']):
            required={'bracket':(12-split['short_brackets'])*39999*10**6,'insert':(21-split['short_inserts'])*19799*10**6};assert sum(required.values())==split['first_companion_area_lower_um2'];inventorychecks+=1
            if all(required[f]<=areas[f] for f in full) and sum(required.values())<=joint:remaining.append(ii)
        row={'signature':si,'retained_box_indices':chosen,'family_area_upper_um2':areas,'combined_area_upper_um2':joint,'remaining_inventory_indices':remaining,'whole_inventory_excluded':not bool(remaining)};assert row==savedgroups[key][si];groups.append(row);viable.append(bool(remaining))
    viable=np.array(viable,dtype=bool);cellgood=viable[inverse];remaining=np.zeros((1200,600),dtype=bool);remaining[ysource,xsource]=cellgood
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        for name,value in [('source_y',ysource),('source_x',xsource),('signature_viable',viable),('remaining_center_cells',remaining)]:assert np.array_equal(z[name],value),(key,name)
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(xsource),'input_cover_signatures':len(signatures),'inventory_excluded_signatures':int((~viable).sum()),'inventory_excluded_center_cells':int((~cellgood).sum()),'remaining_center_cells':int(cellgood.sum()),'maximum_conditional_companion_area_upper_um2':max(g['combined_area_upper_um2'] for g in groups),'provisional_exact_first32_excluded':not bool(cellgood.any())};assert row==saved[key];results.append({**row,'exact_first32_excluded':not bool(cellgood.any())})
process=load(ROOT/'output/h5-coupled-companion-areas-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':3,'conditional_area_bounds_verified':areasverified,'whole_inventory_tests_verified':inventorychecks,'original_unfiltered_area_controls':9,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'inventory_excluded_center_cells':sum(r['inventory_excluded_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'additional_exact_first32_cases_excluded':3-len(remaining),'exact_first32_cases_remaining':len(remaining),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
