"""Seal complete closure of the older eight fixed cores and distinct frontier scope."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
stage_names=['three-cog-frame-support','cog-companion-coupling','coupled-companion-areas','coupled-cog-body','pointwise-companion-covers','pointwise-companion-capacity','last-pointwise-cog-body']
process_names=[v+s for v in stage_names for s in ['', '-audit']]+['remaining-fixed29-scope'];process_paths=[ROOT/'output'/('h5-'+n+'-process-20261108') for n in process_names]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-older-cog-family-closure-20261108'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-last-pointwise-cog-body-20261108';F=BASE/'audit';D=ROOT/'output/h5-remaining-fixed29-scope-20261108'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-older-cog-center-bounds-20261108'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['cases_verified']==1 and front['exact_first32_cases_remaining']==0 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[ROOT/'output'/('h5-'+n+'-20261108') for n in stage_names]+[D,ROOT/'output/h5-older-cog-bounds-main-sync-20261108']+process_paths",
"['*h5*mixed*mode*20261107.py']":"['*h5_three_cog_frame_support*20261108.py','*h5_cog_companion_coupling*20261108.py','*h5_coupled_companion_areas*20261108.py','*h5_coupled_cog_body*20261108.py','*h5_pointwise_companion*20261108.py','*h5_last_pointwise_cog_body*20261108.py','*h5_remaining_fixed29_scope*20261108.py','*h5_older_cog_closure*20261108.py','h5_exact_circular_complement_20261108.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_older_cog_closure_checkpoint_20261108.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
scope=load(D/'checks.json');assert scope['passed'] and scope['remaining_fixed29_choices_verified']==4;total=scope['inherited_preparation_seconds']+load(process_paths[-1]/'process.json')['complete_seconds'];copies=[];process_table=[]
for name in stage_names:
    folder=ROOT/'output'/('h5-'+name+'-20261108');assert load(folder/'audit/checks.json')['passed'];copies.extend([(folder/'plan.json',name+'-plan.json'),(folder/'audit/checks.json',name+'-audit.json'),(folder/'audit/case-results.json',name+'-cases.json')])
copies.extend([(ROOT/'output/h5-three-cog-frame-support-20261108/support-vertex-proof.json','source-support-vertex-proof.json'),(ROOT/'output/h5-pointwise-companion-covers-20261108/source-inner-disk-rectangles.json','source-inner-disk-rectangles.json'),(F/'remaining-cases.json','remaining-older-core-cases.json'),(BASE/'cell-results.json','last-core-cell-deficits.json'),(D/'plan.json','remaining-fixed29-scope-plan.json'),(D/'checks.json','remaining-fixed29-scope-audit.json'),(D/'remaining-fixed29-scopes.json','remaining-fixed29-scopes.json'),(ROOT/'output/h5-older-cog-bounds-main-sync-20261108/receipt.json','prior-main-push-receipt.json')])
for name,folder in zip(process_names,process_paths):
    r=load(folder/'process.json');assert r['passed'] and r['closed'] and r['job']['active_processes']==0;copies.append((folder/'process.json',name+'-process.json'));process_table.append({'stage':name,'seconds':r['complete_seconds'],'cap_seconds':r['job']['maximum_ms']/1000,'closed':True,'active_processes':0})
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'process-summary.json',process_table)
frontier={r['key']:r for r in load(PARENT/'older-eight-core-frontier.json')};assert len(frontier)==8 and sum(r['exact_first32_excluded'] for r in frontier.values())==5
for name in ['three-cog-frame-support','coupled-companion-areas','coupled-cog-body','pointwise-companion-capacity','last-pointwise-cog-body']:
    rows=load(ROOT/'output'/('h5-'+name+'-20261108')/'audit/case-results.json');assert {r['key'] for r in rows}=={k for k,v in frontier.items() if not v['exact_first32_excluded']}
    for r in rows:
        v=frontier[r['key']];assert v['omitted_sites']==r['omitted_sites'];v['remaining_continuous_center_cells']=r['remaining_center_cells']
        if r['exact_first32_excluded']:v['exact_first32_excluded']=True;v['first_excluding_stage']=name
assert all(r['exact_first32_excluded'] for r in frontier.values());write(OUT/'older-eight-core-frontier.json',list(frontier.values()))
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42531430629','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='dc7f004ee664b29544a511f1153e002ebf652076';success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'older_first32_initial_cases':8,'older_first32_prior_exclusions':5,'older_first32_new_exclusions':3,'older_first32_cases_excluded':8,'older_first32_cases_remaining':0,'closed_separate_current_family_cases':680,'remaining_fixed29_choices':4,'complete_preparation_seconds_if_consumed':total,'all_inherited_failures_preserved':True})
write(OUT/'next-step.json',{'status':'all_eight_older_exact_first32_cores_excluded','remaining_distinct_fixed29_choices':[[0,5,10],[5,10,11],[10,11,12],[11,12,13]],'proposal':'All688 exact first32 cores from the two recorded families are now closed; do not reopen them or their optimizers. The separate surviving fixed29/source-cog scopes use18fixedframes+11fixedinserts,12fixedcogsites, and8bracket+8insert movers, with a validated4/2/3 short9. Their source counts differ from the closed14-cog-first32 cores. Inspect the latest closed capacity-model/graph records before considering any new pointwise source-cover or coupled-area strengthening; preserve all original modes, complete boundary classes and higher-order strip constraints. A new proof/model requires genuinely new certified geometry/constraints and independent controls; no unchanged model may rerun. Any future timed constructor must independently recompute source inputs and pass a separate preparation-inclusive budget preflight. The present numeric lineage is exhausted.','latest_fixed29_frontier':'benchmarks/results/h5-strip-capacity-models-20261107','closed_capacity_calls_reopened':False,'new_graph_or_model_prepared':False,'consumed_preparation_seconds':total,'optimizer_allowed_from_current_lineage':False,'whole_allocation_candidates_remaining':440,'source_valid66':False,'optimizer_calls':0,'H5_complete':False})
process_rows='\n'.join(f"| {r['stage']} | {r['seconds']:.6f} | {r['cap_seconds']:.0f} |" for r in process_table)
report=f'''# All eight older fixed cog cores excluded — 2026-11-08

**Complete source-angle and continuous-center proofs exclude the final three
older exact first32 cores. All eight older cores are now closed**, alongside
the separate 680-case five-column family. These are conditional results for
their actual eighteen fixed frames and fourteen fixed cogs. They exclude no
whole allocation or orientation class. H2/H5 remain open at **60% completed
milestone weight**, and the valid64 layout remains best.

[A finite-frame support proof]({NAME}/source-support-vertex-proof.json) uses an
actual original cog vertex maximizing each signed axis projection. The source
hull guarantees projection at least139 mm; source outer radius140.001 mm bounds
that vertex's transverse displacement by **16.712 mm**. A whole center cell is
excluded only when every possible support-vertex offset lies strictly inside
an actual source frame inner rectangle. The hull disk is never treated as
filled source material. [Independent original-source and corner checks]({NAME}/three-cog-frame-support-audit.json)
remove381 cells, leaving3,325 across the same three cases.

[Conditional companion covers]({NAME}/cog-companion-coupling-plan.json) then
test every combination of a cog center cell and an original companion-mode
center box. Guaranteed collisions use the source109 mm inner disk or an actual
support vertex. Every box lacking a whole-product witness remains.
[The independent audit]({NAME}/cog-companion-coupling-audit.json) verifies all
**601,444 cell/box pairs**, excluding251,910 and retaining319 distinct complete
cover signatures. All twelve original bracket/insert modes and twenty source
component inner rectangles are checked.

[Exact conditional capacities]({NAME}/coupled-companion-areas-audit.json)
verify957 family/joint area bounds and6,803 necessary whole-inventory tests,
including nine original unfiltered area controls. They exclude2,638 center
cells, leaving687. This changes the possible companion regions as a function
of the cog position; it is stronger than subtracting cog area from one global
companion envelope.

[Full-body conservation]({NAME}/coupled-cog-body-plan.json) uses each conditional
companion union `U_C` and mandatory fixed-source inner union `F`. Valid companions
lie in `U_C minus F`. A valid source cog is disjoint from `F`; its area outside
the companion region is bounded by its complete circular neighborhood outside
`U_C union F`. The remaining cog area is unavailable to companions.
[Independent orthogonal exact-area sweeps]({NAME}/coupled-cog-body-audit.json)
check687 queries and218 conditional regions. They exclude545 cells and close
`omit-03-15`, with minimum deficit**428.925791 mm²**. Two cores and142 cells remain.

[Pointwise center-cover subtraction]({NAME}/pointwise-companion-covers-plan.json)
splits the remaining companion boxes at certified collision boundaries. Twenty-two
rectangles lie strictly in the universal source109 mm disk; intersecting their
translations over the entire cog cell yields compulsory filled cog material.
Each component overlap gives an open forbidden companion-center rectangle;
the finite-component support-vertex proof contributes further forbidden regions.
All boundary points and lines remain in the closed surviving covers.

[The independent complete-class audit]({NAME}/pointwise-companion-covers-audit.json)
does not repeat producer subtraction. It checks equality of the original closed
cover minus the open forbidden union and the produced closed cover on
**29,480,658 exact point/open-interval classes**. It verifies1,704 conditional
mode covers and49,984 common source-disk corner distances. All142 cog cells
remain represented; this stage alone claims no exclusion.

[Exact pointwise capacities]({NAME}/pointwise-companion-capacity-audit.json)
verify852 family/joint area bounds and2,972 original inventory tests. They keep
separate capacities before and after common cog material subtraction.
All120 cells of `omit-03-07` fail: even its largest fixed-only companion region
is at most**429,601.977897 mm²**, below the universal435,979 mm² required lower.
The last core, `omit-14-15`, retains22 cells.

[Final full-body readback]({NAME}/last-pointwise-cog-body-audit.json) applies the
whole source cog area lower50,000 mm² to those22 complete pointwise covers.
It uses the fixed-only capacity before common cog material subtraction, and
`F` contains only fixed-source obstacles, avoiding double subtraction.
Independent vertical signed-event sweeps agree with horizontal interval merging
on every circular-neighborhood complement area. **All22 cells fail**, with
minimum deficit**1,411.178149 mm²**. [Every final deficit is preserved]({NAME}/last-core-cell-deficits.json).
[The older-core frontier is empty]({NAME}/remaining-older-core-cases.json);
[all eight original identities and first exclusion stages reconcile]({NAME}/older-eight-core-frontier.json).

[Broader scope readback]({NAME}/remaining-fixed29-scope-audit.json) preserves
four distinct older fixed29/source-cog choices: **[0,5,10], [5,10,11],
[10,11,12], [11,12,13]**. Their fixed29 consists of18frames and11inserts, with
twelve of fifteen cog sites and eight bracket/eight insert movers on the first
sheet. The independently source-valid short9 contains four brackets, two inserts
and three cogs. [All66 identities and these exact scopes reconcile]({NAME}/remaining-fixed29-scopes.json).
These differ from the newly closed fourteen-cog-first32 family. All four latest
capacity-model calls remain closed at their proof-byte limits, with no accepted
proof or placement; no new exclusion transfers to them.

| Bounded stage | Complete process (s) | Cap (s) |
|---|---:|---:|
{process_rows}

[All fifteen processes close]({NAME}/process-summary.json) with zero children,
unchanged CCD1/thread controls and2 GiB Windows Job limits. Consumed preparation
is **{total:.6f} s**, including inherited failed work. No optimizer is opened,
no timer resets and no timed H5 acceptance is claimed.

[Next]({NAME}/next-step.json), assess genuinely new source constraints for the
four distinct remaining fixed29 choices, preserving their complete domains and
latest strip-capacity constraints. All440 whole-job allocations, full66
source/native/material validation, production integration/parity and the full
H5 matrix remain open. Product, README and release state are unchanged.

[The previous checkpoint reached maindc7f004e]({NAME}/prior-main-push-receipt.json).
[CI at review]({NAME}/main-ci-at-review.json) has**{success} passed / {live} live jobs**;
this checkpoint awaits the ordinary push gate.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve all consumed evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-08 H5 older cog-family closure:** [complete conditional pointwise source proofs]({{link}}) exclude all three remaining older exact first32 cores; all eight are now closed alongside the separate680-case family. Actual support vertices remove381 cells. Complete companion coupling verifies601444 cell/box pairs and319 cover signatures;957 exact area bounds and6803 inventory tests leave687 cells. Orthogonal full-body complement sweeps close omit-03-15. Pointwise forbidden-center subtraction preserves all boundary classes, independently checking29480658 classes and1704 mode covers. Exact pointwise capacities close omit-03-07; final full-body bounds close all22 omit-14-15 cells with minimum deficit1411.178149mm². No whole allocation/class is excluded. Distinct fixed29 choices[0,5,10],[5,10,11],[10,11,12],[11,12,13] retain18frames+11inserts+12cogs with8bracket/8insert movers and short9; their closed limited calls are not reopened. All15 processes close; consumed preparation {total:.6f}s cannot reset or open an optimizer. All440 whole allocations remain; valid64 stays best and H2/H5 stay open at60%. Maindc7f004e has{success} passed/{live} live CI jobs; this checkpoint awaits ordinary push. Product/releases unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';content=p.read_text(encoding='utf-8');a=content.index('Latest H5 evidence:');b=content.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [older cog-family closure](../benchmarks/results/{NAME}.md).
All eight older exact first32 cores are now excluded, alongside the separate
680-case family. Complete source-angle/center proofs use actual support vertices,
conditional companion covers, exact source-body conservation and pointwise
collision subtraction. Independent replay checks 29,480,658 boundary/interior
classes; the final22 cells fail by at least1,411.178149 mm².
No whole allocation or orientation class is excluded. Four distinct fixed29
choices remain: [0,5,10], [5,10,11], [10,11,12], [11,12,13]. They fix18frames,
11inserts and12cogs, with8bracket/8insert movers and the validated short9.
Their latest limited calls remain closed; this closure does not transfer to them.
All fifteen bounded processes close. Consumed preparation is {total:.6f} s;
no optimizer or timer reset is permitted. All440 whole-job allocations remain;
valid64 stays best, H2/H5 stay open at60%. Prior checkpoint reached maindc7f004e,
whose CI has{success} passed/{live} live jobs. This checkpoint awaits ordinary push.
Product and releases are unchanged.
'''
p.write_text(content[:a]+intro+content[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'consumed_preparation_seconds':total,'older_fixed_cores_remaining':0,'distinct_fixed29_choices_remaining':4,'main_ci_passed':success,'main_ci_live':live})
