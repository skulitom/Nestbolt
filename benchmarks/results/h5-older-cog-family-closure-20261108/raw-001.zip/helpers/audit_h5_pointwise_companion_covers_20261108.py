"""Independent complete point/open-interval class proof of every clipped center cover."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pointwise-companion-covers-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-coupled-cog-body-20261108';COV=ROOT/'output/h5-cog-companion-coupling-20261108';AREAS=ROOT/'output/h5-coupled-companion-areas-20261108';SUPPORT=ROOT/'output/h5-three-cog-frame-support-20261108';M=ROOT/'output/h5-one-three-covers-20261107';HULL=ROOT/'output/h5-cog-hull-stock-20261108';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',COV/'audit',AREAS/'audit',SUPPORT/'audit',M/'audit',G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'source-inner-disk-rectangles.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*-covers.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Verify every source inner rectangle corner lies strictly within the certified109mm disk. For each actual cog-cell closure, verify every corner of every common filled rectangle relative to all4 cell corners remains inside that disk. Independently derive all companion open forbidden rectangles from positive-area component/filled-rectangle intersection or the actual support vertex theorem. Reconstruct all original conditional boxes. Without rerunning producer rectangle subtraction, create every exact boundary point/open interval class along both axes and verify original_closed_union minus forbidden_OPEN_union equals the produced remaining_closed_union on EVERY class. This checks all degenerate boundary lines and corner points, not just area or sample interiors. Retain all142 cells without a feasibility/exclusion claim.'})
source=load(BASE/'source-inner-disk-rectangles.json');assert source['radius_um']==109000;assert min(Q(v['segment_distance_squared']) for v in load(G/'geometry.json')['source_disk_edge_certificates'])>109**2
for l,b,r,t in source['strict_source_rectangles_um']:assert l<r and b<t and all(x*x+y*y<109000**2 for x,y in product([l,r],[b,t]))
geometries=load(M/'geometries.json');offsets=load(SUPPORT/'support-vertex-proof.json')['signed_axis_support_vertex_offset_rectangles_um'];domain=load(HULL/'hull-support.json')['necessary_stock_center_domain_um'];boxesbykey={r['key']:r['boxes'] for r in load(COV/'companion-boxes.json')};groupsbykey={r['key']:r['groups'] for r in load(AREAS/'conditional-groups.json')};cases=load(OLD/'audit/remaining-cases.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==2;h=2500;classes=0;commonchecks=0;results=[]
def axis(cuts):
    values=np.array(sorted(cuts),dtype=np.int64);out=np.empty(2*len(values)-1,dtype=np.int64);out[::2]=2*values;out[1::2]=values[:-1]+values[1:];return out
for case in cases:
    key=case['key'];boxes=boxesbykey[key];groups=groupsbykey[key];records=load(BASE/(key+'-covers.json'));pieces_total=0
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domainmask=z['remaining_center_cells'];ys,xs=np.nonzero(domainmask)
    with np.load(COV/(key+'.npz'),allow_pickle=False) as z:signatures=z['cell_signature'][domainmask[z['source_y'],z['source_x']]]
    assert len(records)==len(xs)
    for y,x,si,record in zip(ys,xs,signatures,records):
        cbox=[max(int(x)*h,domain[0]),max(int(y)*h,domain[1]),min((int(x)+1)*h,domain[2]),min((int(y)+1)*h,domain[3])];assert record['cell_y']==y and record['cell_x']==x and record['prior_signature']==si and record['stock_clipped_cog_cell_um']==cbox;cl,cb,cr,ct=cbox;common=record['common_filled_cog_rectangles_um'];assert len(record['modes'])==12 and [m['geometry'] for m in record['modes']]==list(range(12))
        for l,b,r,t in common:
            assert l<r and b<t
            for px,py in product([l,r],[b,t]):
                for cx,cy in product([cl,cr],[cb,ct]):assert (px-cx)**2+(py-cy)**2<109000**2;commonchecks+=1
        selected=groups[int(si)]['retained_box_indices']
        for mode,g in zip(record['modes'],geometries):
            original=sorted({tuple(boxes[bi]['cover'][1:5]) for bi in selected if boxes[bi]['geometry']==g['geometry']});assert [list(v) for v in original]==mode['original_center_boxes_um'];forbidden=set()
            for component in g['inner_components_um']:
                a,b,r,t=component
                for k in common:forbidden.add((k[0]-r,k[1]-t,k[2]-a,k[3]-b))
                for offset in offsets:
                    lowx=cr+offset[2]-r;highx=cl+offset[0]-a;lowy=ct+offset[3]-t;highy=cb+offset[1]-b
                    if lowx<highx and lowy<highy:forbidden.add((lowx,lowy,highx,highy))
            assert [list(v) for v in sorted(forbidden)]==mode['open_forbidden_center_rectangles_um'];remaining=mode['remaining_closed_center_boxes_um'];assert all(r[0]<=r[2] and r[1]<=r[3] for r in remaining);rectangles=original+list(forbidden)+remaining
            if not rectangles:continue
            xx=axis({r[k] for r in rectangles for k in [0,2]});yy=axis({r[k] for r in rectangles for k in [1,3]});assert len(xx)*len(yy)<4000000
            def cover(rows,closed):
                grid=np.zeros((len(yy),len(xx)),dtype=bool)
                for l,b,r,t in rows:
                    xa=int(np.searchsorted(xx,2*l,side='left' if closed else 'right'));xb=int(np.searchsorted(xx,2*r,side='right' if closed else 'left'));ya=int(np.searchsorted(yy,2*b,side='left' if closed else 'right'));yb=int(np.searchsorted(yy,2*t,side='right' if closed else 'left'));grid[ya:yb,xa:xb]=True
                return grid
            assert np.array_equal(cover(original,True)&~cover(forbidden,False),cover(remaining,True)),(key,int(y),int(x),g['geometry']);classes+=len(xx)*len(yy);pieces_total+=len(remaining)
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'continuous_cog_cells':len(xs),'conditional_mode_covers':len(xs)*12,'remaining_closed_companion_boxes':pieces_total,'boundary_classes_preserved':True,'exact_first32_excluded':False};assert row==saved[key];results.append(row)
process=load(ROOT/'output/h5-pointwise-companion-covers-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'case-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':2,'continuous_cog_cells_preserved':sum(r['continuous_cog_cells'] for r in results),'conditional_mode_covers_verified':sum(r['conditional_mode_covers'] for r in results),'complete_point_and_open_interval_classes_verified':classes,'common_source_disk_corner_checks':commonchecks,'remaining_closed_companion_boxes':sum(r['remaining_closed_companion_boxes'] for r in results),'core_exclusions_claimed':0,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
