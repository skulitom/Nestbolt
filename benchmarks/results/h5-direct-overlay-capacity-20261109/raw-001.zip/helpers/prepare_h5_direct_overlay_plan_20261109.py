"""Freeze all current direct references under independently proved pair edges."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-direct-overlay-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-pair-capacity-conflicts-20261109';OLD=ROOT/'output/h5-combined-reference-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PARENT/'archive-checks.json')['passed'] and load(ROOT/'output/h5-direct-overlay-controls-20261109/checks.json')['passed']
control=load(ROOT/'output/h5-direct-overlay-controls-process-20261109/process.json');assert control['passed'] and control['closed'] and control['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),PARENT/'archive-checks.json',PARENT/'checks.json',ROOT/'output/h5-direct-overlay-controls-20261109/checks.json',ROOT/'output/h5-direct-overlay-controls-20261109/source-bindings.json',ROOT/'output/h5-direct-overlay-controls-process-20261109/process.json',ROOT/'output/h5-pair-capacity-frontier-20261109/audit/plan.json',ROOT/'output/h5-pair-capacity-frontier-20261109/audit/checks.json',OLD/'preflight-audit/plan.json',OLD/'preflight-audit/checks.json',ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json']
geometry=load(inputs[10]);summaries=[]
for case in [1,9]:
    prior=load(OLD/f'choice-{case:02d}-queries.json');graph=ROOT/prior['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    active=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];active_set=set(active);active_mask=sum(1<<p for p in active);edges=load(PARENT/f'choice-{case:02d}-new-edges.json');overlay=[0]*len(nodes)
    for edge in edges:
        a,b=edge['left_current_position'],edge['right_current_position'];assert a<b and a in active_set and b in active_set
        assert not (raw[a*width+b//8]&(1<<(b%8)))
        overlay[a]|=1<<b;overlay[b]|=1<<a
    positions=[p for family in [0,1] for p in active if nodes[p]['family']==family];assert len(positions)==len(active)==len(set(positions))
    witnesses=ROOT/f'output/h5-fixed29-conditional-frontier-20261108/choice-{case:02d}-frontier.json';components=load(witnesses)['source_self_collision_components'];rows=[]
    for p in positions:
        l,b,r,t=nodes[p]['bounds_um'];c=geometry[nodes[p]['geometry']]['inner_rectangles_um'][components[p]]
        assert r-l<c[2]-c[0] and t-b<c[3]-c[1]
        rows.append(hex((int.from_bytes(raw[p*width:(p+1)*width],'little')|overlay[p]|(1<<p))&active_mask))
    cliques=[]
    for family,groups in enumerate(load(graph/'root-covers.json')):
        masks=[];covered=set()
        for group in groups:
            mask=sum(1<<p for p in group);assert len(group)==len(set(group)) and all(nodes[p]['family']==family for p in group)
            for p in group:assert (int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p))&mask==mask
            masks.append(hex(mask));covered.update(group)
        assert covered=={p for p,node in enumerate(nodes) if node['family']==family};cliques.append(masks)
    record={'refinement_index':case,'empty_sites':prior['empty_sites'],'graph':prior['graph'],'current_nodes':len(nodes),'active_current_positions':active,'query_positions':positions,'query_families':[nodes[p]['family'] for p in positions],'query_targets':[[p] for p in positions],'representative_active_forbidden_rows_hex':rows,'node_regions':[{'current_position':p,'family':nodes[p]['family']} for p in active],'root_clique_masks_hex':cliques,'required_by_reference_family_um2':[[279993000000,158392000000,438385000000],[319992000000,138593000000,458585000000]],'new_unique_edges':len(edges),'source_self_collision_components':[components[p] for p in positions]}
    write(OUT/f'choice-{case:02d}-queries.json',record);records=0
    for family in [0,1]:
        path=OLD/f'choice-{case:02d}-family-{family}-covers.json';values=[[key,possible,hex(int(possible,16)&active_mask)] for key,possible,_ in load(path)]
        assert len(values)==len({row[0] for row in values});write(OUT/f'choice-{case:02d}-family-{family}-possible-nodes.json',values);records+=len(values);inputs.append(path)
    inputs.extend([OLD/f'choice-{case:02d}-queries.json',PARENT/f'choice-{case:02d}-frontier.json',PARENT/f'choice-{case:02d}-new-edges.json',witnesses,graph/'nodes.json',graph/'conflicts.bin',graph/'root-covers.json'])
    summaries.append({'refinement_index':case,'complete_direct_queries':len(positions),'bracket_queries':sum(nodes[p]['family']==0 for p in positions),'insert_queries':sum(nodes[p]['family']==1 for p in positions),'source_self_witnesses':len(positions),'new_conflict_edges':len(edges),'possible_node_records':records})
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):inputs.extend([ROOT/piece['folder']/'atoms.json',ROOT/piece['folder']/'audit/checks.json'])
cost=load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed']+control['complete_seconds']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Complete direct queries for every current cell, original certified graph plus pair-capacity edge overlay and self witness. No representative implication or geometric atlas repetition. Project each original certified P intersected with the unchanged active mask against all direct query rows. Two full case producers use forbidden-intersection projections and weighted query loss sums; independent auditors use allowed-union projection and physical transpose/integer weight-plane area sums from every original physical record. Then independently replay all seeds and at most eight simultaneous root-clique passes.','complete_case_order':[1,9],'case_producer_cap_seconds':60,'case_auditor_cap_seconds':60,'maximum_clique_passes':8,'memory_bytes':2**31,'inherited_numeric_preparation_seconds':cost,'optimizer_calls':0,'H5_complete':False})
write(OUT/'case-summary.json',summaries);write(OUT/'checks.json',{'prepared':True,'complete_direct_queries':sum(r['complete_direct_queries'] for r in summaries),'possible_node_records':sum(r['possible_node_records'] for r in summaries),'new_conflict_edges':sum(r['new_conflict_edges'] for r in summaries),'seconds':time.perf_counter()-began,'independent_audit_pending':True,'optimizer_calls':0});print(summaries)
