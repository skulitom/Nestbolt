"""Verify both independent area-sum paths at the new complete direct widths."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_weighted_query_masks_20261109 import weighted_query_sums
from h5_pair_capacity_bitsets_20261109 import physical_columns,weight_planes,weighted_area
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-direct-overlay-controls-20261109';OUT.mkdir();began=time.perf_counter()
cases=scalars=transposed=0
for bcount,icount in [(2118,1675),(2939,1819)]:
    count=bcount+icount;positions=[0,7,8,63,64,129,511,bcount-1,bcount,bcount+1,count-1]
    for seed in range(64):
        weights=[0 if (j+seed)%13==0 else (1<<(j%30+31))-1+seed*1009 for j in range(65)]
        masks=[sum(1<<p for k,p in enumerate(positions) if ((seed*(j+3)+29*j)>>(k%8))&1) for j in range(65)]
        expected=[sum(w for m,w in zip(masks,weights) if m&(1<<q)) for q in range(count)]
        assert weighted_query_sums(list(zip(masks,weights)),count)==expected
        columns=physical_columns(masks,count);planes=weight_planes(weights)
        assert [weighted_area(column,planes) for column in columns]==expected
        for q in positions:assert columns[q]==sum(1<<p for p,m in enumerate(masks) if m&(1<<q))
        assert all(column>>len(weights)==0 for column in columns)
        cases+=1;scalars+=count;transposed+=count*len(weights)
checks={'passed':True,'complete_width_cases':cases,'scalar_area_answers':scalars,'transpose_memberships':transposed,'maximum_query_index':4757,'family_boundaries':[2118,2939],'partial_physical_byte_padding_checked':True,'large_weight_carries_checked':True,'seconds':time.perf_counter()-began,'optimizer_calls':0}
bindings={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'output/h5_weighted_query_masks_20261109.py',ROOT/'output/h5_pair_capacity_bitsets_20261109.py']}
for name,v in [('checks.json',checks),('source-bindings.json',bindings)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
print(checks)
