"""Independently derive every direct graph row and all certified possible sets."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-overlay-reference-20261109';OLD=ROOT/'output/h5-combined-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-pair-capacity-conflicts-20261109';OUT=BASE/'preflight-audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-direct-overlay-plan-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings={};seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
verify(load(BASE/'plan.json')['inputs'])
for p in [OLD/'preflight-audit/plan.json',ROOT/'output/h5-pair-capacity-frontier-20261109/audit/plan.json']:
    verify(load(p)['inputs'])
for name,h in load(ROOT/'output/h5-direct-overlay-controls-20261109/source-bindings.json').items():verify({name:h})
geometry=load(ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json');queries=membership=records=edges_total=clique_edges=0
for case in [1,9]:
    path=BASE/f'choice-{case:02d}-queries.json';data=load(path);prior=load(OLD/f'choice-{case:02d}-queries.json');graph=ROOT/prior['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    active=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];assert data['active_current_positions']==active;active_set=set(active);active_mask=sum(1<<p for p in active)
    overlay={p:set() for p in active};seen_edges=set()
    raw_edges=ROOT/f'output/h5-pair-capacity-frontier-20261109/choice-{case:02d}-new-edges.json';assert load(PARENT/f'choice-{case:02d}-new-edges.json')==load(raw_edges)
    for edge in load(raw_edges):
        a,b=edge['left_current_position'],edge['right_current_position'];assert a<b and (a,b) not in seen_edges and a in active_set and b in active_set
        assert not raw[a*width+b//8]&(1<<(b%8)) and not raw[b*width+a//8]&(1<<(a%8))
        seen_edges.add((a,b));overlay[a].add(b);overlay[b].add(a)
    positions=sorted(active,key=lambda p:(nodes[p]['family'],p));assert data['query_positions']==positions and data['query_targets']==[[p] for p in positions]
    assert data['query_families']==[nodes[p]['family'] for p in positions] and data['current_nodes']==len(nodes) and data['graph']==prior['graph']
    assert data['node_regions']==[{'current_position':p,'family':nodes[p]['family']} for p in active]
    assert data['required_by_reference_family_um2']==[[279993000000,158392000000,438385000000],[319992000000,138593000000,458585000000]]
    components=load(ROOT/f'output/h5-fixed29-conditional-frontier-20261108/choice-{case:02d}-frontier.json')['source_self_collision_components']
    assert data['source_self_collision_components']==[components[p] for p in positions]
    expected=[]
    for p in positions:
        l,b,r,t=nodes[p]['bounds_um'];c=geometry[nodes[p]['geometry']]['inner_rectangles_um'][components[p]]
        assert r-l<c[2]-c[0] and t-b<c[3]-c[1]
        expected.append(hex(sum(1<<q for q in active if p==q or q in overlay[p] or raw[p*width+q//8]&(1<<(q%8)))));membership+=len(active)
    assert data['representative_active_forbidden_rows_hex']==expected and data['new_unique_edges']==len(seen_edges)
    for family,groups in enumerate(load(graph/'root-covers.json')):
        covered=set();masks=[]
        for group in groups:
            assert len(group)==len(set(group)) and all(nodes[p]['family']==family for p in group)
            for p in group:
                for q in group:
                    assert p==q or raw[p*width+q//8]&(1<<(q%8));clique_edges+=p!=q
            masks.append(hex(sum(1<<p for p in group)));covered.update(group)
        assert data['root_clique_masks_hex'][family]==masks and covered=={p for p,node in enumerate(nodes) if node['family']==family}
    for family in [0,1]:
        path=BASE/f'choice-{case:02d}-family-{family}-possible-nodes.json';saved=load(path);old=load(OLD/f'choice-{case:02d}-family-{family}-covers.json')
        assert saved==[[key,possible,hex(int(possible,16)&active_mask)] for key,possible,_ in old]
        assert len(saved)==len({r[0] for r in saved});records+=len(saved);bindings[path.relative_to(ROOT).as_posix()]=sha256(path.read_bytes()).hexdigest()
    queries+=len(positions);edges_total+=len(seen_edges)
    path=BASE/f'choice-{case:02d}-queries.json';bindings[path.relative_to(ROOT).as_posix()]=sha256(path.read_bytes()).hexdigest()
assert queries==8551 and records==87484 and edges_total==14306 and clique_edges==1848482
for p in [Path(__file__),BASE/'plan.json',BASE/'case-summary.json',process_path,process_path.parent/'opened.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Complete direct raw-byte graph membership check plus independently reconstructed edge sets, every current source self witness, all original root-clique edges, exact original P identities and active intersections. Prior complete pair and possible-node proof bindings verified. No fictional reference transfer.'})
checks={'passed':True,'complete_direct_queries':queries,'raw_graph_memberships_checked':membership,'source_self_witnesses':queries,'verified_new_conflict_edges':edges_total,'directed_clique_edges':clique_edges,'possible_node_records':records,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
