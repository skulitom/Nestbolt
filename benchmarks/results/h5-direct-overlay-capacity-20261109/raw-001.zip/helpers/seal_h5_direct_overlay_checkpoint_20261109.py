"""Seal full direct-reference capacities and the independently reconstructed frontier."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-direct-overlay-capacity-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-direct-overlay-reference-20261109';F=ROOT/'output/h5-direct-overlay-frontier-20261109/audit';D=F.parent",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-pair-capacity-conflicts-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['complete_direct_queries']==8551 and front['direct_seed_exclusions']==201 and front['remaining_nodes']==8350",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-direct-overlay-controls-20261109']+[ROOT/'output'/(r['stage']+'-process-20261109') for r in load(D/'process-summary.json')]+[ROOT/'output'/('h5-direct-overlay-frontier'+suffix+'-process-20261109') for suffix in ['', '-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*direct_overlay*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_direct_overlay_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json').items()":"load(F/'plan.json')['inputs'].items()",
}
for before,after in changes.items():assert before in prefix,before;prefix=prefix.replace(before,after)
exec(prefix)
processes=load(D/'process-summary.json')
for suffix in ['', '-audit']:
    label='h5-direct-overlay-frontier'+suffix;p=load(ROOT/'output'/(label+'-process-20261109')/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':suffix==''})
inherited=load(PARENT/'process-summary.json')+load(PARENT/'inherited-process-summary.json');assert len(processes)==9 and len(inherited)==729 and all(p['closed'] and p['active_processes']==0 for p in inherited)
write(OUT/'process-summary.json',processes);write(OUT/'inherited-process-summary.json',inherited)
copies=[(F/'checks.json','frontier-audit.json'),(F/'case-results.json','case-results.json'),(F/'remaining-cases.json','remaining-cases.json'),(BASE/'plan.json','complete-plan.json'),(BASE/'case-summary.json','source-cases.json'),(BASE/'preflight-audit/checks.json','source-preflight-audit.json'),(ROOT/'output/h5-direct-overlay-controls-20261109/checks.json','direct-width-controls.json'),(PARENT/'prior-main-push-receipt.json','prior-main-push-receipt.json')]
for case in [1,9]:
    copies.extend([(D/f'choice-{case:02d}-frontier.json',f'choice-{case:02d}-frontier.json'),(BASE/f'choice-{case:02d}-capacity/query-results.json',f'choice-{case:02d}-all-query-results.json'),(BASE/f'choice-{case:02d}-capacity/audit/checks.json',f'choice-{case:02d}-complete-area-audit.json')])
for source,name in copies:shutil.copyfile(source,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42551023684','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='afe23d6f19cca4145f27e4e8f2ea3e3fe590de25';write(OUT/'main-ci-at-review.json',ci)
cost=front['complete_preparation_seconds_if_consumed'];cases=load(F/'case-results.json')
write(OUT/'checks.json',{**front,**archive,'passed':True,'new_processes_closed':9,'inherited_processes_closed':729,'all738_processes_closed':True,'completion_percent':60,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'combined_fixed_point_claimed':False})
proposal='The 201 independently proved removals change the active masks from8551 to8350. Freeze a bounded complete monotone restriction loop retaining all8551 original direct queries and their own family requirements, with seed transfer only to currently active targets. Original graph plus certified14306-edge overlay remains unchanged. Existing complete direct signatures and area vectors are the8551-mask baseline. For each original P, carry its projected query mask only if P intersected with old/current active masks is exactly equal; otherwise independently reproject it. Producer may subtract exact newly lost weighted areas; auditor must independently recompute every full family/joint area from all original151597physical records. Preserve original physical keys, all87484P records, all query identities and every simultaneous clique implication. Predeclare a finite round cap and require complete terminal audits before each dependent round; stop at a genuine fixed point, complete scope exclusion or cap. No unchanged call, source atlas or P construction repeat. No next loop plan/call is prepared. All consumed preparation remains charged; no optimizer or timed H5 acceptance from this lineage.'
write(OUT/'next-step.json',{'status':'complete_direct_overlay_bounds_remove201cells_both_cases_open','proposal':proposal,'next_loop_prepared':False,'authoritative_current_masks':'output/h5-direct-overlay-frontier-20261109/choice-{01,09}-frontier.json remaining_current_positions','baseline_signatures':'output/h5-direct-overlay-reference-20261109/choice-{01,09}-capacity/projected-signatures.json','consumed_preparation_seconds':cost,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'H5_complete':False})
table='\n'.join(f"| {r['empty_sites']} | {r['direct_seed_exclusions']} | {r['remaining_nodes']} | {r['remaining_nodes_by_family'][0]} / {r['remaining_nodes_by_family'][1]} | {r['family_and_joint_area_upper_um2'][2]/1e6:,.6f} |" for r in cases)
passed=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Complete direct bounds under pair conflicts — 2026-11-09

**All 8,551 remaining cells receive direct conditional checks; 201 more cells are excluded.**
There are 199 bracket exclusions and two insert exclusions. Both fixed29
choices remain open with **8,350 current cells**. H2/H5 remain open at
**60% completed milestone weight**.

## Complete direct reference scope

The [preceding pair proof](h5-pair-capacity-conflicts-20261109.md) added
14,306 necessary conflict edges. This stage uses the original graph plus that
certified symmetric overlay. Every current bracket and insert cell is its own
reference; target-specific new edges are therefore used without attaching them
to fictional bracket representatives.

[Width controls]({NAME}/direct-width-controls.json) verify both independent
area-summing paths through query index 4,757, including 547,264 scalar answers,
35,572,160 transpose memberships, both family boundaries, partial-byte padding
and large integer carries. The [source audit]({NAME}/source-preflight-audit.json)
checks all 37,025,413 direct graph memberships, every current self-collision
witness, all 14,306 added edges, 1,848,482 directed root-clique edges and
87,484 original certified possible-node records.

Both complete case producers intersect forbidden-query columns for every P
under the active mask, then sum weighted uncovered query masks. Independent
auditors project allowed-node unions, read every original physical record,
transpose positive physical coverage and sum integer weight-plane population
counts. These use different projection and summation paths. All **25,653
conditional family/joint bounds** exactly match across
[case01]({NAME}/choice-01-complete-area-audit.json) and
[case09]({NAME}/choice-09-complete-area-audit.json). The complete scopes contain
3,793 and 4,758 direct references; all 151,597 physical records are accounted for.
Each family retains its own seven/eight companion requirements.

## Independently reconstructed frontier

The [final audit]({NAME}/frontier-audit.json) derives every seed from the complete
audited direct results, verifies all 8,914 source self witnesses and every
root-clique edge, and replays every candidate in the overlay-aware count pass.
No additional clique removal follows. All 21,194 retained original source
component sweeps replay, including every closed cover and alias component.
Independent horizontal interval-tree areas exactly reproduce all six vertical
global union bounds.

| Omitted sites | New cells excluded | Remaining cells | Brackets / inserts | Global joint upper (mm²) |
|---|---:|---:|---:|---:|
{table}

The joint areas remain above the required 478,384 mm², so neither arrangement
is excluded. The 453/455 earlier whole-choice exclusions stand, including
428 at zero clearance. Common-line occupied outer envelopes reserve holes;
all 90 cutting holes remain. No ordinary part-in-hole or whole-allocation
exclusion follows.

## Closure and next work

[All nine new numerical processes]({NAME}/process-summary.json) pass and close
with zero descendants. The [729 inherited processes]({NAME}/inherited-process-summary.json)
remain terminal, including four preserved failures. Numeric workers retain
CCD1 logical processors 16–31, one BLAS/OMP/MKL thread and 2 GiB Windows Job caps.
Controls use 20 s; plan/frontier stages use 30 s each; complete case producers
and auditors use 60 s each. Consumed preparation is **{cost:.6f} s**.
No optimizer, timer reset or timed H5 pass follows.

[Next]({NAME}/next-step.json), assess a bounded complete restriction loop under
the reduced masks. The present result is not a fixed-point claim: its 201
removals can further tighten possible-node intersections. Retain all 8,551
direct query identities, filter seeds to surviving targets and independently
recompute complete physical sums before any dependent round. No loop is prepared.

All 440 whole-job allocations, full66 source/native/material validation,
production integration and the H5 matrix remain open. Valid64 stays best;
eight older first32 and 680 five-column cores remain closed. Product, README
and releases are unchanged.

The preceding pair checkpoint is committed as `5bff1af0`. [Earlier checkpoints
reached main `afe23d6f`]({NAME}/prior-main-push-receipt.json) after all six prior
checks passed, preserving 52 files. [Current CI at review]({NAME}/main-ci-at-review.json)
has {passed} passed / {live} live jobs. Both new checkpoints await ordinary push.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete chain.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 complete direct bounds under pair conflicts:** [full source, projection, area and frontier audits]({{link}}) verify all 8,551 current direct references, 37,025,413 graph memberships, 87,484 possible-node records and 25,653 conditional bounds. The certified pair-edge overlay and direct rows exclude 199 bracket cells and two insert cells. No further clique removal follows; both choices remain with 8,350 cells. All 21,194 source-component sweeps and six exact global union bounds replay; neither whole scope is excluded. All nine new and 729 inherited processes are terminal, preserving inherited failures. Consumed preparation {cost:.6f} s cannot reset or open an optimizer. Next freeze a bounded complete restriction loop under the reduced masks; none is prepared and no fixed point is claimed. All 440 allocations/full66/H5 remain open, valid64 stays best, H2/H5 remain at 60%, common-line holes stay reserved, and product/README/releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [complete direct bounds under pair conflicts](../benchmarks/results/{NAME}.md).
All 8,551 current direct references and 25,653 conditional area bounds pass
independent verification under the certified conflict overlay. The proof
excludes 199 bracket cells and two insert cells; no further clique removal
follows. Both choices remain with 8,350 cells. All 21,194 original source
component sweeps and six global union bounds replay; neither arrangement is
excluded. The 453/455 prior exclusions stand, including 428 at zero clearance.
Common-line holes remain reserved; no ordinary part-in-hole or whole-allocation
exclusion is claimed. All nine new and 729 inherited processes are terminal,
with four inherited failures preserved. Consumed preparation is {cost:.6f} s;
no optimizer or timer reset is permitted. Next freeze a bounded complete
restriction loop under the reduced masks; none is prepared. All 440 allocations
and full66/H5 remain open, valid64 stays best, and H2/H5 remain at 60%. Eight
older first32 and 680 five-column cores stay closed. Product, README and
releases are unchanged. Pair checkpoint5bff1af0 is committed; main afe23d6f
has {passed} passed/{live} live CI jobs at review. Both checkpoints await ordinary push.
'''
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content[:start]+intro+content[end:])
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text\n')
print({'passed':True,'archive':archive,'source_bindings':len(bindings),'historical_references':len(external),'new_cell_exclusions':201,'remaining_cells':8350,'complete_preparation_seconds':cost})
