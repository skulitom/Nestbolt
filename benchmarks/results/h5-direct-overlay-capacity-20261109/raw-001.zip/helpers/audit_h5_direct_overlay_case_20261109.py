"""Independent complete allowed projection and positive physical area sums."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import allowed_projection
from h5_pair_capacity_bitsets_20261109 import physical_columns,weight_planes,weighted_area
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-overlay-reference-20261109';case=int(sys.argv[1]);assert case in [1,9];SOURCE=BASE/f'choice-{case:02d}-capacity';OUT=SOURCE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/f'output/h5-direct-overlay-choice-{case:02d}-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings=dict(load(SOURCE/'plan.json')['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
for name,h in {**load(BASE/'preflight-audit/plan.json')['inputs'],**load(ROOT/'output/h5-direct-overlay-controls-20261109/source-bindings.json')}.items():
    assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;bindings[name]=h
data=load(BASE/f'choice-{case:02d}-queries.json');project=allowed_projection(data);saved=load(SOURCE/'projected-signatures.json');maps=[{},{}];record_count=0
for family in [0,1]:
    records=load(BASE/f'choice-{case:02d}-family-{family}-possible-nodes.json');assert len(records)==len(saved[family])
    for (key,original,current),row in zip(records,saved[family]):
        value=project(int(current,16))[family];assert row==[key,hex(value)];maps[family][int(key,16)]=value;record_count+=1
qcount=len(data['query_positions']);full=(1<<qcount)-1;physical_masks=[[],[]];weights=[]
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    if piece['refinement_index']!=case:continue
    for b,i,area in load(ROOT/piece['folder']/'atoms.json'):
        physical_masks[0].append(full-maps[0][int(b,16)]);physical_masks[1].append(full-maps[1][int(i,16)]);weights.append(area)
columns=[physical_columns(rows,qcount) for rows in physical_masks];planes=weight_planes(weights);rows=load(SOURCE/'query-results.json');assert len(rows)==qcount
excluded=[];by_family=[0,0]
for qi,row in enumerate(rows):
    values=[weighted_area(mask,planes) for mask in [columns[0][qi],columns[1][qi],columns[0][qi]|columns[1][qi]]];family=data['query_families'][qi];required=data['required_by_reference_family_um2'][family];fails=[f for f in range(3) if values[f]<required[f]];p=data['query_positions'][qi]
    assert row=={'query_index':qi,'current_position':p,'family':family,'family_and_joint_area_upper_um2':values,'required_area_um2':required,'failing_area_indices':fails,'provisional_cell_excluded':bool(fails)}
    if fails:excluded.append(p);by_family[family]+=1
summary=load(SOURCE/'checks.json')
assert summary['complete_direct_queries']==qcount and summary['conditional_area_bounds']==3*qcount and summary['possible_node_records']==record_count and summary['original_physical_records']==len(weights) and summary['provisional_cell_exclusions']==len(excluded) and summary['provisional_exclusions_by_family']==by_family
for p in [Path(__file__),ROOT/'output/h5_pair_capacity_bitsets_20261109.py',process_path,process_path.parent/'opened.json']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently project every certified P with allowed-column unions. Convert every original physical record to positive family covers, transpose physical membership and sum integer weight-plane population counts. Every family/joint bound and direct target verified, without producer weighted-query loss arithmetic.'})
write(OUT/'excluded-positions.json',sorted(excluded))
checks={'passed':True,'refinement_index':case,'complete_direct_queries':qcount,'conditional_area_bounds':3*qcount,'possible_node_records':record_count,'original_physical_records':len(weights),'verified_cell_exclusions':len(excluded),'verified_exclusions_by_family':by_family,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
