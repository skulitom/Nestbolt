"""Apply all direct exclusions and recompute complete source-envelope bounds."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-overlay-reference-20261109';OUT=ROOT/'output/h5-direct-overlay-frontier-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',BASE/'plan.json',BASE/'preflight-audit/plan.json',BASE/'preflight-audit/checks.json',PRE/'audit/checks.json',PRE/'audit/plan.json'];cases=[];processes=[]
cost=load(ROOT/'benchmarks/results/h5-pair-capacity-conflicts-20261109/checks.json')['complete_preparation_seconds_if_consumed']
for label,charge in [('h5-direct-overlay-controls',True),('h5-direct-overlay-plan',True),('h5-direct-overlay-plan-audit',False)]+[(f'h5-direct-overlay-choice-{case:02d}'+suffix,suffix=='') for case in [1,9] for suffix in ['', '-audit']]:
    folder=ROOT/'output'/(label+'-process-20261109');p=load(folder/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    if charge:cost+=p['complete_seconds']
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':charge});inputs.extend([folder/'process.json',folder/'opened.json'])
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-queries.json');regions_source=load(PRE/f'choice-{case:02d}.json');source=BASE/f'choice-{case:02d}-capacity';assert load(source/'audit/checks.json')['passed']
    queries=load(source/'query-results.json');original=data['active_current_positions'];positions=data['query_positions'];assert [r['current_position'] for r in queries]==positions
    graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');rows={p:int(row,16) for p,row in zip(positions,data['representative_active_forbidden_rows_hex'])};cliques=[[int(v,16) for v in family] for family in data['root_clique_masks_hex']]
    seeds=[{'current_position':row['current_position'],'query_index':row['query_index'],'family':row['family'],'failing_area_indices':row['failing_area_indices']} for row in queries if row['provisional_cell_excluded']]
    assert sorted(r['current_position'] for r in seeds)==load(source/'audit/excluded-positions.json')
    mask=sum(1<<p for p in original)&~sum(1<<r['current_position'] for r in seeds);rounds=[]
    for step in range(8):
        removed=[]
        for p in original:
            if not mask&(1<<p):continue
            allowed=mask&~rows[p];counts=[sum(bool(group&allowed) for group in family) for family in cliques];required=[8-int(nodes[p]['family']==f) for f in [0,1]]
            if any(a<b for a,b in zip(counts,required)):removed.append({'current_position':p,'upper':counts,'required':required})
        rounds.append({'pass_index':step,'removed':removed});mask&=~sum(1<<r['current_position'] for r in removed)
        if not removed:break
    retained=[p for p in original if mask&(1<<p)];regions=[set(),set()]
    for row in regions_source['node_regions']:
        if mask&(1<<row['current_position']):regions[row['family']].update(map(tuple,row['regions_um']))
    regions=[sorted(group) for group in regions];areas=vertical_areas(*regions,regions_source['fixed_forbidden_clearance_regions_um']);counts=[sum(bool(group&mask) for group in family) for family in cliques];required=[319992000000,158392000000,478384000000];fails=[f for f in range(3) if areas[f]<required[f]]
    summary={'refinement_index':case,'empty_sites':data['empty_sites'],'input_nodes':len(original),'direct_seed_exclusions':len(seeds),'direct_seeds_by_family':[sum(r['family']==f for r in seeds) for f in [0,1]],'clique_exclusions':len(original)-len(retained)-len(seeds),'remaining_nodes':len(retained),'remaining_nodes_by_family':[sum(nodes[p]['family']==f for p in retained) for f in [0,1]],'global_clique_upper_counts':counts,'family_and_joint_area_upper_um2':areas,'required_global_area_um2':required,'failing_area_indices':fails,'scope_excluded':bool(fails) or any(n<8 for n in counts)}
    write(OUT/f'choice-{case:02d}-frontier.json',{**summary,'input_active_positions':original,'seed_exclusions':seeds,'clique_rounds':rounds,'remaining_current_positions':retained,'family_component_regions_um':[[list(r) for r in family] for family in regions]});cases.append(summary)
    inputs.extend([BASE/f'choice-{case:02d}-queries.json',PRE/f'choice-{case:02d}.json',source/'query-results.json',source/'audit/plan.json',source/'audit/checks.json',source/'audit/excluded-positions.json',graph/'nodes.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Every current direct query must be independently audited before its seed is consumed. Apply all seeds and at most eight simultaneous root-clique passes using the certified graph overlay. Recompute complete global family/joint source envelopes against fixed clearance regions.','maximum_clique_passes':8,'complete_preparation_seconds_before_this_stage':cost,'optimizer_calls':0,'H5_complete':False})
write(OUT/'case-results.json',cases);write(OUT/'process-summary.json',processes)
checks={'prepared':True,'direct_seed_exclusions':sum(r['direct_seed_exclusions'] for r in cases),'clique_exclusions':sum(r['clique_exclusions'] for r in cases),'remaining_nodes':sum(r['remaining_nodes'] for r in cases),'provisional_scope_exclusions':sum(r['scope_excluded'] for r in cases),'seconds':time.perf_counter()-began,'independent_audit_pending':True,'optimizer_calls':0};write(OUT/'checks.json',checks);print(checks);print(cases)
