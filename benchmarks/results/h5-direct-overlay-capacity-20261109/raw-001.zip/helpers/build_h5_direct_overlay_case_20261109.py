"""Complete direct-reference projection and all conditional area bounds."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import forbidden_projection
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-overlay-reference-20261109';case=int(sys.argv[1]);assert case in [1,9];OUT=BASE/f'choice-{case:02d}-capacity'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'preflight-audit/checks.json')['passed']
process=load(ROOT/'output/h5-direct-overlay-plan-audit-process-20261109/process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();data=load(BASE/f'choice-{case:02d}-queries.json');project=forbidden_projection(data);maps=[{},{}];signatures=[[],[]];inputs=[Path(__file__),ROOT/'output/h5_block_projected_coverage_atoms_20261109.py',ROOT/'output/h5_weighted_query_masks_20261109.py',BASE/'plan.json',BASE/'preflight-audit/plan.json',BASE/'preflight-audit/checks.json',BASE/f'choice-{case:02d}-queries.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'];record_count=physical=0
for family in [0,1]:
    path=BASE/f'choice-{case:02d}-family-{family}-possible-nodes.json';inputs.append(path)
    for key,original,current in load(path):
        value=project(int(current,16))[family];maps[family][int(key,16)]=value;signatures[family].append([key,hex(value)]);record_count+=1
total=0;weighted=[[],[],[]]
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    if piece['refinement_index']!=case:continue
    path=ROOT/piece['folder']/'atoms.json';inputs.append(path)
    for b,i,weight in load(path):
        b=maps[0][int(b,16)];i=maps[1][int(i,16)]
        for f,mask in enumerate([b,i,b&i]):weighted[f].append((mask,weight))
        total+=weight;physical+=1
qcount=len(data['query_positions']);losses=[weighted_query_sums(values,qcount) for values in weighted];rows=[]
for q,p in enumerate(data['query_positions']):
    family=data['query_families'][q];values=[total-losses[f][q] for f in range(3)];required=data['required_by_reference_family_um2'][family];assert all(v>=0 for v in values);fails=[f for f in range(3) if values[f]<required[f]]
    rows.append({'query_index':q,'current_position':p,'family':family,'family_and_joint_area_upper_um2':values,'required_area_um2':required,'failing_area_indices':fails,'provisional_cell_excluded':bool(fails)})
write(OUT/'projected-signatures.json',signatures);write(OUT/'query-results.json',rows)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Every original P projected against all direct queries under the proved overlay by forbidden-column intersection. Weighted uncovered masks from every original physical record give complete family/joint area bounds.'})
checks={'passed':True,'refinement_index':case,'complete_direct_queries':qcount,'conditional_area_bounds':3*qcount,'possible_node_records':record_count,'original_physical_records':physical,'provisional_cell_exclusions':sum(r['provisional_cell_excluded'] for r in rows),'provisional_exclusions_by_family':[sum(r['provisional_cell_excluded'] and r['family']==f for r in rows) for f in [0,1]],'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
