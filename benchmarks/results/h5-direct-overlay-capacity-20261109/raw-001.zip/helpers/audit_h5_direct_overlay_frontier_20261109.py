"""Independent seed, graph implication and original closed-cover area replay."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_horizontal_segment_areas_20261109 import horizontal_segment_areas
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-direct-overlay-frontier-20261109';OUT=SOURCE/'audit';BASE=ROOT/'output/h5-direct-overlay-reference-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';GEOM=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';PAIR=ROOT/'benchmarks/results/h5-pair-capacity-conflicts-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-direct-overlay-frontier-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings={};seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
for folder in [SOURCE,PRE/'audit',BASE/'preflight-audit']+[BASE/f'choice-{case:02d}-capacity/audit' for case in [1,9]]:verify(load(folder/'plan.json')['inputs'])
geometry=load(GEOM/'geometries.json');stock=load(GEOM/'stock-cover.json')['outward_stock_rectangle_um'];results=[];sweeps=self_checks=edges=queries_checked=0
for case,summary in zip([1,9],load(SOURCE/'case-results.json')):
    data=load(BASE/f'choice-{case:02d}-queries.json');old=load(PRE/f'choice-{case:02d}.json');saved=load(SOURCE/f'choice-{case:02d}-frontier.json');original=load(PAIR/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];assert saved['input_active_positions']==original==data['active_current_positions']
    graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8;overlay=[0]*len(nodes)
    for edge in load(PAIR/f'choice-{case:02d}-new-edges.json'):
        a,b=edge['left_current_position'],edge['right_current_position'];overlay[a]|=1<<b;overlay[b]|=1<<a
    witnesses=load(ROOT/f'output/h5-fixed29-conditional-frontier-20261108/choice-{case:02d}-frontier.json')['source_self_collision_components']
    for p,node in enumerate(nodes):
        l,b,r,t=node['bounds_um'];c=geometry[node['geometry']]['inner_rectangles_um'][witnesses[p]];assert r-l<c[2]-c[0] and t-b<c[3]-c[1];self_checks+=1
    cliques=[]
    for family,groups in enumerate(load(graph/'root-covers.json')):
        masks=[];covered=set()
        for group in groups:
            assert len(group)==len(set(group)) and all(nodes[p]['family']==family for p in group)
            for p in group:
                for q in group:assert p==q or raw[p*width+q//8]&(1<<(q%8));edges+=p!=q
            covered.update(group);masks.append(sum(1<<p for p in group))
        assert covered=={p for p,node in enumerate(nodes) if node['family']==family};cliques.append(masks)
    rows=load(BASE/f'choice-{case:02d}-capacity/query-results.json');assert [r['current_position'] for r in rows]==data['query_positions'];seeds=[]
    for qi,row in enumerate(rows):
        p=row['current_position'];family=nodes[p]['family'];required=[(8-int(family==0))*39999000000,(8-int(family==1))*19799000000];required.append(sum(required));fails=[f for f in range(3) if row['family_and_joint_area_upper_um2'][f]<required[f]]
        assert row['query_index']==qi and row['family']==family and row['required_area_um2']==required and row['failing_area_indices']==fails and row['provisional_cell_excluded']==bool(fails);queries_checked+=1
        if fails:seeds.append({'current_position':p,'query_index':qi,'family':family,'failing_area_indices':fails})
    assert saved['seed_exclusions']==seeds
    active=sum(1<<p for p in original)&~sum(1<<r['current_position'] for r in seeds);rounds=saved['clique_rounds'];assert 1<=len(rounds)<=8
    for step,round_saved in enumerate(rounds):
        removed=[]
        for p in original:
            if not active&(1<<p):continue
            forbidden=int.from_bytes(raw[p*width:(p+1)*width],'little')|overlay[p]|(1<<p);allowed=active&~forbidden;counts=[sum((group&allowed)>0 for group in family) for family in cliques];required=[7 if nodes[p]['family']==f else 8 for f in [0,1]]
            if counts[0]<required[0] or counts[1]<required[1]:removed.append({'current_position':p,'upper':counts,'required':required})
        assert round_saved=={'pass_index':step,'removed':removed}
        if not removed:assert step==len(rounds)-1
        active&=~sum(1<<r['current_position'] for r in removed)
    retained=[p for p in original if active&(1<<p)];assert retained==saved['remaining_current_positions']
    path=COVER/f'choice-{case:02d}-covers.json';cover=load(path);bindings[path.relative_to(ROOT).as_posix()]=sha256(path.read_bytes()).hexdigest();regions=[set(),set()]
    for p in retained:
        node=nodes[p]
        for box in cover[p]['remaining_closed_anchor_boxes_um']:
            for component in geometry[node['geometry']]['all_alias_component_outer_rectangles_um']:
                rectangle=(max(stock[0],box[0]+component[0]),max(stock[1],box[1]+component[1]),min(stock[2],box[2]+component[2]),min(stock[3],box[3]+component[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[node['family']].add(rectangle)
                sweeps+=1
    regions=[sorted(group) for group in regions];assert saved['family_component_regions_um']==[[list(r) for r in family] for family in regions]
    areas=horizontal_segment_areas(*regions,old['fixed_forbidden_clearance_regions_um']);counts=[sum(bool(group&active) for group in family) for family in cliques];required=[319992000000,158392000000,478384000000];fails=[f for f in range(3) if areas[f]<required[f]]
    expected={'refinement_index':case,'empty_sites':data['empty_sites'],'input_nodes':len(original),'direct_seed_exclusions':len(seeds),'direct_seeds_by_family':[sum(r['family']==f for r in seeds) for f in [0,1]],'clique_exclusions':len(original)-len(retained)-len(seeds),'remaining_nodes':len(retained),'remaining_nodes_by_family':[sum(nodes[p]['family']==f for p in retained) for f in [0,1]],'global_clique_upper_counts':counts,'family_and_joint_area_upper_um2':areas,'required_global_area_um2':required,'failing_area_indices':fails,'scope_excluded':bool(fails) or any(n<8 for n in counts)}
    assert expected==summary;results.append(expected)
assert queries_checked==8551
cost=load(PAIR/'checks.json')['complete_preparation_seconds_if_consumed'];processes=load(SOURCE/'process-summary.json');assert len(processes)==7
for row in processes:
    p=load(ROOT/'output'/(row['stage']+'-process-20261109')/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0 and p['complete_seconds']==row['complete_seconds']
    charged=row['stage'] in ['h5-direct-overlay-controls','h5-direct-overlay-plan','h5-direct-overlay-choice-01','h5-direct-overlay-choice-09'];assert row['charged']==charged
    if charged:cost+=p['complete_seconds']
assert abs(cost-load(SOURCE/'plan.json')['complete_preparation_seconds_before_this_stage'])<1e-8
cost+=process['complete_seconds']
for p in [Path(__file__),ROOT/'output/h5_horizontal_segment_areas_20261109.py',GEOM/'geometries.json',GEOM/'stock-cover.json',process_path,process_path.parent/'opened.json']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Recompute all direct threshold signs, every source self witness and original root-clique edge, all overlay-aware simultaneous implications and all original closed-cover component sweeps. Independent horizontal interval-tree areas reproduce vertical bounds. Reconcile every preparation process without resetting the exhausted lineage.'})
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',[r for r in results if not r['scope_excluded']])
checks={'passed':True,'complete_direct_queries':queries_checked,'conditional_area_bounds':3*queries_checked,'source_self_witnesses':self_checks,'directed_root_clique_edges':edges,'retained_source_component_sweeps':sweeps,'exact_global_area_bounds':6,'direct_seed_exclusions':sum(r['direct_seed_exclusions'] for r in results),'clique_exclusions':sum(r['clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'remaining_fixed29_cases':sum(not r['scope_excluded'] for r in results),'complete_preparation_seconds_if_consumed':cost,'seconds':time.perf_counter()-began,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'whole_allocations_remaining':440,'optimizer_calls':0,'optimizer_allowed_from_current_lineage':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks);print(results)
