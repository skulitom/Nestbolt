"""Seal the closed32-case necessary screen and preserve the complete count frontier."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-short-count-x-screen-20261028';OUT=ROOT/'benchmarks/results'/NAME;BASE=ROOT/'output'/NAME;PUB=BASE/'publication'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='f9629063f8a39dc9492f0122426006db8a23a4da' and not git('diff','HEAD','--name-only')
model=load(BASE/'model-audit/checks.json');result=load(BASE/'response-audit/checks.json');cases=load(BASE/'response-audit/cases.json')
assert model['passed'] and result['passed'] and result['solver_calls']==32
assert result['status_counts']=={'UNKNOWN':27,'OPTIMAL':1,'INFEASIBLE':4} and result['remaining_necessary_allocations']==448
assert result['newly_excluded_counts']==[[0,10,5],[1,8,5],[2,9,4],[4,7,3]]
assert not result['process_timeout'] and result['shared_process_seconds']<120
old=load(ROOT/'benchmarks/results/h5-oblique24-baseline-review-20261028/publication-review.json')
production=source_digest();assert production==old['production_digest']
readmes={n:digest(ROOT/n) for n in old['current_readmes']};assert readmes==old['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],
    'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==old[k] for k in up)
assert load(PUB/'main.json')['commit']['sha']==head
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-oblique24-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_count_x_model_20261028.py','prepare_h5_short_count_x_screen_20261028.py','audit_h5_short_count_x_models_20261028.py',
    'run_h5_short_count_x_screen_20261028.py','audit_h5_short_count_x_responses_20261028.py','pack_h5_evidence_archive.py',
    'push_oblique24_checkpoint_20261028.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies={'plan.json':'screen-plan.json','prepared.json':'prepared.json','model-audit/checks.json':'model-checks.json',
    'model-audit/cases.json':'model-cases.json','search/process.json':'search-process.json','search/results.json':'search-results.json',
    'response-audit/checks.json':'response-checks.json','response-audit/cases.json':'response-cases.json',
    'response-audit/updated-allocations.json':'updated-allocations.json','response-audit/newly-excluded-allocations.json':'newly-excluded-allocations.json',
    'response-audit/pareto-necessary-counts.json':'pareto-necessary-counts.json','response-audit/necessity-proof.json':'necessity-proof.json',
    'publication/main-ci-jobs.json':'prior-main-ci.json'}
for a,b in copies.items():shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,
    'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,
    'main_CI':40693544095,'main_all6_pass':True,'normal_push_authorized_after_fresh_live_run_check':True,
    'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'all32_models_independently_verified':True,'all32_responses_independently_verified':True,
    'new_count_exclusions':4,'remaining_necessary_allocations':448,'all4576_rows_retained':True,
    'solver_calls':32,'repeat_calls':0,'source_layout_claimed':False,'full66_exclusion_claimed':False,'native_calls':0,
    'main_all6_pass':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The predeclared32-case X-capacity screen is closed:4 audited infeasible vectors are removed,27 UNKNOWN vectors and the7/4/1 relaxed solution remain candidates. Do not rerun or extend any case from this pass. Keep all4576 original rows and the448 current survivors; retain earlier7/5/1 and7/6/1 exclusions. The source64 construction still lacks two first-sheet brackets. Before another optimizer call, inspect a materially different complete source construction that could move a sixth insert to the short sheet with eight brackets, freeing first-sheet space. This8/6/0 count is still allowed and has not been solved by the32-case screen (8/7/0 was UNKNOWN). Build any such source construction from original full orthogonal polygons with both X and Y, every bracket/insert mode, conservative clearance and the unchanged short target. Independently audit its full model and positive control before a single predeclared bounded call; an infeasible conservative construction would not exclude the actual count. A successful short14 layout would still need all52 first-sheet originals, independent full66 source readback and native validation before any H5 integration or matrix rerun. Do not reopen the failed17/24-mover source calls, change the material target or open22 reserved H2 vectors. H2 stays open under the explicit unchanged-gate decision; no new release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
table='\n'.join(f"| {r['counts'][0]} / {r['counts'][1]} / {r['counts'][2]} | {r['status']} | {r['returned_solve_seconds']:.6f} |" for r in cases)
report=f'''# Remaining short-sheet count screen — 2026-10-28

The bounded screen excludes four more short-sheet allocations, leaving **448
necessary candidates**. It does not produce a complete source layout or close H5.
The excluded counts, in brackets / inserts / cogs order, are **0/10/5, 1/8/5,
2/9/4 and 4/7/3**. All 4,576 original allocation rows remain recorded, including
every previous exclusion. The known source-valid 7/4/1 and 8/5/0 controls remain.

## Frozen scope and independent model check

The complete prior frontier had 452 survivors and 32 maximal count vectors.
All 32 were selected and ordered before search, by descending bracket count,
then descending cog count and descending insert count. Previously excluded
7/5/1 and 7/6/1 were never reopened. Every original in each selected vector is
mandatory; every allowed bracket/insert outer mode and every real cog angle
retain their complete reference-coordinate domain.

The source X-capacity model uses only disjoint source-contained rectangles:
three coarse components per bracket mode, one per insert mode and sixteen
guaranteed strips per cog. The full stems used for pair spacing are not added
as extra height. The 121 directed pair distances are unchanged. In particular,
the 251,956 µm cog/cog horizontal bound applies to arbitrary independent real
angles throughout the complete short-stock Y domain. Identical copies may be
relabelled in X order, including multiple cogs. No source Y or cog angle is fixed.

Before any search, an independent protobuf reader verifies **6,649 variables
and 85,989 constraints** across the 32 models. It rejects unreviewed fields and
checks all coordinate domains, mode selectors, source intervals, capacity,
symmetry and both directions of every selected original pair. It does not
import the model builder. The source-to-model necessity mapping and deletion
argument are recorded in the [necessity proof]({NAME}/necessity-proof.json).

## One bounded pass

Each case receives one call with a 3-second solver setting, four workers,
seed zero and the `fj` subsolver excluded. The aggregate settings total 96 s;
the entire child process has a 120-second bound. All 32 calls complete in
**85.249128 s shared time**. Aggregate reported solver time is 83.401531 s.
Small solver-return overruns are preserved; the largest is **0.034838 s**.
There is no timeout, retry, reseed, extension or adaptive second pass.

| Brackets / inserts / cogs | Terminal status | Returned seconds |
|---|---|---:|
{table}

All raw responses, logs, parameters and opened-call records are preserved and
independently compared. Only the four terminal INFEASIBLE results remove count
vectors. Their subset/upward closure removes four previously surviving rows.
The remaining 448 vectors still have 32 maxima; newly exposed maxima were not
searched in this pass.

The single OPTIMAL result is a satisfaction-model solution for **7/4/1**,
already known to have valid source controls. Every one of its 143 variables
and 4,104 constraints passes independent evaluation. A second sweep rebuilt
from the source inputs verifies 41 active rectangles and all 66 original pairs,
with 2,979 µm of minimum vertical-capacity slack. This assignment contains only
reference X and mode: it is not a new source layout. All 27 UNKNOWN cases remain
allowed. No full66 infeasibility, native validation or H5 completion is claimed.

## Next construction and publication

The current source-valid 64-part layout still lacks two brackets. Inspect the
remaining 8/6/0 short-sheet allocation using full original orthogonal geometry
in both coordinates; transferring one extra insert could free first-sheet
space. Any such construction needs an audited new model and a declared bounded
call, followed by actual source checks. A valid short14 alone would still leave
the complete first-sheet construction and full66 validation to do. The closed
32-case screen and failed 17/24-mover searches will not be restarted.

The previous checkpoint `f9629063` passes all six jobs in
[CI 40693544095](https://github.com/skulitom/Nestbolt/actions/runs/40693544095).
Production, READMEs and upstream heads/releases are unchanged. H2 and H5 remain
open at **60% completed milestone weight**, all 22 reserved H2 vectors remain
unopened, and no new release qualifies.

[Model checks]({NAME}/model-checks.json),
[response checks]({NAME}/response-checks.json),
[complete allocation list]({NAME}/updated-allocations.json),
[next step]({NAME}/next-step.json),
[byte-verified archive]({NAME}/raw-manifest.json).
The archive retains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all models, inputs, helper sources, responses and
the preceding main-push receipt.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 remaining short-count screen, 2026-10-28:** [the evidence]({link})
independently checks all 6,649 variables / 85,989 constraints before one bounded
pass over the 32 predeclared maximal count vectors. Four cases are INFEASIBLE,
27 remain UNKNOWN, and 7/4/1 has a fully checked relaxed assignment. The four
new exclusions are 0/10/5, 1/8/5, 2/9/4 and 4/7/3 (brackets/inserts/cogs).
All 4,576 original rows remain recorded; 448 count candidates survive. All 32
calls finish in 85.249128 shared seconds; the largest 3-second return overrun is
0.034838 seconds and is preserved. This pass is closed without retries. Known
source-valid 7/4/1 and 8/5/0 remain allowed; no full66 or native pass follows.
Next inspect a full-geometry 8/6/0 short-sheet construction to free first-sheet
space, auditing a new model before any bounded call. Main f9629063 passes all
six CI jobs. Production, READMEs and upstream releases are unchanged. H2/H5
remain open at 60%; the 22 reserved vectors stay unopened and no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'remaining_necessary_allocations':448,'completion_percent':60})
