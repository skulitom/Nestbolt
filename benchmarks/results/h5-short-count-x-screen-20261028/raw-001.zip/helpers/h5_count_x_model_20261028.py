"""Count-parametric source X-capacity model, without search or mutation on import."""
from ortools.sat.python import cp_model
def build(counts,profiles,variants,dist,capacity):
    B,I,C=counts;families=['bracket']*B+['insert']*I+['cog']*C;ps={p['variant']:p for p in profiles};vs={v['id']:v for v in variants};m=cp_model.CpModel();items=[];xx=[];flags={}
    for i,f in enumerate(families):
        choices=[p for p in profiles if p['family']==f];x=m.new_int_var(min(p['reference_x_domain_um'][0] for p in choices),max(p['reference_x_domain_um'][1] for p in choices),f'x_{i}');zs=[m.new_bool_var(f'option_{i}_{p["variant"]}') for p in choices];one=m.add_exactly_one(zs);options=[]
        for p,z in zip(choices,zs):
            lo,hi=p['reference_x_domain_um'];cs=[m.add(x>=lo),m.add(x<=hi)]
            for ct in cs:ct.only_enforce_if(z)
            options.append({'variant':p['variant'],'selector':z.index,'domain_constraints':[c.index for c in cs]});flags[i,p['variant']]=z
        items.append({'index':i,'family':f,'x':x.index,'exactly_one':one.index,'options':options});xx.append(x)
    groups=[list(range(B)),list(range(B,B+I)),list(range(B+I,B+I+C))];symmetry=[{'items':[a,b],'constraint':m.add(xx[a]<=xx[b]).index} for ids in groups for a,b in zip(ids,ids[1:])];rects=[];intervals=[];demands=[]
    for it in items:
        i=it['index']
        for o in it['options']:
            v=o['variant'];boxes=vs[v]['source_capacity_rectangles_um'] if v==12 else vs[v]['coarse_rectangles_um']
            for k,b in enumerate(boxes):
                ix=m.new_optional_fixed_size_interval_var(xx[i]+b[0]-ps[v]['reference_x_um'],b[2]-b[0],flags[i,v],f'source_x_{len(rects)}');rects.append({'item':i,'variant':v,'component':k,'bounds_um':b,'presence':o['selector'],'interval':ix.index});intervals.append(ix);demands.append(b[3]-b[1])
    cap=m.add_cumulative(intervals,demands,capacity);pairs=[]
    for i in range(len(items)):
        for j in range(i+1,len(items)):
            order=m.new_bool_var(f'before_{i}_{j}');choices=[]
            for a in items[i]['options']:
                for b in items[j]['options']:
                    p,q=a['variant'],b['variant'];ct1=m.add(xx[j]-xx[i]>=dist[p,q]);ct2=m.add(xx[i]-xx[j]>=dist[q,p]);ct1.only_enforce_if([flags[i,p],flags[j,q],order]);ct2.only_enforce_if([flags[i,p],flags[j,q],~order]);choices.append({'variants':[p,q],'constraints':[ct1.index,ct2.index]})
            pairs.append({'items':[i,j],'order':order.index,'choices':choices})
    assert m.validate()==''
    return m,{'counts':counts,'items':items,'symmetry':symmetry,'rectangles':rects,'capacity_constraint':cap.index,'pairs':pairs}
