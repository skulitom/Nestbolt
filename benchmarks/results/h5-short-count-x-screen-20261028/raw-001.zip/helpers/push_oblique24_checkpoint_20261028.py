"""Normal atomic push only after the exact preceding main head passes all six checks."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-oblique24-main-sync-20261028';OLD='541d5bc94c32d4852cc9146dbcc3ff3c6ef67e2d';NEW='f9629063f8a39dc9492f0122426006db8a23a4da';BRANCH='codex/v1-1-shop-files'
def command(*args):return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not OUT.exists();assert command('git','rev-parse','HEAD')==NEW and command('git','branch','--show-current')==BRANCH
assert not command('git','diff','HEAD','--name-only')
paths=command('git','diff','--name-only',OLD+'..'+NEW).splitlines();allowed={'.gitattributes','BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md'}
assert all(p in allowed or p.startswith('benchmarks/results/h5-short13-x-exclusion-20261028') or p.startswith('benchmarks/results/h5-oblique24-baseline-review-20261028') for p in paths)
ci=json.loads(command('gh','run','view','40685021297','--json','databaseId,status,conclusion,headSha,jobs,url'))
assert ci['headSha']==OLD and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
live=json.loads(command('gh','run','list','--branch','main','--limit','100','--json','databaseId,status,conclusion,headSha,workflowName,url'))
assert not [r for r in live if r['status']!='completed'],[r for r in live if r['status']!='completed']
refs=dict(reversed(line.split()) for line in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines())
assert refs=={'refs/heads/main':OLD,'refs/heads/'+BRANCH:OLD},refs
subprocess.run(['git','merge-base','--is-ancestor',OLD,NEW],cwd=ROOT,check=True)
OUT.mkdir();write(OUT/'prior-main-ci.json',ci);write(OUT/'pre-push-live-run-check.json',live);write(OUT/'changed-paths.json',paths)
result=subprocess.run(['git','push','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/'+BRANCH],cwd=ROOT,capture_output=True,text=True)
with (OUT/'push-stdout.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(result.stdout)
with (OUT/'push-stderr.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(result.stderr)
assert result.returncode==0,result.stderr
refs=dict(reversed(line.split()) for line in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines());assert set(refs.values())=={NEW}
new_ci=None
for _ in range(15):
    runs=json.loads(command('gh','run','list','--branch','main','--commit',NEW,'--workflow','Checks','--limit','10','--json','databaseId,status,conclusion,headSha,url'))
    if runs:new_ci=runs[0];break
    time.sleep(2)
receipt={'utc':datetime.now(timezone.utc).isoformat(),'old_main':OLD,'new_main':NEW,'normal_atomic_fast_forward':True,'working_branch_also_updated':True,'prior_main_all6_pass':True,'prior_CI_run':40685021297,'new_main_CI':new_ci,'evidence_and_documentation_only':True,'live_run_cancelled':False,'completion_percent':60,'H2_complete':False,'H5_complete':False,'release_created':False}
write(OUT/'receipt.json',receipt);print(receipt)
