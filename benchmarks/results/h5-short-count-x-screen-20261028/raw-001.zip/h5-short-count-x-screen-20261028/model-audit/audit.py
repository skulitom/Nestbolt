"""Independent complete readback of every count-specific necessary model."""
from pathlib import Path
from hashlib import sha256
import json, shutil, time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-short-count-x-screen-20261028'
GEO=ROOT/'output/h5-insert-order-projection-20261028'
SHAPES=ROOT/'output/h5-short13-necessary-geometry-20261028'
FRONT=ROOT/'output/h5-short13-x-capacity-20261028/necessity-audit'
OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
LOW=-9223372036854775808; HIGH=9223372036854775807
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def fields(p,allowed):assert {f.name for f,v in p.ListFields()}<=set(allowed)
def coeffs(e,expected):
    assert len(e.vars)==len(e.coeffs)==len(expected)
    assert dict(zip(e.vars,e.coeffs))==expected
def expr(e,co,offset=0):
    fields(e,['vars','coeffs','offset']);coeffs(e,co);assert e.offset==offset

def verify(folder,counts,profiles,vs,dist,capacity):
    p=cp_model_pb2.CpModelProto();p.ParseFromString((folder/'model.pb').read_bytes())
    fields(p,['variables','constraints'])
    mp=load(folder/'mapping.json');B,I,C=counts;N=sum(counts);vi=ci=0
    assert mp['counts']==counts and len(mp['items'])==N
    ps={s['variant']:s for s in profiles}
    def var(ix,name,domain):
        nonlocal vi
        assert ix==vi;v=p.variables[ix];fields(v,['name','domain'])
        assert v.name==name and list(v.domain)==domain;vi+=1
    def ct_at(ix,kind,enforcement=(),name=''):
        nonlocal ci
        assert ix==ci;ct=p.constraints[ix]
        fields(ct,['name','enforcement_literal',kind])
        assert ct.WhichOneof('constraint')==kind and ct.name==name
        assert list(ct.enforcement_literal)==list(enforcement);ci+=1;return ct
    def linear(ix,co,domain,enforcement=()):
        ct=ct_at(ix,'linear',enforcement);fields(ct.linear,['vars','coeffs','domain'])
        coeffs(ct.linear,co);assert list(ct.linear.domain)==domain
    for i,(f,r) in enumerate(zip(['bracket']*B+['insert']*I+['cog']*C,mp['items'])):
        assert r['index']==i and r['family']==f
        choices=[s for s in profiles if s['family']==f]
        var(r['x'],f'x_{i}',[min(s['reference_x_domain_um'][0] for s in choices),max(s['reference_x_domain_um'][1] for s in choices)])
        assert len(r['options'])==len(choices)
        for o,s in zip(r['options'],choices):
            assert o['variant']==s['variant'];var(o['selector'],f'option_{i}_{s["variant"]}',[0,1])
        ct=ct_at(r['exactly_one'],'exactly_one');fields(ct.exactly_one,['literals'])
        assert list(ct.exactly_one.literals)==[o['selector'] for o in r['options']]
        for o,s in zip(r['options'],choices):
            lo,hi=s['reference_x_domain_um'];assert len(o['domain_constraints'])==2
            linear(o['domain_constraints'][0],{r['x']:1},[lo,HIGH],[o['selector']])
            linear(o['domain_constraints'][1],{r['x']:1},[LOW,hi],[o['selector']])
    groups=[list(range(B)),list(range(B,B+I)),list(range(B+I,N))]
    expected_order=[(a,b) for g in groups for a,b in zip(g,g[1:])]
    assert len(mp['symmetry'])==len(expected_order)
    for (a,b),r in zip(expected_order,mp['symmetry']):
        assert r['items']==[a,b]
        linear(r['constraint'],{mp['items'][a]['x']:1,mp['items'][b]['x']:-1},[LOW,0])
    ri=0;intervals=[];demands=[]
    for it in mp['items']:
        for o in it['options']:
            v=o['variant'];boxes=vs[v]['source_capacity_rectangles_um'] if v==12 else vs[v]['coarse_rectangles_um']
            for k,b in enumerate(boxes):
                assert mp['rectangles'][ri]=={'item':it['index'],'variant':v,'component':k,'bounds_um':b,'presence':o['selector'],'interval':ci}
                intervals.append(ci);ct=ct_at(ci,'interval',[o['selector']],f'source_x_{ri}')
                fields(ct.interval,['start','end','size'])
                expr(ct.interval.start,{it['x']:1},b[0]-ps[v]['reference_x_um'])
                expr(ct.interval.end,{it['x']:1},b[2]-ps[v]['reference_x_um'])
                expr(ct.interval.size,{},b[2]-b[0]);demands.append(b[3]-b[1]);ri+=1
    assert ri==len(mp['rectangles'])==24*B+2*I+16*C
    ct=ct_at(mp['capacity_constraint'],'cumulative');fields(ct.cumulative,['intervals','demands','capacity'])
    assert list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(demands)
    for e,d in zip(ct.cumulative.demands,demands):expr(e,{},d)
    expr(ct.cumulative.capacity,{},capacity);pi=modepairs=0
    for i in range(N):
        for j in range(i+1,N):
            r=mp['pairs'][pi];assert r['items']==[i,j];z=r['order'];var(z,f'before_{i}_{j}',[0,1])
            expected=[(a,b) for a in mp['items'][i]['options'] for b in mp['items'][j]['options']]
            assert len(r['choices'])==len(expected)
            for saved,(a,b) in zip(r['choices'],expected):
                aa,bb=a['variant'],b['variant'];assert saved['variants']==[aa,bb] and len(saved['constraints'])==2
                x,y=mp['items'][i]['x'],mp['items'][j]['x']
                linear(saved['constraints'][0],{y:1,x:-1},[dist[aa,bb],HIGH],[a['selector'],b['selector'],z])
                linear(saved['constraints'][1],{x:1,y:-1},[dist[bb,aa],HIGH],[a['selector'],b['selector'],-z-1]);modepairs+=1
            pi+=1
    assert pi==len(mp['pairs'])==N*(N-1)//2 and vi==len(p.variables) and ci==len(p.constraints)
    return {'counts':counts,'model_sha256':digest(folder/'model.pb'),'mapping_sha256':digest(folder/'mapping.json'),
            'variables_verified':vi,'constraints_verified':ci,'source_rectangles_verified':ri,'original_pairs_verified':pi,
            'mode_pairs_verified':modepairs,'all_originals_required':True,'passed':True}

OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert plan['per_case_solver_seconds']==3 and plan['aggregate_solver_setting_seconds']==96
assert plan['shared_process_seconds']==120 and plan['maximum_calls_per_case']==1 and not plan['retry_permitted']
survivors=[r['short_counts'] for r in load(FRONT/'updated-allocations.json') if r['excluded_by'] is None]
pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)]
cases=sorted(pareto,key=lambda q:(-q[0],-q[2],-q[1]))
assert len(survivors)==452 and len(cases)==32 and cases==plan['case_counts']
assert [7,5,1] not in cases and [7,6,1] not in cases
profiles=load(GEO/'profiles.json');vs={v['id']:v for v in load(SHAPES/'variants.json')}
dist={tuple(r['profiles']):r['minimum_reference_distance_um'] for r in load(GEO/'pair-distances.json')}
assert len(profiles)==11 and len(dist)==121 and all(v>=0 for v in dist.values())
assert load(GEO/'audit/checks.json')['passed'] and load(SHAPES/'audit/checks.json')['passed']
cog=load(ROOT/'output/h5-global-short-frontier-20261026/cog-spacing.json')
assert dist[12,12]==cog['integer_horizontal_lower']==251956
assert (dist[12,12]-1)**2<cog['squared_horizontal_lower']<=dist[12,12]**2
capacity=load(SHAPES/'stock.json')['capacity_um'][1];assert capacity==312967
records=load(BASE/'models.json');assert len(records)==32;checks=[]
for index,(counts,r) in enumerate(zip(cases,records)):
    name='b%02d-i%02d-c%02d'%tuple(counts);folder=BASE/'cases'/name
    assert r['index']==index and r['case']==name and r['counts']==counts
    check=verify(folder,counts,profiles,vs,dist,capacity)
    assert r['model_sha256']==check['model_sha256'] and r['variables']==check['variables_verified'] and r['constraints']==check['constraints_verified']
    assert r['source_rectangles']==check['source_rectangles_verified'] and r['source_pairs']==check['original_pairs_verified']
    checks.append({'case':name,**check})
write(OUT/'cases.json',checks)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'cases':len(checks),
    'plan_sha256':digest(BASE/'plan.json'),'cases_sha256':digest(OUT/'cases.json'),
    'variables_verified':sum(r['variables_verified'] for r in checks),'constraints_verified':sum(r['constraints_verified'] for r in checks),
    'all_originals_required':True,'all_modes_and_real_cog_angles_retained':True,'all32_maximal_cases_verified':True,
    'cog_pair_all_angle_distance_um':dist[12,12],'double_counted_stems':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
