"""One predeclared bounded pass; no case can be reopened or retried."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-count-x-screen-20261028';OUT=BASE/'search'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child(deadline):
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    audit=load(BASE/'model-audit/checks.json');plan=load(BASE/'plan.json')
    assert audit['passed'] and audit['all32_maximal_cases_verified'] and audit['all_originals_required']
    assert digest(BASE/'plan.json')==audit['plan_sha256'] and digest(BASE/'model-audit/cases.json')==audit['cases_sha256']
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
    checks=load(BASE/'model-audit/cases.json')
    for check in checks:
        if time.perf_counter()+3>=deadline:break
        source=BASE/'cases'/check['case'];folder=OUT/check['case'];folder.mkdir()
        assert digest(source/'model.pb')==check['model_sha256'] and digest(source/'mapping.json')==check['mapping_sha256']
        model=cp_model.CpModel();assert model.proto.parse_text_format((source/'model.pbtxt').read_text())
        assert model.validate()=='' and model.export_to_file(str(folder/'model.pb'))
        assert digest(folder/'model.pb')==check['model_sha256']
        solver=cp_model.CpSolver()
        params={'max_time_in_seconds':3.,'num_search_workers':4,'random_seed':0,'cp_model_probing_level':0,
                'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False,'ignore_subsolvers':['fj']}
        for k,v in params.items():
            if isinstance(v,list):getattr(solver.parameters,k).extend(v)
            else:setattr(solver.parameters,k,v)
        (folder/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        if time.perf_counter()+3>=deadline:break
        write(folder/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'case':check['case'],'counts':check['counts'],
            'model_sha256':check['model_sha256'],'model_audit_sha256':digest(BASE/'model-audit/checks.json'),
            'maximum_calls':1,'solver_seconds':3,'remaining_shared_seconds':deadline-time.perf_counter(),'parameters':params})
        with (folder/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
            solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter()
            status=solver.solve(model);elapsed=time.perf_counter()-start
        response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse())
        (folder/'response.pb').write_bytes(response.SerializeToString())
        if response.solution:
            original=cp_model_pb2.CpModelProto();original.ParseFromString((folder/'model.pb').read_bytes())
            write(folder/'assignment.json',{v.name:int(value) for v,value in zip(original.variables,response.solution)})
        result={'case':check['case'],'counts':check['counts'],'status':solver.status_name(status),
            'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'returned_response_branches':response.num_branches,
            'returned_response_conflicts':response.num_conflicts,'has_solution':bool(response.solution),
            'solver_soft_overrun_seconds':max(0.,response.wall_time-3),'returned_soft_overrun_seconds':max(0.,elapsed-3),
            'solver_calls':1,'closed':True,'source_layout_claimed':False,'H5_complete':False}
        write(folder/'result.json',result);print(check['case'],result['status'],round(elapsed,4),flush=True)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();deadline=start+120
    write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':120,'per_case_seconds':3,
        'maximum_cases':32,'maximum_calls_per_case':1,'aggregate_solver_setting_seconds':96,'retry_permitted':False})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child',str(deadline)],
            cwd=ROOT,capture_output=True,timeout=max(.01,deadline-time.perf_counter()))
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr)
        process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'')
        process={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',process);records=[]
    for case in load(BASE/'models.json'):
        folder=OUT/case['case'];result=folder/'result.json'
        records.append(load(result) if result.exists() else {'case':case['case'],'counts':case['counts'],
            'status':'INTERRUPTED_RETAINED' if (folder/'opened.json').exists() else 'NOT_RUN_RETAINED',
            'solver_calls':int((folder/'opened.json').exists()),'closed':True,'source_layout_claimed':False,'H5_complete':False})
    write(OUT/'results.json',records);print(process)
    print({s:sum(r['status']==s for r in records) for s in sorted({r['status'] for r in records})})
if __name__=='__main__':child(float(sys.argv[2])) if '--child' in sys.argv else main()
