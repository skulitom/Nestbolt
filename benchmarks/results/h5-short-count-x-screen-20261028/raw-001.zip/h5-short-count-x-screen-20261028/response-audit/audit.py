"""Verify every response and assignment, then conservatively update the full frontier."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
from collections import Counter
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-count-x-screen-20261028';SEARCH=BASE/'search';OUT=BASE/'response-audit'
GEO=ROOT/'output/h5-insert-order-projection-20261028';SHAPES=ROOT/'output/h5-short13-necessary-geometry-20261028'
FRONT=ROOT/'output/h5-short13-x-capacity-20261028/necessity-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def assigned(model,response,mapping,counts,profiles,variants,dist):
    sol=list(response.solution);assert len(sol)==len(model.variables)
    for v,value in zip(model.variables,sol):assert any(a<=value<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    def literal(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def present(ct):return all(literal(v) for v in ct.enforcement_literal)
    intervals={i:(expr(ct.interval.start),expr(ct.interval.end),expr(ct.interval.size),present(ct))
        for i,ct in enumerate(model.constraints) if ct.WhichOneof('constraint')=='interval'}
    for i,ct in enumerate(model.constraints):
        if not present(ct):continue
        kind=ct.WhichOneof('constraint')
        if kind=='linear':
            value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs))
            assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='exactly_one':assert sum(literal(v) for v in ct.exactly_one.literals)==1
        elif kind=='interval':
            a,b,size,on=intervals[i];assert a+size==b and size>0 and on
        elif kind=='cumulative':
            events={}
            for ix,dem in zip(ct.cumulative.intervals,ct.cumulative.demands):
                a,b,size,on=intervals[ix]
                if on:
                    d=expr(dem);events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
            amount=0;cap=expr(ct.cumulative.capacity)
            for point in sorted(events):amount+=events[point];assert 0<=amount<=cap
            assert amount==0
        else:raise AssertionError(kind)
    # Second sweep is reconstructed from source geometry, not the model's intervals.
    poses=[];events={};families=Counter();rects=0
    for r in mapping['items']:
        selected=[o for o in r['options'] if sol[o['selector']]];assert len(selected)==1
        v=selected[0]['variant'];x=sol[r['x']];lo,hi=profiles[v]['reference_x_domain_um'];assert lo<=x<=hi
        families[r['family']]+=1;poses.append({'index':r['index'],'family':r['family'],'variant':v,'reference_x_um':x})
        boxes=variants[v]['source_capacity_rectangles_um'] if v==12 else variants[v]['coarse_rectangles_um']
        for a,b,c,d in boxes:
            left=x+a-profiles[v]['reference_x_um'];right=x+c-profiles[v]['reference_x_um']
            events[left]=events.get(left,0)+d-b;events[right]=events.get(right,0)-(d-b);rects+=1
    assert [families[f] for f in ['bracket','insert','cog']]==counts
    height=peak=0;sweep=[]
    for x,delta in sorted(events.items()):
        height+=delta;assert 0<=height<=312967;peak=max(peak,height);sweep.append([x,height])
    assert height==0;pair_checks=0
    for i,a in enumerate(poses):
        for b in poses[i+1:]:
            delta=b['reference_x_um']-a['reference_x_um']
            assert delta>=dist[a['variant'],b['variant']] or -delta>=dist[b['variant'],a['variant']]
            pair_checks+=1
    return {'poses':poses,'capacity_sweep':sweep,'source_y_and_cog_angles_unselected':True,'source_geometry_validated':False}, {
        'variables_verified':len(sol),'constraints_verified':len(model.constraints),'active_intervals_verified':sum(v[3] for v in intervals.values()),
        'independent_source_rectangles_swept':rects,'independent_source_pairs_checked':pair_checks,'capacity_slack_um':312967-peak}

OUT.mkdir();(OUT/'assignments').mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
plan=load(BASE/'plan.json');audit=load(BASE/'model-audit/checks.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert audit['passed'] and digest(BASE/'plan.json')==audit['plan_sha256']
assert digest(BASE/'model-audit/cases.json')==audit['cases_sha256']
process=load(SEARCH/'process.json');results=load(SEARCH/'results.json');checks=load(BASE/'model-audit/cases.json')
assert len(results)==len(checks)==32
profiles={p['variant']:p for p in load(GEO/'profiles.json')};variants={v['id']:v for v in load(SHAPES/'variants.json')}
dist={tuple(r['profiles']):r['minimum_reference_distance_um'] for r in load(GEO/'pair-distances.json')}
review=[];bound=[BASE/'plan.json',BASE/'model-audit/checks.json',BASE/'model-audit/cases.json',SEARCH/'budget.json',SEARCH/'process.json',SEARCH/'results.json']
for check,result in zip(checks,results):
    name=check['case'];folder=SEARCH/name;source=BASE/'cases'/name
    assert result['case']==name and result['counts']==check['counts'] and result['closed']
    assert digest(source/'model.pb')==check['model_sha256'] and digest(source/'mapping.json')==check['mapping_sha256']
    row={'case':name,'counts':check['counts'],'status':result['status'],'solver_calls':result['solver_calls'],'passed':True}
    bound.extend([source/'model.pb',source/'mapping.json'])
    if result['status'] in ['INTERRUPTED_RETAINED','NOT_RUN_RETAINED']:
        assert not (folder/'result.json').exists()
        assert result['solver_calls']==int((folder/'opened.json').exists())
        row['retained']=True;review.append(row);continue
    assert result==load(folder/'result.json') and result['solver_calls']==1
    opened=load(folder/'opened.json');assert opened['maximum_calls']==1 and opened['solver_seconds']==3
    assert opened['model_audit_sha256']==digest(BASE/'model-audit/checks.json') and opened['remaining_shared_seconds']>=3
    assert digest(folder/'model.pb')==check['model_sha256']==opened['model_sha256']
    params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
    assert params.max_time_in_seconds==3 and params.num_search_workers==4 and params.random_seed==0
    assert params.cp_model_probing_level==0 and params.symmetry_level==0 and list(params.ignore_subsolvers)==['fj']
    assert params.log_search_progress and not params.log_to_stdout
    assert {f.name for f,v in params.ListFields()}==set(opened['parameters'])
    response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes())
    status=cp_model_pb2.CpSolverStatus.Name(response.status)
    assert status==result['status'] and status in ['UNKNOWN','FEASIBLE','OPTIMAL','INFEASIBLE']
    assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['returned_response_branches']
    assert response.num_conflicts==result['returned_response_conflicts'] and bool(response.solution)==result['has_solution']
    assert bool(response.solution)==(status in ['OPTIMAL','FEASIBLE'])
    log=(folder/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log
    printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1))
    assert abs(printed-Decimal(str(response.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
    assert result['solver_soft_overrun_seconds']==max(0.,response.wall_time-3)
    assert result['returned_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-3)
    verified={}
    if response.solution:
        model=cp_model_pb2.CpModelProto();model.ParseFromString((source/'model.pb').read_bytes())
        assignment,verified=assigned(model,response,load(source/'mapping.json'),check['counts'],profiles,variants,dist)
        assert load(folder/'assignment.json')=={v.name:int(value) for v,value in zip(model.variables,response.solution)}
        write(OUT/'assignments'/f'{name}.json',assignment)
    else:assert not (folder/'assignment.json').exists()
    bound.extend(p for p in folder.iterdir() if p.is_file())
    row.update({'retained':status!='INFEASIBLE','solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],
        'branches':response.num_branches,'conflicts':response.num_conflicts,'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],
        'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'assignment_checks':verified})
    review.append(row)
infeasible=[r for r in review if r['status']=='INFEASIBLE'];prior=load(FRONT/'updated-allocations.json');updated=[];excluded=[]
for original in prior:
    r=dict(original);containing=[q for q in infeasible if all(r['short_counts'][k]>=q['counts'][k] for k in range(3))]
    if r['excluded_by'] is None and containing:
        r['excluded_by']='source_x_capacity_screen_20261028:'+','.join(q['case'] for q in containing);excluded.append(r)
    updated.append(r)
survivors=[r['short_counts'] for r in updated if r['excluded_by'] is None]
assert len(prior)==len(updated)==4576 and [7,4,1] in survivors and [8,5,0] in survivors
assert len(survivors)+len(excluded)==452
for old,new in zip(prior,updated):
    if old['excluded_by'] is not None:assert old==new
pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)]
write(OUT/'cases.json',review);write(OUT/'updated-allocations.json',updated)
write(OUT/'newly-excluded-allocations.json',excluded);write(OUT/'pareto-necessary-counts.json',pareto)
bound.extend([FRONT/'plan.json',FRONT/'updated-allocations.json',FRONT/'necessity-proof.json',FRONT/'checks.json',
    GEO/'profiles.json',GEO/'pair-distances.json',GEO/'audit/checks.json',SHAPES/'variants.json',SHAPES/'stock.json',SHAPES/'audit/checks.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in bound}})
write(OUT/'necessity-proof.json',{
    'source_geometry_basis':'The unchanged audited source rectangles, outward coordinate domains and 121 directed pair distances are necessary for each original. No bounding-hull or separation-only cog rectangles contribute height. Bracket stems used for spacing are not extra cumulative demands.',
    'arbitrary_count_mapping':'Delete originals not in the specified count vector. Floor source anchors/centers and add each audited source reference offset. All bracket/insert modes and every real cog rotation retain their guaranteed source strips and spacing. Relabel identical copies within each family by reference X, including cogs; this changes no source geometry. Choose each free pair-order literal from the two reference coordinates. At every open X section, disjoint source-contained rectangles occupy at most the full relaxed stock height. The pre-search readback verifies every variable and constraint for each mandatory count model.',
    'multiple_cogs':'Each cog has the same complete center domain and all-angle guaranteed source rectangles. The unchanged pair bound251956um derives from all-angle center separation254297um and maximum short-stock Y difference34426um. Cog angles may differ independently; the model does not tie them. Same-family X ordering is harmless relabeling.',
    'exclusion_rule':'Only an audited terminal INFEASIBLE result excludes its count vector. Any larger vector containing that subset is excluded by deletion. All earlier exclusions and all4576 original rows are preserved. UNKNOWN, interrupted, unrun and positive relaxed assignments remain candidates. The32 cases were fixed before search; newly exposed maximal vectors are not searched in this pass.',
    'limits':'A relaxed assignment selects reference X and outer mode only. It selects neither source Y nor cog angle and is not a source-valid layout. The screen cannot prove full66 feasibility, first-sheet feasibility, global infeasibility, native validity or H5 completion.'})
summary={'passed':True,'seconds':time.perf_counter()-start,'cases':32,'status_counts':dict(Counter(r['status'] for r in review)),
    'solver_calls':sum(r['solver_calls'] for r in review),'shared_process_seconds':process['seconds'],'process_timeout':process['timeout'],
    'aggregate_solver_wall_seconds':sum(r.get('solver_wall_seconds',0) for r in review),
    'maximum_returned_soft_overrun_seconds':max(r.get('returned_soft_overrun_seconds',0) for r in review),
    'assignment_variables_verified':sum(r.get('assignment_checks',{}).get('variables_verified',0) for r in review),
    'assignment_constraints_verified':sum(r.get('assignment_checks',{}).get('constraints_verified',0) for r in review),
    'all_count_allocations_retained':4576,'previous_remaining_allocations':452,'new_exclusions':len(excluded),
    'newly_excluded_counts':[r['short_counts'] for r in excluded],'remaining_necessary_allocations':len(survivors),
    'pareto_necessary_count_vectors':len(pareto),'short_7_4_1_retained':True,'short_8_5_0_retained':True,
    'source_layout_claimed':False,'full66_exclusion_claimed':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
