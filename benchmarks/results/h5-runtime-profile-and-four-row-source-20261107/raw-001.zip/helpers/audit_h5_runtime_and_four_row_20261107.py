"""Independent profile/ledger readback and full original-source construction audit."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,math,pstats
import numpy as np
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_readback_20261107 import verify
from h5_legacy64_source_readback import audit as source_audit
from h5_indexed_source_cache_20261107 import NAMES,restore
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-runtime-and-four-row-audit-20261107';PROFILE=ROOT/'output/h5-screened-runtime-profile-20261107';PILOT=ROOT/'output/h5-batched-guarded-pilot-20261107';BASE=ROOT/'output/h5-four-row-source-20261107';Z=ROOT/'output/h5-screened-source-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();bindings={}
paths=[Path(__file__),JOB,A/'library.json',A/'initial-state.json',A/'objective-identity.json',B/'regions.json',V/'audit/plan.json',V/'cache-context.json',Z/'audit/checks.json']
for folder in [PROFILE,PILOT,BASE]:paths.extend(p for p in folder.rglob('*') if p.is_file())
for stage in ['screened-runtime-profile','batched-guarded-pilot','four-row-source-preparation']:paths += [ROOT/'output'/f'h5-{stage}-process-20261107'/n for n in ['opened.json','process.json']]
paths += [V/n for n in NAMES]
for p in paths:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
queue=paths.copy();seen=set()
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    d=load(p)
    if not isinstance(d,dict):continue
    for name,h in {**d.get('inputs',{}),**d.get('preserved_inputs',{})}.items():
        q=ROOT/name;assert digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json','runtime-cost-plan.json','source-cache-bindings.json'] or q.name.endswith('process.json'):queue.append(q)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Read profile binary stats independently, reconcile every saved profile row and exact replay count, sum only exclusive times, and recompute the closed-time partition from original timestamps. Reconcile both pilot timings and narrow exact-match controls. Independently reconstruct the new four-row centers by rational interpolation of the source bounds, every unchanged coordinate, full model and original-source pose; independently evaluate all81 scalar gradients and recheck all66 original parts and the48-part partial. Explicitly reject reuse of source cache after center changes. All25 keys stay closed; no optimization or candidate variation.'})
profile=load(PROFILE/'checks.json');assert profile['passed'] and profile['unique_saved_evaluation_records']==120 and profile['replayed_evaluations']==240
assert sum(r['records'] for r in load(PROFILE/'replay-controls.json'))==240 and all(r['maximum_gradient_difference']==0 and r['all_saved_scores_exact'] for r in load(PROFILE/'replay-controls.json'))
profile_summary=[]
for epoch in [0,1]:
    stats=pstats.Stats(str(PROFILE/f'epoch-{epoch:02d}.prof'));rows=load(PROFILE/f'epoch-{epoch:02d}-profile.json');expected={}
    for (filename,line,function),(primitive,total,self_s,cumulative,callers) in stats.stats.items():
        try:name=Path(filename).resolve().relative_to(ROOT).as_posix()
        except ValueError:name=filename
        expected[(name,line,function)]=(primitive,total,self_s,cumulative)
    assert len(rows)==len(expected)
    for row in rows:assert expected[(row['file'],row['line'],row['function'])]==tuple(row[k] for k in ['primitive_calls','total_calls','self_seconds','cumulative_seconds'])
    total=sum(r['self_seconds'] for r in rows);intersection=sum(r['self_seconds'] for r in rows if r['function']=='intersection' and r['file'].endswith('shapely/set_operations.py'))
    boundary=next(r['cumulative_seconds'] for r in rows if r['function']=='boundary_gradients' and r['file'].endswith('h5_screened_boundary_gradient_20261107.py'))
    profile_summary.append({'epoch':epoch,'self_time_sum_seconds':total,'intersection_self_seconds':intersection,'intersection_share_of_instrumented_self_time':intersection/total,'boundary_cumulative_seconds':boundary,'cumulative_not_additive':True,'profile_rows':len(rows)})
ledger=load(PROFILE/'closed-time-ledger.json');s=Z/'search';result=load(s/'result.json');process=load(s/'process.json');prep=load(Z/'audit/checks.json')['complete_preparation_seconds'];clock='algorithm_seconds_including_preparation';rows=ledger['intervals'];assert rows[0]['seconds']==prep
for epoch in [0,1]:
    opened=load(s/f'epoch-{epoch:02d}/opened.json');call=load(s/f'epoch-{epoch:02d}/optimizer-opened.json');response=load(s/f'epoch-{epoch:02d}/response.json');prior=prep if epoch==0 else load(s/'epoch-00/response.json')[clock]
    expected=[opened[clock]-prior,call[clock]-opened[clock],response['returned_seconds'],response[clock]-call[clock]-response['returned_seconds']]
    assert [r['seconds'] for r in rows[1+4*epoch:5+4*epoch]]==expected
assert rows[-2]['seconds']==result[clock]-load(s/'epoch-01/response.json')[clock] and rows[-1]['seconds']==process['seconds_including_preparation']-result[clock]
assert sum(r['seconds'] for r in rows)==process['seconds_including_preparation'] and result[clock]<60 and process['seconds_including_preparation']<90
write(OUT/'profile-and-ledger-controls.json',{'passed':True,'profile_summary':profile_summary,'closed_time_intervals_verified':len(rows),'sum_error_seconds':0.,'exact_replayed_gradients':19440,'nested_times_not_added':True})
pilot=load(PILOT/'checks.json');controls=load(PILOT/'controls.json');times=load(PILOT/'timings.json')
assert len(controls)==20 and all(r['gradient_exact'] and r['counts_exact'] and r['shared_lengths_exact'] for r in controls) and load(PILOT/'observed-differences.json')==[]
totals={kind:[sum(r['complete_kernel_seconds'] for r in times if r['kind']==kind and r['sequence']==seq) for seq in ([0,3] if kind=='old' else [1,2])] for kind in ['old','pilot']};assert totals==pilot['aggregate_complete_kernel_seconds']
old=sum(totals['old'])/2;candidate=sum(totals['pilot'])/2;assert candidate>old
write(OUT/'batched-pilot-decision.json',{'passed':True,'contexts_verified':20,'directed_pairs':566,'fast_pairs':338,'fallback_pairs':228,'shared_fallback_pairs':62,'ambiguous_or_split_edge_fallback_pairs':166,'old_mean_seconds':old,'pilot_mean_seconds':candidate,'pilot_to_old_ratio':candidate/old,'replacement_accepted':False,'global_equivalence_claimed':False,'reason':'Matches the finite controls but is slower in both fixed whole-kernel observations. No full objective is built.'})
lib=load(A/'library.json');initial=load(A/'initial-state.json');state=load(BASE/'source-state.json');model=load(BASE/'model.json');centerdata=load(BASE/'centers.json');bounds=lib['family_modes']['cog'][0]['center_bounds_mm'];expected=initial['values'].copy();count=0
for row,n in enumerate([4,4,4,3]):
    for col in range(n):
        owner=18+count;fx=F(2*col+(row%2),7);fy=F(row,3)
        x=F(bounds[0][0])*(1-fx)+F(bounds[0][1])*fx;y=F(bounds[1][0])*(1-fy)+F(bounds[1][1])*fy
        saved=centerdata['centers'][count];assert saved['owner']==owner and saved['row']==row and saved['column']==col and saved['exact_center']==[str(x),str(y)] and saved['center_mm']==[float(x),float(y)]
        expected[owner*2:owner*2+2]=[float(x),float(y)];count+=1
assert state['values']==expected and state['modes']==initial['modes'] and state['pair_weights']==initial['pair_weights'] and expected[:36]==initial['values'][:36] and expected[66:]==initial['values'][66:]
identity=load(A/'objective-identity.json');assert verify(model,lib,state['modes'],expected,state['pair_weights'],identity)
fresh=load(BASE/'fresh-objective.json');value,gradient,detail=Reference(lib).evaluate(model,expected,True,fresh['details']['auxiliary_terms'])
error=float(np.max(np.abs(gradient-np.asarray(fresh['gradient']))));assert error<1e-6 and abs(value-fresh['value'])<1e-6
source_rows=load(BASE/'source66.json');assert source_rows[:33]==lib['fixed_source_rows']
for i,(owner,row) in enumerate(zip(model['owners'],source_rows[33:])):
    assert row['part_id']==owner['identity'][0] and row['copy_index']==owner['identity'][1] and row['sheet_id']=='sheet-0'
    theta=expected[owner['angle_coordinate']]/owner['angle_scale_mm'] if owner['angle_coordinate'] is not None else owner['rotation_radians'];c,sn=math.cos(theta),math.sin(theta);sign=-1 if owner['mirrored'] else 1;cx,cy=owner['source_center']
    assert row['transform']=={'rotation_radians':theta,'mirrored':owner['mirrored'],'translation':[expected[2*i]-(sign*cx*c-cy*sn),expected[2*i+1]-(sign*cx*sn+cy*c)]}
job=load(JOB);checked=source_audit(job,source_rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert checked==load(BASE/'source-checks.json')
partial=load(BASE/'fixed33-and-cogs15.json');assert partial==[r for r in source_rows if r in lib['fixed_source_rows'] or r['part_id']=='cog']
pc=source_audit(job,partial,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in partial]);assert pc==load(BASE/'fixed33-and-cogs15-checks.json')
failed=[r for r in pc['pairs'] if not r['passed']];assert len(failed)==10 and all(r['keys'][0][0]==r['keys'][1][0]=='cog' for r in failed)
plan=load(V/'audit/plan.json');hashes={n:plan['inputs'][(V/n).relative_to(ROOT).as_posix()] for n in NAMES};payloads={n:(V/n).read_bytes() for n in NAMES};context=load(V/'cache-context.json')['context']
try:restore(payloads,hashes,context,lib,state['modes'],expected,state['pair_weights'],identity,load(B/'regions.json'))
except AssertionError:cache_rejected=True
else:raise AssertionError('Changed source coordinates accepted by historical score cache')
closed=load(BASE/'closed-problems.json');assert len(closed)==25 and len({r['key'] for r in closed})==25 and state['key'] in {r['key'] for r in closed} and state['key_already_closed'] and not state['optimizer_allowed_for_this_key']
process=load(ROOT/'output/h5-four-row-source-preparation-process-20261107/process.json');assert process['closed'] and process['passed']
charge=prep+process['complete_seconds'];summary={'passed':True,'rational_centers_verified':15,'unchanged_cog_angles':15,'all66_originals_verified':66,'same_sheet_pairs_verified':checked['same_sheet_pairs'],'stock_edges_verified':checked['stock_edges'],'source_pair_failures':checked['pair_failures'],'source_stock_failures':checked['stock_failures'],'partial48_pair_failures':pc['pair_failures'],'partial_failures_all_cog_cog':True,'scalar_gradient_coordinates':81,'maximum_scalar_gradient_error':error,'original_source_score_error':abs(value-fresh['value']),'fresh_objective_mm2':fresh['value'],'original_source_objective_mm2':load(BASE/'checks.json')['original_source_objective_mm2'],'improves_original_source_objective':False,'historical_source_score_cache_rejected':cache_rejected,'source_key_already_closed':True,'optimizer_calls':0,'source_valid66':False,'prior_preparation_seconds':prep,'new_preparation_seconds':process['complete_seconds'],'complete_preparation_seconds_if_consumed':charge,'H5_complete':False}
write(OUT/'source-controls.json',summary);write(OUT/'cog-contact-failures.json',failed);write(OUT/'source-bindings.json',bindings)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'time_ledger_verified':True,'profile_records_verified':sum(r['profile_rows'] for r in profile_summary),'replayed_evaluation_records':240,'batched_pilot_rejected':True,'four_row_source_verified':True,'source_valid66':False,'source_pair_failures':checked['pair_failures'],'partial_cog_pair_failures':10,'closed_problem_keys':25,'complete_preparation_seconds_if_consumed':charge,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
