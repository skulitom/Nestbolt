"""One direct original-source 4/4/4/3 cog arrangement, with no search."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,time,os
from h5_screened_augmented_objective_20261107 import Objective,compile_model,problem_key
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_mixed_direct_pose_20261107 import source_rows
from h5_legacy64_source_readback import audit
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-four-row-source-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-bulk-contact-proof-and-guarded-pilot-20261107';Z=ROOT/'output/h5-screened-source-preflight-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
paths=[Path(__file__),JOB]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json',P/'closed-problems.json',P/'archive-checks.json',Z/'audit/checks.json',Z/'runtime-bindings.json',ROOT/'output/h5-screened-runtime-profile-20261107/checks.json',ROOT/'output/h5-batched-guarded-pilot-20261107/checks.json']+[ROOT/'output'/n for n in ['h5_screened_augmented_objective_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_movable_roof_model_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Construct exactly one new source-only arrangement directly from the original unoptimized A/W library/state. Preserve all non-cog coordinates, all15 original source angles, modes, weights, original geometry and fixed33 rows. Replace only the15 cog centers by four equal-height rows with counts4/4/4/3, alternating half-pitch stagger and the upper-right slot omitted. Horizontal pitch is two sevenths of the common source center-domain width; vertical pitch is one third of its height. Use exact Fraction arithmetic on the binary64 source bounds before one final float conversion. No angle/offset/seed sweep or objective minimization. Freshly evaluate the resulting full model and all66 source parts, including a separate fixed33-plus-cog15 partial check. This is intended original-source construction, not reuse of a validation/optimized coordinate state. No historical neighbor scores may be reused for changed centers.','row_counts':[4,4,4,3],'row_offset_pitch_fractions':[0,.5,0,.5],'candidate_count':1,'original_source_only':True,'complete_prior_preparation_seconds':load(Z/'audit/checks.json')['complete_preparation_seconds'],'charge_entire_new_process':True,'cap_seconds':22,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');modes=initial['modes'].copy();values=initial['values'].copy();weights=initial['pair_weights'];cogs=lib['angle_owners'];assert len(cogs)==15 and cogs==list(range(18,33))
mode=lib['family_modes']['cog'][0];assert all(modes[i]==0 for i in cogs)
(x0,x1),(y0,y1)=[[Fraction(v) for v in axis] for axis in mode['center_bounds_mm']];dx=(x1-x0)*2/7;dy=(y1-y0)/3
centers=[];index=0
for row,n in enumerate([4,4,4,3]):
    for col in range(n):
        owner=cogs[index];x=x0+dx*(Fraction(col)+Fraction(row%2,2));y=y0+dy*row
        values[2*owner:2*owner+2]=[float(x),float(y)]
        centers.append({'owner':owner,'identity':lib['identities'][owner],'row':row,'column':col,'exact_center':[str(x),str(y)],'center_mm':[float(x),float(y)]});index+=1
assert index==15
write(OUT/'centers.json',{'source_bounds':mode['center_bounds_mm'],'exact_horizontal_pitch':str(dx),'exact_vertical_pitch':str(dy),'centers':centers})
model=compile_model(lib,modes,values,weights,identity);assert model['initial']==values
key=problem_key(physical_key(lib,family_classes(lib),modes),weights,identity);closed=load(P/'closed-problems.json');was_closed=key in {r['key'] for r in closed}
write(OUT/'model.json',model);write(OUT/'source-state.json',{'modes':modes,'values':values,'pair_weights':weights,'key':key,'key_already_closed':was_closed,'optimizer_allowed_for_this_key':not was_closed,'source_only':True,'optimized_ancestor_consumed':False})
obj=Objective(model,regions,identity);value,gradient,details=obj.evaluate(values,True)
write(OUT/'fresh-objective.json',{'value':value,'gradient':gradient.tolist(),'details':details})
baseline_model=compile_model(lib,initial['modes'],initial['values'],weights,identity);baseline=Objective(baseline_model,regions,identity).score(initial['values'])
rows=source_rows(model,values);write(OUT/'source66.json',rows)
job=load(JOB);source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));write(OUT/'source-checks.json',source)
partial=rows[:len(lib['fixed_source_rows'])]+[r for r in rows[len(lib['fixed_source_rows']):] if r['part_id']=='cog'];assert len(partial)==48
write(OUT/'fixed33-and-cogs15.json',partial);partial_check=audit(job,partial,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in partial]);write(OUT/'fixed33-and-cogs15-checks.json',partial_check)
write(OUT/'closed-problems.json',closed)
for name,h in load(Z/'runtime-bindings.json').items():assert digest(ROOT/name)==h
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'candidates':1,'source_only':True,'changed_cog_centers':15,'unchanged_continuous_angles':15,'key_already_closed':was_closed,'key':key,'source_stock_failures':source['stock_failures'],'source_pair_failures':source['pair_failures'],'source_valid66':source['valid'],'fixed33_and_cogs15_valid':partial_check['valid'],'fixed33_and_cogs15_pair_failures':partial_check['pair_failures'],'fresh_objective_mm2':value,'original_source_objective_mm2':baseline,'improves_original_source_objective':value<baseline-1e-6,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
