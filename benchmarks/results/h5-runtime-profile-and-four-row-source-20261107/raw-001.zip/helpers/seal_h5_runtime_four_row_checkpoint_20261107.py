"""Archive measured runtime costs, rejected batched kernel and failed source geometry."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-runtime-profile-and-four-row-source-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-four-row-source-20261107';F=ROOT/'output/h5-runtime-and-four-row-audit-20261107';D=ROOT/'output/h5-screened-runtime-profile-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-bulk-contact-proof-and-guarded-pilot-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['source_pair_failures']==39 and front['partial_cog_pair_failures']==10 and front['optimizer_calls']==0 and front['batched_pilot_rejected']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F,D,ROOT/'output/h5-batched-guarded-pilot-20261107']+[ROOT/'output'/f'h5-{stage}-process-20261107' for stage in ['screened-runtime-profile','batched-guarded-pilot','four-row-source-preparation','runtime-and-four-row-audit']]",
"['*h5*mixed*mode*20261107.py']":"['profile_h5_screened_runtime_20261107.py','*h5*batched*20261107.py','*h5*four_row*20261107.py','run_h5_screened_runtime_profile_stage_20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_runtime_four_row_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
extra="""for ancestor_name in ['h5-screened-source-construction-20261107']:
    ancestor=ROOT/'benchmarks/results'/ancestor_name;am=load(ancestor/'raw-manifest.json');ah=digest(ancestor/'raw-manifest.json')
    for row in am['files']:
        parents.setdefault((row['sha256'],row['bytes']),{'manifest':(ancestor/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':ah,'archive':row['archive'],'member':row['path'],'bytes':row['bytes'],'sha256':row['sha256']})
    for row in load(ancestor/'external-evidence.json').values():parents.setdefault((row['sha256'],row['bytes']),row)
"""
prefix=prefix.replace('OUT.mkdir();members={}',extra+'OUT.mkdir();members={}')
exec(prefix)
runtime=load(ROOT/'output/h5-screened-source-preflight-20261107/runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
PILOT=ROOT/'output/h5-batched-guarded-pilot-20261107'
copies=[(D/'checks.json','runtime-profile.json'),(D/'closed-time-ledger.json','closed-time-ledger.json'),(D/'replay-controls.json','replay-controls.json'),(D/'replay-timings.json','replay-timings.json'),(D/'profiles.json','profiles.json'),(F/'checks.json','independent-audit.json'),(F/'profile-and-ledger-controls.json','profile-and-ledger-controls.json'),(F/'batched-pilot-decision.json','batched-pilot-decision.json'),(F/'source-controls.json','four-row-source-controls.json'),(F/'cog-contact-failures.json','cog-contact-failures.json'),(PILOT/'checks.json','batched-pilot.json'),(PILOT/'controls.json','batched-pilot-controls.json'),(PILOT/'timings.json','batched-pilot-timings.json'),(BASE/'checks.json','four-row-preparation.json'),(BASE/'plan.json','four-row-source-plan.json'),(BASE/'centers.json','four-row-centers.json'),(BASE/'source-state.json','four-row-source-state.json'),(BASE/'source-checks.json','four-row-source-checks.json'),(BASE/'fixed33-and-cogs15-checks.json','partial48-source-checks.json'),(BASE/'closed-problems.json','closed-problems.json')]
for stage in ['screened-runtime-profile','batched-guarded-pilot','four-row-source-preparation','runtime-and-four-row-audit']:copies.append((ROOT/'output'/f'h5-{stage}-process-20261107/process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
ledger=load(OUT/'closed-time-ledger.json');pilot=load(OUT/'batched-pilot-decision.json');proof=load(OUT/'four-row-source-controls.json');profile=load(OUT/'profile-and-ledger-controls.json');checks=load(OUT/'runtime-profile.json')
ci=json.loads(subprocess.check_output(['gh','run','view','42396069909','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='b4e16c74f77be961d6226e482e5116f8b1d7714f'
write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{'passed':True,**archive,'source_bindings':len(bindings),'external_evidence_references':len(external),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'source_contact_geometry_preflight_required',
    'finding':'The closed run time ledger reconciles exactly. The original boundary kernel remains the choice: two bulk variants match narrow controls but lose on complete cost. One direct original-source4/4/4/3 arrangement changes only the15 cog centers. Ten cog/cog contacts overlap by about6.527mm2 each; the full66 arrangement has39 failed pairs and a worse objective than original A/W. It is not a valid partial or a strict source improvement. Its mathematical key was already closed, so no call is allowed.',
    'proposal':'Review the two diagonal source-contact directions of this four-row arrangement and the original cog boundary support geometry. Establish whether a geometrically derived common-angle choice can remove those contacts at fixed centers before constructing another full source arrangement. Do not perform arbitrary angle/seed sweeps or rerun the existing failed construction. Any new source initialization must independently rebuild its complete scores and prove a justified strict improving, unclosed physical-mode/weight key before a bounded call. Changed centers or continuous angles alone never reopen the current closed key.',
    'requirements':['Keep the original filled geometry, clearance, stock bounds, quantities, angles permitted by the job and all original acceptance requirements.','The previous source cache explicitly rejects the new centers. Recompute source scores; do not rebind old scores to a changed context or use optimized/validation states for initialization.','The retained preparation is40.43863689946011s; consuming the new direct construction adds its complete0.49531130003742874s process, totaling40.933948199497536s before further work. Preserve all costs and the60/90s/2GiB limits.','All25 objective/physical-mode/weight keys remain closed. No solver or optimizer ran in this checkpoint.','Four fixed arrangements and440 whole-job allocations remain unresolved. Full66 source/native/material validity, production parity and the original H5 matrix remain required.'],
    'closed_problem_keys':25,'complete_preparation_seconds_if_four_row_construction_consumed':proof['complete_preparation_seconds_if_consumed'],'new_source_geometry_prepared':True,'source_geometry_valid':False,'new_search_contract_prepared':False,'optimizer_calls':0,'H5_complete':False})
report=f'''# Runtime profile and direct four-row source — 2026-11-07

The complete time ledger now reconciles, and the current boundary kernel remains
the measured choice. A batched bulk variant is still slower. A new direct
four-row source construction has **39 failing pairs**, including **10 cog/cog
overlaps**, and worsens the original source objective. It supplies no valid
layout or optimizer opportunity. H2/H5 remain open at **60% completed weight**.

[The closed-run ledger]({NAME}/closed-time-ledger.json) partitions all eleven
recorded intervals with zero sum error. Source preparation is **40.438637 s**;
post-preparation algorithm work is **14.013596 s**, comprising **7.650560 s**
inside the two optimizer calls and **6.363036 s** elsewhere. The second epoch's
weight/selection/output/model interval is **4.493695 s**. The 54-second reserve
is not fresh optimizer budget. Some historical markers combine multiple tasks;
their untimed subcomponents are explicitly left unresolved.

[Complete saved-evaluation replay]({NAME}/runtime-profile.json) checks all
**120 records twice**, including **19,440 scalar gradient coordinates**, with
exact score/gradient equality. [Controls]({NAME}/replay-controls.json) and
[timings]({NAME}/replay-timings.json) retain both unprofiled and instrumented
passes. They are diagnostic replays, not resumed solver calls. Observed timing
variation is preserved; profiler timings do not replace the actual search time.

[Independent binary-profile readback]({NAME}/profile-and-ledger-controls.json)
verifies all 282 function records. Intersections account for
**{100*profile['profile_summary'][0]['intersection_share_of_instrumented_self_time']:.2f}% /
{100*profile['profile_summary'][1]['intersection_share_of_instrumented_self_time']:.2f}%**
of exclusive instrumented time in the two epochs. Nested cumulative times are
not added. [The full profiles]({NAME}/profiles.json) retain the attribution.

This evidence motivated batching component correspondence in the rejected bulk
pilot. The new version also falls back for multiple components on one source
edge, preserving the existing component order. [All 20 controls]({NAME}/batched-pilot-controls.json)
match gradients, counts and shared lengths exactly. Of 566 directed pairs,
338 take the bulk path and 228 fall back (62 shared, 166 ambiguous/split-edge).
[Complete-kernel timing]({NAME}/batched-pilot-timings.json) has old/pilot means
**{pilot['old_mean_seconds']:.6f} / {pilot['pilot_mean_seconds']:.6f} s**:
the pilot takes **{pilot['pilot_to_old_ratio']:.3f} times** as long in these fixed
observations. [It is rejected]({NAME}/batched-pilot-decision.json), and no full
replacement objective is built. Finite exact agreement is not global equivalence.

[The new source construction]({NAME}/four-row-source-plan.json) directly derives
one 4/4/4/3 arrangement from original unoptimized A/W data. Horizontal pitch is
two sevenths of the source center-domain width; vertical pitch is one third of
its height. Rows alternate half-pitch offsets, omitting the upper-right slot.
[Exact rational centers]({NAME}/four-row-centers.json) undergo one final float
conversion. All non-cog coordinates, 15 source angles, modes, weights and fixed
33 rows remain unchanged. There is no coordinate or angle sweep.

[Independent source/model checks]({NAME}/four-row-source-controls.json) verify
all 15 rational centers, all 81 scalar gradients, 66 original identities, 1,380
same-sheet pairs and 264 stock edges. Maximum independent gradient error is
**{proof['maximum_scalar_gradient_error']:.3e}**. [Full source checks]({NAME}/four-row-source-checks.json)
have no stock failures but **39 pair failures**. Even the fixed33-plus-cog15
[48-part partial]({NAME}/partial48-source-checks.json) is invalid: the ten
[diagonal cog contacts]({NAME}/cog-contact-failures.json) overlap by approximately
**6.527023 mm²** each.

The fresh objective is **{proof['fresh_objective_mm2']:.6f} mm²**, compared with
**{proof['original_source_objective_mm2']:.6f} mm²** for original A/W, so this is
not a strict source improvement. [Its source state]({NAME}/four-row-source-state.json)
also has an already-closed mathematical key. Changing centers does not permit
another call. The historical source-score cache explicitly rejects this changed
context; old neighbor scores cannot be reused.

The complete [source preparation process]({NAME}/four-row-source-preparation-process.json)
costs **{proof['new_preparation_seconds']:.6f} s**. If consumed, the retained source
lineage totals **{proof['complete_preparation_seconds_if_consumed']:.6f} s** before
new work. [Profiling]({NAME}/screened-runtime-profile-process.json),
[pilot]({NAME}/batched-guarded-pilot-process.json) and
[independent audit]({NAME}/runtime-and-four-row-audit-process.json) all close under
the fixed CCD1/one-thread/2 GiB controls. [The audit]({NAME}/independent-audit.json)
records zero optimizer calls and preserves every failure.

[Next]({NAME}/next-step.json), inspect the actual diagonal support/contact
geometry before any source-phase construction. No search contract is prepared;
[all 25 keys]({NAME}/closed-problems.json) stay closed. Four fixed arrangements
and all 440 allocations remain. The original full66/native/material and H5 matrix
requirements remain unmet. Main b4e16c74 has {success} passed / {live} live jobs in
[the CI snapshot]({NAME}/main-ci-at-review.json); no live run is cancelled.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the consumed evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 runtime and four-row source:** [independent time/profile/source checks]({{link}}) reconcile all11 intervals and240 exact evaluation replays. The closed run has40.438637s preparation,7.650560s optimizer work and6.363036s other algorithm work. Intersections dominate instrumented time. A batched bulk pilot matches20 controls but takes{pilot["pilot_to_old_ratio"]:.3f} times the complete current-kernel cost and is rejected. One direct original-source4/4/4/3 arrangement preserves all15 angles but has39 full-source pair failures, including10 cog/cog overlaps, and worsens the objective from244577.060782 to334586.901596mm2. All81 scalar gradients and all66 source parts independently check; changed-context cache reuse is rejected. Its key was already closed, so no optimizer call follows. Consuming the0.495311s preparation makes the source lineage40.933948s. Next inspect diagonal source-contact geometry before any successor. All25 keys, four unresolved arrangements and440 allocations remain; H2/H5 stay open at60%. Main b4e16c74 has{success} passed/{live} live jobs at review.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [runtime profile and direct four-row source](../benchmarks/results/{NAME}.md).
The complete time ledger reconciles and all120 recorded evaluations replay
exactly twice. A batched bulk pilot still loses on complete cost; the verified
screened per-edge kernel remains. One direct original-source4/4/4/3 arrangement
has39 full-source pair failures, including10 cog/cog overlaps, and a worse
objective than original A/W. All66 source parts and all81 scalar gradients
independently check. Changed-context score reuse is rejected and the source
key is already closed; no optimizer call follows. Next inspect diagonal source
contact geometry. Consuming this preparation makes the lineage40.933948s.
All25 keys stay closed. Four arrangements and440 allocations remain unresolved;
H2/H5 remain open at60%. Main b4e16c74 has{success} passed/{live} live jobs at review.
Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
