"""Read closed time records and profile evaluation replay without a solver."""
from pathlib import Path
from hashlib import sha256
import cProfile,pstats,json,time,os,math
import numpy as np
from h5_screened_augmented_objective_20261107 import Objective
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-screened-runtime-profile-20261107';BASE=ROOT/'output/h5-screened-source-preflight-20261107';S=BASE/'search';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-bulk-contact-proof-and-guarded-pilot-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter()
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(P/'archive-checks.json')['passed'] and load(BASE/'response-audit/checks.json')['passed']
runtime=load(BASE/'runtime-bindings.json')
for n,h in runtime.items():assert digest(ROOT/n)==h
paths=[Path(__file__),P/'next-step.json',P/'pilot-decision.json',P/'archive-checks.json',BASE/'audit/checks.json',BASE/'plan.json',BASE/'checks.json',BASE/'runtime-bindings.json',BASE/'model-and-source-costs.json',BASE/'response-audit/checks.json',ROOT/'output/h5-screened-source-preparation-process-20261107/process.json',ROOT/'output/h5-shared-source-preflight-20261107/audit/checks.json',A/'objective-identity.json',B/'regions.json',ROOT/'output/run_h5_screened_source_search_20261107.py']
paths += [S/n for n in ['plan.json','result.json','process.json','budget-assessment.json']]
paths += [S/f'epoch-{e:02d}'/n for e in [0,1] for n in ['model.json','opened.json','optimizer-opened.json','response.json','closed-problem.json','evaluations.jsonl']]
paths += [ROOT/'output'/n for n in ['h5_screened_augmented_objective_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_cross_pair_boundary_gradient_20261107.py']]
bindings={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
write(OUT/'plan.json',{'inputs':bindings,'method':'Read only the closed two-epoch timestamps and preparation charge, partition recorded runtime without double-counting. Replay each of the120 recorded evaluations once without a profiler and once under cProfile, comparing all saved score fields and all81 gradients exactly. Profile reports include instrumentation overhead and do not replace the original bounded-run timings. No optimizer, selection, new coordinate, source initializer, replacement objective or reopening.','trajectory_passes':['exact_unprofiled_replay','exact_cprofile_replay'],'expected_records':120,'cap_seconds':120,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
prep=load(BASE/'audit/checks.json');prior=load(ROOT/'output/h5-shared-source-preflight-20261107/audit/checks.json');new=load(ROOT/'output/h5-screened-source-preparation-process-20261107/process.json');result=load(S/'result.json');process=load(S/'process.json');plan=load(S/'plan.json')
charge=prior['complete_preparation_seconds']+new['complete_seconds']
assert charge==prep['complete_preparation_seconds']==result['complete_preparation_seconds']==plan['complete_preparation_seconds']
assert new['closed'] and new['passed'] and process['closed'] and process['tree_closed'] and process['exit_code']==0
clock='algorithm_seconds_including_preparation';parts=[{'interval':'retained_source_preparation','seconds':charge}];cursor=charge;epoch_rows=[];replays=[]
for e in [0,1]:
    folder=S/f'epoch-{e:02d}';opened=load(folder/'opened.json');call=load(folder/'optimizer-opened.json');response=load(folder/'response.json');closed=load(folder/'closed-problem.json')
    assert response['closed'] and response['optimizer_calls']==1 and closed['key']==call['key']==response['key'] and closed['response_sha256']==digest(folder/'response.json')
    assert math.isclose(max(0.,response['returned_seconds']-response['allocated_seconds']),response['slice_overrun_seconds'],abs_tol=1e-12)
    intervals=[('before_epoch_open',opened[clock]-cursor),('epoch_open_to_call_marker',call[clock]-opened[clock]),('optimizer_returned',response['returned_seconds']),('call_marker_to_response_excluding_optimizer',response[clock]-call[clock]-response['returned_seconds'])]
    assert all(v>=0 for _,v in intervals)
    parts.extend({'interval':name,'epoch':e,'seconds':seconds} for name,seconds in intervals)
    cursor=response[clock]
    records=[json.loads(line) for line in (folder/'evaluations.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(records)==response['total_evaluation_records']==response['function_evaluations']+1
    epoch_rows.append({'epoch':e,'key':closed['key'],'records':len(records),'optimizer_allocated_seconds':call['allocated_seconds'],'optimizer_returned_seconds':response['returned_seconds'],'overrun_seconds':response['slice_overrun_seconds'],'call_marker_seconds':call[clock],'response_marker_seconds':response[clock]})
    replays.append((e,Objective(load(folder/'model.json'),load(B/'regions.json'),load(A/'objective-identity.json')),records))
parts.append({'interval':'after_last_response_to_algorithm_result','seconds':result[clock]-cursor})
parts.append({'interval':'algorithm_result_to_supervisor_close','seconds':process['seconds_including_preparation']-result[clock]})
total=sum(r['seconds'] for r in parts);assert abs(total-process['seconds_including_preparation'])<1e-9
optimizer=sum(r['optimizer_returned_seconds'] for r in epoch_rows);postprep=result[clock]-charge
write(OUT/'closed-time-ledger.json',{'passed':True,'source_preparation_seconds':charge,'prior_preparation_seconds':prior['complete_preparation_seconds'],'new_preparation_seconds':new['complete_seconds'],'algorithm_seconds':result[clock],'shared_seconds':process['seconds_including_preparation'],'intervals':parts,'sum_error_seconds':total-process['seconds_including_preparation'],'optimizer_seconds':optimizer,'postpreparation_algorithm_seconds':postprep,'postpreparation_nonoptimizer_seconds':postprep-optimizer,'epoch_records':epoch_rows,'algorithm_limit_seconds':60,'shared_limit_seconds':90,'source_reserve_boundary_seconds':54,'source_reserve_boundary_is_not_new_optimizer_budget':True,'no_attempt_to_subtract_inherited_costs':True,'marker_limitations':'The residual call-marker-to-response interval includes marker serialization, post-optimizer winner evaluation, source checks and writes. These historical records do not time those subcomponents separately.','optimizer_calls':0,'old_calls_resumed':False})
fields=['augmented_objective_mm2','original_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']
controls=[];timings=[];profiles=[]
def replay(epoch,obj,records,label):
    count=0;maximum=0.;started=time.perf_counter()
    for record in records:
        value,g,info=obj.evaluate(record['values'],True)
        assert value==record['augmented_objective_mm2'] and all(info[f]==record[f] for f in fields)
        error=float(np.max(np.abs(g-np.asarray(record['gradient']))));maximum=max(maximum,error)
        assert np.array_equal(g,np.asarray(record['gradient']))
        count+=1
    elapsed=time.perf_counter()-started
    controls.append({'epoch':epoch,'pass':label,'records':count,'exact_scalar_gradient_coordinates':count*81,'maximum_gradient_difference':maximum,'all_saved_scores_exact':True})
    timings.append({'epoch':epoch,'pass':label,'complete_replay_seconds':elapsed,'includes_saved_result_comparison':True})
for e,obj,records in replays:replay(e,obj,records,'unprofiled')
for e,obj,records in replays:
    profiler=cProfile.Profile();profiler.runcall(replay,e,obj,records,'profiled');profiler.dump_stats(str(OUT/f'epoch-{e:02d}.prof'))
    rows=[]
    for (filename,line,function),(primitive,total,self_s,cumulative,callers) in pstats.Stats(profiler).stats.items():
        try:name=Path(filename).resolve().relative_to(ROOT).as_posix()
        except ValueError:name=filename
        rows.append({'file':name,'line':line,'function':function,'primitive_calls':primitive,'total_calls':total,'self_seconds':self_s,'cumulative_seconds':cumulative})
    rows.sort(key=lambda r:(-r['self_seconds'],r['file'],r['line'],r['function']));write(OUT/f'epoch-{e:02d}-profile.json',rows)
    profiles.append({'epoch':e,'self_time_sum_seconds':sum(r['self_seconds'] for r in rows),'top_self_time':rows[:25],'cumulative_times_are_nested_not_additive':True})
write(OUT/'replay-controls.json',controls);write(OUT/'replay-timings.json',timings);write(OUT/'profiles.json',profiles)
for name,h in bindings.items():assert digest(ROOT/name)==h
write(OUT/'source-bindings.json',bindings)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'unique_saved_evaluation_records':sum(len(r) for _,_,r in replays),'complete_replay_passes':2,'replayed_evaluations':sum(r['records'] for r in controls),'exact_scalar_gradient_coordinates':sum(r['exact_scalar_gradient_coordinates'] for r in controls),'maximum_gradient_difference':max(r['maximum_gradient_difference'] for r in controls),'closed_time_ledger_passed':True,'profile_files':2,'profile_timing_not_an_uninstrumented_benchmark':True,'source_preparation_seconds':charge,'postpreparation_algorithm_seconds':postprep,'optimizer_seconds':optimizer,'new_source_state_prepared':False,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False})
print(load(OUT/'checks.json'))
