"""Validation-only bulk pilot with batched original-edge correspondence."""
import numpy as np
import shapely
from h5_cross_pair_boundary_gradient_20261107 import integrate_groups
from h5_screened_boundary_gradient_20261107 import boundary_gradients as fallback

def boundary_gradients(vertices,lines,others,pivots,statistics=None):
    count=len(vertices);assert count==len(lines)==len(others)==len(pivots)
    gradient=np.zeros((count,3));counts=np.zeros(count,dtype=np.int64);lengths=np.zeros(count)
    if not count:return gradient,counts,lengths
    cache={};unique=[];owners=[]
    for v,ll in zip(vertices,lines):
        key=id(v)
        if key not in cache:
            a=np.asarray(v,dtype=float).reshape((-1,2));assert len(a)==len(ll)
            edge=np.roll(a,-1,axis=0)-a;cache[key]=len(unique)
            unique.append((a,edge,np.sum(edge*edge,axis=1),shapely.multilinestrings(ll)))
        owners.append(cache[key])
    owners=np.asarray(owners,dtype=int);sizes=np.asarray([len(r[0]) for r in unique]);offsets=np.concatenate(([0],np.cumsum(sizes)))
    starts=np.concatenate([r[0] for r in unique]);edges=np.concatenate([r[1] for r in unique]);den=np.concatenate([r[2] for r in unique])
    bounds=np.asarray([r[3] for r in unique],dtype=object)[owners];other=np.asarray(others,dtype=object)
    clipped=shapely.intersection(bounds,other);common=shapely.intersection(bounds,shapely.boundary(other));shared=shapely.length(common)
    shared_fallback=(shared>0)|~np.isfinite(shared);bad=shared_fallback.copy()
    geometries=clipped[~bad];groups=np.flatnonzero(~bad)
    while len(geometries):
        keep=~shapely.is_empty(geometries);geometries=geometries[keep];groups=groups[keep]
        if not len(geometries) or not np.any(shapely.get_type_id(geometries)>=4):break
        geometries,parents=shapely.get_parts(geometries,return_index=True);groups=groups[parents]
    if len(geometries):
        keep=shapely.get_type_id(geometries)==1;geometries=geometries[keep];groups=groups[keep]
    mapped_segments=0
    if len(geometries):
        coords,coord_segments=shapely.get_coordinates(geometries,return_index=True)
        coordinate_counts=np.bincount(coord_segments,minlength=len(geometries));simple=(coordinate_counts==2)&(shapely.length(geometries)>0)
        bad[groups[~simple]]=True
        keep=simple&~bad[groups];coords=coords[keep[coord_segments]].reshape((-1,2,2));geometries=geometries[keep];groups=groups[keep]
        if len(geometries):
            segment_sizes=sizes[owners[groups]];pair_segments=np.repeat(np.arange(len(groups)),segment_sizes)
            pair_offsets=np.concatenate(([0],np.cumsum(segment_sizes)))
            edge_ids=np.arange(len(pair_segments))-np.repeat(pair_offsets[:-1],segment_sizes)+offsets[owners[groups]][pair_segments]
            v=starts[edge_ids];edge=edges[edge_ids];denominator=den[edge_ids];safe=np.where(denominator>0,denominator,1.)
            offset=coords[pair_segments]-v[:,None,:]
            t=np.sum(offset*edge[:,None,:],axis=2)/safe[:,None]
            projected=v[:,None,:]+t[:,:,None]*edge[:,None,:]
            residual=np.max(np.sum((coords[pair_segments]-projected)**2,axis=2),axis=1)
            tolerance=1e-7;parameter_tolerance=tolerance/np.sqrt(safe)
            match=(denominator>0)&(residual<=tolerance*tolerance)&(np.min(t,axis=1)>=-parameter_tolerance)&(np.max(t,axis=1)<=1+parameter_tolerance)
            matches=np.bincount(pair_segments[match],minlength=len(groups));bad[groups[matches!=1]]=True
            index=np.zeros(len(groups),dtype=int);parameter=np.zeros(len(groups))
            index[pair_segments[match]]=edge_ids[match];parameter[pair_segments[match]]=np.min(t[match],axis=1)
            # A split source edge can carry an implementation-specific component
            # order. Keep that entire pair on the existing per-edge path.
            codes=groups*max(1,len(starts))+index;_,inverse,frequency=np.unique(codes,return_inverse=True,return_counts=True)
            bad[groups[frequency[inverse]>1]]=True
            keep=~bad[groups];groups=groups[keep];geometries=geometries[keep];index=index[keep];parameter=parameter[keep]
            order=np.lexsort((parameter,index,groups));groups=groups[order];geometries=geometries[order];index=index[order]
            if len(groups):gradient,counts=integrate_groups(starts[index],edges[index],np.asarray(pivots)[groups],groups,geometries,count)
            mapped_segments=len(groups)
    selected=np.flatnonzero(bad)
    if len(selected):
        g,n,l=fallback(*[[values[i] for i in selected] for values in [vertices,lines,others,pivots]])
        gradient[selected]=g;counts[selected]=n;lengths[selected]=l
    if statistics is not None:statistics.update(directed_pairs=count,unique_owner_arrays=len(unique),fast_pairs=int(np.count_nonzero(~bad)),fallback_pairs=len(selected),shared_fallback_pairs=int(np.count_nonzero(shared_fallback)),ambiguous_fallback_pairs=int(np.count_nonzero(bad&~shared_fallback)),mapped_segments=mapped_segments,mapping_tolerance_mm=1e-7)
    return gradient,counts,lengths
