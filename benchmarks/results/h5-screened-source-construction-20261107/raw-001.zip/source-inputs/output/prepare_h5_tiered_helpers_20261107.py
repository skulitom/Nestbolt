"""Version a complete primary neighborhood and a one-shot optional extension."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/h5_indexed_two_center_neighbors_20261107.py').read_text(encoding='utf-8')
changes={
    'import math,time':'import math,time,copy',
    'def neighbors(library,modes,values,weights,identity,region_data,closed_keys,deadline,clock=time.perf_counter,cached_trials=None):':'''class TieredPool:
    def __init__(self,primary,aliases,trials,selections,extension):
        self.primary,self.aliases,self.trials,self.selections=copy.deepcopy((primary,aliases,trials,selections))
        self._extension=extension
    def extend(self,deadline,clock=None):return self._extension(deadline,clock)

def primary(library,modes,values,weights,identity,region_data,closed_keys,deadline,clock=time.perf_counter,cached_trials=None):
    library,modes,values,weights,identity,region_data,closed_keys,cached_trials=copy.deepcopy((library,modes,values,weights,identity,region_data,closed_keys,cached_trials))''',
    'aliases=[];trials=[];selections=[];records=[];checks=0':'aliases=[];trials=[];selections=[];records=[];checks=0;phase="primary";primary_private=[];primary_complete=False',
    "'stage':stage,'checkpoints':checks":"'stage':stage,'tier':phase,'primary_complete':primary_complete,'primary_records':primary_private,'checkpoints':checks",
    "for row,idx in zip(selected,indices_selected):options[i].append({'owner':i":"for center_rank,(row,idx) in enumerate(zip(selected,indices_selected)):options[i].append({'center_rank':center_rank,'owner':i",
    'def emit(selected):':'def emit(selected,sequence):',
    "records.append({'sequence':len(records),'changes':":"records.append({'sequence':sequence,'changes':",
}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
s=s[:s.index('    emit([])')]+'''    schedule=[()]
    for i in range(count):
        for option in options[i]:schedule.append((option,))
    for i,j in combinations(range(count),2):
        for a,b in product(options[i],options[j]):schedule.append((a,b))
    assert len(schedule)==23419 and len(trials)==9102 and len(selections)==111
    primary_indices=[k for k,selected in enumerate(schedule) if all(o['center_rank']==0 for o in selected)]
    extension_indices=[k for k,selected in enumerate(schedule) if any(o['center_rank']==1 for o in selected)]
    assert len(primary_indices)==5911 and len(extension_indices)==17508
    for k in primary_indices:emit(schedule[k],k)
    assert len(records)==5911 and len({r['key'] for r in records})==2854
    checkpoint('complete-primary')
    primary_complete=True;primary_private=records;used=False
    def extension(extension_deadline,extension_clock=None):
        nonlocal deadline,clock,phase,records,used
        assert not used,'An extension can be attempted only once'
        assert math.isfinite(extension_deadline)
        used=True;deadline=extension_deadline
        if extension_clock is not None:clock=extension_clock
        phase='extension';records=[];checkpoint('before-extension')
        for k in extension_indices:emit(schedule[k],k)
        result=sorted(primary_private+records,key=lambda r:r['sequence'])
        assert len(result)==23419 and [r['sequence'] for r in result]==list(range(23419))
        checkpoint('complete-extension')
        return result
    return TieredPool(primary_private,aliases,trials,selections,extension)
'''
compile(s,'h5_tiered_neighbors_20261107.py','exec')
with (ROOT/'output/h5_tiered_neighbors_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/h5_two_center_key_choice_20261107.py').read_text(encoding='utf-8')
insert='''
def primary_sequences():
    counts=[10]*6+[3]*12+[1]*15
    result=[0]+[1+2*k for k in range(111)];offset=223
    for i in range(33):
        for j in range(i+1,33):
            for a in range(counts[i]):
                for b in range(counts[j]):result.append(offset+(2*a)*(2*counts[j])+2*b)
            offset+=4*counts[i]*counts[j]
    assert len(result)==5911 and offset==23419
    return result
PRIMARY_SEQUENCES=tuple(primary_sequences())
'''
s=s.replace('def rank(row):',insert+'\ndef rank(row):')
changes={
    'def choose(records,deadline,clock=time.perf_counter):':'def choose(records,tier,deadline,clock=time.perf_counter):',
    "assert math.isfinite(deadline) and len(records)==23419 and [r['sequence'] for r in records]==list(range(23419))":"assert tier in ['primary','extended'] and math.isfinite(deadline)\n    expected=PRIMARY_SEQUENCES if tier=='primary' else tuple(range(23419))\n    assert tuple(r['sequence'] for r in records)==expected\n    by_sequence={r['sequence']:r for r in records}",
    "'stage':stage,'checkpoints':checks":"'stage':stage,'tier':tier,'checkpoints':checks",
    'dict(Counter(map(len,groups.values())))=={2179:1,130:78,4:2775}':"dict(Counter(map(len,groups.values())))==({562:1,33:78,1:2775} if tier=='primary' else {2179:1,130:78,4:2775})",
    'rows=[records[i] for i in groups[key]]':'rows=[by_sequence[i] for i in groups[key]]',
}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
compile(s,'h5_tiered_key_choice_20261107.py','exec')
with (ROOT/'output/h5_tiered_key_choice_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Separate tiered neighbor and key-choice helpers prepared; no call executed.')
