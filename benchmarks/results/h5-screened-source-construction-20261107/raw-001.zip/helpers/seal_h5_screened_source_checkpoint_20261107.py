"""Preserve the screened-source construction and full scalar-gradient replay."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
SYNC=ROOT/'output/h5-screened-objective-main-sync-20261107'
if not (SYNC/'receipt.json').exists():SYNC=ROOT/'output/h5-tiered-source-main-sync-20261107'
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-screened-source-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-screened-source-preflight-20261107';F=BASE/'response-audit';D=BASE/'outcome-diagnostic'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-screened-objective-preflight-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==2 and front['best_original']['pair_failures']==53 and front['best_unweighted']['pair_failures']==52 and not front['source_valid66'] and front['independent_runtime_full_scores']==15013 and front['all_evaluation_scalar_gradients_verified']==front['total_evaluation_records_verified']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/f'h5-screened-source-{stage}-process-20261107' for stage in ['preparation','audit','response-audit','diagnosis']]+[SYNC]",
"['*h5*mixed*mode*20261107.py']":"['*h5*screened*source*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_screened_source_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'audit/checks.json','source-preflight-audit.json'),(BASE/'audit/selected-model-controls.json','source-model-controls.json'),(BASE/'audit/initializer-source-controls.json','initializer-source-controls.json'),(BASE/'audit/inherited-source-domains.json','inherited-source-domains.json'),(BASE/'audit/cache-rejection-controls.json','source-cache-controls.json'),(BASE/'audit/deadline-controls.json','source-deadline-controls.json'),(BASE/'source-cache-bindings.json','source-cache-bindings.json'),(BASE/'model-and-source-costs.json','source-costs.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-01/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01/unweighted-source-checks.json','best-unweighted-source-checks.json'),(F/'epoch-01-selection/checks.json','runtime-selection-audit.json'),(BASE/'search/plan.json','search-plan.json'),(BASE/'search/budget-assessment.json','budget-assessment.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-search-process.json'),(D/'checks.json','outcome-diagnostic.json'),(D/'family-failures.json','family-failures.json'),(D/'runtime-costs.json','runtime-costs.json'),(D/'bulk-clipping-controls.json','bulk-clipping-controls.json'),(D/'bulk-clipping-timings.json','bulk-clipping-timings.json'),(D/'bulk-clipping-diagnostic.json','bulk-clipping-diagnostic.json'),(BASE/'search/main-ci-at-review.json','main-ci-at-review.json'),(SYNC/'receipt.json','prior-main-push-receipt.json')]
for stage in ['preparation','audit','response-audit','diagnosis']:copies.append((ROOT/'output'/f'h5-screened-source-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
closed=load(BASE/'closed-problems.json')+[load(BASE/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]];assert len(closed)==len({r['key'] for r in closed})==25;write(OUT/'closed-problems.json',closed)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
prep=load(OUT/'source-preflight-audit.json');model=load(OUT/'source-model-controls.json');diag=load(OUT/'outcome-diagnostic.json');cost=load(OUT/'runtime-costs.json');process=load(OUT/'closed-search-process.json');selection=load(OUT/'runtime-selection-audit.json');bulk=load(OUT/'bulk-clipping-diagnostic.json');ci=load(OUT/'main-ci-at-review.json');receipt=load(OUT/'prior-main-push-receipt.json');main=receipt['new_main'];assert ci['headSha']==main
success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);assert all(r['passed'] for r in [prep,model,diag,cost,selection]) and bulk['diagnostic_complete']
separate_mean=sum(bulk['aggregate_clipping_seconds']['separate'])/2;bulk_mean=sum(bulk['aggregate_clipping_seconds']['bulk'])/2
bulk_discrepancies=[r for r in load(OUT/'bulk-clipping-controls.json') if not r['topologically_exact'] or not r['component_count_equal']]
write(OUT/'bulk-clipping-discrepancies.json',{'unconditional_bulk_substitution_accepted':False,'maximum_line_length_difference_mm':max(abs(r['bulk_line_length_mm']-r['separate_line_length_mm']) for r in bulk_discrepancies),'zero_set_distance_does_not_prove_matching_components_or_shared_boundary_integrals':True,'controls':bulk_discrepancies})
write(OUT/'next-step.json',{'status':'bulk_boundary_correspondence_and_integral_preflight_required',
'finding':'The new source-only attempt makes two closed calls with screened gradients, and every recorded gradient is independently checked. The original-area winner still fails 53 pairs; a distinct augmented/unweighted winner fails 52. No valid layout follows. The whole-owner MultiLineString diagnostic has four filled/shared discrepancies for clearance owner11 against owner5 at both distinct winners. Bulk shared line lengths are60.774488003598464mm and63.52250527517097mm where per-edge shared line lengths arezero, despite zero reported set distances. Unconditional bulk substitution is rejected; matching set-distance measurements do not establish matching gradients.',
'proposal':'Review the complete bulk-clipping diagnostic before choosing a replacement. If its cost supports further work, establish exact directed source-edge correspondence for every returned component, including orientation, split/coincident segments and original ordering, then independently verify integrated translation/rotation gradients, clipped counts and shared-boundary lengths. Resolve or reject every geometry/count discrepancy; raw clipping timing alone does not authorize a full objective or source search.',
'requirements':['All 25 objective/physical-mode/weight keys and previous finite pipelines remain closed. No code change, different coordinate state, optimized result or validation case can reopen a problem.','Preserve exact original/clearance geometry, 528 weighted area terms, 15 auxiliary terms, 33 movers/15 angles, strict selector improvement, shared-boundary convention and all three winner streams. Whole-boundary geometry is not yet a verified gradient kernel.','Any future initializer must use only original unoptimized A/W data after exact payload/context verification. Retain 40.43863689946011 s source preparation plus every new cost, and independently verify the selected model and all66 source parts before a new finite contract.','A successor needs complete objective/source/budget evidence under the original 60/90 s and 2 GiB limits. The current prototype supplies no gradient equivalence, whole-objective speedup or packing result.','H5 still requires full66 validity, native/material evidence, production parity and its original matrix. Four fixed arrangements and 440 allocation candidates remain unresolved.'],
'closed_problem_keys':25,'source_only_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'bulk_clipping_diagnostic_complete':True,'bulk_integrated_gradient_kernel_prepared':False,'new_source_state_prepared':False,'new_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
report=f'''# Screened-objective source construction — 2026-11-07

The fresh finite attempt makes two calls within the unchanged limits. Its
lowest-original-overlap output still fails **53 source pairs**, with
**{front['best_original']['score_mm2']:,.6f} mm² overlap**. A different augmented/
unweighted winner fails **52 pairs**. All stock checks pass; no full66 valid layout,
native/material evidence or allocation exclusion follows. H2/H5 remain open at
**60% completed milestone weight**.

[Fresh source preflight]({NAME}/source-preflight-audit.json) retains all 23 prior
closures, binds the exact original A/W payload/context and reads back all 5,911
first-center proposals and 2,854 minima. Nine matching keys exclude 730 proposals;
132 changed exclusion flags remain recorded. Ten stale-cache/payload rejections,
four key-deadline controls, three no-candidate policies and inherited source-domain
controls pass. No optimized or validation state supplies initialization.

[The selected model]({NAME}/source-model-controls.json) changes owners
{model['changes']} at source centers {model['source_centers']}. All 81 coordinates,
33 movers, 15 angles, 528 weighted areas and 15 auxiliary terms read back. Scalar
gradient error is {model['maximum_scalar_gradient_error_mm']:.3e} mm across
{model['directed_scalar_gradient_terms']} directed terms. The [initializer's 66
original parts]({NAME}/initializer-source-controls.json) retain all source geometry
and 38 failed pairs.

The [preparation process]({NAME}/preparation-process.json) adds
{prep['new_source_preparation_seconds']:.6f} s to the retained 39.049161 s, for
**{front['complete_preparation_seconds']:.6f} s**. The [frozen contract]({NAME}/search-plan.json)
uses the verified screened objective and complete shared primary selector, at most
two four-second calls, 52 s selection cutoff and 54 s source reserve. Mathematical
identity and closure keys remain unchanged. [The budget estimate]({NAME}/budget-assessment.json)
binds measured costs and the earlier complete trajectory observations; no observed
speedup extends a time limit or guarantees both full slices.

[Runtime selection replay]({NAME}/runtime-selection-audit.json) independently
checks all 9,102 center scores, 5,911 proposals and 2,854 minima. The full runtime
weight/selection/output/model interval is
**{cost['runtime_weight_selection_output_model_interval_seconds']:.6f} s**;
call allocations are {cost['optimizer_allocations_seconds']} s.
[Response replay]({NAME}/response-audit.json) verifies **{front['total_evaluation_records_verified']}
records**, **{front['saved_points_verified']} saved points**, 528 updated weights,
all three winner streams and six full66 outputs. Every recorded evaluation now
receives an independent scalar reconstruction of all 81 gradient coordinates,
with maximum error **{front['max_all_evaluation_scalar_gradient_error_mm']:.3e} mm**.
The first epoch has one distinct winner; the second has two. Both final source
outcomes remain explicit: [original-area winner]({NAME}/best-original-source-checks.json)
and [unweighted winner]({NAME}/best-unweighted-source-checks.json).

Algorithm/shared totals are **{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**.
Slice overruns {front['slice_overruns_seconds']} are preserved. All
[five search processes close]({NAME}/closed-search-process.json), with peak memory
{process['job']['peak_job_committed_memory']:,} bytes. The 60/90 s and 2 GiB limits hold.
Twenty-five exact problem keys remain closed. Compared with the preceding attempt,
the original-area winner has one fewer failed pair but much more overlap; these
different starting states and timed trajectories do not isolate a packing gain.

[Residual diagnosis]({NAME}/outcome-diagnostic.json) records {diag['positive_area_pairs']}
positive area pairs, {diag['flat_available_pair_gradient_count']} flat available
gradients, {diag['bracket_bracket_source_failures']} bracket/bracket source failures
and {diag['cog_lower_y_negative_gradient_blocked']} cogs blocked at their lower-y
bound. [Family failures]({NAME}/family-failures.json) remain explicit.

A new [read-only clipping diagnostic]({NAME}/bulk-clipping-diagnostic.json) compares
the current per-edge strict-box operation with clipping each owner's full
MultiLineString boundary. It covers the source initializer and the two distinct
latest winners, at both geometry levels: {bulk['geometry_contexts']} contexts,
{bulk['directed_pairs']} directed pairs and {bulk['clipped_geometry_sets']} filled/shared
clipped sets. [Geometry controls]({NAME}/bulk-clipping-controls.json) retain
**{bulk['topologically_exact_sets']} topologically exact sets** and
**{bulk['component_count_mismatches']} component-count mismatches**. Maximum symmetric
difference length is {bulk['maximum_symmetric_difference_length_mm']:.3e} mm; maximum
finite Hausdorff distance is {bulk['maximum_finite_hausdorff_distance_mm']:.3e} mm,
with {bulk['nonfinite_hausdorff_cases']} nonfinite cases recorded explicitly.

The [four discrepancies]({NAME}/bulk-clipping-discrepancies.json) concern clearance
owner 11 against owner 5 at the two distinct winners. Bulk clipping reports shared
line lengths of **60.774488 mm and 63.522505 mm** where the per-edge method reports
zero, and adds corresponding filled-line components. Zero reported set distance
does not prove that those components or their gradients agree. Unconditional bulk
substitution is rejected; the full source-edge geometry must be understood first.

The fixed separate/bulk/bulk/separate [clipping timings]({NAME}/bulk-clipping-timings.json)
have aggregate means **{separate_mean:.6f} s / {bulk_mean:.6f} s**, including boundary
construction, bounds/filtering and both filled/shared intersections. They exclude
source-edge correspondence, gradient integration, complete objective work and
optimization. No integrated bulk gradient has been verified, and the prototype
is not substituted into the search. All mismatches remain evidence to resolve or
reject before any such substitution.

[Next]({NAME}/next-step.json), assess directed source-edge correspondence and full
integrals, including segment order, orientation and coincidence, if the clipping
cost supports it. No new gradient kernel, initializer or successor search is
prepared. Four arrangements and all 440 allocations remain unresolved.

Main is **{main[:8]}**, with {success} passed / {live} live jobs in the [CI snapshot]({NAME}/main-ci-at-review.json).
The [previous ordinary push receipt]({NAME}/prior-main-push-receipt.json) retains
its six-check gate and 52 protected files. Product code, README and releases are
unchanged; this evidence awaits the next ordinary push gate.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical evidence]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 screened-objective source construction:** [complete source, selection and scalar-gradient replay]({{link}}) verifies a fresh original-source model under 23 closures, all 5,911 primary proposals and 2,854 keys. Full preparation is {front["complete_preparation_seconds"]:.6f} s. Two calls close within {front["algorithm_seconds"]:.6f}/{front["shared_seconds"]:.6f} s algorithm/shared totals. The original-area winner remains invalid with 53 failed pairs and {front["best_original"]["score_mm2"]:.6f} mm² overlap; a distinct augmented/unweighted winner fails 52 pairs. All {front["total_evaluation_records_verified"]} records, {front["saved_points_verified"]} saved points, 528 updated weights, 15,013 runtime scores and six source outputs replay, including independent all81 scalar gradients on every evaluation. All 25 keys stay closed. A read-only whole-boundary clipping diagnostic retains {bulk["topologically_exact_sets"]}/{bulk["clipped_geometry_sets"]} exact geometry sets and {bulk["component_count_mismatches"]} component-count mismatches; aggregate separate/bulk clip means are {separate_mean:.6f}/{bulk_mean:.6f} s, excluding correspondence/integration. Next resolve source-edge correspondence and full integrals before any replacement kernel, objective or search. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. Main {main[:8]} has {success} passed / {live} live jobs at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [screened-objective source construction](../benchmarks/results/{NAME}.md).
Fresh original-source preparation totals {front['complete_preparation_seconds']:.6f} s. Both finite calls close,
but the original-area winner fails 53 source pairs and a different augmented/
unweighted winner fails 52. All {front['total_evaluation_records_verified']} records, {front['saved_points_verified']} saved points, 528 updated weights,
15,013 runtime scores and six full66 outputs replay. All 81 gradient coordinates
are independently checked at every evaluation. All 25 exact keys remain closed.
A whole-boundary clipping diagnostic retains {bulk['topologically_exact_sets']}/{bulk['clipped_geometry_sets']} exact geometry sets and
{bulk['component_count_mismatches']} component-count mismatches, including extra shared-boundary lengths of
60.77/63.52 mm. Unconditional substitution is rejected. Source-edge correspondence
and integrated gradients need verification before any replacement kernel or search.
Four arrangements and 440 allocations remain; H2/H5 stay at 60%. Main {main[:8]}
has {success} passed / {live} live jobs at review. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
