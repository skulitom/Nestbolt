"""Replay every evaluation, three winner streams and full original-source output."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
from h5_bracket_augmented_reference_20261107 import Reference,source_rows
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';S=BASE/'search';OUT=BASE/'response-audit';B=ROOT/'output/h5-bracket-collision-depth-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def audit_epoch(S,OUT,lib,initial,identity,regions,closed_keys):
    OUT.mkdir();model=load(S/'model.json');response=load(S/'response.json')
    assert verify(model,lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
    assert response['closed'] and response['optimizer_calls']==1 and response['mode_changes']==response['coefficient_updates']==0
    assert not response['old_calls_resumed'] and not response['any_allocation_excluded'] and not response['H5_complete'] and response['native_calls']==0
    key=initial['key'];assert response['key']==key
    assert key not in closed_keys
    closed=load(S/'closed-problem.json');assert closed['key']==key and closed['closed'] and not closed['retry_permitted'] and closed['response_sha256']==digest(S/'response.json') and closed['objective_identity_sha256']==model['supplementary_objective']['identity_sha256']
    opened=load(S/'optimizer-opened.json');assert opened['key']==key and opened['model_sha256']==digest(S/'model.json') and opened['maximum_calls_for_problem']==1 and not opened['retry_permitted'] and opened['options']==load(A/'audit-v2/optimizer-controls.json')['options'] and opened['parameters']==81
    obj=Objective(model,regions,identity);reference=Reference(lib);bounds=np.array(model['bounds']);metrics={'augmented':'augmented_objective_mm2','original':'original_overlap_area_mm2','unweighted':'unweighted_objective_mm2'};winners={};saved=0;records=0;score_errors=[];original_errors=[];evaluation_gradient_errors=[];replay=[]
    for sequence,line in enumerate((S/'evaluations.jsonl').read_text(encoding='utf-8').splitlines()):
        r=json.loads(line);x=np.array(r['values']);value,g,d=obj.evaluate(x,True)
        assert r['evaluation']==sequence and np.all(x>=bounds[:,0]) and np.all(x<=bounds[:,1]) and value==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
        for field in ['augmented_objective_mm2','original_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']:assert r[field]==d[field]
        independent,scalar_gradient,rd=reference.evaluate(model,x,True,d['auxiliary_terms']);gradient_error=float(np.max(np.abs(g-scalar_gradient)));assert gradient_error<1e-6;evaluation_gradient_errors.append(gradient_error);score_error=abs(independent-value);original_error=abs(rd['original_overlap_area_mm2']-r['original_overlap_area_mm2'])
        assert score_error<1e-6 and original_error<1e-7 and abs(rd['unweighted_objective_mm2']-r['unweighted_objective_mm2'])<1e-7
        score_errors.append(score_error);original_errors.append(original_error)
        flags={name:name not in winners or r[field]<winners[name][field] for name,field in metrics.items()};assert r['improved']==flags
        if sequence==0:assert r['values']==model['initial'] and all(flags.values())
        if any(flags.values()):
            assert r['saved_sequence']==saved and r==load(S/'points'/f'{saved:05d}.json');saved+=1
            for name,flag in flags.items():
                if flag:winners[name]=r
        else:assert r['saved_sequence'] is None
        records+=1
        replay.append({'evaluation':sequence,'independent_augmented_error_mm2':score_error,'independent_original_error_mm2':original_error,'independent_all81gradient_error_mm':gradient_error,'improved':flags})
        if sequence and sequence%100==0:print({'evaluations_replayed':sequence},flush=True)
    assert records==response['total_evaluation_records']==response['function_evaluations']+1 and saved==response['saved_points']==len(list((S/'points').glob('*.json'))) and winners==response['winners']
    assert response['status'] in ['TIME_STOP','RETURNED'] and (response['numerical_result'] is None)==(response['status']=='TIME_STOP')
    if response['numerical_result'] is not None:
        r=response['numerical_result'];assert r['function_evaluations']==response['function_evaluations'];assert abs(obj.evaluate(r['values'])[0]-r['objective_mm2'])<1e-6
    job=load(JOB);fixedids={tuple((r['part_id'],r['copy_index'])) for r in lib['fixed_source_rows']};readbacks={};max_gradient_error=0.;valid_witness=None
    for name,r in winners.items():
        rows=source_rows(lib,model,r['values']);assert rows==load(S/(name+'-source66.json'))
        checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])))
        assert checked==load(S/(name+'-source-checks.json')) and checked['originals']==66 and checked['same_sheet_pairs']==1380 and checked['stock_edges']==264 and checked['cutouts']==90 and checked['hole_vertices']==10026 and checked['stock_failures']==0
        assert all(p['passed'] for p in checked['pairs'] if any(tuple(k) in fixedids for k in p['keys']))
        value,g,d=obj.evaluate(r['values'],True);independent,gg,dd=reference.evaluate(model,r['values'],True,d['auxiliary_terms'])
        error=float(np.max(np.abs(g-gg)));max_gradient_error=max(max_gradient_error,error);assert abs(value-independent)<1e-6 and error<1e-6
        original=sum(p['intersection_area_mm2'] for p in checked['pairs']);assert abs(original-r['original_overlap_area_mm2'])<1e-7
        expected={'pair_failures':checked['pair_failures'],'source_valid66':checked['valid'],'original_overlap_mm2':d['original_overlap_area_mm2'],'unweighted_objective_mm2':d['unweighted_objective_mm2'],'augmented_objective_mm2':value,'auxiliary_bracket_depth_mm2':d['auxiliary_bracket_depth_mm2']}
        assert expected==response['source_readbacks'][name]
        readbacks[name]={**expected,'original_source_overlap_mm2':original,'positive_intersections':sum(p['intersection_area_mm2']>0 for p in checked['pairs'] if not p['passed']),'scalar_gradient_error':error,'winning_evaluation':r['evaluation']}
        write(OUT/(name+'-source-checks.json'),checked)
        if checked['valid'] and valid_witness is None:valid_witness={'label':name,'source66_path':(S/(name+'-source66.json')).relative_to(ROOT).as_posix()}
    assert valid_witness==response['valid_witness'] and response['source_valid66']==(valid_witness is not None)

    write(OUT/'all-evaluation-replay.json',replay);write(OUT/'winner-reconciliation.json',readbacks)
    return {'records':records,'all_evaluation_scalar_gradients':len(evaluation_gradient_errors),'all_evaluation_scalar_gradient_error':max(evaluation_gradient_errors),'saved_points':saved,'function_evaluations':response['function_evaluations'],'score_error':max(score_errors),'original_error':max(original_errors),'gradient_error':max_gradient_error,'readbacks':readbacks,'valid_witness':valid_witness,'distinct_winners':len({r['evaluation'] for r in winners.values()})}
