"""Fresh source-only initializer and independent verification under 23 closures."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
def version(old,new,changes):
    text=(OUT/old).read_text(encoding='utf-8')
    for before,after in changes:
        assert before in text,(old,before)
        text=text.replace(before,after)
    ast.parse(text)
    with (OUT/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
common=[
    ('h5-shared-source-preflight-20261107','h5-screened-source-preflight-20261107'),
    ("P=ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107'","P=ROOT/'benchmarks/results/h5-screened-objective-preflight-20261107';Q=ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107'"),
    ("X=ROOT/'output/h5-tiered-source-preflight-20261107'","X=ROOT/'output/h5-shared-source-preflight-20261107'"),
    ('h5_bracket_augmented_objective_20261107','h5_screened_augmented_objective_20261107'),
    ("P/'deadline-controls.json'","Q/'deadline-controls.json'"),
    ("'closed_keys':21","'closed_keys':23"),('==21','==23'),
]
version('prepare_h5_shared_source_preflight_20261107.py','prepare_h5_screened_source_preflight_20261107.py',common+[
    ('all21closed','all23closed'),
    ('audit_h5_shared_source_preflight_20261107.py','audit_h5_screened_source_preflight_20261107.py'),
    ("load(P/'selector-audit.json')['passed']","load(Q/'selector-audit.json')['passed'] and load(P/'objective-audit.json')['passed'] and load(P/'trajectory-checks.json')['passed']"),
    ("P/'geometry-reuse-controls.json',P/'changed-context-controls.json',P/'twenty-one-key-control.json'","Q/'geometry-reuse-controls.json',Q/'changed-context-controls.json',Q/'twenty-one-key-control.json',Q/'timings.json',P/'objective-audit.json',P/'trajectory-checks.json',P/'trajectory-timings.json'"),
    ("P/'selector-audit.json'","Q/'selector-audit.json'"),
    ("'h5_screened_augmented_objective_20261107.py',","'h5_screened_augmented_objective_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_boundary_gradient_20261107.py',"),
])
version('audit_h5_shared_source_preflight_20261107.py','audit_h5_screened_source_preflight_20261107.py',common+[
    ('the21-key','the23-key'),('37.6806913993787','39.04916139948182'),
    ('h5-shared-source-preparation-process-20261107','h5-screened-source-preparation-process-20261107'),
])
version('run_h5_shared_source_stage_20261107.py','run_h5_screened_source_stage_20261107.py',[
    ('h5_shared_source','h5_screened_source'),('h5-shared-source','h5-screened-source'),
])
version('h5_adaptive_augmented_epoch_readback_20261107.py','h5_screened_source_epoch_readback_20261107.py',[
    ('score_errors=[];original_errors=[];replay=[]','score_errors=[];original_errors=[];evaluation_gradient_errors=[];replay=[]'),
    ('independent,_,rd=reference.evaluate(model,x);score_error=',"independent,scalar_gradient,rd=reference.evaluate(model,x,True,d['auxiliary_terms']);gradient_error=float(np.max(np.abs(g-scalar_gradient)));assert gradient_error<1e-6;evaluation_gradient_errors.append(gradient_error);score_error="),
    ("'independent_original_error_mm2':original_error,'improved':flags","'independent_original_error_mm2':original_error,'independent_all81gradient_error_mm':gradient_error,'improved':flags"),
    ("'records':records,'saved_points':saved","'records':records,'all_evaluation_scalar_gradients':len(evaluation_gradient_errors),'all_evaluation_scalar_gradient_error':max(evaluation_gradient_errors),'saved_points':saved"),
])
version('audit_h5_shared_source_response_20261107.py','audit_h5_screened_source_response_20261107.py',[
    ('h5-shared-source-preflight-20261107','h5-screened-source-preflight-20261107'),
    ('h5_adaptive_augmented_epoch_readback_20261107','h5_screened_source_epoch_readback_20261107'),
    ('==21','==23'),("'prior_closed_keys':21","'prior_closed_keys':23"),
    ("'max_winner_scalar_gradient_error_mm':max(r['gradient_error'] for r in epochs)","'max_winner_scalar_gradient_error_mm':max(r['gradient_error'] for r in epochs),'all_evaluation_scalar_gradients_verified':sum(r['all_evaluation_scalar_gradients'] for r in epochs),'max_all_evaluation_scalar_gradient_error_mm':max(r['all_evaluation_scalar_gradient_error'] for r in epochs)"),
])
version('run_h5_shared_source_response_stage_20261107.py','run_h5_screened_source_response_stage_20261107.py',[
    ('h5_shared_source','h5_screened_source'),('h5-shared-source','h5-screened-source'),
])
print('Prepared source preparation/audit and full scalar-gradient response helpers. No process opened.')
