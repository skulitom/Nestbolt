"""One closed augmented-objective call; preserve all evaluations and three winners."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-screened-source-preflight-20261107';K=ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107';Q=ROOT/'benchmarks/results/h5-tiered-selector-preflight-20261107';Z=ROOT/'output/h5-tiered-source-preflight-20261107';U=ROOT/'benchmarks/results/h5-screened-objective-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'search';B=ROOT/'output/h5-bracket-collision-depth-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
METRICS={'augmented':'augmented_objective_mm2','original':'original_overlap_area_mm2','unweighted':'unweighted_objective_mm2'}

def run_epoch(folder,started,model,lib,identity,regions,key,plan):
    import numpy as np
    from scipy.optimize import minimize
    from h5_screened_augmented_objective_20261107 import Objective
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_legacy64_source_readback import audit
    obj=Objective(model,regions,identity);bounds=np.array(model['bounds']);initial_x=np.array(model['initial']);winners={};saved=0;evaluations=0
    (folder/'points').mkdir();log=(folder/'evaluations.jsonl').open('x',encoding='utf-8',newline='\n')
    def record(x,value,g,details,evaluation):
        nonlocal saved
        r={'evaluation':evaluation,'values':x.tolist(),'gradient':g.tolist(),**{field:float(details[field]) for field in ['augmented_objective_mm2','original_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']}}
        assert value==r['augmented_objective_mm2'] and np.all(x>=bounds[:,0]) and np.all(x<=bounds[:,1])
        flags={name:name not in winners or r[field]<winners[name][field] for name,field in METRICS.items()};r['improved']=flags
        r['saved_sequence']=saved if any(flags.values()) else None
        log.write(json.dumps(r,allow_nan=False,separators=(',',':'))+'\n');log.flush()
        if any(flags.values()):
            write(folder/'points'/f'{saved:05d}.json',r);saved+=1
            for name,improved in flags.items():
                if improved:winners[name]=r
        return r
    value,g,details=obj.evaluate(initial_x,True);record(initial_x,value,g,details,0)
    options=load(A/'audit-v2/optimizer-controls.json')['options'];allocated=min(plan['optimizer_slice_seconds'],54-(time.perf_counter()-started));assert allocated>0
    write(folder/'optimizer-opened.json',{'key':key,'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'nonsmooth_convention':'existing source boundary convention and deterministic bracket nearest branch; not globally differentiable','parameters':81,'allocated_seconds':allocated,'model_sha256':digest(folder/'model.json'),'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'maximum_calls_for_problem':1,'retry_permitted':False,'algorithm_seconds_including_preparation':time.perf_counter()-started})
    class Deadline(Exception):pass
    def function(x):
        nonlocal evaluations
        if time.perf_counter()>=deadline:raise Deadline()
        value,g,d=obj.evaluate(x,True);evaluations+=1;record(x,value,g,d,evaluations);return value,g
    def callback(x):
        if winners['unweighted']['unweighted_objective_mm2']<=1e-16:raise StopIteration()
    before=time.perf_counter();deadline=before+allocated;numerical=None
    try:
        result=minimize(function,initial_x,jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options)
        status='RETURNED';numerical={'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'objective_mm2':float(result.fun),'values':result.x.tolist()}
    except Deadline:status='TIME_STOP'
    returned=time.perf_counter()-before;log.close();readbacks={};job=load(JOB);valid_witness=None
    for name,r in winners.items():
        value,g,d=obj.evaluate(r['values'],True)
        assert value==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
        rows=source_rows(model,r['values']);write(folder/(name+'-source66.json'),rows)
        checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])))
        write(folder/(name+'-source-checks.json'),checked)
        assert checked['stock_failures']==0 and checked['originals']==66
        readbacks[name]={'pair_failures':checked['pair_failures'],'source_valid66':checked['valid'],'original_overlap_mm2':d['original_overlap_area_mm2'],'unweighted_objective_mm2':d['unweighted_objective_mm2'],'augmented_objective_mm2':value,'auxiliary_bracket_depth_mm2':d['auxiliary_bracket_depth_mm2']}
        if checked['valid'] and valid_witness is None:valid_witness={'label':name,'source66_path':(folder/(name+'-source66.json')).relative_to(ROOT).as_posix()}
    elapsed=time.perf_counter()-started
    response={'closed':True,'status':status,'key':key,'numerical_result':numerical,'allocated_seconds':allocated,'returned_seconds':returned,'slice_overrun_seconds':max(0.,returned-allocated),'function_evaluations':evaluations,'total_evaluation_records':evaluations+1,'saved_points':saved,'winners':winners,'source_readbacks':readbacks,'source_valid66':valid_witness is not None,'valid_witness':valid_witness,'optimizer_calls':1,'mode_changes':0,'coefficient_updates':0,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'complete_preparation_seconds':plan['complete_preparation_seconds'],'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False}
    write(folder/'response.json',response);write(folder/'closed-problem.json',{'key':key,'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'closed':True,'retry_permitted':False,'response_sha256':digest(folder/'response.json')})
    return response

def child(started):
    import scipy
    from h5_screened_augmented_objective_20261107 import compile_model,Objective,problem_key
    from h5_bracket_augmented_readback_20261107 import verify
    from h5_indexed_two_center_neighbors_20261107 import apply_neighbor
    from h5_shared_geometry_selection_20261107 import select
    from h5_weighted_original_model_20261107 import update_weights
    from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
    from h5_checked_affinity_20261107 import affinity_mask
    assert scipy.__version__=='1.17.1' and affinity_mask()==4294901760
    assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
    plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
    initial=load(BASE/'selected-state.json');lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');classes=family_classes(lib)
    modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];old_closed={r['key'] for r in load(BASE/'closed-problems.json')};visited=set(old_closed)
    summaries=[];best_original=None;best_unweighted=None;valid_witness=None;stop='MAXIMUM_EPOCHS';total_trials=0;total_centers=0;updates=0
    for epoch in range(plan['maximum_optimizer_calls']):
        if time.perf_counter()-started>=plan['selection_boundary_seconds']:stop='TIME_STOP_BEFORE_EPOCH';break
        folder=OUT/f'epoch-{epoch:02d}';folder.mkdir();incoming=list(values)
        write(folder/'opened.json',{'epoch':epoch,'incoming_values':incoming,'incoming_modes':modes,'weights_before_update':weights,'runtime_neighbor_cache_used':False,'visited_keys':sorted(visited),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        if epoch:
            previous=compile_model(lib,modes,incoming,weights,identity);losses=Objective(previous,regions,identity).pair_losses(incoming).tolist();after=update_weights(weights,losses)
            write(folder/'weight-transition.json',{'before':weights,'pair_losses_mm2':losses,'after':after,'source':'previous_epoch_augmented_best','auxiliary_excluded_from_weight_update':True});weights=after;updates+=1
            tier=select(lib,modes,incoming,weights,identity,regions,visited,primary_deadline=started+plan['selection_boundary_seconds'],extension_deadline=None,cached_trials=None)
            if tier['status']!='PRIMARY_COMPLETE':
                assert tier['status']=='NO_COMPLETE_PRIMARY' and tier['selected_proposal'] is None
                write(folder/'incomplete-primary.json',tier);stop='PRIMARY_SELECTION_DEADLINE';break
            assert tier['completed_tier']=='primary' and tier['extended'] is None and tier['partial'] is None
            records=tier['primary']['records'];selection=tier['primary']['selection'];groups=tier['primary']['groups'];minima=tier['primary']['minima']
            aliases,trials,selections=[tier[n] for n in ['aliases','trials','selections']]
            write(folder/'selection-tier.json',{'completed_tier':'primary','raw_proposals':5911,'distinct_keys':2854,'extension_attempted':False,'selected_proposal':tier['selected_proposal']})
            write(folder/'neighbors.json',records);write(folder/'owner-aliases.json',aliases);write(folder/'center-trials.json',trials);write(folder/'center-selections.json',selections);total_trials+=len(records);total_centers+=len(trials)
            write(folder/'selection.json',selection);write(folder/'group-members.json',groups);write(folder/'key-minima.json',minima)
            if not selection['strictly_improves_current']:stop='NO_IMPROVING_ADMISSIBLE';break
            chosen=selection['accepted_choice'];modes,model,point=apply_neighbor(lib,modes,incoming,weights,identity,chosen);incoming=point.tolist()
        else:
            model=compile_model(lib,modes,incoming,weights,identity);assert model==load(BASE/'selected-model.json')
        assert verify(model,lib,modes,incoming,weights,identity)
        key=problem_key(physical_key(lib,classes,modes),weights,identity);assert key not in visited
        if time.perf_counter()-started>=plan['source_reserve_boundary_seconds']:stop='TIME_STOP_BEFORE_CALL';break
        write(folder/'model.json',model);assert verify(load(folder/'model.json'),lib,modes,incoming,weights,identity)
        visited.add(key);response=run_epoch(folder,started,model,lib,identity,regions,key,plan)
        for label,field in [('original','original_overlap_area_mm2'),('unweighted','unweighted_objective_mm2')]:
            r=response['winners'][label];candidate={'epoch':epoch,'label':label,'metric':field,'score_mm2':r[field],'pair_failures':response['source_readbacks'][label]['pair_failures'],'source_valid66':response['source_readbacks'][label]['source_valid66']}
            if label=='original' and (best_original is None or candidate['score_mm2']<best_original['score_mm2']):best_original=candidate
            if label=='unweighted' and (best_unweighted is None or candidate['score_mm2']<best_unweighted['score_mm2']):best_unweighted=candidate
        if response['valid_witness'] is not None:valid_witness={'epoch':epoch,**response['valid_witness']}
        summary={'epoch':epoch,'key':key,'status':response['status'],'function_evaluations':response['function_evaluations'],'saved_points':response['saved_points'],'source_readbacks':response['source_readbacks'],'minimum_weight':min(weights),'maximum_weight':max(weights)}
        summaries.append(summary);print(summary,flush=True);values=response['winners']['augmented']['values']
        if valid_witness is not None:stop='SOURCE_VALID_CANDIDATE';break
        if time.perf_counter()-started>=plan['source_reserve_boundary_seconds']:stop='TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started
    result={'closed':True,'status':stop,'optimizer_calls':len(summaries),'unique_new_keys':len(visited)-len(old_closed),'historical_closed_keys':len(old_closed),'weight_updates':updates,'neighborhood_tier':'primary','extension_attempts':0,'complete_runtime_proposals':total_trials,'complete_runtime_centers':total_centers,'runtime_neighbor_cache_used':False,'epochs':summaries,'best_original':best_original,'best_unweighted':best_unweighted,'source_valid66':valid_witness is not None,'valid_witness':valid_witness,'complete_preparation_seconds':plan['complete_preparation_seconds'],'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False}
    write(OUT/'result.json',result);print({k:v for k,v in result.items() if k!='epochs'})


def main():
    checked=load(BASE/'audit/checks.json');assert checked['passed'] and checked['strictly_improves_current'] and load(U/'objective-audit.json')['passed'] and load(U/'trajectory-checks.json')['passed'] and load(U/'closed-problems.json')==load(BASE/'closed-problems.json');OUT.mkdir();charge=checked['complete_preparation_seconds'];assert charge<46;started=time.perf_counter()-charge
    inputs=[Path(__file__),JOB,Q/'cost-profile.json',Z/'outcome-diagnostic/runtime-costs.json']+[U/n for n in ['archive-checks.json','objective-audit.json','complete-objective-controls.json','trajectory-checks.json','trajectory-timings.json','timings.json','next-step.json','closed-problems.json']]+[BASE/n for n in ['plan.json','checks.json','selected-model.json','selected-state.json','selection.json','closed-problems.json','runtime-bindings.json','audit/plan.json','audit/checks.json','audit/deadline-controls.json','audit/selected-model-controls.json','audit/inherited-source-domains.json','audit/cache-rejection-controls.json','audit/policy-controls.json','source-cache-bindings.json','model-and-source-costs.json','initializer-source66.json','initializer-source-checks.json','audit/initializer-source-controls.json']]+[K/n for n in ['plan.json','selector-audit.json','stale-cache-controls.json','deadline-controls.json','timings.json','geometry-reuse-controls.json','changed-context-controls.json','archive-checks.json']]+[A/n for n in ['library.json','objective-identity.json','audit-v2/optimizer-controls.json']]+[B/'regions.json']+[ROOT/'output'/n for n in ['audit_h5_screened_source_response_20261107.py','run_h5_screened_source_response_stage_20261107.py','h5_shared_geometry_selection_20261107.py','h5_shared_geometry_neighbors_20261107.py','h5_tiered_key_choice_20261107.py','h5_tiered_primary_key_readback_20261107.py','h5_tiered_primary_selection_readback_20261107.py','h5_indexed_two_center_neighbors_20261107.py','h5_indexed_source_cache_20261107.py','h5_screened_augmented_objective_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_screened_source_epoch_readback_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_weighted_original_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_preparation_seconds':charge,'algorithm_seconds':60,'shared_seconds':90,'source_reserve_boundary_seconds':54,'selection_boundary_seconds':52,'memory_bytes':2**31,'cpu_affinity_mask':4294901760,'blas_threads':1,'maximum_optimizer_calls':2,'optimizer_slice_seconds':4.,'neighborhood_tier':'primary','extension_attempts':0,'method':'One new finite adaptive pipeline from the independently verified original A/W source initializer under all23closed identities, charging all inherited and new source preparation. Source initialization uses only exact hash/context-bound original-source scores and complete5911first-center proposals. Runtime evaluates the declared complete PRIMARY tier only:9x9plusclamped source centers,111physical owner/mode options,9102trials,5911raw proposals,2854complete key minima. Second-center extension is deliberately disabled in this finite contract to reserve the remaining budget for optimizer/source checks; its separate validated implementation does not make incomplete output eligible. Runtime geometry recalculates with cached_trials=None, sharing exact immutable raw center rows only within this invocation. Nominal mode, angle and centers remain exact keys; no changed-context reuse or quantization. Use the completely verified screened augmented objective, omitting only strictly disjoint edge/polygon boxes while retaining touching and nonfinite bounds. Mathematical identity and closure keys remain unchanged. Keep528weighted area terms,15coefficient1auxiliary terms,33movers/15continuousangles and the existing bounded area-only weight update. At most two4second calls, each shortened at54seconds for source checks; primary selection/grouping stop at52seconds. Timing observations support this bounded attempt, not a guarantee of a second call. Every exact objective/physical-mode/weight key closes after one call; changed coordinates/code cannot reopen it. Preserve every evaluation, three winner streams and full66source outputs. Stop on finite count, time, no strict1e-6improvement, source validity or inconsistency.60/90second preparation-inclusive algorithm/shared limits,2GiBverifiedJobv4. No restart/reseed/refinement/native call.','retry_permitted':False,'restarts':0})
    profile=load(Q/'cost-profile.json');runtime_profile=next(r for r in profile['profiles'] if r['context']=='runtime-uncached');timings=load(K/'timings.json');selector=max(r['selector_and_grouping_seconds'] for r in timings if r['context'] in ['runtime','latest_runtime'] and r['tier']=='primary' and r['kind']=='shared');cost=load(BASE/'model-and-source-costs.json');planned=charge+8+selector+runtime_profile['serialization']['wall_seconds']+2*(cost['model_construction_verification_and_serialization_seconds']+3*cost['source_output_and_validation_seconds'])+load(Z/'outcome-diagnostic/runtime-costs.json')['first_call_startup_after_preparation_seconds']
    assert planned<60
    write(OUT/'budget-assessment.json',{'complete_preparation_seconds':charge,'maximum_optimizer_seconds':8,'primary_selector_observed_upper_seconds':selector,'runtime_serialization_observed_seconds':runtime_profile['serialization']['wall_seconds'],'per_model_observed_seconds':cost['model_construction_verification_and_serialization_seconds'],'per_source_check_observed_seconds':cost['source_output_and_validation_seconds'],'prior_complete_first_call_startup_observed_seconds':load(Z/'outcome-diagnostic/runtime-costs.json')['first_call_startup_after_preparation_seconds'],'serialization_reference':'Earlier runtime primary outputs are unchanged in shared-selector equivalence controls; reuse its complete serialization observation, not a new measurement.','screened_objective_observed_saved_trajectory_seconds':load(U/'trajectory-checks.json')['summary'],'screened_objective_identity_unchanged':True,'evaluation_speedup_used_to_extend_limits':False,'planned_algorithm_seconds':planned,'limits_guaranteed_by_estimate':False,'actual_deadlines_required':True,'source_variation_retained':True,'optimizer_calls':0})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'complete_preparation_seconds':charge,'memory_bytes':2**31,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'retry_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No complete result; pipeline remains closed.')

if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
