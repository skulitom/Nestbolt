"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_screened_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-screened-source-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';X=ROOT/'output/h5-indexed-source-preflight-20261107';Z=ROOT/'output/h5-shared-source-preflight-20261107';Y=ROOT/'output/h5-tiered-source-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==1
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-01/original-source-checks.json','search/epoch-01/response.json','search/epoch-01/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json',Q/'response-audit/checks.json',U/'response-audit/checks.json',V/'response-audit/checks.json',X/'response-audit/checks.json',Z/'response-audit/checks.json',Y/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-01/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-01/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-01/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P),('prior_best_admissible',Q),('prior_current_mode',U),('prior_two_center',V),('prior_indexed_source',X),('prior_tiered_source',Y),('prior_shared_source',Z)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))





"""Read-only whole-boundary clipping cost and geometry correspondence diagnostic."""
import shapely
from h5_original_overlap_gradient_v2_20261107 import line_parts
E=BASE/'search/epoch-01';opened=load(E/'opened.json');call=load(E/'optimizer-opened.json');first_call=load(BASE/'search/epoch-00/optimizer-opened.json');result=load(BASE/'search/result.json')
paths=[Path(__file__),ROOT/'output/h5_screened_augmented_objective_20261107.py',ROOT/'output/h5_screened_boundary_gradient_20261107.py',ROOT/'output/h5_original_overlap_gradient_v2_20261107.py']+[BASE/n for n in ['selected-model.json','selected-state.json','audit/checks.json','response-audit/checks.json','search/result.json','search/epoch-00/optimizer-opened.json']]+[E/n for n in ['model.json','response.json','opened.json','optimizer-opened.json']]
write(OUT/'runtime-cost-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Reconcile the new finite search costs and compare per-edge strict-box clipping with whole-owner MultiLineString clipping. Test the fresh source initializer and both distinct final winners at original and clearance levels. Fixed separate/bulk/bulk/separate order including boundary construction, bounds/filtering and both filled/shared intersections. Independently compare the complete clipped geometry sets, component counts and clipped lengths after timing. No integrated gradients or complete-objective implementation is substituted; this is a diagnostic only, with discrepancies retained. No optimizer, source initializer or reopening.','geometry_diagnostic_tolerance_mm':1e-7,'validation_only':True,'optimizer_calls':0})
write(OUT/'runtime-costs.json',{'passed':True,'runtime_weight_selection_output_model_interval_seconds':call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'],'first_call_startup_after_preparation_seconds':first_call['algorithm_seconds_including_preparation']-result['complete_preparation_seconds'],'optimizer_allocations_seconds':[first_call['allocated_seconds'],call['allocated_seconds']],'optimizer_calls':0,'closed_search_resumed':False})
states=[('source_initializer',load(BASE/'selected-model.json'),load(BASE/'selected-state.json')['values'])]
seen=set()
for label,r in response['winners'].items():
    key=tuple(r['values'])
    if key not in seen:states.append((label,model,r['values']));seen.add(key)
assert len(states)==3
controls=[];timings=[];total_edges=retained=directed=0;whole_gradients_verified=False
for label,m,point in states:
    objective=Objective(m,load(B/'regions.json'),load(A/'objective-identity.json'))
    for level,entries in enumerate(objective.geometry(point)):
        polygons=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(polygons[objective.left],polygons[objective.right]))
        owners=[];others=[]
        for index in np.flatnonzero(areas>0):
            i,j=m['pairs'][index]
            for own,other in [(i,j),(j,i)]:owners.append(own);others.append(other)
        owners=np.asarray(owners,dtype=int);others=np.asarray(others,dtype=int);count=len(owners);directed+=count
        def separate():
            sizes=np.asarray([len(entries[i][0]) for i in owners]);groups=np.repeat(np.arange(count),sizes);lines=np.concatenate([entries[i][2] for i in owners])
            left=shapely.bounds(lines);right=shapely.bounds(polygons[others])[groups]
            disjoint=(left[:,0]>right[:,2])|(left[:,2]<right[:,0])|(left[:,1]>right[:,3])|(left[:,3]<right[:,1])
            keep=~disjoint|~(np.all(np.isfinite(left),axis=1)&np.all(np.isfinite(right),axis=1));groups=groups[keep];lines=lines[keep]
            clipped=shapely.intersection(lines,polygons[others][groups]);shared=shapely.intersection(lines,shapely.boundary(polygons[others])[groups])
            return clipped,shared,groups,int(np.count_nonzero(keep)),len(keep)
        def bulk():
            boundaries=np.asarray([shapely.multilinestrings(e[2]) for e in entries],dtype=object)
            clipped=shapely.intersection(boundaries[owners],polygons[others]);shared=shapely.intersection(boundaries[owners],shapely.boundary(polygons[others]))
            return clipped,shared
        observations=[]
        for sequence,kind in enumerate(['separate','bulk','bulk','separate']):
            start=time.perf_counter();got=(separate if kind=='separate' else bulk)();elapsed=time.perf_counter()-start
            observations.append(got);timings.append({'state':label,'level':level,'sequence':sequence,'kind':kind,'complete_clipping_seconds':elapsed,'directed_pairs':count})
        old=observations[0];new=observations[1];assert all(shapely.equals_exact(a,b,0.).all() for a,b in zip(old[:2],observations[3][:2])) and np.array_equal(old[2],observations[3][2]);assert all(shapely.equals_exact(a,b,0.).all() for a,b in zip(new,observations[2]))
        retained+=old[3];total_edges+=old[4]
        for group,(own,other) in enumerate(zip(owners,others)):
            for kind,k in [('filled',0),('shared',1)]:
                parts=old[k][old[2]==group];combined=shapely.union_all(parts);whole=new[k][group]
                exact=bool(shapely.equals(combined,whole));difference=shapely.symmetric_difference(combined,whole);length=float(difference.length)
                distance=0. if combined.is_empty and whole.is_empty else float(shapely.hausdorff_distance(combined,whole))
                separate_lines=[line for part in parts for line in line_parts(part)];bulk_lines=line_parts(whole)
                controls.append({'state':label,'level':level,'kind':kind,'owner':int(own),'other':int(other),'topologically_exact':exact,'symmetric_difference_length_mm':length,'hausdorff_distance_mm':distance if np.isfinite(distance) else None,'separate_line_components':len(separate_lines),'bulk_line_components':len(bulk_lines),'component_count_equal':len(separate_lines)==len(bulk_lines),'separate_line_length_mm':sum(line.length for line in separate_lines),'bulk_line_length_mm':sum(line.length for line in bulk_lines)})
write(OUT/'bulk-clipping-controls.json',controls);write(OUT/'bulk-clipping-timings.json',timings)
totals={kind:[sum(r['complete_clipping_seconds'] for r in timings if r['kind']==kind and r['sequence']==sequence) for sequence in ([0,3] if kind=='separate' else [1,2])] for kind in ['separate','bulk']}
write(OUT/'bulk-clipping-diagnostic.json',{'diagnostic_complete':True,'states':len(states),'geometry_contexts':2*len(states),'directed_pairs':directed,'separate_nominal_edges':total_edges,'separate_retained_edges':retained,'clipped_geometry_sets':len(controls),'topologically_exact_sets':sum(r['topologically_exact'] for r in controls),'component_count_mismatches':sum(not r['component_count_equal'] for r in controls),'maximum_symmetric_difference_length_mm':max(r['symmetric_difference_length_mm'] for r in controls),'maximum_finite_hausdorff_distance_mm':max(r['hausdorff_distance_mm'] or 0. for r in controls),'nonfinite_hausdorff_cases':sum(r['hausdorff_distance_mm'] is None for r in controls),'aggregate_clipping_seconds':totals,'full_integrated_gradients_verified':False,'full_objective_speedup_claimed':False,'new_boundary_kernel_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'closed_search_resumed':False,'H5_complete':False});print(load(OUT/'bulk-clipping-diagnostic.json'))
