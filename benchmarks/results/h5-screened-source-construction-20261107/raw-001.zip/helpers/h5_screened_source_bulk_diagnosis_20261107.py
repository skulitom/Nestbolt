"""Read-only whole-boundary clipping cost and geometry correspondence diagnostic."""
import shapely
from h5_original_overlap_gradient_v2_20261107 import line_parts
E=BASE/'search/epoch-01';opened=load(E/'opened.json');call=load(E/'optimizer-opened.json');first_call=load(BASE/'search/epoch-00/optimizer-opened.json');result=load(BASE/'search/result.json')
paths=[Path(__file__),ROOT/'output/h5_screened_augmented_objective_20261107.py',ROOT/'output/h5_screened_boundary_gradient_20261107.py',ROOT/'output/h5_original_overlap_gradient_v2_20261107.py']+[BASE/n for n in ['selected-model.json','selected-state.json','audit/checks.json','response-audit/checks.json','search/result.json','search/epoch-00/optimizer-opened.json']]+[E/n for n in ['model.json','response.json','opened.json','optimizer-opened.json']]
write(OUT/'runtime-cost-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Reconcile the new finite search costs and compare per-edge strict-box clipping with whole-owner MultiLineString clipping. Test the fresh source initializer and both distinct final winners at original and clearance levels. Fixed separate/bulk/bulk/separate order including boundary construction, bounds/filtering and both filled/shared intersections. Independently compare the complete clipped geometry sets, component counts and clipped lengths after timing. No integrated gradients or complete-objective implementation is substituted; this is a diagnostic only, with discrepancies retained. No optimizer, source initializer or reopening.','geometry_diagnostic_tolerance_mm':1e-7,'validation_only':True,'optimizer_calls':0})
write(OUT/'runtime-costs.json',{'passed':True,'runtime_weight_selection_output_model_interval_seconds':call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'],'first_call_startup_after_preparation_seconds':first_call['algorithm_seconds_including_preparation']-result['complete_preparation_seconds'],'optimizer_allocations_seconds':[first_call['allocated_seconds'],call['allocated_seconds']],'optimizer_calls':0,'closed_search_resumed':False})
states=[('source_initializer',load(BASE/'selected-model.json'),load(BASE/'selected-state.json')['values'])]
seen=set()
for label,r in response['winners'].items():
    key=tuple(r['values'])
    if key not in seen:states.append((label,model,r['values']));seen.add(key)
assert len(states)==3
controls=[];timings=[];total_edges=retained=directed=0;whole_gradients_verified=False
for label,m,point in states:
    objective=Objective(m,load(B/'regions.json'),load(A/'objective-identity.json'))
    for level,entries in enumerate(objective.geometry(point)):
        polygons=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(polygons[objective.left],polygons[objective.right]))
        owners=[];others=[]
        for index in np.flatnonzero(areas>0):
            i,j=m['pairs'][index]
            for own,other in [(i,j),(j,i)]:owners.append(own);others.append(other)
        owners=np.asarray(owners,dtype=int);others=np.asarray(others,dtype=int);count=len(owners);directed+=count
        def separate():
            sizes=np.asarray([len(entries[i][0]) for i in owners]);groups=np.repeat(np.arange(count),sizes);lines=np.concatenate([entries[i][2] for i in owners])
            left=shapely.bounds(lines);right=shapely.bounds(polygons[others])[groups]
            disjoint=(left[:,0]>right[:,2])|(left[:,2]<right[:,0])|(left[:,1]>right[:,3])|(left[:,3]<right[:,1])
            keep=~disjoint|~(np.all(np.isfinite(left),axis=1)&np.all(np.isfinite(right),axis=1));groups=groups[keep];lines=lines[keep]
            clipped=shapely.intersection(lines,polygons[others][groups]);shared=shapely.intersection(lines,shapely.boundary(polygons[others])[groups])
            return clipped,shared,groups,int(np.count_nonzero(keep)),len(keep)
        def bulk():
            boundaries=np.asarray([shapely.multilinestrings(e[2]) for e in entries],dtype=object)
            clipped=shapely.intersection(boundaries[owners],polygons[others]);shared=shapely.intersection(boundaries[owners],shapely.boundary(polygons[others]))
            return clipped,shared
        observations=[]
        for sequence,kind in enumerate(['separate','bulk','bulk','separate']):
            start=time.perf_counter();got=(separate if kind=='separate' else bulk)();elapsed=time.perf_counter()-start
            observations.append(got);timings.append({'state':label,'level':level,'sequence':sequence,'kind':kind,'complete_clipping_seconds':elapsed,'directed_pairs':count})
        old=observations[0];new=observations[1];assert all(shapely.equals_exact(a,b,0.).all() for a,b in zip(old[:2],observations[3][:2])) and np.array_equal(old[2],observations[3][2]);assert all(shapely.equals_exact(a,b,0.).all() for a,b in zip(new,observations[2]))
        retained+=old[3];total_edges+=old[4]
        for group,(own,other) in enumerate(zip(owners,others)):
            for kind,k in [('filled',0),('shared',1)]:
                parts=old[k][old[2]==group];combined=shapely.union_all(parts);whole=new[k][group]
                exact=bool(shapely.equals(combined,whole));difference=shapely.symmetric_difference(combined,whole);length=float(difference.length)
                distance=0. if combined.is_empty and whole.is_empty else float(shapely.hausdorff_distance(combined,whole))
                separate_lines=[line for part in parts for line in line_parts(part)];bulk_lines=line_parts(whole)
                controls.append({'state':label,'level':level,'kind':kind,'owner':int(own),'other':int(other),'topologically_exact':exact,'symmetric_difference_length_mm':length,'hausdorff_distance_mm':distance if np.isfinite(distance) else None,'separate_line_components':len(separate_lines),'bulk_line_components':len(bulk_lines),'component_count_equal':len(separate_lines)==len(bulk_lines),'separate_line_length_mm':sum(line.length for line in separate_lines),'bulk_line_length_mm':sum(line.length for line in bulk_lines)})
write(OUT/'bulk-clipping-controls.json',controls);write(OUT/'bulk-clipping-timings.json',timings)
totals={kind:[sum(r['complete_clipping_seconds'] for r in timings if r['kind']==kind and r['sequence']==sequence) for sequence in ([0,3] if kind=='separate' else [1,2])] for kind in ['separate','bulk']}
write(OUT/'bulk-clipping-diagnostic.json',{'diagnostic_complete':True,'states':len(states),'geometry_contexts':2*len(states),'directed_pairs':directed,'separate_nominal_edges':total_edges,'separate_retained_edges':retained,'clipped_geometry_sets':len(controls),'topologically_exact_sets':sum(r['topologically_exact'] for r in controls),'component_count_mismatches':sum(not r['component_count_equal'] for r in controls),'maximum_symmetric_difference_length_mm':max(r['symmetric_difference_length_mm'] for r in controls),'maximum_finite_hausdorff_distance_mm':max(r['hausdorff_distance_mm'] or 0. for r in controls),'nonfinite_hausdorff_cases':sum(r['hausdorff_distance_mm'] is None for r in controls),'aggregate_clipping_seconds':totals,'full_integrated_gradients_verified':False,'full_objective_speedup_claimed':False,'new_boundary_kernel_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'closed_search_resumed':False,'H5_complete':False});print(load(OUT/'bulk-clipping-diagnostic.json'))
