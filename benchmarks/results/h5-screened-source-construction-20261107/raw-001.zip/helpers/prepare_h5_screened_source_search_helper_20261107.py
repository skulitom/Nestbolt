"""Freeze a new finite search after independent original-source preparation."""
from pathlib import Path
import ast,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output';load=lambda p:json.loads(p.read_bytes())
base=OUT/'h5-screened-source-preflight-20261107';checked=load(base/'audit/checks.json');assert checked['passed'] and checked['closed_keys']==23
text=(OUT/'run_h5_shared_source_search_20261107.py').read_text(encoding='utf-8')
changes=[
    ('h5-shared-source-preflight-20261107','h5-screened-source-preflight-20261107'),
    ('h5_bracket_augmented_objective_20261107','h5_screened_augmented_objective_20261107'),
    ('audit_h5_shared_source_response_20261107','audit_h5_screened_source_response_20261107'),
    ('run_h5_shared_source_response_stage_20261107','run_h5_screened_source_response_stage_20261107'),
    (";A=ROOT/'output/h5-bracket-augmented-model-20261107'",";U=ROOT/'benchmarks/results/h5-screened-objective-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107'"),
    ("inputs=[Path(__file__),JOB,Q/'cost-profile.json',Z/'outcome-diagnostic/runtime-costs.json']","inputs=[Path(__file__),JOB,Q/'cost-profile.json',Z/'outcome-diagnostic/runtime-costs.json']+[U/n for n in ['archive-checks.json','objective-audit.json','complete-objective-controls.json','trajectory-checks.json','trajectory-timings.json','timings.json','next-step.json','closed-problems.json']]"),
    ("'h5_screened_augmented_objective_20261107.py',","'h5_screened_augmented_objective_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_screened_source_epoch_readback_20261107.py',"),
    ('all21closed','all23closed'),
    ('Keep528weighted area terms','Use the completely verified screened augmented objective, omitting only strictly disjoint edge/polygon boxes while retaining touching and nonfinite bounds. Mathematical identity and closure keys remain unchanged. Keep528weighted area terms'),
    ("assert checked['passed'] and checked['strictly_improves_current'];OUT.mkdir()","assert checked['passed'] and checked['strictly_improves_current'] and load(U/'objective-audit.json')['passed'] and load(U/'trajectory-checks.json')['passed'] and load(U/'closed-problems.json')==load(BASE/'closed-problems.json');OUT.mkdir()"),
    ("'planned_algorithm_seconds':planned,","'screened_objective_observed_saved_trajectory_seconds':load(U/'trajectory-checks.json')['summary'],'screened_objective_identity_unchanged':True,'evaluation_speedup_used_to_extend_limits':False,'planned_algorithm_seconds':planned,"),
]
for before,after in changes:
    assert before in text,before
    text=text.replace(before,after)
ast.parse(text)
with (OUT/'run_h5_screened_source_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
cost=load(base/'model-and-source-costs.json');timings=load(ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107/timings.json');selector=max(r['selector_and_grouping_seconds'] for r in timings if r['context'] in ['runtime','latest_runtime'] and r['tier']=='primary' and r['kind']=='shared')
profile=load(ROOT/'benchmarks/results/h5-tiered-selector-preflight-20261107/cost-profile.json');serial=next(r for r in profile['profiles'] if r['context']=='runtime-uncached')['serialization']['wall_seconds'];startup=load(OUT/'h5-tiered-source-preflight-20261107/outcome-diagnostic/runtime-costs.json')['first_call_startup_after_preparation_seconds']
planned=checked['complete_preparation_seconds']+8+selector+serial+2*(cost['model_construction_verification_and_serialization_seconds']+3*cost['source_output_and_validation_seconds'])+startup
assert planned<60
print({'complete_preparation_seconds':checked['complete_preparation_seconds'],'planned_algorithm_seconds':planned,'algorithm_limit_seconds':60,'shared_limit_seconds':90,'search_opened':False,'both_full_slices_guaranteed':False})
