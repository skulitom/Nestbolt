from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
text=(OUT/'diagnose_h5_tiered_source_outcome_20261107.py').read_text(encoding='utf-8');text=text[:text.index('# Read-only costs and an exact empty-intersection screen')]
text=text.replace('h5-tiered-source-preflight-20261107','h5-screened-source-preflight-20261107').replace('from h5_bracket_augmented_objective_20261107 import Objective','from h5_screened_augmented_objective_20261107 import Objective')
text=text.replace("X=ROOT/'output/h5-indexed-source-preflight-20261107';","X=ROOT/'output/h5-indexed-source-preflight-20261107';Z=ROOT/'output/h5-shared-source-preflight-20261107';Y=ROOT/'output/h5-tiered-source-preflight-20261107';")
text=text.replace("X/'response-audit/checks.json']","X/'response-audit/checks.json',Z/'response-audit/checks.json',Y/'response-audit/checks.json']")
text=text.replace("('prior_indexed_source',X)]","('prior_indexed_source',X),('prior_tiered_source',Y),('prior_shared_source',Z)]")
text+='\n'+(OUT/'h5_screened_source_bulk_diagnosis_20261107.py').read_text(encoding='utf-8');ast.parse(text)
with (OUT/'diagnose_h5_screened_source_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(OUT/'run_h5_shared_source_diagnosis_stage_20261107.py').read_text(encoding='utf-8').replace('h5_shared_source','h5_screened_source').replace('h5-shared-source','h5-screened-source');ast.parse(text)
with (OUT/'run_h5_screened_source_diagnosis_stage_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared new read-only outcome and bulk clipping diagnosis; no stage opened.')
