"""Independent membership, per-key minima and full-score ranking controls."""
from collections import Counter

def reconstruct_choice(records,independent_rows):
    assert len(records)==len(independent_rows)==5911
    by_sequence={r["sequence"]:r for r in records};assert len(by_sequence)==5911
    actual={r['sequence']:r['augmented_objective_mm2'] for r in independent_rows}
    assert set(actual)==set(by_sequence)
    def order(row,score):return (score,tuple(row['modes']),len(row['changes']),tuple(map(tuple,row['changes'])),tuple(map(tuple,row['centers'])),row['sequence'])
    grouped={};controls=[];near=[]
    for row in records:
        assert abs(row['augmented_objective_mm2']-actual[row['sequence']])<1e-6
        grouped.setdefault(row['key'],[]).append(row['sequence'])
    assert len(grouped)==2854 and Counter(map(len,grouped.values()))=={562:1,33:78,1:2775}
    minima=[]
    for key,sequences in sorted(grouped.items()):
        rows=[by_sequence[s] for s in sequences];assert len({tuple(r['physical_key']) for r in rows})==1 and len({r['excluded'] for r in rows})==1
        winner=sorted(rows,key=lambda r:order(r,r['augmented_objective_mm2']))[0]
        oracle=sorted(rows,key=lambda r:order(r,actual[r['sequence']]))[0];gap=actual[winner['sequence']]-actual[oracle['sequence']];assert gap<=1e-6;minima.append(winner)
        record={'key':key,'raw_members':len(rows),'representative_sequence':winner['sequence'],'independent_sequence':oracle['sequence'],'independent_score_gap_mm2':gap,'excluded':winner['excluded']};controls.append(record)
        if winner['sequence']!=oracle['sequence']:near.append({'kind':'key_minimum',**record})
    def pick(rows,label):
        if not rows:return None
        winner=sorted(rows,key=lambda r:order(r,r['augmented_objective_mm2']))[0];oracle=sorted(rows,key=lambda r:order(r,actual[r['sequence']]))[0];gap=actual[winner['sequence']]-actual[oracle['sequence']];assert gap<=1e-6
        if winner['sequence']!=oracle['sequence']:near.append({'kind':label,'representative_sequence':winner['sequence'],'independent_sequence':oracle['sequence'],'independent_score_gap_mm2':gap})
        return winner
    single=pick([r for r in records if not r['excluded'] and len(r['changes'])==1],'raw_single')
    joint=pick([r for r in records if not r['excluded'] and len(r['changes'])==2],'raw_joint')
    best=pick([r for r in minima if not r['excluded']],'eligible_key')
    baseline=records[0]['augmented_objective_mm2'];improves=best is not None and baseline-best['augmented_objective_mm2']>1e-6
    if improves:assert actual[0]-actual[best['sequence']]>1e-6
    selection={'best_single':single,'best_joint':joint,'best_admissible':best,'current_score':baseline,'strictly_improves_current':improves,'accepted_choice':best if improves else None,'raw_proposals':len(records),'distinct_keys':len(grouped),'excluded_keys':sum(r['excluded'] for r in minima),'excluded_raw_proposals':sum(r['excluded'] for r in records)}
    return selection,grouped,minima,controls,near
