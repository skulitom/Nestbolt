"""Select exclusively from a completed, fully grouped declared neighborhood tier."""
import time
from h5_tiered_neighbors_20261107 import primary,SelectionDeadline
from h5_tiered_key_choice_20261107 import choose,KeySelectionDeadline

def select(library,modes,values,weights,identity,regions,closed_keys,primary_deadline,extension_deadline=None,clock=time.perf_counter,cached_trials=None):
    try:pool=primary(library,modes,values,weights,identity,regions,closed_keys,deadline=primary_deadline,clock=clock,cached_trials=cached_trials)
    except SelectionDeadline as exc:
        return {'status':'NO_COMPLETE_PRIMARY','completed_tier':None,'selected_proposal':None,'primary':None,'extended':None,'partial':exc.evidence,'optimizer_calls':0}
    common={'aliases':pool.aliases,'trials':pool.trials,'selections':pool.selections}
    try:choice,groups,minima=choose(pool.primary,'primary',deadline=primary_deadline,clock=clock)
    except KeySelectionDeadline as exc:
        return {**common,'status':'NO_COMPLETE_PRIMARY','completed_tier':None,'selected_proposal':None,'primary':{'records':pool.primary,'selection':None},'extended':None,'partial':exc.evidence,'optimizer_calls':0}
    first={'records':pool.primary,'selection':choice,'groups':groups,'minima':minima}
    result={**common,'status':'PRIMARY_COMPLETE','completed_tier':'primary','selected_proposal':choice['accepted_choice'],'primary':first,'extended':None,'partial':None,'optimizer_calls':0}
    if extension_deadline is None:return result
    full=None
    try:
        full=pool.extend(extension_deadline,clock=clock)
        extended_choice,extended_groups,extended_minima=choose(full,'extended',deadline=extension_deadline,clock=clock)
    except (SelectionDeadline,KeySelectionDeadline) as exc:
        # The exception's incomplete extension never participates in this choice.
        return {**result,'status':'PRIMARY_ONLY_EXTENSION_DEADLINE','partial':exc.evidence,'unselected_complete_extension_records':full}
    assert extended_choice['current_score']==choice['current_score']
    if choice['best_admissible'] is not None:assert extended_choice['best_admissible']['augmented_objective_mm2']<=choice['best_admissible']['augmented_objective_mm2']
    return {**result,'status':'EXTENDED_COMPLETE','completed_tier':'extended','selected_proposal':extended_choice['accepted_choice'],'extended':{'records':full,'selection':extended_choice,'groups':extended_groups,'minima':extended_minima}}
