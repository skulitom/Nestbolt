"""A separately frozen staged construction from the deterministic 5/4/3 control."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def rename(s):
    s=s.replace('h5-expanded-cog-row-integer-20261104','h5-twelve-cog-543-row-integer-20261107').replace('h5-first55-after-source-valid11-20261029','h5-first57-direct-short9-20261104').replace('h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json','h5-first57-direct-short9-20261104/short9-source.json')
    for stage in ['packet','regions','integer']:
        s=s.replace('h5-staged-row-'+stage+'-20261104','h5-twelve-cog-543-staged-'+stage+'-20261107').replace('h5-staged-row-'+stage+'-process-20261104','h5-twelve-cog-543-staged-'+stage+'-process-20261107')
    return s.replace('packet-source13','packet-source12').replace('source53','source50').replace('source_valid53','source_valid50').replace('moving13_orthogonal_identities','moving16_orthogonal_identities').replace('required_cog13_identities','required_cog12_identities').replace('==916','==856').replace('==63','==58').replace('==6732','==6122').replace('len(cogs)==13','len(cogs)==12').replace('len(instances)==13','len(instances)==16').replace("'source_mode_options':80","'source_mode_options':96").replace("sum(r['mode_count'] for r in instances)==80", "sum(r['mode_count'] for r in instances)==96")
def read(name):return rename((R/'output'/name).read_text(encoding='utf-8'))
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=read('prepare_h5_staged_row_packet_20261104.py')
s=s.replace('all13 missing orthogonal','all16 missing orthogonal').replace('fixed13-cog','fixed12-cog').replace("'fixed_cogs':13","'fixed_cogs':12").replace("'same_sheet_pairs':916,'cutouts':63,'hole_vertices':6732", "'same_sheet_pairs':856,'cutouts':58,'hole_vertices':6122")
s=s.replace('deterministic expanded-row control','deterministic5/4/3-row control').replace('The closed expanded joint model and its solver result','The closed5/4/3 joint model and its solver result')
write('prepare_h5_twelve_cog_543_staged_packet_20261107.py',s)
s=read('audit_h5_staged_row_packet_20261104.py')
s=s.replace('len(identities)==53 and len(missing)==13','len(identities)==50 and len(missing)==16').replace('reconstructed53-source','reconstructed50-source').replace('fixed29 and short11, all13 cog','fixed29 and short9, all12 cog').replace("'fixed_packet_cogs_verified':13", "'fixed_packet_cogs_verified':12").replace("'source_control_pairs_already_independently_verified':916", "'source_control_pairs_already_independently_verified':856")
a=s.index("process=load(PROCESS/");b=s.index('inputs=[Path(__file__)',a)
s=s[:a]+"""process=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json')
assert process['passed'] and process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0
assert process['complete_seconds']>=load(BASE/'checks.json')['seconds_including_source_controls'] and process['complete_seconds']<=30
for name,h in opened['inputs'].items():assert digest(ROOT/name)==h
assert not opened['repeat_permitted']
"""+s[b:]
s=s.replace("list(PROCESS.glob('*'))", "[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]").replace("process['complete_process_seconds']", "process['complete_seconds']")
write('audit_h5_twelve_cog_543_staged_packet_20261107.py',s)
s=read('prepare_h5_staged_row_regions_20261104.py').replace('all13 original cog','all12 original cog').replace('all13 source obstacles','all12 source obstacles').replace("'original_cogs':13", "'original_cogs':12")
write('prepare_h5_twelve_cog_543_staged_regions_20261107.py',s)
s=read('audit_h5_staged_row_regions_20261104.py').replace('the13 fixed','the12 fixed').replace("'original_cog_sites_verified':13", "'original_cog_sites_verified':12").replace("'all13_reference_cogs_checked'", "'all12_reference_cogs_checked'")
write('audit_h5_twelve_cog_543_staged_regions_20261107.py',s)
s=read('prepare_h5_staged_row_integer_20261104.py')
s=s.replace("for name in ['components.json','component-pairs.json']:shutil.copyfile(PRIOR/'rigid-rectangle-preflight'/name,OUT/name)", """components=[]
for owner,item in enumerate(load(REG/'instances.json')):
    for piece in range(2 if item['identity'][0]=='bracket' else 1):components.append({'component':len(components),'owner':owner,'identity':item['identity'],'piece':piece})
component_pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for i,a in enumerate(components) for b in components[i+1:] if a['owner']!=b['owner']]
assert len(components)==24 and len(component_pairs)==268
write(OUT/'components.json',components);write(OUT/'component-pairs.json',component_pairs)""")
write('prepare_h5_twelve_cog_543_staged_integer_20261107.py',s)
s=read('audit_h5_staged_row_integer_20261104.py')
s=s.replace("for n in ['components.json','component-pairs.json']:assert digest(BASE/n)==digest(PRIOR/'rigid-rectangle-preflight'/n)", """instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json')
assert [r['identity'] for r in instances]==inventory['moving16_orthogonal_identities'] and len(instances)==16 and sum(r['mode_count'] for r in instances)==96
components=load(BASE/'components.json');expected=[]
for owner,r in enumerate(instances):
    counts={len(m['rectangles']) for m in new_rect[r['identity'][0]]};assert len(counts)==1
    for piece in range(next(iter(counts))):expected.append({'component':len(expected),'owner':owner,'identity':r['identity'],'piece':piece})
assert components==expected and len(components)==24
expected_pairs=[{'components':[i,j],'owners':[a['owner'],b['owner']]} for i,a in enumerate(components) for j,b in enumerate(components) if i<j and a['owner']!=b['owner']]
assert len(expected_pairs)==268 and expected_pairs==load(BASE/'component-pairs.json')""")
s=s.replace("'source_family_modes_verified':mode_count", "'source_family_modes_verified':mode_count,'orthogonal_instances_verified':16,'rigid_components_verified':24,'different_owner_component_pairs_verified':268")
write('audit_h5_twelve_cog_543_staged_integer_20261107.py',s)
for stage,cap,auditcap in [('packet',30,60),('regions',40,90),('integer',30,60)]:
    s=(R/'output/run_h5_twelve_cog_543_row_domains_20261107.py').read_text(encoding='utf-8').replace('h5-twelve-cog-543-row-domains-process','h5-twelve-cog-543-staged-'+stage+'-process').replace('prepare_h5_twelve_cog_543_row_domains','prepare_h5_twelve_cog_543_staged_'+stage).replace('audit_h5_twelve_cog_543_row_domains','audit_h5_twelve_cog_543_staged_'+stage)
    s=s.replace("staged_"+stage+"_20261107.py',30", "staged_"+stage+"_20261107.py',"+str(cap)).replace("staged_"+stage+"_20261107.py',60", "staged_"+stage+"_20261107.py',"+str(auditcap))
    write('run_h5_twelve_cog_543_staged_'+stage+'_20261107.py',s)
print({'prepared':True,'packing_solver_calls':0,'joint_solver_output_consumed':False})
