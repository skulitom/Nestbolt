from pathlib import Path
R=Path(__file__).resolve().parents[1]
old=(R/'output/seal_h5_twelve_cog_checkpoint_20261107.py').read_text(encoding='utf-8')
head="""from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-twelve-cog-543-constructions-20261107';OUT=ROOT/'benchmarks/results'/NAME
D=ROOT/'output/h5-twelve-cog-543-row-domains-20261107';G=ROOT/'output/h5-twelve-cog-543-row-regions-20261107';I=ROOT/'output/h5-twelve-cog-543-row-integer-20261107'
P=ROOT/'output/h5-twelve-cog-543-staged-packet-20261107';S=ROOT/'output/h5-twelve-cog-543-staged-regions-20261107';T=ROOT/'output/h5-twelve-cog-543-staged-integer-20261107';F=ROOT/'output/h5-twelve-cog-543-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['independent_rows_result']=='UNKNOWN' and front['staged_result']=='grid-INFEASIBLE' and not front['source_valid66']
assert front['fixed_arrangements_remaining']==4 and front['new_fixed_arrangement_exclusions']==0
"""
inventory=old[old.index('inventory_ast='):old.index('walker=')]+"PARENTS.append(ROOT/'benchmarks/results/h5-twelve-cog-row-construction-20261107')\n"+old[old.index('walker='):old.index('folders=')]
body="""folders=[D,G,I,P,S,T,F]+[ROOT/'output'/('h5-twelve-cog-543-'+s+'-process-20261107') for s in ['row-domains','row-regions','row-integer','row-control','row-model','staged-packet','staged-regions','staged-integer','staged-model']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5*twelve*cog*543*20261107.py'):add('helpers/'+p.name,p)
failure=ROOT/'output/h5-twelve-cog-543-staged-helper-failure-20261107.json';add('helper-failure.json',failure)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_twelve_cog_checkpoint_20261107.py','seal_h5_exact_circle_forest_20261107.py','seal_h5_polygon_clearance_proofs_20261107.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
# Preserve the exact malformed source. It failed at parse time and executed no
# imports, so it has no executed local-import dependencies for AST traversal.
failed=ROOT/load(failure)['failed_helper'];assert digest(failed)==load(failure)['sha256']
queue=[p for p in queue if p!=failed]
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'case-results.json','case-results.json'),(F/'next-step.json','next-step.json'),(D/'audit/checks.json','row-domain-audit.json'),(D/'rows.json','row-domains.json'),(G/'source-region-audit/checks.json','row-source-audit.json'),(I/'geometry-audit/checks.json','row-integer-audit.json'),(I/'row-control/audit/checks.json','row-control-audit.json'),(I/'model-audit/checks.json','joint-model-audit.json'),(I/'model/final-preparation-charges.json','joint-preparation-charges.json'),(I/'response-audit/checks.json','joint-response-audit.json'),(I/'search/process.json','joint-process.json'),(P/'audit/checks.json','staged-packet-audit.json'),(S/'source-region-audit/checks.json','staged-source-audit.json'),(T/'geometry-audit/checks.json','staged-integer-audit.json'),(T/'model-audit/checks.json','staged-model-audit.json'),(T/'model/final-preparation-charges.json','staged-preparation-charges.json'),(T/'response-audit/checks.json','staged-response-audit.json'),(T/'search/process.json','staged-process.json'),(failure,'helper-failure.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
"""
report='''# Twelve-cog 5/4/3 constructions — 2026-11-07

Two distinct constructions close without a placement. The new independent
**5/4/3-cog row model returns UNKNOWN**. A separate staged method fixes its
deterministic source-valid row control before placing companions and returns
**grid-INFEASIBLE**. Neither result excludes a continuous layout or whole
allocation. Four fixed arrangements and all 440 whole allocations remain.
H2/H5 stay open at **60% completed milestone weight**.

## Fresh row geometry and complete joint model

The source allocation uses reference sites 0–4, 6–9 and 12–14, with the same
validated nine-part small sheet. Five, four and three cogs receive independent
translations; all twelve remaining cog identities and sixteen orthogonal
companions are retained. The earlier 4/4/4 and thirteen-cog calls remain closed.

[Exact domain readback]({NAME}/row-domain-audit.json) verifies all three full
stock/core-safe rectangles, nearest excluded grid points, 36 source-mode relative
domains and three row-difference domains. Twelve individual-row corner controls
plus the simultaneous 50-part reference check 7,628 same-sheet pairs. The
Cartesian product of these individual boxes is not claimed collision-free.

| Row | X shift, mm | Y shift, mm |
|---|---|---|
| 0, five cogs | -91.56 to 79.99 | 0.01 to 605.65 |
| 1, four cogs | -430.42 to -0.01 | -246.19 to 359.46 |
| 2, three cogs | -609.28 to 79.99 | -492.38 to 113.27 |

The largest horizontal row difference reaches -689.27 mm. The old 600 mm
normal-error envelope would be insufficient. [Fresh integer checks]({NAME}/row-integer-audit.json)
verify a 700 × 1100 mm row-difference envelope, all 9,847 halfplane implications,
24 rigid rectangles and 268 different-owner pairs. The mover-relative envelope
remains 2000 × 1500 mm and is independently checked against every new row range.

[Original-source region checks]({NAME}/row-source-audit.json) certify 2,099
mover/row regions and 577 row-pair regions, using 48,332 and 98,753 exact rational
support proofs. Eleven degenerate regions are disabled. All source aliases and
cross-row original pairs are covered, with minimum certified gap
0.225999999 mm. No global free-space coverage claim is made.

[The deterministic positive control]({NAME}/row-control-audit.json) considers
1,528 centroid grid neighbors and accepts its first adjacent-row combination.
The shifts are [-9156,1], [-8832,1269] and [-9303,2475] in 0.01 mm units.
All 50 placed originals pass 856 pair, 200 stock-edge, 58 hole and 6,122
hole-vertex checks; the sixteen orthogonal companions remain unplaced.

[Every joint-model field]({NAME}/joint-model-audit.json) is verified:
18,671 variables, 66,604 constraints, all 96 modes, six independent row shifts,
16,792 mover/row selectors, 577 row-pair selectors, 640 rigid coordinate links,
268 component pairs and fourteen valid identical-copy ordering constraints.
The 583-value hint specifies only the source-checked row control.

[Complete charged preparation]({NAME}/joint-preparation-charges.json) is
**8.301528 seconds**, including the complete model build. [Response readback]({NAME}/joint-response-audit.json)
verifies one UNKNOWN call with 63,657 branches and 428 conflicts, no incumbent
or assignment. Allocated/returned solve time is 46.716391 / 46.863195 seconds;
the **0.146804-second solve-slice overrun is preserved**. Preparation-inclusive
algorithm/shared totals are **56.165204 / 56.309005 seconds**, within 60/90 s.
[The process record]({NAME}/joint-process.json) confirms every descendant closed.

## Separately defined staged construction

The staged method fixes the first deterministic row control before examining
companion placements. [Point-domain readback]({NAME}/staged-packet-audit.json)
binds the twelve fixed cogs, fixed29 and short9 to the independent 50-part source
control. The two compatibility coordinates are constants X=Y=0. The staged
input graph contains **no joint model, joint search or joint response**.

Fresh combined obstacles replace the three independent row disjunctions.
[Source certification]({NAME}/staged-source-audit.json) verifies 208 rounded
regions with 7,712 exact support proofs against all twelve cog poses and every
source-mode alias. [Integer readback]({NAME}/staged-integer-audit.json) verifies
737 conservative halfplane implications, all original world bounds and all
24 rigid components. No prior fixed-cog capacity result is consumed.

[The complete staged model]({NAME}/staged-model-audit.json) has 2,962 variables
and 8,386 constraints, all sixteen original movers and 96 modes, 1,664 unary
region selectors, 5,896 unary planes, 640 rigid links and 268 different-owner
pairs. It has no objective or hint. The only free coordinates belong to the
sixteen orthogonal parts; the packet remains fixed.

[Its full preparation ledger]({NAME}/staged-preparation-charges.json) charges
**7.286199 seconds**. This includes all four stage-one domain/region/integer/control
processes, source geometry/sites/rectangles, direct short9, the new point-packet
preflight, combined geometry, integer conversion and complete model build.
Stage one receives no free cached placement preparation. Independent verification
processes are retained separately.

[Response readback]({NAME}/staged-response-audit.json) verifies one grid-INFEASIBLE
call: 153,249 branches, 38,769 conflicts, no incumbent or assignment.
It returns in 7.508641 seconds against 48.081655 seconds allocated. Complete
algorithm/shared totals are **15.441594 / 15.510424 seconds**, without overruns.
[Every process descendant closes]({NAME}/staged-process.json). No independent
continuous UNSAT certificate is claimed. Both calls remain closed and will not
be repeated, reseeded or extended.

## Preserved corrections and remaining scope

A [helper-generation syntax failure]({NAME}/helper-failure.json) occurred before
any model builder was created or process started. The malformed source remains
unchanged; a versioned corrected generator creates the audited staged model.
The prior 4/4/4 integer producer also used the same local-name reuse described
in its preserved audit-report correction: it reported component count 268 in
the row-region field. Its actual source/model audits cover all 583 regions and
model bytes remain unchanged. This new producer and audit both check the exact
577 row-region count separately from 268 component pairs.

[The next prospective construction]({NAME}/next-step.json) uses 5/5/2 rows from
reference sites 0–9, 13 and 14, corresponding to still-unresolved empty sites
[10,11,12]. Fresh source domains, interaction certificates, coordinate error
envelopes and complete preparation charges are required before any new call.
No such call is prepared here. Full66 source/native/material validation,
production integration and the full H5 matrix remain open.

Main remains 9e878243; the preceding twelve-cog checkpoint and this checkpoint
await the normal push condition. At review,
[CI42328915911](https://github.com/skulitom/Nestbolt/actions/runs/42328915911)
has five successful jobs and a live Windows check. No run is cancelled. Production,
READMEs and release assets are unchanged; no new release qualifies.

[The manifest]({NAME}/raw-manifest.json) contains {archive['archive_members']}
new canonical members in {archive['archive_parts']} ZIP parts, totaling
{archive['archive_bytes']:,} bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) preserve exact inputs and
failed bytes. Independent archive verification is required before commit.
'''
tail='report=f'+repr(report)+"\nwith OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)\n"
note="\n\n**2026-11-07 H5 5/4/3 twelve-cog constructions:** [fresh source and full-model audits]({link}) verify 2,099 mover regions, 577 row-pair regions, 147,085 source support proofs and 9,847 integer implications. The widened 700 mm row-difference error bound covers the new third-row freedom. One complete joint model closes UNKNOWN with no placement; charged preparation is 8.301528 s and algorithm/shared totals are 56.165204/56.309005 s, preserving its 0.146804 s solve-slice overrun. A separately frozen staged control has 208 fresh combined regions and a fully audited 2,962-variable companion model; its sole call closes grid-INFEASIBLE in 15.441594/15.510424 s including all 7.286199 s of preparation. Neither result excludes a continuous layout or allocation. Both calls stay closed. Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. The next unprepared hypothesis uses 5/5/2 rows with the same validated nine-part small sheet. A pre-execution helper syntax failure and all original evidence remain preserved. No new release is made.\n"
tail+='note='+repr(note)+"\nfor name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))\n"
tail+="""p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\\nThe earlier fixed 13-cog construction',a)
s=s[:a]+f'''Latest H5 evidence: [twelve-cog 5/4/3 constructions](../benchmarks/results/{NAME}.md).
The new independent 5/4/3-cog model passes all source and model checks, then
closes UNKNOWN without a placement. A separate staged method fixes its validated
row control and closes grid-INFEASIBLE. Both include all sixteen orthogonal
companions and 96 modes; all preparation is charged, and overall 60/90-second
limits pass. The joint solve-slice overrun remains recorded. Both calls are
closed; neither excludes a continuous layout or whole allocation. Next assess
fresh 5/5/2 row domains with the same nine-part small sheet.
The fixed29/current-cog frontier remains four arrangements: 451 of 455 excluded
at original 0.2 mm clearance, 427 even at zero. All 440 whole allocations and
the full66 source/material/native checks remain open. H2/H5 remain open at 60%.
'''+s[b:]
with p.open('w',encoding='utf-8',newline='\\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':True,**archive,'source_valid66':False,'remaining':4})
"""
with (R/'output/seal_h5_twelve_cog_543_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(head+inventory+body+tail)
s=(R/'output/verify_h5_twelve_cog_checkpoint_20261107.py').read_text(encoding='utf-8').replace('h5-twelve-cog-row-construction-20261107','h5-twelve-cog-543-constructions-20261107')
with (R/'output/verify_h5_twelve_cog_543_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':True})
