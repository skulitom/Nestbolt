from pathlib import Path
from hashlib import sha256
import json,time
R=Path(__file__).resolve().parents[1];OUT=R/'output/h5-twelve-cog-543-checkpoint-20261107';OUT.mkdir();start=time.perf_counter()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
D=R/'output/h5-twelve-cog-543-row-domains-20261107';G=R/'output/h5-twelve-cog-543-row-regions-20261107';I=R/'output/h5-twelve-cog-543-row-integer-20261107'
P=R/'output/h5-twelve-cog-543-staged-packet-20261107';S=R/'output/h5-twelve-cog-543-staged-regions-20261107';T=R/'output/h5-twelve-cog-543-staged-integer-20261107'
d=load(D/'audit/checks.json');g=load(G/'source-region-audit/checks.json');i=load(I/'geometry-audit/checks.json');s=load(S/'source-region-audit/checks.json');t=load(T/'geometry-audit/checks.json')
assert all(c['passed'] for c in [d,g,i,s,t,load(P/'audit/checks.json')])
assert d['row_sizes']==g['row_source_counts_verified']==[5,4,3]
assert i['mover_row_regions_verified']==g['mover_row_regions_verified']==load(I/'checks.json')['mover_row_regions']==2099
assert i['row_pair_regions_verified']==g['row_pair_regions_verified']==load(I/'checks.json')['row_pair_regions']==577
assert load(I/'plan.json')['row_pair_error_envelope_mm']==[700,1100]
assert i['exact_integer_plane_implications']==9847 and i['different_owner_component_pairs_verified']==268
assert s['original_cog_sites_verified']==12 and s['rounded_regions_reviewed']==208 and s['disabled_degenerate_regions']==0
assert load(P/'translation-domain.json')['shift_bounds_grid']==[[0,0],[0,0]]
rows=[];bindings={}
for base,expected in [(I,'UNKNOWN'),(T,'INFEASIBLE')]:
    ma=load(base/'model-audit/checks.json');a=load(base/'response-audit/checks.json');process=load(base/'search/process.json')
    assert ma['passed'] and a['passed'] and a['solver_status']==expected and a['closed_solver_calls']==1 and a['windows_job_descendants_closed']
    assert a['incumbents_verified']==a['assignments']==a['source_checker_calls']==a['native_calls']==0 and not a['source_valid66'] and not a['any_allocation_excluded']
    assert a['algorithm_overrun_seconds']==a['shared_overrun_seconds']==0 and process['job']['active_processes']==0
    assert ma['source_mode_selectors_verified']==96 and ma['rigid_components_verified']==24 and ma['different_owner_rectangle_pairs_verified']==268
    assert ma['model_sha256']==digest(base/'model/model.pb')==digest(base/'search/model.pb')
    current=load(base/'response-audit/source-bindings.json');bindings.update(current)
    if base==T:
        prefix=I.relative_to(R).as_posix()+'/'
        assert not any(name.startswith(prefix+suffix) for name in current for suffix in ['model/','model-audit/','search/','response-audit/'])
    rows.append({'construction':'independent_rows' if base==I else 'fixed_control_then_companions','status':expected,'model_sha256':ma['model_sha256'],'variables':ma['variables_verified'],'constraints':ma['constraints_verified'],
        'complete_preparation_seconds':a['preparation_seconds_charged'],'allocated_solve_seconds':a['allocated_solve_seconds'],'returned_solve_seconds':a['returned_solve_seconds'],'solve_slice_overrun_seconds':a['solve_slice_overrun_seconds'],
        'algorithm_seconds':a['algorithm_seconds_including_preparation'],'shared_seconds':a['shared_seconds_including_preparation'],'branches':a['branches'],'conflicts':a['conflicts'],'assignments':0,'source_valid66':False,'continuous_or_allocation_exclusion':False,'closed':True})
processes=[]
for stem in ['row-domains','row-regions','row-integer','row-control','row-model','staged-packet','staged-regions','staged-integer','staged-model']:
    folder=R/'output'/('h5-twelve-cog-543-'+stem+'-process-20261107');p=load(folder/'process.json')
    assert p['passed'] and p['closed'] and all(r['passed'] and r['job']['closed'] and r['job']['active_processes']==0 for r in p['stages']);processes.append(folder)
failure=load(R/'output/h5-twelve-cog-543-staged-helper-failure-20261107.json');assert digest(R/failure['failed_helper'])==failure['sha256'] and not failure['model_build_process_started'] and failure['solver_calls']==0
front=load(R/'output/h5-capacity-sat-batch-20261107/audit/checks.json');assert front['remaining_fixed29_choices']==4 and front['total_excluded_at_required_clearance']==451
for folder in [D,G,I,P,S,T,*processes]:
    for p in folder.rglob('*'):
        if p.is_file():bindings[p.relative_to(R).as_posix()]=digest(p)
for p in [Path(__file__),R/'output/h5-twelve-cog-543-staged-helper-failure-20261107.json',R/'output/h5-capacity-sat-batch-20261107/audit/checks.json',R/'output/h5-twelve-cog-row-integer-20261107/checks.json',R/'output/h5-twelve-cog-row-integer-20261107/geometry-audit-v2/checks.json']:
    bindings[p.relative_to(R).as_posix()]=digest(p)
for p,h in bindings.items():assert digest(R/p)==h
write('plan.json',{'inputs':bindings,'method':'Read every closed source/model/process record, all actual region counts and both responses. Verify all complete preparation charges through the model audits. Prove the staged input graph contains no joint model or search result. Preserve the pre-execution helper syntax failure and previous count-report error without changing their original bytes. No new solver or placement preparation is performed.'})
write('source-bindings.json',bindings);write('case-results.json',rows)
write('checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_row_sizes':[5,4,3],'individual_row_control_pairs':d['pairs'],'row_mover_regions':2099,'row_pair_regions':577,'row_source_supports':g['exact_mover_row_support_proofs']+g['exact_row_pair_support_proofs'],'row_integer_planes':9847,'staged_regions':208,'staged_source_supports':s['exact_original_source_support_proofs'],'staged_integer_planes':t['exact_integer_plane_implications'],
    'closed_construction_calls':2,'independent_rows_result':'UNKNOWN','staged_result':'grid-INFEASIBLE','joint_solver_output_used_by_staged_method':False,'source_valid66':False,'new_fixed_arrangement_exclusions':0,'fixed_arrangements_remaining':4,'fixed_arrangements_excluded_at_original_clearance':451,'whole_allocations_remaining':440,'native_or_LightBurn_calls':0,'all_descendants_closed':True,'helper_syntax_failure_preserved':True,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write('next-step.json',{'all_existing_calls_closed':True,'no_retry_reseed_or_extension':True,'next_hypothesis':'Assess a distinct5/5/2 twelve-cog source-row allocation for short9, initially reference sites0..9,13,14 (empty10,11,12), one of the still-unresolved fixed choices. The two-cog row admits more translation freedom and changes available companion geometry. Derive fresh exact row/core/stock bounds and error envelopes; independently certify all new source interactions, controls and integer/model implications; charge all consumed preparation before a single new bounded construction. Existing4/4/4 and5/4/3 models and the fixed5/4/3 control call remain closed. This is prospective only, not a source-valid66 placement or an allocation conclusion.','new_solver_prepared':False,'native_requires_source_valid66':True,'full_material_matrix_and_production_parity_required':True,'H5_complete':False})
print(load(OUT/'checks.json'))
