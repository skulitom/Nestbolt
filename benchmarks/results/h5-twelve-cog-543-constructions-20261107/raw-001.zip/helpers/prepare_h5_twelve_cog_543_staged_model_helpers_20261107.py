from pathlib import Path
R=Path(__file__).resolve().parents[1]
def rename(s):
    for stage in ['packet','regions','integer']:
        s=s.replace('h5-staged-row-'+stage+'-20261104','h5-twelve-cog-543-staged-'+stage+'-20261107').replace('h5-staged-row-'+stage+'-process-20261104','h5-twelve-cog-543-staged-'+stage+'-process-20261107')
    return s.replace('h5-first55-after-source-valid11-20261029','h5-first57-direct-short9-20261104').replace('h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json','h5-first57-direct-short9-20261104/short9-source.json').replace('moving13_orthogonal_identities','moving16_orthogonal_identities').replace('packet-source13','packet-source12').replace('1540','1632')
def read(name):return rename((R/'output'/name).read_text(encoding='utf-8'))
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
stageone="STAGE_ONE_PROCESSES={'stage_one_'+s+'_complete_preparation_seconds':'h5-twelve-cog-543-row-'+s+'-process-20261107' for s in ['domains','regions','integer','control']}"
charges="""{'fixed_source_mode_geometry_preparation_seconds':load(ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(SLOTS/'checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],
    'direct_short9_and_inventory_complete_process_seconds':load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds'],
    **{key:load(ROOT/'output'/name/'prepare.json')['complete_seconds'] for key,name in STAGE_ONE_PROCESSES.items()},
    'packet_complete_preparation_seconds':load(PACKET_PROCESS/'prepare.json')['complete_seconds'],
    'fresh_combined_regions_complete_preparation_seconds':load(REG_PROCESS/'prepare.json')['complete_seconds'],
    'staged_integer_complete_preparation_seconds':load(PREPARATION_PROCESS/'prepare.json')['complete_seconds'],
    'cp_model_build_seconds':BUILD_TIME}"
def reledger(s):
    a=s.index('STAGE_ONE_PROCESSES=');b=s.index('\n',a);return s[:a]+stageone+s[b:]
s=reledger(read('build_h5_staged_row_model_20261104.py'))
s=s.replace('Local0.1mm-grid construction with audited source implications and all35 site choices.','Fixed twelve-cog companion construction at0.01mm with all sixteen original movers.')
s=s.replace('packet_shift==[26,27]','packet_shift==[32,33]')
a=s.index('charges={');b=s.index(";write(OUT/'preparation-charges.json',charges)",a)
s=s[:a]+'charges='+charges.replace('BUILD_TIME','elapsed')+s[b:]
s=s.replace("FIRST/'checks.json',SLOTS/'checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json'", "ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json',SLOTS/'checks.json',ROOT/'output/h5-first57-direct-short9-process-20261104/opened.json',ROOT/'output/h5-first57-direct-short9-process-20261104/process.json'")
s=s.replace("for file in ['opened.json','process.json']", "for file in ['opened.json','prepare.json','process.json']")
s=s.replace("PACKET_PROCESS/'opened.json'", "PACKET_PROCESS/'prepare.json',PACKET_PROCESS/'opened.json'").replace("REG_PROCESS/'opened.json'", "REG_PROCESS/'prepare.json',REG_PROCESS/'opened.json'").replace("PREPARATION_PROCESS/'opened.json'", "PREPARATION_PROCESS/'prepare.json',PREPARATION_PROCESS/'opened.json'")
s=s.replace('all13 orthogonal owners and80 modes','all16 orthogonal owners and96 modes').replace('stage-one13-cog','stage-one12-cog').replace('all13 orthogonal companions','all16 orthogonal companions').replace('all20 rigid outward rectangles and183','all24 rigid outward rectangles and268')
s=s.replace("'original_moving_parts':13,'source_mode_selectors':80", "'original_moving_parts':16,'source_mode_selectors':96").replace("'world_stock_constraints':160", "'world_stock_constraints':192")
write('build_h5_twelve_cog_543_staged_model_20261107.py',s)
s=reledger(read('audit_h5_staged_row_model_20261104.py'))
for before,after in [('rectangle_start=108+expected_unary','rectangle_start=130+expected_unary'),('direction_start=rectangle_start+80','direction_start=rectangle_start+96'),('len(instances)==13','len(instances)==16'),('28<=selector<108','34<=selector<130'),('26+k','32+k'),('[26,27]','[32,33]'),('108<=selector<rectangle_start','130<=selector<rectangle_start'),('len(components)==20','len(components)==24'),('len(separations)==183','len(separations)==268'),('coordinate_links==544','coordinate_links==640'),('direction_start+732','direction_start+1072'),('mode_count==80','mode_count==96'),('combinations(range(20),2)','combinations(range(24),2)')]:s=s.replace(before,after)
a=s.index('expected_charges={');b=s.index('\nassert load(MODEL/',a)
s=s[:a]+'expected_charges='+charges.replace('BUILD_TIME',"load(MODEL/'checks.json')['seconds']")+s[b:]
s=s.replace("build_h5_staged_row_model_20261104.py", "build_h5_twelve_cog_543_staged_model_20261107.py")
s=s.replace("assert process['exit_code']==0 and", "assert process['job']['closed'] and process['job']['active_processes']==0 and process['exit_code']==0 and")
s=s.replace("'original_moving_parts':13", "'original_moving_parts':16").replace("'world_stock_constraints_verified':160", "'world_stock_constraints_verified':192").replace("'rigid_components_verified':20", "'rigid_components_verified':24").replace("'source_mode_coordinate_links_verified':544", "'source_mode_coordinate_links_verified':640").replace("'different_owner_rectangle_pairs_verified':183", "'different_owner_rectangle_pairs_verified':268").replace("'separation_direction_selectors_verified':732", "'separation_direction_selectors_verified':1072").replace("'same_family_order_constraints_verified':11", "'same_family_order_constraints_verified':14")
write('audit_h5_twelve_cog_543_staged_model_20261107.py',s)
s=(R/'output/run_h5_twelve_cog_543_row_model_build_20261107.py').read_text(encoding='utf-8').replace('h5-twelve-cog-543-row-integer','h5-twelve-cog-543-staged-integer').replace('h5-twelve-cog-543-row-model-process','h5-twelve-cog-543-staged-model-process').replace('h5_twelve_cog_543_row_model','h5_twelve_cog_543_staged_model')
write('run_h5_twelve_cog_543_staged_model_build_20261107.py',s)
s=read('check_h5_staged_row_candidate_20261104.py').replace("'first_originals':55,'short_originals':11", "'first_originals':57,'short_originals':9")
write('check_h5_twelve_cog_543_staged_candidate_20261107.py',s)
# The staged child has different input mappings, while the proven current supervisor remains unchanged.
s=read('run_h5_staged_row_model_20261104.py').replace('check_h5_staged_row_candidate_20261104.py','check_h5_twelve_cog_543_staged_candidate_20261107.py').replace('on a micrometre grid','on a0.01mm grid')
current=(R/'output/run_h5_twelve_cog_543_row_model_20261107.py').read_text(encoding='utf-8')
a=s.index('    try:\n',s.index('def main():'));b=s.index("    write(OUT / 'process.json', summary)",a)
ca=current.index("    exe=ROOT/",current.index('def main():'));cb=current.index("    write(OUT / 'process.json', summary)",ca)
s=s[:a]+current[ca:cb]+s[b:]
write('run_h5_twelve_cog_543_staged_model_20261107.py',s)
s=read('audit_h5_staged_row_response_20261104.py')
old="assert charges['source_valid_short11_shared_seconds']==load(ROOT/'output/h5-short11-integer-mode-regions-20261029/response-audit/checks.json')['shared_seconds_including_preparation']"
current=(R/'output/audit_h5_twelve_cog_543_row_response_20261107.py').read_text(encoding='utf-8')
a=current.index("assert charges['direct_short9");b=current.index("assert opened['source_validation",a)
s=s.replace(old,current[a:b].rstrip()).replace("'closed_solver_calls':1", "'closed_solver_calls':1,'windows_job_descendants_closed':True")
write('audit_h5_twelve_cog_543_staged_response_20261107.py',s)
print({'prepared':True,'joint_solver_or_model_consumed':False,'solver_calls':0})
