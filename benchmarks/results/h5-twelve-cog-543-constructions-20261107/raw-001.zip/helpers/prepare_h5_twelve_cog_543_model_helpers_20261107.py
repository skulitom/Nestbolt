"""Fresh 5/4/3 integer/control/model helpers with widened error bounds."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def rename(s):return s.replace('h5-twelve-cog-','h5-twelve-cog-543-').replace('h5_twelve_cog_','h5_twelve_cog_543_').replace('4/4/4-row source allocation','5/4/3-row source allocation')
def read(name):return rename((R/'output'/name).read_text(encoding='utf-8'))
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=read('prepare_h5_twelve_cog_row_integer_20261107.py')
s=s.replace('pair_envelope=[F(600),F(1100)]','pair_envelope=[F(700),F(1100)]').replace('600x1100mm','700x1100mm').replace("'row_pair_error_envelope_mm':[600,1100]", "'row_pair_error_envelope_mm':[700,1100]")
s=s.replace("pairs=[{'components'", "component_pairs=[{'components'").replace('len(pairs)==268','len(component_pairs)==268').replace("write(OUT/'component-pairs.json',pairs)", "write(OUT/'component-pairs.json',component_pairs)")
write('prepare_h5_twelve_cog_543_row_integer_20261107.py',s)
s=read('audit_h5_twelve_cog_row_integer_v2_20261107.py').replace("OUT=BASE/'geometry-audit-v2'","OUT=BASE/'geometry-audit'")
s=s.replace('pair_limits==[600,1100]','pair_limits==[700,1100]')
s=s.replace("'supersedes_reported_row_region_count_only':'geometry-audit/checks.json','original_count_was_component_pairs_due_to_local_name_reuse':True,'model_or_region_bytes_changed':False,",'')
s=s.replace("assert planes==load(BASE/'checks.json')['integer_planes'];", "assert planes==load(BASE/'checks.json')['integer_planes'] and len(pairs)==load(BASE/'checks.json')['row_pair_regions'] and len(mover)==load(BASE/'checks.json')['mover_row_regions'];")
write('audit_h5_twelve_cog_543_row_integer_20261107.py',s)
for name in ['run_h5_twelve_cog_row_integer_20261107.py','prepare_h5_twelve_cog_row_control_20261107.py','audit_h5_twelve_cog_row_control_20261107.py','run_h5_twelve_cog_row_control_20261107.py','build_h5_twelve_cog_row_model_20261107.py','audit_h5_twelve_cog_row_model_20261107.py','run_h5_twelve_cog_row_model_build_20261107.py','check_h5_twelve_cog_row_candidate_20261107.py','run_h5_twelve_cog_row_model_20261107.py','audit_h5_twelve_cog_row_response_20261107.py']:
    write(name.replace('twelve_cog_','twelve_cog_543_'),read(name))
print({'prepared':True,'row_pair_error_envelope_mm':[700,1100],'source_audit_required_before_model':True,'calls_started':0})
