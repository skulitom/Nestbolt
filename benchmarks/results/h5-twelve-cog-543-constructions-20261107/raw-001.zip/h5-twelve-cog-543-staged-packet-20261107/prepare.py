"""Freeze the deterministic5/4/3-row control as a point-domain stage."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];CONTROL=ROOT/'output/h5-twelve-cog-543-row-integer-20261107/row-control';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';OUT=ROOT/'output/h5-twelve-cog-543-staged-packet-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SHORT=ROOT/'output/h5-first57-direct-short9-20261104/short9-source.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(CONTROL/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
source=load(CONTROL/'candidate-source50.json');cogs=[r for r in source if r['part_id']=='cog' and r['sheet_id']=='sheet-0'];fixed=load(FIRST/'fixed29.json');short=load(SHORT)
assert fixed+cogs+short==source and len(cogs)==12
inventory=load(CONTROL.parent/'inventory.json');missing=set(map(tuple,inventory['moving16_orthogonal_identities']));expected=[tuple(x) for x in inventory['full66_identities'] if tuple(x) not in missing]
spec=load(FIRST/'plan.json');check=audit(load(JOB),source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert check['valid'] and check['same_sheet_pairs']==856 and check['cutouts']==58 and check['hole_vertices']==6122
modes={family:[{**m,'relative_lower_left_bounds_mm':[[str(F(v)) for v in bounds] for bounds in m['lower_left_bounds']]} for m in load(FIRST/'family-modes.json')[family]] for family in ['bracket','insert']}
domain={'shift_grid_units_per_mm':100,'shift_bounds_grid':[[0,0],[0,0]],'shift_bounds_mm':[['0','0'],['0','0']],'fixed_packet_point_domain':True,'source_control':'output/h5-twelve-cog-543-row-integer-20261107/row-control/candidate-source50.json','selection_rule':'First feasible fresh centroid-difference control, fixed before companion placement. No completed packing solver or old restricted-row control is consumed.','all_cogs_share_one_translation':True,'translation_is_fixed_zero':True}
for name,value in [('packet-source12.json',cogs),('inventory.json',inventory),('family-modes.json',modes),('translation-domain.json',domain),('source50.json',source),('source-checks.json',check)]:write(OUT/name,value)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'family-modes.json',CONTROL.parent/'inventory.json']+[CONTROL/n for n in ['plan.json','checks.json','candidate-source50.json','selected-control.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Two-stage positive construction: retain the first admissible deterministic5/4/3-row control, then construct all16 missing orthogonal originals against the combined fixed12-cog obstacle union. Freeze stage one before examining companion placements. Represent the fixed cog packet as a zero-translation point domain for compatibility with the audited packet schema; these are not free translation variables. Rebuild and independently certify all combined regions from original source geometry. Charge every preparation used by stage one and stage two before a new bounded companion call. The closed5/4/3 joint model and its solver result are not algorithm inputs. No continuous exclusion or optimality claim.','new_model_created':False,'solver_calls':0,'source_valid66':False,'H5_complete':False})
result={'passed':True,'seconds_including_source_controls':time.perf_counter()-started,'fixed_cogs':12,'source_valid50':True,'same_sheet_pairs':856,'cutouts':58,'hole_vertices':6122,'shared_shift_fixed_zero':True,'source_mode_options':96,'fresh_combined_regions_required':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
