"""Include the two highest source members within the existing pair caps."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-pair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');red=load(out/'before-boundary-pair/checks.json')
assert red['expected_runtime_failure'] and digest(out/'before-boundary-pair/expected-failure.log')==red['log_sha256']
rel=plan['changed_files'][0];path=out/'candidate'/rel
assert path.read_bytes()==(out/'before-boundary-pair'/rel).read_bytes()
before=path.read_text(encoding='utf-8');start=before.index('fn include_boundary_pair(');end=before.index('struct Proposal {',start)
stub=before[start:end]
replacement='''// Reserve the first choice in the appropriate existing pair list for the
// two highest-ranked source members. Keep nearby alternatives, remove the
// equivalent pair in either anchor order, and retain the original six cap.
// The caller restores each selected pair's original member frame afterwards.
fn include_boundary_pair(
    layout: &JLayout,
    keys: &[PItemKey],
    same: &mut Vec<Vec<PItemKey>>,
    mixed: &mut Vec<Vec<PItemKey>>,
) {
    let [a, b, ..] = keys else { return; };
    let pairs = if std::sync::Arc::ptr_eq(
        layout.placed_items()[*a].item(), layout.placed_items()[*b].item(),
    ) { same } else { mixed };
    pairs.retain(|pair| !(pair.len() == 2 && pair.contains(a) && pair.contains(b)));
    pairs.insert(0, vec![*a, *b]);
    pairs.truncate(6);
}

'''
after=before[:start]+replacement+before[end:]
assert after.replace(replacement,stub)==before
assert after.split('#[cfg(test)]',1)[1]==before.split('#[cfg(test)]',1)[1]
path.write_text(after,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
(out/'pair-substitution.json').write_text(json.dumps({'before':stub,'after':replacement},indent=2)+'\n',encoding='utf-8',newline='\n')
parent=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8');current=path.read_text(encoding='utf-8')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(parent.splitlines(True),current.splitlines(True),fromfile='boundary-priority/'+rel,tofile='boundary-pair/'+rel)),encoding='utf-8',newline='\n')
checks={'boundary_pair_installed':True,'prior_tests_unchanged':126,'new_tests':4,
        'substitution_reverses_exactly':True,'test_source_unchanged_from_expected_failure':True,
        'existing_pair_generators_unchanged':True,'same_and_mixed_caps_six_each':True,
        'original_pair_member_frames_preserved':True,'duplicate_pair_removed_in_either_order':True,
        'existing_geometry_material_guards_unchanged':True,'existing_deadlines_work_charges_and_coefficients_unchanged':True,
        'normal_mode_unchanged':True,'source_sha256':digest(path),'production_changed':False,'quality_claim':False}
(out/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'apply.py');print(json.dumps(checks))
