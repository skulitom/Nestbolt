"""Preserve the trailing-comma reader failure and require the exact formatted call."""
from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-pair-probe-20261018'
checker=root/'output/check_h5_boundary_pair_source.py';failed=probe/'source-check-format-failure-v2';failed.mkdir()
shutil.copyfile(checker,failed/'check.py')
source=probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs';before=source.read_bytes()
record={'command':['python','output/ccd1.py','python','output/check_h5_boundary_pair_source.py'],
        'exit_code':1,'exception':'AssertionError','line':17,
        'failed_assertion':"assert ''.join(formatted_call.split())==''.join(call.split())",
        'cause':'The formatter also inserts a legal trailing argument comma. Require its exact formatted spelling instead.',
        'candidate_sha256':sha256(before).hexdigest(),'source_changed':False,'new_measurements':0}
(failed/'failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
expected='''        include_boundary_pair(
            &sep.layout,
            &incoming_keys,
            &mut same_pairs,
            &mut mixed_pairs,
        );
'''
s=checker.read_text(encoding='utf-8');old="assert ''.join(formatted_call.split())==''.join(call.split())"
new='assert formatted_call=='+repr(expected)+"\nassert call=='        include_boundary_pair(&sep.layout, &incoming_keys, &mut same_pairs, &mut mixed_pairs);\\n'"
assert s.count(old)==1;s=s.replace(old,new);compile(s,str(checker),'exec')
checker.write_text(s,encoding='utf-8',newline='\n');assert source.read_bytes()==before
shutil.copyfile(__file__,failed/'fix-reader.py');print('Preserved the second reader failure; exact formatted call required, source unchanged.')
