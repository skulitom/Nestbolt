"""Preserve the literal-format reader failure; compare the formatter's actual call."""
from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-pair-probe-20261018'
checker=root/'output/check_h5_boundary_pair_source.py';failed=probe/'source-check-format-failure';failed.mkdir()
shutil.copyfile(checker,failed/'check.py')
source=probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs';before=source.read_bytes()
record={'command':['python','output/ccd1.py','python','output/check_h5_boundary_pair_source.py'],
        'exit_code':1,'exception':'AssertionError','line':13,
        'failed_assertion':"call=load(out/'no-op-extraction.json')['call'];assert restored.count(call)==1",
        'cause':'cargo fmt wraps the injected call across lines; the checker incorrectly expects its pre-format literal.',
        'candidate_sha256':sha256(before).hexdigest(),'source_changed':False,'new_measurements':0}
(failed/'failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
s=checker.read_text(encoding='utf-8')
old="call=load(out/'no-op-extraction.json')['call'];assert restored.count(call)==1\nassert restored.replace(call,'')==old_runtime"
new="""call=load(out/'no-op-extraction.json')['call']
call_start=restored.index('        include_boundary_pair(')
call_end=restored.index('        preserve_pair_frames(&mut same_pairs, &original_order);',call_start)
formatted_call=restored[call_start:call_end]
assert ''.join(formatted_call.split())==''.join(call.split())
assert (out/'before-boundary-pair'/rel).read_text(encoding='utf-8').count(formatted_call)==1
assert restored[:call_start]+restored[call_end:]==old_runtime"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("'material_profile_and_validator_sources_unchanged':True", "'formatting_reader_failure_preserved':True,'material_profile_and_validator_sources_unchanged':True")
checker.write_text(s,encoding='utf-8',newline='\n');assert source.read_bytes()==before
shutil.copyfile(__file__,failed/'fix-reader.py');print('Preserved the failed reader; candidate source is unchanged.')
