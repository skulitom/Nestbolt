"""Reconstruct the candidate and verify that only bounded pair inclusion changes."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-pair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'build.json')['all_checks_passed']
rel=plan['changed_files'][0];parent=Path(plan['old_probe'])/'candidate'
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]',1);runtime,tests=current.split('#[cfg(test)]',1)
start=runtime.index('// Reserve the first choice');end=runtime.index('struct Proposal {',start)
restored=runtime[:start]+runtime[end:]
call=load(out/'no-op-extraction.json')['call']
call_start=restored.index('        include_boundary_pair(')
call_end=restored.index('        preserve_pair_frames(&mut same_pairs, &original_order);',call_start)
formatted_call=restored[call_start:call_end]
assert formatted_call=='        include_boundary_pair(\n            &sep.layout,\n            &incoming_keys,\n            &mut same_pairs,\n            &mut mixed_pairs,\n        );\n'
assert call=='        include_boundary_pair(&sep.layout, &incoming_keys, &mut same_pairs, &mut mixed_pairs);\n'
assert (out/'before-boundary-pair'/rel).read_text(encoding='utf-8').count(formatted_call)==1
assert restored[:call_start]+restored[call_end:]==old_runtime
assert tests.split('    // BEGIN boundary-pair tests',1)[0].rstrip()==old_tests.rsplit('\n}',1)[0].rstrip()
fresh=root/'output/h5-boundary-pair-reconstruction-20261018';shutil.copytree(out/'candidate',fresh)
s=(out/'before-boundary-pair'/rel).read_text(encoding='utf-8');change=load(out/'pair-substitution.json')
assert s.count(change['before'])==1;s=s.replace(change['before'],change['after'])
(fresh/rel).write_text(s,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
files=[]
for row in plan['old_source_files']['candidate']:
    name=row['path'];assert digest(parent/name)==row['sha256']
    assert (fresh/name).read_bytes()==(out/'candidate'/name).read_bytes()
    if name!=rel:assert digest(out/'candidate'/name)==row['sha256']
    files.append(name)
record={'all_checks_passed':True,'all_126_prior_tests_unchanged':True,'other_runtime_exact':True,
        'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(files),'unchanged_other_files':len(files)-1,
        'formatting_reader_failure_preserved':True,'material_profile_and_validator_sources_unchanged':True,'only_bounded_pair_inclusion_changes':True,
        'original_frame_preserved_within_each_selected_pair':True,
        'existing_generators_caps_budgets_acceptance_work_charges_unchanged':True,'new_searches':0}
(out/'reconstruction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
