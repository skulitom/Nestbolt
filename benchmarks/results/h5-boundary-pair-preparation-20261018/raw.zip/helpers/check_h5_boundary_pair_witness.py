"""Independently identify both highest physical parts in each selection witness."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-pair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out=probe/'pair-checks';out.mkdir()
target=Path(load(probe/'preparation.json')['target']);bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1;binary=bins[0]
command=[str(binary),'boundary_pair','--nocapture','--test-threads=1'];r=subprocess.run(command,capture_output=True,timeout=120)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr)
(out/'command.json').write_text(json.dumps({'command':command,'exit_code':r.returncode},indent=2)+'\n',encoding='utf-8',newline='\n')
assert r.returncode==0 and '4 passed; 0 failed' in r.stdout.decode()
rows=[json.loads(s.removeprefix('BOUNDARY_PAIR_WITNESS ')) for s in r.stderr.decode().splitlines() if s.startswith('BOUNDARY_PAIR_WITNESS ')]
assert len(rows)==2 and {r['mixed'] for r in rows}=={False,True}
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def key(p):return p['part_id'],json.dumps(p['transform'],sort_keys=True)
records=[]
for i,row in enumerate(rows):
    case=out/f'case-{i}';case.mkdir()
    for name in ['job','layout']:write(case/(name+'.json'),row[name])
    args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/'layout.json')]
    r=subprocess.run(args,capture_output=True,timeout=60)
    (case/'validate-stdout.json').write_bytes(r.stdout);(case/'validate-stderr.log').write_bytes(r.stderr)
    assert r.returncode==0 and json.loads(r.stdout)['valid']
    parts={p['id']:p for p in row['job']['parts']};heights={}
    for p in row['layout']['placements']:
        if p['sheet_id']!='sheet-1':continue
        t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
        top=max(m*x*s+y*c+t['translation'][1] for polygon in parts[p['part_id']]['geometry'] for x,y in polygon['outer'])
        assert key(p) not in heights;heights[key(p)]=top
    highest=max(heights.values());owners={p for p,h in heights.items() if h==highest}
    assert len(owners)==2 and {key(p) for p in row['selected']}==owners
    records.append({'mixed':row['mixed'],'source_parts':len(heights),'height_mm':highest,
                    'selected_exactly_both_highest_original_contours':True,'selected':row['selected']})
    write(case/'selection.json',row['selected'])
shutil.copyfile(binary,out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
checks={'all_checks_passed':True,'new_pair_tests':4,'public_CLI_validations':2,
        'same_and_mixed_highest_pair_independently_confirmed':True,'caps_dedup_fallbacks_and_original_anchor_checked':True,
        'CLI_sha256':expected,'test_binary_sha256':digest(binary),'records':records,'quality_claim':False,'new_measured_searches':0}
write(out/'checks.json',checks);print(json.dumps(checks))
