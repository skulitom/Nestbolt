"""Seal qualified bounded boundary-pair coverage before its quality pilot."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-pair-probe-20261018'
out=root/'benchmarks/results/h5-boundary-pair-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');pair=load(probe/'pair-checks/checks.json')
assert all(x['all_checks_passed'] for x in [build,source,public,branch,pair])
assert '130 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['all_126_prior_tests_unchanged'] and source['other_runtime_exact'] and source['unchanged_other_files']==155
assert source['original_frame_preserved_within_each_selected_pair']
for folder in ['source-check-format-failure','source-check-format-failure-v2']:
    failure=load(probe/folder/'failure.json')
    assert failure['exit_code']==1 and not failure['source_changed']
    assert failure['candidate_sha256']==digest(probe/'candidate'/plan['changed_files'][0])
red=load(probe/'before-boundary-pair/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-boundary-pair/expected-failure.log')==red['log_sha256']
assert digest(probe/'before-boundary-pair/authored-tests.exe')==red['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/rel)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
assert branch['actual_outcomes']==12 and branch['public_validations']==24
assert pair['new_pair_tests']==4 and pair['public_CLI_validations']==2 and pair['same_and_mixed_highest_pair_independently_confirmed']
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256']
assert digest(root/method['candidate_runner'])==method['runner_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_boundary_pair.py','check_h5_boundary_pair_red.py','apply_h5_boundary_pair.py','build_h5_boundary_pair.py',
             'prepare_h5_boundary_pair_checks.py','check_h5_boundary_pair_source.py','check_h5_boundary_pair_witness.py',
             'check_h5_boundary_pair_public.py','check_h5_boundary_pair_branch.py','check_h5_boundary_pair_harness.py',
             'seal_h5_boundary_pair.py','record_h5_boundary_pair_preparation.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_boundary_pair_pilot.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':130,'prior_tests_unchanged':126,'new_tests':4,
        'expected_three_failures_preserved':True,'two_format_reader_failures_preserved':True,'original_pair_frames_preserved':True,'strict_lint_passed':True,'observer_build_passed':True,
        'only_bounded_pair_inclusion_changes':True,'existing_generators_caps_budgets_work_charges_acceptance_unchanged':True,
        'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':155,
        'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'pair_witness_CLI_checks':2,
        'same_and_mixed_top_copy_coverage_independently_verified':True,
        'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,
        'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'production_unchanged':True,
        'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
for sub,name in [('before-boundary-pair','expected-failure'),('public-checks','public-checks'),('branch-checks','branch-checks'),('pair-checks','pair-checks')]:shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
doc='''# Include both highest source members — preparation, 2026-10-18

The [exact-copy diagnostic](h5-boundary-observer-20261018.md) reaches an
actual height-setting copy on all 19 attempts, but its available choices
never include both height-setting inserts together. Eighteen attempts stop
at repair or expiry. This evidence motivates a coverage experiment; it
does not establish that the omitted pair can move or meet H5.

The isolated candidate puts the two highest-ranked source members first in
the appropriate same-item or mixed-item pair list. It removes an equivalent
pair in either anchor order and retains the original six-plus-six caps and
nearby alternatives within those caps. Existing pair generators remain.
The original area/stable member order still defines each selected pair's
anchor and relative frame. Sampling, repairs, allowed orientations, deadlines,
work charges, early neutral rejections and full acceptance checks are unchanged.

All 130 optimized tests pass, including all 126 prior tests unchanged.
The previous selector first fails three new coverage/priority regressions
while passing the empty/single-source case; that source, executable and
failed log are preserved. Same-item and mixed-item fixtures place closer
lower neighbours around the two upper parts. The candidate includes those
two upper parts together. Independent transformed original contours confirm
the selected physical pair is exactly the two highest, and both canonical
fixtures validate with the frozen CLI. Reversed-pair de-duplication, caps,
remaining alternative order and original anchors are also checked.

Twelve existing rejection-boundary outcomes pass 24 further frozen-CLI checks.
Strict lint/build, ten public outcomes, four CLI comparisons, exact normal
results and deterministic common replays (apart from wall time) pass. All
156 formatted files reconstruct exactly; 155 and every other runtime block
remain unchanged. Five adversarial pilot harness checks pass.
Two source-reader failures caused by formatted line breaks and a trailing
argument comma are preserved. Requiring the exact formatted call fixes that
reader against the same source; no candidate code or measurement is rerun.

The planned pilot retains four frozen development jobs, both kerfs, three
seeds, 60 seconds, rotating serial three-arm blocks and eight physical CCD0
cores. Block, case, scoring and measurement functions are AST-identical to
the preceding pilot. Its plan is committed before measurement. A passing
pilot would still require the complete original 13-job H5 comparison.
Production, reserved inputs, previous failures, release and README claims
remain unchanged. H2/H5 remain open at 60%.

[Checks](h5-boundary-pair-preparation-20261018/checks.json),
[retained failures](h5-boundary-pair-preparation-20261018/expected-failure.json),
[physical pair witnesses](h5-boundary-pair-preparation-20261018/pair-checks.json),
[source reconstruction](h5-boundary-pair-preparation-20261018/reconstruction.json),
[archive integrity](h5-boundary-pair-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-boundary-pair-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_functional_checks_pass':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
