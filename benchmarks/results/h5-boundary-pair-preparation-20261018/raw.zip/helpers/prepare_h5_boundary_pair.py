"""Add physical boundary-pair coverage regressions before changing selection."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-pair-probe-20261018'
old=root/'output/h5-boundary-priority-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
evidence=load(root/'benchmarks/results/h5-boundary-observer-20261018/layout-checks.json')
assert evidence['attempts_with_actual_height_copy']==19 and evidence['attempts_with_all_height_copies']==0
assert all(not b['all_height_copies_choice_indices'] for b in evidence['baselines'])
assert load(root/'benchmarks/results/h5-boundary-priority-pilot-20261018/verification.json')['valid']==72
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');text=original
helper='''fn include_boundary_pair(
    _layout: &JLayout,
    _keys: &[PItemKey],
    _same: &mut Vec<Vec<PItemKey>>,
    _mixed: &mut Vec<Vec<PItemKey>>,
) {
}

'''
needle='struct Proposal {';assert text.count(needle)==1;text=text.replace(needle,helper+needle)
call='        include_boundary_pair(&sep.layout, &incoming_keys, &mut same_pairs, &mut mixed_pairs);\n'
needle='        preserve_pair_frames(&mut same_pairs, &original_order);'
assert text.count(needle)==1;text=text.replace(needle,call+needle)
assert text.replace(helper,'').replace(call,'')==original
tests='''
    // BEGIN boundary-pair tests
    fn boundary_pair_fixture(mixed: bool) -> (Job, Layout) {
        let (mut job, mut layout)=fixture();
        job.name="Boundary pair with closer lower neighbours".into();
        job.parts=vec![rectangle("anchor",94.0,94.0),rectangle("a",5.0,5.0)];
        job.parts[1].quantity=if mixed {3} else {6};
        let members=if mixed {
            let mut b=rectangle("b",5.0,5.0);b.quantity=3;job.parts.push(b);
            [("a",0,[10.0,80.0]),("b",0,[70.0,80.0]),
             ("b",1,[10.0,74.0]),("b",2,[10.0,68.0]),
             ("a",1,[70.0,74.0]),("a",2,[70.0,68.0])]
        } else {
            [("a",0,[10.0,80.0]),("a",1,[70.0,80.0]),
             ("a",2,[10.0,74.0]),("a",3,[10.0,68.0]),
             ("a",4,[70.0,74.0]),("a",5,[70.0,68.0])]
        };
        layout.placements=vec![Placement {part_id:"anchor".into(),copy_index:0,sheet_id:"sheet-0".into(),
            transform:RigidTransform {translation:[2.0,2.0],..Default::default()}}];
        layout.placements.extend(members.into_iter().map(|(id,copy_index,translation)|Placement {
            part_id:id.into(),copy_index,sheet_id:"sheet-1".into(),
            transform:RigidTransform {translation,..Default::default()}
        }));
        assert!(validate(&job,&layout).unwrap().valid);
        (job,layout)
    }

    fn boundary_pair_contains(pair:&[PItemKey], a:PItemKey,b:PItemKey)->bool {
        pair.len()==2 && pair.contains(&a) && pair.contains(&b)
    }

    fn boundary_pair_witness(mixed:bool) {
        let (job,layout)=boundary_pair_fixture(mixed);
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[1].layout();let mut keys:Vec<_>=source.placed_items().keys().collect();
        rank_incoming(source,&mut keys);
        assert_eq!(source.placed_items()[keys[0]].shape().bbox().x_max,source.placed_items()[keys[1]].shape().bbox().x_max);
        let mut same=incoming_pairs(source,&keys);let mut other=mixed_incoming_pairs(source,&keys);
        let before_same=same.clone();let before_mixed=other.clone();
        assert!(!same.iter().chain(&other).any(|p|boundary_pair_contains(p,keys[0],keys[1])),"Fixture must expose the existing missing upper pair");
        include_boundary_pair(source,&keys,&mut same,&mut other);
        assert!(same.len()<=6 && other.len()<=6);
        let selected=if mixed {assert_eq!(same,before_same);&other} else {assert_eq!(other,before_mixed);&same};
        assert_eq!(selected[0],vec![keys[0],keys[1]],"Both highest members must enter the appropriate pair list first");
        assert_eq!(selected.iter().filter(|p|boundary_pair_contains(p,keys[0],keys[1])).count(),1);
        let poses:Vec<_>=selected[0].iter().map(|key| {
            let p=&source.placed_items()[*key];let item=p.item().idx();
            serde_json::json!({"part_id":job.parts[model.part[item]].id,"transform":model.external(item,&p.d_transf())})
        }).collect();
        eprintln!("BOUNDARY_PAIR_WITNESS {}",serde_json::json!({"job":job,"layout":model.to_layout(&sheets),"mixed":mixed,"selected":poses}));
    }

    #[test]
    fn boundary_pair_same_item_reaches_both_highest_despite_nearby_lower_parts() {
        boundary_pair_witness(false);
    }

    #[test]
    fn boundary_pair_mixed_items_reach_both_highest_despite_nearby_lower_parts() {
        boundary_pair_witness(true);
    }

    #[test]
    fn boundary_pair_deduplicates_and_retains_caps_alternatives_and_anchor() {
        let (job,layout)=boundary_pair_fixture(false);
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[1].layout();let mut keys:Vec<_>=source.placed_items().keys().collect();
        rank_incoming(source,&mut keys);let mut same=incoming_pairs(source,&keys);let mut mixed=Vec::new();
        assert_eq!(same.len(),6);same[2]=vec![keys[1],keys[0]];
        let alternatives:Vec<_>=same.iter().filter(|p|!boundary_pair_contains(p,keys[0],keys[1])).cloned().collect();
        include_boundary_pair(source,&keys,&mut same,&mut mixed);
        assert_eq!(same[0],vec![keys[0],keys[1]],"Existing reversed upper pair must be promoted without duplication");
        assert_eq!(same.len(),6);assert_eq!(&same[1..],alternatives.as_slice());assert!(mixed.is_empty());
        let mut original=keys.clone();original.reverse();preserve_pair_frames(&mut same,&original);
        assert_eq!(same[0],vec![keys[1],keys[0]],"Original pair anchor order must survive selection priority");
        let mut seen=Vec::new();
        for pair in same {let mut key=pair.clone();key.sort();assert!(!seen.contains(&key));seen.push(key);}
    }

    #[test]
    fn boundary_pair_empty_or_single_source_keeps_empty_choices() {
        let (job,layout)=boundary_pair_fixture(false);
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[1].layout();let key=source.placed_items().keys().next().unwrap();
        for keys in [vec![],vec![key]] {
            let mut same=Vec::new();let mut mixed=Vec::new();
            include_boundary_pair(source,&keys,&mut same,&mut mixed);
            assert!(same.is_empty() && mixed.is_empty());
        }
    }
    // END boundary-pair tests
'''
pos=text.rindex('\n}');text=text[:pos]+tests+text[pos:]
path.write_text(text,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
    'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'changed_files':[rel],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'target':str(root/'output/h5-boundary-pair-target-20261018'),'unchanged_prior_tests':126,'new_tests':4,
    'no_op_helper_and_call_reverse_exactly':True,'boundary_pair_installed':False,'held_out_access':False,'acceptance_guards_unchanged':True}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'no-op-extraction.json').write_text(json.dumps({'helper':helper,'call':call},indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
s=(root/'output/build_h5_boundary_priority.py').read_text(encoding='utf-8').replace('h5-boundary-priority','h5-boundary-pair')
(root/'output/build_h5_boundary_pair.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/check_h5_boundary_priority_red.py').read_text(encoding='utf-8').replace('h5-boundary-priority','h5-boundary-pair').replace('before-boundary-ranking','before-boundary-pair').replace('boundary_priority','boundary_pair')
s=s.replace("'1 passed; 2 failed'", "'1 passed; 3 failed'")
s=s.replace("'Boundary parts must precede larger interior parts'", "'Both highest members must enter the appropriate pair list first'")
s=s.replace("'Boundary family must enter the bounded pair choices first'", "'Existing reversed upper pair must be promoted without duplication'")
(root/'output/check_h5_boundary_pair_red.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'expected_tests':130,'prior_unchanged':126,'boundary_pair_installed':False}))
