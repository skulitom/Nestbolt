"""Reconstruct all adjusted originals and check every pair and stock boundary."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import copy,json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape,mapping
from shapely.affinity import translate

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-source-adjustment-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OLD=ROOT/'output/h5-conflict-owner-neighborhood-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source'];jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
    inputs=[BASE/n for n in ['plan.json','parts.json','segment-constraints.json','preparation-audit/checks.json','solve/plan.json','solve/model-audit.json','solve/result.json','solve/offsets.json']]
    inputs += [sourcepath,jobpath,SRC/'geometry.json',SRC/'items.json',SRC/'propagation.json',OLD/'fixed-originals.json',OLD/'plan.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Independently check every offset and all467 integer projection inequalities, then reconstruct the57 actual original polygons from the source job and adjusted transforms. Verify all1246 same-sheet original-polygon distances and every stock-boundary margin against both the declared construction targets and current native conservative thresholds. Check every original copy, sheet, rotation, mirror flag and area charge remains unchanged. Preserve a57-part partial layout for diagnosis, explicitly excluding full66-part/native/H5 acceptance. This full geometry check, not the local proposal objective, determines whether the adjusted baseline is usable.'})
    start=time.perf_counter();assert load(BASE/'preparation-audit/checks.json')['passed'] and load(BASE/'solve/model-audit.json')['passed']
    result=load(BASE/'solve/result.json');assert result['has_baseline_proposal'] and result['solver_calls']==1
    fixed=load(OLD/'fixed-originals.json');parts=load(BASE/'parts.json');offsets=load(BASE/'solve/offsets.json');byid={r['item']:r for r in offsets}
    assert len(byid)==len(offsets)==len(fixed)==57 and set(byid)=={r['item'] for r in fixed}
    for p in parts:
        off=byid[p['item']];b=p['offset_bounds_units'];assert b[0]<=off['dx_units']<=b[2] and b[1]<=off['dy_units']<=b[3]
        assert abs(off['dx_units'])<=500 and abs(off['dy_units'])<=500
    objective=sum(abs(r['dx_units'])+abs(r['dy_units']) for r in offsets);assert objective==result['objective_units']
    for row in load(BASE/'segment-constraints.json'):
        a,b=[byid[i] for i in row['items']]
        assert row['a']*(b['dx_units']-a['dx_units'])+row['b']*(b['dy_units']-a['dy_units'])>=row['required_offset_projection_units']
    source=load(sourcepath);job=load(jobpath);family={p['id']:p for p in job['parts']};items=load(SRC/'items.json');g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json')
    stocks=[[float(F(*v)) for v in b] for b in g['stock_bounds_rational']];guard=max(3000*32*2**-23,.00002);native_gap=(job['clearance']+guard)/math.cos(.05)
    layout=copy.deepcopy(source);layout['placements']=[];adjusted=[];geometries={};changes=[];max_error=0.
    for r in fixed:
        item=items[r['item']];placement=copy.deepcopy(source['placements'][r['source_index']]);old=copy.deepcopy(placement['transform']);assert old==r['transform']
        off=byid[r['item']];dx,dy=off['dx_units']/10000,off['dy_units']/10000
        t=copy.deepcopy(old);t['translation']=[old['translation'][0]+dx,old['translation'][1]+dy]
        assert t['rotation_radians']==old['rotation_radians'] and t['mirrored']==old['mirrored'];placement['transform']=t;placement['copy_index']=item['copy']
        assert placement['part_id']==r['family'] and int(placement['sheet_id'][-1])==r['sheet'];layout['placements'].append(placement)
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        polygon=Polygon([(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in family[r['family']]['geometry'][0]['outer']]);assert polygon.is_valid
        independently_shifted=translate(shape(r['geometry']),dx,dy);error=polygon.hausdorff_distance(independently_shifted);assert error<1e-7;max_error=max(max_error,error)
        geometries[r['item']]=polygon;adjusted.append({**r,'transform':t,'geometry':mapping(polygon),'unadjusted_transform':old,
            'adjustment_units':{'dx':off['dx_units'],'dy':off['dy_units'],'units_per_mm':10000},'translation_hausdorff_error_mm':error})
        if off['dx_units'] or off['dy_units']:changes.append({'item':r['item'],'family':r['family'],'sheet':r['sheet'],'dx_mm':dx,'dy_mm':dy})
    assert Counter(r['family'] for r in adjusted)=={'frame':18,'bracket':10,'insert':20,'cog':9}
    spec=load(OLD/'plan.json');assert sorted(r['item'] for r in adjusted)==spec['fixed_items']
    assert Counter([r['family'] for r in adjusted]+[r['family'] for r in spec['movable_parts']])=={'frame':18,'bracket':12,'insert':21,'cog':15}
    pairs=[];stockchecks=[];min_gap=float('inf');min_edge=float('inf')
    for a,b in combinations(adjusted,2):
        if a['sheet']!=b['sheet']:continue
        pa,pb=geometries[a['item']],geometries[b['item']];distance=pa.distance(pb);intersection=pa.intersection(pb).area
        assert intersection==0 and distance>=.2125-1e-7 and distance>native_gap,(a['item'],b['item'],distance,native_gap)
        min_gap=min(min_gap,distance);pairs.append({'items':[a['item'],b['item']],'gap_mm':distance,'intersection_area_mm2':intersection,'above_native_guard_mm':distance-native_gap})
    for r in adjusted:
        b=geometries[r['item']].bounds;st=stocks[r['sheet']];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]]
        assert min(extra)>=.0125-1e-7 and min(extra)>guard,(r['item'],extra,guard)
        min_edge=min(min_edge,min(extra));stockchecks.append({'item':r['item'],'sheet':r['sheet'],'bounds':list(b),'extra_stock_margins_mm':extra,'minimum_above_native_guard_mm':min(extra)-guard})
    areas=[sum(aux['part_areas'][r['family']]['lower_units'] for r in adjusted if r['sheet']==s) for s in [0,1]]
    assert areas==spec['fixed_original_area_units_per_sheet']
    write(OUT/'adjusted-fixed-originals.json',adjusted);write(OUT/'partial-layout-57-originals.json',layout);write(OUT/'changes.json',changes)
    write(OUT/'pair-checks.json',pairs);write(OUT/'stock-checks.json',stockchecks)
    checks={'passed':True,'seconds':time.perf_counter()-start,'baseline_originals':57,'other_mandatory_originals':9,'required_originals':66,
        'all_original_identities_sheets_orientations_and_shapes_preserved':True,'changed_parts':len(changes),'changed_families':dict(Counter(r['family'] for r in changes)),
        'total_absolute_axis_translation_mm':objective/10000,'maximum_absolute_axis_translation_mm':max(max(abs(r['dx_units']),abs(r['dy_units'])) for r in offsets)/10000,
        'maximum_original_reconstruction_error_mm':max_error,'original_same_sheet_pairs_checked':len(pairs),'minimum_pair_gap_mm':min_gap,
        'native_conservative_pair_gap_mm':native_gap,'minimum_pair_excess_above_native_mm':min_gap-native_gap,'stock_boundaries_checked':4*len(stockchecks),
        'minimum_extra_stock_margin_mm':min_edge,'native_conversion_guard_mm':guard,'minimum_stock_excess_above_native_mm':min_edge-guard,
        'original_area_units_per_sheet':areas,'nine_prior_pair_shortfalls_resolved':True,'four_prior_stock_shortfalls_resolved':True,
        'adjusted_baseline_geometrically_clears_native_conservative_guards':True,'native_packing_calls':0,'native_full_job_qualified':False,
        'partial_layout_contains_only57_originals':True,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<120;write(OUT/'checks.json',checks);print(checks,flush=True);print({'changes':changes},flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
