"""Full-original clearance obstacles and free regions on an adjusted baseline."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback
from shapely.geometry import shape,mapping,box
from shapely.affinity import translate
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand,disk_vertices,circle_check

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-source-adjustment-20261025'
PROFILES=ROOT/'output/h5-circle-stock-neighborhood-20261025/original-outline-construction'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
OUT=BASE/'original-regions'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def vertices(g):
    if g.is_empty:return 0
    if g.geom_type=='Polygon':return len(g.exterior.coords)+sum(len(r.coords) for r in g.interiors)
    if hasattr(g,'geoms'):return sum(vertices(p) for p in g.geoms)
    return len(g.coords)

def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(PROFILES/'audit/checks.json')['passed']
    OUT.mkdir();(OUT/'obstacles').mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    profiles=load(PROFILES/'profiles.json');fixed=load(BASE/'audit/adjusted-fixed-originals.json');styles=load(GEO/'fixed-styles.json');g=load(SRC/'geometry.json')
    stocks=[[F(*v) for v in b] for b in g['stock_bounds_rational']];queries=[]
    for q in load(PROFILES/'queries.json'):
        p=profiles[q['profile']];b=list(map(F,p['bounds']));st=stocks[q['sheet']];extra=F(125,10000)
        continuous=[st[0]-b[0]+extra,st[1]-b[1]+extra,st[2]-b[2]-extra,st[3]-b[3]-extra]
        anchors=[math.ceil(continuous[0]*1000),math.ceil(continuous[1]*1000),math.floor(continuous[2]*1000),math.floor(continuous[3]*1000)]
        assert anchors[0]<anchors[2] and anchors[1]<anchors[3]
        queries.append({**q,'continuous_bounds_rational':[[v.numerator,v.denominator] for v in continuous],'anchor_bounds_units1000':anchors})
    caches=[{'index':si*10+pi,'fixed_style':si,'moving_profile':pi} for si in range(10) for pi in range(10)]
    inputs=[BASE/'audit/adjusted-fixed-originals.json',BASE/'audit/checks.json',PROFILES/'profiles.json',PROFILES/'queries.json',PROFILES/'audit/checks.json',GEO/'fixed-styles.json',SRC/'geometry.json']
    inputs += [ROOT/'output'/n for n in ['conservative_h5_round_obstacles.py','conservative_h5_polygon_obstacles.py','diagnose_h5_concave_gaps.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'construction_limit_seconds':180,'maximum_total_region_vertices':1000000,'cache_cases':caches,'queries':queries,
        'fixed_originals':57,'mandatory_moving_originals':9,'required_originals':66,'anchor_units_per_mm':1000,
        'original_clearance_mm':.2,'construction_clearance_mm':.2125,'clearance_envelope_extra_mm':.0001,'extra_stock_margin_mm':.0125,
        'method':'Use all10 full-original moving profiles, including every cog tooth at its known source angle, against all10 unchanged orientation styles of the57 independently adjusted originals. Construct100 actual polygonal zero-clearance Minkowski obstacles. Add an explicit circumscribed128-gon clearance envelope by boundary-segment Minkowski unions; no rounded buffer substitute. Translate those local envelopes to all57 adjusted transforms. For each of20 mode/sheet queries, subtract the complete forbidden union from the inward1-micrometre stock anchor rectangle with0.0125mm extra edge margin. Retain the whole free geometry without outward padding or sampled candidate points. Finite cog angle/grid and positive construction margins define a constructive subset, not a necessary all-angle relaxation. Preserve pending cases on caps. Independent obstacle and region audit is required before any full-original joint model.'})
    start=time.perf_counter();deadline=start+180
    write(OUT/'profiles.json',profiles);write(OUT/'adjusted-fixed-originals.json',fixed)
    write(OUT/'clearance-envelope.json',{'vertices':[list(map(float,p)) for p in disk_vertices(.2125,.0001)],**circle_check(.2125,.0001)})
    local={};complete=[]
    for q in caches:
        if time.perf_counter()>=deadline:break
        raw=raw_obstacle(shape(styles[q['fixed_style']]['geometry']),shape(profiles[q['moving_profile']]['geometry']))
        expanded=expand(raw,.2125,.0001);assert raw.is_valid and expanded.is_valid and not raw.is_empty and not expanded.is_empty and expanded.covers(raw)
        write(OUT/'obstacles'/f"{q['index']:03d}.json",{**q,'raw_forbidden':mapping(raw),'expanded_forbidden':mapping(expanded),
            'raw_vertices':vertices(raw),'expanded_vertices':vertices(expanded),'raw_area_mm2':raw.area,'expanded_area_mm2':expanded.area})
        local[(q['fixed_style'],q['moving_profile'])]=expanded;complete.append(q['index'])
        if len(complete)%25==0:print({'cache_cases_completed':len(complete),'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'pending-caches.json',caches[len(complete):]);records=[];total=0
    if len(complete)==100:
        for q in queries:
            if time.perf_counter()>=deadline or total>=1000000:break
            stock=box(*(v/1000 for v in q['anchor_bounds_units1000']));owners=[r for r in fixed if r['sheet']==q['sheet']]
            obstacles=unary_union([translate(local[(r['style'],q['profile'])],*r['transform']['translation']) for r in owners])
            free=stock.difference(obstacles);assert free.is_valid
            n=vertices(free);total+=n
            write(OUT/'queries'/f"{q['index']:03d}.json",{'query':q,'fixed_items':[r['item'] for r in owners],
                'original_stock_anchor_rectangle':mapping(stock),'expanded_forbidden_union':mapping(obstacles),'free_region':mapping(free),
                'empty':free.is_empty,'geometry_type':free.geom_type,'area_mm2':free.area,'vertices':n})
            records.append({'query':q['index'],'family':q['family'],'mode':q['mode'],'sheet':q['sheet'],'empty':free.is_empty,'area_mm2':free.area,'vertices':n})
    write(OUT/'pending-queries.json',queries[len(records):]);write(OUT/'query-summary.json',records)
    result={'seconds':time.perf_counter()-start,'cache_cases_planned':100,'cache_cases_completed':len(complete),'cache_cases_pending':100-len(complete),
        'queries_planned':20,'queries_completed':len(records),'queries_pending':20-len(records),'empty_queries':sum(r['empty'] for r in records),
        'region_vertices':total,'vertex_cap_reached':total>=1000000,'full_original_cog_vertices':80,'full_originals_required':66,
        'independent_audit_pending':True,'full_original_solver_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
