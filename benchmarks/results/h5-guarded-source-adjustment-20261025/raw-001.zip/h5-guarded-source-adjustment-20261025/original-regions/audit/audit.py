"""Independent full-original Minkowski and polygonal-clearance region audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,shutil,time,traceback
import shapely
from shapely.geometry import shape,MultiPoint,Polygon,box
from shapely.affinity import translate
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-guarded-source-adjustment-20261025'
BASE=SOURCE/'original-regions';OUT=BASE/'audit';GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def triangles(poly):
    result=list(shapely.constrained_delaunay_triangles(poly).geoms)
    assert result and unary_union(result).equals(poly);return result

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':180,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.rglob('*.json')) if OUT not in p.parents},
        'method':'Independently reconstruct every full-original obstacle using unmerged constrained triangles of both shapes and all triangle-vertex Minkowski sums. Verify the explicit128-gon clearance envelope with exact rational support-line distances and convexity. Reconstruct positive clearance by triangulating each independent raw obstacle and Minkowski-summing every triangle with the whole envelope, a different decomposition from boundary-segment expansion. Check all100 cache pairs and every20 query against all57 adjusted original transforms. Retain complete free regions without outward padding. These are constructive finite-angle/grid regions; a positive must still be checked on every actual original part and native geometry.'})
    start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed']
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    result=load(BASE/'result.json');assert result['cache_cases_completed']==100 and result['queries_completed']==20 and not load(BASE/'pending-caches.json') and not load(BASE/'pending-queries.json')
    profiles=load(BASE/'profiles.json');fixed=load(BASE/'adjusted-fixed-originals.json');styles=load(GEO/'fixed-styles.json')
    assert fixed==load(SOURCE/'audit/adjusted-fixed-originals.json') and len(profiles)==10 and len(fixed)==57
    envelope=load(BASE/'clearance-envelope.json');kverts=envelope['vertices'];K=Polygon(kverts);assert len(kverts)==128 and K.is_valid and K.equals(K.convex_hull)
    rational=[[F(v) for v in p] for p in kverts];line_distances=[];convex_tests=0
    for a,b in zip(rational,rational[1:]+rational[:1]):
        nx,ny=b[1]-a[1],a[0]-b[0];c=nx*a[0]+ny*a[1];assert c>0
        assert c*c>=F(17,80)**2*(nx*nx+ny*ny)
        for x,y in rational:assert nx*x+ny*y<=c;convex_tests+=1
        line_distances.append(float(c*c/(nx*nx+ny*ny))**.5)
    # Each zero-translation fixed style must still reconstruct its adjusted original.
    for r in fixed:
        assert translate(shape(styles[r['style']]['geometry']),*r['transform']['translation']).hausdorff_distance(shape(r['geometry']))<1e-7
    ft={s['index']:triangles(shape(s['geometry'])) for s in styles};mt={p['index']:triangles(shape(p['geometry'])) for p in profiles}
    assert profiles[9]['family']=='cog' and profiles[9]['original_vertex_count']==80
    cache={};checks=[];rawhulls=expandedhulls=0
    for q in plan['cache_cases']:
        assert time.perf_counter()-start<180
        row=load(BASE/'obstacles'/f"{q['index']:03d}.json");assert all(row[k]==v for k,v in q.items())
        sums=[MultiPoint([(a[0]-b[0],a[1]-b[1]) for a in list(x.exterior.coords)[:-1] for b in list(y.exterior.coords)[:-1]]).convex_hull for x,y in product(ft[q['fixed_style']],mt[q['moving_profile']])]
        raw=unary_union(sums);stored=shape(row['raw_forbidden']);hd=raw.hausdorff_distance(stored);area=raw.symmetric_difference(stored).area
        assert hd<1e-7 and area<1e-4,(q,'raw',hd,area)
        pieces=[]
        for t in triangles(raw):
            points=[(x+kx,y+ky) for x,y in list(t.exterior.coords)[:-1] for kx,ky in kverts]
            pieces.append(MultiPoint(points).convex_hull)
        expanded=unary_union(pieces);saved=shape(row['expanded_forbidden']);ehd=expanded.hausdorff_distance(saved);earea=expanded.symmetric_difference(saved).area
        assert ehd<1e-7 and earea<1e-4 and saved.covers(stored),(q,'expanded',ehd,earea)
        cache[(q['fixed_style'],q['moving_profile'])]=expanded;rawhulls+=len(sums);expandedhulls+=len(pieces)
        checks.append({**q,'raw_triangle_pair_hulls':len(sums),'expanded_raw_triangle_hulls':len(pieces),
            'raw_hausdorff_error_mm':hd,'raw_symmetric_difference_mm2':area,'expanded_hausdorff_error_mm':ehd,'expanded_symmetric_difference_mm2':earea})
        if len(checks)%25==0:print({'obstacles_audited':len(checks),'seconds':time.perf_counter()-start},flush=True)
    querychecks=[]
    for q in plan['queries']:
        assert time.perf_counter()-start<180
        row=load(BASE/'queries'/f"{q['index']:03d}.json");assert row['query']==q
        p=profiles[q['profile']];continuous=[F(*v) for v in q['continuous_bounds_rational']];bounds=q['anchor_bounds_units1000']
        assert bounds==[math.ceil(continuous[0]*1000),math.ceil(continuous[1]*1000),math.floor(continuous[2]*1000),math.floor(continuous[3]*1000)]
        geometry=load(ROOT/'output/h5-source-orientation-construction-20261025/geometry.json');st=[F(*v) for v in geometry['stock_bounds_rational'][q['sheet']]];b=list(map(F,p['bounds']));margin=F(125,10000)
        assert continuous==[st[0]-b[0]+margin,st[1]-b[1]+margin,st[2]-b[2]-margin,st[3]-b[3]-margin]
        owners=[r for r in fixed if r['sheet']==q['sheet']];assert row['fixed_items']==[r['item'] for r in owners]
        obstacles=unary_union([translate(cache[(r['style'],q['profile'])],*r['transform']['translation']) for r in owners])
        stock=box(*(v/1000 for v in bounds));free=stock.difference(obstacles);saved=shape(row['free_region']);forbidden=shape(row['expanded_forbidden_union'])
        assert shape(row['original_stock_anchor_rectangle']).equals(stock)
        ohd=obstacles.hausdorff_distance(forbidden);oa=obstacles.symmetric_difference(forbidden).area
        assert ohd<1e-7 and oa<1e-4
        assert saved.is_empty==free.is_empty==row['empty'];fhd=0 if free.is_empty else free.hausdorff_distance(saved);fa=free.symmetric_difference(saved).area
        assert fhd<1e-6 and fa<1e-4,(q['index'],fhd,fa)
        assert stock.covers(saved) and unary_union([saved,forbidden]).covers(stock)
        querychecks.append({'query':q['index'],'family':q['family'],'sheet':q['sheet'],'empty':free.is_empty,'free_area_mm2':saved.area,
            'fixed_originals_checked':len(owners),'forbidden_hausdorff_error_mm':ohd,'free_hausdorff_error_mm':fhd,'free_symmetric_difference_mm2':fa,
            'complete_stock_partition_verified':True,'no_outward_padding':True})
    write(OUT/'obstacle-checks.json',checks);write(OUT/'query-checks.json',querychecks)
    output={'passed':True,'seconds':time.perf_counter()-start,'full_original_profiles':10,'original_cog_vertices':80,'adjusted_fixed_transforms':57,
        'exact_clearance_support_lines':128,'exact_envelope_convexity_checks':convex_tests,'minimum_envelope_support_mm':min(line_distances),
        'certified_envelope_contains_radius_mm':.2125,'independent_raw_triangle_pair_hulls':rawhulls,'independent_expanded_triangle_hulls':expandedhulls,
        'all100_obstacles_verified':True,'maximum_raw_hausdorff_error_mm':max(r['raw_hausdorff_error_mm'] for r in checks),
        'maximum_expanded_hausdorff_error_mm':max(r['expanded_hausdorff_error_mm'] for r in checks),
        'all20_full_original_queries_verified':True,'empty_queries':sum(r['empty'] for r in querychecks),
        'maximum_free_region_hausdorff_error_mm':max(r['free_hausdorff_error_mm'] for r in querychecks),
        'whole_stock_partitions_verified':True,'outward_padding_applied':False,'construction_scope_not_unrestricted':True,
        'full_original_joint_solver_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',output);print(output,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
