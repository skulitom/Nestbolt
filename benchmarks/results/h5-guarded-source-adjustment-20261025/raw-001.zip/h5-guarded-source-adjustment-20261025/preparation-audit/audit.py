"""Independent complete near-feature census and exact projection verification."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape,LineString

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-source-adjustment-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'preparation-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.glob('*.json'))},
        'method':'Reconstruct every original world transform and rational stock-offset bound. Independently enumerate all1246 same-sheet polygon pairs and all near boundary segment pairs, so the complete467-row census cannot omit a local contact. Recompute exact full-segment integer-normal projection gaps and conservative norm ceilings; verify the rational rounded required offset inequality. Prove the0.36mm threshold exceeds the0.2125mm target plus the maximum relative displacement. Check immutable source inputs against committed evidence. Require an independent all-pair/all-stock audit after a candidate, not acceptance from proposal constraints alone.'})
    start=time.perf_counter()
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    manifest=ROOT/'benchmarks/results/h5-circle-stock-neighborhood-20261025/raw-manifest.json';mf=load(manifest);byhash={r['sha256']:r for r in mf['files']+mf['aliases']}
    oldpath=ROOT/'output/h5-conflict-owner-neighborhood-20261025/fixed-originals.json';fixed=load(oldpath);parts=load(BASE/'parts.json');rows=load(BASE/'segment-constraints.json');census=load(BASE/'pair-census.json')
    assert digest(oldpath) in byhash and len(fixed)==len(parts)==57
    g=load(SRC/'geometry.json');stocks=[[F(*v) for v in b] for b in g['stock_bounds_rational']];items=load(SRC/'items.json')
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source'];source=load(sourcepath);jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';job=load(jobpath);family={p['id']:p for p in job['parts']}
    assert digest(sourcepath) in byhash and digest(jobpath) in byhash
    geometries={};segments={};maxerr=0.
    for saved,r in zip(parts,fixed):
        assert saved['item']==r['item'] and saved['original_transform']==r['transform'] and saved['original_geometry']==r['geometry']
        item=items[r['item']];p=source['placements'][item['source_index']];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        polygon=Polygon([(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in family[r['family']]['geometry'][0]['outer']]);actual=shape(saved['original_geometry']);error=actual.hausdorff_distance(polygon);assert error<1e-7;maxerr=max(maxerr,error)
        geometries[r['item']]=actual;coords=list(actual.exterior.coords);segments[r['item']]=[([list(a),list(b)],LineString([a,b])) for a,b in zip(coords,coords[1:])]
        b=list(map(F,actual.bounds));st=stocks[r['sheet']];m=F(1,80)
        bounds=[max(-500,math.ceil((st[0]+m-b[0])*10000)),max(-500,math.ceil((st[1]+m-b[1])*10000)),
                min(500,math.floor((st[2]-m-b[2])*10000)),min(500,math.floor((st[3]-m-b[3])*10000))]
        assert bounds==saved['offset_bounds_units'] and bounds[0]<=bounds[2] and bounds[1]<=bounds[3]
    assert (F(36,100)-F(2125,10000))**2>8*F(5,100)**2
    expected=[];nearrows=[];tested=0
    for a,b in combinations(fixed,2):
        if a['sheet']!=b['sheet']:continue
        distance=geometries[a['item']].distance(geometries[b['item']]);indices=[]
        if distance<.36:
            for ai,(ap,sa) in enumerate(segments[a['item']]):
                for bi,(bp,sb) in enumerate(segments[b['item']]):
                    tested+=1;d=sa.distance(sb)
                    if d<.36:
                        indices.append(len(nearrows));nearrows.append((a['item'],b['item'],ai,bi,ap,bp,d))
        expected.append({'items':[a['item'],b['item']],'distance_mm':distance,'near':distance<.36,'constraint_indices':indices})
    assert census==expected and len(rows)==len(nearrows)==467
    for i,(row,near) in enumerate(zip(rows,nearrows)):
        a,b,ai,bi,ap,bp,d=near;assert row['index']==i and row['items']==[a,b] and row['segments']==[ai,bi] and row['segment_a']==ap and row['segment_b']==bp and row['source_distance_mm']==d
        A,B=row['a'],row['b'];assert (A or B) and abs(A)<=10**8 and abs(B)<=10**8
        n=row['normal_norm_upper'];assert (n-1)**2<A*A+B*B<=n*n
        gap=min(A*F(x)+B*F(y) for x,y in bp)-max(A*F(x)+B*F(y) for x,y in ap)
        assert row['exact_source_projection_gap']==[gap.numerator,gap.denominator]
        rhs=math.ceil((F(2125,10000)*n-gap)*10000);assert rhs==row['required_offset_projection_units']
        assert max(abs(rhs),1000*(abs(A)+abs(B)))<2**60
    assert time.perf_counter()-start<120
    write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_transforms':57,'maximum_transform_error_mm':maxerr,
        'original_pairs':len(expected),'near_pairs':sum(r['near'] for r in expected),'segment_pairs_examined':tested,
        'all_local_contact_constraints':len(rows),'rational_stock_bounds':57,'exact_integer_projection_inequalities':467,
        'far_feature_displacement_bound_verified':True,'full_geometry_validation_still_required':True,'solver_calls':0,'H5_complete':False})
    print(load(OUT/'checks.json'),flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
