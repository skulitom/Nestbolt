"""Bounded small translations with sufficient local segment separation proposals."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback
from shapely.geometry import shape,LineString
from shapely.ops import nearest_points

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
CIRCLE=ROOT/'output/h5-circle-stock-neighborhood-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OUT=ROOT/'output/h5-guarded-source-adjustment-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def normceil(a,b):
    n=math.isqrt(a*a+b*b);return n if n*n==a*a+b*b else n+1

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[OLD/'fixed-originals.json',OLD/'plan.json',SRC/'geometry.json',SRC/'items.json',SRC/'propagation.json',
        CIRCLE/'original-outline-construction/audit/checks.json',CIRCLE/'original-outline-construction/native-margin-shortfalls.json',
        CIRCLE/'original-outline-construction/audit/fixed-stock-guard-shortfalls.json',
        ROOT/'crates/core/src/construct.rs',ROOT/'crates/core/src/sheets.rs',ROOT/'benchmarks/results/h5-circle-stock-neighborhood-20261025/raw-manifest.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'preparation_limit_seconds':120,'maximum_segment_constraints':200000,'offset_units_per_mm':10000,'maximum_axis_offset_units':500,
        'target_original_pair_gap_mm':.2125,'target_extra_stock_margin_mm':.0125,'near_pair_threshold_mm':.36,
        'normal_coefficient_scale':10**8,'required_originals':66,'baseline_originals':57,'other_mandatory_originals':9,
        'method':'Prepare one distinct small-adjustment construction for the57 previously fixed originals. Each retains its original shape, orientation, sheet and copy, with each axis translation bounded to+/-0.05mm on a0.0001mm grid. Intersect those bounds with rational inward stock constraints requiring0.0125mm extra margin. For every same-sheet polygon pair within0.36mm, examine every boundary segment pair within0.36mm. The closest-point direction proposes a fixed separating normal; round that normal to integer coefficients and compute exact rational full-segment projection gaps, using an integer ceiling of its norm for a conservative0.2125mm target. Far original features are not assumed safe without the final full-geometry check. These local projection constraints are a proposal mechanism; only independent reconstruction of every moved original pair and stock edge can qualify the adjusted baseline geometry. No counts or native guards are reduced. No solver call in preparation.'})
    start=time.perf_counter();fixed=load(OLD/'fixed-originals.json');g=load(SRC/'geometry.json');stock=[[F(*v) for v in b] for b in g['stock_bounds_rational']]
    assert len(fixed)==57;polys={r['item']:shape(r['geometry']) for r in fixed};segments={};variables=[]
    for r in fixed:
        poly=polys[r['item']];pts=list(poly.exterior.coords);assert not poly.interiors
        segments[r['item']]=[(list(a),list(b),LineString([a,b])) for a,b in zip(pts,pts[1:])]
        b=list(map(F,poly.bounds));st=stock[r['sheet']];extra=F(125,10000)
        bounds=[max(-500,math.ceil((st[0]+extra-b[0])*10000)),max(-500,math.ceil((st[1]+extra-b[1])*10000)),
                min(500,math.floor((st[2]-extra-b[2])*10000)),min(500,math.floor((st[3]-extra-b[3])*10000))]
        assert bounds[0]<=bounds[2] and bounds[1]<=bounds[3]
        variables.append({'item':r['item'],'family':r['family'],'sheet':r['sheet'],'source_index':r['source_index'],
            'original_transform':r['transform'],'original_geometry':r['geometry'],'offset_bounds_units':bounds})
    write(OUT/'parts.json',variables);rows=[];pairrows=[];segmenttests=0;minimum_gap=float('inf')
    for a,b in combinations(fixed,2):
        assert time.perf_counter()-start<120
        if a['sheet']!=b['sheet']:continue
        distance=polys[a['item']].distance(polys[b['item']]);minimum_gap=min(minimum_gap,distance);near=distance<.36
        ids=[]
        if near:
            for ai,(a0,a1,sa) in enumerate(segments[a['item']]):
                for bi,(b0,b1,sb) in enumerate(segments[b['item']]):
                    segmenttests+=1;d=sa.distance(sb)
                    if d>=.36:continue
                    pa,pb=nearest_points(sa,sb);nx,ny=pb.x-pa.x,pb.y-pa.y;length=math.hypot(nx,ny);assert length>0
                    A,B=round(nx/length*10**8),round(ny/length*10**8);norm=normceil(A,B)
                    ap=[A*F(x)+B*F(y) for x,y in [a0,a1]];bp=[A*F(x)+B*F(y) for x,y in [b0,b1]]
                    gap=min(bp)-max(ap);rhs=math.ceil(10000*(F(2125,10000)*norm-gap));assert max(abs(rhs),2*(abs(A)+abs(B))*500)<2**60
                    ids.append(len(rows));rows.append({'index':len(rows),'items':[a['item'],b['item']],'segments':[ai,bi],
                        'segment_a':[a0,a1],'segment_b':[b0,b1],'source_distance_mm':d,'nearest_points':[[pa.x,pa.y],[pb.x,pb.y]],
                        'a':A,'b':B,'normal_norm_upper':norm,'exact_source_projection_gap':[gap.numerator,gap.denominator],
                        'required_offset_projection_units':rhs})
                    assert len(rows)<=200000 and time.perf_counter()-start<120
        pairrows.append({'items':[a['item'],b['item']],'distance_mm':distance,'near':near,'constraint_indices':ids})
    write(OUT/'segment-constraints.json',rows);write(OUT/'pair-census.json',pairrows)
    checks={'preparation_complete':True,'seconds':time.perf_counter()-start,'baseline_originals':57,'required_originals':66,
        'original_pairs_examined':len(pairrows),'near_original_pairs':sum(r['near'] for r in pairrows),'segment_pairs_examined':segmenttests,
        'segment_separation_constraints':len(rows),'minimum_original_gap_mm':minimum_gap,'maximum_axis_offset_mm':.05,
        'target_pair_gap_mm':.2125,'target_extra_stock_margin_mm':.0125,'counts_sheets_orientations_preserved':True,
        'full_original_geometry_audit_required_after_candidate':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'preparation.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
