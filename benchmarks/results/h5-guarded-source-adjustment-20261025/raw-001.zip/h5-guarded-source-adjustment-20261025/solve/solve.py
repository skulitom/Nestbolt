"""One bounded minimum-translation proposal with a full protobuf oracle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,shutil,sys,time,traceback
import ortools
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from google.protobuf import text_format

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-source-adjustment-20261025';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def verify(actual,parts,rows):
    vi=ci=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);vi+=1;return vi-1
    def linear(terms,lo,hi):
        nonlocal ci
        merged=Counter()
        for i,c in terms:merged[i]+=c
        ids=sorted(i for i,c in merged.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(merged[i] for i in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    mapping=[];absolute=[]
    for p in parts:
        tag=f"item{p['item']}";loX,loY,hiX,hiY=p['offset_bounds_units']
        dx=var(tag+'-dx',loX,hiX);dy=var(tag+'-dy',loY,hiY);ax=var(tag+'-abs-x',0,500);ay=var(tag+'-abs-y',0,500)
        linear([(dx,1),(ax,-1)],-2**63,0);linear([(dx,-1),(ax,-1)],-2**63,0)
        linear([(dy,1),(ay,-1)],-2**63,0);linear([(dy,-1),(ay,-1)],-2**63,0)
        mapping.append({'item':p['item'],'dx':dx,'dy':dy,'abs_x':ax,'abs_y':ay});absolute.extend([ax,ay])
    byid={p['item']:p for p in mapping}
    for r in rows:
        a,b=[byid[i] for i in r['items']];A,B=r['a'],r['b']
        linear([(b['dx'],A),(a['dx'],-A),(b['dy'],B),(a['dy'],-B)],r['required_offset_projection_units'],2**63-1)
    assert vi==len(actual.variables)==228 and ci==len(actual.constraints)==695
    obj=actual.objective;assert dict(zip(obj.vars,obj.coeffs))=={i:1 for i in absolute} and len(obj.vars)==114 and obj.scaling_factor==1 and obj.offset==0
    assert {f.name for f,v in obj.ListFields()}=={'vars','coeffs','scaling_factor'}
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual)
    for name in ['variables','constraints','objective']:extra.ClearField(name)
    assert not extra.ListFields()
    return mapping,{'variables':vi,'constraints':ci,'offset_variables':114,'absolute_value_auxiliaries':114,
        'absolute_value_inequalities':228,'original_segment_projection_constraints':467,'objective_absolute_offsets':114,
        'original_parts':57,'optional_parts':0,'source_position_hints':0,'original_sheets_and_rotations_unchanged':True}

def main():
    assert load(BASE/'preparation-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    parts=load(BASE/'parts.json');rows=load(BASE/'segment-constraints.json');params={'max_time_in_seconds':10,'num_search_workers':8,'random_seed':0,
        'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/n for n in ['plan.json','parts.json','segment-constraints.json','preparation-audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'parameters':params,'maximum_solver_calls':1,'construction_and_audit_limit_seconds':120,
        'method':'All57 original parts receive mandatory bounded translations; shapes, sheets and rotations are unchanged. Minimize the sum of absolute axis offsets on the declared0.0001mm grid using two linear lower bounds per absolute value. Enforce every independently audited local segment projection inequality and the exact inward stock offset bounds. Verify every protobuf variable, constraint, objective and parameter before one10-second/eight-worker/seed-zero call. This proposes an adjusted baseline only; independent full original-geometry checks are required before use.'})
    start=time.perf_counter();model=cp_model.CpModel();mapping=[];allvars=[];absvars=[]
    for p in parts:
        tag=f"item{p['item']}";b=p['offset_bounds_units']
        dx=model.new_int_var(b[0],b[2],tag+'-dx');dy=model.new_int_var(b[1],b[3],tag+'-dy')
        ax=model.new_int_var(0,500,tag+'-abs-x');ay=model.new_int_var(0,500,tag+'-abs-y')
        allvars.extend([dx,dy,ax,ay]);absvars.extend([ax,ay])
        model.add(dx-ax<=0);model.add(-dx-ax<=0);model.add(dy-ay<=0);model.add(-dy-ay<=0)
        mapping.append({'item':p['item'],'dx':dx.index,'dy':dy.index,'abs_x':ax.index,'abs_y':ay.index})
    byid={r['item']:r for r in mapping}
    for row in rows:
        a,b=[byid[i] for i in row['items']]
        model.add(row['a']*(allvars[b['dx']]-allvars[a['dx']])+row['b']*(allvars[b['dy']]-allvars[a['dy']])>=row['required_offset_projection_units'])
    model.minimize(sum(absvars));assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',mapping)
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());expected,stats=verify(actual,parts,rows);assert expected==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    elapsed=time.perf_counter()-start;assert elapsed<120
    write(OUT/'model-audit.json',{'passed':True,'construction_and_audit_seconds':elapsed,**stats,'model_sha256':digest(OUT/'model.pb'),
        'parameters_sha256':digest(OUT/'parameters.pbtxt'),'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    def positions(value):return [{'item':r['item'],'dx_units':value(allvars[r['dx']]),'dy_units':value(allvars[r['dy']])} for r in mapping]
    records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            p=positions(self.value);write(OUT/f'incumbent-{len(records)}.json',p)
            records.append({'index':len(records),'seconds':self.wall_time,'objective_units':self.objective_value});print(records[-1],flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':10,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush());start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if feasible:write(OUT/'offsets.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':seconds,'solver_calls':1,'incumbents':records,'has_baseline_proposal':feasible,
        'objective_units':solver.objective_value if feasible else None,'response_stats':solver.response_stats(),
        'full_original_geometry_audit_pending':feasible,'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
