"""Independent backward count recurrence, exact source area and scope readback."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-short-frontier-20261026';OUT=BASE/'audit';OLD=ROOT/'output/h5-core-sequence-bound-20261026';GEO=ROOT/'output/h5-rotation-independent-geometry-20261026';SUP=ROOT/'output/h5-all-angle-support-bounds-20261026';PARENT=ROOT/'output/h5-stem-ordered-nine-decision-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for record in [plan,load(OLD/'plan.json')]:
    for n,h in record['inputs'].items():assert digest(ROOT/n)==h,n
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in list(BASE.iterdir()) if p.is_file()},'method':'Recompute all81 pair lower bounds, independently merging the integer forbidden intervals for every ordered bracket pair. Check fresh outward-target anchor floors and universal support margins. Independently derive forward Bellman minima and backward maxima over every available count, compare every transition and witness prefix, and cross-check count survival. Independently triangulate original filled outlines using exact binary coordinates, enumerate all4576 allocations and first-sheet complements, and verify their reasons and necessary Pareto frontier. No solver or source-witness claim.'})
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};stock=[F(*v) for v in plan['stock_bounds_rational']];relaxed=[F(*v) for v in plan['relaxed_stock_bounds_rational']];assert stock==[F('6.5'),F('6.5'),F('1493.5'),F('319.42699')] and relaxed==[stock[0]-F('.02'),stock[1]-F('.02'),stock[2]+F('.02'),stock[3]+F('.02')]
assert stock[3]>F(*load(GEO/'plan.json')['stock_bounds_rational'][3]);profiles={r['index']:r for r in load(GEO/'profiles.json')};stems={r['profile']:r['stem_bounds_units1000'] for r in load(SUP/'bracket-direction-bounds.json')};directions={r['profile']:r for r in load(PARENT/'direction-requirements.json') if r['parts']==[0,7]};anchor={}
for p in range(8):
    ob=[F(v) for v in profiles[p]['original_bounds']];anchor[str(p)]=[int((relaxed[a]-ob[a])*1000//1) for a in range(4)]
proof=load(GEO/'original-cog-proof.json');h=proof['all_angle_stock_support_radius_units1000'];anchor['11']=[int((relaxed[a]*1000+(h if a<2 else -h))//1) for a in range(4)];assert anchor==load(BASE/'anchor-bounds.json') and all(v==load(GEO/'anchor-bounds.json')[k] for k,v in anchor.items())
domains={p:[anchor[str(p)][0]+(stems[p][0] if p<8 else 0),anchor[str(p)][2]+(stems[p][0] if p<8 else 0)] for p in list(range(8))+[11]};assert {str(k):v for k,v in domains.items()}==load(BASE/'coordinate-domains.json');distance={};unions=[];paircount=0
for p,q in product(domains,repeat=2):
    if p<8 and q<8:
        a,b=stems[p],stems[q];delta=[anchor[str(q)][1]-anchor[str(p)][3],anchor[str(q)][3]-anchor[str(p)][1]];intervals=[]
        # Every possible stem crosses the same horizontal line, ensuring strict X order.
        assert anchor[str(p)][3]+a[1]<160000<anchor[str(p)][1]+a[3]
        for r in profiles[p]['rectangles_units1000']+[a]:
            for s in profiles[q]['rectangles_units1000']+[b]:
                if delta[0]+s[3]>r[1] and delta[1]+s[1]<r[3]:intervals.append([r[0]-s[2]+b[0]-a[0]+1,r[2]-s[0]+b[0]-a[0]-1]);paircount+=1
        merged=[]
        for lo,hi in sorted(intervals):
            if lo>hi:continue
            if merged and lo<=merged[-1][1]+1:merged[-1][1]=max(hi,merged[-1][1])
            else:merged.append([lo,hi])
        gap=a[2]-a[0]
        for lo,hi in merged:
            if lo<=gap<=hi:gap=hi+1
        unions.append({'profiles':[p,q],'closed_forbidden_union':merged,'minimum_distance':gap})
    elif p==q==11:
        cert=load(ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json');assert cert['passed'] and cert['all_real_angles'] if 'all_real_angles' in cert else cert['full_circle_cells_verified']==720
        d=cert['rounded_center_separation_units1000'];dy=anchor['11'][3]-anchor['11'][1];rad=d*d-dy*dy;gap=math.isqrt(rad-1)+1;assert (gap-1)**2<rad<=gap*gap
    elif q==11:gap=directions[p]['right']-stems[p][0]
    else:gap=stems[q][0]-directions[q]['left']
    assert gap>0;distance[p,q]=gap
assert [{'profiles':[p,q],'minimum_distance':v} for (p,q),v in sorted(distance.items())]==load(BASE/'pair-distances.json')
# Recheck that the support-vertex transverse range still lies inside every stem
# under the slightly enlarged continuous stock, rather than assuming old bounds.
beta=load(SUP/'cog-spacing-proof.json')['support_transverse_bound_units1000'];support_margins=[]
for p in range(8):
    ob=[F(v)*1000 for v in profiles[p]['original_bounds']];stem=stems[p];lo=(relaxed[1]*1000+h)-(relaxed[3]*1000-ob[3]);hi=(relaxed[3]*1000-h)-(relaxed[1]*1000-ob[1]);margins=[lo-beta-stem[1],stem[3]-hi-beta];assert min(margins)>0;support_margins.append({'profile':p,'margins_rational':[ratio(v) for v in margins]})
forward={};backward={};types=list(domains)
for total in range(1,28):
    for b in range(13):
        c=total-b
        if not 0<=c<=15:continue
        for p in types:
            prev=(b-int(p<8),c-int(p==11))
            if min(prev)<0:continue
            lo,hi=domains[p]
            if prev==(0,0):earliest,latest=lo,hi
            else:
                earliest=min([max(lo,forward[(*prev,q)]+distance[q,p]) for q in types if (*prev,q) in forward],default=hi+1)
                latest=max([min(hi,backward[(*prev,q)]-distance[p,q]) for q in types if (*prev,q) in backward],default=lo-1)
            if earliest<=hi:forward[b,c,p]=earliest
            if latest>=lo:backward[b,c,p]=latest
assert forward=={tuple(r['key']):r['earliest'] for r in load(BASE/'forward-states.json')}
for b,c in product(range(13),range(16)):assert any(k[:2]==(b,c) for k in forward)==any(k[:2]==(b,c) for k in backward)
for row in load(BASE/'forward-states.json'):
    ps,xs=row['profiles'],row['coordinates'];b,c,p=row['key'];assert len(ps)==len(xs)==b+c and ps[-1]==p and xs[-1]==row['earliest'];assert sum(v<8 for v in ps)==b and sum(v==11 for v in ps)==c;assert all(domains[p][0]<=x<=domains[p][1] for p,x in zip(ps,xs));assert all(y-x>=distance[p,q] for p,q,x,y in zip(ps,ps[1:],xs,xs[1:]))
expected=[]
for (b,c,p),x in forward.items():
    for q in types:
        nb,nc=b+int(q<8),c+int(q==11)
        if nb<=12 and nc<=15 and b+c<27:
            y=max(domains[q][0],x+distance[p,q]);expected.append({'from':[b,c,p],'to':[nb,nc,q],'earliest':y,'within_domain':y<=domains[q][1]})
key=lambda r:(r['from'],r['to']);assert sorted(expected,key=key)==sorted(load(BASE/'transitions.json'),key=key)
def area(ring):
    pts=[(F(x),F(y)) for x,y in ring];o=pts[0];return abs(sum((p[0]-o[0])*(q[1]-o[1])-(p[1]-o[1])*(q[0]-o[0]) for p,q in zip(pts[1:-1],pts[2:])))/2
areas={k:sum(area(g['outer']) for g in p['geometry']) for k,p in parts.items()};available=(stock[2]-stock[0])*(stock[3]-stock[1]);ap=load(BASE/'area-proof.json');assert ap['filled_source_areas_rational']=={k:ratio(v) for k,v in areas.items()} and ap['stock_area_rational']==ratio(available) and ap['holes_reserved']
frame=parts['frame'];assert frame['rotations']['degrees']==[0.,90.,180.,270.] and not frame['allow_mirror'];ring=frame['geometry'][0]['outer'];dims=[max(F(p[k]) for p in ring)-min(F(p[k]) for p in ring) for k in [0,1]];assert min(dims)>stock[3]-stock[1]
front=load(BASE/'frontier.json');assert len(front)==208;observed=load(BASE/'allocations.json');expected=[];survivors=[];max_cogs=[]
for b,c in product(range(13),range(16)):
    alive=(b==c==0) or any(k[:2]==(b,c) for k in backward);budget=available-b*areas['bracket']-c*areas['cog'];cap=min(21,int(budget//areas['insert'])) if alive else -1
    assert front[b*16+c]=={'brackets':b,'cogs':c,'ordered_projection_survives':alive,'maximum_inserts_from_area':max(-1,cap),'actual_source_fit_claimed':False}
    for i in range(22):
        why='ordered_projection' if not alive else 'filled_outer_area' if b*areas['bracket']+c*areas['cog']+i*areas['insert']>available else None;expected.append({'short_counts':[b,i,c],'first_counts':[18,12-b,21-i,15-c],'excluded_by':why})
        if why is None:survivors.append([b,i,c])
assert observed==expected and len(expected)==4576
pareto=[r for r in survivors if not any(q!=r and all(a>=b for a,b in zip(q,r)) for q in survivors)];assert pareto==load(BASE/'pareto-necessary-counts.json')
for b in range(13):max_cogs.append({'short_brackets':b,'maximum_cogs_from_projection':max([c for c in range(16) if (b==c==0) or any(k[:2]==(b,c) for k in backward)],default=-1)})
write(OUT/'independent-forbidden-unions.json',unions);write(OUT/'support-margins.json',support_margins);write(OUT/'backward-latest-states.json',[{'key':list(k),'latest':v} for k,v in sorted(backward.items())]);write(OUT/'maximum-cog-counts.json',max_cogs)
write(OUT/'necessity-proof.json',{'stock_bounds_rational':plan['stock_bounds_rational'],'all_available_original_counts':True,'fixed_first_sheet_assumed':False,'all_real_cog_angles':True,'all_continuous_anchors':True,'frames_must_be_on_first_sheet_for_this_two_sheet_target':True,'statement':'Each original source layout maps to the already source-contained quantized rectangles and rounded cog centers. The slightly enlarged continuous target yields exactly the same integer anchor domains; support-vertex transverse margins remain positive. Every bracket stem crosses Y160mm, and bracket/cog support separation and positive cog spacing enforce a strict total X order. Guaranteed-Y rectangle overlaps give necessary ordered bracket gaps. The new full-circle cog certificate and the entire rounded vertical range give the exact integer horizontal lower bound251956. Every source layout therefore maps to one of the complete all-count ordered paths. Forward earliest and backward latest recurrences independently cover all8 bracket modes and every count up to12/15, with no nonadjacent or insert constraints needed for the negative implication. Filled-outer area independently bounds each insert count when holes are reserved. Excluded allocations are impossible within this declared short-sheet target; surviving allocations are only necessary and have no source witness. Their first-sheet complementary counts preserve all66 originals. The whole job remains unresolved.','surviving_allocations_are_feasible':False,'whole_job_excluded':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'pair_bounds_recomputed':81,'guaranteed_y_pairs':paircount,'forward_states_verified':len(forward),'backward_states_verified':len(backward),'transitions_verified':len(expected) if False else len(load(BASE/'transitions.json')),'all_count_pairs_verified':208,'all_allocations_verified':4576,'excluded_ordered_projection':sum(r['excluded_by']=='ordered_projection' for r in observed),'excluded_filled_outer_area':sum(r['excluded_by']=='filled_outer_area' for r in observed),'necessary_survivors':len(survivors),'pareto_necessary_count_vectors':len(pareto),'fresh_outward_target_has_same_integer_domains':True,'all66_count_complements_verified':True,'fixed_first_sheet_assumed':False,'source_witness_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'));print(max_cogs)
