"""All-copy short-sheet necessary count frontier, independent of a first-sheet core."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-global-short-frontier-20261026';OLD=ROOT/'output/h5-core-sequence-bound-20261026';GEO=ROOT/'output/h5-rotation-independent-geometry-20261026';CERT=ROOT/'output/h5-cog-pair-rotation-certificate-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[JOB]+[OLD/n for n in ['plan.json','coordinate-domains.json','pair-distance-bounds.json','audit/checks.json','audit/necessity-proof.json']]+[GEO/n for n in ['plan.json','profiles.json','anchor-bounds.json','original-cog-proof.json','audit/checks.json','audit/necessity-proof.json']]+[CERT/n for n in ['plan.json','audit/checks.json']]
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
stock=[F('6.5'),F('6.5'),F('1493.5'),F('319.42699')];relaxed=[stock[0]-F('.02'),stock[1]-F('.02'),stock[2]+F('.02'),stock[3]+F('.02')]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'stock_bounds_rational':[ratio(x) for x in stock],'relaxed_stock_bounds_rational':[ratio(x) for x in relaxed],'bracket_count_range':[0,12],'cog_count_range':[0,15],'insert_count_range':[0,21],'method':'Expand the necessary ordered horizontal projection to every available bracket/cog count, with no fixed first-sheet arrangement. Recompute floor-anchor bounds for an outward target upper edge319.42699mm and verify they equal the previously proved domains. Reuse only intrinsic bracket/stem and mixed-pair distances, strengthening cog/cog horizontal spacing with the audited full-circle254.297mm rounded-center distance and the entire vertical domain. Complete earliest-position dynamic programming covers all8 bracket modes and all real cog angles. Combine projected count survival with exact filled-source outer areas for every0..21 insert count. This is a necessary frontier, not source feasibility. Frames cannot fit this short height in any allowed quarter turn. Every original count is retained via complementary first-sheet counts. No solver/native calls; no unrestricted whole-job exclusion.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};assert {k:p['quantity'] for k,p in parts.items()}=={'bracket':12,'cog':15,'frame':18,'insert':21}
profiles={r['index']:r for r in load(GEO/'profiles.json')};anchor={}
for p in range(8):
    ob=[F(v) for v in profiles[p]['original_bounds']];anchor[str(p)]=[math.floor((relaxed[a]-ob[a])*1000) for a in range(2)]+[math.floor((relaxed[a+2]-ob[a+2])*1000) for a in range(2)]
h=load(GEO/'original-cog-proof.json')['all_angle_stock_support_radius_units1000'];anchor['11']=[math.floor(relaxed[a]*1000+h) for a in range(2)]+[math.floor(relaxed[a+2]*1000-h) for a in range(2)];assert all(v==load(GEO/'anchor-bounds.json')[k] for k,v in anchor.items())
domains={int(p):v for p,v in load(OLD/'coordinate-domains.json').items()};oldedges=load(OLD/'pair-distance-bounds.json');distance={tuple(r['profiles']):r['minimum_distance'] for r in oldedges};D=load(CERT/'audit/checks.json')['rounded_center_separation_units1000'];dy=anchor['11'][3]-anchor['11'][1];radicand=D*D-dy*dy;dx=math.isqrt(radicand);dx+=dx*dx<radicand;assert (dx-1)**2<radicand<=dx*dx and dx>distance[11,11];previous_dx=distance[11,11];distance[11,11]=dx
write(OUT/'coordinate-domains.json',domains);write(OUT/'anchor-bounds.json',anchor);write(OUT/'pair-distances.json',[{'profiles':[p,q],'minimum_distance':v} for (p,q),v in sorted(distance.items())]);write(OUT/'cog-spacing.json',{'rounded_center_distance':D,'maximum_vertical_difference':dy,'squared_horizontal_lower':radicand,'integer_horizontal_lower':dx,'previous_horizontal_lower':previous_dx})
states={};transitions=[]
for p,(lo,hi) in domains.items():states[int(p<8),int(p==11),p]={'earliest':lo,'profiles':[p],'coordinates':[lo]}
for total in range(1,27):
    for (b,c,p),value in sorted(list(states.items())):
        if b+c!=total:continue
        for q,(lo,hi) in domains.items():
            nb,nc=b+int(q<8),c+int(q==11)
            if nb>12 or nc>15:continue
            x=max(lo,value['earliest']+distance[p,q]);valid=x<=hi;transitions.append({'from':[b,c,p],'to':[nb,nc,q],'earliest':x,'within_domain':valid})
            if valid and ((nb,nc,q) not in states or x<states[nb,nc,q]['earliest']):states[nb,nc,q]={'earliest':x,'profiles':value['profiles']+[q],'coordinates':value['coordinates']+[x]}
write(OUT/'forward-states.json',[{'key':list(k),**v} for k,v in sorted(states.items())]);write(OUT/'transitions.json',transitions)
def area(r):return abs(sum(F(x)*F(v)-F(y)*F(u) for (x,y),(u,v) in zip(r,r[1:]+r[:1])))/2
areas={k:sum(area(g['outer']) for g in p['geometry']) for k,p in parts.items()};available=(stock[2]-stock[0])*(stock[3]-stock[1]);write(OUT/'area-proof.json',{'filled_source_areas_rational':{k:ratio(v) for k,v in areas.items()},'stock_area_rational':ratio(available),'holes_reserved':True,'clearance_omitted':True})
frontier=[];allocations=[]
for b in range(13):
    for c in range(16):
        surviving=(b==c==0) or any(k[:2]==(b,c) for k in states);budget=available-b*areas['bracket']-c*areas['cog'];cap=min(21,math.floor(budget/areas['insert'])) if surviving else -1
        frontier.append({'brackets':b,'cogs':c,'ordered_projection_survives':surviving,'maximum_inserts_from_area':max(-1,cap),'actual_source_fit_claimed':False})
        for i in range(22):
            reason='ordered_projection' if not surviving else 'filled_outer_area' if i>cap else None
            allocations.append({'short_counts':[b,i,c],'first_counts':[18,12-b,21-i,15-c],'excluded_by':reason})
survivors=[r['short_counts'] for r in allocations if r['excluded_by'] is None];pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)]
write(OUT/'frontier.json',frontier);write(OUT/'allocations.json',allocations);write(OUT/'pareto-necessary-counts.json',pareto)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'ordered_profile_types':9,'ordered_pair_bounds':81,'states':len(states),'transitions':len(transitions),'count_pairs':len(frontier),'all_allocations':len(allocations),'excluded_ordered_projection':sum(r['excluded_by']=='ordered_projection' for r in allocations),'excluded_filled_outer_area':sum(r['excluded_by']=='filled_outer_area' for r in allocations),'necessary_survivors':len(survivors),'pareto_necessary_count_vectors':len(pareto),'stronger_cog_horizontal_gap_units1000':dx,'all_original_counts_retained':True,'fixed_first_sheet_assumed':False,'actual_source_fit_claimed':False,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'));print('Pareto necessary counts [bracket,insert,cog]:',pareto)
