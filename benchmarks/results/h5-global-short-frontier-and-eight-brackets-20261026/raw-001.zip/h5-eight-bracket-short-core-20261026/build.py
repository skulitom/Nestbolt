"""A concrete eight-bracket/five-insert short sheet with a wide-row frame core."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,math,shutil
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-eight-bracket-short-core-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';PROFILES=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');inputs=[JOB,SRC/'items.json',SRC/'geometry.json',PROFILES,ROOT/'output/h5-global-short-frontier-20261026/audit/checks.json',ROOT/'output/h5-nine-insert-short-sheet-20261026/short-sheet-placements.json',ROOT/'output/h5-mixed-rows-contact-pool-20261026/response-audit-log-precision-repaired/checks.json'];assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Construct one surviving count allocation rather than assert the necessary frontier is feasible. Put four previously verified bracket-pair/insert patterns side by side, plus one vertical insert on the right: eight brackets and five inserts on the short sheet. Use original IDs18..25 and30..34. First sheet has18 unturned frames in3 columns/6 rows and11 vertical inserts35..45 beside them. All four brackets26..29, five inserts46..50 and15 cogs51..65 stay mandatory. This changes both the short allocation and first core from the just-closed mixed-row contact call. No old source exclusions transfer, no solver/native call, and no claim of a better total partial count than64.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');profiles={p['index']:p for p in load(PROFILES)};rows=[];anchors=[]
def add(i,sheet,a,mirror,x,y,role):
    family=items[i]['family'];c,s=math.cos(a),math.sin(a);m=-1 if mirror else 1;g=affine_transform(Polygon(parts[family]['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0]);b=g.bounds;t={'rotation_radians':a,'mirrored':mirror,'translation':[x-b[0],y-b[1]]};rows.append({'part_id':family,'copy_index':items[i]['copy'],'sheet_id':f'sheet-{sheet}','transform':t});anchors.append({'original':i,'sheet':sheet,'lower_left':[x,y],'angle':a,'mirror':mirror,'role':role})
for i in range(18):r,c=divmod(i,3);add(i,0,0.,False,6.525+c*450.225,6.525+r*350.225,'wide frame row')
for k in range(11):add(35+k,0,math.pi/2,False,1357.2,6.525+k*180.225,'side insert')
for k in range(4):
    x=6.525+k*330.675
    for i,profile,xx,yy in [(18+2*k,7,x,6.525),(19+2*k,5,x+80.45,19.),(30+k,10,x+75.225,106.75)]:p=profiles[profile];add(i,1,p['rotation_radians'],p['mirrored'],xx,yy,'bracket pair and inter-part insert')
add(34,1,math.pi/2,False,1329.225,6.525,'right vertical insert')
ids={(p['family'],p['copy']):i for i,p in enumerate(items)};placed=[ids[p['part_id'],p['copy_index']] for p in rows];remaining=sorted(set(range(66))-set(placed));assert len(set(placed))==len(rows)==42 and remaining==list(range(26,30))+list(range(46,66))
write(OUT/'placements.json',rows);write(OUT/'anchors.json',anchors);write(OUT/'first-sheet-placements.json',[p for p in rows if p['sheet_id']=='sheet-0']);write(OUT/'short-sheet-placements.json',[p for p in rows if p['sheet_id']=='sheet-1']);write(OUT/'mandatory-remaining-originals.json',remaining);write(OUT/'result.json',{'first_originals':29,'short_originals':13,'short_counts':{'bracket':8,'insert':5},'mandatory_moving_counts':dict(Counter(items[i]['family'] for i in remaining)),'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
