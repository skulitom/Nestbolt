"""Read every original source ring and reconstruct all new core anchors independently."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-bracket-short-core-20261026';OUT=BASE/'audit';SRC=ROOT/'output/h5-source-orientation-construction-20261025';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};rows=load(BASE/'placements.json');first=[p for p in rows if p['sheet_id']=='sheet-0'];short=[p for p in rows if p['sheet_id']=='sheet-1'];assert len(first)==29 and len(short)==13;stocks=[[float(F(*v)) for v in r] for r in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);shapes={};stock=[];holes=vertices=0;actual_anchors=[]
for p in rows:
    i=ids[p['part_id'],p['copy_index']];assert i not in shapes;t=p['transform'];part=parts[p['part_id']];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=part['geometry'][0]
    def ring(vs):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in vs]
    filled=Polygon(ring(g['outer']));full=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])]);assert filled.is_valid and full.is_valid;assert abs(filled.area-Polygon(g['outer']).area)<1e-6 and abs(full.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6;sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;stock.append({'original':i,'extra_mm':extra});shapes[i]=(sheet,filled);holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]))
    if i<18:r,col=divmod(i,3);x=F('6.525')+col*F('450.225');y=F('6.525')+r*F('350.225');angle=0.;mirror=False
    elif 35<=i<=45:x=F('1357.2');y=F('6.525')+(i-35)*F('180.225');angle=math.pi/2;mirror=False
    elif 18<=i<=25:
        k,partner=divmod(i-18,2);x=F('6.525')+k*F('330.675')+partner*F('80.45');y=F('19') if partner else F('6.525');angle=math.pi/2 if partner else 3*math.pi/2;mirror=True
    elif 30<=i<=33:x=F('6.525')+(i-30)*F('330.675')+F('75.225');y=F('106.75');angle=math.pi;mirror=False
    else:assert i==34;x=F('1329.225');y=F('6.525');angle=math.pi/2;mirror=False
    assert abs(math.remainder(t['rotation_radians']-angle,math.tau))<1e-12 and t['mirrored']==mirror,(i,t,angle,mirror);assert max(abs(b[0]-float(x)),abs(b[1]-float(y)))<1e-9;actual_anchors.append({'original':i,'x':float(x),'y':float(y)})
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>required,(i,j,d);pairs.append({'originals':[i,j],'distance_mm':d})
remaining=sorted(set(range(66))-set(shapes));assert remaining==list(range(26,30))+list(range(46,66))==load(BASE/'mandatory-remaining-originals.json');assert Counter(p['part_id'] for p in short)=={'bracket':8,'insert':5}
area=lambda ps:sum(Polygon(parts[p['part_id']]['geometry'][0]['outer']).area for p in ps);oldshort=load(ROOT/'output/h5-nine-insert-short-sheet-20261026/short-sheet-placements.json');oldarea=area(oldshort);newarea=area(short);assert oldarea==418200 and newarea==419000 and newarea-oldarea==800
inventory={'fixed_first_originals':sorted(ids[p['part_id'],p['copy_index']] for p in first),'fixed_first_placements':first,'fixed_short_originals':sorted(ids[p['part_id'],p['copy_index']] for p in short),'fixed_short_placements':short,'mandatory_moving_first_originals':remaining,'mandatory_moving_first_cogs':list(range(51,66)),'mandatory_moving_first_noncogs':list(range(26,30))+list(range(46,51)),'mandatory_moving_family_counts':{'bracket':4,'insert':5,'cog':15},'all24_movers_mandatory':True,'all66_originals_accounted_once':True,'old_domains_or_exclusions_transferred':False}
write(OUT/'next-neighborhood.json',inventory);write(OUT/'pair-readback.json',pairs);write(OUT/'stock-readback.json',stock);write(OUT/'anchor-readback.json',actual_anchors)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_verified':42,'first_originals':29,'short_originals':13,'short_counts':{'bracket':8,'insert':5},'mandatory_moving_counts':inventory['mandatory_moving_family_counts'],'all66_originals_accounted_once':True,'same_sheet_pairs':len(pairs),'stock_edge_checks':4*len(rows),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'minimum_extra_stock_mm':min(min(p['extra_mm']) for p in stock),'short_filled_area_mm2':newarea,'previous_short_filled_area_mm2':oldarea,'short_filled_area_increase_mm2':800,'highest_fixed_first_y_mm':max(g.bounds[3] for s,g in shapes.values() if s==0),'short_highest_y_mm':max(g.bounds[3] for s,g in shapes.values() if s==1),'short_rightmost_x_mm':max(g.bounds[2] for s,g in shapes.values() if s==1),'all42_anchors_independently_reconstructed':True,'part_in_hole_used':False,'older64_partials_preserved':True,'old_exclusions_transferred':False,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
