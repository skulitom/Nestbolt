"""Independent source, convex-hull, cell, edge and complete-cover verification."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from fractions import Fraction as F
from itertools import product
import json,time,math,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-polygon-clearance-20261107';OUT=BASE/'audit'
SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104';RAW=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json';SITES=ROOT/'output/h5-first57-direct-short9-20261104/source-cog-sites.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def turn(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def check_hull(poly,points):
    assert len(poly)>=3 and len(set(poly))==len(poly) and set(poly)<=set(points)
    assert all(turn(poly[i],poly[(i+1)%len(poly)],poly[(i+2)%len(poly)])>0 for i in range(len(poly)))
    for i in range(len(poly)):
        assert all(turn(poly[i],poly[(i+1)%len(poly)],p)>=0 for p in points)
    return len(poly)*len(points)
def gift_wrap(points):
    points=sorted(set(points));first=points[0];p=first;answer=[]
    while True:
        answer.append(p);q=next(v for v in points if v!=p)
        for r in points:
            t=turn(p,q,r)
            if t<0 or (t==0 and sum((r[k]-p[k])**2 for k in range(2))>sum((q[k]-p[k])**2 for k in range(2))):q=r
        p=q
        if p==first:break
        assert len(answer)<=len(points)
    return answer
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
plan=load(BASE/'plan.json');inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',JOB,PIECES,SITES,SRC/'audit/exact-source-partitions.json'}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h,p
for prior in [SRC/'audit',RAW/'audit',ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106/audit']:
    assert load(prior/'checks.json')['passed'];inputs.add(prior/'plan.json');inputs.add(prior/'checks.json')
    for p,h in load(prior/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
process=load(ROOT/'output/h5-six-polygon-clearance-process-20261107/prepare.json')
assert process['passed'] and process['job']['active_processes']==0
inputs.add(ROOT/'output/h5-six-polygon-clearance-process-20261107/prepare.json')
kernel=load(BASE/'kernel.json');K=[tuple(p) for p in kernel['vertices_um']];inputs.add(BASE/'kernel.json')
assert K==[tuple(p) for p in plan['kernel_um']] and len(K)==16
assert all(F(x*x+y*y,10**6)<F(load(JOB)['clearance'])**2 for x,y in K)
assert max(x*x+y*y for x,y in K)==39601
check_hull(K,K)
for old in [(199,0),(-199,0),(0,199),(0,-199)]+list(product([-140,140],repeat=2)):
    assert all(turn(K[i],K[(i+1)%16],old)>=0 for i in range(16))
geom=load(SRC/'geometry-domains.json');raw=load(RAW/'integer-source.json');canonical=load(PIECES)['cog'];sites=load(SITES)
D=int(raw['scaled_units_per_micrometre']);assert D>0
c,s=F(math.cos(raw['rotation_radians'])),F(math.sin(raw['rotation_radians']));m=-1 if raw['mirrored'] else 1
assert raw['cosine_rational']==str(c) and raw['sine_rational']==str(s)
pieces=[]
for poly in canonical:
    transformed=[]
    for x,y in poly:
        point=(1000*D*(m*F(x)*c-F(y)*s),1000*D*(m*F(x)*s+F(y)*c))
        assert all(v.denominator==1 for v in point);transformed.append(tuple(map(int,point)))
    pieces.append(transformed)
assert pieces==[[tuple(map(int,p)) for p in poly] for poly in raw['normalized_cog_pieces']]
shifts=[]
for i,site in enumerate(sites):
    assert raw['sites'][i]['source']==site
    tr=site['transform'];assert tr['rotation_radians']==raw['rotation_radians'] and tr['mirrored']==raw['mirrored']
    delta=[1000*D*F(x) for x in tr['translation']];assert all(v.denominator==1 for v in delta)
    shifts.append(tuple(map(int,delta)));assert list(map(str,shifts[-1]))==raw['sites'][i]['translation_scaled']
assert any(r['family']=='cog' and r['positive_convex_pieces']==21 and r['exact_partition_boundary_and_area'] for r in load(SRC/'audit/exact-source-partitions.json'))
templates=load(BASE/'collision-polygons.json');inputs.add(BASE/'collision-polygons.json');seen=set();polys=[];hull_checks=0
for i,t in enumerate(templates):
    key=(t['geometry'],t['component'],t['source_piece']);assert key not in seen and t['template']==i;seen.add(key)
    g,ri,pi=key;r=geom[g]['inner_rectangles_um'][ri]
    points={(x-u*D+dx*D,y-v*D+dy*D) for (x,y),(u,v),(dx,dy) in product(pieces[pi],product([r[0],r[2]],[r[1],r[3]]),K)}
    poly=[tuple(map(int,p)) for p in t['vertices_scaled']];hull_checks+=check_hull(poly,points);polys.append(poly)
assert seen=={(g['geometry'],ri,pi) for g in geom for ri in range(len(g['inner_rectangles_um'])) for pi in range(len(pieces))}
cells=load(BASE/'cells.json');certs=load(BASE/'certificates.json');inputs.update([BASE/'cells.json',BASE/'certificates.json'])
assert len({(c['geometry'],*c['bounds_um']) for c in cells})==len(cells)
assert all(i==c['cell'] for i,c in enumerate(cells))
corner_checks=0
for i,c in enumerate(certs):
    assert c['certificate']==i and cells[c['cell']]['geometry']==templates[c['template']]['geometry']
    x0,y0,x1,y1=cells[c['cell']]['bounds_um'];assert x0<=x1 and y0<=y1
    sx,sy=shifts[c['site']];poly=polys[c['template']]
    for x,y in product([x0,x1],[y0,y1]):
        for j in range(len(poly)):
            assert turn(poly[j],poly[(j+1)%len(poly)],(x*D-sx,y*D-sy))>0;corner_checks+=1
results=[];pair_polys={};pair_checks=0;all_pairs=0
for row in plan['selection']:
    old=ROOT/row['graph'];folder=BASE/f"choice-{row['refinement_index']:02d}"
    for name in ['nodes.json','kept-old-node-ids.json','removed.json','added-edges.json','root-covers.json','conflicts.bin','checks.json']:inputs.add(folder/name)
    original=load(old/'nodes.json');N=len(original);kept=load(folder/'kept-old-node-ids.json');ns=load(folder/'nodes.json');n=len(ns)
    removed=load(folder/'removed.json');removed_ids=set()
    for r in removed:
        oi=r['old_graph_node'];assert oi not in removed_ids and 0<=oi<N;removed_ids.add(oi)
        cert=certs[r['certificate']];assert cert['site'] not in row['empty_sites'];cell=cells[cert['cell']]
        assert (cell['geometry'],cell['bounds_um'])==(original[oi]['geometry'],original[oi]['bounds_um'])
    assert kept==[i for i in range(N) if i not in removed_ids] and ns==[original[i] for i in kept]
    assert all(v['family'] in [0,1] and v['family']==int(v['geometry']>=8) for v in ns)
    inherited=np.unpackbits(np.frombuffer((old/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(N,(N+7)//8),axis=1,bitorder='little')[:,:N].astype(bool)[np.ix_(kept,kept)]
    expected=inherited.copy();edges=load(folder/'added-edges.json');seen_edges=set()
    for e in edges:
        a,b=e['a'],e['b'];assert 0<=a<b<n and (a,b) not in seen_edges and not inherited[a,b];seen_edges.add((a,b))
        ga,gb=ns[a]['geometry'],ns[b]['geometry'];ri,rj=e['component_a'],e['component_b'];key=(ga,gb,ri,rj)
        if key not in pair_polys:
            ra,rb=geom[ga]['inner_rectangles_um'][ri],geom[gb]['inner_rectangles_um'][rj]
            points={(ax-bx+kx,ay-by+ky) for (ax,ay),(bx,by),(kx,ky) in product(product([ra[0],ra[2]],[ra[1],ra[3]]),product([rb[0],rb[2]],[rb[1],rb[3]]),K)}
            poly=gift_wrap(points);hull_checks+=check_hull(poly,points);pair_polys[key]=poly
        poly=pair_polys[key];A,B=ns[a]['bounds_um'],ns[b]['bounds_um']
        for x,y in product([B[0]-A[2],B[2]-A[0]],[B[1]-A[3],B[3]-A[1]]):
            for j in range(len(poly)):
                assert turn(poly[j],poly[(j+1)%len(poly)],(x,y))>0;pair_checks+=1
        expected[a,b]=expected[b,a]=True
    packed=np.frombuffer((folder/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(n,(n+7)//8)
    unpacked=np.unpackbits(packed,axis=1,bitorder='little');assert not np.any(unpacked[:,n:]);actual=unpacked[:,:n].astype(bool)
    assert np.array_equal(actual,expected) and np.all(actual==actual.T) and np.all(np.diag(actual));all_pairs+=n*(n-1)//2
    covers=load(folder/'root-covers.json');inverse={v:i for i,v in enumerate(kept)}
    expected_covers=[[[inverse[i] for i in group if i in inverse] for group in family] for family in load(old/'root-covers.json')];expected_covers=[[g for g in family if g] for family in expected_covers]
    assert covers==expected_covers
    for f,groups in enumerate(covers):
        assert sorted(i for g in groups for i in g)==[i for i,v in enumerate(ns) if v['family']==f]
        assert all(np.all(actual[np.ix_(g,g)]) for g in groups)
    reported=load(folder/'checks.json');assert reported['removed_nodes']==len(removed) and reported['added_edges']==len(edges)
    assert reported['conflict_bytes_sha256']==digest(folder/'conflicts.bin')
    stronger=bool(removed or edges);assert reported['genuinely_stronger']==stronger
    results.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'retained_nodes':n,'removed_nodes':len(removed),'added_edges':len(edges),'root_clique_counts':list(map(len,covers)),'genuinely_stronger':stronger,'new_solver_call_permitted_by_source_change':stronger})
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},'proof':'Exact source binary64 rational transforms and original convex partitions are replayed. Every collision hull vertex is an unexpanded source difference plus a kernel vertex; strict convexity and all-generator halfplanes prove equality. All kernel vertices lie strictly inside the original clearance disk. Every removed closed cell has four corners inside a present-cog forbidden hull. A separate gift-wrapping reconstruction certifies all added pair conflicts by all four relative-anchor corners. Full matrix equality preserves every inherited conflict and adds only certified edges. Retained nodes equal the complete old cover minus only certified impossible cells; complete clique partitions and all their edges are checked. No solver, placement, full-construction or whole-arrangement exclusion claim is made.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'choices':results,'source_templates_verified':len(templates),'source_cog_vertices':sum(map(len,pieces)),'hull_halfplane_checks':hull_checks,'cell_corner_halfplane_checks':corner_checks,'pair_corner_halfplane_checks':pair_checks,'all_retained_graph_pairs':all_pairs,'removed_nodes':sum(r['removed_nodes'] for r in results),'added_edges':sum(r['added_edges'] for r in results),'genuinely_stronger_cases':sum(r['genuinely_stronger'] for r in results),'whole_arrangements_excluded':0,'remaining_fixed29_choices':6,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(json.dumps(checks),flush=True)
