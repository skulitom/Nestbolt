"""One new source-geometry scan; no placement or SAT call."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from itertools import product
import json, time, shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-six-polygon-clearance-20261107'
FRONT=ROOT/'output/h5-first57-clique-sat-frontier-20261107'
SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104'
RAW=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    ps=sorted(set(points));lo=[];hi=[]
    for seq,stack in [(ps,lo),(reversed(ps),hi)]:
        for p in seq:
            while len(stack)>1 and cross(stack[-2],stack[-1],p)<=0:stack.pop()
            stack.append(p)
    return lo[:-1]+hi[:-1]
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
rows=sorted(load(FRONT/'remaining-source-graphs.json'),key=lambda r:r['refinement_index'])
assert len(rows)==6 and load(FRONT/'checks.json')['passed']
geom=load(SRC/'geometry-domains.json');raw=load(RAW/'integer-source.json')
assert load(RAW/'audit/checks.json')['passed'] and load(SRC/'audit/checks.json')['passed']
assert load(JOB)['clearance']==0.2
K=[]
for x,y in [(199,0),(183,76),(140,140),(76,183)]:
    K.extend([(x,y),(-y,x),(-x,-y),(y,-x)])
K=hull(K);assert len(K)==16 and max(x*x+y*y for x,y in K)<200**2
normals=[(b[1]-a[1],a[0]-b[0]) for a,b in zip(K,K[1:]+K[:1])]
supports=[max(nx*x+ny*y for x,y in K) for nx,ny in normals]
inputs=[Path(__file__),JOB,FRONT/'checks.json',FRONT/'remaining-source-graphs.json',SRC/'geometry-domains.json',SRC/'audit/plan.json',SRC/'audit/checks.json',RAW/'integer-source.json',RAW/'audit/plan.json',RAW/'audit/checks.json',ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106/audit/plan.json',ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106/audit/checks.json']
for r in rows:inputs += [ROOT/r['graph']/n for n in ['nodes.json','conflicts.bin','root-covers.json','checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':rows,'kernel_um':K,'required_clearance_mm':0.2,'per_case_cap_seconds':30,'preparation_cap_seconds':160,'maximum_process_seconds':170,'repeat_permitted':False,'solver_calls':0,'native_calls':0,'full_construction_budget_claimed':False,'method':'Rebuild cog-piece minus source-inner rectangle sums from the unexpanded exact source, adding a convex inscribed16-direction clearance kernel. Remove only closed cells certified wholly within one such collision polygon. Add pair conflicts only when the full closed relative-anchor box lies strictly within an original source-inner rectangle difference plus the same kernel. Preserve every inherited edge and every unproved cell/alias/boundary. No unchanged case may justify a fresh solver call.'})
write(OUT/'kernel.json',{'vertices_um':K,'outward_normals':normals,'supports':supports,'maximum_squared_radius_um2':max(x*x+y*y for x,y in K)})
D=int(raw['scaled_units_per_micrometre']);pieces=[[tuple(map(int,p)) for p in poly] for poly in raw['normalized_cog_pieces']]
shifts=[tuple(map(int,r['translation_scaled'])) for r in raw['sites']]
templates=[];polys=[]
for g in geom:
    for ri,r in enumerate(g['inner_rectangles_um']):
        for pi,p in enumerate(pieces):
            poly=hull([(x-u*D+kx*D,y-v*D+ky*D) for (x,y),(u,v),(kx,ky) in product(p,product([r[0],r[2]],[r[1],r[3]]),K)])
            polys.append(poly);templates.append({'template':len(templates),'geometry':g['geometry'],'component':ri,'source_piece':pi,'vertices_scaled':[[str(x),str(y)] for x,y in poly]})
write(OUT/'collision-polygons.json',templates)
cells=[];keys={};mappings=[]
for row in rows:
    ns=load(ROOT/row['graph']/'nodes.json');mapping=[];bits=((1<<15)-1)^sum(1<<i for i in row['empty_sites'])
    for n in ns:
        key=(n['geometry'],*n['bounds_um'])
        if key not in keys:keys[key]=len(cells);cells.append({'cell':len(cells),'geometry':n['geometry'],'bounds_um':n['bounds_um'],'present_site_bits':0})
        i=keys[key];cells[i]['present_site_bits']|=bits;mapping.append(i)
    mappings.append(mapping)
write(OUT/'cells.json',cells)
bounds=np.array([c['bounds_um'] for c in cells],dtype=np.float64)
relevance=np.array([c['present_site_bits'] for c in cells],dtype=np.int64)
groups={g:np.array([i for i,c in enumerate(cells) if c['geometry']==g],dtype=np.int64) for g in range(10)}
certs=[];proofs={};candidates=0
for t,poly in zip(templates,polys):
    ids=groups[t['geometry']];bs=bounds[ids]
    local=[min(p[0] for p in poly)/D,min(p[1] for p in poly)/D,max(p[0] for p in poly)/D,max(p[1] for p in poly)/D]
    for site,(sx,sy) in enumerate(shifts):
        assert time.perf_counter()-start<40
        dx,dy=sx/D,sy/D
        candidate=(bs[:,0]>=local[0]+dx-1e-6)&(bs[:,1]>=local[1]+dy-1e-6)&(bs[:,2]<=local[2]+dx+1e-6)&(bs[:,3]<=local[3]+dy+1e-6)&((relevance[ids]&(1<<site))!=0)
        for i in ids[candidate]:
            i=int(i)
            if (i,site) in proofs:continue
            candidates+=1;x0,y0,x1,y1=cells[i]['bounds_um'];corners=[(x*D-sx,y*D-sy) for x,y in product([x0,x1],[y0,y1])]
            if all(cross(a,b,v)>0 for a,b in zip(poly,poly[1:]+poly[:1]) for v in corners):
                proofs[i,site]=len(certs);certs.append({'certificate':len(certs),'cell':i,'site':site,'template':t['template']})
write(OUT/'certificates.json',certs)
results=[]
for row,mapping in zip(rows,mappings):
    case_start=time.perf_counter();old=ROOT/row['graph'];folder=OUT/f"choice-{row['refinement_index']:02d}";folder.mkdir()
    original=load(old/'nodes.json');N=len(original);oldgraph=np.unpackbits(np.frombuffer((old/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(N,(N+7)//8),axis=1,bitorder='little')[:,:N].astype(bool)
    removed=[]
    for i,cell in enumerate(mapping):
        for site in range(15):
            if site not in row['empty_sites'] and (cell,site) in proofs:
                removed.append({'old_graph_node':i,'certificate':proofs[cell,site]});break
    removed_ids={r['old_graph_node'] for r in removed};kept=[i for i in range(N) if i not in removed_ids]
    ns=[original[i] for i in kept];n=len(ns);bs=np.array([v['bounds_um'] for v in ns],dtype=np.int64)
    assert max(abs(int(v)) for v in bs.flat)<10**7
    assert max(abs(v) for g in geom for r in g['inner_rectangles_um'] for v in r)<10**7
    assert max(abs(v) for normal in normals for v in normal)<1000
    # Each support expression has magnitude below 2*1000*4e7+1e6 < 2**63.
    inherited=oldgraph[np.ix_(kept,kept)];graph=inherited.copy();edge_records={}
    bygeom={g:np.array([i for i,v in enumerate(ns) if v['geometry']==g],dtype=np.int64) for g in range(10)}
    for ga in range(10):
        for gb in range(ga,10):
            assert time.perf_counter()-case_start<30 and time.perf_counter()-start<160
            ia,ib=bygeom[ga],bygeom[gb]
            if not len(ia) or not len(ib):continue
            a,b=bs[ia],bs[ib];lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3];ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1]
            new=np.zeros((len(ia),len(ib)),dtype=bool);eligible=~inherited[np.ix_(ia,ib)]
            for ri,ra in enumerate(geom[ga]['inner_rectangles_um']):
                for rj,rb in enumerate(geom[gb]['inner_rectangles_um']):
                    rect=[ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]];hit=eligible&~new
                    for (nx,ny),support in zip(normals,supports):
                        h=support+nx*rect[2 if nx>=0 else 0]+ny*rect[3 if ny>=0 else 1]
                        hit &= nx*(ux if nx>=0 else lx)+ny*(uy if ny>=0 else ly)<h
                    for ai,bi in zip(*np.nonzero(hit)):
                        u,v=int(ia[ai]),int(ib[bi])
                        if u!=v:
                            left,right,ca,cb=(u,v,ri,rj) if u<v else (v,u,rj,ri)
                            edge_records.setdefault((left,right),{'a':left,'b':right,'component_a':ca,'component_b':cb})
                    new|=hit
            graph[np.ix_(ia,ib)]|=new;graph[np.ix_(ib,ia)]|=new.T
    added=[edge_records[k] for k in sorted(edge_records)]
    assert np.all(graph==graph.T) and np.all(np.diag(graph))
    assert np.count_nonzero(np.triu(graph&~inherited,1))==len(added)
    inverse={v:i for i,v in enumerate(kept)};covers=[[[inverse[i] for i in group if i in inverse] for group in family] for family in load(old/'root-covers.json')];covers=[[g for g in family if g] for family in covers]
    write(folder/'nodes.json',ns);write(folder/'kept-old-node-ids.json',kept);write(folder/'removed.json',removed);write(folder/'added-edges.json',added);write(folder/'root-covers.json',covers)
    (folder/'conflicts.bin').write_bytes(np.packbits(graph,axis=1,bitorder='little').tobytes())
    result={'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source_selection':row['source_selection'],'old_graph':row['graph'],'original_nodes':N,'compact_nodes':n,'bracket_nodes':sum(v['family']==0 for v in ns),'insert_nodes':sum(v['family']==1 for v in ns),'row_bytes':(n+7)//8,'removed_nodes':len(removed),'added_edges':len(added),'root_clique_counts':list(map(len,covers)),'genuinely_stronger':bool(removed or added),'conflict_bytes_sha256':digest(folder/'conflicts.bin'),'seconds':time.perf_counter()-case_start}
    write(folder/'checks.json',result);results.append(result);print(json.dumps(result),flush=True)
elapsed=time.perf_counter()-start
write(OUT/'checks.json',{'prepared':True,'seconds':elapsed,'choices':results,'unique_cells':len(cells),'templates':len(templates),'certificates':len(certs),'candidate_corner_checks':candidates,'removed_nodes':sum(r['removed_nodes'] for r in results),'added_edges':sum(r['added_edges'] for r in results),'stronger_cases':sum(r['genuinely_stronger'] for r in results),'scan_complete':True,'solver_calls':0,'native_calls':0,'whole_arrangements_excluded':0,'independent_audit_pending':True,'H5_complete':False})
assert elapsed<160
