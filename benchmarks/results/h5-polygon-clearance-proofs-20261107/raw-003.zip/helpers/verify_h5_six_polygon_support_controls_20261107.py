"""Replay the preserved boundary controls without changing the original record."""
from pathlib import Path
import ast,itertools,json
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output'
audit=P/'audit_h5_six_polygon_clearance_20261107.py'
functions=[n for n in ast.parse(audit.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['turn','gift_wrap','check_hull']]
assert len(functions)==3
ns={};exec(compile(ast.Module(body=functions,type_ignores=[]),str(audit),'exec'),ns)
K=[tuple(p) for p in json.loads((P/'h5-six-polygon-clearance-20261107/kernel.json').read_bytes())['vertices_um']]
normals=[(K[(i+1)%16][1]-K[i][1],K[i][0]-K[(i+1)%16][0]) for i in range(16)]+[(1,0),(-1,0),(0,1),(0,-1)]
checks=0;old_falsepositives=0
for rect in [[-20,-30,40,50],[-299998,-74998,99998,249998],[0,0,1,1]]:
    points={(x+u,y+v) for x,y in itertools.product([rect[0],rect[2]],[rect[1],rect[3]]) for u,v in K}
    poly=ns['gift_wrap'](points);ns['check_hull'](poly,points)
    hs=[max(nx*x+ny*y for x,y in points) for nx,ny in normals]
    samples=set(poly)
    for x,y in poly:samples.update((x+dx,y+dy) for dx,dy in itertools.product(range(-3,4),repeat=2))
    for x,y in samples:
        expected=all(ns['turn'](poly[i],poly[(i+1)%len(poly)],(x,y))>0 for i in range(len(poly)))
        actual=all(nx*x+ny*y<h for (nx,ny),h in zip(normals,hs))
        old_result=all(nx*x+ny*y<h for (nx,ny),h in zip(normals[:16],hs[:16]))
        assert actual==expected
        old_falsepositives+=old_result and not expected;checks+=1
actual={'passed':True,'point_membership_comparisons':checks,'old_missing_axis_false_positives':old_falsepositives,'new_normals_count':len(normals),'solver_calls':0}
assert actual==json.loads((P/'h5-six-polygon-clearance-support-controls-20261107.json').read_bytes())
print(actual)
