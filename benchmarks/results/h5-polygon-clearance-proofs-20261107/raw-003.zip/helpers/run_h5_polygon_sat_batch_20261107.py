from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import time,json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-polygon-sat-batch-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());plan=load(OUT/'plan.json');start=time.perf_counter();records=[]
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
for p,h in plan['inputs'].items():assert sha256((ROOT/p).read_bytes()).hexdigest()==h
for row in plan['selection']:
    for entry in row['scripts'].values():assert sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256']
control=load(ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json');assert control['passed'] and sha256(EXE.read_bytes()).hexdigest()==control['runner_sha256']
write('opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{'output/h5-polygon-sat-batch-20261107/plan.json':sha256((OUT/'plan.json').read_bytes()).hexdigest(),Path(__file__).relative_to(ROOT).as_posix():sha256(Path(__file__).read_bytes()).hexdigest()},'runner_sha256':sha256(EXE.read_bytes()).hexdigest(),'global_batch_seconds':plan['global_batch_seconds'],'retry_permitted':False})
for row in plan['selection']:
    if time.perf_counter()-start>plan['global_batch_seconds']-430:break
    folder=OUT/f"case-{row['graph_index']:02d}";folder.mkdir();stages=[]
    for stage,scriptkey in [('prepare','prepare_h5_clique_sat_model_20261107.py'),('model_audit','audit_h5_clique_sat_model_20261107.py'),('call','run_h5_clique_sat_20261107.py'),('result_audit','audit_h5_clique_sat_result_20261107.py')]:
        cap=plan['stage_caps_seconds'][stage];script=ROOT/row['scripts'][scriptkey]['path']
        args=[str(EXE),str(cap*1000),str(plan['frozen_job_committed_memory_bytes']),str(folder/(stage+'-job.json')),str(folder/(stage+'-stdout.txt')),str(folder/(stage+'-stderr.txt')),str(folder/(stage+'-stop')),subprocess.list2cmdline([str(PY),str(script)]),str(ROOT),'version4']
        t=time.perf_counter()
        try:r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap+8);stdout,stderr=r.stdout,r.stderr;exit_code=r.returncode;timeout=False
        except subprocess.TimeoutExpired as e:stdout,stderr=e.stdout or b'',e.stderr or b'';exit_code=None;timeout=True
        (folder/(stage+'-runner-stdout.txt')).write_bytes(stdout);(folder/(stage+'-runner-stderr.txt')).write_bytes(stderr)
        job=load(folder/(stage+'-job.json')) if (folder/(stage+'-job.json')).exists() else None
        passed=exit_code==0 and not timeout and job is not None and job['closed'] and job['active_processes']==0 and job['reason_code']==0 and job['error_code']==0
        stages.append({'stage':stage,'exit_code':exit_code,'outer_timeout':timeout,'complete_seconds':time.perf_counter()-t,'job':job,'passed':passed})
        write(f"case-{row['graph_index']:02d}-{stage}.json",stages[-1])
        if not passed:break
    result_path=ROOT/'output'/row['result_audit']/'checks.json'
    result=load(result_path) if result_path.exists() else None
    record={'graph_index':row['graph_index'],'empty_sites':row['empty_sites'],'stages':stages,'result':result,'all_stages_passed':len(stages)==4 and all(s['passed'] for s in stages)}
    records.append(record);write(f"case-{row['graph_index']:02d}-record.json",record)
    print(json.dumps({'finished_case':row['empty_sites'],'stages_passed':record['all_stages_passed'],'status':result['solver_status'] if result else 'stage-failure','proof_verified':result['proof_verified'] if result else False,'elapsed':time.perf_counter()-start}),flush=True)
    assert all(s['job'] is not None and s['job']['closed'] and s['job']['active_processes']==0 for s in stages),'No new phase may start without closed process-tree evidence'
write('process.json',{'closed':True,'cases_attempted':len(records),'cases_not_attempted':len(plan['selection'])-len(records),'complete_seconds':time.perf_counter()-start,'global_cap_seconds':plan['global_batch_seconds'],'global_cap_overrun_seconds':max(0,time.perf_counter()-start-plan['global_batch_seconds']),'all_attempted_trees_closed':True,'retry_permitted':False})
print('batch closed',len(records),flush=True)
