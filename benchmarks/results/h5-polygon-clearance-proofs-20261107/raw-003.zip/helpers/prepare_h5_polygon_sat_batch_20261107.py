"""Freeze six first calls on independently verified, genuinely stronger graphs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-polygon-sat-batch-20261107';OUT.mkdir()
GBASE=ROOT/'output/h5-six-polygon-clearance-v2-20261107';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
geometry=load(GBASE/'audit/checks.json');assert geometry['passed'] and geometry['genuinely_stronger_cases']==6
names=['prepare_h5_clique_sat_model_20261107.py','audit_h5_clique_sat_model_20261107.py','solve_h5_clique_sat_20261107.py','run_h5_clique_sat_20261107.py','audit_h5_clique_sat_result_20261107.py']
templates={name:(ROOT/'output'/name).read_text(encoding='utf-8') for name in names};rows=[]
for choice in geometry['choices']:
    index=choice['refinement_index'];assert choice['genuinely_stronger'] and choice['removed_nodes']+choice['added_edges']>0
    G=GBASE/f'choice-{index:02d}';gc=load(G/'checks.json');sites=choice['empty_sites']
    model=f'h5-polygon-sat-{index:02d}-model-20261107';call=f'h5-polygon-sat-{index:02d}-call-20261107';audit=f'h5-polygon-sat-{index:02d}-result-audit-20261107'
    assert not any((ROOT/'output'/p).exists() for p in [model,call,audit])
    renamed={name:name.replace('_20261107.py',f'_polygon_{index:02d}_20261107.py') for name in names};scripts={}
    for name,text in templates.items():
        text=text.replace('h5-first57-clique-sat-model-20261107',model).replace('h5-first57-clique-sat-call-20261107',call).replace('h5-first57-clique-sat-result-audit-20261107',audit)
        for before,after in renamed.items():text=text.replace(before,after)
        if name.startswith('prepare_'):
            text=text.replace('h5-first57-frontier-refined-graphs-v2-20261106/choice-02',f'h5-six-polygon-clearance-v2-20261107/choice-{index:02d}').replace('[0,5,11]',str(sites)).replace('==2135','=='+str(gc['compact_nodes']))
            text=text.replace("'binary_proof_byte_limit':268435456","'binary_proof_byte_limit':67108864")
            text=text.replace("'method':'A fresh arrangement and explicit clique-count CNF.","'method':'A genuinely stronger source graph and explicit clique-count CNF.")
            text=text.replace("'distinct_from_closed_pilot':{'old_empty_sites':[0,5,12],'new_empty_sites':"+str(sites)+",'old_pilot_repeated':False}","'source_strengthening':"+repr({'source_audit':'output/h5-six-polygon-clearance-v2-20261107/audit/checks.json','new_cell_removals':choice['removed_nodes'],'new_source_edges':choice['added_edges'],'old_calls_repeated':False}))
            text=text.replace("paths=[G/'checks.json'", "assert load(G.parent/'audit/checks.json')['passed'] and gc['genuinely_stronger']\npaths=[G.parent/'audit/plan.json',G/'checks.json'")
        elif name.startswith('solve_'):
            text=text.replace("'proof_bytes':(OUT/'proof.drat.bin').stat().st_size", "'proof_bytes_before_solver_destruction':(OUT/'proof.drat.bin').stat().st_size")
            text=text.replace("write('result.json',result);print(result)","result.update({'proof_bytes':(OUT/'proof.drat.bin').stat().st_size,'proof_sha256_after_solver_destruction':sha256((OUT/'proof.drat.bin').read_bytes()).hexdigest()})\nwrite('result.json',result);print(result)")
        elif name=='audit_h5_clique_sat_result_20261107.py':
            text=text.replace("ROOT/'output/h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json'", "ROOT/'output/h5-first57-clique-sat-frontier-20261107/remaining-fixed29-choices.json'")
        p=ROOT/'output'/renamed[name];compile(text,str(p),'exec')
        with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
        scripts[name]={'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p)}
    rows.append({'graph_index':index,'empty_sites':sites,'compact_nodes':gc['compact_nodes'],'new_source_cell_removals':choice['removed_nodes'],'new_source_edges':choice['added_edges'],'graph_checks_sha256':digest(G/'checks.json'),'model':model,'call':call,'result_audit':audit,'scripts':scripts})
rows.sort(key=lambda r:(r['compact_nodes'],r['graph_index']))
inputs=[Path(__file__),GBASE/'audit/checks.json',GBASE/'audit/plan.json',ROOT/'output/h5-six-polygon-clearance-v2-process-20261107/process.json',ROOT/'output/h5-first57-clique-sat-frontier-20261107/remaining-fixed29-choices.json']+[ROOT/'output'/n for n in names]
plan={'utc':datetime.now(timezone.utc).isoformat(),'selection':rows,'cases':6,'order':'ascending retained node count then refinement index','baseline_fixed29_choices':6,'baseline_required_clearance_exclusions':449,'frozen_per_case_search_seconds':60,'frozen_conflict_budget':1000000,'frozen_binary_proof_bytes':67108864,'frozen_job_committed_memory_bytes':2147483648,'one_call_per_distinct_new_source_graph':True,'retry_permitted':False,'stage_caps_seconds':{'prepare':120,'model_audit':120,'call':100,'result_audit':90},'global_batch_seconds':1200,'full_job_construction_budget_claimed':False,'source_change':'Every case gains independently checked source conflicts; two also lose a certified impossible closed cell. No old model is rerun. All source/model/audit/preparation costs stay recorded. Only independently accepted complete certificates exclude an arrangement.','inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}}
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(plan,f,indent=2);f.write('\n')
runner=(ROOT/'output/run_h5_clique_sat_batch_20261107.py').read_text(encoding='utf-8').replace('h5-first57-clique-sat-batch-20261107','h5-polygon-sat-batch-20261107')
with (ROOT/'output/run_h5_polygon_sat_batch_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
print({'prepared':True,'cases':len(rows),'order':[r['empty_sites'] for r in rows]})
