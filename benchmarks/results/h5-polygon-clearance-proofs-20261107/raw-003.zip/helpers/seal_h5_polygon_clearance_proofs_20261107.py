from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-polygon-clearance-proofs-20261107';OUT=ROOT/'benchmarks/results'/NAME
B=ROOT/'output/h5-polygon-sat-batch-20261107';F=B/'audit';G=ROOT/'output/h5-six-polygon-clearance-v2-20261107';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');geometry=load(G/'audit/checks.json');assert front['passed'] and geometry['passed']
assert geometry['removed_nodes']==2 and geometry['added_edges']==6589 and geometry['genuinely_stronger_cases']==6
assert load(ROOT/'output/h5-six-polygon-clearance-process-20261107/process.json')['passed'] is False
assert load(ROOT/'output/h5-six-polygon-clearance-v2-process-20261107/process.json')['passed']
# Reuse only the historical archive inventory from the previous sealer.
setup=(ROOT/'output/seal_h5_clique_sat_frontier_v2_20261107.py').read_text(encoding='utf-8');nodes=ast.parse(setup).body
def assigns(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
lo=next(i for i,n in enumerate(nodes) if assigns(n,'setup'));hi=next(i for i,n in enumerate(nodes) if assigns(n,'walker'))
exec(compile(ast.Module(body=nodes[lo:hi],type_ignores=[]),'historical-archive-inventory','exec'))
PARENTS.append(ROOT/'benchmarks/results/h5-clique-sat-frontier-20261107')
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[B,G,ROOT/'output/h5-six-polygon-clearance-20261107',ROOT/'output/h5-six-polygon-clearance-process-20261107',ROOT/'output/h5-six-polygon-clearance-v2-process-20261107']
for row in load(B/'plan.json')['selection']:folders.extend(ROOT/'output'/row[key] for key in ['model','call','result_audit'])
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*six_polygon*20261107.py','*h5*polygon_sat*20261107.py','*h5*clique_sat*polygon*20261107.py','*h5*polygon_clearance*20261107.py','h5-six-polygon-clearance-*.json']:
    for p in (ROOT/'output').glob(pattern):
        if p.is_file():add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_clique_sat_frontier_v2_20261107.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(G/'audit/checks.json','geometry-audit.json'),(F/'checks.json','frontier-audit.json'),(F/'case-results.json','case-results.json'),(F/'new-exclusions.json','new-exclusions.json'),(F/'remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(F/'remaining-source-graphs.json','remaining-source-graphs.json'),(F/'next-step.json','next-step.json'),(B/'process.json','batch-process.json'),(ROOT/'output/h5-six-polygon-clearance-correction-20261107.json','source-correction.json'),(ROOT/'output/h5-six-polygon-clearance-support-controls-20261107.json','support-controls.json'),(ROOT/'output/h5-six-polygon-clearance-process-20261107/process.json','original-failed-process.json'),(ROOT/'output/h5-six-polygon-clearance-v2-process-20261107/process.json','corrected-process.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Stronger source clearance and checked proofs — 2026-11-07

The [combined audit]({NAME}/frontier-audit.json) excludes **{front['new_fixed29_exclusions']} more fixed29/current-cog arrangements**.
There are **{front['remaining_fixed29_choices']} remaining**, with **{front['total_excluded_at_required_clearance']} of 455 excluded** at the original
0.2 mm clearance. The earlier zero-clearance count remains 427. These are
conditional fixed-arrangement proofs, not full-job placements or whole-allocation
exclusions. All 440 allocation candidates and full66 validation remain open;
H2/H5 stay open at **60% completed milestone weight**.

## Original source geometry

A convex clearance kernel has sixteen integer-micrometre vertices generated
from (199,0), (183,76), (140,140) and (76,183) by quarter-turn symmetry. Every
vertex has squared radius at most 39,601 µm², below the required 40,000 µm².
Its convex hull therefore lies strictly inside the original clearance disk.
It contains the previous 199 µm diamond and 140 µm square.

All 378 cog collision polygons are rebuilt from unexpanded original convex
source pieces and independently certified inner rectangles. Exact binary64
rotation/translation rationals use scaled units per micrometre. No rounded
bounds, source validator numerical guard, increased gap or double expansion
is used to prove an exclusion.

[Independent geometry verification]({NAME}/geometry-audit.json) checks
5,472,320 hull halfplanes, 96 closed-cell corner halfplanes and 527,120 pair
corner halfplanes. It removes two impossible source cells and adds **6,589
verified pair conflicts** across all six arrangements. All 42,706,462 retained
unordered graph pairs are checked against the inherited matrix plus exactly
the certified additions. Complete old covers, every retained boundary and
mode alias, and complete conflict-clique partitions are preserved.

## Preserved failed preparation and correction

The [first producer]({NAME}/original-failed-process.json) omitted the axis
normals contributed by the rectangle in the Minkowski sum. That overestimated
the forbidden region and proposed invalid pair conflicts. The independent
gift-wrapping source audit rejected the first invalid certificate before any
SAT model or call. Its outputs and process failure remain preserved and support
no exclusions.

The [versioned correction]({NAME}/source-correction.json) adds the four axis
support planes. [Boundary controls]({NAME}/support-controls.json) compare
2,772 source polygon membership cases and expose 48 false positives from the
old predicate. The corrected preparation and independent audit close in
14.434343 and 3.447393 seconds, within unchanged limits. The first failed
preparation/audit costs, 21.403395 and 2.459566 seconds, remain recorded.

## Six distinct bounded models

Every case gains actual independently checked source constraints before its
new model is prepared. Earlier models and calls remain closed. Complete
source conflict-clique partitions give exact group-count equivalences; each
model keeps every pair clause and requires at least eight brackets and eight
inserts. Independent audits verify **{front['model_clauses_verified']:,} clauses**,
{front['graph_pairs_verified']:,} graph pairs, {front['threshold_gates_verified']:,} threshold gates and
{front['source_cell_capacity_proofs']:,} source single-cell capacities.

[The batch]({NAME}/batch-process.json) makes exactly six fresh calls, each
limited to 60 seconds of search, one million conflicts, 64 MiB of binary proof
and 2 GiB aggregate committed memory. Complete process and stage limits are
frozen before execution; Windows Job Object supervision closes every descendant.
The complete batch takes {front['complete_batch_seconds']:.6f} seconds.
{front['accepted_proofs']} complete proofs are independently accepted against exact model bytes;
{front['limited_calls']} limited calls remain unresolved. There are
{front['necessary_graph_witnesses']} necessary graph witnesses and no source-valid placement.
The new worker distinguishes proof size before solver destruction from final
closed proof size. Neither metadata nor an unverified solver status substitutes
for an accepted certificate.

[Per-case results]({NAME}/case-results.json), [new exclusions]({NAME}/new-exclusions.json)
and [remaining source graphs]({NAME}/remaining-source-graphs.json) preserve exact
scope. Per-case remaining counts share the same six-case baseline and must not
be summed. The combined audit uses set union of accepted exclusions.

[Next]({NAME}/next-step.json), assess exact coverage by unions of the new cog
collision polygons on the remaining refined closed cells. Freeze subdivision
limits and independently replay every removal. A further model requires new
certified source constraints. No full-job 60/90-second construction, LightBurn
call, release or registry publication is claimed; all consumed preparation
remains chargeable before any future construction claim.

[The manifest]({NAME}/raw-manifest.json) contains {archive['archive_members']}
new canonical members in {archive['archive_parts']} ZIP parts, totaling
{archive['archive_bytes']:,} bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) preserve every original input.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=f"\n\n**2026-11-07 H5 stronger polygon clearance:** [independent source/model/proof audits]({{link}}) verify 378 original-source collision hulls, two impossible-cell removals and 6,589 additional conflicts across six refined arrangements. The first producer omitted rectangle axis normals; independent source checking rejected its invalid conflicts before any SAT call. Both failure and versioned correction remain preserved, with 2,772 boundary controls. Corrected geometry checks all 42,706,462 retained graph pairs. Six genuinely stronger models verify {front['model_clauses_verified']:,} clauses; {front['accepted_proofs']} complete proofs exclude further arrangements and {front['limited_calls']} limited calls stay unresolved. The frontier is now {front['remaining_fixed29_choices']} ({front['total_excluded_at_required_clearance']} of 455 excluded at original 0.2 mm clearance; 427 even at zero clearance). The batch closes in {front['complete_batch_seconds']:.6f} s with all descendant trees closed. Next assess exact polygon-union coverage on remaining refined cells; no old call is repeated. All 440 whole allocations, source-valid66/native/material checks and H2/H5 stay open at 60%. No release or full construction budget claim is made.\n"
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a='Latest H5 evidence: [clique-count certificate frontier](../benchmarks/results/h5-clique-sat-frontier-20261107.md).';assert s.count(a)==1
s=s.replace(a,f'Latest H5 evidence: [stronger polygon clearance proofs](../benchmarks/results/{NAME}.md).',1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'remaining':front['remaining_fixed29_choices']})
