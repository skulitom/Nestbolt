from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];B=ROOT/'output/h5-polygon-sat-batch-20261107';OUT=B/'audit';OUT.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();start=time.perf_counter()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(B/'plan.json');process=load(B/'process.json');assert process['closed'] and process['all_attempted_trees_closed'] and process['global_cap_overrun_seconds']==0
baseline=load(ROOT/'output/h5-first57-clique-sat-frontier-20261107/remaining-fixed29-choices.json')
def sites(row):return tuple(row['empty_sites'] if 'empty_sites' in row else row['source_selection']['empty_sites'])
assert len(baseline)==6
bindings={};cases=[];excluded=set();mapped=[];counts={'clauses':0,'pairs':0,'gates':0,'capacities':0,'calls':0,'proofs':0,'limits':0,'witnesses':0}
def bind(p):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for row in plan['selection']:
    for script in row['scripts'].values():assert digest(ROOT/script['path'])==script['sha256'];bindings[script['path']]=script['sha256']
    casepath=B/f"case-{row['graph_index']:02d}-record.json";case=load(casepath);bind(casepath)
    assert case['all_stages_passed'] and all(s['passed'] and s['job']['closed'] and s['job']['active_processes']==0 for s in case['stages'])
    M=ROOT/'output'/row['model'];C=ROOT/'output'/row['call'];A=ROOT/'output'/row['result_audit']
    mp=load(M/'plan.json');ma=load(M/'audit.json');cp=load(C/'process.json');answer=load(A/'checks.json');g=ROOT/mp['graph'];gc=load(g/'checks.json')
    assert ma['passed'] and answer['passed'] and gc['genuinely_stronger'] and gc['removed_nodes']+gc['added_edges']>0
    assert cp['closed'] and cp['job']['active_processes']==0 and cp['solver_calls_started']==1
    assert digest(M/'model.cnf')==ma['model_sha256']==answer['model_sha256'] and sites(answer)==tuple(row['empty_sites'])
    for p,h in mp['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
    counts['clauses']+=ma['all_clauses_verified'];counts['pairs']+=ma['every_graph_pair_checked'];counts['gates']+=ma['acyclic_threshold_gates'];counts['capacities']+=ma['single_cell_capacity_proofs'];counts['calls']+=cp['solver_calls_started']
    if answer['proof_verified']:
        assert answer['valid_complete_process'] and answer['new_exclusions']==1 and cp['exit_code']==0 and cp['limit_reason'] is None
        checker=load(A/'checker-process.json');opened=load(A/'checker-opened.json');conv=load(A/'conversion.json')
        assert checker['verified'] and checker['exit_code']==0 and checker['closed'] and not checker['timeout'] and checker['process_cap_overrun_seconds']==0
        assert digest(C/'proof.drat.bin')==conv['binary_sha256'] and digest(A/'proof.drat.txt')==conv['text_sha256']==opened['proof_sha256']
        assert opened['formula_sha256']==ma['model_sha256'] and any(line.strip()==b's VERIFIED' for line in (A/'checker-stdout.txt').read_bytes().splitlines())
        assert tuple(row['empty_sites']) not in excluded;excluded.add(tuple(row['empty_sites']));counts['proofs']+=1
    else:
        assert answer['new_exclusions']==0
        counts['limits']+=bool(cp['limit_reason']);counts['witnesses']+=answer['assignment_verified']
        mapped.append({'empty_sites':row['empty_sites'],'refinement_index':row['graph_index'],'source_selection':gc['source_selection'],'graph':mp['graph'],'closed_result':answer['classification'],'limit_reason':cp['limit_reason'],'model':M.relative_to(ROOT).as_posix(),'call':C.relative_to(ROOT).as_posix(),'result_audit':A.relative_to(ROOT).as_posix(),'no_repeat':True})
    cases.append({'empty_sites':row['empty_sites'],'graph_index':row['graph_index'],'new_cell_removals':gc['removed_nodes'],'new_edges':gc['added_edges'],'model_clauses':ma['all_clauses_verified'],'model_audit_seconds':ma['seconds'],'complete_call_seconds':cp['complete_process_seconds'],'status':answer['solver_status'],'limit_reason':cp['limit_reason'],'proof_verified':answer['proof_verified'],'assignment_verified':answer['assignment_verified'],'process_success':answer['valid_complete_process']})
    for folder in [M,C,A]:
        for p in folder.rglob('*'):
            if p.is_file():bind(p)
    bind(g/'checks.json')
assert counts['calls']==process['cases_attempted']==6 and process['cases_not_attempted']==0
remaining=[r for r in baseline if sites(r) not in excluded];assert len(remaining)==6-len(excluded)
assert {tuple(r['empty_sites']) for r in mapped}=={sites(r) for r in remaining}
for p in [Path(__file__),B/'plan.json',B/'process.json',ROOT/'output/h5-six-polygon-clearance-v2-20261107/audit/plan.json',ROOT/'output/h5-six-polygon-clearance-v2-20261107/audit/checks.json']:bind(p)
checks={'passed':True,'new_fixed29_exclusions':len(excluded),'remaining_fixed29_choices':len(remaining),'total_excluded_at_required_clearance':449+len(excluded),'previous_zero_clearance_exclusions':427,'fresh_research_SAT_calls':counts['calls'],'accepted_proofs':counts['proofs'],'limited_calls':counts['limits'],'necessary_graph_witnesses':counts['witnesses'],'model_clauses_verified':counts['clauses'],'graph_pairs_verified':counts['pairs'],'threshold_gates_verified':counts['gates'],'source_cell_capacity_proofs':counts['capacities'],'complete_batch_seconds':process['complete_seconds'],'whole_allocation_candidates':440,'source_valid_placements':0,'LightBurn_or_full66_native_validator_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'seconds':time.perf_counter()-start}
for name,value in [('checks.json',checks),('case-results.json',cases),('new-exclusions.json',sorted(excluded)),('remaining-fixed29-choices.json',remaining),('remaining-source-graphs.json',mapped),('source-bindings.json',bindings)]:write(name,value)
write('next-step.json',{'all_existing_calls_closed':True,'remaining_fixed29_choices':len(remaining),'next_hypothesis':'Assess complete closed-cell coverage by unions of the new original-source cog collision polygons on the remaining refined covers. Prior union pruning used coarser parent cells and older kernels; current child covers and16-direction source polygons are distinct inputs. Freeze subdivision depth/node/time limits before scanning. Independently replay each subdivision and exact hull-membership certificate; retain every unproved cell and all aliases/boundaries. Require actual new source removals or pair conflicts before any further model/call. No change to original clearance, fixed geometry, benchmark limits or final acceptance.','no_new_solver_prepared':True,'source_valid66_required_before_native':True,'H5_complete':False})
print(checks)
