from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
from h5_sat_encoding_20261107 import threshold
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-polygon-sat-21-model-20261107';G=ROOT/'output/h5-six-polygon-clearance-v2-20261107/choice-21'
load=lambda p:json.loads(p.read_bytes())
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
start=time.perf_counter();OUT.mkdir();gc=load(G/'checks.json');nodes=load(G/'nodes.json');covers=load(G/'root-covers.json')
assert gc['source_selection']['empty_sites']==[11, 12, 13] and gc['compact_nodes']==3457
assert load(ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json')['passed'] and load(ROOT/'output/h5-windows-job-external-stop-20261107/checks.json')['passed']
assert load(G.parent/'audit/checks.json')['passed'] and gc['genuinely_stronger']
paths=[G.parent/'audit/plan.json',G/'checks.json',G/'nodes.json',G/'conflicts.bin',G/'root-covers.json',G.parent/'audit/checks.json',
    ROOT/'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json',ROOT/'output/h5_sat_encoding_20261107.py',
    ROOT/'output/h5-sat-controls-v2-20261107/checks.json',ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json',ROOT/'output/h5-windows-job-external-stop-20261107/checks.json',Path(__file__)]
write('plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'graph':G.relative_to(ROOT).as_posix(),'source_selection':gc['source_selection'],
    'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in paths},
    'method':'A genuinely stronger source graph and explicit clique-count CNF. Preserve every certified pair clause. A Boolean group is equivalent to OR of the cells in each complete source-verified conflict clique. Each clique admits at most1 cell; count at least8 selected groups per family. This replaces the long all-cell threshold circuit by the exact equivalent group count on independent sets.',
    'source_strengthening':{'source_audit': 'output/h5-six-polygon-clearance-v2-20261107/audit/checks.json', 'new_cell_removals': 0, 'new_source_edges': 455, 'old_calls_repeated': False},
    'maximum_model_preparation_seconds':120,'maximum_model_audit_seconds':120,'solver_call_count':1,'solver_search_seconds':60,'solver_conflict_budget':1000000,
    'solver_complete_process_seconds':90,'native_job_hard_wall_ms':85000,'solver_aggregate_committed_memory_bytes':2147483648,'binary_proof_byte_limit':67108864,
    'checker_seconds':60,'checker_complete_process_seconds':70,'retry_permitted':False,'required_job_clearance_mm':.2,
    'full_construction_60_or_90_second_claim':False,'prior_consumed_preparation_stays_charged':True,'scope':'Fixed29/current12cog poses only; SAT is necessary graph witness, UNSAT requires a complete separately accepted proof, all failures/limits unresolved.'})
n=len(nodes);raw=(G/'conflicts.bin').read_bytes();rb=gc['row_bytes'];assert sha256(raw).hexdigest()==gc['conflict_bytes_sha256']
rows=[int.from_bytes(raw[i*rb:(i+1)*rb],'little') for i in range(n)];edgecount=sum((row>>(i+1)).bit_count() for i,row in enumerate(rows))
top=n;groups=[];extras=[];families=[];gates=[]
for family in [0,1]:
    selected=[]
    for index,cells in enumerate(covers[family]):
        top+=1;variable=top;selected.append(variable);groups.append({'family':family,'index':index,'variable':variable,'compact_nodes':cells})
        extras.extend([[-(i+1),variable] for i in cells]);extras.append([-variable]+[i+1 for i in cells])
    families.append({'family':family,'group_variables':selected})
group_top=top
for family in [0,1]:
    cs,gs,top,final=threshold(families[family]['group_variables'],8,top);extras.extend(cs)
    families[family].update({'final':final,'gate_count':len(gs),'threshold_clause_count':len(cs)})
    gates.extend(dict(g,family=family) for g in gs)
write('groups.json',groups);write('families.json',families);write('threshold-gates.json',gates)
with (OUT/'model.cnf').open('x',encoding='utf-8',newline='\n') as f:
    f.write(f'p cnf {top} {edgecount+len(extras)}\n')
    for i,row in enumerate(rows):
        bits=row&~((1<<(i+1))-1)
        while bits:
            bit=bits&-bits;bits-=bit;f.write(f'-{i+1} -{bit.bit_length()} 0\n')
    for c in extras:f.write(' '.join(map(str,c))+' 0\n')
elapsed=time.perf_counter()-start;assert elapsed<=120
write('checks.json',{'passed':True,'nodes':n,'group_variables':len(groups),'family_group_counts':[len(f['group_variables']) for f in families],'group_variable_top':group_top,'threshold_gates':len(gates),'variables':top,'conflict_clauses':edgecount,'additional_clauses':len(extras),'clauses':edgecount+len(extras),'model_bytes':(OUT/'model.cnf').stat().st_size,'model_sha256':sha256((OUT/'model.cnf').read_bytes()).hexdigest(),'complete_preparation_seconds':elapsed,'solver_calls':0})
print(load(OUT/'checks.json'))
