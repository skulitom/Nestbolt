"""Verify exact feasible starting points for every reduced joint model."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from hashlib import sha256
import json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
PART=ROOT/'output/h5-substituted-partials-20261020'
COMP=ROOT/'output/h5-substituted-insert-completion-20261020'
JOINT=ROOT/'output/h5-reduced-joint-frames-brackets-20261020'
OUT=ROOT/'output/h5-certified-partial-seeds-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'verify.py')
    inputs=[SRC/'candidates.json',PART/'result-audit.json',COMP/'result-audit/checks.json',COMP/'results.json']
    for case in range(4):inputs += [JOINT/f'case-{case}/mapping.json',JOINT/f'case-{case}/model.pbtxt']
    for case in range(6):inputs += [COMP/f'case-{case}/selected-indices.json',COMP/f'case-{case}/mapping.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'method':'For each cog case choose the already audited completed partial with most inserts, breaking ties by source case. Construct the full zero/one vector for the reduced joint model and check every domain, conflict, exact quantity, exclusion and objective arithmetically. Retain original insert positions separately for the next actual insert-count optimization. No solver run.',
        'scope':'Feasible for the frame/bracket construction model only. The original 21-insert job remains incomplete.',
        'solver_calls':0,'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');candidates=[]
    for r in load(COMP/'results.json'):
        mp=load(COMP/f"case-{r['case']}/mapping.json")
        candidates.append({'source_case':r['case'],'cog_case':mp['cog_case'],'inserts':r['inserts'],
            'ids':load(COMP/f"case-{r['case']}/selected-indices.json")})
    records=[]
    for si in range(4):
        source=min((r for r in candidates if r['cog_case']==si),key=lambda r:(-r['inserts'],r['source_case']))
        mp=load(JOINT/f'case-{si}/mapping.json');selected=set(source['ids'])
        x=[int(i in selected) for i in mp['candidates']]
        noncog_noninsert={i for i in selected if pool[i]['placement']['part_id'] in ['frame','bracket']}
        assert noncog_noninsert<=set(mp['candidates'])
        model=text_format.Parse((JOINT/f'case-{si}/model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert len(x)==len(model.variables)
        for v,value in zip(model.variables,x):assert list(v.domain)==[0,1] and value in [0,1]
        for c in model.constraints:
            kind=c.WhichOneof('constraint')
            if kind=='at_most_one':assert sum(x[j] for j in c.at_most_one.literals)<=1
            else:
                assert kind=='linear' and len(c.linear.domain)==2
                value=sum(co*x[j] for j,co in zip(c.linear.vars,c.linear.coeffs))
                assert c.linear.domain[0]<=value<=c.linear.domain[1]
        objective=sum(co*x[j] for j,co in zip(model.objective.vars,model.objective.coeffs))
        assert Counter(pool[i]['placement']['part_id'] for i in noncog_noninsert)=={'frame':18,'bracket':12}
        record={'case':si,'source_completion_case':source['source_case'],'seed_inserts':source['inserts'],
            'missing_inserts':21-source['inserts'],'joint_objective':objective,'joint_variables':len(x),
            'joint_constraints_verified':len(model.constraints),'complete_feasible_joint_hint':True,
            'original_job_complete':False}
        write(OUT/f'case-{si}-joint-hint.json',x);write(OUT/f'case-{si}-selected-indices.json',source['ids'])
        records.append(record)
    write(OUT/'checks.json',{'all_four_joint_hints_exactly_feasible':True,'cases':records,
        'full_target_witness':False,'native_margin_qualified':False})
    print(json.dumps(records),flush=True)
if __name__=='__main__':main()
