"""Independent original-vertex checks of lattice components and selected layout."""
from pathlib import Path
from collections import Counter
import json, math, itertools, gzip, subprocess, sys, time
from hashlib import sha256
from datetime import datetime, timezone
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-cog-lattices-20261018';OUT=RUN/'audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def shape(part,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;x,y=t['translation']
    return Polygon([(m*a*c-b*s+x,m*a*s+b*c+y) for a,b in part['geometry'][0]['outer']])
def main():
    OUT.mkdir();t0=time.perf_counter();plan=load(RUN/'plan.json');job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};variants=load(RUN/'variants.json');patterns=load(RUN/'patterns.json');allpatterns=load(RUN/'all-patterns.json');layout=load(RUN/'best-partial.json');result=load(RUN/'result.json')
    for n,h in plan['sources'].items():assert digest(ROOT/n)==h
    assert len(variants)==162 and len(patterns)==162*7
    assert {(v['base'],v['phase'],*v['offset']) for v in variants}==set(itertools.product(plan['base_angles_degrees'],plan['relative_phases_degrees'],plan['alternate_offsets_mm'],plan['alternate_offsets_mm']))
    cp=Polygon(parts['cog']['geometry'][0]['outer']);cx,cy=cp.centroid.coords[0];checks=0;mind=math.inf
    for v in variants:
        for name,(n,cols) in zip(v['patterns'],plan['grids']):
            p=patterns[name];assert len(p['members'])==n;raw=[]
            for i in range(n):
                col,row=i%cols,i//cols;alt=(col+row)%2;theta=math.radians(v['base']+alt*v['phase']);c,s=math.cos(theta),math.sin(theta)
                x=col*v['pitch'][0]+alt*v['offset'][0];y=row*v['pitch'][1]+alt*v['offset'][1]
                raw.append({'rotation_radians':theta,'translation':[x-c*cx+s*cy,y-s*cx-c*cy],'mirrored':False})
            raws=[shape(parts['cog'],t) for t in raw];x0=min(g.bounds[0] for g in raws);y0=min(g.bounds[1] for g in raws);actual=[]
            for saved,t in zip(p['members'],raw):
                assert saved['part_id']=='cog';t['translation'][0]-=x0;t['translation'][1]-=y0
                assert t==saved['transform'];actual.append(shape(parts['cog'],saved['transform']))
            assert abs(max(g.bounds[2] for g in actual)-p['width'])<1e-9 and abs(max(g.bounds[3] for g in actual)-p['height'])<1e-9
            for a,b in itertools.combinations(actual,2):checks+=1;d=a.distance(b);mind=min(mind,d);assert a.disjoint(b) and d>=job['clearance']
    assert checks==load(RUN/'generation.json')['pair_checks']
    # Review every attempted inventory, including placements and unplaced
    # components. This does not claim pairwise validation of rejected attempts.
    required=Counter({k:p['quantity'] for k,p in parts.items()});attempts=0;complete=0;max_area=-1;maximum_count=0
    with gzip.open(RUN/'attempts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            r=json.loads(line);attempts+=1;placed=Counter();remaining=Counter();area=0
            for b in r['blocks']:
                p=allpatterns[b['pattern']];placed.update(m['part_id'] for m in p['members']);area+=p['area']
            for n in r['unplaced']:remaining.update(m['part_id'] for m in allpatterns[n]['members'])
            assert placed+remaining==required and sum(placed.values())==r['count'] and abs(area-r['area'])<1e-6
            if not remaining:complete+=1
            max_area=max(max_area,area);maximum_count=max(maximum_count,r['count'])
    assert attempts==result['attempts'] and (complete>0)==result['complete'] and abs(max_area-result['area'])<1e-6
    st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];target=load(RUN/'conditional-target.json');tops={};seen=set();counts=Counter();geoms={};slack=math.inf;layoutpairs=0
    assert layout['sheets']==load(RUN/'original.json')['sheets']
    for p in layout['placements']:
        key=(p['part_id'],p['copy_index']);assert key not in seen;seen.add(key);counts[p['part_id']]+=1;part=parts[p['part_id']];t=p['transform']
        assert not t['mirrored'] or part['allow_mirror']
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        g=shape(part,t);assert g.is_valid and g.area>0
        top=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        x0,y0,x1,y1=g.bounds;assert x0>=m['left']+e-1e-7 and y0>=m['bottom']+e-1e-7 and x1<=st['width']-m['right']-e+1e-7 and y1<=top-m['top']-e+1e-7
        tops[p['sheet_id']]=max(tops.get(p['sheet_id'],0),y1);geoms.setdefault(p['sheet_id'],[]).append(g)
    for gs in geoms.values():
        for a,b in itertools.combinations(gs,2):layoutpairs+=1;d=a.distance(b);slack=min(slack,d-job['clearance']);assert a.disjoint(b) and d>=job['clearance']-1e-7
    assert dict(required-counts)==result['missing']
    charged=st['width']*(st['height']+tops.get('sheet-1',0)+m['top']+e);assert charged<=target['target_material_mm2']+1e-6
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    command=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(RUN/'best-partial.json')]
    r=subprocess.run(command,capture_output=True,timeout=60);(OUT/'validator-stdout.json').write_bytes(r.stdout);(OUT/'validator-stderr.log').write_bytes(r.stderr);write(OUT/'command.json',{'command':command,'exit_code':r.returncode})
    public=json.loads(r.stdout)
    write(OUT/'checks.json',{'verified_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-t0,'source_hashes_unchanged':True,'all_lattice_transforms_reconstructed':True,'lattice_pairs':checks,'minimum_component_distance_mm':mind,'attempt_inventories_verified':attempts,'rejected_attempt_pair_geometry_not_claimed':True,'max_attempt_placed_count':maximum_count,'selected_filled_outer_pairs':layoutpairs,'selected_minimum_clearance_slack_mm':slack,'missing':dict(required-counts),'charged_material_mm2':charged,'material_target_mm2':target['target_material_mm2'],'complete_witness':complete>0,'public_report':public})
    print(json.dumps(load(OUT/'checks.json')),flush=True)
if __name__=='__main__':main()
