"""Require all frames and brackets simultaneously before insert completion."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
OLD=ROOT/'output/h5-whole-frame-census-20261020'
OUT=ROOT/'output/h5-joint-frames-brackets-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[SRC/n for n in ['job.json','candidates.json','mapping.json','cog-skeletons.json',
        'projected-cliques.jsonl.gz','audit/checks.json','conditional-target.json']]
    inputs += [OLD/'groups.json',ROOT/'benchmarks/results/h5-frame-bracket-diagnosis-20261020/checks.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'cases':[0,1,2,3],'seconds_per_case':30,'workers':8,'seed':0,
        'method':'Fix one original full 15-cog arrangement. Select exactly 18 whole frames and 12 whole brackets simultaneously, using all compatible original poses and every projected original conflict clique. Exclude the 26 old exact frame sets. Minimize the sum of the numbers of eligible insert poses blocked by each selected frame or bracket; blocked poses may count repeatedly, so this is only a ranking heuristic. No insert is physically selected at this stage.',
        'followup':'For only the final group in each feasible case, at most four, independently check original geometry and build an exact insert-only completion model using every surviving original insert pose and conflict. One 20-second solve per group, maximizing inserts up to original cap 21. Preserve all statuses and returned incumbents. No suffix retry.',
        'acceptance':'The original 66-copy inventory, stock, clearances, target, native margins and full H5 gates remain unchanged. Restricted failure is not unrestricted impossibility.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');mapping={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    selectedids={i for i in mapping if pool[i]['placement']['part_id'] in ['frame','bracket']}
    insertids=set(mapping)-selectedids;neighbors={i:set() for i in selectedids}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    for c in cliques:
        for i in c&selectedids:neighbors[i].update(c&insertids)
    groups=load(OLD/'groups.json');prepared=[]
    for case in range(4):
        dest=OUT/f'case-{case}';dest.mkdir()
        ids=sorted(i for i in selectedids if case in mapping[i]['compatible_skeletons']);idset=set(ids)
        ins={i for i in insertids if case in mapping[i]['compatible_skeletons']}
        rows=sorted({tuple(sorted(c&idset)) for c in cliques if len(c&idset)>1})
        exclusions=[g['candidates'] for g in groups if set(g['candidates'])<=idset]
        costs=[{'candidate':i,'blocked_inserts':len(neighbors[i]&ins)} for i in ids]
        model=cp_model.CpModel();variables={i:model.new_bool_var(f'p{i}') for i in ids}
        for c in rows:model.add_at_most_one(variables[i] for i in c)
        for family,count in [('frame',18),('bracket',12)]:
            model.add(sum(variables[i] for i in ids if pool[i]['placement']['part_id']==family)==count)
        for group in exclusions:model.add(sum(variables[i] for i in group)<=17)
        model.minimize(sum(r['blocked_inserts']*variables[r['candidate']] for r in costs))
        assert model.validate()=='';model.export_to_file(str(dest/'model.pbtxt'))
        write(dest/'mapping.json',{'case':case,'candidates':ids,'costs':costs,'eligible_inserts':len(ins),
            'excluded_frame_sets':exclusions})
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=30
        solver.parameters.num_search_workers=8;solver.parameters.random_seed=0
        solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (dest/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        prepared.append({'case':case,'variables':len(ids),'conflict_cliques':len(rows),'excluded_sets':len(exclusions),
            'model_sha256':digest(dest/'model.pbtxt'),'parameters_sha256':digest(dest/'parameters.pbtxt')})
    write(OUT/'prepared.json',prepared);print(json.dumps(prepared),flush=True)
if __name__=='__main__':main()
