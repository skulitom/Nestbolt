from datetime import datetime,timezone
import json,shutil,time,traceback
from ortools.sat.python import cp_model
from build_h5_joint_frames_brackets import OUT,load,write,digest
def main():
    assert load(OUT/'model-audit.json')['all_four_models_exact']
    shutil.copyfile(__file__,OUT/'solve.py');results=[]
    for prepared in load(OUT/'prepared.json'):
        case=prepared['case'];dest=OUT/f'case-{case}';mp=load(dest/'mapping.json')
        assert digest(dest/'model.pbtxt')==prepared['model_sha256']
        assert digest(dest/'parameters.pbtxt')==prepared['parameters_sha256']
        model=cp_model.CpModel();assert model.proto.parse_text_format((dest/'model.pbtxt').read_text())
        model.rebuild_constant_map();assert model.validate()==''
        solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((dest/'parameters.pbtxt').read_text())
        write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':30})
        incumbents=[]
        class Capture(cp_model.CpSolverSolutionCallback):
            def on_solution_callback(self):
                ids=[i for j,i in enumerate(mp['candidates']) if self.value(model.get_int_var_from_proto_index(j))]
                r={'index':len(incumbents),'selected_indices':ids,'heuristic_cost':self.objective_value,'seconds':self.wall_time}
                write(dest/f"incumbent-{r['index']}.json",r);incumbents.append(r)
        with (dest/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
            solver.log_callback=lambda s:(log.write(s+'\n'),log.flush())
            start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
        feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
        result={'case':case,'status':solver.status_name(status),'seconds':seconds,'feasible':feasible,
            'incumbents':len(incumbents),'response_stats':solver.response_stats(),
            'full_target_witness':False,'native_margin_qualified':False}
        if feasible:
            ids=[i for j,i in enumerate(mp['candidates']) if solver.value(model.get_int_var_from_proto_index(j))]
            assert len(ids)==30;write(dest/'selected-indices.json',ids)
            result.update(heuristic_cost=solver.objective_value,best_cost_bound=solver.best_objective_bound)
        write(dest/'result.json',result);results.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!='response_stats'}),flush=True)
    write(OUT/'results.json',results)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
