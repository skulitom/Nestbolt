"""Check every whole frame/bracket/cog proposal and freeze final insert candidates."""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations
import gzip,json,math,shutil
from audit_h5_cog_lattices import shape,load,write,digest
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
OUT=ROOT/'output/h5-joint-frames-brackets-20261020';OLD=ROOT/'output/h5-whole-frame-census-20261020'
def main():
    shutil.copyfile(__file__,OUT/'audit-results.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');mp={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0]
    m=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json')
    cogs=load(SRC/'cog-skeletons.json')['sets'];old={tuple(g['candidates']) for g in load(OLD/'groups.json')}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    checked=[];finals=[];outcomes=[]
    for result in load(OUT/'results.json'):
        case=result['case'];dest=OUT/f'case-{case}';mapping=load(dest/'mapping.json')
        if not result['feasible']:
            assert result['incumbents']==0 and not (dest/'selected-indices.json').exists()
            outcomes.append({'case':case,'status':result['status'],'seconds':result['seconds'],'returned_group':False});continue
        final=load(dest/'selected-indices.json')
        records=[load(dest/f'incumbent-{i}.json') for i in range(result['incumbents'])]
        if final!=records[-1]['selected_indices']:
            records.append({'index':'final','selected_indices':final,'heuristic_cost':result['heuristic_cost']})
        costs={r['candidate']:r['blocked_inserts'] for r in mapping['costs']}
        for record in records:
            chosen=record['selected_indices'];assert len(chosen)==len(set(chosen))==30
            assert set(chosen)<=set(mapping['candidates'])
            frames=tuple(i for i in chosen if pool[i]['placement']['part_id']=='frame')
            assert frames not in old and sum(costs[i] for i in chosen)==record['heuristic_cost']
            assert Counter(pool[i]['placement']['part_id'] for i in chosen)=={'frame':18,'bracket':12}
            assert all(len(c&set(chosen))<=1 for c in cliques)
            ids=chosen+cogs[case]['candidates'];geometries=defaultdict(list)
            for i in ids:
                p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform']
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind']=='list':
                    assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
                g=shape(part,t);x0,y0,x1,y1=g.bounds
                h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
                assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
                assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7
                geometries[p['sheet_id']].append(g)
            pairs=0;minimum=math.inf
            for gs in geometries.values():
                for a,b in combinations(gs,2):
                    pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                    assert a.disjoint(b) and distance>=job['clearance']-1e-7
            checked.append({'case':case,'incumbent':record['index'],'pairs':pairs,'minimum_distance_mm':minimum,
                'heuristic_cost':record['heuristic_cost']})
        blocked=set()
        for clique in cliques:
            if clique&set(final):blocked.update(clique-set(final))
        insertids=sorted(i for i,r in mp.items() if pool[i]['placement']['part_id']=='insert'
            and case in r['compatible_skeletons'] and i not in blocked)
        finals.append({'case':case,'fixed_candidates':sorted(final+cogs[case]['candidates']),'insert_candidates':insertids})
        outcomes.append({'case':case,'status':result['status'],'seconds':result['seconds'],'returned_group':True,
            'insert_candidates':len(insertids),'heuristic_cost':result['heuristic_cost']})
    write(OUT/'completion-inputs.json',finals)
    check={'all_returned_groups_checked':len(checked),'records':checked,'cases':outcomes,
        'final_groups_for_completion':len(finals),'exact_frame_quantity':18,'exact_bracket_quantity':12,
        'full_target_witness':False,'native_margin_qualified':False,'no_insert_completion_credit_yet':True}
    write(OUT/'result-audit.json',check)
    print(json.dumps({k:v for k,v in check.items() if k!='records'}),flush=True)
if __name__=='__main__':main()
