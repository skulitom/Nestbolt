"""Independently reconstruct the joint model from original candidate cliques."""
import gzip,json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from build_h5_joint_frames_brackets import ROOT,SRC,OLD,OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'audit-model.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');mapping={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    groups=load(OLD/'groups.json');checks=[]
    for r in load(OUT/'prepared.json'):
        case=r['case'];dest=OUT/f'case-{case}';mp=load(dest/'mapping.json')
        assert digest(dest/'model.pbtxt')==r['model_sha256']
        eligible={i for i,m in mapping.items() if case in m['compatible_skeletons']}
        ids=sorted(i for i in eligible if pool[i]['placement']['part_id']!='insert')
        ins=eligible-set(ids);assert ids==mp['candidates'] and len(ins)==mp['eligible_inserts']
        owner={i:[] for i in ids}
        for ci,c in enumerate(cliques):
            for i in c&owner.keys():owner[i].append(ci)
        costs=[{'candidate':i,'blocked_inserts':len(set().union(*(cliques[ci] for ci in owner[i]))&ins)} for i in ids]
        assert costs==mp['costs'];local={i:j for j,i in enumerate(ids)}
        rows=sorted({tuple(sorted(c&local.keys())) for c in cliques if len(c&local.keys())>1})
        exclusions=[g['candidates'] for g in groups if set(g['candidates'])<=local.keys()]
        assert exclusions==mp['excluded_frame_sets']
        expected=cp_model_pb2.CpModelProto()
        for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
        for row in rows:expected.constraints.add().at_most_one.literals.extend(local[i] for i in row)
        for family,count in [('frame',18),('bracket',12)]:
            indices=[local[i] for i in ids if pool[i]['placement']['part_id']==family]
            c=expected.constraints.add().linear;c.vars.extend(indices);c.coeffs.extend([1]*len(indices));c.domain.extend([count,count])
        for group in exclusions:
            c=expected.constraints.add().linear;c.vars.extend(local[i] for i in group);c.coeffs.extend([1]*18);c.domain.extend([-(2**63),17])
        for j,cost in enumerate(costs):
            if cost['blocked_inserts']:
                expected.objective.vars.append(j);expected.objective.coeffs.append(cost['blocked_inserts'])
        expected.objective.scaling_factor=1
        actual=text_format.Parse((dest/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
        checks.append({'case':case,'variables':len(ids),'cliques':len(rows),'full_model_reconstructed':True,
            'all_costs_recomputed':True,'exact_frame_quantity':18,'exact_bracket_quantity':12})
    write(OUT/'model-audit.json',{'all_four_models_exact':True,'cases':checks})
    print(json.dumps(checks),flush=True)
if __name__=='__main__':main()
