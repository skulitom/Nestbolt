"""Record exact adaptations for six direct-substitution completion cases."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-substituted-completion-adapter-20261020'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'adapt.py')
    specs=[
        ('prepare_h5_joint_insert_completion.py','prepare_h5_substituted_insert_completion.py',[
            ('assert len(groups)<=4','assert len(groups)<=6'),
            ("case=group['case'];dest=OUT/f'case-{case}';dest.mkdir();fixed=set(group['fixed_candidates'])",
             "case=group['case'];si=group['cog_case'];dest=OUT/f'case-{case}';dest.mkdir();fixed=set(group['fixed_candidates'])"),
            ("cogs[case]['candidates']","cogs[si]['candidates']"),
            ("and case in r['compatible_skeletons']","and si in r['compatible_skeletons']"),
            ("'mapping.json',{'case':case,'fixed_candidates'","'mapping.json',{'case':case,'cog_case':si,'fixed_candidates'")]),
        ('solve_h5_joint_insert_completion.py','solve_h5_substituted_insert_completion.py',[
            ('from prepare_h5_joint_insert_completion import','from prepare_h5_substituted_insert_completion import')])]
    records=[]
    for old,new,changes in specs:
        source=ROOT/'output'/old;raw=source.read_bytes();shutil.copyfile(source,OUT/old);text=raw.decode()
        common=[('output/h5-joint-frames-brackets-20261020','output/h5-substituted-partials-20261020'),
            ('output/h5-joint-insert-completion-20261020','output/h5-substituted-insert-completion-20261020')]
        for a,b in common:text=text.replace(a,b)
        for a,b in changes:
            assert text.count(a)==1,(old,a,text.count(a));text=text.replace(a,b)
        p=ROOT/'output'/new
        with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
        records.append({'original':old,'sha256':sha256(raw).hexdigest(),'adapted':new,
            'adapted_sha256':sha256(p.read_bytes()).hexdigest(),'replacements':common+changes})
    (OUT/'adaptations.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'adapted_scripts':len(records)}),flush=True)
if __name__=='__main__':main()
