"""Verify every substitution independently using explicit candidate sets."""
from pathlib import Path
import gzip,json,shutil,time
from reduce_h5_dominated_poses import ROOT,SRC,PARENT,OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');mapping={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    substitutions={case:load(OUT/f'case-{case}/substitutions.json') for case in range(4)}
    needed={i for rows in substitutions.values() for r in rows for i in [r['removed'],r['kept']]}
    owners={i:[] for i in needed}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    for ci,group in enumerate(cliques):
        for i in group&needed:owners[i].append(ci)
    summaries=[]
    for case,rows in substitutions.items():
        mp=load(PARENT/f'case-{case}/mapping.json');kept=set(load(OUT/f'case-{case}/kept-candidates.json'))
        removed={r['removed'] for r in rows};assert kept|removed==set(mp['candidates']) and not kept&removed
        assert len(removed)==len(rows)
        eligible={i for i,m in mapping.items() if case in m['compatible_skeletons']}
        cached={}
        def adjacent(i):
            if i not in cached:cached[i]=(set().union(*(cliques[ci] for ci in owners[i]))&eligible)-{i}
            return cached[i]
        costs={r['candidate']:r['blocked_inserts'] for r in mp['costs']}
        for r in rows:
            a,b=r['kept'],r['removed']
            assert a in kept and b not in kept
            assert pool[a]['placement']['part_id']==pool[b]['placement']['part_id']==r['family']
            assert a in adjacent(b) and b in adjacent(a)
            assert adjacent(a)-{b} <= adjacent(b)-{a}
            for group in mp['excluded_frame_sets']:assert a not in group or b in group
            assert costs[a]<=costs[b]
        result=load(OUT/f'case-{case}/result.json')
        assert len(kept)==result['kept_joint_variables'] and len(rows)==result['removed_joint_variables']
        assert result['qualifies_for_reduced_solve']==(len(rows)*4>=len(mp['candidates']))
        summaries.append({'case':case,'substitutions_checked':len(rows),'all_dominators_survive':True,
            'full_eligible_insert_neighborhoods_included':True,'excluded_frame_rows_preserved':True,
            'source_geometry_unchanged':True,'qualifies_for_reduced_solve':result['qualifies_for_reduced_solve']})
    write(OUT/'audit.json',{'all_substitutions_verified_with_sets':True,'cases':summaries,
        'seconds':time.perf_counter()-start,'preserves_finite_pool_completion_existence':True,
        'unrestricted_impossibility_claimed':False})
    print(json.dumps(summaries),flush=True)
if __name__=='__main__':main()
