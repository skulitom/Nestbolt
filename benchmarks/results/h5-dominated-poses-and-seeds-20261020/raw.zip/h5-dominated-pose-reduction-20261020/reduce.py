"""Certified same-family substitutions preserve all finite-pool completions."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from hashlib import sha256
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
PARENT=ROOT/'output/h5-joint-frames-brackets-20261020'
OUT=ROOT/'output/h5-dominated-pose-reduction-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py')
    inputs=[SRC/n for n in ['candidates.json','mapping.json','projected-cliques.jsonl.gz','audit/checks.json']]
    inputs += [PARENT/n for n in ['plan.json','model-audit.json','result-audit.json']]
    inputs += [PARENT/f'case-{i}/mapping.json' for i in range(4)]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'maximum_seconds':60,'maximum_comparisons_per_case':10000000,
        'method':'For each fixed cog case, order eligible frame/bracket poses by full eligible conflict degree, then forbidden-frame-set incidence count, then original candidate index. Keep a pose unless an earlier kept same-family adjacent pose has no extra neighbor after removing the compared pair, across ALL eligible frame/bracket/insert poses, and belongs to no extra excluded frame set. Record each removed->kept substitution. Keep every unprocessed pose if the bound is reached. No rounding, changed geometry or deleted source data.',
        'preservation_argument':'Replacing removed B by kept A preserves family quantity. A and B conflict, so A was not already selected. Every other conflict of A was already a conflict of B, including all future inserts. A appears in no extra forbidden-frame-set row. Thus a feasible completion remains feasible after substitution, and blocked-insert cost cannot increase. Dominators are final survivors, so no replacement chains are required.',
        'followup':'Only cases removing at least 25% of joint variables may get one reduced-model solve of at most 30 seconds, after independent substitution and model audits. Less substantial reductions are not rerun.',
        'minimum_reduction_fraction_for_solve':0.25,'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');mp={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    universe=sorted(mp);position={i:j for j,i in enumerate(universe)};bits={i:1<<j for i,j in position.items()}
    adjacency={i:0 for i in universe}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            group=json.loads(line);mask=sum(bits[i] for i in group)
            for i in group:adjacency[i]|=mask^bits[i]
    started=time.perf_counter();summaries=[]
    for case in range(4):
        dest=OUT/f'case-{case}';dest.mkdir();parent=load(PARENT/f'case-{case}/mapping.json')
        eligible={i for i,r in mp.items() if case in r['compatible_skeletons']}
        mask=sum(bits[i] for i in eligible);neighbors={i:adjacency[i]&mask for i in eligible}
        ids=parent['candidates'];incidence={i:0 for i in ids}
        for j,group in enumerate(parent['excluded_frame_sets']):
            for i in group:incidence[i]|=1<<j
        order=sorted(ids,key=lambda i:(neighbors[i].bit_count(),incidence[i].bit_count(),i))
        kept=[];byfamily={'frame':[],'bracket':[]};removed=[];comparisons=0;bounded=False
        costs={r['candidate']:r['blocked_inserts'] for r in parent['costs']}
        for at,b in enumerate(order):
            if time.perf_counter()-started>=60 or comparisons>=10000000:
                kept.extend(order[at:]);bounded=True;break
            family=pool[b]['placement']['part_id'];dominator=None
            for a in byfamily[family]:
                comparisons+=1
                if comparisons>=10000000:break
                if not (neighbors[a]&bits[b]):continue
                if incidence[a]&~incidence[b]:continue
                if neighbors[a]&~neighbors[b]&~bits[b]:continue
                assert costs[a]<=costs[b];dominator=a;break
            if dominator is None:kept.append(b);byfamily[family].append(b)
            else:removed.append({'removed':b,'kept':dominator,'family':family})
        assert set(kept)|{r['removed'] for r in removed}==set(ids)
        assert not(set(kept)&{r['removed'] for r in removed})
        write(dest/'substitutions.json',removed);write(dest/'kept-candidates.json',sorted(kept))
        summary={'case':case,'original_joint_variables':len(ids),'kept_joint_variables':len(kept),
            'removed_joint_variables':len(removed),'removed_by_family':dict(Counter(r['family'] for r in removed)),
            'comparison_count':comparisons,'bounded_early':bounded,
            'qualifies_for_reduced_solve':len(removed)*4>=len(ids)}
        write(dest/'result.json',summary);summaries.append(summary);print(json.dumps(summary),flush=True)
    write(OUT/'results.json',{'seconds':time.perf_counter()-started,'cases':summaries})
if __name__=='__main__':main()
