"""Validate substituted physical partials and freeze six insert-only completions."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import copy,json,math,shutil,subprocess
from audit_h5_cog_lattices import shape,load,write,digest
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
OUT=ROOT/'output/h5-substituted-partials-20261020';PARENT=ROOT/'output/h5-whole-group-selection-20261020'
RED=ROOT/'output/h5-dominated-pose-reduction-20261020'
def main():
    dest=OUT/'geometry-audit';dest.mkdir();shutil.copyfile(__file__,dest/'audit.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    mp={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    target=load(SRC/'conditional-target.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    sheets=load(SRC/'selected-layout.json')['sheets'];records=[];groups=[]
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    import gzip
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    for record in load(OUT/'results.json'):
        case=record['source_case'];si=record['cog_case'];ids=record['selected_indices']
        counts=Counter();geoms=defaultdict(list);placements=[];tops=Counter()
        for i in ids:
            p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform']
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':
                assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
            g=shape(part,t);x0,y0,x1,y1=g.bounds;top=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
            assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=top-m['top']-edge+1e-7
            geoms[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
        assert counts['frame']==18 and counts['bracket']==12 and counts['cog']==15 and counts['insert']<21
        pairs=0;minimum=math.inf
        for gs in geoms.values():
            for a,b in combinations(gs,2):
                pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                assert a.disjoint(b) and distance>=job['clearance']-1e-7
        path=dest/f'layout-{case}.json';write(path,{'version':1,'units':'mm','sheets':sheets,'placements':placements})
        material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
        cmd=[str(cli),'validate','--library',str(SRC/'library.json'),'--request',str(SRC/'request.json'),'--layout',str(path)]
        cp=subprocess.run(cmd,capture_output=True,timeout=60)
        (dest/f'public-{case}.json').write_bytes(cp.stdout);(dest/f'public-{case}.stderr').write_bytes(cp.stderr)
        write(dest/f'command-{case}.json',{'command':cmd,'exit_code':cp.returncode})
        report=json.loads(cp.stdout)
        assert not report['valid'] and cp.returncode!=0
        assert report['violations']==[{'code':'quantity','message':f"part insert: expected 21, found {counts['insert']}"}]
        prior=load(PARENT/f'case-{case}/selected-indices.json')
        subs={r['removed']:r['kept'] for r in load(RED/f'case-{si}/substitutions.json')};moves=[]
        for i in prior:
            if i not in subs:continue
            a=pool[i]['placement'];b=pool[subs[i]]['placement']
            ga=shape(parts[a['part_id']],a['transform']);gb=shape(parts[b['part_id']],b['transform'])
            moves.append({'from':i,'to':subs[i],'family':a['part_id'],'filled_outline_hausdorff_mm':ga.hausdorff_distance(gb)})
        fixed=sorted(i for i in ids if pool[i]['placement']['part_id']!='insert');blocked=set()
        for c in cliques:
            if c&set(fixed):blocked.update(c-set(fixed))
        inserts=sorted(i for i,r in mp.items() if pool[i]['placement']['part_id']=='insert' and si in r['compatible_skeletons'] and i not in blocked)
        assert set(i for i in ids if pool[i]['placement']['part_id']=='insert')<=set(inserts)
        groups.append({'case':case,'cog_case':si,'fixed_candidates':fixed,'insert_candidates':inserts})
        records.append({'case':case,'cog_case':si,'inserts':counts['insert'],'pairs':pairs,'minimum_distance_mm':minimum,
            'charged_material_mm2':material,'movements':moves,'available_insert_poses':len(inserts),
            'frozen_CLI_original_quantity_only_failure':True})
    write(OUT/'completion-inputs.json',groups)
    check={'all_six_partials_original_geometry_checked':True,'cases':records,'full_target_witness':False,
        'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'result-audit.json',check)
    print(json.dumps([{k:v for k,v in r.items() if k!='movements'} for r in records]),flush=True)
if __name__=='__main__':main()
