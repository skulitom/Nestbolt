"""Apply certified substitutions once to each of the six known whole-group partials."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import gzip,json,shutil
from reduce_h5_dominated_poses import ROOT,SRC,OUT as RED,load,write,digest
PARENT=ROOT/'output/h5-whole-group-selection-20261020'
OUT=ROOT/'output/h5-substituted-partials-20261020'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py')
    inputs=[RED/'audit.json',SRC/'candidates.json',SRC/'projected-cliques.jsonl.gz',
        ROOT/'output/h5-whole-frame-census-20261020/groups.json']
    for i in range(4):inputs += [RED/f'case-{i}/substitutions.json',RED/f'case-{i}/kept-candidates.json']
    for i in range(6):inputs += [PARENT/f'case-{i}/mapping.json',PARENT/f'case-{i}/selected-indices.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'method':'One direct substitution pass over each of the six previously audited fixed-group partial layouts. Map frame/bracket candidates using the independently verified same-cog-case certificates; keep all inserts and cogs exactly. Check uniqueness, inventory and original conflict cliques, then report whether the frame set escapes all 26 old exclusions. No solver, placement generation or native packing.',
        'solver_calls':0,'native_packing_calls':0,'quality_runs':0})
    assert load(RED/'audit.json')['all_substitutions_verified_with_sets']
    pool=load(SRC/'candidates.json')
    old={tuple(g['candidates']) for g in load(ROOT/'output/h5-whole-frame-census-20261020/groups.json')}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    results=[]
    for case in range(6):
        mp=load(PARENT/f'case-{case}/mapping.json');si=mp['cog_group'];prior=load(PARENT/f'case-{case}/selected-indices.json')
        subs={r['removed']:r['kept'] for r in load(RED/f'case-{si}/substitutions.json')}
        ids=sorted(subs.get(i,i) for i in prior);assert len(ids)==len(set(ids))==len(prior)
        assert Counter(pool[i]['placement']['part_id'] for i in ids)==Counter(pool[i]['placement']['part_id'] for i in prior)
        assert all(len(c&set(ids))<=1 for c in cliques)
        assert set(i for i in ids if pool[i]['placement']['part_id'] in ['cog','insert'])==set(i for i in prior if pool[i]['placement']['part_id'] in ['cog','insert'])
        frames=tuple(i for i in ids if pool[i]['placement']['part_id']=='frame')
        record={'source_case':case,'cog_case':si,'changed_candidates':sum(i in subs for i in prior),
            'changed_frames':sum(i in subs and pool[i]['placement']['part_id']=='frame' for i in prior),
            'changed_brackets':sum(i in subs and pool[i]['placement']['part_id']=='bracket' for i in prior),
            'new_frame_set_outside_original_exclusions':frames not in old,
            'inventory_and_conflict_checks_pass':True,'selected_indices':ids,'full_target_witness':False}
        write(OUT/f'case-{case}.json',record);results.append(record)
    write(OUT/'results.json',results)
    print(json.dumps([{k:v for k,v in r.items() if k!='selected_indices'} for r in results]),flush=True)
if __name__=='__main__':main()
