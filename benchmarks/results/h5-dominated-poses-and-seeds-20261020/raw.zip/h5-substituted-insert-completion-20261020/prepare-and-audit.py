"""Freeze and independently reconstruct exact insert-only completion models."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from hashlib import sha256
import gzip,json,shutil
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
PARENT=ROOT/'output/h5-substituted-partials-20261020';OUT=ROOT/'output/h5-substituted-insert-completion-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare-and-audit.py')
    inputs=[PARENT/'completion-inputs.json',PARENT/'result-audit.json',PARENT/'plan.json']
    inputs += [SRC/n for n in ['candidates.json','job.json','mapping.json','cog-skeletons.json',
        'projected-cliques.jsonl.gz','conditional-target.json']]
    groups=load(PARENT/'completion-inputs.json');assert len(groups)<=6
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},'cases':[g['case'] for g in groups],
        'seconds_per_case':20,'workers':8,'seed':0,
        'method':'Fix each audited final group of 18 frames, 12 brackets and 15 cogs. Select original insert poses only, preserving every projected original conflict and maximizing their count up to the unchanged 21-copy cap. One bounded solve per distinct case, no retry. Empty candidate pools get the direct bound zero without a solve.',
        'acceptance':'Any full 66-copy result needs original geometry, frozen CLI and native-margin checks before full H5 qualification.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');mp={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    cogs=load(SRC/'cog-skeletons.json')['sets']
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    prepared=[]
    for group in groups:
        case=group['case'];si=group['cog_case'];dest=OUT/f'case-{case}';dest.mkdir();fixed=set(group['fixed_candidates'])
        assert Counter(pool[i]['placement']['part_id'] for i in fixed)=={'frame':18,'bracket':12,'cog':15}
        assert sorted(i for i in fixed if pool[i]['placement']['part_id']=='cog')==cogs[si]['candidates']
        blocked=set()
        for c in cliques:
            assert len(c&fixed)<=1
            if c&fixed:blocked.update(c-fixed)
        ids=sorted(i for i,r in mp.items() if pool[i]['placement']['part_id']=='insert'
            and si in r['compatible_skeletons'] and i not in blocked)
        assert ids==group['insert_candidates'];local={i:j for j,i in enumerate(ids)}
        rows=sorted({tuple(sorted(c&local.keys())) for c in cliques if len(c&local.keys())>1})
        write(dest/'mapping.json',{'case':case,'cog_case':si,'fixed_candidates':sorted(fixed),'insert_candidates':ids})
        if not ids:
            prepared.append({'case':case,'empty':True,'direct_insert_upper_bound':0});continue
        model=cp_model.CpModel();variables={i:model.new_bool_var(f'p{i}') for i in ids}
        for row in rows:model.add_at_most_one(variables[i] for i in row)
        model.add(sum(variables.values())<=21);model.maximize(sum(variables.values()))
        assert model.validate()=='';model.export_to_file(str(dest/'model.pbtxt'))
        expected=cp_model_pb2.CpModelProto()
        for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
        # Reconstruct projected rows a second way from saved original cliques.
        independent=set()
        for source in cliques:
            selected=tuple(j for j,i in enumerate(ids) if i in source)
            if len(selected)>1:independent.add(selected)
        for row in sorted(independent):expected.constraints.add().at_most_one.literals.extend(row)
        c=expected.constraints.add().linear;c.vars.extend(range(len(ids)));c.coeffs.extend([1]*len(ids));c.domain.extend([-(2**63),21])
        expected.objective.vars.extend(range(len(ids)));expected.objective.coeffs.extend([-1]*len(ids));expected.objective.scaling_factor=-1
        actual=text_format.Parse((dest/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=20;solver.parameters.num_search_workers=8
        solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (dest/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        prepared.append({'case':case,'variables':len(ids),'cliques':len(rows),'model_exactly_reconstructed':True,
            'model_sha256':digest(dest/'model.pbtxt'),'parameters_sha256':digest(dest/'parameters.pbtxt'),'empty':False})
    write(OUT/'prepared.json',prepared);print(json.dumps(prepared),flush=True)
if __name__=='__main__':main()
