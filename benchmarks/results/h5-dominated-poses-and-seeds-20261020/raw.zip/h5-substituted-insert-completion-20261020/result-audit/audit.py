"""Audit all insert-completion returns against original geometry and frozen CLI."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import copy,json,math,shutil,subprocess
from audit_h5_cog_lattices import shape,load,write,digest
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
RUN=ROOT/'output/h5-substituted-insert-completion-20261020';OUT=RUN/'result-audit'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    for p,h in load(RUN/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    target=load(SRC/'conditional-target.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    sheets=load(SRC/'selected-layout.json')['sheets'];records=[]
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    for result in load(RUN/'results.json'):
        case=result['case'];source=RUN/f'case-{case}';dest=OUT/f'case-{case}';dest.mkdir()
        mp=load(source/'mapping.json');outcomes=[load(source/f'incumbent-{i}.json') for i in range(result['incumbents'])]
        final=load(source/'selected-indices.json')
        if not outcomes or final!=outcomes[-1]['selected_indices']:
            outcomes.append({'index':'final','selected_indices':final,'inserts':result['inserts']})
        for record in outcomes:
            ids=record['selected_indices'];assert len(ids)==len(set(ids))
            assert set(mp['fixed_candidates'])<=set(ids)
            assert set(ids)-set(mp['fixed_candidates'])<=set(mp['insert_candidates'])
            counts=Counter();placements=[];geoms=defaultdict(list);tops=Counter()
            for i in ids:
                p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform']
                p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind']=='list':
                    assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
                g=shape(part,t);x0,y0,x1,y1=g.bounds;top=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
                assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
                assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=top-m['top']-edge+1e-7
                geoms[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
            assert counts==Counter(frame=18,bracket=12,cog=15,insert=record['inserts'])
            pairs=0;minimum=math.inf
            for gs in geoms.values():
                for a,b in combinations(gs,2):
                    pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                    assert a.disjoint(b) and distance>=job['clearance']-1e-7
            key=record['index'];path=dest/f'layout-{key}.json'
            write(path,{'version':1,'units':'mm','sheets':sheets,'placements':placements})
            material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
            cmd=[str(cli),'validate','--library',str(SRC/'library.json'),'--request',str(SRC/'request.json'),'--layout',str(path)]
            cp=subprocess.run(cmd,capture_output=True,timeout=60)
            (dest/f'public-{key}.json').write_bytes(cp.stdout);(dest/f'public-{key}.stderr').write_bytes(cp.stderr)
            write(dest/f'command-{key}.json',{'command':cmd,'exit_code':cp.returncode});public=json.loads(cp.stdout)
            missing=21-record['inserts'];assert public['valid']==(missing==0)
            if missing:
                assert cp.returncode!=0
                assert public['violations']==[{'code':'quantity','message':f"part insert: expected 21, found {record['inserts']}"}]
            else:assert cp.returncode==0 and not public['violations']
            records.append({'case':case,'incumbent':key,'inserts':record['inserts'],'missing_inserts':missing,
                'pairs':pairs,'minimum_distance_mm':minimum,'charged_material_mm2':material,
                'filled_area_mm2':sum(g.area for gs in geoms.values() for g in gs),'original_CLI_valid':public['valid']})
        assert result['status']=='OPTIMAL' and result['inserts']==result['best_bound']==records[-1]['inserts']
    check={'all_returned_layouts_checked':len(records),'records':records,
        'best_insert_count':max(r['inserts'] for r in records),'full_target_witness':any(r['original_CLI_valid'] for r in records),
        'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
