from datetime import datetime,timezone
import json,shutil,time,traceback
from ortools.sat.python import cp_model
from prepare_h5_substituted_insert_completion import OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'solve.py');results=[]
    for prepared in load(OUT/'prepared.json'):
        case=prepared['case'];dest=OUT/f'case-{case}';mp=load(dest/'mapping.json')
        if prepared['empty']:
            r={'case':case,'status':'EMPTY_POOL','inserts':0,'incumbents':0,'solver_called':False}
            write(dest/'selected-indices.json',mp['fixed_candidates']);write(dest/'result.json',r);results.append(r);continue
        assert prepared['model_exactly_reconstructed'] and digest(dest/'model.pbtxt')==prepared['model_sha256']
        assert digest(dest/'parameters.pbtxt')==prepared['parameters_sha256']
        model=cp_model.CpModel();assert model.proto.parse_text_format((dest/'model.pbtxt').read_text())
        model.rebuild_constant_map();assert model.validate()==''
        solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((dest/'parameters.pbtxt').read_text())
        write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':20})
        incumbents=[]
        class Capture(cp_model.CpSolverSolutionCallback):
            def on_solution_callback(self):
                chosen=[i for j,i in enumerate(mp['insert_candidates']) if self.value(model.get_int_var_from_proto_index(j))]
                r={'index':len(incumbents),'selected_indices':sorted(mp['fixed_candidates']+chosen),'inserts':len(chosen),
                    'seconds':self.wall_time,'best_bound':self.best_objective_bound}
                write(dest/f"incumbent-{r['index']}.json",r);incumbents.append(r)
        with (dest/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
            solver.log_callback=lambda s:(log.write(s+'\n'),log.flush())
            start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
        feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
        result={'case':case,'status':solver.status_name(status),'seconds':seconds,'feasible':feasible,
            'incumbents':len(incumbents),'response_stats':solver.response_stats(),'solver_called':True,
            'full_target_witness':False,'native_margin_qualified':False}
        if feasible:
            chosen=[i for j,i in enumerate(mp['insert_candidates']) if solver.value(model.get_int_var_from_proto_index(j))]
            write(dest/'selected-indices.json',sorted(mp['fixed_candidates']+chosen))
            result.update(inserts=len(chosen),missing_inserts=21-len(chosen),best_bound=solver.best_objective_bound,
                full_inventory_candidate=len(chosen)==21)
        write(dest/'result.json',result);results.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!='response_stats'}),flush=True)
    write(OUT/'results.json',results)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
