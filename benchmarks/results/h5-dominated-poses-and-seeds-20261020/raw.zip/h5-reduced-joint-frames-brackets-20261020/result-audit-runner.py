"""Use the unchanged bounded solver and result auditor with the reduced root."""
from pathlib import Path
import sys,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-reduced-joint-frames-brackets-20261020'
def main():
    if '--audit' in sys.argv:
        import audit_h5_joint_frames_brackets_results as run
        shutil.copyfile(__file__,OUT/'result-audit-runner.py')
    else:
        import solve_h5_joint_frames_brackets as run
        shutil.copyfile(__file__,OUT/'solver-runner.py')
    run.OUT=OUT
    run.main()
if __name__=='__main__':
    try:main()
    except BaseException:
        p=OUT/('result-audit-failure.txt' if '--audit' in sys.argv else 'failure.txt')
        if not p.exists():p.write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
