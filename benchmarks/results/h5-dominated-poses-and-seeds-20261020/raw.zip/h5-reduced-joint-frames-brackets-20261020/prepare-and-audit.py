"""Build reduced joint models and audit them against restricted parent protobufs."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from hashlib import sha256
import json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
PARENT=ROOT/'output/h5-joint-frames-brackets-20261020'
RED=ROOT/'output/h5-dominated-pose-reduction-20261020'
OUT=ROOT/'output/h5-reduced-joint-frames-brackets-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare-and-audit.py')
    reduction=load(RED/'results.json');assert load(RED/'audit.json')['all_substitutions_verified_with_sets']
    assert all(r['qualifies_for_reduced_solve'] for r in reduction['cases'])
    inputs=[PARENT/'plan.json',PARENT/'prepared.json',PARENT/'model-audit.json',PARENT/'result-audit.json',
        RED/'plan.json',RED/'results.json',RED/'audit.json',SRC/'candidates.json',SRC/'mapping.json',
        SRC/'cog-skeletons.json',SRC/'projected-cliques.jsonl.gz',SRC/'job.json',SRC/'conditional-target.json',
        ROOT/'output/solve_h5_joint_frames_brackets.py',ROOT/'output/audit_h5_joint_frames_brackets_results.py']
    for i in range(4):inputs += [PARENT/f'case-{i}/model.pbtxt',PARENT/f'case-{i}/mapping.json',
        PARENT/f'case-{i}/parameters.pbtxt',RED/f'case-{i}/kept-candidates.json',RED/f'case-{i}/substitutions.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},'cases':[0,1,2,3],
        'seconds_per_case':30,'workers':8,'seed':0,
        'method':'Restrict each audited parent joint model to its independently certified surviving poses. Preserve exact frame/bracket quantities, excluded-frame rows and heuristic cost; drop only false literals and tautological projected constraints. These cases meet the predeclared 25% reduction threshold. Each smaller model receives one fresh 30-second bounded solve, not a continuation or replacement of the failed parent result.',
        'followup':'Only a final feasible group may enter the already declared exact 20-second insert completion check. No full-job credit from this stage.',
        'preservation':'Every removed pose has a final surviving same-family substitute with no extra conflict across all original eligible insert poses and no extra excluded-frame-set membership. Finite-pool completion existence and no-worse heuristic optimum are preserved.',
        'native_packing_calls':0,'quality_runs':0})
    prepared=[];checks=[]
    for case in range(4):
        source=PARENT/f'case-{case}';dest=OUT/f'case-{case}';dest.mkdir()
        mp=load(source/'mapping.json');ids=load(RED/f'case-{case}/kept-candidates.json');keep=set(ids)
        old=text_format.Parse((source/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        old_ids=mp['candidates'];new_index={i:j for j,i in enumerate(ids)}
        remap={j:new_index[i] for j,i in enumerate(old_ids) if i in keep}
        model=cp_model.CpModel();vars=[model.new_bool_var(f'p{i}') for i in ids];expected=cp_model_pb2.CpModelProto()
        for oldvar in remap:expected.variables.add().CopyFrom(old.variables[oldvar])
        removed_tautologies=0
        for constraint in old.constraints:
            kind=constraint.WhichOneof('constraint')
            if kind=='at_most_one':
                literals=[remap[j] for j in constraint.at_most_one.literals if j in remap]
                if len(literals)<=1:removed_tautologies+=1;continue
                model.add_at_most_one(vars[j] for j in literals)
                expected.constraints.add().at_most_one.literals.extend(literals)
            else:
                assert kind=='linear' and len(constraint.linear.domain)==2
                terms=[(remap[j],c) for j,c in zip(constraint.linear.vars,constraint.linear.coeffs) if j in remap]
                lo,hi=constraint.linear.domain
                minimum=sum(min(0,c) for j,c in terms);maximum=sum(max(0,c) for j,c in terms)
                if lo<=minimum and hi>=maximum:removed_tautologies+=1;continue
                model.add_linear_constraint(sum(c*vars[j] for j,c in terms),lo,hi)
                target=expected.constraints.add().linear
                target.vars.extend(j for j,c in terms);target.coeffs.extend(c for j,c in terms);target.domain.extend([lo,hi])
        terms=[(remap[j],c) for j,c in zip(old.objective.vars,old.objective.coeffs) if j in remap]
        assert old.objective.scaling_factor==1 and old.objective.offset==0
        model.minimize(sum(c*vars[j] for j,c in terms))
        expected.objective.vars.extend(j for j,c in terms);expected.objective.coeffs.extend(c for j,c in terms)
        expected.objective.scaling_factor=1
        assert model.validate()=='';model.export_to_file(str(dest/'model.pbtxt'))
        actual=text_format.Parse((dest/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
        write(dest/'mapping.json',{**mp,'candidates':ids,'costs':[r for r in mp['costs'] if r['candidate'] in keep]})
        shutil.copyfile(source/'parameters.pbtxt',dest/'parameters.pbtxt')
        prepared.append({'case':case,'variables':len(ids),'model_sha256':digest(dest/'model.pbtxt'),
            'parameters_sha256':digest(dest/'parameters.pbtxt')})
        checks.append({'case':case,'parent_variables':len(old.variables),'retained_variables':len(ids),
            'retained_constraints':len(expected.constraints),'removed_tautologies':removed_tautologies,
            'restricted_parent_model_exactly_reconstructed':True,'safe_substitutions_independently_verified':True})
    write(OUT/'prepared.json',prepared);write(OUT/'model-audit.json',{'all_four_models_exact':True,'cases':checks})
    print(json.dumps(checks),flush=True)
if __name__=='__main__':main()
