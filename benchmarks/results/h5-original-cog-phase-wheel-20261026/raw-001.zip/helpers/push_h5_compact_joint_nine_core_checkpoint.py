"""Push the audited joint source graph and compact domain checkpoint after completed prior-main CI."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-compact-joint-nine-core-main-sync-20261026';OUT.mkdir();expected_head=sys.argv[1]
def write(n,v):
    with (OUT/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name):
    p=subprocess.run(args,cwd=ROOT,capture_output=True,text=True);write(name+'.json',{'utc':datetime.now(timezone.utc).isoformat(),'args':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});p.check_returncode();return p.stdout.strip()
ci=json.loads(run(['gh','run','view','40336537934','--json','databaseId,status,conclusion,headSha,jobs,url'],'prior-ci'));assert ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
run(['git','fetch','origin','main'],'fetch');head=run(['git','rev-parse','HEAD'],'head-before');main=run(['git','rev-parse','origin/main'],'main-before');assert head==expected_head and len(head)==40 and main=='32282158178d201e95c4c3defa028e06579e7bec' and ci['headSha']==main
assert run(['git','rev-list','--left-right','--count','origin/main...HEAD'],'ancestry').split()==['0','1'] and run(['git','rev-parse','HEAD^'],'parent')==main and not run(['git','diff','HEAD','--name-only'],'tracked-diff')
paths=run(['git','diff','--name-only','origin/main...HEAD'],'changed-paths').splitlines();assert all(p in ['.gitattributes','BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md'] or p.startswith('benchmarks/results/h5-compact-joint-model-and-nine-insert-core-20261026') for p in paths)
run(['git','push','origin','HEAD:main'],'push');assert run(['git','ls-remote','origin','refs/heads/main'],'remote-after').split()[0]==head and run(['git','rev-parse','origin/main'],'tracking-after')==head
run(['gh','run','list','--repo','skulitom/Nestbolt','--branch','main','--commit',head,'--limit','10','--json','databaseId,name,status,conclusion,headSha,url,createdAt,updatedAt'],'new-ci-initial')
record={'utc':datetime.now(timezone.utc).isoformat(),'head':head,'previous_main':main,'pushed_commits':1,'normal_fast_forward_push':True,'remote_main_verified':True,'previous_successful_ci':40336537934,'previous_ci_successful_jobs':6,'new_ci_pass_claimed':False,'production_and_readmes_unchanged':True,'H2_complete':False,'H5_complete':False,'completion_percent':60};write('receipt.json',record);print(record,flush=True)
