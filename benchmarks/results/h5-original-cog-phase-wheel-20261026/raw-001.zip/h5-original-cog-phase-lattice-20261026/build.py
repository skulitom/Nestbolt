"""Declare a finite original-cog phase construction for the new fixed27 core."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.affinity import translate
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-original-cog-phase-lattice-20261026'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
CORE=ROOT/'output/h5-central-nine-insert-core-20261026/audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
job=load(JOB);spec=load(CORE/'next-neighborhood.json');assert load(CORE/'checks.json')['passed']
guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);gap=.225
pitches=[260.,262.,264.,266.,268.];phases=[i*.5 for i in range(36)]
center=[139.723742,139.723742];radius=140.001
box=[146.535,2297.66,1353.465,2853.465]
plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,CORE/'next-neighborhood.json',CORE/'checks.json']},'construction_seconds_limit':60,'pitches_mm':pitches,'phases_degrees':phases,'rows':3,'columns':5,'odd_row_offset_fraction':.5,'center_box_mm':box,'pair_gap_mm':gap,'required_native_pair_gap_mm':required,'stock_guard_mm':guard,'source_center_mm':center,'source_outer_radius_bound_mm':radius,'maximum_phase_solver_calls':1,'phase_solver_seconds':20,'phase_shared_seconds':30,'mandatory_cogs':list(range(51,66)),'mandatory_noncogs':[18,19,20,23,24,27,47,48,49],'method':'Fresh original cog outlines, all fifteen required. Consider five declared triangular pitches and36 original angles, without assuming exact tooth symmetry. Build compatibility tables for every near pair; rigorously separated non-neighbor center pairs need no phase restriction. One audited phase CSP only. This is a necessary preparatory condition for this finite lattice family, not a full layout or an unrestricted exclusion. If it returns a positive, independently check all fifteen source cogs at the nine declared x/y anchor combinations against the current fixed27 originals; all six brackets and three inserts must subsequently be placed together using fresh contact regions. Select only the first returned phase assignment; no retry or reseed. Negative/unknown closes this lattice construction. No old fixed24 domains, poses or exclusions transfer. Native validation only after all66 originals.' ,'anchor_fractions':[0.,.5,1.],'no_objective_or_hints':True}
write(OUT/'plan.json',plan)
source=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];assert max(math.hypot(x-center[0],y-center[1]) for x,y in source)<radius
shapes=[]
for degrees in phases:
    a=math.radians(degrees);co,si=math.cos(a),math.sin(a)
    shapes.append(Polygon([((x-center[0])*co-(y-center[1])*si,(x-center[0])*si+(y-center[1])*co) for x,y in source]))
shapes=np.asarray(shapes,dtype=object);nodes=[{'index':5*r+c,'row':r,'column':c,'x_factor':c+.5*(r%2),'y_factor':r*math.sqrt(3)/2} for r in range(3) for c in range(5)]
directions=[(1.,0.),(.5,math.sqrt(3)/2),(-.5,math.sqrt(3)/2)];tables=[]
for pi,pitch in enumerate(pitches):
    for di,(dx,dy) in enumerate(directions):
        assert time.perf_counter()-start<60
        moved=np.asarray([translate(p,xoff=pitch*dx,yoff=pitch*dy) for p in shapes],dtype=object)
        distances=shapely.distance(shapes[:,None],moved[None,:]);allowed=np.argwhere(distances>gap).tolist()
        tables.append({'pitch_index':pi,'direction':di,'offset_mm':[pitch*dx,pitch*dy],'distances_mm':distances.tolist(),'allowed_phase_pairs':allowed})
edges=[];far=[]
for a in nodes:
    for b in nodes[a['index']+1:]:
        dx=b['x_factor']-a['x_factor'];dy=b['y_factor']-a['y_factor']
        d=math.hypot(dx,dy)
        if d<1.01:
            di=next(i for i,(x,y) in enumerate(directions) if abs(dx-x)<1e-12 and abs(dy-y)<1e-12)
            edges.append({'a':a['index'],'b':b['index'],'direction':di})
        else:
            lower=math.nextafter(d*min(pitches),-math.inf);assert lower>2*radius+gap
            far.append({'a':a['index'],'b':b['index'],'minimum_center_distance_mm':lower,'minimum_outer_distance_bound_mm':lower-2*radius})
assert len(edges)+len(far)==105
for pitch in pitches:assert 4.5*pitch<box[2]-box[0] and math.sqrt(3)*pitch<box[3]-box[1]
write(OUT/'nodes.json',nodes);write(OUT/'near-edges.json',edges);write(OUT/'far-pairs.json',far);write(OUT/'tables.json',tables)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'source_shapes':36,'tables':len(tables),'source_pair_distances':len(tables)*36*36,'near_pairs':len(edges),'far_pairs':len(far),'allowed_pairs_by_pitch_direction':[{'pitch':pitches[r['pitch_index']],'direction':r['direction'],'allowed':len(r['allowed_phase_pairs']),'max_distance_mm':max(map(max,r['distances_mm']))} for r in tables],'source_radius_bound_mm':radius,'fixed_first_originals':27,'fixed_short_originals':15,'all15_cogs_mandatory':True,'all9_noncogs_still_required':True,'source_inventory_accounted':66,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'result.json'),flush=True)
