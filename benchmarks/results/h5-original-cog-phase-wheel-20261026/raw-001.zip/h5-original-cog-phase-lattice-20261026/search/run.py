"""One closed 20-second finite phase call within30 shared seconds."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-cog-phase-lattice-20261026';OUT=BASE/'search'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    check=load(BASE/'model/checks.json');assert check['passed'] and digest(BASE/'model/model.pb')==check['model_sha256']
    for n,h in check['inputs'].items():assert digest(ROOT/n)==h,n
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model/model.pbtxt').read_text()) and model.validate()==''
    assert model.export_to_file(str(OUT/'model.pb')) and (OUT/'model.pb').read_bytes()==(BASE/'model/model.pb').read_bytes()
    solver=cp_model.CpSolver();params={'max_time_in_seconds':20.,'num_search_workers':4,'random_seed':0,'log_search_progress':True,'log_to_stdout':False}
    for k,v in params.items():setattr(solver.parameters,k,v)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':digest(OUT/'model.pb'),'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'params':params})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-start
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString())
    write(OUT/'result.json',{'status':solver.status_name(status),'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'branches':response.num_branches,'conflicts':response.num_conflicts,'solution':list(response.solution),'solver_soft_overrun_seconds':max(0.,response.wall_time-20),'returned_soft_overrun_seconds':max(0.,elapsed-20),'solver_calls':1,'closed':True,'all15_cogs_mandatory':True,'all9_noncogs_still_required':True,'full66_target_witness':False,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':30,'solver_seconds':20,'maximum_calls':1,'retry_permitted':False})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,30-(time.perf_counter()-start)));(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final result; call closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
