"""Independently enumerate all seven-cog assignments in the saved finite tables."""
from pathlib import Path
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-cog-phase-lattice-20261026';OUT=BASE/'wheel-audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');tables=load(BASE/'tables.json');edges=load(BASE/'near-edges.json');proof=load(BASE/'response-audit/wheel-reachability.json');summary=load(BASE/'response-audit/wheel-summary.json');assert load(BASE/'response-audit/checks.json')['passed']
assert summary['center']==6 and summary['cyclic_neighbors']==[7,12,11,5,1,2]
mat={(r['pitch_index'],r['direction']):r['distances_mm'] for r in tables};edge={(r['a'],r['b']):r['direction'] for r in edges};center=6;ring=summary['cyclic_neighbors'];records=[];visited=0;complete=0
def fits(pi,a,b,x,y):
    if a>b:a,b,x,y=b,a,y,x
    return mat[pi,edge[a,b]][x][y]>.225
for pi in range(5):
    for pc in range(36):
        ds=[[a for a in range(36) if fits(pi,center,n,pc,a)] for n in ring]
        for first in ds[0]:
            frontier=[set() for _ in range(6)];closings=set();stack=[(first,)]
            while stack:
                path=stack.pop();k=len(path)-1;frontier[k].add(path[-1]);visited+=1;assert visited<2000000 and time.perf_counter()-start<30
                if k==5:
                    if fits(pi,ring[5],ring[0],path[5],first):closings.add(path[5]);complete+=1
                    continue
                for candidate in ds[k+1]:
                    if fits(pi,ring[k],ring[k+1],path[-1],candidate):stack.append(path+(candidate,))
            records.append({'pitch_index':pi,'center_phase':pc,'first_phase':first,'domains':ds,'reachable_layers':[sorted(s) for s in frontier],'closing_phases':sorted(closings)})
assert records==proof and complete==0
band=sum(plan['required_native_pair_gap_mm']<d<=.225 for table in mat.values() for row in table for d in row)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'independent_depth_first_prefixes_visited':visited,'reachability_records_exact':len(records),'all_complete_wheel_assignments':complete,'all5_finite_lattices_rejected_by_contained7_cog_wheel':True,'distance_entries_between_native_gap_and_construction_gap':band,'phase_range_degrees':[0.,17.5],'phase_increment_degrees':.5,'pitches_mm':plan['pitches_mm'],'construction_gap_mm':.225,'scope':'Only these five pitches,36 phases and exact seven-cog relative positions. No claim excludes arbitrary angles, shifted centers, another contact graph or the fixed27 neighborhood.','solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
