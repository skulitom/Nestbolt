"""Audit the closed phase result, plus exact finite triangle and seven-cog wheel supports."""
from pathlib import Path
from hashlib import sha256
import json,math,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-cog-phase-lattice-20261026';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();modelcheck=load(BASE/'model/checks.json');assert modelcheck['passed']
for n,h in modelcheck['inputs'].items():assert digest(ROOT/n)==h,n
assert digest(SEARCH/'model.pb')==modelcheck['model_sha256'];opened=load(SEARCH/'opened.json');assert opened['maximum_calls']==1 and opened['solver_seconds']==20 and opened['shared_seconds']==30
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20.,num_search_workers=4,random_seed=0,log_search_progress=True,log_to_stdout=False)
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<30
status=cp_model_pb2.CpSolverStatus.Name(response.status);assert status==result['status']=='INFEASIBLE' and not response.solution and result['closed'] and result['solver_calls']==1
assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['branches']==0 and response.num_conflicts==result['conflicts']==0
assert 0<response.wall_time<=result['returned_solve_seconds']<=process['seconds'] and response.wall_time<20 and result['returned_solve_seconds']<20
log=(SEARCH/'solver.log').read_text();wall=float(re.findall(r'^walltime:\s+([0-9.]+)',log,re.M)[-1]);assert abs(wall-response.wall_time)<.000001 and 'Problem closed by presolve.' in log
tables=load(BASE/'tables.json');edges=load(BASE/'near-edges.json');supports={(r['pitch_index'],r['direction']):set(map(tuple,r['allowed_phase_pairs'])) for r in tables};edge={(e['a'],e['b']):e['direction'] for e in edges}
def allowed(pi,a,b,pa,pb):
    if a>b:a,b,pa,pb=b,a,pb,pa
    return (pa,pb) in supports[pi,edge[a,b]]
triangles=[];cert=[];wheel_solutions=[];center=6;ring=[7,12,11,5,1,2]
assert all(tuple(sorted((center,n))) in edge for n in ring) and all(tuple(sorted((ring[i],ring[(i+1)%6]))) in edge for i in range(6))
for pi in range(5):
    triples=[[a,b,c] for a,b in supports[pi,0] for c in range(36) if (a,c) in supports[pi,1] and (b,c) in supports[pi,2]];triples.sort();triangles.append({'pitch_index':pi,'nodes':[0,1,5],'supported_phase_triples':triples})
    count=0
    for pc in range(36):
        domains=[[p for p in range(36) if allowed(pi,center,n,pc,p)] for n in ring]
        for first in domains[0]:
            layers=[[first]]
            for k in range(1,6):layers.append([p for p in domains[k] if any(allowed(pi,ring[k-1],ring[k],q,p) for q in layers[-1])])
            close=[p for p in layers[-1] if allowed(pi,ring[-1],ring[0],p,first)];count+=len(close)
            cert.append({'pitch_index':pi,'center_phase':pc,'first_phase':first,'domains':domains,'reachable_layers':layers,'closing_phases':close})
    wheel_solutions.append({'pitch_index':pi,'closing_states':count})
write(OUT/'triangle-supports.json',triangles);write(OUT/'wheel-reachability.json',cert);write(OUT/'wheel-summary.json',{'center':center,'cyclic_neighbors':ring,'results':wheel_solutions,'scope':'Exact finite compatibility tables only. Reachability counts endpoint states, not all assignments. A zero count certifies no seven-cog wheel at the declared phase/pitch; nonzero is not a full15-cog witness.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'solver_calls':1,'closed':True,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'shared_budget_honored':True,'soft_overruns':False,'stopped_after_presolve':True,'finite_triangle_counts':[len(r['supported_phase_triples']) for r in triangles],'wheel_closing_states':[r['closing_states'] for r in wheel_solutions],'wheel_reachability_records':len(cert),'all15_cogs_mandatory':True,'all9_noncogs_still_required':True,'unrestricted_exclusion':False,'full66_target_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
