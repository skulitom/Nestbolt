"""Reconstruct all actual lattice edge pairs from source vertices, independently."""
from pathlib import Path
from hashlib import sha256
import itertools,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-cog-phase-lattice-20261026';OUT=BASE/'geometry-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');source=part['geometry'][0]['outer'];assert part['rotations']['kind']=='free' and not part['allow_mirror']
spec=load(ROOT/'output/h5-central-nine-insert-core-20261026/audit/next-neighborhood.json');assert spec['mandatory_moving_first_cogs']==list(range(51,66)) and spec['mandatory_moving_first_noncogs']==[18,19,20,23,24,27,47,48,49]
assert plan['pitches_mm']==[260.,262.,264.,266.,268.] and plan['phases_degrees']==[i/2 for i in range(36)]
nodes=load(BASE/'nodes.json');edges=load(BASE/'near-edges.json');far=load(BASE/'far-pairs.json');tables=load(BASE/'tables.json');lookup={(r['pitch_index'],r['direction']):r for r in tables};seen=set();maxerror=0.;pairs=0;radius=140.001
assert len(nodes)==15 and len(edges)==30 and len(far)==75 and len(tables)==15
assert max(math.dist(p,[139.723742,139.723742]) for p in source)<radius
for i,n in enumerate(nodes):
    row,col=divmod(i,5);assert n=={'index':i,'row':row,'column':col,'x_factor':col+.5*(row%2),'y_factor':row*math.sqrt(3)/2}
for pi,pitch in enumerate(plan['pitches_mm']):
    actual=[]
    for n in nodes:
        shapes=[]
        for degrees in plan['phases_degrees']:
            a=degrees*math.pi/180.;co,si=math.cos(a),math.sin(a)
            cx=400+n['x_factor']*pitch;cy=2300+n['y_factor']*pitch
            tx=cx-139.723742*co+139.723742*si;ty=cy-139.723742*si-139.723742*co
            shapes.append(Polygon([(x*co-y*si+tx,x*si+y*co+ty) for x,y in source]))
        actual.append(np.asarray(shapes,dtype=object))
    for e in edges:
        a,b=e['a'],e['b'];assert 0<=a<b<15
        if pi==0:assert (a,b) not in seen;seen.add((a,b))
        dx=nodes[b]['x_factor']-nodes[a]['x_factor'];dy=nodes[b]['y_factor']-nodes[a]['y_factor']
        direction=0 if abs(dy)<1e-12 else (1 if dx>0 else 2)
        assert e['direction']==direction and abs(math.hypot(dx,dy)-1)<1e-12
        r=lookup[pi,direction];assert np.max(np.abs(np.asarray(r['offset_mm'])-np.asarray([dx*pitch,dy*pitch])))<1e-10
        distances=shapely.distance(actual[a][:,None],actual[b][None,:]);error=float(np.max(np.abs(distances-np.asarray(r['distances_mm']))));assert error<1e-8;maxerror=max(maxerror,error)
        assert np.argwhere(distances>.225).tolist()==r['allowed_phase_pairs'];pairs+=36*36
    for f in far:
        a,b=f['a'],f['b'];assert 0<=a<b<15
        if pi==0:assert (a,b) not in seen;seen.add((a,b))
        d=math.hypot(nodes[b]['x_factor']-nodes[a]['x_factor'],nodes[b]['y_factor']-nodes[a]['y_factor'])*pitch
        assert d+1e-10>=f['minimum_center_distance_mm'] and f['minimum_outer_distance_bound_mm']>.225
        assert f['minimum_outer_distance_bound_mm']==f['minimum_center_distance_mm']-2*radius
assert seen==set(itertools.combinations(range(15),2))
for r in tables:
    assert len(r['distances_mm'])==36 and all(len(row)==36 for row in r['distances_mm'])
    assert r['allowed_phase_pairs']==[[i,j] for i in range(36) for j in range(36) if r['distances_mm'][i][j]>.225]
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_reconstructions':pairs,'tables_verified':15,'near_pairs_verified':30,'far_pairs_verified':75,'maximum_translation_rounding_difference_mm':maxerror,'all15_cogs_mandatory':True,'all9_noncogs_still_required':True,'source_inventory_accounted':66,'scope':'Finite original phases and triangular pitches only; not an unrestricted phase, placement or neighborhood exclusion. Final positive must be checked against fixed27, all105 actual cog pairs and all9 noncogs.','native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
