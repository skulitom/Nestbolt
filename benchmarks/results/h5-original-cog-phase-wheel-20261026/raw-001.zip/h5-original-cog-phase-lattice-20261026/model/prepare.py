"""Build and independently reconstruct the one declared finite phase CSP."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-cog-phase-lattice-20261026';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(BASE/'geometry-audit/checks.json')['passed'];tables=load(BASE/'tables.json');edges=load(BASE/'near-edges.json')
model=cp_model.CpModel();pitch=model.new_int_var(0,4,'pitch');phases=[model.new_int_var(0,35,f'phase_{i}') for i in range(15)]
for e in edges:
    rows=[[r['pitch_index'],*ab] for r in tables if r['direction']==e['direction'] for ab in r['allowed_phase_pairs']]
    model.add_allowed_assignments([pitch,phases[e['a']],phases[e['b']]],rows)
assert not model.validate();assert model.export_to_file(str(OUT/'model.pb'));assert model.export_to_file(str(OUT/'model.pbtxt'))
saved=cp_model_pb2.CpModelProto();saved.ParseFromString((OUT/'model.pb').read_bytes());text=text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto());assert saved==text
expected=cp_model_pb2.CpModelProto();expected.variables.add(name='pitch',domain=[0,4])
for i in range(15):expected.variables.add(name=f'phase_{i}',domain=[0,35])
for e in edges:
    table=expected.constraints.add().table
    for index in [0,e['a']+1,e['b']+1]:table.exprs.add(vars=[index],coeffs=[1])
    for r in tables:
        if r['direction']==e['direction']:
            for a,b in r['allowed_phase_pairs']:table.values.extend([r['pitch_index'],a,b])
assert saved==expected and not saved.HasField('objective') and not saved.solution_hint.vars
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(saved.variables),'constraints':len(saved.constraints),'all15_phase_variables_mandatory':True,'geometry_audit_sha256':digest(BASE/'geometry-audit/checks.json'),'model_sha256':digest(OUT/'model.pb'),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'tables.json',BASE/'near-edges.json',BASE/'geometry-audit/checks.json']},'exact_independent_proto_reconstruction':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
