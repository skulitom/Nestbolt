from pathlib import Path
import tarfile
ROOT=Path(__file__).resolve().parents[1];DEP=ROOT/'output/h5-sat-dependency-review-20261106'
with tarfile.open(DEP/'python_sat-1.9.dev21.tar.gz','r:gz') as t:
    name=next(n for n in t.getnames() if n.endswith('/pysolvers.cc'))
    data=t.extractfile(name).read();(DEP/'pysolvers.cc').write_bytes(data)
    s=data.decode()
    for key in ['static PyObject *py_cadical195_tracepr(', 'static PyObject *py_flushpr(']:
        positions=[];offset=0
        while True:
            p=s.find(key,offset)
            if p<0:break
            positions.append(p);offset=p+1
        print(key,positions)
        print(s[positions[-1]:positions[-1]+3200])
with tarfile.open(DEP/'cadical195.tar.gz','r:gz') as t:
    for name in t.getnames():
        if name.endswith(('/options.hpp','/solver.cpp','/proof.cpp')):
            data=t.extractfile(name).read();(DEP/Path(name).name).write_bytes(data)
