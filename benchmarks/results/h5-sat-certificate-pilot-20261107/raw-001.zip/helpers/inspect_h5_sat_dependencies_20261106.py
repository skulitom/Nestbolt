from pathlib import Path
import urllib.request,json,zipfile,hashlib,tarfile,io
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-sat-dependency-review-20261106';OUT.mkdir(exist_ok=False)
def save(name,data):
    (OUT/name).write_bytes(data)
    return {'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def fetch(url):return urllib.request.urlopen(url,timeout=30).read()
rows=[]
for project,version in [('python-sat','1.9.dev21'),('six','1.17.0')]:
    meta=json.loads(fetch(f'https://pypi.org/pypi/{project}/{version}/json'))
    rows.append(save(project+'-metadata.json',json.dumps(meta,indent=2).encode()+b'\n'))
    for wheel in (ROOT/'.cache/h5-sat-packages-20261106').glob(('python_sat' if project=='python-sat' else 'six')+'-*.whl'):
        row=next(r for r in meta['urls'] if r['filename']==wheel.name)
        assert hashlib.sha256(wheel.read_bytes()).hexdigest()==row['digests']['sha256']
        rows.append({'path':str(wheel.relative_to(ROOT)).replace('\\','/'),'sha256':row['digests']['sha256'],'url':row['url']})
        with zipfile.ZipFile(wheel) as z:
            for name in z.namelist():
                if any(x in name.lower() for x in ['license','copying','notice']):
                    rows.append(save(project+'-'+Path(name).name,z.read(name)))
                    print(name,z.read(name).decode(errors='replace')[:5000])
    if project=='python-sat':
        src=next(r for r in meta['urls'] if r['packagetype']=='sdist');data=fetch(src['url'])
        assert hashlib.sha256(data).hexdigest()==src['digests']['sha256']
        rows.append(save(src['filename'],data))
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
            names=[n for n in t.getnames() if 'cadical' in n.lower() or n.endswith('solvers.py')]
            print('CADICAL files:',names)
            for n in names:
                if n.endswith(('solvers.py','.tar.gz','.zip','LICENSE')):
                    data=t.extractfile(n).read();rows.append(save(Path(n).name,data))
commit='2e3b2dc0ecf938addbd779d42877b6ed69d9a985'
for name in ['drat-trim.c','LICENSE','README.md','Makefile']:
    url=f'https://raw.githubusercontent.com/marijnheule/drat-trim/{commit}/{name}'
    rows.append({**save('drat-'+name,fetch(url)),'url':url,'commit':commit})
    if name=='LICENSE':print((OUT/('drat-'+name)).read_text())
with (OUT/'files.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(rows,f,indent=2);f.write('\n')
print('saved',len(rows),'dependency source records')
