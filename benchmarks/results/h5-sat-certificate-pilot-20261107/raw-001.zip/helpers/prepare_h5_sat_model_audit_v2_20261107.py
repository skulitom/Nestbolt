from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/audit_h5_sat_pilot_model_20261107.py'
text=old.read_text(encoding='utf-8').replace("assert not (raw[a*rb+a//8]>>(a%8)&1)","assert raw[a*rb+a//8]>>(a%8)&1")
text=text.replace("'single-cell-capacity.json'","'single-cell-capacity-v2.json'").replace("'audit.json'","'audit-v2.json'")
with (ROOT/'output/audit_h5_sat_pilot_model_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
result={'original_script':old.relative_to(ROOT).as_posix(),'original_script_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'exit_code':1,'original_tool_wall_seconds':2.3312431,'failure':'Expected graph diagonal0, but the previously audited conflict graphs have diagonal1 to express collision of two copies in one cell. Original auditor stopped at the first diagonal, before output or any SAT call.','correction':'Versioned auditor requires diagonal1, matching the source graph producer and its independent all-pair audit. It separately proves capacity1 for every cell using strict source inner rectangle overlap. Self bits are not unary exclusion clauses: a cell may contain1 part, but cannot contain2.','model_bytes_changed':False,'solver_calls':0,'authoritative_audit':'audit-v2.json'}
with (ROOT/'output/h5-sat-model-diagonal-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
