from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-sat-pilot-model-20261107'
load=lambda p:json.loads(p.read_bytes());start=time.perf_counter()
plan=load(OUT/'plan.json');checks=load(OUT/'checks.json');assert checks['passed']
for p,h in plan['source_bindings'].items():assert sha256((ROOT/p).read_bytes()).hexdigest()==h
G=ROOT/plan['graph'];nodes=load(G/'nodes.json');gc=load(G/'checks.json');raw=(G/'conflicts.bin').read_bytes();n=len(nodes);rb=gc['row_bytes']
assert sha256(raw).hexdigest()==gc['conflict_bytes_sha256'] and sha256((OUT/'model.cnf').read_bytes()).hexdigest()==checks['model_sha256']
geometries=load(ROOT/'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json')
single_cell=[]
for i,node in enumerate(nodes):
    a=node['bounds_um'];rects=geometries[node['geometry']]['inner_rectangles_um']
    matches=[j for j,r in enumerate(rects) if a[2]-a[0]<r[2]-r[0] and a[3]-a[1]<r[3]-r[1]]
    assert matches,(i,node);single_cell.append({'compact_node':i,'inner_component':matches[0]})
families=load(OUT/'families.json');gates=load(OUT/'cardinality-gates.json');counter=0;edgecount=0;gatecount=0;truthrows=0;top=n;gatepos=0
with (OUT/'model.cnf').open(encoding='ascii') as f:
    assert f.readline().split()==['p','cnf',str(checks['variables']),str(checks['clauses'])]
    def clause():
        global counter
        row=list(map(int,f.readline().split()));assert row and row[-1]==0 and all(0<abs(x)<=checks['variables'] for x in row[:-1]);counter+=1
        return row[:-1]
    # Read every expected graph bit in lexicographic order, including absent pairs.
    for a in range(n):
        assert raw[a*rb+a//8]>>(a%8)&1
        for b in range(a+1,n):
            bit=raw[a*rb+b//8]>>(b%8)&1
            assert bit==(raw[b*rb+a//8]>>(a%8)&1)
            if bit:assert clause()==[-(a+1),-(b+1)];edgecount+=1
    for family in [0,1]:
        selectors=[i+1 for i,node in enumerate(nodes) if node['family']==family]
        assert families[family]['selectors']==selectors
        prev={0:True}
        for i,x in enumerate(selectors,1):
            current={0:True}
            for j in range(1,min(i,8)+1):
                top+=1;y=top;a=prev.get(j,False);b=prev[j-1]
                g=gates[gatepos];gatepos+=1
                assert g=={'i':i,'j':j,'x':x,'a':a,'b':b,'y':y,'family':family}
                assert a is False or type(a) is int;assert b is True or type(b) is int
                block=[clause() for _ in range(4-int(a is False)-int(b is True))]
                variables=sorted({v for v in [a,b,x,y] if type(v) is int})
                assert all(set(map(abs,c))<=set(variables) for c in block)
                for values in product([False,True],repeat=len(variables)):
                    assignment=dict(zip(variables,values))
                    val=lambda v:v if type(v) is bool else assignment[v]
                    cnf=all(any(assignment[abs(l)]==(l>0) for l in c) for c in block)
                    assert cnf==(val(y)==(val(a) or(val(x) and val(b))));truthrows+=1
                current[j]=y;gatecount+=1
            prev=current
        assert clause()==[prev[8]] and families[family]['final']==prev[8]
    assert f.read()==''
assert gatepos==len(gates) and top==checks['variables'] and counter==checks['clauses'] and edgecount==checks['conflict_clauses']
elapsed=time.perf_counter()-start;assert elapsed<=plan['maximum_model_audit_seconds']
result={'passed':True,'every_graph_pair_checked':n*(n-1)//2,'conflict_clauses_verified':edgecount,'all_clauses_verified':counter,'acyclic_threshold_gates':gatecount,'local_truth_table_rows':truthrows,'single_cell_capacity_proofs':len(single_cell),'model_sha256':checks['model_sha256'],'seconds':elapsed,'solver_calls':0,'continuous_necessity':'Complete retained cells cover every valid source anchor. Every cell has capacity at most1, proved by strict source-inner-rectangle overlap even at zero clearance. All certified pair incompatibilities are CNF clauses. Each family threshold is exactly at least8. Thus every valid16-part continuous completion induces a satisfying assignment; only checked UNSAT may exclude this fixed arrangement.'}
for name,value in [('single-cell-capacity-v2.json',single_cell),('audit-v2.json',result)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(result)
