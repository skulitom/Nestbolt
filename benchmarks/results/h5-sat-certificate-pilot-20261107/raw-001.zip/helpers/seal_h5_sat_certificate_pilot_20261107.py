from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-sat-certificate-pilot-20261107';OUT=ROOT/'benchmarks/results'/NAME
MODEL=ROOT/'output/h5-first57-sat-pilot-model-20261107';CALL=ROOT/'output/h5-first57-sat-pilot-call-20261107';AUDIT=ROOT/'output/h5-first57-sat-pilot-result-audit-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
controls=load(ROOT/'output/h5-sat-controls-v2-20261107/checks.json');ma=load(MODEL/'audit-v2.json');response=load(AUDIT/'checks.json');process=load(CALL/'process.json')
assert controls['passed'] and ma['passed'] and response['passed']
assert response['solver_status']=='UNRESOLVED' and response['new_exclusions']==0 and response['remaining_fixed29_choices']==26
assert process['closed'] and process['limit_reason']=='search-time-limit' and process['solver_calls_started']==1
assert load(CALL/'descendant-closure-v2.json')['all_matching_workers_closed']
parent_setup=(ROOT/'output/seal_h5_frontier_refined_proofs_20261106.py').read_text(encoding='utf-8')
exec(parent_setup[parent_setup.index('prior=ROOT'):parent_setup.index('walker=ROOT')])
PARENTS.append(ROOT/'benchmarks/results/h5-frontier-refined-proofs-20261106')
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
folders=[MODEL,CALL,AUDIT,ROOT/'output/h5-sat-tools-20261107',ROOT/'output/h5-sat-controls-20261107',ROOT/'output/h5-sat-controls-v2-20261107']
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
dep=ROOT/'output/h5-sat-dependency-review-20261106'
# Do not archive the multi-solver source distribution, wheel or unused solver sources.
# Preserve only selected MIT source/notice files plus published package hashes/URLs.
excluded={'python_sat-1.9.dev21.tar.gz','cadical103.tar.gz','cadical153.tar.gz','cadical300.tar.gz'}
for p in dep.iterdir():
    if p.is_file() and p.name not in excluded:add(dep.name+'/'+p.name,p)
for pattern in ['*h5_sat*20261107.py','*h5_sat*20261106.py','*h5_cadical*20261106.py','h5_drat_text_20261107.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['h5-sat-proof-io-correction-20261107.json','h5-sat-model-diagonal-correction-20261107.json','pack_h5_evidence_archive.py','ccd1.py',walker.name,'seal_h5_frontier_refined_proofs_20261106.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(MODEL/'plan.json')['source_bindings'].items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
graph=ROOT/load(MODEL/'plan.json')['graph']
for p in [graph.parent/'plan.json',graph.parent/'audit/checks.json',ROOT/'output/h5-first57-frontier-refined-covers-20261106/plan.json',ROOT/'output/h5-first57-frontier-refined-covers-20261106/audit-v2/checks.json']:
    add('source-inputs/'+p.relative_to(ROOT).as_posix(),p);bindings[p.relative_to(ROOT).as_posix()]=digest(p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(MODEL/'checks.json','model.json'),(MODEL/'audit-v2.json','model-audit.json'),(AUDIT/'checks.json','response-audit.json'),
    (AUDIT/'remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(CALL/'process.json','call-process.json'),(CALL/'descendant-closure-v2.json','worker-closure.json'),
    (ROOT/'output/h5-sat-controls-v2-20261107/checks.json','tool-controls.json'),(ROOT/'output/h5-sat-proof-io-correction-20261107.json','proof-io-correction.json'),
    (ROOT/'output/h5-sat-model-diagonal-correction-20261107.json','model-audit-correction.json')]:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'model_clauses_verified':953103,'threshold_gates_verified':16840,'single_cell_capacity_proofs':2112,'research_SAT_calls':1,'closed_SAT_status':'UNRESOLVED',
    'proof_independently_accepted':False,'new_exclusions':0,'remaining_fixed29_choices':26,'total_fixed29_excluded_at_required_clearance':429,
    'previous_zero_clearance_exclusions':427,'whole_allocations':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'next-step.json',{'closed_pilot_must_not_be_repeated_or_extended':True,'pilot_formula_sha256':ma['model_sha256'],
    'next_required_work':'Repair process supervision before another research call. Use a Windows job that contains the launcher and every descendant, with aggregate memory accounting and kill-on-close; validate it on a harmless spawned-child timeout control. Preserve the direct-process supervisor and failed inventory helper. Then assess a separately selected, independently audited remaining arrangement or genuinely new source constraints; do not repeat the closed[0,5,12] pilot.',
    'proof_toolchain':'Pinned MIT PySAT1.9.dev21/CaDiCaL195 and MIT drat-trim2e3b2dc. Lossless binary-to-text DRAT with exact round-trip is required on Windows; complete independent acceptance required for any exclusion.',
    'no_new_native_call_without_source_valid66':True,'remaining_fixed29_choices':26,'whole_allocation_candidates':440,'H2_gate_unchanged':True,'completion_percent':60})
report=f'''# SAT certificate pilot — 2026-11-07

The new certificate workflow is audited, but its only research call reaches
the frozen time limit without a usable result. **No arrangement is excluded.**
All 26 fixed29/current-cog choices and 440 whole-job allocations remain open;
H2/H5 remain open at **60% completed milestone weight**.

## Verified tools and encoding

The local diagnostic toolchain pins PySAT1.9.dev21's Windows CPython3.13 wheel,
the bundled CaDiCaL1.9.5 source, and drat-trim commit
`2e3b2dc0ecf938addbd779d42877b6ed69d9a985`. The selected solver, wrapper and
checker are MIT licensed. Package URLs/hashes and selected source/notices are
preserved. The multi-solver source distribution, wheel and unused solver
archives are not committed. Production dependencies are unchanged.

The first checker build fails because MinGW lacks `getc_unlocked`; the versioned
build uses standard `getc` through a compiler macro, preserving original source.
The first larger proof control then fails: Windows text-mode input treats binary
byte0x1a as EOF. [The preserved correction]({NAME}/proof-io-correction.json)
uses a lossless binary-to-ASCII decoder and independently written inverse,
requiring an exact byte round-trip. A metadata helper's off-by-one assertion is
also retained and corrected separately.

[Versioned controls]({NAME}/tool-controls.json) pass three valid UNSAT proofs,
including a pigeonhole example, and reject absent, tampered and false proofs.
Two satisfiable controls have checked assignments. Threshold controls verify
16 local truth rows, 15,874 complete selector assignments and 483,846 prefix
counts. The four-clause gate is exactly `y <=> a or (x and b)`; its acyclic
prefix recurrence uniquely represents the number of selected cells.

## Complete pilot model

The smallest retained refined graph is arrangement `[0,5,12]`: 896 bracket
cells and1,216 insert cells. The [model audit]({NAME}/model-audit.json) checks
all2,229,216 graph pairs,887,869 conflict clauses and953,103 total clauses,
including16,840 threshold gates over18,952 variables. Both families require at
least8 selected cells. A separate source-inner-rectangle proof establishes
capacity1 for every one of the2,112 cells. Every valid continuous completion
therefore induces a satisfying assignment; checked UNSAT could exclude only
this fixed core/current-cog arrangement at original0.2mm clearance.

The first audit incorrectly expects zero graph diagonals and stops before any
SAT call. [Audit-v2]({NAME}/model-audit-correction.json) requires the documented
self-conflict bits and separately proves single-cell capacity. Model bytes do
not change. Complete model preparation takes3.085335s; authoritative audit
takes17.633587s. Prior preparation and failed-control costs remain preserved;
there is no full-job60/90-second construction claim.

## Closed bounded call

The plan freezes one60-second search, a1,000,000-conflict budget, a90-second
complete-process cap,2GiB memory and256MiB binary-proof limits before execution.
The [process record]({NAME}/call-process.json) closes at the search-time limit
after66.683245s total, without a status or assignment. Its incomplete binary
proof is archived as evidence and is not submitted as a complete certificate.

The supervisor samples only its direct process and reports about4MiB RSS,
which does not establish aggregate interpreter/descendant memory usage. No
successful memory-cap claim is made. A psutil inventory helper does not finish
and is stopped; [independent Windows CIM inspection]({NAME}/worker-closure.json)
confirms no matching SAT worker remains. This call stays closed and unresolved.
Its formula, partial proof and all failed/versioned controls are preserved.

[The response audit]({NAME}/response-audit.json) records zero new exclusions,
zero source-valid placements and no native calls. There are still429 of455
fixed arrangements excluded at required clearance,427 even at zero clearance.
[Next]({NAME}/next-step.json), validate process-tree resource enforcement before
considering a distinct remaining arrangement. The closed pilot is never rerun.

[The manifest]({NAME}/raw-manifest.json) contains{archive['archive_members']} new
canonical members and{archive['archive_bytes']:,} compressed bytes.
[Source bindings]({NAME}/source-bindings.json) and
[historical references]({NAME}/external-evidence.json) preserve the exact inputs.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 SAT certificate pilot:** [the pinned tool controls and complete model audit]({link}) verify953,103 CNF clauses,16,840 threshold gates and2,112 source-proved single-cell capacities for[0,5,12]. MIT solver/checker notices, package hashes, failed Windows binary-proof control and versioned lossless text conversion are preserved. The first diagonal audit error is separately corrected without changing model bytes. The sole60-second search closes without a usable result after66.683245s total; its incomplete proof yields no exclusion. The direct-process supervisor does not establish aggregate descendant memory; Windows CIM confirms no matching worker remains after a stalled diagnostic helper is stopped. Next validate process-tree resource limits before any distinct new research call. This pilot and all earlier calls remain closed. The26 arrangements,440 whole allocations and H2/H5 remain open at60%; no source-valid66, native call or full construction-budget claim is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
s=s.replace('# Status — 2026-11-06','# Status — 2026-11-07',1)
a='Latest H5 evidence: [complete refined frontier](../benchmarks/results/h5-frontier-refined-proofs-20261106.md).';assert s.count(a)==1
s=s.replace(a,f'Latest H5 evidence: [SAT certificate pilot](../benchmarks/results/{NAME}.md).',1)
a='The corrected index audit and pre-graph failure are preserved. An independently\nchecked Boolean certificate method is next; no SAT model or call has run.'
b='The corrected index audit and pre-graph failure are preserved. The new Boolean\ncertificate workflow passes tool controls and a full953,103-clause model audit.\nIts sole[0,5,12] pilot times out without a usable proof or assignment. All26\narrangements remain unresolved. Process-tree resource enforcement must pass\na spawned-child control before another distinct call; this pilot stays closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
