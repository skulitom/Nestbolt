from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import psutil,json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-sat-pilot-call-20261107'
target=(ROOT/'output/solve_h5_sat_pilot_20261107.py').resolve();matches=[]
for p in psutil.process_iter(['pid','ppid','cmdline','memory_info','create_time']):
    try:
        args=p.info['cmdline'] or []
        if any(Path(arg).resolve()==target for arg in args[1:] if arg.endswith('.py')):
            matches.append({'pid':p.pid,'ppid':p.info['ppid'],'cmdline':args,'rss_bytes':p.info['memory_info'].rss,'created_epoch':p.info['create_time']})
    except (psutil.NoSuchProcess,psutil.AccessDenied,OSError):pass
record={'utc':datetime.now(timezone.utc).isoformat(),'original_process_record_sha256':sha256((OUT/'process.json').read_bytes()).hexdigest(),'matched_workers':matches,'reason':'Audit of the unusually small4MB supervised RSS: Windows venv launcher may have a separate interpreter child. The frozen search limit has expired; close any surviving exact-match worker and preserve this supervisor failure. Never restart or reuse this call as a completed in-budget proof.','valid_complete_call':False,'retry_permitted':False}
for row in matches:
    try:
        p=psutil.Process(row['pid']);children=p.children(recursive=True)
        for child in children:child.kill()
        p.kill();gone,alive=psutil.wait_procs(children+[p],timeout=5);assert not alive
    except psutil.NoSuchProcess:pass
record['all_matching_workers_closed']=True
with (OUT/'descendant-closure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
