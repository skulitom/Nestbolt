from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import time,json,subprocess,psutil
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-first57-sat-pilot-model-20261107';OUT=ROOT/'output/h5-first57-sat-pilot-call-20261107'
SCRIPT=ROOT/'output/solve_h5_sat_pilot_20261107.py';plan=json.loads((MODEL/'plan.json').read_bytes())
assert json.loads((MODEL/'audit-v2.json').read_bytes())['passed'];OUT.mkdir()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
write('opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'plan_sha256':sha256((MODEL/'plan.json').read_bytes()).hexdigest(),'worker_sha256':sha256(SCRIPT.read_bytes()).hexdigest(),'supervisor_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'retry_permitted':False,'maximum_complete_process_seconds':plan['solver_complete_process_seconds'],'maximum_search_seconds':plan['solver_search_seconds'],'maximum_rss_bytes':plan['solver_memory_bytes'],'maximum_proof_bytes':plan['binary_proof_byte_limit']})
started=time.perf_counter();reason=None;peak=0
with (OUT/'stdout.txt').open('xb') as stdout,(OUT/'stderr.txt').open('xb') as stderr:
    p=subprocess.Popen([str(ROOT/'.cache/h5-sat-venv-20261106/Scripts/python.exe'),str(SCRIPT)],cwd=ROOT,stdout=stdout,stderr=stderr)
    process=psutil.Process(p.pid)
    while p.poll() is None:
        elapsed=time.perf_counter()-started
        try:peak=max(peak,process.memory_info().rss)
        except psutil.NoSuchProcess:pass
        proof=OUT/'proof.drat.bin';phase=OUT/'search-started.json'
        if elapsed>plan['solver_complete_process_seconds']:reason='complete-process-limit'
        elif peak>plan['solver_memory_bytes']:reason='memory-limit'
        elif proof.exists() and proof.stat().st_size>plan['binary_proof_byte_limit']:reason='proof-byte-limit'
        elif phase.exists():
            try:phase_data=json.loads(phase.read_bytes())
            except json.JSONDecodeError:phase_data=None
            if phase_data and time.perf_counter()-phase_data['perf_counter']>plan['solver_search_seconds']:reason='search-time-limit'
        if reason:p.kill();p.wait();break
        time.sleep(.05)
elapsed=time.perf_counter()-started
result={'closed':True,'exit_code':p.returncode,'limit_reason':reason,'complete_process_seconds':elapsed,'complete_process_cap_overrun_seconds':max(0,elapsed-plan['solver_complete_process_seconds']),'peak_rss_bytes':peak,'solver_calls_started':1 if (OUT/'search-started.json').exists() else 0,'retry_permitted':False,'proof_status':'unverified','new_exclusions':0}
write('process.json',result);print(result)
