from pathlib import Path
from hashlib import sha256
import time,json
from pysat.solvers import Cadical195
import pysolvers
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-first57-sat-pilot-model-20261107';OUT=ROOT/'output/h5-first57-sat-pilot-call-20261107'
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=json.loads((MODEL/'plan.json').read_bytes());audit=json.loads((MODEL/'audit-v2.json').read_bytes());assert audit['passed']
assert sha256((MODEL/'model.cnf').read_bytes()).hexdigest()==audit['model_sha256']
started=time.perf_counter()
with Cadical195() as s:
    s.prfile=(OUT/'proof.drat.bin').open('x+b');s.prfp=pysolvers.cadical195_tracepr(s.cadical,s.prfile)
    with (MODEL/'model.cnf').open(encoding='ascii') as f:
        header=f.readline().split();nvars=int(header[2]);nclauses=int(header[3]);count=0
        for line in f:
            clause=list(map(int,line.split()));assert clause[-1]==0;s.add_clause(clause[:-1]);count+=1
        assert count==nclauses
    s.conf_budget(plan['solver_conflict_budget'])
    before=time.perf_counter();write('search-started.json',{'perf_counter':before,'load_seconds':before-started,'calls':1})
    status=s.solve_limited();seconds=time.perf_counter()-before
    pysolvers.flushpr(s.prfp);s.prfile.flush()
    model=s.get_model() if status is True else None
    result={'status':'SAT' if status is True else 'UNSAT' if status is False else 'UNKNOWN','search_seconds':seconds,'load_and_search_seconds':time.perf_counter()-started,'stats':s.accum_stats(),'proof_bytes':(OUT/'proof.drat.bin').stat().st_size,'model_sha256':audit['model_sha256'],'solver_calls':1,'proof_independently_checked':False,'source_valid_placement':False}
    if model is not None:write('assignment.json',model)
write('result.json',result);print(result)
