from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
from h5_sat_encoding_20261107 import threshold
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-sat-pilot-model-20261107'
GRAPH=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106/choice-03'
load=lambda p:json.loads(p.read_bytes())
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=time.perf_counter();assert not OUT.exists();OUT.mkdir()
checks=load(GRAPH/'checks.json');nodes=load(GRAPH/'nodes.json');raw=(GRAPH/'conflicts.bin').read_bytes()
assert checks['source_selection']['empty_sites']==[0,5,12] and len(nodes)==2112 and checks['bracket_nodes']==896
assert sha256(raw).hexdigest()==checks['conflict_bytes_sha256']
paths=[GRAPH/'checks.json',GRAPH/'nodes.json',GRAPH/'conflicts.bin',GRAPH.parent/'audit/checks.json',
    ROOT/'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json',
    ROOT/'output/h5-sat-controls-v2-20261107/checks.json',ROOT/'output/h5_sat_encoding_20261107.py',Path(__file__),
    ROOT/'output/h5-sat-proof-io-correction-20261107.json']
assert load(ROOT/'output/h5-sat-controls-v2-20261107/checks.json')['passed']
write('plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_selection':checks['source_selection'],'graph':GRAPH.relative_to(ROOT).as_posix(),
    'source_bindings':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in paths},
    'method':'New explicit CNF certificate workflow over the existing independently audited complete continuous-cell graph. No closed tree or placement call is resumed, repeated or extended.',
    'selection_reason':'Smallest retained refined graph among the26 remaining fixed29/current-cog arrangements:2112 nodes.',
    'cardinality':'At least8 bracket and8 insert cell selectors; every cell admits at most1 physical part, separately verified from source inner rectangles.',
    'maximum_model_preparation_seconds':120,'maximum_model_audit_seconds':120,'solver_call_count':1,'solver_search_seconds':60,'solver_conflict_budget':1000000,
    'solver_complete_process_seconds':90,'solver_memory_bytes':2147483648,'binary_proof_byte_limit':268435456,
    'checker_seconds':60,'checker_complete_process_seconds':70,'retry_permitted':False,'required_job_clearance_mm':0.2,
    'scope':'Only fixed29 and these12 current reference cog poses. SAT is only a necessary graph witness. UNSAT requires the exact DIMACS formula and a separately checked complete proof. UNKNOWN/failure/limits remain unresolved.',
    'full_construction_60_or_90_second_claim':False,'consumed_preparation_note':'All preceding source, cover, graph and tree preparation remains charged. This is a bounded diagnostic proof workflow, not a full-job construction timing claim.'})
n=len(nodes);rb=checks['row_bytes'];rows=[int.from_bytes(raw[i*rb:(i+1)*rb],'little') for i in range(n)]
edges=sum((row>>(i+1)).bit_count() for i,row in enumerate(rows))
card=[];gates=[];top=n;families=[]
for family in [0,1]:
    selectors=[i+1 for i,node in enumerate(nodes) if node['family']==family]
    clauses,gs,top,final=threshold(selectors,8,top);card.extend(clauses);gates.extend(dict(g,family=family) for g in gs)
    families.append({'family':family,'selectors':selectors,'final':final,'gate_count':len(gs),'clauses':len(clauses)})
write('cardinality-gates.json',gates);write('families.json',families)
with (OUT/'model.cnf').open('x',encoding='utf-8',newline='\n') as f:
    f.write(f'p cnf {top} {edges+len(card)}\n')
    for i,row in enumerate(rows):
        bits=row&~((1<<(i+1))-1)
        while bits:
            bit=bits&-bits;j=bit.bit_length()-1;bits-=bit
            f.write(f'-{i+1} -{j+1} 0\n')
    for c in card:f.write(' '.join(map(str,c))+' 0\n')
elapsed=time.perf_counter()-started
write('checks.json',{'passed':elapsed<=120,'nodes':n,'variables':top,'conflict_clauses':edges,'cardinality_clauses':len(card),'clauses':edges+len(card),'model_bytes':(OUT/'model.cnf').stat().st_size,'model_sha256':sha256((OUT/'model.cnf').read_bytes()).hexdigest(),'complete_preparation_seconds':elapsed,'overrun_seconds':max(0,elapsed-120),'solver_calls':0})
assert elapsed<=120;print(load(OUT/'checks.json'))
