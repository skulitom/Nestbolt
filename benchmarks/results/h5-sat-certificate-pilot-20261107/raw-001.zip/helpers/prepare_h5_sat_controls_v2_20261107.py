from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/check_h5_sat_tools_20261107.py'
text=SRC.read_text(encoding='utf-8').replace('h5-sat-controls-20261107','h5-sat-controls-v2-20261107')
text=text.replace('from h5_sat_encoding_20261107 import threshold','from h5_sat_encoding_20261107 import threshold\nfrom h5_drat_text_20261107 import to_text')
text=text.replace("    if model is not None:assert holds", "    (OUT/(name+'.drat.txt')).write_bytes(to_text((OUT/(name+'.drat')).read_bytes()))\n    if model is not None:assert holds")
for name in ['xor-unsat','threshold-unsat','pigeonhole-unsat']:
    text=text.replace("'"+name+".drat',True", "'"+name+".drat.txt',True")
text=text.replace("'encoding_sha256':", "'converter_sha256':sha256((ROOT/'output/h5_drat_text_20261107.py').read_bytes()).hexdigest(),'encoding_sha256':")
out=ROOT/'output/check_h5_sat_tools_v2_20261107.py'
with out.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
original=ROOT/'output/h5-sat-controls-20261107/pigeonhole-unsat.drat';data=original.read_bytes()
assert data[99]==26 and len(data)==247
with (ROOT/'output/h5-sat-proof-io-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'preserved_failed_control':'output/h5-sat-controls-20261107/valid-pigeonhole.json','original_proof_sha256':hashlib.sha256(data).hexdigest(),'original_proof_bytes':len(data),'checker_reported_bytes_read':99,'byte_at_reported_cutoff':26,'diagnosis':'drat-trim opens proof with fopen r; Windows text-mode input treats byte0x1a as EOF. The original complete binary proof is preserved.','correction':'Decode binary DRAT to ASCII and require exact binary round-trip before independent checking. Both representations are preserved. No solver algorithm or checker proof logic changes.','research_calls':0},f,indent=2);f.write('\n')
print(out)
