"""Lossless binary DRAT decoding for a Windows text-mode proof checker."""
def to_text(data):
    p=0;lines=[]
    while p<len(data):
        operation=data[p];p+=1
        assert operation in (97,100)
        literals=[]
        while True:
            value=0;shift=0
            while True:
                assert p<len(data) and shift<=28
                b=data[p];p+=1;value|=(b&127)<<shift;shift+=7
                if b<128:break
            if value==0:break
            assert value>=2
            lit=value>>1;literals.append(-lit if value&1 else lit)
        lines.append(('d ' if operation==100 else '')+' '.join(map(str,literals))+(' ' if literals else '')+'0\n')
    text=''.join(lines).encode('ascii')
    # A separately written inverse checks exact byte preservation, including deletions.
    rebuilt=bytearray()
    for line in text.decode('ascii').splitlines():
        fields=line.split();deletion=fields[0]=='d'
        if deletion:fields=fields[1:]
        assert fields[-1]=='0';rebuilt.append(100 if deletion else 97)
        for field in fields[:-1]:
            number=int(field);number=2*abs(number)+(number<0)
            while number>127:rebuilt.append(128+(number%128));number//=128
            rebuilt.append(number)
        rebuilt.append(0)
    assert bytes(rebuilt)==data
    return text
