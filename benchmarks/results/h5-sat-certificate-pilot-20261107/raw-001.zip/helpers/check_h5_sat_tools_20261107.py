from pathlib import Path
from itertools import product,combinations
from hashlib import sha256
import json,time,subprocess
from pysat.solvers import Cadical195
import pysolvers
from h5_sat_encoding_20261107 import threshold
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-sat-controls-20261107';OUT.mkdir()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cnf(name,clauses,n):
    with (OUT/(name+'.cnf')).open('x',encoding='utf-8',newline='\n') as f:
        f.write(f'p cnf {n} {len(clauses)}\n')
        for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
def holds(clauses,assignment):return all(any(assignment[abs(x)]==(x>0) for x in c) for c in clauses)
def solve(name,clauses,n):
    cnf(name,clauses,n);t=time.perf_counter()
    with Cadical195() as s:
        s.prfile=(OUT/(name+'.drat')).open('x+b');s.prfp=pysolvers.cadical195_tracepr(s.cadical,s.prfile)
        for c in clauses:s.add_clause(c)
        s.conf_budget(100000);status=s.solve_limited()
        pysolvers.flushpr(s.prfp);s.prfile.flush()
        model=s.get_model() if status is True else None
    if model is not None:assert holds(clauses,{abs(x):x>0 for x in model})
    return {'name':name,'status':status,'seconds':time.perf_counter()-t,'proof_bytes':(OUT/(name+'.drat')).stat().st_size,'model':model}
checker=ROOT/'output/h5-sat-tools-20261107/drat-trim.exe'
def check(name,formula,proof,expected):
    t=time.perf_counter();r=subprocess.run([str(checker),str(OUT/formula),str(OUT/proof),'-t','10'],capture_output=True,timeout=15)
    (OUT/(name+'-stdout.txt')).write_bytes(r.stdout);(OUT/(name+'-stderr.txt')).write_bytes(r.stderr)
    verified=b's VERIFIED' in r.stdout.splitlines()
    # Output is CR-prefixed on some platforms: normalize only line terminators.
    verified=any(line.strip()==b's VERIFIED' for line in r.stdout.splitlines())
    row={'name':name,'formula':formula,'proof':proof,'exit_code':r.returncode,'verified':verified,'expected':expected,'seconds':time.perf_counter()-t}
    write(name+'.json',row);assert verified is expected,row
    return row
started=time.perf_counter();local_truth=0
for a,b,x,y in product([False,True],repeat=4):
    actual=((not a) or y) and ((not x) or (not b) or y) and ((not y) or a or x) and ((not y) or a or b)
    assert actual==(y==(a or (x and b)));local_truth+=1
assignments=0;gates_checked=0
for n in range(1,11):
    for k in range(1,min(8,n)+1):
        clauses,gates,top,final=threshold(list(range(1,n+1)),k,n)
        for values in product([False,True],repeat=n):
            assignment=dict(enumerate(values,1))
            for g in gates:
                # Independent prefix-count semantics, rather than producer recurrence.
                assignment[g['y']]=sum(values[:g['i']])>=g['j'];gates_checked+=1
            assert holds(clauses,assignment)==(sum(values)>=k);assignments+=1
rows=[];checks=[]
rows.append(solve('xor-unsat',[[1,2],[1,-2],[-1,2],[-1,-2]],2));assert rows[-1]['status'] is False
checks.append(check('valid-xor','xor-unsat.cnf','xor-unsat.drat',True))
(OUT/'empty.drat').write_bytes(b'')
checks.append(check('missing-proof','xor-unsat.cnf','empty.drat',False))
(OUT/'tampered.drat').write_bytes(b'3 0\n0\n')
checks.append(check('tampered-proof','xor-unsat.cnf','tampered.drat',False))
rows.append(solve('satisfiable',[[1,2],[-1,2]],2));assert rows[-1]['status'] is True
(OUT/'false-empty-clause.drat').write_bytes(b'0\n')
checks.append(check('false-unsat','satisfiable.cnf','false-empty-clause.drat',False))
clauses,gates,top,_=threshold([1,2,3,4,5],3,5)
rows.append(solve('threshold-sat',clauses,top));assert rows[-1]['status'] is True
rows.append(solve('threshold-unsat',clauses+[[-a,-b] for a,b in combinations(range(1,6),2)],top));assert rows[-1]['status'] is False
checks.append(check('valid-threshold','threshold-unsat.cnf','threshold-unsat.drat',True))
php=[[p*4+h+1 for h in range(4)] for p in range(5)]
php += [[-(p*4+h+1),-(q*4+h+1)] for h in range(4) for p,q in combinations(range(5),2)]
rows.append(solve('pigeonhole-unsat',php,20));assert rows[-1]['status'] is False
checks.append(check('valid-pigeonhole','pigeonhole-unsat.cnf','pigeonhole-unsat.drat',True))
write('checks.json',{'passed':True,'local_gate_truth_rows':local_truth,'prefix_count_assignments':assignments,'prefix_gate_checks':gates_checked,'solver_controls':rows,'checker_controls':checks,'checker_sha256':sha256(checker.read_bytes()).hexdigest(),'encoding_sha256':sha256((ROOT/'output/h5_sat_encoding_20261107.py').read_bytes()).hexdigest(),'seconds':time.perf_counter()-started,'research_calls':0,'proof_logging':'persistent binary native CaDiCaL proof stream, flushed with the same binding used by PySAT.get_proof','semantic_argument':'Each local four-clause gate is equivalent to y iff a or (x and b). Its acyclic prefix indexing forces the unique threshold-count assignment. Final positive threshold unit is satisfiable exactly when at least k selectors are true.'})
print('SAT/checker and threshold controls passed',assignments,gates_checked)
