from pathlib import Path
import json,subprocess,hashlib,time
ROOT=Path(__file__).resolve().parents[1];DEP=ROOT/'output/h5-sat-dependency-review-20261106'
OUT=ROOT/'output/h5-sat-tools-20261107';OUT.mkdir()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
write('initial-checker-build-failure.json',{'exit_code':1,'source':str(DEP.relative_to(ROOT)/'drat-drat-trim.c'),'source_sha256':digest(DEP/'drat-drat-trim.c'),'compiler':'C:/msys64/mingw64/bin/gcc.exe','flags':['-std=c99','-O2'],'diagnostic':'implicit declaration of getc_unlocked; undefined reference to getc_unlocked; ld returned 1 exit status','capture':'Recorded from the original terminal result; no local raw stdout/stderr capture was made.','retry_scope':'Build portability correction only, before any proof-checker or SAT research call. Source is unchanged; preprocessor maps getc_unlocked to standard getc.'})
for name in ['python-sat-LICENSE.txt','six-LICENSE','cadical195-LICENSE.txt','drat-LICENSE']:
    data=(DEP/name).read_text(encoding='utf-8');assert 'Permission is hereby granted' in data
    (OUT/name).write_bytes((DEP/name).read_bytes())
gcc=Path('C:/msys64/mingw64/bin/gcc.exe')
args=[str(gcc),str(DEP/'drat-drat-trim.c'),'-std=c99','-O2','-Dgetc_unlocked=getc','-o',str(OUT/'drat-trim.exe')]
t=time.perf_counter();r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=60)
(OUT/'build-stdout.txt').write_bytes(r.stdout);(OUT/'build-stderr.txt').write_bytes(r.stderr)
write('checker-build.json',{'command':args,'exit_code':r.returncode,'seconds':time.perf_counter()-t,'compiler_sha256':digest(gcc),'source_sha256':digest(DEP/'drat-drat-trim.c'),'binary_sha256':digest(OUT/'drat-trim.exe') if (OUT/'drat-trim.exe').exists() else None})
assert r.returncode==0
py=ROOT/'.cache/h5-sat-venv-20261106/Scripts/python.exe'
r=subprocess.run([str(py),'-m','pip','install','--no-index','--find-links',str(ROOT/'.cache/h5-sat-packages-20261106'),'python-sat==1.9.dev21','six==1.17.0'],cwd=ROOT,capture_output=True,timeout=90)
(OUT/'install-stdout.txt').write_bytes(r.stdout);(OUT/'install-stderr.txt').write_bytes(r.stderr);assert r.returncode==0,r.stderr
r=subprocess.run([str(py),'-m','pip','freeze'],capture_output=True,check=True);(OUT/'packages.txt').write_bytes(r.stdout)
write('checks.json',{'passed':True,'solver':'CaDiCaL195 from python-sat1.9.dev21 cp313 Windows wheel','checker':'drat-trim commit2e3b2dc0ecf938addbd779d42877b6ed69d9a985','solver_license':'MIT','checker_license':'MIT','source_modified':False,'checker_portability_macro':'getc_unlocked=getc','research_solver_calls':0,'proof_controls_pending':True})
print((OUT/'checks.json').read_text())
