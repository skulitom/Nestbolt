from pathlib import Path
import tarfile,hashlib,json
OUT=Path(__file__).resolve().parent/'h5-sat-dependency-review-20261106'
with tarfile.open(OUT/'cadical195.tar.gz','r:gz') as t:
    names=[n for n in t.getnames() if n.endswith('/LICENSE')]
    assert len(names)==1
    data=t.extractfile(names[0]).read()
    (OUT/'cadical195-LICENSE.txt').write_bytes(data)
    print(data.decode())
    with (OUT/'cadical195-license-binding.json').open('x',encoding='utf-8',newline='\n') as f:
        json.dump({'source_archive':'cadical195.tar.gz','source_archive_sha256':hashlib.sha256((OUT/'cadical195.tar.gz').read_bytes()).hexdigest(),'member':names[0],'license_sha256':hashlib.sha256(data).hexdigest()},f,indent=2);f.write('\n')
src=(OUT/'solvers.py').read_text(encoding='utf-8');start=src.index('class Cadical195(');end=src.index('\nclass ',start+1);part=src[start:end]
for meth in ['solve_limited','interrupt','get_proof']:
    pos=part.index('    def '+meth+'(');finish=part.find('\n    def ',pos+1);print(part[pos:finish])
