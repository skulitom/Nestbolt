"""Check the sole call against its frozen budget and explain the rejected result."""
from pathlib import Path
from hashlib import sha256
import json, shutil
ROOT = Path(__file__).resolve().parents[1]; BASE = ROOT / 'output/h5-continuous-cog-source-20261028'; OUT = BASE / 'contract-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(v,f,indent=2); f.write('\n')
OUT.mkdir(); shutil.copyfile(__file__,OUT/'audit.py')
p = load(BASE/'plan.json'); opened = load(BASE/'search/opened.json'); r = load(BASE/'search/result.json'); process = load(BASE/'search/process.json'); raw = load(BASE/'search/raw-response.json'); source = load(BASE/'source-audit/checks.json'); callbacks = load(BASE/'search/callbacks.json'); invalid = load(BASE/'source-audit/raw-source-readback.json')
for n,h in load(BASE/'search/plan.json')['inputs'].items(): assert digest(ROOT/n)==h,n
assert p['maximum_solver_calls']==r['solver_calls']==1 and p['random_restarts']==r['random_restarts']==0
assert p['maximum_geometry_evaluations']==opened['maximum_geometry_evaluations']==6000 and r['geometry_evaluations']<=6000
assert p['maximum_iterations']==opened['maximum_iterations']==200 and raw['iterations']<=200
assert p['search_seconds']==opened['search_seconds']==60 and r['search_seconds']<60
assert p['shared_seconds']==90 and process['seconds']<90 and process['exit_code']==0 and not process['timeout']
assert p['finite_difference_step']==opened['finite_difference_step']==1e-7
assert len(callbacks)==r['callbacks']==raw['iterations']==48
assert opened['bounds']==[[0,1.5],[0,3],[0,p['angle_domain_radians'][1]]]*15+[[0,.778717]]
assert raw['status']==4 and not raw['success'] and raw['message']=='Inequality constraints incompatible'
assert not invalid['valid'] and invalid['pair_failures']==11 and invalid['stock_failures']==1
assert source['source_incumbents_verified']==1 and source['height_reduction_mm']==0
assert all(not v['diagnostics']['physical_source_outer_valid'] for v in callbacks)
initial=load(BASE/'initial.json'); first=callbacks[0]
write(OUT/'checks.json',{'passed':True,'frozen_input_bindings_verified':len(load(BASE/'search/plan.json')['inputs']),'solver_calls':1,'geometry_evaluations':r['geometry_evaluations'],'iterations':48,'search_seconds':r['search_seconds'],'shared_seconds':process['seconds'],'time_or_evaluation_overrun':False,'saved_source_valid_candidates':1,'all_callbacks_source_invalid':True,'raw_pair_failures':11,'raw_stock_failures':1,'first_proposed_top_decrease_mm':1000*(initial[45]-first['objective_top_m']),'first_proposal_minimum_constraint_mm':1000*first['diagnostics']['minimum_residual_m'],'returned_packet_height_mm':callbacks[-1]['diagnostics']['height_mm'],'valid_start_proves_constraint_system_is_not_empty':True,'solver_message_is_not_infeasibility_proof':True,'new_valid_height_gain_mm':0,'full66_witness':False,'native_calls':0,'H5_complete':False})
write(OUT/'plan.json',{'inputs':{q.relative_to(ROOT).as_posix():digest(q) for q in [BASE/'plan.json',BASE/'search/plan.json',BASE/'search/opened.json',BASE/'search/result.json',BASE/'search/process.json',BASE/'search/raw-response.json',BASE/'search/callbacks.json',BASE/'source-audit/checks.json',BASE/'source-audit/raw-source-readback.json']}})
print(load(OUT/'checks.json'))
