"""Independently read every retained original-source incumbent and raw response."""
from pathlib import Path
from hashlib import sha256
import json, math, shutil, time
from h5_legacy64_source_readback import audit
ROOT = Path(__file__).resolve().parents[1]; BASE = ROOT / 'output/h5-continuous-cog-source-20261028'; OUT = BASE / 'source-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f: json.dump(v, f, indent=2); f.write('\n')
def rows(z):
    result = []
    for i in range(15):
        x, y, a = z[3*i:3*i+3]; c, s = math.cos(a), math.sin(a)
        result.append({'part_id': 'cog', 'copy_index': i, 'sheet_id': 'sheet-0', 'transform': {'rotation_radians': a, 'mirrored': False, 'translation': [1000*x-139.723742*c+139.723742*s, 1000*y-139.723742*s-139.723742*c]}})
    return result
def extent(part, rr):
    points = []
    for r in rr:
        t = r['transform']; c, s = math.cos(t['rotation_radians']), math.sin(t['rotation_radians']); tx, ty = t['translation']
        points += [(x*c-y*s+tx, x*s+y*c+ty) for x, y in part['geometry'][0]['outer']]
    return [min(x for x,y in points), min(y for x,y in points), max(x for x,y in points), max(y for x,y in points)]
OUT.mkdir(); shutil.copyfile(__file__, OUT / 'audit.py'); started = time.perf_counter()
plan = load(BASE / 'plan.json'); result = load(BASE / 'search/result.json'); assert result['closed'] and result['solver_calls'] == 1
assert result['geometry_evaluations'] <= 6000 and load(BASE / 'search/process.json')['closed']
job = load(ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'); part = next(p for p in job['parts'] if p['id'] == 'cog')
expected = {('cog', i) for i in range(15)}; stocks = {'sheet-0': [6.5,6.5,1493.5,2993.5]}
records = []; source_rows = None
for p in sorted((BASE / 'search/incumbents').glob('*.json')):
    saved = load(p); z = saved['variables']; rr = rows(z)
    assert len(z) == 46 and all(0 <= z[i] <= math.pi/10 for i in range(2,45,3))
    checked = audit(job, rr, stocks, plan['required_source_gap_mm'], plan['native_stock_guard_mm'], expected); assert checked['valid']
    bb = extent(part, rr); height = bb[3]-bb[1]; width = bb[2]-bb[0]
    assert bb[3] <= 1000*z[45]+1e-7 and 0 <= z[45] <= .778717
    assert abs(height-saved['diagnostics']['height_mm']) < 1e-9 and abs(width-saved['diagnostics']['width_mm']) < 1e-9
    assert checked['minimum_pair_gap_mm'] >= .224-1e-7 and checked['minimum_extra_stock_mm'] >= .013-1e-7
    if records: assert height < records[-1]['height_mm']-.000099
    records.append({'sequence': saved['sequence'], 'source_valid': True, 'bounds_mm': bb, 'height_mm': height, 'width_mm': width, 'angle_degrees': [math.degrees(z[i]) for i in range(2,45,3)], **{k: checked[k] for k in ['same_sheet_pairs','stock_edges','cutouts','hole_vertices','minimum_pair_gap_mm','minimum_extra_stock_mm']}})
    source_rows = rr
assert records and len(records) == result['saved_valid_incumbents_including_control']
assert load(BASE / 'search/best.json') == load(sorted((BASE / 'search/incumbents').glob('*.json'))[-1])
published = load(BASE / 'search/best-source15.json')
for a,b in zip(source_rows,published):
    assert a['copy_index'] == b['copy_index'] and a['transform']['rotation_radians'] == b['transform']['rotation_radians']
    assert max(abs(x-y) for x,y in zip(a['transform']['translation'], b['transform']['translation'])) < 1e-9
write(OUT / 'best-source15.json', source_rows)
write(OUT / 'best-source-readback.json', audit(job, source_rows, stocks, plan['required_source_gap_mm'], plan['native_stock_guard_mm'], expected))
raw_valid = None
if result['raw_response_exists']:
    raw = load(BASE / 'search/raw-response.json'); raw_rows = rows(raw['variables']); checked = audit(job, raw_rows, stocks, plan['required_source_gap_mm'], plan['native_stock_guard_mm'], expected)
    write(OUT / 'raw-source-readback.json', checked); raw_valid = checked['valid']
    assert raw['objective_gradient'] == [0]*45+[1] and abs(raw['objective_top_m']-raw['variables'][45]) < 1e-15
write(OUT / 'incumbents.json', records)
old = load(ROOT / 'output/h5-cog15-height-20261028/source-audit/checks.json')
write(OUT / 'checks.json', {'passed': True, 'seconds': time.perf_counter()-started, 'status': result['status'], 'source_incumbents_verified': len(records), 'minimum_height_mm': records[-1]['height_mm'], 'width_mm': records[-1]['width_mm'], 'height_reduction_mm': old['actual_packet_height_mm']-records[-1]['height_mm'], 'width_change_mm': records[-1]['width_mm']-old['actual_packet_width_mm'], 'angle_range_degrees': [min(records[-1]['angle_degrees']),max(records[-1]['angle_degrees'])], 'raw_source_valid': raw_valid, 'source_pairs_per_incumbent': 105, 'source_stock_edges_per_incumbent': 60, 'source_holes_per_incumbent': 15, 'source_hole_vertices_per_incumbent': 3000, 'other_originals_required': 51, 'global_optimum_claimed': False, 'full66_witness': False, 'native_calls': 0, 'H5_complete': False})
inputs = [p for p in (BASE / 'search').rglob('*') if p.is_file()] + [BASE / 'plan.json', ROOT / 'output/h5_legacy64_source_readback.py', ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json']
write(OUT / 'plan.json', {'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
print(load(OUT / 'checks.json'))
