"""One predeclared SLSQP call, preserving valid incumbents and every exit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, subprocess, sys, time
ROOT = Path(__file__).resolve().parents[1]; BASE = ROOT / 'output/h5-continuous-cog-source-20261028'; OUT = BASE / 'search'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f: json.dump(v, f, indent=2); f.write('\n')
class BudgetStop(Exception): pass

def child():
    import numpy as np
    import scipy
    from scipy.optimize import minimize
    from h5_continuous_cog_source_20261028 import SourceProblem
    problem = SourceProblem(BASE); plan = problem.plan
    assert load(BASE / 'preflight/checks.json')['passed']
    for n, h in load(OUT / 'plan.json')['inputs'].items(): assert digest(ROOT / n) == h, n
    bounds = [(0, 1.5), (0, 3), (0, np.pi / 10)] * 15 + [(0, float(problem.initial[45]))]
    assert len(bounds) == 46 and all(lo <= v <= hi for v, (lo, hi) in zip(problem.initial, bounds))
    started = time.perf_counter(); deadline = started + plan['search_seconds']
    evaluations = 0; best = None; incumbents = []; callbacks = []; cached = None
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'scipy_version': scipy.__version__, 'numpy_version': np.__version__, 'one_solver_call': True, 'bounds': bounds, 'finite_difference_step': plan['finite_difference_step'], 'search_seconds': 60, 'maximum_geometry_evaluations': 6000, 'maximum_iterations': 200})
    def evaluate(z):
        nonlocal evaluations, best, cached
        if time.perf_counter() >= deadline: raise BudgetStop('TIME_LIMIT')
        if cached is not None and np.array_equal(cached[0], z): return cached[1], cached[2]
        if evaluations >= plan['maximum_geometry_evaluations']: raise BudgetStop('EVALUATION_LIMIT')
        residuals, diag = problem.geometry(z); evaluations += 1
        assert np.isfinite(z).all() and np.isfinite(residuals).all()
        in_bounds = all(lo-1e-14 <= value <= hi+1e-14 for value, (lo, hi) in zip(z, bounds))
        if in_bounds and diag['physical_source_outer_valid'] and residuals.min() >= -1e-10 and (best is None or diag['height_mm'] < best['diagnostics']['height_mm'] - .0001):
            best = {'sequence': len(incumbents), 'seconds': time.perf_counter()-started, 'evaluation': evaluations, 'variables': np.asarray(z).tolist(), 'diagnostics': diag}
            write(OUT / 'incumbents' / f"{len(incumbents):04d}.json", best); incumbents.append(best)
        cached = (np.asarray(z).copy(), residuals, diag)
        return residuals, diag
    def objective(z):
        evaluate(z)
        return float(z[45])
    def jacobian(z):
        gradient = np.zeros(46); gradient[45] = 1
        return gradient
    def constraints(z): return evaluate(z)[0]
    def callback(z):
        residuals, diag = evaluate(z)
        callbacks.append({'iteration': len(callbacks)+1, 'seconds': time.perf_counter()-started, 'evaluation': evaluations, 'objective_top_m': float(z[45]), 'diagnostics': diag})
    status = 'NOT_STARTED'; raw = None; error = None
    try:
        residuals, diag = evaluate(problem.initial)
        assert residuals.min() >= 0 and best is not None
        result = minimize(objective, problem.initial, jac=jacobian, method='SLSQP', bounds=bounds, constraints=[{'type': 'ineq', 'fun': constraints}], callback=callback, options={'maxiter': plan['maximum_iterations'], 'eps': plan['finite_difference_step'], 'ftol': plan['ftol'], 'disp': False})
        status = 'RETURNED'
        raw = {'success': bool(result.success), 'status': int(result.status), 'message': str(result.message), 'objective_top_m': float(result.fun), 'variables': np.asarray(result.x).tolist(), 'iterations': int(result.nit), 'nfev': int(result.nfev), 'njev': int(result.njev), 'objective_gradient': np.asarray(result.jac).tolist(), 'multipliers': np.asarray(getattr(result, 'multipliers', [])).tolist()}
        write(OUT / 'raw-response.json', raw)
    except BudgetStop as e: status = str(e)
    except Exception as e:
        status = 'ERROR'; error = repr(e)
    seconds = time.perf_counter()-started
    if best is not None:
        write(OUT / 'best.json', best); write(OUT / 'best-source15.json', problem.rows(best['variables']))
    write(OUT / 'callbacks.json', callbacks)
    write(OUT / 'result.json', {'status': status, 'error': error, 'closed': True, 'solver_calls': 1, 'random_restarts': 0, 'geometry_evaluations': evaluations, 'callbacks': len(callbacks), 'saved_valid_incumbents_including_control': len(incumbents), 'search_seconds': seconds, 'search_soft_overrun_seconds': max(0, seconds-plan['search_seconds']), 'raw_response_exists': raw is not None, 'source_readback_required': True, 'full66_witness': False, 'native_calls': 0, 'H5_complete': False})

def main():
    OUT.mkdir(); (OUT / 'incumbents').mkdir(); shutil.copyfile(__file__, OUT / 'run.py')
    inputs = [p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents] + [ROOT / 'output/h5_continuous_cog_source_20261028.py', ROOT / 'output/h5_legacy64_source_readback.py', Path(__file__)]
    write(OUT / 'plan.json', {'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}, 'solver_calls': 1, 'retry_permitted': False, 'shared_seconds': 90, 'search_seconds': 60})
    started = time.perf_counter()
    try:
        p = subprocess.run([str(ROOT / '.cache/shop-venv/Scripts/python.exe'), str(Path(__file__)), '--child'], cwd=ROOT, capture_output=True, timeout=90)
        (OUT / 'stdout.txt').write_bytes(p.stdout); (OUT / 'stderr.txt').write_bytes(p.stderr)
        record = {'seconds': time.perf_counter()-started, 'exit_code': p.returncode, 'timeout': False, 'closed': True}
    except subprocess.TimeoutExpired as e:
        (OUT / 'stdout.txt').write_bytes(e.stdout or b''); (OUT / 'stderr.txt').write_bytes(e.stderr or b'')
        record = {'seconds': time.perf_counter()-started, 'timeout': True, 'closed': True}
    write(OUT / 'process.json', record); print(record)
    print(load(OUT / 'result.json') if (OUT / 'result.json').exists() else 'No completed response; shared call closed.')
if __name__ == '__main__': child() if '--child' in sys.argv else main()
