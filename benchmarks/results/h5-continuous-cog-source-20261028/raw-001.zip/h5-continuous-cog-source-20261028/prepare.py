"""Freeze one direct-source continuous-angle experiment and its positive control."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, math, shutil
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/h5-continuous-cog-source-20261028'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(v, f, indent=2); f.write('\n')
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'prepare.py')
job_path = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
prior = ROOT / 'output/h5-cog15-height-20261028'
assert load(prior / 'source-audit/checks.json')['passed']
part = next(p for p in load(job_path)['parts'] if p['id'] == 'cog')
assert part['rotations']['kind'] == 'free' and len(part['geometry'][0]['outer']) == 80
rows = sorted(load(prior / 'response-audit/source15.json'), key=lambda r: r['copy_index'])
center = [139.723742, 139.723742]
initial = []
for r in rows:
    t = r['transform']; a = t['rotation_radians']; c, s = math.cos(a), math.sin(a)
    initial += [(t['translation'][0] + c * center[0] - s * center[1]) / 1000, (t['translation'][1] + s * center[0] + c * center[1]) / 1000, a]
initial += [.778717]
inputs = [job_path, prior / 'response-audit/source15.json', prior / 'source-audit/checks.json', ROOT / 'output/h5_continuous_cog_source_20261028.py', ROOT / 'output/h5_legacy64_source_readback.py']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}, 'variables': '15 independent (center-x metres, center-y metres, angle radians), then top metres', 'variable_count': 46, 'constraint_count': 180, 'pair_constraints': 105, 'stock_and_top_constraints': 75, 'source_center_mm': center, 'angle_domain_radians': [0, math.pi / 10], 'angle_domain_is_constructive_subset_only': True, 'source_symmetry_claimed': False, 'required_source_gap_mm': .21170867250963943, 'native_stock_guard_mm': .011444091796875, 'construction_gap_mm': .224, 'construction_stock_extra_mm': .013, 'constraint_scale': 'all lengths divided by 1000, in metres', 'overlap_proxy': 'negative square root of original filled-polygon intersection area in mm; disjoint uses actual distance', 'method': 'SLSQP', 'objective': 'top metres; accepted packet height independently measured', 'maximum_solver_calls': 1, 'random_restarts': 0, 'maximum_iterations': 200, 'maximum_geometry_evaluations': 6000, 'search_seconds': 60, 'shared_seconds': 90, 'finite_difference_step': 1e-7, 'ftol': 1e-10, 'retry_permitted': False, 'all_15_mandatory': True, 'other_originals_required': 51, 'native_calls': 0, 'full66_witness': False, 'H5_complete': False})
write(OUT / 'part.json', part); write(OUT / 'initial.json', initial); write(OUT / 'control-source15.json', rows)
print({'prepared': str(OUT), 'variables': len(initial), 'search_started': False})
