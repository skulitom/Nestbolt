"""Independent scalar source construction checks every optimizer constraint."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json, math, shutil, time
import numpy as np
from shapely.geometry import Polygon
from h5_continuous_cog_source_20261028 import SourceProblem
from h5_legacy64_source_readback import audit
ROOT = Path(__file__).resolve().parents[1]; BASE = ROOT / 'output/h5-continuous-cog-source-20261028'; OUT = BASE / 'preflight'
load = lambda p: json.loads(p.read_bytes())
def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f: json.dump(v, f, indent=2); f.write('\n')
OUT.mkdir(); shutil.copyfile(__file__, OUT / 'audit.py'); started = time.perf_counter()
problem = SourceProblem(BASE); plan = problem.plan
for n, h in plan['inputs'].items(): assert sha256((ROOT / n).read_bytes()).hexdigest() == h
job = load(ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json')
part = next(p for p in job['parts'] if p['id'] == 'cog'); assert part == problem.part
stock = {'sheet-0': [6.5, 6.5, 1493.5, 2993.5]}; expected = {('cog', i) for i in range(15)}
rows = problem.rows(problem.initial)
for a, b in zip(rows, load(BASE / 'control-source15.json')):
    assert a['copy_index'] == b['copy_index']
    assert abs(a['transform']['rotation_radians'] - b['transform']['rotation_radians']) < 1e-15
    assert max(abs(x-y) for x, y in zip(a['transform']['translation'], b['transform']['translation'])) < 1e-9
source = audit(job, rows, stock, plan['required_source_gap_mm'], plan['native_stock_guard_mm'], expected); assert source['valid']
write(OUT / 'source-control-audit.json', source)
cases = [('complete-positive-control', problem.initial.copy())]
z = problem.initial.copy(); z[2::3][:15] = np.linspace(0, math.pi / 10, 15); cases.append(('independent-angle-endpoints-and-interior', z))
z = problem.initial.copy(); z[3:6] = z[0:3]; cases.append(('coincident-pair-negative-control', z))
z = problem.initial.copy(); z[0] = 0; cases.append(('left-stock-negative-control', z))
z = problem.initial.copy(); z[45] = .1; cases.append(('top-negative-control', z))
records = []
for name, z in cases:
    polygons = []
    for i in range(15):
        x, y, a = z[3*i:3*i+3]; c, s = math.cos(a), math.sin(a); cx, cy = plan['source_center_mm']
        polygons.append(Polygon([((px-cx)*c-(py-cy)*s+x*1000, (px-cx)*s+(py-cy)*c+y*1000) for px, py in part['geometry'][0]['outer']]))
    residuals = []
    for p in polygons:
        x0, y0, x1, y1 = p.bounds; residuals += [x0-6.513, 1493.487-x1, y0-6.513, 2993.487-y1, z[45]*1000-y1]
    for a, b in combinations(polygons, 2): residuals.append((a.distance(b) if a.disjoint(b) else -math.sqrt(a.intersection(b).area))-.224)
    actual, diag = problem.geometry(z); expected_residuals = np.asarray(residuals)/1000
    error = float(np.max(np.abs(actual-expected_residuals))); assert len(actual) == 180 and error < 1e-12 and np.isfinite(actual).all()
    if name == 'complete-positive-control': assert min(actual) >= 0 and diag['physical_source_outer_valid']
    elif name == 'coincident-pair-negative-control': assert actual[75] < -.2 and not diag['physical_source_outer_valid']
    elif name == 'left-stock-negative-control': assert actual[0] < -.1 and not diag['physical_source_outer_valid']
    elif name == 'top-negative-control': assert actual[4] < -.1
    records.append({'case': name, 'checked_constraints': 180, 'max_error_m': error, 'minimum_constraint_m': float(actual.min())})
# Check all 46 perturbed variables remain finite; changing top moves precisely 15 top constraints.
base, _ = problem.geometry(problem.initial)
for i in range(46):
    z = problem.initial.copy(); z[i] += plan['finite_difference_step']; residuals, _ = problem.geometry(z); assert np.isfinite(residuals).all()
    if i == 45:
        delta = residuals-base; wanted = np.zeros(180); wanted[4:75:5] = plan['finite_difference_step']; assert np.max(np.abs(delta-wanted)) < 1e-15
write(OUT / 'cases.json', records)
write(OUT / 'checks.json', {'passed': True, 'seconds': time.perf_counter()-started, 'independent_scalar_constraint_checks': 900, 'finite_difference_probes': 46, 'complete_positive_control': True, 'source_pairs': 105, 'stock_edges': 60, 'source_holes': source['cutouts'], 'source_hole_vertices': source['hole_vertices'], 'angle_changes_use_all_original_vertices': True, 'negative_overlap_stock_top_controls': True, 'source_symmetry_claimed': False, 'search_calls': 0})
print(load(OUT / 'checks.json'))
