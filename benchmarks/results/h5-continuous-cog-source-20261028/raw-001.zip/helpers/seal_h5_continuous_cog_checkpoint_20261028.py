"""Seal the failed continuous-angle call without replacing the valid packet."""
from pathlib import Path
from datetime import datetime, timezone
import ast, json, shutil, subprocess, sys
from pack_h5_evidence_archive import pack, digest
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE = ROOT/'output/h5-continuous-cog-source-20261028'; PUB=BASE/'publication'; NAME='h5-continuous-cog-source-20261028'; OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(v,f,indent=2); f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD'); assert head=='8713c6e13a1ad2a9ce33a7276722016264105244' and not git('diff','HEAD','--name-only')
pre=load(BASE/'preflight/checks.json'); source=load(BASE/'source-audit/checks.json'); contract=load(BASE/'contract-audit/checks.json')
assert all(x['passed'] for x in [pre,source,contract]) and source['height_reduction_mm']==0 and contract['raw_pair_failures']==11
prior=load(ROOT/'benchmarks/results/h5-independent-cog-height-20261028/publication-review.json'); production=source_digest(); assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']}; assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha']; assert main==head
receipt=load(ROOT/'output/h5-cog15-main-sync-20261028/receipt.json'); assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
jobs=load(PUB/'main-ci-jobs.json')['jobs']; assert len(jobs)==6
passed=[r['name'] for r in jobs if r['status']=='completed' and r['conclusion']=='success']; live=[r['name'] for r in jobs if r['status']!='completed']
assert not [r for r in jobs if r['status']=='completed' and r['conclusion']!='success']
OUT.mkdir(); members={}; queue=[]; seen=set(); bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-cog15-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_continuous_cog_source_20261028.py','prepare_h5_continuous_cog_20261028.py','audit_h5_continuous_cog_preflight_20261028.py','run_h5_continuous_cog_20261028.py','audit_h5_continuous_cog_response_20261028.py','audit_h5_continuous_cog_contract_20261028.py','push_cog15_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n; assert digest(q)==h,n; bindings[n]=h; add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members); write(OUT/'source-bindings.json',bindings)
for a,b in [('preflight/checks.json','preflight-audit.json'),('source-audit/checks.json','source-audit.json'),('source-audit/raw-source-readback.json','rejected-source-readback.json'),('source-audit/best-source15.json','retained-source15.json'),('contract-audit/checks.json','contract-audit.json'),('search/result.json','search-result.json'),('publication/main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'pushed_prior_two_verified_checkpoints':True,'prior_main_CI':40735870933,'prior_main_all6_pass':True,'main_CI':40742366525,'main_all6_pass':len(passed)==6,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='The direct-source continuous-angle SLSQP call is CLOSED after48 iterations and2486 geometry evaluations (8.321686s search,9.325484s shared). Its first proposal lowered top96.679438mm and violated a source constraint by95.187405mm. All48 callbacks are source-invalid; the returned candidate has11 failed source pairs and1 failed stock boundary. The only retained valid candidate is the initial772.202399mm-high packet, so gain is zero. Do not restart, reseed or extend SLSQP and do not read its inequality-incompatible message as a geometric exclusion: the complete positive control proves the declared constraint set nonempty. Next design a materially different feasible-iterate trust-region formulation, using small center/angle increments with direct-source clearance checks for every accepted move. First independently audit the proposed linearized pair derivatives and stock/top constraints, use a complete valid control, and freeze a single finite iteration/evaluation/time budget before a new call. Linearized feasibility alone never accepts a placement. Full source checks are required for all preserved incumbents. The other51 non-cogs, all66 source/native/material checks and the original H5 matrix remain required. Preserve old source64,444 necessary allocation counts, original H2 gate and22 unopened vectors. Prior05a7232c and8713c6e1 are now on main after all6 checks of2adfa569 passed; new main CI40742366525 is live. Queue this evidence until all6 pass and fresh refs/live-run guards permit a normal push. Production/READMEs unchanged; no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':3,'solver_calls':1,'search_closed':True,'solver_status':'RETURNED_LOCAL_FAILURE','raw_pair_failures':11,'raw_stock_failures':1,'new_valid_height_gain_mm':0,'retained_source_height_mm':source['minimum_height_mm'],'retained_source_width_mm':source['width_mm'],'previous_source64_preserved':True,'remaining_necessary_allocations':444,'full66_witness':False,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Continuous cog rotations: rejected local result — 2026-10-28

Allowing independent cog rotations produced **no better source-valid packet**.
The sole SLSQP call is closed. Its returned candidate fails 11 of the 105
source-pair checks and one stock boundary; it is preserved as rejected evidence.
The starting packet remains valid at **772.202399 mm high × 1,436.447399 mm wide**.
H2/H5 remain open at **60% completed milestone weight**.

This experiment gives every one of the 15 cogs an independent center and angle,
plus a common top objective: 46 continuous variables. Angles range from 0° to
18°, a constructive subset of the job's free rotations, with no exact source
symmetry claim. Every evaluation rebuilds the filled polygon from all original
80 vertices. No fixed-angle obstacle or capacity rectangle is reused.

Positions and top use metres; angles use radians. The 180 inequality residuals
are in metres: 105 source-pair constraints and 75 stock/top constraints. The
construction clearance is 0.224 mm and stock extra 0.013 mm, compared with the
original acceptance thresholds of 0.211708673 mm and 0.011444092 mm. Overlap
uses negative square root of intersection area as an optimization proxy; source
acceptance always requires actual disjoint polygons and original distances.

Before solving, independent scalar construction checked all 180 constraints
in five cases, including varied angles and deliberately invalid coincident,
stock and top controls. All 900 comparisons passed, as did 46 finite-difference
probes. The complete positive control passes 105 original pairs, 60 stock edges,
15 holes and 3,000 hole vertices.

The predeclared budget permits one call, 200 iterations, 6,000 geometry
evaluations, 60 seconds of search and 90 seconds shared time. There are no
restarts. The call returned after **48 iterations / 2,486 geometry evaluations**,
using **8.321686 seconds** of search and **9.325484 seconds** shared time; neither
budget was exceeded. The raw status is 4, “Inequality constraints incompatible”.
This is a local numerical failure, **not an infeasibility certificate**: the
independently verified starting packet satisfies the declared constraints.

The first proposed step lowers the top by 96.679438 mm, but its most violated
source residual is −95.187405 mm. Every one of the 48 saved callbacks is
source-invalid. The raw final packet is 777.142862 mm high, has 11 failed pairs,
and extends 0.262361 mm beyond the usable stock boundary. No failed candidate
replaces the starting packet. Independent source readback and the frozen-input,
bound and budget audit pass for the retained evidence. The height gain is zero.

The next formulation must keep accepted iterates feasible: small proposed
center/angle changes, independently checked derivatives, and exact source
clearance checks before accepting any move. It needs a new audited control and
one frozen finite budget. This closed SLSQP call will not be restarted or
extended. The other 51 original parts still need placement; any cog packet
requires all 66 original parts and source/native/material validation before
integration or the full H5 matrix. The previous valid64 and 444 necessary
allocation counts are preserved.

The preceding commits 05a7232c and 8713c6e1 were pushed normally and atomically
to main and the working branch after all six jobs on 2adfa569 passed.
[CI 40742366525](https://github.com/skulitom/Nestbolt/actions/runs/40742366525)
is running on main 8713c6e1. This checkpoint waits for its six jobs before
another normal push. Production and all READMEs are unchanged. Upstream Sparrow
remains 6f7b9d35 / v0.3.0; Studio remains c0bb9e86 without a release. No stop rule
fires. H2's original gate and 22 unopened reserved vectors remain unchanged.
No new release qualifies.

Evidence: [preflight]({NAME}/preflight-audit.json),
[independent source readback]({NAME}/source-audit.json),
[rejected source checks]({NAME}/rejected-source-readback.json),
[budget and diagnosis]({NAME}/contract-audit.json),
[retained packet]({NAME}/retained-source15.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The byte-verified archive contains {archive['archive_members']} canonical files
and {archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including the frozen inputs, scripts, raw response, all callback
diagnostics, rejected readback, positive control and publication receipt.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 independent cog rotations, 2026-10-28:** [the direct-source experiment]({link})
adds independent angles and rebuilds all original vertices. Its 900-constraint
preflight and full source control pass. The sole bounded SLSQP call is CLOSED
after 48 iterations / 2,486 geometry evaluations (8.321686 s search, 9.325484 s
shared). Its result fails 11 source pairs and one stock boundary; all 48
callbacks are invalid. The original valid 772.202399 mm packet is retained;
height gain is zero. The solver message is not geometric infeasibility, since
the complete initial control is valid. Preserve the failed result; no restart
or extension. Next audit a feasible-iterate formulation using small proposed
position/angle steps and exact source checks before acceptance. All other 51
originals, full66 validation and H5 material checks remain required. Earlier
05a7232c/8713c6e1 checkpoints are now on main after all six prior checks passed;
new CI 40742366525 is live. Further pushes wait for all six jobs. Production,
READMEs, valid64, 444-count frontier, H2 gate and 22 reserved vectors remain
unchanged. H2/H5 stay open at 60%; no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
