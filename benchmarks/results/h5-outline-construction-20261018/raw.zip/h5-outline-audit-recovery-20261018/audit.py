"""Replay every recorded addition using original-source vertex transforms."""
from pathlib import Path
from collections import Counter
import gzip,itertools,json,math,shutil,subprocess,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1]
BEAM=ROOT/'output/h5-outline-beam-20261018';FILL=ROOT/'output/h5-outline-backfill-20261018'
OUT=ROOT/'output/h5-outline-audit-recovery-20261018'
OLD=ROOT/'output/h5-outline-audit-20261018'
load=lambda p:json.loads(p.read_bytes())


def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')


def coords(part,t,dx=0,dy=0):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);out=[]
    assert not t['mirrored'] or part['allow_mirror']
    if part['rotations']['kind']=='list':
        assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
    assert len(part['geometry'])==1
    for x,y in part['geometry'][0]['outer']:
        if t['mirrored']:x=-x
        out.append((c*x-s*y+t['translation'][0]+dx,s*x+c*y+t['translation'][1]+dy))
    return out


def templates(job,path):
    parts={p['id']:p for p in job['parts']};result=[];internal=0
    for t in load(path):
        assert t['template_id']==len(result)
        ps=[coords(parts[m['part_id']],m['transform']) for m in t['members']]
        geoms=[Polygon(p) for p in ps];assert all(g.is_valid and g.area>0 for g in geoms)
        for a,b in itertools.combinations(geoms,2):
            assert a.disjoint(b) and a.distance(b)>=job['clearance']-1e-7;internal+=1
        result.append({'id':t['id'],'points':ps,'counts':Counter(m['part_id'] for m in t['members'])})
    return result,internal


def add(parent,block,ts,job,width,heights):
    t=ts[block['template']];sheet=block['sheet'];x,y=block['x'],block['y']
    added=[Polygon([(a+x,b+y) for a,b in p]) for p in t['points']]
    pairs=0;minimum=None;valid=True
    for g in added:
        a,b,c,d=g.bounds
        valid &= a>=-1e-7 and b>=-1e-7 and c<=width+1e-7 and d<=heights[sheet]+1e-7
        for old in parent['geoms'][sheet]:
            pairs+=1;slack=g.distance(old)-job['clearance']
            minimum=slack if minimum is None else min(minimum,slack)
            valid &= g.disjoint(old) and slack>=-1e-7
    geoms=[list(p) for p in parent['geoms']];geoms[sheet]+=added
    return {'geoms':geoms,'counts':parent['counts']+t['counts']},bool(valid),pairs,minimum


def public(folder,job,layout,name):
    dest=OUT/name;dest.mkdir();write(dest/'layout.json',layout)
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    command=[str(cli),'validate','--library',str(folder/'library.json'),'--request',str(folder/'request.json'),'--layout',str(dest/'layout.json')]
    previous=OLD/name
    if (previous/'stdout.json').exists():
        assert (previous/'layout.json').read_bytes()==(dest/'layout.json').read_bytes()
        prior_command=load(previous/'command.json')
        assert prior_command['command'][:-1]==command[:-1]
        raw=(previous/'stdout.json').read_bytes();err=(previous/'stderr.log').read_bytes();code=prior_command['exit_code']
        command_record={**prior_command,'reused_original_output':True,'current_layout_bytes_match_original':True,'current_layout':str(dest/'layout.json')}
    else:
        r=subprocess.run(command,capture_output=True,timeout=60);raw=r.stdout;err=r.stderr;code=r.returncode
        command_record={'command':command,'exit_code':code,'reused_original_output':False}
    (dest/'stdout.json').write_bytes(raw);(dest/'stderr.log').write_bytes(err)
    write(dest/'command.json',command_record);report=json.loads(raw)
    expected=Counter({p['id']:p['quantity'] for p in job['parts']});placed=Counter(p['part_id'] for p in layout['placements'])
    missing=expected-placed;assert missing
    # A public validator may distinguish geometric validity from completeness.
    # Preserve its exact answer and independently require every missing copy.
    count=sum(missing.values())
    assert not report['valid'] and code!=0 and report['metrics'] is None
    expected_messages={f'part {k}: expected {expected[k]}, found {placed[k]}' for k in missing}
    assert report['violation_count']==len(missing)
    assert {v['message'] for v in report['violations']}==expected_messages
    assert all(v['code']=='quantity' for v in report['violations'])
    return {'folder':dest.name,'CLI_valid':False,'CLI_exit':code,'only_expected_quantity_rejections':True,
            'missing':dict(missing),'missing_count':count,'complete':False,'reused_original_output':command_record['reused_original_output']}


def check_final(job,layout,width,heights):
    st=job['stocks'][0];e=job['edge_clearance'];m=st['margins'];parts={p['id']:p for p in job['parts']}
    origin=[m['left']+e+1e-4,m['bottom']+e+1e-4];groups=[[],[]]
    assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
    for p in layout['placements']:
        g=Polygon(coords(parts[p['part_id']],p['transform'],-origin[0],-origin[1]));sheet=int(p['sheet_id'].split('-')[-1]);a,b,c,d=g.bounds
        assert g.is_valid and a>=-1e-7 and b>=-1e-7 and c<=width+1e-7 and d<=heights[sheet]+1e-7
        groups[sheet].append(g)
    pairs=0
    for ps in groups:
        for a,b in itertools.combinations(ps,2):
            pairs+=1;assert a.disjoint(b) and a.distance(b)>=job['clearance']-1e-7
    return {'geoms':groups,'counts':Counter(p['part_id'] for p in layout['placements'])},pairs


def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');records=[];public_checks=[]
    try:
        for result in load(BEAM/'results.json')['cases']:
            folder=BEAM/result['case'];job=load(folder/'job.json');domain=load(folder/'domain.json');ts,internal=templates(job,folder/'templates.json')
            expected=Counter({p['id']:p['quantity'] for p in job['parts']});parents={};children={};count=0;pairs=0;empty=0;roots=0;best_seen=False
            best=load(folder/'best-partial.json')
            with gzip.open(folder/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
                for line in f:
                    event=json.loads(line);kind=event['kind']
                    if kind=='root':
                        roots+=1;order=event['order'];pool={t['id']:t['counts'] for t in ts}
                        assert sum((pool[n] for n in order),Counter())==expected
                        parents={event['id']:{'geoms':[[],[]],'counts':Counter()}};children={}
                    elif kind=='candidate':
                        block=event['block'];assert ts[block['template']]['id']==order[event['depth']]
                        child,valid,n,slack=add(parents[event['parent']],block,ts,job,domain['width'],domain['heights'])
                        count+=1;pairs+=n;assert valid==event['valid']
                        assert all(v<=expected[k] for k,v in child['counts'].items())
                        if valid:children[event['id']]=child
                        if event['id']==best['state']['id']:
                            assert valid and sum((pool[n] for n in best['remaining']),child['counts'])==expected;best_seen=True
                    elif kind=='beam':
                        assert len(event['ids'])<=6 and all(i in children for i in event['ids'])
                        parents={i:children[i] for i in event['ids']};children={}
                    elif kind=='empty_region':assert event['parent'] in parents;empty+=1
                    elif kind=='run_end':assert event['required_patterns']==len(order)
                    else:raise AssertionError(kind)
            assert best_seen and count==result['candidate_additions'] and pairs==result['addition_pair_checks']
            final=load(folder/'best-partial-layout.json');_,fp=check_final(job,final,domain['width'],domain['heights'])
            public_checks.append(public(folder,job,final,'beam-'+folder.name))
            record={'case':folder.name,'candidate_additions':count,'candidate_pairs':pairs,'empty_regions':empty,'orders_started':roots,'internal_template_pairs':internal,'saved_best_pairs':fp}
            records.append(record);print(json.dumps(record),flush=True)
        fills=[]
        for result in load(FILL/'results.json')['cases']:
            folder=FILL/result['case'];source=BEAM/folder.name;job=load(folder/'job.json');domain=load(source/'domain.json');ts,internal=templates(job,folder/'templates.json')
            initial=load(folder/'best-partial-layout.json');state,_=check_final(job,initial,domain['width'],domain['heights'])
            expected=Counter({p['id']:p['quantity'] for p in job['parts']});count=0;pairs=0;accepted=0
            with gzip.open(folder/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
                for line in f:
                    event=json.loads(line)
                    if event['kind']=='candidate':
                        child,valid,n,slack=add(state,event['block'],ts,job,domain['width'],domain['heights'])
                        assert valid==event['valid'];count+=1;pairs+=n
                    elif event['kind']=='accepted':
                        state,valid,_,_=add(state,event['block'],ts,job,domain['width'],domain['heights']);assert valid;accepted+=1
                        assert expected-state['counts']==Counter(event['remaining'])
                    else:assert event['kind']=='empty'
            assert count==result['candidate_attempts'] and pairs==result['addition_pair_checks'] and accepted==result['added_parts']
            final=load(folder/'layout.json');assert final['placements'][:len(initial['placements'])]==initial['placements']
            _,fp=check_final(job,final,domain['width'],domain['heights'])
            pub=public(folder,job,final,'backfill-'+folder.name);assert pub['missing']==result['remaining'];public_checks.append(pub)
            record={'case':folder.name,'candidate_additions':count,'candidate_pairs':pairs,'accepted':accepted,'remaining':result['remaining'],'saved_final_pairs':fp,'initial_placements_exact':True}
            fills.append(record);print(json.dumps(record),flush=True)
        checks={'all_checks_passed':True,'beam':records,'backfill':fills,'public_checks':public_checks,
            'original_quantity_completeness_passed':False,'whole_layouts_complete':0,
            'absolute_clearance_tolerance_mm':1e-7,'all_original_holes_reserved':True,
            'scope':'Every recorded candidate addition is independently replayed from original-source vertices, plus all saved best/final partial pairs. Public original library/request validation is retained verbatim; partial geometry validity is not whole-job completeness. No search repeated.'}
        write(OUT/'checks.json',checks);print(json.dumps({'all_checks_passed':True,'public_checks':len(public_checks),'complete_layouts':0}),flush=True)
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':records,'public':public_checks});raise


if __name__=='__main__':main()
