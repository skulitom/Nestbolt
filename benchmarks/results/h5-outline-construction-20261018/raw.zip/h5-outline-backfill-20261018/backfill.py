"""Continue saved partial layouts with ungrouped, optionally mirrored parts."""
from pathlib import Path
from collections import Counter
import copy,gzip,importlib.util,json,math,shutil,time,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('beam',ROOT/'output/construct_h5_outline_beam.py')
beam=importlib.util.module_from_spec(spec);spec.loader.exec_module(beam)
base=beam.base;gap=beam.gap;load=base.load;write=base.write
PRIOR=ROOT/'output/h5-outline-beam-20261018'
OUT=ROOT/'output/h5-outline-backfill-20261018'


def main():
    assert load(PRIOR/'results.json')['complete']
    OUT.mkdir();shutil.copyfile(__file__,OUT/'backfill.py')
    plan={'input_results_sha256':base.digest(PRIOR/'results.json'),'script_sha256':base.digest(Path(__file__)),
        'method':'Continue each saved best partial layout, preserving every existing placement exactly. Flatten missing compound inventories into original individual copies. Include both mirror states when permitted, all quarter turns for discrete parts and 15-degree choices for free parts. At each step inspect remaining families by decreasing filled area; select the first family with a feasible outline-based contact, then its lowest prefix-waste candidate. Keep all placed neighbours fixed. No-family-fit ends the construction; do not stop merely because an earlier family fails. Only current missing copies are added. This cannot rearrange already placed parts and is not a complete geometric feasibility algorithm.',
        'scope':'Offline continuation only, no Nestbolt solver or quality/timing run. The previous beam results and timeouts remain unchanged.',
        'new_Nestbolt_searches':0}
    write(OUT/'plan.json',plan);results=[]
    try:
        for source_result in load(PRIOR/'results.json')['cases']:
            source=PRIOR/source_result['case'];folder=OUT/source.name;folder.mkdir()
            for name in ['job.json','library.json','request.json','original.json','conditional-target.json','best-partial-layout.json']:
                shutil.copyfile(source/name,folder/name)
            job=load(folder/'job.json');initial=load(folder/'best-partial-layout.json');target=load(folder/'conditional-target.json')
            parts={p['id']:p for p in job['parts']};shapes={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']}
            patterns={k:base.pattern(k,[base.member(k)],shapes) for k in parts}
            for k,p in parts.items():
                if p['allow_mirror']:patterns[k+'-mirror']=base.pattern(k+'-mirror',[base.member(k,base.transform(mirrored=True))],shapes)
            st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];origin=[m['left']+e+1e-4,m['bottom']+e+1e-4]
            width=st['width']-m['left']-m['right']-2*e-2e-4
            heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
            placer=beam.Placement(job,patterns,width,heights)
            candidate_templates={k:[t['template_id'] for t in placer.templates if len(t['members'])==1 and t['members'][0]['part_id']==k] for k in parts}
            state={'id':0,'placed':[]};fixed_cache={}
            for p in initial['placements']:
                t=p['transform'];key=(p['part_id'],t['rotation_radians'],t['mirrored'])
                zero={**t,'translation':[0.,0.]};shape=gap.pose(shapes[p['part_id']],zero);x0,y0,_,_=shape.bounds
                if key not in fixed_cache:
                    q=base.pattern('fixed-'+p['part_id'],[base.member(p['part_id'],zero)],shapes)
                    q.update(template_id=len(placer.templates),outer_geometries=[gap.pose(shapes[p['part_id']],q['members'][0]['transform'])])
                    fixed_cache[key]=q['template_id'];placer.templates.append(q)
                state['placed'].append({'template':fixed_cache[key],'x':t['translation'][0]-origin[0]+x0,
                    'y':t['translation'][1]-origin[1]+y0,'sheet':int(p['sheet_id'].split('-')[-1])})
            state['score']=placer.score(state)
            write(folder/'templates.json',[{k:v for k,v in t.items() if k!='outer_geometries'} for t in placer.templates])
            actual=copy.deepcopy(initial);counts=Counter(p['part_id'] for p in initial['placements'])
            remaining=Counter({p['id']:p['quantity'] for p in job['parts']})-counts
            write(folder/'initial-state.json',{'state':state,'remaining':dict(remaining),'initial_layout_sha256':base.digest(folder/'best-partial-layout.json')})
            transitions=[];attempts=0
            with gzip.open(folder/'candidates.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                while remaining:
                    choice=None
                    for family in sorted(remaining,key=lambda k:(-shapes[k].area,k)):
                        possibilities=[]
                        for tid in candidate_templates[family]:
                            for sheet in [0,1]:
                                points=placer.positions(state,tid,sheet)
                                if not points:log.write(json.dumps({'kind':'empty','step':len(transitions),'family':family,'template':tid,'sheet':sheet})+'\n')
                                for x,y in points:
                                    block={'template':tid,'x':x,'y':y,'sheet':sheet};valid=placer.valid_addition(state,block);attempts+=1
                                    trial={'id':attempts,'placed':state['placed']+[block]};trial['score']=placer.score(trial)
                                    log.write(json.dumps({'kind':'candidate','step':len(transitions),'family':family,'block':block,'valid':valid,'score':trial['score']})+'\n')
                                    if valid:possibilities.append(trial)
                        if possibilities:
                            choice=(family,min(possibilities,key=lambda x:(x['score'],x['id'])));break
                    if choice is None:break
                    family,state=choice;block=state['placed'][-1];t=copy.deepcopy(placer.templates[block['template']]['members'][0]['transform'])
                    t['translation'][0]+=block['x']+origin[0];t['translation'][1]+=block['y']+origin[1]
                    addition={'part_id':family,'copy_index':counts[family],'sheet_id':f"sheet-{block['sheet']}",'transform':t}
                    actual['placements'].append(addition);counts[family]+=1;remaining[family]-=1
                    if not remaining[family]:del remaining[family]
                    transitions.append({'addition':addition,'block':block,'remaining':dict(remaining)})
                    log.write(json.dumps({'kind':'accepted','step':len(transitions),'block':block,'remaining':dict(remaining)})+'\n')
            assert actual['placements'][:len(initial['placements'])]==initial['placements']
            write(folder/'layout.json',actual);write(folder/'transitions.json',transitions)
            success=None
            if not remaining:
                success=gap.validate(folder,'complete',actual,job,load(folder/'original.json'),{(p['part_id'],p['copy_index']) for p in load(folder/'original.json')['placements']})
                assert success['metrics']['material_area']<=target['target_material_mm2']+1e-6
            result={'case':folder.name,'added_parts':len(transitions),'candidate_attempts':attempts,
                'remaining':dict(remaining),'remaining_filled_area_mm2':sum(shapes[k].area*n for k,n in remaining.items()),
                'initial_placements_exact':True,'complete_layout_found':not remaining,'public_complete_check':success,
                'relative_obstacle_cache':len(placer.obstacles),'addition_pair_checks':placer.pair_checks}
            write(folder/'result.json',result);results.append(result);print(json.dumps({k:v for k,v in result.items() if k!='public_complete_check'}),flush=True)
        assert base.digest(PRIOR/'results.json')==plan['input_results_sha256']
        write(OUT/'results.json',{'complete':True,'cases':results,'original_beam_results_unchanged':True,'new_Nestbolt_searches':0,'H5_complete':False})
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
