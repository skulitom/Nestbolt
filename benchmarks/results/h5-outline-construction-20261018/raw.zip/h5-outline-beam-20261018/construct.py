"""Offline constructive beam placement of verified filled-outer components.

No Nestbolt solver run or runtime comparison. Diagnostic ceilings and finite
choices are recorded explicitly; timeout or no witness is not infeasibility.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,importlib.util,itertools,json,math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,box
from shapely.affinity import affine_transform
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('base',ROOT/'output/construct_h5_pattern_layouts.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
gap=base.gap;load=base.load;write=base.write
OUT=ROOT/'output/h5-outline-beam-20261018'
PRIOR=ROOT/'output/h5-angle-pattern-placement-20261018'
WIDTH=6
POINTS=3
SECONDS=120


def oriented(pattern,angle,shapes):
    c,s=math.cos(angle),math.sin(angle);members=[]
    for m in pattern['members']:
        t=copy.deepcopy(m['transform']);x,y=t['translation'];t['translation']=[c*x-s*y,s*x+c*y];t['rotation_radians']+=angle
        members.append(base.member(m['part_id'],t))
    return base.pattern(pattern['id'],members,shapes)


def templates(patterns,shapes,parts):
    out=[];by_name={}
    for name,p in patterns.items():
        free=len(p['members'])==1 and parts[p['members'][0]['part_id']]['rotations']['kind']=='free'
        angles=[math.radians(a) for a in range(0,360,15 if free else 90)]
        seen=set()
        for angle in angles:
            q=oriented(p,angle,shapes)
            geoms=[gap.pose(shapes[m['part_id']],m['transform']) for m in q['members']]
            # Use rounded geometry only to omit equivalent orientation choices;
            # every retained template keeps its original unrounded vertices.
            key=tuple(sorted((m['part_id'],shapely.normalize(shapely.set_precision(g,1e-6)).wkb_hex) for m,g in zip(q['members'],geoms)))
            if key in seen:continue
            seen.add(key);q.update(template_id=len(out),outer_geometries=geoms)
            by_name.setdefault(name,[]).append(q['template_id']);out.append(q)
    return out,by_name


class Placement:
    def __init__(self,job,patterns,width,heights):
        self.job=job;self.patterns=patterns;self.width=width;self.heights=heights
        self.parts={p['id']:p for p in job['parts']};self.shapes={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']}
        self.templates,self.by_name=templates(patterns,self.shapes,self.parts)
        self.obstacles={};self.allowed={};self.clearance=job['clearance']+.001
        self.pair_checks=0
        for t in self.templates:
            for sheet,h in enumerate(heights):
                w=width-t['width'];top=h-t['height']
                self.allowed[(t['template_id'],sheet)]=box(0,0,w,top) if w>0 and top>0 else Polygon()

    def forbidden(self,fixed,moving):
        key=(fixed,moving)
        if key not in self.obstacles:
            a=self.templates[fixed];b=self.templates[moving]
            self.obstacles[key]=unary_union([gap.obstacle(x,y,self.clearance) for x in a['outer_geometries'] for y in b['outer_geometries']])
        return self.obstacles[key]

    def positions(self,state,tid,sheet):
        free=self.allowed[(tid,sheet)]
        if free.is_empty:return []
        obstacles=[affine_transform(self.forbidden(p['template'],tid),[1,0,0,1,p['x'],p['y']]) for p in state['placed'] if p['sheet']==sheet]
        if obstacles:free=free.difference(unary_union(obstacles))
        candidates=[]
        for poly in gap.polygons(free):
            # Positive-area regions only; construction margin is conservative.
            if poly.area<=0:continue
            for ring in [poly.exterior,*poly.interiors]:candidates+=list(ring.coords)[:-1]
            point=poly.representative_point();candidates.append((point.x,point.y))
        candidates=sorted(set(candidates),key=lambda p:(p[1],p[0]))
        # Keep different contact locations rather than several near-identical
        # floating-point vertices at one contact.
        selected=[]
        for x,y in candidates:
            if any(abs(x-a)<1e-4 and abs(y-b)<1e-4 for a,b in selected):continue
            selected.append((x,y))
            if len(selected)==POINTS:break
        return selected

    def valid_addition(self,state,block):
        t=self.templates[block['template']]
        moving=[affine_transform(g,[1,0,0,1,block['x'],block['y']]) for g in t['outer_geometries']]
        for old in state['placed']:
            if old['sheet']!=block['sheet']:continue
            fixed=[affine_transform(g,[1,0,0,1,old['x'],old['y']]) for g in self.templates[old['template']]['outer_geometries']]
            for a,b in itertools.product(moving,fixed):
                self.pair_checks+=1
                if not a.disjoint(b) or a.distance(b)<self.job['clearance']-1e-7:return False
        return all(g.bounds[0]>=-1e-7 and g.bounds[1]>=-1e-7 and g.bounds[2]<=self.width+1e-7 and g.bounds[3]<=self.heights[block['sheet']]+1e-7 for g in moving)

    def score(self,state):
        tops=[0.,0.];areas=[0.,0.]
        for p in state['placed']:
            t=self.templates[p['template']];tops[p['sheet']]=max(tops[p['sheet']],p['y']+t['height']);areas[p['sheet']]+=t['area']
        state['tops']=tops;state['areas']=areas
        return (sum(tops)*self.width-sum(areas),tops[1],tops[0])

    def choose_beam(self,candidates):
        ordered=sorted(candidates,key=lambda x:(x['score'],x['id']))
        bucket_width=self.width*self.heights[1]/WIDTH
        # Retain different sheet allocations, including an empty last sheet,
        # instead of pruning every early second-sheet placement.
        buckets={}
        for s in ordered:
            k=min(WIDTH-1,int(s['areas'][1]/bucket_width))
            if k not in buckets:buckets[k]=s
        selected=sorted(buckets.values(),key=lambda x:(x['score'],x['id']))[:WIDTH]
        ids={s['id'] for s in selected}
        for s in ordered:
            if len(selected)==WIDTH:break
            if s['id'] not in ids:selected.append(s);ids.add(s['id'])
        return selected

    def layout(self,state):
        st=self.job['stocks'][0];m=st['margins'];e=self.job['edge_clearance'];count=Counter();placements=[]
        for block in state['placed']:
            for p in self.templates[block['template']]['members']:
                t=copy.deepcopy(p['transform']);t['translation'][0]+=block['x']+m['left']+e+1e-4;t['translation'][1]+=block['y']+m['bottom']+e+1e-4
                placements.append({'part_id':p['part_id'],'copy_index':count[p['part_id']],'sheet_id':f"sheet-{block['sheet']}",'transform':t});count[p['part_id']]+=1
        return {'version':1,'units':'mm','sheets':[{'id':f'sheet-{i}','stock_id':st['id']} for i in range(2)],'placements':placements}


def main():
    OUT.mkdir();production=gap.source_digest()
    assert production=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'source_digest':production,'script_sha256':base.digest(Path(__file__)),
        'geometry_helper_sha256':base.digest(Path(gap.__file__)),'input_results_sha256':base.digest(PRIOR/'results.json'),
        'method':'Use each original job with two inventories: the verified mixed/free-angle pattern selection, then all single original parts. For each inventory, test four fixed area/long-side/short-side/filled-area orders. Place actual filled outer components by convex-piece Minkowski exclusion and original stock containment. Keep three lowest distinct boundary/interior contact points per template orientation and sheet; retain six beam states with diversity in second-sheet occupied area. Quarter turns preserve compound orientations; free single parts sample 15-degree increments. Every addition is independently distance-checked. Cache relative forbidden polygons without changing original geometry. Retain every considered candidate as parent plus one added block, each surviving beam, and the best partial result. Validate any full witness through original public library/request plus independent filled-outer checks.',
        'beam_width':WIDTH,'contacts_per_template':POINTS,'diagnostic_seconds_per_case':SECONDS,
        'scope':'Finite offline construction on CCD1, not a Nestbolt quality or timing run. The 120-second diagnostic ceiling is independent of and does not alter production or H5 allowances. Missing witnesses, pruned branches and timeouts do not prove infeasibility.',
        'new_Nestbolt_searches':0,'H5_complete':False}
    write(OUT/'plan.json',plan);shutil.copyfile(__file__,OUT/'construct.py')
    results=[]
    try:
        for row in load(PRIOR/'results.json')['cases']:
            src=PRIOR/row['case'];folder=OUT/row['case'];folder.mkdir()
            for name in ['job.json','library.json','request.json','original.json','conditional-target.json','patterns.json','selection.json']:
                shutil.copyfile(src/name,folder/name)
            job=load(folder/'job.json');original=load(folder/'original.json');all_patterns=load(folder/'patterns.json');selection=load(folder/'selection.json')['selected']
            singles={p['id']:p['quantity'] for p in job['parts']}
            patterns={k:all_patterns[k] for k in set(selection)|set(singles)}
            st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];b=load(folder/'conditional-target.json')
            width=st['width']-m['left']-m['right']-2*e-2e-4
            heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,b['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
            start=time.monotonic();deadline=start+SECONDS;placer=Placement(job,patterns,width,heights)
            write(folder/'templates.json',[{k:v for k,v in t.items() if k!='outer_geometries'} for t in placer.templates])
            write(folder/'domain.json',{'width':width,'heights':heights,'inventory_variants':[selection,singles]})
            next_id=1;best=None;attempts=[];success=None;expired=False;candidate_count=0;rejected=0
            with gzip.open(folder/'candidates.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                def emit(value):log.write(json.dumps(value,separators=(',',':'))+'\n')
                for inventory_name,inventory in [('mixed',selection),('single',singles)]:
                    for order_name in ['area','long','short','filled']:
                        if time.monotonic()>=deadline:expired=True;break
                        def rank(name):
                            p=patterns[name]
                            return ({'area':p['width']*p['height'],'long':max(p['width'],p['height']),'short':min(p['width'],p['height']),'filled':p['area']}[order_name],p['area'],name)
                        order=sorted([name for name,count in inventory.items() for _ in range(count)],key=rank,reverse=True)
                        root={'id':next_id,'placed':[],'score':(0,0,0),'areas':[0,0],'tops':[0,0]};next_id+=1
                        beam=[root];emit({'kind':'root','id':root['id'],'inventory':inventory_name,'order_name':order_name,'order':order})
                        reached=0;run_best=root
                        for depth,name in enumerate(order):
                            children=[]
                            for parent in beam:
                                for tid in placer.by_name[name]:
                                    for sheet in [0,1]:
                                        if time.monotonic()>=deadline:expired=True;break
                                        points=placer.positions(parent,tid,sheet)
                                        if not points:emit({'kind':'empty_region','parent':parent['id'],'template':tid,'sheet':sheet,'depth':depth})
                                        for x,y in points:
                                            block={'template':tid,'x':x,'y':y,'sheet':sheet};valid=placer.valid_addition(parent,block)
                                            child={'id':next_id,'placed':parent['placed']+[block]};next_id+=1;candidate_count+=1
                                            child['score']=placer.score(child)
                                            emit({'kind':'candidate','id':child['id'],'parent':parent['id'],'block':block,'valid':valid,'score':child['score'],'depth':depth})
                                            if valid:children.append(child)
                                            else:rejected+=1
                                        if expired:break
                                    if expired:break
                                if expired:break
                            if not children:break
                            beam=placer.choose_beam(children);reached=depth+1;run_best=min(beam,key=lambda s:(s['score'],s['id']))
                            emit({'kind':'beam','depth':depth,'ids':[s['id'] for s in beam]})
                            for child in beam:
                                filled=sum(child['areas'])
                                if best is None or (-filled,child['score'])<(-best['filled_area'],best['state']['score']):
                                    best={'state':child,'filled_area':filled,'inventory':inventory_name,'order_name':order_name,'remaining':order[depth+1:]}
                            if expired:break
                        run={'inventory':inventory_name,'order':order_name,'placed_patterns':reached,'required_patterns':len(order),'expired':expired,'best_node':run_best['id']}
                        attempts.append(run);emit({'kind':'run_end',**run})
                        print(json.dumps({'case':folder.name,**run}),flush=True)
                        if reached==len(order):
                            layout=placer.layout(run_best)
                            checked=gap.validate(folder,'constructed',layout,job,original,{(p['part_id'],p['copy_index']) for p in original['placements']})
                            assert checked['metrics']['material_area']<=b['target_material_mm2']+1e-6
                            success={'run':run,'state':run_best,'checked':checked};write(folder/'success.json',success);break
                        if expired:break
                    if success or expired:break
            assert best is not None
            write(folder/'best-partial.json',best);write(folder/'best-partial-layout.json',placer.layout(best['state']))
            result={'case':folder.name,'complete_layout_found':success is not None,'expired':expired,'runs':attempts,
                'candidate_additions':candidate_count,'rejected_distance_or_boundary':rejected,'relative_obstacle_cache':len(placer.obstacles),
                'addition_pair_checks':placer.pair_checks,'best_placed_filled_area_mm2':best['filled_area'],
                'missing_filled_area_mm2':sum(patterns[n]['area'] for n in best['remaining']),
                'diagnostic_wall_seconds':time.monotonic()-start,'timing_is_not_runtime_evidence':True}
            write(folder/'result.json',result);results.append(result);print(json.dumps({k:v for k,v in result.items() if k!='runs'}),flush=True)
        assert gap.source_digest()==production and base.digest(PRIOR/'results.json')==plan['input_results_sha256']
        write(OUT/'results.json',{'complete':True,'cases':results,'production_and_original_inputs_unchanged':True,'new_Nestbolt_searches':0,'H5_complete':False})
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
