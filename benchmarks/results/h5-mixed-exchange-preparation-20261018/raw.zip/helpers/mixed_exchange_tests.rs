    fn mixed_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/mixed-group-job.json"))).unwrap(),
            serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/mixed-group-before.json"))).unwrap(),
        )
    }

    #[test]
    fn mixed_pair_moves_different_parts_and_three_returns() {
        let (job, before) = mixed_fixture();
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &before, seed, true, false, 0);
            eprintln!("MIXED_WITNESS {}", serde_json::json!({"case":"mixed_positive","seed":seed,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats}));
            assert_eq!(moved, 1, "different original parts must be eligible for the authored two-to-three exchange: {stats:?}");
            assert_eq!(stats.paired_exchanges, 1);
            for id in ["short-incoming", "tall-incoming"] {
                assert!(after.placements.iter().any(|p|p.part_id==id && p.sheet_id=="sheet-0"));
            }
            assert_eq!(after.placements.iter().filter(|p|p.part_id=="return" && p.sheet_id=="sheet-1").count(),3);
        }
    }

    #[test]
    fn mixed_pair_disabled_or_expired_preserves_incumbent() {
        let (job, before) = mixed_fixture();
        for seed in 0..4 {
            for (enabled,expired) in [(false,false),(true,true)] {
                let (moved, _, stats) = exercise(&job, &before, seed, enabled, expired, 0);
                assert_eq!(moved,0);assert_eq!(stats.directed_exchange_attempts,0);
                assert_eq!(stats.directed_exchanges,0);
            }
        }
    }

    #[test]
    fn mixed_pair_checks_each_members_rotation_and_reflection() {
        let (mut job, layout) = mixed_fixture();
        for permit_second in [false,true] {
            for part in &mut job.parts {
                if part.id=="short-incoming" || part.id=="tall-incoming" {
                    let permits=part.id=="short-incoming" || permit_second;
                    part.rotations=Rotations::List { degrees:if permits {vec![0.0,90.0]} else {vec![0.0]} };
                    part.allow_mirror=permits;
                }
            }
            let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
            let mut members:Vec<_>=sheets[1].layout().placed_items().iter()
                .filter(|(_,p)|p.item().area()<2000.0)
                .map(|(key,p)|(key,p.item().clone(),p.d_transf())).collect();
            members.sort_by(|a,b|a.1.area().total_cmp(&b.1.area()));
            assert_eq!(members.len(),2);assert!(!std::sync::Arc::ptr_eq(&members[0].1,&members[1].1));
            let old=members[0].2;
            let quarter=DTransformation::new(old.rotation()+std::f32::consts::FRAC_PI_2,(0.0,0.0)).with_reflection(old.reflected);
            assert_eq!(incoming_group_poses(&members,quarter).is_some(),permit_second);
            let reflected=model.internal(members[0].1.idx(),&RigidTransform {translation:[32.0,2.0],rotation_radians:0.0,mirrored:true});
            assert_eq!(incoming_group_poses(&members,reflected).is_some(),permit_second);
            let translated=incoming_group_poses(&members,DTransformation::new(old.rotation(),(4.0,5.0)).with_reflection(old.reflected)).unwrap();
            let old_delta=(members[1].2.translation().0-old.translation().0,members[1].2.translation().1-old.translation().1);
            let new_delta=(translated[1].translation().0-translated[0].translation().0,translated[1].translation().1-translated[0].translation().1);
            assert!((old_delta.0-new_delta.0).abs()<0.0001 && (old_delta.1-new_delta.1).abs()<0.0001);
        }
    }
