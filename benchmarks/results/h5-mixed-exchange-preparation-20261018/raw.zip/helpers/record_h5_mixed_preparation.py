from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
c=json.loads((root/'benchmarks/results/h5-mixed-exchange-preparation-20261018/checks.json').read_bytes());assert c['all_functional_checks_pass']
note="**N4 mixed-exchange preparation, 2026-10-18:** [the isolated candidate](../benchmarks/results/h5-mixed-exchange-preparation-20261018.md)\npasses 107 optimized core tests, retaining all 101 previous tests, strict\nlint/build, ten public outcomes, four CLI comparisons and five pilot checks.\nSix new tests and twelve actual before/after validations cover mixed parts,\nper-member poses, frozen sheets, bounded choices and rollback. The original\nruntime failure and first candidate's missed seed-two group placement remain\npreserved; mixed-group corner anchors correct that failure without weakening\ntests. Up to six mixed pairs interleave existing same-item pairs within the\noriginal phase/budget. All geometry/material rules and paired methods remain.\nNo measured quality claim or integration; H2/H5 stay open at 60%.\n"
marker='**N4 mixed-exchange preparation, 2026-10-18:**'
paths=[root/n for n in ['docs/STATUS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']]
assert all(marker not in p.read_text(encoding='utf-8') for p in paths)
p=paths[0];s=p.read_text(encoding='utf-8');at=s.index('**N4 mixed-assignment witness, 2026-10-18:**');p.write_text(s[:at]+note+'\n'+s[at:],encoding='utf-8',newline='\n')
for p in paths[1:]:
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n'+note)
print('Mixed candidate preparation recorded without milestone credit')
