from pathlib import Path
import json,shutil,difflib
root=Path(__file__).resolve().parents[1];out=root/'output/h5-mixed-exchange-probe-20261018'
proof=json.loads((out/'regressions-before.json').read_bytes())
assert proof['expected_counts'] and proof['mixed_exchange_assertion_failed'] and proof['disabled_or_expired_passed'] and proof['per_member_poses_passed']
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs';text=path.read_text(encoding='utf-8');before=text;shutil.copyfile(path,out/'exchange-regressions-before.rs')
needle='fn same_original_inventory(';assert text.count(needle)==1
text=text.replace(needle,(root/'output/mixed_pair_selection.rs').read_text(encoding='utf-8')+needle)
needle='''        let mut choices = incoming_pairs(&sep.layout, &incoming_keys);''';assert text.count(needle)==1
text=text.replace(needle,'''        let same_pairs = incoming_pairs(&sep.layout, &incoming_keys);
        let mixed_pairs = mixed_incoming_pairs(&sep.layout, &incoming_keys);
        let mut choices = Vec::with_capacity(same_pairs.len() + mixed_pairs.len() + incoming_keys.len());
        for index in 0..same_pairs.len().max(mixed_pairs.len()) {
            if let Some(pair) = same_pairs.get(index) { choices.push(pair.clone()); }
            if let Some(pair) = mixed_pairs.get(index) { choices.push(pair.clone()); }
        }''')
needle='''            let incoming = &sep.layout.placed_items()[incoming_key];''';assert text.count(needle)==1
text=text.replace(needle,'''            let mixed = paired && !std::sync::Arc::ptr_eq(&members[0].1, &members[1].1);
'''+needle)
needle='''                    self.stats.paired_exchange_attempts += u64::from(paired);''';assert text.count(needle)==1
text=text.replace(needle,needle+'\n                    self.stats.mixed_exchange_attempts += u64::from(mixed);')
needle='''                    self.stats.paired_exchanges += u64::from(paired);''';assert text.count(needle)==1
text=text.replace(needle,needle+'\n                    self.stats.mixed_exchanges += u64::from(mixed);')
at=text.rindex('\n}');text=text[:at]+'\n'+(root/'output/mixed_exchange_additional_tests.rs').read_text(encoding='utf-8')+text[at:]
path.write_text(text,encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='productive-before',tofile='mixed-after')),encoding='utf-8',newline='\n')
path=out/'candidate/crates/core/src/sheets.rs';text=path.read_text(encoding='utf-8');needle='    pub neutral_exchange_rejections: u64,';assert text.count(needle)==1
text=text.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub mixed_exchange_attempts: u64,\n    #[serde(skip_serializing_if = "is_zero")]\n    pub mixed_exchanges: u64,');path.write_text(text,encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_productive_exchange.py').read_text(encoding='utf-8').replace('h5-productive-exchange-probe-20261018','h5-mixed-exchange-probe-20261018')
(root/'output/build_h5_mixed_exchange.py').write_text(builder,encoding='utf-8',newline='\n')
print('Bounded mixed-original-item choices applied only in the isolated candidate')
