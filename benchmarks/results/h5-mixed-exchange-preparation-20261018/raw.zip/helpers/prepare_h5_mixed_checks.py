from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-mixed-exchange-probe-20261018'
source=root/'scripts/h5_productive_exchange_pilot.py';text=source.read_text(encoding='utf-8')
text=text.replace('h5-productive-exchange-probe-20261018','h5-mixed-exchange-probe-20261018').replace('h5-productive-exchange-preparation-20261018','h5-mixed-exchange-preparation-20261018').replace('h5-post-exchange-fill-pilot-20261018/results.json','h5-productive-exchange-pilot-20261018/results.json')
text=text.replace('Isolated varied-pair and productive-exchange candidate, common-line search bonus on','Isolated mixed-original-item pair candidate, common-line search bonus on')
end=text.index('"""',3)+3
text='''"""Paired development pilot for bounded mixed-original-item exchanges.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The candidate interleaves the existing
six same-item pairs with up to six nearby mixed-item pairs. Existing pair
phase and total budgets, repair limits, complete obstructions, returned-area
bound, allowed poses, geometry/material checks and post-exchange fill remain.
This descriptive pilot cannot close H5 or justify a public comparative claim.
"""'''+text[end:]
needle="PROBE/'witness-checks/checks.json'])";assert text.count(needle)==1
text=text.replace(needle,"PROBE/'witness-checks/checks.json',\n                  ROOT/'benchmarks/results/h5-productive-stage-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-productive-stage-20261018/source-review.json',\n                  ROOT/'benchmarks/results/h5-mixed-exchange-witness-20261018/checks.json'])")
target=root/'scripts/h5_mixed_exchange_pilot.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)}
before,after=functions(source),functions(target);names=['blocks','summarize','case','measure'];assert all(before[n]==after[n] for n in names)
method={'reference':source.relative_to(root).as_posix(),'reference_sha256':sha256(source.read_bytes()).hexdigest(),'candidate_runner':target.relative_to(root).as_posix(),'runner_sha256':sha256(target.read_bytes()).hexdigest(),'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
for suffix in ['public','harness']:
    s=(root/f'output/check_h5_productive_exchange_{suffix}.py').read_text(encoding='utf-8').replace('h5-productive-exchange-probe-20261018','h5-mixed-exchange-probe-20261018').replace('h5_productive_exchange_pilot','h5_mixed_exchange_pilot')
    (root/f'output/check_h5_mixed_exchange_{suffix}.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
