from pathlib import Path
root=Path(__file__).resolve().parents[1]
def adapt(s):return s.replace('h5-productive-exchange-probe-20261018','h5-mixed-exchange-probe-20261018').replace('h5-productive-exchange-preparation-20261018','h5-mixed-exchange-preparation-20261018').replace('h5-productive-exchange-pilot-20261018','h5-mixed-exchange-pilot-20261018').replace('h5_productive_exchange_pilot','h5_mixed_exchange_pilot')
s=adapt((root/'output/seal_h5_productive_exchange.py').read_text(encoding='utf-8'))
s=s.replace("witness['actual_outcomes']==8 and witness['public_validations']==16","witness['actual_outcomes']==6 and witness['public_validations']==12").replace("'101 passed; 0 failed' in (probe/'core-tests.log')","'107 passed; 0 failed' in (probe/'core-tests-v2.log')")
start=s.index("for name in ['regressions-before'");end=s.index('sys.path.insert',start)
s=s[:start]+'''regression=load(probe/'regressions-before.json')
assert regression['runtime_unchanged'] and regression['mixed_exchange_assertion_failed'] and regression['disabled_or_expired_passed'] and regression['per_member_poses_passed'] and regression['expected_counts']
assert digest(probe/'regressions-before.log')==regression['log_sha256']
review=load(probe/'initial-mixed-attempt/review.json')
assert review['first_core_result']=='106 passed; 1 failed' and review['public_validations']==10 and review['all_initial_layouts_valid']
'''+s[end:]
s=s.replace('rejected-fill-observer.exe','rejected-productive-observer.exe').replace('rejected_fill_observer_sha256','rejected_productive_observer_sha256')
s=s.replace("for arm in ['baseline','candidate']:assert", "for rel,expected in plan['added_files'].items():assert digest(probe/'candidate'/rel)==expected\nfor arm in ['baseline','candidate']:assert")
start=s.index('helpers=[');end=s.index('for name in helpers:',start)
helpers=['prepare_h5_mixed_exchange.py','check_h5_mixed_exchange_before.py','apply_h5_mixed_exchange.py','build_h5_mixed_exchange.py','fix_h5_mixed_group_anchors.py','build_h5_mixed_exchange_v2.py','prepare_h5_mixed_checks.py','check_h5_mixed_exchange_public.py','check_h5_mixed_exchange_harness.py','check_h5_mixed_witnesses.py','seal_h5_mixed_exchange.py','record_h5_mixed_preparation.py','prepare_h5_mixed_reports.py','mixed_exchange_tests.rs','mixed_exchange_additional_tests.rs','mixed_pair_selection.rs']
s=s[:start]+'helpers='+repr(helpers)+'\n'+s[end:]
start=s.index("write(out/'checks.json'");end=s.index('\nfor name in [',start)
checks={'all_functional_checks_pass':True,'optimized_core_passed':107,'all_101_previous_tests_retained':True,'new_tests':6,'original_runtime_fails_mixed_exchange_regression':True,'initial_candidate_seed_two_missed_group_anchor_preserved':True,'group_corner_anchors_added_without_relaxing_test':True,'actual_exchange_witnesses':6,'actual_witness_CLI_validations':12,'strict_lint_pass':True,'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'production_files_unchanged':True,'measured_search_started':False,'H5_complete':False,'integrated':False,'completed_weight_percent':60}
s=s[:start]+"checks="+repr(checks)+"\nchecks['binaries']=build['binaries']\nwrite(out/'checks.json',checks)"+s[end:]
s=s.replace("'regressions-before.json','regressions-before-v2.json','candidate-final.patch'","'regressions-before.json','group-anchor-correction.patch','candidate-final.patch'")
start=s.index("doc='''");end=s.index('\n(out.parent',start)
doc='''# Bounded mixed-part exchanges — preparation, 2026-10-18

The [latest diagnosis](h5-productive-stage-20261018.md) found a singleton
largest source item excluded from same-item pairing, twenty single attempts
returning more item area than they remove, and eight inventory-preserving
paired attempts. The [mixed-dimension witness](h5-mixed-exchange-witness-20261018.md)
proves a scoped two-for-three assignment that needs distinct incoming parts.

This isolated candidate interleaves the existing six same-item pair choices
with at most six mixed-item pairs, using at most twelve stable area-ranked
anchors and two nearest different-item neighbours each. Pair deduplication
uses stable placement indices and original item pointer identity. Existing
pair-phase, repair and whole-job budgets, complete obstruction sets, returned
area bounds, per-member orientations, strict whole-job validation/material
checks, productive inventory guard and post-exchange fill remain.

The unchanged runtime fails the mixed-dimension exchange regression while
disabled/expired and per-member pose checks pass. The first implementation
passes 106 of 107 tests: seeds zero and one move the pair, but seed two finds
no paired proposal. Its area-ranked first member lies below the other part;
first-member corner anchors can miss the combined group corner. The complete
failure, initial source/test binary and ten independent validations remain.
Additional mixed-group minimum-corner anchors fix this without weakening the
four-seed test. Original samples remain; extra transforms are charged.

All 107 optimized core tests pass, retaining all 101 previous tests. Six new
tests cover actual mixed exchanges, disabled/expired rollback, each member's
rotation/reflection, bounded deterministic singleton choices, frozen sheets
and failed returns. Twelve public validations cover six actual before/after
outcomes. Strict lint/build, ten public observer outcomes, four CLI comparisons
and five adversarial pilot checks pass. Normal output and common fixed-work
replays are exact apart from wall time. Two omitted-zero counters record mixed
attempts/acceptances as subsets of paired attempts/acceptances.

The committed pilot preserves four jobs, both kerfs, three seeds, three
sequential rotating arms per block, eight physical CCD0 cores and 60-second
searches. Block, scoring, case and measurement functions are AST-identical
to the preceding pilot. Source/binary guards and every archive member verify.
No quality claim, integration or reserved-input access. The +1% material
limit and full 13-job H5 gate remain; H2/H5 stay open at 60%.
'''
s=s[:start]+'doc='+repr(doc)+s[end:]
start=s.index("with (root/'BENCHMARKS.md')");end=s.index('print(json.dumps',start)
entry='''

## 2026-10-18 — Qualify bounded mixed-original-item exchanges

[The isolated candidate](benchmarks/results/h5-mixed-exchange-preparation-20261018.md)
passes 107 optimized core tests, preserving all 101 previous tests. The
unchanged runtime fails a mixed-dimension exchange regression. The initial
candidate misses that exchange at seed two; group-minimum corner anchors
correct the placement coverage without weakening tests or limits. All original
failures, sources, test binary and ten independent initial validations remain.

Six new tests cover mixed assignments, per-member poses, bounded choices,
frozen sheets and rollback. Twelve further public validations cover six actual
outcomes. Strict lint/build, ten public observer outcomes, four CLI comparisons
and five adversarial pilot checks pass. Normal output and deterministic common
replay remain exact. Bounded mixed pairs share the existing phase/budget and
keep all acceptance rules. No measured gain, production integration or H5
credit is claimed; H2/H5 remain open at 60%.
'''
s=s[:start]+"with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\\n') as f:f.write("+repr(entry)+")\n"+s[end:]
p=root/'output/seal_h5_mixed_exchange.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
note='''**N4 mixed-exchange preparation, 2026-10-18:** [the isolated candidate](../benchmarks/results/h5-mixed-exchange-preparation-20261018.md)
passes 107 optimized core tests, retaining all 101 previous tests, strict
lint/build, ten public outcomes, four CLI comparisons and five pilot checks.
Six new tests and twelve actual before/after validations cover mixed parts,
per-member poses, frozen sheets, bounded choices and rollback. The original
runtime failure and first candidate's missed seed-two group placement remain
preserved; mixed-group corner anchors correct that failure without weakening
tests. Up to six mixed pairs interleave existing same-item pairs within the
original phase/budget. All geometry/material rules and paired methods remain.
No measured quality claim or integration; H2/H5 stay open at 60%.
'''
record="from pathlib import Path\nimport json\nroot=Path(__file__).resolve().parents[1]\nc=json.loads((root/'benchmarks/results/h5-mixed-exchange-preparation-20261018/checks.json').read_bytes());assert c['all_functional_checks_pass']\nnote="+repr(note)+"\nmarker='**N4 mixed-exchange preparation, 2026-10-18:**'\npaths=[root/n for n in ['docs/STATUS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']]\nassert all(marker not in p.read_text(encoding='utf-8') for p in paths)\np=paths[0];s=p.read_text(encoding='utf-8');at=s.index('**N4 mixed-assignment witness, 2026-10-18:**');p.write_text(s[:at]+note+'\\n'+s[at:],encoding='utf-8',newline='\\n')\nfor p in paths[1:]:\n    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write('\\n\\n'+note)\nprint('Mixed candidate preparation recorded without milestone credit')\n"
p=root/'output/record_h5_mixed_preparation.py';p.write_text(record,encoding='utf-8',newline='\n');compile(record,str(p),'exec')
print('Qualification sealing and plan documentation prepared')
