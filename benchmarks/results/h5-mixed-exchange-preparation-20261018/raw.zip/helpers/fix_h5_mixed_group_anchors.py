"""Preserve the failed mixed-pair attempt and add whole-group corner anchors."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-mixed-exchange-probe-20261018';saved=out/'initial-mixed-attempt';saved.mkdir(exist_ok=False)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert '106 passed; 1 failed' in (out/'core-tests.log').read_text(encoding='utf-8')
for name in ['format.log','core-tests.log','progress.json','build-failure.json','candidate.patch']:shutil.copyfile(out/name,saved/name)
for name in ['apply_h5_mixed_exchange.py','build_h5_mixed_exchange.py','mixed_pair_selection.rs','mixed_exchange_tests.rs','mixed_exchange_additional_tests.rs']:shutil.copyfile(root/'output'/name,saved/name)
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel;shutil.copyfile(path,saved/'exchange.rs');shutil.copyfile(out/'candidate/crates/core/src/sheets.rs',saved/'sheets.rs')
target=Path(json.loads((out/'preparation.json').read_bytes())['target']);binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1;shutil.copyfile(binaries[0],saved/'initial-tests.exe')
rows=[json.loads(line.split('MIXED_WITNESS ',1)[1]) for line in (out/'core-tests.log').read_text(encoding='utf-8').splitlines() if line.startswith('MIXED_WITNESS ')]
assert len(rows)==5 and any(r['case']=='mixed_positive' and r['seed']==2 and r['moved']==0 for r in rows)
cli=root/'target/release/nestbolt.exe';records=[]
for row in rows:
    folder=saved/(row['case']+'-s'+str(row['seed']));folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job'])
    metrics={}
    for phase in ['before','after']:
        write(folder/(phase+'.json'),row[phase]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(phase+'.json'))]
        r=subprocess.run(args,capture_output=True,timeout=60);(folder/(phase+'-stdout.json')).write_bytes(r.stdout);(folder/(phase+'-stderr.log')).write_bytes(r.stderr);write(folder/(phase+'-command.json'),{'command':args,'exit_code':r.returncode})
        assert r.returncode==0;report=json.loads(r.stdout);assert report['valid'];metrics[phase]=report['metrics']['material_area']
    records.append({'case':row['case'],'seed':row['seed'],'moved':row['moved'],'metrics':metrics})
text=path.read_text(encoding='utf-8');before=text
needle='''    let incoming_area: f32 = incoming.iter().map(|(_, item, _)| item.area()).sum();'''
assert text.count(needle)==1
# Add to existing samples: original first-member anchors and random samples
# remain. Mixed groups can extend above/left of their first member.
insert='''    if !std::sync::Arc::ptr_eq(&incoming[0].1, &incoming[1].1) {
        for p in receiver.placed_items().values() {
            let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
            let Some(poses) = incoming_group_poses(incoming, dt) else { continue; };
            let mut min_x = f32::INFINITY;
            let mut min_y = f32::INFINITY;
            for ((_, item, _), pose) in incoming.iter().zip(poses) {
                let mut shape = item.shape_cd().as_ref().clone();
                shape.transform_from(item.shape_cd(), &pose.compose());
                min_x = min_x.min(shape.bbox().x_min);
                min_y = min_y.min(shape.bbox().y_min);
                crate::separate::charge(clock, item, 1);
            }
            let b = p.shape().bbox();
            let (x, y) = dt.translation();
            samples.push(DTransformation::new(dt.rotation(), (x + b.x_min - min_x, y + b.y_min - min_y)).with_reflection(dt.reflected));
        }
    }
'''
text=text.replace(needle,insert+needle);path.write_text(text,encoding='utf-8',newline='\n')
(out/'group-anchor-correction.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='first-mixed-attempt',tofile='group-corner-anchors')),encoding='utf-8',newline='\n')
write(saved/'review.json',{'first_core_result':'106 passed; 1 failed','failed_seed':2,'failed_case':'mixed_pair_moves_different_parts_and_three_returns','observation':'Seeds 0 and 1 exchange successfully; seed 2 retains the valid incumbent without a paired attempt. Both members have fixed orientations, and the taller area-ranked first member starts below the other member. Anchoring only its lower-left corner to receiver parts misses the whole group corner.','correction':'Add collision-tested, per-member allowed-pose group-minimum corner anchors for mixed pairs. Retain all original samples and thresholds; charge the extra transforms. Do not weaken the four-seed test or rerun unchanged code for a lucky outcome.','public_validations':10,'all_initial_layouts_valid':True,'records':records,'CLI_sha256':sha256(cli.read_bytes()).hexdigest(),'initial_test_binary_sha256':sha256((saved/'initial-tests.exe').read_bytes()).hexdigest(),'quality_runs':0})
builder=(root/'output/build_h5_mixed_exchange.py').read_text(encoding='utf-8')
for label in ['format','core-tests','clippy','observer']:builder=builder.replace("run('"+label+"',","run('"+label+"-v2',")
builder=builder.replace("out/'progress.json'","out/'progress-v2.json'").replace("out/'build-failure.json'","out/'build-failure-v2.json'")
(root/'output/build_h5_mixed_exchange_v2.py').write_text(builder,encoding='utf-8',newline='\n')
p=root/'output/check_h5_mixed_witnesses.py';s=p.read_text(encoding='utf-8').replace("probe/'core-tests.log'","probe/'core-tests-v2.log'");p.write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,saved/'correction.py')
print('Original mixed-pair failure and ten independent validations preserved; whole-group corner anchors added')
