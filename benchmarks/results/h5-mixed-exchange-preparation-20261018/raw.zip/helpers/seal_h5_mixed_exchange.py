"""Seal the qualified isolated candidate before any development performance run."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-mixed-exchange-probe-20261018'
out=root/'benchmarks/results/h5-mixed-exchange-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');public=load(probe/'public-checks/checks.json');witness=load(probe/'witness-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed'] and witness['all_checks_passed']
assert witness['actual_outcomes']==6 and witness['public_validations']==12
assert '107 passed; 0 failed' in (probe/'core-tests-v2.log').read_text(encoding='utf-8')
for row in public['records']:
    stats=row['stats'];calls=stats.get('post_exchange_fill_calls',0);moves=stats.get('post_exchange_fill_moves',0)
    assert type(calls) is int and type(moves) is int and moves<=stats.get('direct_insertions',0)
    if row['arm']=='candidate':assert calls==stats.get('directed_exchanges',0)
    else:assert calls==moves==0
regression=load(probe/'regressions-before.json')
assert regression['runtime_unchanged'] and regression['mixed_exchange_assertion_failed'] and regression['disabled_or_expired_passed'] and regression['per_member_poses_passed'] and regression['expected_counts']
assert digest(probe/'regressions-before.log')==regression['log_sha256']
review=load(probe/'initial-mixed-attempt/review.json')
assert review['first_core_result']=='106 passed; 1 failed' and review['public_validations']==10 and review['all_initial_layouts_valid']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in plan['added_files'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
assert digest(probe/'rejected-productive-observer.exe')==plan['rejected_productive_observer_sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
exchange='crates/core/src/sheets/vstrip/exchange.rs'
before=(Path(plan['old_probe'])/'candidate'/exchange).read_text(encoding='utf-8');after=(probe/'candidate'/exchange).read_text(encoding='utf-8')
assert after[after.index('#[cfg(test)]'):].startswith(before[before.index('#[cfg(test)]'):].rsplit('\n}',1)[0])
patch=[]
for rel in plan['changed_files']:
    before=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8');after=(probe/'candidate'/rel).read_text(encoding='utf-8')
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='post-fill/'+rel,tofile='productive/'+rel))
(probe/'candidate-final.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_mixed_exchange.py', 'check_h5_mixed_exchange_before.py', 'apply_h5_mixed_exchange.py', 'build_h5_mixed_exchange.py', 'fix_h5_mixed_group_anchors.py', 'build_h5_mixed_exchange_v2.py', 'prepare_h5_mixed_checks.py', 'check_h5_mixed_exchange_public.py', 'check_h5_mixed_exchange_harness.py', 'check_h5_mixed_witnesses.py', 'seal_h5_mixed_exchange.py', 'record_h5_mixed_preparation.py', 'prepare_h5_mixed_reports.py', 'mixed_exchange_tests.rs', 'mixed_exchange_additional_tests.rs', 'mixed_pair_selection.rs']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['helpers/pilot.py']=root/'scripts/h5_mixed_exchange_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'all_members_and_crc_verified':True})
checks={'all_functional_checks_pass': True, 'optimized_core_passed': 107, 'all_101_previous_tests_retained': True, 'new_tests': 6, 'original_runtime_fails_mixed_exchange_regression': True, 'initial_candidate_seed_two_missed_group_anchor_preserved': True, 'group_corner_anchors_added_without_relaxing_test': True, 'actual_exchange_witnesses': 6, 'actual_witness_CLI_validations': 12, 'strict_lint_pass': True, 'public_observer_outcomes': 10, 'public_CLI_cross_checks': 4, 'normal_exact_except_wall': True, 'common_replay_exact_except_wall': True, 'pilot_harness_tests': 5, 'production_files_unchanged': True, 'measured_search_started': False, 'H5_complete': False, 'integrated': False, 'completed_weight_percent': 60}
checks['binaries']=build['binaries']
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','regressions-before.json','group-anchor-correction.patch','candidate-final.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
doc="# Bounded mixed-part exchanges — preparation, 2026-10-18\n\nThe [latest diagnosis](h5-productive-stage-20261018.md) found a singleton\nlargest source item excluded from same-item pairing, twenty single attempts\nreturning more item area than they remove, and eight inventory-preserving\npaired attempts. The [mixed-dimension witness](h5-mixed-exchange-witness-20261018.md)\nproves a scoped two-for-three assignment that needs distinct incoming parts.\n\nThis isolated candidate interleaves the existing six same-item pair choices\nwith at most six mixed-item pairs, using at most twelve stable area-ranked\nanchors and two nearest different-item neighbours each. Pair deduplication\nuses stable placement indices and original item pointer identity. Existing\npair-phase, repair and whole-job budgets, complete obstruction sets, returned\narea bounds, per-member orientations, strict whole-job validation/material\nchecks, productive inventory guard and post-exchange fill remain.\n\nThe unchanged runtime fails the mixed-dimension exchange regression while\ndisabled/expired and per-member pose checks pass. The first implementation\npasses 106 of 107 tests: seeds zero and one move the pair, but seed two finds\nno paired proposal. Its area-ranked first member lies below the other part;\nfirst-member corner anchors can miss the combined group corner. The complete\nfailure, initial source/test binary and ten independent validations remain.\nAdditional mixed-group minimum-corner anchors fix this without weakening the\nfour-seed test. Original samples remain; extra transforms are charged.\n\nAll 107 optimized core tests pass, retaining all 101 previous tests. Six new\ntests cover actual mixed exchanges, disabled/expired rollback, each member's\nrotation/reflection, bounded deterministic singleton choices, frozen sheets\nand failed returns. Twelve public validations cover six actual before/after\noutcomes. Strict lint/build, ten public observer outcomes, four CLI comparisons\nand five adversarial pilot checks pass. Normal output and common fixed-work\nreplays are exact apart from wall time. Two omitted-zero counters record mixed\nattempts/acceptances as subsets of paired attempts/acceptances.\n\nThe committed pilot preserves four jobs, both kerfs, three seeds, three\nsequential rotating arms per block, eight physical CCD0 cores and 60-second\nsearches. Block, scoring, case and measurement functions are AST-identical\nto the preceding pilot. Source/binary guards and every archive member verify.\nNo quality claim, integration or reserved-input access. The +1% material\nlimit and full 13-job H5 gate remain; H2/H5 stay open at 60%.\n"
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-mixed-exchange-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## 2026-10-18 — Qualify bounded mixed-original-item exchanges\n\n[The isolated candidate](benchmarks/results/h5-mixed-exchange-preparation-20261018.md)\npasses 107 optimized core tests, preserving all 101 previous tests. The\nunchanged runtime fails a mixed-dimension exchange regression. The initial\ncandidate misses that exchange at seed two; group-minimum corner anchors\ncorrect the placement coverage without weakening tests or limits. All original\nfailures, sources, test binary and ten independent initial validations remain.\n\nSix new tests cover mixed assignments, per-member poses, bounded choices,\nfrozen sheets and rollback. Twelve further public validations cover six actual\noutcomes. Strict lint/build, ten public observer outcomes, four CLI comparisons\nand five adversarial pilot checks pass. Normal output and deterministic common\nreplay remain exact. Bounded mixed pairs share the existing phase/budget and\nkeep all acceptance rules. No measured gain, production integration or H5\ncredit is claimed; H2/H5 remain open at 60%.\n')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':archive.stat().st_size}))
