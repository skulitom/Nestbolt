    #[test]
    fn mixed_pair_selection_is_bounded_unique_and_reaches_singletons() {
        let (job,layout)=mixed_fixture();let model=Model::new(&job).unwrap();
        let sheets=model.sheets_of(&layout).unwrap();let source=sheets[1].layout();
        let mut keys:Vec<_>=source.placed_items().keys().collect();
        keys.sort_by(|a,b|source.placed_items()[*b].item().area().total_cmp(&source.placed_items()[*a].item().area()));
        let pairs=mixed_incoming_pairs(source,&keys);
        assert_eq!(pairs.len(),3);assert_eq!(pairs,mixed_incoming_pairs(source,&keys));
        assert!(pairs.iter().any(|p|p.contains(&keys[0])));
        assert!(pairs.iter().any(|p|p.contains(&keys[1]) && p.contains(&keys[2])));
        for (i,pair) in pairs.iter().enumerate() {
            assert_ne!(pair[0],pair[1]);assert!(!pairs[..i].contains(pair));
            assert!(!std::sync::Arc::ptr_eq(source.placed_items()[pair[0]].item(),source.placed_items()[pair[1]].item()));
        }
        let mut many=JLayout::new(source.container().clone());let mut many_keys=Vec::new();
        for (family,key) in keys.iter().enumerate() {
            for copy in 0..20 {
                many_keys.push(many.place_item(source.placed_items()[*key].item(),DTransformation::new(0.0,(copy as f32*500.0,family as f32*10000.0))));
            }
        }
        let pairs=mixed_incoming_pairs(&many,&many_keys);assert_eq!(pairs.len(),6);
        assert_eq!(pairs,mixed_incoming_pairs(&many,&many_keys));
        for (i,pair) in pairs.iter().enumerate() { assert!(!pairs[..i].contains(pair)); }
        assert!(mixed_incoming_pairs(&many,&many_keys[..20]).is_empty());
    }

    #[test]
    fn mixed_pair_preserves_a_frozen_sheet() {
        let (mut job,mut before)=mixed_fixture();
        for p in &mut before.placements { p.sheet_id=if p.sheet_id=="sheet-0" {"sheet-1".into()} else {"sheet-2".into()}; }
        before.sheets.push(Sheet {id:"sheet-2".into(),stock_id:"stock".into()});
        job.parts.push(rectangle("fixed",20.0,20.0));
        before.placements.push(Placement {part_id:"fixed".into(),copy_index:0,sheet_id:"sheet-0".into(),transform:RigidTransform {translation:[2.0,2.0],rotation_radians:0.0,mirrored:false}});
        let (moved,after,stats)=exercise(&job,&before,0,true,false,1);
        eprintln!("MIXED_WITNESS {}",serde_json::json!({"case":"mixed_frozen","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats}));
        assert_eq!(moved,1);assert_eq!(stats.mixed_exchanges,1);
        for id in ["short-incoming","tall-incoming"] { assert!(after.placements.iter().any(|p|p.part_id==id && p.sheet_id=="sheet-1")); }
    }

    #[test]
    fn mixed_pair_failed_return_room_preserves_incumbent() {
        let (mut job,mut before)=mixed_fixture();
        *job.parts.iter_mut().find(|p|p.id=="short-incoming").unwrap()=rectangle("short-incoming",30.0,39.9);
        *job.parts.iter_mut().find(|p|p.id=="tall-incoming").unwrap()=rectangle("tall-incoming",30.0,49.9);
        for p in &mut before.placements {
            if p.part_id=="short-incoming" {p.transform.translation[1]=1.01;}
            if p.part_id=="tall-incoming" {p.transform.translation[1]=41.12;}
        }
        job.parts.push(rectangle("source-extra",30.0,7.7));
        before.placements.push(Placement {part_id:"source-extra".into(),copy_index:0,sheet_id:"sheet-1".into(),transform:RigidTransform {translation:[2.0,91.23],rotation_radians:0.0,mirrored:false}});
        let (moved,after,stats)=exercise(&job,&before,0,true,false,0);
        eprintln!("MIXED_WITNESS {}",serde_json::json!({"case":"mixed_no_return_room","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats}));
        assert_eq!(moved,0);assert_eq!(stats.mixed_exchanges,0);
        assert!(stats.directed_exchange_attempts>0);
    }
