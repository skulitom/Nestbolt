"""Run the three new authored checks against the unchanged previous runtime."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-mixed-exchange-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());work=out/'candidate';old=Path(plan['old_probe'])/'candidate'
rel='crates/core/src/sheets/vstrip/exchange.rs'
assert (work/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(old/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]
assert (work/'crates/core/src/sheets.rs').read_bytes()==(old/'crates/core/src/sheets.rs').read_bytes()
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',plan['target'],'mixed_pair_','--','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (out/'regressions-before.log').open('xb') as f:
    result=subprocess.run(command,cwd=work,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
log=(out/'regressions-before.log').read_text(encoding='utf-8')
record={'command':command,'exit_code':result.returncode,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'log_sha256':sha256((out/'regressions-before.log').read_bytes()).hexdigest(),'runtime_unchanged':True,'mixed_exchange_assertion_failed':'different original parts must be eligible for the authored two-to-three exchange:' in log,'disabled_or_expired_passed':'mixed_pair_disabled_or_expired_preserves_incumbent ... ok' in log,'per_member_poses_passed':'mixed_pair_checks_each_members_rotation_and_reflection ... ok' in log,'expected_counts':'2 passed; 1 failed' in log,'measured_searches':0}
(out/'regressions-before.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result.returncode==101 and all(record[k] for k in ['mixed_exchange_assertion_failed','disabled_or_expired_passed','per_member_poses_passed','expected_counts']),record
print(json.dumps(record))
