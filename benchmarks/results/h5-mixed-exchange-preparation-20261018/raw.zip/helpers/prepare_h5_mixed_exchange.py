"""Prepare authored regressions before adding bounded mixed-original-item pairs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-mixed-exchange-probe-20261018';old=root/'output/h5-productive-exchange-probe-20261018';out.mkdir(exist_ok=False)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
added={}
for source,name in [('job.json','mixed-group-job.json'),('before.json','mixed-group-before.json')]:
    path=out/'candidate/examples'/name;shutil.copyfile(root/'benchmarks/results/h5-mixed-exchange-witness-20261018'/source,path);added['examples/'+name]=digest(path)
rel='crates/core/src/sheets/vstrip/exchange.rs';p=out/'candidate'/rel;text=p.read_text(encoding='utf-8');at=text.rindex('\n}')
p.write_text(text[:at]+'\n'+(root/'output/mixed_exchange_tests.rs').read_text(encoding='utf-8')+text[at:],encoding='utf-8',newline='\n')
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe');shutil.copyfile(old/'candidate-observer.exe',out/'rejected-productive-observer.exe')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),'changed_files':[rel,'crates/core/src/sheets.rs'],'added_files':added,'production_digest':source_digest(),'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},'target':str(root/'output/h5-mixed-exchange-target-20261018'),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),'rejected_productive_observer_sha256':digest(out/'rejected-productive-observer.exe'),'policy':'Interleave the existing six same-original-item pair choices with at most six nearby mixed-original-item pairs, before existing singles. Mixed pairs use at most twelve stable area-ranked anchors and two nearest different-item neighbours, with stable ties and unordered pair deduplication. Keep the original pair-phase, repair and whole-job deadlines, complete obstructions and returned-area bound, per-member allowed poses, independent geometry/material validation, productive inventory guard, post-exchange fill and normal mode.','new_initial_tests':3,'all_101_existing_tests_retained':True,'runtime_changed':False,'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
driver=(root/'output/check_h5_productive_exchange_before.py').read_text(encoding='utf-8').replace('h5-productive-exchange-probe-20261018','h5-mixed-exchange-probe-20261018').replace("'productive_exchange_'","'mixed_pair_'")
start=driver.index('record={');end=driver.index("(out/'regressions-before.json')",start)
driver=driver[:start]+'''record={'command':command,'exit_code':result.returncode,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'log_sha256':sha256((out/'regressions-before.log').read_bytes()).hexdigest(),'runtime_unchanged':True,'mixed_exchange_assertion_failed':'different original parts must be eligible for the authored two-to-three exchange:' in log,'disabled_or_expired_passed':'mixed_pair_disabled_or_expired_preserves_incumbent ... ok' in log,'per_member_poses_passed':'mixed_pair_checks_each_members_rotation_and_reflection ... ok' in log,'expected_counts':'2 passed; 1 failed' in log,'measured_searches':0}
'''+driver[end:]
start=driver.index('assert result.returncode==101');end=driver.index('print(json.dumps',start)
driver=driver[:start]+"assert result.returncode==101 and all(record[k] for k in ['mixed_exchange_assertion_failed','disabled_or_expired_passed','per_member_poses_passed','expected_counts']),record\n"+driver[end:]
path=root/'output/check_h5_mixed_exchange_before.py';path.write_text(driver,encoding='utf-8',newline='\n');compile(driver,str(path),'exec')
print(json.dumps({'prepared':str(out),'runtime_unchanged':True,'initial_tests':3}))
