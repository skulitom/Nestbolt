// Try nearby members of different original items, including singleton types.
// Input order is stable and area-ranked. Bounds match the existing selector.
fn mixed_incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut pairs = Vec::new();
    let mut seen = Vec::new();
    for (i, &key) in keys.iter().enumerate().take(12) {
        let item = layout.placed_items()[key].item();
        let a = layout.placed_items()[key].shape().bbox();
        let mut neighbours: Vec<_> = keys.iter().enumerate().filter_map(|(j,&other)| {
            if i==j || std::sync::Arc::ptr_eq(item,layout.placed_items()[other].item()) { return None; }
            let b=layout.placed_items()[other].shape().bbox();
            let dx=(a.x_min+a.x_max)-(b.x_min+b.x_max);
            let dy=(a.y_min+a.y_max)-(b.y_min+b.y_max);
            Some((dx*dx+dy*dy,j))
        }).collect();
        neighbours.sort_by(|a,b|a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_,j) in neighbours.into_iter().take(2) {
            let pair=(i.min(j),i.max(j));
            if !seen.contains(&pair) {
                seen.push(pair);pairs.push(vec![keys[pair.0],keys[pair.1]]);
                if pairs.len()==6 { return pairs; }
            }
        }
    }
    pairs
}

