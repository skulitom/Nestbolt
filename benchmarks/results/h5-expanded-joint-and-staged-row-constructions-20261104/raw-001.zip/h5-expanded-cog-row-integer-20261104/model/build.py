"""A complete construction model with independent world movers and three cog rows."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-cog-row-integer-20261104';OUT=BASE/'model';CONTROL=BASE/'row-control';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed'] and load(CONTROL/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();model=cp_model.CpModel();modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');rows=load(BASE/'rows.json');unary={(t['row'],t['geometry']):t['regions'] for t in load(BASE/'mover-row-templates.json')}
def linear(coeff,lo,hi,guard=None):
    expr=sum(c*model.get_int_var_from_proto_index(i) for i,c in coeff.items() if c);ct=model.add_linear_constraint(expr,lo,hi)
    if guard is not None:ct.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return ct.index
owners=[]
for i,instance in enumerate(instances):
    opts=modes[instance['identity'][0]];positions=[model.new_int_var(min(m['integer_world_lower_left_bounds'][k][0] for m in opts),max(m['integer_world_lower_left_bounds'][k][1] for m in opts),f'world_{i}_{k}_grid').index for k in [0,1]]
    owners.append({'owner':i,'identity':instance['identity'],'positions':positions,'modes':[],'row_regions':[]})
row_vars=[]
for row in rows:
    coords=[model.new_int_var(lo,hi,f'row_shift_{row["row"]}_{k}_grid').index for k,(lo,hi) in enumerate(row['shift_bounds_grid'])]
    row_vars.append({**row,'positions':coords})
assert [v for r in row_vars for v in r['positions']]==list(range(26,32))
for owner in owners:
    for mode in modes[owner['identity'][0]]:
        sel=model.new_bool_var(f'mode_{owner["owner"]}_{mode["mode"]}').index
        record={**mode,'selector':sel,'stock_constraints':[linear({owner['positions'][k]:1},*mode['integer_world_lower_left_bounds'][k],sel) for k in [0,1]]};owner['modes'].append(record)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
unary_count=plane_count=0
for owner in owners:
    i=owner['owner'];geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    for row in row_vars:
        rv=row['positions'];record={'row':row['row'],'regions':[],'geometry_marginals':[]}
        for gid in geometries:
            for region in unary[row['row'],gid]:
                sel=model.new_bool_var(f'unary_{i}_{row["row"]}_{gid}_{region["region"]}').index;cts=[]
                for plane in region['planes']:
                    nx,ny=plane['coefficients'];cts.append(linear({owner['positions'][0]:nx,owner['positions'][1]:ny,rv[0]:-nx,rv[1]:-ny},cp_model.INT_MIN,plane['upper'],sel));plane_count+=1
                record['regions'].append({'geometry':gid,'region':region['region'],'selector':sel,'plane_constraints':cts});unary_count+=1
        record['one_region_constraint']=linear({r['selector']:1 for r in record['regions']},1,1)
        for gid in geometries:
            ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in record['regions'] if r['geometry']==gid]
            record['geometry_marginals'].append({'geometry':gid,'mode_selectors':ms,'region_selectors':rs,'constraint':linear({**{v:-1 for v in ms},**{v:1 for v in rs}},0,0)})
        owner['row_regions'].append(record)
row_pairs=[];row_pair_planes=0
for source in load(BASE/'row-pair-templates.json'):
    ai,bi=source['rows'];a,b=row_vars[ai]['positions'],row_vars[bi]['positions'];record={'rows':source['rows'],'regions':[]}
    for region in source['regions']:
        sel=model.new_bool_var(f'row_pair_{ai}_{bi}_{region["region"]}').index;cts=[]
        for plane in region['planes']:
            nx,ny=plane['coefficients'];cts.append(linear({b[0]:nx,b[1]:ny,a[0]:-nx,a[1]:-ny},cp_model.INT_MIN,plane['upper'],sel));row_pair_planes+=1
        record['regions'].append({'region':region['region'],'selector':sel,'plane_constraints':cts})
    record['one_region_constraint']=linear({r['selector']:1 for r in record['regions']},1,1);row_pairs.append(record)
rectangles=load(BASE/'mode-rectangles.json');components=[];coordinate_links=0
for item in load(BASE/'components.json'):
    owner=owners[item['owner']];family=owner['identity'][0];pi=item['piece'];coords=[]
    for k,label in enumerate(['left','bottom','right','top']):
        lo=min(m['integer_world_lower_left_bounds'][k%2][0]+rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_grid'][k] for m in owner['modes']);hi=max(m['integer_world_lower_left_bounds'][k%2][1]+rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_grid'][k] for m in owner['modes'])
        coords.append(model.new_int_var(lo,hi,f'rect_{item["component"]}_{label}_grid').index)
    record={**item,'coordinates':coords,'mode_links':[]}
    for mode in owner['modes']:
        offsets=rectangles[family][mode['mode']]['rectangles'][pi]['outward_offsets_grid'];cts=[linear({coords[k]:1,owner['positions'][k%2]:-1},v,v,mode['selector']) for k,v in enumerate(offsets)]
        coordinate_links+=len(cts);record['mode_links'].append({'mode':mode['mode'],'mode_selector':mode['selector'],'outward_offsets_grid':offsets,'constraints':cts})
    components.append(record)
separations=[]
for item in load(BASE/'component-pairs.json'):
    ai,bi=item['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];sels=[];cts=[]
    for d,co in enumerate([{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]):
        sel=model.new_bool_var(f'separate_{ai}_{bi}_{d}').index;sels.append(sel);cts.append(linear(co,cp_model.INT_MIN,-23,sel))
    separations.append({**item,'selectors':sels,'constraints':cts,'one_direction_constraint':linear({v:1 for v in sels},1,1)})
symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):symmetry.append({'family':family,'owners':[a['owner'],b['owner']],'constraint':linear({a['positions'][0]:1,b['positions'][0]:-1},cp_model.INT_MIN,0)})
control=load(CONTROL/'selected-control.json');hints={}
for row,xy in zip(row_vars,control['row_shifts_grid']):hints.update(zip(row['positions'],xy))
for pair,chosen in zip(row_pairs,control['row_pair_regions']):
    for r in pair['regions']:hints[r['selector']]=int(r['region']==chosen)
for vi,value in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(vi),value)
assert len(hints)==6+sum(len(t['regions']) for t in load(BASE/'row-pair-templates.json'))
mapping={'owners':owners,'cog_rows':row_vars,'row_pair_regions':row_pairs,'rigid_components':components,'rectangle_separations':separations,'rectangle_gap_grid':23,'symmetry_constraints':symmetry,'partial_row_hint':[[vi,v] for vi,v in sorted(hints.items())],'position_units_per_mm':100,'world_origin_mm':[0,2100]};write(OUT/'mapping.json',mapping)
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert validation=='';assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
elapsed=time.perf_counter()-started
process_names={'packet_complete_preparation_seconds':'h5-translated-cog-packet-preflight-process-20261104','individual_row_domain_complete_preparation_seconds':'h5-individual-cog-row-domains-process-20261104','fresh_row_regions_complete_preparation_seconds':'h5-expanded-cog-row-regions-process-20261104','row_integer_complete_preparation_seconds':'h5-expanded-cog-row-integer-process-20261104','row_control_complete_preparation_seconds':'h5-expanded-cog-row-control-process-20261104'}
charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],**{key:load(ROOT/'output'/name/'process.json')['complete_process_seconds'] for key,name in process_names.items()},'cp_model_build_seconds':elapsed};write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),FIRST/'checks.json',SLOTS/'checks.json',PRIOR/'rigid-rectangle-preflight/checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json',CONTROL/'plan.json',CONTROL/'selected-control.json',CONTROL/'audit/plan.json',CONTROL/'audit/checks.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json']+[p for p in BASE.glob('*.json')]+[ROOT/'output'/name/file for name in process_names.values() for file in ['opened.json','process.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'All13 orthogonal originals have independent world positions and all80 source modes. The three rigid cog rows have six independent translation coordinates over individually source-certified stock/core boxes, substantially enlarged from the previously closed restricted-row model. Every mover selects one certified region against each row, coupling its world position minus that row shift to its single source mode. Every row pair selects a certified shiftB-minus-shiftA region. All20 orthogonal component rectangles remain rigid with0.23mm pair spacing. Original world stock bounds and same-family interchangeable-copy X ordering remain. A partial hint supplies only the independently audited six row shifts and all new row-pair selectors; it is not a complete layout. No objective or capacity table is used. Charge source-valid short11, source/core preparation, expanded individual row domains, fresh row geometry, integer/control preparation and complete model build before one bounded call.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'orthogonal_originals':13,'row_cog_originals':13,'source_mode_selectors':80,'row_translation_variables':6,'mover_row_region_selectors':unary_count,'mover_row_integer_planes':plane_count,'row_pair_region_selectors':sum(len(p['regions']) for p in row_pairs),'row_pair_integer_planes':row_pair_planes,'rigid_components':len(components),'rigid_component_coordinate_links':coordinate_links,'different_owner_rectangle_pairs':len(separations),'partial_row_hint_values':len(hints),'same_family_order_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
