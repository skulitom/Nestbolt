"""Bind the frozen point packet to the independently source-checked row control."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staged-row-packet-20261104';OUT=BASE/'audit';CONTROL=ROOT/'output/h5-expanded-cog-row-integer-20261104/row-control';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';PROCESS=ROOT/'output/h5-staged-row-packet-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
original=load(CONTROL/'audit/checks.json');assert original['passed'] and original['source_valid53'] and original['source_pairs_verified']==916
for name,h in load(CONTROL/'audit/plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
source=load(BASE/'source53.json');assert source==load(CONTROL/'candidate-source53.json')
assert load(FIRST/'fixed29.json')+load(BASE/'packet-source13.json')+load(SHORT)==source
assert load(BASE/'source-checks.json')==load(CONTROL/'original-source-checks.json')
inventory=load(BASE/'inventory.json');assert inventory==load(CONTROL.parent/'inventory.json')
identities={(r['part_id'],r['copy_index']) for r in source};missing=set(map(tuple,inventory['moving13_orthogonal_identities']))
assert len(source)==len(identities)==53 and len(missing)==13 and not identities&missing and identities|missing==set(map(tuple,inventory['full66_identities']))
assert [[r['part_id'],r['copy_index']] for r in load(BASE/'packet-source13.json')]==inventory['required_cog13_identities']
domain=load(BASE/'translation-domain.json');assert domain['shift_grid_units_per_mm']==100 and domain['shift_bounds_grid']==[[0,0],[0,0]] and domain['shift_bounds_mm']==[['0','0'],['0','0']] and domain['fixed_packet_point_domain'] and domain['translation_is_fixed_zero']
modes=load(BASE/'family-modes.json');mode_count=0
assert set(modes)=={'bracket','insert'}
for family,opts in modes.items():
    previous=load(FIRST/'family-modes.json')[family];assert len(opts)==len(previous)
    for m,old in zip(opts,previous):
        assert {k:v for k,v in m.items() if k!='relative_lower_left_bounds_mm'}==old
        assert [[F(v) for v in b] for b in m['relative_lower_left_bounds_mm']]==[[F(v) for v in b] for b in old['lower_left_bounds']];mode_count+=1
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_seconds']>=load(BASE/'checks.json')['seconds_including_source_controls']
assert digest(ROOT/opened['script'])==opened['script_sha256'] and opened['maximum_calls']==1 and not opened['retry_permitted']
inputs=[Path(__file__),CONTROL/'audit/plan.json',CONTROL/'audit/checks.json']+list(BASE.glob('*.json'))+list(PROCESS.glob('*'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Bind every byte and original identity in the fixed packet to the independently reconstructed53-source control. Verify unchanged fixed29 and short11, all13 cog identities, all12 source modes, complete66 identity partition and exact zero-shift domain. Safety at the single permitted packet pose follows from the independent control polygon/pair/stock audit; no additional movement or completeness claim.'})
result={'passed':True,'seconds':time.perf_counter()-started,'fixed_packet_cogs_verified':13,'source53_identity_and_geometry_binding_verified':True,'source_control_pairs_already_independently_verified':916,'source_modes_verified':mode_count,'zero_shift_domain_verified':True,'source_valid53':True,'complete_preparation_seconds':process['complete_process_seconds'],'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
