"""Fresh source-relative regions over the movable packet's expanded domains."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import merge_exact
ROOT=Path(__file__).resolve().parents[1];FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';PRE=ROOT/'output/h5-staged-row-packet-20261104';OUT=ROOT/'output/h5-staged-row-regions-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygonal(g):
    if g.is_empty:return Polygon()
    if g.geom_type=='Polygon':return g
    children=[polygonal(p) for p in g.geoms] if hasattr(g,'geoms') else []
    return unary_union([p for p in children if not p.is_empty]) if children else Polygon()
assert load(PRE/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'geometries').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
modes=load(PRE/'family-modes.json');library=load(FIRST/'geometry-library.json');sites=load(PRE/'packet-source13.json');inventory=load(PRE/'inventory.json');cgmode=load(FIRST/'family-modes.json')['cog'][0]
instances=[{'identity':identity,'mode_count':len(modes[identity[0]])} for identity in inventory['moving13_orthogonal_identities']];assert len(instances)==13 and sum(r['mode_count'] for r in instances)==80
anchors=[]
for site in sites:
    t=site['transform'];assert t['rotation_radians']==cgmode['rotation_radians'] and t['mirrored']==cgmode['mirrored'];anchors.append([t['translation'][k]-cgmode['translation_from_lower_left'][k] for k in [0,1]])
square=np.asarray([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]]);records=[];obstacle_records=[]
for gid in range(10):
    aliases=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid];assert aliases
    bounds=[[max(F(m['relative_lower_left_bounds_mm'][k][0]) for m in aliases),min(F(m['relative_lower_left_bounds_mm'][k][1]) for m in aliases)] for k in [0,1]]
    domain=[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]];relative=[]
    for c in library[10]['pieces']:
        for a in library[gid]['pieces']:
            differences=(np.asarray(c)[:,None,:]-np.asarray(a)[None,:,:]).reshape(-1,2)
            relative.append(MultiPoint((differences[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    obstacle=unary_union(relative);obstacles=[translate(obstacle,xoff=x,yoff=y) for x,y in anchors]
    free=polygonal(box(*map(float,domain)).difference(unary_union(obstacles)))
    triangles=[p for p in shapely.constrained_delaunay_triangles(free).geoms if p.area>0];assert all(p.geom_type=='Polygon' and len(p.exterior.coords)==4 for p in triangles)
    convex,merges=merge_exact(triangles) if triangles else ([],0)
    polygons=[Polygon(p) for p in convex];error=unary_union(polygons).symmetric_difference(free).area if polygons else free.area;assert error<1e-6
    regions=[{'region':i,'vertices':v} for i,v in enumerate(convex)]
    record={'geometry':gid,'relative_domain_mm':[str(v) for v in domain],'free_area_mm2':free.area,'initial_triangles':len(triangles),'exact_merges':merges,'regions':regions,'floating_partition_coverage_error_mm2':error}
    write(OUT/'geometries'/f'{gid:02d}.json',record);records.append(record);obstacle_records.append({'geometry':gid,'source_packet_obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Fresh geometry preparation cap reached; no model or search may open.'
for name,data in [('family-modes.json',modes),('instances.json',instances),('inventory.json',inventory),('obstacles.json',obstacle_records)]:write(OUT/name,data)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',FIRST/'family-modes.json',FIRST/'geometry-library.json']+[PRE/n for n in ['plan.json','packet-source13.json','inventory.json','family-modes.json','translation-domain.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Rebuild relative no-fit obstacles from source convex pieces and all13 original cog poses, inflated by a0.226mm halfwidth square. Use world-coordinate domains against the fixed stage-one cog packet; its permitted translation is exactly zero. No previous fixed-cog region or capacity table is consumed. Intersect alias domains conservatively. Subtract all13 source obstacles, triangulate and exactly merge adjacent convex pieces. Independently certify every rounded output region against all original source modes and cog outlines before any model uses it. The stage-one packet is fixed; relative and world coordinates coincide and original stock constraints remain mandatory.','geometry_preparation_target_seconds':30,'future_algorithm_seconds':60,'future_shared_seconds':90,'square_halfwidth_mm':.226,'required_certified_source_gap_mm':.225,'old_fixed_cog_regions_reused':False,'count_capacity_tables_used':False,'global_coverage_claimed':False,'new_model_created':False,'solver_calls':0})
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'source_mode_options':80,'filled_geometries':10,'original_cogs':13,'convex_regions':sum(len(r['regions']) for r in records),'source_modes':sum(len(v) for v in modes.values()),'independent_source_region_audit_required':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
