"""Build and independently audit the genuinely expanded-domain construction."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rewrite(s):
    return s.replace('h5-independent-cog-row-integer-20261104','h5-expanded-cog-row-integer-20261104').replace('build_h5_independent_cog_row_model_20261104.py','build_h5_expanded_cog_row_model_20261104.py').replace('check_h5_independent_cog_row_candidate_20261104.py','check_h5_expanded_cog_row_candidate_20261104.py')
def charges(s):
    return s.replace("'failed_row_stagger_preparation_seconds':'h5-independent-cog-rows-process-20261104'", "'individual_row_domain_complete_preparation_seconds':'h5-individual-cog-row-domains-process-20261104'").replace('h5-independent-cog-rows-v2-process-20261104','h5-expanded-cog-row-regions-process-20261104').replace('h5-independent-cog-row-integer-process-20261104','h5-expanded-cog-row-integer-process-20261104').replace('h5-cog-row-control-process-20261104','h5-expanded-cog-row-control-process-20261104')
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=charges(rewrite((ROOT/'output/build_h5_independent_cog_row_model_20261104.py').read_text(encoding='utf-8')))
s=s.replace('len(hints)==54',"len(hints)==6+sum(len(t['regions']) for t in load(BASE/'row-pair-templates.json'))")
s=s.replace('A54-value partial hint supplies only the independently audited six row shifts and48 row-pair selectors','A partial hint supplies only the independently audited six row shifts and all new row-pair selectors')
s=s.replace('failed row control, corrected row geometry','expanded individual row domains, fresh row geometry')
s=s.replace('The three rigid cog rows have six independent translation coordinates.','The three rigid cog rows have six independent translation coordinates over individually source-certified stock/core boxes, substantially enlarged from the previously closed restricted-row model.')
save('build_h5_expanded_cog_row_model_20261104.py',s)
s=rewrite((ROOT/'output/run_h5_independent_cog_row_model_build_20261104.py').read_text(encoding='utf-8'))
save('run_h5_expanded_cog_row_model_build_20261104.py',s)
s=charges(rewrite((ROOT/'output/audit_h5_independent_cog_row_model_20261104.py').read_text(encoding='utf-8')))
s=s.replace('len(hints)==54',"len(hints)==6+sum(len(t['regions']) for t in load(BASE/'row-pair-templates.json'))")
s=s.replace('including the preserved failed row control and full model process','including the complete expanded row-domain preflight, fresh geometry/control processes and full model process')
s=s.replace("'failed_row_stagger_cost_preserved':True", "'expanded_domain_complete_cost_charged':True,'old_restricted_row_control_or_solver_consumed':False")
save('audit_h5_expanded_cog_row_model_20261104.py',s)
s=rewrite((ROOT/'output/check_h5_independent_cog_row_candidate_20261104.py').read_text(encoding='utf-8'))
save('check_h5_expanded_cog_row_candidate_20261104.py',s)
s=rewrite((ROOT/'output/run_h5_independent_cog_row_model_20261104.py').read_text(encoding='utf-8'))
save('run_h5_expanded_cog_row_model_20261104.py',s)
s=rewrite((ROOT/'output/audit_h5_independent_cog_row_response_20261104.py').read_text(encoding='utf-8'))
s=s.replace("ma['variables_verified']==9924", "ma['variables_verified']==load(MODEL/'checks.json')['variables']").replace("ma['constraints_verified']==35142", "ma['constraints_verified']==load(MODEL/'checks.json')['constraints']")
save('audit_h5_expanded_cog_row_response_20261104.py',s)
