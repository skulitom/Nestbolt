"""Seal the expanded joint and deterministic staged constructions."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-expanded-joint-and-staged-row-constructions-20261104';OUT=ROOT/'benchmarks/results'/NAME
REG=ROOT/'output/h5-expanded-cog-row-regions-20261104';BASE=ROOT/'output/h5-expanded-cog-row-integer-20261104';STAGED=ROOT/'output/h5-staged-row-integer-20261104';SREG=ROOT/'output/h5-staged-row-regions-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104','h5-independent-cog-rows-and-expanded-domains-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for reg in [REG,SREG]:assert load(reg/'source-region-audit/checks.json')['passed']
for base in [BASE,STAGED]:
    for folder in ['geometry-audit','model-audit','response-audit']:assert load(base/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json');staged=load(STAGED/'response-audit/checks.json')
assert response['solver_status']=='UNKNOWN' and 0<response['solve_slice_overrun_seconds']<.18
assert staged['solver_status']=='INFEASIBLE' and staged['solve_slice_overrun_seconds']==0
for r in [response,staged]:assert r['closed_solver_calls']==1 and r['assignments']==0 and r['algorithm_overrun_seconds']==r['shared_overrun_seconds']==0
# Reuse the already archived generic member/recursive-binding walker verbatim.
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')])
folders=[ROOT/'output'/n for n in ['h5-expanded-cog-row-regions-20261104','h5-expanded-cog-row-regions-process-20261104','h5-expanded-cog-row-integer-20261104','h5-expanded-cog-row-integer-process-20261104','h5-expanded-cog-row-control-process-20261104','h5-staged-row-packet-20261104','h5-staged-row-packet-process-20261104','h5-staged-row-regions-20261104','h5-staged-row-regions-process-20261104','h5-staged-row-integer-20261104','h5-staged-row-integer-process-20261104']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*expanded_cog_row*20261104.py','*h5*staged_row*20261104.py','*h5*expanded_row_checkpoint*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,'h5-expanded-row-checkpoint-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(REG/'source-region-audit/checks.json','expanded-source-region-audit.json'),(BASE/'geometry-audit/checks.json','expanded-integer-audit.json'),(BASE/'row-control/audit/checks.json','expanded-positive-control-audit.json'),(BASE/'model-audit/checks.json','expanded-model-audit.json'),(BASE/'model/final-preparation-charges.json','expanded-preparation-charges.json'),(BASE/'model/build-process.json','expanded-model-process.json'),(BASE/'response-audit/checks.json','expanded-response-audit.json'),(SREG/'source-region-audit/checks.json','staged-source-region-audit.json'),(STAGED/'geometry-audit/checks.json','staged-integer-audit.json'),(STAGED/'model-audit/checks.json','staged-model-audit.json'),(STAGED/'model/final-preparation-charges.json','staged-preparation-charges.json'),(STAGED/'model/build-process.json','staged-model-process.json'),(STAGED/'response-audit/checks.json','staged-response-audit.json'),(ROOT/'output/h5-staged-row-packet-20261104/audit/checks.json','staged-packet-audit.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'both_closed_calls_must_not_be_repeated':True,'expanded_joint_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],'staged_model_sha256':load(STAGED/'model-audit/checks.json')['model_sha256'],'next_method':'Before any further search, assess exact integer-domain reductions of the expanded joint representation: certify regions with no admissible integer point and remove halfplanes already implied by each source-mode world bound and the corresponding row shift domain. Preserve every proof and full preparation time; independently verify reductions, including the existing partial control. Only a materially smaller, fully audited representation warrants consideration of a new bounded construction call. Do not rerun either current model, select another staged control from failed placements, or transfer grid infeasibility to continuous geometry.','reduction_prepared':False,'continuous_source_domain_excluded':False,'remaining_allocation_candidates':440,'fixed_cog_frontier':{'site_choices':2,'count_distributions':3},'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'new_closed_solver_calls':2,'expanded_joint_status':'UNKNOWN','staged_status':'INFEASIBLE','assignments':0,'expanded_solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'staged_solve_slice_overrun_seconds':0,'overall_algorithm_shared_overruns_seconds':0,'continuous_source_domain_excluded':False,'remaining_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-expanded-row-checkpoint-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 expanded and staged row constructions:** [independent source/model/response audits]({link}) verify a 16,314-variable expanded joint model and a separate 1,756-variable staged companion model. Their sole calls close UNKNOWN and grid-INFEASIBLE, respectively, with no assignment. The joint 0.176077 s solve-slice overrun is retained; both complete algorithm/shared totals remain within 60/90 s. The staged ledger charges every preparation used by both stages. Neither status excludes continuous geometry or any of the 440 whole-job allocations. A certified integer-domain reduction is the next method to assess; both calls stay closed. Full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
old='Latest H5 evidence: [independent cog rows and expanded domains](../benchmarks/results/h5-independent-cog-rows-and-expanded-domains-20261104.md).';assert s.count(old)==1
s=s.replace(old,f'Latest H5 evidence: [expanded joint and staged row constructions](../benchmarks/results/{NAME}.md).',1)
old='The independent-row construction is audited and its sole call closes UNKNOWN\nwithout a placement. Fresh individual row bounds allow substantially more motion\ninside the stock; their enlarged interaction regions and model remain to build.';assert s.count(old)==1
s=s.replace(old,'The expanded joint and deterministic staged constructions are audited; their\nsole calls close UNKNOWN and grid-INFEASIBLE without a placement. A certified\ninteger-domain reduction is the next method to assess before further search.',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
