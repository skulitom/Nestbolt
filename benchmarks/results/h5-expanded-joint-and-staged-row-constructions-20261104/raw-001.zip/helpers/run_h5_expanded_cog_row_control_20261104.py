from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-expanded-cog-row-control-process-20261104';SCRIPT=ROOT/'output/prepare_h5_expanded_cog_row_control_20261104.py'
OUT.mkdir();started=time.perf_counter()
record={'utc':datetime.now(timezone.utc).isoformat(),'script':SCRIPT.relative_to(ROOT).as_posix(),'script_sha256':sha256(SCRIPT.read_bytes()).hexdigest(),'maximum_process_seconds':90,'discovery_stop_seconds':35,'preparation_target_seconds':60,'maximum_calls':1,'retry_permitted':False}
with (OUT/'opened.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
try:
    r=subprocess.run(['python',str(ROOT/'output/ccd1.py'),str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(SCRIPT)],cwd=ROOT,capture_output=True,timeout=90);result={'exit_code':r.returncode,'timeout':False};stdout,stderr=r.stdout,r.stderr
except subprocess.TimeoutExpired as e:
    result={'timeout':True};stdout,stderr=e.stdout or b'',e.stderr or b''
elapsed=time.perf_counter()-started
(OUT/'stdout.txt').write_bytes(stdout);(OUT/'stderr.txt').write_bytes(stderr)
result.update({'complete_process_seconds':elapsed,'complete_process_cap_overrun_seconds':max(0,elapsed-90),'preparation_target_overrun_seconds':max(0,elapsed-60),'closed':True})
with (OUT/'process.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(result);print(stdout.decode(errors='replace'));print(stderr.decode(errors='replace'))
