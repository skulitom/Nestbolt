"""Prepare fresh interaction regions and an independent expanded-domain auditor."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def change(s,a,b):
    assert s.count(a)==1,(a[:120],s.count(a));return s.replace(a,b,1)
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/prepare_h5_independent_cog_rows_v2_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-independent-cog-row-regions-v2-20261104','h5-expanded-cog-row-regions-20261104')
s=change(s,"OUT=ROOT/'output/h5-expanded-cog-row-regions-20261104'", "OUT=ROOT/'output/h5-expanded-cog-row-regions-20261104';EXP=ROOT/'output/h5-individual-cog-row-domains-20261104'")
s=change(s,"assert load(PACKET/'audit/checks.json')['passed'];", "assert load(PACKET/'audit/checks.json')['passed'] and load(EXP/'audit/checks.json')['passed'];")
start=s.index('inputs=[');end=s.index('sites=load(',start)
s=s[:start]+'''inputs=[Path(__file__),ROOT/'output/prepare_h5_expanded_cog_row_region_helpers_20261104.py',ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT]+[FIRST/n for n in ['plan.json','fixed29.json','family-modes.json','geometry-library.json','audit/plan.json','audit/checks.json']]+[PACKET/n for n in ['plan.json','packet-source13.json','inventory.json','translation-domain.json','audit/plan.json','audit/checks.json']]+[EXP/n for n in ['plan.json','checks.json','rows.json','row-modes.json','pair-domains.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New construction using independently source-certified individual stock/core translation boxes for each rigid5/4/4-cog row. Rebuild every mover-to-row and row-pair Minkowski obstacle from original convex source pieces over the enlarged row-specific relative domains. Triangulate each bounded free region and exactly merge adjacent convex polygons. Every rounded region requires independent original-source support certification. Preserve four common-shift53 controls without claiming they satisfy the inflated model. The closed restricted-row UNKNOWN model is not reused or rerun. No fixed-cog capacity exclusions transfer.','square_halfwidth_mm':.226,'required_certified_source_gap_mm':.225,'source_geometry_preparation_target_seconds':30,'complete_process_cap_seconds':90,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'source_controls_are_not_model_controls':True,'count_capacity_tables_used':False,'new_model_created':False,'solver_calls':0})
''' +s[end:]
s=change(s,"modes=load(PACKET/'family-modes.json');", "modes={family:[{**m,'relative_lower_left_bounds_by_row_mm':[next(r['relative_lower_left_bounds_mm'] for r in load(EXP/'row-modes.json') if r['row']==row and r['family']==family and r['mode']==m['mode']) for row in range(3)]} for m in load(FIRST/'family-modes.json')[family]] for family in ['bracket','insert']};")
start=s.index('levels=sorted(');end=s.index('anchors=[]',start)
s=s[:start]+"groups=load(EXP/'rows.json');assert [len(g['source_indices']) for g in groups]==[5,4,4]\n"+s[end:]
start=s.index('mover_records=[]');end=s.index('pair_nf=inflated(',start)
s=s[:start]+'''mover_records=[];obstacle_records=[]
for gid in range(10):
    aliases=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid];assert aliases
    nf=inflated(library[10]['pieces'],library[gid]['pieces'])
    for group in groups:
        ri=group['row'];bounds=[[max(F(m['relative_lower_left_bounds_by_row_mm'][ri][k][0]) for m in aliases),min(F(m['relative_lower_left_bounds_by_row_mm'][ri][k][1]) for m in aliases)] for k in [0,1]];domain=[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
        obstacles=[translate(nf,xoff=anchors[i][0],yoff=anchors[i][1]) for i in group['source_indices']]
        record={'row':ri,'geometry':gid,**partition(domain,obstacles)}
        write(OUT/'mover-rows'/f'{ri}-{gid:02d}.json',record);mover_records.append(record)
        obstacle_records.append({'row':ri,'geometry':gid,'obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Fresh expanded-row geometry preparation closed at target.'
''' +s[end:]
s=change(s,"relative_bounds=[[F(lo-hi,grid),F(hi-lo,grid)] for lo,hi in shift];domain=[relative_bounds[0][0],relative_bounds[1][0],relative_bounds[0][1],relative_bounds[1][1]]", "pair_domains=load(EXP/'pair-domains.json')")
s=change(s,"for ga,gb in combinations(groups,2):\n    obstacles=", "for ga,gb in combinations(groups,2):\n    relative_bounds=[list(map(F,b)) for b in next(p['bounds_mm'] for p in pair_domains if p['rows']==[ga['row'],gb['row']])];domain=[relative_bounds[0][0],relative_bounds[1][0],relative_bounds[0][1],relative_bounds[1][1]]\n    obstacles=")
s=change(s,"('source-cogs.json',sites),", "('pair-domains.json',pair_domains),('source-cogs.json',sites),")
save('prepare_h5_expanded_cog_row_regions_20261104.py',s)
s=(ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py').read_text(encoding='utf-8').replace('h5-cog-row-overlap-regions-process-20261104','h5-expanded-cog-row-regions-process-20261104').replace('prepare_h5_cog_row_overlap_regions_20261104.py','prepare_h5_expanded_cog_row_regions_20261104.py')
save('run_h5_expanded_cog_row_regions_20261104.py',s)
s=(ROOT/'output/audit_h5_independent_cog_row_regions_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-regions-v2-20261104','h5-expanded-cog-row-regions-20261104')
s=change(s,"load=lambda p:", "EXP=ROOT/'output/h5-individual-cog-row-domains-20261104'\nload=lambda p:")
s=change(s,"assert sites==load(PRE/'packet-source13.json') and modes==load(PRE/'family-modes.json') and inventory==load(PRE/'inventory.json')", "assert sites==load(PRE/'packet-source13.json') and inventory==load(PRE/'inventory.json') and groups==load(EXP/'rows.json') and load(EXP/'audit/checks.json')['passed']\nfor family,opts in modes.items():\n    assert len(opts)==len(load(FIRST/'family-modes.json')[family])\n    for m,original in zip(opts,load(FIRST/'family-modes.json')[family]):\n        assert {k:v for k,v in m.items() if k!='relative_lower_left_bounds_by_row_mm'}==original\n        assert len(m['relative_lower_left_bounds_by_row_mm'])==3\n        for ri,g in enumerate(groups):\n            for axis,bounds in enumerate(m['relative_lower_left_bounds_by_row_mm'][ri]):\n                assert list(map(F,bounds))==[F(original['lower_left_bounds'][axis][0])-F(g['shift_bounds_grid'][axis][1],100),F(original['lower_left_bounds'][axis][1])-F(g['shift_bounds_grid'][axis][0],100)]")
start=s.index('levels=sorted(');end=s.index('controls=load(',start)
s=s[:start]+"assert [len(g['source_indices']) for g in groups]==[5,4,4]\n"+s[end:]
s=s.replace("['relative_lower_left_bounds_mm'][k]", "['relative_lower_left_bounds_by_row_mm'][row][k]")
s=change(s,"bounds=[[F(lo-hi,100),F(hi-lo,100)] for lo,hi in shift];", "bounds=[[F(gb['shift_bounds_grid'][k][0]-ga['shift_bounds_grid'][k][1],100),F(gb['shift_bounds_grid'][k][1]-ga['shift_bounds_grid'][k][0],100)] for k in [0,1]];")
s=change(s,"PRE/'translation-domain.json']", "PRE/'translation-domain.json',EXP/'plan.json',EXP/'audit/plan.json',EXP/'audit/checks.json',EXP/'rows.json',EXP/'row-modes.json',EXP/'pair-domains.json']")
s=s.replace('Source stock/fixed-core safety follows from each row using the independently verified packet shift rectangle;', 'Source stock/fixed-core safety follows from each independently verified expanded individual row box;')
s=s.replace("'all_three_row_pairs_checked':True", "'all_three_row_pairs_checked':True,'expanded_row_specific_mode_domains_verified':36,'individual_row_shift_boxes_verified':3")
save('audit_h5_expanded_cog_row_regions_20261104.py',s)
