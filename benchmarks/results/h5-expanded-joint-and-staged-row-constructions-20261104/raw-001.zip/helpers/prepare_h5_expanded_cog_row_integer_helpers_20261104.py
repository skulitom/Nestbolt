"""Create integer converters with row-specific bounds and wider error envelopes."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def change(s,a,b):
    assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
def rewrite(s):return s.replace('h5-independent-cog-row-integer-20261104','h5-expanded-cog-row-integer-20261104').replace('h5-independent-cog-row-regions-v2-20261104','h5-expanded-cog-row-regions-20261104')
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=rewrite((ROOT/'output/prepare_h5_independent_cog_row_integer_20261104.py').read_text(encoding='utf-8'))
s=s.replace('envelope=[F(1600),F(1000)];pair_envelope=[F(100),F(120)]','envelope=[F(2000),F(1500)];pair_envelope=[F(600),F(1100)]')
s=change(s,"for source,dest in [('lower_left_bounds','integer_world_lower_left_bounds'),('relative_lower_left_bounds_mm','integer_relative_lower_left_bounds')]:", "for source,dest in [('lower_left_bounds','integer_world_lower_left_bounds')]:")
s=change(s,"        converted[family].append({**m,**extra})", "        extra['integer_relative_lower_left_bounds_by_row']=[[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(bounds)] for bounds in m['relative_lower_left_bounds_by_row_mm']]\n        converted[family].append({**m,**extra})")
s=s.replace("['rows.json','source-cogs.json','instances.json','inventory.json','controls.json']", "['rows.json','source-cogs.json','instances.json','inventory.json','controls.json','pair-domains.json']")
s=change(s,"[REG/n for n in ['plan.json'", "[REG/n for n in ['pair-domains.json','plan.json'")
s=s.replace('1600x1000mm','2000x1500mm').replace('100x120mm','600x1100mm').replace("'mover_relative_error_envelope_mm':[1600,1000]", "'mover_relative_error_envelope_mm':[2000,1500]").replace("'row_pair_error_envelope_mm':[100,120]", "'row_pair_error_envelope_mm':[600,1100]")
save('prepare_h5_expanded_cog_row_integer_20261104.py',s)
s=(ROOT/'output/run_h5_independent_cog_row_integer_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-integer-process-20261104','h5-expanded-cog-row-integer-process-20261104').replace('prepare_h5_independent_cog_row_integer_20261104.py','prepare_h5_expanded_cog_row_integer_20261104.py')
save('run_h5_expanded_cog_row_integer_20261104.py',s)
s=rewrite((ROOT/'output/audit_h5_independent_cog_row_integer_20261104.py').read_text(encoding='utf-8'))
s=s.replace('limits==[1600,1000] and pair_limits==[100,120]','limits==[2000,1500] and pair_limits==[600,1100]')
s=change(s,"shift=rows[0]['shift_bounds_grid'];assert all(r['shift_bounds_grid']==shift for r in rows)\nfor axis,(lo,hi) in enumerate(shift):assert hi-lo<=pair_limits[axis]*grid", "for a in range(3):\n    for b in range(a+1,3):\n        for axis in [0,1]:\n            lo=rows[b]['shift_bounds_grid'][axis][0]-rows[a]['shift_bounds_grid'][axis][1];hi=rows[b]['shift_bounds_grid'][axis][1]-rows[a]['shift_bounds_grid'][axis][0]\n            assert -pair_limits[axis]*grid<=lo<=hi<=pair_limits[axis]*grid")
start=s.index('        assert {k:v for k,v in m.items()');end=s.index('        mode_count+=1',start)
s=s[:start]+'''        assert {k:v for k,v in m.items() if k not in ['integer_world_lower_left_bounds','integer_relative_lower_left_bounds_by_row']}==source
        for axis in [0,1]:
            a,b=map(F,source['lower_left_bounds'][axis]);lo,hi=m['integer_world_lower_left_bounds'][axis]
            assert [lo,hi]==[ceil((a-origin[axis])*grid),floor((b-origin[axis])*grid)]
            assert F(lo,grid)+origin[axis]>=a and F(hi,grid)+origin[axis]<=b
        assert len(m['integer_relative_lower_left_bounds_by_row'])==3
        for ri,row in enumerate(rows):
            for axis in [0,1]:
                a,b=map(F,source['relative_lower_left_bounds_by_row_mm'][ri][axis]);lo,hi=m['integer_relative_lower_left_bounds_by_row'][ri][axis]
                assert [lo,hi]==[ceil((a-origin[axis])*grid),floor((b-origin[axis])*grid)]
                assert F(lo,grid)+origin[axis]>=a and F(hi,grid)+origin[axis]<=b
                wl,wh=m['integer_world_lower_left_bounds'][axis];sl,sh=row['shift_bounds_grid'][axis]
                assert [lo,hi]==[wl-sh,wh-sl] and -limits[axis]*grid<=lo<=hi<=limits[axis]*grid
''' +s[end:]
s=s.replace("['rows.json','source-cogs.json','instances.json','inventory.json','controls.json']", "['rows.json','source-cogs.json','instances.json','inventory.json','controls.json','pair-domains.json']")
s=s.replace("'source_modes_verified':mode_count", "'source_modes_verified':mode_count,'row_specific_relative_domains_verified':3*mode_count")
save('audit_h5_expanded_cog_row_integer_20261104.py',s)
