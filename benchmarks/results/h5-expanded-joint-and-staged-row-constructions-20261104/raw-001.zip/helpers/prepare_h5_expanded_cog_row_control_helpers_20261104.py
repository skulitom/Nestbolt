from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_cog_row_region_control_20261104.py').read_text(encoding='utf-8').replace('h5-cog-row-control-process-20261104','h5-expanded-cog-row-control-process-20261104').replace('prepare_h5_cog_row_region_control_20261104.py','prepare_h5_expanded_cog_row_control_20261104.py')
save('run_h5_expanded_cog_row_control_20261104.py',s)
s=(ROOT/'output/audit_h5_cog_row_region_control_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-integer-20261104','h5-expanded-cog-row-integer-20261104').replace('h5-cog-row-control-process-20261104','h5-expanded-cog-row-control-process-20261104')
s=s.replace(";bounds=rows[0]['shift_bounds_grid']",'')
start=s.index("    expected[','.join(map(str,pair))]=opts");end=s.index('source_cogs=deepcopy(',start)
s=s[:start]+'''    expected[','.join(map(str,pair))]=sorted(opts,key=lambda r:(sum(v*v for v in r['difference_grid']),r['region'],r['difference_grid']))
assert expected==load(CONTROL/'centroid-grid-options.json');combos=0;first_feasible=None
for first,second in product(expected['0,1'],expected['1,2']):
    combos+=1;u,v=first['difference_grid'],second['difference_grid'];w=[u[k]+v[k] for k in [0,1]]
    third=[r['region'] for r in templates[(0,2)] if fits(w,r)]
    if not third:continue
    offsets=[[0,0],u,w];base=[];base_bounds=[];valid=True
    for k in [0,1]:
        least=max(row['shift_bounds_grid'][k][0]-p[k] for row,p in zip(rows,offsets));greatest=min(row['shift_bounds_grid'][k][1]-p[k] for row,p in zip(rows,offsets))
        if least>greatest:valid=False;break
        base.append(least);base_bounds.append([least,greatest])
    if valid:
        first_feasible={'row_shifts_grid':[[base[k]+p[k] for k in [0,1]] for p in offsets],'row_pair_regions':[first['region'],min(third),second['region']],'row_pair_differences_grid':[u,w,v],'base_bounds_grid':base_bounds,'inspected_prefix':combos};break
chosen=load(CONTROL/'selected-control.json');assert first_feasible==chosen
shifts=chosen['row_shifts_grid'];assert all(lo<=v<=hi for row,xy in zip(rows,shifts) for v,(lo,hi) in zip(xy,row['shift_bounds_grid']))
for pair,region_id,delta in zip([(0,1),(0,2),(1,2)],chosen['row_pair_regions'],chosen['row_pair_differences_grid']):
    assert delta==[shifts[pair[1]][k]-shifts[pair[0]][k] for k in [0,1]];assert fits(delta,next(r for r in templates[pair] if r['region']==region_id))
''' +s[end:]
s=s.replace('all adjacent-row difference combinations','the declared adjacent-row combination prefix').replace('verify the complete retained list and deterministic selected minimum','verify the deterministic first feasible selection and all preceding failures')
s=s.replace("'feasible_controls_verified':len(feasible)","'first_feasible_control_verified':True")
save('audit_h5_expanded_cog_row_control_20261104.py',s)
