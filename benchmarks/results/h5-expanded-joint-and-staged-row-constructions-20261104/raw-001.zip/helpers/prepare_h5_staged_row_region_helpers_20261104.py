from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py').read_text(encoding='utf-8').replace('h5-cog-row-overlap-regions-process-20261104','h5-staged-row-packet-process-20261104').replace('prepare_h5_cog_row_overlap_regions_20261104.py','prepare_h5_staged_row_packet_20261104.py')
save('run_h5_staged_row_packet_20261104.py',s)
for old,new in [('prepare_h5_translated_packet_regions_20261104.py','prepare_h5_staged_row_regions_20261104.py'),('audit_h5_translated_packet_regions_20261104.py','audit_h5_staged_row_regions_20261104.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-translated-packet-regions-20261104','h5-staged-row-regions-20261104').replace('h5-translated-cog-packet-preflight-20261104','h5-staged-row-packet-20261104')
    s=s.replace('Use the newly expanded relative-coordinate domains for the translating packet, not the old fixed-cog domains or capacity tables.', 'Use world-coordinate domains against the fixed stage-one cog packet; its permitted translation is exactly zero. No previous fixed-cog region or capacity table is consumed.')
    s=s.replace('Shared translation later cancels in mover/cog comparisons; world-coordinate stock constraints remain mandatory.', 'The stage-one packet is fixed; relative and world coordinates coincide and original stock constraints remain mandatory.')
    s=s.replace('Shared packet translation cancels in these relative comparisons.', 'The permitted packet shift is exactly zero, so every comparison is in world coordinates.')
    s=s.replace("'shared_translation_cancels_in_source_supports':True", "'stage_one_packet_fixed_zero':True")
    save(new,s)
s=(ROOT/'output/run_h5_translated_packet_regions_preparation_20261104.py').read_text(encoding='utf-8') if (ROOT/'output/run_h5_translated_packet_regions_preparation_20261104.py').exists() else (ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-translated-packet-regions-process-20261104','h5-staged-row-regions-process-20261104').replace('prepare_h5_translated_packet_regions_20261104.py','prepare_h5_staged_row_regions_20261104.py').replace('h5-cog-row-overlap-regions-process-20261104','h5-staged-row-regions-process-20261104').replace('prepare_h5_cog_row_overlap_regions_20261104.py','prepare_h5_staged_row_regions_20261104.py')
save('run_h5_staged_row_regions_20261104.py',s)
