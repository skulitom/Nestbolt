"""Rebuild all66 original filled outlines from a translated-packet assignment."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from copy import deepcopy
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staged-row-integer-20261104';SEARCH=BASE/'search';OUT=SEARCH/'source-response'
PACKET=ROOT/'output/h5-staged-row-packet-20261104';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir();mapping=load(BASE/'model/mapping.json');values=load(SEARCH/'assignment.json');inventory=load(BASE/'inventory.json');grid=mapping['position_units_per_mm'];assert grid==100
shift=[values[v] for v in mapping['packet_translation_variables']];assert all(lo<=v<=hi for v,(lo,hi) in zip(shift,mapping['packet_shift_bounds_grid']))
cogs=deepcopy(load(PACKET/'packet-source13.json'))
for row in cogs:
    row['transform']['translation']=[v+shift[k]/grid for k,v in enumerate(row['transform']['translation'])]
rows=load(FIRST/'fixed29.json')+cogs+load(SHORT);chosen=[]
for owner in mapping['owners']:
    modes=[m for m in owner['modes'] if values[m['selector']]];regions=[r for r in owner['unary_regions'] if values[r['selector']]];assert len(modes)==len(regions)==1
    mode,region=modes[0],regions[0];assert mode['normalized_geometry']==region['geometry']
    relative=[values[v] for v in owner['positions']];world=[relative[k]+shift[k] for k in [0,1]]
    assert all(lo<=v<=hi for v,(lo,hi) in zip(relative,mode['integer_lower_left_bounds']))
    assert all(lo<=v<=hi for v,(lo,hi) in zip(world,mode['integer_world_lower_left_bounds']))
    xy=[world[k]/grid+mapping['world_origin_mm'][k] for k in [0,1]]
    rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
    chosen.append({'owner':owner['owner'],'identity':owner['identity'],'mode':mode['mode'],'geometry':mode['normalized_geometry'],'relative_lower_left_grid':relative,'world_lower_left_mm':xy,'unary_region':region['region']})
job,spec=load(JOB),load(FIRST/'plan.json');expected=list(map(tuple,inventory['full66_identities']));assert len(rows)==66
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert check['cutouts']==90 and check['hole_vertices']==10026 and check['same_sheet_pairs']==1540 and check['stock_edges']==264
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-modes.json',chosen);write(OUT/'packet-translation.json',{'shift_grid':shift,'shift_mm':[v/grid for v in shift]});write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',PACKET/'packet-source13.json',PACKET/'audit/plan.json',PACKET/'audit/checks.json',BASE/'inventory.json',BASE/'model/mapping.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'source_valid66':check['valid'],'originals':66,'first_originals':55,'short_originals':11,'shared_packet_translation_grid':shift,'same_sheet_pairs':1540,'stock_edges':264,'cutouts':90,'hole_vertices':10026,'source_checker_calls':1,'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
