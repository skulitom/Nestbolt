"""Adapt the audited packet schema to a fixed stage-one row control."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rewrite(s):
    replacements=[('h5-translated-packet-integer-regions-20261104','h5-staged-row-integer-20261104'),('h5-translated-packet-regions-20261104','h5-staged-row-regions-20261104'),('h5-translated-cog-packet-preflight-20261104','h5-staged-row-packet-20261104'),('h5-translated-cog-packet-preflight-process-20261104','h5-staged-row-packet-process-20261104'),('h5-translated-packet-regions-process-20261104','h5-staged-row-regions-process-20261104'),('h5-translated-packet-integer-process-20261104','h5-staged-row-integer-process-20261104'),('prepare_h5_translated_packet_integer_regions_20261104.py','prepare_h5_staged_row_integer_20261104.py'),('build_h5_translated_packet_model_20261104.py','build_h5_staged_row_model_20261104.py'),('check_h5_translated_packet_candidate_20261104.py','check_h5_staged_row_candidate_20261104.py')]
    for a,b in replacements:s=s.replace(a,b)
    return s
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for old,new in [('prepare_h5_translated_packet_integer_regions_20261104.py','prepare_h5_staged_row_integer_20261104.py'),('audit_h5_translated_packet_integer_regions_20261104.py','audit_h5_staged_row_integer_20261104.py'),('run_h5_translated_packet_integer_regions_20261104.py','run_h5_staged_row_integer_20261104.py')]:
    s=rewrite((ROOT/'output'/old).read_text(encoding='utf-8'))
    s=s.replace('movable-packet relative hulls','fixed stage-one packet world-coordinate hulls').replace('preserve the separately source-audited shared packet translation limits','preserve the independently source-audited zero-shift packet point domain')
    save(new,s)
processes="{'stage_one_packet_preparation_seconds':'h5-translated-cog-packet-preflight-process-20261104','stage_one_individual_row_domain_seconds':'h5-individual-cog-row-domains-process-20261104','stage_one_expanded_row_regions_seconds':'h5-expanded-cog-row-regions-process-20261104','stage_one_expanded_row_integer_seconds':'h5-expanded-cog-row-integer-process-20261104','stage_one_row_control_seconds':'h5-expanded-cog-row-control-process-20261104'}"
for old,new in [('build_h5_translated_packet_model_20261104.py','build_h5_staged_row_model_20261104.py'),('audit_h5_translated_packet_model_20261104.py','audit_h5_staged_row_model_20261104.py')]:
    s=rewrite((ROOT/'output'/old).read_text(encoding='utf-8'))
    s=s.replace('load=lambda p:',f'STAGE_ONE_PROCESSES={processes}\nload=lambda p:',1)
    s=s.replace("'packet_complete_preparation_seconds':load(PACKET_PROCESS", "**{key:load(ROOT/'output'/name/'process.json')['complete_process_seconds'] for key,name in STAGE_ONE_PROCESSES.items()},'packet_complete_preparation_seconds':load(PACKET_PROCESS",1)
    s=s.replace('inputs=[Path(__file__),',"inputs=[ROOT/'output'/name/file for name in STAGE_ONE_PROCESSES.values() for file in ['opened.json','process.json']]+[Path(__file__),",1)
    s=s.replace("shift_bounds=load(BASE/'packet-translation-domain.json')['shift_bounds_grid']", "shift_bounds=load(BASE/'packet-translation-domain.json')['shift_bounds_grid'];assert shift_bounds==[[0,0],[0,0]]",1)
    s=s.replace('New translating-packet construction:','Two-stage fixed-row companion construction:')
    s=s.replace('Two additional shared X/Y variables translate all13 reference cogs and every orthogonal coordinate together into world space.', 'Two compatibility coordinates are fixed to zero; the independently source-checked stage-one13-cog layout remains fixed and all13 orthogonal companions have independent world positions.')
    s=s.replace('Charge every preparation process.','Charge every preparation process.')
    s=s.replace("'shared_packet_translation_variables':2", "'shared_packet_translation_variables':2,'free_packet_translation_variables':0,'staged_companion_construction':True")
    s=s.replace("'shared_packet_translation_variables_verified':2", "'shared_packet_translation_variables_verified':2,'free_packet_translation_variables_verified':0,'all_stage_one_process_costs_charged':True")
    save(new,s)
for old,new in [('run_h5_translated_packet_model_build_20261104.py','run_h5_staged_row_model_build_20261104.py'),('check_h5_translated_packet_candidate_20261104.py','check_h5_staged_row_candidate_20261104.py'),('run_h5_translated_packet_model_20261104.py','run_h5_staged_row_model_20261104.py'),('audit_h5_translated_packet_response_20261104.py','audit_h5_staged_row_response_20261104.py')]:
    s=rewrite((ROOT/'output'/old).read_text(encoding='utf-8'))
    s=s.replace("ma['variables_verified']==2407", "ma['variables_verified']==load(MODEL/'checks.json')['variables']").replace("ma['constraints_verified']==7410", "ma['constraints_verified']==load(MODEL/'checks.json')['constraints']")
    save(new,s)
