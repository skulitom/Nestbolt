"""Exact mandatory15-cell model and complete independent protobuf reconstruction."""
from pathlib import Path
from hashlib import sha256
import gzip,json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-clipped-capacity-20261026';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(BASE/'audit/checks.json')['passed'];cells=load(BASE/'cells.json');cliques=load(BASE/'cliques.json');left=load(BASE/'residual-pairs.json');assert not left;n=len(cells);assert n==1045 and load(BASE/'audit/checks.json')['additional_geometric_conflicts']==139
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'cells.json',BASE/'cliques.json',BASE/'residual-pairs.json',BASE/'graph.bin.gz',BASE/'audit/checks.json',BASE/'audit/necessity-proof.json']},'method':'After exact clipping of all forbidden support-box lattice points and139 independently certified new pair conflicts, one Boolean per complete necessary nonempty occupancy hull, exact sum15 and all verified incompatibility cliques. No objective or hints. All15 original cogs remain mandatory; ignore the remaining two inserts only for this necessary test. Positive means only compatible cells; negative excludes only the current fixed34/short15 arrangement by the audited continuous-domain necessity proof. One20-second solver call within30 shared seconds, no retry or extension.','maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0})
model=cp_model.CpModel();variables=[model.new_bool_var(f'cell_{i}') for i in range(n)];model.add(sum(variables)==15)
for clique in cliques:model.add_at_most_one([variables[i] for i in clique])
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));saved=cp_model_pb2.CpModelProto();saved.ParseFromString((OUT/'model.pb').read_bytes());assert text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())==saved;expected=cp_model_pb2.CpModelProto()
for i in range(n):expected.variables.add(name=f'cell_{i}',domain=[0,1])
row=expected.constraints.add().linear;row.vars.extend(range(n));row.coeffs.extend([1]*n);row.domain.extend([15,15])
for clique in cliques:expected.constraints.add().at_most_one.literals.extend(clique)
assert expected==saved and not saved.HasField('objective') and not saved.solution_hint.vars;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());nb=(n+7)//8;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];covered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:others=mask^(1<<i);assert graph[i]&others==others;covered[i]|=others
assert covered==graph
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':n,'constraints':len(saved.constraints),'required_occupied_cells':15,'complete_graph_projection':True,'exact_independent_proto_reconstruction':True,'model_sha256':digest(OUT/'model.pb'),'geometry_audit_sha256':digest(BASE/'audit/checks.json'),'no_objective_or_hints':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
