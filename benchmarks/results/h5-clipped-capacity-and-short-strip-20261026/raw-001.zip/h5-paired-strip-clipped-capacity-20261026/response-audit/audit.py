"""Read back the single closed UNKNOWN call without turning it into an exclusion."""
from pathlib import Path
from hashlib import sha256
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-clipped-capacity-20261026';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
assert load(BASE/'model/checks.json')['passed']
for n,h in load(BASE/'model/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert digest(SEARCH/'model.pb')==load(BASE/'model/checks.json')['model_sha256']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20.,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False)
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');budget=load(SEARCH/'budget.json')
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<budget['shared_seconds']==30
assert cp_model_pb2.CpSolverStatus.Name(response.status)==result['status']=='UNKNOWN' and not response.solution and result['selected_cells'] is None
assert result['closed'] and result['solver_calls']==budget['maximum_calls']==1 and not budget['retry_permitted']
assert 0<response.wall_time==result['solver_wall_seconds']<=result['returned_solve_seconds']<=process['seconds']
assert result['solver_soft_overrun_seconds']==max(0,response.wall_time-budget['solver_seconds'])
assert result['returned_soft_overrun_seconds']==max(0,result['returned_solve_seconds']-budget['solver_seconds'])
assert response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts']
model=cp_model_pb2.CpModelProto();model.ParseFromString((SEARCH/'model.pb').read_bytes());assert len(model.variables)==1045 and len(model.constraints)==1747
assert not model.HasField('objective') and not model.solution_hint.vars
log=(SEARCH/'solver.log').read_text();lines=log.splitlines();assert re.findall(r'^status:\s+(\w+)',log,re.M)[-1]=='UNKNOWN'
assert abs(float(re.findall(r'^walltime:\s+([0-9.]+)',log,re.M)[-1])-response.wall_time)<.0005
assert int(re.findall(r'^branches:\s+(\d+)',log,re.M)[-1])==response.num_branches
workers=[];k=next(i for i,line in enumerate(lines) if line.startswith('Search stats'))+1
while k<len(lines) and lines[k].strip():
    match=re.match(r"\s+'([^']+)':\s+([0-9']+)\s+([0-9']+)\s+([0-9']+)",lines[k]);assert match
    name,bools,conflicts,branches=match.groups();workers.append({'worker':name,'booleans':int(bools.replace("'",'')),'conflicts':int(conflicts.replace("'",'')),'branches':int(branches.replace("'",''))});k+=1
assert any(w['branches']>0 for w in workers) and any(line.startswith('Starting search at') for line in lines)
assert any(w['branches']==response.num_branches and w['conflicts']==response.num_conflicts for w in workers)
write(OUT/'worker-stats.json',workers)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':'UNKNOWN','solver_calls':1,'closed':True,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'shared_budget_honored':True,'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'returned_worker_branches':response.num_branches,'returned_worker_conflicts':response.num_conflicts,'search_beyond_presolve':True,'model_variables':len(model.variables),'model_constraints':len(model.constraints),'previous_exclusions':66,'additional_geometric_conflicts':139,'required_cogs':15,'required_remaining_inserts_for_full_layout':2,'source_or_necessary_positive_found':False,'fixed34_neighborhood_excluded':False,'formal_unsat_certificate_claimed':False,'native_calls':0,'full66_target_witness':False,'H5_complete':False})
print(load(OUT/'checks.json'))
