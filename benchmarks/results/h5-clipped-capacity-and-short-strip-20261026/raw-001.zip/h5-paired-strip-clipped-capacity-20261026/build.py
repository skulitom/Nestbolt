"""Clip rounded-center cells by all certified support boxes before building capacity."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-clipped-capacity-20261026';OLD=ROOT/'output/h5-paired-strip-capacity-cells-20261026';OB=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';CLR=ROOT/'output/h5-paired-strip-clearance-capacity-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def intersect(a,b):
    r=[max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])]
    return r if r[0]<=r[2] and r[1]<=r[3] else None
def subtract(a,b):
    q=intersect(a,b)
    if q is None:return [a]
    x,y,u,v=q;rows=[[a[0],a[1],x-1,a[3]],[u+1,a[1],a[2],a[3]],[x,a[1],u,y-1],[x,v+1,u,a[3]]]
    return [r for r in rows if r[0]<=r[2] and r[1]<=r[3]]
def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
def hull(points):
    points=sorted(set(points))
    if len(points)<=1:return points
    lower=[];upper=[]
    for p in points:
        while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    for p in reversed(points):
        while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
def bits(v):
    while v:l=v&-v;yield l.bit_length()-1;v-=l
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[OLD/'cells.json',OLD/'graph.bin.gz',OLD/'audit/checks.json',OB/'support-vertex-boxes.json',OB/'excluded-cells.json',OB/'audit/checks.json',CLR/'support-vertex-boxes.json',CLR/'new-excluded-cells.json',CLR/'audit/checks.json',CLR/'response-audit/checks.json']
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'The preceding model is closed UNKNOWN. Mathematically strengthen its cell footprints, not its timing or seed. Preserve the66 certified whole-cell exclusions. For each remaining original occupancy cell subtract every closed integer support-vertex box from both independently audited proof families. Inclusive integer subtraction keeps all floor-rounded source centers and uses plus/minus1 only at integer endpoints. Do not remove points on the strength of samples. Retain all surviving lattice rectangles, then take their exact integer convex hull solely as an outer relaxation. Empty footprints are forbidden. Recompute the full pair graph: cells conflict only if even the farthest pair of hull vertices is strictly closer than the certified254297 micrometre separation. Any source15-cog layout must occupy15 distinct compatible nonempty cells; both inserts remain required for full layout. Independently verify lattice coverage, hull containment and every pair before any solve. One new20-second call inside30 shared seconds is permitted only if the model gains certified exclusions or edges. No retry of earlier models.','rounded_separation_units1000':254297,'geometry_and_graph_seconds':60,'clique_cover_seconds':20,'maximum_solver_calls':1,'solver_seconds':20,'shared_seconds':30,'required_cogs':15,'required_inserts_for_full_layout':2})
boxes=[{'index':i,'source_family':family,'source_box':r['index'],'bounds_units1000':r['bounds_units1000']} for i,(family,r) in enumerate([(family,r) for family,folder in [('oblique',OB),('clearance',CLR)] for r in load(folder/'support-vertex-boxes.json')])]
previous=sorted({r['cell'] for r in load(OB/'excluded-cells.json')}|{r['cell'] for r in load(CLR/'new-excluded-cells.json')});assert len(previous)==66
old=load(OLD/'cells.json');footprints=[];cells=[];empty=[]
for cell in old:
    assert time.perf_counter()-start<60
    if cell['index'] in previous:continue
    relevant=[r for r in boxes if intersect(cell['bounds_units1000'],r['bounds_units1000']) is not None]
    pieces=[cell['bounds_units1000']]
    for r in relevant:pieces=[p for oldpiece in pieces for p in subtract(oldpiece,r['bounds_units1000'])]
    pieces.sort();vertices=hull([(x,y) for a,b,c,d in pieces for x in [a,c] for y in [b,d]])
    footprints.append({'original_cell':cell['index'],'relevant_boxes':[r['index'] for r in relevant],'integer_rectangles':pieces,'hull_vertices_units1000':vertices})
    if not pieces:empty.append(cell['index']);continue
    cells.append({'index':len(cells),'original_cell':cell['index'],'hull_vertices_units1000':vertices})
n=len(cells);adj=np.zeros((n,n),dtype=np.bool_);arrays=[np.asarray(c['hull_vertices_units1000'],dtype=np.int64) for c in cells]
for i in range(n):
    assert time.perf_counter()-start<60
    for j in range(i+1,n):
        delta=arrays[i][:,None,:]-arrays[j][None,:,:];maximum=int(np.max(np.sum(delta*delta,axis=2)));adj[i,j]=adj[j,i]=maximum<254297**2
raw=np.packbits(adj,axis=1,bitorder='little').tobytes();nb=(n+7)//8;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)]
oldraw=gzip.decompress((OLD/'graph.bin.gz').read_bytes());oldnb=(len(old)+7)//8;oldgraph=[int.from_bytes(oldraw[i*oldnb:(i+1)*oldnb],'little') for i in range(len(old))];new_edges=0;old_edges=0
for i in range(n):
    for j in range(i+1,n):
        prior=bool((oldgraph[cells[i]['original_cell']]>>cells[j]['original_cell'])&1);edge=bool((graph[i]>>j)&1);assert not prior or edge;old_edges+=prior;new_edges+=edge and not prior
assert new_edges or empty
residual=list(graph);cliques=[];coverstart=time.perf_counter()
while time.perf_counter()-coverstart<20:
    v=max(range(n),key=lambda i:residual[i].bit_count())
    if not residual[v]:break
    clique=[v];candidates=residual[v]
    while candidates:u=max(bits(candidates),key=lambda i:(graph[i]&candidates).bit_count());clique.append(u);candidates&=graph[u]
    mask=sum(1<<i for i in clique)
    for i in clique:assert graph[i]&(mask^(1<<i))==mask^(1<<i);residual[i]&=~mask
    cliques.append(clique)
left=[[i,j] for i in range(n) for j in bits(residual[i]) if i<j];covered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:covered[i]|=mask^(1<<i)
for i,j in left:covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph
for name,data in [('forbidden-boxes.json',boxes),('previous-exclusions.json',previous),('footprints.json',footprints),('cells.json',cells),('new-empty-cells.json',empty),('cliques.json',cliques),('residual-pairs.json',left)]:write(OUT/name,data)
with gzip.open(OUT/'graph.bin.gz','xb') as f:f.write(raw)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'support_boxes':len(boxes),'previous_exclusions':len(previous),'new_empty_cells':len(empty),'retained_cells':n,'retained_integer_rectangles':sum(len(r['integer_rectangles']) for r in footprints),'changed_nonempty_footprints':sum(r['integer_rectangles']!=[old[r['original_cell']]['bounds_units1000']] for r in footprints if r['integer_rectangles']),'unordered_pair_checks':n*(n-1)//2,'retained_old_edges':old_edges,'new_geometric_edges':new_edges,'total_conflicts':sum(r.bit_count() for r in graph)//2,'cliques':len(cliques),'residual_edges':len(left),'clique_cover_seconds':time.perf_counter()-coverstart,'graph_uncompressed_sha256':sha256(raw).hexdigest(),'all_source_floor_centers_retained':True,'finite_source_sampling_used':False,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
