"""Independent atomic integer partition, convex containment and complete pair audit."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-clipped-capacity-20261026';OUT=BASE/'audit';OLD=ROOT/'output/h5-paired-strip-capacity-cells-20261026';OB=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';CLR=ROOT/'output/h5-paired-strip-clearance-capacity-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def contains(r,x,y):return r[0]<=x<=r[2] and r[1]<=y<=r[3]
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def in_hull(p,h):
    if len(h)==1:return list(p)==h[0]
    if len(h)==2:return cross(h[0],h[1],p)==0 and all(min(h[0][k],h[1][k])<=p[k]<=max(h[0][k],h[1][k]) for k in [0,1])
    return all(cross(h[k],h[(k+1)%len(h)],p)>=0 for k in range(len(h)))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for folder in [OLD,OB,CLR]:assert load(folder/'audit/checks.json')['passed']
expected=[]
for family,folder in [('oblique',OB),('clearance',CLR)]:
    for r in load(folder/'support-vertex-boxes.json'):expected.append({'index':len(expected),'source_family':family,'source_box':r['index'],'bounds_units1000':r['bounds_units1000']})
boxes=load(BASE/'forbidden-boxes.json');assert boxes==expected
previous=sorted({r['cell'] for r in load(OB/'excluded-cells.json')}|{r['cell'] for r in load(CLR/'new-excluded-cells.json')});assert previous==load(BASE/'previous-exclusions.json') and len(previous)==66
old=load(OLD/'cells.json');footprints=load(BASE/'footprints.json');assert [r['original_cell'] for r in footprints]==[r['index'] for r in old if r['index'] not in previous]
atoms_checked=0;lattice_retained=0;lattice_removed=0;corner_checks=0;cells=[];empty=[]
for f in footprints:
    source=old[f['original_cell']]['bounds_units1000'];a,b,c,d=source
    relevant=[r for r in boxes if max(a,r['bounds_units1000'][0])<=min(c,r['bounds_units1000'][2]) and max(b,r['bounds_units1000'][1])<=min(d,r['bounds_units1000'][3])]
    assert f['relevant_boxes']==[r['index'] for r in relevant]
    pieces=f['integer_rectangles'];assert pieces==sorted(pieces) and all(all(isinstance(v,int) for v in p) and a<=p[0]<=p[2]<=c and b<=p[1]<=p[3]<=d for p in pieces)
    xs={a,c+1};ys={b,d+1}
    for r in relevant:
        q=r['bounds_units1000'];xs.update([max(a,q[0]),min(c,q[2])+1]);ys.update([max(b,q[1]),min(d,q[3])+1])
    for p in pieces:xs.update([p[0],p[2]+1]);ys.update([p[1],p[3]+1])
    xs=sorted(xs);ys=sorted(ys);local_kept=0;local_removed=0
    for i,j in product(range(len(xs)-1),range(len(ys)-1)):
        x,y=xs[i],ys[j];size=(xs[i+1]-x)*(ys[j+1]-y)
        forbidden=any(contains(r['bounds_units1000'],x,y) for r in relevant)
        multiplicity=sum(contains(p,x,y) for p in pieces);assert multiplicity==int(not forbidden)
        atoms_checked+=1
        if forbidden:local_removed+=size
        else:local_kept+=size
    assert local_kept+local_removed==(c-a+1)*(d-b+1)
    assert local_kept==sum((p[2]-p[0]+1)*(p[3]-p[1]+1) for p in pieces)
    lattice_retained+=local_kept;lattice_removed+=local_removed
    hull=f['hull_vertices_units1000'];corners={(x,y) for p in pieces for x in [p[0],p[2]] for y in [p[1],p[3]]}
    if not pieces:assert not hull;empty.append(f['original_cell']);continue
    assert hull and len(set(map(tuple,hull)))==len(hull) and all(tuple(v) in corners for v in hull)
    if len(hull)>=3:assert all(cross(hull[k],hull[(k+1)%len(hull)],hull[(k+2)%len(hull)])>0 for k in range(len(hull)))
    for point in corners:assert in_hull(point,hull);corner_checks+=1
    assert max((x-u)**2+(y-v)**2 for x,y in hull for u,v in hull)<254297**2
    cells.append({'index':len(cells),'original_cell':f['original_cell'],'hull_vertices_units1000':hull})
assert cells==load(BASE/'cells.json') and empty==load(BASE/'new-empty-cells.json')
n=len(cells);nb=(n+7)//8;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());assert len(raw)==n*nb and sha256(raw).hexdigest()==load(BASE/'result.json')['graph_uncompressed_sha256'];graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)]
oldraw=gzip.decompress((OLD/'graph.bin.gz').read_bytes());oldnb=(len(old)+7)//8;oldgraph=[int.from_bytes(oldraw[i*oldnb:(i+1)*oldnb],'little') for i in range(len(old))];pair_checks=0;vertex_pairs=0;conflicts=0;new_edges=[]
for i in range(n):
    assert not(graph[i]>>i)&1 and graph[i]>>n==0
    for j in range(i+1,n):
        aa=cells[i]['hull_vertices_units1000'];bb=cells[j]['hull_vertices_units1000'];maximum=max((x-u)**2+(y-v)**2 for x,y in aa for u,v in bb);edge=maximum<254297**2
        assert edge==bool((graph[i]>>j)&1)==bool((graph[j]>>i)&1);pair_checks+=1;vertex_pairs+=len(aa)*len(bb);conflicts+=edge
        prior=bool((oldgraph[cells[i]['original_cell']]>>cells[j]['original_cell'])&1);assert not prior or edge
        if edge and not prior:new_edges.append({'cells':[i,j],'original_cells':[cells[i]['original_cell'],cells[j]['original_cell']],'maximum_squared_units1000':maximum})
covered=[0]*n;cliques=load(BASE/'cliques.json');left=load(BASE/'residual-pairs.json')
for clique in cliques:
    assert len(set(clique))==len(clique)>=2 and all(0<=i<n for i in clique);mask=sum(1<<i for i in clique)
    for i in clique:others=mask^(1<<i);assert graph[i]&others==others;covered[i]|=others
for i,j in left:assert 0<=i<j<n and (graph[i]>>j)&1;covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph and len(new_edges)==load(BASE/'result.json')['new_geometric_edges'] and (new_edges or empty)
write(OUT/'new-edge-certificates.json',new_edges)
write(OUT/'necessity-proof.json',{'statement':'Prior source and clearance support boxes are forbidden for every floor-rounded source center, every sub-micrometre fractional rounding offset and every original rotation. Removing their inclusive integer point sets from each remaining closed occupancy cell preserves every floor-rounded source-feasible center. Independent atomic integer coordinate partitions verify the exact complement, including endpoints, with no missing or multiply covered lattice point. Each recorded hull uses retained rectangle corners, is convex and contains every corner; hence it encloses every retained rectangle and every surviving integer point. Taking a convex hull adds possibilities and cannot exclude a source center. Squared Euclidean distance is convex in either argument, so the maximum over two convex polygon hulls occurs at a pair of vertices. An exact maximum strictly below the independently certified254297 micrometre rounded source separation proves a mutual cell conflict. Each hull has smaller diameter than that separation, retaining capacity one. Thus every source15-cog solution selects15 distinct nonempty hull cells obeying the entire independently verified graph. Both inserts are still required for the full layout and are relaxed only for this necessary bound. This strictly stronger geometry adds certified conflicts; it is not a retry of the previous closed UNKNOWN model. A positive selection would still not prove source feasibility.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'support_boxes_verified':len(boxes),'prior_exclusions_preserved':len(previous),'atomic_integer_regions_verified':atoms_checked,'lattice_points_retained':lattice_retained,'lattice_points_removed':lattice_removed,'hull_corner_checks':corner_checks,'retained_cells_verified':n,'new_empty_cells':len(empty),'unordered_pair_checks':pair_checks,'vertex_pair_checks':vertex_pairs,'conflicts_verified':conflicts,'additional_geometric_conflicts':len(new_edges),'cliques_verified':len(cliques),'residual_edges_verified':len(left),'complete_graph_coverage':True,'all_source_floor_centers_retained':True,'all_original_angles_covered':True,'finite_samples_used_as_exclusion':False,'required_cogs':15,'required_inserts_for_full_layout':2,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
