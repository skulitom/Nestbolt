"""Bind existing model serialization and single-call tools to the changed exact graph."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('prepare_h5_paired_strip_capacity_model.py','prepare_h5_paired_strip_clipped_model.py'),('run_h5_paired_strip_capacity_model.py','run_h5_paired_strip_clipped_model.py')]:
    s=(ROOT/'output'/source).read_text(encoding='utf-8').replace('h5-paired-strip-capacity-cells-20261026','h5-paired-strip-clipped-capacity-20261026')
    s=s.replace('assert n==1111','assert n==1045 and load(BASE/\'audit/checks.json\')[\'additional_geometric_conflicts\']==139')
    s=s.replace('One Boolean per complete necessary occupancy cell,','After exact clipping of all forbidden support-box lattice points and139 independently certified new pair conflicts, one Boolean per complete necessary nonempty occupancy hull,')
    with (ROOT/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
