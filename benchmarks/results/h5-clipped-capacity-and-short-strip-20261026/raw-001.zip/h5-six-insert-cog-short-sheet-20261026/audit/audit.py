"""Independent fixed-source validation and faithful finite-query readback."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,shape as from_mapping
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-insert-cog-short-sheet-20261026';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)}
bounds=[float(F(*v)) for v in load(ROOT/'output/h5-source-orientation-construction-20261025/geometry.json')['stock_bounds_rational'][1]];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
baseline=load(ROOT/'output/h5-nine-insert-short-sheet-20261026/short-sheet-placements.json');expected_ids=[21,22,25,26,28,29,32,34,35,36,37,38];variants=load(BASE/'variants.json');pair_checks=edge_checks=holes=hole_vertices=0;minimum=math.inf;extra=math.inf
for v in variants:
    assert v['index'] in range(4);poses=v['fixed_placements'];assert len(poses)==12 and sorted(ids[p['part_id'],p['copy_index']] for p in poses)==expected_ids
    assert Counter(p['part_id'] for p in poses)=={'bracket':6,'insert':6};polys=[]
    for p in poses:
        item=ids[p['part_id'],p['copy_index']]
        if item in [21,22,25,26,28,29,32,34,35]:assert p==next(q for q in baseline if (q['part_id'],q['copy_index'])==(p['part_id'],p['copy_index']))
        t=p['transform'];f=parts[p['part_id']];assert p['sheet_id']=='sheet-1' and (not t['mirrored'] or f['allow_mirror'])
        assert f['rotations']['kind']=='list' and any(abs(math.degrees(t['rotation_radians'])%360-a)<1e-8 for a in f['rotations']['degrees'])
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        def project(points):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in points]
        source=f['geometry'][0];outer=Polygon(project(source['outer']));full=Polygon(project(source['outer']),[project(h) for h in source['holes']]);assert outer.is_valid and full.is_valid and len(full.interiors)==len(source['holes'])
        holes+=len(source['holes']);hole_vertices+=sum(len(h) for h in source['holes']);b=outer.bounds
        margins=[b[0]-bounds[0],b[1]-bounds[1],bounds[2]-b[2],bounds[3]-b[3]];assert min(margins)>guard;extra=min(extra,*margins);edge_checks+=4;polys.append(outer)
    for a,b in combinations(polys,2):
        distance=a.distance(b);assert a.intersection(b).area==0 and distance>required;minimum=min(minimum,distance);pair_checks+=1
queries=load(BASE/'queries.json');schedule=[(v,deg) for deg in plan['phases_degrees'] for v in range(4)];assert len(queries)==len(schedule)==144 and not load(BASE/'pending.json')
for q,(v,deg) in zip(queries,schedule):
    assert q['index'] in range(144) and q['variant']==v and q['degrees']==deg
    saved=load(BASE/'queries'/f"{q['index']:03d}.json");assert saved['index']==q['index'] and saved['variant']==v and saved['degrees']==deg
    region=from_mapping(saved['region']);assert region.is_empty and region.area==q['area']==0 and q['empty'] and saved['proposals']==[] and q['proposals']==0
assert not load(BASE/'events.json') and not load(BASE/'accepted.json');result=load(BASE/'result.json');assert result['closed'] and result['seconds']<60 and result['completed_queries']==result['empty_queries']==144 and result['accepted_13_original_short_layouts']==0 and not result['unrestricted_short_sheet_excluded']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fixed_variants_verified':4,'fixed_originals_each':12,'same_sheet_pair_checks':pair_checks,'stock_edge_checks':edge_checks,'cutouts_across_variants':holes,'hole_vertices_across_variants':hole_vertices,'minimum_fixed_pair_gap_mm':minimum,'minimum_extra_stock_mm':extra,'saved_finite_queries_read_back':144,'empty_conservative_regions':144,'proposals_checked':0,'accepted_13_part_candidates':0,'generation_seconds':result['seconds'],'generation_limit_honored':True,'query_helper_recomputed':False,'independent_unrestricted_exclusion_claimed':False,'source_geometry_independently_reconstructed':True,'interpretation':'Direct vertex geometry independently validates all fixed originals. Saved empty conservative query results and their provenance are read back, not promoted to an independent negative geometry proof. No source candidate was found among the declared queries, and no solver was opened.','closed':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
