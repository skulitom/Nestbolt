"""Finite original-cog translation queries for a changed13-original short strip."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import copy,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,mapping
from shapely.affinity import affine_transform
import diagnose_h5_concave_gaps as geom
from build_h5_cog_free_regions import proposals
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-six-insert-cog-short-sheet-20261026';OLD=ROOT/'output/h5-five-insert-short-sheet-repaired-20261026';NINE=ROOT/'output/h5-nine-insert-short-sheet-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[JOB,SRC/'items.json',SRC/'geometry.json',OLD/'short-sheet-placements.json',OLD/'first-sheet-placements.json',OLD/'audit/checks.json',NINE/'short-sheet-placements.json',NINE/'audit/checks.json',Path(geom.__file__),ROOT/'output/build_h5_cog_free_regions.py']
assert load(OLD/'audit/checks.json')['passed'] and load(NINE/'audit/checks.json')['passed']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_generation_seconds':60,'phases_degrees':[i/2 for i in range(36)],'variants':4,'method':'A new allocation relative to the known short six-bracket/five-insert/cog arrangement: widen the third bracket pair to accept insert35 and put inserts36/37/38 in a two-vertical-plus-one-horizontal stack at the right stock edge, leaving cog65 mandatory between them. This moves insert38 from the main sheet if successful. Keep the source-verified nine-part bracket/insert block from the nine-insert short sheet. Test four right-stack variants: horizontal insert left/right aligned, and vertical reflection of the entire stack. For each variant and each actual half-degree angle0..17.5, construct conservative free cog translation regions against all12 fixed originals with the original stock target and native safety margins. Retain every region vertex, midpoint and representative and check actual source distances. No rotational symmetry assumption; empty finite queries are not an arbitrary-angle or unrestricted short-sheet exclusion. Stop after60 seconds and preserve unqueried work; no retry or extension. All13 short quantities are mandatory for a positive. Old capacity models remain closed and are not reused.','mandatory_short_originals':[21,22,25,26,28,29,32,34,35,36,37,38,65],'solver_calls':0,'native_calls':0})
job=load(JOB);parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};bounds=[float(F(*v)) for v in load(SRC/'geometry.json')['stock_bounds_rational'][1]];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
def shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(Polygon(parts[p['part_id']]['geometry'][0]['outer']),[m*c,-s,m*s,c,*t['translation']])
block=[p for p in load(NINE/'short-sheet-placements.json') if ids[p['part_id'],p['copy_index']] in [21,22,25,26,28,29,32,34,35]];assert len(block)==9
variants=[];fixed_checks=[];right=bounds[2]-.025;bottom=bounds[1]+.025;left=right-220.225
for v in range(4):
    stack=[]
    for i,(item,x,y,turn) in enumerate([(36,left,bottom,True),(37,left+110.225,bottom,True),(38,left+(40.225 if v%2 else 0),bottom+180.225,False)]):
        w,h=(110,180) if turn else (180,110)
        if v//2:y=bounds[1]+bounds[3]-y-h
        p={'part_id':'insert','copy_index':items[item]['copy'],'sheet_id':'sheet-1','transform':{'rotation_radians':math.pi/2 if turn else 0.,'mirrored':False,'translation':[x+110 if turn else x,y]}}
        stack.append(p)
    fixed=block+stack;polys=[shape(p) for p in fixed];minimum=min(a.distance(b) for a,b in combinations(polys,2));extra=min(min(p.bounds[0]-bounds[0],p.bounds[1]-bounds[1],bounds[2]-p.bounds[2],bounds[3]-p.bounds[3]) for p in polys);assert minimum>required and extra>guard
    variants.append({'index':v,'fixed_placements':fixed});fixed_checks.append({'variant':v,'originals':12,'pair_checks':66,'stock_edges':48,'minimum_gap_mm':minimum,'minimum_extra_stock_mm':extra})
write(OUT/'variants.json',variants);write(OUT/'fixed-checks.json',fixed_checks)
stock=copy.deepcopy(job['stocks'][0]);stock['height']=bounds[3]+stock['margins']['top']+job['edge_clearance'];geom.EPS=.0126
schedule=[(v,deg) for deg in [i/2 for i in range(36)] for v in range(4)];queries=[];accepted=[];events=[]
for qi,(v,deg) in enumerate(schedule):
    if time.perf_counter()-start>=60:break
    angle=math.radians(deg);moving={'part_id':'cog','copy_index':items[65]['copy'],'sheet_id':'sheet-1','transform':{'rotation_radians':angle,'mirrored':False,'translation':[0.,0.]}};fixed=np.asarray([shape(p) for p in variants[v]['fixed_placements']],dtype=object);region=geom.regions(shape(moving),list(fixed),stock,job['edge_clearance'],required);ps=proposals(region);record={'index':qi,'variant':v,'degrees':deg,'region':mapping(region),'proposals':ps};write(OUT/'queries'/f'{qi:03d}.json',record);queries.append({'index':qi,'variant':v,'degrees':deg,'empty':region.is_empty,'area':region.area,'proposals':len(ps)})
    for pi,row in enumerate(ps):
        p=copy.deepcopy(moving);p['transform']['translation']=row['point'];g=shape(p);b=g.bounds;extra=min(b[0]-bounds[0],b[1]-bounds[1],bounds[2]-b[2],bounds[3]-b[3]);distance=float(np.min(shapely.distance(g,fixed)));ok=extra>guard and distance>required;events.append({'query':qi,'proposal':pi,'minimum_extra_stock_mm':extra,'minimum_fixed_gap_mm':distance,'accepted':ok})
        if ok:accepted.append({'query':qi,'proposal':pi,'placements':variants[v]['fixed_placements']+[p]})
write(OUT/'queries.json',queries);write(OUT/'events.json',events);write(OUT/'accepted.json',accepted);write(OUT/'pending.json',[{'variant':v,'degrees':deg} for v,deg in schedule[len(queries):]])
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'fixed_originals_per_variant':12,'variants':4,'completed_queries':len(queries),'planned_queries':len(schedule),'empty_queries':sum(q['empty'] for q in queries),'proposals_checked':len(events),'accepted_13_original_short_layouts':len(accepted),'generation_budget_reached':len(queries)<len(schedule),'closed':True,'unrestricted_short_sheet_excluded':False,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
