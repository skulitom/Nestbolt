"""Independent original-vertex and full four-family distance-graph audit."""
from collections import Counter
from itertools import combinations,product
import copy,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_individual_frame_joint import ROOT,SRC,COVER,OUT,load,write,digest,read_graph
def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter();plan=load(OUT/'plan.json');mp=load(OUT/'mapping.json');coverage=load(COVER/'mapping.json');pool=load(OUT/'candidates.json')
    for record in [plan,load(COVER/'plan.json')]:
        for name,h in record['inputs'].items():assert digest(ROOT/name)==h
    assert pool==load(ROOT/coverage['source_pool'])
    for key in coverage:assert mp[key]==coverage[key]
    ids=mp['candidates'];assert ids==list(range(len(pool))) and len(ids)==35488
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');original=ROOT/'output/h5-coordinated-placement-selection-20261018'
    assert load(original/'job.json')==job and load(original/'conditional-target.json')==target
    gg=[];maxdistance=maxarea=0.
    for p in pool:
        p=p['placement'];part=parts[p['part_id']];t=p['transform'];angle=t['rotation_radians'];co,si=math.cos(angle),math.sin(angle);mirror=-1 if t['mirrored'] else 1;x,y=t['translation']
        g=Polygon([(mirror*a*co-b*si+x,mirror*a*si+b*co+y) for a,b in part['geometry'][0]['outer']]);reference=shape(part,t);distance=g.hausdorff_distance(reference);area=g.symmetric_difference(reference).area;maxdistance=max(maxdistance,distance);maxarea=max(maxarea,area)
        assert distance<=1e-8 and area<=1e-6 and p['sheet_id'] in ['sheet-0','sheet-1'] and g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(angle-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7;gg.append(g)
    gs=np.asarray(gg,dtype=object);bb=shapely.bounds(gs);ss=np.asarray([p['placement']['sheet_id'] for p in pool]);saved=read_graph(OUT/'adjacency.bin.gz',len(ids));expected=[0]*len(ids);possible=near=0;family_pairs=Counter()
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];possible+=len(js)
        dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clear+1e-7];near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<clear-1e-7]:
            j=int(j);expected[i]|=1<<j;expected[j]|=1<<i
        if i and i%4000==0:print({'audit_rows':i,'seconds':time.perf_counter()-start},flush=True)
    assert expected==saved;edges=sum(v.bit_count() for v in expected)//2;result=load(OUT/'result.json');assert edges==result['conflicts'] and digest(OUT/'adjacency.bin.gz')==result['graph_sha256']
    family_masks={f:sum(1<<i for i,p in enumerate(pool) if p['placement']['part_id']==f) for f in parts}
    for i,row in enumerate(expected):
        later=row&~((1<<(i+1))-1)
        for f,mask in family_masks.items():family_pairs['/'.join(sorted([pool[i]['placement']['part_id'],f]))]+=(later&mask).bit_count()
    assert sum(family_pairs.values())==edges
    keys={identity(p['placement']):i for i,p in enumerate(pool)};seedpairs=0
    for seed in mp['seeds']:
        path=ROOT/seed['source'];assert digest(path)==seed['source_sha256'];mapped=[]
        for p in load(path)['placements']:
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert p==pool[i]['placement'];mapped.append(i)
        assert sorted(mapped)==seed['selected_indices'] and len(mapped)==len(set(mapped))==64;mask=sum(1<<i for i in mapped);assert all(not(saved[i]&mask) for i in mapped)
        counts=Counter(pool[i]['placement']['part_id'] for i in mapped);assert dict(counts)==seed['counts'] and counts==Counter(frame=18,bracket=10,cog=15,insert=21)
        for i,j in combinations(mapped,2):
            if ss[i]!=ss[j]:continue
            seedpairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clear-1e-7
    families=['frame','bracket','cog','insert'];caps={f:parts[f]['quantity'] for f in families};areas=[Polygon(parts[f]['geometry'][0]['outer']).area for f in families];weights=[mp['area_weights'][f] for f in families]
    assert caps==mp['family_caps'] and weights==[round(a*1000) for a in areas]
    counts=list(product(*(range(caps[f]+1) for f in families)));assert len(counts)==86944
    assert sorted(counts,key=lambda c:sum(n*a for n,a in zip(c,areas)))==sorted(counts,key=lambda c:sum(n*w for n,w in zip(c,weights)))
    floor=min(seed['objective'] for seed in mp['seeds']);full=sum(mp['area_weights'][f]*caps[f] for f in families);max17=full-mp['area_weights']['frame']
    assert floor==4401740785 and full==4481740785 and max17==4324240785<floor
    assert all(sum(c[j]*weights[j] for j in range(4))<floor or c[0]==18 for c in counts)
    check={'passed':True,'seconds':time.perf_counter()-start,'complete_source_pool_exact':True,'original_job_target_caps_exact':True,'all_original_poses_directly_reconstructed':len(ids),'maximum_reconstruction_distance_mm':maxdistance,'maximum_reconstruction_area_mm2':maxarea,'small_and_frame_pair_possibilities':possible,'exact_pair_distances':near,'conflicts':edges,'conflicts_by_family_pair':dict(family_pairs),'every_binary_adjacency_row_independently_rebuilt':True,'both_64_seeds_identity_counts_full_graph_and_geometry_checked':True,'seed_same_sheet_pairs':seedpairs,'integer_objective_orders_all_original_count_combinations':len(counts),'seed_score':floor,'full_score':full,'maximum_score_with_17_frames':max17,'exact_18_frames_already_implied_by_original_floor':True,'native_margin_qualified':False}
    write(dst/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
