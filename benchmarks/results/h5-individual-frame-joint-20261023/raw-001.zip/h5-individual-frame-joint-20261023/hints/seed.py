"""Fresh family-relocation hints from both retained best original partials."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations
import shutil,time
from build_h5_individual_frame_joint import ROOT,OUT as BASE,load,write,digest,read_graph
RED=BASE/'reduced';OUT=BASE/'hints'
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    mp=load(RED/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=read_graph(RED/'adjacency.bin.gz',len(ids));weights=mp['area_weights'];caps=mp['family_caps'];family=[pool[i]['placement']['part_id'] for i in ids];poses=[pool[i]['placement'] for i in ids]
    orders=[]
    def coordinate(j,kind,reverse):
        p=poses[j];x,y=p['transform']['translation'];sheet=(p['sheet_id']=='sheet-1')^reverse
        if kind=='degree':return (adj[j].bit_count(),sheet,y,x,ids[j])
        return (sheet,-y if kind=='top-left' else y,-x if kind=='bottom-right' else x,ids[j])
    for f in permutations(caps):
        for kind in ['bottom-left','top-left','bottom-right','degree']:
            for reverse in [False,True]:
                rank={name:i for i,name in enumerate(f)};orders.append(({'families':list(f),'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:(rank[family[j]],coordinate(j,kind,reverse)))))
    for kind in ['area','degree-per-area']:
        for reverse in [False,True]:
            orders.append(({'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:((poses[j]['sheet_id']=='sheet-1')^reverse,-weights[family[j]] if kind=='area' else Fraction(adj[j].bit_count(),weights[family[j]]),adj[j].bit_count(),ids[j]))))
    starts=[{'source_seed':si,'remove_family':f,'indices':[local[i] for i in seed['selected_candidates'] if pool[i]['placement']['part_id']!=f]} for si,seed in enumerate(mp['mapped_seeds']) for f in [None,*caps]]
    cases=[(s,d,o) for s in starts for d,o in orders];assert len(orders)==196 and len(starts)==10 and len(cases)==1960
    inputs=[BASE/n for n in ['plan.json','candidates.json','audit/checks.json']]+[RED/n for n in ['mapping.json','adjacency.bin.gz','cliques.jsonl.gz','checks.json','substitutions.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_cases':1960,'ordering_specs':[d for d,o in orders],'starts':starts,'method':'For both newly mapped original seeds, retain all poses or remove each one of four families in turn. Greedily add compatible poses under each of 196 deterministic family/coordinate/sheet orders using the complete induced graph and original caps. Preserve all results and pending cases. Keep the best original-area mapped seed unless improved. This is a fresh bounded relocation census, not a solver retry.'})
    best={**load(RED/'best-hint.json'),'source':'mapped-original-seed'};baseline=best['objective'];hints=[];start=time.perf_counter()
    for initial,description,order in cases:
        if time.perf_counter()-start>=30:break
        chosen=initial['indices'].copy();counts=Counter(family[j] for j in chosen);mask=sum(1<<j for j in chosen)
        assert all(not(adj[j]&mask) for j in chosen)
        for j in order:
            if counts[family[j]]>=caps[family[j]] or (mask>>j)&1 or adj[j]&mask:continue
            chosen.append(j);mask|=1<<j;counts[family[j]]+=1
            if counts==caps:break
        row={'index':len(hints),'source':'fresh-family-relocation','source_seed':initial['source_seed'],'remove_family':initial['remove_family'],'ordering':description,'selected_candidates':sorted(ids[j] for j in chosen),'counts':dict(counts),'objective':sum(weights[family[j]] for j in chosen)};hints.append(row)
        if row['objective']>best['objective']:best=row
    elapsed=time.perf_counter()-start
    for r in hints+[best]:
        chosen=[local[i] for i in r['selected_candidates']];mask=sum(1<<j for j in chosen);counts=Counter(family[j] for j in chosen)
        assert len(chosen)==len(set(chosen)) and dict(counts)==r['counts'] and all(counts[f]<=caps[f] for f in caps) and all(not(adj[j]&mask) for j in chosen) and sum(weights[family[j]] for j in chosen)==r['objective']
    write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best);write(OUT/'pending.json',[{'source_seed':s['source_seed'],'remove_family':s['remove_family'],'ordering':d} for s,d,o in cases[len(hints):]])
    checks={'passed':True,'seconds':elapsed,'planned_cases':1960,'completed_cases':len(hints),'pending_cases':1960-len(hints),'limit_reached':elapsed>=30,'every_result_full_graph_counts_score_checked':True,'best_original_seed_objective':baseline,'best_original_seed_preserved':best['objective']>=baseline,'best_hint':{k:v for k,v in best.items() if k!='selected_candidates'},'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
