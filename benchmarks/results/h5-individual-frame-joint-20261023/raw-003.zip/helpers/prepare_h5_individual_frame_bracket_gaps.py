"""Fresh bracket insertion regions for the newly returned free-frame arrangement."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/check_h5_latest_wide_bracket_gaps.py').read_text(encoding='utf-8')
assert 'build_h5_latest_wide_joint' in s and 'h5-latest-wide-bracket-gaps-20261023' in s
s=s.replace('build_h5_latest_wide_joint','build_h5_individual_frame_joint').replace('h5-latest-wide-bracket-gaps-20261023','h5-individual-frame-bracket-gaps-20261023')
s=s.replace('Keep every returned 64-part placement exactly fixed.','Keep every placement of the newly returned free-frame 64-part arrangement exactly fixed. This arrangement has three frame poses absent from the earlier 29 frame groups and differs from the earlier wide-core gap check. No earlier gap query is resumed.')
with (ROOT/'output/check_h5_individual_frame_bracket_gaps.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared 16 fresh bracket placement queries for the changed 64-part geometry.')
