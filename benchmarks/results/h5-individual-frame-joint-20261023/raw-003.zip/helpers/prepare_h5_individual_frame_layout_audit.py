"""Prepare original-layout checks for four freely selected families."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
s=(ROOT/'output/audit_h5_expanded_frame_direct_layouts.py').read_text()
s=replace(s,"from build_h5_expanded_frame_joint import OUT as SOURCE,read_graph\nOUT=ROOT/'output/h5-expanded-frame-direct-search-20261023'",'from build_h5_individual_frame_joint import OUT,read_graph')
s=replace(s,"RED=SOURCE/'reduced'","RED=OUT/'reduced'")
s=replace(s,"load(SOURCE/","load(OUT/")
s=replace(s,"seed=sorted(mp['frame_groups'][best['frame_group']]['candidates']+best['selected_small_candidates'])","seed=best['selected_candidates']")
s=replace(s,"'frame_group':best['frame_group'],",'');s=replace(s,"'frame_group':result['frame_group'],",'')
s=replace(s,"chosen=r['selected_indices'];fixed=set(mp['frame_groups'][r['frame_group']]['candidates']);sm=set(chosen)-fixed", "chosen=r['selected_indices'];sm=set(chosen)")
s=replace(s,' and fixed<=set(chosen)','')
s=replace(s," and r['frame_group'] in mp['compatible_groups'][j]",'')
s=replace(s,"'frame_group':r['frame_group'],",'')
s=replace(s,"    for r in outcomes:","    previous=load(ROOT/'output/h5-expanded-frame-joint-20261023/mapping.json');previous_frames={i for g in previous['frame_groups'] for i in g['candidates']};previous_small=set(previous['candidates'])\n    for r in outcomes:")
s=replace(s,"'small_candidates_absent_previous_wide_model':sorted(sm-set(load(ROOT/'output/h5-latest-wide-joint-20261023/mapping.json')['candidates']))", "'new_individual_frame_poses_selected':sorted(i for i in sm if pool[i]['placement']['part_id']=='frame' and i not in previous_frames),'small_poses_unavailable_to_previous_groups':sorted(i for i in sm if pool[i]['placement']['part_id']!='frame' and i not in previous_small)")
path=ROOT/'output/audit_h5_individual_frame_layouts.py'
with path.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared original quantity, geometry, stock, material and frozen-CLI checks for every returned layout.')
