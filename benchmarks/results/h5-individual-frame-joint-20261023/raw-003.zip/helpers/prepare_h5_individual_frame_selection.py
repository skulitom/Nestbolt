"""Prepare four-family reduction and seed relocation without fixed frame groups."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/reduce_h5_expanded_frame_joint.py').read_text()
s=replace(s,'build_h5_expanded_frame_joint','build_h5_individual_frame_joint')
s=replace(s,', and compatible-groups(b) a subset of compatible-groups(a)','')
s=replace(s,'map the exact original 64-part seed','map both exact original 64-part layouts')
s=replace(s,";allowed=[sum(1<<g for g in groups) for groups in mp['compatible_groups']]",'')
s=replace(s,' and not(allowed[b]&~allowed[a])','')
s=replace(s,'certificate=groupcert=0','certificate=0')
s=replace(s,"        for g in mp['compatible_groups'][b]:\n            groupcert+=1;assert g in mp['compatible_groups'][a]\n",'')
s=replace(s,"remap={old:new for new,old in enumerate(kept)};projected=[sum(1<<remap[j] for j in bits(adj[i]) if j in ks) for i in kept];", "remap={old:new for new,old in enumerate(kept)};keptmask=sum(1<<j for j in kept);projected=[sum(1<<remap[j] for j in bits(adj[i]&keptmask)) for i in kept];")
start=s.index("    area=mp['area_weights'];");end=s.index('    remaining=projected.copy()',start)
s=s[:start]+'''    area=mp['area_weights'];seeds=[]
    for original in mp['seeds']:
        selected=sorted(replacements.get(i,i) for i in original['selected_indices']);chosen=[newlocal[i] for i in selected];mask=sum(1<<j for j in chosen);counts=Counter(pool[i]['placement']['part_id'] for i in selected)
        assert len(chosen)==len(set(chosen))==64 and dict(counts)==original['counts'] and all(not(projected[j]&mask) for j in chosen)
        score=sum(area[pool[i]['placement']['part_id']] for i in selected);assert score==original['objective']==4401740785
        seeds.append({'source':original['source'],'selected_candidates':selected,'counts':dict(counts),'objective':score})
    best=max(seeds,key=lambda r:r['objective']);write(OUT/'mapping.json',{**mp,'candidates':globals_kept,'seed_candidates':best['selected_candidates'],'mapped_seeds':seeds});write(OUT/'best-hint.json',best);write(OUT/'substitutions.json',removed)
''' +s[end:]
s=replace(s,"sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda j:((projected[j]&choices).bit_count(),-j));c.append(j);mask|=1<<j;choices&=projected[j]", "bit=choices&-choices;j=bit.bit_length()-1;c.append(j);mask|=bit;choices&=projected[j]")
s=replace(s,"'exact_64_seed_counts_group_and_full_graph_checked':True,'compatible_group_memberships_independently_certified':groupcert", "'both_exact_64_seed_counts_and_full_graph_checked':True")
s=replace(s,'then compress the exact induced graph.','then compress the exact induced graph with fresh lowest-index first-fit clique growth.')
put('reduce_h5_individual_frame_joint.py',s)
s=(ROOT/'output/seed_h5_latest_wide_joint.py').read_text()
s=replace(s,'build_h5_latest_wide_joint','build_h5_individual_frame_joint')
s=replace(s,"weights=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights'];caps={'bracket':12,'cog':15,'insert':21}","weights=mp['area_weights'];caps=mp['family_caps']")
s=replace(s,'selected_small_candidates','selected_candidates')
s=replace(s,'len(orders)==52 and len(starts)==8 and len(cases)==416','len(orders)==196 and len(starts)==10 and len(cases)==1960')
s=replace(s,"'maximum_cases':416","'maximum_cases':1960")
s=replace(s,'three families','four families');s=replace(s,'52 deterministic','196 deterministic')
s=replace(s,"'planned_cases':416","'planned_cases':1960");s=replace(s,"'pending_cases':416-len(hints)","'pending_cases':1960-len(hints)")
put('seed_h5_individual_frame_joint.py',s)
print('Prepared fresh four-family reduction and 1,960 bounded hint cases.')
