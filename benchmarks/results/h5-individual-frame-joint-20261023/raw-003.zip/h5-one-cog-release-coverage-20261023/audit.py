"""Two exact 64-part seeds: free one cog with every bracket and insert, retaining original acceptance."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,time
import numpy as np
import shapely
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_individual_frame_joint import ROOT,SRC,OUT as BASE,load,write,digest,read_graph
OUT=ROOT/'output/h5-one-cog-release-coverage-20261023'
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'layout-audit/checks.json')['passed'] and not load(BASE/'layout-audit/checks.json')['full_target_witness']
    mp=load(BASE/'mapping.json');paths=[ROOT/mp['seeds'][0]['source'],BASE/'layout-audit/layout-final.json']
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','adjacency.bin.gz','audit/checks.json','solve/result.json','layout-audit/checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]+paths
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'reason':'The complete four-family finite model reaches search but does not improve the 64-part floor; its full bound remains unresolved. The changed returned layout also admits no bracket from the 16 conservative insertion queries. Prepare a distinct local repair neighborhood that frees one of15 cogs together with every bracket and insert, for each of two exact 64-part layouts. The original full66-copy target and all material/geometry/production requirements remain unchanged. This coverage audit is not a solver retry or an acceptance substitute.','method':'For each exact seed, create each of15 fixed32-part cores consisting of all18 frames and14 cogs. Deduplicate exact fixed index sets. Derive every non-frame pose membership from the newly audited unconditioned full graph, including explicit exclusion of fixed poses themselves because diagonal graph bits are zero. Independently verify every membership by distance to the entire fixed-core polygon union on each sheet. Check every core pair and seed mapping, preserving the baseline at865,862,719 variable area units; full variable inventory1cog/12brackets/21inserts requires945,862,719. Every future solve must choose exactly one fixed core, preserve all original conflicts, and use a fresh compatibility-preserving reduction. No old group-filtered adjacency or reduction may be reused. The full original graph may be projected because it has independently checked every family pair.','solver_calls':0,'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=load(BASE/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];adj=read_graph(BASE/'adjacency.bin.gz',len(pool));assert mp['candidates']==list(range(len(pool)));keys={identity(p['placement']):i for i,p in enumerate(pool)};seeds=[];groups=[];byfixed={}
    for number,path in enumerate(paths):
        chosen=[]
        for p in load(path)['placements']:
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert p==pool[i]['placement'];chosen.append(i)
        assert len(chosen)==len(set(chosen))==64 and Counter(pool[i]['placement']['part_id'] for i in chosen)==Counter(frame=18,cog=15,bracket=10,insert=21)
        frame=sorted(i for i in chosen if pool[i]['placement']['part_id']=='frame');cogs=sorted(i for i in chosen if pool[i]['placement']['part_id']=='cog');sourcegroups=[]
        for released in cogs:
            fixed=sorted(frame+[i for i in cogs if i!=released]);k=tuple(fixed)
            if k not in byfixed:byfixed[k]=len(groups);groups.append({'index':len(groups),'fixed_candidates':fixed,'sources':[]})
            group=byfixed[k];groups[group]['sources'].append({'source_seed':number,'released_cog':released});sourcegroups.append(group)
        seeds.append({'source':path.relative_to(ROOT).as_posix(),'source_sha256':digest(path),'selected_indices':sorted(chosen),'core_groups':sourcegroups})
    gs=np.asarray([shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object);ss=np.asarray([p['placement']['sheet_id'] for p in pool]);small=[i for i,p in enumerate(pool) if p['placement']['part_id']!='frame'];compat={i:[] for i in small};corepairs=uniondistances=memberships=0
    for group in groups:
        fixed=group['fixed_candidates'];assert len(fixed)==32 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=14);blocked=sum(1<<i for i in fixed)
        for i in fixed:blocked|=adj[i]
        for i,j in combinations(fixed,2):
            if ss[i]!=ss[j]:continue
            corepairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clear-1e-7
        bygraph={i:not((blocked>>i)&1) for i in small}
        for sheet in ['sheet-0','sheet-1']:
            indices=[i for i in small if ss[i]==sheet];fixed_shapes=[gs[i] for i in fixed if ss[i]==sheet]
            if fixed_shapes:eligible=shapely.distance(gs[indices],unary_union(fixed_shapes))>=clear-1e-7;uniondistances+=len(indices)
            else:eligible=np.ones(len(indices),dtype=bool)
            for i,ok in zip(indices,eligible,strict=True):
                assert bool(ok)==bygraph[i];memberships+=1
                if ok:compat[i].append(group['index'])
    ids=[i for i in small if compat[i]];area={f:mp['area_weights'][f] for f in ['bracket','cog','insert']};caps={'bracket':12,'cog':1,'insert':21};mapped=[];seedpairs=0
    for seed in seeds:
        for groupid in seed['core_groups']:
            fixed=set(groups[groupid]['fixed_candidates']);variable=sorted(set(seed['selected_indices'])-fixed);counts=Counter(pool[i]['placement']['part_id'] for i in variable);assert counts==Counter(bracket=10,cog=1,insert=21) and all(groupid in compat[i] for i in variable);mask=sum(1<<i for i in variable);assert all(not(adj[i]&mask) for i in variable)
            score=sum(area[pool[i]['placement']['part_id']] for i in variable);assert score==865862719;mapped.append({'source':seed['source'],'core_group':groupid,'selected_variable_candidates':variable,'counts':dict(counts),'objective':score})
        for i,j in combinations(seed['selected_indices'],2):
            if ss[i]!=ss[j]:continue
            seedpairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clear-1e-7
    comparison=[]
    for family in ['frame','cog']:
        old=[i for i in seeds[0]['selected_indices'] if pool[i]['placement']['part_id']==family];new=[i for i in seeds[1]['selected_indices'] if pool[i]['placement']['part_id']==family];matches=[]
        for i in new:
            j=min(old,key=lambda j:gs[i].hausdorff_distance(gs[j]));matches.append({'current':i,'old':j,'distance_mm':gs[i].hausdorff_distance(gs[j]),'symmetric_difference_area_mm2':gs[i].symmetric_difference(gs[j]).area})
        comparison.append({'family':family,'nearest_matches_form_bijection':len({r['old'] for r in matches})==len(old),'maximum_distance_mm':max(r['distance_mm'] for r in matches),'maximum_symmetric_difference_area_mm2':max(r['symmetric_difference_area_mm2'] for r in matches),'matches':matches})
    full=sum(area[f]*caps[f] for f in caps);assert full==945862719
    write(OUT/'groups.json',groups);write(OUT/'filter.json',[{'candidate':i,'compatible_groups':compat[i]} for i in small]);write(OUT/'seed-comparison.json',comparison)
    write(OUT/'mapping.json',{'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'source_full_graph':(BASE/'adjacency.bin.gz').relative_to(ROOT).as_posix(),'source_graph_sha256':digest(BASE/'adjacency.bin.gz'),'candidates':ids,'compatible_groups':[compat[i] for i in ids],'core_groups':groups,'source_seeds':seeds,'mapped_seeds':mapped,'area_weights':area,'variable_family_caps':caps,'fixed_family_counts':{'frame':18,'cog':14}})
    check={'passed':True,'seconds':time.perf_counter()-start,'source_pool_size':len(pool),'source_full_graph_conflicts':load(BASE/'audit/checks.json')['conflicts'],'source_seeds':len(seeds),'planned_source_core_cases':30,'distinct_fixed_cores':len(groups),'all_cores_have_18_frames_and_14_cogs':True,'within_core_pairs_checked':corepairs,'independent_union_distances':uniondistances,'group_memberships_independently_checked':memberships,'fixed_poses_explicitly_excluded_from_variables':True,'eligible_variable_poses':len(ids),'eligible_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'mapped_complete_64_seeds':len(mapped),'seed_same_sheet_pairs':seedpairs,'seed_variable_objective':865862719,'full_variable_objective':full,'seed_geometry_comparison':[{k:v for k,v in r.items() if k!='matches'} for r in comparison],'new_group_filtered_graph_and_reduction_pending':True,'solver_calls':0,'new_poses_generated':0,'full_target_witness':False,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
