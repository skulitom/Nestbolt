"""One bounded four-family search with independent graph, model and parameter checks."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from hashlib import sha256
import gc,gzip,json,shutil,sys,time,ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-individual-frame-joint-20261023';RED=BASE/'reduced';HINT=BASE/'hints';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
def read_graph(path,n):
    width=(n+7)//8;result=[]
    with gzip.open(path,'rb') as f:
        for _ in range(n):
            data=f.read(width);assert len(data)==width;result.append(int.from_bytes(data,'little'))
        assert f.read(1)==b''
    return result
def main():
    audit=load(BASE/'audit/checks.json');assert audit['passed'] and load(RED/'checks.json')['passed'] and load(HINT/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    for p in [BASE/'plan.json',RED/'plan.json',HINT/'plan.json']:
        for name,h in load(p)['inputs'].items():assert digest(ROOT/name)==h
    mp=load(RED/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];n=len(ids);cliques=[];forward=[0]*n;pair_rows=0
    with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);assert len(row)>=2 and row==sorted(set(row)) and 0<=row[0]<=row[-1]<n
            if len(row)==2:i,j=row;forward[i]|=1<<j;pair_rows+=1
            else:cliques.append(row)
    original=read_graph(RED/'adjacency.bin.gz',n);reconstructed=[0]*n
    for row in cliques:
        mask=sum(1<<j for j in row)
        for j in row:reconstructed[j]|=mask^(1<<j)
    for i,mask in enumerate(forward):
        assert not(mask&((1<<(i+1))-1));reconstructed[i]|=mask
        for j in bits(mask):reconstructed[j]|=1<<i
    assert reconstructed==original and pair_rows==sum(v.bit_count() for v in forward)
    write(OUT/'encoding-audit.json',{'passed':True,'complete_original_graph_reconstructed':True,'original_pair_rows':pair_rows,'retained_larger_cliques':len(cliques),'implication_rows':sum(bool(v) for v in forward),'edges':sum(v.bit_count() for v in original)//2,'original_graph_sha256':digest(RED/'adjacency.bin.gz'),'original_constraints_sha256':digest(RED/'cliques.jsonl.gz')});del reconstructed,original
    names=['frame','bracket','cog','insert'];caps=mp['family_caps'];area=mp['area_weights'];families={f:[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==f] for f in names};weights=[area[pool[i]['placement']['part_id']] for i in ids];best=load(HINT/'best-hint.json');seed=set(best['selected_candidates']);hint=[int(i in seed) for i in ids]
    low=sum(w*v for w,v in zip(weights,hint));high=sum(area[f]*caps[f] for f in names);assert low==best['objective']>=4401740785 and high==4481740785 and audit['maximum_score_with_17_frames']<low
    domains={f:([caps[f],caps[f]] if f=='frame' else [0,caps[f]]) for f in names}
    model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in ids]
    for row in cliques:model.add_at_most_one(variables[j] for j in row)
    for i,mask in enumerate(forward):
        if mask:model.add_bool_and(variables[j].Not() for j in bits(mask)).only_enforce_if(variables[i])
    for f,js in families.items():model.add_linear_constraint(sum(variables[j] for j in js),*domains[f])
    expr=sum(weights[j]*variables[j] for j in range(n));model.add_linear_constraint(expr,low,high);model.maximize(expr)
    for j,v in enumerate(hint):model.add_hint(variables[j],v)
    assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'))
    expected=cp_model_pb2.CpModelProto()
    for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
    for row in cliques:expected.constraints.add().at_most_one.literals.extend(row)
    for i,mask in enumerate(forward):
        if mask:c=expected.constraints.add();c.enforcement_literal.append(i);c.bool_and.literals.extend(-j-1 for j in bits(mask))
    for f,js in families.items():c=expected.constraints.add().linear;c.vars.extend(js);c.coeffs.extend([1]*len(js));c.domain.extend(domains[f])
    c=expected.constraints.add().linear;c.vars.extend(range(n));c.coeffs.extend(weights);c.domain.extend([low,high]);expected.objective.vars.extend(range(n));expected.objective.coeffs.extend([-w for w in weights]);expected.objective.scaling_factor=-1;expected.solution_hint.vars.extend(range(n));expected.solution_hint.values.extend(hint)
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
    hintmask=sum(1<<j for j,v in enumerate(hint) if v);assert all(sum(hint[j] for j in row)<=1 for row in cliques) and all(not hint[i] or not(mask&hintmask) for i,mask in enumerate(forward))
    assert {f:sum(hint[j] for j in js) for f,js in families.items()}==best['counts'] and all(domains[f][0]<=best['counts'][f]<=domains[f][1] for f in names)
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=60;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0;solver.parameters.cp_model_presolve=False;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    expected_params=sat_parameters_pb2.SatParameters(max_time_in_seconds=60,num_search_workers=8,random_seed=0,cp_model_presolve=False,log_search_progress=True,log_to_stdout=False)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters()).SerializeToString(deterministic=True)==expected_params.SerializeToString(deterministic=True)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','audit/checks.json']]+[RED/n for n in ['plan.json','mapping.json','adjacency.bin.gz','cliques.jsonl.gz','checks.json','substitutions.json']]+[HINT/n for n in ['plan.json','best-hint.json','checks.json']]+[OUT/'encoding-audit.json']
    write(OUT/'model-audit.json',{'passed':True,'all_protobuf_fields_independently_reconstructed':True,'all_parameters_independently_reconstructed':True,'complete_hint_verified':True,'variables':n,'constraints':len(actual.constraints),'seed_score':low,'full_score':high,'frame_equality_already_implied_by_floor':True,'maximum_score_with_17_frames':audit['maximum_score_with_17_frames'],'cp_model_presolve':False,'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'model_format':'binary protobuf','ortools_version':ortools.__version__,'python_version':sys.version})
    records=[]
    def selected(value):return [i for j,i in enumerate(ids) if value(variables[j])]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen=selected(self.value);r={'index':len(records),'selected_indices':chosen,'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),'seconds':self.wall_time,'objective':self.objective_value,'best_bound':self.best_objective_bound};write(OUT/f"incumbent-{r['index']}.json",r);records.append(r);print({k:v for k,v in r.items() if k!='selected_indices'},flush=True)
    del cliques,forward,expected,actual;gc.collect();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':60,'maximum_calls':1,'cp_model_presolve':False})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
    result={'status':solver.status_name(status),'seconds':seconds,'incumbents':len(records),'best_bound':solver.best_objective_bound,'response_stats':solver.response_stats()}
    if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
        chosen=selected(solver.value);write(OUT/'selected-indices.json',chosen);result.update(counts=dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),objective=solver.objective_value)
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
