from pathlib import Path
from datetime import datetime,timezone
import json,psutil
ROOT=Path(__file__).resolve().parents[1]
p=psutil.Process(67628)
assert p.cmdline()==['python','output/audit_h5_corrected49_cog_capacity.py']
record={'utc':datetime.now(timezone.utc).isoformat(),'pid':p.pid,'cmdline':p.cmdline(),'cpu_user_seconds':p.cpu_times().user,
 'reason':'Stop this read-only checker to replace repeated pairwise checks within each color class with the exact equivalent bitset intersection. No feasibility search is repeated, no result is discarded, and the complete partial certificate will still be replayed.','completed':False}
out=ROOT/'output/h5-corrected49-cog-capacity-20261026/audit/interrupted.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
p.terminate();p.wait(timeout=10)
src=ROOT/'output/audit_h5_corrected49_cog_capacity.py';s=src.read_text(encoding='utf-8')
s=s.replace("OUT=BASE/'audit'","OUT=BASE/'audit-bitset'")
s=s.replace('available=remaining;c+=1;chosen=[]','available=remaining;c+=1;chosen=0')
s=s.replace('assert all(not ((adj[v]>>u)&1) for u in chosen);chosen.append(v)','assert not (adj[v]&chosen);chosen |= bit')
s=s.replace("result=load(BASE/'result.json');", "print({'graph_pairs_verified':pairs},flush=True)\nresult=load(BASE/'result.json');")
s=s.replace('node_total+=1','node_total+=1\n        if node_total%50000==0:print({\'certificate_nodes_replayed\':node_total},flush=True)')
with (ROOT/'output/audit_h5_corrected49_cog_capacity_bitset.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'previous_reader_stopped':True,'new_reader_created':True,'original_reader_and_interruption_preserved':True})
