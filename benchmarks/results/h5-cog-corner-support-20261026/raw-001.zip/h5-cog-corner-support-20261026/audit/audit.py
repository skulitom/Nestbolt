"""Read the tooth angular-gap certificate and every closed corner box exactly."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-corner-support-20261026';OUT=BASE/'audit'
OLD=ROOT/'output/h5-rotation-independent-geometry-20261026';EDGE=ROOT/'output/h5-cog-flat-edge-support-20261026';GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
additional=[ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',GEO/'fixed-source-rectangles.json',GEO/'mandatory17.json',ROOT/'output/h5-allocation-geometry-20261026/variants.json']
write(OUT/'inputs.json',{p.relative_to(ROOT).as_posix():digest(p) for p in additional})
proof=load(OLD/'original-cog-proof.json');p=load(BASE/'proof.json');job=load(additional[0]);cog=next(part for part in job['parts'] if part['id']=='cog')
cx,cy=map(F,proof['center']);v=[((F(x)-cx)*1000,(F(y)-cy)*1000) for x,y in cog['geometry'][0]['outer']]
assert v==[(F(*x)*1000,F(*y)*1000) for x,y in proof['centered_vertices_rational']]
hull=[(F(*x)*1000,F(*y)*1000) for x,y in proof['convex_hull_vertices_rational']];assert len(hull)==len(set(hull))==40 and all(a in v for a in hull)
rmin=p['original_hull_radius_lower_um'];rmax=p['original_radius_upper_um'];s=F(*p['maximum_angular_gap_sine_upper']);S=F(*p['half_gap_sine_upper']);C=F(*p['half_gap_cosine_lower'])
assert rmin==139999 and rmax==140001 and s==F(234,1000) and 0<S<F(1,2) and 0<C<1
assert all(x*x+y*y>=rmin*rmin for x,y in hull) and all(x*x+y*y<=rmax*rmax for x,y in v)
def face(a,b,z):return (b[0]-a[0])*(z[1]-a[1])-(b[1]-a[1])*(z[0]-a[0])
checks=0
for a,b in zip(hull,hull[1:]+hull[:1]):
    assert face(a,b,(0,0))>0 and all(face(a,b,z)>=0 for z in v)
    cross=a[0]*b[1]-a[1]*b[0];dot=a[0]*b[0]+a[1]*b[1]
    assert cross>0 and dot>0 and cross**2<=s*s*(a[0]**2+a[1]**2)*(b[0]**2+b[1]**2);checks+=1
# Convex ordered original vertices contain the origin, hence cover one full circle.
# Every rotated direction is within half the largest adjacent angular gap of a vertex.
# Positive dot restricts the gap below pi/2, so the squared sine comparison is sufficient.
assert s*s<4*S*S*(1-S*S) and C*C+S*S<1
P=p['original_simultaneous_support_pairs_um'];assert len(P)==3 and P[0][0]==P[0][1]
a=P[0][0];assert 2*a*a<=rmin*rmin*(1-s)<2*(a+1)**2
for (u,w),pair in zip([(F(4,5),F(3,5)),(F(3,5),F(4,5))],P[1:]):
    assert u*u+w*w==1 and 0<pair[0]<=rmin*(u*C-w*S)<pair[0]+1 and 0<pair[1]<=rmin*(w*C-u*S)<pair[1]+1
Q=p['rounded_simultaneous_support_pairs_um'];R=p['rounded_vertex_radius_strict_upper_um'];assert Q==[[x-2,y-2] for x,y in P] and R==rmax+2
fixed=load(BASE/'fixed-corner-boxes.json');moving=load(BASE/'moving-corner-boxes.json');rects=load(additional[1]);variants=load(additional[3]);boxes=0
def check_box_family(rect,records):
    global boxes
    x,y,xx,yy=rect;w=xx-x;h=yy-y;expected=[]
    for pi,(qx,qy) in enumerate(Q):
        lowx=max(0,R-w);lowy=max(0,R-h)
        if lowx>qx or lowy>qy:continue
        for sx,sy in [(1,1),(-1,1),(-1,-1),(1,-1)]:
            corner=[x if sx==1 else xx,y if sy==1 else yy]
            xb=sorted([corner[0]-sx*lowx,corner[0]-sx*qx]);yb=sorted([corner[1]-sy*lowy,corner[1]-sy*qy])
            expected.append({'support_pair':pi,'signs':[sx,sy],'corner_um':corner,'offset_range_um':[lowx,lowy,qx,qy],'closed_forbidden_box_um':[xb[0],yb[0],xb[1],yb[1]]})
            assert R-lowx<=w and R-lowy<=h and P[pi][0]-1>qx and P[pi][1]-1>qy;boxes+=1
    assert records==expected
assert len(fixed)==len(rects)==69
for row,r in zip(fixed,rects):
    assert row['source_rectangle_um']==r['bounds_um'] and row['fixed_rectangle_id']==r['id'] and row['sheet']==r['sheet'] and row['original_index']==r['original_index']
    check_box_family(r['bounds_um'],row['corner_boxes'])
expected=[(r['id'],i,b) for r in variants if r['family']=='bracket' for i,b in enumerate(r['coarse_rectangles_um'])];assert len(expected)==len(moving)==24
for row,(variant,component,b) in zip(moving,expected):
    assert row['variant']==variant and row['component']==component and row['source_rectangle_um']==b;check_box_family(b,row['corner_boxes'])
old=load(EDGE/'mask/cog-cell-table.json');kept=load(BASE/'cog-cell-table.json');removed=load(BASE/'removed-cells.json');rem={r['old_row']:r for r in removed};assert len(rem)==len(removed)
assert kept==[row for i,row in enumerate(old) if i not in rem]
domains={r['sheet']:r['domain_um'] for r in load(GEO/'cog-cell-covers.json')};corner_checks=0
for i,r in rem.items():
    sheet,gx,gy=old[i];x0,y0,x1,y1=domains[sheet];a=[x0+gx*10000,y0+gy*10000,min(x1,x0+(gx+1)*10000),min(y1,y0+(gy+1)*10000)]
    family=fixed[r['fixed_rectangle_record']];assert family['sheet']==sheet;b=family['corner_boxes'][r['corner_box']]['closed_forbidden_box_um']
    for x in [a[0],a[2]]:
        for y in [a[1],a[3]]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3];corner_checks+=1
prior=load(EDGE/'prior15-center-checks.json');saved=load(BASE/'prior15-checks.json');assert len(prior)==len(saved)==15
for row,sv in zip(prior,saved):
    assert sv=={'original_index':row['original_index'],'violations':[]};x,y=row['rounded_center_um'];sheet=row['sheet']
    for r in fixed:
        if r['sheet']!=sheet:continue
        for b in r['corner_boxes']:
            l,bt,rt,tp=b['closed_forbidden_box_um'];assert not(l<=x<=rt and bt<=y<=tp)
    x0,y0,_,_=domains[sheet];assert [sheet,(x-x0)//10000,(y-y0)//10000] in kept
write(OUT/'necessity-proof.json',{'all_real_rotations':True,'actual_source_vertices_only':True,'argument':'The40 certified convex-hull vertices are original source vertices around the origin, with radius at least139999um. Every adjacent angular gap is less thanpi/2 and has sine at most0.234. Thus, after any rotation, some original vertex lies within half that maximum gap of any chosen signed direction. The exact diagonal identity and rational3-4-5 direction bounds certify the listed simultaneous coordinate supports. Flooring the actual cog center changes each signed coordinate by less than1um; subtracting2 gives strict near-edge margins. Every listed corner offset is at least max(0,140003-rectangle-width) in its axis, so the actual vertex also lies strictly before each far edge. Therefore every center in a closed corner box places an actual original vertex strictly inside a source-contained rectangle, giving positive-area source overlap. The hull is used for angular coverage only, never as filled collision geometry. Removed closed cells lie wholly inside one such forbidden box; all remaining legal centers, including boundary sets, stay covered.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_vertices_verified':len(v),'exact_angular_gap_checks':checks,
 'all_real_rotations_without_angle_sampling':True,'simultaneous_support_pairs_verified':P,'corner_boxes_verified':boxes,
 'fixed_rectangles_verified':69,'moving_components_verified':24,'removed_cells_verified':len(removed),'exact_cell_corner_checks':corner_checks,
 'retained_cells_verified':len(kept),'all15_prior_cells_retained':True,'filled_hull_not_used':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
