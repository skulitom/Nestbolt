"""All-angle actual-tooth corner occupancy, with exact rational prerequisites."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-corner-support-20261026'
OLD=ROOT/'output/h5-rotation-independent-geometry-20261026';EDGE=ROOT/'output/h5-cog-flat-edge-support-20261026';GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[OLD/'original-cog-proof.json',OLD/'audit/checks.json',EDGE/'fixed49-support-strips.json',EDGE/'moving-bracket-support-strips.json',
 EDGE/'mask/cog-cell-table.json',EDGE/'mask/audit/checks.json',GEO/'cog-cell-covers.json',EDGE/'prior15-center-checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
 'method':'For all real rotations, certify an actual outer tooth vertex near any prescribed direction using the maximum angular gap of the40 original convex-hull vertices. Exact radius/cross/dot inequalities prove three simultaneous signed-coordinate support pairs. Account for rounded-center error and each rectangle far edge, giving closed forbidden corner boxes, distinct from the earlier one-axis edge strips. Only actual source vertices establish collision; never treat the filled hull or a virtual disk as source geometry. Build complete fixed/moving corner boxes and remove a prior closed cog-center cell only when every corner is in one certified closed forbidden box. No solver or native call.'})
proof=load(OLD/'original-cog-proof.json');vertices=[(F(*x)*1000,F(*y)*1000) for x,y in proof['centered_vertices_rational']];hull=[(F(*x)*1000,F(*y)*1000) for x,y in proof['convex_hull_vertices_rational']]
rmin=139999;rmax=140001;gap_sin=F(234,1000);half_sin=F(3,25);half_cos=F(124,125)
assert all(rmin*rmin<=x*x+y*y<=rmax*rmax for x,y in hull) and all(p in vertices for p in hull)
for a,b in zip(hull,hull[1:]+hull[:1]):
    cross=a[0]*b[1]-a[1]*b[0];dot=a[0]*b[0]+a[1]*b[1]
    assert cross>0 and dot>0 and cross*cross<=gap_sin**2*(a[0]**2+a[1]**2)*(b[0]**2+b[1]**2)
assert gap_sin**2<4*half_sin**2*(1-half_sin**2) and half_cos**2+half_sin**2<1
diagonal=math.isqrt((rmin*rmin*(1-gap_sin)/2).__floor__())
px=(rmin*(F(4,5)*half_cos-F(3,5)*half_sin)).__floor__();py=(rmin*(F(3,5)*half_cos-F(4,5)*half_sin)).__floor__()
pairs=[[diagonal,diagonal],[px,py],[py,px]];R=rmax+2
write(OUT/'proof.json',{'source_vertices':80,'source_hull_vertices':40,'original_hull_radius_lower_um':rmin,'original_radius_upper_um':rmax,
 'maximum_angular_gap_sine_upper':[gap_sin.numerator,gap_sin.denominator],'half_gap_sine_upper':[half_sin.numerator,half_sin.denominator],
 'half_gap_cosine_lower':[half_cos.numerator,half_cos.denominator],'original_simultaneous_support_pairs_um':pairs,
 'rounded_simultaneous_support_pairs_um':[[x-2,y-2] for x,y in pairs],'rounded_vertex_radius_strict_upper_um':R})
def boxes(rect):
    x,y,xx,yy=rect;w=xx-x;h=yy-y;out=[]
    for pi,(px,py) in enumerate(pairs):
        dx0=max(0,R-w);dy0=max(0,R-h);dx1=px-2;dy1=py-2
        if dx0>dx1 or dy0>dy1:continue
        for sx,sy in [(1,1),(-1,1),(-1,-1),(1,-1)]:
            corner=[x if sx==1 else xx,y if sy==1 else yy]
            xb=sorted([corner[0]-sx*dx0,corner[0]-sx*dx1]);yb=sorted([corner[1]-sy*dy0,corner[1]-sy*dy1])
            out.append({'support_pair':pi,'signs':[sx,sy],'corner_um':corner,'offset_range_um':[dx0,dy0,dx1,dy1],'closed_forbidden_box_um':[xb[0],yb[0],xb[1],yb[1]]})
    return out
fixed=[];moving=[]
for r in load(EDGE/'fixed49-support-strips.json'):
    fixed.append({k:r[k] for k in ['fixed_rectangle_id','original_index','sheet','source_rectangle_um']}|{'corner_boxes':boxes(r['source_rectangle_um'])})
for r in load(EDGE/'moving-bracket-support-strips.json'):
    moving.append({k:r[k] for k in ['variant','component','source_rectangle_um']}|{'corner_boxes':boxes(r['source_rectangle_um'])})
write(OUT/'fixed-corner-boxes.json',fixed);write(OUT/'moving-corner-boxes.json',moving)
old=load(EDGE/'mask/cog-cell-table.json');domains={r['sheet']:r['domain_um'] for r in load(GEO/'cog-cell-covers.json')};retained=[];removed=[]
for index,(sheet,gx,gy) in enumerate(old):
    x0,y0,x1,y1=domains[sheet];box=[x0+gx*10000,y0+gy*10000,min(x1,x0+(gx+1)*10000),min(y1,y0+(gy+1)*10000)];hit=None
    for ri,r in enumerate(fixed):
        if r['sheet']!=sheet:continue
        for bi,b in enumerate(r['corner_boxes']):
            a,c,d,e=b['closed_forbidden_box_um']
            if a<=box[0] and c<=box[1] and box[2]<=d and box[3]<=e:hit=[ri,bi];break
        if hit is not None:break
    if hit is None:retained.append([sheet,gx,gy])
    else:removed.append({'old_row':index,'fixed_rectangle_record':hit[0],'corner_box':hit[1]})
write(OUT/'removed-cells.json',removed);write(OUT/'cog-cell-table.json',retained)
prior=[]
for p in load(EDGE/'prior15-center-checks.json'):
    px,py=p['rounded_center_um'];violations=[]
    for ri,r in enumerate(fixed):
        if r['sheet']!=p['sheet']:continue
        for bi,b in enumerate(r['corner_boxes']):
            x,y,xx,yy=b['closed_forbidden_box_um']
            if x<=px<=xx and y<=py<=yy:violations.append([ri,bi])
    prior.append({'original_index':p['original_index'],'violations':violations})
write(OUT/'prior15-checks.json',prior)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'simultaneous_original_support_pairs_um':pairs,'fixed_corner_boxes':sum(len(r['corner_boxes']) for r in fixed),
 'moving_corner_boxes':sum(len(r['corner_boxes']) for r in moving),'old_cells':len(old),'removed_cells':len(removed),'new_cells':len(retained),
 'new_cells_by_sheet':[sum(s==i for s,x,y in retained) for i in [0,1]],'prior15_violations':sum(len(r['violations']) for r in prior),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
