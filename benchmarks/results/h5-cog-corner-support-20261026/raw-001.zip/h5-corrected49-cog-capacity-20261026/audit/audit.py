"""Independent integer graph and exhaustive certificate reader; no search."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-corrected49-cog-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
mask=load(ROOT/'output/h5-cog-flat-edge-support-20261026/mask/cog-cell-table.json');D=254297;assert plan['distance_um']==D
domains={r['sheet']:r['domain_um'] for r in load(ROOT/'output/h5-corrected49-joint-geometry-20261026/cog-cell-covers.json')}
graphs={};pairs=0;cell_count=0
for sheet in [0,1]:
    g=load(BASE/f'sheet-{sheet}.json');cells=g['cells_um'];adj=[int(s,16) for s in g['adjacency_hex']];domain=domains[sheet]
    assert g['domain_um']==domain and g['grid_indices']==[[x,y] for s,x,y in mask if s==sheet]
    assert len(cells)==len(adj)==len(g['grid_indices']);x0,y0,x1,y1=domain;n=len(cells)
    for i,((gx,gy),a) in enumerate(zip(g['grid_indices'],cells)):
        assert a==[x0+gx*10000,y0+gy*10000,min(x1,x0+(gx+1)*10000),min(y1,y0+(gy+1)*10000)]
        assert (a[2]-a[0])**2+(a[3]-a[1])**2 < D*D and not ((adj[i]>>i)&1)
        assert adj[i]>>n==0
        for j in range(i):
            b=cells[j];dx=max(abs(a[0]-b[2]),abs(a[2]-b[0]));dy=max(abs(a[1]-b[3]),abs(a[3]-b[1]));compatible=dx*dx+dy*dy>=D*D
            assert bool((adj[i]>>j)&1)==compatible==bool((adj[j]>>i)&1);pairs+=1
    graphs[sheet]=adj;cell_count+=len(cells)
result=load(BASE/'result.json');assert result['closed'] and result['external_solver_calls']==result['native_calls']==0
node_total=clique_pairs=0;bounds={};positive=[]
for row in result['results']:
    if row['status']=='NOT_STARTED_BUDGET':continue
    saved=load(BASE/f"sheet-{row['sheet']}-target-{row['target']}.json");assert saved['result']==row
    adj=graphs[row['sheet']];n=len(adj);nodes=saved['nodes'];assert len(nodes)==row['certificate_nodes']
    for ix,node in enumerate(nodes):
        p=int(node['candidates_hex'],16);k=node['required'];assert p>>n==0 and k>=1
        # Reconstruct the deterministic independent-set coloring and also certify each color.
        remaining=p;order=[];colors=[];c=0
        while remaining:
            available=remaining;c+=1;chosen=[]
            while available:
                v=(available&-available).bit_length()-1;bit=1<<v
                assert all(not ((adj[v]>>u)&1) for u in chosen);chosen.append(v)
                order.append(v);colors.append(c);remaining ^= bit;available ^= bit;available &= ~adj[v]
        assert sum(1<<v for v in order)==p and len(order)==len(set(order))
        remaining=p;bi=0;cut=0
        for i in range(len(order)-1,-1,-1):
            if colors[i]<k:cut=i+1;break
            assert bi<len(node['branches']);v,child=node['branches'][bi];bi+=1
            assert v==order[i] and isinstance(child,int) and 0<=child<ix
            sub=nodes[child];assert sub['required']==k-1 and int(sub['candidates_hex'],16)==(remaining&adj[v])
            remaining &= ~(1<<v)
        assert bi==len(node['branches']) and cut==node['pruned_prefix']
        if cut:assert max(colors[:cut])<k
        node_total+=1
    if row['status']=='TARGET_EXCLUDED':
        root=nodes[saved['root']];assert int(root['candidates_hex'],16)==(1<<n)-1 and root['required']==row['target']
        assert row['upper_bound']==row['target']-1 and row['cell_clique'] is None;bounds[row['sheet']]=row['upper_bound']
    elif row['status']=='CELL_CLIQUE_FOUND':
        witness=row['cell_clique'];assert len(witness)==len(set(witness))==row['target']
        for a,b in combinations(witness,2):assert 0<=a<n and 0<=b<n and (adj[a]>>b)&1;clique_pairs+=1
        positive.append({'sheet':row['sheet'],'size':len(witness)})
    else:assert row['status']=='UNKNOWN_BUDGET' and saved['root'] is None and row['cell_clique'] is None and row['upper_bound'] is None
assert not result['source_or_point_witness'] and not result['fixed49_excluded'] and not result['all66_witness']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_cells_verified':cell_count,'exact_cell_pair_checks':pairs,
 'certificate_nodes_replayed':node_total,'cell_clique_pair_checks':clique_pairs,'proved_upper_bounds_by_sheet':bounds,
 'necessary_cell_cliques':positive,'source_or_point_witness':False,'fixed49_excluded':False,'full66_witness':False,
 'all_real_cog_angles_retained':True,'external_solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
