"""Bound cog counts using the complete corrected-source closed-cell cover."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-corrected49-cog-capacity-20261026'
MASK=ROOT/'output/h5-cog-flat-edge-support-20261026/mask';GEOM=ROOT/'output/h5-corrected49-joint-geometry-20261026'
PAIR=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=start+60;distance=254297
inputs=[MASK/'cog-cell-table.json',MASK/'audit/checks.json',GEOM/'cog-cell-covers.json',GEOM/'audit/checks.json',PAIR]
assert load(MASK/'audit/checks.json')['passed'] and load(GEOM/'audit/checks.json')['passed'] and load(PAIR)['passed']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
 'maximum_shared_seconds':60,'maximum_expanded_nodes':200000,'retry_permitted':False,'distance_um':distance,
 'targets':[[1,4],[0,13],[0,14],[0,15]],'method':'Use the independently verified complete corrected49 flat-edge cog-center cell cover. For each sheet connect two cells exactly if their maximum squared point distance is at least254297^2. Each cell has smaller diameter, so any source placement of k cogs entails a k-clique. First audit short4, then first13,14,15 until a target is excluded or the common60-second/node cap is reached. Deterministic independent-set coloring and exhaustive include branches provide replayable exclusion certificates; a found cell clique is never a continuous or source witness. Store compact certificates whose coloring is recomputed by the reader. No external solver, changed pose, orientation restriction or native validation.'})
rows=load(MASK/'cog-cell-table.json');domains={d['sheet']:d['domain_um'] for d in load(GEOM/'cog-cell-covers.json')}
graphs={};cellsets={};expanded_total=0;results=[]
class Limit(Exception):pass
for sheet in [1,0]:
    domain=domains[sheet];x0,y0,x1,y1=domain;indices=[[x,y] for s,x,y in rows if s==sheet]
    cells=np.array([[x0+x*10000,y0+y*10000,min(x1,x0+(x+1)*10000),min(y1,y0+(y+1)*10000)] for x,y in indices],dtype=np.int64)
    adj=[]
    for i,a in enumerate(cells):
        dx=np.maximum(abs(a[0]-cells[:,2]),abs(a[2]-cells[:,0]));dy=np.maximum(abs(a[1]-cells[:,3]),abs(a[3]-cells[:,1]));mask=dx*dx+dy*dy>=distance*distance;assert not mask[i]
        adj.append(int.from_bytes(np.packbits(mask,bitorder='little').tobytes(),'little'))
    graphs[sheet]=adj;cellsets[sheet]=cells
    write(OUT/f'sheet-{sheet}.json',{'sheet':sheet,'domain_um':domain,'grid_indices':indices,'cells_um':cells.tolist(),'distance_um':distance,'adjacency_hex':[hex(v) for v in adj]})
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'vertices_by_sheet':{s:len(g) for s,g in graphs.items()},'all_rows_preserved':True})
excluded=set()
for sheet,target in [[1,4],[0,13],[0,14],[0,15]]:
    if sheet in excluded:continue
    if time.perf_counter()>deadline:results.append({'sheet':sheet,'target':target,'status':'NOT_STARTED_BUDGET'});continue
    adj=graphs[sheet];n=len(adj);nodes=[];cache={};expanded=0;begin=time.perf_counter()
    def color(p):
        order=[];colors=[];c=0;remaining=p
        while remaining:
            c+=1;available=remaining
            while available:
                bit=available&-available;v=bit.bit_length()-1;order.append(v);colors.append(c);remaining^=bit;available^=bit;available &= ~adj[v]
        return order,colors
    def solve(p,k):
        global expanded_total,expanded
        if time.perf_counter()>deadline or expanded_total>=200000:raise Limit()
        if k==1 and p:return [(p&-p).bit_length()-1],None
        key=(p,k)
        if key in cache:return None,cache[key]
        expanded_total+=1;expanded+=1;order,colors=color(p);branches=[];remaining=p;cut=0
        for i in range(len(order)-1,-1,-1):
            if colors[i]<k:cut=i+1;break
            v=order[i];answer,child=solve(remaining&adj[v],k-1)
            if answer is not None:return [v]+answer,None
            branches.append([v,child]);remaining &= ~(1<<v)
        rec={'candidates_hex':hex(p),'required':k,'pruned_prefix':cut,'branches':branches};ix=len(nodes);nodes.append(rec);cache[key]=ix;return None,ix
    try:
        witness,root=solve((1<<n)-1,target);status='CELL_CLIQUE_FOUND' if witness is not None else 'TARGET_EXCLUDED'
    except Limit:witness=root=None;status='UNKNOWN_BUDGET'
    record={'sheet':sheet,'target':target,'status':status,'expanded_nodes':expanded,'certificate_nodes':len(nodes),'search_seconds':time.perf_counter()-begin,
            'cell_clique':witness,'upper_bound':target-1 if status=='TARGET_EXCLUDED' else None}
    if status=='TARGET_EXCLUDED':excluded.add(sheet)
    write(OUT/f'sheet-{sheet}-target-{target}.json',{'result':record,'root':root,'nodes':nodes})
    results.append(record);print({k:v for k,v in record.items() if k!='cell_clique'},flush=True)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'closed':True,'expanded_nodes':expanded_total,'results':results,
 'source_or_point_witness':False,'fixed49_excluded':False,'all66_witness':False,'external_solver_calls':0,'native_calls':0,'H5_complete':False})
