"""Translate saved partials minimally to accommodate the unchanged native margins; no packing search."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import copy,itertools,json,math,shutil,sys,traceback
import numpy as np
from scipy.optimize import linprog
from shapely.geometry import Polygon
from shapely.affinity import affine_transform,translate
from shapely.ops import nearest_points
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-native-collision-observer-20261018'
OUT=ROOT/'output/h5-native-partial-spacing-20261018';EPS=.001;MAX_MOVE=2.;MAX_ITERATIONS=20
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def pose(g,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(g,[m*c,-s,m*s,c,*t['translation']])
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'space.py')
    plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'native_shape_and_container_source':str(PRIOR),
        'positive_native_gap_mm':EPS,'maximum_coordinate_translation_mm':MAX_MOVE,'maximum_contact_iterations':MAX_ITERATIONS,
        'method':'Minimize the largest absolute translation with a linear program. Keep rotations, copies and sheet assignments unchanged. Native polygon stock bounds constrain every part. At each iteration add a separating normal from the closest original outer points for pairs whose shifted native polygons have less than 0.001 mm separation; require original distance at least native model separation plus that margin. Recheck every shifted native pair and container, record each LP and constraint. This local contact linearization is only a construction; infeasibility or iteration exhaustion is not a global geometric proof. Verify actual native reconstruction afterward.',
        'packing_calls':0,'repair_calls':0,'unchanged_conversion_guard':True,'completion_claim':False}
    write(OUT/'plan.json',plan);records=[]
    try:
        for item in load(PRIOR/'plan.json')['cases']:
            src=PRIOR/'runs'/item['case'];folder=OUT/item['case'];folder.mkdir()
            data=load(src/'geometry.json');fixture=load(src/'fixture.json');job=fixture['job'];partial=fixture['partial']
            ob=next(o for o in data['observations'] if o['input']=='partial');n=len(partial['placements'])
            pieces={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']};native=[None]*n;original=[None]*n;sheet_of=[None]*n
            containers={};bounds=[None]*(2*n)+[(0,MAX_MOVE)];rows=[];rhs=[];constraints=[]
            for sheet in ob['per_sheet']:
                container=Polygon(sheet['container_physical_vertices']);containers[sheet['sheet']]=container;left,bottom,right,top=container.bounds
                for p in sheet['items']:
                    i=p['original_placement_index'];native[i]=Polygon(p['physical_vertices']);original[i]=pose(pieces[p['part_id']],partial['placements'][i]['transform']);sheet_of[i]=sheet['sheet']
                    a,b,c,d=native[i].bounds
                    bounds[2*i]=(left+EPS-a,right-EPS-c);bounds[2*i+1]=(bottom+EPS-b,top-EPS-d)
                    for coordinate in [2*i,2*i+1]:
                        for sign in [-1.,1.]:
                            row=np.zeros(2*n+1);row[coordinate]=sign;row[-1]=-1;rows.append(row);rhs.append(0.)
            assert all(p is not None for p in native) and all(x is not None for x in bounds)
            shifts=np.zeros((n,2));history=[];success=False;previous_constraint_keys=set()
            pairs=[(i,j) for i,j in itertools.combinations(range(n),2) if sheet_of[i]==sheet_of[j]]
            for iteration in range(MAX_ITERATIONS):
                shifted=[translate(p,*shifts[i]) for i,p in enumerate(native)];physical=[translate(p,*shifts[i]) for i,p in enumerate(original)]
                bad=[(i,j) for i,j in pairs if shifted[i].distance(shifted[j])<EPS-1e-8]
                outside=[i for i,p in enumerate(shifted) if not containers[sheet_of[i]].buffer(-EPS+1e-8,join_style='mitre').covers(p)]
                if not bad and not outside:success=True;break
                added=0
                for i,j in bad:
                    a,b=nearest_points(physical[i],physical[j]);dx=b.x-a.x;dy=b.y-a.y;distance=math.hypot(dx,dy)
                    if distance<1e-9:raise RuntimeError('Local correction made physical originals intersect; do not invent a contact normal.')
                    normal=np.array([dx/distance,dy/distance]);required=data['model_separation']+EPS-distance+float(normal@(shifts[j]-shifts[i]))
                    key=(i,j,round(float(normal[0]),10),round(float(normal[1]),10),round(required,10))
                    if key in previous_constraint_keys:continue
                    previous_constraint_keys.add(key);row=np.zeros(2*n+1);row[2*i:2*i+2]=normal;row[2*j:2*j+2]=-normal
                    rows.append(row);rhs.append(-required);constraints.append({'iteration':iteration,'a':i,'b':j,'normal':normal.tolist(),'required_relative_projection_mm':required,'original_distance_mm':distance});added+=1
                objective=np.zeros(2*n+1);objective[-1]=1
                solution=linprog(objective,A_ub=np.asarray(rows),b_ub=np.asarray(rhs),bounds=bounds,method='highs',options={'time_limit':30.})
                event={'iteration':iteration,'native_contacts_before':len(bad),'outside_before':len(outside),'added_constraints':added,
                    'status':int(solution.status),'message':solution.message,'success':bool(solution.success),
                    'max_translation_coordinate_mm':None if solution.x is None else float(solution.x[-1]),
                    'shifts':None if solution.x is None else solution.x[:-1].reshape(n,2).tolist()}
                history.append(event);write(folder/f'iteration-{iteration:02}.json',event)
                if not solution.success:break
                shifts=solution.x[:-1].reshape(n,2)
            shifted=[translate(p,*shifts[i]) for i,p in enumerate(native)]
            native_min=min(a.distance(b) for i,a in enumerate(shifted) for j,b in enumerate(shifted) if i<j and sheet_of[i]==sheet_of[j])
            native_outside=sum(p.difference(containers[sheet_of[i]]).area for i,p in enumerate(shifted))
            # The final iteration may have obtained a feasible result at its limit.
            success=success or (native_min>=EPS-1e-8 and native_outside<=1e-9)
            adjusted=copy.deepcopy(partial)
            for i,p in enumerate(adjusted['placements']):p['transform']['translation']=[p['transform']['translation'][j]+float(shifts[i,j]) for j in range(2)]
            original_min=min(translate(original[i],*shifts[i]).distance(translate(original[j],*shifts[j])) for i,j in pairs)
            record={'case':item['case'],'success':success,'partial_count':n,'missing_parts':dict(Counter({p['id']:p['quantity'] for p in job['parts']})-Counter(p['part_id'] for p in partial['placements'])),
                'native_pair_count':len(pairs),'predicted_native_min_gap_mm':native_min,'predicted_native_outside_mm2':native_outside,
                'original_min_gap_mm':original_min,'max_coordinate_translation_mm':float(np.abs(shifts).max()),
                'iterations':len(history),'constraints':len(constraints),'rotations_reflections_sheets_and_copies_unchanged':True,
                'actual_native_zero_loss_verified':False,'complete_original_quantities':False}
            write(folder/'checks.json',record);write(folder/'constraints.json',constraints);write(folder/'layout.json',adjusted)
            adjusted_fixture={**fixture,'partial':adjusted}
            # Keep original deliberate proposal for comparison; only partial is translated.
            write(folder/'fixture.json',adjusted_fixture);write(folder/'source.json',{'geometry_sha256':digest(src/'geometry.json'),'fixture_sha256':digest(src/'fixture.json')})
            records.append(record);print(json.dumps(record),flush=True)
        write(OUT/'checks.json',{'complete':True,'cases':records,'native_verification_pending':True,'new_quality_runs':0})
    except Exception as e:
        write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed':records});raise
if __name__=='__main__':main()
