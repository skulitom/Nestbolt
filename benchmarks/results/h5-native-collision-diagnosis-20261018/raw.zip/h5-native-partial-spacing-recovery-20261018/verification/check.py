"""Verify adjusted partials with the unchanged native observer and original public request."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import copy,itertools,json,math,os,psutil,shutil,subprocess,sys,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-native-partial-spacing-recovery-20261018'
PRIOR=ROOT/'output/h5-native-collision-observer-20261018';DEST=OUT/'verification'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygon(part,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);points=[]
    for x,y in part['geometry'][0]['outer']:
        if t['mirrored']:x=-x
        points.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
    return Polygon(points)
def main():
    DEST.mkdir();shutil.copyfile(__file__,DEST/'check.py');records=[]
    binary=PRIOR/'observer-tests.exe';build=load(PRIOR/'build.json');assert digest(binary)==build['binary_sha256']
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    psutil.Process().cpu_affinity([8]);assert psutil.Process().cpu_affinity()==[8]
    write(DEST/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'binary_sha256':digest(binary),'cpu':[8],
        'note':'The extra 0.001 mm construction cushion was not reached within 20 iterations. Do not relabel those failures. These new inputs still have positive predicted native gaps; check actual native zero loss independently under unchanged settings.',
        'new_packing_calls':0,'new_repair_calls':0})
    try:
        for row in load(OUT/'checks.json')['cases']:
            case=row['case'];src=OUT/case;folder=DEST/case;folder.mkdir();fixture=load(src/'fixture.json');job=fixture['job'];layout=fixture['partial']
            old=load(PRIOR/'runs'/case/'fixture.json')['partial'];parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
            assert len(layout['placements'])==len(old['placements'])
            grouped=[[],[]];max_shift=0.
            for a,b in zip(layout['placements'],old['placements']):
                ta=a['transform'];tb=b['transform'];assert {k:v for k,v in a.items() if k!='transform'}=={k:v for k,v in b.items() if k!='transform'}
                assert ta['rotation_radians']==tb['rotation_radians'] and ta['mirrored']==tb['mirrored']
                max_shift=max(max_shift,*(abs(ta['translation'][j]-tb['translation'][j]) for j in range(2)))
                g=polygon(parts[a['part_id']],ta);assert g.is_valid;i=int(a['sheet_id'][-1]);x0,y0,x1,y1=g.bounds
                assert x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7 and x1<=stock['width']-m['right']-edge+1e-7
                assert y1<=[stock['height'],fixture['target_used_height_mm']][i]-m['top']-edge+1e-7
                grouped[i].append(g)
            pairs=0;minimum=math.inf
            for group in grouped:
                for a,b in itertools.combinations(group,2):
                    pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                    assert a.disjoint(b) and distance>=job['clearance']-1e-7
            env=os.environ.copy();assert not env.get('NESTBOLT_SIMPLIFY')
            env['NESTBOLT_COLLISION_FIXTURE']=str(src/'fixture.json');env['NESTBOLT_COLLISION_OUTPUT']=str(folder/'geometry.json')
            command=[str(binary),'--exact',load(PRIOR/'plan.json')['test'],'--ignored','--nocapture','--test-threads=1']
            with (folder/'native.log').open('xb') as log:r=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
            write(folder/'native-command.json',{'command':command,'exit_code':r.returncode,'fixture_sha256':digest(src/'fixture.json')})
            assert r.returncode==0
            native=load(folder/'geometry.json');obs=next(o for o in native['observations'] if o['input']=='partial')
            losses=[s['loss_details']['total_loss'] for s in obs['per_sheet']]+[obs['joined_pinned_loss']]
            publicsrc=ROOT/'output/h5-pattern-joint-probe-20261018/inputs'/case
            command=[str(cli),'validate','--library',str(publicsrc/'library.json'),'--request',str(publicsrc/'request.json'),'--layout',str(src/'layout.json')]
            r=subprocess.run(command,capture_output=True,timeout=60);(folder/'public.json').write_bytes(r.stdout);(folder/'public.stderr').write_bytes(r.stderr)
            write(folder/'public-command.json',{'command':command,'exit_code':r.returncode});report=json.loads(r.stdout)
            expected=Counter({p['id']:p['quantity'] for p in job['parts']});counts=Counter(p['part_id'] for p in layout['placements']);missing=expected-counts
            assert r.returncode!=0 and not report['valid'] and report['metrics'] is None and missing
            assert len(report['violations'])==len(missing) and all(v['code']=='quantity' for v in report['violations'])
            assert {v['message'] for v in report['violations']}=={f'part {k}: expected {expected[k]}, found {counts[k]}' for k in missing}
            for name in ['before','proposal']:
                newob=next(o for o in native['observations'] if o['input']==name)
                oldob=next(o for o in load(PRIOR/'runs'/case/'geometry.json')['observations'] if o['input']==name)
                assert newob==oldob
            record={'case':case,'native_sheet_and_joined_losses':losses,'actual_native_zero_loss':all(v==0 for v in losses),
                'geometry_pairs':pairs,'original_minimum_clearance_mm':minimum,'max_coordinate_translation_mm':max_shift,
                'rotations_reflections_assignments_copies_unchanged':True,'native_other_inputs_exact':True,
                'original_public_only_missing_quantity_rejection':True,'missing':dict(missing),'complete_layout':False,
                'extra_construction_cushion_reached':row['success'],'native_geometry_sha256':digest(folder/'geometry.json')}
            write(folder/'checks.json',record);records.append(record);print(json.dumps(record),flush=True)
        write(DEST/'checks.json',{'complete':True,'cases':records,'native_zero_loss_partials':sum(r['actual_native_zero_loss'] for r in records),
            'complete_layouts':0,'new_packing_calls':0,'new_repair_calls':0})
    except Exception as e:
        write(DEST/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed':records});raise
if __name__=='__main__':main()
