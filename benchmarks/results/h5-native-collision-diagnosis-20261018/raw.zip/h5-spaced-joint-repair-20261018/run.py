"""Test the unchanged joint helper after removing measured native-margin collisions from partial inputs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import copy,importlib.util,json,os,psutil,shutil,subprocess,time,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-spaced-joint-repair-20261018'
SPACED=ROOT/'output/h5-native-partial-spacing-recovery-20261018';OLD=ROOT/'output/h5-pattern-joint-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');checks=load(SPACED/'verification/checks.json')
    assert checks['native_zero_loss_partials']==4 and checks['complete_layouts']==0
    binary=OLD/'native-tests.exe';assert digest(binary)==load(OLD/'native-recovery-build.json')['binary_sha256']
    cli=OLD/'public-checks/nestbolt-validator.exe'
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'binary_sha256':digest(binary),'original_inputs':str(OLD),
        'adjusted_inputs':str(SPACED),'partial_verification_sha256':digest(SPACED/'verification/checks.json'),
        'changed_input':'Only previously placed partial copies receive the independently verified sub-0.18 mm translations. Restore the same missing original copies at their already-saved deliberate poses; do not rerun pose selection.',
        'seed':0,'work_seconds_each':12.,'cpu':[8],'cases':[c['case'] for c in checks['cases']],
        'runtime_changed':False,'quality_runs':0,'original_failed_repairs_preserved':True}
    write(OUT/'plan.json',plan);records=[];psutil.Process().cpu_affinity([8]);assert psutil.Process().cpu_affinity()==[8]
    spec=importlib.util.spec_from_file_location('audit',ROOT/'output/audit_h5_pattern_joint_witness_verified.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
    try:
        for case in plan['cases']:
            folder=OUT/case;folder.mkdir();old=load(OLD/'inputs'/case/'fixture.json');fixture=load(SPACED/case/'fixture.json');partial=fixture['partial']
            missing=old['proposal']['placements'][len(old['partial']['placements']):]
            proposal=copy.deepcopy(partial);proposal['placements'].extend(copy.deepcopy(missing));fixture['proposal']=proposal
            assert Counter(p['part_id'] for p in proposal['placements'])==Counter({p['id']:p['quantity'] for p in fixture['job']['parts']})
            assert proposal['placements'][:len(partial['placements'])]==partial['placements'] and fixture['before']==old['before']
            write(folder/'fixture.json',fixture);write(folder/'proposal.json',proposal)
            physical=audit.geometry(fixture['job'],proposal,fixture['target_used_height_mm'],True,False)
            assert physical['conflicts']>0
            publicsrc=OLD/'inputs'/case
            command=[str(cli),'validate','--library',str(publicsrc/'library.json'),'--request',str(publicsrc/'request.json'),'--layout',str(folder/'proposal.json')]
            cp=subprocess.run(command,capture_output=True,timeout=60);(folder/'proposal-public.json').write_bytes(cp.stdout);(folder/'proposal-public.stderr').write_bytes(cp.stderr)
            write(folder/'proposal-command.json',{'command':command,'exit_code':cp.returncode});public=json.loads(cp.stdout)
            assert cp.returncode!=0 and not public['valid'] and {v['code'] for v in public['violations']}<={'overlap','clearance','total_overlap'}
            env=os.environ.copy();assert not env.get('NESTBOLT_SIMPLIFY')
            env['NESTBOLT_JOINT_FIXTURE']=str(folder/'fixture.json');env['NESTBOLT_JOINT_OUTPUT']=str(folder/'result.json')
            command=[str(binary),'--exact',load(OLD/'native-plan.json')['diagnostic_test'],'--ignored','--nocapture','--test-threads=1']
            write(folder/'native-command.json',{'command':command,'fixture_sha256':digest(folder/'fixture.json'),'cpu':[8]})
            start=time.perf_counter()
            with (folder/'native.log').open('xb') as log:cp=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100)
            wall=time.perf_counter()-start;r=load(folder/'result.json')
            write(folder/'native-exit.json',{'exit_code':cp.returncode,'wall_seconds':wall,'result_sha256':digest(folder/'result.json')})
            assert cp.returncode==0
            before=next(x for x in r['native_loss_observations'] if x['input']=='partial')
            assert before['joined_pinned_loss']==0 and all(s['loss']==0 for s in before['per_sheet'])
            after_check=None
            if r['success']:
                after_check=audit.geometry(fixture['job'],r['after'],fixture['target_used_height_mm'],True,True)
                assert after_check['filled_material_mm2']<=fixture['target_material_mm2']+1e-7
                write(folder/'after.json',r['after']);command=[str(cli),'validate','--library',str(publicsrc/'library.json'),'--request',str(publicsrc/'request.json'),'--layout',str(folder/'after.json')]
                cp=subprocess.run(command,capture_output=True,timeout=60);(folder/'after-public.json').write_bytes(cp.stdout);(folder/'after-public.stderr').write_bytes(cp.stderr)
                write(folder/'after-command.json',{'command':command,'exit_code':cp.returncode});report=json.loads(cp.stdout)
                assert cp.returncode==0 and report['valid'] and report['metrics']['material_area']<=fixture['target_material_mm2']
            else:assert r['after'] is None and r['after_report'] is None
            record={'case':case,'partial_native_loss_zero':True,'success':r['success'],'work_seconds':r['finished']-r['started'],
                'wall_seconds':wall,'joint_attempts':r['stats'].get('joint_repair_attempts',0),'completed':r['stats'].get('joint_repair_completed',0),
                'expired':r['stats'].get('joint_repair_expired',0),'failed':r['stats'].get('joint_repair_failed',0),
                'proposal_geometry':physical,'after_geometry':after_check,'same_missing_poses_reused':True}
            write(folder/'checks.json',record);records.append(record);print(json.dumps({k:record[k] for k in ['case','partial_native_loss_zero','success','expired','failed','work_seconds']}),flush=True)
        write(OUT/'checks.json',{'complete':True,'cases':records,'complete_target_layouts':sum(r['success'] for r in records),
            'packing_quality_runs':0,'native_helper_calls':4,'unchanged_budget_and_seed':True})
    except Exception as e:
        write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed':records});raise
if __name__=='__main__':main()
