"""Use exact f32 accumulation for tracker totals; retain the original audit and reuse completed geometry checks."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-native-collision-observer-20261018'
old=ROOT/'output/audit_h5_native_collision_geometry.py';new=ROOT/'output/audit_h5_native_collision_geometry_recovery.py'
assert (OUT/'audit/failure.json').exists() and not new.exists() and not (OUT/'audit-recovery').exists()
text=old.read_text(encoding='utf-8').replace('import gzip,itertools,json,math,shutil,sys,traceback','import gzip,itertools,json,math,shutil,struct,sys,traceback')
text=text.replace("AUDIT=OUT/'audit'","AUDIT=OUT/'audit-recovery'")
helper='''def f32_sum(values):
    result=0.0
    for value in values:result=struct.unpack('<f',struct.pack('<f',result+value))[0]
    return result
def exact_loss_check(loss):
    pairs={(p['a'],p['b']):p['loss'] for p in loss['pairs']}
    assert f32_sum([p['loss'] for p in loss['pairs']]+[p['static_loss'] for p in loss['items']])==loss['total_loss']
    for i,p in enumerate(loss['items']):
        total=f32_sum(pairs.get((min(i,j),max(i,j)),0.) for j in range(len(loss['items'])))
        assert f32_sum([total,p['static_loss']])==p['total_loss']

'''
text=text.replace('def main():',helper+'def main():')
needle="            assert digest(folder/'geometry.json')==case['geometry_sha256']"
text=text.replace(needle,needle+'''
            for observation in data['observations']:
                for sheet in observation['per_sheet']:exact_loss_check(sheet['loss_details'])
            completed=OUT/'audit'/(case['case']+'.json')
            if completed.exists():
                record=load(completed);records.append(record)
                for p in [completed,OUT/'audit'/(case['case']+'-pairs.jsonl.gz')]:
                    shutil.copyfile(p,AUDIT/p.name)
                print(json.dumps({'case':case['case'],'completed_geometry_audit_reused':True,'exact_f32_loss_check':True}),flush=True)
                continue''')
text=text.replace("                        assert abs(summed-loss['total_loss'])<=max(1e-6,loss['total_loss']*1e-6)","                        assert f32_sum(list(reported.values())+[p['static_loss'] for p in loss['items']])==loss['total_loss']")
text=text.replace("                            assert abs(total-p['total_loss'])<=max(1e-6,p['total_loss']*1e-6)","                            exact_loss_check(loss)")
new.write_text(text,encoding='utf-8',newline='\n')
record={'cause':'The auditor added exact native f32 entries in Python binary64; on the last case, accumulated rounding exceeded the arbitrary 1e-6 relative comparison.',
    'correction':'Reproduce the actual native f32 accumulation order and require exact equality for every item and total. Reuse the first three completed geometry audits byte-for-byte, after verifying their raw tracker totals exactly. Complete only the fourth geometry audit. No native observer, repair or packing reruns.',
    'original_audit_failure_sha256':sha256((OUT/'audit/failure.json').read_bytes()).hexdigest(),
    'completed_geometry_files':{p.name:sha256(p.read_bytes()).hexdigest() for p in (OUT/'audit').iterdir() if p.is_file() and p.name.startswith('m-') and (p.name.endswith('.json') or (OUT/'audit'/(p.name.removesuffix('-pairs.jsonl.gz')+'.json')).exists())},
    'new_auditor_sha256':sha256(new.read_bytes()).hexdigest(),'new_native_calls':0}
with (OUT/'audit-recovery-plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'prepared':True,'exact_native_arithmetic':True}))
