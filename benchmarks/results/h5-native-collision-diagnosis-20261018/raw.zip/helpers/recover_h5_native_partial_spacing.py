"""Retain the local linearization failure and add an original-geometry line search."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/space_h5_native_partials.py';new=ROOT/'output/space_h5_native_partials_recovery.py'
failed=ROOT/'output/h5-native-partial-spacing-20261018'
assert (failed/'failure.json').exists() and not new.exists()
text=old.read_text(encoding='utf-8').replace("OUT=ROOT/'output/h5-native-partial-spacing-20261018'","OUT=ROOT/'output/h5-native-partial-spacing-recovery-20261018'")
text=text.replace("'method':'Minimize", "'retained_first_failure':str(ROOT/'output/h5-native-partial-spacing-20261018'),\n        'recovery':'The first linear solution violates a different original contact. Backtrack each proposed translation until all actual original pairs preserve the requested clearance; retain the first LP solution and use it once, then add newly active contact normals.',\n        'method':'Minimize")
needle="                solution=linprog(objective,A_ub=np.asarray(rows),b_ub=np.asarray(rhs),bounds=bounds,method='highs',options={'time_limit':30.})"
replacement="""                prior=ROOT/'output/h5-native-partial-spacing-20261018'/item['case']/f'iteration-{iteration:02}.json'
                if iteration==0 and prior.exists():
                    from types import SimpleNamespace
                    saved=load(prior)
                    solution=SimpleNamespace(status=saved['status'],message=saved['message'],success=saved['success'],
                        x=np.r_[np.asarray(saved['shifts']).flatten(),saved['max_translation_coordinate_mm']])
                    assert np.max(np.asarray(rows)@solution.x-np.asarray(rhs))<1e-6
                    reused_first=True
                else:
                    solution=linprog(objective,A_ub=np.asarray(rows),b_ub=np.asarray(rhs),bounds=bounds,method='highs',options={'time_limit':30.})
                    reused_first=False"""
assert needle in text;text=text.replace(needle,replacement)
needle="                shifts=solution.x[:-1].reshape(n,2)"
replacement="""                proposed=solution.x[:-1].reshape(n,2);alpha=1.;accepted=None
                for backtrack in range(25):
                    trial=shifts+alpha*(proposed-shifts)
                    geoms=[translate(p,*trial[i]) for i,p in enumerate(original)]
                    if all(geoms[i].distance(geoms[j])>=job['clearance']-1e-7 and geoms[i].disjoint(geoms[j]) for i,j in pairs):
                        accepted=trial;break
                    alpha*=.5
                write(folder/f'line-search-{iteration:02}.json',{'reused_original_LP':reused_first,
                    'fraction':alpha,'accepted':accepted is not None,'pairs_checked':len(pairs),
                    'shifts':None if accepted is None else accepted.tolist()})
                if accepted is None:break
                shifts=accepted"""
assert needle in text;text=text.replace(needle,replacement)
new.write_text(text,encoding='utf-8',newline='\n')
with (failed/'recovery-plan.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_failure_sha256':sha256((failed/'failure.json').read_bytes()).hexdigest(),
        'first_linear_solution_sha256':sha256((failed/'m-mechanical-large-plates-k0.2-s0-candidate/iteration-00.json').read_bytes()).hexdigest(),
        'recovery_source_sha256':sha256(new.read_bytes()).hexdigest(),'original_solution_reused':True,'native_calls':0},f,indent=2);f.write('\n')
print(json.dumps({'prepared':True,'original_failure_preserved':True}))
