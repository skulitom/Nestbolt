"""Observe four pinned saved fixtures once each, with no packing or repair calls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,psutil,shutil,subprocess,time,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-native-collision-observer-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(OUT/'plan.json');build=load(OUT/'build.json');binary=OUT/'observer-tests.exe'
assert build['exit_code']==0 and digest(binary)==build['binary_sha256']
for p,h in plan['changed_files'].items():assert digest(OUT/'candidate'/p)==h
runs=OUT/'runs';runs.mkdir();psutil.Process().cpu_affinity([8]);assert psutil.Process().cpu_affinity()==[8]
shutil.copyfile(__file__,OUT/'run.py');write(runs/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'binary_sha256':digest(binary),'cpu':[8],'search_calls':0})
records=[]
try:
    for case in plan['cases']:
        folder=runs/case['case'];folder.mkdir();src=Path(case['fixture']);assert digest(src)==case['fixture_sha256']
        fixture=folder/'fixture.json';shutil.copyfile(src,fixture)
        env=os.environ.copy();assert not env.get('NESTBOLT_SIMPLIFY')
        env['NESTBOLT_COLLISION_FIXTURE']=str(fixture);env['NESTBOLT_COLLISION_OUTPUT']=str(folder/'geometry.json')
        command=[str(binary),'--exact',plan['test'],'--ignored','--nocapture','--test-threads=1']
        write(folder/'command.json',{'command':command,'fixture_sha256':digest(fixture),'cpu':[8]})
        start=time.perf_counter()
        with (folder/'test.log').open('xb') as log:r=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
        record={'case':case['case'],'exit_code':r.returncode,'wall_seconds':time.perf_counter()-start,'log_sha256':digest(folder/'test.log')}
        if (folder/'geometry.json').exists():record['geometry_sha256']=digest(folder/'geometry.json')
        write(folder/'check.json',record);records.append(record)
        assert r.returncode==0 and '1 passed; 0 failed' in (folder/'test.log').read_text(encoding='utf-8')
        data=load(folder/'geometry.json');assert data['no_separation_called'] and len(data['observations'])==3
        print(json.dumps({'case':case['case'],'observed':True,'before_joined_loss':data['observations'][0]['joined_pinned_loss'],
            'partial_joined_loss':data['observations'][1]['joined_pinned_loss'],'seconds':record['wall_seconds']}),flush=True)
    write(runs/'checks.json',{'complete':True,'cases':records,'packing_calls':0,'repair_calls':0})
except Exception as e:
    write(runs/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed':records});raise
