"""Append test-only geometry and collision decomposition observers; no search or runtime change."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-pattern-joint-probe-20261018/candidate-recovery'
OUT=ROOT/'output/h5-native-collision-observer-20261018';WORK=OUT/'candidate';TARGET=ROOT/'output/h5-native-collision-target-20261018'
EXCHANGE='crates/core/src/sheets/vstrip/exchange.rs';SEPARATE='crates/core/src/separate.rs'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not OUT.exists() and not TARGET.exists();OUT.mkdir();shutil.copytree(OLD,WORK)
assert digest(OLD/EXCHANGE)=='2463471d4b7107109623f47049f3d74d27334bbc908643262eef9d10f3679a6b'
append=r'''
// BEGIN read-only saved-geometry diagnostic. Never compiled into runtime builds.
#[cfg(test)]
pub(crate) fn saved_geometry_loss_details(tracker: &Tracker, layout: &Layout) -> serde_json::Value {
    let keys:Vec<_>=layout.placed_items().keys().collect();
    let mut items=vec![];let mut pairs=vec![];
    for (i,&key) in keys.iter().enumerate() {
        let index=tracker.index[key];
        items.push(serde_json::json!({"index":i,"total_loss":tracker.loss(key),
            "static_loss":tracker.statics[index].loss}));
        for (j,&other) in keys.iter().enumerate().skip(i) {
            let loss=tracker.pairs[tracker.pair(index,tracker.index[other])].loss;
            if loss>0.0 {pairs.push(serde_json::json!({"a":i,"b":j,"loss":loss}));}
        }
    }
    serde_json::json!({"total_loss":tracker.total_loss(),"items":items,"pairs":pairs})
}
// END read-only saved-geometry diagnostic.
'''
old_separate=(OLD/SEPARATE).read_text(encoding='utf-8');(WORK/SEPARATE).write_text(old_separate+append,encoding='utf-8',newline='\n')
tests=r'''
    // BEGIN saved native collision geometry: observation only, no separation.
    #[test]
    #[ignore = "explicit read-only saved geometry diagnostic"]
    fn saved_native_collision_geometry_diagnostic() {
        let fixture_path=std::env::var("NESTBOLT_COLLISION_FIXTURE").unwrap();
        let output_path=std::env::var("NESTBOLT_COLLISION_OUTPUT").unwrap();
        let input:serde_json::Value=serde_json::from_slice(&std::fs::read(fixture_path).unwrap()).unwrap();
        let job:Job=serde_json::from_value(input["job"].clone()).unwrap();
        let model=Model::new(&job).unwrap();
        let guard=conversion_guard(&job);let sep=(job.clearance+guard)/0.05_f64.cos();
        let expand=(job.clearance+guard)/2.0+sep/2.0-(job.edge_clearance+guard);
        let m=job.stocks[0].margins;let target=input["target_used_height_mm"].as_f64().unwrap();
        let exact_last=target-m.bottom-m.top+2.0*expand;let mut target_last=exact_last as f32;
        if f64::from(target_last)>exact_last {target_last=f32::from_bits(target_last.to_bits()-1);}
        let clock=Clock::new(Timing::Work,60.0);
        let strip=Strip{model:&model,gap:2.0,clock:clock.clone(),containers:Default::default()};
        let physical=|shape:&jagua_rs::geometry::primitives::SPolygon|shape.vertices().iter()
            .map(|p|model.inverse.apply([f64::from(p.0),f64::from(p.1)])).collect::<Vec<_>>();
        let internal=|shape:&jagua_rs::geometry::primitives::SPolygon|shape.vertices().iter()
            .map(|p|[f64::from(p.0),f64::from(p.1)]).collect::<Vec<_>>();
        let templates:Vec<_>=model.instance.items.iter().map(|(item,_)|{
            let pre=item.shape_orig().pre_transform;
            serde_json::json!({"item_index":item.idx(),"part_id":job.parts[model.part[item.idx()]].id,
                "original_vertices":internal(&item.shape_orig().shape),"collision_vertices":internal(item.shape_cd()),
                "pre_translation":[f64::from(pre.translation().0),f64::from(pre.translation().1)],
                "pre_rotation":f64::from(pre.rotation()),"pre_reflected":pre.reflected,
                "offset":item.shape_orig().modify_config.offset,
                "simplify_tolerance":item.shape_orig().modify_config.simplify_tolerance})
        }).collect();
        let mut observations=vec![];
        for name in ["before","partial","proposal"] {
            let layout:Layout=serde_json::from_value(input[name].clone()).unwrap();
            let sheets=model.sheets_of(&layout).unwrap();assert_eq!(sheets.len(),2);
            let last=if name=="before" {model.full_width} else {target_last};
            let mut per_sheet=vec![];
            for (i,sheet) in sheets.iter().enumerate() {
                let shape=Shape{sheets:1,last:if i==0 {model.full_width} else {last}};
                let mut local=JLayout::new(strip.container(shape).unwrap());
                for p in sheet.layout().placed_items().values() {local.place_item(p.item(),p.d_transf());}
                let native=Separator::new(local,0,EXPLORE,clock.clone());
                let mut items=vec![];
                for (index,p) in native.layout.placed_items().values().enumerate() {
                    let dt=p.d_transf();let part_index=model.part[p.item().idx()];
                    let matches:Vec<_>=layout.placements.iter().enumerate().filter(|(_,original)|{
                        if original.sheet_id!=layout.sheets[i].id || original.part_id!=job.parts[part_index].id {return false;}
                        let expected=model.internal(p.item().idx(),&original.transform);
                        expected.translation()==dt.translation() && expected.rotation()==dt.rotation() && expected.reflected==dt.reflected
                    }).collect();assert_eq!(matches.len(),1);
                    items.push(serde_json::json!({"index":index,"original_placement_index":matches[0].0,
                        "part_id":job.parts[part_index].id,"copy_index":matches[0].1.copy_index,
                        "item_index":p.item().idx(),"native_transform":{"rotation":f64::from(dt.rotation()),
                            "translation":[f64::from(dt.translation().0),f64::from(dt.translation().1)],"reflected":dt.reflected},
                        "native_external_transform":model.external(p.item().idx(),&dt),
                        "internal_vertices":internal(p.shape()),"physical_vertices":physical(p.shape())}));
                }
                per_sheet.push(serde_json::json!({"sheet":i,"items":items,
                    "container_internal_vertices":internal(native.layout.container().outer_cd()),
                    "container_physical_vertices":physical(native.layout.container().outer_cd()),
                    "loss_details":crate::separate::saved_geometry_loss_details(&native.tracker,&native.layout)}));
            }
            let whole=strip.layout(&sheets,Shape{sheets:2,last}).unwrap();
            let mut joined=Separator::new(whole,0,EXPLORE,clock.clone());joined.pin(blocker_index(&model));
            observations.push(serde_json::json!({"input":name,"per_sheet":per_sheet,
                "joined_pinned_loss":joined.tracker.total_loss()}));
        }
        let record=serde_json::json!({"job":job,"templates":templates,"observations":observations,
            "conversion_guard_mm":guard,"model_separation":f64::from(model.separation),
            "model_frame":{"m":model.frame.m,"t":model.frame.t},
            "model_inverse":{"m":model.inverse.m,"t":model.inverse.t},
            "model_full_width":f64::from(model.full_width),"target_internal_exact":exact_last,
            "target_internal_rounded_down":f64::from(target_last),"no_separation_called":true,"work":clock.counts()});
        use std::io::Write;
        let mut file=std::fs::OpenOptions::new().write(true).create_new(true).open(output_path).unwrap();
        file.write_all(&serde_json::to_vec_pretty(&record).unwrap()).unwrap();file.write_all(b"\n").unwrap();
        eprintln!("SAVED_NATIVE_COLLISION_GEOMETRY observations=3 search_calls=0");
    }
    // END saved native collision geometry diagnostic.
'''
old_exchange=(OLD/EXCHANGE).read_text(encoding='utf-8');pos=old_exchange.rindex('\n}')
(WORK/EXCHANGE).write_text(old_exchange[:pos]+'\n'+tests+old_exchange[pos:],encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=WORK,check=True)
files=[{'path':p.relative_to(OLD).as_posix(),'sha256':digest(p)} for p in sorted(OLD.rglob('*')) if p.is_file()]
for row in files:
    rel=row['path']
    if rel not in [EXCHANGE,SEPARATE]:assert digest(WORK/rel)==row['sha256']
current=(WORK/EXCHANGE).read_text(encoding='utf-8');assert current.startswith(old_exchange[:pos]) and current.endswith(old_exchange[pos:])
assert (WORK/SEPARATE).read_text(encoding='utf-8').startswith(old_separate)
for rel in [EXCHANGE,SEPARATE]:
    (OUT/(Path(rel).stem+'.patch')).write_text(''.join(difflib.unified_diff((OLD/rel).read_text(encoding='utf-8').splitlines(True),(WORK/rel).read_text(encoding='utf-8').splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)),encoding='utf-8',newline='\n')
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
inputs=ROOT/'output/h5-pattern-joint-probe-20261018/inputs'
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_source':str(OLD),'source_files':files,
    'changed_files':{r:digest(WORK/r) for r in [EXCHANGE,SEPARATE]},'all_runtime_unchanged':True,'all_prior_tests_exact':True,
    'production_digest':source_digest(),'target':str(TARGET),'native_cpu':[8],'search_or_repair_calls':0,
    'test':'sheets::vstrip::exchange::tests::saved_native_collision_geometry_diagnostic',
    'cases':[{'case':p.parent.name,'fixture':str(p),'fixture_sha256':digest(p)} for p in sorted(inputs.glob('*/fixture.json'))]})
shutil.copyfile(__file__,OUT/'prepare.py');print(json.dumps({'prepared':True,'source_files':len(files),'runtime_changed':False,'new_searches':0}))
