"""Reconstruct native polygons from original vertices and classify every recorded pair/boundary loss."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,itertools,json,math,shutil,sys,traceback
from shapely.geometry import Polygon
from shapely.affinity import affine_transform,translate
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-native-collision-observer-20261018';AUDIT=OUT/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def pose(g,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(g,[m*c,-s,m*s,c,*t['translation']])
def native_pose(g,t):
    c,s=math.cos(t['rotation']),math.sin(t['rotation']);m=-1 if t['reflected'] else 1
    return affine_transform(g,[c,-m*s,s,m*c,*t['translation']])
def main():
    AUDIT.mkdir();shutil.copyfile(__file__,AUDIT/'audit.py');records=[]
    try:
        plan=load(OUT/'plan.json');run=load(OUT/'runs/checks.json');assert run['complete']
        assert source_digest()==plan['production_digest']
        parent=Path(plan['old_source']);work=OUT/'candidate'
        for row in plan['source_files']:
            assert digest(parent/row['path'])==row['sha256']
            if row['path'] not in plan['changed_files']:assert digest(work/row['path'])==row['sha256']
        for rel,h in plan['changed_files'].items():
            assert digest(work/rel)==h;old=(parent/rel).read_text(encoding='utf-8');new=(work/rel).read_text(encoding='utf-8')
            if rel.endswith('exchange.rs'):
                pos=old.rindex('\n}');assert new.startswith(old[:pos]) and new.endswith(old[pos:])
            else:assert new.startswith(old)
        for case in run['cases']:
            folder=OUT/'runs'/case['case'];data=load(folder/'geometry.json');fixture=load(folder/'fixture.json')
            assert digest(folder/'geometry.json')==case['geometry_sha256']
            pinned=next(r for r in plan['cases'] if r['case']==case['case']);assert digest(folder/'fixture.json')==pinned['fixture_sha256']
            job=fixture['job'];parts={p['id']:p for p in job['parts']};base={k:Polygon(v['geometry'][0]['outer']) for k,v in parts.items()}
            templates={t['item_index']:t for t in data['templates']};guard=data['conversion_guard_mm'];gap=job['clearance'];separation=data['model_separation']
            template_checks=[]
            for t in templates.values():
                g=Polygon(t['original_vertices']);cd=Polygon(t['collision_vertices']);assert g.is_valid and cd.is_valid
                raw_error=g.hausdorff_distance(base[t['part_id']]);assert raw_error<guard
                assert t['pre_rotation']==0 and not t['pre_reflected'] and t['simplify_tolerance'] is None
                assert abs(t['offset']-separation/2)<1e-7
                ideal=translate(g,*t['pre_translation']).buffer(t['offset'],quad_segs=128)
                error=ideal.hausdorff_distance(cd);assert error<guard
                template_checks.append({'part':t['part_id'],'raw_vertices_error_mm':raw_error,'offset_model_error_mm':error,'native_offset_mm':t['offset']})
            observations=[];events=[]
            with gzip.open(AUDIT/(case['case']+'-pairs.jsonl.gz'),'xt',encoding='utf-8',newline='\n') as pairs_file:
                for ob in data['observations']:
                    layout=fixture[ob['input']];sheet_results=[]
                    for sheet in ob['per_sheet']:
                        items=sheet['items'];loss=sheet['loss_details'];container=Polygon(sheet['container_physical_vertices']);assert container.is_valid
                        actual=[];original=[];ideal=[];without_guard=[];item_records=[]
                        for i,p in enumerate(items):
                            assert p['index']==i and loss['items'][i]['index']==i
                            src=layout['placements'][p['original_placement_index']]
                            assert src['part_id']==p['part_id'] and src['copy_index']==p['copy_index'] and src['sheet_id']==layout['sheets'][sheet['sheet']]['id']
                            poly=pose(base[p['part_id']],src['transform']);external=pose(base[p['part_id']],p['native_external_transform'])
                            cd=Polygon(p['physical_vertices']);local=Polygon(p['internal_vertices']);t=templates[p['item_index']]
                            predicted=native_pose(Polygon(t['collision_vertices']),p['native_transform'])
                            local_error=local.hausdorff_distance(predicted);pose_error=poly.hausdorff_distance(external)
                            assert cd.is_valid and local.is_valid and local_error<guard and pose_error<guard
                            expected=poly.buffer(t['offset'],quad_segs=128);offset_error=cd.hausdorff_distance(expected);assert offset_error<guard
                            actual.append(cd);original.append(poly);ideal.append(expected)
                            without_guard.append(poly.buffer(gap/(2*math.cos(.05)),quad_segs=128))
                            outside=cd.difference(container).area;static=loss['items'][i]['static_loss']
                            item_records.append({'index':i,'part':p['part_id'],'copy':p['copy_index'],'pose_roundtrip_error_mm':pose_error,
                                'native_vertex_transform_error_mm':local_error,'native_offset_model_error_mm':offset_error,
                                'outside_container_mm2':outside,'static_loss':static,'static_positive_without_polygon_outside':static>0 and outside==0,
                                'outside_without_static_loss':outside>1e-7 and static==0})
                        reported={(p['a'],p['b']):p['loss'] for p in loss['pairs']};assert all(a<b for a,b in reported)
                        counter=Counter();positive=[];pair_count=0
                        for a,b in itertools.combinations(range(len(items)),2):
                            pair_count+=1;distance=original[a].distance(original[b]);native_distance=actual[a].distance(actual[b]);overlap=actual[a].intersection(actual[b]).area
                            reported_loss=reported.get((a,b),0.);original_overlap=original[a].intersection(original[b]).area
                            if overlap>1e-7:counter['native_polygon_overlaps']+=1
                            if reported_loss>0:counter['reported_pairs']+=1
                            if reported_loss>0 and native_distance>1e-7:counter['reported_but_disjoint']+=1
                            if reported_loss==0 and overlap>1e-7:counter['polygon_overlap_without_report']+=1
                            if reported_loss>0 or overlap>1e-7:
                                ideal_overlap=ideal[a].intersection(ideal[b]).area
                                nominal_overlap=without_guard[a].intersection(without_guard[b]).area
                                physical_valid=original_overlap<1e-7 and distance>=gap-1e-7
                                event={'input':ob['input'],'sheet':sheet['sheet'],'a':a,'b':b,
                                    'parts':[items[a]['part_id'],items[b]['part_id']], 'original_distance_mm':distance,
                                    'original_overlap_mm2':original_overlap,'original_pair_valid':physical_valid,
                                    'native_overlap_mm2':overlap,'native_distance_mm':native_distance,'loss':reported_loss,
                                    'ideal_native_offset_overlap_mm2':ideal_overlap,'offset_without_guard_overlap_mm2':nominal_overlap}
                                positive.append(event)
                                if physical_valid and reported_loss>0:
                                    counter['reported_originally_valid_pairs']+=1
                                    if ideal_overlap>1e-7:counter['explained_by_native_offset_margin']+=1
                                    else:counter['requires_roundtrip_or_collision_precision_review']+=1
                            pairs_file.write(json.dumps({'input':ob['input'],'sheet':sheet['sheet'],'a':a,'b':b,
                                'original_distance_mm':distance,'original_overlap_mm2':original_overlap,
                                'native_distance_mm':native_distance,'native_overlap_mm2':overlap,'tracker_loss':reported_loss},separators=(',',':'))+'\n')
                        summed=sum(reported.values())+sum(p['static_loss'] for p in loss['items'])
                        assert abs(summed-loss['total_loss'])<=max(1e-6,loss['total_loss']*1e-6)
                        for i,p in enumerate(loss['items']):
                            total=sum(v for (a,b),v in reported.items() if i in (a,b))+p['static_loss']
                            assert abs(total-p['total_loss'])<=max(1e-6,p['total_loss']*1e-6)
                        for p in item_records:
                            if p['static_loss']>0:counter['static_positive']+=1
                            if p['static_positive_without_polygon_outside']:counter['static_false_positive']+=1
                            if p['outside_without_static_loss']:counter['static_missing']+=1
                        sheet_results.append({'sheet':sheet['sheet'],'items':len(items),'pairs_checked':pair_count,'counts':dict(counter),
                            'native_loss':loss['total_loss'],'static_loss_sum':sum(p['static_loss'] for p in loss['items']),
                            'max_pose_roundtrip_mm':max(p['pose_roundtrip_error_mm'] for p in item_records),
                            'max_native_vertex_transform_mm':max(p['native_vertex_transform_error_mm'] for p in item_records),
                            'max_offset_model_error_mm':max(p['native_offset_model_error_mm'] for p in item_records),
                            'total_native_overlap_mm2':sum(p['native_overlap_mm2'] for p in positive),
                            'max_native_overlap_mm2':max((p['native_overlap_mm2'] for p in positive),default=0),
                            'items_detail':item_records,'positive_pairs':positive})
                    if ob['input']!='before':
                        prior=load(ROOT/'output/h5-pattern-joint-probe-20261018/native-runs'/case['case']/'result.json')
                        old=next(x for x in prior['native_loss_observations'] if x['input']==ob['input'])
                        assert ob['joined_pinned_loss']==old['joined_pinned_loss']
                        assert [s['native_loss'] for s in sheet_results]==[s['loss'] for s in old['per_sheet']]
                    observations.append({'input':ob['input'],'sheets':sheet_results,'joined_pinned_loss':ob['joined_pinned_loss']})
            record={'case':case['case'],'template_checks':template_checks,'observations':observations,
                'guard_mm':guard,'native_separation_mm':separation,'original_gap_mm':gap,'unchanged_previous_losses':True}
            write(AUDIT/(case['case']+'.json'),record);records.append(record)
            print(json.dumps({'case':case['case'],'observations':[{ 'input':o['input'],'counts':dict(sum((Counter(s['counts']) for s in o['sheets']),Counter()))} for o in observations]}),flush=True)
        summary={'source_and_geometry_reconstruction_verified':True,'cases':[r['case'] for r in records],
            'all_pairs_checked':sum(s['pairs_checked'] for r in records for o in r['observations'] for s in o['sheets']),
            'max_pose_roundtrip_mm':max(s['max_pose_roundtrip_mm'] for r in records for o in r['observations'] for s in o['sheets']),
            'max_offset_model_error_mm':max(s['max_offset_model_error_mm'] for r in records for o in r['observations'] for s in o['sheets']),
            'all_runtime_and_previous_tests_exact':True,'new_packing_calls':0,'new_repair_calls':0,'production_digest':source_digest(),
            'collision_discrepancies_are_reported_not_suppressed':True}
        write(AUDIT/'checks.json',summary);print(json.dumps(summary),flush=True)
    except Exception as e:
        write(AUDIT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed_cases':[r['case'] for r in records]});raise
if __name__=='__main__':main()
