"""Build a new isolated observation binary; preserve every build outcome."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-native-collision-observer-20261018'
plan=json.loads((OUT/'plan.json').read_bytes());target=Path(plan['target']);assert not target.exists()
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--no-run','--target-dir',str(target)]
started=datetime.now(timezone.utc).isoformat()
with (OUT/'build.log').open('xb') as log:r=subprocess.run(command,cwd=OUT/'candidate',stdout=log,stderr=subprocess.STDOUT,timeout=1800)
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode}
if r.returncode==0:
    bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
    shutil.copyfile(bins[0],OUT/'observer-tests.exe');record['binary_sha256']=sha256((OUT/'observer-tests.exe').read_bytes()).hexdigest()
with (OUT/'build.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
shutil.copyfile(__file__,OUT/'build.py');print(json.dumps(record),flush=True)
assert r.returncode==0
