"""Prepare one original-geometry readback, preserving the reused audit source."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-outer-original-search-20261026'
source=ROOT/'output/diagnose_h5_lazy_original_proposals.py';target=ROOT/'output/audit_h5_outer_original_geometry.py'
s=source.read_text(encoding='utf-8')
edits={
"RUN=BASE/'lazy-full-original';OUT=RUN/'original-proposal-audit'":"RUN=ROOT/'output/h5-outer-original-search-20261026';OUT=RUN/'original-proposal-audit'",
"assert load(RUN/'audit/checks.json')['passed']":"assert load(RUN/'search-audit/checks.json')['passed']",
"paths=sorted(RUN.glob('round-*/proposal.json'))":"paths=[RUN/'candidate/proposal.json']",
"RUN/'plan.json',RUN/'result.json',RUN/'audit/checks.json'":"RUN/'shared-search/plan.json',RUN/'shared-search/result.json',RUN/'search-audit/checks.json',SRC/'propagation.json'",
"start=time.perf_counter();job=load(JOB)":"start=time.perf_counter();job=load(JOB);assert all(len(p['geometry'])==1 and not p['geometry'][0].get('holes') for p in job['parts'])",
"assert len(fixedby)==57":"aux=load(SRC/'propagation.json');charges=list(spec['fixed_original_area_units_per_sheet'])\n        for p in moving:charges[p['sheet']]+=aux['part_areas'][p['family']]['lower_units']\n        caps=[s['upper_area_units'] for s in aux['sheet_capacities']];assert all(a<=b for a,b in zip(charges,caps))\n        write(dest/'area-checks.json',{'passed':True,'original_area_units_per_sheet':charges,'upper_area_units_per_sheet':caps,'lower_units_per_mm2':1000,'all66_originals_charged':True})\n        assert len(fixedby)==57",
"'all_original_copies_and_counts_present':True":"'all_original_copies_and_counts_present':True,'all_original_area_constraints_checked':True"
}
for a,b in edits.items():assert s.count(a)==1,a;s=s.replace(a,b)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (RUN/'geometry-audit-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'exact_replacements':edits,'solver_calls':0,'purpose':'Reuse full original polygon and guard oracle on the one closed outer-cover candidate; add explicit source area-charge readback and verify original shapes have one outer polygon and no holes. Preserve invalid geometry and never invoke native validation for it.'},f,indent=2);f.write('\n')
print(target)
