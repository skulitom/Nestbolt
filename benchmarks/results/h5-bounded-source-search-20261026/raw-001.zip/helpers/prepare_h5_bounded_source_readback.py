"""Prepare terminal readback from the already exercised original-source oracle."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];source=ROOT/'output/audit_h5_outer_original_search.py';target=ROOT/'output/audit_h5_bounded_source_search.py';BASE=ROOT/'output/h5-bounded-source-search-20261026'
s=source.read_text(encoding='utf-8');start=s.index("        rows=load(RUN/'solve/outer-box-selection.json')");end=s.index('        excluded=load(',start);removed=s[start:end];s=s[:start]+"        assert not failures,'A full-source model positive violates an original source clause'\n        aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json');charges=list(spec['fixed_original_area_units_per_sheet'])\n        for p in parts:charges[p['sheet']]+=aux['part_areas'][p['family']]['lower_units']\n        assert all(a<=b['upper_area_units'] for a,b in zip(charges,aux['sheet_capacities']))\n        write(OUT/'area-checks.json',{'passed':True,'original_area_units_per_sheet':charges,'caps':[a['upper_area_units'] for a in aux['sheet_capacities']]})\n"+s[end:]
edits={
'h5-outer-original-search-20261026':'h5-bounded-source-search-20261026',
"model['all_strict_cell_restrictions_removed']":"model['all_original_full_guarded_source_clauses_equivalent']",
"model['hints']==79":"model['hints']==72",
"solved['has_necessary_coordinate_candidate']":"solved['has_full_guarded_source_candidate']",
"'necessary_integer_candidate':positive":"'full_guarded_source_candidate':positive",
"'outer_pair_mode_uses_checked':394 if positive else 0,'active_outer_boxes_checked':boxcount":"'full_source_pair_modes_in_verified_model':394,'all_selected_original_area_constraints_checked':positive",
"'Read back one closed necessary outer-cover call, actual parameters/model/timing. Verify all nine selected original identities, domains, areas, copy ordering, 394 pair activations and chosen box memberships. Directly evaluate every full guarded source clause for each same-sheet original pair and retain all failed faces/inequality deficits. Box membership is never inferred safe. No solver or native call.'":"'Read back one closed full-source-clause call, actual parameters/model/timing. Verify all selected original identities, domains, areas and copy ordering. Independently evaluate every full guarded source clause for every selected same-sheet pair; any source violation in a positive fails this audit. All394 pair modes were independently verified in the complete model audit. No solver/native call. A negative remains limited to the recorded source angles/inward integer domains/fixed57 construction.'"
}
for a,b in edits.items():assert s.count(a)==1,a;s=s.replace(a,b)
s=s.replace('Read back the closed outer-cover call and retain every source-rule failure.','Read back the closed full-source call and check original guarded clauses.')
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (BASE/'readback-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'removed_outer_box_verification':removed,'edits':edits,'solver_calls':0},f,indent=2);f.write('\n')
print(target)
