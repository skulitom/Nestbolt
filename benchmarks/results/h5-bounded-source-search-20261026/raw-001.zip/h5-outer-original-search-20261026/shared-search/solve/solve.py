"""One necessary outer-cover coordinate search; positives are not yet safe."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,sys,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-outer-original-search-20261026';OUT=BASE/'shared-search/solve';PREP=ROOT/'output/h5-outer-original-model-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';BOXES=ROOT/'output/h5-outer-displacement-boxes-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter();verified=load(PREP/'audit/checks.json');assert verified['passed'] and verified['all_full_guarded_source_valid_integer_displacements_retained']
    paths=[PREP/n for n in ['plan.json','result.json','model.pb','model.pbtxt','mapping.json','transformation.json','audit/plan.json','audit/checks.json','audit/solver-import-roundtrip.pb']]+[SOURCE/'plan.json',BOXES/'plan.json',BOXES/'audit-provenance-repaired/checks.json',OUT.parent/'budget.json']
    checked_inputs=load(PREP/'audit/plan.json')['inputs']
    for p in paths[:6]:assert digest(p)==checked_inputs[p.relative_to(ROOT).as_posix()]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_solver_calls':1,'workers':8,'random_seed':0,'solver_cap_seconds':45,'shutdown_reserve_seconds':10,
        'method':'One distinct necessary outer-cover model, derived from committed full-original source data and independently audited before this call. All strict pair cells, including 54 empty-sum restrictions, are replaced by complete integer outer covers. All source domains, original counts, areas, coordinates, activations and proved necessary exclusions remain. Verify the actual solver import/export equals the audited 70926-variable/180101-constraint model. Loading and verification plus the sole call share 60 seconds, with at most 45 solver seconds and ten-second shutdown reserve. Preserve 79 advisory hints. Positive coordinates may violate original clearance and must be checked against all original source clauses and complete geometry; never claim safety from box membership. A negative only concerns the recorded source-angle/inward-integer-domain/fixed-57 construction, not unrestricted packing. Offline preparation is not production-budget qualification.'})
    expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());assert digest(PREP/'model.pb')==load(PREP/'result.json')['model_sha256'];mapping=load(PREP/'mapping.json');spec=load(SOURCE/'plan.json')
    model=cp_model.CpModel();assert model.proto.parse_text_format((PREP/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'model.pb'));loaded=time.perf_counter()-start;start=time.perf_counter()
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());assert actual==expected and len(actual.variables)==70926 and len(actual.constraints)==180101 and len(actual.solution_hint.vars)==79
    assert len(mapping['outer_displacement_pairs'])==394 and len(mapping['simultaneous_original_coordinates'])==9 and 'guarded_displacement_cell_pairs' not in mapping and 'remaining_original_cell_pairs' not in mapping
    write(OUT/'mapping.json',mapping);remaining=load(OUT.parent/'budget.json')['deadline_perf_counter']-time.perf_counter()-10;assert remaining>0
    params={'max_time_in_seconds':min(45,remaining),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audit_seconds=time.perf_counter()-start
    audit={'passed':True,'loading_seconds':loaded,'audit_seconds':audit_seconds,'variables':70926,'constraints':180101,'required_originals':66,'mandatory_moving_originals':9,'fixed_originals':57,'original_anchor_variables':18,
        'outer_pair_mode_uses':394,'all_strict_cell_restrictions_removed':True,'all_original_valid_integer_displacements_retained':True,'positive_original_safety_not_claimed':True,'hints':79,'optional_originals':0,'objectives':0,
        'actual_solver_import_export_matches_independently_verified_model':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining,'shutdown_reserve_seconds':10,'python':sys.version,'ortools':ortools.__version__}
    write(OUT/'model-audit.json',audit);print(audit,flush=True);write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds'],'model_sha256':audit['model_sha256']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    def value(i):return solver.value(model.get_int_var_from_proto_index(i))
    if positive:
        selected=[]
        for p in mapping['parts']:
            modes=[m for m in p['modes'] if value(m['active'])];assert len(modes)==1;m=modes[0];ds=[i for i,v in enumerate(m['domains']) if value(v)];assert len(ds)==1;q=spec['queries'][m['query']];d=load(SOURCE/'queries'/f"{m['query']:03d}.json")['domains'][ds[0]]
            selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':ds[0],'domain_index':d['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':value(p['choice'])})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66})
        write(OUT/'original-positions.json',[{'part':p['part'],'x_units':value(p['x']),'y_units':value(p['y'])} for p in mapping['simultaneous_original_coordinates']])
        write(OUT/'outer-box-selection.json',[{'parts':p['parts'],'case':p['case'],'active':bool(value(p['active'])),'chosen_boxes':[c['index'] for c in p['cells'] if value(c['flag'])]} for p in mapping['outer_displacement_pairs']])
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_necessary_coordinate_candidate':positive,'response_stats':solver.response_stats(),
        'scope':'Necessary integer outer-cover model, all 66 originals mandatory, nine movable with recorded source angles/inward domains and 57 fixed. A positive may violate full guarded source clauses. A negative is not unrestricted packing impossibility. Offline preparation is not production qualification.',
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
