"""Reconstruct all66 originals in every relaxed proposal; retain every failure."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import copy,json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape
from shapely.affinity import translate,affine_transform

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025';RUN=ROOT/'output/h5-outer-original-search-20261026';OUT=RUN/'original-proposal-audit'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';FIXED=ROOT/'output/h5-guarded-source-adjustment-20261025/audit/adjusted-fixed-originals.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(RUN/'search-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    paths=[RUN/'candidate/proposal.json'];sourcepath=ROOT/load(SRC/'plan.json')['hint_source']
    inputs=[BASE/'plan.json',BASE/'profiles.json',RUN/'shared-search/plan.json',RUN/'shared-search/result.json',RUN/'search-audit/checks.json',SRC/'propagation.json',FIXED,JOB,SRC/'geometry.json',SRC/'items.json',sourcepath]+paths
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Independently reconstruct every retained relaxed proposal as a complete66-original layout, using the adjusted57 source transforms and exact original job outer polygons. Verify all original identities, copies, orientations, profile reconstructions, every same-sheet original pair and all stock edges against unchanged native guards. Preserve all collisions rather than assuming any proposal passed. Rank diagnostics by total original overlap area, failing-pair count, then summed native-clearance deficits; ranking is diagnostic only, no production objective or acceptance. No native call on invalid geometry.'})
    start=time.perf_counter();job=load(JOB);assert all(len(p['geometry'])==1 and not p['geometry'][0].get('holes') for p in job['parts']);family={p['id']:p for p in job['parts']};items=load(SRC/'items.json');spec=load(BASE/'plan.json');profiles=load(BASE/'profiles.json');source=load(sourcepath)
    fixed=load(FIXED);fixedby={r['item']:r for r in fixed};stocks=[[float(F(*v)) for v in s] for s in load(SRC/'geometry.json')['stock_bounds_rational']]
    guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);summaries=[];totalpairs=0;totalstock=0;reconstruction=0.
    for path in paths:
        assert time.perf_counter()-start<120
        name=path.parent.name;dest=OUT/name;dest.mkdir();solution=load(path);moving=solution['movable_parts'];mb={p['item']:p for p in moving}
        aux=load(SRC/'propagation.json');charges=list(spec['fixed_original_area_units_per_sheet'])
        for p in moving:charges[p['sheet']]+=aux['part_areas'][p['family']]['lower_units']
        caps=[s['upper_area_units'] for s in aux['sheet_capacities']];assert all(a<=b for a,b in zip(charges,caps))
        write(dest/'area-checks.json',{'passed':True,'original_area_units_per_sheet':charges,'upper_area_units_per_sheet':caps,'lower_units_per_mm2':1000,'all66_originals_charged':True})
        assert len(fixedby)==57 and len(mb)==9 and set(fixedby).isdisjoint(mb) and set(fixedby)|set(mb)==set(range(66))
        layout=copy.deepcopy(source);layout['placements']=[];polys={};records=[]
        for i in range(66):
            item=items[i];fam=item['family']
            if i in fixedby:
                r=fixedby[i];t=copy.deepcopy(r['transform']);sheet=r['sheet'];expected=shape(r['geometry'])
            else:
                r=mb[i];p=profiles[r['profile']];sheet=r['sheet'];x,y=r['x_units']/1000,r['y_units']/1000
                angle=p['rotation_radians'];mirror=p['mirrored'];c,s=math.cos(angle),math.sin(angle);mi=-1 if mirror else 1
                if fam=='cog':
                    cx,cy=p['original_center'];tx=x-c*cx+s*cy;ty=y-s*cx-c*cy
                else:
                    pts=[(mi*a*c-b*s,mi*a*s+b*c) for a,b in family[fam]['geometry'][0]['outer']];tx=x-min(a for a,b in pts);ty=y-min(b for a,b in pts)
                t={'rotation_radians':angle,'translation':[tx,ty],'mirrored':mirror};expected=translate(shape(p['geometry']),x,y)
            placement={'part_id':fam,'copy_index':item['copy'],'sheet_id':f'sheet-{sheet}','transform':t};layout['placements'].append(placement)
            c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1
            poly=affine_transform(Polygon(family[fam]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,*t['translation']]);assert poly.is_valid
            error=poly.hausdorff_distance(expected);assert error<1e-7;reconstruction=max(reconstruction,error);polys[i]=poly
            records.append({'item':i,'family':fam,'sheet':sheet,'fixed':i in fixedby})
        assert Counter(r['family'] for r in records)==spec['required_original_counts']
        for fam,count in spec['required_original_counts'].items():assert sorted(p['copy_index'] for p in layout['placements'] if p['part_id']==fam)==list(range(count))
        pairs=[];failures=[];stock=[];stockfail=[]
        for a,b in combinations(records,2):
            if a['sheet']!=b['sheet']:continue
            pa,pb=polys[a['item']],polys[b['item']];distance=pa.distance(pb);area=pa.intersection(pb).area
            row={'items':[a['item'],b['item']],'families':[a['family'],b['family']],'gap_mm':distance,'intersection_area_mm2':area,
                 'native_clearance_deficit_mm':max(0,gap-distance),'both_moving':not a['fixed'] and not b['fixed']}
            pairs.append(row)
            if area>0 or distance<gap:failures.append(row)
        for r in records:
            b=polys[r['item']].bounds;st=stocks[r['sheet']];margins=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]]
            row={'item':r['item'],'sheet':r['sheet'],'bounds':list(b),'extra_stock_margins_mm':margins};stock.append(row)
            if min(margins)<guard:stockfail.append(row)
        assert all(f['both_moving'] for f in failures) and not stockfail
        write(dest/'original-layout.json',layout);write(dest/'all-pair-checks.json',pairs);write(dest/'pair-failures.json',failures);write(dest/'stock-checks.json',stock);write(dest/'stock-failures.json',stockfail)
        totalpairs+=len(pairs);totalstock+=4*len(stock)
        summary={'round':name,'original_parts':66,'same_sheet_pairs_checked':len(pairs),'failed_original_pairs':len(failures),'failed_stock_parts':len(stockfail),
            'summed_intersection_area_mm2':sum(r['intersection_area_mm2'] for r in failures),'summed_native_clearance_deficit_mm':sum(r['native_clearance_deficit_mm'] for r in failures),
            'all_failures_between_moving_originals':True,'all_fixed_collisions_and_stock_margins_pass':True,'original_geometry_clears_native_guards':not failures and not stockfail}
        write(dest/'checks.json',summary);summaries.append(summary)
    ranked=sorted(summaries,key=lambda r:(r['summed_intersection_area_mm2'],r['failed_original_pairs'],r['summed_native_clearance_deficit_mm']))
    write(OUT/'ranked-proposals.json',ranked)
    checks={'passed':True,'seconds':time.perf_counter()-start,'complete_original_proposals_checked':len(summaries),'all_original_pair_checks':totalpairs,
        'all_original_stock_edge_checks':totalstock,'maximum_original_profile_reconstruction_error_mm':reconstruction,'all_original_copies_and_counts_present':True,'all_original_area_constraints_checked':True,
        'all_fixed_original_collision_and_stock_checks_pass':True,'originally_valid_proposals':sum(r['original_geometry_clears_native_guards'] for r in summaries),
        'best_diagnostic_proposal':ranked[0] if ranked else None,'native_packing_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
