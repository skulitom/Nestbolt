"""Read back the closed outer-cover call and retain every source-rule failure."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-outer-original-search-20261026';RUN=BASE/'shared-search';OUT=BASE/'search-audit';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';BOXES=ROOT/'output/h5-outer-displacement-boxes-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert (RUN/'result.json').is_file();OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    inputs=list(p for p in RUN.rglob('*') if p.is_file())+[SOURCE/'plan.json',BOXES/'plan.json']+sorted((SOURCE/'queries').glob('*.json'))+sorted((SOURCE/'mutual').glob('*.json'))+sorted((BOXES/'cases').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Read back one closed necessary outer-cover call, actual parameters/model/timing. Verify all nine selected original identities, domains, areas, copy ordering, 394 pair activations and chosen box memberships. Directly evaluate every full guarded source clause for each same-sheet original pair and retain all failed faces/inequality deficits. Box membership is never inferred safe. No solver or native call.'})
    budget=load(RUN/'budget.json');result=load(RUN/'result.json');model=load(RUN/'solve/model-audit.json');solved=load(RUN/'solve/result.json');opened=load(RUN/'solve/opened.json')
    for path in [RUN/'plan.json',RUN/'solve/plan.json']:
        for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h
    assert model['passed'] and model['all_strict_cell_restrictions_removed'] and model['original_anchor_variables']==18 and model['hints']==79 and model['required_originals']==66
    assert digest(RUN/'solve/model.pb')==model['model_sha256']==opened['model_sha256'] and digest(RUN/'solve/parameters.pbtxt')==model['parameters_sha256']
    params=text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
    assert params.max_time_in_seconds==opened['seconds_limit']==min(45,model['remaining_shared_budget_at_parameter_set']) and params.num_search_workers==8 and params.random_seed==0
    assert budget['shared_seconds']==60 and budget['solver_cap_seconds']==45 and budget['solver_shutdown_reserve_seconds']==10 and budget['deadline_perf_counter']==budget['start_perf_counter']+60
    assert params.cp_model_presolve and params.cp_model_probing_level==0 and params.symmetry_level==0
    assert solved['solver_calls']==result['solver_calls_opened']==1 and result['status']=='MASTER_'+solved['status'] and result['stage']['exit_code']==0
    assert solved['seconds']+model['loading_seconds']+model['audit_seconds']<=result['stage']['seconds']<=result['elapsed_seconds']
    positive=solved['status'] in ['OPTIMAL','FEASIBLE'];assert positive==solved['has_necessary_coordinate_candidate'];planes=pieces=edges=boxcount=same_pairs=0;failures=[];charges=[]
    if positive:
        selected=load(RUN/'solve/selection.json');positions=load(RUN/'solve/original-positions.json');spec=load(SOURCE/'plan.json');parts=selected['movable_parts'];assert selected['fixed_items']==spec['fixed_items'] and selected['required_originals']==66 and [p['part'] for p in positions]==list(range(9)) and len(parts)==9
        mapping=load(RUN/'solve/mapping.json');assert len(mapping['parts'])==9
        for i,(p,xy) in enumerate(zip(parts,positions)):
            original=spec['parts'][i];assert p['part']==i and p['item']==original['index'] and p['family']==original['family'] and p['query'] in original['queries']
            q=spec['queries'][p['query']];assert q['profile']==p['profile'] and q['sheet']==p['sheet'];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];x,y=xy['x_units'],xy['y_units'];assert isinstance(x,int) and isinstance(y,int)
            offset=0
            for mode in mapping['parts'][i]['modes']:
                if mode['query']==p['query']:break
                offset+=len(mode['domains'])
            assert p['choice_index']==offset+p['domain_row']
            for b in [q['anchor_bounds_units1000'],d['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
            for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];planes+=1
        for i,j in [(0,1),(3,4),(4,5),(5,6),(6,7),(7,8)]:assert parts[i]['choice_index']<=parts[j]['choice_index']
        # Area rules are reconstructed from the original source plan below.
        clauses=[]
        for a,b in combinations(parts,2):
            if a['sheet']!=b['sheet']:continue
            mi=next(c['index'] for c in spec['mutual_cases'] if c['profile_a']==a['profile'] and c['profile_b']==b['profile']);x=positions[b['part']]['x_units']-positions[a['part']]['x_units'];y=positions[b['part']]['y_units']-positions[a['part']]['y_units'];count=0;bad=[]
            for fi,face in enumerate(load(SOURCE/'mutual'/f'{mi:03d}.json')['faces']):
                values=[h['a']*x+h['b']*y-h['bound'] for h in face['outside_halfplanes']];edges+=len(values);pieces+=1;count+=1
                if max(values)<0:
                    failure={'parts':[a['part'],b['part']],'items':[a['item'],b['item']],'queries':[a['query'],b['query']],'mutual_case':mi,'face':fi,'difference_units1000':[x,y],'outside_inequality_slacks':values};failures.append(failure);bad.append(fi)
            clauses.append({'parts':[a['part'],b['part']],'mutual_case':mi,'original_guarded_clauses':count,'failed_faces':bad});same_pairs+=1
        rows=load(RUN/'solve/outer-box-selection.json');plan=load(BOXES/'plan.json');expected=[(c['index'],pair) for c in plan['cases'] for pair in c['physical_pairs']];assert [(r['case'],r['parts']) for r in rows]==expected and len(rows)==394
        for row in rows:
            case=plan['cases'][row['case']];i,j=row['parts'];active=parts[i]['query']==case['query_a'] and parts[j]['query']==case['query_b'];assert active==row['active'] and len(row['chosen_boxes'])==int(active)
            if not active:continue
            data=load(BOXES/'cases'/f"{row['case']:03d}.json");d=next(d for d in data['domains'] if d['index']==row['chosen_boxes'][0]);x=positions[j]['x_units']-positions[i]['x_units'];y=positions[j]['y_units']-positions[i]['y_units']
            for b in [data['difference_bounds_units1000'],d['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
            boxcount+=1
        assert boxcount==same_pairs
        excluded=load(ROOT/'output/h5-six-cog-guided-search-20261025/conflict-proof-audit-completed/certified-selected-combination-exclusion.json')['parts'];assert any((a['query'],a['domain_row'])!=(b['query'],b['domain_row']) for a,b in zip(parts,excluded))
        write(OUT/'original-pair-clause-checks.json',clauses);write(OUT/'original-clause-failures.json',failures)
        verified=[{**p,**xy} for p,xy in zip(parts,positions)];write(OUT/'verified-original-positions.json',verified);dest=BASE/'candidate';dest.mkdir();write(dest/'proposal.json',{'movable_parts':verified,'required_originals':66,'not_yet_safe':True})
    else:
        assert solved['status'] in ['UNKNOWN','INFEASIBLE'] and not (RUN/'solve/selection.json').exists() and not (RUN/'solve/original-positions.json').exists()
    checks={'passed':True,'seconds':time.perf_counter()-start,'terminal_status':solved['status'],'necessary_integer_candidate':positive,'solver_calls':1,'actual_solver_seconds':solved['seconds'],'declared_solver_seconds':params.max_time_in_seconds,
        'solver_soft_limit_overshoot_seconds':max(0,solved['seconds']-params.max_time_in_seconds),'actual_shared_seconds':result['elapsed_seconds'],'shared_budget_honored':result['elapsed_seconds']<=60,'shared_overrun_seconds':max(0,result['elapsed_seconds']-60),
        'mandatory_moving_originals':9,'fixed_originals':57,'required_originals':66,'same_sheet_original_pairs_checked':same_pairs,'source_inward_halfplanes_checked':planes,'source_full_guarded_clauses_checked':pieces,'source_outside_inequalities_checked':edges,'outer_pair_mode_uses_checked':394 if positive else 0,'active_outer_boxes_checked':boxcount,
        'failed_original_clauses':len(failures),'failed_original_pairs':len(set(tuple(f['parts']) for f in failures)),'candidate_passes_all_original_clauses':positive and not failures,
        'completed_call_closed_no_retry':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
