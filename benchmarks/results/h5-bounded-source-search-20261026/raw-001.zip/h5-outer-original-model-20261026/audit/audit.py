"""Independent exhaustive audit of strict-cell replacement and source preservation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-all-original-cell-search-20261025/direct-geometry-projection';BOXES=ROOT/'output/h5-outer-displacement-boxes-20261025';BASE=ROOT/'output/h5-outer-original-model-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def make_linear(terms,lo,hi,en=()):
    values=Counter()
    for v,c in terms:values[v]+=c
    keys=sorted(v for v,c in values.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(keys);p.linear.coeffs.extend(values[v] for v in keys);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);return p
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Verify committed provenance of the parent and complete outer cover. Independently reconstruct every deleted strict cell box/halfplane and cell-sum equation from old mappings and original cell files, including all empty sums. Inverse-map every retained variable, constraint and mapping entry to exact parent equality. Reconstruct every appended complete difference bound, outer box variable/bound and active-cell equality in order; verify every pair/mode and every hint. Rebuild the parent from retained fields plus independently checked deleted fields and require full protobuf equality. Verify actual solver parse/validation/export. The replacement preserves all originally safe integer pair displacements but does not certify positive packing safety. No solver call.'})
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-direct-original-search-20261025/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in [PARENT/'model.pb',PARENT/'mapping.json',PARENT/'audit/checks.json']:
        assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    for p in [BOXES/'plan.json',BOXES/'audit-provenance-repaired/checks.json']+list((BOXES/'cases').glob('*.json')):assert digest(p)==known[p.relative_to(ROOT/'output').as_posix()]
    cover=load(BOXES/'audit-provenance-repaired/checks.json');assert cover['passed'] and cover['every_full_guarded_source_valid_integer_displacement_retained']
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());actual=cp_model_pb2.CpModelProto();actual.ParseFromString((BASE/'model.pb').read_bytes());assert text_format.Parse((BASE/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())==actual
    oldmap=load(PARENT/'mapping.json');newmap=load(BASE/'mapping.json');meta=load(BASE/'transformation.json');original_xy=oldmap['simultaneous_original_coordinates'];groups=[]
    cog={q:load(ROOT/'output/h5-cog-displacement-cells-20261025/coarse-refinement'/f'selected-query-{q}.json') for q in [18,19]};remaining={i:load(ROOT/'output/h5-remaining-displacement-cells-20261025/cases'/f'{i:03d}'/'selected.json') for i in range(162)}
    older=load(ROOT/'benchmarks/results/h5-all-original-cell-search-20261025/raw-manifest.json');olderknown={r['path']:r['sha256'] for r in older['files']+older['aliases']}
    for q in [18,19]:
        p=ROOT/'output/h5-cog-displacement-cells-20261025/coarse-refinement'/f'selected-query-{q}.json';assert digest(p)==olderknown['source-inputs/'+p.relative_to(ROOT).as_posix()]
    for i in range(162):
        p=ROOT/'output/h5-remaining-displacement-cells-20261025/cases'/f'{i:03d}'/'selected.json';assert digest(p)==olderknown[p.relative_to(ROOT/'output').as_posix()]
    for pair in oldmap['guarded_displacement_cell_pairs']:
        for m in pair['sheet_modes']:groups.append({'parts':pair['parts'],'query_a':m['query'],'query_b':m['query'],'active':m['active'],'cells':m['cells'],'data':cog[m['query']]})
    for pair in oldmap['remaining_original_cell_pairs']:groups.append({**pair,'data':remaining[pair['case']]})
    expected_removed=Counter();removed_vars=set();empty_sums=0
    for g in groups:
        a,b=[original_xy[i] for i in g['parts']];ds={d['index']:d for d in g['data']['domains']};assert [c['index'] for c in g['cells']]==list(ds)
        for cell in g['cells']:
            flag=cell['flag'];assert flag not in removed_vars;removed_vars.add(flag);assert parent.variables[flag].domain==[0,1];d=ds[cell['index']];r=d['coordinate_bounds']
            constraints=[make_linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[flag]),make_linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[flag])]
            constraints += [make_linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],-2**63,h['bound'],[flag]) for h in d['halfplanes']]
            expected_removed.update(c.SerializeToString() for c in constraints)
        expected_removed[make_linear([(c['flag'],1) for c in g['cells']]+[(g['active'],-1)],0,0).SerializeToString()]+=1;empty_sums+=not g['cells']
    assert len(groups)==394 and empty_sums==meta['removed_empty_cell_sums']==54 and sorted(removed_vars)==meta['removed_old_cell_variables'] and len(removed_vars)==21819
    assert Counter(parent.constraints[i].SerializeToString() for i in meta['removed_old_cell_constraints'])==expected_removed and sum(expected_removed.values())==116237
    removed_c=set(meta['removed_old_cell_constraints']);kept=[i for i in range(len(parent.constraints)) if i not in removed_c];assert kept==meta['retained_old_constraint_indices']
    inverse=[i for i in range(len(parent.variables)) if i not in removed_vars];assert inverse==meta['retained_old_variable_indices'];forward={v:i for i,v in enumerate(inverse)};assert len(inverse)==10255 and len(kept)==57577
    for v,i in zip(actual.variables,inverse):assert v==parent.variables[i]
    def undo(v):return inverse[v] if v>=0 else -inverse[-v-1]-1
    reconstructed={}
    for c,oi in zip(actual.constraints[:len(kept)],kept):
        d=cp_model_pb2.ConstraintProto();d.CopyFrom(c);d.enforcement_literal[:]=[undo(v) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
        if kind=='linear':d.linear.vars[:]=[inverse[v] for v in c.linear.vars]
        else:assert kind in ['bool_or','at_most_one','exactly_one'];getattr(d,kind).literals[:]=[undo(v) for v in getattr(c,kind).literals]
        assert d==parent.constraints[oi];reconstructed[oi]=d
    def undo_mapping(v,key=None):
        if isinstance(v,dict):return {k:undo_mapping(w,k) for k,w in v.items()}
        if isinstance(v,list):return [inverse[w] for w in v] if key in ['domains','selectors'] else [undo_mapping(w) for w in v]
        return inverse[v] if key in ['sheet','choice','active','occupied','flag','x','y'] else v
    retainedmap={k:v for k,v in newmap.items() if k!='outer_displacement_pairs'};assert undo_mapping(retainedmap)=={k:v for k,v in oldmap.items() if k not in ['guarded_displacement_cell_pairs','remaining_original_cell_pairs']}
    vi=len(inverse);ci=len(kept);pairrows=[];plan=load(BOXES/'plan.json');lookup={(tuple(g['parts']),g['query_a'],g['query_b']):g for g in groups};hints=[(forward[v],value) for v,value in zip(parent.solution_hint.vars,parent.solution_hint.values) if v not in removed_vars];assert len(hints)==72
    witnesspath=ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json';six={p['part']:p for p in load(witnesspath)};hint_records=[]
    def check_linear(terms,lo,hi,en=()):
        nonlocal ci
        p=make_linear(terms,lo,hi,en);assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    for case in plan['cases']:
        data=load(BOXES/'cases'/f"{case['index']:03d}.json");r=data['difference_bounds_units1000']
        for i,j in case['physical_pairs']:
            old=lookup[(tuple([i,j]),case['query_a'],case['query_b'])];active=forward[old['active']];a,b=newmap['simultaneous_original_coordinates'][i],newmap['simultaneous_original_coordinates'][j]
            check_linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[active]);check_linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[active]);choices=[]
            for d in data['domains']:
                assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=f"outer-pair{i}-{j}-case{case['index']}-box{d['index']}",domain=[0,1]);flag=vi;vi+=1;choices.append({'index':d['index'],'flag':flag});db=d['coordinate_bounds']
                check_linear([(b['x'],1),(a['x'],-1)],db[0],db[2],[flag]);check_linear([(b['y'],1),(a['y'],-1)],db[1],db[3],[flag])
            check_linear([(c['flag'],1) for c in choices]+[(active,-1)],0,0);pairrows.append({'parts':[i,j],'case':case['index'],'query_a':case['query_a'],'query_b':case['query_b'],'active':active,'cells':choices})
            if i in six and j in six and six[i]['query']==case['query_a'] and six[j]['query']==case['query_b']:
                x=six[j]['x_units']-six[i]['x_units'];y=six[j]['y_units']-six[i]['y_units'];indices=[d['index'] for d in data['domains'] if d['coordinate_bounds'][0]<=x<=d['coordinate_bounds'][2] and d['coordinate_bounds'][1]<=y<=d['coordinate_bounds'][3]];assert len(indices)==1
                flag=next(c['flag'] for c in choices if c['index']==indices[0]);hints.append((flag,1));hint_records.append({'parts':[i,j],'case':case['index'],'box':indices[0],'flag':flag,'difference':[x,y]})
    assert vi==len(actual.variables)==70926 and ci==len(actual.constraints)==180101 and pairrows==newmap['outer_displacement_pairs'] and hint_records==load(BASE/'new-box-hints.json')
    hp=cp_model_pb2.PartialVariableAssignment();hp.vars.extend(v for v,_ in hints);hp.values.extend(value for _,value in hints);assert actual.solution_hint==hp and len(hints)==len(set(v for v,_ in hints))==79
    for v,value in hints:assert actual.variables[v].domain[0]<=value<=actual.variables[v].domain[-1]
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(actual);del restored.variables[:];restored.variables.extend(parent.variables);del restored.constraints[:]
    for i in range(len(parent.constraints)):restored.constraints.add().CopyFrom(parent.constraints[i] if i in removed_c else reconstructed[i])
    restored.solution_hint.CopyFrom(parent.solution_hint);assert restored==parent
    solvermodel=cp_model.CpModel();assert solvermodel.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and solvermodel.validate()=='' and solvermodel.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    imported=cp_model_pb2.CpModelProto();imported.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert imported==actual
    checks={'passed':True,'seconds':time.perf_counter()-start,'deleted_strict_cell_variables_verified':21819,'deleted_strict_cell_constraints_verified':116237,'all54_empty_cell_sum_restrictions_removed':True,
        'retained_original_variables_inverse_verified':10255,'retained_original_constraints_inverse_verified':57577,'outer_box_flags_verified':60671,'new_pair_mode_choices_verified':394,'variables':70926,'constraints':180101,
        'hints_verified':79,'entire_parent_reconstructed_from_verified_changes':True,'actual_solver_import_export_verified':True,'all_original_domains_counts_areas_coordinates_and_activations_unchanged':True,
        'all_full_guarded_source_valid_integer_displacements_retained':True,'retained_other_exclusions_are_original_source_necessary_conditions':True,'positive_original_safety_not_claimed':True,'required_originals':66,'movable_originals':9,'fixed_originals':57,
        'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
