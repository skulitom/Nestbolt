"""Replace every strict pair cell with the complete necessary integer cover."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import copy,json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-all-original-cell-search-20261025/direct-geometry-projection';BOXES=ROOT/'output/h5-outer-displacement-boxes-20261025';OUT=ROOT/'output/h5-outer-original-model-20261026'
WIT=ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def linear(terms,lo,hi,en=()):
    counts=Counter()
    for v,c in terms:counts[v]+=c
    ids=sorted(v for v,c in counts.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(counts[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);return p
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(BOXES/'audit-provenance-repaired/checks.json')['passed']
    paths=[PARENT/'model.pb',PARENT/'mapping.json',PARENT/'result.json',PARENT/'audit/checks.json',BOXES/'plan.json',BOXES/'result.json',BOXES/'audit-provenance-repaired/checks.json',WIT]
    paths+=sorted((BOXES/'cases').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,
        'method':'Replace ALL strict safe displacement cells in the audited table-free model with independently proved necessary integer outer boxes, for both cog/cog and remaining pairs. Delete all old cell variables, all constraints using them, and every old sum(cell flags)=active equation including empty zero-cell cases. Retain every original domain/count/area/coordinate/capacity/proved-exclusion constraint and exact pair-query activation. Add complete original difference bounds, conditional box bounds and exactly one outer box for each active query pair. Remove old cell hints, preserve other hints and add seven valid box hints for the already checked six-cog witness. This is a necessary relaxation of full guarded source pair relations, not a safe packing model. Positive positions require all original source/geometry checks. Independent complete transformation audit is required before any solver call.'})
    old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes());assert digest(PARENT/'model.pb')==load(PARENT/'result.json')['model_sha256'];mapping=load(PARENT/'mapping.json');plan=load(BOXES/'plan.json')
    groups=[]
    for pair in mapping['guarded_displacement_cell_pairs']:
        for mode in pair['sheet_modes']:groups.append({'parts':pair['parts'],'query_a':mode['query'],'query_b':mode['query'],'active':mode['active'],'cells':mode['cells']})
    groups+=mapping['remaining_original_cell_pairs'];assert len(groups)==394
    removed_vars=sorted({c['flag'] for g in groups for c in g['cells']});removed=set(removed_vars);assert len(removed)==21819
    sums={linear([(c['flag'],1) for c in g['cells']]+[(g['active'],-1)],0,0).SerializeToString() for g in groups};assert len(sums)==394
    def references(c):
        values={v if v>=0 else -v-1 for v in c.enforcement_literal};kind=c.WhichOneof('constraint')
        if kind=='linear':values.update(c.linear.vars)
        else:assert kind in ['bool_or','at_most_one','exactly_one'];values.update(v if v>=0 else -v-1 for v in getattr(c,kind).literals)
        return values
    removed_constraints=[i for i,c in enumerate(old.constraints) if references(c)&removed or c.SerializeToString() in sums]
    assert len(removed_constraints)==116237;removed_c=set(removed_constraints);kept_vars=[i for i in range(len(old.variables)) if i not in removed];forward={v:i for i,v in enumerate(kept_vars)};kept_constraints=[i for i in range(len(old.constraints)) if i not in removed_c]
    model=cp_model_pb2.CpModelProto();model.CopyFrom(old);del model.variables[:];model.variables.extend(old.variables[i] for i in kept_vars);del model.constraints[:]
    def literal(v):return forward[v] if v>=0 else -forward[-v-1]-1
    for i in kept_constraints:
        c=old.constraints[i];d=model.constraints.add();d.CopyFrom(c);d.enforcement_literal[:]=[literal(v) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
        if kind=='linear':d.linear.vars[:]=[forward[v] for v in c.linear.vars]
        else:getattr(d,kind).literals[:]=[literal(v) for v in getattr(c,kind).literals]
    def remap(v,key=None):
        if isinstance(v,dict):return {k:remap(w,k) for k,w in v.items()}
        if isinstance(v,list):return [forward[w] for w in v] if key in ['domains','selectors'] else [remap(w) for w in v]
        return forward[v] if key in ['sheet','choice','active','occupied','flag','x','y'] else v
    newmap=remap({k:v for k,v in mapping.items() if k not in ['guarded_displacement_cell_pairs','remaining_original_cell_pairs']});lookup={(tuple(g['parts']),g['query_a'],g['query_b']):g for g in groups}
    retained_hints=[(forward[v],value) for v,value in zip(old.solution_hint.vars,old.solution_hint.values) if v not in removed];assert len(retained_hints)==72
    model.ClearField('solution_hint');model.solution_hint.vars.extend(v for v,_ in retained_hints);model.solution_hint.values.extend(value for _,value in retained_hints);newpairs=[];six={p['part']:p for p in load(WIT)};newhints=[]
    for case in plan['cases']:
        data=load(BOXES/'cases'/f"{case['index']:03d}.json");r=data['difference_bounds_units1000']
        for i,j in case['physical_pairs']:
            oldgroup=lookup[(tuple([i,j]),case['query_a'],case['query_b'])];active=forward[oldgroup['active']];a,b=newmap['simultaneous_original_coordinates'][i],newmap['simultaneous_original_coordinates'][j]
            model.constraints.add().CopyFrom(linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[active]));model.constraints.add().CopyFrom(linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[active]));choices=[]
            for d in data['domains']:
                flag=len(model.variables);model.variables.add(name=f"outer-pair{i}-{j}-case{case['index']}-box{d['index']}",domain=[0,1]);choices.append({'index':d['index'],'flag':flag});db=d['coordinate_bounds']
                model.constraints.add().CopyFrom(linear([(b['x'],1),(a['x'],-1)],db[0],db[2],[flag]));model.constraints.add().CopyFrom(linear([(b['y'],1),(a['y'],-1)],db[1],db[3],[flag]))
            model.constraints.add().CopyFrom(linear([(c['flag'],1) for c in choices]+[(active,-1)],0,0))
            newpairs.append({'parts':[i,j],'case':case['index'],'query_a':case['query_a'],'query_b':case['query_b'],'active':active,'cells':choices})
            if i in six and j in six and six[i]['query']==case['query_a'] and six[j]['query']==case['query_b']:
                x=six[j]['x_units']-six[i]['x_units'];y=six[j]['y_units']-six[i]['y_units'];matches=[d['index'] for d in data['domains'] if d['coordinate_bounds'][0]<=x<=d['coordinate_bounds'][2] and d['coordinate_bounds'][1]<=y<=d['coordinate_bounds'][3]];assert len(matches)==1
                flag=next(c['flag'] for c in choices if c['index']==matches[0]);model.solution_hint.vars.append(flag);model.solution_hint.values.append(1);newhints.append({'parts':[i,j],'case':case['index'],'box':matches[0],'flag':flag,'difference':[x,y]})
    assert len(newhints)==7 and len(model.solution_hint.vars)==len(set(model.solution_hint.vars))==79;newmap['outer_displacement_pairs']=newpairs
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');write(OUT/'mapping.json',newmap);write(OUT/'new-box-hints.json',newhints)
    write(OUT/'transformation.json',{'removed_old_cell_variables':removed_vars,'removed_old_cell_constraints':removed_constraints,'retained_old_variable_indices':kept_vars,'retained_old_constraint_indices':kept_constraints,'removed_empty_cell_sums':sum(not g['cells'] for g in groups)})
    result={'seconds':time.perf_counter()-start,'parent_variables':len(old.variables),'parent_constraints':len(old.constraints),'removed_old_cell_variables':len(removed_vars),'removed_old_cell_constraints':len(removed_constraints),'removed_empty_cell_sums':sum(not g['cells'] for g in groups),
        'retained_original_variables':len(kept_vars),'retained_original_constraints':len(kept_constraints),'outer_box_flags':len(model.variables)-len(kept_vars),'variables':len(model.variables),'constraints':len(model.constraints),'pair_mode_uses':len(newpairs),'hints':79,
        'model_sha256':digest(OUT/'model.pb'),'all_original_safe_displacements_retained':True,'positive_safety_claim':False,'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
