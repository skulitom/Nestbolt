"""Replace the relaxation with complete source clauses simplified by exact bounds."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-outer-original-model-20261026';BOXES=ROOT/'output/h5-outer-displacement-boxes-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-bounded-source-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def linear(terms,lo,hi,en=()):
    d=Counter()
    for v,c in terms:d[v]+=c
    ids=sorted(v for v,c in d.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(d[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);return p
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(PARENT/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed']
    inputs=[PARENT/n for n in ['model.pb','mapping.json','transformation.json','result.json','audit/checks.json']]+[SOURCE/'plan.json',SOURCE/'audit/checks.json',BOXES/'plan.json']+sorted((SOURCE/'queries').glob('*.json'))+sorted((SOURCE/'mutual').glob('*.json'))+sorted((BOXES/'cases').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0,
        'method':'Remove every outer box variable and appended pair-cover constraint from the independently audited necessary model. Preserve all 10255 original variables and 57577 original constraints, with the 72 non-box advisory hints. Reimpose all394 query-difference rectangles. For every full original guarded forbidden face, calculate exact integer extrema of each outside inequality over its full rectangle. Drop only faces with one always-true edge and only edges that cannot be true anywhere in that rectangle. A zero-live-edge face forbids its active pair; a single live edge is required directly. Otherwise require an OR of all live directions, each implying its original inequality and pair activation. Share identical directional halfplanes only within a single pair/query mode. This is exactly equivalent to all original full guarded pair clauses within the original source inward integer domains; no simplification padding, outer boxes or partial-pair cuts remain. Audit the complete transformation before a fresh bounded diagnostic. The prior full181160-variable call remains closed; this formulation adds all proved domain/capacity exclusions, copy ordering, exact bounds and advisory six-cog hints derived since that call. Offline preparation does not qualify a production-budget pass.'})
    old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes());m=load(PARENT/'mapping.json');assert len(old.variables)==70926 and len(old.constraints)==180101
    model=cp_model_pb2.CpModelProto();model.CopyFrom(old);del model.variables[10255:];del model.constraints[57577:]
    for c in model.constraints:
        refs=list(c.enforcement_literal);kind=c.WhichOneof('constraint');refs+=list(c.linear.vars if kind=='linear' else getattr(c,kind).literals);assert all((v if v>=0 else -v-1)<10255 for v in refs)
    hints=[(v,x) for v,x in zip(old.solution_hint.vars,old.solution_hint.values) if v<10255];assert len(hints)==72;model.ClearField('solution_hint');model.solution_hint.vars.extend(v for v,x in hints);model.solution_hint.values.extend(x for v,x in hints)
    counts=Counter();newpairs=[];caseplan=load(BOXES/'plan.json');lookup={(p['case'],tuple(p['parts'])):p for p in m['outer_displacement_pairs']}
    for case in caseplan['cases']:
        data=load(BOXES/'cases'/f"{case['index']:03d}.json");r=data['difference_bounds_units1000'];original=load(SOURCE/'mutual'/f"{case['mutual_case']:03d}.json");faces=[]
        for fi,face in enumerate(original['faces']):
            bounds=[]
            for h in face['outside_halfplanes']:
                lo=h['a']*(r[0] if h['a']>=0 else r[2])+h['b']*(r[1] if h['b']>=0 else r[3]);hi=h['a']*(r[2] if h['a']>=0 else r[0])+h['b']*(r[3] if h['b']>=0 else r[1]);bounds.append([lo,hi])
            true=[i for i,((lo,hi),h) in enumerate(zip(bounds,face['outside_halfplanes'])) if lo>=h['bound']];live=[i for i,((lo,hi),h) in enumerate(zip(bounds,face['outside_halfplanes'])) if hi>=h['bound']]
            faces.append({'face':fi,'edge_extrema':bounds,'always_true_edges':true,'live_edges':live});counts['source_faces']+=1;counts['source_edges']+=len(bounds)
        write(OUT/'cases'/f"{case['index']:03d}.json",{'case':case,'difference_bounds_units1000':r,'faces':faces})
        for i,j in case['physical_pairs']:
            active=lookup[(case['index'],(i,j))]['active'];a,b=m['simultaneous_original_coordinates'][i],m['simultaneous_original_coordinates'][j];begin=len(model.constraints);varbegin=len(model.variables);edges={};clauses=[]
            model.constraints.add().CopyFrom(linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[active]));model.constraints.add().CopyFrom(linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[active]));counts['physical_pair_modes']+=1
            for face in faces:
                counts['physical_source_faces']+=1
                if face['always_true_edges']:counts['whole_face_tautologies']+=1;continue
                fi=face['face'];live=face['live_edges'];directions=[]
                if not live:
                    model.constraints.add().CopyFrom(linear([(active,1)],0,0));counts['impossible_faces']+=1
                elif len(live)==1:
                    h=original['faces'][fi]['outside_halfplanes'][live[0]];model.constraints.add().CopyFrom(linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[active]));counts['single_direction_faces']+=1
                else:
                    for hi in live:
                        h=original['faces'][fi]['outside_halfplanes'][hi];key=(h['a'],h['b'],h['bound'])
                        if key not in edges:
                            flag=len(model.variables);edges[key]=flag;model.variables.add(name=f"source-pair{i}-{j}-case{case['index']}-edge{len(edges)-1}",domain=[0,1]);counts['shared_direction_flags']+=1
                            model.constraints.add().CopyFrom(linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[flag]));model.constraints.add().CopyFrom(linear([(flag,1),(active,-1)],-2**63,0))
                        directions.append({'edge':hi,'flag':edges[key]})
                    clause=model.constraints.add();clause.bool_or.literals.extend([-active-1]+[d['flag'] for d in directions]);counts['disjunctive_faces']+=1;counts['physical_live_direction_uses']+=len(directions)
                clauses.append({'face':fi,'live_edges':live,'directions':directions})
            newpairs.append({'parts':[i,j],'case':case['index'],'mutual_case':case['mutual_case'],'query_a':case['query_a'],'query_b':case['query_b'],'active':active,'clauses':clauses,'constraint_span':[begin,len(model.constraints)],'new_variable_span':[varbegin,len(model.variables)]})
    newmap={k:v for k,v in m.items() if k!='outer_displacement_pairs'};newmap['source_pair_faces']=newpairs
    write(OUT/'mapping.json',newmap);write(OUT/'transformation.json',{'retained_parent_variable_prefix':10255,'retained_parent_constraint_prefix':57577,'removed_outer_box_variables':60671,'removed_outer_pair_constraints':122524,'retained_hints':72,'removed_box_hints':7,'all394_pair_modes_replaced':True})
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':72,**counts,'solver_calls':0,'model_sha256':digest(OUT/'model.pb'),'required_originals':66,'all_original_full_guarded_pair_clauses_retained':True,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
