"""Independent corner-extrema and complete source-clause model oracle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from itertools import product
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bounded-source-model-20261026';OUT=BASE/'audit';PARENT=ROOT/'output/h5-outer-original-model-20261026';BOXES=ROOT/'output/h5-outer-displacement-boxes-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify immutable source provenance and the complete retained parent prefix. Recompute all anchor union bounds directly from original query domains; enumerate all four difference-rectangle corners for every source halfplane, independently checking each recorded min/max and each whole-face/edge elimination. Reconstruct every variable, direct implication, shared direction, face OR and pair activation in order; verify all394 pair modes. Restore the exact parent protobuf after removing verified additions. Require identical mapping, non-box hints, and actual solver import/export. No source clause, guard or original domain may be weakened; no solver call.'})
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    for n,h in load(PARENT/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
    assert load(PARENT/'audit/checks.json')['passed']
    known={}
    for name in ['h5-direct-original-search-20261025','h5-all-original-cell-search-20261025','h5-six-cog-guided-search-20261025']:
        manifest=load(ROOT/'benchmarks/results'/name/'raw-manifest.json')
        for row in manifest['files']+manifest['aliases']:
            if row['path'].startswith('source-inputs/'):
                key=row['path'][len('source-inputs/'):]
                if key in known:assert known[key]==row['sha256']
                known[key]=row['sha256']
    sourcefiles=[SOURCE/'plan.json']+list((SOURCE/'queries').glob('*.json'))+list((SOURCE/'mutual').glob('*.json'))
    for p in sourcefiles:assert digest(p)==known[p.relative_to(ROOT).as_posix()]
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());actual=cp_model_pb2.CpModelProto();actual.ParseFromString((BASE/'model.pb').read_bytes());assert actual==text_format.Parse((BASE/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
    assert actual.variables[:10255]==parent.variables[:10255] and actual.constraints[:57577]==parent.constraints[:57577]
    oldmap=load(PARENT/'mapping.json');newmap=load(BASE/'mapping.json');assert {k:v for k,v in newmap.items() if k!='source_pair_faces'}=={k:v for k,v in oldmap.items() if k!='outer_displacement_pairs'}
    meta=load(BASE/'transformation.json');assert meta=={'retained_parent_variable_prefix':10255,'retained_parent_constraint_prefix':57577,'removed_outer_box_variables':60671,'removed_outer_pair_constraints':122524,'retained_hints':72,'removed_box_hints':7,'all394_pair_modes_replaced':True}
    pairs={(p['case'],tuple(p['parts'])):p for p in oldmap['outer_displacement_pairs']};assert len(pairs)==394
    vi=10255;ci=57577;expected=[];cornerchecks=0;counts=Counter();plan=load(BOXES/'plan.json')
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        terms={v:sum(c for w,c in terms if w==v) for v,c in terms};keys=sorted(v for v,c in terms.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(keys);p.linear.coeffs.extend(terms[v] for v in keys);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);assert actual.constraints[ci]==p,ci;ci+=1
    def variable(name):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[0,1]);vi+=1;return vi-1
    for case in plan['cases']:
        unions=[]
        for q in [case['query_a'],case['query_b']]:
            ds=load(SOURCE/'queries'/f'{q:03d}.json')['domains'];unions.append([min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)])
        a,b=unions;r=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];corners=list(product([r[0],r[2]],[r[1],r[3]]));original=load(SOURCE/'mutual'/f"{case['mutual_case']:03d}.json");faces=[]
        for fi,face in enumerate(original['faces']):
            ranges=[];always=[];live=[]
            for hi,h in enumerate(face['outside_halfplanes']):
                values=[h['a']*x+h['b']*y for x,y in corners];bounds=[min(values),max(values)];ranges.append(bounds);cornerchecks+=4
                if all(v>=h['bound'] for v in values):always.append(hi)
                if any(v>=h['bound'] for v in values):live.append(hi)
            faces.append({'face':fi,'edge_extrema':ranges,'always_true_edges':always,'live_edges':live});counts['source_faces']+=1;counts['source_edges']+=len(ranges)
        assert load(BASE/'cases'/f"{case['index']:03d}.json")=={'case':case,'difference_bounds_units1000':r,'faces':faces}
        for i,j in case['physical_pairs']:
            active=pairs[(case['index'],(i,j))]['active'];a,b=newmap['simultaneous_original_coordinates'][i],newmap['simultaneous_original_coordinates'][j];begin=ci;vb=vi;shared={};clauses=[]
            linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[active]);linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[active]);counts['physical_pair_modes']+=1
            for f in faces:
                counts['physical_source_faces']+=1
                if f['always_true_edges']:counts['whole_face_tautologies']+=1;continue
                fi=f['face'];live=f['live_edges'];ds=[]
                if not live:linear([(active,1)],0,0);counts['impossible_faces']+=1
                elif len(live)==1:
                    h=original['faces'][fi]['outside_halfplanes'][live[0]];linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[active]);counts['single_direction_faces']+=1
                else:
                    for hi in live:
                        h=original['faces'][fi]['outside_halfplanes'][hi];key=(h['a'],h['b'],h['bound'])
                        if key not in shared:
                            flag=variable(f"source-pair{i}-{j}-case{case['index']}-edge{len(shared)}");shared[key]=flag;linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[flag]);linear([(flag,1),(active,-1)],-2**63,0);counts['shared_direction_flags']+=1
                        ds.append({'edge':hi,'flag':shared[key]})
                    p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend([-active-1]+[d['flag'] for d in ds]);assert actual.constraints[ci]==p;ci+=1;counts['disjunctive_faces']+=1;counts['physical_live_direction_uses']+=len(ds)
                clauses.append({'face':fi,'live_edges':live,'directions':ds})
            expected.append({'parts':[i,j],'case':case['index'],'mutual_case':case['mutual_case'],'query_a':case['query_a'],'query_b':case['query_b'],'active':active,'clauses':clauses,'constraint_span':[begin,ci],'new_variable_span':[vb,vi]})
    assert expected==newmap['source_pair_faces'] and vi==len(actual.variables)==167044 and ci==len(actual.constraints)==376363
    hints=[(v,x) for v,x in zip(parent.solution_hint.vars,parent.solution_hint.values) if v<10255];assert list(zip(actual.solution_hint.vars,actual.solution_hint.values))==hints and len(hints)==72
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(actual);del restored.variables[10255:];restored.variables.extend(parent.variables[10255:]);del restored.constraints[57577:];restored.constraints.extend(parent.constraints[57577:]);restored.solution_hint.CopyFrom(parent.solution_hint);assert restored==parent
    result=load(BASE/'result.json');assert all(result[k]==v for k,v in counts.items()) and digest(BASE/'model.pb')==result['model_sha256']
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'));p=cp_model_pb2.CpModelProto();p.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert p==actual
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_files_verified':len(sourcefiles),'retained_parent_variables_verified':10255,'retained_parent_constraints_verified':57577,'exact_corner_extrema_checks':cornerchecks,'variables':vi,'constraints':ci,'hints_verified':72,**counts,'entire_parent_reconstructed_exactly':True,'actual_solver_import_export_verified':True,'all_original_full_guarded_source_clauses_equivalent':True,'all_original_domains_counts_areas_coordinates_activations_and_proved_exclusions_unchanged':True,'all_outer_boxes_removed':True,'all_strict_safe_cells_absent':True,'required_originals':66,'movable_originals':9,'fixed_originals':57,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
