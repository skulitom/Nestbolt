"""Build/test the isolated depth-three candidate on CCD1; no measurements."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h4-quadtree-depth-probe';WORK=OUT/'workspace';TARGET=ROOT/'output/h4-quadtree-depth-target'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(OUT/'preparation.json');records=[]
assert not (OUT/'build-opened.json').exists()
write(OUT/'build-opened.json',{'utc':datetime.now(timezone.utc).isoformat()})
def guards():
    assert digest(WORK/plan['one_changed_product_file'])==plan['candidate_sha256']
    for row in plan['baseline_files']:
        assert digest(ROOT/row['path'])==row['sha256'],'Production changed: '+row['path']
        if row['path']!=plan['one_changed_product_file']:assert digest(WORK/row['path'])==row['sha256'],'Unexpected candidate change: '+row['path']
def run(label,args,cwd=WORK):
    guards();log=OUT/(label+'.log');started=datetime.now(timezone.utc).isoformat()
    command=[sys.executable,str(ROOT/'output/ccd1.py'),*map(str,args)]
    with log.open('xb') as stream:p=subprocess.run(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
    row={'label':label,'command':command,'cwd':str(cwd),'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'log_sha256':digest(log)}
    records.append(row);write(OUT/'build-progress.json',records);print(json.dumps(row),flush=True)
    assert p.returncode==0,'Preserve original build failure: '+label
try:
    run('format',['cargo','fmt','--all','--check'])
    run('core-release',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',TARGET])
    run('clippy',['cargo','clippy','--locked','-p','nestbolt-core','--lib','--target-dir',TARGET,'--','-D','warnings'])
    run('cli',['cargo','build','--release','--locked','-p','nestbolt-cli','--target-dir',TARGET])
    shutil.copyfile(TARGET/'release/nestbolt.exe',OUT/'nestbolt-depth3.exe')
    run('wasm',['cargo','build','--release','--locked','-p','nestbolt-wasm','--target','wasm32-unknown-unknown','--target-dir',TARGET])
    run('bindings',['wasm-bindgen','--target','web','--out-dir',WORK/'web/src/pkg',TARGET/'wasm32-unknown-unknown/release/nestbolt_wasm.wasm'])
    run('types',['node',ROOT/'web/node_modules/typescript/bin/tsc','--noEmit'],WORK/'web')
    run('bundle',['node',ROOT/'web/node_modules/vite/bin/vite.js','build'],WORK/'web')
    guards();write(OUT/'build.json',{'all_checks_passed':True,'stages':records,'production_unchanged':True,'candidate_sha256':plan['candidate_sha256'],'cli_sha256':digest(OUT/'nestbolt-depth3.exe'),'wasm_sha256':digest(WORK/'web/src/pkg/nestbolt_wasm_bg.wasm'),'site':{p.relative_to(WORK/'web/dist').as_posix():digest(p) for p in sorted((WORK/'web/dist').rglob('*')) if p.is_file()},'measured_search_started':False,'integrated':False})
except BaseException:
    write(OUT/'build-failure.json',{'error':traceback.format_exc(),'stages':records});raise
