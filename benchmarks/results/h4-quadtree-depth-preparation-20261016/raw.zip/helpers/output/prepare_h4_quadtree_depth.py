"""Prepare one isolated separator-window quadtree-depth experiment."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
ROOT=Path.cwd();OUT=ROOT/'output/h4-quadtree-depth-probe';WORK=OUT/'workspace';TARGET=ROOT/'output/h4-quadtree-depth-target'
assert not OUT.exists() and not TARGET.exists()
names=subprocess.check_output(['git','ls-files','-z','--','crates','.cargo','web','Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE','THIRD_PARTY_NOTICES','examples/validation-job.json'],cwd=ROOT).decode().split('\0')
rows=[]
for name in filter(None,names):
    source=ROOT/name;target=WORK/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    rows.append({'path':name,'sha256':sha256(source.read_bytes()).hexdigest()})
p=WORK/'crates/core/src/sheets/vstrip.rs';s=p.read_text(encoding='utf-8')
old='        let mut cde = DEFAULT_SPARROW_CONFIG.cde_config;\n        cde.quadtree_depth += '
new='''        let mut cde = DEFAULT_SPARROW_CONFIG.cde_config;
        // Profile-guided experiment: trade one tree level for more leaf work.
        // Keep all original geometry, leaf threshold and aspect scaling.
        cde.quadtree_depth = 3;
        cde.quadtree_depth += '''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
modules=WORK/'web/node_modules'
subprocess.run(['powershell','-NoProfile','-Command',"New-Item -ItemType Junction -Path '"+str(modules)+"' -Target '"+str(ROOT/'web/node_modules')+"' | Out-Null"],check=True)
notices=WORK/'web/public/THIRD_PARTY_NOTICES.txt';notices.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/'web/public/THIRD_PARTY_NOTICES.txt',notices)
plan={'scope':__doc__,'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
 'production_candidate':'7eba929420d218d04169c1fdf24481051c8afae5',
 'hypothesis':'Current profiles show edge collection/quadrant traversal at 47-76% of samples. Lower separator-window base tree depth from 4 to 3, retaining aspect scaling, to reduce traversal; larger leaf work could instead hurt.',
 'one_changed_product_file':'crates/core/src/sheets/vstrip.rs','candidate_sha256':sha256(p.read_bytes()).hexdigest(),
 'baseline_files':rows,'unique_target':str(TARGET),
 'unchanged':['original outlines and exports','independent validator','constructor and upstream strip paths','leaf threshold 64','aspect-depth adjustment','surrogate geometry','score arithmetic','work coefficients','deadlines','budgets','dependencies','public options'],
 'not_claimed':['fixed-work byte identity: hazard traversal order can change','speed improvement','material improvement','H4 pass','release readiness'],
 'measurement_prerequisite':'H5 early-exchange pilot must finish and be sealed before any new measured search',
 'source_freeze':'Production and existing H5 observer workspaces stay untouched','integrated':False,'measured_search_started':False,'held_out_geometry_read':False}
(OUT/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'copied':len(rows),'single_change':plan['one_changed_product_file'],'candidate_sha256':plan['candidate_sha256']}))
