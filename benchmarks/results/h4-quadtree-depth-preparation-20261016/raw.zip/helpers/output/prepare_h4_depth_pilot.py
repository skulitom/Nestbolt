"""Create the one-use depth-three diagnostic runner and seal its build evidence."""
from pathlib import Path
from hashlib import sha256
import json, shutil, zipfile

ROOT=Path(__file__).resolve().parents[1]
PROBE=ROOT/'output/h4-quadtree-depth-probe'
OUT=ROOT/'benchmarks/results/h4-quadtree-depth-preparation-20261016'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')

source=(ROOT/'scripts/h4_score_chunks_probe.py').read_text(encoding='utf-8')
start=source.index('import argparse')
source='''"""One isolated separator-window depth-three experiment, never H4 completion.

Current CPU profiles identify collision-tree traversal as the main sampled cost.
Test one shallower level; retain original geometry, leaf threshold, aspect-depth
adjustment, budgets, work coefficients, score arithmetic and public defaults.
The unchanged eleven-job subset runs once: native/Chrome/Firefox, seeds 0-2,
60 seconds on eight physical CCD0 cores. Original +1% median/+5% job limits.
No exact fixed-work identity claim: hazard traversal order can change.
Prepare and commit before running. The opened marker forbids an unchanged retry.
"""\n'''+source[start:]
source=source.replace("PROBE=ROOT/'output/h4-score-granularity-probe'", "PROBE=ROOT/'output/h4-quadtree-depth-probe'")
source=source.replace("CANDIDATE=PROBE/'nestbolt-score-chunks8.exe'", "CANDIDATE=PROBE/'nestbolt-depth3.exe'")
source=source.replace("ORIGINAL=ROOT/'benchmarks/results/h4-preview-development-20261016'\nREPLAY_IDS=['example-letters','m-public-gear-1']", "ORIGINAL=ROOT/'benchmarks/results/h4-preview-score-release-20261016'\nPREP=ROOT/'benchmarks/results/h4-quadtree-depth-preparation-20261016'\nH5=ROOT/'benchmarks/results/h5-early-exchange-pilot-20261016'")
source=source.replace("paths=[Path(__file__),CANDIDATE,PROBE/'build-v3.json',PROBE/'plan.json',\n           PROBE/'formatted-v3-plan.json',PROBE/'bounded-tests-v2.json']\n    paths += [WORK/r['path'] for r in load(PROBE/'plan.json')['baseline_files']]", "paths=[Path(__file__),CANDIDATE,PROBE/'build.json',PROBE/'preparation.json',PREP/'raw.zip',PREP/'integrity.json']\n    paths += [WORK/r['path'] for r in load(PROBE/'preparation.json')['baseline_files']]\n    paths += [ROOT/r['path'] for r in load(PROBE/'preparation.json')['baseline_files']]")
source=source.replace("assert load(PROBE/'build-v3.json')['all_passed']", "assert load(PROBE/'build.json')['all_checks_passed']\n    assert load(PREP/'integrity.json')['crc_and_every_member_verified']")
source=source.replace("'baseline_product':'0a9fb440560bf96f5a81bd05e3f50d7df01238b3'", "'baseline_product':'7eba929420d218d04169c1fdf24481051c8afae5'")
a=source.index("'concurrency':8,'replay':")
b=source.index("        'gates':",a)
source=source[:a]+"'concurrency':8,'attempts':99,'fixed_work_identity_claim':False,\n"+source[b:]
source=source.replace("'source_change':'Eight-pair score-bound granularity only, plus explicit test coverage'", "'source_change':'Separator-window base quadtree depth 4 to 3 only',\n        'prerequisites':'Original complete matrix and H5 early-exchange pilot terminal and sealed',\n        'failure_policy':'Retain every failed/incomplete attempt; no unchanged retry or seed substitution',\n        'temperature_limitation':'No available reliable temperature sensor; CPU frequency is not temperature'")
a=source.index('\ndef replay_one(');b=source.index('\ndef native(',a);source=source[:a]+source[b:]
source=source.replace("assert load(ORIGINAL/'integrity.json')['crc_and_every_member_verified'], 'Seal the complete original first'", "assert load(ORIGINAL/'integrity.json')['crc_and_every_member_verified'], 'Seal the complete original first'\n    assert load(H5/'verification.json')['all_original_archives_verified']\n    assert load(H5/'assessment.json')['valid_attempts']==72\n    h5pid=load(H5/'opened.json')['pid']\n    assert not psutil.pid_exists(h5pid) or not any('h5_early_exchange_pilot.py' in p for p in psutil.Process(h5pid).cmdline())")
a=source.index('        replay_rows=');b=source.index('        preflight()',a);source=source[:a]+source[b:]
(ROOT/'scripts/h4_quadtree_depth_probe.py').write_text(source,encoding='utf-8',newline='\n')
compile(source,'h4_quadtree_depth_probe.py','exec')

plan=load(PROBE/'preparation.json');build=load(PROBE/'build.json')
assert build['all_checks_passed'] and len(build['stages'])==8
assert build['candidate_sha256']==plan['candidate_sha256']
for r in plan['baseline_files']:
    assert digest(ROOT/r['path'])==r['sha256']
    assert digest(PROBE/'workspace'/r['path'])==(plan['candidate_sha256'] if r['path']==plan['one_changed_product_file'] else r['sha256'])
OUT.mkdir()
files={}
for p in PROBE.iterdir():
    if p.is_file():files['build/'+p.name]=p
for r in plan['baseline_files']:
    files['baseline/'+r['path']]=ROOT/r['path']
    files['candidate/'+r['path']]=PROBE/'workspace'/r['path']
for folder in ['web/dist','web/src/pkg']:
    for p in sorted((PROBE/'workspace'/folder).rglob('*')):
        if p.is_file():files['candidate/'+p.relative_to(PROBE/'workspace').as_posix()]=p
for name in ['output/prepare_h4_quadtree_depth.py','output/build_h4_quadtree_depth.py','output/prepare_h4_depth_pilot.py','output/ccd1.py','scripts/h4_quadtree_depth_probe.py']:
    files['helpers/'+name]=ROOT/name
inventory={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in files.items()}
archive=OUT/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,r in inventory.items():
        data=z.read(name);assert len(data)==r['bytes'] and sha256(data).hexdigest()==r['sha256']
write(OUT/'integrity.json',{'sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'crc_and_every_member_verified':True})
for name in ['preparation.json','build.json']:shutil.copyfile(PROBE/name,OUT/name)
report='''# Isolated collision-tree depth preparation — 2026-10-16

**All eight preparation stages pass. No quality or speed gain is claimed.**

The current preview's [CPU profiles](h4-browser-profile-20261016T040030Z.md)
put edge collection and quadrant traversal at 46.5–75.7% of sampled time.
This isolated candidate lowers only the separator-window base quadtree depth
from four to three. Aspect scaling, leaf threshold, original outlines,
independent validation, score arithmetic, work coefficients, budgets, public
options and dependencies are unchanged. Fewer tree visits may cost more leaf
work. Hazard traversal order may change; fixed-work byte identity is not assumed.

The copy uses its own Cargo target. All 196 baseline files retain their hashes;
only `crates/core/src/sheets/vstrip.rs` differs in the candidate. Production is
unchanged. Format, 75 optimized core tests, strict core lint, native build, WASM
build, bindings, TypeScript and browser bundle pass on CCD1. This preparation
has not run measured searches or read held-out geometry.

[Preparation](h4-quadtree-depth-preparation-20261016/preparation.json),
[build results](h4-quadtree-depth-preparation-20261016/build.json),
[exact source/build archive](h4-quadtree-depth-preparation-20261016/raw.zip),
[member verification](h4-quadtree-depth-preparation-20261016/integrity.json).
The archive retains both source copies, exact executable/WASM/site, all logs
and preparation helpers. CRC, every size and every SHA-256 are verified.

The next single-use pilot fixes all 11 declared development jobs, seeds 0–2,
60 seconds, native/Chrome/Firefox and at most eight physical CCD0 cores.
All 99 attempts must validate independently. Original +1% median and +5% job
limits remain unchanged. It starts only after both previous measured sessions
are terminal and sealed. A pilot cannot complete H4 or establish release readiness;
full quality/native comparisons, scale and current packaging checks remain.
The failed preview and rejected common-line candidate remain preserved.
Completed milestone weight stays 45%.
'''
(OUT.parent/(OUT.name+'.md')).write_text(report,encoding='utf-8',newline='\n')
print(json.dumps({'archive_sha256':digest(archive),'members':len(inventory),'bytes':archive.stat().st_size}))
