"""Exactly one fixed-region continuous repair call, with all consumed work charged."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';OUT=BASE/'search';PREP=ROOT/'output/h5-cog-convex-repair-preparation-process-20261107';AUDIT=ROOT/'output/h5-cog-convex-repair-audit-v2-process-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/shop-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child(started):
    from fractions import Fraction as F
    from scipy.optimize._highspy import _core as h
    from h5_cog_convex_lp_tools_v2_20261107 import make_highs,residuals
    plan=load(OUT/'plan.json');checked=load(BASE/'audit-v2/checks.json');assert checked['passed']
    for name,value in plan['inputs'].items():assert digest(ROOT/name)==value,name
    for name,record in load(BASE/'audit-v2/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==record['sha256'],name
    assert digest(BASE/'model-exact.json')==checked['model_exact_sha256'] and digest(BASE/'model-numeric.json')==checked['model_numeric_sha256']
    raw=load(BASE/'model-exact.json');numeric=load(BASE/'model-numeric.json');solver,options,readback=make_highs(numeric,1.0,OUT/'solver.log')
    remaining=60-(time.perf_counter()-started)-4
    if remaining<=0:
        write(OUT/'result.json',{'closed':True,'solver_calls':0,'status':'NO_SOLVE_TIME','algorithm_seconds_including_preparation':time.perf_counter()-started,'source_valid66':False});return
    assert solver.setOptionValue('time_limit',remaining)==h.HighsStatus.kOk;status,value=solver.getOptionValue('time_limit');assert status==h.HighsStatus.kOk and value==remaining;options['time_limit']=remaining
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'options':options,'model_readback':readback,'model_exact_sha256':checked['model_exact_sha256'],'model_numeric_sha256':checked['model_numeric_sha256'],'maximum_calls':1,'retry_permitted':False,'algorithm_seconds_including_preparation_at_open':time.perf_counter()-started})
    before=time.perf_counter();run_status=solver.run();elapsed=time.perf_counter()-before;model_status=solver.getModelStatus();info=solver.getInfo();solution=solver.getSolution()
    response={'run_status':str(run_status),'model_status':str(model_status),'status':solver.modelStatusToString(model_status),'solver_runtime_seconds':solver.getRunTime(),'returned_solve_seconds':elapsed,'allocated_solve_seconds':remaining,'solve_slice_overrun_seconds':max(0.,elapsed-remaining),'primal_solution_status':info.primal_solution_status,'dual_solution_status':info.dual_solution_status,'simplex_iterations':info.simplex_iteration_count,'value_valid':solution.value_valid,'dual_valid':solution.dual_valid,'objective':info.objective_function_value if solution.value_valid else None,'values':list(solution.col_value) if solution.value_valid else None,'row_values':list(solution.row_value) if solution.value_valid else None,'row_duals':list(solution.row_dual) if solution.dual_valid else None,'column_duals':list(solution.col_dual) if solution.dual_valid else None}
    write(OUT/'response.json',response);source_valid=False;source_calls=0;state=response['status'];numeric_ok=None
    if model_status==h.HighsModelStatus.kOptimal and run_status==h.HighsStatus.kOk and solution.value_valid:
        values=list(solution.col_value);read=residuals(raw,values);write(OUT/'exact-residuals.json',read)
        normalized=[F(s)/n['scale'] for s,n in zip(read['row_slacks_exact'],numeric['rows'])]
        bounds=[F(s) for b in read['bound_slacks_exact'] for s in b if s is not None]
        numeric_ok=min(normalized)>=-F(1,10**7) and min(bounds)>=-F(1,10**7)
        write(OUT/'numeric-feasibility.json',{'passed':numeric_ok,'minimum_normalized_row_slack':str(min(normalized)),'minimum_bound_slack_grid':str(min(bounds)),'tolerance_grid':1e-7,'exact_negative_rows':read['negative_rows'],'exact_negative_bounds':read['negative_bounds'],'source_check_still_required':True})
        if numeric_ok and time.perf_counter()-started<60:
            from h5_legacy64_source_readback import audit
            first=ROOT/'output/h5-first57-direct-short9-20261104';spec=load(first/'plan.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');inventory=load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json')
            rows=load(first/'fixed29.json')+load(first/'short9-source.json')
            for owner in raw['owners']:
                oid=owner['owner'];world=[values[2*oid]/100,values[2*oid+1]/100+2100]
                rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':owner['rotation_radians'],'mirrored':owner['mirrored'],'translation':[world[k]+owner['translation_from_lower_left'][k] for k in [0,1]]}})
            write(OUT/'candidate-source66.json',rows);before=time.perf_counter();source=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,inventory['full66_identities'])));source_seconds=time.perf_counter()-before;source_calls=1
            assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
            write(OUT/'original-source-checks.json',source);write(OUT/'source-time.json',{'seconds':source_seconds});source_valid=source['valid'];state='SOURCE_VALID_CANDIDATE' if source_valid else 'SOURCE_INVALID_CANDIDATE'
        else:state='NUMERIC_OR_TIME_STOP'
    elapsed_all=time.perf_counter()-started
    write(OUT/'result.json',{'closed':True,'solver_calls':1,'status':state,'solver_status':response['status'],'has_assignment':bool(response['value_valid']),'source_checker_calls':source_calls,'source_valid66':source_valid,'numeric_feasible':numeric_ok,'algorithm_seconds_including_preparation':elapsed_all,'algorithm_overrun_seconds':max(0.,elapsed_all-60),'preparation_seconds_charged':plan['preparation_seconds_charged'],'any_allocation_excluded':False,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
def main():
    assert load(BASE/'audit-v2/checks.json')['passed'] and load(AUDIT/'process.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py')
    charge=load(BASE/'plan.json')['preparation_before_model_seconds']+load(PREP/'prepare.json')['complete_seconds'];started=time.perf_counter()-charge
    source=ROOT/'output/h5-first57-direct-short9-20261104'
    files=[Path(__file__),ROOT/'output/h5_cog_convex_lp_tools_v2_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',BASE/'plan.json',BASE/'model-exact.json',BASE/'model-numeric.json',BASE/'audit-v2/plan.json',BASE/'audit-v2/checks.json',BASE/'audit-v2/solver-controls.json',BASE/'audit-v2/tool-provenance.json',PREP/'prepare.json',PREP/'process.json',AUDIT/'process.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json']+[source/n for n in ['plan.json','fixed29.json','short9-source.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'maximum_calls':1,'retry_permitted':False,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'preparation_seconds_charged':charge,'budget_rule':'Entire closed candidate pipeline plus complete projection preparation plus complete new model preparation; no original preparation double counting. Every import, readback, solve and source check now counts. Verification recorded separately.','solver':'Pinned embedded HiGHS1.12.0/SciPy1.17.1 dual simplex; one thread; no warm start; seed0; presolve on.','blas_threads':1,'infeasibility_scope':'Only these selected modes and convex choices; no source-domain or allocation exclusion.','native_requires_full66_source_validation':True})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
    cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'aggregate_memory_bytes':2**31,'preparation_seconds_charged':charge,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    command=subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)])
    r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),command,str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env)
    (OUT/'supervisor-stdout.txt').write_bytes(r.stdout);(OUT/'supervisor-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'repeat_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; this call remains closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
