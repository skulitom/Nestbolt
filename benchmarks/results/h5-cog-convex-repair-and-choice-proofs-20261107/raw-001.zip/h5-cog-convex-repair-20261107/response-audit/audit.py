"""Reconcile the sole LP response, exact selected-choice proof and all costs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import defaultdict
import json,time,shutil
from h5_cog_convex_repair_reader_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';S=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');raw=load(BASE/'model-exact.json');numeric=load(BASE/'model-numeric.json');assert verify(raw,numeric)['passed']
response=load(S/'response.json');result=load(S/'result.json');process=load(S/'process.json');opened=load(S/'opened.json');plan=load(S/'plan.json');sup=load(S/'supervisor-opened.json');job=load(S/'job.json')
assert result['closed'] and result['solver_calls']==1 and result['solver_status']==result['status']=='Infeasible' and not result['has_assignment'] and result['source_checker_calls']==0 and not result['source_valid66'] and result['native_calls']==0 and not result['any_allocation_excluded']
assert response['run_status']=='HighsStatus.kOk' and response['model_status']=='HighsModelStatus.kInfeasible' and response['simplex_iterations']==0 and not response['value_valid'] and not response['dual_valid']
for key in ['values','row_values','row_duals','column_duals','objective']:assert response[key] is None
assert not (S/'candidate-source66.json').exists() and not (S/'original-source-checks.json').exists()
assert opened['model_exact_sha256']==digest(BASE/'model-exact.json') and opened['model_numeric_sha256']==digest(BASE/'model-numeric.json')
options=opened['options'];assert options=={'solver':'simplex','simplex_strategy':1,'presolve':'on','parallel':'off','threads':1,'random_seed':0,'time_limit':response['allocated_solve_seconds'],'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9,'output_flag':True,'log_to_console':False,'log_file':str(S/'solver.log')}
assert opened['model_readback']['passed'] and opened['model_readback']['variables']==112 and opened['model_readback']['rows']==1730 and opened['model_readback']['nonzeros']==3952
assert response['returned_solve_seconds']<=response['allocated_solve_seconds'] and response['solve_slice_overrun_seconds']==0 and response['solver_runtime_seconds']<=response['returned_solve_seconds']
assert response['allocated_solve_seconds']+opened['algorithm_seconds_including_preparation_at_open']<=56.01
before=load(BASE/'plan.json')['preparation_before_model_seconds'];prep=load(ROOT/'output/h5-cog-convex-repair-preparation-process-20261107/prepare.json')['complete_seconds'];charge=before+prep
assert plan['preparation_seconds_charged']==result['preparation_seconds_charged']==sup['preparation_seconds_charged']==charge
assert charge<result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0
assert process['exit_code']==0 and process['job']==job and process['closed'] and process['tree_closed'] and job['closed'] and job['active_processes']==job['error_code']==job['reason_code']==0 and job['peak_job_committed_memory']<2**31 and job['complete_ms']<=job['maximum_ms'] and job['assigned_before_resume'] and job['resumed']
assert load(BASE/'audit-v2/checks.json')['passed'] and load(BASE/'interval-proof/audit/checks.json')['passed']
core=load(BASE/'interval-proof/core.json');assert len(core['rows'])==6
coeff=defaultdict(int);upper=0
for ri in core['rows']:
    row=raw['rows'][ri];upper+=row['upper']
    for i,c in row['terms']:coeff[i]+=c
terms=sorted([[i,c] for i,c in coeff.items() if c]);minimum=sum(c*raw['bounds'][i][0 if c>0 else 1] for i,c in terms)
assert terms==[[0,1],[14,-1]] and upper==-128821 and minimum==-118694 and minimum>upper
pairs=load(ROOT/'output/h5-cog-candidate-projections-20261107/pair-projections.json')
chain={'source_rows':core['rows'],'multipliers':[1]*6,'summed_terms':terms,'summed_upper_grid':upper,'minimum_possible_lhs_grid':minimum,'contradiction_margin_grid':minimum-upper,'required_horizontal_span_mm':-upper/100,'available_horizontal_span_mm':-minimum/100,'excess_mm':(minimum-upper)/100,'selected_choices':[{'pair':raw['rows'][i]['source'][0],'kind':pairs[raw['rows'][i]['source'][0]]['selected_kind'],'source_id':pairs[raw['rows'][i]['source'][0]]['selected_source_id']} for i in core['rows']],'interpretation':'At least one of these six selected convex-region choices must change. The sum contradicts current selected-mode stock bounds even if every other pair/orthogonal constraint is removed. It does not exclude the fixed source modes under other region choices, another mode set, or any allocation.'}
write(OUT/'six-region-chain.json',chain)
inputs=[Path(__file__),ROOT/'output/h5_cog_convex_repair_reader_20261107.py',BASE/'plan.json',BASE/'model-exact.json',BASE/'model-numeric.json',BASE/'audit-v2/plan.json',BASE/'audit-v2/checks.json',BASE/'audit-v2/tool-provenance.json',BASE/'interval-proof/audit/plan.json',BASE/'interval-proof/audit/checks.json',BASE/'interval-proof/core.json',S/'plan.json',S/'supervisor-opened.json',S/'opened.json',S/'response.json',S/'result.json',S/'process.json',S/'solver.log',S/'job.json',ROOT/'output/h5-cog-convex-repair-preparation-process-20261107/opened.json',ROOT/'output/h5-cog-convex-repair-preparation-process-20261107/process.json',ROOT/'output/h5-cog-convex-repair-audit-v2-process-20261107/opened.json',ROOT/'output/h5-cog-convex-repair-audit-v2-process-20261107/process.json']
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
for name,record in load(BASE/'audit-v2/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==record['sha256']
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Re-read all exact/numeric source fields and reconcile the one closed pinned LP response, option/model readback, complete consumed preparation, timings, memory and closure. Independently sum the six original source rows from the exact interval certificate to a1288.21mm required horizontal span versus1186.94mm permitted by stock bounds. This exact continuous contradiction refutes only the six chosen safe regions under these selected modes; no allocation is excluded. All prior calls and failed verification bytes remain closed and preserved.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings':len(bindings),'closed_source_solver_calls':1,'solver_status':'Infeasible','exact_selected_choice_contradiction':True,'conflicting_region_choices':6,'contradiction_excess_mm':101.27,'variables':112,'rows':1730,'nonzeros':3952,'preparation_seconds_charged':charge,'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'peak_job_committed_memory':job['peak_job_committed_memory'],'all_descendants_closed':True,'new_assignments':0,'source_valid66':False,'native_calls':0,'any_allocation_excluded':False,'fixed_arrangements_remaining':4,'whole_allocations_remaining':440,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
