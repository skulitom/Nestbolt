"""Read all model fields, reject corruptions and check the pinned LP bridge."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,copy,shutil,sys
import numpy as np
import scipy
from scipy.optimize._highspy import _core as h
from h5_cog_convex_repair_reader_20261107 import verify
from h5_cog_convex_lp_tools_v2_20261107 import numeric_model,make_highs,residuals
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';OUT=BASE/'audit-v2'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');raw=load(BASE/'model-exact.json');numeric=load(BASE/'model-numeric.json');checked=verify(raw,numeric)
rejected=[]
for case in ['missing_row','wrong_sign','relaxed_stock','wrong_objective','lost_mode','bad_scaling']:
    rr,nn=copy.deepcopy(raw),copy.deepcopy(numeric)
    if case=='missing_row':rr['rows'].pop();nn['rows'].pop()
    elif case=='wrong_sign':rr['rows'][0]['terms'][0][1]*=-1;nn=numeric_model(rr)
    elif case=='relaxed_stock':rr['bounds'][0][0]-=1;nn=numeric_model(rr)
    elif case=='wrong_objective':rr['objective'][0]=1;nn=numeric_model(rr)
    elif case=='lost_mode':rr['owners'][0]['mode']+=1
    else:nn['rows'][0]['upper']+=.001
    try:verify(rr,nn)
    except AssertionError:rejected.append(case)
    else:raise AssertionError('Accepted corrupted model: '+case)
controls=[]
problems=[('optimal',{'bounds':[[0,1],[0,1]],'objective':[-1,-1],'rows':[{'terms':[[0,1],[1,1]],'upper':1.5}]}),('infeasible',{'bounds':[[0,2]],'objective':[0],'rows':[{'terms':[[0,1]],'upper':0},{'terms':[[0,-1]],'upper':-1}]})]
for name,problem in problems:
    # Explicit binary64 control rows; no source-model solve or geometry consumed.
    model={'bounds':problem['bounds'],'objective':problem['objective'],'rows':[dict(r,scale=1) for r in problem['rows']]}
    solver,options,readback=make_highs(model,1.0,OUT/(name+'.log'));begin=time.perf_counter();run=solver.run();elapsed=time.perf_counter()-begin
    status=solver.getModelStatus();assert run==h.HighsStatus.kOk
    if name=='optimal':
        assert status==h.HighsModelStatus.kOptimal;x=list(solver.getSolution().col_value);assert abs(sum(x)-1.5)<1e-12 and all(0<=v<=1 for v in x) and solver.getInfo().objective_function_value==-1.5
    else:assert status==h.HighsModelStatus.kInfeasible;x=None
    controls.append({'name':name,'status':solver.modelStatusToString(status),'seconds':elapsed,'values':x,'options':options,'model_readback':readback})
# This only loads/readbacks the actual model. No actual source solver call here.
solver,options,readback=make_highs(numeric,1.0,OUT/'source-model-load.log')
write(OUT/'solver-controls.json',{'passed':True,'scipy_version':scipy.__version__,'highs_version':solver.version(),'synthetic_calls':len(controls),'source_model_calls':0,'records':controls,'actual_model_readback':readback,'actual_model_options_readback':options})
toolpaths=[Path(sys.executable),Path(h.__file__),Path(scipy.__file__),ROOT/'.cache/shop-venv/Lib/site-packages/scipy/optimize/_highspy/_highs_wrapper.py',ROOT/'.cache/shop-venv/Lib/site-packages/scipy-1.17.1.dist-info/LICENSE.txt',ROOT/'output/h5-highs-1.12.0-LICENSE.txt']
provenance={'scipy_version':scipy.__version__,'highs_version':solver.version(),'numpy_version':np.__version__,'python_version':sys.version,'tool_files':{p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in toolpaths},'highs_license':'MIT','highs_license_source':'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.12.0/LICENSE.txt','scipy_license':'BSD-3-Clause','primary_api_sources':['installed scipy/optimize/_highspy/_highs_wrapper.py','https://ergo-code.github.io/HiGHS/dev/options/definitions/'],'research_only_no_production_dependency':True}
assert (ROOT/'output/h5-highs-1.12.0-LICENSE.txt').read_text().startswith('MIT License');write(OUT/'tool-provenance.json',provenance)
inputs=[ROOT/'output/h5-cog-convex-audit-correction-20261107.json',ROOT/'output/h5-cog-convex-repair-preparation-process-20261107/process.json',Path(__file__),ROOT/'output/h5_cog_convex_repair_reader_20261107.py',ROOT/'output/h5_cog_convex_lp_tools_v2_20261107.py',ROOT/'output/h5-highs-1.12.0-LICENSE.txt',BASE/'plan.json',BASE/'model-exact.json',BASE/'model-numeric.json',BASE/'checks.json',ROOT/'output/h5-cog-candidate-projections-20261107/audit/plan.json',ROOT/'output/h5-cog-candidate-projections-20261107/audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently substitute all112 world basis vectors into each original canonical pair-plane expression; read every row, stock bound, fixed mode, absolute-motion auxiliary and objective. Verify every numeric coefficient/RHS equals its exact integer source after power-of-two scaling. Reject six corruptions. Run two synthetic LP controls with pinned SciPy1.17.1/HiGHS1.12.0 and read back every option, variable, bound, objective and sparse matrix field. Load but do not solve the actual model. Version/license/binary provenance preserved. This is verification time, not construction consumed by the future candidate.'})
write(OUT/'checks.json',{'passed':True,**checked,'seconds':time.perf_counter()-start,'corrupted_models_rejected':rejected,'synthetic_solver_controls':len(controls),'source_solver_calls':0,'actual_model_loaded_and_read_back':True,'model_exact_sha256':digest(BASE/'model-exact.json'),'model_numeric_sha256':digest(BASE/'model-numeric.json'),'source_valid66':False,'H5_complete':False});print(load(OUT/'checks.json'))
