"""Replay every bound deduction using exact rational, continuous inequalities."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';P=BASE/'interval-proof';OUT=P/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');model=load(BASE/'model-exact.json');cert=load(P/'certificate.json');d=cert['denominator'];assert d==10**6;bounds=[[F(a),F(b)] for a,b in model['bounds'][:56]];last=[[-1,-1] for _ in bounds]
for si,step in enumerate(cert['steps']):
    row=model['rows'][step['row']];assert row['kind'] not in ['absolute_positive','absolute_negative'];i=step['variable'];c=dict(row['terms'])[i];side=step['side'];assert side==(1 if c>0 else 0) and bounds[i][side]==F(step['old'],d)
    expected_parents=[[j,0 if v>0 else 1,last[j][0 if v>0 else 1]] for j,v in row['terms'] if j!=i];assert step['parents']==expected_parents
    rhs=F(row['upper'])-sum(v*bounds[j][0 if v>0 else 1] for j,v in row['terms'] if j!=i);exact=rhs/c;new=F(step['new'],d)
    if side==1:assert exact<=new<exact+F(1,d) and new<bounds[i][side]
    else:assert exact-F(1,d)<new<=exact and new>bounds[i][side]
    bounds[i][side]=new;last[i][side]=si
    if si!=len(cert['steps'])-1:assert all(lo<=hi for lo,hi in bounds)
assert [[str(v) for v in b] for b in bounds]==[[str(F(v,d)) for v in b] for b in cert['final_bounds']]
end=cert['conclusion'];contradiction=False
if end['kind']=='row':
    row=model['rows'][end['row']];minimum=sum(c*bounds[i][0 if c>0 else 1] for i,c in row['terms']);assert minimum>row['upper'] and minimum*d==end['minimum'] and row['upper']*d==end['upper'];assert end['parents']==[[i,0 if c>0 else 1,last[i][0 if c>0 else 1]] for i,c in row['terms']];contradiction=True
elif end['kind']=='bounds':
    i=end['variable'];assert bounds[i][0]>bounds[i][1] and end['parents']==[[i,k,last[i][k]] for k in [0,1]];contradiction=True
else:assert end['kind'] in ['limit','fixed_point']
core=load(P/'core.json');required=set();pending=[r[2] for r in end.get('parents',[]) if r[2]>=0]
while pending:
    i=pending.pop()
    if i in required:continue
    required.add(i);pending.extend(r[2] for r in cert['steps'][i]['parents'] if r[2]>=0)
rows={cert['steps'][i]['row'] for i in required}
if end['kind']=='row':rows.add(end['row'])
assert core['steps']==sorted(required) and core['rows']==sorted(rows) and core['source_rows']==[{**model['rows'][i],'row':i} for i in sorted(rows)]
inputs=[Path(__file__),P/'plan.json',P/'certificate.json',P/'core.json',P/'checks.json',BASE/'model-exact.json',BASE/'audit-v2/plan.json',BASE/'audit-v2/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replay every deduction in exact rational arithmetic; independently check antecedents, the continuous inequality, outward rounding and strict improvement. Verify the terminal row/bound contradiction and its exact dependency closure. These selected region choices only are refuted, never the complete source domain or any allocation.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'bound_deductions_verified':len(cert['steps']),'exact_continuous_selected_model_contradiction':contradiction,'core_rows':len(rows),'core_bound_steps':len(required),'cog_pairs_in_core':sorted({model['rows'][i]['source'][0] for i in rows if model['rows'][i]['kind']=='cog_region'}),'orthogonal_separators_in_core':sorted({model['rows'][i]['source'] for i in rows if model['rows'][i]['kind']=='orthogonal'}),'solver_calls':0,'any_allocation_excluded':False};write(OUT/'checks.json',checks);print(checks)
