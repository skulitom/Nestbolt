"""Exact outward-rounded bound deductions for this one chosen convex model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';OUT=BASE/'interval-proof';D=10**6
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');model=load(BASE/'model-exact.json');bounds=[[a*D,b*D] for a,b in model['bounds'][:56]];history=[[-1,-1] for _ in bounds];steps=[];stop=None;scans=0
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'model-exact.json',BASE/'audit-v2/plan.json',BASE/'audit-v2/checks.json',BASE/'search/response.json',BASE/'search/process.json']},'method':'Exact continuous bound propagation using integer numerators at a fixed1e6 denominator in grid units. Every inferred lower bound rounds down and upper bound rounds up, preserving a necessary continuous enclosure. Store each parent bound reference and replay the resulting contradiction without a numerical solver. Scope is only the selected convex regions and fixed modes; no original continuous-domain or allocation exclusion.','denominator':D,'maximum_passes':128,'maximum_row_scans':200000,'maximum_seconds':20,'solver_calls':0,'retry_permitted':False})
rows=[(i,r) for i,r in enumerate(model['rows']) if r['kind'] not in ['absolute_positive','absolute_negative']];assert len(rows)==1618
for sweep in range(128):
    changed=0
    for ri,row in rows:
        scans+=1
        if scans>200000 or time.perf_counter()-start>20:stop={'kind':'limit','scan':scans};break
        terms=row['terms'];upper=row['upper']*D;parents=[[j,0 if c>0 else 1,history[j][0 if c>0 else 1]] for j,c in terms];minimum=sum(c*bounds[j][0 if c>0 else 1] for j,c in terms)
        if minimum>upper:stop={'kind':'row','row':ri,'minimum':minimum,'upper':upper,'parents':parents};break
        for i,c in terms:
            others=[(j,v) for j,v in terms if j!=i];parents=[[j,0 if v>0 else 1,history[j][0 if v>0 else 1]] for j,v in others];remainder=upper-sum(v*bounds[j][0 if v>0 else 1] for j,v in others)
            side=1 if c>0 else 0;new=-((-remainder)//c) if c>0 else remainder//c
            if (side==1 and new<bounds[i][1]) or (side==0 and new>bounds[i][0]):
                step={'row':ri,'variable':i,'side':side,'old':bounds[i][side],'new':new,'parents':parents};bounds[i][side]=new;history[i][side]=len(steps);steps.append(step);changed+=1
                if bounds[i][0]>bounds[i][1]:stop={'kind':'bounds','variable':i,'bounds':bounds[i].copy(),'parents':[[i,k,history[i][k]] for k in [0,1]]};break
        if stop:break
    if stop:break
    if not changed:stop={'kind':'fixed_point','passes':sweep+1};break
if stop is None:stop={'kind':'limit','passes':128}
core_steps=set();todo=[p[2] for p in stop.get('parents',[]) if p[2]>=0]
while todo:
    si=todo.pop()
    if si in core_steps:continue
    core_steps.add(si);todo.extend(p[2] for p in steps[si]['parents'] if p[2]>=0)
core_rows={steps[si]['row'] for si in core_steps}
if stop['kind']=='row':core_rows.add(stop['row'])
core={'steps':sorted(core_steps),'rows':sorted(core_rows),'source_rows':[{**model['rows'][i],'row':i} for i in sorted(core_rows)]}
write(OUT/'certificate.json',{'denominator':D,'steps':steps,'conclusion':stop,'final_bounds':bounds});write(OUT/'core.json',core)
checks={'passed':True,'seconds':time.perf_counter()-start,'row_scans':scans,'bound_updates':len(steps),'conclusion':stop['kind'],'exact_selected_model_contradiction':stop['kind'] in ['row','bounds'],'core_rows':len(core_rows),'core_bound_steps':len(core_steps),'solver_calls':0,'any_allocation_excluded':False};write(OUT/'checks.json',checks);print(checks)
