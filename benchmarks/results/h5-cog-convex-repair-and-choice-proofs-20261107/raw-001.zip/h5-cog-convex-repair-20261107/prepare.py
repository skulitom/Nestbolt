"""One new fixed-mode continuous repair; no solver calls in preparation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_cog_convex_lp_tools_20261107 import numeric_model
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';F=ROOT/'output/h5-staged-cog-candidate-checkpoint-20261107';OUT=ROOT/'output/h5-cog-convex-repair-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(P/'audit/checks.json')['passed'];OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
files=[Path(__file__),ROOT/'output/h5_cog_convex_lp_tools_20261107.py',F/'next-step.json',F/'next-preparation-charges.json',P/'plan.json',P/'audit/plan.json',P/'audit/checks.json']+[P/n for n in ['regions.json','owners.json','pair-projections.json','orthogonal-separators.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'method':'Fix the returned candidate modes; move all28 original owners continuously inside their certified stock bounds. Choose exactly the nearest certified convex region for every cog pair and the audited axis separators for all orthogonal components. Retain the cog X-order domain chain. Minimize L1 coordinate movement with56 absolute-motion auxiliaries. Exact integer constraints are scaled only by powers of two, with exact Fraction verification of every binary64 coefficient and RHS. No solver or global exclusion in preparation.','position_units_per_mm':100,'world_origin_mm':[0,2100],'maximum_solver_calls':1,'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'memory_bytes':2**31,'preparation_before_model_seconds':load(F/'next-step.json')['preparation_seconds_before_new_model_build'],'infeasibility_scope':'Only the chosen modes and convex regions; no continuous/allocation exclusion.','retry_permitted':False})
owners=load(P/'owners.json');regions=load(P/'regions.json');pairs=load(P/'pair-projections.json');seps=load(P/'orthogonal-separators.json');rows=[]
def row(kind,source,terms,upper):
    terms=sorted([[i,c] for i,c in terms.items() if c]);assert terms
    rows.append({'kind':kind,'source':source,'terms':terms,'upper':upper})
for pair in pairs:
    a,b=pair['owners'];q=pair['matrix'];off=pair['offset_grid'];region=next(r for r in regions if (r['class'],r['kind'],r['source_id'])==(pair['class'],pair['selected_kind'],pair['selected_source_id']));assert not region['empty']
    for pi,plane in enumerate(region['planes']):
        n=plane['coefficients'];c=[sum(n[k]*q[k][j] for k in [0,1]) for j in [0,1]]
        row('cog_region',[pair['pair'],pi],{2*b+j:c[j] for j in [0,1]}|{2*a+j:-c[j] for j in [0,1]},plane['upper']-sum(n[k]*off[k] for k in [0,1]))
for index,s in enumerate(seps):row('orthogonal',index,{2*s['positive_owner']+s['axis']:1,2*s['negative_owner']+s['axis']:-1},s['upper'])
cogs=[o['owner'] for o in owners if o['identity'][0]=='cog']
for a,b in zip(cogs,cogs[1:]):row('cog_x_order',[a,b],{2*a:1,2*b:-1},0)
for owner in owners:
    for axis in [0,1]:
        i=2*owner['owner']+axis;p=owner['position_grid'][axis]
        row('absolute_positive',i,{i:1,56+i:-1},p);row('absolute_negative',i,{i:-1,56+i:-1},-p)
raw={'bounds':[b for o in owners for b in o['position_bounds_grid']]+[[0,None] for _ in range(56)],'objective':[0]*56+[1]*56,'rows':rows,'owners':owners,'cog_pairs':258,'orthogonal_component_pairs':268,'cog_x_orders':11}
write(OUT/'model-exact.json',raw);numeric=numeric_model(raw);write(OUT/'model-numeric.json',numeric)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_movers':28,'variables':len(raw['bounds']),'rows':len(rows),'cog_region_rows':sum(r['kind']=='cog_region' for r in rows),'orthogonal_rows':268,'cog_order_rows':11,'absolute_motion_rows':112,'binary64_scaling_exact':True,'model_exact_sha256':digest(OUT/'model-exact.json'),'model_numeric_sha256':digest(OUT/'model-numeric.json'),'solver_calls':0,'source_valid66':False,'H5_complete':False});print(load(OUT/'checks.json'))
