"""One bounded proof-guided search for a changed convex-region combination."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,heapq,shutil
from h5_cog_convex_choice_model_20261107 import source,model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';OUT=ROOT/'output/h5-cog-convex-choice-search-20261107';D=10**6
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def propagate(raw,deadline):
    bounds=[[a*D,b*D] for a,b in raw['bounds'][:56]];last=[[-1,-1] for _ in bounds];steps=[];scans=0;end=None
    rows=[(i,r) for i,r in enumerate(raw['rows']) if r['kind'] not in ['absolute_positive','absolute_negative']]
    for sweep in range(128):
        changed=0
        for ri,row in rows:
            scans+=1
            if scans>200000 or (scans%128==0 and time.perf_counter()>=deadline):end={'kind':'limit'};break
            terms=row['terms'];upper=row['upper']*D;minimum=sum(c*bounds[i][0 if c>0 else 1] for i,c in terms)
            if minimum>upper:end={'kind':'row','row':ri,'minimum':minimum,'upper':upper,'parents':[[i,0 if c>0 else 1,last[i][0 if c>0 else 1]] for i,c in terms]};break
            for i,c in terms:
                others=[(j,v) for j,v in terms if j!=i];parents=[[j,0 if v>0 else 1,last[j][0 if v>0 else 1]] for j,v in others];rest=upper-sum(v*bounds[j][0 if v>0 else 1] for j,v in others);side=1 if c>0 else 0;new=-((-rest)//c) if c>0 else rest//c
                if (side==1 and new<bounds[i][1]) or (side==0 and new>bounds[i][0]):
                    steps.append({'row':ri,'variable':i,'side':side,'old':bounds[i][side],'new':new,'parents':parents});bounds[i][side]=new;last[i][side]=len(steps)-1;changed+=1
                    if bounds[i][0]>bounds[i][1]:end={'kind':'bounds','variable':i,'parents':[[i,k,last[i][k]] for k in [0,1]]};break
            if end:break
        if end:break
        if not changed:end={'kind':'fixed_point'};break
    if end is None:end={'kind':'limit'}
    required=set();todo=[p[2] for p in end.get('parents',[]) if p[2]>=0]
    while todo:
        i=todo.pop()
        if i in required:continue
        required.add(i);todo.extend(p[2] for p in steps[i]['parents'] if p[2]>=0)
    core={steps[i]['row'] for i in required}
    if end['kind']=='row':core.add(end['row'])
    pairs=sorted({raw['rows'][i]['source'][0] for i in core if raw['rows'][i]['kind']=='cog_region'})
    return {'steps':steps,'conclusion':end,'core_steps':sorted(required),'core_rows':sorted(core),'core_pairs':pairs,'final_bounds':bounds,'row_scans':scans}
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+8
assert load(BASE/'response-audit/checks.json')['passed'];base,options,tail,ranked=source()
inputs=[Path(__file__),ROOT/'output/h5_cog_convex_choice_model_20261107.py',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',BASE/'response-audit/six-region-chain.json',BASE/'model-exact.json',BASE/'search/process.json']+[ROOT/'output/h5-cog-candidate-projections-20261107'/n for n in ['plan.json','audit/plan.json','audit/checks.json','pair-projections.json','all-ranked-projections.json','regions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'The exact six-region contradiction requires a changed choice. Search distinct source-region assignments in deterministic increasing sum-of-ranks order, with full vector lexicographic ties. Reuse the already proved all-zero root; each contradictory node branches only by incrementing one causally involved pair choice. All stock/modes/orthogonal separators and cog-order constraints stay fixed. Exact outward-rounded continuous bound deductions either refute a node, reach a necessary fixed point, or stop at a cap. Stop at the first fixed point; it is not a feasible LP or source layout. No numerical solver calls.','denominator':D,'maximum_seconds':8,'maximum_nodes':256,'maximum_row_scans_per_node':200000,'maximum_passes_per_node':128,'retry_permitted':False,'closed_root_replayed':False,'lp_calls':0,'any_allocation_excluded':False})
root=(0,)*258;root_pairs=sorted({r['pair'] for r in load(BASE/'response-audit/six-region-chain.json')['selected_choices']});heap=[];seen={root}
def children(ranks,core):
    generated=[]
    for pair in core:
        if ranks[pair]+1>=len(options[pair]):continue
        child=list(ranks);child[pair]+=1;child=tuple(child)
        if child in seen:continue
        seen.add(child);heapq.heappush(heap,(sum(child),child));generated.append(pair)
    return generated
children(root,root_pairs);records=[];selected=None;state='NODE_LIMIT'
for index in range(256):
    if time.perf_counter()>=deadline:state='TIME_LIMIT';break
    if not heap:state='ENUMERATED_BRANCHES_EXHAUSTED';break
    cost,ranks=heapq.heappop(heap);raw=model(base,options,tail,ranks);proof=propagate(raw,deadline);changes=[[i,r] for i,r in enumerate(ranks) if r]
    record={'node':index,'cost':cost,'changes':changes,'proof':proof};kind=proof['conclusion']['kind']
    if kind=='fixed_point':selected=ranks;state='NECESSARY_FIXED_POINT';record['generated_children_pairs']=[]
    elif kind=='limit':state='PROPAGATION_LIMIT';record['generated_children_pairs']=[]
    else:record['generated_children_pairs']=children(ranks,proof['core_pairs'])
    records.append(record)
    if selected is not None or kind=='limit':break
write(OUT/'nodes.json',records);write(OUT/'frontier.json',{'pending_nodes':len(heap),'seen_states':len(seen),'minimum_pending_cost':heap[0][0] if heap else None})
if selected is not None:
    write(OUT/'selected-ranks.json',list(selected));write(OUT/'selected-model-exact.json',model(base,options,tail,selected))
checks={'passed':True,'seconds':time.perf_counter()-start,'status':state,'nodes':len(records),'contradictory_nodes':sum(r['proof']['conclusion']['kind'] in ['row','bounds'] for r in records),'selected_necessary_combination':selected is not None,'selected_changed_pairs':[] if selected is None else [[i,r] for i,r in enumerate(selected) if r],'lp_calls':0,'source_valid66':False,'any_allocation_excluded':False,'repeat_permitted':False};write(OUT/'checks.json',checks);print(checks)
