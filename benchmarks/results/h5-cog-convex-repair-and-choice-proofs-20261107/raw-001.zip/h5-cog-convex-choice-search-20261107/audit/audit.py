"""Independent exact source-row and certificate replay for all distinct choices."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,heapq,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-convex-repair-20261107';P=ROOT/'output/h5-cog-candidate-projections-20261107';C=ROOT/'output/h5-cog-convex-choice-search-20261107';OUT=C/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');base=load(BASE/'model-exact.json');records=load(C/'nodes.json');plan=load(C/'plan.json');regions=load(P/'regions.json');pairs=load(P/'pair-projections.json');ranked=load(P/'all-ranked-projections.json');cache={};rows_checked=0
def pair_rows(index,rank):
    global rows_checked
    key=index,rank
    if key in cache:return cache[key]
    pair=pairs[index];choice=ranked[index]['ranked'][rank];matches=[r for r in regions if (r['class'],r['kind'],r['source_id'])==(pair['class'],choice['kind'],choice['source_id'])];assert len(matches)==1 and not matches[0]['empty'];rows=[]
    for pi,plane in enumerate(matches[0]['planes']):
        def value(x):
            aa,bb=pair['owners'];delta=[x[2*bb+k]-x[2*aa+k] for k in [0,1]];z=[sum(pair['matrix'][k][j]*delta[j] for j in [0,1])+pair['offset_grid'][k] for k in [0,1]]
            return sum(v*z[k] for k,v in enumerate(plane['coefficients']))
        constant=value([0]*56);terms=[]
        for i in range(56):
            basis=[0]*56;basis[i]=1;c=value(basis)-constant
            if c:terms.append([i,c])
        rows.append({'kind':'cog_region','source':[index,pi],'terms':terms,'upper':plane['upper']-constant});rows_checked+=1
    cache[key]=rows;return rows
tail=[r for r in base['rows'] if r['kind']!='cog_region'];assert [r for i in range(258) for r in pair_rows(i,0)]+tail==base['rows']
root=(0,)*258;seen={root};heap=[]
def children(ranks,core):
    generated=[]
    for pi in core:
        if ranks[pi]+1==len(ranked[pi]['ranked']):continue
        rr=list(ranks);rr[pi]+=1;rr=tuple(rr)
        if rr in seen:continue
        seen.add(rr);heapq.heappush(heap,(sum(rr),rr));generated.append(pi)
    return generated
children(root,sorted({r['pair'] for r in load(BASE/'response-audit/six-region-chain.json')['selected_choices']}));updates=0;cores=[]
for ni,record in enumerate(records):
    cost,ranks=heapq.heappop(heap);assert record['node']==ni and record['cost']==cost and record['changes']==[[i,r] for i,r in enumerate(ranks) if r]
    rows=[r for i,rank in enumerate(ranks) for r in pair_rows(i,rank)]+tail;proof=record['proof'];bounds=[[F(a),F(b)] for a,b in base['bounds'][:56]];last=[[-1,-1] for _ in bounds]
    for si,step in enumerate(proof['steps']):
        row=rows[step['row']];assert row['kind'] not in ['absolute_positive','absolute_negative'];i=step['variable'];coef=dict(row['terms'])[i];side=1 if coef>0 else 0;assert step['side']==side and bounds[i][side]==F(step['old'],10**6)
        assert step['parents']==[[j,0 if c>0 else 1,last[j][0 if c>0 else 1]] for j,c in row['terms'] if j!=i]
        exact=(row['upper']-sum(c*bounds[j][0 if c>0 else 1] for j,c in row['terms'] if j!=i))/coef;new=F(step['new'],10**6)
        if side==1:assert exact<=new<exact+F(1,10**6) and new<bounds[i][side]
        else:assert exact-F(1,10**6)<new<=exact and new>bounds[i][side]
        bounds[i][side]=new;last[i][side]=si;updates+=1
        if si<len(proof['steps'])-1:assert all(lo<=hi for lo,hi in bounds)
    assert bounds==[[F(v,10**6) for v in b] for b in proof['final_bounds']]
    end=proof['conclusion'];assert end['kind'] in ['row','bounds']
    if end['kind']=='row':
        row=rows[end['row']];minimum=sum(c*bounds[i][0 if c>0 else 1] for i,c in row['terms']);assert minimum>row['upper'] and minimum*10**6==end['minimum'] and row['upper']*10**6==end['upper'];assert end['parents']==[[i,0 if c>0 else 1,last[i][0 if c>0 else 1]] for i,c in row['terms']]
    else:
        i=end['variable'];assert bounds[i][0]>bounds[i][1] and end['parents']==[[i,k,last[i][k]] for k in [0,1]]
    required=set();todo=[p[2] for p in end['parents'] if p[2]>=0]
    while todo:
        si=todo.pop()
        if si in required:continue
        required.add(si);todo.extend(p[2] for p in proof['steps'][si]['parents'] if p[2]>=0)
    core_rows={proof['steps'][si]['row'] for si in required}
    if end['kind']=='row':core_rows.add(end['row'])
    core_pairs=sorted({rows[i]['source'][0] for i in core_rows if rows[i]['kind']=='cog_region'})
    assert proof['core_steps']==sorted(required) and proof['core_rows']==sorted(core_rows) and proof['core_pairs']==core_pairs
    assert record['generated_children_pairs']==children(ranks,core_pairs)
    cores.append({'node':ni,'choices':[[i,ranks[i]] for i in core_pairs],'core_rows':sorted(core_rows)})
assert len(records)==plan['maximum_nodes']==256 and plan['maximum_seconds']==8 and load(C/'checks.json')['seconds']<8 and load(C/'checks.json')['status']=='NODE_LIMIT' and not (C/'selected-ranks.json').exists()
assert load(C/'frontier.json')=={'pending_nodes':len(heap),'seen_states':len(seen),'minimum_pending_cost':heap[0][0] if heap else None}
process=load(ROOT/'output/h5-cog-convex-choice-preparation-process-20261107/process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0 and process['job']['peak_job_committed_memory']<2**31
inputs=[Path(__file__),BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',BASE/'response-audit/six-region-chain.json',BASE/'model-exact.json',BASE/'audit-v2/plan.json',BASE/'audit-v2/checks.json']+[P/n for n in ['plan.json','audit/plan.json','audit/checks.json','regions.json','pair-projections.json','all-ranked-projections.json']]+[C/n for n in ['plan.json','nodes.json','frontier.json','checks.json']]+[ROOT/'output/h5-cog-convex-choice-preparation-process-20261107'/n for n in ['opened.json','process.json']]
write(OUT/'certified-choice-nogoods.json',cores)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct every used region plane independently by world basis substitution. Replay all bound updates as exact continuous rational inequalities, outward rounding, antecedents, terminal contradictions and minimal dependency closure. Reconstruct deterministic best-first branching, seen-state deduplication and exact256-node stop. The frozen search remains closed with no LP or layout. Certified no-good clauses concern only each selected region combination under these modes and fixed separator assumptions.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'distinct_closed_nodes':len(records),'exact_continuous_contradictions':len(cores),'bound_deductions_verified':updates,'source_pair_region_choices_reconstructed':len(cache),'source_planes_independently_reconstructed':rows_checked,'pending_states_not_searched':len(heap),'seen_states':len(seen),'minimum_pending_rank_sum':heap[0][0] if heap else None,'lp_calls':0,'source_valid66':False,'any_allocation_excluded':False,'repeat_or_extension_permitted':False};write(OUT/'checks.json',checks);print(checks)
