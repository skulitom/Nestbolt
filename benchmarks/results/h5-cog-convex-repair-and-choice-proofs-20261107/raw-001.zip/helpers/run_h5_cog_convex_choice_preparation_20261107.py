from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-convex-choice-preparation-process-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';SCRIPT=ROOT/'output/prepare_h5_cog_convex_choice_search_20261107.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,ROOT/'output/h5_cog_convex_choice_model_20261107.py',EXE,EXE.parent/'checks.json']},'maximum_ms':15000,'memory_bytes':2**31,'internal_search_cap_seconds':8,'maximum_nodes':256,'retry_permitted':False,'lp_calls':0})
r=subprocess.run([str(EXE),'15000',str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([sys_executable:=__import__('sys').executable,str(SCRIPT)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=23)
(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');passed=r.returncode==0 and job['reason_code']==job['error_code']==0 and job['closed'] and job['active_processes']==0
record={'passed':passed,'closed':job['closed'],'complete_seconds':time.perf_counter()-start,'exit_code':r.returncode,'job':job,'repeat_permitted':False};write(OUT/'process.json',record);print(record)
