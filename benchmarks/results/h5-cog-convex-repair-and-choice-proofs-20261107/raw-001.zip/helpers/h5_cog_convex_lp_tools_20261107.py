"""Pinned HiGHS bridge; exact dyadic rows and explicit option/model readback."""
from fractions import Fraction as F
import math

def numeric_model(raw):
    result={'bounds':raw['bounds'],'objective':raw['objective'],'rows':[]}
    for row in raw['rows']:
        scale=1 << max(0,max(abs(v) for _,v in row['terms']).bit_length()-1)
        terms=[[i,v/scale] for i,v in row['terms']];upper=row['upper']/scale
        assert all(F(value)*scale==v for (_,value),(_,v) in zip(terms,row['terms']))
        assert F(upper)*scale==row['upper']
        result['rows'].append({'terms':terms,'upper':upper,'scale':scale})
    return result

def make_highs(model,seconds,log):
    import numpy as np
    import scipy
    from scipy.optimize._highspy import _core as h
    assert scipy.__version__=='1.17.1'
    solver=h._Highs();assert solver.version()=='1.12.0'
    options={'solver':'simplex','simplex_strategy':1,'presolve':'on','parallel':'off','threads':1,'random_seed':0,'time_limit':float(seconds),'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9,'output_flag':True,'log_to_console':False,'log_file':str(log)}
    for k,v in options.items():
        assert solver.setOptionValue(k,v)==h.HighsStatus.kOk,(k,v)
        status,actual=solver.getOptionValue(k);assert status==h.HighsStatus.kOk and actual==v,(k,v,actual)
    starts=[0];indices=[];values=[]
    for row in model['rows']:
        for index,value in row['terms']:indices.append(index);values.append(value)
        starts.append(len(indices))
    lp=h.HighsLp();lp.num_col_=len(model['bounds']);lp.num_row_=len(model['rows'])
    lp.col_cost_=np.asarray(model['objective'],dtype=float)
    lp.col_lower_=np.asarray([b[0] if b[0] is not None else -h.kHighsInf for b in model['bounds']],dtype=float)
    lp.col_upper_=np.asarray([b[1] if b[1] is not None else h.kHighsInf for b in model['bounds']],dtype=float)
    lp.row_lower_=np.full(lp.num_row_,-h.kHighsInf);lp.row_upper_=np.asarray([r['upper'] for r in model['rows']],dtype=float)
    lp.a_matrix_.format_=h.MatrixFormat.kRowwise;lp.a_matrix_.num_col_=lp.num_col_;lp.a_matrix_.num_row_=lp.num_row_
    lp.a_matrix_.start_=np.asarray(starts,dtype=np.int32);lp.a_matrix_.index_=np.asarray(indices,dtype=np.int32);lp.a_matrix_.value_=np.asarray(values,dtype=float)
    assert solver.passModel(lp)==h.HighsStatus.kOk
    actual=solver.getLp();assert actual.num_col_==lp.num_col_ and actual.num_row_==lp.num_row_ and actual.sense_==h.ObjSense.kMinimize and actual.offset_==0 and len(actual.integrality_)==0
    for key in ['col_cost_','col_lower_','col_upper_','row_lower_','row_upper_']:assert list(getattr(actual,key))==list(getattr(lp,key)),key
    assert actual.a_matrix_.format_==h.MatrixFormat.kRowwise
    for key in ['start_','index_','value_']:assert list(getattr(actual.a_matrix_,key))==list(getattr(lp.a_matrix_,key)),key
    return solver,options,{'passed':True,'variables':lp.num_col_,'rows':lp.num_row_,'nonzeros':len(values),'all_bounds_objective_rows_options_read_back':True}

def residuals(raw,values):
    assert len(values)==len(raw['bounds']) and all(math.isfinite(v) for v in values)
    exact=list(map(F,values));rows=[];bounds=[]
    for row in raw['rows']:rows.append(F(row['upper'])-sum(c*exact[i] for i,c in row['terms']))
    for x,(lo,hi) in zip(exact,raw['bounds']):bounds.append([None if lo is None else x-lo,None if hi is None else hi-x])
    return {'row_slacks_exact':[str(v) for v in rows],'bound_slacks_exact':[[None if v is None else str(v) for v in b] for b in bounds],'negative_rows':[i for i,v in enumerate(rows) if v<0],'negative_bounds':[[i,k] for i,b in enumerate(bounds) for k,v in enumerate(b) if v is not None and v<0],'objective_exact':str(sum(c*v for c,v in zip(raw['objective'],exact)))}
