"""Source-derived region substitutions; no solver imports or source mutations."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';B=ROOT/'output/h5-cog-convex-repair-20261107'
load=lambda p:json.loads(p.read_bytes())
def source():
    base=load(B/'model-exact.json');pairs=load(P/'pair-projections.json');ranked=load(P/'all-ranked-projections.json');regions=load(P/'regions.json');lookup={(r['class'],r['kind'],r['source_id']):r for r in regions};options=[]
    for pair,choices in zip(pairs,ranked):
        assert pair['pair']==choices['pair'];a,b=pair['owners'];q=pair['matrix'];offset=pair['offset_grid'];pair_options=[]
        for choice in choices['ranked']:
            region=lookup[pair['class'],choice['kind'],choice['source_id']];assert not region['empty'];rows=[]
            for pi,plane in enumerate(region['planes']):
                n=plane['coefficients'];terms={}
                for axis in [0,1]:
                    v=sum(n[k]*q[k][axis] for k in [0,1])
                    if v:terms[2*a+axis]=-v;terms[2*b+axis]=v
                rows.append({'kind':'cog_region','source':[pair['pair'],pi],'terms':sorted([[i,c] for i,c in terms.items()]),'upper':plane['upper']-sum(n[k]*offset[k] for k in [0,1])})
            pair_options.append(rows)
        options.append(pair_options)
    tail=[r for r in base['rows'] if r['kind']!='cog_region'];assert [r for choices in options for r in choices[0]]+tail==base['rows']
    return base,options,tail,ranked
def model(base,options,tail,ranks):
    assert len(ranks)==len(options)==258 and all(0<=r<len(o) for r,o in zip(ranks,options))
    return {**base,'rows':[row for i,r in enumerate(ranks) for row in options[i][r]]+tail}
