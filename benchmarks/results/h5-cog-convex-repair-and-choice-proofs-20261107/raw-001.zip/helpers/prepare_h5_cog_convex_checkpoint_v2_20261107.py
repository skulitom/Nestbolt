from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'output';old=D/'audit_h5_cog_convex_checkpoint_20261107.py'
text=old.read_text(encoding='utf-8').replace("OUT=ROOT/'output/h5-cog-convex-checkpoint-20261107'","OUT=ROOT/'output/h5-cog-convex-checkpoint-v2-20261107'")
text=text.replace('record=load(p)\n    for name,h',"record=load(p)\n    if not isinstance(record,dict):continue\n    for name,h")
text=text.replace('inputs=[Path(__file__)',"inputs=[ROOT/'output/h5-cog-convex-checkpoint-correction-20261107.json',Path(__file__)")
ast.parse(text)
record={'preserved_inputs':{old.relative_to(ROOT).as_posix():sha256(old.read_bytes()).hexdigest()},'failure':'Checkpoint reader called .get on the top-level certified-choice-nogoods JSON list. It stopped before writing its plan/checks; the two already-written charge records are preserved.','correction':'v2 walks inputs/preserved_inputs only on JSON objects, while retaining and hashing list documents as input evidence. No source geometry, prepared model, solver or choice search is repeated.','failed_output_directory':'output/h5-cog-convex-checkpoint-20261107'}
with (D/'h5-cog-convex-checkpoint-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
with (D/'audit_h5_cog_convex_checkpoint_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
