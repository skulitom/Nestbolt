"""Independent source substitution, signs, domains, objective and scaling reader."""
from pathlib import Path
from fractions import Fraction as F
import json
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107'
load=lambda p:json.loads(p.read_bytes())
def verify(raw,numeric):
    owners=load(P/'owners.json');pairs=load(P/'pair-projections.json');regions=load(P/'regions.json');seps=load(P/'orthogonal-separators.json')
    assert raw['owners']==owners and len(owners)==28 and [o['owner'] for o in owners]==list(range(28))
    assert raw['bounds']==[o['position_bounds_grid'][k] for o in owners for k in [0,1]]+[[0,None]]*56
    assert raw['objective']==[0]*56+[1]*56 and raw['cog_pairs']==258 and raw['orthogonal_component_pairs']==268 and raw['cog_x_orders']==11
    expected=[]
    def add(kind,source,coeff,upper):expected.append({'kind':kind,'source':source,'terms':[[i,c] for i,c in enumerate(coeff) if c],'upper':upper})
    for pair in pairs:
        match=[r for r in regions if r['class']==pair['class'] and r['kind']==pair['selected_kind'] and r['source_id']==pair['selected_source_id']];assert len(match)==1 and not match[0]['empty']
        for pi,plane in enumerate(match[0]['planes']):
            # Derive the affine expression by applying it to each world basis vector.
            def expression(x):
                a,b=pair['owners'];delta=[x[2*b+k]-x[2*a+k] for k in [0,1]]
                z=[sum(pair['matrix'][k][j]*delta[j] for j in [0,1])+pair['offset_grid'][k] for k in [0,1]]
                return sum(v*z[k] for k,v in enumerate(plane['coefficients']))
            zero=expression([0]*112);coeff=[]
            for i in range(112):
                x=[0]*112;x[i]=1;coeff.append(expression(x)-zero)
            add('cog_region',[pair['pair'],pi],coeff,plane['upper']-zero)
    for si,s in enumerate(seps):
        c=[0]*112;c[2*s['positive_owner']+s['axis']]=1;c[2*s['negative_owner']+s['axis']]=-1;add('orthogonal',si,c,s['upper'])
    cogs=[o['owner'] for o in owners if o['identity'][0]=='cog'];assert cogs==list(range(16,28))
    for a,b in zip(cogs,cogs[1:]):
        c=[0]*112;c[2*a]=1;c[2*b]=-1;add('cog_x_order',[a,b],c,0)
    for i in range(56):
        pos=owners[i//2]['position_grid'][i%2]
        for sign,kind in [(1,'absolute_positive'),(-1,'absolute_negative')]:
            c=[0]*112;c[i]=sign;c[56+i]=-1;add(kind,i,c,sign*pos)
    assert raw['rows']==expected
    assert set(numeric)=={'bounds','objective','rows'} and numeric['bounds']==raw['bounds'] and numeric['objective']==raw['objective'] and len(numeric['rows'])==len(expected)
    numbers=0
    for exact,num in zip(expected,numeric['rows']):
        scale=num['scale'];assert type(scale)==int and scale>0 and scale&(scale-1)==0
        maximum=max(abs(c) for _,c in exact['terms']);assert scale<=maximum<scale*2
        assert [i for i,c in num['terms']]==[i for i,c in exact['terms']]
        for (_,v),(_,c) in zip(num['terms'],exact['terms']):assert F(v)*scale==c;numbers+=1
        assert F(num['upper'])*scale==exact['upper'];numbers+=1
    assert set(raw)=={'bounds','objective','rows','owners','cog_pairs','orthogonal_component_pairs','cog_x_orders'}
    return {'passed':True,'variables':112,'rows':len(expected),'source_cog_pairs':258,'orthogonal_component_pairs':268,'fixed_modes':28,'cog_x_orders':11,'absolute_motion_rows':112,'exact_binary64_values':numbers,'all_fields_checked':True}
