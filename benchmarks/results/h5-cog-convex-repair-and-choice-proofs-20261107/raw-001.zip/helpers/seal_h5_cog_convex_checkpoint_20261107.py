"""Preserve the closed convex repair, exact conflict and bounded choice proofs."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1]
prior=(ROOT/'output/seal_h5_cog_capacity_search_checkpoint_v2_20261107.py').read_text(encoding='utf-8');prefix=prior[:prior.index('copies=[')]
prefix=prefix.replace("NAME='h5-cog-capacity-search-and-initial-model-v2-20261107'","NAME='h5-cog-convex-repair-and-choice-proofs-20261107'")
prefix=prefix.replace("H=ROOT/'output/h5-independent-cog-capacity-20261107';C=ROOT/'output/h5-independent-cog-lazy-20261107';F=ROOT/'output/h5-cog-capacity-search-checkpoint-20261107'","H=ROOT/'output/h5-cog-convex-repair-20261107';C=ROOT/'output/h5-cog-convex-choice-search-20261107';F=ROOT/'output/h5-cog-convex-checkpoint-v2-20261107'")
prefix=prefix.replace("front['closed_solver_status']=='UNKNOWN' and not front['pipeline_prepared']","front['closed_solver_status']=='Infeasible' and not front['new_joint_choice_model_prepared']")
prefix=prefix.replace("'h5-cog-halfplane-search-and-capacity-20261107'])","'h5-cog-halfplane-search-and-capacity-20261107','h5-cog-capacity-search-and-initial-model-v2-20261107','h5-staged-cog-candidate-and-projections-20261107'])")
prefix=prefix.replace("['h5-independent-cog-capacity-model-process-20261107','h5-independent-cog-lazy-initial-process-20261107','h5-cog-halfplane-capacity-main-sync-20261107']","['h5-cog-convex-repair-preparation-process-20261107','h5-cog-convex-repair-audit-v2-process-20261107','h5-cog-convex-choice-preparation-process-20261107','h5-cog-convex-checkpoint-20261107']")
prefix=prefix.replace("['*h5*independent*cog*capacity*20261107.py','*h5*independent*cog*lazy*20261107.py','*h5*cog*capacity*search*20261107.py']","['*h5*cog*convex*20261107.py']")
prefix=prefix.replace("for name in ['ccd1.py'","for name in ['seal_h5_cog_capacity_search_checkpoint_v2_20261107.py','ccd1.py'")
prefix=prefix.replace("for name,h in load(F/'source-bindings.json').items():","for name in ['h5-cog-convex-audit-correction-20261107.json','h5-cog-convex-checkpoint-correction-20261107.json','h5-highs-1.12.0-LICENSE.txt']:add('corrections-and-license/'+name,ROOT/'output'/name)\nfor name,h in load(F/'source-bindings.json').items():")
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'next-preparation-charges.json','next-preparation-charges.json'),(F/'interval-proof-complete-charge.json','interval-proof-complete-charge.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(H/'audit-v2/checks.json','model-audit.json'),(H/'audit-v2/solver-controls.json','solver-controls.json'),(H/'audit-v2/tool-provenance.json','tool-provenance.json'),(H/'response-audit/checks.json','response-audit.json'),(H/'response-audit/six-region-chain.json','six-region-chain.json'),(H/'search/process.json','closed-lp-process.json'),(H/'interval-proof/audit/checks.json','interval-proof-audit.json'),(C/'checks.json','choice-search.json'),(C/'audit/checks.json','choice-audit.json'),(C/'audit/certified-choice-nogoods.json','certified-choice-nogoods.json'),(ROOT/'output/h5-cog-convex-choice-preparation-process-20261107/process.json','choice-process.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Convex repair and exact choice conflicts — 2026-11-07

The one-call continuous repair is **infeasible for its selected safe regions**.
An exact source proof explains why: six choices require a **1,288.21 mm**
horizontal span, while their selected-mode stock bounds permit **1,186.94 mm**.
At least one of those choices must change. A distinct bounded choice search
then verifies **256 further contradictory combinations** and stops at its
frozen node limit. Neither result excludes the original continuous domain,
another mode set or any whole allocation. Four fixed arrangements and all
440 allocations remain; H2/H5 stay open at **60% completed milestone weight**.

## Complete model and pinned solver controls

[Independent field readback]({NAME}/model-audit.json) verifies all **112 variables,
1,730 constraints and 3,952 nonzero coefficients**. The model retains all
28 selected legal modes, all 56 original translation coordinates and stock
bounds, 1,339 source-region rows for all 258 cog interactions, 268 orthogonal
component separators, the 11 required cog X-order constraints, and 112
absolute-motion rows. Its objective minimizes total absolute translation.
Every one of **5,682 coefficient/RHS values** is exactly representable after
power-of-two scaling; six deliberately corrupted models are rejected.

[Solver controls]({NAME}/solver-controls.json) verify a synthetic feasible and
infeasible LP, then load and read back the entire actual model without solving
it. Every option, bound, objective and sparse matrix entry is checked.
[Tool provenance]({NAME}/tool-provenance.json) pins installed SciPy 1.17.1 and
embedded HiGHS 1.12.0, with binary hashes and the MIT/BSD license records.
The call uses dual simplex, one thread, seed zero and presolve.

The first preflight stopped before any solver call because its reader expected
row storage after HiGHS had normalized the matrix to columns. The preserved
failure and corrected v2 reader verify mathematical entries in either storage
order. Complete model preparation is **0.231523 s**; the failed verification
takes 2.126282 s and corrected verification 2.367949 s. Neither changes or
repeats the prepared model. One-thread BLAS also reduces import memory.

## Closed response and exact explanation

[Response reconciliation]({NAME}/response-audit.json) verifies exactly one
source-model LP call. It reports infeasible during presolve after **0.001151 s**,
with 24.871619 s allocated, zero simplex iterations and no assignment.
There is no solve or algorithm overrun. Preparation-inclusive algorithm/shared
totals are **31.130687 / 31.200950 s**; charged preparation is 30.153657 s.
[The Windows Job]({NAME}/closed-lp-process.json) closes all five processes,
with zero active descendants and **62,181,376 bytes** peak committed memory.
No source candidate or native validation follows.

[Exact interval replay]({NAME}/interval-proof-audit.json) verifies 163 bound
deductions, rounded outward so they remain valid for continuous coordinates.
Its contradiction depends on only six source rows and five prior deductions.
[Independent summation of those six rows]({NAME}/six-region-chain.json) gives
the span contradiction above: **101.27 mm** more than the allowed range.
This explanation does not depend on trusting floating-point infeasibility.
It refutes only these selected region choices under their current modes.

## Closed proof-guided choice search

The new search reuses that proved root and changes region choices jointly.
It orders distinct combinations by total source-region rank, with deterministic
ties; each exact contradiction branches only on choices in its dependency
core. Every node retains all original modes, stock bounds, orthogonal
separators and cog ordering. There are no numerical LP calls in this search.

[The frozen 256-node search]({NAME}/choice-search.json) stops normally after
**2.173843 s**, below its eight-second internal cap. Its [complete process]({NAME}/choice-process.json)
takes **2.702245 s**, closes both processes and peaks at 137,736,192 bytes.
All 256 combinations have exact contradictions. **1,350 queued states remain
unsearched**, with minimum pending rank sum four; no larger-domain conclusion
is justified and this search will not be extended.

[Independent replay]({NAME}/choice-audit.json) verifies **47,804 exact bound
deductions**, 308 used pair/region choices and 1,618 independently reconstructed
source planes, plus every branch, tie, deduplication and terminal contradiction.
[The 256 resulting choice conflicts]({NAME}/certified-choice-nogoods.json),
along with the original six-choice conflict, provide 257 constraints for a
different model that chooses all source-safe regions together.

## Next construction and unchanged gates

[The next specification]({NAME}/next-step.json) first clips every candidate
region against its exact selected-mode relative stock bounds. It then proposes
joint region selectors coupled to the original 56 coordinates, complete source
planes and all 257 certified choice conflicts. Every field and tool control
still requires independent review before one newly frozen call. No such model
or call is prepared in this checkpoint.

[The complete charge before new geometry/model building]({NAME}/next-preparation-charges.json)
is **34.464716 s**: the entire consumed convex process, the conservatively
charged complete proof command, and complete choice preparation. The original
candidate/projection/model costs are already inside that process and must not
be counted twice. [The proof command charge]({NAME}/interval-proof-complete-charge.json)
includes its separate audit conservatively; this standard-library command used
internal limits and was not a Windows Job run. Other verification is separate.

Full66 original-source checks, native/material checks, production integration
and UI/CLI/MCP parity, and the full unchanged H5 matrix remain required. H2
retains its original gate and unopened reserved vectors. No release or README
change is warranted by these research results. [All six current-main CI jobs
pass]({NAME}/main-ci-at-review.json); these evidence commits can now undergo the
ordinary guarded fast-forward push. No live run is cancelled.

A checkpoint packaging reader also stopped on a top-level JSON list. Its
partial charge records and source bytes are retained; v2 checks object inputs
and hashes list documents without repeating any construction or search.

[Raw evidence]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) retain every consumed input,
including earlier frozen failures. Independent archive verification is required
before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 convex repair and exact choice conflicts:** [complete model, response and certificate audits]({link}) verify the112-variable/1,730-row continuous repair. Its sole LP call closes infeasible with no assignment; preparation-inclusive algorithm/shared totals are31.130687/31.200950 s, peak memory is62,181,376 bytes and all descendants close. An exact six-region chain needs1,288.21 mm of horizontal span against1,186.94 mm allowed, a101.27 mm contradiction confined to those selected choices. A different proof-guided search closes at256 nodes; all256 contradictions and47,804 bound deductions replay independently, while1,350 queued states remain unsearched. No call is repeated or extended. The257 verified choice conflicts can feed a new joint-region model after exact stock-domain pruning; complete consumed charge is34.464716 s before new geometry/model building. No valid full66 layout or allocation exclusion follows. Four fixed arrangements and440 allocations remain; H2/H5 stay open at60%. All six prior-main CI jobs pass; ordinary guarded checkpoint push is next. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';text=status.read_text(encoding='utf-8');begin=text.index('Latest H5 evidence:');end=text.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [convex repair and exact choice conflicts](../benchmarks/results/{NAME}.md).
The fully audited continuous repair closes infeasible for its selected regions.
Six exact source constraints require1,288.21 mm of span against1,186.94 mm
allowed by stock bounds. A new proof-guided choice search verifies256 more
contradictions, then stops at its frozen node cap with1,350 states unsearched.
These results exclude only the selected combinations. A distinct joint-region
model with257 certified choice conflicts and stock-domain pruning is next;
complete consumed charge is34.464716 s before its new preparation. It is not
yet built. Four fixed arrangements and all440 allocations remain. Full66
source/native/material checks and the unchanged H5 gate remain open.
H2/H5 stay open at60%. All six checks on main548f5b40 now pass; these evidence
commits are ready for the ordinary guarded push. No release is made.
'''
status.write_text(text[:begin]+intro+text[end:],encoding='utf-8',newline='\n')
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
