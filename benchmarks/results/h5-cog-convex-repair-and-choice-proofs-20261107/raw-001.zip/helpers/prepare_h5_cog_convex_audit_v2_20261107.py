from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'output'
def put(name,text):
    ast.parse(text)
    with (D/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(D/'h5_cog_convex_lp_tools_20261107.py').read_text(encoding='utf-8')
old="""    assert actual.a_matrix_.format_==h.MatrixFormat.kRowwise
    for key in ['start_','index_','value_']:assert list(getattr(actual.a_matrix_,key))==list(getattr(lp.a_matrix_,key)),key
"""
new="""    # HiGHS normalizes the input matrix to column storage. Verify mathematical
    # entries independently of storage order, including uniqueness and zeros.
    matrix=actual.a_matrix_;read=[];expected=[(ri,i,value) for ri,row in enumerate(model['rows']) for i,value in row['terms']]
    assert matrix.num_col_==lp.num_col_ and matrix.num_row_==lp.num_row_
    count=lp.num_col_ if matrix.format_==h.MatrixFormat.kColwise else lp.num_row_
    assert matrix.format_ in [h.MatrixFormat.kColwise,h.MatrixFormat.kRowwise]
    assert len(matrix.start_)==count+1 and matrix.start_[0]==0 and matrix.start_[-1]==len(values)
    assert len(matrix.index_)==len(matrix.value_)==len(values)
    for major in range(count):
        assert matrix.start_[major]<=matrix.start_[major+1]
        for k in range(matrix.start_[major],matrix.start_[major+1]):
            minor=matrix.index_[k];row,col=(minor,major) if matrix.format_==h.MatrixFormat.kColwise else (major,minor)
            assert 0<=row<lp.num_row_ and 0<=col<lp.num_col_
            read.append((row,col,matrix.value_[k]))
    assert len(set((r,c) for r,c,v in read))==len(read) and sorted(read)==sorted(expected)
"""
assert old in text;put('h5_cog_convex_lp_tools_v2_20261107.py',text.replace(old,new))
text=(D/'audit_h5_cog_convex_repair_20261107.py').read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'").replace('h5_cog_convex_lp_tools_20261107','h5_cog_convex_lp_tools_v2_20261107')
text=text.replace("inputs=[Path(__file__)","inputs=[ROOT/'output/h5-cog-convex-audit-correction-20261107.json',ROOT/'output/h5-cog-convex-repair-preparation-process-20261107/process.json',Path(__file__)")
put('audit_h5_cog_convex_repair_v2_20261107.py',text)
text=(D/'run_h5_cog_convex_repair_preparation_20261107.py').read_text(encoding='utf-8').replace('import json,subprocess,time','import json,subprocess,time,os').replace('h5-cog-convex-repair-preparation-process-20261107','h5-cog-convex-repair-audit-v2-process-20261107').replace("stages=[('prepare','prepare_h5_cog_convex_repair_20261107.py',30),('audit','audit_h5_cog_convex_repair_20261107.py',90)]","stages=[('audit','audit_h5_cog_convex_repair_v2_20261107.py',90)]").replace('h5_cog_convex_lp_tools_20261107','h5_cog_convex_lp_tools_v2_20261107').replace('len(records)==2','len(records)==1')
text=text.replace('records=[]',"env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');records=[]").replace('r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap+8)','r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap+8,env=env)')
put('run_h5_cog_convex_repair_audit_v2_20261107.py',text)
files=[D/n for n in ['h5_cog_convex_lp_tools_20261107.py','audit_h5_cog_convex_repair_20261107.py','h5-cog-convex-repair-preparation-process-20261107/audit-stderr.txt','h5-cog-convex-repair-preparation-process-20261107/process.json','h5-cog-convex-repair-20261107/model-exact.json','h5-cog-convex-repair-20261107/model-numeric.json']]
record={'preserved_inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in files},'failure':'Bridge expected the row-wise input storage after HiGHS passModel; HiGHS actually normalizes it to column storage. The first synthetic control stopped before solver.run; no synthetic/source solve ran. Exact and numeric source models already passed full independent field/scaling readback and all six corruption controls before this bridge failure.','correction':'v2 reconstructs all mathematical row/column/value triples from either valid storage, checks dimensions, index range, uniqueness and equality. It preserves the raw source model and all failed bytes. Verification-only v2 uses one-thread BLAS environment to reduce import memory.','source_model_preparation_repeated':False,'source_solver_calls':0,'failed_verification_seconds':2.1262817000970244,'complete_model_preparation_seconds':.2315234001725912}
with (D/'h5-cog-convex-audit-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
