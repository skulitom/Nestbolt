"""Refresh and verify the paused checkpoint without changing product or gates."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import base64, json, subprocess, sys, urllib.request, zipfile
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from h2_import_audit import source_digest
OUT = ROOT/'output/h5-group-choice-20261023-refresh'
def run(*args):
    return subprocess.check_output(args, cwd=ROOT)
def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')
def main():
    OUT.mkdir()
    local = 'a08893a7ad433768e3225c8090a122f0151ea080'
    remote = 'e9046d5392339c2a6cee0ae91bc0eca3d791cfe6'
    base = '7c47f4989d40a6ba81e7022457f175b3965c4e7d'
    changed_remote = run('git','diff','--name-only',base,remote).decode().splitlines()
    changed_local = run('git','diff','--name-only',base,local).decode().splitlines()
    assert not set(changed_local)&set(changed_remote)
    for revision, paths in [(local,changed_local),(remote,changed_remote)]:
        for path in paths:
            assert run('git','show',revision+':'+path)==run('git','show','HEAD:'+path),path
    assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    archives=[]
    for name in ['h5-single-frame-continuous-regions-20261020','h5-joint-frame-cog-construction-20261020']:
        p=ROOT/'benchmarks/results'/name
        manifest=json.loads((p/'raw-manifest.json').read_bytes())
        assert sha256((p/'raw.zip').read_bytes()).hexdigest()==manifest['archive_sha256']
        with zipfile.ZipFile(p/'raw.zip') as z:
            assert z.testzip() is None
            assert len(z.namelist())==len(manifest['files'])
            for row in manifest['files']:
                assert sha256(z.read(row['path'])).hexdigest()==row['sha256']
        archives.append({'name':name,'members':len(manifest['files']),'verified':True})
    for run_id in ['39461163256','39623126632','39627731583']:
        r=json.loads(run('gh','run','view',run_id,'--json','headSha,status,conclusion,jobs,url'))
        assert r['conclusion']=='success' and all(j['conclusion']=='success' for j in r['jobs'])
        write('ci-'+run_id+'.json',r)
    releases=json.loads(run('gh','api','repos/skulitom/Nestbolt/releases'))
    write('releases.json',[{k:r[k] for k in ['tag_name','published_at','prerelease','html_url','target_commitish']} for r in releases])
    studio=json.loads(run('gh','api','repos/JeroenGar/sparrow-studio/commits','-F','per_page=1','--method','GET'))[0]
    write('studio-head.json',studio)
    ref=studio['sha']
    readme=json.loads(run('gh','api','repos/JeroenGar/sparrow-studio/contents/README.md?ref='+ref))
    (OUT/'studio-README.md').write_bytes(base64.b64decode(readme['content']))
    with urllib.request.urlopen('https://sparrowstudio.app/', timeout=30) as response:
        html=response.read()
    (OUT/'studio-published.html').write_bytes(html)
    for text in [b'does not allocate parts across multiple fixed-size sheets',b'placing other parts inside holes is not supported']:
        assert text in html
    write('sparrow-head.json',json.loads(run('gh','api','repos/JeroenGar/sparrow/commits','-F','per_page=1','--method','GET')))
    review={'utc':datetime.now(timezone.utc).isoformat(),'merged_head':run('git','rev-parse','HEAD').decode().strip(),
      'incoming_head':remote,'local_checkpoint':local,'incoming_files_preserved':changed_remote,
      'local_files_preserved':changed_local,'archive_checks':archives,
      'production_digest':source_digest(),'readmes':{p:sha256((ROOT/p).read_bytes()).hexdigest() for p in ['README.md','README.ja.md','README.zh-CN.md']},
      'readme_update_needed':False,'new_application_release_qualified':False,
      'studio_head':ref,'studio_published_fixed_sheets':False,'studio_published_part_in_hole':False,
      'H2_decision':'Keep original gate and leave H2 open; no reserved evaluation',
      'H5_complete':False,'completion_percent':60}
    write('checks.json',review)
    print(json.dumps({'merge_verified':review['merged_head'],'remote_files':len(changed_remote),'local_files':len(changed_local),'archives':archives,'production_unchanged':True}))
if __name__=='__main__': main()
