"""Independently enumerate pairs using bounding boxes instead of the builder's tree."""
from collections import Counter
from itertools import combinations, product
import math, shutil, time
import numpy as np
import shapely
from audit_h5_cog_lattices import shape
from build_h5_group_choice import ROOT,SRC,CENSUS,OUT,load,write,digest,rows
def main():
    dst=OUT/'graph-audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter()
    for name,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    groups=load(CENSUS/'groups.json');mp=load(OUT/'mapping.json');assert mp['frame_groups']==groups
    gs=np.asarray([shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object)
    bounds=shapely.bounds(gs);sheets=np.asarray([p['placement']['sheet_id'] for p in pool]);clearance=job['clearance']
    stock=job['stocks'][0];margin=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json')
    frames=sorted({i for g in groups for i in g['candidates']});small=[i for i,p in enumerate(pool) if p['placement']['part_id']!='frame']
    filters=load(OUT/'group-filter.json');assert len(filters)==len(small);paircount=0;eligible=[];compat=[]
    for i,row in zip(small,filters):
        blockers=[]
        for j in frames:
            if sheets[i]==sheets[j]:
                paircount+=1
                # Full geometry distance is used for every frame/small pair, even distant ones.
                if gs[i].distance(gs[j])<clearance-1e-7:blockers.append(j)
        good=[g['index'] for g in groups if not set(g['candidates'])&set(blockers)]
        assert row=={'candidate':i,'frame_blockers':blockers,'compatible_groups':good}
        if good:eligible.append(i);compat.append(good)
    assert mp['candidates']==eligible and mp['compatible_groups']==compat
    for i in sorted(set(eligible+frames)):
        g=gs[i];p=pool[i]['placement'];t=p['transform'];part=parts[p['part_id']]
        assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        a,b,c,d=g.bounds;top=stock['height'] if sheets[i]=='sheet-0' else target['required_used_height_mm']
        assert a>=margin['left']+edge-1e-7 and b>=margin['bottom']+edge-1e-7
        assert c<=stock['width']-margin['right']-edge+1e-7 and d<=top-margin['top']-edge+1e-7
    fixed_pairs=0
    for group in groups:
        assert len(group['candidates'])==len(set(group['candidates']))==18
        for i,j in combinations(group['candidates'],2):
            assert pool[i]['placement']['part_id']==pool[j]['placement']['part_id']=='frame'
            if sheets[i]==sheets[j]:fixed_pairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clearance-1e-7
    ids=eligible;localgs=gs[ids];bb=bounds[ids];ss=sheets[ids];edges=set();adj=[0]*len(ids);allpairs=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];allpairs+=len(js)
        dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]))
        js=js[np.hypot(dx,dy)<=clearance+1e-7];near+=len(js)
        for j in js[shapely.distance(localgs[i],localgs[js])<clearance-1e-7]:
            j=int(j);edges.add((i,j));adj[i]|=1<<j;adj[j]|=1<<i
    saved=rows(OUT/'conflicts.jsonl.gz');assert len(saved)==len(edges) and set(map(tuple,saved))==edges
    cliques=rows(OUT/'cliques.jsonl.gz');covered=[0]*len(ids)
    for c in cliques:
        assert len(c)==len(set(c));mask=sum(1<<j for j in c)
        for j in c:
            others=mask^(1<<j);assert not(others&~adj[j]);covered[j]|=others
    assert covered==adj
    seed=mp['seed_indices'];group=mp['seed_group'];local={i:j for j,i in enumerate(ids)}
    seed_small=set(seed)-set(groups[group]['candidates']);assert len(seed_small)==40
    sm=sum(1<<local[i] for i in seed_small)
    for i in seed_small:assert group in compat[local[i]] and not(adj[local[i]]&sm)
    assert Counter(pool[i]['placement']['part_id'] for i in seed)==Counter(frame=18,bracket=12,cog=15,insert=13)
    families=['bracket','cog','insert'];areas={f:shape(parts[f],{'rotation_radians':0,'translation':[0,0],'mirrored':False}).area for f in families}
    assert mp['area_weights']=={f:round(a*1000) for f,a in areas.items()}
    combinations_areas=[]
    for counts in product(range(13),range(16),range(22)):
        original=sum(n*areas[f] for f,n in zip(families,counts));score=sum(n*mp['area_weights'][f] for f,n in zip(families,counts))
        combinations_areas.append((original,score,counts))
    sorted_original=sorted(combinations_areas);sorted_integer=sorted(combinations_areas,key=lambda x:(x[1],x[0],x[2]))
    assert sorted_original==sorted_integer
    for a,b in zip(sorted_original,sorted_original[1:]):assert (a[0]==b[0])==(a[1]==b[1])
    r={'passed':True,'seconds':time.perf_counter()-start,'all_inputs_hash_verified':True,'frame_small_pairs':paircount,
      'within_group_frame_pairs':fixed_pairs,'small_pairs_considered':allpairs,'small_pair_distances':near,'conflicts':len(edges),'cliques':len(cliques),
      'all_graph_edges_and_coverage_verified':True,'all_groups_and_filters_verified':True,'complete_feasible_hint_verified':True,
      'integer_objective_orders_all_original_count_combinations':len(combinations_areas),'retained_small_poses':len(ids)}
    write(dst/'checks.json',r);print(r,flush=True)
if __name__=='__main__':main()
