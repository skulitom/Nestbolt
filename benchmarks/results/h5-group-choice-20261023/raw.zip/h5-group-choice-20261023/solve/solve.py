"""Audited joint frame-group choice and area objective, one bounded call."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import gzip,json,shutil,time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
BASE=ROOT/'output/h5-group-choice-20261023'
OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,obj):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'graph-audit/checks.json')['passed']
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    mp=load(BASE/'mapping.json');pool=load(SRC/'candidates.json');ids=mp['candidates'];n=len(ids);ng=len(mp['frame_groups'])
    with gzip.open(BASE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[json.loads(l) for l in f]
    families={f:[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==f] for f in ['bracket','cog','insert']}
    quotas={'bracket':12,'cog':15,'insert':21};weights=[mp['area_weights'][pool[i]['placement']['part_id']] for i in ids]
    seed=set(mp['seed_indices']);hint=[int(i in seed) for i in ids]+[int(g==mp['seed_group']) for g in range(ng)]
    minimum=sum(weights[j]*hint[j] for j in range(n));maximum=sum(quotas[f]*mp['area_weights'][f] for f in quotas)
    model=cp_model.CpModel();vars=[model.new_bool_var(f'p{i}') for i in ids]+[model.new_bool_var(f'group{g}') for g in range(ng)]
    for c in cliques:model.add_at_most_one(vars[j] for j in c)
    model.add_exactly_one(vars[n:])
    for j,compatible in enumerate(mp['compatible_groups']):model.add_bool_or([vars[j].Not()]+[vars[n+g] for g in compatible])
    for f,js in families.items():model.add_linear_constraint(sum(vars[j] for j in js),0,quotas[f])
    expr=sum(weights[j]*vars[j] for j in range(n));model.add_linear_constraint(expr,minimum,maximum);model.maximize(expr)
    for j,v in enumerate(hint):model.add_hint(vars[j],v)
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'))
    expected=cp_model_pb2.CpModelProto()
    for name in [f'p{i}' for i in ids]+[f'group{g}' for g in range(ng)]:
        v=expected.variables.add();v.name=name;v.domain.extend([0,1])
    for c in cliques:expected.constraints.add().at_most_one.literals.extend(c)
    expected.constraints.add().exactly_one.literals.extend(range(n,n+ng))
    for j,compatible in enumerate(mp['compatible_groups']):expected.constraints.add().bool_or.literals.extend([-j-1]+[n+g for g in compatible])
    for f,js in families.items():
        c=expected.constraints.add().linear;c.vars.extend(js);c.coeffs.extend([1]*len(js));c.domain.extend([0,quotas[f]])
    c=expected.constraints.add().linear;c.vars.extend(range(n));c.coeffs.extend(weights);c.domain.extend([minimum,maximum])
    expected.objective.vars.extend(range(n));expected.objective.coeffs.extend([-w for w in weights]);expected.objective.scaling_factor=-1
    expected.solution_hint.vars.extend(range(n+ng));expected.solution_hint.values.extend(hint)
    actual=text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
    assert sum(hint[n:])==1 and all(sum(hint[j] for j in c)<=1 for c in cliques)
    assert all(not hint[j] or mp['seed_group'] in mp['compatible_groups'][j] for j in range(n))
    assert all(sum(hint[j] for j in js)<=quotas[f] for f,js in families.items())
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=60;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0
    solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'model-audit.json',{'passed':True,'all_model_fields_independently_reconstructed':True,'complete_feasible_hint_verified':True,
      'variables':len(vars),'constraints':len(actual.constraints),'seed_score':minimum,'full_score':maximum,'model_sha256':digest(OUT/'model.pbtxt'),
      'parameters_sha256':digest(OUT/'parameters.pbtxt'),'mapping_sha256':digest(BASE/'mapping.json'),'cliques_sha256':digest(BASE/'cliques.jsonl.gz')})
    records=[]
    def selection(value):
        selected=[i for j,i in enumerate(ids) if value(vars[j])];groups=[g for g in range(ng) if value(vars[n+g])];assert len(groups)==1
        return groups[0],sorted(selected+mp['frame_groups'][groups[0]]['candidates'])
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            g,chosen=selection(self.value)
            r={'index':len(records),'frame_group':g,'selected_indices':chosen,'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),
              'seconds':self.wall_time,'objective':self.objective_value,'best_bound':self.best_objective_bound}
            write(OUT/f"incumbent-{r['index']}.json",r);records.append(r);print(json.dumps({k:v for k,v in r.items() if k!='selected_indices'}),flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_seconds':60,'maximum_calls':1})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    result={'status':solver.status_name(status),'seconds':elapsed,'incumbents':len(records),'best_bound':solver.best_objective_bound,'response_stats':solver.response_stats()}
    if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
        group,chosen=selection(solver.value);write(OUT/'selected-indices.json',chosen)
        result.update(frame_group=group,counts=dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),objective=solver.objective_value)
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
