"""Bounded deterministic insertion into the first sheet after the7/7 transfer."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short7-7-first49-probe-20261028';SOURCE=ROOT/'output/h5-short7-7-source-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    import math
    from shapely.geometry import Polygon,mapping
    from shapely.affinity import affine_transform,translate
    import diagnose_h5_concave_gaps as geom
    geom.EPS=.0126;job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
    rows=load(SOURCE/'source63.json');required=.21170867250963943;start=time.perf_counter();records=[];placed=[]
    def world(r):
        t=r['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1
        return affine_transform(Polygon(parts[r['part_id']]['geometry'][0]['outer']),[m*c,-s,m*s,c,*t['translation']])
    modes=[]
    for mirror in [False,True]:
        for q in range(4):
            a=q*math.pi/2;c,s=math.cos(a),math.sin(a);m=-1 if mirror else 1
            raw=affine_transform(Polygon(parts['bracket']['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0]);offset=[-raw.bounds[0],-raw.bounds[1]];g=translate(raw,*offset)
            modes.append({'mode':len(modes),'angle':a,'mirrored':mirror,'source_offset':offset,'geometry':mapping(g)})
    write(OUT/'modes.json',modes)
    from shapely.geometry import shape
    for step,copy in enumerate([7,10,11]):
        folder=OUT/f'step-{step}';folder.mkdir();fixed=[world(r) for r in rows if r['sheet_id']=='sheet-0'];candidates=[];step_rows=[]
        for mode in modes:
            g=shape(mode['geometry']);free=geom.regions(g,fixed,job['stocks'][0],job['edge_clearance'],required)
            assert free.is_valid;write(folder/f'mode-{mode["mode"]}.json',mapping(free));components=geom.polygons(free)
            step_rows.append({'mode':mode['mode'],'empty':free.is_empty,'area_mm2':free.area,'components':len(components)})
            for index,component in enumerate(components):
                point=component.representative_point();candidates.append({'mode':mode['mode'],'component':index,'area_mm2':component.area,'anchor':list(point.coords)[0]})
        write(folder/'regions.json',step_rows);write(folder/'candidates.json',candidates);records.extend({'step':step,**r} for r in step_rows)
        if not candidates:break
        chosen=sorted(candidates,key=lambda r:(-r['area_mm2'],r['mode'],r['component']))[0];mode=modes[chosen['mode']]
        row={'part_id':'bracket','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],
            'translation':[chosen['anchor'][k]+mode['source_offset'][k] for k in [0,1]]}}
        g=world(row);assert min(g.distance(p) for p in fixed)>required
        rows.append(row);placed.append({'copy_index':copy,'choice':chosen,'row':row});write(folder/'chosen.json',placed[-1])
    write(OUT/'regions.json',records);write(OUT/'placed.json',placed);write(OUT/'source-candidate.json',rows)
    write(OUT/'result.json',{'seconds':time.perf_counter()-start,'closed':True,'region_calculations':len(records),'inserted_brackets':len(placed),
        'originals':len(rows),'all_empty_at_last_step':all(r['empty'] for r in step_rows),'conservative_fixed_neighbour_probe':True,
        'actual_infeasibility_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'probe.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed']
    inputs=[SOURCE/'plan.json',SOURCE/'source63.json',SOURCE/'audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/diagnose_h5_concave_gaps.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'shared_seconds':120,
        'method':'One finite greedy construction, at most3 insertions and24 full-source fixed-neighbour region calculations. Start from the independently valid source63 (49 first-sheet originals,14 short). Missing brackets are7,10,11 in that order. At each step compute all8 legal bracket mode regions against every currently fixed first-sheet original, retaining all regions and representative points. Choose the largest-area component, then mode/index order; place its representative point and re-evaluate for the next missing copy. Stop immediately if all regions are empty. Use unchanged required pair gap0.21170867250963943mm, EPS0.0126mm and stock guard. No optimizer, seed, retry, source rearrangement or native call; empty conservative regions do not establish actual/global infeasibility. Independently read every resulting original and account for all missing copies.'})
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,120-(time.perf_counter()-start)))
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final result; probe remains closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
