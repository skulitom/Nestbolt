"""Read the closed fixed-neighbour probe without turning empty regions into a proof."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,shape
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short7-7-first49-probe-20261028';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-short7-7-source-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(BASE/'process.json');result=load(BASE/'result.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<120
assert result['closed'] and result['region_calculations']==8 and result['inserted_brackets']==0 and result['all_empty_at_last_step']
assert not (BASE/'step-1').exists() and load(BASE/'placed.json')==[] and load(BASE/'step-0/candidates.json')==[]
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='bracket');modes=load(BASE/'modes.json')
assert len(modes)==8 and {(m['angle'],m['mirrored']) for m in modes}=={(q*math.pi/2,mir) for q in range(4) for mir in [False,True]}
for i,m in enumerate(modes):
    c,s=math.cos(m['angle']),math.sin(m['angle']);sign=-1 if m['mirrored'] else 1;tx,ty=m['source_offset']
    original=Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in part['geometry'][0]['outer']])
    assert m['mode']==i and original.equals_exact(shape(m['geometry']),1e-10)
    free=shape(load(BASE/'step-0'/f'mode-{i}.json'));assert free.is_empty and free.is_valid
regions=load(BASE/'regions.json');assert len(regions)==8 and all(r['step']==0 and r['empty'] and r['components']==0 and r['area_mm2']==0 for r in regions)
rows=load(BASE/'source-candidate.json');assert rows==load(SOURCE/'source63.json')
missing={('bracket',7),('bracket',10),('bracket',11)};expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}-missing
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,expected)
assert readback['valid'];write(OUT/'source-readback.json',readback)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_probe':True,'source_modes_verified':8,
    'empty_conservative_regions_verified':8,'inserted_brackets':0,'source63_unchanged_and_valid':True,
    'unplaced_originals':[list(k) for k in sorted(missing)],'shared_process_seconds':process['seconds'],
    'actual_fixed49_infeasibility_claimed':False,'full66_exclusion_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
