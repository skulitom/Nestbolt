"""Predeclare and enumerate only the new7..9-insert gaps; preserve all old bounds."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from math import factorial
import itertools,json,shutil,time
from h5_gap_schedule_enumeration_20261028 import orders,schedule
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-short-stem-gap-bound-20261028';OUT=ROOT/'output/h5-short-stem-gap-extension-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'schedules').mkdir();shutil.copyfile(__file__,OUT/'derive.py');start=time.perf_counter()
assert load(OLD/'audit/checks.json')['passed'] and load(OLD/'audit/source-mode-completeness.json')['passed']
wings=[(),('A',),('B',),('A','A'),('A','B'),('B','B')];cases=[]
for w in wings:
    for count in [7,8,9]:
        for horizontal in range(count+1):
            counts=Counter(w);counts['H']+=horizontal;counts['V']+=count-horizontal
            expected=factorial(sum(counts.values()))
            for n in counts.values():expected//=factorial(n)
            cases.append({'case':(''.join(w) or 'none')+f'-i{count}-h{horizontal}','wings':list(w),'inserts':count,
                'horizontal':horizontal,'vertical':count-horizontal,'expected_distinct_orders':expected})
assert len(cases)==162 and sum(c['expected_distinct_orders'] for c in cases)==194944
inputs=[OLD/n for n in ['plan.json','tasks.json','profiles.json','gap-widths.json','schedule-cases.json','audit/plan.json','audit/checks.json','audit/necessity-proof.json','audit/source-mode-completeness.json','audit/positive-control-gaps.json']]
inputs += [ROOT/'output/h5_gap_schedule_enumeration_20261028.py',ROOT/'benchmarks/results/h5-short-stem-gap-exclusion-20261028/updated-allocations.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'new_cases':cases,'new_distinct_orders':194944,'maximum_brackets':8,'maximum_inserts':9,'reused_insert_counts':list(range(7)),
    'new_insert_counts':[7,8,9],'method':'Finite deterministic extension of the audited source stem-gap certificate. Copy the42 existing0..6-insert gap bounds byte-for-byte; never rerun their schedules. Derive only162 new wing/orientation cases with194944 distinct orders, retaining every order and earliest-start schedule. Recompute the full chain for0..8 brackets and0..9 inserts, then independently audit all new schedules, exact coverage and both forward/backward recurrences before applying any exclusion to the446 surviving count vectors. Preserve old exclusions and all4576 original rows. No CP-SAT/source/native/production call, no retry of any closed search, no target or guard change.'})
shutil.copyfile(OLD/'gap-widths.json',OUT/'reused-gap-widths.json');shutil.copyfile(OLD/'schedule-cases.json',OUT/'reused-schedule-cases.json')
assert digest(OLD/'gap-widths.json')==digest(OUT/'reused-gap-widths.json') and digest(OLD/'schedule-cases.json')==digest(OUT/'reused-schedule-cases.json')
tasks=load(OLD/'tasks.json');gap={(tuple(r['wings']),r['inserts']):r['minimum_width_um'] for r in load(OUT/'reused-gap-widths.json')};records=[]
for case in cases:
    counts=Counter(case['wings']);counts['H']+=case['horizontal'];counts['V']+=case['vertical'];saved=[]
    for order in orders(counts):
        starts,width=schedule(order,tasks,312967);saved.append({'order':list(order),'starts_um':starts,'width_um':width})
    assert len(saved)==case['expected_distinct_orders'];path=OUT/'schedules'/f'{case["case"]}.json';write(path,saved)
    best=min(r['width_um'] for r in saved);records.append({**case,'orders':len(saved),'minimum_width_um':best,'schedules_sha256':digest(path)})
    key=(tuple(case['wings']),case['inserts']);gap[key]=min(gap.get(key,best),best)
    if case['horizontal']==case['inserts']:print('closed',case['wings'],case['inserts'],gap[key],flush=True)
write(OUT/'new-schedule-cases.json',records)
write(OUT/'gap-widths.json',[{'wings':list(w),'inserts':k,'minimum_width_um':v} for (w,k),v in sorted(gap.items())])
widths={'A':74996,'B':99996};dp={(0,0,'none'):0};transitions=[]
for number in range(8):
    for (n,used,pending),value in list(dp.items()):
        if n!=number:continue
        for kind,direction in itertools.product(['A','B'],['left','right']):
            ws=tuple(sorted(([pending] if pending!='none' else [])+([kind] if direction=='left' else [])))
            following=kind if direction=='right' else 'none'
            for k in range(10-used):
                target=(n+1,used+k,following);candidate=value+gap[ws,k]+widths[kind]
                transitions.append({'from':list((n,used,pending)),'to':list(target),'kind':kind,'direction':direction,'gap_inserts':k,'gap_wings':list(ws),'candidate_um':candidate})
                if target not in dp or candidate<dp[target]:dp[target]=candidate
terminal=[]
for n in range(9):
    for count in range(10):
        possibilities=[value+gap[(() if pending=='none' else (pending,)),count-used] for (nn,used,pending),value in dp.items() if nn==n and used<=count]
        best=min(possibilities);terminal.append({'brackets':n,'inserts':count,'minimum_required_width_um':best,'stock_width_um':1487040,'excluded':best>1487040})
write(OUT/'states.json',[{'state':list(s),'width_um':v} for s,v in sorted(dp.items())]);write(OUT/'transitions.json',transitions);write(OUT/'terminal.json',terminal)
write(OUT/'derived.json',{'seconds':time.perf_counter()-start,'new_schedule_cases':len(records),'new_distinct_orders':sum(r['orders'] for r in records),
    'reused_gap_cases':42,'total_gap_cases':len(gap),'states':len(dp),'transitions':len(transitions),'terminal_cases':len(terminal),
    'seven_bracket_bounds':[r for r in terminal if r['brackets']==7],'exclusion_not_applied_until_independent_audit':True,
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'derived.json'))
