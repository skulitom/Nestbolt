"""Independent combinatorial-rank coverage, interval readback and whole-chain audit."""
from pathlib import Path
from hashlib import sha256
from itertools import product
from collections import Counter
from functools import lru_cache
from math import factorial
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-short-stem-gap-bound-20261028';BASE=ROOT/'output/h5-short-stem-gap-extension-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'audit/checks.json')['passed'] and load(OLD/'audit/source-mode-completeness.json')['passed']
assert digest(BASE/'reused-gap-widths.json')==digest(OLD/'gap-widths.json')
assert digest(BASE/'reused-schedule-cases.json')==digest(OLD/'schedule-cases.json')
tasks=load(OLD/'tasks.json');H=312967;W=1487040;facs=[factorial(n) for n in range(12)]
def order_count(counts):
    denominator=1
    for n in counts.values():denominator*=facs[n]
    return facs[sum(counts.values())]//denominator
def rank(order,expected):
    assert Counter(order)==+expected;remaining=expected.copy();value=0
    for label in order:
        for smaller in sorted(k for k,n in remaining.items() if n and k<label):
            remaining[smaller]-=1;value+=order_count(remaining);remaining[smaller]+=1
        assert remaining[label]>0;remaining[label]-=1
    assert not any(remaining.values());return value
def capacity_ok(placed,at,kind):
    length,demand=tasks[kind];end=at+length
    cuts=sorted({at,end}|{x for a,b,h in placed for x in [a,b] if at<x<end})
    return all(demand+sum(h for a,b,h in placed if a<=x<b)<=H for x in cuts[:-1])
wing_sets=[(),('A',),('B',),('A','A'),('A','B'),('B','B')]
expected=[(w,k,h) for w in wing_sets for k in [7,8,9] for h in range(k+1)]
records=load(BASE/'new-schedule-cases.json');assert len(records)==len(plan['new_cases'])==len(expected)==162
gap={(tuple(r['wings']),r['inserts']):r['minimum_width_um'] for r in load(BASE/'reused-gap-widths.json')}
orders_checked=steps=0;cases=[];new_minima={}
for record,frozen,(w,k,horizontal) in zip(records,plan['new_cases'],expected):
    assert all(record[key]==value for key,value in frozen.items())
    assert record['wings']==list(w) and record['inserts']==k and record['horizontal']==horizontal and record['vertical']==k-horizontal
    counts=Counter(w);counts['H']+=horizontal;counts['V']+=k-horizontal;expected_count=order_count(counts)
    assert expected_count==record['orders']==record['expected_distinct_orders']
    path=BASE/'schedules'/f'{record["case"]}.json';assert digest(path)==record['schedules_sha256'];saved=load(path)
    assert len(saved)==expected_count;seen=set();best=None
    for s in saved:
        index=rank(s['order'],counts);assert 0<=index<expected_count and index not in seen;seen.add(index)
        assert len(s['starts_um'])==len(s['order']);placed=[]
        for label,at in zip(s['order'],s['starts_um']):
            candidates=sorted({0}|{b for a,b,height in placed})
            earliest=next(x for x in candidates if capacity_ok(placed,x,label));assert at==earliest
            length,demand=tasks[label];placed.append((at,at+length,demand));steps+=1
        width=max((b for a,b,height in placed),default=0);assert width==s['width_um'];best=width if best is None else min(best,width)
    assert seen==set(range(expected_count)) and best==record['minimum_width_um']
    orders_checked+=expected_count;new_minima[w,k,horizontal]=best
    cases.append({'case':record['case'],'complete_rank_range':[0,expected_count-1],'orders_verified':expected_count,'minimum_width_um':best})
    if horizontal==k:print('verified',list(w),k,flush=True)
assert orders_checked==plan['new_distinct_orders']==194944
for w in wing_sets:
    for k in [7,8,9]:gap[w,k]=min(new_minima[w,k,h] for h in range(k+1))
assert load(BASE/'gap-widths.json')==[{'wings':list(w),'inserts':k,'minimum_width_um':v} for (w,k),v in sorted(gap.items())]
widths={'A':74996,'B':99996}
@lru_cache(None)
def suffix(stems,inserts,pending):
    if stems==0:return gap[(() if pending=='none' else (pending,)),inserts]
    values=[]
    for kind,direction in product(['A','B'],['left','right']):
        wings=tuple(sorted(([pending] if pending!='none' else [])+([kind] if direction=='left' else [])))
        following=kind if direction=='right' else 'none'
        for k in range(inserts+1):values.append(gap[wings,k]+widths[kind]+suffix(stems-1,inserts-k,following))
    return min(values)
terminal=[]
for b in range(9):
    for i in range(10):
        width=suffix(b,i,'none');terminal.append({'brackets':b,'inserts':i,'minimum_required_width_um':width,'stock_width_um':W,'excluded':width>W})
assert terminal==load(BASE/'terminal.json')
old_terminal=load(OLD/'terminal.json');assert old_terminal==[r for r in terminal if r['inserts']<=6]
states={tuple(r['state']):r['width_um'] for r in load(BASE/'states.json')};assert states[0,0,'none']==0 and len(states)==241
old_states={tuple(r['state']):r['width_um'] for r in load(OLD/'states.json')};assert all(states[k]==v for k,v in old_states.items())
edges=[];incoming={}
for state,value in states.items():
    n,used,pending=state
    if n==8:continue
    for kind,direction in product(['A','B'],['left','right']):
        ws=tuple(sorted(([pending] if pending!='none' else [])+([kind] if direction=='left' else [])))
        following=kind if direction=='right' else 'none'
        for k in range(10-used):
            target=(n+1,used+k,following);candidate=value+gap[ws,k]+widths[kind]
            edges.append({'from':list(state),'to':list(target),'kind':kind,'direction':direction,'gap_inserts':k,'gap_wings':list(ws),'candidate_um':candidate})
            incoming.setdefault(target,[]).append(candidate)
assert set(states)==set(incoming)|{(0,0,'none')}
for state,values in incoming.items():assert states[state]==min(values)
canonical=lambda r:json.dumps(r,sort_keys=True)
saved_edges=load(BASE/'transitions.json');assert len(saved_edges)==4660 and sorted(map(canonical,saved_edges))==sorted(map(canonical,edges))
prior_path=ROOT/'benchmarks/results/h5-short-stem-gap-exclusion-20261028/updated-allocations.json';prior=load(prior_path)
assert sum(r['excluded_by'] is None for r in prior)==446
excluded=[r for r in terminal if r['excluded']];updated=[];new=[]
for original in prior:
    r=dict(original);b,i,c=r['short_counts']
    matching=[q for q in excluded if b>=q['brackets'] and i>=q['inserts']]
    if r['excluded_by'] is None and matching:r['excluded_by']='source_stem_gap_width_extension_20261028';new.append(r)
    updated.append(r)
assert [r['short_counts'] for r in new]==[[7,8,0],[7,9,0]]
survivors=[r['short_counts'] for r in updated if r['excluded_by'] is None];assert len(survivors)==444 and [8,5,0] in survivors and [7,4,1] in survivors
assert len(prior)==len(updated)==4576
for old,newrow in zip(prior,updated):
    if old['excluded_by'] is not None:assert old==newrow
pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)]
write(OUT/'schedule-cases.json',cases);write(OUT/'updated-allocations.json',updated);write(OUT/'newly-excluded-allocations.json',new);write(OUT/'pareto-necessary-counts.json',pareto)
proof={'inherited_source_mapping':'The previous audited source-to-stem-gap necessity argument and mode completeness are unchanged. Inward source rectangles and the full relaxed stock bounds are identical. Every valid source layout maps into the stem chain and its resource-feasible gap schedules; no fixed Y, wing anchoring or optional clearance is introduced.',
    'old_bounds':'All42 gap bounds for0..6 inserts are reused byte-for-byte; their168 schedules cases and12925 orders were already independently audited. All63 prior terminal bounds and169 old chain states are unchanged. The extension neither reruns nor replaces them.',
    'new_coverage':'There are exactly162 new wing/orientation cases for7..9 inserts and194944 distinct multiset orders. The independent reader computes each order rank using factorial counts for all smaller next letters. Matching every integer rank from0 through count-1, without duplicates, proves full order coverage independently of the derivation generator. It separately recomputes each earliest feasible start by clipped resource intervals and verifies every returned makespan. The earlier serial earliest-start completeness proof applies to these larger task sets unchanged.',
    'chain':'The full0..8-bracket,0..9-insert recurrence permits every stem type/direction and every insert distribution. All4660 forward transitions are checked, and an independently written backward recurrence agrees on all90 terminal count cases. Previously excluded rows are preserved, and only audited subset/upward-closure exclusions apply to the446 surviving vectors.',
    'conclusion':'Seven brackets/eight inserts need at least1489948um of width, exceeding the relaxed1487040um stock by2908um. Seven brackets/nine inserts need1559948um, exceeding it by72908um. They are the only two new excluded vectors. All4576 original rows remain recorded and444 survive. No source layout, full66 infeasibility, native pass or H5 completion is claimed. No solver call was made.'}
write(OUT/'necessity-proof.json',proof)
inputs=[BASE/'plan.json',BASE/'new-schedule-cases.json',BASE/'gap-widths.json',BASE/'states.json',BASE/'transitions.json',BASE/'terminal.json',OLD/'audit/checks.json',OLD/'audit/necessity-proof.json',prior_path]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
summary={'passed':True,'seconds':time.perf_counter()-start,'new_schedule_cases_verified':162,'new_distinct_orders_verified':orders_checked,
    'new_earliest_start_steps_verified':steps,'reused_gap_bounds_unchanged':42,'old_terminal_bounds_unchanged':63,'old_states_unchanged':169,
    'gap_bounds_verified':60,'forward_states_verified':241,'forward_transitions_verified':4660,'backward_terminal_cases_verified':90,
    'short7_8_minimum_width_um':suffix(7,8,'none'),'short7_9_minimum_width_um':suffix(7,9,'none'),
    'relaxed_stock_width_um':W,'newly_excluded_counts':[r['short_counts'] for r in new],
    'remaining_necessary_allocations':444,'pareto_necessary_count_vectors':len(pareto),'all_count_allocations_retained':4576,
    'full66_exclusion_claimed':False,'source_layout_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
