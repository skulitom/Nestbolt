"""Seal the extended necessary bound, valid short14 and closed fixed49 probe."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-seven-bracket-source-and-bound-20261028';OUT=ROOT/'benchmarks/results'/NAME
PROOF=ROOT/'output/h5-short-stem-gap-extension-20261028';OLD=ROOT/'output/h5-short-stem-gap-bound-20261028'
SOURCE=ROOT/'output/h5-short7-7-source-20261028';PROBE=ROOT/'output/h5-short7-7-first49-probe-20261028';PUB=PROOF/'publication'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='db26d1203163d3af0331d7159734a33028be6e26' and not git('diff','HEAD','--name-only')
proof=load(PROOF/'audit/checks.json');source=load(SOURCE/'audit/checks.json');probe=load(PROBE/'audit/checks.json')
assert proof['passed'] and source['passed'] and probe['passed']
assert proof['newly_excluded_counts']==[[7,8,0],[7,9,0]] and proof['remaining_necessary_allocations']==444
assert source['short14_source_valid'] and source['combined63_source_valid'] and not source['full66_witness']
assert probe['inserted_brackets']==0 and probe['closed_probe'] and probe['source63_unchanged_and_valid']
prior=load(ROOT/'benchmarks/results/h5-short-stem-gap-exclusion-20261028/publication-review.json')
production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],
    'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up);assert load(PUB/'main.json')['commit']['sha']==head
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6
passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed']
assert len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [PROOF,SOURCE,PROBE,OLD,ROOT/'output/h5-short-stem-gap-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_gap_schedule_enumeration_20261028.py','derive_h5_short_stem_gap_extension_20261028.py','audit_h5_short_stem_gap_extension_20261028.py',
    'construct_h5_short7_7_source_20261028.py','audit_h5_short7_7_source_20261028.py','render_h5_short7_7_source_20261028.py',
    'probe_h5_short7_7_first49_20261028.py','audit_h5_short7_7_first49_20261028.py','derive_h5_short_stem_gap_bound_20261028.py',
    'audit_h5_short_stem_gap_bound_20261028.py','audit_h5_stem_gap_mode_coverage_20261028.py',
    'push_short_stem_gap_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(PROOF/'derived.json','gap-derived.json'),(PROOF/'audit/checks.json','gap-audit-checks.json'),
    (PROOF/'audit/necessity-proof.json','necessity-proof.json'),(PROOF/'audit/updated-allocations.json','updated-allocations.json'),
    (PROOF/'audit/newly-excluded-allocations.json','newly-excluded-allocations.json'),(PROOF/'audit/pareto-necessary-counts.json','pareto-necessary-counts.json'),
    (PROOF/'gap-widths.json','gap-widths.json'),(PROOF/'terminal.json','terminal-width-bounds.json'),
    (SOURCE/'audit/checks.json','source-checks.json'),(SOURCE/'source14.json','short-source14.json'),(SOURCE/'source63.json','combined-source63.json'),
    (SOURCE/'source14.png','short-source14.png'),(PROBE/'audit/checks.json','fixed49-probe-checks.json'),
    (PUB/'main-ci-jobs.json','prior-main-ci.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,
    'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,
    'main_CI':40711177461,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,
    'normal_push_requires_remaining_main_check':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,
    'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'new_count_exclusions':[[7,8,0],[7,9,0]],'remaining_necessary_allocations':444,
    'all4576_rows_retained':True,'new_source_short14_valid':True,'short_counts':[7,7,0],'combined63_valid':True,
    'unplaced_originals':source['unplaced_originals'],'fixed49_probe_closed_without_insertion':True,'source64_preserved':True,
    'full66_witness':False,'full66_exclusion_claimed':False,'solver_calls':0,'native_calls':0,
    'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The exact extension excludes short7/8/0 and7/9/0, leaving444 candidates and preserving every earlier exclusion. Do not reopen those branches or the closed8/6/0 source call. The deterministic7/7/0 short14 is now source-valid, and inserts16/17 have been transferred off the first sheet. Its unchanged49 first-sheet rows plus short14 form source63, missing brackets7/10/11; the earlier source64 remains intact. The sole fixed49 greedy probe closed after all8 conservative bracket regions were empty, so do not repeat it or claim actual/global infeasibility. A complete next construction must rearrange the first-sheet packet: retain the29-original frame/side-insert core and14 short originals, and account for all23 remaining originals (15 cogs,5 brackets and3 upper inserts). This is a different allocation from the closed24-mover call. Inspect actual cog contact geometry and permit changed phases/row structure before choosing and predeclaring a bounded construction; do not simply restart the failed fixed-phase7 local search. Every resulting candidate still requires independent all66 source and native readback, unchanged PIH OFF, material target and guards before integration or a full H5 matrix. Main db26d120 currently has five passing jobs and its Windows check is live; preserve it and push normally only after allsix pass plus fresh remote/ancestry checks. H2 stays open by explicit instruction and22 reserved vectors remain unopened; no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Seven-bracket width bounds and a source-valid short sheet — 2026-10-28

The new deterministic source construction fits **seven brackets and seven
inserts** on the unchanged short sheet, with at least **0.225 mm** between
original filled outlines. A separate exact width argument excludes seven
brackets with eight or nine inserts. The complete frontier now has **444
necessary candidates**; no complete 66-part layout or H5 pass is claimed.

![Verified source short14]({NAME}/short-source14.png)

## Exact width extension

The previous [source stem-gap proof](h5-short-stem-gap-exclusion-20261028.md)
is unchanged. Its 42 gap bounds for 0–6 inserts are reused byte-for-byte.
Only the predeclared 7–9-insert cases are enumerated: **162 new wing/orientation
cases and 194,944 distinct task orders**. Every order and schedule is retained.
Derivation takes 26.377307 s, with no solver call.

The independent reader checks complete multiset-order coverage using a separate
factorial rank calculation, then recomputes **2,033,536 earliest-start steps**
and every makespan. It verifies all 60 gap bounds, 241 chain states and 4,660
transitions. An independent backward recurrence agrees on all 90 terminal
count cases. The old 169 states and 63 terminal bounds remain identical.
The independent audit takes 39.778210 s.

Seven brackets/eight inserts require at least **1,489.948 mm**, exceeding the
relaxed sheet width of 1,487.040 mm by **2.908 mm**. Seven brackets/nine inserts
require **1,559.948 mm**, a deficit of **72.908 mm**. These are the only two
newly excluded vectors. All 4,576 original rows and previous exclusions remain
recorded. The proof retains every allowed source mode and does not rely on
any unknown solver response or fixed source placement.

## Direct original-shape construction

The seven-bracket/seven-insert case remains allowed. Its source construction
keeps six existing brackets and three horizontal inserts exactly. A new end
group contains one bracket, one vertical insert in its notch, two vertical
inserts beside it and one horizontal insert above those two. This is a direct
geometric construction, without an optimizer or random choice.

Independent original-ring readback checks all 14 originals, **91 pairs, 56 stock
edges, 28 holes and 3,416 hole vertices**. Minimum pair clearance is 0.225 mm;
minimum extra stock clearance is 0.025 mm. Holes remain reserved and all legal
mode, source-identity and unchanged-target checks pass.

Moving inserts16/17 off the first sheet leaves 49 first-sheet originals in
their exact previous poses. Combined with the new short14, these are **63
source-valid originals**, with brackets7/10/11 explicitly unplaced. The full
partial readback checks 1,267 pairs, 252 stock edges and 81 holes containing
8,928 vertices; minimum pair gap is 0.214826983 mm, above the unchanged guarded
requirement. The previous source-valid64 remains unchanged. The new allocation
is an alternative construction, not a better total part-count result.

The rendered original-shape figure was visually checked. Two preliminary
versions with a clipped title or overlapping legend are retained in the raw
archive; the final figure fixes those layout issues without changing geometry.

## Closed fixed-neighbour probe and next work

One predeclared greedy probe computes all eight legal bracket-mode regions
against the 49 fixed first-sheet originals. Every conservative region is empty,
so it stops before inserting any bracket, in **7.484384 shared seconds**. The
independent reader verifies the modes, empty results and unchanged valid63.
This is neither actual fixed49 nor global infeasibility; no placement search
is restarted and no native call is made.

Completion needs a different first-sheet arrangement. The new allocation leaves
a 29-original frame/side-insert core and 23 upper originals: 15 cogs, five
brackets and three inserts. Inspect actual contact geometry and allow changed
cog phases or row structure before declaring a bounded new construction.
The failed fixed-phase local calls remain closed. All66 original source and
native checks are still required before integration or an H5 matrix rerun.

At publication review, main `db26d120` has five passing jobs and its Windows
check is running in
[CI 40711177461](https://github.com/skulitom/Nestbolt/actions/runs/40711177461).
A normal main push waits for all six to pass and fresh remote checks. Production,
READMEs and upstream heads/releases are unchanged. H2/H5 remain open at **60%
completed milestone weight**, all 22 reserved H2 vectors remain unopened, and
no new release qualifies.

[Width audit]({NAME}/gap-audit-checks.json),
[source readback]({NAME}/source-checks.json),
[closed insertion probe]({NAME}/fixed49-probe-checks.json),
[complete allocation list]({NAME}/updated-allocations.json),
[next step]({NAME}/next-step.json),
[byte-verified archive]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every new task order, reused proof evidence,
original source ring inputs, candidate, audit and preceding main-push receipt.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 seven-bracket bound and source construction, 2026-10-28:** [the evidence]({link})
reuses all existing gap bounds exactly and audits 194,944 new task orders /
2,033,536 earliest-start steps. The complete recurrence excludes 7/8/0 and
7/9/0, leaving 444 candidates with all 4,576 original rows preserved. A direct
7/7/0 short14 construction passes original-shape readback: 91 pairs, 56 stock
edges and all 28 holes, with 0.225 mm minimum separation. Moving two inserts
from the first sheet leaves a valid63 alternative, missing brackets7/10/11;
the earlier valid64 is unchanged. One fixed49 probe closes after all eight
conservative bracket regions are empty, without claiming infeasibility. Next
reconstruct the first-sheet23-part packet with actual contact geometry and
changed cog phases/row structure; closed local calls stay closed. Main db26d120
has five passing jobs and its Windows check is live; wait for allsix before
pushing. Production, READMEs and upstream releases are unchanged. H2/H5 remain
open at 60%; all 22 reserved vectors remain unopened and no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'remaining_necessary_allocations':444,'completion_percent':60,'main_windows_live_at_review':True})
