"""Render verified original rings, with no geometry modification."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Patch,Rectangle
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short7-7-source-20261028';load=lambda p:json.loads(p.read_bytes())
assert load(BASE/'audit/checks.json')['short14_source_valid'];job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
fig,ax=plt.subplots(figsize=(15,5.2));colours={'bracket':'#efc48b','insert':'#baa5d9'}
for r in load(BASE/'source14.json'):
    g=parts[r['part_id']]['geometry'][0];t=r['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    def ring(points):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in points]
    outer=ring(g['outer']);ax.add_patch(Polygon(outer,facecolor=colours[r['part_id']],edgecolor='#625d62',linewidth=.7))
    for h in g.get('holes',[]):ax.add_patch(Polygon(ring(h),facecolor='none',edgecolor='#8b8290',linewidth=.45))
ax.add_patch(Rectangle((6.5,6.5),1487,319.42690232999934-6.5,fill=False,edgecolor='#333333',linestyle='--',linewidth=1))
ax.set_xlim(0,1500);ax.set_ylim(0,330);ax.set_aspect('equal');ax.set_xlabel('mm');ax.set_ylabel('mm')
fig.suptitle('Verified short sheet: seven brackets and seven inserts',y=.97,fontsize=15)
ax.set_title('Original filled outlines; holes remain reserved',pad=10,fontsize=11)
fig.legend(handles=[Patch(facecolor=c,label=f.title()) for f,c in colours.items()],loc='lower center',bbox_to_anchor=(.5,.10),ncol=2,frameon=False)
fig.text(.5,.035,'Minimum separation 0.225 mm. The combined construction still has three unplaced brackets; H5 is not complete.',ha='center',fontsize=10)
fig.subplots_adjust(left=.055,right=.99,bottom=.25,top=.84);fig.savefig(BASE/'source14.png',dpi=150);plt.close(fig)
print(str(BASE/'source14.png'))
