"""Pure finite earliest-start interval enumeration; no search service or side effects."""
def orders(counts,prefix=()):
    if not any(counts.values()):yield prefix;return
    for kind in sorted(counts):
        if counts[kind]:
            counts[kind]-=1;yield from orders(counts,prefix+(kind,));counts[kind]+=1
def feasible(placed,start,length,demand,tasks,capacity):
    events={start:demand,start+length:-demand}
    for at,kind in placed:
        duration,height=tasks[kind];events[at]=events.get(at,0)+height;events[at+duration]=events.get(at+duration,0)-height
    level=0
    for point,delta in sorted(events.items()):
        level+=delta
        if level>capacity:return False
    assert level==0;return True
def schedule(order,tasks,capacity):
    placed=[]
    for kind in order:
        length,demand=tasks[kind];candidates=sorted({0}|{at+tasks[k][0] for at,k in placed})
        start=next(at for at in candidates if feasible(placed,at,length,demand,tasks,capacity));placed.append((start,kind))
    return [at for at,kind in placed],max((at+tasks[kind][0] for at,kind in placed),default=0)
