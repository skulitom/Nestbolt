"""One explicit source construction: three old bracket pairs and a new end group."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short7-7-source-20261028'
SOURCE=ROOT/'output/h5-oblique64-source-20261028/source64.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
FRONT=ROOT/'output/h5-short-stem-gap-extension-20261028/audit/updated-allocations.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py')
assert any(r['short_counts']==[7,7,0] and r['excluded_by'] is None for r in load(FRONT))
inputs=[SOURCE,JOB,FRONT,ROOT/'output/h5-short-stem-gap-extension-20261028/audit/checks.json',ROOT/'output/h5-short14-orthogonal-source-20261028/stock.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'counts':[7,7,0],'method':'Deterministic construction, no optimizer. Keep exactly the existing first six short-sheet brackets0..5 and horizontal inserts0..2. Replace the remaining end group by bracket6, unmirrored270degrees, lower-left anchor[998.55,6.525]. Put a vertical insert3 in its notch at[1073.775,6.525]; put vertical inserts4 and16 beside it at[1248.775,6.525] and[1359.0,6.525]; put horizontal insert17 above those two at[1248.775,186.75]. All separations use0.225mm or more. Read original filled outers, holes, stock and modes independently. For context, combine this short14 with the unchanged49 first-sheet rows from source64 after removing inserts16/17: the result is only63 originals, with bracket7/10/11 explicitly unplaced. The previous valid64 is retained unchanged. No native or H5 claim.'})
old=load(SOURCE);job=load(JOB);parts={p['id']:p for p in job['parts']}
rows=[r for r in old if r['sheet_id']=='sheet-1' and ((r['part_id']=='bracket' and r['copy_index']<6) or (r['part_id']=='insert' and r['copy_index']<3))]
assert len(rows)==9
def pose(family,copy,quarter,anchor):
    c=round(math.cos(quarter*math.pi/2));s=round(math.sin(quarter*math.pi/2))
    raw=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
    lo=[min(p[k] for p in raw) for k in [0,1]]
    return {'part_id':family,'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':quarter*math.pi/2,
        'mirrored':False,'translation':[anchor[k]-lo[k] for k in [0,1]]}}
rows += [pose('bracket',6,3,[998.55,6.525]),pose('insert',3,1,[1073.775,6.525]),pose('insert',4,1,[1248.775,6.525]),
    pose('insert',16,1,[1359.0,6.525]),pose('insert',17,0,[1248.775,186.75])]
first=[r for r in old if r['sheet_id']=='sheet-0' and not (r['part_id']=='insert' and r['copy_index'] in [16,17])]
assert len(rows)==14 and len(first)==49;write(OUT/'source14.json',rows);write(OUT/'source63.json',first+rows)
write(OUT/'constructed.json',{'short_originals':14,'counts':[7,7,0],'unchanged_first_sheet_originals':49,'partial_combined_originals':63,
    'unplaced_originals':[['bracket',7],['bracket',10],['bracket',11]],'previous_source64_unchanged':True,
    'source_validity_pending_independent_readback':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'constructed.json'))
