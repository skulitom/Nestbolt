"""Independent original-ring readback of the explicit short14 and contextual63."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short7-7-source-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');old=load(ROOT/'output/h5-oblique64-source-20261028/source64.json')
stock=load(ROOT/'output/h5-short14-orthogonal-source-20261028/stock.json');stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':stock['actual_outline_bounds_mm']}
short=load(BASE/'source14.json');combined=load(BASE/'source63.json')
expected=[('bracket',i) for i in range(7)]+[('insert',i) for i in [0,1,2,3,4,16,17]]
short_result=audit(job,short,stocks,stock['required_source_gap_mm'],stock['native_guard_mm'],expected)
assert short_result['valid'] and short_result['family_counts']=={'bracket':7,'insert':7}
missing={('bracket',7),('bracket',10),('bracket',11)}
allkeys={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
combined_result=audit(job,combined,stocks,stock['required_source_gap_mm'],stock['native_guard_mm'],allkeys-missing)
assert combined_result['valid'] and len(combined)==63 and Counter(r['sheet_id'] for r in combined)=={'sheet-0':49,'sheet-1':14}
first=[r for r in old if r['sheet_id']=='sheet-0' and not (r['part_id']=='insert' and r['copy_index'] in [16,17])]
assert [r for r in combined if r['sheet_id']=='sheet-0']==first
kept=[r for r in old if r['sheet_id']=='sheet-1' and ((r['part_id']=='bracket' and r['copy_index']<6) or (r['part_id']=='insert' and r['copy_index']<3))]
assert short[:9]==kept
assert allkeys-{(r['part_id'],r['copy_index']) for r in combined}==missing
write(OUT/'short-source-readback.json',short_result);write(OUT/'combined-source-readback.json',combined_result)
summary={'passed':True,'seconds':time.perf_counter()-start,'short14_source_valid':True,'short_counts':[7,7,0],
    'short_pairs_verified':short_result['same_sheet_pairs'],'short_stock_edges_verified':short_result['stock_edges'],
    'short_holes_verified':short_result['cutouts'],'short_hole_vertices_verified':short_result['hole_vertices'],
    'minimum_short_pair_gap_mm':short_result['minimum_pair_gap_mm'],'minimum_short_stock_extra_mm':short_result['minimum_extra_stock_mm'],
    'combined63_source_valid':True,'combined_pairs_verified':combined_result['same_sheet_pairs'],
    'combined_stock_edges_verified':combined_result['stock_edges'],'combined_holes_verified':combined_result['cutouts'],
    'combined_hole_vertices_verified':combined_result['hole_vertices'],'minimum_combined_pair_gap_mm':combined_result['minimum_pair_gap_mm'],
    'unchanged_first_sheet_rows':49,'unchanged_short_rows':9,'unplaced_originals':[list(k) for k in sorted(missing)],
    'source64_preserved_unchanged':True,'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
