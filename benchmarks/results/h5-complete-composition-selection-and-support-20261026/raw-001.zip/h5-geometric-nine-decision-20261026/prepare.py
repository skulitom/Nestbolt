"""Necessary geometry-only projection of the closed nine-or-more decision."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-nine-short-decision-20261026';OUT=ROOT/'output/h5-geometric-nine-decision-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN';old=load(PARENT/'plan.json');copied=['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json'];paths=[PARENT/n for n in ['plan.json','models/000.pb','inventory.json','cell-selectors.json','cell-groups.json','optional-rectangles.json','model-audit/checks.json','model-audit/necessity-proof.json','response-audit/checks.json']+copied]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':old['allowed_profiles'],'originals':old['originals'],'families':old['families'],'checked_first_originals':old['checked_first_originals'],'minimum_short_sheet_count':9,'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Necessary geometry-only relaxation of the closed nine-or-more decision. Remove all2300 vertical-cell variables, their2300 interval implications,54 profile/cell equalities and63 band capacities. Retain all original coordinate/profile/presence variables, conditional stock bounds, prefix symmetry, original-tip/stem directional constraints, strengthened cog gaps,146 optional inner rectangles, first-sheet area resource, composition cut and cardinality>=9. Remap interval-constraint references exactly. Removing necessary area bounds weakens the model; a negative still excludes the original count subfamily, while a positive needs the omitted band checks and original geometry. Independently account for every removed field and actual import before one new20solver/30shared4worker seed0 call; prior calls closed.'})
parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'models/000.pb').read_bytes());m=cp_model_pb2.CpModelProto();removed={r['variable'] for r in load(PARENT/'cell-selectors.json')};assert removed==set(range(116,2416));m.variables.extend(parent.variables[:116]);kept=list(range(565))+list(range(2982,3276));mapping={old:new for new,old in enumerate(kept)}
for i in kept:
    c=m.constraints.add();c.CopyFrom(parent.constraints[i])
    if c.WhichOneof('constraint')=='no_overlap_2d':c.no_overlap_2d.x_intervals[:]=[mapping[v] for v in c.no_overlap_2d.x_intervals];c.no_overlap_2d.y_intervals[:]=[mapping[v] for v in c.no_overlap_2d.y_intervals]
assert (len(m.variables),len(m.constraints))==(116,859)
for n in copied:shutil.copyfile(PARENT/n,OUT/n)
write(OUT/'kept-parent-constraints.json',kept);write(OUT/'removed-parent-variables.json',sorted(removed));write(OUT/'optional-rectangles.json',[{**r,'interval_constraints':[mapping[v] for v in r['interval_constraints']]} for r in load(PARENT/'optional-rectangles.json')])
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');r={**load(PARENT/'inventory.json')[0],'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'cell_selectors':0,'profile_cell_equalities':0,'band_inequalities':0,'removed_cell_variables':2300,'removed_constraints':2431,'geometry_only_necessary_relaxation':True};write(OUT/'inventory.json',[r]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**r,'solver_calls':0});print(load(OUT/'prepared.json'))
