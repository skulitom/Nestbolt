"""Independent complete retention/removal audit for necessary geometry projection."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-geometric-nine-decision-20261026';PARENT=ROOT/'output/h5-nine-short-decision-20261026';DATA=ROOT/'output/h5-rotation-independent-bands-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct every removed cell implication, profile equality and band row from audited mappings; verify every removed variable. Check all other complete parent fields retained with exact interval-reference remapping. Verify no removed variable remains referenced, every optional rectangle and actual import/export. This is a weaker necessary projection, not an equivalent area model.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'];parent=proto(PARENT/'models/000.pb');m=proto(BASE/'models/000.pb');cells=load(PARENT/'cell-selectors.json');groups=load(PARENT/'cell-groups.json');ci=565
for row in cells:
    v=row['variable'];assert parent.variables[v]==cp_model_pb2.IntegerVariableProto(name=f"p{row['part']}-profile{row['profile']}-cell{row['cell']}",domain=[0,1]);assert parent.constraints[ci]==cp_model_pb2.ConstraintProto(enforcement_literal=[v],linear=cp_model_pb2.LinearConstraintProto(vars=[2*row['part']+1],coeffs=[1],domain=row['y_bounds_units1000']));ci+=1
for g in groups:
    terms={g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)};vs=sorted(terms);assert parent.constraints[ci]==cp_model_pb2.ConstraintProto(linear=cp_model_pb2.LinearConstraintProto(vars=vs,coeffs=[terms[v] for v in vs],domain=[0,0]));ci+=1
for band,cap in enumerate(load(DATA/'band-capacities.json')):
    rows=[r for r in cells if r['demands'][band]];assert parent.constraints[ci]==cp_model_pb2.ConstraintProto(linear=cp_model_pb2.LinearConstraintProto(vars=[r['variable'] for r in rows],coeffs=[r['demands'][band] for r in rows],domain=[-2**63,cap]));ci+=1
assert ci==2982;removed=[r['variable'] for r in cells];assert removed==list(range(116,2416))==load(BASE/'removed-parent-variables.json');assert list(m.variables)==list(parent.variables[:116]);kept=list(range(565))+list(range(ci,len(parent.constraints)));assert kept==load(BASE/'kept-parent-constraints.json');remap={old:new for new,old in enumerate(kept)};expected=cp_model_pb2.CpModelProto();expected.variables.extend(parent.variables[:116])
for old in kept:
    c=expected.constraints.add();c.CopyFrom(parent.constraints[old]);assert all(0<=v if v>=0 else -v-1>=0 for v in c.enforcement_literal)
    if c.WhichOneof('constraint')=='no_overlap_2d':c.no_overlap_2d.x_intervals[:]=[remap[v] for v in c.no_overlap_2d.x_intervals];c.no_overlap_2d.y_intervals[:]=[remap[v] for v in c.no_overlap_2d.y_intervals]
assert m==expected and len(m.variables)==116 and len(m.constraints)==859
assert load(BASE/'optional-rectangles.json')==[{**r,'interval_constraints':[remap[v] for v in r['interval_constraints']]} for r in load(PARENT/'optional-rectangles.json')]
for n in ['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'necessary_original_count_subfamily_projection':True,'reverse_parent_equivalence':False,'statement':'Every full source continuation with at least9 short-sheet originals satisfies the audited parent. Project away its vertical-cell variables and delete their channeling and area capacities. Every remaining variable and constraint is unchanged except internal interval reference renumbering. Thus any source continuation still satisfies this weaker geometry projection. A negative excludes the same count subfamily; a positive must restore/check all omitted band capacities and full original geometry. All66 identity obligations and the first-sheet complement remain unchanged.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':116,'constraints':859,'removed_variables_verified':2300,'removed_cell_implications_verified':2300,'removed_profile_cell_equalities_verified':54,'removed_band_constraints_verified':63,'all_remaining_fields_exact':True,'optional_rectangle_references_verified':146,'actual_import_export_verified':True,'necessary_projection_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
