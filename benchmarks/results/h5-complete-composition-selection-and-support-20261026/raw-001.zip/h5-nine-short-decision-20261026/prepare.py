"""Separate feasibility question: can at least nine remaining originals go short?"""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-support-composition-selector-20261026';OUT=ROOT/'output/h5-nine-short-decision-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['selected_short_sheet_count']==8 and load(PARENT/'response-audit/checks.json')['status']=='FEASIBLE'
copied=['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json','cell-selectors.json','cell-groups.json','optional-rectangles.json'];paths=[PARENT/n for n in ['plan.json','models/000.pb','inventory.json','model-audit/checks.json','model-audit/necessity-proof.json','response-audit/checks.json']+copied];old=load(PARENT/'plan.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':old['allowed_profiles'],'originals':old['originals'],'families':old['families'],'checked_first_originals':old['checked_first_originals'],'minimum_short_sheet_count':9,'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'New feasibility subproblem: retain all optional original-support selector constraints and require at least9 of the11 remaining originals on the short sheet. Remove only the lexicographic objective; do not transfer its unproved optimality. A negative would prove every source continuation of the checked55 needs at least3 additions on the first sheet; a positive is still only a necessary allocation. All originals and complementary first-sheet obligations remain. Independently restore the parent and check import before one20solver/30shared4worker seed0 call. Previous optimization calls remain closed.'})
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'models/000.pb').read_bytes());m.ClearField('objective');presence=load(PARENT/'presence-flags.json');c=m.constraints.add();c.linear.vars.extend(presence);c.linear.coeffs.extend([1]*11);c.linear.domain.extend([9,11]);assert (len(m.variables),len(m.constraints))==(2416,3276)
for name in copied:shutil.copyfile(PARENT/name,OUT/name)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');r={**load(PARENT/'inventory.json')[0],'constraints':len(m.constraints),'model_sha256':digest(p),'minimum_short_sheet_count':9,'objective_removed':True};write(OUT/'inventory.json',[r]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**r,'solver_calls':0});print(load(OUT/'prepared.json'))
