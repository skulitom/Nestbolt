"""Exact parent restoration and complete nine-or-more subproblem scope audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-nine-short-decision-20261026';PARENT=ROOT/'output/h5-support-composition-selector-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify exactly one complete cardinality constraint added and exactly the parent objective removed. Restore both and demand complete proto equality. Check all unchanged mappings and actual import/export. Any source continuation with9 or more remaining short-sheet originals maps to the parent and satisfies the new constraint. A negative therefore provides a necessary maximum8 bound only for this checked55 continuation and stock target; no global full-job exclusion.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'model-audit/necessity-proof.json')['all_angle_continuous_source_continuation_maps'];m=proto(BASE/'models/000.pb');parent=proto(PARENT/'models/000.pb');presence=load(PARENT/'presence-flags.json');assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};assert m.constraints[-1]==cp_model_pb2.ConstraintProto(linear=cp_model_pb2.LinearConstraintProto(vars=presence,coeffs=[1]*11,domain=[9,11]));restored=proto(BASE/'models/000.pb');del restored.constraints[-1];restored.objective.CopyFrom(parent.objective);assert restored==parent
for name in ['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json','cell-selectors.json','cell-groups.json','optional-rectangles.json']:assert (BASE/name).read_bytes()==(PARENT/name).read_bytes()
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'all66_identity_obligations_preserved':True,'all_angle_continuous_source_subfamily_covered':True,'minimum_short_sheet_count':9,'statement':'The complete parent necessary feasibility region is preserved, with its objective removed and only a minimum9 short-sheet count added. Every actual source continuation of the checked55 with at least9 remaining originals on the short sheet still maps to this model. A negative excludes that count subfamily and implies at least3 remaining originals must go to the first sheet. It excludes neither other first-sheet partials nor other stock targets; positives still need both-sheet original geometry.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'exact_parent_restoration_verified':True,'minimum_short_sheet_count':9,'only_objective_removed_and_one_constraint_added':True,'actual_import_export_verified':True,'all66_identity_obligations_preserved':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
