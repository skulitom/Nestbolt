"""Independent complete optional-composition model, identity and objective audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-composition-selector-20261026';SOURCE=ROOT/'output/h5-rotation-independent-geometry-20261026';DATA=ROOT/'output/h5-rotation-independent-bands-20261026';RESOURCE=ROOT/'output/h5-composition-resources-20261026';CUT=ROOT/'output/h5-all-angle-composition-cut-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct every optional coordinate/profile/presence/direction/cell variable, every complete constraint proto, all146 optional rectangles and the exact lexicographic objective from audited source geometry and resources. Prove all source continuations map to a selected-prefix and x-sorted family assignment, while absent part coordinates impose no first-sheet pose. Exhaustively check presence/rank permutations. Verify all66 identities, complete profile cell covers, every coefficient and actual solver import/export. No solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert all(load(p/n)['passed'] for p,n in [(SOURCE,'audit/checks.json'),(DATA,'audit/checks.json'),(RESOURCE,'checks.json'),(CUT,'checks.json')]);resource=load(RESOURCE/'resources.json');spec=load(BASE/'plan.json');originals=resource['remaining_originals'];assert originals==spec['originals']==[21,22,25,26,28,29,37,53,63,64,65];assert sorted(resource['checked_first_originals']+originals)==list(range(66)) and len(set(resource['checked_first_originals']+originals))==66
allowed=[list(range(8))]*6+[[8,10]]+[[11]]*4;families=['bracket']*6+['insert']+['cog']*4;assert allowed==spec['allowed_profiles'] and families==spec['families'];bounds=load(SOURCE/'anchor-bounds.json');m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints','objective'};vi=ci=0
def var(name,domain):
    global vi
    v=vi;assert m.variables[v]==cp_model_pb2.IntegerVariableProto(name=name,domain=domain),v;vi+=1;return v
def check(c):
    global ci
    assert m.constraints[ci]==c,ci;ci+=1
def lin(terms,lo,hi,enforce=()):
    vs=sorted(v for v,k in terms.items() if k);check(cp_model_pb2.ConstraintProto(enforcement_literal=enforce,linear=cp_model_pb2.LinearConstraintProto(vars=vs,coeffs=[terms[v] for v in vs],domain=[lo,hi])))
for i,ps in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in ps),max(bounds[str(p)][axis+2] for p in ps)])
flags={i:{p:var(f'p{i}-profile{p}',[0,1]) for p in ps} for i,ps in enumerate(allowed)};present=[var(f'p{i}-on-short-sheet',[0,1]) for i in range(11)];assert present==load(BASE/'presence-flags.json') and {str(i):{str(p):v for p,v in fs.items()} for i,fs in flags.items()}==load(BASE/'profile-flags.json')
for i in range(11):
    lin({present[i]:-1,**dict.fromkeys(flags[i].values(),1)},0,0)
    for p,v in flags[i].items():
        for axis in range(2):lin({2*i+axis:1},bounds[str(p)][axis],bounds[str(p)][axis+2],[v])
for i in [0,1,2,3,4,7,8,9]:
    lin({present[i]:1,present[i+1]:-1},0,2**63-1);lin({2*i:1,2*(i+1):-1},-2**63,0,[present[i],present[i+1]])
assert (vi,ci)==(87,135)
ds={r['profile']:r for r in load(SOURCE/'profile-bounds.json')};cases={r['profiles'][0]:r for r in load(SOURCE/'pair-bounds.json')};gap=cases[11]['right_minimum_dx_units1000'];dirs={};req=[]
for a,b in product(range(7),range(7,11)):
    v=var(f'pair-{a}-{b}-right',[0,1]);dirs[f'{a}-{b}']=v
    for p in allowed[a]:
        left,right=ds[p]['left_maximum_dx_units1000'],ds[p]['right_minimum_dx_units1000'];assert left==cases[p]['left_maximum_dx_units1000'] and right==cases[p]['right_minimum_dx_units1000'] and right+gap-left>0
        lin({2*a:-1,2*b:1},-2**63,left,[flags[a][p],present[b],-v-1]);lin({2*a:-1,2*b:1},right,2**63-1,[flags[a][p],present[b],v]);req.append({'parts':[a,b],'profile':p,'left':left,'right':right})
for a,b in product(range(7),range(7,10)):check(cp_model_pb2.ConstraintProto(enforcement_literal=[present[a],present[b],present[b+1]],bool_or=cp_model_pb2.BoolArgumentProto(literals=[-dirs[f'{a}-{b}']-1,dirs[f'{a}-{b+1}']])))
for a,b in combinations(range(7,11),2):lin({2*a:-1,2*b:1},gap,2**63-1,[present[a],present[b]])
assert dirs==load(BASE/'direction-flags.json') and req==load(BASE/'direction-requirements.json')
choice=var('short-sheet-composition-cut-branch',[0,1]);lin({present[i]:1 for i in range(6)},-2**63,3,[choice]);lin({present[i]:1 for i in range(7,11)},-2**63,3,[-choice-1]);lin({present[i]:resource['rounded_up_area_units'][families[i]] for i in range(11)},resource['necessary_short_sheet_minimum_area_units'],2**63-1)
assert load(CUT/'implication.json')['necessary_short_sheet_cut']=='bracket_count <= 3 OR cog_count <= 3';cells=[];groups=[];covered=0
for i,ps in enumerate(allowed):
    for p in ps:
        data=load(DATA/'profiles'/f'{p:03d}.json');lo,hi=bounds[str(p)][1::2];assert data['y_bounds_units1000']==[lo,hi];following=lo;ids=[]
        for ordinal,c in enumerate(data['cells']):
            low,high=c['y_bounds_units1000'];assert c['index']==ordinal and low==following and high==min(low+999,hi);following=high+1;covered+=high-low+1;v=var(f'p{i}-profile{p}-cell{ordinal}',[0,1]);lin({2*i+1:1},low,high,[v]);ids.append(v);cells.append({'variable':v,'part':i,'profile':p,'cell':ordinal,'y_bounds_units1000':[low,high],'demands':c['band_lower_area_units']})
        assert following==hi+1;groups.append({'part':i,'profile':p,'profile_flag':flags[i][p],'cell_flags':ids})
for g in groups:lin({g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)},0,0)
caps=load(DATA/'band-capacities.json');assert len(caps)==63
for band,cap in enumerate(caps):lin({r['variable']:r['demands'][band] for r in cells if r['demands'][band]},-2**63,cap)
assert (vi,ci)==(2416,2982) and cells==load(BASE/'cell-selectors.json') and groups==load(BASE/'cell-groups.json')
data={p['index']:p for p in load(SOURCE/'profiles.json')};rects=[];xs=[];ys=[]
for part in range(7):
    for p in allowed[part]:
        for ordinal,b in enumerate(data[p]['rectangles_units1000']):
            ids=[]
            for axis in range(2):
                ids.append(ci);low,high=b[axis::2];expr=lambda offset:cp_model_pb2.LinearExpressionProto(vars=[2*part+axis],coeffs=[1],offset=offset);check(cp_model_pb2.ConstraintProto(enforcement_literal=[flags[part][p]],interval=cp_model_pb2.IntervalConstraintProto(start=expr(low),end=expr(high),size=cp_model_pb2.LinearExpressionProto(offset=high-low))))
            xs.append(ids[0]);ys.append(ids[1]);rects.append({'part':part,'profile':p,'rectangle':ordinal,'presence':flags[part][p],'interval_constraints':ids,'bounds_units1000':b})
check(cp_model_pb2.ConstraintProto(no_overlap_2d=cp_model_pb2.NoOverlap2DConstraintProto(x_intervals=xs,y_intervals=ys)));assert rects==load(BASE/'optional-rectangles.json')
weights=[resource['count_objective_weight']+resource['rounded_up_area_units'][f] for f in families];assert m.objective==cp_model_pb2.CpObjectiveProto(vars=present,coeffs=[-v for v in weights],scaling_factor=-1);assert sum(w-resource['count_objective_weight'] for w in weights)==resource['maximum_secondary_area_objective']<resource['count_objective_weight'];assert load(BASE/'objective.json')=={'presence_variables':present,'weights':weights,'priority':resource['count_objective_weight'],'cut_branch_variable':choice}
r=load(BASE/'inventory.json')[0];assert vi==len(m.variables)==r['variables']==2416 and ci==len(m.constraints)==r['constraints']==3275 and digest(BASE/'models/000.pb')==r['model_sha256'] and r['originals']==originals and r['allowed_profiles']==allowed and r['solver_seconds']==20
symmetry={}
for family,offset,n in [('bracket',0,6),('cog',7,4)]:
    count=0;options=allowed[offset];assert all(allowed[i]==options and families[i]==family for i in range(offset,offset+n))
    for mask in product([0,1],repeat=n):
        for ranks in permutations(range(n)):
            order=sorted(range(n),key=lambda k:(-mask[k],ranks[k]));selected=[mask[k] for k in order];assert selected==sorted(mask,reverse=True);k=sum(mask);assert [ranks[j] for j in order[:k]]==sorted(ranks[j] for j in range(n) if mask[j]);assert sorted(order)==list(range(n));count+=1
    symmetry[family]=count
assert symmetry=={'bracket':46080,'cog':384}
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'necessity-proof.json',{'every_original_has_two_sheet_obligation':True,'all_angle_continuous_source_continuation_maps':True,'first_sheet_coordinates_not_modelled':True,'converse_claimed':False,'statement':'For each of the11 remaining originals assign its actual sheet; only second-sheet parts select a profile and proxy coordinates. Sort selected identical copies first, with their profiles in x order; all remaining copies are mandatory first-sheet obligations. Identical-family allowed profiles, stock domains, pair constraints, area coefficients and objective weights make this relabelling invariant. Absent coordinate variables may be assigned any domain value: every stock/pair/cell/rectangle constraint involving the absent original is inactive, and its presence-prefix condition does not constrain actual first-sheet geometry. Selected parts satisfy the separately audited all-angle/continuous proxy map, necessary direction/gap/order constraints, fresh band bounds and inner-rectangle nonoverlap. The proved subset cut and outward-relaxed first-sheet area inequality follow from any source continuation. Thus all source continuations extend to this model without deleting an original; positives and objective optima remain necessary relaxations, not layouts or H5 acceptance.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'optional_originals_with_mandatory_first_complements':11,'all66_originals_accounted_once':True,'cell_selectors':len(cells),'cell_band_coefficients_checked':len(cells)*63,'complete_profile_y_values_covered':covered,'optional_inner_rectangles':len(rects),'presence_and_rank_symmetry_cases':symmetry,'exact_lexicographic_objective_verified':True,'all_fields_reconstructed':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
