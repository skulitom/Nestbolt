"""Necessary sheet-composition selector with explicit full-job complements."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-rotation-independent-geometry-20261026';DATA=ROOT/'output/h5-rotation-independent-bands-20261026';RESOURCE=ROOT/'output/h5-composition-resources-20261026';CUT=ROOT/'output/h5-all-angle-composition-cut-20261026';OUT=ROOT/'output/h5-complete-composition-selector-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert all(load(p/n)['passed'] for p,n in [(SOURCE,'audit/checks.json'),(DATA,'audit/checks.json'),(RESOURCE,'checks.json'),(CUT,'checks.json')]);resource=load(RESOURCE/'resources.json');originals=resource['remaining_originals'];assert originals==[21,22,25,26,28,29,37,53,63,64,65];families=['bracket']*6+['insert']+['cog']*4;allowed=[list(range(8)) for _ in range(6)]+[[8,10]]+[[11] for _ in range(4)];bounds=load(SOURCE/'anchor-bounds.json')
paths=[p for folder in [SOURCE,DATA,RESOURCE,CUT] for p in folder.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':allowed,'originals':originals,'families':families,'checked_first_originals':resource['checked_first_originals'],'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Complete necessary composition selector over all11 remaining originals, with every unselected short-sheet original explicitly mandatory on the first sheet. Presence is exactly the sum of profile flags, hence one selected proxy or a first-sheet obligation. Selected identical family copies form a prefix and are x-ordered with their profiles; absent anchors do not represent first-sheet positions. Add only presence-conditional all-angle stock/direction/order/gap constraints, complete fresh band cells,146 optional inner rectangles, the proved bracket<=3 OR cog<=3 short-sheet cut and exact relaxed-first-sheet area resource. Maximize selected count then rounded original area using independently proved lexicographic weights. No geometry or count cut from finite angles. A positive is only a necessary allocation. A negative excludes continuations of this checked55 partial under this stock target, not all H5 layouts. One20solver/30shared4worker seed0 call after complete independent reconstruction and import audit.'})
m=cp_model_pb2.CpModelProto()
def var(name,dom):
    v=len(m.variables);m.variables.add(name=name,domain=dom);return v
def lin(terms,lo,hi,enforce=()):
    vs=sorted(v for v,k in terms.items() if k);c=m.constraints.add();c.enforcement_literal.extend(enforce);c.linear.vars.extend(vs);c.linear.coeffs.extend(terms[v] for v in vs);c.linear.domain.extend([lo,hi])
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in options),max(bounds[str(p)][axis+2] for p in options)])
flags={i:{p:var(f'p{i}-profile{p}',[0,1]) for p in options} for i,options in enumerate(allowed)};present=[var(f'p{i}-on-short-sheet',[0,1]) for i in range(11)]
for i in range(11):
    lin({present[i]:-1,**dict.fromkeys(flags[i].values(),1)},0,0)
    for p,v in flags[i].items():
        for axis in range(2):lin({2*i+axis:1},bounds[str(p)][axis],bounds[str(p)][axis+2],[v])
for i in [0,1,2,3,4,7,8,9]:
    lin({present[i]:1,present[i+1]:-1},0,2**63-1);lin({2*i:1,2*(i+1):-1},-2**63,0,[present[i],present[i+1]])
assert (len(m.variables),len(m.constraints))==(87,135)
dirs={};dmap={r['profile']:r for r in load(SOURCE/'profile-bounds.json')};requirements=[]
for a,b in product(range(7),range(7,11)):
    v=var(f'pair-{a}-{b}-right',[0,1]);dirs[f'{a}-{b}']=v
    for p in allowed[a]:
        d=dmap[p];left,right=d['left_maximum_dx_units1000'],d['right_minimum_dx_units1000'];lin({2*a:-1,2*b:1},-2**63,left,[flags[a][p],present[b],-v-1]);lin({2*a:-1,2*b:1},right,2**63-1,[flags[a][p],present[b],v]);requirements.append({'parts':[a,b],'profile':p,'left':left,'right':right})
for a,b in product(range(7),range(7,10)):
    c=m.constraints.add();c.enforcement_literal.extend([present[a],present[b],present[b+1]]);c.bool_or.literals.extend([-dirs[f'{a}-{b}']-1,dirs[f'{a}-{b+1}']])
gap=load(SOURCE/'result.json')['cog_minimum_dx_units1000']
for a,b in combinations(range(7,11),2):lin({2*a:-1,2*b:1},gap,2**63-1,[present[a],present[b]])
choice=var('short-sheet-composition-cut-branch',[0,1]);lin({present[i]:1 for i in range(6)},-2**63,3,[choice]);lin({present[i]:1 for i in range(7,11)},-2**63,3,[-choice-1]);lin({present[i]:resource['rounded_up_area_units'][families[i]] for i in range(11)},resource['necessary_short_sheet_minimum_area_units'],2**63-1)
selectors=[];groups=[]
for i,options in enumerate(allowed):
    for p in options:
        ids=[]
        for cell in load(DATA/'profiles'/f'{p:03d}.json')['cells']:
            v=var(f'p{i}-profile{p}-cell{cell["index"]}',[0,1]);lin({2*i+1:1},*cell['y_bounds_units1000'],[v]);ids.append(v);selectors.append({'variable':v,'part':i,'profile':p,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
        groups.append({'part':i,'profile':p,'profile_flag':flags[i][p],'cell_flags':ids})
for g in groups:lin({g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)},0,0)
for b,cap in enumerate(load(DATA/'band-capacities.json')):lin({r['variable']:r['demands'][b] for r in selectors},-2**63,cap)
assert (len(m.variables),len(m.constraints))==(2416,2982)
profiles={p['index']:p for p in load(SOURCE/'profiles.json')};rects=[];xs=[];ys=[]
for part in range(7):
    for p in allowed[part]:
        for j,b in enumerate(profiles[p]['rectangles_units1000']):
            ids=[]
            for axis in range(2):
                ids.append(len(m.constraints));c=m.constraints.add();c.enforcement_literal.append(flags[part][p]);c.interval.start.vars.append(2*part+axis);c.interval.start.coeffs.append(1);c.interval.start.offset=b[axis];c.interval.end.vars.append(2*part+axis);c.interval.end.coeffs.append(1);c.interval.end.offset=b[axis+2];c.interval.size.offset=b[axis+2]-b[axis]
            xs.append(ids[0]);ys.append(ids[1]);rects.append({'part':part,'profile':p,'rectangle':j,'presence':flags[part][p],'interval_constraints':ids,'bounds_units1000':b})
c=m.constraints.add();c.no_overlap_2d.x_intervals.extend(xs);c.no_overlap_2d.y_intervals.extend(ys);assert (len(m.variables),len(m.constraints))==(2416,3275)
weights=[resource['count_objective_weight']+resource['rounded_up_area_units'][f] for f in families];m.objective.vars.extend(present);m.objective.coeffs.extend(-v for v in weights);m.objective.scaling_factor=-1
for n,v in [('profile-flags.json',flags),('presence-flags.json',present),('direction-flags.json',dirs),('direction-requirements.json',requirements),('cell-selectors.json',selectors),('cell-groups.json',groups),('optional-rectangles.json',rects),('objective.json',{'presence_variables':present,'weights':weights,'priority':resource['count_objective_weight'],'cut_branch_variable':choice})]:write(OUT/n,v)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');r={'index':0,'parts':list(range(11)),'originals':originals,'allowed_profiles':allowed,'variables':len(m.variables),'constraints':len(m.constraints),'solver_seconds':20,'model_sha256':digest(p),'cell_selectors':len(selectors),'profile_cell_equalities':len(groups),'presence_flags':11,'direction_flags':28,'direction_inequalities':400,'conditional_monotone_clauses':21,'conditional_cog_spacing_constraints':6,'band_inequalities':63,'optional_inner_rectangles':146,'optional_intervals':292,'no_overlap_2d_constraints':1};write(OUT/'inventory.json',[r]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**r,'solver_calls':0});print(load(OUT/'prepared.json'))
