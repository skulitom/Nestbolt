from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_support_composition_selector.py').read_text().replace('h5-support-composition-selector-20261026','h5-nine-short-decision-20261026')
with (ROOT/'output/run_h5_nine_short_decision.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_support_selector_response.py').read_text().replace('h5-support-composition-selector-20261026','h5-nine-short-decision-20261026')
old="objective=-(sum(sol[v]*k for v,k in zip(m.objective.vars,m.objective.coeffs))+m.objective.offset);assert objective==expected==response.objective_value and response.best_objective_bound>=objective\n    if r['status']=='OPTIMAL':assert response.best_objective_bound==objective"
new="objective=expected;assert selected_count>=9 and not m.HasField('objective') and response.objective_value==response.best_objective_bound==0"
assert old in s;s=s.replace(old,new).replace("'lexicographic_optimal':r['status']=='OPTIMAL'","'lexicographic_optimal':False").replace("'maximum_necessary_selected_count':selected_count if r['status']=='OPTIMAL' else None","'maximum_necessary_selected_count':None").replace("'objective_optimal':r['status']=='OPTIMAL'","'objective_optimal':False").replace("If optimum is proved, use exact lexicographic objective to infer maximum necessary selected count; no actual geometric layout claim.","Verify selected count is at least9; no objective remains and no actual layout is claimed.")
with (ROOT/'output/audit_h5_nine_short_response.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Separate nine-or-more feasibility runner and response auditor prepared.')
