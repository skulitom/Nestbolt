from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,dest in [('run_h5_complete_composition_selector.py','run_h5_support_composition_selector.py'),('audit_h5_composition_selector_response.py','audit_h5_support_selector_response.py')]:
    s=(ROOT/'output'/source).read_text().replace('h5-complete-composition-selector-20261026','h5-support-composition-selector-20261026')
    with (ROOT/'output'/dest).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Separate strengthened selector call and response audit prepared.')
