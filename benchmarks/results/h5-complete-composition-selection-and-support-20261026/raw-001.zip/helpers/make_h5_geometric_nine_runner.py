from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_nine_short_decision.py').read_text().replace('h5-nine-short-decision-20261026','h5-geometric-nine-decision-20261026')
with (ROOT/'output/run_h5_geometric_nine_decision.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_nine_short_response.py').read_text().replace('h5-nine-short-decision-20261026','h5-geometric-nine-decision-20261026')
begin=s.index("    cells=[r for r in load(BASE/'cell-selectors.json')")
end=s.index(";resource=load(RESOURCE/'resources.json')",begin)
replacement="""    # Omitted parent bands are checked diagnostically, never asserted as model constraints.
    cells=[]
    for i,p in enumerate(chosen):
        if p is None:continue
        datum=load(ROOT/'output/h5-rotation-independent-bands-20261026/profiles'/f'{p:03d}.json')
        matching=[c for c in datum['cells'] if c['y_bounds_units1000'][0]<=sol[2*i+1]<=c['y_bounds_units1000'][1]]
        assert len(matching)==1;cell=matching[0];cells.append({'part':i,'profile':p,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
    loads=[sum(r['demands'][j] for r in cells) for j in range(63)];caps=load(ROOT/'output/h5-rotation-independent-bands-20261026/band-capacities.json')"""
s=s[:begin]+replacement+s[end:]
s=s.replace("'band_capacities':caps,","'band_capacities':caps,'omitted_bands_satisfied':all(a<=b for a,b in zip(loads,caps)),")
with (ROOT/'output/audit_h5_geometric_nine_response.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Separate geometry-only necessary decision runner prepared.')
