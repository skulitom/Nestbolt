from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_all_angle_projection.py').read_text().replace('h5-all-angle-projection-20261026','h5-complete-composition-selector-20261026').replace('One nine-original strip model','One complete remaining-original composition selector')
with (ROOT/'output/run_h5_complete_composition_selector.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('One20solver/30shared second call prepared, not started.')
