"""Strengthen the closed selector with new original-tip support implications."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-complete-composition-selector-20261026';DATA=ROOT/'output/h5-all-angle-support-bounds-20261026';OUT=ROOT/'output/h5-support-composition-selector-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='FEASIBLE' and load(DATA/'audit/checks.json')['passed']
copied=['profile-flags.json','presence-flags.json','direction-flags.json','cell-selectors.json','cell-groups.json','optional-rectangles.json','objective.json'];paths=[PARENT/n for n in ['plan.json','models/000.pb','inventory.json','direction-requirements.json','model-audit/checks.json','model-audit/necessity-proof.json','response-audit/checks.json']+copied]+[p for p in DATA.rglob('*') if p.is_file()];oldplan=load(PARENT/'plan.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':oldplan['allowed_profiles'],'originals':oldplan['originals'],'families':oldplan['families'],'checked_first_originals':oldplan['checked_first_originals'],'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Preserve the complete closed optional selector and objective. Tighten only192 bracket/cog directional endpoints using the independently proved original support-tip/full-height-stem intervals, and all6 presence-conditional cog X gaps from215446 to245034micrometres. Every original continuation obeys these all-angle/continuous-position implications. No pose, count, original, cell or objective changes; parent proxy positives need not survive. Independently restore every parent field and verify actual import before one new20solver/30shared4worker seed0 call. The earlier FEASIBLE call is closed, not extended.'})
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'models/000.pb').read_bytes());rows=load(PARENT/'direction-requirements.json');updates={r['profile']:r for r in load(DATA/'bracket-direction-bounds.json')};changes=[]
def change(index,side,new):
    c=m.constraints[index];old=c.linear.domain[side]
    if old!=new:changes.append({'constraint':index,'domain_endpoint':side,'old':old,'new':new});c.linear.domain[side]=new
for j,row in enumerate(rows):
    if row['profile']>=8:continue
    p=updates[row['profile']];change(135+2*j,1,p['combined_left']);change(135+2*j+1,0,p['combined_right']);row['left'],row['right']=p['combined_left'],p['combined_right']
gap=load(DATA/'cog-spacing-proof.json')['minimum_dx_units1000']
for ordinal,pair in enumerate(combinations(range(7,11),2)):change(556+ordinal,0,gap)
assert len(changes)==198 and (len(m.variables),len(m.constraints))==(2416,3275)
for name in copied:shutil.copyfile(PARENT/name,OUT/name)
write(OUT/'direction-requirements.json',rows);write(OUT/'changed-domain-endpoints.json',changes)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');r={**load(PARENT/'inventory.json')[0],'model_sha256':digest(p),'strengthened_domain_endpoints':len(changes),'new_cog_minimum_dx_units1000':gap};write(OUT/'inventory.json',[r]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**r,'solver_calls':0});print(load(OUT/'prepared.json'))
