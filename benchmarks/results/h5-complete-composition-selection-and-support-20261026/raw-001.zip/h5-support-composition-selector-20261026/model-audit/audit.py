"""Independent original-support strengthening and complete parent restoration."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-support-composition-selector-20261026';PARENT=ROOT/'output/h5-complete-composition-selector-20261026';DATA=ROOT/'output/h5-all-angle-support-bounds-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently derive all192 strengthened bracket endpoints and6 cog gaps from audited original support geometry. Verify exact physical coordinate coefficients and presence/profile/side enforcement at each changed constraint. Restore every changed endpoint and require full parent proto equality, including all variables, other constraints and objective. Verify all mappings and actual import/export. Every strengthened condition is necessary for all-angle continuous original placements; no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'model-audit/necessity-proof.json')['all_angle_continuous_source_continuation_maps'] and load(DATA/'audit/checks.json')['passed'];m=proto(BASE/'models/000.pb');parent=proto(PARENT/'models/000.pb');restored=proto(BASE/'models/000.pb');flags=load(PARENT/'profile-flags.json');presence=load(PARENT/'presence-flags.json');directions=load(PARENT/'direction-flags.json');new={r['profile']:r for r in load(DATA/'bracket-direction-bounds.json')};rows=load(PARENT/'direction-requirements.json');changes=[]
for j,row in enumerate(rows):
    a,b=row['parts'];p=row['profile'];left,right=(new[p]['combined_left'],new[p]['combined_right']) if p in new else (row['left'],row['right']);side=directions[f'{a}-{b}']
    for index,endpoint,want,enforce,domain in [(135+2*j,1,left,[flags[str(a)][str(p)],presence[b],-side-1],[-2**63,left]),(135+2*j+1,0,right,[flags[str(a)][str(p)],presence[b],side],[right,2**63-1])]:
        expected=cp_model_pb2.ConstraintProto(enforcement_literal=enforce,linear=cp_model_pb2.LinearConstraintProto(vars=[2*a,2*b],coeffs=[-1,1],domain=domain));assert m.constraints[index]==expected;old=parent.constraints[index].linear.domain[endpoint]
        if old!=want:assert (want<old if endpoint==1 else want>old);changes.append({'constraint':index,'domain_endpoint':endpoint,'old':old,'new':want});restored.constraints[index].linear.domain[endpoint]=old
    row['left'],row['right']=left,right
gap=load(DATA/'cog-spacing-proof.json')['minimum_dx_units1000']
for ordinal,(a,b) in enumerate(combinations(range(7,11),2)):
    index=556+ordinal;expected=cp_model_pb2.ConstraintProto(enforcement_literal=[presence[a],presence[b]],linear=cp_model_pb2.LinearConstraintProto(vars=[2*a,2*b],coeffs=[-1,1],domain=[gap,2**63-1]));assert m.constraints[index]==expected;old=parent.constraints[index].linear.domain[0];assert gap>old;changes.append({'constraint':index,'domain_endpoint':0,'old':old,'new':gap});restored.constraints[index].linear.domain[0]=old
assert len(changes)==198 and restored==parent and rows==load(BASE/'direction-requirements.json') and changes==load(BASE/'changed-domain-endpoints.json')
for name in ['profile-flags.json','presence-flags.json','direction-flags.json','cell-selectors.json','cell-groups.json','optional-rectangles.json','objective.json']:assert (BASE/name).read_bytes()==(PARENT/name).read_bytes()
r=load(BASE/'inventory.json')[0];assert digest(BASE/'models/000.pb')==r['model_sha256'] and len(m.variables)==r['variables']==2416 and len(m.constraints)==r['constraints']==3275
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'every_original_has_two_sheet_obligation':True,'all_angle_continuous_source_continuation_maps':True,'parent_proxy_equivalence_claimed':False,'statement':'The whole parent necessary model, all66 identity accounting, optional-prefix symmetry, first-sheet area resource and lexicographic objective are unchanged. Only192 bracket/cog bounds and6 cog gaps tighten. They follow from the separately audited original-vertex support, original disk containment, full-height bracket stems and continuous anchor rounding proof, for every real cog angle. Thus every actual source continuation still maps into this stronger model, while an earlier proxy-only feasible selection may be removed. Positives remain necessary allocations; no first-sheet poses or full original collision witness are inferred.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'strengthened_bracket_direction_endpoints':192,'strengthened_cog_spacing_bounds':6,'complete_parent_restoration_verified':True,'all_other_fields_and_objective_unchanged':True,'actual_import_export_verified':True,'all66_identity_obligations_preserved':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
