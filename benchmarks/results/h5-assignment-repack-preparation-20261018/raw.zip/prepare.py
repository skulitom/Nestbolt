"""Prepare a diagnostic-only original-model reconstruction and full repack."""
from pathlib import Path
from hashlib import sha256
import json,shutil,zipfile,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-assignment-repack-20261018';out.mkdir()
old=root/'output/h5-return-frame-probe-20261017/candidate';work=out/'workspace';shutil.copytree(old,work)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
changed=['crates/core/src/sheets.rs','crates/core/src/sheets/vstrip.rs']
p=work/changed[0];s=p.read_text(encoding='utf-8');assert s.count('mod vstrip;')==1
p.write_text(s.replace('mod vstrip;','pub mod vstrip;'),encoding='utf-8',newline='\n')
p=work/changed[1];s=p.read_text(encoding='utf-8');p.write_text(s+'\n// Isolated diagnostic entry point; existing search behavior is unchanged.\npub mod repack_diagnostic;\n',encoding='utf-8',newline='\n')
shutil.copyfile(root/'output/return_assignment_repack.rs',work/'crates/core/src/sheets/vstrip/repack_diagnostic.rs')
shutil.copyfile(root/'output/return_assignment_repack_example.rs',work/'crates/core/examples/return_assignment_repack.rs')
source=root/'benchmarks/results/h5-return-capacity-diagnosis-20261017';records=load(source/'summary.json')['records']
inputs=out/'inputs';inputs.mkdir();selection=[]
for record in records:
    archive=source/record['archive'];assert digest(archive)==record['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        case=json.loads(z.read('case.json'))
        assert all(sha256(z.read(name)).hexdigest()==expected for name,expected in case['artifacts'].items())
        job=json.loads(z.read('nested/job.json'))
        traces=[json.loads(line.removeprefix('OBSTRUCTION_DIAG ')) for line in z.read('search-stderr.log').decode().splitlines() if line.startswith('OBSTRUCTION_DIAG ')]
    ti,ai,t,a=next((ti,ai,t,a) for ti,t in enumerate(traces) for ai,a in enumerate(t['attempts']))
    context=t['contexts'][a['context_index']]
    name=record['job']+'-k'+str(record['kerf_mm'])+'.json'
    value={'job':job,'shape_last':context['shape_last'],'full_width':context['full_width'],'initial':a['source_initial']}
    write(inputs/name,value)
    selection.append({'job':record['job'],'kerf_mm':record['kerf_mm'],'input':name,'sha256':digest(inputs/name),
        'archive':record['archive'],'archive_sha256':record['archive_sha256'],'trace_index':ti,'attempt_index':ai,
        'parts':len(value['initial']['items']),'original_outcome':a['outcome'],'selection':'first attempted exchange in this saved case'})
assert len(selection)==4
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'production_digest':source_digest(),'old_source':str(old),'source_files':[{'path':p.relative_to(old).as_posix(),'sha256':digest(p)} for p in sorted(old.rglob('*')) if p.is_file()],
    'changed_existing_files':changed,'added_files':['crates/core/src/sheets/vstrip/repack_diagnostic.rs','crates/core/examples/return_assignment_repack.rs'],
    'selection':selection,'target':str(root/'output/h5-assignment-repack-target-20261018'),
    'method':'Original model and shortened container; require exact saved f32 polygon and boundary equality before search. Up to six ten-second rounds, first from saved positions and five full random restarts, stopping on first separator-clear snapshot. Seed zero; serial physical CCD0 CPU8. Every round retained and independently audited. No integration or H5 quality claim.',
    'measured_search_started':False}
write(out/'preparation.json',plan);shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'fixed_assignments':len(selection),'production_digest':plan['production_digest']}))
