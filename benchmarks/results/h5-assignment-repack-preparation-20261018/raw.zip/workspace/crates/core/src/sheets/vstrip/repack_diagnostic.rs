//! Diagnostic only: reconstruct a saved assignment exactly, then seek a packing.
use super::*;
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
struct Pose {
    rotation: f32,
    reflected: bool,
    translation: (f32, f32),
}
impl Pose {
    fn transform(&self) -> DTransformation {
        DTransformation::new(self.rotation, self.translation).with_reflection(self.reflected)
    }
}
#[derive(Deserialize)]
struct SavedItem {
    item_index: usize,
    external_id: u64,
    pose: Pose,
    polygon: Vec<[f32; 2]>,
}
#[derive(Deserialize)]
struct SavedLayout {
    container: Vec<[f32; 2]>,
    items: Vec<SavedItem>,
}
#[derive(Deserialize)]
struct Input {
    job: Job,
    shape_last: f32,
    full_width: f32,
    initial: SavedLayout,
}
#[derive(Serialize)]
struct Round {
    index: usize,
    initialization: &'static str,
    initial_loss: f32,
    best_loss: f32,
    seconds: f64,
    geometry: serde_json::Value,
}

fn geometry(layout: &JLayout, model: &Model<'_>) -> serde_json::Value {
    let container: Vec<_> = layout
        .container()
        .outer_cd()
        .vertices()
        .iter()
        .map(|p| [p.x(), p.y()])
        .collect();
    let items: Vec<_> = layout.placed_items().values().map(|p| {
        let polygon: Vec<_> = p.shape().vertices().iter().map(|q| [q.x(),q.y()]).collect();
        let pose=p.d_transf();
        serde_json::json!({"item_index":p.item().idx(),"external_id":p.item().external_id(),
            "pose":{"rotation":pose.rotation(),"reflected":pose.reflected,"translation":pose.translation()},
            "public_transform":model.external(p.item().idx(),&pose),
            "orientation_allowed":p.item().allowed_orientations().allows(&pose),"polygon":polygon})
    }).collect();
    serde_json::json!({"container":container,"items":items})
}

/// With zero seconds, only verify exact reconstruction. Otherwise run once for
/// at most sixty seconds: one warm repair and up to five full random restarts,
/// each capped at ten seconds. Stop at the first separator-clear snapshot.
pub fn run(bytes: &[u8], seconds: f64, seed: u64) -> Result<serde_json::Value> {
    ensure!(
        seconds == 0.0 || seconds == 60.0,
        "diagnostic allows restore-only or fixed 60-second search"
    );
    let input: Input = serde_json::from_slice(bytes)?;
    let model = Model::new(&input.job)?;
    ensure!(model.full_width == input.full_width, "full width changed");
    let build_clock = crate::clock::Clock::new(crate::clock::Timing::Wall, 60.0);
    let strip = Strip {
        model: &model,
        gap: model.full_width.max(model.instance.base_strip.fixed_height) * 0.02,
        clock: build_clock,
        containers: Default::default(),
    };
    let container = strip.container(Shape {
        sheets: 1,
        last: input.shape_last,
    })?;
    let points: Vec<_> = container
        .outer_cd()
        .vertices()
        .iter()
        .map(|p| [p.x(), p.y()])
        .collect();
    ensure!(
        points == input.initial.container,
        "saved boundary differs from original model"
    );
    let mut restored = JLayout::new(container.clone());
    let mut members = Vec::new();
    for saved in &input.initial.items {
        let (item, _) = model
            .instance
            .items
            .iter()
            .find(|(item, _)| item.idx() == saved.item_index)
            .ok_or_else(|| anyhow::anyhow!("missing original item index"))?;
        ensure!(
            item.external_id() == saved.external_id,
            "original part identity changed"
        );
        let dt = saved.pose.transform();
        ensure!(
            item.allowed_orientations().allows(&dt),
            "saved pose is forbidden"
        );
        let key = restored.place_item(item, dt);
        let polygon: Vec<_> = restored.placed_items()[key]
            .shape()
            .vertices()
            .iter()
            .map(|p| [p.x(), p.y()])
            .collect();
        ensure!(
            polygon == saved.polygon,
            "saved collision polygon differs from original model"
        );
        members.push(item.clone());
    }
    let restored_geometry = geometry(&restored, &model);
    if seconds == 0.0 {
        return Ok(
            serde_json::json!({"exact_reconstruction":true,"parts":members.len(),"geometry":restored_geometry,"search_started":false}),
        );
    }
    let clock = crate::clock::Clock::new(crate::clock::Timing::Wall, seconds);
    let mut rng = Xoshiro256PlusPlus::seed_from_u64(seed);
    let bounds = container.outer_cd().bbox();
    let mut rounds = Vec::new();
    let mut found = false;
    for index in 0..6 {
        if clock.now() >= seconds {
            break;
        }
        let mut layout = if index == 0 {
            JLayout::from_snapshot(&restored.save())
        } else {
            JLayout::new(container.clone())
        };
        if index > 0 {
            for item in &members {
                let sampler = UniformBBoxSampler::new(bounds, item, bounds)
                    .ok_or_else(|| anyhow::anyhow!("item has no legal bounding-box sample"))?;
                layout.place_item(item, sampler.sample(&mut rng));
            }
        }
        let start = clock.now();
        let mut separator = Separator::new(layout, rng.next_u64(), EXPLORE, clock.clone());
        let initial_loss = separator.tracker.total_loss();
        let (snapshot, tracker) = separator.separate(&crate::clock::Deadline {
            clock: clock.clone(),
            at: (start + 10.0).min(seconds),
        });
        let best_loss = tracker.total_loss();
        rounds.push(Round {
            index,
            initialization: if index == 0 {
                "saved_initial"
            } else {
                "all_items_random"
            },
            initial_loss,
            best_loss,
            seconds: clock.now() - start,
            geometry: geometry(&JLayout::from_snapshot(&snapshot), &model),
        });
        if best_loss == 0.0 {
            found = true;
            break;
        }
    }
    Ok(
        serde_json::json!({"exact_reconstruction":true,"parts":members.len(),"seed":seed,"maximum_seconds":seconds,
        "search_seconds":clock.now(),"separator_clear_snapshot_found":found,"rounds":rounds,
        "independent_validation_required":true,"quality_claim":false,"H5_complete":false}),
    )
}
