use anyhow::{Result, ensure};
use std::{fs, path::PathBuf};
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    ensure!(
        args.len() == 5,
        "usage: return_assignment_repack INPUT OUTPUT SECONDS SEED"
    );
    let out = PathBuf::from(&args[2]);
    ensure!(!out.exists(), "output already exists");
    let result = nestbolt_core::sheets::vstrip::repack_diagnostic::run(
        &fs::read(&args[1])?,
        args[3].parse()?,
        args[4].parse()?,
    )?;
    fs::write(out, serde_json::to_vec_pretty(&result)?)?;
    Ok(())
}
