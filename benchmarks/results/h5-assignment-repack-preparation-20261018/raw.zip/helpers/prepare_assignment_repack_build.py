from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/build_h5_return_capacity_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5-return-capacity-diagnosis-20261017','h5-assignment-repack-20261018').replace('h5-return-capacity-target-20261017','h5-assignment-repack-target-20261018')
s=s.replace("shutil.copyfile(WORK/plan['changed_file'],OUT/'exchange-before-format.rs')", "shutil.copyfile(WORK/'crates/core/src/sheets/vstrip/repack_diagnostic.rs',OUT/'repack-before-format.rs')")
s=s.replace("if r['path']!=plan['changed_file']:","if r['path'] not in plan['changed_existing_files']:")
s=s.replace("'exchange_probe'","'return_assignment_repack'").replace('release/examples/exchange_probe.exe','release/examples/return_assignment_repack.exe').replace('exchange-diagnosis.exe','assignment-repack.exe')
s=s.replace("'source_sha256':digest(WORK/plan['changed_file'])", "'source_sha256':{rel:digest(WORK/rel) for rel in plan['changed_existing_files']+plan['added_files']}")
p=root/'output/build_h5_assignment_repack.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared isolated assignment-repacking build with full source guards.')
