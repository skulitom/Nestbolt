"""Verify exact saved-input reconstruction without starting a search."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-repack-20261018'
out=probe/'restore-checks';out.mkdir();load=lambda p:json.loads(p.read_bytes())
plan=load(probe/'preparation.json');build=load(probe/'build.json');assert build['all_passed']
binary=probe/'assignment-repack.exe';assert sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
rows=[]
def run(name,path,valid):
    result=out/(name+'.json');cmd=[str(binary),str(path),str(result),'0','0']
    p=subprocess.run(cmd,cwd=root,capture_output=True,timeout=30)
    (out/(name+'-stdout.log')).write_bytes(p.stdout);(out/(name+'-stderr.log')).write_bytes(p.stderr)
    row={'name':name,'input':str(path),'command':cmd,'exit_code':p.returncode,'expected_valid':valid}
    rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
    assert (p.returncode==0)==valid,(name,p.stderr.decode(errors='replace'))
    if valid:
        x=load(result);assert x['exact_reconstruction'] and x['search_started'] is False
        assert x['parts']==len(load(path)['initial']['items']);row['parts']=x['parts']
    else:assert not result.exists()
for row in plan['selection']:run(Path(row['input']).stem,probe/'inputs'/row['input'],True)
first=load(probe/'inputs'/plan['selection'][0]['input'])
mutations=[('changed-boundary',lambda x:x['initial']['container'][0].__setitem__(0,x['initial']['container'][0][0]+1)),
    ('changed-part-identity',lambda x:x['initial']['items'][0].update(external_id=999)),
    ('changed-polygon',lambda x:x['initial']['items'][0]['polygon'][0].__setitem__(0,x['initial']['items'][0]['polygon'][0][0]+1)),
    ('forbidden-orientation',lambda x:x['initial']['items'][0]['pose'].update(rotation=x['initial']['items'][0]['pose']['rotation']+.123))]
for name,mutate in mutations:
    value=copy.deepcopy(first);mutate(value);path=out/(name+'-input.json')
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n');run(name,path,False)
record={'all_checks_pass':True,'binary_sha256':build['binary_sha256'],'real_saved_assignments_exact':4,
    'malformed_reconstructions_rejected':4,'measured_searches':0,'rows':rows}
(out/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check.py');print(json.dumps(record))
