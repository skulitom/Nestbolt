"""Exercise independent feasibility audit acceptance and rejection boundaries."""
from pathlib import Path
from hashlib import sha256
from copy import deepcopy
import json,shutil,subprocess
import audit_h5_assignment_repack as audit
root=Path(__file__).resolve().parents[1];out=root/'output/h5-assignment-repack-20261018/audit-checks';out.mkdir()
part={'id':'square','quantity':2,'geometry':[{'outer':[[0,0],[30,0],[30,30],[0,30]],'holes':[]}],
    'rotations':{'kind':'list','degrees':[0]},'allow_mirror':False,'priority':1}
job={'version':1,'name':'authored independent audit check','units':'mm','parts':[part],
    'stocks':[{'id':'stock','width':100,'height':100,'margins':dict(left=0,right=0,top=0,bottom=0),'outline':[],'defects':[],'count':None}],
    'clearance':.2,'edge_clearance':1,'mode':'all'}
value={'container':[[1,1],[99,1],[99,99],[1,99]],'items':[
    {'item_index':0,'external_id':0,'orientation_allowed':True,
        'public_transform':{'translation':[x,2],'rotation_radians':0,'mirrored':False},
        'polygon':[[x-.1,1.9],[x+30.1,1.9],[x+30.1,32.1],[x-.1,32.1]]} for x in [2,34]]}
original={'job':job,'initial':deepcopy(value)}
positive,subset,layout=audit.inspect(value,original)
assert positive['collision_clear'] and positive['original_filled_outer_clear']
assert abs(positive['minimum_original_clearance_slack_mm']-1.8)<1e-12
audit.write(out/'job.json',subset);audit.write(out/'layout.json',layout)
command=[str(root/'target/release/nestbolt.exe'),'validate','--job',str(out/'job.json'),'--layout',str(out/'layout.json')]
p=subprocess.run(command,cwd=root,capture_output=True,timeout=30)
(out/'stdout.json').write_bytes(p.stdout);(out/'stderr.log').write_bytes(p.stderr)
assert p.returncode==0 and json.loads(p.stdout)['valid']
collision=deepcopy(value);collision['items'][1]['polygon']=collision['items'][0]['polygon']
assert not audit.inspect(collision,original)[0]['collision_clear']
physical=deepcopy(value);physical['items'][1]['public_transform']=physical['items'][0]['public_transform']
assert not audit.inspect(physical,original)[0]['original_filled_outer_clear']
mutations=[('wrong membership',lambda v:v['items'].pop()),
    ('changed shortened boundary',lambda v:v['container'][0].__setitem__(0,0)),
    ('forbidden original orientation',lambda v:v['items'][0]['public_transform'].update(rotation_radians=.123))]
for name,mutate in mutations:
    v=deepcopy(value);mutate(v)
    try:audit.inspect(v,original)
    except AssertionError:pass
    else:raise AssertionError('Audit accepted '+name)
record={'all_checks_pass':True,'positive_layout_CLI_valid':True,'analytic_original_gap_slack_mm':1.8,
    'rejected':['saved collision overlap','original filled-outer overlap',*[name for name,_ in mutations]],
    'audit_sha256':sha256(Path(audit.__file__).read_bytes()).hexdigest(),'shapely_version':audit.shapely.__version__,
    'CLI_sha256':sha256((root/'target/release/nestbolt.exe').read_bytes()).hexdigest(),'command':command,'new_searches':0}
audit.write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py');print(json.dumps(record))
