from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-repack-20261018'
out=root/'benchmarks/results/h5-assignment-repack-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
prep=load(probe/'preparation.json');build=load(probe/'build.json');restore=load(probe/'restore-checks/checks.json');audit=load(probe/'audit-checks/checks.json')
assert build['all_passed'] and restore['all_checks_pass'] and audit['all_checks_pass']
assert restore['binary_sha256']==build['binary_sha256']==digest(probe/'assignment-repack.exe')
assert audit['audit_sha256']==digest(root/'output/audit_h5_assignment_repack.py')
assert '90 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==prep['production_digest']
for row in prep['source_files']:
    assert digest(Path(prep['old_source'])/row['path'])==row['sha256']
    if row['path'] not in prep['changed_existing_files']:assert digest(probe/'workspace'/row['path'])==row['sha256']
old=Path(prep['old_source']);work=probe/'workspace'
before=(old/'crates/core/src/sheets.rs').read_text(encoding='utf-8')
after=(work/'crates/core/src/sheets.rs').read_text(encoding='utf-8')
assert after==before.replace('mod vstrip;','pub mod vstrip;')
before=(old/'crates/core/src/sheets/vstrip.rs').read_text(encoding='utf-8')
after=(work/'crates/core/src/sheets/vstrip.rs').read_text(encoding='utf-8')
assert after==before+'\n// Isolated diagnostic entry point; existing search behavior is unchanged.\npub mod repack_diagnostic;\n'
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_assignment_repack_build.py','build_h5_assignment_repack.py','check_h5_assignment_restore.py',
    'audit_h5_assignment_repack.py','check_assignment_repack_audit.py','return_assignment_repack.rs','return_assignment_repack_example.rs']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_assignment_repack.py';files['seal.py']=Path(__file__)
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'crc_and_all_members_verified':True})
for name in ['preparation.json','build.json']:shutil.copyfile(probe/name,out/name)
write(out/'checks.json',{'core_tests':90,'strict_lint_passed':True,'build_passed':True,'exact_saved_assignment_restorations':4,
    'malformed_reconstruction_inputs_rejected':4,'independent_audit_positive_CLI_valid':True,'independent_audit_negative_cases_rejected':5,
    'existing_source_changes_only_module_visibility_and_entry':True,'all_other_146_original_source_files_unchanged':True,
    'production_unchanged':True,'measured_searches':0,'H5_complete':False,'completed_weight_percent':60})
doc='''# Fixed return-assignment repack preparation — 2026-10-18

The first attempted exchange in each of the four saved capacity cases is fixed
before new searching: two large-plate assignments of 21 parts and two panel
assignments of 103 parts. Both kerfs are retained. All four restore through the
original full-job model with **exact saved f32 container and collision polygons**
and allowed orientations. No rescaling, new clearance or reduced part count.

An isolated diagnostic entry passes 90 optimized core tests, strict lint and
build. Existing source differs only in exposing the module and adding the new
entry module; 146 other original files and production are unchanged. Four
malformed reconstruction inputs are rejected. The independent audit accepts an
analytic two-part layout, also validated by the public CLI, and rejects five
invalid membership, geometry, boundary or orientation cases.

After committing the plan, run four serial searches on physical CCD0 CPU 8,
seed zero, with at most six ten-second rounds each: saved positions first, then
up to five full random restarts. Stop at the first separator-clear snapshot.
Every round and failure is retained; this diagnostic does not change the short
repair budget in production or claim a quality improvement. Packaging/checks
run on CCD1. Each final snapshot is independently checked against the unchanged
shortened collision boundary and original filled outer rings, kerf, quantities,
orientations and full-stock public validation.

A verified layout proves that particular fixed assignment can fit. Failure of
this finite search proves neither infeasibility nor a need to relax H5. Any
future repair change still requires its own qualification and unchanged matched
quality gates. H2/H5 remain open at 60%; no reserved input is opened.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-assignment-repack-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-18 — Prepare fixed-assignment feasibility repacking

[The isolated reconstruction and repack entry](benchmarks/results/h5-assignment-repack-preparation-20261018.md)
passes 90 optimized tests, strict lint, build and exact restoration of all four
selected saved assignments. Every container and collision polygon matches the
original f32 coordinates, with the same parts and orientations. Four malformed
restorations and five invalid independent-audit cases are rejected; the authored
positive audit also passes the public CLI. Production remains unchanged.

The planned four serial CPU8 searches use the first saved attempt of each
mechanical job/kerf, seed zero, at most six ten-second rounds, with every outcome
retained. A separately verified packing would prove source-assignment feasibility;
failure does not prove impossibility. No quality claim, original-budget change,
reserved-input access or H5 credit. H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':archive.stat().st_size}))
