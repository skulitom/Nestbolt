"""Read the failed conservative repair and certify its exact negative cycle."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained49-guard-repair-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
result=load(BASE/'result.json');assert not result['feasible'] and result['closed'] and result['feasibility_calls']==1 and not (BASE/'corrected49-source.json').exists()
rows=load(BASE/'retained-originals.json');movers=load(BASE/'mandatory-movers.json');original=load(ROOT/'output/h5-retained64-proxy-regions-20261026/construction/all66-source-candidate.json')
key=lambda r:(r['part_id'],r['copy_index']);assert len(rows)==49 and len(movers)==17 and sorted(rows+movers,key=key)==sorted(original,key=key)
assert sum(r['part_id']=='cog' for r in movers)==15 and sorted(key(r) for r in movers if r['part_id']=='bracket')==[('bracket',2),('bracket',5)]
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
source=audit(job,rows,load(BASE/'stocks.json'),required,guard,[key(r) for r in rows]);assert not source['valid'];write(OUT/'retained49-original-source-failures.json',source)
edges=load(BASE/'difference-constraints.json');n=99;dist=[0]*n;pred=[None]*n;last=None
for _ in range(n):
    last=None
    for ei,e in enumerate(edges):
        assert 0<=e['from']<n and 0<=e['to']<n and isinstance(e['weight'],int)
        if dist[e['to']]>dist[e['from']]+e['weight']:dist[e['to']]=dist[e['from']]+e['weight'];pred[e['to']]=ei;last=e['to']
assert last is not None
v=last
for _ in range(n):assert pred[v] is not None;v=edges[pred[v]]['from']
first=v;cycle=[]
while True:
    ei=pred[v];cycle.append(ei);v=edges[ei]['from']
    if v==first:break
    assert len(cycle)<=n
cycle.reverse();assert all(edges[a]['to']==edges[b]['from'] for a,b in zip(cycle,cycle[1:]+cycle[:1]));weight=sum(edges[i]['weight'] for i in cycle);assert weight<0
involved=sorted({v//2 for i in cycle for v in [edges[i]['from'],edges[i]['to']] if v!=98});geometry=load(BASE/'geometry.json')
certificate={'edge_indices':cycle,'edges':[edges[i] for i in cycle],'sum_of_weights_um':weight,'original_keys':[geometry[i]['key'] for i in involved],
    'scope':'The particular225um outward rectangle spacing and plus/minus50um fixed-axis repair model is inconsistent. This is a sufficient construction model, not a necessary source model; its negative cycle does not prove source repair impossible.'}
write(OUT/'negative-cycle.json',certificate)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'retained_originals':49,'mandatory_movers_preserved':17,'initial_source_pair_failures':source['pair_failures'],'initial_source_stock_failures':source['stock_failures'],
    'initial_same_sheet_pairs':source['same_sheet_pairs'],'initial_stock_edges':source['stock_edges'],'initial_holes':source['cutouts'],'initial_hole_vertices':source['hole_vertices'],
    'negative_cycle_edges':len(cycle),'cycle_weight_um':weight,'involved_originals':certificate['original_keys'],'conservative_repair_model_excluded':True,'source_repair_excluded':False,
    'corrected49_candidate_exists':False,'closed_original_feasibility_calls':1,'audit_constructs_cycle_not_new_repair_candidate':True,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'));print(certificate)
