"""One exact integer difference-constraint repair of the retained49 non-cog poses."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import copy,json,math,shutil,time
from shapely.geometry import Polygon,Point,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-retained49-guard-repair-20261026';SOURCE=ROOT/'output/h5-retained64-proxy-regions-20261026/construction'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'repair.py');started=time.perf_counter();gap=225;maximum=50;guard=3000*32*2**-23
stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,SOURCE/'all66-source-candidate.json',SOURCE/'copy-bijection.json']},'maximum_axis_translation_um':maximum,'component_gap_um':gap,'maximum_feasibility_calls':1,'retry_permitted':False,
    'method':'Keep the49 non-cog originals other than the two added bracket copies as a future retained subset; the15 cogs and2 brackets remain explicitly mandatory movers, not deleted from the job. Decompose each fixed-orientation filled outer into axis-aligned cells and enclose them by outward integer micrometre rectangles. Require225um gaps on the current maximum separating axis for component pairs that could become close under plus/minus50um translations. Far pairs are safe for every bounded translation. Require conservative integer stock bounds including the native guard. Solve all difference constraints once with exact integer Bellman-Ford; no iterations, optimizer seeds or budget extension. Preserve all old source failures. Apply only integer translations to the existing source transforms, keeping orientation, sheet and copy identity. A separate original-ring reader must verify every retained source pair/stock edge and all hole geometry. This is49-part preparation, not a66-part witness; all changed forbidden geometry must be rebuilt for the subsequent mandatory17-mover construction.'})
allrows=load(SOURCE/'all66-source-candidate.json');bijection=load(SOURCE/'copy-bijection.json');missing={('bracket',p['to_copy_index']) for p in bijection if p['family']=='bracket' and p['from_copy_index'] in [10,11]};assert missing=={('bracket',2),('bracket',5)}
rows=[p for p in allrows if p['part_id']!='cog' and (p['part_id'],p['copy_index']) not in missing];movers=[p for p in allrows if p not in rows];assert len(rows)==49 and len(movers)==17
job=load(JOB);parts={p['id']:p for p in job['parts']};geometry=[];boxes=[];bounds=[]
for i,row in enumerate(rows):
    t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    outer=[(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[row['part_id']]['geometry'][0]['outer']];poly=Polygon(outer);assert poly.is_valid
    xs=sorted(set(round(x,8) for x,y in outer));ys=sorted(set(round(y,8) for x,y in outer));assert len(xs)<=3 and len(ys)<=3
    rects=[]
    for x,xx in zip(xs,xs[1:]):
        for y,yy in zip(ys,ys[1:]):
            if poly.contains(Point((x+xx)/2,(y+yy)/2)):
                b=[math.floor((x-1e-7)*1000),math.floor((y-1e-7)*1000),math.ceil((xx+1e-7)*1000),math.ceil((yy+1e-7)*1000)];rects.append(b)
    cover=unary_union([box(*(v/1000 for v in b)) for b in rects]);assert cover.covers(poly) and cover.area-poly.area<poly.length*.0021
    b=[min(r[0] for r in rects),min(r[1] for r in rects),max(r[2] for r in rects),max(r[3] for r in rects)];stock=stocks[row['sheet_id']]
    allowed=[max(-maximum,math.ceil((stock[0]+guard)*1000)+1-b[0]),max(-maximum,math.ceil((stock[1]+guard)*1000)+1-b[1]),
        min(maximum,math.floor((stock[2]-guard)*1000)-1-b[2]),min(maximum,math.floor((stock[3]-guard)*1000)-1-b[3])]
    assert allowed[0]<=allowed[2] and allowed[1]<=allowed[3]
    geometry.append({'index':i,'key':[row['part_id'],row['copy_index']],'sheet':row['sheet_id'],'outer_vertices_mm':outer,'source_cover_rectangles_um':rects,'full_bounds_um':b,'shift_bounds_um':allowed});bounds.append(allowed)
    boxes.extend({'owner':i,'component':k,'sheet':row['sheet_id'],'bounds_um':b} for k,b in enumerate(rects))
zero=2*len(rows);edges=[]
def edge(u,v,w,reason):edges.append({'from':u,'to':v,'weight':w,'reason':reason})
for i,b in enumerate(bounds):
    for axis in [0,1]:edge(zero,2*i+axis,b[axis+2],['upper',i,axis]);edge(2*i+axis,zero,-b[axis],['lower',i,axis])
near=[];far=0
for ai,bi in combinations(range(len(boxes)),2):
    a,b=boxes[ai],boxes[bi]
    if a['owner']==b['owner'] or a['sheet']!=b['sheet']:continue
    aa,bb=a['bounds_um'],b['bounds_um'];gaps=[bb[0]-aa[2],aa[0]-bb[2],bb[1]-aa[3],aa[1]-bb[3]];axis=max(range(4),key=lambda k:gaps[k]);g=gaps[axis];assert g>=0,(a,b,gaps)
    if g>=gap+2*maximum:far+=1;continue
    direction=axis//2;before,after=(a['owner'],b['owner']) if axis%2==0 else (b['owner'],a['owner'])
    ix=len(edges);edge(2*after+direction,2*before+direction,g-gap,['pair',ai,bi,axis]);near.append({'components':[ai,bi],'selected_gap_axis':axis,'old_gap_um':g,'constraint':ix})
write(OUT/'geometry.json',geometry);write(OUT/'component-rectangles.json',boxes);write(OUT/'difference-constraints.json',edges);write(OUT/'near-pairs.json',near)
write(OUT/'retained-originals.json',rows);write(OUT/'mandatory-movers.json',movers);write(OUT/'stocks.json',stocks)
dist=[0]*(zero+1);passes=0;updates=0;changed=None
for iteration in range(zero+1):
    changed=None;passes+=1
    for ei,e in enumerate(edges):
        v=dist[e['from']]+e['weight']
        if dist[e['to']]>v:dist[e['to']]=v;changed=ei;updates+=1
    if changed is None:break
feasible=changed is None;result={'seconds':time.perf_counter()-started,'feasible':feasible,'closed':True,'feasibility_calls':1,'passes':passes,'integer_relaxations':updates,'variables':zero,'constraints':len(edges),'near_component_pairs':len(near),'universally_safe_far_component_pairs':far,'retained_originals':49,'mandatory_movers':17,'full66_witness':False,'native_calls':0,'H5_complete':False}
if feasible:
    shifts=[d-dist[zero] for d in dist[:-1]];corrected=copy.deepcopy(rows)
    for i,row in enumerate(corrected):row['transform']['translation']=[rows[i]['transform']['translation'][a]+shifts[2*i+a]/1000 for a in [0,1]]
    assert all(-maximum<=v<=maximum for v in shifts);values=shifts+[0];assert all(values[e['to']]<=values[e['from']]+e['weight'] for e in edges)
    write(OUT/'shift-assignment.json',shifts);write(OUT/'corrected49-source.json',corrected);result.update({'moved_originals':sum(bool(shifts[2*i] or shifts[2*i+1]) for i in range(len(rows))),'maximum_axis_shift_um':max(map(abs,shifts))})
write(OUT/'result.json',result);print(result)
