"""Use the diagnosed stack deficit to construct a bounded source-guard repair."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import copy,json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-retained49-guard-repair-20261026';OUT=ROOT/'output/h5-retained49-stack-repair-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(OLD/'audit/checks.json')['passed'];cycle=load(OLD/'audit/negative-cycle.json');assert cycle['sum_of_weights_um']==-29
OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter()
paths=[OLD/n for n in ['plan.json','geometry.json','component-rectangles.json','difference-constraints.json','retained-originals.json','mandatory-movers.json','stocks.json','audit/checks.json','audit/negative-cycle.json']]
limit=50-cycle['sum_of_weights_um'];assert limit==79
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_feasibility_calls':1,'retry_permitted':False,'component_gap_um':225,
    'method':'The preserved failed225um construction has an exact -29um cycle: insert0 needs13um upward stock correction and the seven-insert chain requires insert6 to move at least79um. Build a different bounded repair allowing only those seven inserts upperY shifts of79um, derived from the certificate; all other coordinate bounds, orientations, sheets and source identities stay as before. Recalculate every component-pair bound for the changed per-coordinate ranges, so no old far-pair exclusion is reused unsafely. One exact integer difference-constraint construction; no random search, threshold relaxation or time-budget extension. Independently read all49 original source rings after applying translations. All17 omitted originals remain explicitly mandatory movers for later work.'})
geometry=load(OLD/'geometry.json');rows=load(OLD/'retained-originals.json');boxes=load(OLD/'component-rectangles.json');stocks=load(OLD/'stocks.json');guard=3000*32*2**-23;wanted={tuple(k) for k in cycle['original_keys']};bounds=[]
assert wanted=={('insert',i) for i in range(7)}
for p in geometry:
    b=p['shift_bounds_um'].copy()
    if tuple(p['key']) in wanted:b[3]=min(limit,math.floor((stocks[p['sheet']][3]-guard)*1000)-1-p['full_bounds_um'][3])
    bounds.append(b)
zero=98;edges=[];near=[];far=[]
def edge(u,v,w,reason):edges.append({'from':u,'to':v,'weight':w,'reason':reason})
for i,b in enumerate(bounds):
    for a in [0,1]:edge(zero,2*i+a,b[a+2],['upper',i,a]);edge(2*i+a,zero,-b[a],['lower',i,a])
for ai,bi in combinations(range(len(boxes)),2):
    a,b=boxes[ai],boxes[bi]
    if a['owner']==b['owner'] or a['sheet']!=b['sheet']:continue
    aa,bb=a['bounds_um'],b['bounds_um'];gaps=[bb[0]-aa[2],aa[0]-bb[2],bb[1]-aa[3],aa[1]-bb[3]];axis=max(range(4),key=lambda k:gaps[k]);g=gaps[axis];dim=axis//2
    before,after=(a['owner'],b['owner']) if axis%2==0 else (b['owner'],a['owner']);worst=g+bounds[after][dim]-bounds[before][dim+2]
    if worst>=225:far.append({'components':[ai,bi],'gap_axis':axis,'worst_gap_um':worst});continue
    ix=len(edges);edge(2*after+dim,2*before+dim,g-225,['pair',ai,bi,axis]);near.append({'components':[ai,bi],'gap_axis':axis,'constraint':ix})
write(OUT/'shift-bounds.json',bounds);write(OUT/'difference-constraints.json',edges);write(OUT/'near-pairs.json',near);write(OUT/'far-pairs.json',far)
dist=[0]*99;passes=updates=0;changed=None
for _ in range(99):
    changed=None;passes+=1
    for ei,e in enumerate(edges):
        if dist[e['to']]>dist[e['from']]+e['weight']:dist[e['to']]=dist[e['from']]+e['weight'];changed=ei;updates+=1
    if changed is None:break
result={'seconds':time.perf_counter()-start,'feasible':changed is None,'closed':True,'feasibility_calls':1,'passes':passes,'integer_relaxations':updates,'variables':98,'constraints':len(edges),'retained_originals':49,'mandatory_movers':17,'full66_witness':False,'native_calls':0,'H5_complete':False}
if changed is None:
    shifts=[v-dist[zero] for v in dist[:-1]];values=shifts+[0];assert all(values[e['to']]<=values[e['from']]+e['weight'] for e in edges)
    corrected=copy.deepcopy(rows)
    for i,p in enumerate(corrected):p['transform']['translation']=[rows[i]['transform']['translation'][a]+shifts[2*i+a]/1000 for a in [0,1]]
    write(OUT/'shift-assignment.json',shifts);write(OUT/'corrected49-source.json',corrected);write(OUT/'mandatory17-movers.json',load(OLD/'mandatory-movers.json'))
    result.update({'moved_originals':sum(bool(shifts[2*i] or shifts[2*i+1]) for i in range(49)),'maximum_absolute_axis_shift_um':max(map(abs,shifts))})
write(OUT/'result.json',result);print(result)
