"""Verify exact shifts and every original source ring of the retained49 repair."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained49-stack-repair-20261026';OLD=ROOT/'output/h5-retained49-guard-repair-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [OLD,BASE]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
result=load(BASE/'result.json');assert result['feasible'] and result['closed'] and result['feasibility_calls']==1
before=load(OLD/'retained-originals.json');after=load(BASE/'corrected49-source.json');movers=load(BASE/'mandatory17-movers.json');assert movers==load(OLD/'mandatory-movers.json') and len(after)==49 and len(movers)==17
key=lambda p:(p['part_id'],p['copy_index']);assert [key(p) for p in before]==[key(p) for p in after]
shifts=load(BASE/'shift-assignment.json');bounds=load(BASE/'shift-bounds.json');assert len(shifts)==98 and all(isinstance(v,int) for v in shifts)
geometry=load(OLD/'geometry.json');stocks=load(OLD/'stocks.json');guard=3000*32*2**-23;job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
assert sorted(key(p) for p in after+movers)==sorted((p['id'],i) for p in job['parts'] for i in range(p['quantity']))
for i,(a,b,g,limit) in enumerate(zip(before,after,geometry,bounds)):
    assert a['sheet_id']==b['sheet_id'] and a['transform']['rotation_radians']==b['transform']['rotation_radians'] and a['transform']['mirrored']==b['transform']['mirrored']
    expected=g['shift_bounds_um'].copy()
    if key(a) in {('insert',k) for k in range(7)}:expected[3]=min(79,math.floor((stocks[a['sheet_id']][3]-guard)*1000)-1-g['full_bounds_um'][3])
    assert limit==expected
    for axis in [0,1]:assert limit[axis]<=shifts[2*i+axis]<=limit[axis+2] and b['transform']['translation'][axis]==a['transform']['translation'][axis]+shifts[2*i+axis]/1000
    t=a['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];outer=parts[a['part_id']]['geometry'][0]['outer']
    polygon=Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in outer]);cover=unary_union([box(*(v/1000 for v in r)) for r in g['source_cover_rectangles_um']]);assert cover.covers(polygon)
edges=load(BASE/'difference-constraints.json');values=shifts+[0];assert all(values[e['to']]<=values[e['from']]+e['weight'] for e in edges)
ei=0
for i,b in enumerate(bounds):
    for a in [0,1]:
        assert edges[ei]=={'from':98,'to':2*i+a,'weight':b[a+2],'reason':['upper',i,a]};ei+=1
        assert edges[ei]=={'from':2*i+a,'to':98,'weight':-b[a],'reason':['lower',i,a]};ei+=1
boxes=load(OLD/'component-rectangles.json');near=load(BASE/'near-pairs.json');far=load(BASE/'far-pairs.json');ni=fi=0
for ai,bi in combinations(range(len(boxes)),2):
    a,b=boxes[ai],boxes[bi]
    if a['owner']==b['owner'] or a['sheet']!=b['sheet']:continue
    aa,bb=a['bounds_um'],b['bounds_um'];gaps=[bb[0]-aa[2],aa[0]-bb[2],bb[1]-aa[3],aa[1]-bb[3]];axis=max(range(4),key=lambda k:gaps[k]);dim=axis//2
    first,second=(a['owner'],b['owner']) if axis%2==0 else (b['owner'],a['owner']);worst=gaps[axis]+bounds[second][dim]-bounds[first][dim+2]
    if worst>=225:assert far[fi]=={'components':[ai,bi],'gap_axis':axis,'worst_gap_um':worst};fi+=1
    else:
        assert near[ni]=={'components':[ai,bi],'gap_axis':axis,'constraint':ei};ni+=1
        assert edges[ei]=={'from':2*second+dim,'to':2*first+dim,'weight':gaps[axis]-225,'reason':['pair',ai,bi,axis]};ei+=1
assert (ei,ni,fi)==(len(edges),len(near),len(far))
required=(job['clearance']+guard)/math.cos(.05);readback=audit(job,after,stocks,required,guard,[key(p) for p in before]);assert readback['valid'];write(OUT/'corrected49-source-readback.json',readback)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'retained_source_originals_verified':49,'mandatory_movers_preserved':17,'source_identities_orientations_sheets_unchanged':True,'integer_shift_values_verified':98,'difference_constraints_verified':ei,
    'near_component_pairs_verified':ni,'far_component_pairs_verified_for_changed_ranges':fi,'source_pairs_verified':readback['same_sheet_pairs'],'source_stock_edges_verified':readback['stock_edges'],'source_cutouts_preserved':readback['cutouts'],'source_hole_vertices_preserved':readback['hole_vertices'],
    'source_pair_failures':0,'source_stock_failures':0,'minimum_source_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'required_source_gap_mm':required,'required_extra_stock_mm':guard,
    'maximum_absolute_axis_shift_um':max(map(abs,shifts)),'moved_originals':sum(bool(shifts[2*i] or shifts[2*i+1]) for i in range(49)),'only_seven_inserts_can_exceed50um_in_positiveY':True,
    'old_fixed51_capacity_certificate_not_transferred':True,'full66_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
