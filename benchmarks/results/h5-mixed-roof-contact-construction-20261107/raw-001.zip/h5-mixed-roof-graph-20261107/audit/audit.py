from pathlib import Path
from hashlib import sha256
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-graph-20261107';CONTACTS=ROOT/'output/h5-mixed-roof-contacts-20261107';SOURCE=ROOT/'output/h5-mixed-roof-source-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');checked=load(CONTACTS/'audit/checks.json');assert checked['passed'];pool=load(CONTACTS/'candidates.json');data=load(SOURCE/'source-geometry.json');parts={p['id']:p for p in load(JOB)['parts']};saved=np.load(BASE/'edges.npy',allow_pickle=False);mapping=load(BASE/'mapping.json');assert saved.dtype==np.dtype('int32') and saved.shape[1]==2
polygons=[]
for row in pool:
    pose=row['transform'];c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];polygons.append(Polygon([(tx+c*m*x-s*y,ty+s*m*x+c*y) for x,y in parts[row['family']]['geometry'][0]['outer']]))
gs=np.asarray(polygons,dtype=object);cursor=0;pairs=0
for i in range(len(gs)):
    # Independent row enumeration, including every nonconflicting pair.
    others=np.arange(i+1,len(gs));ds=shapely.distance(gs[i],gs[others]);js=others[ds<data['required_pair_gap_mm']];rows=np.column_stack([np.full(len(js),i),js]);assert np.array_equal(rows,saved[cursor:cursor+len(js)]);cursor+=len(js);pairs+=len(others)
assert cursor==len(saved) and pairs==2096128
expected_links=[[i,j] for i,row in enumerate(pool) for j in row['conflicting_cog_sites']];assert expected_links==load(BASE/'pose-cog-conflicts.json')
assert mapping=={'candidate_count':2048,'cog_sites':17,'original_quantities':{'bracket':6,'insert':12,'cog':15},'family_indices':{family:[i for i,r in enumerate(pool) if r['family']==family] for family in ['bracket','insert']},'fixed_originals':33}
process=load(ROOT/'output/h5-mixed-roof-graph-preparation-process-20261107/process.json');assert process['closed'] and process['passed'];charge=checked['complete_preparation_seconds']+process['complete_seconds']
inputs=[Path(__file__),JOB,CONTACTS/'candidates.json',CONTACTS/'audit/checks.json',SOURCE/'source-geometry.json',BASE/'plan.json',BASE/'edges.npy',BASE/'mapping.json',BASE/'pose-cog-conflicts.json',ROOT/'output/h5-mixed-roof-graph-preparation-process-20261107/process.json'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent original-vertex transform and per-row enumeration of every unordered candidate pair, with no geometric pruning; exact agreement of full conflict-edge array and all pose/site implications and original quantities.'})
result={'passed':True,'seconds':time.perf_counter()-start,'original_candidates_verified':len(gs),'all_pairs_verified':pairs,'conflict_edges_verified':len(saved),'pose_cog_implications_verified':len(expected_links),'whole_original_counts':[18,12,21,15],'missing_original_counts':[6,12,15],'complete_preparation_seconds':charge,'edges_sha256':digest(BASE/'edges.npy'),'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
