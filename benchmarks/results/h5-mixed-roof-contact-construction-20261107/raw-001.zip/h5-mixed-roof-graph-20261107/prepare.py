"""Complete actual-outline conflict graph for the finite contact pool."""
from pathlib import Path
from hashlib import sha256
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-contacts-20261107';SOURCE=ROOT/'output/h5-mixed-roof-source-20261107';OUT=ROOT/'output/h5-mixed-roof-graph-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');checked=load(BASE/'audit/checks.json');assert checked['passed'] and checked['candidate_sha256']==digest(BASE/'candidates.json');pool=load(BASE/'candidates.json');data=load(SOURCE/'source-geometry.json');parts={p['id']:p for p in load(JOB)['parts']};inputs=[Path(__file__),JOB,BASE/'plan.json',BASE/'candidates.json',BASE/'audit/checks.json',SOURCE/'source-geometry.json',SOURCE/'audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'All2048 original-outline candidates and every unordered pair, exact required clearance comparator without candidate thinning or bbox rejection. Save sorted complete conflicting pairs as int32 NPY, and every pose-to-cog-site implication. No optimization.','complete_reused_preparation_seconds':checked['complete_preparation_seconds'],'process_cap_seconds':15,'memory_bytes':2**31,'source_optimizer_calls':0,'retry_permitted':False})
polygons=[]
for row in pool:
    pose=row['transform'];c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];polygons.append(Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[row['family']]['geometry'][0]['outer']]))
polygons=np.asarray(polygons,dtype=object);left,right=np.triu_indices(len(pool),1);distance=shapely.distance(polygons[left],polygons[right]);take=distance<data['required_pair_gap_mm'];edges=np.column_stack([left[take],right[take]]).astype(np.int32);np.save(OUT/'edges.npy',edges,allow_pickle=False);links=[[i,j] for i,row in enumerate(pool) for j in row['conflicting_cog_sites']];write(OUT/'pose-cog-conflicts.json',links);write(OUT/'mapping.json',{'candidate_count':len(pool),'cog_sites':17,'original_quantities':{'bracket':6,'insert':12,'cog':15},'family_indices':{family:[i for i,r in enumerate(pool) if r['family']==family] for family in ['bracket','insert']},'fixed_originals':33})
result={'prepared':True,'seconds':time.perf_counter()-start,'candidates':len(pool),'all_unordered_pairs_checked':len(left),'conflict_edges':len(edges),'pose_cog_conflicts':len(links),'required_gap_mm':data['required_pair_gap_mm'],'edges_sha256':digest(OUT/'edges.npy'),'complete_reused_preparation_seconds':checked['complete_preparation_seconds'],'model_prepared':False,'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
