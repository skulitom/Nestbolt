"""One finite contact pool over the 136 choices of two unused cog sites."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,product
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box
from shapely.affinity import translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-source-20261107';OUT=ROOT/'output/h5-mixed-roof-contacts-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def components(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [v for child in g.geoms for v in components(child)]
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');data=load(BASE/'source-geometry.json');checked=load(BASE/'audit/checks.json');assert checked['passed'] and checked['source_geometry_sha256']==digest(BASE/'source-geometry.json');parts={p['id']:p for p in load(JOB)['parts']};partitions=load(Q/'partitions.json');assert load(Q/'audit/checks.json')['passed'];safe=data['safe_stock_mm'];gap=.23;cases=list(combinations(range(17),2));modes=[]
inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','source-geometry.json','audit/checks.json']]+[Q/n for n in ['plan.json','partitions.json','audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'Finite candidate construction only. For each of136 omitted-cog pairs and all8 bracket/2 physically distinct insert modes, subtract source convex-piece Minkowski exclusions for the18 fixed frames and15 selected cog sites. Expand every exclusion with a0.23mm square. Include each free polygon representative point and every exterior/interior vertex. Round candidate centers once to1e-6mm; validate actual original outlines against stock,allframes,andall17cogs. Admit only candidates conflicting with at most2cogsites. Select at most1024 candidates perfamily by round-robin over case/mode contexts, each context representative points first then vertices byY/X; deduplicate exact rounded family/mode/center keys. No region-completeness or infeasibility claim. No placement optimizer or iterative reseed.','complete_reused_preparation_seconds':checked['complete_preparation_seconds'],'source_partition_lineage_included_in_reused_charge':True,'case_count':136,'family_candidate_caps':{'bracket':1024,'insert':1024},'process_cap_seconds':25,'internal_cap_seconds':22,'memory_bytes':2**31,'source_optimizer_calls':0,'retry_permitted':False})
def placed_polygon(family,pose):
    c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']])
frames=[placed_polygon('frame',r['transform']) for r in data['fixed_source_rows'] if r['part_id']=='frame'];cogs=[placed_polygon('cog',r['transform']) for r in data['cog_pool']];frame_vertices=[list(p.exterior.coords)[:-1] for p in frames];theta=data['cog_phase_radians'];c,s=math.cos(theta),math.sin(theta);px,py=data['source_center'];cog_local=[[(c*(x-px)-s*(y-py),s*(x-px)+c*(y-py)) for x,y in piece] for piece in partitions['cog']['pieces']]
contexts=[];all_candidates={};rejected=[];regions=[]
for family in ['bracket','insert']:
    center=data['families'][family]['source_center'];family_modes=[]
    for mirror,quarter in product([False,True] if family=='bracket' else [False],range(4) if family=='bracket' else range(2)):
        def local(point):
            x,y=point[0]-center[0],point[1]-center[1]
            if mirror:x=-x
            for _ in range(quarter):x,y=-y,x
            return [x,y]
        local_outer=[local(v) for v in parts[family]['geometry'][0]['outer']];local_pieces=[[local(v) for v in piece] for piece in partitions[family]['pieces']];xs=[p[0] for p in local_outer];ys=[p[1] for p in local_outer];bounds=[safe[0]-min(xs),safe[1]-min(ys),safe[2]-max(xs),safe[3]-max(ys)];forbidden=[]
        for fixed,piece in product(frame_vertices,local_pieces):forbidden.append(MultiPoint([(a[0]-b[0]+dx,a[1]-b[1]+dy) for a,b,(dx,dy) in product(fixed,piece,product([-gap,gap],repeat=2))]).convex_hull)
        frame_free=box(*bounds).difference(unary_union(forbidden));cog_forbidden=unary_union([MultiPoint([(a[0]-b[0]+dx,a[1]-b[1]+dy) for a,b,(dx,dy) in product(fixed,piece,product([-gap,gap],repeat=2))]).convex_hull for fixed,piece in product(cog_local,local_pieces)]);site_forbidden=[translate(cog_forbidden,*site['center']) for site in data['cog_pool']];mi=len(family_modes);family_modes.append({'mode':mi,'quarter':quarter,'mirrored':mirror,'rotation_radians':quarter*math.pi/2,'local_outer':local_outer,'local_pieces':local_pieces,'center_stock_bounds':bounds});modes.append({'family':family,**family_modes[-1]})
        for omitted in cases:
            free=frame_free.difference(unary_union([p for i,p in enumerate(site_forbidden) if i not in omitted]));polygons=components(free);assert free.is_valid;representatives=[];vertices=[]
            for p in polygons:
                representatives.append(tuple(p.representative_point().coords[0]));vertices.extend(p.exterior.coords[:-1])
                for ring in p.interiors:vertices.extend(ring.coords[:-1])
            points=[];seen=set()
            for p in sorted(representatives,key=lambda v:(v[1],v[0]))+sorted(vertices,key=lambda v:(v[1],v[0])):
                xy=tuple(round(float(v),6) for v in p)
                if xy not in seen:points.append(xy);seen.add(xy)
            context={'family':family,'mode':mi,'omitted_sites':list(omitted),'candidate_keys':[],'free_center_area_mm2':free.area,'components':len(polygons)};ci=len(contexts)
            regions.append({'context':ci,'geometry':shapely.geometry.mapping(free)})
            for x,y in points:
                key=(family,mi,x,y);label='|'.join(map(str,key));context['candidate_keys'].append(label)
                if label in all_candidates:continue
                angle=quarter*math.pi/2;c,s=math.cos(angle),math.sin(angle);m=-1 if mirror else 1;px,py=center;pose={'rotation_radians':angle,'mirrored':mirror,'translation':[x-(m*px*c-py*s),y-(m*px*s+py*c)]};poly=placed_polygon(family,pose);x0,y0,x1,y1=poly.bounds;stock_ok=x0>=safe[0]-1e-9 and y0>=safe[1]-1e-9 and x1<=safe[2]+1e-9 and y1<=safe[3]+1e-9;fd=shapely.distance(poly,np.asarray(frames,dtype=object));cd=shapely.distance(poly,np.asarray(cogs,dtype=object));mask=[i for i,d in enumerate(cd) if d<data['required_pair_gap_mm']];valid=stock_ok and bool(np.all(fd>=data['required_pair_gap_mm'])) and len(mask)<=2
                candidate={'key':label,'family':family,'mode':mi,'center':[x,y],'transform':pose,'first_context':ci,'stock_passed':stock_ok,'minimum_frame_distance_mm':float(np.min(fd)),'cog_distances_mm':list(map(float,cd)),'conflicting_cog_sites':mask,'admitted':valid};all_candidates[label]=candidate
                if not valid:rejected.append(label)
            contexts.append(context)
            assert time.perf_counter()-start<22
selected=[];selection=[]
for family in ['bracket','insert']:
    family_contexts=[(i,r) for i,r in enumerate(contexts) if r['family']==family];offset=0;seen=set();done=False
    while len(seen)<1024 and not done:
        done=True
        for ci,context in family_contexts:
            if offset>=len(context['candidate_keys']):continue
            done=False;key=context['candidate_keys'][offset]
            if key in seen or not all_candidates[key]['admitted']:continue
            seen.add(key);selected.append(all_candidates[key]);selection.append({'candidate':len(selected)-1,'key':key,'context':ci,'offset':offset})
            if len(seen)==1024:break
        offset+=1
write(OUT/'modes.json',modes);write(OUT/'contexts.json',contexts);write(OUT/'free-regions.json',regions);write(OUT/'all-candidates.json',list(all_candidates.values()));write(OUT/'candidates.json',selected);write(OUT/'selection.json',selection)
checks={'prepared':True,'seconds':time.perf_counter()-start,'contexts':len(contexts),'mode_count':len(modes),'omission_pairs':len(cases),'empty_contexts':sum(c['components']==0 for c in contexts),'unique_candidate_points':len(all_candidates),'source_rejected_candidates':len(rejected),'selected_brackets':sum(r['family']=='bracket' for r in selected),'selected_inserts':sum(r['family']=='insert' for r in selected),'selected_total':len(selected),'candidates_with_zero_cog_conflicts':sum(not r['conflicting_cog_sites'] for r in selected),'candidates_with_one_cog_conflict':sum(len(r['conflicting_cog_sites'])==1 for r in selected),'candidates_with_two_cog_conflicts':sum(len(r['conflicting_cog_sites'])==2 for r in selected),'consumed_preparation_seconds':checked['complete_preparation_seconds'],'source_optimizer_calls':0,'complete_model_prepared':False,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
