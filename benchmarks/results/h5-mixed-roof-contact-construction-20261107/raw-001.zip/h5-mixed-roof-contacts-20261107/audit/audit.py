"""Read back every finite contact, original outline, mask and deterministic cap."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-contacts-20261107';SOURCE=ROOT/'output/h5-mixed-roof-source-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');data=load(SOURCE/'source-geometry.json');parts={p['id']:p for p in load(JOB)['parts']};contexts=load(BASE/'contexts.json');regions=load(BASE/'free-regions.json');modes=load(BASE/'modes.json');pool=load(BASE/'all-candidates.json');index={r['key']:r for r in pool};selected=load(BASE/'candidates.json');selection=load(BASE/'selection.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
assert len(index)==len(pool)==4445 and len(contexts)==len(regions)==1360 and len(modes)==10
def polygon(family,pose):
    c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];return Polygon([(tx+c*m*x-s*y,ty+s*m*x+c*y) for x,y in parts[family]['geometry'][0]['outer']])
frames=np.asarray([polygon('frame',r['transform']) for r in data['fixed_source_rows'] if r['part_id']=='frame'],dtype=object);cogs=np.asarray([polygon('cog',r['transform']) for r in data['cog_pool']],dtype=object);safe=data['safe_stock_mm'];checked_pairs=0;observed=set()
for i,(context,region) in enumerate(zip(contexts,regions)):
    assert region['context']==i and len(context['omitted_sites'])==2 and context['omitted_sites']==sorted(set(context['omitted_sites'])) and all(0<=x<17 for x in context['omitted_sites'])
    key=(context['family'],context['mode'],tuple(context['omitted_sites']));assert key not in observed;observed.add(key)
    free=shape(region['geometry']);assert free.is_valid and abs(free.area-context['free_center_area_mm2'])<1e-7
    def pieces(g):
        if g.is_empty:return []
        if g.geom_type=='Polygon':return [g]
        return [p for child in g.geoms for p in pieces(child)]
    pp=pieces(free);assert len(pp)==context['components'];representatives=[];vertices=[]
    for p in pp:
        representatives.append(tuple(p.representative_point().coords[0]));vertices+=list(p.exterior.coords[:-1])
        for ring in p.interiors:vertices+=list(ring.coords[:-1])
    keys=[];seen=set()
    for xy in sorted(representatives,key=lambda p:(p[1],p[0]))+sorted(vertices,key=lambda p:(p[1],p[0])):
        point=tuple(round(float(x),6) for x in xy)
        if point in seen:continue
        seen.add(point);key='|'.join(map(str,(context['family'],context['mode'],*point)));keys.append(key);assert key in index
    assert keys==context['candidate_keys']
assert observed=={(family,mode,pair) for family,n in [('bracket',8),('insert',2)] for mode in range(n) for pair in combinations(range(17),2)}
max_error=0.;masks={}
for row in pool:
    family=row['family'];mode=next(m for m in modes if m['family']==family and m['mode']==row['mode']);pose=row['transform'];assert pose['mirrored']==mode['mirrored'] and pose['rotation_radians']==mode['rotation_radians'] and mode['quarter']*math.pi/2==pose['rotation_radians'];px,py=data['families'][family]['source_center'];c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;center=[pose['translation'][0]+c*m*px-s*py,pose['translation'][1]+s*m*px+c*py];assert max(abs(a-b) for a,b in zip(center,row['center']))<1e-9
    p=polygon(family,pose);x0,y0,x1,y1=p.bounds;stock=x0>=safe[0]-1e-9 and y0>=safe[1]-1e-9 and x1<=safe[2]+1e-9 and y1<=safe[3]+1e-9;fd=shapely.distance(p,frames);cd=shapely.distance(p,cogs);mask=[i for i,d in enumerate(cd) if d<data['required_pair_gap_mm']];valid=stock and min(fd)>=data['required_pair_gap_mm'] and len(mask)<=2
    assert stock==row['stock_passed'] and valid==row['admitted'] and mask==row['conflicting_cog_sites'];max_error=max(max_error,abs(float(min(fd))-row['minimum_frame_distance_mm']),max(abs(float(a)-b) for a,b in zip(cd,row['cog_distances_mm'])));assert max_error<1e-8;checked_pairs+=35;masks[row['key']]=mask
reselected=[];reselection=[]
for family in ['bracket','insert']:
    seen=set();offset=0;done=False
    while len(seen)<1024 and not done:
        done=True
        for ci,context in enumerate(contexts):
            if context['family']!=family or offset>=len(context['candidate_keys']):continue
            done=False;key=context['candidate_keys'][offset]
            if key in seen or not index[key]['admitted']:continue
            seen.add(key);reselected.append(index[key]);reselection.append({'candidate':len(reselected)-1,'key':key,'context':ci,'offset':offset})
            if len(seen)==1024:break
        offset+=1
assert reselected==selected and reselection==selection and len(selected)==2048
process=load(ROOT/'output/h5-mixed-roof-contacts-preparation-process-20261107/process.json');assert process['closed'] and process['passed'];charge=load(SOURCE/'audit/checks.json')['complete_preparation_seconds']+process['complete_seconds']
inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','modes.json','contexts.json','free-regions.json','all-candidates.json','candidates.json','selection.json']]+[SOURCE/n for n in ['plan.json','source-geometry.json','audit/checks.json']]+[ROOT/'output/h5-mixed-roof-contacts-preparation-process-20261107/process.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct all1360 recorded free-region vertex/representative point contexts and the once-rounded source poses. Independently check all4445 actual original outlines against every fixed frame and cog site, stock and legal mode; reconstruct all exact conflict masks and both1024-per-family round-robin selections. Finite safe samples only; no continuum coverage claim.'})
result={'passed':True,'seconds':time.perf_counter()-start,'contexts_verified':len(contexts),'original_contacts_verified':len(pool),'source_fixed_pair_checks':checked_pairs,'maximum_distance_replay_error_mm':max_error,'selected_brackets':1024,'selected_inserts':1024,'deterministic_selection_verified':True,'all_selected_source_safe_with_recorded_cog_mask':True,'complete_preparation_seconds':charge,'candidate_sha256':digest(BASE/'candidates.json'),'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
