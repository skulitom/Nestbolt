"""Exact finite original-inventory CP-SAT model; preparation only."""
from pathlib import Path
from hashlib import sha256
import json,time,shutil
import numpy as np
import ortools
from ortools.sat.python import cp_model,cp_model_helper
ROOT=Path(__file__).resolve().parents[1];G=ROOT/'output/h5-mixed-roof-graph-20261107';OUT=ROOT/'output/h5-mixed-roof-model-20261107';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');checked=load(G/'audit/checks.json');assert checked['passed'] and checked['edges_sha256']==digest(G/'edges.npy');assert ortools.__version__=='9.15.6755';mapping=load(G/'mapping.json');edges=np.load(G/'edges.npy',allow_pickle=False);links=load(G/'pose-cog-conflicts.json');n=mapping['candidate_count'];model=cp_model.CpModel()
files=[Path(__file__),G/'plan.json',G/'mapping.json',G/'edges.npy',G/'pose-cog-conflicts.json',G/'audit/checks.json',Path(cp_model.__file__),Path(cp_model_helper.__file__)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'method':'One Boolean per2048 finite bracket/insert source poses and17 original cog sites; exact counts6brackets,12inserts,15cogs plus33fixed originals. Every actual-outline pair conflict and pose/cog mask is an at-most-one constraint. No objective, hints, partial counts or dropped pair. No solver opened during preparation.','complete_reused_preparation_seconds':checked['complete_preparation_seconds'],'maximum_solver_calls':1,'algorithm_seconds':60,'shared_seconds':90,'solver_maximum_seconds':40,'workers':4,'random_seed':0,'excluded_subsolvers':['fj'],'memory_bytes':2**31,'preparation_cap_seconds':15,'retry_permitted':False,'scope':'Finite contact pool only; solver infeasibility does not exclude a continuous layout or allocation.'})
for i in range(n):model.new_bool_var(f'p{i}')
for i in range(17):model.new_bool_var(f'c{i}')
for i,j in edges:model.proto.constraints.add().at_most_one.literals.extend([int(i),int(j)])
for i,j in links:model.proto.constraints.add().at_most_one.literals.extend([i,n+j])
for family,count in [('bracket',6),('insert',12)]:
    row=model.proto.constraints.add().linear;ids=mapping['family_indices'][family];row.vars.extend(ids);row.coeffs.extend([1]*len(ids));row.domain.extend([count,count])
row=model.proto.constraints.add().linear;row.vars.extend(range(n,n+17));row.coeffs.extend([1]*17);row.domain.extend([15,15]);assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'))
checks={'prepared':True,'seconds':time.perf_counter()-start,'variables':n+17,'constraints':len(model.proto.constraints),'pair_constraints':len(edges),'pose_cog_constraints':len(links),'exact_quantity_constraints':3,'model_sha256':digest(OUT/'model.pbtxt'),'ortools_version':ortools.__version__,'tool_hashes':{str(Path(p).relative_to(ROOT).as_posix()):digest(Path(p)) for p in [cp_model.__file__,cp_model_helper.__file__]},'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
