"""Reconstruct every saved protobuf field using an independent protobuf reader."""
from pathlib import Path
from hashlib import sha256
import json,time,shutil,sys,copy
import numpy as np
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model,cp_model_helper
import ortools
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-model-20261107';G=ROOT/'output/h5-mixed-roof-graph-20261107';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');assert ortools.__version__=='9.15.6755';checked=load(G/'audit/checks.json');assert checked['passed'];mapping=load(G/'mapping.json');edges=np.load(G/'edges.npy',allow_pickle=False);links=load(G/'pose-cog-conflicts.json');expected=cp_model_pb2.CpModelProto();n=mapping['candidate_count']
for i in range(n+17):
    v=expected.variables.add();v.name=f'p{i}' if i<n else f'c{i-n}';v.domain.extend([0,1])
for i,j in edges:expected.constraints.add().at_most_one.literals.extend([int(i),int(j)])
for i,j in links:expected.constraints.add().at_most_one.literals.extend([i,n+j])
for family,count in [('bracket',6),('insert',12)]:
    row=expected.constraints.add().linear;ids=mapping['family_indices'][family];row.vars.extend(ids);row.coeffs.extend([1]*len(ids));row.domain.extend([count,count])
row=expected.constraints.add().linear;row.vars.extend(range(n,n+17));row.coeffs.extend([1]*17);row.domain.extend([15,15]);actual=text_format.Parse((BASE/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());wire=expected.SerializeToString(deterministic=True);assert wire==actual.SerializeToString(deterministic=True)
negative=[]
for kind in ['variable-domain','missing-conflict','wrong-cog-link','short-quantity','extra-objective']:
    changed=copy.deepcopy(actual)
    if kind=='variable-domain':changed.variables[0].domain[1]=2
    elif kind=='missing-conflict':del changed.constraints[0]
    elif kind=='wrong-cog-link':changed.constraints[len(edges)].at_most_one.literals[1]=n+16 if changed.constraints[len(edges)].at_most_one.literals[1]!=n+16 else n+15
    elif kind=='short-quantity':changed.constraints[-1].linear.domain[0]=changed.constraints[-1].linear.domain[1]=14
    else:changed.objective.vars.append(0);changed.objective.coeffs.append(1)
    assert changed.SerializeToString(deterministic=True)!=wire;negative.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',negative)
controls=[]
for feasible in [True,False]:
    m=cp_model.CpModel();a=m.new_bool_var('a');b=m.new_bool_var('b');m.add_at_most_one(a,b);m.add(a+b==(1 if feasible else 2));solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=1;status=solver.solve(m);assert status==(cp_model.OPTIMAL if feasible else cp_model.INFEASIBLE);controls.append({'expected_feasible':feasible,'status':solver.status_name(status),'seconds':solver.wall_time,'selected':[solver.value(a),solver.value(b)] if feasible else None})
write(OUT/'synthetic-tool-controls.json',controls)
process=load(ROOT/'output/h5-mixed-roof-model-preparation-process-20261107/process.json');assert process['passed'] and process['closed'];charge=checked['complete_preparation_seconds']+process['complete_seconds'];inputs=[Path(__file__),BASE/'plan.json',BASE/'model.pbtxt',BASE/'checks.json',G/'mapping.json',G/'edges.npy',G/'pose-cog-conflicts.json',G/'audit/checks.json',ROOT/'output/h5-mixed-roof-model-preparation-process-20261107/process.json'];tool_files={str(Path(p).relative_to(ROOT).as_posix()):digest(Path(p)) for p in [sys.executable,cp_model.__file__,cp_model_helper.__file__,cp_model_pb2.__file__]};write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'tool_files':tool_files,'method':'Independent protobuf serialization equality for every variable and every constraint; all actual-outline edges,pose-to-site implications and exact source counts. Five corruptions rejected. Two tiny synthetic tool controls only; no original placement solver call.'});result={'passed':True,'seconds':time.perf_counter()-start,'variables_verified':len(actual.variables),'constraints_verified':len(actual.constraints),'original_pose_pair_constraints':len(edges),'pose_cog_constraints':len(links),'exact_inventory_constraints':3,'extra_fields_present':False,'model_sha256':digest(BASE/'model.pbtxt'),'tool_files':tool_files,'synthetic_controls':len(controls),'corruption_controls':len(negative),'complete_preparation_seconds':charge,'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='tool_files'})
