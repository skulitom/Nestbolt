from pathlib import Path
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-model-20261107';S=BASE/'search';OUT=S/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');plan=load(S/'plan.json');opened=load(S/'opened.json');r=load(S/'result.json');process=load(S/'process.json');job=load(S/'job.json');model=load(BASE/'audit/checks.json');assert model['passed'];response=text_format.Parse((S/'response.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpSolverResponse());parameters=text_format.Parse((S/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters());expected=sat_parameters_pb2.SatParameters();expected.max_time_in_seconds=opened['allocated_solve_seconds'];expected.num_search_workers=4;expected.random_seed=0;expected.ignore_subsolvers.append('fj');expected.log_search_progress=True;expected.log_to_stdout=False;assert expected==parameters
assert r['closed'] and r['solver_calls']==1 and r['status']=='INFEASIBLE' and response.status==cp_model_pb2.INFEASIBLE and not response.solution and r['incumbents']==0 and not list(S.glob('incumbent-*.json')) and not r['assignment_returned'];assert not (S/'selected.json').exists() and not (S/'candidate-source66.json').exists();assert r['branches_reported']==response.num_branches and r['conflicts_reported']==response.num_conflicts
assert r['allocated_solve_seconds']==40==parameters.max_time_in_seconds and r['returned_solve_seconds']>=response.wall_time and r['solve_slice_overrun_seconds']==max(0,r['returned_solve_seconds']-parameters.max_time_in_seconds)==0
assert r['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and r['algorithm_overrun_seconds']==0 and plan['preparation_seconds_charged']==model['complete_preparation_seconds'];assert process['closed'] and process['tree_closed'] and process['job']==job and process['exit_code']==job['root_exit_code']==job['error_code']==job['reason_code']==job['active_processes']==0 and job['closed'] and job['peak_job_committed_memory']<2**31
assert r['source_valid66']==r['H5_complete']==r['any_allocation_excluded']==r['retry_permitted']==False and r['native_calls']==0 and opened['model_sha256']==model['model_sha256']==digest(BASE/'model.pbtxt')
log=(S/'solver.log').read_text(encoding='utf-8');assert 'status: INFEASIBLE' in log and 'Starting CP-SAT solver v9.15.6755' in log
bindings={};queue=[S/'plan.json',BASE/'audit/plan.json',BASE/'plan.json'];seen=set()
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p);d=load(p)
    for name,h in d.get('inputs',{}).items():
        q=ROOT/name;assert digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json'] or q.name.endswith('process.json'):queue.append(q)
for name,h in model['tool_files'].items():assert digest(ROOT/name)==h
write(OUT/'source-bindings.json',bindings);inputs=[Path(__file__),BASE/'audit/checks.json']+[S/n for n in ['plan.json','opened.json','result.json','response.pbtxt','parameters.pbtxt','solver.log','process.json','job.json','supervisor-opened.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Exact parameter protobuf and saved response fields; original finite-inventory model and all recursive source hashes, complete consumed preparation, solver and supervisor limits, no assignment or hidden source/native call, all descendants closed. INFEASIBLE is the solver status on a finite sample pool only; no independently certified continuous/allocation exclusion.'});checks={'passed':True,'seconds':time.perf_counter()-start,'source_bindings_verified':len(bindings),'closed_original_solver_calls':1,'status':r['status'],'finite_sample_pool_only':True,'variables':2065,'constraints':234513,'assignment_returned':False,'source_valid66':False,'incumbents':0,'complete_preparation_seconds':model['complete_preparation_seconds'],'returned_solve_seconds':r['returned_solve_seconds'],'algorithm_seconds':r['algorithm_seconds_including_preparation'],'shared_seconds':process['seconds_including_preparation'],'solve_slice_overrun_seconds':0,'peak_committed_memory_bytes':job['peak_job_committed_memory'],'all_descendants_closed':True,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
