"""Independent recipe, site-pair and original-source readback."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from fractions import Fraction as F
import json,math,time,shutil
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-source-20261107';OUT=BASE/'audit';PRIOR=ROOT/'output/h5-six-bracket-cog-source-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');job=load(JOB);parts={p['id']:p for p in job['parts']};data=load(BASE/'source-geometry.json');fixed=load(BASE/'fixed33-source.json');short=load(PRIOR/'short15-source.json');old=load(PRIOR/'library.json');plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
assert data['families']==old['families'] and data['fixed_source_rows']==fixed and fixed[18:]==short and len(fixed)==33
assert data['source_stocks']==old['source_stocks'] and data['required_pair_gap_mm']==old['required_pair_gap_mm'] and data['stock_guard_mm']==old['stock_guard_mm']
expected_ids={('frame',i) for i in range(18)}|{(r['part_id'],r['copy_index']) for r in short};assert expected_ids=={(r['part_id'],r['copy_index']) for r in fixed}
safe=data['safe_stock_mm'];gap=.23;frame_controls=[]
def independent_polygon(family,pose):
    angle=pose['rotation_radians'];c,s=math.cos(angle),math.sin(angle);mirror=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];points=parts[family]['geometry'][0]['outer']
    return Polygon([(tx+c*(mirror*x)-s*y,ty+s*(mirror*x)+c*y) for x,y in points])
for i,row in enumerate(fixed[:18]):
    assert row['copy_index']==i and row['sheet_id']=='sheet-0' and not row['transform']['mirrored']
    if i<16:
        col,rr=divmod(i,4);theta=math.pi/2;x=safe[0]+col*(350+gap);y=safe[1]+rr*(450+gap);expected=[x,y,x+350,y+450]
    else:
        theta=0.;x=safe[0]+(i-16)*(450+gap);y=safe[1]+4*(450+gap);expected=[x,y,x+450,y+350]
    assert row['transform']['rotation_radians']==theta
    actual=independent_polygon('frame',row['transform']);assert max(abs(a-b) for a,b in zip(actual.bounds,expected))<1e-9
    frame_controls.append({'frame':i,'expected_bounds_mm':expected,'actual_bounds_mm':list(actual.bounds),'maximum_error_mm':max(abs(a-b) for a,b in zip(actual.bounds,expected))})
for left,right in combinations(frame_controls,2):
    a,b=left['expected_bounds_mm'],right['expected_bounds_mm'];axis=max(F(a[0])-F(b[2]),F(b[0])-F(a[2]),F(a[1])-F(b[3]),F(b[1])-F(a[3]));assert axis>F('.229999999'),(left,right)
source=audit(job,fixed,data['source_stocks'],data['required_pair_gap_mm'],data['stock_guard_mm']);assert source==load(BASE/'fixed33-checks.json') and source['valid']
sites=load(BASE/'cog-sites.json');assert sites==data['cog_pool'] and len(sites)==17
contact=load(PRIOR/'source-contact-pitches.json');assert data['cog_pitch_mm']==contact['pitches_mm']==[261.766,261.766] and abs(data['cog_phase_radians']-math.radians(contact['phase_degrees']))<1e-15
assert load(PRIOR/'audit/checks.json')['passed'];assert data['source_radius_mm']==old['angle_scale_mm'];radius=data['source_radius_mm'];px,py=data['source_center'];polys=[]
for i,row in enumerate(sites):
    group='left' if i<9 else 'right';index=i if i<9 else i-9;columns=3 if i<9 else 2;rr,cc=divmod(index,columns)
    if group=='left':ox=safe[0]+radius+.000001;oy=safe[1]+4*(450+gap)+350+gap+radius+.000001
    else:ox=safe[0]+2*(450+gap)+radius+.000001;oy=safe[1]+4*(450+gap)+radius+.000001
    center=[ox+cc*261.766,oy+rr*261.766];assert row['site']==i and row['group']==group and row['row']==rr and row['column']==cc and max(abs(a-b) for a,b in zip(row['center'],center))<1e-9
    pose=row['transform'];assert pose['rotation_radians']==data['cog_phase_radians']==row['angle_radians'] and not pose['mirrored'];c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);recenter=[pose['translation'][0]+c*px-s*py,pose['translation'][1]+s*px+c*py];assert max(abs(a-b) for a,b in zip(recenter,center))<1e-9
    polygon=independent_polygon('cog',pose);polys.append(polygon);x0,y0,x1,y1=polygon.bounds;assert x0>=safe[0] and y0>=safe[1] and x1<=safe[2] and y1<=safe[3]
pair_rows=load(BASE/'site-pair-checks.json');assert len(pair_rows)==136
for record,(i,j) in zip(pair_rows,combinations(range(17),2)):
    distance=polys[i].distance(polys[j]);assert record['sites']==[i,j] and abs(distance-record['distance_mm'])<1e-9 and record['original_overlap_mm2']==polys[i].intersection(polys[j]).area==0 and distance>=data['required_pair_gap_mm']
frame_rows=load(BASE/'site-frame-checks.json');assert len(frame_rows)==306
for record in frame_rows:
    a=polys[record['site']];b=independent_polygon('frame',fixed[record['frame']]['transform']);distance=a.distance(b);assert abs(distance-record['distance_mm'])<1e-9 and record['original_overlap_mm2']==a.intersection(b).area==0 and distance>=data['required_pair_gap_mm']
control=fixed+[{'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':sites[i]['transform']} for i in range(15)];assert control==load(BASE/'source48-control.json');source48=audit(job,control,data['source_stocks'],data['required_pair_gap_mm'],data['stock_guard_mm']);assert source48==load(BASE/'source48-checks.json') and source48['valid'] and source48['originals']==48
ids={(r['part_id'],r['copy_index']) for r in control};missing=set(map(tuple,old['all66_identities']))-ids;assert missing==set(map(tuple,data['missing_identities'])) and len(missing)==18
process=load(ROOT/'output/h5-mixed-roof-source-preparation-process-20261107/process.json');assert process['closed'] and process['passed'];charge=load(PRIOR/'audit/checks.json')['complete_preparation_seconds']+process['complete_seconds']
write(OUT/'frame-controls.json',frame_controls)
inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','source-geometry.json','fixed33-source.json','fixed33-checks.json','cog-sites.json','site-pair-checks.json','site-frame-checks.json','source48-control.json','source48-checks.json']]+[PRIOR/n for n in ['plan.json','library.json','short15-source.json','source-contact-pitches.json','audit/checks.json']]+[ROOT/'output/h5-mixed-roof-source-preparation-process-20261107/process.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct all eighteen mixed-orientation frame rectangles from dimensions, exact rational nominal axis separation with measured trig error below1e-9mm; independently derive both source cog grids, reconstruct original transforms and every one of136 site pairs and306 site/frame checks. Validate fixed33 and exact first15-cog source48, preserving missing18 identities. No optimizer or nativecall.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':33,'fixed_source_pairs':source['same_sheet_pairs'],'frame_rectangles_verified':18,'exact_nominal_frame_pair_checks':153,'cog_sites_verified':17,'cog_site_pairs_verified':136,'cog_site_frame_pairs_verified':306,'minimum_cog_pair_gap_mm':min(r['distance_mm'] for r in pair_rows),'minimum_cog_frame_gap_mm':min(r['distance_mm'] for r in frame_rows),'source_control_originals':48,'source_control_cogs':15,'source_control_pairs':source48['same_sheet_pairs'],'source_control_stock_edges':source48['stock_edges'],'source_control_holes':source48['cutouts'],'source_control_hole_vertices':source48['hole_vertices'],'source_control_valid':True,'missing_brackets':6,'missing_inserts':12,'complete_preparation_seconds':charge,'source_geometry_sha256':digest(BASE/'source-geometry.json'),'source_optimizer_calls':0,'source_valid66':False,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
