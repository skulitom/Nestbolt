"""Original66 source checker subprocess, inside the parent bounded Job Object."""
from pathlib import Path
import json,sys
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'output/h5-mixed-roof-model-20261107/search';SOURCE=ROOT/'output/h5-mixed-roof-source-20261107';CONTACTS=ROOT/'output/h5-mixed-roof-contacts-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
selection=load(S/'selected.json');data=load(SOURCE/'source-geometry.json');pool=load(CONTACTS/'candidates.json');rows=data['fixed_source_rows'].copy();used={family:sorted(i for f,i in data['missing_identities'] if f==family) for family in ['bracket','insert']}
for family,count in [('bracket',6),('insert',12)]:
    indices=[i for i in selection['poses'] if pool[i]['family']==family];assert len(indices)==len(used[family])==count
    for index,identity in zip(indices,used[family]):rows.append({'part_id':family,'copy_index':identity,'sheet_id':'sheet-0','transform':pool[index]['transform']})
assert len(selection['cog_sites'])==15
for identity,index in enumerate(selection['cog_sites']):rows.append({'part_id':'cog','copy_index':identity,'sheet_id':'sheet-0','transform':data['cog_pool'][index]['transform']})
write(S/'candidate-source66.json',rows);checked=audit(load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'),rows,data['source_stocks'],data['required_pair_gap_mm'],data['stock_guard_mm'],list(map(tuple,data['all66_identities'])));write(S/'original-source-checks.json',checked);print({'valid':checked['valid'],'originals':checked['originals'],'pair_failures':checked['pair_failures'],'stock_failures':checked['stock_failures']})
