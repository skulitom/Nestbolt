"""Seal source geometry, finite contacts, complete graph/model and closed call."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-mixed-roof-contact-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-mixed-roof-model-20261107';F=BASE/'search/audit';D=ROOT/'output/h5-mixed-roof-source-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-joint-cell-vector-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_original_solver_calls']==1 and front['status']=='INFEASIBLE' and not front['assignment_returned']",
"OUT.mkdir();members={};external={};bindings={};queue=[];seen=set()":"OUT.mkdir();members={};external={};bindings={};tool_bindings={};queue=[];seen=set()",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D]+[ROOT/'output'/n for n in ['h5-mixed-roof-contacts-20261107','h5-mixed-roof-graph-20261107','h5-mixed-roof-source-preparation-process-20261107','h5-mixed-roof-source-audit-process-20261107','h5-mixed-roof-contacts-preparation-process-20261107','h5-mixed-roof-contacts-audit-process-20261107','h5-mixed-roof-graph-preparation-process-20261107','h5-mixed-roof-graph-audit-process-20261107','h5-mixed-roof-model-preparation-process-20261107','h5-mixed-roof-model-audit-process-20261107','h5-mixed-roof-response-audit-process-20261107','h5-joint-cell-main-sync-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*mixed*roof*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_mixed_roof_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)":"    p=ROOT/name;assert digest(p)==h\n    if name.startswith('.cache/'):\n        tool_bindings[name]=h;continue\n    bindings[name]=h;add('source-inputs/'+name,p)",
"            z=ROOT/name;assert digest(z)==h,name;bindings[name]=h;add('source-inputs/'+name,z)":"            z=ROOT/name;assert digest(z)==h,name\n            if name.startswith('.cache/'):\n                tool_bindings[name]=h;continue\n            bindings[name]=h;add('source-inputs/'+name,z)"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
C=ROOT/'output/h5-mixed-roof-contacts-20261107';G=ROOT/'output/h5-mixed-roof-graph-20261107';tool_bindings.update(load(BASE/'audit/checks.json')['tool_files'])
for name,h in tool_bindings.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',tool_bindings)
copies=[(D/'audit/checks.json','source-audit.json'),(D/'audit/frame-controls.json','frame-controls.json'),(C/'checks.json','contact-preparation.json'),(C/'audit/checks.json','contact-audit.json'),(G/'audit/checks.json','graph-audit.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'audit/synthetic-tool-controls.json','synthetic-tool-controls.json'),(F/'checks.json','response-audit.json'),(BASE/'search/result.json','closed-response.json'),(BASE/'search/process.json','closed-process.json'),(ROOT/'output/h5-joint-cell-main-sync-20261107/receipt.json','prior-main-push-receipt.json'),(ROOT/'output/h5-mixed-roof-main-ci-at-review-20261107.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(tool_bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'source_domain_preflight_required','proposal':'Retain the changed mixed-orientation frame roof and short15 source allocation; assess a continuous original-outline model freeing all fifteen cog centers and angles along with six brackets and twelve inserts.','changed_scope':'The closed pool fixes cog positions to17sites and companions to2048finiteposes. The proposed model must allow actual continuous translations, rotations and source-certified cell choices. It is not an extension of the finite call or the old three-column model.','requirements':['Construct and independently verify hard source-safe center cells for every legal bracket/insert orientation and all-angle cog envelopes against the eighteen mixed-orientation frames.','If cogs have multiple cells, include those choices in owner/mode bindings, physical equivalence and neighbor enumeration; do not retain old single-cog-cell assumptions.','Freeze one complete source-only initializer and charge all consumed preparation before any call. A graph-derived partial may be used only after separate original-source validation and without claiming it is a full solution.','Preserve the finite INFEASIBLE result and all older calls; do not reset an optimized ancestor clock or claim a continuous/allocation exclusion.'],'new_continuous_geometry_prepared':False,'new_initializer_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Mixed frame roof and finite contact construction — 2026-11-07

The changed frame arrangement leaves **17 mutually compatible cog sites**.
However, the complete finite model cannot select the required fifteen sites
together with six brackets and twelve inserts from its sampled contact pool:
the one declared call returns **INFEASIBLE** after **2.227445 s**. This is the
solver's result on a finite pool, not a continuous or whole-allocation exclusion.
There is no complete candidate, native call or H5 credit. H2/H5 remain open at
**60% completed milestone weight**.

## Changed fixed geometry and source control

The large sheet fixes sixteen quarter-turned frames in a four-by-four base,
then two unturned frames along the left side of its top edge. The resulting
step differs from both the closed 5/5/4/4 all-turned frame construction and the
three-column core. The short sheet retains the audited six-bracket/nine-insert
arrangement. All **33 fixed originals** pass source checks.

The left region above the frames admits a three-by-three cog grid and the right
region a two-by-four grid. Both use the exact source-contact phase near 6.75°
and 261.766 mm pitches. Seventeen denotes candidate sites; the job still requires
exactly fifteen cog copies. [Independent source readback]({NAME}/source-audit.json)
checks every one of 136 site pairs and 306 site/frame pairs. Minimum original
clearances are **0.301547629 mm** between sites and **0.268862770 mm** to frames,
above the unchanged required 0.211708673 mm.

[All eighteen frame recipes]({NAME}/frame-controls.json) are independently
reconstructed. Their nominal rectangles pass 153 exact rational axis-separation
checks; the actual trigonometric bounds differ by less than 1e-9 mm. One control
using exactly the first fifteen sites contains **48 original parts**, passes
633 pair checks and 192 stock edges, and retains 60 holes with 6,366 vertices.
Six brackets and twelve inserts are missing. It is not a new best partial or
full66 result. Complete consumed source preparation is **4.136496 s**.

Historical contact pools, source Minkowski regions and mixed component searches
are acknowledged and bound as inputs. No claim that contact sampling or finite
cog pools are unprecedented is made; the fixed obstacle geometry is changed.

## Finite contacts and complete conflict graph

For each of the **136 choices of two unused sites**, the generator considers
eight bracket modes and two physically distinct insert modes. Source convex-piece
Minkowski obstacles, expanded by a 0.23 mm square, give conservative free regions
against the frames and the fifteen selected cogs. Each free polygon contributes
a representative point and all boundary vertices. Centers are rounded once to
0.000001 mm and independently checked using actual original outlines.

[The contact audit]({NAME}/contact-audit.json) replays **1,360 contexts and all
4,445 unique contacts**, including 155,575 original checks against fixed frames
and cog sites. All are individually source-safe after omitting their recorded
conflicting sites. Maximum distance-replay difference is 5.68435e-13 mm. A frozen
round-robin rule retains **1,024 brackets and 1,024 inserts**; no arbitrary
post-result expansion or thinning occurs. The conservative regions and finite
samples do not claim complete continuous coverage.

[Independent full graph readback]({NAME}/graph-audit.json) checks every one of
**2,096,128 unordered candidate pairs** without geometric pruning. It reproduces
all **231,343 conflict edges** and **3,167 pose-to-cog-site conflicts**. All source
quantities and mappings remain unchanged. Complete consumed contact and graph
preparation totals are **7.893946 s** and **9.665682 s**, respectively.

## Exact inventory model and closed solve

The model has **2,065 Boolean variables and 234,513 constraints**. It selects
exactly six brackets, twelve inserts and fifteen cog sites, adding them to the
33 fixed originals. Every candidate conflict and pose/site conflict is present.
There is no objective, hint, relaxed count or partial-inventory acceptance.

[Independent protobuf reconstruction]({NAME}/model-audit.json) checks every
saved variable and constraint field. [Five deliberate corruptions]({NAME}/negative-controls.json)
are rejected, and [two tiny synthetic tool controls]({NAME}/synthetic-tool-controls.json)
confirm the installed OR-Tools 9.15.6755 behavior. These synthetic tests are
separate from the one original placement call. Complete preparation, including
all consumed source lineage and full model construction, is **11.631014 s**.

The declared solver uses four workers, seed zero, `fj` excluded, and at most
40 solve seconds within preparation-inclusive 60/90-second algorithm/shared
limits. It returns no assignment or incumbent. The saved response reports
2,594 branches and two conflicts; these are response counters, not a sum of
all portfolio workers. [Independent response readback]({NAME}/response-audit.json)
verifies exact parameters, source hashes, raw status, log, no hidden candidate
or native check, and all process limits.

Algorithm/shared totals are **14.700575/14.803571 s**, with no solve or overall
overrun. Peak aggregate committed memory is **186,945,536 bytes**; [all three
search processes close]({NAME}/closed-process.json). The call remains closed
despite unused time. Its finite-pool INFEASIBLE status does not prove that this
frame arrangement, allocation, or unrestricted original job is impossible.

## Next source scope and repository

[The next source preflight]({NAME}/next-step.json) assesses continuous original
cog centers and angles, together with the six brackets and twelve inserts,
against the changed fixed frame roof. Every legal orientation needs independently
certified hard source-safe cells. Multiple cog cells must be represented in mode
bindings, equivalence and neighbor enumeration. No successor continuous geometry,
complete initializer or optimizer call is prepared. All consumed preparation
must be charged and all current calls remain closed.

Four earlier fixed arrangements and **440 whole allocations** remain unresolved.
Full66 source/native/material checks, production parity and the unchanged H5
matrix remain required. H2 keeps its original gate and reserved vectors.
Production, README and releases are unchanged; no release qualifies.

[The previous two checkpoints reached main 6b81bf9d]({NAME}/prior-main-push-receipt.json)
after all six prior checks and aggregate CI passed, preserving all 52 remote
files. [Fresh main CI is running at review]({NAME}/main-ci-at-review.json).

[The raw manifest]({NAME}/raw-manifest.json) and [source bindings]({NAME}/source-bindings.json)
preserve source evidence and exact prior archive references. Four installed
runtime files are [separately pinned by hash]({NAME}/runtime-bindings.json),
including the Python executable and OR-Tools wrapper/native/protobuf modules;
vendor runtime bytes are not bundled into this evidence archive.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 mixed frame roof and finite contacts:** [independent source/contact/graph/model/response audits]({link}) verify sixteen turned base frames plus two unturned roof frames and a17-site compatible cog pool. A source48 control uses exactly15cogs and leaves six brackets/twelve inserts missing; it is not a new best partial. All136 cog-site pairs and306 site/frame pairs pass, with minimum gaps0.301547629/0.268862770mm. All4,445 generated contacts and155,575 fixed-pair checks replay; the frozen cap keeps1,024 candidates per companion family. Every2,096,128 candidate pair is checked, reproducing231,343 edges and3,167 pose/cog conflicts. The2,065-variable/234,513-constraint model requires exact original quantities. One declared call returns finite-pool INFEASIBLE in2.227445s, without an assignment or incumbent; no continuous layout or allocation is excluded. Complete preparation is11.631014s and algorithm/shared totals14.700575/14.803571s, with no overrun and all processes closed. Next assess source-certified hard cells for continuous cog centers/angles and all18 companions under the changed frame roof, including multiple cog-cell choices; no successor geometry or call is prepared. Four earlier fixed arrangements and440 allocations remain; H2/H5 stay open at60%. Checkpoints be75186f/6b81bf9d reached main normally after all six prior checks passed, preserving52 remote files; fresh CI is running. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [mixed frame roof and finite contacts](../benchmarks/results/{NAME}.md).
Sixteen turned base frames and two unturned roof frames leave17 compatible cog
sites. The48-part source control uses exactly15cogs; six brackets and twelve
inserts remain absent. Independent audits verify4,445 contacts and all2,096,128
candidate pairs, then every field of the exact-inventory model. Its one declared
call returns finite-pool INFEASIBLE in2.227445s, with no assignment or incumbent.
Algorithm/shared totals including11.631014s preparation are14.700575/14.803571s;
all processes close without an overrun. No continuous layout or allocation is
excluded. Next assess source-safe cells for continuous cog centers/angles and
the18 companions under the changed roof, including multiple cog-cell choices.
No successor geometry or call is prepared. Four earlier fixed arrangements and
440 allocations remain; H2/H5 stay open at60% completed milestone weight.
Main6b81bf9d includes the previous two checkpoints after all six prior checks
passed; fresh CI is running. Full66 source/native/material checks, production
parity and the unchanged H5 matrix remain required. No release qualifies.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings),'runtime_bindings':len(tool_bindings)})
