"""Bounded validation-only phase attribution; no optimizer or source initializer."""
from pathlib import Path
from hashlib import sha256
import json,time,os,gc
from h5_tiered_neighbors_20261107 import primary,cache_context
from h5_tiered_key_choice_20261107 import choose
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-tiered-cost-profile-20261107';T=ROOT/'output/h5-tiered-selector-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';X=ROOT/'output/h5-indexed-source-preflight-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def tick():return (time.perf_counter(),time.process_time())
def delta(a,b):return {'wall_seconds':b[0]-a[0],'process_cpu_seconds':b[1]-a[1]}
OUT.mkdir();started=time.perf_counter();assert load(T/'checks.json')['passed'] and load(ROOT/'output/h5-tiered-preflight-process-20261107/process.json')['passed']
assert affinity_mask()==4294901760 and all(os.environ[n]=='1' for n in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
inputs=[Path(__file__),T/'checks.json',T/'plan.json',ROOT/'output/h5-tiered-preflight-process-20261107/process.json']+[T/n for n in ['source-primary-records.json','source-primary-choice.json','source-primary-minima.json','runtime-primary-records.json','runtime-primary-choice.json','runtime-primary-minima.json']]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json']+[V/n for n in ['closed-problems.json','center-trials.json','runtime-bindings.json']]+[X/n for n in ['search/epoch-01/opened.json','search/epoch-01/weight-transition.json']]+[ROOT/'output'/n for n in ['h5_tiered_neighbors_20261107.py','h5_tiered_key_choice_20261107.py']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Three fresh validation-only primary calls in fixed order: source uncached, source cached, closed-runtime uncached. Attribute wall and process CPU time using existing unchanged cooperative checkpoint positions, then public snapshot return and complete grouping. Measure complete raw-record/center/alias/group/minimum/selection JSON serialization and readback separately. Require exact prior independently audited primary records, minima and choices. No extension, source initializer, model preparation, optimizer call or resumed pipeline. One observation per context/cache variant; no significance or stable-runtime claim.','checkpoint_events':{'before_model':1,'after_baseline':2,'after_all_modes':224,'before_first_proposal':225,'complete_primary':6136},'maximum_process_seconds':180,'memory_bytes':2**31,'primary_deadline_seconds':60,'validation_only':True,'optimizer_calls':0})
for name,h in load(V/'runtime-bindings.json').items():assert digest(ROOT/name)==h
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');opened=load(X/'search/epoch-01/opened.json')
source_args=[lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,{r['key'] for r in load(V/'closed-problems.json')}]
runtime_args=[lib,opened['incoming_modes'],opened['incoming_values'],load(X/'search/epoch-01/weight-transition.json')['after'],identity,regions,set(opened['visited_keys'])]
cache={'context':cache_context(*source_args[:6]),'trials':load(V/'center-trials.json')}
summaries=[]
for label,context,args,cached in [('source-uncached','source',source_args,None),('source-cached','source',source_args,cache),('runtime-uncached','runtime',runtime_args,None)]:
    folder=OUT/label;folder.mkdir();expected=load(T/(context+'-primary-records.json'));expected_choice=load(T/(context+'-primary-choice.json'));expected_minima=load(T/(context+'-primary-minima.json'));events={};calls=[0]
    def clock():
        calls[0]+=1;wall=time.perf_counter()
        if calls[0] in [1,2,224,225,6136]:events[calls[0]]=(wall,time.process_time())
        return wall
    gc.collect();begin=tick();pool=primary(*args,deadline=begin[0]+60,clock=clock,cached_trials=cached);returned=tick();assert calls[0]==6136
    choice,groups,minima=choose(pool.primary,'primary',deadline=begin[0]+60);grouped=tick()
    assert pool.primary==expected and choice==expected_choice and minima==expected_minima and len(groups)==2854
    phases={'input_snapshot_and_cache_validation':delta(begin,events[1]),'model_and_baseline':delta(events[1],events[2]),'center_geometry_and_ranking':delta(events[2],events[224]),'proposal_schedule':delta(events[224],events[225]),'primary_proposals':delta(events[225],events[6136]),'public_snapshot':delta(events[6136],returned),'key_grouping_and_choice':delta(returned,grouped)}
    total=delta(begin,grouped)
    assert all(abs(sum(p[k] for p in phases.values())-total[k])<1e-6 for k in total)
    values={'primary-records':pool.primary,'aliases':pool.aliases,'center-trials':pool.trials,'center-selections':pool.selections,'selection':choice,'groups':groups,'key-minima':minima}
    before=tick()
    for name,v in values.items():write(folder/(name+'.json'),v)
    written=tick()
    for name,v in values.items():assert load(folder/(name+'.json'))==v
    read=tick();row={'context':label,'phases':phases,'selector_and_grouping':total,'serialization':delta(before,written),'independent_json_readback':delta(written,read),'serialized_bytes':sum(p.stat().st_size for p in folder.glob('*.json')),'complete_primary_records':5911,'complete_key_minima':2854,'exact_prior_audit_output':True,'cache_used':cached is not None,'optimizer_calls':0};write(folder/'checks.json',{'passed':True,**row});summaries.append(row);print(row,flush=True)
    del pool,choice,groups,minima,values,expected,expected_choice,expected_minima
write(OUT/'checks.json',{'passed':True,'complete_seconds':time.perf_counter()-started,'profiles':summaries,'calls':3,'all_outputs_exact':True,'one_observation_per_variant':True,'statistical_significance_claimed':False,'model_preparation_measured':False,'source_validation_measured':False,'new_source_state_prepared':False,'optimizer_calls':0,'validation_only':True,'H5_complete':False})
