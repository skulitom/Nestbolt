"""Preserve complete tier membership, fallback, timing and closure controls."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-tiered-selector-preflight-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-tiered-selector-preflight-20261107';F=BASE;D=BASE",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-indexed-source-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['timed_calls']==10 and front['optimizer_calls']==0 and front['synthetic_deadline_cases']==26",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-tiered-preflight-process-20261107',ROOT/'output/h5-indexed-source-main-sync-20261107',ROOT/'output/h5-tiered-cost-profile-20261107',ROOT/'output/h5-tiered-cost-profile-process-20261107']",
    "['*h5*mixed*mode*20261107.py']":"['*h5*tiered*20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_tiered_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "load(F/'source-bindings.json')":"load(F/'plan.json')['inputs']",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','partial-coverage-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(ROOT/'output/h5-two-center-preflight-20261107/runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
for name in ['plan','checks','timings','complete-tier-controls','deadline-controls','different-best-fallback-controls','snapshot-isolation-controls','stale-cache-controls','policy-controls','nineteen-key-control','main-ci-at-review']:
    shutil.copyfile(BASE/(name+'.json'),OUT/('selector-audit.json' if name=='checks' else name+'.json'))
shutil.copyfile(ROOT/'output/h5-tiered-preflight-process-20261107/process.json',OUT/'preflight-process.json')
shutil.copyfile(ROOT/'output/h5-tiered-cost-profile-20261107/checks.json',OUT/'cost-profile.json')
shutil.copyfile(ROOT/'output/h5-tiered-cost-profile-process-20261107/process.json',OUT/'cost-profile-process.json')
shutil.copyfile(ROOT/'output/h5-indexed-source-main-sync-20261107/receipt.json',OUT/'prior-main-push-receipt.json')
shutil.copyfile(PARENT/'closed-problems.json',OUT/'closed-problems.json')
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k!='passed'}})
timing=front['timing_summary'];assert len(timing)==2
process=load(OUT/'preflight-process.json');assert process['passed'] and process['job']['active_processes']==0 and process['job']['closed']
profile=load(OUT/'cost-profile.json');profile_process=load(OUT/'cost-profile-process.json');assert profile['passed'] and profile['calls']==3 and profile_process['passed'] and profile_process['job']['active_processes']==0
profiles={r['context']:r for r in profile['profiles']};runtime_profile=profiles['runtime-uncached'];cached_profile=profiles['source-cached']
ci=load(OUT/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'next-step.json',{'status':'tiered_original_source_and_budget_preflight_required',
    'finding':'The complete tier implementation reproduces source and closed-runtime references and preserves a completed primary choice across extension deadlines, including when a better extension proposal was already scored. Ten fixed-order timings remain validation-only and are too limited to establish stable search budget.',
    'proposal':'The separate three-call phase profile finds uncached runtime center geometry dominates the primary cost; snapshot isolation is a small part of that observation. Cached original-source primary selection and complete output serialization are measured separately. Next prepare and independently validate an original-source primary-tier initializer under all19closed keys, retaining every preparation charge. Use those actual costs, model/source verification and full output costs to decide whether a new finite search contract fits; do not assume the earlier timing outliers are explained or guarantee another optimizer call.',
    'requirements':['Retain all19closed objective/physical-mode/weight keys, prior finite pipeline stops, source geometry,528weighted pairs,15auxiliary terms,33movers/15angles,strict1e-6improvement and stable tie ordering. No old call or validation state may resume.','Any new implementation must preserve complete5911primary and23419extended membership, all2854keys per tier, exact scores, independent minima, stale-context rejection, snapshot isolation and complete-tier-only selection. Partial extensions never supply a candidate.','Any future initializer must come from original unoptimized A/W source data with exact hash/context checks. Retain36.02814369951375s prior preparation plus every new preparation cost. No current optimized or validation data may seed it.','Prepare and verify a fresh original-source model and freeze a new finite60/90s2GiB contract only after measured complete output/model/source costs support it. No new source model or search is prepared by this validation checkpoint.','A valid66source result, native/material evidence, production parity and the original H5matrix remain necessary for milestone credit. Four arrangements and 440 allocations remain unresolved.'],
    'closed_problem_keys':19,'source_only_preparation_seconds_before_new_work':36.02814369951375,'tiered_selector_prepared':True,'new_source_state_prepared':False,'new_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
table='\n'.join(f"| {r['context']} | {r['old_full_mean_seconds']:.6f} | {r['primary_mean_seconds']:.6f} | {r['extended_seconds'][0]:.6f} |" for r in timing)
report=f'''# Complete tier selector preflight — 2026-11-07

The validation-only selector finishes a complete **5,911-proposal primary tier**
before optionally evaluating the remaining **17,508 proposals**. Both tiers cover
all **2,854 objective/physical-mode/weight keys**. The complete source and closed-runtime
outputs reproduce the previously independently checked references exactly.
This establishes selection behavior, not a valid packing. H2/H5 remain open at
**60% completed milestone weight**. The last search still has 55 source-pair failures.

[Complete membership and score controls]({NAME}/complete-tier-controls.json) bind
both contexts to prior independent evidence for 65,042 center/proposal scores.
Every primary and extended key minimum is reconstructed against the independent
proposal scores; numerical ties within 1e-6 mm² remain recorded. The primary tier
uses each owner's best source-grid center with canonical sequence gaps; the full
tier restores the original ordered pool. Source centers, objectives and exclusions
are unchanged. [All nineteen closed keys]({NAME}/nineteen-key-control.json) remain excluded.

[Deadline controls]({NAME}/deadline-controls.json) cover **26 synthetic boundaries**
across cached and uncached paths, **two real primary deadlines** and **one real
extension deadline**. An incomplete primary has no selected candidate. An incomplete
or ungrouped extension retains its evidence but returns only the fully grouped
primary result. [Different-best controls]({NAME}/different-best-fallback-controls.json)
restrict eligibility for validation so the complete extension selects proposal 22625
instead of primary proposal 22619. Even after the better proposal appears in the
partial extension, and at the final full-grouping checkpoint, fallback still selects
22619. These artificial eligibility restrictions never become search exclusions.

[Isolation controls]({NAME}/snapshot-isolation-controls.json) mutate caller inputs,
source-cache contents and public result views after primary completion; the private
extension still matches its original reference. An extension can be attempted only
once, including after interruption. [Six stale-cache cases]({NAME}/stale-cache-controls.json)
are rejected. [Policy controls]({NAME}/policy-controls.json) reject missing/reordered
members and a mixed-tier prefix, and select nothing for all-closed or zero-margin pools.

[Measured selector plus grouping times]({NAME}/timings.json), in seconds:

| Context | Previous full mean | Primary mean | Primary plus extension |
| --- | ---: | ---: | ---: |
{table}

The fixed order is old full, primary, extended, primary, old full for each context.
Each compared mean has only two samples; the extended result has one. All new input
and public snapshot copies are timed. Serialization, source validation and model
preparation are outside these measurements. Timing variability prevents a stable
budget or significance claim. The [bounded preflight process]({NAME}/preflight-process.json)
closes in {process['complete_seconds']:.6f} s with peak committed memory
{process['job']['peak_job_committed_memory']:,} bytes under its 600 s / 2 GiB limits.

[Separate phase profiling]({NAME}/cost-profile.json) makes three validation-only
calls: uncached source, cached source and uncached closed-runtime. Every primary
record, minimum and choice still matches the independent preflight. The runtime
primary takes {runtime_profile['selector_and_grouping']['wall_seconds']:.6f} s
({runtime_profile['selector_and_grouping']['process_cpu_seconds']:.6f} process CPU seconds): center geometry and ranking consume
{runtime_profile['phases']['center_geometry_and_ranking']['wall_seconds']:.6f} s,
proposal scoring {runtime_profile['phases']['primary_proposals']['wall_seconds']:.6f} s,
public snapshots {runtime_profile['phases']['public_snapshot']['wall_seconds']:.6f} s,
and grouping {runtime_profile['phases']['key_grouping_and_choice']['wall_seconds']:.6f} s.
Complete raw/minimum/group/center output serialization adds
{runtime_profile['serialization']['wall_seconds']:.6f} s, with separate JSON readback
{runtime_profile['independent_json_readback']['wall_seconds']:.6f} s. Cached original-source
selection takes {cached_profile['selector_and_grouping']['wall_seconds']:.6f} s before
{cached_profile['serialization']['wall_seconds']:.6f} s serialization. These single
observations identify the dominant measured cost; they do not explain earlier
outliers or establish stable runtime. Model preparation and original-source geometry
validation are not measured here. [The profiling process]({NAME}/cost-profile-process.json)
closes normally in {profile_process['complete_seconds']:.6f} s, peak committed memory
{profile_process['job']['peak_job_committed_memory']:,} bytes.

[Next]({NAME}/next-step.json), prepare and independently validate an original-source
primary-tier initializer under all nineteen closed keys, then assess its actual
cost and model/source/output costs before freezing a search contract. The retained
original-source preparation charge remains
36.028144 s plus new work. No optimizer call, initializer, search contract, native
call or allocation exclusion follows this validation. Four arrangements and all
440 allocation candidates remain unresolved.

The preceding checkpoint reached main **831ad47e** through an ordinary atomic
push after all six prior checks passed, preserving 52 protected files.
[The receipt]({NAME}/prior-main-push-receipt.json) and [current CI snapshot]({NAME}/main-ci-at-review.json)
are retained ({success} passed, {live} live at review). Product code, README claims
and releases remain unchanged. This checkpoint awaits the next ordinary push gate.

[Archive verification]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical evidence]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 complete tier selector preflight:** [exact tier, deadline and isolation evidence]({{link}}) verifies all 5,911 primary / 23,419 extended proposals and 2,854 keys per tier in source and closed-runtime contexts. Both full outputs match independent score references. Twenty-six synthetic and three real deadline cases preserve complete-primary-only fallback; two different-best controls discard a better partial extension candidate. Snapshot isolation, one-shot extension, six stale-cache rejections and incomplete/mixed-tier policy controls pass. Ten fixed-order timing samples retain variability without a stable budget claim. A separate three-call phase profile reproduces all primary outputs, identifies center geometry as the main runtime cost and measures complete output serialization. Next prepare and independently audit the original-source initializer and full budget before any search. All 19 keys and prior searches remain closed; no optimizer call or new source model follows. Retained preparation is 36.028144 s plus new work. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. Prior checkpoint reached main 831ad47e after all 6 checks passed, preserving 52 files; fresh CI has {success} passed / {live} live at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [complete tier selector preflight](../benchmarks/results/{NAME}.md).
The complete 5,911-proposal primary tier and 23,419-proposal extension reproduce both
source and closed-runtime references, covering all 2,854 keys per tier. Twenty-six
synthetic and three real deadlines preserve selection from a fully completed tier.
Two different-best controls prove partial extension candidates cannot displace the
completed primary. Snapshot isolation, one-shot extension, six stale-cache cases
and membership/policy controls pass. Ten timing samples retain variability. A
separate three-call phase profile reproduces all outputs and finds center geometry
dominates runtime cost; serialization is measured separately. Next prepare and
independently audit the original-source initializer and full budget before a search.
All 19 problem keys remain closed, with 36.028144 s prior preparation retained plus
new work. The last search remains invalid with 55 source-pair failures. Four
arrangements and 440 allocations remain; H2/H5 stay at 60%. Main 831ad47e contains the
preceding checkpoint after all 6 prior checks passed, preserving 52 files. Fresh CI has
{success} passed / {live} live jobs at review. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
