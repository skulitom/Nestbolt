"""Prepare the three distinct original insert/cog domains once."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,subprocess,shutil,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-focused-other-regions-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    start=time.perf_counter();deadline=start+180;shutil.copyfile(__file__,OUT/'run.py');assert load(ROOT/'output/h5-single-cog-release-20261026/audit-recovered/checks.json')['passed']
    write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'start_perf_counter':start,'deadline_perf_counter':deadline,'shared_seconds':180,'per_case_seconds':60,'maximum_cases':3,'release_parts':[4,7,8],'solver_calls':0,'offline_not_production_qualification':True})
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [ROOT/'output/prove_h5_focused_other_regions.py',ROOT/'output/h5-single-cog-release-20261026/audit-recovered/checks.json',OUT/'helper-preparation.json']},'method':'Prepare exactly one complete insert/released-cog region census for each of original cogs57,64,65, using their correct original pair ordering. Three distinct cases under180 shared seconds,60 each; preserve caps and unfinished domains. All original counts and final66-part requirements remain unchanged; no solver/native call.'})
    results=[];pending=[]
    for part in [4,7,8]:
        if time.perf_counter()>=deadline:pending.append(part);continue
        began=time.perf_counter()
        try:
            p=subprocess.run([sys.executable,str(ROOT/'output/prove_h5_focused_other_regions.py'),str(part)],cwd=ROOT,capture_output=True,timeout=max(.01,min(65,deadline-time.perf_counter()+5)));(OUT/f'release-{part}-stdout.txt').write_bytes(p.stdout);(OUT/f'release-{part}-stderr.txt').write_bytes(p.stderr);write(OUT/f'release-{part}-process.json',{'seconds':time.perf_counter()-began,'exit_code':p.returncode});assert p.returncode==0,p.stderr.decode();r=load(OUT/f'release-{part}/result.json');results.append(r);print(r,flush=True)
        except subprocess.TimeoutExpired as e:
            (OUT/f'release-{part}-stdout.txt').write_bytes(e.stdout or b'');(OUT/f'release-{part}-stderr.txt').write_bytes(e.stderr or b'');write(OUT/f'release-{part}-process.json',{'seconds':time.perf_counter()-began,'timeout':True});pending.append(part);break
    pending=sorted(set(pending+[p for p in [4,7,8] if p not in [r['released_cog_part'] for r in results]]));write(OUT/'results.json',results);write(OUT/'pending-cases.json',pending);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'completed_cases':len(results),'pending_cases':len(pending),'pending_domains':sum(r['pending_domains'] for r in results),'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
if __name__=='__main__':main()
