"""Complete necessary bracket/released-cog compatibility for three focused cases."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil,math,traceback
from prove_h5_fixed_six_completion import apply_clause,encode_many
from prove_h5_top_cog_bracket_capacity import hull
ROOT=Path(__file__).resolve().parents[1];BR=ROOT/'output/h5-single-cog-release-20261026';CG=ROOT/'output/h5-focused-other-regions-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-focused-bracket-cog-pairs-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def parts(rows,family):
    out=[]
    for row in rows:
        if row['family']!=family:continue
        for i,p in enumerate(row['fragments']):
            poly=[(F(*v[0]),F(*v[1])) for v in p];xs=[v[0] for v in poly];ys=[v[1] for v in poly]
            out.append({'query':row['query'],'domain_row':row['domain_row'],'domain_index':row['domain_index'],'fragment':i,'poly':poly,'outward_bounds':[math.floor(min(xs)),math.floor(min(ys)),math.ceil(max(xs)),math.ceil(max(ys))]})
    return out
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=start+120;spec=load(SOURCE/'plan.json');lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']};inputs=[SOURCE/'plan.json',ROOT/'output/prove_h5_fixed_six_completion.py',ROOT/'output/prove_h5_top_cog_bracket_capacity.py']
    for p in [4,7,8]:
        for base in [BR,CG]:
            assert load(base/f'release-{p}/audit/checks.json')['passed'];inputs.extend([base/f'release-{p}/audit/checks.json',base/f'release-{p}/audit/verified-residuals.json'])
    needed=sorted({lookup[spec['queries'][r['query']]['profile'],9] for p in [4,7,8] for r in load(BR/f'release-{p}/audit/verified-residuals.json')});inputs.extend(SOURCE/'mutual'/f'{i:03d}.json' for i in needed)
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'release_parts':[4,7,8],'original_items':[57,64,65],'proof_limit_seconds':120,'maximum_residual_fragments_per_pair':50000,'solver_calls':0,'method':'Before any focused search, test the necessary coexistence of one original bracket and the released original cog over all independently verified residual fragments, including lower-dimensional fragments. Enumerate every Cartesian pair for each release. Different-sheet pairs remain possible. For same-sheet pairs, form an outward integer enclosure of the complete real displacement B(cog)-A(bracket), rounding minima down/maxima up. A whole-box rejection requires strict failure of every original outside edge of one full guarded source face. Otherwise form the exact rational Minkowski difference hull from all vertex differences and clip against every complete original separation clause, preserving all closed boundaries. Preserve every nonempty, empty or unfinished result. Empty differences are conditional on the other five cog positions and original source domains only; all66 originals, the released cog, both brackets and insert remain mandatory. No solver/native call or production-budget qualification.'})
    mutual={i:load(SOURCE/'mutual'/f'{i:03d}.json') for i in needed};summaries=[];pending=[]
    for part in [4,7,8]:
        arows=parts(load(BR/f'release-{part}/audit/verified-residuals.json'),'bracket');brows=parts(load(CG/f'release-{part}/audit/verified-residuals.json'),'cog');records=[]
        for i,j in product(range(len(arows)),range(len(brows))):
            if time.perf_counter()>=deadline:pending.append({'released_part':part,'fragments':[i,j]});continue
            a,b=arows[i],brows[j];qa,qb=spec['queries'][a['query']],spec['queries'][b['query']];case=lookup[qa['profile'],qb['profile']];row={'fragments':[i,j],'queries':[a['query'],b['query']],'domain_rows':[a['domain_row'],b['domain_row']],'local_fragments':[a['fragment'],b['fragment']],'mutual_case':case}
            if qa['sheet']!=qb['sheet']:row.update({'status':'DIFFERENT_SHEETS','excluded':False});records.append(row);continue
            u,v=a['outward_bounds'],b['outward_bounds'];r=[v[0]-u[2],v[1]-u[3],v[2]-u[0],v[3]-u[1]];bad=None
            for fi,face in enumerate(mutual[case]['faces']):
                if all(h['a']*(r[2] if h['a']>=0 else r[0])+h['b']*(r[3] if h['b']>=0 else r[1])<h['bound'] for h in face['outside_halfplanes']):bad=fi;break
            row['outward_difference_bounds']=r
            if bad is not None:row.update({'status':'WHOLE_DIFFERENCE_BOX_EXCLUDED','failed_face':bad,'excluded':True})
            else:
                d=hull([(v[0]-u[0],v[1]-u[1]) for u,v in product(a['poly'],b['poly'])]);polys=[tuple(d)];events=[];done=0
                for fi,face in enumerate(mutual[case]['faces']):
                    if not polys:break
                    if time.perf_counter()>=deadline or len(polys)>50000:pending.append({'released_part':part,'fragments':[i,j],'partial':True});break
                    after=apply_clause(polys,[[-h['a'],-h['b'],-h['bound']] for h in face['outside_halfplanes']]);done+=1
                    if after!=polys:events.append({'face':fi,'before_count':len(polys),'after':encode_many(after)})
                    polys=after
                status='CONTINUOUS_DIFFERENCE_EXCLUDED' if not polys else 'DIFFERENCE_RESIDUAL' if done==len(mutual[case]['faces']) else 'UNRESOLVED_CAP'
                row.update({'status':status,'difference_hull':encode_many([d])[0],'events':events,'completed_faces':done,'residual':encode_many(polys),'excluded':not polys})
            records.append(row)
        write(OUT/f'release-{part}-pairs.json',records);summary={'released_part':part,'bracket_fragments':len(arows),'cog_fragments':len(brows),'planned_pairs':len(arows)*len(brows),'completed_pairs':sum(r['status']!='UNRESOLVED_CAP' for r in records),'box_excluded':sum(r['status']=='WHOLE_DIFFERENCE_BOX_EXCLUDED' for r in records),'continuously_excluded':sum(r['status']=='CONTINUOUS_DIFFERENCE_EXCLUDED' for r in records),'possible_pairs':sum(r['status'] in ['DIFFERENCE_RESIDUAL','DIFFERENT_SHEETS'] for r in records),'all_original_bracket_cog_pairs_excluded':len(records)==len(arows)*len(brows) and all(r['excluded'] for r in records)};summaries.append(summary);print(summary,flush=True)
    write(OUT/'summary.json',summaries);write(OUT/'pending-pairs.json',pending);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'planned_pairs':sum(r['planned_pairs'] for r in summaries),'completed_pairs':sum(r['completed_pairs'] for r in summaries),'pending_pairs':len(pending),'box_excluded':sum(r['box_excluded'] for r in summaries),'continuously_excluded':sum(r['continuously_excluded'] for r in summaries),'possible_pairs':sum(r['possible_pairs'] for r in summaries),'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
