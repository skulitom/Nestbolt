"""Independent complete conditional bracket/cog non-coexistence certificates."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil,math
from audit_h5_fixed_six_completion import union_clause,encode_many
from audit_h5_top_cog_bracket_capacity import gift_wrap
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-focused-bracket-cog-pairs-20261026';OUT=BASE/'audit';BR=ROOT/'output/h5-single-cog-release-20261026';CG=ROOT/'output/h5-focused-other-regions-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def flatten(rows,family):
    out=[]
    for r in rows:
        if r['family']!=family:continue
        for i,values in enumerate(r['fragments']):out.append({'query':r['query'],'domain_row':r['domain_row'],'fragment':i,'points':[(F(*v[0]),F(*v[1])) for v in values]})
    return out
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');assert result['pending_pairs']==0 and load(BASE/'pending-pairs.json')==[]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify committed bracket residuals and original mutual sources, exact audited released-cog residuals, and complete Cartesian pair inventories for all three release cases. Recompute outward boxes with rational floor/ceiling and evaluate every original source outside inequality at all four box corners for each rejected box. Independently construct every remaining real difference hull by gift wrapping and replay every full-source union with candidate-vertex/convex-hull clipping. Retain all line/point boundaries. A proved empty pair set excludes only the corresponding single-cog-position release with the other five poses and original source domains fixed. No solver/native call or unrestricted packing claim.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-fixed-six-completion-20261026/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']};older=load(ROOT/'benchmarks/results/h5-bounded-source-search-20261026/raw-manifest.json');oldknown={r['path']:r['sha256'] for r in older['files']+older['aliases']};spec=load(SOURCE/'plan.json');counts={'ordered_pairs':0,'whole_box_exclusions':0,'exact_hull_exclusions':0,'corner_inequalities':0,'changed_clause_events':0};summary=[]
    for part in [4,7,8]:
        for n in ['audit/checks.json','audit/verified-residuals.json']:
            p=BR/f'release-{part}'/n;assert digest(p)==known[p.relative_to(ROOT/'output').as_posix()]
        assert load(CG/f'release-{part}/audit/checks.json')['passed']
        for n,h in load(CG/f'release-{part}/audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
        aa=flatten(load(BR/f'release-{part}/audit/verified-residuals.json'),'bracket');bb=flatten(load(CG/f'release-{part}/audit/verified-residuals.json'),'cog');rows=load(BASE/f'release-{part}-pairs.json');assert [r['fragments'] for r in rows]==[list(v) for v in product(range(len(aa)),range(len(bb)))];boxcount=exactcount=0
        for row in rows:
            i,j=row['fragments'];a,b=aa[i],bb[j];assert row['queries']==[a['query'],b['query']] and row['domain_rows']==[a['domain_row'],b['domain_row']] and row['local_fragments']==[a['fragment'],b['fragment']];qa,qb=spec['queries'][a['query']],spec['queries'][b['query']];assert qa['sheet']==qb['sheet'];case=next(c['index'] for c in spec['mutual_cases'] if c['profile_a']==qa['profile'] and c['profile_b']==qb['profile']);assert case==row['mutual_case'];source=SOURCE/'mutual'/f'{case:03d}.json';assert digest(source)==oldknown['source-inputs/'+source.relative_to(ROOT).as_posix()];faces=load(source)['faces']
            def bounds(poly):return [math.floor(min(x for x,y in poly)),math.floor(min(y for x,y in poly)),math.ceil(max(x for x,y in poly)),math.ceil(max(y for x,y in poly))]
            u,v=bounds(a['points']),bounds(b['points']);r=[v[0]-u[2],v[1]-u[3],v[2]-u[0],v[3]-u[1]];assert r==row['outward_difference_bounds'];corners=list(product([r[0],r[2]],[r[1],r[3]]))
            assert all(r[0]<=y[0]-x[0]<=r[2] and r[1]<=y[1]-x[1]<=r[3] for x,y in product(a['points'],b['points']))
            if row['status']=='WHOLE_DIFFERENCE_BOX_EXCLUDED':
                for h in faces[row['failed_face']]['outside_halfplanes']:
                    for x,y in corners:assert h['a']*x+h['b']*y<h['bound'];counts['corner_inequalities']+=1
                boxcount+=1
            else:
                assert row['status']=='CONTINUOUS_DIFFERENCE_EXCLUDED';d=gift_wrap([(y[0]-x[0],y[1]-x[1]) for x,y in product(a['points'],b['points'])]);assert encode_many([d])[0]==row['difference_hull'];polys=[tuple(d)];events=[];done=0
                for fi,face in enumerate(faces):
                    if not polys:break
                    after=union_clause(polys,[(-h['a'],-h['b'],-h['bound']) for h in face['outside_halfplanes']]);done+=1
                    if after!=polys:events.append({'face':fi,'before_count':len(polys),'after':encode_many(after)})
                    polys=after
                assert not polys and row['residual']==[] and events==row['events'] and done==row['completed_faces'];exactcount+=1;counts['changed_clause_events']+=len(events)
            assert row['excluded'];counts['ordered_pairs']+=1
        counts['whole_box_exclusions']+=boxcount;counts['exact_hull_exclusions']+=exactcount;summary.append({'released_part':part,'bracket_fragments':len(aa),'cog_fragments':len(bb),'planned_pairs':len(rows),'completed_pairs':len(rows),'box_excluded':boxcount,'continuously_excluded':exactcount,'possible_pairs':0,'all_original_bracket_cog_pairs_excluded':True})
    assert summary==load(BASE/'summary.json') and counts['ordered_pairs']==result['planned_pairs']==result['completed_pairs']==2362 and counts['whole_box_exclusions']==result['box_excluded']==2072 and counts['exact_hull_exclusions']==result['continuously_excluded']==290
    write(OUT/'conditional-no-single-cog-completion.json',{'proved':True,'previous_fixed_six_and_other_release_certificates':'benchmarks/results/h5-fixed-six-completion-20261026.md','newly_excluded_released_original_cogs':[57,64,65],'newly_excluded_released_parts':[4,7,8],'bracket_released_cog_fragment_pairs':2362,'scope':'For each of original cogs57,64,65, keep the other five witness cog poses and the57 source placements fixed. No original bracket anchor in its complete recorded inward regions can coexist with any anchor of the released cog satisfying the original full guarded source clauses. Therefore no such single-cog-position release can complete all66 originals. Combined with the earlier no-bracket/capacity proofs for releases54,58,62, no change to just one cog position completes the layout within the recorded orientations/domains. At least two cog positions, another fixed source pose, or source orientation/domain inventory must change. No claim about unrestricted packing or changing multiple poses is made.','all66_originals_still_required':True,'must_not_apply_to_two_or_more_released_cogs':True,'full_target_witness':False,'H5_complete':False})
    checks={'passed':True,'seconds':time.perf_counter()-start,**counts,'complete_cases_verified':3,'all_source_pair_directions_preserved':True,'all_rational_boundaries_retained':True,'all_single_cog_releases_conditionally_excluded_with_prior_proofs':True,'no_focused_solver_needed_for_these_proved_empty_cases':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
