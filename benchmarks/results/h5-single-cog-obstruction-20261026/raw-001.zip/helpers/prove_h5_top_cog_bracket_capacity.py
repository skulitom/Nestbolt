"""Complete two-bracket capacity check when only original cog58 is released."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
from prove_h5_fixed_six_completion import apply_clause,encode_many,canon
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';PREP=ROOT/'output/h5-single-cog-release-20261026/release-5';OUT=ROOT/'output/h5-top-cog-bracket-capacity-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def hull(points):
    pts=sorted(set(points));halves=[]
    for seq in [pts,pts[::-1]]:
        chain=[]
        for p in seq:
            while len(chain)>=2:
                a,b=chain[-2:]
                if (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>0:break
                chain.pop()
            chain.append(p)
        halves.append(chain)
    return canon(halves[0][:-1]+halves[1][:-1]) if len(pts)>1 else pts
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();assert load(PREP/'audit/checks.json')['passed'];residuals=load(PREP/'audit/verified-residuals.json');assert len(residuals)==14 and all(r['query']==8 and len(r['fragments'])==1 for r in residuals)
    spec=load(SOURCE/'plan.json');profile=spec['queries'][8]['profile'];case=next(c['index'] for c in spec['mutual_cases'] if c['profile_a']==c['profile_b']==profile);mutual=load(SOURCE/'mutual'/f'{case:03d}.json')
    inputs=[PREP/'audit/checks.json',PREP/'audit/verified-residuals.json',PREP/'plan.json',SOURCE/'plan.json',SOURCE/'mutual'/f'{case:03d}.json',ROOT/'output/prove_h5_fixed_six_completion.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_mutual_case':case,'released_original_item':58,'fixed_other_cogs':5,'originals_required':66,'maximum_seconds':120,'solver_calls':0,'method':'Both missing original brackets must belong to the complete14 independently verified query8 residual polygons when only cog58 changes position. Enumerate all196 ordered polygon pairs, including same-cell pairs. Form the exact rational convex difference hull B-A from every vertex difference. Apply every original full guarded bracket/bracket outside clause to that entire difference polygon via exact rational closed-halfplane unions. Preserve every line/point residual and changed clause. If all differences are empty, at most one bracket can fit with the other five cog positions fixed, even before replacing cog58 or the insert. This is conditional source-domain geometry, never an unconditional exclusion or part-count reduction.'})
    polys=[[(F(*p[0]),F(*p[1])) for p in r['fragments'][0]] for r in residuals];records=[]
    for i,j in product(range(14),repeat=2):
        assert time.perf_counter()-start<120;d=hull([(b[0]-a[0],b[1]-a[1]) for a,b in product(polys[i],polys[j])]);active=[tuple(d)];events=[]
        for fi,face in enumerate(mutual['faces']):
            if not active:break
            after=apply_clause(active,[[-h['a'],-h['b'],-h['bound']] for h in face['outside_halfplanes']])
            if after!=active:events.append({'face':fi,'before_count':len(active),'after':encode_many(after)})
            active=after
        records.append({'residual_rows':[i,j],'domain_rows':[residuals[i]['domain_row'],residuals[j]['domain_row']],'difference_hull':encode_many([d])[0],'events':events,'residual':encode_many(active),'excluded':not active})
    write(OUT/'ordered-pair-proofs.json',records);result={'seconds':time.perf_counter()-start,'complete_ordered_residual_pairs':196,'excluded_pairs':sum(r['excluded'] for r in records),'remaining_pairs':sum(not r['excluded'] for r in records),'changed_clause_events':sum(len(r['events']) for r in records),'at_most_one_original_bracket':all(r['excluded'] for r in records),'conditional_on_other_five_cog_positions':True,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
