"""Independent exact difference-hull and all196 bracket-pair proof replay."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
from audit_h5_fixed_six_completion import union_clause,encode_many
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-top-cog-bracket-capacity-20261026';OUT=BASE/'audit';PREP=ROOT/'output/h5-single-cog-release-20261026/release-5';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def gift_wrap(points):
    points=sorted(set(points))
    if len(points)<2:return points
    start=points[0];out=[];p=start
    while True:
        out.append(p);q=next(v for v in points if v!=p)
        for r in points:
            if r==p:continue
            cross=(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]);qd=(q[0]-p[0])**2+(q[1]-p[1])**2;rd=(r[0]-p[0])**2+(r[1]-p[1])**2
            if cross<0 or cross==0 and rd>qd:q=r
        p=q
        if p==start:return out
        assert len(out)<=len(points)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'ordered-pair-proofs.json',BASE/'result.json',ROOT/'output/audit_h5_fixed_six_completion.py']},'method':'Reconstruct every complete rational Minkowski difference using independent gift wrapping of all vertex differences. Independently replay all original full guarded outside-clause unions with candidate-vertex/convex-hull clipping. Compare all196 ordered cases including same-cell cases, every event and every retained boundary. Verify the preceding full14-domain release census and source mutual file provenance. No solver/native call. Capacity is conditional on original query8 domains and the other five cog poses.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    source=SOURCE/'mutual'/f"{plan['source_mutual_case']:03d}.json";manifest=load(ROOT/'benchmarks/results/h5-bounded-source-search-20261026/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']};assert digest(source)==known['source-inputs/'+source.relative_to(ROOT).as_posix()]
    prior=load(PREP/'audit/checks.json');assert prior['passed'] and prior['recorded_domains']==2418 and prior['residual_domains']==14 and prior['residual_fragments']==14
    rows=load(PREP/'audit/verified-residuals.json');assert len(rows)==14 and all(r['query']==8 and len(r['fragments'])==1 for r in rows);polys=[[(F(*p[0]),F(*p[1])) for p in row['fragments'][0]] for row in rows];mutual=load(source);records=load(BASE/'ordered-pair-proofs.json');assert [r['residual_rows'] for r in records]==[list(v) for v in product(range(14),repeat=2)];events_count=0
    for row in records:
        i,j=row['residual_rows'];assert row['domain_rows']==[rows[i]['domain_row'],rows[j]['domain_row']];difference=gift_wrap([(b[0]-a[0],b[1]-a[1]) for a,b in product(polys[i],polys[j])]);assert encode_many([difference])[0]==row['difference_hull'];pieces=[tuple(difference)];events=[]
        for fi,face in enumerate(mutual['faces']):
            if not pieces:break
            after=union_clause(pieces,[(-h['a'],-h['b'],-h['bound']) for h in face['outside_halfplanes']])
            if after!=pieces:events.append({'face':fi,'before_count':len(pieces),'after':encode_many(after)})
            pieces=after
        assert events==row['events'] and encode_many(pieces)==row['residual']==[] and row['excluded'];events_count+=len(events)
    checks={'passed':True,'seconds':time.perf_counter()-start,'ordered_pairs_verified':196,'all_vertex_difference_hulls_independently_verified':True,'changed_clause_events_verified':events_count,'empty_complete_difference_regions':196,'point_and_line_boundaries_retained':True,'at_most_one_original_bracket':True,'two_original_brackets_required':True,'conditional_on_releasing_only_original_cog58_position':True,'does_not_exclude_other_poses_or_angles':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);write(OUT/'at-most-one-certificate.json',{'proved':True,'capacity':1,'required_original_brackets':2,'released_original_cog_item':58,'fixed_other_cog_items':[54,57,62,64,65],'original_query':8,'complete_residual_domains':14,'complete_ordered_pairs':196,'scope':'With the five recorded other cog poses and57 original fixed placements unchanged, releasing only cog58 leaves space for at most one original bracket in the recorded original inward domains. Thus that single release cannot complete all66 originals, even without placing the released cog or missing insert. Moving another source pose or changing source orientations/domains is outside this certificate.','unrestricted_impossibility_claim':False,'full_target_witness':False,'H5_complete':False});print(checks,flush=True)
if __name__=='__main__':main()
