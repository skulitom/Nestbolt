"""Prepare insert/released-cog region diagnostics with original pair direction."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-focused-other-regions-20261026';OUT.mkdir();records=[]
source=ROOT/'output/prove_h5_single_cog_release.py';s=source.read_text(encoding='utf-8')
changes={"PART in range(3,9)":"PART in [4,7,8]",'h5-single-cog-release-20261026':'h5-focused-other-regions-20261026',"spec['parts'][:2]":"[spec['parts'][2],spec['parts'][PART]]","queries==list(range(16))":"queries==list(range(16,20))","'planned_queries':16":"'planned_queries':4",
"[[h['a'],h['b'],h['a']*cog['x_units']+h['b']*cog['y_units']-h['bound']] for h in face['outside_halfplanes']]":"[[sign*h['a'],sign*h['b'],sign*(h['a']*cog['x_units']+h['b']*cog['y_units'])-h['bound']] for h in face['outside_halfplanes']]",
"            for fi,face in enumerate(mutual['faces']):":"            moving_part=2 if q['family']=='insert' else PART;sign=1 if moving_part<cog['part'] else -1\n            for fi,face in enumerate(mutual['faces']):"}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
begin=s.index("        'method':");end=s.index("})\n    completed",begin)
s=s[:begin]+"        'method':'Distinct focused diagnostic for the insert and released original cog, against the five other fixed cog poses and the original57-fixed source domains. Examine all4 original queries16..19 and all1105 domains, with exact full guarded source clauses and rational clipping preserving boundaries/lines/points. For a moving part before the fixed cog in original pair order, transform outside(a*(fixed-moving)>=bound) to a*moving<=a*fixed-bound. For the released cog after a fixed cog, reverse coefficients and use -a*moving<=-a*fixed-bound. Preserve all source angles and originals; no fresh inset, grid sample or geometry simplification. Bracket residuals are separately committed. All66 originals remain mandatory. This is offline preparation, not production-budget or full-layout qualification. No solver/native call.'"+s[end:]
target=ROOT/'output/prove_h5_focused_other_regions.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'replacements':changes})
source=ROOT/'output/audit_h5_single_cog_release.py';s=source.read_text(encoding='utf-8');changes={"PART in range(3,9)":"PART in [4,7,8]",'h5-single-cog-release-20261026':'h5-focused-other-regions-20261026',"spec['parts'][:2]":"[spec['parts'][2],spec['parts'][PART]]","==list(range(16))":"==list(range(16,20))","==result['planned_domains']==2418":"==result['planned_domains']==1105",
"            for fi,face in enumerate(mutual['faces']):":"            moving_part=2 if q['family']=='insert' else PART\n            for fi,face in enumerate(mutual['faces']):",
"[[h['a'],h['b'],h['a']*cog['x_units']+h['b']*cog['y_units']-h['bound']] for h in face['outside_halfplanes']]":"[([h['a'],h['b'],h['a']*cog['x_units']+h['b']*cog['y_units']-h['bound']] if moving_part<cog['part'] else [-h['a'],-h['b'],-h['a']*cog['x_units']-h['b']*cog['y_units']-h['bound']]) for h in face['outside_halfplanes']]",
"br=[s for s in summaries if s['family']=='bracket'];assert sum(s['planned_domains'] for s in br)==2418":"assert sum(s['planned_domains'] for s in summaries if s['family']=='insert')==338 and sum(s['planned_domains'] for s in summaries if s['family']=='cog')==767",
"'all2418_bracket_domains_examined':True":"'all1105_insert_and_cog_domains_examined':True",
"'all16_queries_and2418_original_domains_replayed':True":"'all4_queries_and1105_original_domains_replayed':True"}
for a,b in changes.items():assert s.count(a)>=1,a;s=s.replace(a,b)
s=s.replace('Residuals are conditional bracket regions with five cogs fixed and one cog position released. They do not place both brackets, the insert or the released cog and do not establish a66-original target layout.','Residuals are complete conditional original insert/cog regions with five cogs fixed. Source pair direction is preserved. They do not place both brackets, the insert and the released cog together or establish a66-original target layout.')
s=s.replace('Empty real domains certify no integer bracket anchor only with the five selected cog poses fixed; nonempty residuals do not place both brackets or the released cog.','Empty real domains certify no insert/cog anchor only with the five selected cog poses fixed; nonempty residuals do not establish simultaneous completion.')
target=ROOT/'output/audit_h5_focused_other_regions.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'replacements':changes})
with (OUT/'helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'generated_helpers':records,'distinct_release_cases':[4,7,8],'queries':[16,17,18,19],'solver_calls':0},f,indent=2);f.write('\n')
print({'root':str(OUT),'helpers':2})
