"""Finite staggered row groups using original filled outer Minkowski contacts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import math,itertools,json,time,shutil,traceback
from shapely.geometry import Polygon,LineString,mapping
from shapely.affinity import affine_transform
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;gap=base.gap;load=base.load;write=gap.write;digest=base.digest
SRC=ROOT/'output/h5-cog-lattices-20261018';OUT=ROOT/'output/h5-ragged-cogs-20261018'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py')
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'source_digest':gap.source_digest(),'script_sha256':digest(Path(__file__)),
          'inputs':{str(SRC.relative_to(ROOT)/n):digest(SRC/n) for n in ['job.json','library.json','request.json','original.json','conditional-target.json','all-patterns.json']},
          'base_angles_degrees':[0,4.5,9],'row_phase_degrees':[0,3,6,9,12,15],'half_pitch_offsets_mm':[-6,0,6],
          'row_counts':[[5,4,5],[5,4,4],[5,4,3],[5,4,2],[5,4,1],[5,4]],'construction_clearance_mm':.22,'pitch_increment_mm':.0001,'generation_seconds_limit':120,
          'method':'Alternate entire rows between two actual cog orientations. The same-row pitch is the maximum positive or negative horizontal extent of both self Minkowski obstacles at zero vertical separation. Shift odd rows by half that pitch plus a declared offset. The adjacent-row pitch is the maximum absolute vertical extent of A-B obstacle slices at every integer column displacement from -5 through +5 plus the row shift. Ensure two-row spacing clears same-orientation vertical extents. Independently check every component pair. Retain minimum rectangle-area valid variant separately for each row-count list for a later exact-inventory model. This is a finite construction, not unrestricted feasibility or H5 evidence.'}
    assert plan['source_digest']=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88';write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};cog=shapes['cog'];cx,cy=cog.centroid.coords[0];centered=affine_transform(cog,[1,0,0,1,-cx,-cy]);cache={};patterns={};variants=[];pairchecks=0;queries=0;expired=False;t0=time.perf_counter();(OUT/'obstacles').mkdir()
    def obstacle(a,b):
        nonlocal queries
        key=(a,b)
        if key not in cache:
            sa=gap.pose(centered,base.transform(math.radians(a)));sb=gap.pose(centered,base.transform(math.radians(b)));cache[key]=gap.obstacle(sa,sb,plan['construction_clearance_mm']);queries+=1;write(OUT/'obstacles'/f'{a}-{b}.json',mapping(cache[key]))
        return cache[key]
    for angle,phase in itertools.product(plan['base_angles_degrees'],plan['row_phase_degrees']):
        if time.perf_counter()-t0>=plan['generation_seconds_limit']:expired=True;break
        aa=obstacle(angle,angle);bb=obstacle(angle+phase,angle+phase);ab=obstacle(angle,angle+phase);horizontal=[p.intersection(LineString([(-1000,0),(1000,0)])).bounds for p in [aa,bb]];dx=max(max(-q[0],q[2]) for q in horizontal)+plan['pitch_increment_mm'];vertical=[p.intersection(LineString([(0,-1000),(0,1000)])).bounds for p in [aa,bb]]
        for delta in plan['half_pitch_offsets_mm']:
            offset=dx/2+delta;slices=[]
            for k in range(-5,6):
                x=k*dx+offset;s=ab.intersection(LineString([(x,-1000),(x,1000)]))
                if not s.is_empty:slices.append({'column_difference':k,'x':x,'bounds':list(s.bounds)})
            assert slices;dy=max(max(abs(q['bounds'][1]),abs(q['bounds'][3])) for q in slices)+plan['pitch_increment_mm'];dy=max(dy,max(max(abs(q[1]),abs(q[3]))/2 for q in vertical)+plan['pitch_increment_mm'])
            ident=f'b{angle}-p{phase}-d{delta}';variant={'id':ident,'base':angle,'phase':phase,'offset_adjustment':delta,'row_shift':offset,'pitch':[dx,dy],'slices':slices,'patterns':[]}
            for counts in plan['row_counts']:
                members=[]
                for row,count in enumerate(counts):
                    theta=math.radians(angle+(row%2)*phase);c,s=math.cos(theta),math.sin(theta)
                    for col in range(count):
                        x=col*dx+(row%2)*offset;y=row*dy;members.append(base.member('cog',base.transform(theta,x-c*cx+s*cy,y-s*cx-c*cy)))
                p=base.pattern(ident+'-rows'+'-'.join(map(str,counts)),members,shapes);geoms=[gap.pose(cog,m['transform']) for m in p['members']];bad=[];minimum=math.inf
                for i,j in itertools.combinations(range(len(geoms)),2):
                    pairchecks+=1;d=geoms[i].distance(geoms[j]);minimum=min(minimum,d)
                    if not geoms[i].disjoint(geoms[j]) or d<job['clearance']:bad.append([i,j,d,geoms[i].intersection(geoms[j]).area])
                p['construction']={'variant':ident,'row_counts':counts,'count':sum(counts),'minimum_distance_mm':minimum,'violations':bad};patterns[p['id']]=p;variant['patterns'].append(p['id'])
            variants.append(variant)
    selected=[]
    for rows in plan['row_counts']:
        candidates=[p for p in patterns.values() if p['construction']['row_counts']==rows and not p['construction']['violations']];assert candidates
        p=min(candidates,key=lambda p:(p['width']*p['height'],p['width'],p['id']));selected.append({'pattern':p['id'],'rows':rows,'cogs':sum(rows),'remaining_cogs':15-sum(rows),'width':p['width'],'height':p['height'],'padded_area_mm2':(p['width']+.22)*(p['height']+.22)})
    write(OUT/'patterns.json',patterns);write(OUT/'variants.json',variants);write(OUT/'selection.json',selected)
    result={'seconds':time.perf_counter()-t0,'expired':expired,'variants':len(variants),'components':len(patterns),'valid_components':sum(not p['construction']['violations'] for p in patterns.values()),'pair_checks':pairchecks,'obstacle_queries':queries,'center':[cx,cy],'selected':selected};write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
