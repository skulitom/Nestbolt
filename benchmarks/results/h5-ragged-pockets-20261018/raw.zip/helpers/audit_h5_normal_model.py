"""Independent Boolean-array coordinate generation and exact model difference audit."""
from pathlib import Path
from hashlib import sha256
import json,math,bisect
import numpy as np
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-ragged-separator-cpsat-20261018';OUT=ROOT/'output/h5-ragged-normal-cpsat-20261018';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    old=text_format.Parse((BASE/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());new=text_format.Parse((OUT/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());plan=load(OUT/'plan.json');p=load(OUT/'patterns.json');mapping=load(OUT/'mapping.json');coords=load(OUT/'normal-coordinates.json');g=plan['block_gap_mm'];scale=plan['scale_per_mm'];W=mapping['W'];Hs=mapping['Hs']
    assert plan['normal_baseline_model_sha256']==sha256((BASE/'model.pbtxt').read_bytes()).hexdigest();assert (BASE/'patterns.json').read_bytes()==(OUT/'patterns.json').read_bytes() and (BASE/'mapping.json').read_bytes()==(OUT/'mapping.json').read_bytes()
    for sheet in [0,1]:
        for axis,cap in [('x',W),('y',Hs[sheet])]:
            total=np.zeros(cap+1,dtype=np.bool_)
            for recipe in plan['recipes']:
                possible=np.zeros(cap+1,dtype=np.bool_);possible[0]=True
                for name,qty in sorted(recipe['recipe'].items()):
                    q=p[name];dims=set()
                    for rot in [False,True]:
                        w,h=(q['height'],q['width']) if rot else (q['width'],q['height']);wi=math.ceil((w+g)*scale);hi=math.ceil((h+g)*scale)
                        if wi<=W and hi<=Hs[sheet]:dims.add(wi if axis=='x' else hi)
                    for _ in range(qty):
                        prior=possible.copy()
                        for d in dims:possible[d:] |= prior[:-d]
                total |= possible
            expected=np.flatnonzero(total).tolist();assert expected==coords[f'{sheet}-{axis}']
    normalized=cp_model_pb2.CpModelProto();normalized.CopyFrom(new);changed=set();values=0
    for item in mapping['items']:
        for r in item['choices']:
            for axis in ['x','y']:
                vi=r[axis+'_var'];maximum=(W-r['width_units']) if axis=='x' else (Hs[r['sheet']]-r['height_units']);allowed=coords[f"{r['sheet']}-{axis}"];allowed=allowed[:bisect.bisect_right(allowed,maximum)];domain=[]
                for value in allowed:
                    if domain and value==domain[-1]+1:domain[-1]=value
                    else:domain.extend([value,value])
                assert list(new.variables[vi].domain)==domain;assert list(old.variables[vi].domain)==[0,maximum];del normalized.variables[vi].domain[:];normalized.variables[vi].domain.extend([0,maximum]);changed.add(vi);values+=len(allowed)
    assert normalized.SerializeToString(deterministic=True)==old.SerializeToString(deterministic=True)
    result={'independent_boolean_array_domains_equal':True,'domain_counts':{k:len(v) for k,v in coords.items()},'coordinate_variables':len(changed),'per_variable_values_total':values,'all_other_model_bytes_exact':True,'feasibility_preservation_argument':'Left-compaction at fixed y yields each x from a chain of earlier positive-width rectangles ending at zero. Down-compaction at fixed x yields each y from a positive-height chain ending at zero; x values remain unchanged. Every chain uses each coexisting item at most once in an allowed orientation. Domain generation includes all recipe chains. Relabel identical copies afterward to restore their ordering. A horizontal separator already at (0,0) cannot move farther left/down; other objects remain separated by the same nonoverlap constraints.','baseline_audit':load(BASE/'model-audit.json'),'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()};write(OUT/'model-audit.json',result);print(json.dumps({k:v for k,v in result.items() if k!='baseline_audit'}))
if __name__=='__main__':main()
