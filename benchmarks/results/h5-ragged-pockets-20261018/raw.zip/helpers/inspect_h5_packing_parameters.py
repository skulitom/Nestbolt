from pathlib import Path
from hashlib import sha256
import json
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-ragged-normal-cpsat-20261018';p=sat_parameters_pb2.SatParameters();names=[d.name for d in p.DESCRIPTOR.fields if 'no_overlap_2d' in d.name];doc=Path(sat_parameters_pb2.__file__).with_suffix('.pyi');lines=doc.read_text(encoding='utf-8').splitlines();selected=['use_timetabling_in_no_overlap_2d','use_energetic_reasoning_in_no_overlap_2d','use_area_energetic_reasoning_in_no_overlap_2d','use_try_edge_reasoning_in_no_overlap_2d','max_pairs_pairwise_reasoning_in_no_overlap_2d','no_overlap_2d_boolean_relations_limit'];result={'defaults':{n:getattr(p,n) for n in names},'installed_declaration_sha256':sha256(doc.read_bytes()).hexdigest(),'selected_declarations':{n:'\n'.join(lines[next(i for i,l in enumerate(lines) if l.strip().startswith(n+':')):next(i for i,l in enumerate(lines) if l.strip().startswith(n+':'))+9]) for n in selected if n in names},'observation_only_no_search':True}
with (OUT/'parameter-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result['defaults']))
