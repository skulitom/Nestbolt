from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Patch
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-ragged-pockets-20261018';MODEL=ROOT/'output/h5-ragged-pocket-cpsat-20261018';load=lambda p:json.loads(p.read_bytes())
job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};patterns=load(RUN/'components.json');recipes=load(RUN/'selected-recipes.json');kept={r['id'] for r in load(MODEL/'plan.json')['recipes']};colors={'cog':'#d88b45','insert':'#5d956f','bracket':'#437f9b'}
fig,axes=plt.subplots(2,3,figsize=(15,8.7));fig.subplots_adjust(wspace=.18,hspace=.35,top=.86,bottom=.10)
for ax,r in zip(axes.flat,recipes):
    p=patterns[r['id']]
    for member in p['members']:
        t=member['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;x,y=t['translation'];points=[(m*a*c-b*s+x,m*a*s+b*c+y) for a,b in parts[member['part_id']]['geometry'][0]['outer']];ax.add_patch(Polygon(points,facecolor=colors[member['part_id']],edgecolor='#293744',linewidth=.45))
    ax.add_patch(Rectangle((0,0),p['width'],p['height'],fill=False,linestyle='--',edgecolor='#536575'));ax.set_aspect('equal');ax.set_xlim(-25,1415);ax.set_ylim(-25,790);ax.tick_params(labelsize=8);title=' + '.join(f'{n} {k}s' for k,n in r['inventory'].items());ax.set_title(title+'\n'+('Whole-job rectangle area fits' if r['id'] in kept else 'Whole-job rectangle area exceeds capacity'),fontsize=10,color='#274b38' if r['id'] in kept else '#9a4b39');ax.set_xlabel('mm',fontsize=9)
fig.suptitle('Original inserts and brackets fitted into staggered cog pockets',fontsize=17,y=.97);fig.text(.5,.917,'324 cog components and 48 filled variants independently checked; these are components, not complete cutting layouts.',ha='center',fontsize=11)
fig.legend(handles=[Patch(color=c,label=k.capitalize()) for k,c in colors.items()],loc='lower center',bbox_to_anchor=(.5,.015),ncol=3,frameon=False);fig.savefig(RUN/'pockets.png',dpi=160,bbox_inches='tight');plt.close(fig)
