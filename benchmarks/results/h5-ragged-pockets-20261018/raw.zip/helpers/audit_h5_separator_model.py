"""Verify normalization inequalities and exact model identity after removing them."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-ragged-pocket-cpsat-20261018';OUT=ROOT/'output/h5-ragged-separator-cpsat-20261018';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    old=text_format.Parse((BASE/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());new=text_format.Parse((OUT/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());plan=load(OUT/'plan.json');p=load(OUT/'patterns.json');mapping=load(OUT/'mapping.json');proof=[];expected={};g=plan['block_gap_mm'];scale=plan['scale_per_mm'];W=mapping['W']
    assert sha256((BASE/'model.pbtxt').read_bytes()).hexdigest()==plan['baseline_model_sha256'];assert (BASE/'patterns.json').read_bytes()==(OUT/'patterns.json').read_bytes() and (BASE/'mapping.json').read_bytes()==(OUT/'mapping.json').read_bytes()
    for item in mapping['items']:
        if item['group'] is None or not item['pattern'].startswith('rows-'):continue
        rows=[r for r in item['choices'] if r['sheet']==0 and not r['rotated']];assert len(rows)==1;r=rows[0];pi=r['present_var'];wi=r['width_units'];hi=r['height_units'];checks=[]
        for name,qty in plan['recipes'][item['group']]['recipe'].items():
            if name==item['pattern'] or not qty:continue
            q=p[name];mw=min(math.ceil((q['width']+g)*scale),math.ceil((q['height']+g)*scale));assert wi+mw>W;checks.append({'pattern':name,'minimum_orientation_width':mw,'sum_width':wi+mw,'stock_width':W})
        proof.append({'item':item['item'],'pattern':item['pattern'],'padded_height':hi,'inequalities':checks})
        for axis in ['x','y']:expected[f"separator-origin-{axis}-{item['item']}"]=([pi],[r[axis+'_var']],[1],[0,0])
    retained=[];remap={};seen=set()
    for i,c in enumerate(new.constraints):
        if c.name.startswith('separator-origin-'):
            assert c.name in expected and c.name not in seen and c.WhichOneof('constraint')=='linear';seen.add(c.name);assert (list(c.enforcement_literal),list(c.linear.vars),list(c.linear.coeffs),list(c.linear.domain))==expected[c.name]
        else:remap[i]=len(retained);retained.append(c)
    assert seen==set(expected)
    normalized=cp_model_pb2.CpModelProto();normalized.CopyFrom(new);del normalized.constraints[:]
    for c in retained:
        q=normalized.constraints.add();q.CopyFrom(c)
        if q.WhichOneof('constraint')=='no_overlap_2d':
            for i,index in enumerate(q.no_overlap_2d.x_intervals):q.no_overlap_2d.x_intervals[i]=remap[index]
            for i,index in enumerate(q.no_overlap_2d.y_intervals):q.no_overlap_2d.y_intervals[i]=remap[index]
    assert normalized.SerializeToString(deterministic=True)==old.SerializeToString(deterministic=True)
    # Algebraic certificate: a below rectangle ends at <=Y and becomes <=Y+H;
    # an above rectangle starts at >=Y+H and remains fixed. Below starts >=H
    # after translation, and its end <=Y+H<=stockHeight. Thus the new [0,H]
    # separator is disjoint, and no pair or stock boundary is invalidated.
    result={'added_constraints':len(expected),'proofs':proof,'all_width_inequalities_verified':True,'stock_and_nonoverlap_preservation':'Translate every below rectangle by the integer padded separator height; leave every above rectangle fixed; place the separator at (0,0). All vertical order and stock inequalities follow from its original valid interval [Y,Y+H]. Horizontal coordinates of other rectangles stay unchanged. Width sums forbid horizontal separation, establishing the premise. Quarter-turned groups are untouched.','baseline_model_exact_after_removing_only_proven_symmetries':True,'baseline_audit':load(BASE/'model-audit.json'),'normalized_model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()};write(OUT/'model-audit.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['proofs','baseline_audit']}))
if __name__=='__main__':main()
