from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
import shutil
import subprocess
import zipfile
root=Path(__file__).resolve().parents[1]
out=root/'output/ci-lead-budget-20261017';out.mkdir()
def gh(*args):return subprocess.check_output(['gh',*args],cwd=root,timeout=120)
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
run=gh('run','view','39074673874','--json','status,conclusion,headSha,url,jobs')
state=json.loads(run);assert state['headSha']=='bf9e880184d9123a92311f173376d578a91e6eb7'
web=next(j for j in state['jobs'] if j['name']=='web');assert web['conclusion']=='failure'
(out/'run-at-inspection.json').write_bytes(run)
log=gh('api','repos/skulitom/Nestbolt/actions/jobs/117519249876/logs')
assert b'no complete layout within 1 s' in log and b'85 passed' in log
(out/'web-failure.log').write_bytes(log)
artifacts=gh('api','repos/skulitom/Nestbolt/actions/runs/39074673874/artifacts')
(out/'artifacts.json').write_bytes(artifacts)
artifact=next(a for a in json.loads(artifacts)['artifacts'] if a['name']=='browser-failure-diagnostics')
assert artifact['id']==12115983662 and not artifact['expired']
raw=gh('api','repos/skulitom/Nestbolt/actions/artifacts/12115983662/zip')
assert len(raw)==artifact['size_in_bytes'] and sha256(raw).hexdigest()=='3d732f52cbfba872cb1eaca0887192e64a11f2bf9cd301b15d95c066b6e69fdc'
archive=out/'browser-failure-diagnostics.zip';archive.write_bytes(raw)
inventory={}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name in z.namelist():
        b=z.read(name);inventory[name]={'bytes':len(b),'sha256':sha256(b).hexdigest()}
    failed='features-lead-allowances-e-d34ed-ort-a-separate-review-layer-chromium/'
    for name in ['error-context.md','test-failed-1.png','trace.zip']:
        (out/name).write_bytes(z.read(failed+name))
shutil.copyfile(root/'web/tests/features.spec.ts',out/'features-before.spec.ts')
write(out/'capture.json',{'utc':datetime.now(timezone.utc).isoformat(),'run':39074673874,
    'web_job':web['databaseId'],'artifact':artifact,'archive_sha256':sha256(raw).hexdigest(),
    'crc_and_every_member_recorded':True,'members':inventory,
    'finding':'Chromium lead functional test reports no complete layout within its requested 1 second. 85 other tests pass; 4 opt-in tests skip.',
    'old_c36_Firefox_cause_established':False})
shutil.copyfile(__file__,out/'capture.py')
print(json.dumps({'captured':str(out),'artifact_bytes':len(raw),'members':len(inventory)}))
