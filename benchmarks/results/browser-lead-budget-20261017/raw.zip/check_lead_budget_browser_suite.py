from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
import os
import shutil
import subprocess
import sys
import traceback
root=Path(__file__).resolve().parents[1]
out=root/'output/ci-lead-budget-20261017/local-checks';out.mkdir()
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
original=(out.parent/'features-before.spec.ts').read_text(encoding='utf-8')
old="  const sheet = await setUp(page, [source], { 'leads-1': 2 }, 60, 35, 1);"
new="  // Exercise lead behavior with the usual five-second functional-test budget.\n  // One second can expire before a complete layout exists on shared CI runners.\n  const sheet = await setUp(page, [source], { 'leads-1': 2 }, 60, 35);"
assert original.count(old)==1
assert (root/'web/tests/features.spec.ts').read_text(encoding='utf-8')==original.replace(old,new)
plan={'started_utc':datetime.now(timezone.utc).isoformat(),'production_digest':source_digest(),
    'changed_test_sha256':digest(root/'web/tests/features.spec.ts'),
    'only_test_budget_and_explanation_changed':True,'assertions_unchanged':True,
    'CI_workers':2,'local_workers':2,'retries':0,'benchmark_or_gate_change':False,
    'old_failure_preserved':'../browser-failure-diagnostics.zip','old_c36_cause_established':False}
write(out/'plan.json',plan);stages=[]
def run(label,command,cwd):
    started=datetime.now(timezone.utc).isoformat()
    with (out/(label+'.log')).open('xb') as f:
        p=subprocess.run(list(map(str,command)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
    row={'label':label,'command':list(map(str,command)),'exit_code':p.returncode,'started_utc':started,
         'finished_utc':datetime.now(timezone.utc).isoformat(),'log_sha256':digest(out/(label+'.log'))}
    stages.append(row);write(out/'progress.json',stages);print(json.dumps(row),flush=True)
    assert p.returncode==0,label
try:
    run('web-build',[sys.executable,'scripts/build_web.py'],root)
    run('test-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.tests.json'],root/'web')
    run('browser-suite',['node','node_modules/@playwright/test/cli.js','test','--workers','2','--retries','0',
                        '--output',out/'test-results','--trace','retain-on-failure'],root/'web')
    assert source_digest()==plan['production_digest']
    assert digest(root/'web/tests/features.spec.ts')==plan['changed_test_sha256']
    log=(out/'browser-suite.log').read_text(encoding='utf-8')
    assert '86 passed' in log and '4 skipped' in log
    write(out/'checks.json',{'all_pass':True,'browser_passed':86,'browser_skipped':4,'stages':stages,
        'unchanged_product_source':True,'unchanged_assertions':True,'changed_functional_test_allowance_seconds':[1,5],
        'hosted_followup_pending':True,'not_a_performance_measurement':True})
    shutil.copyfile(root/'web/tests/features.spec.ts',out/'features-after.spec.ts')
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'stages':stages});raise
