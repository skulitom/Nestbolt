"""Complete integer regions and exact outward occupied-area bounds for33 releases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
from build_h5_proxy_bracket_completion import forbidden,free_cells
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-source-orientation-construction-20261025';PRIOR=ROOT/'output/h5-proxy-two-bracket-completion-20261025';OUT=ROOT/'output/h5-core-relocation-regions-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def union_area(rectangles):
    rs=sorted(set(map(tuple,rectangles)))
    if not rs:return 0
    xs=sorted({x for r in rs for x in [r[0],r[2]]});area=0
    for lo,hi in zip(xs,xs[1:]):
        spans=sorted((r[1],r[3]) for r in rs if r[0]<=lo<r[2]);merged=[]
        for a,b in spans:
            if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
            else:merged.append([a,b])
        area+=(hi-lo)*sum(b-a for a,b in merged)
    return area
def main():
    OUT.mkdir();(OUT/'queries').mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'build.py');g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json');hints=load(SRC/'hint-poses.json');fixed=load(SRC/'audit/source-inner-rectangles.json');core=[i for i in items if i['family'] in ['frame','cog']];brmodes=[m for m in g['modes'] if m['family']=='bracket'];queries=[];cases=[]
    for ci,item in enumerate(core):
        qs=[]
        for m in brmodes:
            qi=len(queries);queries.append({'index':qi,'case':ci,'released_item':item['index'],'role':'bracket','family':'bracket','mode':m['index'],'class':m['class'],'sheet':m['sheet'],'domain':m['coordinate_bounds'],'components':aux['inner_non_cog_components'][m['class']]['components']});qs.append(qi)
        modes=([{'index':si,'class':None,'sheet':si,'coordinate_bounds':b} for si,b in enumerate(g['cog_center_bounds'])] if item['family']=='cog' else [m for m in g['modes'] if m['index'] in item['allowed_modes']])
        for m in modes:
            qi=len(queries);queries.append({'index':qi,'case':ci,'released_item':item['index'],'role':'restored','family':item['family'],'mode':m['index'],'class':m['class'],'sheet':m['sheet'],'domain':m['coordinate_bounds'],'components':aux['cog_inner_components'] if item['family']=='cog' else aux['inner_non_cog_components'][m['class']]['components']});qs.append(qi)
        cases.append({'index':ci,'released_item':item['index'],'family':item['family'],'source_index':item['source_index'],'queries':qs})
    inputs=[SRC/n for n in ['plan.json','geometry.json','propagation.json','items.json','groups.json','hint-poses.json','audit/checks.json','audit/source-inner-rectangles.json','solve/result.json']]+[PRIOR/'audit/checks.json',PRIOR/'audit/ranked-core-release-census.json',ROOT/'output/build_h5_proxy_bracket_completion.py',ROOT/'benchmarks/results/h5-source-inventory-and-proxy-slot-coverage-20261025/raw-manifest.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'maximum_total_free_cells':500000,'cases':cases,'queries':queries,'required_original_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},'fixed_original_parts_per_case':63,'restored_original_parts_per_case':1,'additional_mandatory_brackets':2,'method':'For every one of33 core releases, remove every component of that part and retain all63 other source proxy poses. Construct complete inclusive integer free-anchor cells for both new brackets and the restored original part with the existing finite orientation inventory. For each anchor cell, the moving component swept over its continuous bounding rectangle is an outward occupied-region rectangle. Exact continuous union areas on each sheet bound all realizable occupied proxy area. Enumerate every count allocation of the two brackets and every allowed restored-part sheet; reject only by exact per-sheet required proxy areas or audited original-part area capacities.','scope':'Conditional finite relocation neighborhoods, not unrestricted infeasibility. The removed part must be restored and all66 original counts remain mandatory. Outward occupied covers may include unrealizable continuous positions and therefore give necessary area bounds only. A surviving allocation is not a layout. No native, quality, release or held-out action.'});start=time.perf_counter();completed=[];pending=[];celltotal=0;case_outputs=[]
    for case in cases:
        covers={s:{role:[] for role in ['bracket','restored']} for s in [0,1]};case_done=[]
        for qi in case['queries']:
            if time.perf_counter()-start>=120 or celltotal>=500000:pending=[q['index'] for q in queries if q['index'] not in completed];break
            q=queries[qi];boxes=[r['bounds'] for r in fixed if r['sheet']==q['sheet'] and r['item']!=case['released_item']];obs=forbidden(boxes,q['components'],q['domain']);cells=free_cells(q['domain'],obs);celltotal+=len(cells);occupied=sorted(set((cell[0]+r[0],cell[1]+r[1],cell[2]+r[2],cell[3]+r[3]) for cell in cells for r in q['components']));covers[q['sheet']][q['role']].extend(occupied);write(OUT/'queries'/f'{qi:03d}.json',{'query':q,'fixed_inner_components':len(boxes),'forbidden_integer_rectangles':obs,'free_integer_cells':cells,'free_integer_anchor_count':sum((r[2]-r[0]+1)*(r[3]-r[1]+1) for r in cells),'outward_occupied_cover_rectangles':occupied});completed.append(qi);case_done.append(qi)
        if pending:break
        released=items[case['released_item']];remaining=[h for h in hints if h['item']!=case['released_item']];assert len(remaining)==63;counts=Counter(h['family'] for h in remaining);counts[released['family']]+=1;counts['bracket']+=2;assert counts=={'frame':18,'bracket':12,'insert':21,'cog':15};basearea=[sum(aux['part_areas'][h['family']]['lower_units'] for h in remaining if h['sheet']==s) for s in [0,1]];brareas={sum((r[2]-r[0])*(r[3]-r[1]) for r in queries[qi]['components']) for qi in case['queries'] if queries[qi]['role']=='bracket'};coreareas={sum((r[2]-r[0])*(r[3]-r[1]) for r in queries[qi]['components']) for qi in case['queries'] if queries[qi]['role']=='restored'};assert len(brareas)==len(coreareas)==1;br_area=next(iter(brareas));core_area=next(iter(coreareas));areas={s:{'bracket':union_area(covers[s]['bracket']),'restored':union_area(covers[s]['restored']),'combined':union_area(covers[s]['bracket']+covers[s]['restored'])} for s in [0,1]};allocations=[]
        for restored_sheet in sorted({queries[qi]['sheet'] for qi in case['queries'] if queries[qi]['role']=='restored'}):
            for brackets_sheet1 in [0,1,2]:
                fails=[];brackets=[2-brackets_sheet1,brackets_sheet1]
                for sheet in [0,1]:
                    restored=int(sheet==restored_sheet);charge=basearea[sheet]+restored*aux['part_areas'][released['family']]['lower_units']+brackets[sheet]*aux['part_areas']['bracket']['lower_units']
                    if charge>aux['sheet_capacities'][sheet]['upper_area_units']:fails.append({'sheet':sheet,'condition':'original_area_capacity','required':charge,'upper':aux['sheet_capacities'][sheet]['upper_area_units']})
                    for role,needed in [('bracket',brackets[sheet]*br_area),('restored',restored*core_area),('combined',brackets[sheet]*br_area+restored*core_area)]:
                        if needed>areas[sheet][role]:fails.append({'sheet':sheet,'condition':role+'_occupied_cover','required':needed,'upper':areas[sheet][role]})
                allocations.append({'restored_sheet':restored_sheet,'brackets_per_sheet':brackets,'passes_necessary_bounds':not fails,'failures':fails})
        record={'case':case,'base_original_area_units':basearea,'proxy_required_area_units_squared':{'bracket':br_area,'restored':core_area},'outward_occupied_cover_area_units_squared':areas,'allocations':allocations,'excluded_by_necessary_bounds':all(not a['passes_necessary_bounds'] for a in allocations),'surviving_allocations':sum(a['passes_necessary_bounds'] for a in allocations)};write(OUT/'cases'/f'{case["index"]:03d}.json',record);case_outputs.append({'case':case['index'],'released_item':case['released_item'],'family':case['family'],'excluded':record['excluded_by_necessary_bounds'],'surviving_allocations':record['surviving_allocations']})
    write(OUT/'pending.json',pending);result={'seconds':time.perf_counter()-start,'queries_completed':len(completed),'queries_planned':len(queries),'cases_completed':len(case_outputs),'cases_planned':len(cases),'total_free_cells':celltotal,'cell_cap_reached':celltotal>=500000,'pending_queries':len(pending),'excluded_cases':sum(r['excluded'] for r in case_outputs),'surviving_cases':sum(not r['excluded'] for r in case_outputs),'surviving_allocations':sum(r['surviving_allocations'] for r in case_outputs),'cases':case_outputs,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
