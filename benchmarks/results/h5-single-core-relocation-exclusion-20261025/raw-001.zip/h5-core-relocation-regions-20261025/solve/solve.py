"""One bounded exact integer-proxy feasibility call for five audited neighborhoods."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from collections import Counter
from itertools import combinations, product
import json, shutil, sys, time, traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2, sat_parameters_pb2
from ortools.sat.python import cp_model

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-core-relocation-regions-20261025'
SRC = ROOT / 'output/h5-source-orientation-construction-20261025'
OUT = BASE / 'solve'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

def main():
    assert load(BASE / 'audit/checks.json')['passed']
    OUT.mkdir(); shutil.copyfile(__file__, OUT / 'solve.py')
    source_plan = load(BASE / 'plan.json')
    survivors = load(BASE / 'audit/surviving-neighborhoods.json')
    aux = load(SRC / 'propagation.json'); hints = load(SRC / 'hint-poses.json')
    params = {'max_time_in_seconds': 60, 'num_search_workers': 8, 'random_seed': 0,
              'cp_model_presolve': True, 'cp_model_probing_level': 0, 'symmetry_level': 0,
              'log_search_progress': True, 'log_to_stdout': False}
    inputs = [BASE / n for n in ['plan.json', 'result.json', 'audit/checks.json',
                                'audit/surviving-neighborhoods.json', 'audit/case-checks.json']]
    inputs += [SRC / n for n in ['propagation.json', 'hint-poses.json', 'items.json']]
    specs = []
    for record in survivors:
        assert len(record['surviving_allocations']) == 1 and record['family'] == 'cog'
        allocation = record['surviving_allocations'][0]; sheet = allocation['restored_sheet']
        assert allocation['brackets_per_sheet'][sheet] == 2
        case = source_plan['cases'][record['case']]
        assert case['released_item'] == record['released_item']
        queries = []
        for qi in case['queries']:
            p = BASE / 'queries' / f'{qi:03d}.json'
            inputs.append(p); q = load(p)
            assert q['query'] == source_plan['queries'][qi]
            if q['query']['sheet'] == sheet: queries.append(q)
        remaining = [h for h in hints if h['item'] != case['released_item']]
        assert len(remaining) == 63
        counts = Counter(h['family'] for h in remaining); counts.update(cog=1, bracket=2)
        assert counts == {'frame': 18, 'bracket': 12, 'insert': 21, 'cog': 15}
        charges = [sum(aux['part_areas'][h['family']]['lower_units'] for h in remaining if h['sheet'] == s)
                   + (aux['part_areas']['cog']['lower_units'] + 2*aux['part_areas']['bracket']['lower_units'] if s == sheet else 0)
                   for s in [0, 1]]
        assert all(charges[s] <= aux['sheet_capacities'][s]['upper_area_units'] for s in [0, 1])
        specs.append({'case': case['index'], 'released_item': case['released_item'], 'sheet': sheet,
                      'queries': queries, 'original_area_charges': charges})
    assert len(specs) == 5
    write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(),
          'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
          'model_construction_limit_seconds': 120, 'model_audit_limit_seconds': 120,
          'maximum_solver_calls': 1, 'parameters': params, 'objective': None,
          'cases': [{k: s[k] for k in ['case', 'released_item', 'sheet', 'original_area_charges']} for s in specs],
          'required_counts': {'frame':18, 'bracket':12, 'insert':21, 'cog':15},
          'meaning': 'Select exactly one audited surviving neighborhood. Keep63 original source proxy poses fixed, restore one mandatory cog, and add both mandatory missing brackets. Select one complete integer free cell per movable part; every component shares its anchor and orientation. Disjointness of all24 cross-part inner-rectangle pairs is exact on this integer proxy grid, with touching allowed. No copy ordering, hints, optional physical parts, objectives or additional restrictions. Original sheet area charges retained. An infeasible result is conditional on these five one-core-part neighborhoods, not unrestricted original packing. Any positive proxy needs original-outline and native checks; H5 remains open.'})
    start = time.perf_counter(); model = cp_model.CpModel(); variables = []; mapping = []
    def var(name, lo, hi):
        v = model.new_int_var(lo, hi, name); assert v.index == len(variables)
        variables.append(v); return v.index
    def linear(terms, lo, hi, en=()):
        constraint = model.add_linear_constraint(sum(variables[i]*c for i,c in terms), lo, hi)
        if en: constraint.only_enforce_if([variables[i] if i >= 0 else variables[-i-1].Not() for i in en])
    def disjunct(ids):
        model.add_bool_or([variables[i] if i >= 0 else variables[-i-1].Not() for i in ids])
    loinf = cp_model.INT_MIN
    active = [var(f"case{s['case']}-active", 0, 1) for s in specs]
    model.add_exactly_one([variables[i] for i in active])
    for spec, enabled in zip(specs, active):
        prefix = f"case{spec['case']}"; parts = []
        for pi, role in enumerate(['bracket', 'bracket', 'restored']):
            name = f'{prefix}-part{pi}'; x = var(name+'-x', 0, 150000); y = var(name+'-y', 0, 300000)
            options = []
            for q in spec['queries']:
                if q['query']['role'] != role: continue
                for cell_index, cell in enumerate(q['free_integer_cells']):
                    tag = f"{name}-q{q['query']['index']}-cell{cell_index}"
                    chosen = var(tag, 0, 1)
                    options.append({'query':q['query']['index'], 'cell_index':cell_index, 'cell':cell,
                                    'components':q['query']['components'], 'active':chosen})
                    linear([(x,1)], cell[0], cell[2], [chosen]); linear([(y,1)], cell[1], cell[3], [chosen])
            linear([(o['active'],1) for o in options]+[(enabled,-1)], 0, 0)
            components = []
            for arm in range(2 if role == 'bracket' else 5):
                offsets = []
                for axis in range(4):
                    values = [o['components'][arm][axis] for o in options]
                    offset = var(f'{name}-arm{arm}-offset{axis}', min([0]+values), max([0]+values))
                    linear([(offset,1)]+[(o['active'],-o['components'][arm][axis]) for o in options], 0, 0)
                    offsets.append(offset)
                components.append(offsets)
            parts.append({'index':pi, 'role':role, 'x':x, 'y':y, 'options':options, 'components':components})
        for pa, pb in combinations(parts, 2):
            for ai, ar in enumerate(pa['components']):
                for bi, br in enumerate(pb['components']):
                    names = [f"{prefix}-pair{pa['index']}-{pb['index']}-arms{ai}-{bi}-direction{d}" for d in range(4)]
                    directions = [var(n, 0, 1) for n in names]
                    terms = [[(pa['x'],1),(ar[2],1),(pb['x'],-1),(br[0],-1)],
                             [(pb['x'],1),(br[2],1),(pa['x'],-1),(ar[0],-1)],
                             [(pa['y'],1),(ar[3],1),(pb['y'],-1),(br[1],-1)],
                             [(pb['y'],1),(br[3],1),(pa['y'],-1),(ar[1],-1)]]
                    for d, terms_d in zip(directions, terms):
                        linear([(d,1),(enabled,-1)], loinf, 0)
                        linear(terms_d, loinf, 0, [d])
                    disjunct([-enabled-1]+directions)
        for s in [0,1]:
            linear([(enabled, spec['original_area_charges'][s]-aux['sheet_capacities'][s]['upper_area_units'])], loinf, 0)
        mapping.append({'case':spec['case'], 'active':enabled, 'parts':parts})
    assert model.validate() == ''; assert model.export_to_file(str(OUT / 'model.pb'))
    write(OUT / 'mapping.json', mapping)
    construction_seconds = time.perf_counter()-start; assert construction_seconds < 120
    print({'construction_seconds':construction_seconds, 'variables':len(variables)}, flush=True)

    # Independently reconstruct every serialized variable, clause and linear bound.
    start = time.perf_counter(); actual = cp_model_pb2.CpModelProto()
    actual.ParseFromString((OUT / 'model.pb').read_bytes()); vi = ci = 0; pair_count = option_count = 0
    def checkvar(name, lo, hi):
        nonlocal vi
        assert actual.variables[vi] == cp_model_pb2.IntegerVariableProto(name=name, domain=[lo,hi]), (vi,name)
        vi += 1; return vi-1
    def checklinear(terms, lo, hi, en=()):
        nonlocal ci
        coefficients = Counter()
        for idx, c in terms: coefficients[idx] += c
        ids = sorted(i for i,c in coefficients.items() if c)
        expected = cp_model_pb2.ConstraintProto(); expected.enforcement_literal.extend(en)
        expected.linear.vars.extend(ids); expected.linear.coeffs.extend(coefficients[i] for i in ids)
        expected.linear.domain.extend([lo,hi])
        assert actual.constraints[ci] == expected, (ci, actual.constraints[ci], expected)
        ci += 1
    def checkbool(kind, ids):
        nonlocal ci
        expected = cp_model_pb2.ConstraintProto(); getattr(expected, kind).literals.extend(ids)
        assert actual.constraints[ci] == expected, (ci,kind); ci += 1
    oracle_active = [checkvar(f"case{s['case']}-active",0,1) for s in specs]
    checkbool('exactly_one',oracle_active)
    oracle = []
    for spec, enabled in zip(specs,oracle_active):
        name = f"case{spec['case']}"; parts = []
        for part_index in range(3):
            role = 'restored' if part_index == 2 else 'bracket'; part_name = name+f'-part{part_index}'
            x = checkvar(part_name+'-x',0,150000); y = checkvar(part_name+'-y',0,300000); opts = []
            # Re-read source cell files instead of taking decisions from the mapping.
            for qi in source_plan['cases'][spec['case']]['queries']:
                q = load(BASE / 'queries' / f'{qi:03d}.json')
                if q['query']['role'] != role or q['query']['sheet'] != spec['sheet']: continue
                for cell_index, bounds in enumerate(q['free_integer_cells']):
                    b = checkvar(part_name+f'-q{qi}-cell{cell_index}',0,1)
                    checklinear([(x,1)],bounds[0],bounds[2],[b]); checklinear([(y,1)],bounds[1],bounds[3],[b])
                    opts.append({'query':qi,'cell_index':cell_index,'cell':bounds,'components':q['query']['components'],'active':b})
            option_count += len(opts); checklinear([(o['active'],1) for o in opts]+[(enabled,-1)],0,0)
            arms = []
            for arm in range([2,2,5][part_index]):
                coordinates = []
                for axis in [0,1,2,3]:
                    values = [o['components'][arm][axis] for o in opts]
                    v = checkvar(part_name+f'-arm{arm}-offset{axis}',min([0]+values),max([0]+values))
                    checklinear([(v,1)]+[(o['active'],-o['components'][arm][axis]) for o in opts],0,0)
                    coordinates.append(v)
                arms.append(coordinates)
            parts.append({'index':part_index,'role':role,'x':x,'y':y,'options':opts,'components':arms})
        for i,j in [(0,1),(0,2),(1,2)]:
            for ai,bi in product(range(len(parts[i]['components'])),range(len(parts[j]['components']))):
                a,b = parts[i],parts[j]; ar,br = a['components'][ai],b['components'][bi]; pair_count += 1
                ds = [checkvar(name+f'-pair{i}-{j}-arms{ai}-{bi}-direction{k}',0,1) for k in [0,1,2,3]]
                for k,d in enumerate(ds):
                    checklinear([(d,1),(enabled,-1)],-2**63,0)
                    left,right,lr,rr = (a,b,ar,br) if k%2 == 0 else (b,a,br,ar)
                    axis = 'x' if k<2 else 'y'; end = 2 if k<2 else 3; begin = end-2
                    checklinear([(left[axis],1),(lr[end],1),(right[axis],-1),(rr[begin],-1)],-2**63,0,[d])
                checkbool('bool_or',[-enabled-1]+ds)
        for s in [0,1]:
            checklinear([(enabled,spec['original_area_charges'][s]-aux['sheet_capacities'][s]['upper_area_units'])],-2**63,0)
        oracle.append({'case':spec['case'],'active':enabled,'parts':parts})
    assert oracle == mapping and pair_count == 120
    assert vi == len(actual.variables) == len(variables) and ci == len(actual.constraints)
    extra = cp_model_pb2.CpModelProto(); extra.CopyFrom(actual)
    extra.ClearField('variables'); extra.ClearField('constraints'); assert not extra.ListFields()
    solver = cp_model.CpSolver()
    for k,v in params.items(): setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters()) == sat_parameters_pb2.SatParameters(**params)
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    audit_seconds = time.perf_counter()-start; assert audit_seconds < 120
    write(OUT / 'model-audit.json', {'passed':True,'construction_seconds':construction_seconds,'audit_seconds':audit_seconds,
          'every_variable_constraint_parameter_reconstructed':True,'variables':vi,'constraints':ci,
          'cases':5,'mandatory_original_parts_per_case':66,'fixed_parts_per_case':63,
          'movable_parts_per_case':3,'cross_part_component_pairs_per_case':24,'total_component_pairs':pair_count,
          'complete_cell_options_in_model':option_count,'original_area_constraints':10,'hints':0,'objectives':0,
          'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),
          'python':sys.version,'ortools':ortools.__version__})
    print(load(OUT/'model-audit.json'),flush=True)
    def positions(value):
        selected = [r for r in mapping if value(variables[r['active']])]; assert len(selected)==1
        chosen = selected[0]; spec = next(s for s in specs if s['case']==chosen['case']); rows=[]
        for part in chosen['parts']:
            options = [o for o in part['options'] if value(variables[o['active']])]; assert len(options)==1
            option = options[0]; q = source_plan['queries'][option['query']]
            rows.append({'role':part['role'],'part':part['index'],'x_units':value(variables[part['x']]),
                         'y_units':value(variables[part['y']]),'query':option['query'],'cell':option['cell_index'],
                         'sheet':q['sheet'],'class':q['class'],'mode':q['mode']})
        return {'case':chosen['case'],'released_item':spec['released_item'],'movable_parts':rows}
    records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            p=positions(self.value); write(OUT/f'incumbent-{len(records)}.json',p)
            records.append({'index':len(records),'seconds':self.wall_time,'case':p['case']})
            print(records[-1],flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,
                            'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush())
        start=time.perf_counter(); status=solver.solve(model,Capture()); elapsed=time.perf_counter()-start
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
    if feasible: write(OUT/'positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'incumbents':records,
            'has_full_proxy_solution':feasible,'response_stats':solver.response_stats(),
            'infeasibility_scope':'Only the five complete audited one-core-part integer-proxy neighborhoods, with63 fixed poses. Along with28 area exclusions, this covers the33 recorded releases. No unrestricted packing impossibility claim.',
            'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result); print(result,flush=True)

if __name__=='__main__':
    try: main()
    except Exception:
        if OUT.exists(): (OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
