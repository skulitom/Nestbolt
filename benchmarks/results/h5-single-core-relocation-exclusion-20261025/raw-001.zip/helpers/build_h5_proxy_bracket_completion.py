"""Exact integer free-anchor cells around64 proxy parts, then bounded two-slot completion."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from itertools import combinations_with_replacement,product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=ROOT/'output/h5-proxy-two-bracket-completion-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def forbidden(fixed,moving,domain):
    out=[]
    for a in fixed:
        for b in moving:
            r=[max(domain[0],a[0]-b[2]+1),max(domain[1],a[1]-b[3]+1),min(domain[2],a[2]-b[0]-1),min(domain[3],a[3]-b[1]-1)]
            if r[0]<=r[2] and r[1]<=r[3]:out.append(r)
    return out
def free_cells(domain,obstacles):
    x0,y0,x1,y1=domain;xs=sorted({x0,x1+1}|{v for r in obstacles for v in [r[0],r[2]+1]});out=[]
    for left,right in zip(xs,xs[1:]):
        intervals=sorted((r[1],r[3]) for r in obstacles if r[0]<=left<=r[2]);merged=[]
        for lo,hi in intervals:
            if merged and lo<=merged[-1][1]+1:merged[-1][1]=max(merged[-1][1],hi)
            else:merged.append([lo,hi])
        cursor=y0
        for lo,hi in merged:
            if cursor<lo:out.append([left,cursor,right-1,lo-1])
            cursor=max(cursor,hi+1)
        if cursor<=y1:out.append([left,cursor,right-1,y1])
    return out
def main():
    OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py');inputs=[SRC/n for n in ['plan.json','geometry.json','propagation.json','items.json','groups.json','hint-poses.json','audit/checks.json','audit/source-inner-rectangles.json','solve/result.json']];g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');modes=[m for m in g['modes'] if m['family']=='bracket'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'maximum_free_cells':200000,'pair_selection_limit_seconds':60,'maximum_cell_pairs':1000000,'coordinate_units_per_mm':100,'queries':modes,'fixed_proxy_original_parts':64,'additional_mandatory_brackets':2,'method':'All coordinates are exact integers. A moving component overlaps a fixed component only when its anchor lies strictly inside their axis-aligned Minkowski rectangle; integer forbidden intervals are [fixedMin-movingMax+1,fixedMax-movingMin-1]. Clip to the existing inclusive mode bounds. Sweep every critical x slab and complement merged inclusive y intervals, covering all valid integer anchors including touching boundaries and isolated grid lines/points. For a same-sheet pair of free-anchor cells, every relative offset lies in their exact difference rectangle; exclude the four moving-component collision rectangles and reconstruct anchors from any remaining integer offset. Different sheets are independent.','scope':'Only completion around the64 fixed inner-proxy poses; all original counts and target retained. A positive result is diagnostic proxy geometry. A negative excludes only this fixed proxy arrangement after complete audits, never all moving layouts or original geometry. No solver retries or resumed candidate lists. Preserve pending/caps.'});start=time.perf_counter();fixed=load(SRC/'audit/source-inner-rectangles.json');assert len(fixed)==134;rows=[];pending=[];celltotal=0
    for qi,m in enumerate(modes):
        if time.perf_counter()-start>=120 or celltotal>=200000:pending=modes[qi:];break
        boxes=[r['bounds'] for r in fixed if r['sheet']==m['sheet']];moving=aux['inner_non_cog_components'][m['class']]['components'];obs=forbidden(boxes,moving,m['coordinate_bounds']);cells=free_cells(m['coordinate_bounds'],obs);celltotal+=len(cells);record={'query':qi,'mode':m['index'],'class':m['class'],'sheet':m['sheet'],'domain':m['coordinate_bounds'],'moving_components':moving,'forbidden_integer_rectangles':obs,'free_integer_cells':cells,'free_anchor_count':sum((r[2]-r[0]+1)*(r[3]-r[1]+1) for r in cells)};write(OUT/'queries'/f'{qi:03d}.json',record);rows.append({'query':qi,'mode':m['index'],'sheet':m['sheet'],'cells':len(cells),'free_anchors':record['free_anchor_count']})
    elapsed=time.perf_counter()-start;write(OUT/'pending.json',pending);write(OUT/'generation.json',{'seconds':elapsed,'queries_completed':len(rows),'queries_pending':len(pending),'total_free_cells':celltotal,'results':rows,'cell_cap_reached':celltotal>=200000,'full_target_witness':False,'H5_complete':False});print(load(OUT/'generation.json'),flush=True)
    assert not pending and celltotal<200000;queries=[load(OUT/'queries'/f'{r["query"]:03d}.json') for r in rows];pool=[{'query':q['query'],'sheet':q['sheet'],'mode':q['mode'],'cell':cell,'components':q['moving_components']} for q in queries for cell in q['free_integer_cells']];start=time.perf_counter();tried=0;solution=None;capped=False
    for a,b in combinations_with_replacement(pool,2):
        if tried>=1000000 or time.perf_counter()-start>=60:capped=True;break
        tried+=1;ra,rb=a['cell'],b['cell']
        if a['sheet']!=b['sheet']:pa,pb=ra[:2],rb[:2]
        else:
            domain=[rb[0]-ra[2],rb[1]-ra[3],rb[2]-ra[0],rb[3]-ra[1]];obs=forbidden(a['components'],b['components'],domain);space=free_cells(domain,obs)
            if not space:continue
            delta=space[0][:2];pa=[max(ra[k],rb[k]-delta[k]) for k in [0,1]];pb=[pa[k]+delta[k] for k in [0,1]];assert all(ra[k]<=pa[k]<=ra[k+2] and rb[k]<=pb[k]<=rb[k+2] for k in [0,1])
        solution=[{'query':r['query'],'mode':r['mode'],'sheet':r['sheet'],'x_units':p[0],'y_units':p[1]} for r,p in [(a,pa),(b,pb)]];break
    selection={'seconds':time.perf_counter()-start,'cell_pairs_examined':tried,'available_free_cell_pairs':len(pool)*(len(pool)+1)//2,'capped':capped,'found_two_proxy_slots':solution is not None,'all_cell_pairs_exhausted':solution is None and not capped,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    if solution is not None:write(OUT/'two-slots.json',solution)
    write(OUT/'selection.json',selection);print(selection,flush=True)
if __name__=='__main__':main()
