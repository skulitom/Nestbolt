"""Reconstruct the contained-return candidate and isolate its exact runtime delta."""
from pathlib import Path
from hashlib import sha256
import ast,difflib,json,re,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-contained-return-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'build.json')['all_checks_passed']
rel=plan['changed_files'][0];parent=Path(plan['old_probe'])/'candidate'
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]',1);runtime,tests=current.split('#[cfg(test)]',1)
start=runtime.index('// Bounds work is charged');end=runtime.index('// Only choose the reciprocal frame',start)
helpers=runtime[start:end];restored=runtime[:start]+runtime[end:]
start=restored.index('                    contain_return_group(')
end=restored.index('                    for ((_, victim, _), pose)',start)
call=restored[start:end]
assert re.sub(r'\s+','',call)=='contain_return_group(&victims,&mutreturned,&last_container.outer_cd().bbox(),&self.clock,);'
restored=(restored[:start]+restored[end:]).replace('let mut returned = if victims.len() == 1','let returned = if victims.len() == 1')
assert restored==old_runtime
assert tests.split('    // BEGIN contained-return tests',1)[0].rstrip()==old_tests.rsplit('\n}',1)[0].rstrip()
assert helpers.count('crate::separate::charge(clock, item, 1)')==1
assert '.rng' not in helpers and '.now(' not in helpers
fresh=root/'output/h5-contained-return-reconstruction-20261018';shutil.copytree(out/'candidate',fresh)
s=(out/'before-boundary-pair'/rel).read_text(encoding='utf-8');stub=(out/'stub.txt').read_text(encoding='utf-8')
tree=ast.parse((out/'apply.py').read_text(encoding='utf-8'))
node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='implementation' for t in n.targets))
implementation=ast.literal_eval(node.value);assert s.count(stub)==1
(fresh/rel).write_text(s.replace(stub,implementation),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
repair=load(out/'containment-repair.json');s=(fresh/rel).read_text(encoding='utf-8')
assert s.count(repair['before'])==1
(fresh/rel).write_text(s.replace(repair['before'],repair['after']),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
assert (out/'failed-boundary-contact'/rel).read_text(encoding='utf-8').split('#[cfg(test)]',1)[1]==current.split('#[cfg(test)]',1)[1]
files=[]
for row in plan['old_source_files']['candidate']:
    name=row['path'];assert digest(parent/name)==row['sha256']
    assert (fresh/name).read_bytes()==(out/'candidate'/name).read_bytes()
    if name!=rel:assert digest(out/'candidate'/name)==row['sha256']
    files.append(name)
record={'all_checks_passed':True,'all_130_prior_tests_unchanged':True,'other_runtime_exact':True,
    'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(files),'unchanged_other_files':len(files)-1,
    'material_profile_and_validator_sources_unchanged':True,'only_return_initialization_changes':True,
    'existing_generators_caps_budgets_repairs_acceptance_unchanged':True,'new_geometry_work_charged':True,
    'original_and_shifted_bounds_checked':True,'no_new_random_samples_or_clock_reads':True,'new_searches':0}
(out/'reconstruction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'source-checks.json').write_text(json.dumps({'all_checks_passed':True,'changed_runtime_files':[rel],
    'original_candidate_file_sha256':digest(parent/rel),'candidate_file_sha256':digest(out/'candidate'/rel),
    'all_other_candidate_files_unchanged':True,'all_prior_tests_unchanged':130,
    'new_tests':3,'all_assertions_unchanged_after_rounding_repair':True,
    'new_searches':0},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(prior.splitlines(True),current.splitlines(True),
    fromfile='boundary-pair/'+rel,tofile='contained-return/'+rel)),encoding='utf-8',newline='\n')
(out/'qualified-helpers.rs').write_text(helpers,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
