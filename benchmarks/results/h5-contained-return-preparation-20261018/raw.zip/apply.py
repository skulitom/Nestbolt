"""Implement bounded translation only after the new regressions fail as expected."""
from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-contained-return-probe-20261018'
assert json.loads((out/'before-boundary-pair/checks.json').read_bytes())['expected_runtime_failure']
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs';text=path.read_text(encoding='utf-8')
stub=(out/'stub.txt').read_text(encoding='utf-8');assert text.count(stub)==1
implementation='''// Bounds work is charged both for the original seed and any proposed shift.
// The existing separator and whole-job validator still decide feasibility.
fn return_group_bounds(
    victims: &[IncomingMember],
    poses: &[DTransformation],
    clock: &Clock,
) -> Option<Rect> {
    let mut x0 = f32::INFINITY;
    let mut y0 = f32::INFINITY;
    let mut x1 = f32::NEG_INFINITY;
    let mut y1 = f32::NEG_INFINITY;
    for ((_, item, _), pose) in victims.iter().zip(poses) {
        let mut shape = item.shape_cd().as_ref().clone();
        shape.transform_from(item.shape_cd(), &pose.compose());
        crate::separate::charge(clock, item, 1);
        let bounds = shape.bbox();
        if ![bounds.x_min, bounds.y_min, bounds.x_max, bounds.y_max]
            .into_iter().all(f32::is_finite)
        {
            return None;
        }
        x0 = x0.min(bounds.x_min);
        y0 = y0.min(bounds.y_min);
        x1 = x1.max(bounds.x_max);
        y1 = y1.max(bounds.y_max);
    }
    Rect::try_new(x0, y0, x1, y1).ok()
}

// Shift a fitting return seed as a whole into the existing source box.
// Already contained, oversized, malformed or numerically uncontained results
// retain the original seed exactly. Translation leaves permissions intact;
// no random samples, deadline extensions or acceptance changes are introduced.
fn contain_return_group(
    victims: &[IncomingMember],
    poses: &mut [DTransformation],
    bounds: &Rect,
    clock: &Clock,
) -> bool {
    if victims.is_empty() || victims.len() > 3 || victims.len() != poses.len() {
        return false;
    }
    let Some(before) = return_group_bounds(victims, poses, clock) else {
        return false;
    };
    if before.x_max - before.x_min > bounds.x_max - bounds.x_min
        || before.y_max - before.y_min > bounds.y_max - bounds.y_min
    {
        return false;
    }
    let correction = |low: f32, high: f32, min: f32, max: f32| {
        if low < min { min - low } else if high > max { max - high } else { 0.0 }
    };
    let dx = correction(before.x_min, before.x_max, bounds.x_min, bounds.x_max);
    let dy = correction(before.y_min, before.y_max, bounds.y_min, bounds.y_max);
    if dx == 0.0 && dy == 0.0 {
        return false;
    }
    let shifted: Vec<_> = poses.iter().map(|pose| {
        let (x, y) = pose.translation();
        DTransformation::new(pose.rotation(), (x + dx, y + dy)).with_reflection(pose.reflected)
    }).collect();
    let Some(after) = return_group_bounds(victims, &shifted, clock) else {
        return false;
    };
    if after.x_min < bounds.x_min || after.y_min < bounds.y_min
        || after.x_max > bounds.x_max || after.y_max > bounds.y_max
    {
        return false;
    }
    poses.copy_from_slice(&shifted);
    true
}

'''
path.write_text(text.replace(stub,implementation),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
shutil.copyfile(__file__,out/'apply.py')
print('Applied bounded, charged return-seed translation after preserved expected regressions.')
