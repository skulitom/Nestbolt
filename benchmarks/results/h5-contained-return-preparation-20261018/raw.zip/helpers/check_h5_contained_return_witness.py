"""Check the saved authored seed witness without repeating its tests or any search."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-contained-return-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out=probe/'seed-checks';out.mkdir()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '133 passed; 0 failed' in log
rows=[json.loads(line.removeprefix('CONTAINED_RETURN_WITNESS ')) for line in log.splitlines() if line.startswith('CONTAINED_RETURN_WITNESS ')]
assert len(rows)==1;row=rows[0]
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
write(out/'witness.json',row);write(out/'job.json',row['job']);write(out/'layout.json',row['source_layout'])
args=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(out/'layout.json')]
r=subprocess.run(args,capture_output=True,timeout=60)
(out/'stdout.json').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr);write(out/'command.json',{'command':args,'exit_code':r.returncode})
assert r.returncode==0 and json.loads(r.stdout)['valid']
parts={p['id']:p for p in row['job']['parts']};deltas=[];residuals=[]
def transform(p,point):
    t=p['transform'];angle=t['rotation_radians'];c=math.cos(angle);s=math.sin(angle);m=-1 if t['mirrored'] else 1;x,y=point
    return (m*c*x-s*y+t['translation'][0],m*s*x+c*y+t['translation'][1])
for before,after in zip(row['before'],row['after']):
    assert before['part_id']==after['part_id']
    a=before['transform'];b=after['transform']
    assert a['rotation_radians']==b['rotation_radians'] and a['mirrored']==b['mirrored']
    delta=[b['translation'][i]-a['translation'][i] for i in range(2)];deltas.append(delta)
    for polygon in parts[before['part_id']]['geometry']:
        for ring in [polygon['outer'],*polygon['holes']]:
            for vertex in ring:
                old=transform(before,vertex);new=transform(after,vertex)
                residuals.append(max(abs(new[i]-old[i]-delta[i]) for i in range(2)))
assert len(deltas)==2 and max(abs(x-y) for x,y in zip(*deltas))<=1e-6
assert any(abs(x)>0 for x in deltas[0]) and max(residuals)<=1e-6
assert row['work']['evaluations']==4.0 and row['work']['evaluated_vertices']>0
target=Path(load(probe/'preparation.json')['target']);bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
shutil.copyfile(bins[0],out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
checks={'all_checks_passed':True,'new_seed_tests':3,'public_CLI_validations':1,
    'source_fixture_independently_valid':True,'original_contours_translate_without_rotation_or_reflection_change':True,
    'max_vertex_translation_residual_mm':max(residuals),'public_translation_vectors':deltas,
    'actual_geometry_evaluations_charged':4,'CLI_sha256':expected,'test_binary_sha256':digest(bins[0]),
    'core_log_sha256':digest(probe/'core-tests.log'),'tests_reused_from_full_build':True,
    'limits':'Native authored tests check exact internal containment, bitwise no-ops, mixed allowed orientations/reflection and work charges. The public witness verifies preserved original contours and a valid source fixture; it is not a searched output or a quality comparison.',
    'new_searches':0,'quality_claim':False}
write(out/'checks.json',checks);print(json.dumps(checks))
