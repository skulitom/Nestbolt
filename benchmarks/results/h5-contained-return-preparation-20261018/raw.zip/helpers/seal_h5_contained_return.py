"""Seal the contained-return functional qualification before any quality pilot."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-contained-return-probe-20261018'
out=root/'benchmarks/results/h5-contained-return-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');seed=load(probe/'seed-checks/checks.json')
assert all(x['all_checks_passed'] for x in [build,source,public,branch,seed])
assert '133 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['all_130_prior_tests_unchanged'] and source['other_runtime_exact'] and source['unchanged_other_files']==155
assert source['new_geometry_work_charged'] and source['existing_generators_caps_budgets_repairs_acceptance_unchanged']
red=load(probe/'before-boundary-pair/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-boundary-pair/expected-failure.log')==red['log_sha256']
assert digest(probe/'before-boundary-pair/authored-tests.exe')==red['binary_sha256']
repair=load(probe/'containment-repair.json');assert repair['all_133_tests_unchanged'] and repair['exact_containment_check_unchanged']
assert digest(probe/'failed-boundary-contact/core-tests.log')==repair['failure_log_sha256']
assert digest(probe/'failed-boundary-contact/authored-tests.exe')==repair['failure_binary_sha256']
assert digest(probe/'failed-boundary-contact'/plan['changed_files'][0])==repair['failure_source_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/rel)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
assert branch['actual_outcomes']==12 and branch['public_validations']==24
assert seed['new_seed_tests']==3 and seed['public_CLI_validations']==1 and seed['actual_geometry_evaluations_charged']==4
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256']
assert digest(root/method['candidate_runner'])==method['runner_sha256']
assert method['scoring_measurement_and_PID_reuse_guard_unchanged']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_contained_return.py','check_h5_contained_return_red.py','apply_h5_contained_return.py',
             'repair_h5_contained_return_rounding.py','build_h5_contained_return.py','prepare_h5_contained_return_checks.py',
             'check_h5_contained_return_source.py','check_h5_contained_return_witness.py','check_h5_contained_return_public.py',
             'check_h5_contained_return_branch.py','check_h5_contained_return_harness.py','seal_h5_contained_return.py',
             'record_h5_contained_return_preparation.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_contained_return_pilot.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':133,'prior_tests_unchanged':130,'new_tests':3,
    'expected_two_failures_preserved':True,'boundary_contact_failure_preserved':True,'assertions_and_exact_containment_unchanged':True,
    'strict_lint_passed':True,'observer_build_passed':True,'only_return_initialization_changes':True,
    'existing_choices_budgets_repairs_acceptance_unchanged':True,'additional_geometry_work_charged':True,
    'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':155,
    'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'seed_witness_CLI_checks':1,
    'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,
    'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'PID_reuse_guard_unchanged':True,
    'production_unchanged':True,'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json','containment-repair.json']:shutil.copyfile(probe/name,out/name)
for sub,name in [('before-boundary-pair','expected-failure'),('public-checks','public-checks'),('branch-checks','branch-checks'),('seed-checks','seed-checks')]:shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
doc='''# Contained return initialization — preparation, 2026-10-18

The [failure diagnosis](h5-exchange-failure-observer-20261018.md) finds eighteen
source repairs with positive loss and actual remaining filled-outer violations.
Four valid trials retain the height-setting inserts and increase material by
only 0.0025–0.00375 mm². The strict acceptance guard remains appropriate.
This motivates a return-initialization hypothesis, not a feasibility claim.

The isolated candidate translates a returned group as a whole into the existing
source-container bounding box when it fits. It retains orientations/reflection;
relative positions share the same translation, subject to native float arithmetic.
Already contained, oversized, malformed and numerically uncontained groups keep
their old poses exactly. The original and shifted collision-shape bounds are
charged. A small interior offset, capped at half the available space, avoids
placing a rotated group exactly on a rounded boundary. The second containment
check remains exact; no acceptance tolerance changes. This box is only an initial
seed constraint: all existing collision repairs and full-job checks still apply.

All 133 optimized tests pass, with 130 prior tests unchanged. Against the old
behavior the new tests first show two expected movement failures and one no-op
pass. The first implementation passes 132 tests but fails rotated containment;
its source, binary and log remain. The interior-seed correction changes no test
or exact containment assertion. The saved authored witness independently confirms
translation of original contours, unchanged rotation/reflection, charged work and
a valid source fixture. It is not a searched output or quality comparison.

Twelve rejection-boundary outcomes pass 24 frozen-CLI checks. Ten public outcomes,
four CLI comparisons, exact normal results and deterministic common replays apart
from wall time pass. Strict lint and the experimental executable build pass.
All 156 formatted files reconstruct exactly; 155 and all other runtime blocks
are unchanged. Five adversarial harness checks pass. Pilot execution, scoring,
case ordering and the previously qualified PID-reuse guard remain AST-identical.

The next pilot must commit its plan before measurement, retaining the same four
development jobs, two kerfs, three seeds, matched 60-second budgets and eight
physical CCD0 cores. No quality measurement has started at this checkpoint.
Any pilot success still requires the full original 13-job H5 gate.
Production, reserved inputs, release and README claims are unchanged.
**H2/H5 remain open; completed milestone weight is 60%.**

[Checks](h5-contained-return-preparation-20261018/checks.json),
[retained initial failures](h5-contained-return-preparation-20261018/expected-failure.json),
[preserved boundary-contact failure and repair](h5-contained-return-preparation-20261018/containment-repair.json),
[original-contour witness](h5-contained-return-preparation-20261018/seed-checks.json),
[source reconstruction](h5-contained-return-preparation-20261018/reconstruction.json),
[raw archive integrity](h5-contained-return-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-contained-return-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_functional_checks_pass':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
