"""Preserve the failed boundary-contact build and propose an interior seed."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-contained-return-probe-20261018'
fail=out/'failed-boundary-contact';fail.mkdir()
log=(out/'core-tests.log').read_text(encoding='utf-8')
assert '132 passed; 1 failed' in log and 'Permitted mixed group must keep its orientations while translating' in log
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
p=fail/rel;p.parent.mkdir(parents=True);shutil.copyfile(path,p)
for name in ['format.log','core-tests.log','progress.json','build-failure.json','apply.py']:
    shutil.copyfile(out/name,fail/name)
target=Path(json.loads((out/'preparation.json').read_bytes())['target'])
bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
shutil.copyfile(bins[0],fail/'authored-tests.exe')
s=path.read_text(encoding='utf-8');start=s.index('    let correction = |low:');end=s.index('    let dx = correction(',start)
before=s[start:end]
after='''    let correction = |low: f32, high: f32, min: f32, max: f32| {
        // Place the seed just inside instead of exactly on a rounded edge.
        // The final box check remains exact; this is a real translation,
        // never a relaxed geometry tolerance. Limit it to half the free span.
        let scale = low.abs().max(high.abs()).max(min.abs()).max(max.abs()).max(1.0);
        let room = ((max - min) - (high - low)).max(0.0);
        let inset = (4.0 * f32::EPSILON * scale).min(room * 0.5);
        if low < min {
            min - low + inset
        } else if high > max {
            max - high - inset
        } else {
            0.0
        }
    };
'''
fixed=s[:start]+after+s[end:]
assert fixed.split('#[cfg(test)]',1)[1]==s.split('#[cfg(test)]',1)[1]
record={'before':before,'after':after,'all_133_tests_unchanged':True,'exact_containment_check_unchanged':True,
    'failure_log_sha256':sha256((fail/'core-tests.log').read_bytes()).hexdigest(),
    'failure_binary_sha256':sha256((fail/'authored-tests.exe').read_bytes()).hexdigest(),
    'failure_source_sha256':sha256((fail/rel).read_bytes()).hexdigest(),'new_searches':0}
(out/'containment-repair.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
path.write_text(fixed,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
# Remove only the duplicated build records; immutable copies remain above.
for name in ['format.log','core-tests.log','progress.json','build-failure.json']:(out/name).unlink()
shutil.copyfile(__file__,out/'repair.py');print(json.dumps({k:v for k,v in record.items() if k not in ['before','after']}))
