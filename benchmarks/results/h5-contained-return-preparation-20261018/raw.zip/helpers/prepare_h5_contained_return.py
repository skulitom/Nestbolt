"""Add contained-return seed regressions to an isolated candidate before implementation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-contained-return-probe-20261018'
old=root/'output/h5-boundary-pair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
evidence=load(root/'benchmarks/results/h5-exchange-failure-observer-20261018/failure-detail-checks.json')
assert evidence['all_checks_passed'] and evidence['failure_reason_counts']=={'material_increased':4,'source_loss_positive':18}
assert all(s['after']['pair_violations'] for s in evidence['sources'])
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');text=original
stub='''// Bounded return initialization; acceptance remains independently guarded.
fn contain_return_group(
    _victims: &[IncomingMember],
    _poses: &mut [DTransformation],
    _bounds: &Rect,
    _clock: &Clock,
) -> bool {
    false
}

'''
needle='// Only choose the reciprocal frame';assert text.count(needle)==1;text=text.replace(needle,stub+needle)
before='''                    let returned = if victims.len() == 1 {'''
after=before.replace('let returned','let mut returned');assert text.count(before)==1;text=text.replace(before,after)
needle='''                    for ((_, victim, _), pose) in victims.iter().zip(returned) {'''
call='''                    contain_return_group(&victims, &mut returned, &last_container.outer_cd().bbox(), &self.clock);
'''
assert text.count(needle)==1;text=text.replace(needle,call+needle)
assert text.replace(stub,'').replace(call,'').replace(after,before)==original
tests='''
    // BEGIN contained-return tests
    fn return_seed_members(source:&JLayout)->Vec<IncomingMember> {
        source.placed_items().iter().take(2).map(|(key,p)|(key,p.item().clone(),p.d_transf())).collect()
    }

    fn return_seed_bounds(members:&[IncomingMember],poses:&[DTransformation])->Rect {
        assert_eq!(members.len(),poses.len());assert!(!members.is_empty());
        let mut x0=f32::INFINITY;let mut y0=f32::INFINITY;
        let mut x1=f32::NEG_INFINITY;let mut y1=f32::NEG_INFINITY;
        for ((_,item,_),pose) in members.iter().zip(poses) {
            let mut shape=item.shape_cd().as_ref().clone();shape.transform_from(item.shape_cd(),&pose.compose());
            let b=shape.bbox();x0=x0.min(b.x_min);y0=y0.min(b.y_min);x1=x1.max(b.x_max);y1=y1.max(b.y_max);
        }
        Rect::try_new(x0,y0,x1,y1).unwrap()
    }

    fn return_seed_pose_bits(poses:&[DTransformation])->Vec<([u32;3],bool)> {
        poses.iter().map(|p|{let(x,y)=p.translation();([p.rotation().to_bits(),x.to_bits(),y.to_bits()],p.reflected)}).collect()
    }

    #[test]
    fn contained_return_moves_fitting_group_inside_and_charges_all_transforms() {
        let (job,layout)=boundary_pair_fixture(false);let model=Model::new(&job).unwrap();
        let sheets=model.sheets_of(&layout).unwrap();let members=return_seed_members(sheets[1].layout());
        let mut poses=vec![DTransformation::new(0.0,(20.0,120.0)),DTransformation::new(0.0,(50.0,120.0))];
        let before=poses.clone();let bounds=Rect::try_new(0.0,0.0,100.0,100.0).unwrap();
        assert!(return_seed_bounds(&members,&poses).y_max>bounds.y_max);
        let clock=Clock::new(Timing::Work,120.0);
        assert!(contain_return_group(&members,&mut poses,&bounds,&clock),"Fitting returned group must be moved inside");
        let b=return_seed_bounds(&members,&poses);
        assert!(b.x_min>=bounds.x_min && b.y_min>=bounds.y_min && b.x_max<=bounds.x_max && b.y_max<=bounds.y_max);
        for (old,new) in before.iter().zip(&poses) {
            assert_eq!(old.rotation().to_bits(),new.rotation().to_bits());assert_eq!(old.reflected,new.reflected);
            assert_eq!(old.translation().0.to_bits(),new.translation().0.to_bits());
        }
        assert_eq!(poses[1].translation().0-poses[0].translation().0,30.0);
        assert_eq!(poses[1].translation().1,poses[0].translation().1);
        assert_eq!(clock.counts().evaluations,4.0,"Both original and proposed member bounds must be charged");
        assert!(clock.counts().evaluated_vertices>0.0 && clock.work()>0.0);
        eprintln!("CONTAINED_RETURN_WITNESS {}",serde_json::json!({"job":job,
            "source_layout":model.to_layout(&sheets),"bounds":[bounds.x_min,bounds.y_min,bounds.x_max,bounds.y_max],
            "before":members.iter().zip(&before).map(|((_,item,_),p)|serde_json::json!({"part_id":job.parts[model.part[item.idx()]].id,"transform":model.external(item.idx(),p)})).collect::<Vec<_>>(),
            "after":members.iter().zip(&poses).map(|((_,item,_),p)|serde_json::json!({"part_id":job.parts[model.part[item.idx()]].id,"transform":model.external(item.idx(),p)})).collect::<Vec<_>>(),
            "work":clock.counts()}));
    }

    #[test]
    fn contained_return_empty_contained_and_oversized_groups_are_bitwise_unchanged() {
        let (job,layout)=boundary_pair_fixture(false);let model=Model::new(&job).unwrap();
        let sheets=model.sheets_of(&layout).unwrap();let members=return_seed_members(sheets[1].layout());
        let original=vec![DTransformation::new(0.0,(20.0,30.0)),DTransformation::new(0.0,(50.0,30.0))];
        for bounds in [Rect::try_new(0.0,0.0,100.0,100.0).unwrap(),Rect::try_new(0.0,0.0,1.0,1.0).unwrap()] {
            let mut poses=original.clone();let clock=Clock::new(Timing::Work,120.0);
            assert!(!contain_return_group(&members,&mut poses,&bounds,&clock));
            assert_eq!(return_seed_pose_bits(&poses),return_seed_pose_bits(&original));
        }
        let mut empty=vec![];let bounds=Rect::try_new(0.0,0.0,100.0,100.0).unwrap();let clock=Clock::new(Timing::Work,120.0);
        assert!(!contain_return_group(&[],&mut empty,&bounds,&clock));assert!(empty.is_empty());assert_eq!(clock.work(),0.0);
    }

    #[test]
    fn contained_return_preserves_mixed_member_orientations_and_reflection() {
        let (mut job,layout)=boundary_pair_fixture(true);
        for part in &mut job.parts {part.allow_mirror=true;part.rotations=Rotations::List{degrees:vec![0.0,90.0,180.0,270.0]};}
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();let members=return_seed_members(sheets[1].layout());
        assert!(!std::sync::Arc::ptr_eq(&members[0].1,&members[1].1));
        let mut poses=vec![DTransformation::new(0.0,(-30.0,20.0)).with_reflection(true),
            DTransformation::new(std::f32::consts::FRAC_PI_2,(-30.0,50.0))];
        assert!(members.iter().zip(&poses).all(|((_,item,_),p)|item.allowed_orientations().allows(p)));
        let before=poses.clone();let bounds=Rect::try_new(0.0,0.0,100.0,100.0).unwrap();let clock=Clock::new(Timing::Work,120.0);
        assert!(contain_return_group(&members,&mut poses,&bounds,&clock),"Permitted mixed group must keep its orientations while translating");
        let b=return_seed_bounds(&members,&poses);assert!(b.x_min>=0.0 && b.y_min>=0.0 && b.x_max<=100.0 && b.y_max<=100.0);
        for ((old,new),(_,item,_)) in before.iter().zip(&poses).zip(&members) {
            assert_eq!(old.rotation().to_bits(),new.rotation().to_bits());assert_eq!(old.reflected,new.reflected);
            assert_eq!(old.translation().1.to_bits(),new.translation().1.to_bits());assert!(item.allowed_orientations().allows(new));
        }
        assert_eq!(poses[0].translation().0,poses[1].translation().0);
        assert_eq!(poses[1].translation().1-poses[0].translation().1,30.0);
    }
    // END contained-return tests
'''
pos=text.rindex('\n}');text=text[:pos]+tests+text[pos:];path.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
    'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'changed_files':[rel],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'target':str(root/'output/h5-contained-return-target-20261018'),'unchanged_prior_tests':130,'new_tests':3,
    'normal_mode_unchanged':True,'budgets_and_acceptance_unchanged':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py');(out/'stub.txt').write_text(stub,encoding='utf-8',newline='\n')
print(json.dumps({'prepared':True,'new_tests':3,'prior_tests':130,'new_searches':0}))
