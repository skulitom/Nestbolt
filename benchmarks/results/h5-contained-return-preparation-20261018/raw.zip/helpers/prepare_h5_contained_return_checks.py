"""Reuse the qualified pilot method with bounded return seeding as its sole lever."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-contained-return-probe-20261018'
ref=root/'scripts/h5_boundary_pair_pilot.py';original=ref.read_text(encoding='utf-8');s=original
s=s.replace('h5-boundary-pair-probe','h5-contained-return-probe').replace('h5-boundary-pair-preparation','h5-contained-return-preparation')
s=s.replace('h5-boundary-priority-pilot','h5-boundary-pair-pilot')
s=s.replace("PROBE/'pair-checks/checks.json'", "PROBE/'seed-checks/checks.json'")
needle="ROOT/'benchmarks/results/h5-boundary-observer-20261018/source-review.json'"
assert s.count(needle)==1
s=s.replace(needle,needle+",\n                  ROOT/'benchmarks/results/h5-exchange-failure-observer-20261018/failure-detail-checks.json',\n                  ROOT/'benchmarks/results/h5-exchange-failure-observer-20261018/interpretation.json'")
end=s.index('"""',3)+3
s='''"""Paired development pilot of bounded return-group initialization.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The isolated candidate translates a
fitting returned group inside the existing source-container bounding box.
Already contained, oversized, malformed or numerically uncontained cases
retain the old seed. Orientations/reflections remain exact and all added
transformed-geometry work is charged. Existing choices, repairs, budgets and
full material/geometry acceptance remain. All 130 prior tests are unchanged;
three tests cover containment, charged work, exact no-ops and permissions.
This descriptive pilot cannot close H5 or justify a comparative claim.
"""'''+s[end:]
s=s.replace('Isolated boundary-pair candidate','Isolated contained-return candidate')
path=root/'scripts/h5_contained_return_pilot.py';assert not path.exists();compile(s,str(path),'exec');path.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
names=['blocks','summarize','case','measure','require_runner_stopped','require_measurements_finished']
for n in names:assert ast.dump(fn(s,n))==ast.dump(fn(original,n))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
    'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),
    'identical_function_ASTs':names,'scoring_measurement_and_PID_reuse_guard_unchanged':True}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
for stage in ['public','branch','harness']:
    s=(root/f'output/check_h5_boundary_pair_{stage}.py').read_text(encoding='utf-8')
    s=s.replace('h5-boundary-pair','h5-contained-return').replace('h5_boundary_pair','h5_contained_return')
    compile(s,stage,'exec');(root/f'output/check_h5_contained_return_{stage}.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
