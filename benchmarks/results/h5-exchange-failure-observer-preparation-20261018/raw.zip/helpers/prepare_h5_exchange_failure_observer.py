"""Add observations only inside existing failed exchange branches."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import ast, difflib, json, shutil, sys

root = Path(__file__).resolve().parents[1]
out = root/'output/h5-exchange-failure-observer-20261018'
old = root/'output/h5-boundary-pair-observer-20261018/workspace'
work = out/'workspace'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
prior = root/'benchmarks/results/h5-boundary-pair-observer-20261018'
assert load(prior/'verification.json')['valid'] == 2
assert load(prior/'layout-checks.json')['attempts_with_all_height_copies'] == 11
assert load(prior/'observed-exchanges.json')['summary']['outcomes'] == {'material_guard_or_expiry':4, 'source_repair_or_expiry':18}
out.mkdir(); shutil.copytree(old, work)
rel = 'crates/core/src/sheets/vstrip/exchange.rs'
original = (old/rel).read_text(encoding='utf-8'); text = original; changes = []

def replace(before, after):
    global text
    assert text.count(before) == 1
    text = text.replace(before, after); changes.append([before, after])

replace('"outcome":"pending"}));', '"outcome":"pending", "failure_detail":null}));')
for outcome, addition in [
    ('receiver_repair_failed', '''
                        trace.attempts[attempt_index]["failure_detail"] = serde_json::json!({
                            "receiver_loss": receiver_tracker.total_loss(),
                        });'''),
    ('source_repair_or_expiry', '''
                        let initial = if victims.len() == 1 {
                            vec![convert_sample_to_closest_feasible(incoming_old, &victims[0].1)]
                        } else {
                            return_group_poses(&victims, proposal.incoming, incoming_old)
                        };
                        trace.attempts[attempt_index]["failure_detail"] = serde_json::json!({
                            "source_loss": source_tracker.total_loss(),
                            "source_after": JLayout::from_snapshot(&source_snapshot).placed_items().values().map(|p| {
                                let item = p.item().idx();
                                serde_json::json!({"part_id":self.model.job.parts[self.model.part[item]].id,
                                    "transform":self.model.external(item, &p.d_transf())})
                            }).collect::<Vec<_>>(),
                            "returned_initial": victims.iter().zip(initial).map(|((_, item, _), pose)| {
                                let item = item.idx();
                                serde_json::json!({"part_id":self.model.job.parts[self.model.part[item]].id,
                                    "transform":self.model.external(item, &pose)})
                            }).collect::<Vec<_>>(),
                        });'''),
    ('material_guard_or_expiry', '''
                        trace.attempts[attempt_index]["failure_detail"] = serde_json::json!({
                            "material_increased": exchange_increases_material(before, after),
                            "metrics": after,
                            "layout": trial_layout,
                        });'''),
]:
    before = 'serde_json::json!("'+outcome+'");'
    replace(before, before + addition)

reverse = text
for before, after in reversed(changes):
    assert reverse.count(after) == 1; reverse = reverse.replace(after, before)
assert reverse == original
assert text.split('#[cfg(test)]',1)[1] == original.split('#[cfg(test)]',1)[1]
(work/rel).write_text(text, encoding='utf-8', newline='\n')
(out/'substitutions.json').write_text(json.dumps(changes, indent=2)+'\n', encoding='utf-8', newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='parent/'+rel,tofile='failure-observer/'+rel)),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts')); from h2_import_audit import source_digest
plan = {'utc':datetime.now(timezone.utc).isoformat(), 'purpose':__doc__, 'old_source':str(old),
    'source_files':[{'path':p.relative_to(old).as_posix(),'sha256':digest(p)} for p in sorted(old.rglob('*')) if p.is_file()],
    'changed_file':rel, 'changed_files':[rel], 'production_digest':source_digest(),
    'target':str(root/'output/h5-exchange-failure-observer-target-20261018'),
    'all_130_prior_tests_unchanged':True, 'exact_preformat_reversal':True,
    'original_short_circuit_conditions_unchanged':True,
    'no_added_clock_reads_or_work_charges':True,
    'detail_computed_only_after_original_failure_decision':True,
    'trace_overhead_can_change_wall_trajectory':True, 'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')

def adapt(s):
    return s.replace('h5-boundary-pair-observer', 'h5-exchange-failure-observer').replace('h5_boundary_pair_observer','h5_exchange_failure_observer')

for name in ['build_h5_boundary_pair_observer.py', 'check_h5_boundary_pair_observer_source.py']:
    target = root/'output'/name.replace('h5_boundary_pair_observer','h5_exchange_failure_observer')
    s=adapt((root/'output'/name).read_text(encoding='utf-8')); compile(s,str(target),'exec')
    target.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'prepared':True,'parent_tests_unchanged':130,'new_searches':0,'changes':len(changes)}))
