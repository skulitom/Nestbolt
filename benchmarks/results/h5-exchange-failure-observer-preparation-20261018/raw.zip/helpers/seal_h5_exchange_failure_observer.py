"""Seal the focused observation build before its two diagnostic searches."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exchange-failure-observer-20261018'
out=root/'benchmarks/results/h5-exchange-failure-observer-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_exchange_failure_observer as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '130 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
source=load(probe/'reconstruction.json');assert source['all_formatted_files_exact'] and len(source['files'])==156
assert source['unchanged_other_files']==155 and source['all_130_original_tests_unchanged']
assert runner.prior.source_digest()==plan['production_digest']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==16
assert len(reader['malformed_records_rejected'])==34 and reader['reader_sha256']==digest(root/'scripts/h5_exchange_failure_observer.py')
assert reader['all_choice_poses_match_unique_baseline_members']
assert len(reader['synthetic_parser_cases'])==4 and reader['source_return_inventories_verified']
assert reader['parent_profile_branch_witnesses_exact']==12 and reader['actual_profile_branch_counters_exact']
assert reader['frozen_CLI_baseline_checks']==reader['actual_invocations']>0
assert digest(probe/'authored-tests.exe')==reader['test_binary_sha256']
method=load(probe/'runner-method.json');assert method['measurement_function_AST_exact'] and method['runner_sha256']==reader['reader_sha256']
assert digest(root/method['reference'])==method['reference_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_exchange_failure_observer.py','prepare_h5_exchange_failure_reader.py',
             'add_h5_exchange_failure_reader_checks.py','prepare_h5_exchange_failure_finishers.py',
             'build_h5_exchange_failure_observer.py','check_h5_exchange_failure_observer_reader.py',
             'check_h5_exchange_failure_observer_source.py','seal_h5_exchange_failure_observer.py',
             'record_h5_exchange_failure_observer_preparation.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_exchange_failure_observer.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_qualified':True,'optimized_core_tests_passed':130,'original_tests_unchanged':130,
    'strict_lint_passed':True,'observer_build_passed':True,'authored_test_cases':16,'malformed_records_rejected':34,
    'frozen_CLI_baseline_checks':reader['frozen_CLI_baseline_checks'],'baseline_metrics_exact':True,
    'parent_profile_branch_witnesses_exact':12,'actual_profile_branch_counters_exact':True,
    'exact_choice_poses_verified':True,'exact_parent_reconstruction':True,'unchanged_other_files':155,'production_unchanged':True,'measured_search_started':False,'H5_complete':False}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','reconstruction.json','instrumentation.patch','runner-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'authored-trace-reader/checks.json',out/'reader-checks.json')
doc=f'''# Exchange failure reasons — observation preparation, 2026-10-18

The [exact-copy diagnosis](h5-boundary-pair-observer-20261018.md) found eleven
attempts selecting both height-setting copies: seven reached a combined
source-repair/deadline rejection and four a combined material/deadline rejection.
This observer distinguishes those outcomes before any further search change.

Only the existing rejection branches gain details. Source failures record the
actual separator loss, failed source poses and the purely recomputed initial
return poses. Material/deadline failures record the actual validated trial and
metrics, with the original material predicate. Receiver failures record loss.
No original branch, short-circuit expression, clock read, work charge, repair,
proposal or test changes. Positive source loss establishes repair failure;
zero loss implies the original deadline branch fired. The source record does
not claim that positive loss proves global infeasibility or excludes expiry.

All 130 optimized tests, strict lint and the executable build pass. Exact
reconstruction verifies all 156 source files, with 155 unchanged. Sixteen
authored cases exercise the actual logs; 35 saved baselines validate with
exact metrics, and twelve original branch witnesses/counters match exactly.
The reader checks source/return inventory and every physical transform.
Thirty-four malformed records are rejected. Four explicitly synthetic parser
cases test zero-loss expiry and material/sheet comparisons; these are not
searches or independently validated material-increase examples. Actual trial
layouts captured by the diagnostic must separately pass public validation,
filled-outer clearance and independent rectangular-stock material checks.

Two serial panel diagnostics retain both kerfs, seed zero, 60 seconds and
physical CCD0 CPU 8, with the same 20-minute session cap. Execution is
AST-identical to the preceding diagnostic. The plan is committed first.
Logging may change wall trajectories; no quality or speed comparison follows.
The failed 72-run pilot remains authoritative. No production integration,
reserved-data access or new release. H2/H5 remain open at 60%.

[Checks](h5-exchange-failure-observer-preparation-20261018/checks.json),
[reader checks](h5-exchange-failure-observer-preparation-20261018/reader-checks.json),
[source reconstruction](h5-exchange-failure-observer-preparation-20261018/reconstruction.json),
[raw archive integrity](h5-exchange-failure-observer-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-exchange-failure-observer-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_qualified':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
