"""Extend reader qualification with bounded synthetic branch classification cases."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'output/check_h5_exchange_failure_observer_reader.py'
s=p.read_text(encoding='utf-8')
s=s.replace("['traces','attempt_rows','visit_rows']", "['traces','attempt_rows','visit_rows','failure_details']")
needle="cli=root/'target/release/nestbolt.exe';"
assert s.count(needle)==1
extra='''# These are parser-only fixtures, not searches or geometry evidence.
source_trace=next(t for t in all_traces if any(a['outcome']=='source_repair_or_expiry' for a in t['attempts']))
source_index=next(i for i,a in enumerate(source_trace['attempts']) if a['outcome']=='source_repair_or_expiry')
receiver_trace=next(t for t in all_traces if any(a['outcome']=='receiver_repair_failed' for a in t['attempts']))
assert summary['failure_reason_counts']['source_loss_positive']>0
assert summary['failure_reason_counts']['receiver_loss_positive']>0

def reject_detail(name,original,index,mutate):
    t=copy.deepcopy(original);mutate(t['attempts'][index])
    try:runner.check_traces([t])
    except (AssertionError,KeyError,TypeError,IndexError):rejected.append(name)
    else:raise AssertionError('Reader accepted '+name)

for value in [-1.0,float('nan'),True,None]:
    reject_detail('invalid source loss '+repr(value),source_trace,source_index,lambda a,v=value:a['failure_detail'].update(source_loss=v))
reject_detail('missing detail',source_trace,source_index,lambda a:a.pop('failure_detail'))
reject_detail('missing returned pose',source_trace,source_index,lambda a:a['failure_detail']['returned_initial'].pop())
reject_detail('missing source copy',source_trace,source_index,lambda a:a['failure_detail']['source_after'].pop())
reject_detail('invalid source transform',source_trace,source_index,lambda a:a['failure_detail']['source_after'][0]['transform']['translation'].__setitem__(0,float('inf')))
receiver_index=next(i for i,a in enumerate(receiver_trace['attempts']) if a['outcome']=='receiver_repair_failed')
reject_detail('zero receiver loss on failure',receiver_trace,receiver_index,lambda a:a['failure_detail'].update(receiver_loss=0.0))
synthetic=[]
t=copy.deepcopy(source_trace);t['attempts'][source_index]['failure_detail']['source_loss']=0.0
check=runner.check_traces([t]);assert any(d['attempt_index']==source_index and d['reason']=='source_deadline' for d in check['failure_details'])
synthetic.append('source zero loss classifies the original short-circuit as deadline')

def material_case():
    t=copy.deepcopy(source_trace);a=t['attempts'][source_index];a['outcome']='material_guard_or_expiry'
    a['failure_detail']={'material_increased':False,'metrics':copy.deepcopy(t['baseline']['metrics']),'layout':copy.deepcopy(t['baseline']['layout'])}
    return t,a

t,a=material_case();check=runner.check_traces([t]);assert any(d['attempt_index']==source_index and d['reason']=='exchange_deadline' for d in check['failure_details'])
synthetic.append('equal material and sheets classify as exchange deadline')
for key in ['material_area','sheets_used']:
    t,a=material_case();a['failure_detail']['metrics'][key]+=1;a['failure_detail']['material_increased']=True
    check=runner.check_traces([t]);assert any(d['attempt_index']==source_index and d['reason']=='material_increased' for d in check['failure_details'])
    synthetic.append('parser-only increase of '+key+' classifies material rejection; not a validated geometry claim')
t,a=material_case()
reject_detail('false material classification',t,source_index,lambda a:a['failure_detail'].update(material_increased=True))
reject_detail('missing trial placement',t,source_index,lambda a:a['failure_detail']['layout']['placements'].pop())
reject_detail('nonfinite trial material',t,source_index,lambda a:a['failure_detail']['metrics'].update(material_area=float('inf')))
reject_detail('unknown trial sheet',t,source_index,lambda a:a['failure_detail']['layout']['placements'][0].update(sheet_id='unknown'))
assert len(synthetic)==4 and len(rejected)==34
'''
s=s.replace(needle,extra+'\n'+needle)
s=s.replace("'all_checks_pass':True,'authored_test_traces':rows", "'all_checks_pass':True,'synthetic_parser_cases':synthetic,'actual_failure_reason_counts':summary['failure_reason_counts'],'source_return_inventories_verified':True,'authored_test_traces':rows")
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Added thirteen malformed-detail cases and four explicitly synthetic parser classifications.')
