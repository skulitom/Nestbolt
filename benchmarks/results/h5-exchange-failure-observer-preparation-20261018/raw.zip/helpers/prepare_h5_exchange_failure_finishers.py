"""Prepare sealing, unchanged baseline audits and evidence documents."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def adapt(s):return s.replace('h5-boundary-pair-observer','h5-exchange-failure-observer').replace('h5_boundary_pair_observer','h5_exchange_failure_observer')
def save(name,s):
    compile(s,name,'exec');(root/'output'/name).write_text(s,encoding='utf-8',newline='\n')
for name in ['finish_h5_boundary_pair_observer.py','check_h5_boundary_pair_observer_layouts.py']:
    s=adapt((root/'output'/name).read_text(encoding='utf-8'))
    save(name.replace('h5_boundary_pair_observer','h5_exchange_failure_observer'),s)
s=adapt((root/'output/seal_h5_boundary_pair_observer.py').read_text(encoding='utf-8'))
s=s.replace("==21", "==34").replace("'malformed_records_rejected':21", "'malformed_records_rejected':34")
start=s.index('for name in [');end=s.index("files['runner.py']",start)
s=s[:start]+'''for name in ['prepare_h5_exchange_failure_observer.py','prepare_h5_exchange_failure_reader.py',
             'add_h5_exchange_failure_reader_checks.py','prepare_h5_exchange_failure_finishers.py',
             'build_h5_exchange_failure_observer.py','check_h5_exchange_failure_observer_reader.py',
             'check_h5_exchange_failure_observer_source.py','seal_h5_exchange_failure_observer.py',
             'record_h5_exchange_failure_observer_preparation.py']:
    files['helpers/'+name]=root/'output'/name
'''+s[end:]
start=s.index("doc=f'''");end=s.index("(out.parent/",start)
s=s[:start]+'''doc=f\'''# Exchange failure reasons — observation preparation, 2026-10-18

The [exact-copy diagnosis](h5-boundary-pair-observer-20261018.md) found eleven
attempts selecting both height-setting copies: seven reached a combined
source-repair/deadline rejection and four a combined material/deadline rejection.
This observer distinguishes those outcomes before any further search change.

Only the existing rejection branches gain details. Source failures record the
actual separator loss, failed source poses and the purely recomputed initial
return poses. Material/deadline failures record the actual validated trial and
metrics, with the original material predicate. Receiver failures record loss.
No original branch, short-circuit expression, clock read, work charge, repair,
proposal or test changes. Positive source loss establishes repair failure;
zero loss implies the original deadline branch fired. The source record does
not claim that positive loss proves global infeasibility or excludes expiry.

All 130 optimized tests, strict lint and the executable build pass. Exact
reconstruction verifies all 156 source files, with 155 unchanged. Sixteen
authored cases exercise the actual logs; 35 saved baselines validate with
exact metrics, and twelve original branch witnesses/counters match exactly.
The reader checks source/return inventory and every physical transform.
Thirty-four malformed records are rejected. Four explicitly synthetic parser
cases test zero-loss expiry and material/sheet comparisons; these are not
searches or independently validated material-increase examples. Actual trial
layouts captured by the diagnostic must separately pass public validation,
filled-outer clearance and independent rectangular-stock material checks.

Two serial panel diagnostics retain both kerfs, seed zero, 60 seconds and
physical CCD0 CPU 8, with the same 20-minute session cap. Execution is
AST-identical to the preceding diagnostic. The plan is committed first.
Logging may change wall trajectories; no quality or speed comparison follows.
The failed 72-run pilot remains authoritative. No production integration,
reserved-data access or new release. H2/H5 remain open at 60%.

[Checks](h5-exchange-failure-observer-preparation-20261018/checks.json),
[reader checks](h5-exchange-failure-observer-preparation-20261018/reader-checks.json),
[source reconstruction](h5-exchange-failure-observer-preparation-20261018/reconstruction.json),
[raw archive integrity](h5-exchange-failure-observer-preparation-20261018/integrity.json).
\'''
'''+s[end:]
s=s.replace("assert reader['parent_profile_branch_witnesses_exact']==12", "assert len(reader['synthetic_parser_cases'])==4 and reader['source_return_inventories_verified']\nassert reader['parent_profile_branch_witnesses_exact']==12")
save('seal_h5_exchange_failure_observer.py',s)
s=adapt((root/'output/record_h5_boundary_pair_observer_preparation.py').read_text(encoding='utf-8'))
start=s.index("note=f'''");end=s.index('\ndef append(',start)
s=s[:start]+'''note=f\'''**N4 exchange-failure observation, 2026-10-18:** [the isolated failure-detail observer qualifies](../benchmarks/results/h5-exchange-failure-observer-preparation-20261018.md).
All 130 optimized tests and strict code checks pass. The original short-circuit
conditions, clock reads and work charges are unchanged; extra loss/pose or
validated-trial data is recorded only inside existing failed branches.
Sixteen authored cases, 35 public baseline checks, twelve exact parent branch
witnesses, 34 malformed-record rejections and four synthetic parser cases pass.
The same two serial panel searches retain both kerfs, seed zero and 60 seconds.
Logging can change wall trajectories; no quality comparison or integration.
The committed scope requires independent checks of captured trials. H2/H5
remain open at 60%.
\'''
'''+s[end:]
s=s.replace("needle='**N4 boundary-pair outcome, 2026-10-18:**'", "needle='**N4 boundary-pair diagnosis, 2026-10-18:**'")
s=s.replace('Qualify boundary-pair observation','Qualify exchange failure reasons')
save('record_h5_exchange_failure_observer_preparation.py',s)
print('Prepared failure-observer sealing, committed-scope records and baseline audit helpers.')
