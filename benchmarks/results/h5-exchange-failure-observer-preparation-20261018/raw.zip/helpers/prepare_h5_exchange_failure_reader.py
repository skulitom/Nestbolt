"""Prepare strict failure-detail reader and unchanged diagnostic execution method."""
from pathlib import Path
from hashlib import sha256
import ast, json
root=Path(__file__).resolve().parents[1]
parent=root/'scripts/h5_boundary_pair_observer.py'
runner=root/'scripts/h5_exchange_failure_observer.py'
out=root/'output/h5-exchange-failure-observer-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def adapt(s):return s.replace('h5-boundary-pair-observer','h5-exchange-failure-observer').replace('h5_boundary_pair_observer','h5_exchange_failure_observer')
before=parent.read_text(encoding='utf-8');s=adapt(before)
s=s.replace('Observe exact physical copies selected by the boundary-pair candidate.', 'Diagnose existing exchange failure branches without changing their conditions.')
s=s.replace("ROOT/'scripts/h5_frontier_observer.py',", "ROOT/'scripts/h5_frontier_observer.py', ROOT/'scripts/h5_boundary_pair_observer.py',")
start=s.index('def check_traces(');end=s.index('\n\ndef parse_log(',start)
wrapper='''def check_traces(traces, stats=None):
    import copy
    import h5_boundary_pair_observer as parent
    stripped=copy.deepcopy(traces)
    details=[]
    for invocation,(trace,clean) in enumerate(zip(traces,stripped)):
        base=trace['baseline']
        source=Counter(p['part_id'] for p in base['layout']['placements'] if p['sheet_id']==base['source_sheet'])
        job_inventory=Counter({p['id']:p['quantity'] for p in base['job']['parts']})
        def finite_nonnegative(value):
            assert type(value) in [int,float] and math.isfinite(value) and value>=0
        def poses(values):
            assert isinstance(values,list)
            for p in values:pose_key(p)
            return Counter(p['part_id'] for p in values)
        for index,(attempt,without) in enumerate(zip(trace['attempts'],clean['attempts'])):
            assert 'failure_detail' in attempt
            detail=without.pop('failure_detail');outcome=attempt['outcome'];reason=None
            if outcome=='receiver_repair_failed':
                assert isinstance(detail,dict) and set(detail)=={'receiver_loss'}
                finite_nonnegative(detail['receiver_loss']);assert detail['receiver_loss']>0
                reason='receiver_loss_positive'
            elif outcome=='source_repair_or_expiry':
                assert isinstance(detail,dict) and set(detail)=={'source_loss','source_after','returned_initial'}
                finite_nonnegative(detail['source_loss'])
                assert poses(detail['returned_initial'])==Counter(attempt['returned'])
                expected=source.copy();expected.subtract(trace['choices'][attempt['choice_index']]);expected.update(attempt['returned'])
                assert all(v>=0 for v in expected.values())
                assert poses(detail['source_after'])==+expected
                reason='source_loss_positive' if detail['source_loss']>0 else 'source_deadline'
            elif outcome=='material_guard_or_expiry':
                assert isinstance(detail,dict) and set(detail)=={'material_increased','metrics','layout'}
                after=detail['metrics'];old=base['metrics']
                finite_nonnegative(after['material_area'])
                assert type(after['sheets_used']) is int and after['sheets_used']>0
                assert type(detail['material_increased']) is bool
                increased=after['sheets_used']>old['sheets_used'] or after['material_area']>old['material_area']
                assert detail['material_increased']==increased
                layout=detail['layout'];assert set(layout)==set(base['layout'])
                assert Counter(p['part_id'] for p in layout['placements'])==job_inventory
                known_sheets={p['sheet_id'] for p in base['layout']['placements']}
                for p in layout['placements']:
                    assert p['sheet_id'] in known_sheets
                    pose_key({'part_id':p['part_id'],'transform':p['transform']})
                reason='material_increased' if increased else 'exchange_deadline'
            else:
                assert detail is None
            if reason:
                details.append({'invocation':invocation,'attempt_index':index,'choice_index':attempt['choice_index'],
                    'target_sheet':attempt['target_sheet'],'outcome':outcome,'reason':reason,'detail':detail})
    result=parent.check_traces(stripped,stats)
    result['traces']=traces
    result['failure_details']=details
    result['failure_reason_counts']=dict(Counter(d['reason'] for d in details))
    result['failure_details_verified']=True
    return result
'''
s=s[:start]+wrapper+s[end:]
s=s.replace("'source_change':'Record the validated public baseline/job, credited and source sheet, original part names and exact public source poses for every choice, visited choices and actual attempted members with terminal outcome. All inserted observations reverse exactly; no decision or work charge changes.'", "'source_change':'Add failure details only after the original short-circuit branches reject: exact loss and source poses, or validated trial layout and material. The original conditions, clock reads, work charges and 130 tests remain. Recomputed return poses are pure and are observed only after failure.'")
compile(s,str(runner),'exec');assert not runner.exists();runner.write_text(s,encoding='utf-8',newline='\n')
def fn(text,name):return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
for name in ['run','pose_key','parse_log','read_trace']:
    assert ast.dump(fn(s,name))==ast.dump(fn(before,name))
(out/'runner-method.json').write_text(json.dumps({'reference':parent.relative_to(root).as_posix(),'reference_sha256':digest(parent),'measurement_function_AST_exact':True,'case_method_reused_unchanged':True,'parent_pose_reader_reused':True,'failure_details_read_after_original_rejections':True,'runner_sha256':digest(runner)},indent=2)+'\n',encoding='utf-8',newline='\n')
name='check_h5_exchange_failure_observer_reader.py'
s=adapt((root/'output/check_h5_boundary_pair_observer_reader.py').read_text(encoding='utf-8'))
# The original branch witnesses belong to the unobserved candidate, not this new observer.
assert "output/h5-boundary-pair-probe-20261018/branch-checks" in s
compile(s,name,'exec');(root/'output'/name).write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'runner_prepared':True,'unchanged_measured_run_AST':True,'new_searches':0}))
