"""New complete three-empty covers from immutable certified full masks."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-three-empty-covers-20261107';MASK=ROOT/'output/h5-five-column-covers-v2-20261107';SOURCE=ROOT/'output/h5-three-empty-sources-20261107';POOL=ROOT/'output/h5-five-column-cog-pool-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107';FRAME=1<<17;SENTINEL=(1<<18)-1
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();prior=load(SOURCE/'audit/checks.json');assert prior['passed'] and prior['source44_subsets_certified']==680 and load(MASK/'mask-audit/checks.json')['passed'];inputs=[Path(__file__),SOURCE/'canonical-source.json',SOURCE/'cases.json',SOURCE/'audit/checks.json',POOL/'sites.json',POOL/'roof-source.json',OLD/'fixed27-source.json',OLD/'source-recipe.json',OLD/'cog-derivation.json',MASK/'mask-audit/checks.json',MASK/'mask-audit/plan.json',MASK/'geometries.json',MASK/'stock-cover.json',MASK/'turned-4/source-inner-rectangles.json']+[MASK/'turned-4'/f'geometry-{i:02d}-classes.npz' for i in range(12)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reuse exactly the independently certified full17site masks for unchanged first-sheet source geometry, full stock domains and legal companion modes. Derive NEW complete covers allowing at most3cog-site bits and zero framebit17. Do not reuse the old retained<=2 covers. Classify every boundary point/open interval with a three-lowest-bit-removal predicate and merge equal labels into closed necessary boxes. An independent bit-count/coverage audit must verify all classes and source/domain/mode equality before use. These covers concern680 exact14-of17 subsets, not feasibility or a timed algorithm result.','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'old_retained_two_empty_covers_reused':False,'full_algorithm_budget_satisfied':False})
for p,h in load(MASK/'mask-audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h
canon=load(SOURCE/'canonical-source.json');base=[r for r in load(OLD/'fixed27-source.json') if r['sheet_id']=='sheet-0'];assert canon['first_frames']==base+load(POOL/'roof-source.json');assert canon['source_stocks']['sheet-0']==load(MASK/'stock-cover.json')['physical_stock_mm'];geometries=load(MASK/'geometries.json');assert len(geometries)==12;records=[]
for gi in range(12):
    with np.load(MASK/'turned-4'/f'geometry-{gi:02d}-classes.npz',allow_pickle=False) as data:xs=data['xcuts_um'];ys=data['ycuts_um'];mask=data['mask']
    assert mask.dtype==np.uint32 and int(mask.max())<1<<18 and mask.shape==(2*len(ys)-1,2*len(xs)-1);boxes=[];active={};retained=0
    def close(key,span):
        label,xa,xb=key;ya,yb=span;boxes.append([label,int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
    for yi,row in enumerate(mask):
        r1=row&(row-1);r2=r1&(r1-1);r3=r2&(r2-1);legal=((row&FRAME)==0)&(r3==0);retained+=int(legal.sum());labels=np.where(legal,row,np.uint32(SENTINEL));starts=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1];ends=np.r_[starts[1:]-1,len(labels)-1];current={}
        for xa,xb in zip(starts.tolist(),ends.tolist()):
            label=int(labels[xa])
            if label==SENTINEL:continue
            key=(label,xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
        for key,span in active.items():
            if key not in current:close(key,span)
        active=current
    for key,span in active.items():close(key,span)
    boxes.sort();assert retained==sum((r[7]-r[5]+1)*(r[8]-r[6]+1) for r in boxes);write(OUT/f'geometry-{gi:02d}.json',{'geometry':gi,'cover':boxes,'source_full_mask_sha256':digest(MASK/'turned-4'/f'geometry-{gi:02d}-classes.npz'),'source_geometry_sha256':digest(MASK/'geometries.json')});records.append({'geometry':gi,'continuous_classes':int(mask.size),'retained_classes':retained,'cover_boxes':len(boxes)})
write(OUT/'class-summary.json',records);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'continuous_classes':sum(r['continuous_classes'] for r in records),'retained_classes':sum(r['retained_classes'] for r in records),'cover_boxes':sum(r['cover_boxes'] for r in records),'independent_audit_pending':True,'source48_exclusions_reused_for_source44':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
