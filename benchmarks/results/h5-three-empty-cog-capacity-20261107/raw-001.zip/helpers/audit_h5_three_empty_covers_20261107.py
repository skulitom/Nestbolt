"""Exact source-cache equality and independent classwise cover completeness."""
from pathlib import Path
from hashlib import sha256
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-three-empty-covers-20261107';OUT=BASE/'audit';MASK=ROOT/'output/h5-five-column-covers-v2-20261107';SOURCE=ROOT/'output/h5-three-empty-sources-20261107';POOL=ROOT/'output/h5-five-column-cog-pool-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for folder in [MASK/'mask-audit',SOURCE/'audit']:
    assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile all prior source/mask certificates and exact source job, frame poses,17cog poses, full physical stock domain and mode geometry. Compare every source transformed cog pose directly with the analytic pose used for the certified world obstacles. Independently classify every full-mask boundary/interval cell by integer bit_count<=3 with fixed-framebit17 forbidden; site16 is an ordinary cog. Check each new box bounds and all covered cells, no duplicate coverage, and equality to the complete legal-class set. Controls distinguish three vs four absent cog bits and framebit17. No area or source-feasibility conclusion follows merely from these necessary covers.'})
canon=load(SOURCE/'canonical-source.json');base=[r for r in load(OLD/'fixed27-source.json') if r['sheet_id']=='sheet-0'];assert canon['first_frames']==base+load(POOL/'roof-source.json');der=load(OLD/'cog-derivation.json');theta=der['rotation_radians'];c,s=math.cos(theta),math.sin(theta);cx,cy=der['source_center'];sites=load(POOL/'sites.json');assert len(sites)==len(canon['first_cog_site_poses'])==17
for pose,site in zip(canon['first_cog_site_poses'],sites):
    t={'rotation_radians':theta,'mirrored':False,'translation':[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)]};assert pose['site']==site['site'] and pose['transform']==t
assert canon['source_stocks']['sheet-0']==load(MASK/'stock-cover.json')['physical_stock_mm'];g=load(MASK/'geometries.json');assert len(g)==12 and [r['geometry'] for r in g]==list(range(12));lookup=np.array([not(n&(1<<17)) and n.bit_count()<=3 for n in range(1<<18)],dtype=np.bool_);assert lookup[(1<<16)|(1<<15)|(1<<14)] and not lookup[(1<<16)|(1<<15)|(1<<14)|(1<<13)] and not lookup[1<<17];records=[]
for gi in range(12):
    record=load(BASE/f'geometry-{gi:02d}.json');path=MASK/'turned-4'/f'geometry-{gi:02d}-classes.npz';assert record['source_full_mask_sha256']==digest(path) and record['source_geometry_sha256']==digest(MASK/'geometries.json')
    with np.load(path,allow_pickle=False) as data:xs=data['xcuts_um'];ys=data['ycuts_um'];mask=data['mask']
    assert mask.shape==(2*len(ys)-1,2*len(xs)-1);legal=lookup[mask];covered=np.zeros(mask.shape,dtype=np.bool_)
    for label,l,b,r,t,xa,ya,xb,yb in record['cover']:
        assert [l,b,r,t]==[int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2])];assert lookup[label] and np.all(mask[ya:yb+1,xa:xb+1]==label) and not np.any(covered[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
    assert np.array_equal(legal,covered);records.append({'geometry':gi,'continuous_classes':int(mask.size),'retained_classes':int(legal.sum()),'cover_boxes':len(record['cover'])})
assert records==load(BASE/'class-summary.json');process=load(ROOT/'output/h5-three-empty-covers-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'class-controls.json',records);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'exact_frame_poses_verified':18,'exact_cog_site_poses_verified':17,'source_domain_and_modes_unchanged':True,'complete_full_masks_reused':12,'continuous_classes_verified':sum(r['continuous_classes'] for r in records),'retained_classes_verified':sum(r['retained_classes'] for r in records),'cover_boxes_verified':sum(r['cover_boxes'] for r in records),'old_two_empty_retained_covers_reused':False,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
