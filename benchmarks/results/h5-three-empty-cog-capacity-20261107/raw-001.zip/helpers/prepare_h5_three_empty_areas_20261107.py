"""Exact occupied-area bounds for all680 newly certified source44 subsets."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_five_column_area_tools_20261107 import difference_area
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-three-empty-areas-20261107';COVER=ROOT/'output/h5-three-empty-covers-20261107';MASK=ROOT/'output/h5-five-column-covers-v2-20261107';SOURCE=ROOT/'output/h5-three-empty-sources-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();prior=load(COVER/'audit/checks.json');assert prior['passed'] and load(SOURCE/'audit/checks.json')['source44_subsets_certified']==680;cases=load(SOURCE/'cases.json');assert len(cases)==680 and all(r['source_geometry_by_common_pair_certificate'] for r in cases);inputs=[Path(__file__),COVER/'audit/checks.json',MASK/'geometries.json',MASK/'stock-cover.json',MASK/'turned-4/source-inner-rectangles.json',SOURCE/'cases.json',SOURCE/'audit/checks.json',ROOT/'output/h5_five_column_area_tools_20261107.py']+[COVER/f'geometry-{i:02d}.json' for i in range(12)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For all680 independently certified fourteen-of-seventeen source cog choices, use the NEW complete three-empty covers. Keep exactly14cog sites and18frames mandatory; sourcecog14 is fixed on the independently verified short6/5/1. Select labels whose cog bits are contained in each omitted triple, sweep original L/insert component bounds, clip to outward stock and subtract mandatory source inners. Compute2040 exact integer family/combined areas for6remainingbrackets/16inserts. Preserve every result and require separate interval-event readback before exclusions. This is conditional geometry research on an already over60second numeric lineage; no optimizer or timed benchmark claim is permitted.','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'preparation_internal_cap_seconds':36,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'full_algorithm_budget_satisfied':False})
g=load(MASK/'geometries.json');sb=load(MASK/'stock-cover.json')['outward_stock_rectangle_um'];sources=load(MASK/'turned-4/source-inner-rectangles.json');covers={i:load(COVER/f'geometry-{i:02d}.json')['cover'] for i in range(12)};results=[]
for case in cases:
    omitted=case['omitted_sites'];assert len(omitted)==3 and all(0<=i<17 for i in omitted);allowed=sum(1<<i for i in omitted);fixed=[r['bounds_um'] for r in sources if r['site_bit']==17 or not(allowed&(1<<r['site_bit']))];regions={};areas={};before={}
    for family in ['bracket','insert']:
        rr=[]
        for mode in g:
            if mode['family']!=family:continue
            for label,l,b,r,t,*_ in covers[mode['geometry']]:
                if label&~allowed:continue
                for a,c,d,e in mode['outer_component_bounds_um']:
                    q=[max(l+a,sb[0]),max(b+c,sb[1]),min(r+d,sb[2]),min(t+e,sb[3])]
                    if q[0]<q[2] and q[1]<q[3]:rr.append(q)
        regions[family]=list(map(list,sorted(set(map(tuple,rr)))));areas[family],before[family]=difference_area(regions[family],fixed)
    joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));combined,old=difference_area(joint,fixed);bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);excluded=bc<6 or ic<16 or combined<556778*10**6
    result={'case':case['case'],'omitted_sites':omitted,'family_regions_um':regions,'combined_regions_um':joint,'fixed_inner_obstacles_um':fixed,'family_area_upper_um2':areas,'family_area_before_fixed_subtraction_um2':before,'combined_area_upper_um2':combined,'combined_area_before_fixed_subtraction_um2':old,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'provisional_fixed44_excluded':excluded,'independent_audit_pending':True};write(OUT/(case['case']+'-capacity.json'),result);results.append({'case':case['case'],'omitted_sites':omitted,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'combined_area_upper_mm2':combined/1e6,'provisional_fixed44_excluded':excluded});assert time.perf_counter()-began<36
write(OUT/'capacity-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source44_cases':680,'provisional_fixed44_exclusions':sum(r['provisional_fixed44_excluded'] for r in results),'provisional_remaining_cases':sum(not r['provisional_fixed44_excluded'] for r in results),'largest_combined_area_upper_mm2':max(r['combined_area_upper_mm2'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
