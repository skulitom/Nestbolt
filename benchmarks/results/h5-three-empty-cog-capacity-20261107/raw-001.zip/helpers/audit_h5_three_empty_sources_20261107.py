"""Pairwise source certificate and complete identity replay for every680 subset."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-three-empty-sources-20261107';OUT=BASE/'audit';POOL=ROOT/'output/h5-five-column-cog-pool-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def world(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);assert not t['mirrored'];return np.array(parts[r['part_id']]['geometry'][0]['outer'])@np.array([[c,s],[-s,c]])+t['translation']
def distance(p,q):
    def directed(a,b):
        d=np.roll(b,-1,axis=0)-b;v=a[:,None,:]-b[None,:,:];t=np.clip((v*d[None,:,:]).sum(2)/(d*d).sum(1)[None,:],0,1);v-=t[:,:,None]*d[None,:,:];return float(np.sqrt((v*v).sum(2).min()))
    return min(directed(p,q),directed(q,p))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p,h in load(POOL/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct all35 first-sheet canonical frame/cog polygons (17 anonymous cog sites, not17 placed original copies) and all12 short-sheet original polygons. Direct vertex-to-segment distances and filled intersections certify every661 common same-sheet pair and all188 stock edges. Compare all17 exact source cog poses and every fixed frame with previously audited originals; separately replay the full44 control and the short12 originals. Enumerate all680 empty triples, legal14cog identity assignments, all remaining original identities and original hole counts. Every subset inherits only independently checked pairs from the complete canonical table. This proves680 source44 partials by a shared pairwise certificate; it does not claim680 separate legacy-reader invocations or any full66 validity.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(OLD/'source-recipe.json');data=load(BASE/'canonical-source.json');frames=data['first_frames'];poses=data['first_cog_site_poses'];short=data['short_rows'];assert frames==load(POOL/'omit-00-01-source.json')[:18] and short==load(SHORT/'short12-source.json');assert data['source_stocks']==rec['source_stocks'] and data['required_pair_gap_mm']==rec['required_pair_gap_mm'] and data['stock_guard_mm']==rec['stock_guard_mm'];der=load(OLD/'cog-derivation.json');theta=der['rotation_radians'];c,s=math.cos(theta),math.sin(theta);center=np.array(der['source_center']);matrix=np.array([[c,s],[-s,c]]);sites=load(POOL/'sites.json');assert len(poses)==len(sites)==17
for pose,site in zip(poses,sites):
    assert pose['site']==site['site'] and pose['part_id']=='cog' and pose['transform']['rotation_radians']==theta;expected=(np.array(parts['cog']['geometry'][0]['outer'])-center)@matrix+site['center'];assert np.allclose(world(pose),expected,rtol=0,atol=1e-10)
pairrecords=[];stockrecords=[];required=rec['required_pair_gap_mm'];guard=rec['stock_guard_mm']
for sheet,rows in [('sheet-0',frames+poses),('sheet-1',short)]:
    vv=list(map(world,rows));pp=list(map(Polygon,vv));st=rec['source_stocks'][sheet]
    for i,j in combinations(range(len(rows)),2):
        intersection=pp[i].intersection(pp[j]).area;gap=0. if intersection>0 else distance(vv[i],vv[j]);assert intersection<1e-8 and gap+1e-7>=required;pairrecords.append({'sheet':sheet,'canonical_indices':[i,j],'gap_mm':gap,'passed':True})
    for i,v in enumerate(vv):
        b=[float(v[:,0].min()),float(v[:,1].min()),float(v[:,0].max()),float(v[:,1].max())];assert b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard;stockrecords.append({'sheet':sheet,'canonical_index':i,'bounds':b,'passed':True})
assert len(pairrecords)==661 and len(stockrecords)==47;shortcheck=audit(job,short,rec['source_stocks'],required,guard);assert shortcheck==load(BASE/'short12-checks.json') and shortcheck['valid'];control=load(BASE/'control44-source.json');check=audit(job,control,rec['source_stocks'],required,guard);assert check==load(BASE/'control44-checks.json') and check['valid'];allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};cases=load(BASE/'cases.json');assert [r['omitted_sites'] for r in cases]==list(map(list,combinations(range(17),3)));holecount=0
for case in cases:
    selected=[p for p in poses if p['site'] not in case['omitted_sites']];assert len(selected)==14 and case['first_cog_sites_in_copy_order']==[p['site'] for p in selected];first=[{'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':p['transform']} for i,p in enumerate(selected)];rows=frames+first+short;ids={(r['part_id'],r['copy_index']) for r in rows};assert len(rows)==len(ids)==case['original_part_count']==44 and list(map(list,sorted(allids-ids)))==load(BASE/'remaining-identities.json');assert {r['copy_index'] for r in first}==set(range(14)) and next(r for r in short if r['part_id']=='cog')['copy_index']==14;holecount+=sum(len(parts[r['part_id']]['geometry'][0]['holes']) for r in rows)
    if case==cases[0]:assert rows==control
process=load(ROOT/'output/h5-three-empty-sources-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'pair-certificate.json',pairrecords);write(OUT/'stock-certificate.json',stockrecords);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source44_subsets_certified':680,'common_same_sheet_pairs_verified':661,'stock_edges_verified':188,'canonical_site_poses_verified':17,'subset_identity_assignments_verified':680,'original_holes_across_subsets':holecount,'full_source44_control_valid':True,'source_validity_method':'Complete shared original-polygon pair/stock certificate plus exhaustive per-subset identity/pose mapping.','remaining_brackets_per_case':6,'remaining_inserts_per_case':16,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
