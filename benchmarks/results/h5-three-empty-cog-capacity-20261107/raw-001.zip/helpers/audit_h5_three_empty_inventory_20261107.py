"""Exact whole-part inventory corollaries for the audited 680 fixed cores."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import itertools,json,time
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-three-empty-inventory-20261107'
SOURCE=ROOT/'output/h5-three-empty-sources-20261107'
AREA=ROOT/'output/h5-three-empty-areas-20261107'
PRIOR=ROOT/'output/h5-one-three-inventory-20261107'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [SOURCE/'audit',AREA/'audit',PRIOR/'audit']:
    assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),SOURCE/'canonical-source.json',SOURCE/'cases.json',AREA/'audit/checks.json',AREA/'audit/capacity-results.json',PRIOR/'fixed-short-cog-area.json',PRIOR/'whole-part-splits.json',PRIOR/'audit/checks.json']:
    bindings[p.relative_to(ROOT).as_posix()]=digest(p)
cases=load(SOURCE/'cases.json')
for case in cases:
    p=AREA/(case['case']+'-capacity.json');bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile the complete source-pair certificate, all 2040 audited area bounds and prior rational material/short-stock/short-cog proof. Require exact original cog14 pose equality. Independently enumerate all 286 original bracket/insert splits with integer arithmetic. First keep the short cog fixed and release all companions. Then relax that cog entirely and permit the full short-stock area for companions, which is a necessary but deliberately insufficient condition. Per-case family and joint area comparisons never claim feasibility. Preserve every survivor. No whole allocation or orientation class is excluded.','inherited_numeric_preparation_seconds':load(AREA/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
canonical=load(SOURCE/'canonical-source.json');cog=next(r for r in canonical['short_rows'] if r['part_id']=='cog')
prior=load(PRIOR/'fixed-short-cog-area.json');assert cog==prior['source_row']
assert len(canonical['first_frames'])==18 and len(canonical['first_cog_site_poses'])==17
short=prior['short_usable_area_upper_um2'];available=prior['short_companion_area_upper_um2']
assert available==short-prior['filled_area_lower_mm2']*10**6
unit_b=39999*10**6;unit_i=19799*10**6;whole=12*unit_b+21*unit_i
splits=[{'short_brackets':b,'short_inserts':i,'short_area_lower_um2':b*unit_b+i*unit_i,'first_area_lower_um2':(12-b)*unit_b+(21-i)*unit_i,'fixed_short_cog_area_pass':b*unit_b+i*unit_i<=available,'free_cog_relaxation_area_pass':b*unit_b+i*unit_i<=short} for b in range(13) for i in range(22)]
saved=load(PRIOR/'whole-part-splits.json')
assert {(r['short_brackets'],r['short_inserts']) for r in splits if r['fixed_short_cog_area_pass']}=={(r['short_brackets'],r['short_inserts']) for r in saved if r['short_area_pass']}
required=whole-max(r['short_area_lower_um2'] for r in splits if r['fixed_short_cog_area_pass'])
relaxed_required=whole-max(r['short_area_lower_um2'] for r in splits if r['free_cog_relaxation_area_pass'])
assert required==495777*10**6
write(OUT/'whole-part-splits.json',splits)
assert {tuple(c['omitted_sites']) for c in cases}==set(itertools.combinations(range(17),3)) and len(cases)==680
audited={r['case']:r for r in load(AREA/'audit/capacity-results.json')};results=[];survivors=[]
for case in cases:
    assert case['source_geometry_by_common_pair_certificate'] and len(case['first_cog_sites_in_copy_order'])==14
    data=load(AREA/(case['case']+'-capacity.json'));area=data['combined_area_upper_um2'];assert area/1e6==audited[case['case']]['combined_area_upper_mm2']
    bc=data['family_area_upper_um2']['bracket']//unit_b;ic=data['family_area_upper_um2']['insert']//unit_i
    assert area<required
    counts=Counter();remaining=[]
    for r in splits:
        b,i=r['short_brackets'],r['short_inserts']
        other=[(12-b>bc,'first_bracket_capacity'),(21-i>ic,'first_insert_capacity'),(r['first_area_lower_um2']>area,'first_combined_area')]
        fixed=[name for fail,name in [(not r['fixed_short_cog_area_pass'],'short_area')]+other if fail]
        relaxed=[name for fail,name in [(not r['free_cog_relaxation_area_pass'],'short_area')]+other if fail]
        assert fixed
        counts.update(fixed)
        if not relaxed:remaining.append([b,i])
    result={'case':case['case'],'omitted_sites':case['omitted_sites'],'first_companion_area_upper_mm2':area/1e6,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'fixed_short_cog_required_first_area_mm2':required/1e6,'fixed_short_cog_area_deficit_mm2':(required-area)/1e6,'all286_splits_excluded_with_fixed_short_cog':True,'fixed_short_cog_failure_counts':dict(counts),'relaxed_free_cog_remaining_splits':remaining,'exact_first32_excluded_even_last_cog_free':not remaining,'necessary_conditions_only':True}
    results.append(result)
    if remaining:survivors.append(result)
write(OUT/'capacity-results.json',results);write(OUT/'remaining-first32-cases.json',survivors)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'fixed_first32_plus_short_cog_cases':680,'all_companion_splits_excluded_with_fixed_short_cog':680,'split_checks_per_cog_condition':680*286,'cog_conditions':2,'short_companion_area_upper_mm2':available/1e6,'first_area_required_with_fixed_short_cog_mm2':required/1e6,'minimum_fixed_short_cog_deficit_mm2':min(r['fixed_short_cog_area_deficit_mm2'] for r in results),'first_area_required_ignoring_last_cog_mm2':relaxed_required/1e6,'exact_first32_excluded_even_last_cog_free':680-len(survivors),'exact_first32_unexcluded_last_cog_free':len(survivors),'inherited_preparation_seconds':load(AREA/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'corollary_process_charge_must_be_added':True,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
