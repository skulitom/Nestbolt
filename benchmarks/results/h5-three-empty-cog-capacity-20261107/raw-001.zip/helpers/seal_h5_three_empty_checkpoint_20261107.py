"""Archive the complete three-empty-site evidence and conditional inventory proofs."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-three-empty-cog-capacity-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-three-empty-inventory-20261107';F=BASE;D=ROOT/'output/h5-three-empty-areas-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-five-column-cog-pool-exclusions-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['all_companion_splits_excluded_with_fixed_short_cog']==680 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-three-empty-sources-20261107',ROOT/'output/h5-three-empty-covers-20261107']+[ROOT/'output'/('h5-three-empty-'+n+'-process-20261107') for n in ['sources','sources-audit','covers','covers-audit','areas','areas-audit','inventory']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_three_empty*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_three_empty_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
S=ROOT/'output/h5-three-empty-sources-20261107';C=ROOT/'output/h5-three-empty-covers-20261107'
process=load(ROOT/'output/h5-three-empty-inventory-process-20261107/process.json');assert process['passed'] and process['closed'];total=front['inherited_preparation_seconds']+process['complete_seconds']
copies=[(S/'plan.json','source-plan.json'),(S/'audit/checks.json','source-audit.json'),(S/'audit/pair-certificate.json','source-pair-certificate.json'),(C/'plan.json','cover-plan.json'),(C/'audit/checks.json','cover-audit.json'),(D/'plan.json','area-plan.json'),(D/'audit/checks.json','area-audit.json'),(D/'audit/capacity-results.json','fixed44-capacities.json'),(BASE/'plan.json','inventory-plan.json'),(BASE/'checks.json','inventory-audit.json'),(BASE/'capacity-results.json','fixed32-capacities.json'),(BASE/'remaining-first32-cases.json','remaining-first32-cases.json'),(BASE/'whole-part-splits.json','whole-part-splits.json')]
stages=['sources','sources-audit','covers','covers-audit','areas','areas-audit','inventory']
for n in stages:
    p=ROOT/'output'/('h5-three-empty-'+n+'-process-20261107')/'process.json';r=load(p);assert r['passed'] and r['closed'] and r['job']['active_processes']==0;copies.append((p,n+'-process.json'))
for p,n in copies:shutil.copyfile(p,OUT/n)
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42410023316','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='9eb6698eb3f734439be6c04bca5b5c9927de1edc' and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'complete_preparation_seconds_if_consumed':total,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'failed_preparation_seconds_retained':6.62785069970414})
write(OUT/'next-step.json',{'status':'all680_fixed44_excluded_443_fixed_first32_excluded_237_unresolved','proposal':'Investigate the 237 surviving exact first32 cores, preserving all necessary-only inventory splits. The present short-cog argument binds its exact verified pose. Before extending it to every short-sheet pose, derive an independent rotation/translation-invariant lower bound from the original filled cog outline, including conservative numerical error, and re-enumerate the integer inventories. Do not assume a fixed-pose proof excludes every legal cog angle or position. If all short-sheet poses are then excluded, any completion requires the fifteenth cog on the first sheet outside the already excluded original 17-site patterns. Establish a necessary free-angle cog placement cover from original source inner geometry before considering new models. The current warm numeric lineage exceeds60seconds and may not open an optimizer or reset its timer. Any eventual timed constructor must recompute all numerical input independently from original sources and pass a separate preflight. No closed optimizer/model call may repeat.','remaining_first32_cases':237,'first32_cases_excluded_all_other_originals_free':443,'fixed_short_cog_cases_excluded':680,'arbitrary_short_cog_pose_excluded':False,'complete_model_prepared':False,'optimizer_allowed_from_current_charged_lineage':False,'consumed_preparation_seconds':total,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'optimizer_calls':0,'H5_complete':False})
rows='\n'.join('| '+n+' | '+f"{load(OUT/(n+'-process.json'))['complete_seconds']:.6f}"+' | Pass |' for n in stages)
report=f'''# Three empty cog sites: conditional capacity proofs — 2026-11-07

**All 680 checked fixed 44-part layouts cannot extend to 66 parts.** Releasing
all brackets and inserts still excludes each layout's exact first 32 parts
when the last cog stays at its verified short-sheet pose. A further relaxation
excludes **443 exact first 32-part arrangements even when every remaining part
is free**; **237 remain unresolved**. No whole allocation or orientation class
is excluded. H2/H5 remain open at **60% completed milestone weight**, and the
preserved valid 64-part result remains best.

[The source construction]({NAME}/source-plan.json) selects fourteen of the same
seventeen cog sites around eighteen fixed frames, leaving three empty sites.
Original cog 14 stays on the verified short sheet with six brackets and five
inserts. Each partial has 44 original identities; six brackets and sixteen
inserts remain unplaced.

[Independent source certification]({NAME}/source-audit.json) checks a common
original-polygon certificate with **661 same-sheet pairs and 188 stock edges**,
then every subset's identity/pose assignment. This certifies all 680 partials
and **38,080 original holes**. It is a complete shared certificate, not 680
separate legacy-reader invocations. One complete original 44-part control and
the short-sheet control also pass. [The pair certificate]({NAME}/source-pair-certificate.json)
retains direct vertex-to-segment distances and filled-polygon intersection checks.

[New three-empty-site covers]({NAME}/cover-plan.json) use the previously audited
full masks only after exact equality checks for all eighteen frame poses,
seventeen cog poses, physical domain and original legal modes. The earlier
two-empty retained covers are insufficient and are not reused as complete.

[Independent cover readback]({NAME}/cover-audit.json) verifies **21,026,872
continuous boundary/interval classes**, including **9,936,621 retained classes**
covered exactly once by **4,728 closed boxes**. Cog sites occupy bits 0–16;
mandatory frames occupy distinct bit 17. Producer bit removal and independent
bit-count controls agree, including the three-allowed/four-forbidden boundary.

[Component-area preparation]({NAME}/area-plan.json) sweeps the original two
L components or insert component through each compatible cover, clips to the
outward physical stock, and subtracts mandatory fixed source interiors.
[Independent event-sweep readback]({NAME}/area-audit.json) checks all **2,040
exact union-difference areas**, separately from producer prefix grids.
The largest available companion region is **471,447.388136 mm²**, below
**556,778 mm²** required for six brackets and sixteen inserts. [Every fixed44
completion fails]({NAME}/fixed44-capacities.json).

[The inventory corollary]({NAME}/inventory-plan.json) releases all twelve
brackets and twenty-one inserts between sheets while first retaining the exact
short-sheet cog. Its original filled body leaves at most **415,265.048858 mm²**
for short-sheet companions. [All 286 whole-part inventories]({NAME}/whole-part-splits.json)
force at least **495,777 mm²** onto the first sheet. [Every one of the 680
fixed first32 plus short-cog hypotheses fails]({NAME}/fixed32-capacities.json),
with a minimum deficit of **24,329.611864 mm²**. The argument is explicitly
conditional on the verified short-cog pose.

A second necessary relaxation ignores the last cog entirely and lets companions
use the whole short stock. Integer counts still require at least **435,979 mm²**
of first-sheet companion area. Combining this with family capacities excludes
**443 exact first32 arrangements with all remaining originals free**.
[The 237 unresolved cases and every surviving inventory split]({NAME}/remaining-first32-cases.json)
are preserved; satisfying necessary bounds is not a packing solution.
[Both conditions check 194,480 case/split combinations each]({NAME}/inventory-audit.json).

| Bounded stage | Complete process (s) | Outcome |
|---|---:|---|
{rows}

Every process closes under the unchanged CCD1/thread and 2 GiB Windows Job
controls. Complete consumed preparation is **{total:.6f} s**, including all
inherited work and the earlier failed preparations. It exceeds the 60-second
algorithm budget: these are geometry proofs, not a timed H5 pass. No optimizer
is opened and this lineage may not reset its timer.

[Next]({NAME}/next-step.json), investigate the 237 unresolved cores. A proof
for every legal short-cog pose requires a new original-source, pose-invariant
filled-area bound with numerical error controlled; the current exact-pose
result alone cannot support that claim. Any subsequent first-sheet cog cover
must include all allowed angles. An eventual timed constructor needs genuinely
independent source computation and preflight, without free cached preparation.

Four earlier fixed arrangements and 440 whole-job allocations remain. Full66
source/native/material acceptance, product integration, parity and the H5
matrix remain open. [All six previous main checks pass]({NAME}/main-ci-at-review.json).
This checkpoint and the preceding two await their ordinary fast-forward push.
Product code, README and release state are unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 three-empty cog capacity:** [independent source, cover, area and inventory proofs]({{link}}) certify all 680 fourteen-of17 partials using 661 common source pairs, 188 stock edges and exhaustive identity/pose checks, preserving 38,080 holes. New complete three-empty covers verify 21,026,872 classes, 9,936,621 retained classes and 4,728 boxes after exact source/domain/mode equality checks. All 2,040 area bounds replay independently; every fixed44 completion fails, with at most 471,447.388136 mm² versus 556,778 required. Releasing all brackets and inserts while retaining the exact short-cog pose still excludes all 680, by at least 24,329.611864 mm². A further relaxation frees the last cog and excludes 443 exact first32 arrangements; 237 remain unresolved, with every necessary inventory split preserved. No whole allocation or orientation class is excluded. Consumed preparation totals {total:.6f} s; no optimizer or timed-gate pass is permitted from this exhausted lineage. Next derive a source-based pose-invariant cog area bound before extending the short-cog conclusion to arbitrary legal poses. Four earlier arrangements and 440 allocations remain; valid64 stays best and H2/H5 stay open at 60%. All six previous main checks pass; this and the preceding two checkpoints await the ordinary push. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';content=p.read_text(encoding='utf-8');a=content.index('Latest H5 evidence:');b=content.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [three-empty cog capacity](../benchmarks/results/{NAME}.md).
All 680 fixed44 layouts fail completion after complete source, cover and
2,040 independent area checks. Releasing every bracket and insert still
excludes each exact first32 core with the last cog at its verified short pose.
A further relaxation frees the last cog and excludes 443 first32 arrangements;
237 remain unresolved. No whole allocation or orientation class is excluded.
Consumed preparation is {total:.6f} s, above 60; this lineage may not reset its
timer or open an optimizer. Next establish an original-source pose-invariant
cog area bound before extending the exact short-pose proof.
Four earlier arrangements and 440 allocations remain; valid64 stays best.
H2/H5 remain open at 60%. All six previous main checks pass; this and the
preceding two checkpoints await the ordinary fast-forward push.
Product and release state are unchanged.
'''
p.write_text(content[:a]+intro+content[b:],encoding='utf-8',newline='\n')
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'total_consumed_preparation_seconds':total})
