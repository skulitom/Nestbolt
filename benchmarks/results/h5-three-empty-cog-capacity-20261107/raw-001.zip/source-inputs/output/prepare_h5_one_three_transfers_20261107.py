"""Every one-cog-transfer subset of two unchanged source-derived roof pools."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-one-three-transfers-20261107';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';PRIOR=ROOT/'output/h5-five-six-inventory-bound-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cog(i,site):return {'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':phase,'mirrored':False,'translation':[site['center'][0]-(cx*cs-cy*sn),site['center'][1]-(cx*sn+cy*cs)]}}
def shape(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];return Polygon([(x*c-y*s+tx,x*s+y*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']])
OUT.mkdir();began=time.perf_counter();prior=load(PRIOR/'audit/checks.json');assert prior['passed'] and load(SOURCE/'audit/checks.json')['passed'] and load(SHORT/'audit/checks.json')['passed']
inputs=[Path(__file__),JOB,PRIOR/'audit/checks.json',SOURCE/'audit/checks.json',SOURCE/'source-recipe.json',SOURCE/'cog-derivation.json',SOURCE/'fixed27-source.json',SHORT/'short12-source.json',SHORT/'audit/checks.json',ROOT/'output/h5_legacy64_source_readback.py']
for k in [1,3]:inputs += [SOURCE/f'turned-{k}'/n for n in ['roof-source.json','sites.json','pool-checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use exactly the earlier source-derived one- and three-turned roof and anonymous cog-site geometry, moving cog14 onto the independently verified short6/5/1. Independently rebuild actual original-source pool contacts. Screen every14-of15 and14-of16 subset against every stock/frame/cog conflict, recording all failure witnesses. Reconstruct all44 original parts and replay full pair/stock/hole checks for every screen survivor. Retain all failures; no source phase, pitch, roof or site change after observation. No prior continuous call is resumed.','declared_subset_counts':[15,120],'inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'process_cap_seconds':20,'preparation_internal_cap_seconds':18,'memory_bytes':2**31,'charge_entire_process_if_consumed':True,'optimizer_calls':0,'retry_permitted':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(SOURCE/'source-recipe.json');d=load(SOURCE/'cog-derivation.json');phase=d['rotation_radians'];cs,sn=math.cos(phase),math.sin(phase);cx,cy=d['source_center'];stocks=rec['source_stocks'];required=rec['required_pair_gap_mm'];guard=rec['stock_guard_mm'];base=[r for r in load(SOURCE/'fixed27-source.json') if r['sheet_id']=='sheet-0'];short=load(SHORT/'short12-source.json');assert len(base)==len(short)==12
allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};results=[]
for k in [1,3]:
    folder=OUT/f'turned-{k}';folder.mkdir();roof=load(SOURCE/f'turned-{k}/roof-source.json');sites=load(SOURCE/f'turned-{k}/sites.json');frames=base+roof;polys=[shape(cog(i,s)) for i,s in enumerate(sites)];fp=list(map(shape,frames));pairs=[];contacts=[];stockchecks=[]
    for i,j in combinations(range(len(sites)),2):
        g=polys[i].distance(polys[j]);pairs.append({'sites':[i,j],'gap_mm':g,'intersection_mm2':polys[i].intersection(polys[j]).area,'passed':g+1e-7>=required})
    for i,p in enumerate(polys):
        for j,f in enumerate(fp):
            g=p.distance(f);contacts.append({'site':i,'frame':j,'gap_mm':g,'intersection_mm2':p.intersection(f).area,'passed':g+1e-7>=required})
        b=p.bounds;st=stocks['sheet-0'];stockchecks.append({'site':i,'bounds':list(b),'passed':b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard})
    for n,v in [('roof-source.json',roof),('sites.json',sites),('pool-checks.json',{'pairs':pairs,'frames':contacts,'stock':stockchecks})]:write(folder/n,v)
    cases=[]
    for omitted in combinations(range(len(sites)),len(sites)-14):
        selected=[s for s in sites if s['site'] not in omitted];ids={s['site'] for s in selected};witnesses=[{'kind':'pair','sites':r['sites']} for r in pairs if not r['passed'] and set(r['sites'])<=ids]+[{'kind':'frame','site':r['site'],'frame':r['frame']} for r in contacts if not r['passed'] and r['site'] in ids]+[{'kind':'stock','site':r['site']} for r in stockchecks if not r['passed'] and r['site'] in ids]
        case='omit-'+'-'.join(f'{i:02d}' for i in omitted);record={'case':case,'omitted_sites':list(omitted),'screen_passed':not witnesses,'witnesses':witnesses,'source_checked':False,'source_valid44':None}
        if not witnesses:
            rows=frames+[cog(i,s) for i,s in enumerate(selected)]+short;used={(r['part_id'],r['copy_index']) for r in rows};remaining=sorted(allids-used);assert len(rows)==len(used)==44 and len(remaining)==22 and sum(f=='bracket' for f,i in remaining)==6 and sum(f=='insert' for f,i in remaining)==16
            check=audit(job,rows,stocks,required,guard);write(folder/(case+'-source.json'),rows);write(folder/(case+'-checks.json'),check);record.update(source_checked=True,source_valid44=check['valid'],pair_failures=check['pair_failures'],stock_failures=check['stock_failures'])
        cases.append(record);assert time.perf_counter()-began<18
    write(folder/'cases.json',cases);results.append({'turned_frames':k,'anonymous_sites':len(sites),'subset_choices':len(cases),'screen_failures':sum(not r['screen_passed'] for r in cases),'source44_checked':sum(r['source_checked'] for r in cases),'source44_valid':sum(r['source_valid44'] is True for r in cases),'failed_pool_pairs':[r['sites'] for r in pairs if not r['passed']]})
write(OUT/'remaining-identities.json',remaining);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'patterns':results,'subset_choices':135,'independent_audit_pending':True,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
