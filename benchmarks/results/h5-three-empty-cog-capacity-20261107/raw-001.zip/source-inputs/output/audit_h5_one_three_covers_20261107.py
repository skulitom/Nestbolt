"""Fresh rational containment, count-event masks and sweep-area readback."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from collections import defaultdict
from bisect import bisect_left,bisect_right
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-one-three-covers-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-one-three-transfers-20261107';ORIGINAL=ROOT/'output/h5-orientation-roofs-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PAD=Q(1,10**6)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def det(a,b):return a[0]*b[1]-a[1]*b[0]
def area(p):return sum(det(a,b) for a,b in zip(p,p[1:]+p[:1]))/2
def posed(p,t):
    c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;matrix=((m*c,-s),(m*s,c));translation=list(map(Q,t['translation']));q=[tuple(sum(matrix[k][j]*Q(v[j]) for j in range(2))+translation[k] for k in range(2)) for v in p];return q if area(q)>0 else q[::-1]
def contains(p,r):
    corners=[(Q(x,1000)+sx*PAD,Q(y,1000)+sy*PAD) for x,sx in [(r[0],-1),(r[2],1)] for y,sy in [(r[1],-1),(r[3],1)]]
    return all(det((b[0]-a[0],b[1]-a[1]),(v[0]-a[0],v[1]-a[1]))>0 for a,b in zip(p,p[1:]+p[:1]) for v in corners)
def axis(cuts):return [v for i,x in enumerate(cuts) for v in ([2*x,x+cuts[i+1]] if i+1<len(cuts) else [2*x])]
def counts(xx,yy,rects):
    d=np.zeros((len(yy)+1,len(xx)+1),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_right(xx,2*a),bisect_left(xx,2*c);k,l=bisect_right(yy,2*b),bisect_left(yy,2*e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]
def sweep(region,obstacles):
    if not region:return 0,0
    rects=region+obstacles;ys=sorted({r[k] for r in rects for k in [1,3]});events=defaultdict(list)
    for kind,rows in enumerate([region,obstacles]):
        for a,b,c,e in rows:events[a].append((kind,b,e,1));events[c].append((kind,b,e,-1))
    live=np.zeros((2,len(ys)-1),dtype=np.int32);height=np.diff(ys);xs=sorted(events);total=0;before=0
    for i,x in enumerate(xs):
        for kind,a,b,change in events[x]:live[kind,bisect_left(ys,a):bisect_left(ys,b)]+=change
        assert live.min()>=0
        if i+1<len(xs):
            w=xs[i+1]-x;covered=live[0]>0;available=covered&(live[1]==0);total+=w*int(height[available].sum());before+=w*int(height[covered].sum())
    assert not np.any(live);return total,before
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p,h in load(SOURCE/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),JOB]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently transform every new original frame and cog convex piece with exact rational float values; certify all source-contained obstacle rectangles. Verify each original bracket/insert mode, its inner/outer component bounds, full physical stock domain and filled-area lower bound. Reconstruct all forbidden rectangles and continuous axes; independently count signed rectangle corners per bit and compare every new full mask. Prove exact once-only coverage of retained classes. Reconstruct component-swept stock-clipped regions for all19 valid44 cases and recompute all57 union-minus-fixed areas with independent1Dinterval events. Changed frame obstacles are fully replayed, never assumed equal to older maps.','process_cap_seconds':60,'optimizer_calls':0,'retry_permitted':False})
assert load(SOURCE/'audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};deriv=load(ORIGINAL/'cog-derivation.json');recipe=load(ORIGINAL/'source-recipe.json');stock=list(map(Q,recipe['source_stocks']['sheet-0']));base=[r for r in load(ORIGINAL/'fixed27-source.json') if r['sheet_id']=='sheet-0'];geometries=load(BASE/'geometries.json');assert len(geometries)==12;component_source={'bracket':[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]],'insert':[parts['insert']['geometry'][0]['outer']]};assert parts['bracket']['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]];assert sum(area(p) for p in component_source['bracket'])==40000;assert area(component_source['insert'][0])==19800
seen={'bracket':set(),'insert':set()};bounds_verified=0;maxdet=Q(0)
for g in geometries:
    family=g['family'];t=g['source_pose'];seen[family].add((t['rotation_radians'],t['mirrored']));assert g['source_components']==component_source[family];outer=posed(parts[family]['geometry'][0]['outer'],t);assert str(area(outer))==g['source_area_mm2'];lo=[min(v[k] for v in outer) for k in range(2)];hi=[max(v[k] for v in outer) for k in range(2)];root=[stock[0]-lo[0]-PAD,stock[1]-lo[1]-PAD,stock[2]-hi[0]+PAD,stock[3]-hi[1]+PAD];assert g['stock_center_domain_um']==[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(root)]
    for p0,inside,outside in zip(component_source[family],g['inner_components_um'],g['outer_component_bounds_um']):
        p=posed(p0,t);assert contains(p,inside);bb=[min(v[0] for v in p),min(v[1] for v in p),max(v[0] for v in p),max(v[1] for v in p)];assert outside==[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(bb)];bounds_verified+=1
    c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));maxdet=max(maxdet,abs(c*c+s*s-1))
assert seen['bracket']==set(product([0,math.pi/2,math.pi,3*math.pi/2],[False,True])) and seen['insert']==set(product([0,math.pi/2,math.pi,3*math.pi/2],[False]));error=6*(2*4096*PAD+PAD*PAD)+40000*maxdet;assert error<1 and Q(64*8192,2**53-64)<PAD
savedstock=load(BASE/'stock-cover.json');sb=savedstock['outward_stock_rectangle_um'];assert list(map(Q,savedstock['physical_stock_mm']))==stock and sb==[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(stock)]
fixture=counts([0,1,2,3,4],[0,1,2,3,4],[(0,0,2,2)]);assert fixture.tolist()==[[0,0,0,0,0],[0,1,1,1,0],[0,1,1,1,0],[0,1,1,1,0],[0,0,0,0,0]];assert sweep([[0,0,3,3]],[[1,1,2,2],[1,1,2,2]])==(8,9)
records=[];results=[];rectcount=0;theta=deriv['rotation_radians'];c,s=math.cos(theta),math.sin(theta);cx,cy=deriv['source_center'];lookup={k:np.array([not(n&65536) and n.bit_count()<=(1 if k==1 else 2) for n in range(131072)],dtype=np.bool_) for k in [1,3]}
for turned in [1,3]:
    folder=BASE/f'turned-{turned}';roof=load(SOURCE/f'turned-{turned}/roof-source.json');sites=load(SOURCE/f'turned-{turned}/sites.json');frames={(r['part_id'],r['copy_index']):r for r in base+roof};assert len(frames)==18;shapes={('frame',i):[posed(parts['frame']['geometry'][0]['outer'],r['transform'])] for i,r in frames.items()}
    for site in sites:
        t={'rotation_radians':theta,'mirrored':False,'translation':[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)]};shapes[('cog',site['site'])]=[posed(p,t) for p in deriv['convex_pieces']]
    sources=load(folder/'source-inner-rectangles.json')
    for r in sources:
        key=('frame',tuple(r['identity'])) if r['kind']=='frame' else ('cog',r['site_bit']);assert r['site_bit']==16 if r['kind']=='frame' else 0<=r['site_bit']<len(sites);p=shapes[key][r['piece']];assert all(abs(v)<4096 for point in p for v in point) and contains(p,r['bounds_um']);rectcount+=1
    assert len({tuple(r['identity']) for r in sources if r['kind']=='frame'})==18 and {r['site_bit'] for r in sources if r['kind']=='cog'}==set(range(len(sites)));covers={}
    for g in geometries:
        gi=g['geometry'];d=g['stock_center_domain_um'];data=load(folder/f'geometry-{gi:02d}.json');expected=[]
        for si,r in enumerate(sources):
            u,v,w,z=r['bounds_um']
            for ci,(a,b,c0,e) in enumerate(g['inner_components_um']):
                q=[u-c0,v-e,w-a,z-b]
                if q[0]<d[2] and q[2]>d[0] and q[1]<d[3] and q[3]>d[1]:expected.append({'source':si,'component':ci,'bit':r['site_bit'],'bounds_um':q})
        assert expected==data['obstacles'];xs=sorted({d[0],d[2]}|{o['bounds_um'][j] for o in expected for j in [0,2] if d[0]<=o['bounds_um'][j]<=d[2]});ys=sorted({d[1],d[3]}|{o['bounds_um'][j] for o in expected for j in [1,3] if d[1]<=o['bounds_um'][j]<=d[3]});xx,yy=axis(xs),axis(ys);mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
        for bit in list(range(len(sites)))+[16]:
            values=counts(xx,yy,[o['bounds_um'] for o in expected if o['bit']==bit]);assert values.min()>=0;mask|=(values>0).astype(np.uint32)<<bit
        with np.load(folder/f'geometry-{gi:02d}-classes.npz',allow_pickle=False) as saved:assert saved['xcuts_um'].tolist()==xs and saved['ycuts_um'].tolist()==ys and np.array_equal(saved['mask'],mask)
        legal=lookup[turned][mask];covered=np.zeros(mask.shape,dtype=np.bool_)
        for label,a,b,c0,e,xa,ya,xb,yb in data['cover']:
            assert [a,b,c0,e]==[xs[xa//2],ys[ya//2],xs[(xb+1)//2],ys[(yb+1)//2]];assert np.all(mask[ya:yb+1,xa:xb+1]==label) and np.all(legal[ya:yb+1,xa:xb+1]) and not np.any(covered[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
        assert np.array_equal(covered,legal);covers[gi]=data['cover'];records.append({'turned_frames':turned,'geometry':gi,'continuous_classes':int(mask.size),'retained_classes':int(legal.sum()),'cover_boxes':len(data['cover']),'fresh_masks_and_complete_cover_verified':True})
    for case in load(SOURCE/f'turned-{turned}/cases.json'):
        
        if not case['source_valid44']:continue
        saved=load(folder/(case['case']+'-capacity.json'));omitted=case['omitted_sites'];allowed=sum(1<<i for i in omitted);fixed=[r['bounds_um'] for r in sources if r['site_bit']==16 or not(allowed&(1<<r['site_bit']))];assert fixed==saved['fixed_inner_obstacles_um'];regions={};areas={}
        for family in ['bracket','insert']:
            rr=[]
            for g in geometries:
                if g['family']!=family:continue
                for label,l,b,r,t,*_ in covers[g['geometry']]:
                    if label&~allowed:continue
                    for a,c0,d0,e in g['outer_component_bounds_um']:
                        q=[max(l+a,sb[0]),max(b+c0,sb[1]),min(r+d0,sb[2]),min(t+e,sb[3])]
                        if q[0]<q[2] and q[1]<q[3]:rr.append(q)
            rr=list(map(list,sorted(set(map(tuple,rr)))));assert rr==saved['occupied_component_regions_um'][family];regions[family]=rr;actual,before=sweep(rr,fixed);assert actual==saved['family_occupied_area_upper_um2'][family] and before==saved['family_area_before_fixed_subtraction_um2'][family];areas[family]=actual
        joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));assert joint==saved['combined_regions_um'];combined,before=sweep(joint,fixed);assert combined==saved['combined_area_upper_um2'] and before==saved['combined_area_before_fixed_subtraction_um2'];bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);excluded=bc<6 or ic<16 or combined<556778*10**6;assert bc==saved['provisional_bracket_capacity'] and ic==saved['provisional_insert_capacity'] and excluded==saved['provisional_excluded'];results.append({'turned_frames':turned,'case':case['case'],'omitted_sites':omitted,'bracket_capacity_upper':bc,'insert_capacity_upper':ic,'combined_area_upper_mm2':combined/1e6,'required_area_lower_mm2':556778,'exact_fixed44_excluded':excluded,'whole_orientation_class_excluded':False,'whole_allocation_excluded':False})
total=sum(r['continuous_classes'] for r in records);assert total==prepared['continuous_classes'];assert len(results)==19;process=load(ROOT/'output/h5-one-three-covers-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'class-controls.json',records);write(OUT/'capacity-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_inner_rectangles_verified':rectcount,'source_component_bounds_verified':bounds_verified,'continuous_classes_verified':total,'fresh_mode_masks_verified':len(records),'exact_union_difference_areas_verified':57,'source44_cases':19,'fixed44_cases_excluded':sum(r['exact_fixed44_excluded'] for r in results),'fixed44_cases_remaining':sum(not r['exact_fixed44_excluded'] for r in results),'complete_preparation_seconds_if_consumed':charge,'conservative_body_area_error_bound_mm2':float(error),'whole_orientation_classes_excluded':0,'whole_allocations_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
