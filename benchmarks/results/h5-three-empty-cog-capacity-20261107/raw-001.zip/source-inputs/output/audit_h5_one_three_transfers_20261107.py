"""Independent source recipes, contact witnesses, subset census and full44 replay."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-one-three-transfers-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def world(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);assert not t['mirrored'];return np.array(parts[r['part_id']]['geometry'][0]['outer'])@np.array([[c,s],[-s,c]])+t['translation']
def distance(p,q):
    def directed(a,b):
        d=np.roll(b,-1,axis=0)-b;v=a[:,None,:]-b[None,:,:];t=np.clip((v*d[None,:,:]).sum(2)/(d*d).sum(1)[None,:],0,1);v-=t[:,:,None]*d[None,:,:];return float(np.sqrt((v*v).sum(2).min()))
    return min(directed(p,q),directed(q,p))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Derive original one-/three-turned frame and cog-pool coordinates independently from source dimensions and the audited analytic phase/pitch. Reconstruct actual source polygons by matrix transforms. Verify every original pool contact by vertex-to-segment distances and filled intersections. Enumerate all135 omission sets and reconcile every screen witness; separately verify four three-turned survivors by the two-edge vertex-cover property. Full original-source audit, exact identity census and original-hole replay for all19 remaining44part cases. No source failure is erased and no necessary bound is treated as feasibility.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(SOURCE/'source-recipe.json');d=load(SOURCE/'cog-derivation.json');origin=rec['origin'];gap=rec['gap_mm'];stocks=rec['source_stocks'];required=rec['required_pair_gap_mm'];guard=rec['stock_guard_mm'];v=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in v)-min(p[0] for p in v);fh=max(p[1] for p in v)-min(p[1] for p in v);bottom=origin[1]+3*fw+3*gap;row2=bottom+fh+gap;low=row2+fh;high=row2+fw;radius=d['radius_upper_mm'];pitch=d['axis_pitch_mm'];theta=d['rotation_radians'];c,s=math.cos(theta),math.sin(theta);rot=np.array([[c,s],[-s,c]]);center=np.array(d['source_center']);base=[r for r in load(SOURCE/'fixed27-source.json') if r['sheet_id']=='sheet-0'];short=load(SHORT/'short12-source.json');allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};patterns=[];contacts=0;holes=0;fullpairs=0
for k in [1,3]:
    folder=BASE/f'turned-{k}';roof=load(folder/'roof-source.json');sites=load(folder/'sites.json');checks=load(folder/'pool-checks.json');assert roof==load(SOURCE/f'turned-{k}/roof-source.json') and sites==load(SOURCE/f'turned-{k}/sites.json');assert [r['copy_index'] for r in roof]==list(range(12,18));x=origin[0]
    for i,r in enumerate(roof):
        turned=i>=6-k;angle=math.pi/2 if turned else 0.;xy=[origin[0]+i*(fw+gap),bottom] if i<3 else [x,row2]
        if i>=3:x+=(fh if turned else fw)+gap
        assert r['part_id']=='frame' and r['sheet_id']=='sheet-0' and r['transform']['rotation_radians']==angle;assert np.allclose(world(r).min(0),xy,rtol=0,atol=1e-10)
    right=x-gap;blocks=[(3,3,origin[0]+radius,low+gap+radius),(2,3,origin[0]+2*(fw+gap)+radius,high+gap+radius)] if k==1 else [(4,3,origin[0]+radius,high+gap+radius),(1,4,right+gap+radius,bottom+fh+gap+radius)]
    expected=[(block,[xx,yy],[x0+xx*pitch,y0+yy*pitch]) for block,(nx,ny,x0,y0) in enumerate(blocks) for yy in range(ny) for xx in range(nx)];assert len(expected)==len(sites)
    for i,(site,(block,grid,xy)) in enumerate(zip(sites,expected)):assert site['site']==i and site['block']==block and site['grid']==grid and site['center']==xy
    pv=[(np.array(parts['cog']['geometry'][0]['outer'])-center)@rot+site['center'] for site in sites];pp=list(map(Polygon,pv));frames=base+roof;fv=list(map(world,frames));fp=list(map(Polygon,fv));badpairs=[];badframes=[];badstock=[]
    assert [r['sites'] for r in checks['pairs']]==list(map(list,combinations(range(len(sites)),2))) and [(r['site'],r['frame']) for r in checks['frames']]==[(i,j) for i in range(len(sites)) for j in range(18)]
    for r in checks['pairs']:
        i,j=r['sites'];a=pp[i].intersection(pp[j]).area;g=0. if a>0 else distance(pv[i],pv[j]);assert abs(a-r['intersection_mm2'])<1e-7 and abs(g-r['gap_mm'])<1e-8 and r['passed']==(g+1e-7>=required);contacts+=1
        if not r['passed']:badpairs.append((i,j))
    for r in checks['frames']:
        i,j=r['site'],r['frame'];a=pp[i].intersection(fp[j]).area;g=0. if a>0 else distance(pv[i],fv[j]);assert abs(a-r['intersection_mm2'])<1e-7 and abs(g-r['gap_mm'])<1e-8 and r['passed']==(g+1e-7>=required);contacts+=1
        if not r['passed']:badframes.append((i,j))
    assert [r['site'] for r in checks['stock']]==list(range(len(sites)))
    for r in checks['stock']:
        b=pp[r['site']].bounds;st=stocks['sheet-0'];assert np.allclose(b,r['bounds'],rtol=0,atol=1e-10);assert r['passed']==(b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard)
        if not r['passed']:badstock.append(r['site'])
    assert not badframes and not badstock and badpairs==([] if k==1 else [(3,14),(7,15)])
    cases=load(folder/'cases.json');assert [r['omitted_sites'] for r in cases]==list(map(list,combinations(range(len(sites)),len(sites)-14)));good=[];valid=0
    for r in cases:
        missing=set(r['omitted_sites']);witness=[{'kind':'pair','sites':list(pair)} for pair in badpairs if not missing.intersection(pair)];assert r['witnesses']==witness and r['screen_passed']==(not witness) and r['source_checked']==(not witness)
        if witness:
            assert r['source_valid44'] is None and not (folder/(r['case']+'-source.json')).exists();continue
        good.append(r['omitted_sites']);rows=load(folder/(r['case']+'-source.json'));assert rows[:18]==frames and rows[-12:]==short;chosen=[site for site in sites if site['site'] not in missing]
        for i,(row,site) in enumerate(zip(rows[18:32],chosen)):
            assert row['part_id']=='cog' and row['copy_index']==i and row['sheet_id']=='sheet-0' and row['transform']['rotation_radians']==theta;assert np.allclose(world(row),pv[site['site']],rtol=0,atol=1e-10)
        ids={(row['part_id'],row['copy_index']) for row in rows};assert len(rows)==len(ids)==44 and list(map(list,sorted(allids-ids)))==load(BASE/'remaining-identities.json');fresh=audit(job,rows,stocks,required,guard);assert fresh==load(folder/(r['case']+'-checks.json')) and fresh['valid']==r['source_valid44'];valid+=fresh['valid'];holes+=sum(len(parts[row['part_id']]['geometry'][0]['holes']) for row in rows);fullpairs+=fresh['same_sheet_pairs']
    assert good==([[i] for i in range(15)] if k==1 else [[3,7],[3,15],[7,14],[14,15]]) and valid==len(good)
    patterns.append({'turned_frames':k,'subset_choices':len(cases),'witnessed_screen_failures':len(cases)-len(good),'valid_source44_cases':valid,'surviving_omissions':good})
process=load(ROOT/'output/h5-one-three-transfers-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'patterns':patterns,'subset_choices_verified':135,'witnessed_screen_failures':116,'source44_cases_verified':19,'valid_source44_cases':19,'pool_contacts_verified':contacts,'same_sheet_pairs_across_valid_cases':fullpairs,'original_holes_across_valid_cases':holes,'remaining_brackets_per_case':6,'remaining_inserts_per_case':16,'complete_preparation_seconds_if_consumed':charge,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
