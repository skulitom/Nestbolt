"""Fresh obstacle maps and exact necessary occupied areas for changed frames."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from bisect import bisect_left
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-one-three-covers-20261107';SOURCE=ROOT/'output/h5-one-three-transfers-20261107';ORIGINAL=ROOT/'output/h5-orientation-roofs-20261107';OLD=ROOT/'output/h5-orientation-roof-covers-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PAD=F(1,10**6)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def posed(p,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation']);q=[(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in p];return q if area(q)>0 else q[::-1]
def bounds(p):return [min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)]
def inward(r):return [math.ceil((v+2*PAD)*1000) if k<2 else math.floor((v-2*PAD)*1000) for k,v in enumerate(r)]
def outward(r):return [math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(r)]
def contains(p,r):return all(cross(a,b,v)>0 for a,b in zip(p,p[1:]+p[:1]) for v in product([F(r[0],1000)-PAD,F(r[2],1000)+PAD],[F(r[1],1000)-PAD,F(r[3],1000)+PAD]))
def inner(p):
    r=inward(bounds(p));assert contains(p,r);return r
def axis(cuts):
    r=np.empty(2*len(cuts)-1,dtype=np.int64);r[::2]=2*cuts;r[1::2]=cuts[:-1]+cuts[1:];return r
def clip(r):
    q=[max(r[0],stockbox[0]),max(r[1],stockbox[1]),min(r[2],stockbox[2]),min(r[3],stockbox[3])];return q if q[0]<q[2] and q[1]<q[3] else None
def difference_area(region,obstacles):
    rects=region+obstacles;xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});assert len(xs)*len(ys)<40000000
    def grid(rows):
        d=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for a,b,c,e in rows:
            i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
        return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]>0
    covered=grid(region);blocked=grid(obstacles);weight=np.diff(ys)[:,None]*np.diff(xs)[None,:];return int(np.sum(weight*(covered&~blocked),dtype=np.int64)),int(np.sum(weight*covered,dtype=np.int64))
def deadline():assert time.perf_counter()-began<18,'Preparation cap reached; no exclusion certified.'
OUT.mkdir();began=time.perf_counter();prior=load(SOURCE/'audit/checks.json');assert prior['passed'] and prior['valid_source44_cases']==19 and load(OLD/'audit/checks.json')['passed']
inputs=[Path(__file__),JOB,SOURCE/'audit/checks.json',ORIGINAL/'source-recipe.json',ORIGINAL/'cog-derivation.json',ORIGINAL/'fixed27-source.json',OLD/'local-cog-rectangles.json',OLD/'audit/checks.json']+[SOURCE/f'turned-{k}'/n for k in [1,3] for n in ['roof-source.json','sites.json','cases.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Rebuild all world obstacle rectangles and all12 mode masks for each earlier one-/three-turned source pool with the newly source-valid one-cog transfers. Reuse only audited local cog inner rectangles and analytic source parameters; no old full masks or truncated covers are read, including for the unchanged one-turned geometry. Every boundary point/open interval in the full physical stock domain is classified. Retain no-frame-conflict labels with at most one empty cog bit for count1 or two for count3; select only each independently verified source44 subset. Sweep original L components and inserts over necessary center boxes, clip to outward stock, subtract mandatory source-inner obstacles, and compute all57 exact integer family/combined area bounds. Independent source containment, mask counts, cover completeness and interval-area audit required before any exclusions','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'preparation_internal_cap_seconds':18,'memory_bytes':2**31,'maximum_classes_per_mode':40000000,'required_brackets':6,'required_inserts':16,'combined_area_lower_mm2':556778,'optimizer_calls':0,'retry_permitted':False,'old_world_masks_reused':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};recipe=load(ORIGINAL/'source-recipe.json');deriv=load(ORIGINAL/'cog-derivation.json');base=[r for r in load(ORIGINAL/'fixed27-source.json') if r['sheet_id']=='sheet-0'];stock=list(map(F,recipe['source_stocks']['sheet-0']));stockbox=outward(stock);theta=deriv['rotation_radians'];c,s=math.cos(theta),math.sin(theta);cx,cy=deriv['source_center'];localrects=load(OLD/'local-cog-rectangles.json');pieces=deriv['convex_pieces'];components={'bracket':[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]],'insert':[parts['insert']['geometry'][0]['outer']]};assert parts['bracket']['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]];geometries=[]
for family in ['bracket','insert']:
    original=parts[family]['geometry'][0]['outer'];center=[(min(v[k] for v in original)+max(v[k] for v in original))/2 for k in range(2)];assert parts[family]['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]};assert parts[family]['allow_mirror']==(family=='bracket')
    for mirror,deg in product([False,True] if family=='bracket' else [False],[0,90,180,270]):
        angle=math.radians(deg);cs,sn=math.cos(angle),math.sin(angle);sign=-1 if mirror else 1;px,py=center;t={'rotation_radians':angle,'mirrored':mirror,'translation':[-(sign*px*cs-py*sn),-(sign*px*sn+py*cs)]};outer=posed(original,t);bb=bounds(outer);root=[stock[0]-bb[0]-PAD,stock[1]-bb[1]-PAD,stock[2]-bb[2]+PAD,stock[3]-bb[3]+PAD];root=[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(root)];pp=[posed(p,t) for p in components[family]];geometries.append({'geometry':len(geometries),'family':family,'source_pose':t,'source_components':components[family],'inner_components_um':[inner(p) for p in pp],'outer_component_bounds_um':[outward(bounds(p)) for p in pp],'stock_center_domain_um':root,'source_area_mm2':str(area(outer))})
write(OUT/'geometries.json',geometries);write(OUT/'stock-cover.json',{'outward_stock_rectangle_um':stockbox,'physical_stock_mm':recipe['source_stocks']['sheet-0']});summary=[]
for turned in [1,3]:
    folder=OUT/f'turned-{turned}';folder.mkdir();roof=load(SOURCE/f'turned-{turned}/roof-source.json');sites=load(SOURCE/f'turned-{turned}/sites.json');sources=[]
    for row in base+roof:sources.append({'kind':'frame','identity':[row['part_id'],row['copy_index']],'site_bit':16,'piece':0,'bounds_um':inner(posed(parts['frame']['geometry'][0]['outer'],row['transform']))})
    for site in sites:
        shift=[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)];pose={'rotation_radians':theta,'mirrored':False,'translation':shift};pp=[posed(p,pose) for p in pieces]
        for r in localrects:
            q=inward([F(v,1000)+F(shift[k%2]) for k,v in enumerate(r['bounds_um'])]);assert contains(pp[r['piece']],q);sources.append({'kind':'cog','site_bit':site['site'],'piece':r['piece'],'bounds_um':q})
    write(folder/'source-inner-rectangles.json',sources);covers={};mode_records=[];deadline()
    for g in geometries:
        gi=g['geometry'];d=g['stock_center_domain_um'];obstacles=[]
        for si,r in enumerate(sources):
            u,v,w,z=r['bounds_um']
            for ci,(a,b,c0,e) in enumerate(g['inner_components_um']):
                q=[u-c0,v-e,w-a,z-b]
                if q[0]<d[2] and q[2]>d[0] and q[1]<d[3] and q[3]>d[1]:obstacles.append({'source':si,'component':ci,'bit':r['site_bit'],'bounds_um':q})
        xs=np.array(sorted({d[0],d[2]}|{o['bounds_um'][i] for o in obstacles for i in [0,2] if d[0]<=o['bounds_um'][i]<=d[2]}),dtype=np.int64);ys=np.array(sorted({d[1],d[3]}|{o['bounds_um'][i] for o in obstacles for i in [1,3] if d[1]<=o['bounds_um'][i]<=d[3]}),dtype=np.int64);xx,yy=axis(xs),axis(ys);assert len(xx)*len(yy)<=40000000;mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
        for o in obstacles:
            a,b,c0,e=o['bounds_um'];xa=int(np.searchsorted(xx,2*a,side='right'));xb=int(np.searchsorted(xx,2*c0,side='left'));ya=int(np.searchsorted(yy,2*b,side='right'));yb=int(np.searchsorted(yy,2*e,side='left'));mask[ya:yb,xa:xb]|=np.uint32(1<<o['bit'])
        np.savez_compressed(folder/f'geometry-{gi:02d}-classes.npz',xcuts_um=xs,ycuts_um=ys,mask=mask);boxes=[];active={}
        def close(key,span):
            label,xa,xb=key;ya,yb=span;boxes.append([label,int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
        for yi,row in enumerate(mask):
            reduced=row&(row-1);legal=((row&65536)==0)&((reduced==0) if turned==1 else ((reduced&(reduced-1))==0));labels=np.where(legal,row,np.uint32(131071));starts=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1];ends=np.r_[starts[1:]-1,len(labels)-1];current={}
            for xa,xb in zip(starts.tolist(),ends.tolist()):
                label=int(labels[xa])
                if label==131071:continue
                key=(label,xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
            for key,span in active.items():
                if key not in current:close(key,span)
            active=current
        for key,span in active.items():close(key,span)
        boxes.sort();covers[gi]=boxes;write(folder/f'geometry-{gi:02d}.json',{'geometry':gi,'obstacles':obstacles,'cover':boxes});mode_records.append({'geometry':gi,'classes':int(mask.size),'retained_classes':sum((r[7]-r[5]+1)*(r[8]-r[6]+1) for r in boxes),'cover_boxes':len(boxes)});deadline()
    cases=[]
    for sourcecase in load(SOURCE/f'turned-{turned}/cases.json'):
        
        if not sourcecase['source_valid44']:continue
        omitted=sourcecase['omitted_sites'];allowed=sum(1<<i for i in omitted);fixed=[r['bounds_um'] for r in sources if r['site_bit']==16 or not(allowed&(1<<r['site_bit']))];regions={};areas={};before={}
        for family in ['bracket','insert']:
            rects=[]
            for g in geometries:
                if g['family']!=family:continue
                for label,l,b,r,t,*_ in covers[g['geometry']]:
                    if label&~allowed:continue
                    for a,c0,d0,e in g['outer_component_bounds_um']:
                        q=clip([l+a,b+c0,r+d0,t+e])
                        if q:rects.append(q)
            regions[family]=list(map(list,sorted(set(map(tuple,rects)))));areas[family],before[family]=difference_area(regions[family],fixed)
        joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));combined,oldarea=difference_area(joint,fixed);bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);excluded=bc<6 or ic<16 or combined<556778*10**6
        result={'case':sourcecase['case'],'omitted_sites':omitted,'occupied_component_regions_um':regions,'combined_regions_um':joint,'fixed_inner_obstacles_um':fixed,'family_occupied_area_upper_um2':areas,'family_area_before_fixed_subtraction_um2':before,'combined_area_upper_um2':combined,'combined_area_before_fixed_subtraction_um2':oldarea,'combined_area_upper_mm2':combined/1e6,'provisional_bracket_capacity':bc,'provisional_insert_capacity':ic,'required_combined_area_lower_mm2':556778,'provisional_excluded':excluded,'independent_audit_pending':True,'fixed_case_excluded':False};write(folder/(sourcecase['case']+'-capacity.json'),result);cases.append({k:v for k,v in result.items() if not('regions' in k or 'obstacles' in k)});deadline()
    write(folder/'mode-summary.json',mode_records);write(folder/'case-summary.json',cases);summary.append({'turned_roof_frames':turned,'source_rectangles':len(sources),'continuous_classes':sum(r['classes'] for r in mode_records),'cover_boxes':sum(r['cover_boxes'] for r in mode_records),'cases':len(cases),'provisional_exclusions':sum(r['provisional_excluded'] for r in cases),'largest_combined_area_upper_mm2':max(r['combined_area_upper_mm2'] for r in cases)})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'patterns':summary,'continuous_classes':sum(r['continuous_classes'] for r in summary),'source44_cases':19,'provisional_exclusions':sum(r['provisional_exclusions'] for r in summary),'independent_audit_pending':True,'whole_allocations_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
