"""Observe a fixed-work gap fixture without altering decisions or work charges."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-gap-trace-20261018';out.mkdir(exist_ok=False)
old=root/'output/h5-larger-return-test-review-v2-20261018/broader';work=out/'workspace';shutil.copytree(old,work)
changes=[];patch=[]
rel='crates/core/src/sheets/vstrip.rs';p=work/rel;original=p.read_text(encoding='utf-8');text=original
def snapshot(stage):
    return '''                        {
                            let mut observed_sheets = frozen.to_vec();
                            observed_sheets.extend(strip.split(&sep.layout, shape.sheets)?);
                            let observed_layout = self.model.to_layout(&observed_sheets);
                            eprintln!("GAP_STAGE {}", serde_json::json!({"stage":"'''+stage+'''","clock":self.clock.now(),"layout":observed_layout,"stats":&self.stats,"shape_sheets":shape.sheets,"shape_last":shape.last}));
                        }
'''
insertions=[]
for needle,stage in [
    ('                        let exchanged = if self.allow_exchange {','before_exchange'),
    ('                        let gaps = std::env::var_os("NESTBOLT_NO_FILL").is_none();','after_exchange'),
    ('                        if exchanged > 0\n                            || gap_moves > 0','after_fill')]:
    assert text.count(needle)==1
    insert=snapshot(stage);text=text.replace(needle,insert+needle);insertions.append(insert)
for insert in insertions:assert text.count(insert)==1
reversed_text=text
for insert in insertions:reversed_text=reversed_text.replace(insert,'')
assert reversed_text==original
p.write_text(text,encoding='utf-8',newline='\n');changes.append(rel)
patch+=difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='broader/'+rel,tofile='observed/'+rel)
rel='crates/core/src/sheets.rs';p=work/rel;original=p.read_text(encoding='utf-8');text=original
needle='''        if !better(metrics, self.metrics()) {
            return Ok(false);
        }'''
insert='''        eprintln!("GAP_ACCEPT {}", serde_json::json!({"stage":stage,"clock":self.clock.now(),"layout":&layout,"incumbent":&self.best.0,"candidate_material":metrics.material_area,"incumbent_material":self.metrics().material_area,"would_accept":better(metrics,self.metrics())}));
'''
assert text.count(needle)==1;text=text.replace(needle,insert+needle);assert text.replace(insert,'')==original
p.write_text(text,encoding='utf-8',newline='\n');changes.append(rel)
patch+=difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='broader/'+rel,tofile='observed/'+rel)
(out/'instrumentation.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
files=[{'path':p.relative_to(old).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(old.rglob('*')) if p.is_file()]
expected=root/'output/h5-larger-return-test-review-v2-20261018/broader-v2-accepted_exchange_still_fills_a_known_gap/0/observation.json'
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_workspace':str(old),'changed_files':changes,'old_files':files,
    'observed_sources':{r:sha256((work/r).read_bytes()).hexdigest() for r in changes},'instrumentation_reverses_exactly':True,
    'expected_observation':str(expected),'expected_observation_sha256':sha256(expected.read_bytes()).hexdigest(),'target':str(root/'output/h5-larger-return-gap-trace-target-20261018'),
    'production_digest':source_digest(),'unchanged_fixture_test':'sheets::vstrip::exchange::tests::accepted_exchange_still_fills_a_known_gap',
    'expected_test_exit':101,'require_exact_final_layout_and_stats':True,'performance_or_quality_measurement':False,'held_out_inputs_read':False}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'observed_files':changes,'original_assertions_unchanged':True,'exact_reversal':True}))
