"""Verify the final fixed-work result is exact, then validate all intermediate layouts."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,traceback
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-gap-trace-20261018';work=out/'workspace'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(out/'plan.json');sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
def guards():
    assert source_digest()==plan['production_digest']
    for row in plan['old_files']:
        assert digest(Path(plan['old_workspace'])/row['path'])==row['sha256']
        assert digest(work/row['path'])==(plan['observed_sources'].get(row['path']) or row['sha256'])
    assert digest(Path(plan['expected_observation']))==plan['expected_observation_sha256']
try:
    guards();command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--no-run','--target-dir',plan['target']]
    started=datetime.now(timezone.utc).isoformat()
    with (out/'build.log').open('xb') as f:r=subprocess.run(command,cwd=work,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
    write(out/'build.json',{'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'log_sha256':digest(out/'build.log')});assert r.returncode==0
    binaries=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
    binary=out/'tests.exe';shutil.copyfile(binaries[0],binary)
    command=[str(binary),'--exact',plan['unchanged_fixture_test'],'--nocapture'];r=subprocess.run(command,cwd=work,capture_output=True,timeout=180)
    (out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr);write(out/'test-command.json',{'command':command,'exit_code':r.returncode,'binary_sha256':digest(binary)})
    assert r.returncode==101
    stages=[];accepts=[];final=[]
    for line in r.stderr.decode().splitlines():
        for prefix,rows in [('GAP_STAGE ',stages),('GAP_ACCEPT ',accepts),('PAIR_FILTER_REVIEW ',final)]:
            if line.startswith(prefix):rows.append(json.loads(line.removeprefix(prefix)))
    assert len(final)==1 and final[0]==load(Path(plan['expected_observation'])),'Instrumentation changed the final result'
    assert [r['stage'] for r in stages]==['before_exchange','after_exchange','after_fill']
    assert stages[-1]['stats']['post_exchange_fill_calls']==stages[-1]['stats']['post_exchange_fill_moves']==1
    observations=[{'kind':'stage',**row} for row in stages]+[{'kind':'accept',**row} for row in accepts]
    observations.append({'kind':'final','stage':'final','layout':final[0]['after'],'stats':final[0]['stats']})
    cli=root/'target/release/nestbolt.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    write(out/'job.json',final[0]['job']);records=[]
    for index,row in enumerate(observations):
        folder=out/f'observation-{index:03d}';folder.mkdir();write(folder/'observation.json',row);write(folder/'layout.json',row['layout'])
        command=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(folder/'layout.json')]
        checked=subprocess.run(command,capture_output=True,timeout=60)
        (folder/'stdout.json').write_bytes(checked.stdout);(folder/'stderr.log').write_bytes(checked.stderr);write(folder/'command.json',{'command':command,'exit_code':checked.returncode})
        assert checked.returncode==0 and json.loads(checked.stdout)['valid']
        metrics=json.loads(checked.stdout)['metrics']
        if row['kind']=='accept':assert metrics['material_area']==row['candidate_material']
        record={'index':index,'kind':row['kind'],'stage':row['stage'],'material':metrics['material_area'],'would_accept':row.get('would_accept'),
            'parts':[{k:p[k] for k in ['part_id','copy_index','sheet_id']} for p in row['layout']['placements']],
            'gap_sheet':[p['sheet_id'] for p in row['layout']['placements'] if p['part_id']=='gap-part'],
            'observation_path':(folder/'observation.json').relative_to(out).as_posix(),'valid':True}
        records.append(record)
    guards();write(out/'results.json',{'exact_final_observation_reproduced':True,'original_assertion_still_fails':True,'all_observed_layouts_valid':True,
        'public_validations':len(records),'records':records,'guards_unchanged':True,'production_changed':False,'quality_or_performance_measurement':False})
    shutil.copyfile(__file__,out/'run.py');print(json.dumps({'exact_final':True,'public_validations':len(records),'records':records}))
except BaseException:write(out/'failure.json',{'error':traceback.format_exc()});raise
