"""Seal the corrected functional qualification and the evidence behind test refinements."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-return-probe-20261018'
trace=root/'output/h5-larger-return-gap-trace-20261018'
out=root/'benchmarks/results/h5-larger-return-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');plan=load(probe/'preparation.json');refined=load(probe/'refined-checks.json')
assert build['all_checks_passed'] and all(r['exit_code']==0 for r in build['stages'])
assert '113 passed; 0 failed' in (probe/'core-tests-v2.log').read_text()
binaries=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
assert not (probe/'qualified-tests.exe').exists()
shutil.copyfile(binaries[0],probe/'qualified-tests.exe')
write(probe/'qualified-tests.json',{'binary_sha256':digest(probe/'qualified-tests.exe'),'source_sha256':build['source_sha256'],'core_log_sha256':digest(probe/'core-tests-v2.log')})
public=load(probe/'public-checks/checks.json');witness=load(probe/'witness-checks/checks.json');fill=load(probe/'direct-fill-checks/checks.json');observed=load(trace/'results.json')
assert public['all_checks_passed'] and witness['all_checks_passed'] and fill['all_checks_passed']
assert witness['actual_outcomes']==6 and witness['public_validations']==12 and fill['public_validations']==2
assert observed['exact_final_observation_reproduced'] and observed['public_validations']==8 and observed['all_observed_layouts_valid']
assert observed['records'][2]['gap_sheet']==['sheet-0'] and observed['records'][6]['gap_sheet']==['sheet-1']
assert observed['records'][6]['would_accept'] and observed['records'][6]['material']<observed['records'][3]['material']
assert refined['extraction_reversed_exactly'] and len(refined['changed_prior_tests'])==4
regression=load(probe/'regressions-before.json')
assert regression['runtime_unchanged'] and regression['positive_assertion_failed'] and regression['disabled_or_expired_passed'] and regression['failed_room_passed'] and regression['expected_counts']
assert digest(probe/'regressions-before.log')==regression['log_sha256'] and digest(probe/'regressions-before.exe')==regression['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in plan['added_files'].items():assert digest(probe/'candidate'/rel)==expected
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert digest(probe/'rejected-mixed-observer.exe')==plan['rejected_mixed_observer_sha256']
method=load(probe/'pilot-method-v2.json');assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
harness=(probe/'pilot-harness-tests.log').read_text();assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
exchange='crates/core/src/sheets/vstrip/exchange.rs'
before=(Path(plan['old_probe'])/'candidate'/exchange).read_text();after=(probe/'candidate'/exchange).read_text()
runtime=before.split('#[cfg(test)]')[0]
for fragment in load(probe/'runtime-change.json')['removed_fragments']:
    assert runtime.count(fragment)==1;runtime=runtime.replace(fragment,'')
actual=after.split('#[cfg(test)]')[0]
actual=actual.replace(refined['guard_helper'],'').replace('if exchange_increases_material(before, after)',refined['original_guard'])
assert actual==runtime
patch=[]
for rel in plan['changed_files']:
    a=(Path(plan['old_probe'])/'candidate'/rel).read_text();b=(probe/'candidate'/rel).read_text()
    patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='mixed/'+rel,tofile='larger-return/'+rel))
(probe/'candidate-final.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
out.mkdir()
files={}
for prefix,folder in [('probe',probe),('gap-trace',trace)]:
    for p in folder.rglob('*'):
        if p.is_file():files[prefix+'/'+p.relative_to(folder).as_posix()]=p
helpers=['prepare_h5_larger_return.py','check_h5_larger_return_before.py','apply_h5_larger_return.py','build_h5_larger_return.py',
 'prepare_h5_larger_return_gap_trace.py','run_h5_larger_return_gap_trace.py','refine_h5_larger_return_checks-first-failed.py',
 'refine_h5_larger_return_checks.py','audit_h5_larger_return_refinement.py','build_h5_larger_return_v2.py',
 'prepare_h5_larger_return_v2_followup.py','check_h5_larger_return_witnesses_v2.py','check_h5_larger_return_direct_fill.py',
 'recover_h5_larger_return_direct_fill.py','check_h5_larger_return_direct_fill_v2.py',
 'check_h5_larger_return_public.py','check_h5_larger_return_harness.py','seal_h5_larger_return_v2.py','record_h5_larger_return_v2.py']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['helpers/pilot.py']=root/'scripts/h5_larger_return_pilot.py'
assert not any('.claude' in n.split('/') for n in files)
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_passed':113,'unchanged_previous_tests':103,'refined_previous_tests':4,'added_tests':6,
 'first_candidate_107_pass_4_fail_preserved':True,'original_runtime_regression_failed':True,'strict_material_guard_semantics_exact':True,
 'all_other_runtime_text_exact_after_reversing_removals_and_extraction':True,'gap_trace_final_exact':True,'gap_trace_CLI_validations':8,
 'direct_fill_CLI_validations':2,'larger_witness_outcomes':6,'larger_witness_CLI_validations':12,'public_observer_outcomes':10,
 'public_CLI_cross_checks':4,'strict_lint_pass':True,'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,
 'pilot_harness_tests':5,'production_unchanged':True,'binaries':build['binaries'],'quality_measurement_started':False,'H5_complete':False,'integrated':False}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','refined-checks.json','refinement-preparation-failures.json','candidate-final.patch','pilot-method-v2.json','regressions-before.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(trace/'results.json',out/'gap-trace-results.json')
shutil.copyfile(probe/'direct-fill-checks/checks.json',out/'direct-fill-checks.json')
doc='''# Larger-return pair qualification — 2026-10-18

The corrected isolated candidate passes **113 optimized core tests**, strict
lint/build, ten public observer outcomes, four public CLI comparisons and five
adversarial pilot checks. Production is unchanged and H5 remains open.

The [first candidate failure and output comparison](h5-larger-return-review-20261018.md)
remain preserved. Removing the returned-area filter admits valid alternatives:
the authored larger-return witness exchanges 2,700 mm2 for 2,790 mm2 without
increasing material. The unchanged runtime first fails this regression.

## Why four tests changed

The original four route/placement assertions all fail in the first candidate,
despite valid layouts and material no greater than each input. The direct
original/broader comparison preserves those failures and every original test.

The additional gap trace reproduces its saved final layout and statistics
exactly. Eight intermediate/final layouts independently validate. The named
part moves to sheet 0 during gap filling and remains there in the first
accepted result (12,205.4484 mm2). Later compression moves it back to sheet 1
and accepts lower material (12,200.1168 mm2). This is still 0.0388 mm2 worse
than the old runtime's final result; it is not a quality improvement claim.

The corrected tests preserve the intended invariants:

- Single fallback uses a source with only one part, so no pair is available.
- The return-frame search allows its newly valid alternative, requiring an
  actual incoming transfer and strictly lower material. Existing direct
  three-piece frame, rotation and reflection checks remain exact.
- The actual runtime material comparison is extracted unchanged into a helper.
  A direct test rejects both the former +0.0007 mm2 increase and a one-ULP
  increase, even with fewer sheets, and rejects an extra sheet despite lower
  material. Equal or reduced material with no extra sheet remains allowed.
- The window test still requires exchange, post-exchange fill calls and moves,
  valid geometry and nonincreasing material, including disabled/expired paths.
  A direct exchange-then-fill test checks the named part on sheet 0 immediately
  after filling, before later optimization. Both saved layouts independently
  validate and preserve strict material nonincrease.

103 previous tests remain unchanged; four are refined as above. Six added
tests cover larger returns, disabled/expired calls, impossible return room,
frozen sheets, the strict material boundary and immediate gap filling. The six
larger-return outcomes pass twelve further frozen-CLI before/after checks.
Exact source reversal proves the runtime differences are the paired area
filter removal, its unused sum removal and the semantics-preserving guard
extraction. Ranking, caps, choices, repairs, geometry, neutral guard, fill and
all budgets are unchanged. Two preparation-script audit failures are retained;
neither started a build or search before its correction.

The passing concurrent core run interleaved test-status stdout into the direct
fill JSON on stderr. Its reader failure and merged log remain. Recovery runs
only that same authored fixed-work test with separately captured streams,
using the same compiled binary; its two saved layouts independently validate.
The full core suite and every other completed observation are not repeated.

Normal public outputs and common-mode deterministic replays are exact except
wall time. Pilot block, score, case and measurement functions remain
AST-identical to the previous pilot. The proposed comparison retains four
jobs, both kerfs, seeds 0–2, three rotating sequential arms, eight physical
CCD0 cores and 60-second searches. The +1% material requirement and complete
13-job H5 gate remain unchanged. No measured gain or integration is claimed.

[Checks](h5-larger-return-preparation-20261018/checks.json),
[trace](h5-larger-return-preparation-20261018/gap-trace-results.json),
[source/test audit](h5-larger-return-preparation-20261018/refined-checks.json)
and [verified archive](h5-larger-return-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-larger-return-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size,'optimized_core_passed':113}))
