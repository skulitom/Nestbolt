"""Run new regression checks against the unchanged mixed-pair runtime."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());work=out/'candidate';old=Path(plan['old_probe'])/'candidate';rel=plan['changed_files'][0]
assert (work/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(old/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]
for row in plan['old_source_files']['candidate']:
    if row['path']!=rel:assert sha256((work/row['path']).read_bytes()).hexdigest()==row['sha256']
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',plan['target'],'larger_return_','--','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (out/'regressions-before.log').open('xb') as f:result=subprocess.run(command,cwd=work,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
log=(out/'regressions-before.log').read_text(encoding='utf-8')
binaries=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
shutil.copyfile(binaries[0],out/'regressions-before.exe')
record={'command':command,'exit_code':result.returncode,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
    'log_sha256':sha256((out/'regressions-before.log').read_bytes()).hexdigest(),'binary_sha256':sha256((out/'regressions-before.exe').read_bytes()).hexdigest(),
    'runtime_unchanged':True,'positive_assertion_failed':'larger return area must not exclude a valid material-nonincreasing pair exchange:' in log,
    'disabled_or_expired_passed':'larger_return_disabled_or_expired_preserves_incumbent ... ok' in log,
    'failed_room_passed':'larger_return_failed_room_preserves_incumbent ... ok' in log,'expected_counts':'2 passed; 1 failed' in log,'measured_searches':0}
(out/'regressions-before.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result.returncode==101 and all(record[k] for k in ['positive_assertion_failed','disabled_or_expired_passed','failed_room_passed','expected_counts']),record
print(json.dumps(record))
