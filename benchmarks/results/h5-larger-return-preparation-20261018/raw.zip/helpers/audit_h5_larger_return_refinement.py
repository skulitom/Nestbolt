"""Finish the source audit after the first audit included non-test impl methods."""
from pathlib import Path
from hashlib import sha256
import ast,json,re,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-return-probe-20261018'
script=root/'output/refine_h5_larger_return_checks.py'
shutil.copyfile(script,probe/'refine-checks-with-audit-failure.py')
load=lambda p:json.loads(p.read_bytes())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
rel='crates/core/src/sheets/vstrip/exchange.rs'
old=(probe/'initial-larger-attempt/candidate'/rel).read_text(encoding='utf-8')
text=(probe/'candidate'/rel).read_text(encoding='utf-8')
assignments={}
for node in ast.parse(script.read_text()).body:
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ['helper','guard','changed']:
        assignments[node.targets[0].id]=ast.literal_eval(node.value)
helper=assignments['helper'];guard=assignments['guard'];changed=assignments['changed']
runtime=text.split('#[cfg(test)]')[0]
assert runtime.count(helper)==1
runtime=runtime.replace(helper,'').replace('if exchange_increases_material(before, after)',guard)
assert runtime==old.split('#[cfg(test)]')[0]
def functions(t):
    t=t.split('#[cfg(test)]')[1]
    matches=list(re.finditer(r'^    fn (\w+)\(',t,re.M));out={}
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(t)
        chunk=t[m.start():end];out[m[1]]=chunk[:chunk.rfind('\n    }')+6]
    return out
a=functions(old);b=functions(text);unchanged=[]
for name,body in a.items():
    if name not in changed:
        assert b.get(name)==body,name;unchanged.append(name)
assert len(re.findall(r'#\[test\]',text))==len(re.findall(r'#\[test\]',old))+2
write(probe/'refined-checks.json',{'changed_prior_tests':changed,'all_other_test_functions_exact':unchanged,
    'unchanged_previous_test_count':103,'added_tests':6,'expected_core_tests':113,
    'first_candidate_preserved':True,'gap_trace_exact_and_valid':True,
    'guard_helper':helper,'original_guard':guard,'extraction_reversed_exactly':True,
    'before_sha256':sha256(old.encode()).hexdigest(),'after_sha256':sha256((probe/'candidate'/rel).read_bytes()).hexdigest(),
    'no_gate_or_budget_change':True,'no_production_change':True})
write(probe/'refinement-preparation-failures.json',{'failures':[
    {'stage':'before source write','error':'Return-count assertion appeared in two tests; stopped on count assertion.','recovery':'Scope the replacement to the reviewed return-frame test.'},
    {'stage':'after source write and formatting; before build','error':'Unchanged-function audit included impl methods and trailing cfg(test) module boundary.','recovery':'Audit test module functions only; reverse guard extraction exactly.'}],
    'no_build_or_search_before_recovery':True,'original_failed_helper':'refine_h5_larger_return_checks-first-failed.py'})
build=(root/'output/build_h5_larger_return.py').read_text()
build=build.replace("out/(label+'.log')","out/(label+'-v2.log')").replace("out/'progress.json'","out/'progress-v2.json'").replace("out/'build-failure.json'","out/'build-failure-v2.json'")
build=build.replace("def guards():","def guards():\n    assert digest(out/'candidate/crates/core/src/sheets/vstrip/exchange.rs')==load(out/'refined-checks.json')['after_sha256']")
(root/'output/build_h5_larger_return_v2.py').write_text(build,encoding='utf-8',newline='\n')
print(json.dumps({'runtime_guard_exact':True,'unchanged_test_functions':len(unchanged),'expected_core_tests':113}))
