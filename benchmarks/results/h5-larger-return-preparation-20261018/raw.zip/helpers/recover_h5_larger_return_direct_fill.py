"""Recover only an interleaved authored-test observation; no quality measurement."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-return-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert load(probe/'build.json')['all_checks_passed']
log=probe/'core-tests-v2.log';assert '113 passed; 0 failed' in log.read_text()
bad=next(s for s in log.read_text().splitlines() if s.startswith('DIRECT_FILL_WITNESS '))
assert 'test sheets::vstrip::exchange::tests::return_frame_preserves_permitted_reflection_and_relative_positions ... ok' in bad
out=probe/'direct-fill-log-recovery';out.mkdir()
write(out/'original-reader-failure.json',{'error':'JSONDecodeError at column 984: concurrent test stdout interleaved into the stderr JSON in the merged core log.',
    'original_log_sha256':digest(log),'original_helper_sha256':digest(root/'output/check_h5_larger_return_direct_fill.py'),
    'original_full_suite_passed':113,'recovery':'Run only the same authored direct-fill test with stdout/stderr captured separately; no quality or performance rerun.'})
binaries=list((Path(load(probe/'preparation.json')['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
binary=out/'tests.exe';shutil.copyfile(binaries[0],binary)
command=[str(binary),'--exact','sheets::vstrip::exchange::tests::gap_fill_moves_known_part_immediately_after_exchange','--nocapture']
r=subprocess.run(command,cwd=probe/'candidate',capture_output=True,timeout=180)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr)
write(out/'command.json',{'command':command,'exit_code':r.returncode,'binary_sha256':digest(binary)});assert r.returncode==0
source=(root/'output/check_h5_larger_return_direct_fill.py').read_text()
needle="rows=[json.loads(s.removeprefix('DIRECT_FILL_WITNESS ')) for s in log.splitlines() if s.startswith('DIRECT_FILL_WITNESS ')]"
assert source.count(needle)==1
source=source.replace(needle,"rows=[json.loads(s.removeprefix('DIRECT_FILL_WITNESS ')) for s in (probe/'direct-fill-log-recovery/stderr.log').read_text().splitlines() if s.startswith('DIRECT_FILL_WITNESS ')]")
helper=root/'output/check_h5_larger_return_direct_fill_v2.py';helper.write_text(source,encoding='utf-8',newline='\n')
subprocess.run(['python',str(helper)],cwd=root,check=True)
shutil.copyfile(__file__,out/'recover.py')
