from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-return-probe-20261018'
load=lambda p:json.loads(p.read_bytes())
assert load(probe/'build.json')['all_checks_passed']
log=(probe/'core-tests-v2.log').read_text();assert '113 passed; 0 failed' in log
rows=[json.loads(s.removeprefix('DIRECT_FILL_WITNESS ')) for s in (probe/'direct-fill-log-recovery/stderr.log').read_text().splitlines() if s.startswith('DIRECT_FILL_WITNESS ')]
assert len(rows)==1;row=rows[0]
out=probe/'direct-fill-checks';out.mkdir()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
cli=root/'target/release/nestbolt.exe';digest=lambda p:sha256(p.read_bytes()).hexdigest()
expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
write(out/'job.json',row['job']);metrics={}
for stage,sheet in [('before','sheet-1'),('after','sheet-0')]:
    assert [p['sheet_id'] for p in row[stage]['placements'] if p['part_id']=='gap-part']==[sheet]
    write(out/(stage+'.json'),row[stage])
    args=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(out/(stage+'.json'))]
    r=subprocess.run(args,capture_output=True,timeout=60)
    (out/(stage+'-stdout.json')).write_bytes(r.stdout);(out/(stage+'-stderr.log')).write_bytes(r.stderr)
    write(out/(stage+'-command.json'),{'command':args,'exit_code':r.returncode})
    assert r.returncode==0
    v=json.loads(r.stdout);assert v['valid'];metrics[stage]=v['metrics']['material_area']
assert metrics['after']<=metrics['before'] and digest(cli)==expected
write(out/'checks.json',{'all_checks_passed':True,'public_validations':2,'named_part_moves_to_earlier_sheet':True,'strict_material_nonincrease':True,'material':metrics,'CLI_sha256':expected})
shutil.copyfile(__file__,out/'check.py');print(json.dumps({'public_validations':2,'material':metrics}))
