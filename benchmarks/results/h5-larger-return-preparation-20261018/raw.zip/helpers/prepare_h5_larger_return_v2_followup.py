from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-return-probe-20261018'
runner=root/'scripts/h5_larger_return_pilot.py';text=runner.read_text()
old='''The baseline is the unchanged preview. Only the paired proposal area rejection
is removed from the preceding mixed-pair candidate. Complete obstruction sets,'''
new='''The baseline is the unchanged preview. The candidate removes the paired proposal
area rejection and extracts the unchanged strict material check for direct tests.
Four route-specific tests are refined after preserved actual-layout diagnosis;
103 prior tests remain unchanged and six added tests cover the new invariants.
Complete obstruction sets,'''
assert text.count(old)==1;text=text.replace(old,new)
needle="PROBE/'build.json', PROBE/'preparation.json',"
assert text.count(needle)==1;text=text.replace(needle,needle+" PROBE/'refined-checks.json',")
runner.write_text(text,encoding='utf-8',newline='\n')
reference=root/'scripts/h5_mixed_exchange_pilot.py'
functions=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
a,b=functions(reference),functions(runner);names=['blocks','summarize','case','measure']
assert all(a[n]==b[n] for n in names)
method={'reference':reference.relative_to(root).as_posix(),'reference_sha256':sha256(reference.read_bytes()).hexdigest(),
 'candidate_runner':runner.relative_to(root).as_posix(),'runner_sha256':sha256(runner.read_bytes()).hexdigest(),
 'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method-v2.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'output/check_h5_larger_return_witnesses.py'
text=p.read_text();assert text.count("'core-tests.log'")==1
(root/'output/check_h5_larger_return_witnesses_v2.py').write_text(text.replace("'core-tests.log'","'core-tests-v2.log'"),encoding='utf-8',newline='\n')
print('Updated qualification metadata; measurement and scoring ASTs remain exact.')
