"""Record per-copy modes, equal-group symmetry and unchanged nonbinding hints."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-orientation-construction-20261025'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def modify(source,target,changes):
    text=source.read_text(encoding='utf-8')
    for old,new in changes:assert text.count(old)==1,(old,text.count(old));text=text.replace(old,new)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    return {'source':source.relative_to(ROOT).as_posix(),'source_sha256':digest(source),'target':target.relative_to(ROOT).as_posix(),'target_sha256':digest(target),'changes':[{'old':a,'new':b} for a,b in changes]}
def main():
    records=[]
    p=ROOT/'output/h5_compound_proxy_encoding.py';target=ROOT/'output/h5_source_inventory_encoding.py';changes=[("qs=[q for q in geo['modes'] if q['family']==item['family']]","qs=[q for q in geo['modes'] if q['family']==item['family'] and q['index'] in item['modes']]"),("for m in geo['modes'] if m['family']==item['family']","for m in geo['modes'] if m['family']==item['family'] and m['index'] in item['modes']")];records.append(modify(p,target,changes));shutil.copyfile(p,BASE/'propagation-module-template.py')
    p=ROOT/'output/h5_verified_source_hints.py';target=ROOT/'output/h5_inventory_source_hints.py';changes=[('def verify(actual,geo,aux,hints,required):','def verify(actual,geo,aux,hints,required,specs):'),("modes=[0,1] if f=='cog' else [m['index'] for m in geo['modes'] if m['family']==f]","modes=specs[r['item']]['allowed_modes'];assert specs[r['item']]['family']==f and specs[r['item']]['copy']==r['copy']")];records.append(modify(p,target,changes));shutil.copyfile(p,BASE/'hint-module-template.py')
    p=ROOT/'output/solve_h5_alias_source_hints.py';target=ROOT/'output/solve_h5_source_orientation_inventory.py';changes=[
        ("BASE=ROOT/'output/h5-alias-source-hints-20261025'","BASE=ROOT/'output/h5-source-orientation-construction-20261025'"),
        ('from h5_compound_proxy_encoding import','from h5_source_inventory_encoding import'),
        ('from h5_verified_source_hints import','from h5_inventory_source_hints import'),
        ("hints=load(BASE/'hint-poses.json');plan=", "hints=load(BASE/'hint-poses.json');specs=load(BASE/'items.json');group_specs=load(BASE/'groups.json');plan="),
        ("BASE/'aliases.json',BASE/'source-poses.json'","BASE/'items.json',BASE/'groups.json'"),
        ("            prefix=f'{family}-{copy}';x=", "            spec=specs[len(items)];assert spec['family']==family and spec['copy']==copy\n            prefix=f'{family}-{copy}';x="),
        ("[m for m in modes if m['family']==family]", "[m for m in modes if m['family']==family and m['index'] in spec['allowed_modes']]"),
        ("items.append({'index':len(items),'family':family", "items.append({'index':len(items),'group':spec['group'],'family':family"),
        ("    for family in required:\n        rows=[r for r in items if r['family']==family]", "    for group in group_specs:\n        rows=[r for r in items if r['group']==group['group']]"),
        ("            name=f'{family}-{copy}';x=", "            spec=specs[len(oracle)];assert spec['family']==family and spec['copy']==copy\n            name=f'{family}-{copy}';x="),
        ("[q for q in geo['modes'] if q['family']==family]", "[q for q in geo['modes'] if q['family']==family and q['index'] in spec['allowed_modes']]"),
        ("oracle.append({'index':len(oracle),'family':family", "oracle.append({'index':len(oracle),'group':spec['group'],'family':family"),
        ("    for family in required:\n        rows=[r for r in oracle if r['family']==family]", "    for group in group_specs:\n        rows=[r for r in oracle if r['group']==group['group']]"),
        ('verify_hints(actual,geo,aux,hints,required)','verify_hints(actual,geo,aux,hints,required,specs)'),
        ("'copy_order_constraints':62", "'copy_order_constraints':56,'ordering_only_within_equal_orientation_option_groups':True,'finite_source_orientation_inventory':True"),
        ("'interpretation':'All66 parts remain movable under the unchanged compound-proxy constraints after exact mode aliasing. Compatible source poses are nonbinding hints only; seven incompatible original poses are retained as omissions. The original source exceeds the target. A positive proxy outcome still requires original-outline/native diagnosis. No H5 qualification.'", "'interpretation':'A finite source-derived orientation inventory with all66 required parts and all positions and allowed sheet assignments free. The64 source poses are nonbinding hints; two additional brackets keep every original orientation. Copy order only within equivalent option groups. A negative result excludes no other orientation inventories; a positive proxy requires original-outline/native diagnosis. No H5 qualification.'"),
        ("A positive solution is only an inner-rectangle proxy relaxation. UNKNOWN is unresolved and does not prove infeasibility.","This finite orientation inventory is only a construction attempt using inner-rectangle proxies. UNKNOWN is unresolved; any infeasibility applies only to this inventory, not all original orientations.")]
    records.append(modify(p,target,changes));shutil.copyfile(p,BASE/'model-template.py')
    with (BASE/'solver-template-provenance.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'transformations':records,'random_seed_workers_and60second_limit_unchanged':True,'all66_mandatory_and_positions_unfixed':True,'finite_construction_not_unrestricted_relaxation':True,'solver_calls':0},f,indent=2);f.write('\n')
    print({'generated':str(target),'model_sha256':digest(target),'module_transformations':len(records)})
if __name__=='__main__':main()
