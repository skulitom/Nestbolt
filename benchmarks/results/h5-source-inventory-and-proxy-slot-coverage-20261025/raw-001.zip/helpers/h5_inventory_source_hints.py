"""Nonbinding hints plus an independent name-based serialized-hint oracle."""
from ortools.sat import cp_model_pb2

def build(model,vs,items,propagation,geo,aux,hints):
    bycopy={(r['family'],r['copy']):r for r in hints};values={}
    def put(idx,value):
        value=int(value)
        if idx in values:assert values[idx]==value
        values[idx]=value
    for item in items:
        r=bycopy.get((item['family'],item['copy']))
        if r is None:continue
        for field,data in [('x','x_units'),('y','y_units'),('sheet','sheet'),('key','key')]:put(item[field],r[data])
        assert r['mode'] in item['modes']
        for qi,vid in item['modes'].items():put(vid,qi==r['mode'])
        if item['family']!='cog':
            c=geo['classes'][r['representative_class']]
            for ci,vids in enumerate(item['components']):
                for axis,vid in enumerate(vids):put(vid,c['components'][ci][axis]*100)
        for p in propagation:
            if p['item']!=item['index']:continue
            box=(aux['cog_inner_components'][p['component']] if item['family']=='cog' else aux['inner_non_cog_components'][r['representative_class']]['components'][p['component']]);coords=[r['x_units']+box[0],r['y_units']+box[1],r['x_units']+box[2],r['y_units']+box[3]]
            for field,value in zip(['sx','sy','ex','ey'],coords):put(p[field],value)
            put(p['width'],box[2]-box[0]);put(p['height'],box[3]-box[1])
    for idx in sorted(values):model.add_hint(vs[idx],values[idx])
    return {'hinted_parts':len(hints),'hinted_variables':len(values),'fixed_parts':0,'missing_part_allowance':False,'hinted_indices':sorted(values)}

def verify(actual,geo,aux,hints,required,specs):
    names={v.name:i for i,v in enumerate(actual.variables)};assert len(names)==len(actual.variables);expected={};families=['frame','bracket','insert','cog'];bases={f:sum(required[g] for g in families[:i]) for i,f in enumerate(families)}
    def put(name,value):
        idx=names[name];value=int(value);assert idx not in expected;domain=list(actual.variables[idx].domain);assert any(domain[j]<=value<=domain[j+1] for j in range(0,len(domain),2)),(name,value,domain);expected[idx]=value
    for r in hints:
        f=r['family'];prefix=f"{f}-{r['copy']}";index=bases[f]+r['copy'];assert r['eligible'] and not r['omission_reasons']
        for suffix,key in [('x','x_units'),('y','y_units'),('sheet','sheet'),('key','key')]:put(prefix+'-'+suffix,r[key])
        modes=specs[r['item']]['allowed_modes'];assert specs[r['item']]['family']==f and specs[r['item']]['copy']==r['copy'];assert r['mode'] in modes
        for mode in modes:put(prefix+f'-mode{mode}',int(mode==r['mode']))
        if f!='cog':
            components=geo['classes'][r['representative_class']]['components']
            for arm,c in enumerate(components):
                for axis,value in enumerate(c):put(prefix+f'-arm{arm}-offset{axis}',int(value)*100)
            boxes=[[int(c[0])*100+1,int(c[1])*100+1,int(c[2])*100-1,int(c[3])*100-1] for c in components]
        else:boxes=aux['cog_inner_components']
        for arm,box in enumerate(boxes):
            prefix2=f'prop-{index}-arm{arm}';spec={'sx':r['x_units']+box[0],'sy':r['y_units']+box[1],'ex':r['x_units']+box[2],'ey':r['y_units']+box[3],'w':box[2]-box[0],'h':box[3]-box[1]}
            for suffix,value in spec.items():put(prefix2+'-'+suffix,value)
    ids=sorted(expected);message=cp_model_pb2.PartialVariableAssignment(vars=ids,values=[expected[i] for i in ids]);assert actual.solution_hint==message
    return {'hinted_parts':len(hints),'hinted_variables':len(expected),'fixed_parts':0,'missing_part_allowance':False,'hinted_indices':ids}
