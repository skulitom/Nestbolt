"""Independent integer-cell coverage and single-owner release census."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import product
from datetime import datetime,timezone
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-source-orientation-construction-20261025';BASE=ROOT/'output/h5-proxy-two-bracket-completion-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');inputs=[BASE/'plan.json',BASE/'generation.json',BASE/'selection.json',SRC/'audit/checks.json',SRC/'audit/source-inner-rectangles.json',SRC/'items.json',SRC/'geometry.json',SRC/'propagation.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'audit_seconds_limit':120,'method':'Independently derive each open rectangle-overlap condition and its inclusive integer bounds. Form every critical x/y cell and use separate per-owner2D prefix-sum difference arrays to count covered integer anchors, without using the construction sweep. Positive widths times heights count all integer points exactly, including one-coordinate-wide rows/columns. Owner counts identify every anchor released by deleting exactly one original part and all of its components. This is a count/certificate only, not placement of the removed part or a completed inventory.','scope':'Full fixed64-proxy grid coverage. A single-core release census only identifies possible bracket anchors; every released original part must be restored in any later full66 construction.'});start=time.perf_counter();plan=load(BASE/'plan.json');assert load(SRC/'audit/checks.json')['passed'];assert load(BASE/'generation.json')['queries_completed']==16 and not load(BASE/'pending.json');g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');fixed=load(SRC/'audit/source-inner-rectangles.json');items=load(SRC/'items.json');owners=sorted({r['item'] for r in fixed});assert len(owners)==64;results=[];release=defaultdict(list);totalcells=totalpoints=totalobstacles=0;maxseconds=0
    for qi,m in enumerate(plan['queries']):
        assert time.perf_counter()-start<120;began=time.perf_counter();q=load(BASE/'queries'/f'{qi:03d}.json');assert q['query']==qi and q['mode']==m['index'] and q['class']==m['class'] and q['sheet']==m['sheet'] and q['domain']==m['coordinate_bounds'];domain=q['domain'];moving=aux['inner_non_cog_components'][m['class']]['components'];assert q['moving_components']==moving;obstacles=[];byowner=defaultdict(list)
        for r in fixed:
            if r['sheet']!=m['sheet']:continue
            a=r['bounds']
            for b in moving:
                lowx=max(domain[0],a[0]-b[2]+1);highx=min(domain[2],a[2]-b[0]-1);lowy=max(domain[1],a[1]-b[3]+1);highy=min(domain[3],a[3]-b[1]-1)
                if lowx>highx or lowy>highy:continue
                rectangle=[lowx,lowy,highx,highy];obstacles.append(rectangle);byowner[r['item']].append(rectangle)
        assert Counter(map(tuple,obstacles))==Counter(map(tuple,q['forbidden_integer_rectangles']));totalobstacles+=len(obstacles);xs=sorted({domain[0],domain[2]+1}|{v for r in obstacles for v in [r[0],r[2]+1]});ys=sorted({domain[1],domain[3]+1}|{v for r in obstacles for v in [r[1],r[3]+1]});ix={v:i for i,v in enumerate(xs)};iy={v:i for i,v in enumerate(ys)};shape=(len(xs)-1,len(ys)-1);counts=np.zeros(shape,dtype=np.int16);ownerxor=np.zeros(shape,dtype=np.int16)
        for owner,rs in byowner.items():
            difference=np.zeros((len(xs),len(ys)),dtype=np.int16)
            for a,b,c,d in rs:
                i,j,k,l=ix[a],iy[b],ix[c+1],iy[d+1];difference[i,j]+=1;difference[k,j]-=1;difference[i,l]-=1;difference[k,l]+=1
            cover=difference.cumsum(axis=0,dtype=np.int32).cumsum(axis=1,dtype=np.int32)[:-1,:-1];assert np.all(cover>=0);mask=cover>0;counts+=mask;ownerxor[mask]^=owner+1
        widths=np.diff(np.array(xs,dtype=np.int64));heights=np.diff(np.array(ys,dtype=np.int64));weights=widths[:,None]*heights[None,:];domainpoints=(domain[2]-domain[0]+1)*(domain[3]-domain[1]+1);assert int(weights.sum())==domainpoints;free=int(weights[counts==0].sum());assert free==q['free_anchor_count']==0 and q['free_integer_cells']==[];totalcells+=counts.size;totalpoints+=domainpoints
        for owner in owners:
            opened=int(weights[(counts==1)&(ownerxor==owner+1)].sum());release[owner].append({'query':qi,'mode':m['index'],'sheet':m['sheet'],'free_bracket_anchors_after_release':opened})
        seconds=time.perf_counter()-began;maxseconds=max(maxseconds,seconds);results.append({'query':qi,'mode':m['index'],'sheet':m['sheet'],'critical_integer_cells':int(counts.size),'domain_integer_anchors':domainpoints,'covered_integer_anchors':domainpoints-free,'free_integer_anchors':free,'minimum_distinct_owner_coverage':int(counts.min()),'maximum_distinct_owner_coverage':int(counts.max()),'seconds':seconds})
    rows=[]
    for owner in owners:
        rows.append({'item':owner,'family':items[owner]['family'],'source_index':items[owner]['source_index'],'total_mode_anchor_pairs_after_release':sum(r['free_bracket_anchors_after_release'] for r in release[owner]),'nonempty_queries':sum(r['free_bracket_anchors_after_release']>0 for r in release[owner]),'queries':release[owner]})
    core=[r for r in rows if r['family'] in ['frame','cog']];core.sort(key=lambda r:(-r['total_mode_anchor_pairs_after_release'],r['item']));assert len(core)==33;write(OUT/'coverage.json',results);write(OUT/'single-part-release-census.json',rows);write(OUT/'ranked-core-release-census.json',core);selection=load(BASE/'selection.json');assert selection['all_cell_pairs_exhausted'] and not selection['capped'] and selection['cell_pairs_examined']==0 and not selection['found_two_proxy_slots'];write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'queries':len(results),'independently_reconstructed_forbidden_rectangles':totalobstacles,'critical_integer_cells':totalcells,'integer_anchors_covered':totalpoints,'free_bracket_anchors_with64_fixed_proxy_parts':0,'single_original_part_release_census':len(rows),'core_releases_censused':len(core),'core_releases_with_any_bracket_anchor':sum(r['nonempty_queries']>0 for r in core),'maximum_query_seconds':maxseconds,'all_touching_and_single_coordinate_cases_included':True,'conditional_conclusion':'No additional bracket can fit on the model grid while all64 source proxy poses remain fixed. Existing positions must change. Deleting one part only identifies potential bracket anchors; that part must still be restored.','full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True);print({'leading_core_releases':[{k:r[k] for k in ['item','family','source_index','total_mode_anchor_pairs_after_release','nonempty_queries']} for r in core[:6]]},flush=True)
if __name__=='__main__':main()
