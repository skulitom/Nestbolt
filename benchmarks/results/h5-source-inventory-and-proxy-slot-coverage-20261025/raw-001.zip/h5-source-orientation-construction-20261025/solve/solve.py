"""One bounded all-parts-movable outer model, with full protobuf audit first."""
from pathlib import Path
from collections import Counter
from itertools import combinations,product
from hashlib import sha256
from datetime import datetime,timezone
import gc,json,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from h5_source_inventory_encoding import build as build_propagation, verify as verify_propagation
from h5_inventory_source_hints import build as build_hints, verify as verify_hints
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');geo=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');hints=load(BASE/'hint-poses.json');specs=load(BASE/'items.json');group_specs=load(BASE/'groups.json');plan=load(BASE/'plan.json');parameters=plan['solver_parameters'];required=plan['required_counts'];classes=geo['classes'];modes=geo['modes'];mx,my=geo['coordinate_maxima'];stride=(mx+1)*(my+1);loint,hiint=cp_model.INT_MIN,cp_model.INT_MAX
    inputs=[BASE/'plan.json',BASE/'geometry.json',BASE/'propagation.json',BASE/'items.json',BASE/'groups.json',BASE/'hint-poses.json',BASE/'audit/checks.json',BASE/'solver-template-provenance.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'parameters':parameters,'maximum_solver_calls':1,'required_counts':required,'fixed_parts':0,'hint':{'source':(BASE/'hint-poses.json').relative_to(ROOT).as_posix(),'parts':len(hints),'binding':False},'objective':None,'quantities':'All66 mandatory; no unplaced variables','interpretation':'A finite source-derived orientation inventory with all66 required parts and all positions and allowed sheet assignments free. The64 source poses are nonbinding hints; two additional brackets keep every original orientation. Copy order only within equivalent option groups. A negative result excludes no other orientation inventories; a positive proxy requires original-outline/native diagnosis. No H5 qualification.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[];items=[];pairs=[]
    def var(lo,hi,n):
        v=model.new_int_var(lo,hi,n);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*v for i,v in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] if i>=0 else vs[-i-1].Not() for i in en])
    for family in ['frame','bracket','insert','cog']:
        for copy in range(required[family]):
            spec=specs[len(items)];assert spec['family']==family and spec['copy']==copy
            prefix=f'{family}-{copy}';x=var(0,mx,prefix+'-x');y=var(0,my,prefix+'-y');sheet=var(0,1,prefix+'-sheet');key=var(0,2*stride-1,prefix+'-key');qs=([{'index':i,'sheet':i,'coordinate_bounds':b} for i,b in enumerate(geo['cog_center_bounds'])] if family=='cog' else [m for m in modes if m['family']==family and m['index'] in spec['allowed_modes']]);active={q['index']:var(0,1,prefix+f"-mode{q['index']}") for q in qs};components=[]
            for arm in range(0 if family=='cog' else 2 if family=='bracket' else 1):
                coords=[]
                for axis in range(4):
                    values=[classes[q['class']]['components'][arm][axis]*100 for q in qs];coords.append(var(min(values),max(values),prefix+f'-arm{arm}-offset{axis}'))
                components.append(coords)
            model.add_exactly_one([vs[v] for v in active.values()])
            for q in qs:
                a,b,c,d=q['coordinate_bounds'];linear([(x,1)],a,c,[active[q['index']]]);linear([(y,1)],b,d,[active[q['index']]])
            linear([(sheet,1)]+[(active[q['index']],-q['sheet']) for q in qs],0,0)
            for arm,coords in enumerate(components):
                for axis,v in enumerate(coords):linear([(v,1)]+[(active[q['index']],-classes[q['class']]['components'][arm][axis]*100) for q in qs],0,0)
            linear([(key,1),(sheet,-stride),(y,-(mx+1)),(x,-1)],0,0);items.append({'index':len(items),'group':spec['group'],'family':family,'copy':copy,'x':x,'y':y,'sheet':sheet,'key':key,'modes':active,'components':components})
    for group in group_specs:
        rows=[r for r in items if r['group']==group['group']]
        for a,b in zip(rows,rows[1:]):linear([(a['key'],1),(b['key'],-1)],loint,0)
    propagation=build_propagation(model,vs,items,geo,aux,var,linear);write(OUT/'propagation-mapping.json',propagation)
    hint_record=build_hints(model,vs,items,propagation,geo,aux,hints);write(OUT/'hint-construction.json',hint_record)
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',{'items':items,'pairs':pairs,'stride':stride});build_seconds=time.perf_counter()-start;assert build_seconds<plan['model_construction_limit_seconds'];print({'construction_seconds':build_seconds,'variables':len(vs),'physical_parts':len(items)},flush=True)
    # Read serialized protobuf independently. Reconstruct all fields from audited geometry.
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());vi=ci=0;oracle=[];oraclepairs=[]
    def vcheck(name,lo,hi):
        nonlocal vi
        expected=cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);assert actual.variables[vi]==expected,(vi,name);vi+=1;return vi-1
    def lcheck(terms,lo,hi,en=()):
        nonlocal ci
        merged=Counter()
        for idx,coef in terms:merged[idx]+=coef
        ids=sorted(i for i,c in merged.items() if c);expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.extend(en);expected.linear.vars.extend(ids);expected.linear.coeffs.extend(merged[i] for i in ids);expected.linear.domain.extend([lo,hi]);assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1
    def bcheck(kind,ids):
        nonlocal ci
        expected=cp_model_pb2.ConstraintProto();getattr(expected,kind).literals.extend(ids);assert actual.constraints[ci]==expected,(ci,kind);ci+=1
    for family,count in [('frame',18),('bracket',12),('insert',21),('cog',15)]:
        for copy in range(count):
            spec=specs[len(oracle)];assert spec['family']==family and spec['copy']==copy
            name=f'{family}-{copy}';x=vcheck(name+'-x',0,150000);y=vcheck(name+'-y',0,300000);s=vcheck(name+'-sheet',0,1);key=vcheck(name+'-key',0,2*stride-1);qs=([{'index':i,'sheet':i,'coordinate_bounds':geo['cog_center_bounds'][i]} for i in [0,1]] if family=='cog' else [q for q in geo['modes'] if q['family']==family and q['index'] in spec['allowed_modes']]);active={q['index']:vcheck(name+f"-mode{q['index']}",0,1) for q in qs};comps=[]
            for arm in range({'frame':1,'bracket':2,'insert':1,'cog':0}[family]):
                ids=[]
                for axis in range(4):
                    vals=[int(geo['classes'][q['class']]['components'][arm][axis])*100 for q in qs];ids.append(vcheck(name+f'-arm{arm}-offset{axis}',min(vals),max(vals)))
                comps.append(ids)
            bcheck('exactly_one',list(active.values()))
            for q in qs:
                bound=q['coordinate_bounds'];lcheck([(x,1)],bound[0],bound[2],[active[q['index']]]);lcheck([(y,1)],bound[1],bound[3],[active[q['index']]])
            lcheck([(s,1)]+[(active[q['index']],-1) for q in qs if q['sheet']==1],0,0)
            for arm,comp in enumerate(comps):
                for axis,v in enumerate(comp):lcheck([(v,1)]+[(active[q['index']],-int(geo['classes'][q['class']]['components'][arm][axis])*100) for q in qs],0,0)
            lcheck([(key,1),(s,-stride),(y,-150001),(x,-1)],0,0);oracle.append({'index':len(oracle),'group':spec['group'],'family':family,'copy':copy,'x':x,'y':y,'sheet':s,'key':key,'modes':active,'components':comps})
    for group in group_specs:
        rows=[r for r in oracle if r['group']==group['group']]
        for a,b in zip(rows,rows[1:]):lcheck([(a['key'],1),(b['key'],-1)],-2**63,0)
    assert oracle==items and oraclepairs==pairs
    def ccheck(expected):
        nonlocal ci
        assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1
    verified_propagation=verify_propagation(oracle,geo,aux,vcheck,lcheck,ccheck,lambda:ci);assert verified_propagation==propagation and len(propagation)==138
    assert vi==len(actual.variables)==len(vs) and ci==len(actual.constraints);extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');hint_audit=verify_hints(actual,geo,aux,hints,required,specs);assert hint_audit==hint_record;write(OUT/'hint-audit.json',{'passed':True,**hint_audit});extra.ClearField('solution_hint');assert not extra.ListFields();solver=cp_model.CpSolver()
    for n,v in parameters.items():setattr(solver.parameters,n,v)
    assert not solver.parameters.fix_variables_to_their_hinted_value
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**parameters);(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audit_seconds=time.perf_counter()-start;assert audit_seconds<plan['independent_model_audit_limit_seconds'];counts=Counter(block['kind'] for p in pairs for block in p['blocks']);assert counts=={};write(OUT/'model-audit.json',{'passed':True,'construction_seconds':build_seconds,'audit_seconds':audit_seconds,'all_variables_constraints_and_parameters_independently_reconstructed':True,'variables':vi,'constraints':ci,'original_required_parts':len(items),'fixed_parts':0,'modes':sum(len(i['modes']) for i in items),'physical_part_pairs':len(pairs),'component_pairs_by_kind':dict(counts),'explicit_same_part_pair_disjunctions':0,'own_bracket_components_in_global_no_overlap':True,'inner_rectangles':138,'optional_intervals':552,'own_cog_components_in_global_no_overlap':True,'global_no_overlap_2d_constraints':2,'orthogonal_cumulative_constraints':4,'original_area_constraints':2,'copy_order_constraints':56,'ordering_only_within_equal_orientation_option_groups':True,'finite_source_orientation_inventory':True,'hinted_parts':hint_audit['hinted_parts'],'hinted_variables':hint_audit['hinted_variables'],'hints_verified_independently_and_nonbinding':True,'original_mode_aliases_audited':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    records=[]
    def positions(value):
        rows=[]
        for i in items:
            active=[q for q,v in i['modes'].items() if value(vs[v])];assert len(active)==1;rows.append({'family':i['family'],'copy':i['copy'],'x_units':value(vs[i['x']]),'y_units':value(vs[i['y']]),'sheet':value(vs[i['sheet']]),'mode':active[0]})
        assert Counter(r['family'] for r in rows)==Counter(required);return rows
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            rows=positions(self.value);record={'index':len(records),'seconds':self.wall_time,'relaxation_parts':len(rows)};write(OUT/f"incumbent-{len(records)}-positions.json",rows);records.append(record);print(record,flush=True)
    del actual,extra,oracle,oraclepairs;gc.collect();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush());start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
    if feasible:write(OUT/'relaxed-positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'has_full_relaxation_solution':feasible,'incumbents':records,'response_stats':solver.response_stats(),'all_parts_movable':True,'original_cog_shapes_and_angles_unresolved':True,'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False,'interpretation':'This finite orientation inventory is only a construction attempt using inner-rectangle proxies. UNKNOWN is unresolved; any infeasibility applies only to this inventory, not all original orientations. No original cutting layout or acceptance result is created.'};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
