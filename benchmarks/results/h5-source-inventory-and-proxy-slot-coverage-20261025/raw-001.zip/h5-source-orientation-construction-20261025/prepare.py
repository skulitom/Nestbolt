"""Freeze a source-derived finite orientation inventory with all positions free."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from collections import Counter,defaultdict
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-alias-source-hints-20261025';OUT=ROOT/'output/h5-source-orientation-construction-20261025';SOURCE=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json';SRC=ROOT/'output/h5-coordinated-placement-selection-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');plan=load(OLD/'plan.json');inputs=[OLD/n for n in ['plan.json','geometry.json','propagation.json','aliases.json','audit/checks.json','solve/result.json','next-source-orientations/census.json']]+[SOURCE,SRC/'job.json',SRC/'conditional-target.json',ROOT/'output/h5-cog-center-capacity-20261020/disk.json',ROOT/'benchmarks/results/h5-orientation-aliases-and-source-hints-20261025/raw-manifest.json',ROOT/'benchmarks/results/h5-orientation-aliases-and-source-hints-20261025/next-step.json'];plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'hint_source':SOURCE.relative_to(ROOT).as_posix(),'method':'A finite constructive orientation inventory from the checked64-part layout. All18 frames are horizontal; inserts have eight horizontal and thirteen vertical copies; ten brackets retain five recorded orientation/mirror groups; two additional mandatory brackets retain every original orientation/mirror choice. All15 cog centers, every anchor and every allowed sheet assignment remain free. Same five-piece inner cog proxy, original area bounds, stock domains and material target. Copies are ordered only within equal orientation-option groups. All64 source poses are nonbinding hints; neither absent bracket is optional.','scope':'This restricts orientation inventories for a construction attempt, not a necessary relaxation of every original arrangement. UNKNOWN or infeasibility of this finite inventory says nothing about other inventories. One60-second call after complete audits. A positive proxy still requires larger disks, original shapes/cog angles, native guards, production budget and full H5 matrix. No new quality run or acceptance.'});write(OUT/'plan.json',plan);start=time.perf_counter()
    for n in ['geometry.json','propagation.json']:shutil.copyfile(OLD/n,OUT/n)
    g=load(OUT/'geometry.json');aliases=load(OLD/'aliases.json')['aliases'];source=load(SOURCE)['placements'];disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');center=[float(F(*v)) for v in disk['center']];classes=g['classes'];groups=defaultdict(list);stride=150001*300001
    for idx,p in enumerate(source):
        f=p['part_id'];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];mi=-1 if t['mirrored'] else 1;sheet=int(p['sheet_id'][-1])
        if f=='cog':cl=rep=None;xy=[mi*center[0]*c-center[1]*s+tx,mi*center[0]*s+center[1]*c+ty];mode=sheet;allowed=[0,1]
        else:
            k=round(t['rotation_radians']*2/math.pi)%4;cl=next(v for v in classes if v['family']==f and v['quarter_turn']==k and v['mirrored']==t['mirrored']);a=next(v for v in aliases if v['original_class']==cl['index'] and v['sheet']==sheet);rep=a['representative_class'];xy=[tx+cl['original_zero_bounds_min'][0],ty+cl['original_zero_bounds_min'][1]];mode=a['representative_mode'];allowed=[m['index'] for m in g['modes'] if m['family']==f and m['class']==rep]
        x,y=[math.floor(v*100) for v in xy];key=sheet*stride+y*150001+x;groups[(f,rep)].append({'family':f,'source_index':idx,'source_copy':p['copy_index'],'original_class':None if cl is None else cl['index'],'representative_class':rep,'sheet':sheet,'mode':mode,'allowed_modes':allowed,'x_units':x,'y_units':y,'key':key,'eligible':True,'omission_reasons':[]})
    items=[];hints=[];group_rows=[]
    for f in ['frame','bracket','insert','cog']:
        copy=0
        for _,rep in sorted([k for k in groups if k[0]==f],key=lambda k:-1 if k[1] is None else k[1]):
            group=f'{f}-class{rep}';rs=sorted(groups[(f,rep)],key=lambda r:(r['key'],r['source_index']));indices=[]
            for r in rs:
                index=len(items);item={'index':index,'family':f,'copy':copy,'group':group,'allowed_modes':r['allowed_modes'],'fixed_representative_class':rep,'source_index':r['source_index']};items.append(item);hints.append({**r,'copy':copy,'group':group,'item':index});indices.append(index);copy+=1
            group_rows.append({'group':group,'family':f,'allowed_modes':rs[0]['allowed_modes'],'items':indices})
        if f=='bracket':
            allowed=[m['index'] for m in g['modes'] if m['family']=='bracket'];indices=[]
            for _ in range(2):
                index=len(items);items.append({'index':index,'family':f,'copy':copy,'group':'bracket-additional-free','allowed_modes':allowed,'fixed_representative_class':None,'source_index':None});indices.append(index);copy+=1
            group_rows.append({'group':'bracket-additional-free','family':f,'allowed_modes':allowed,'items':indices})
        assert copy==plan['required_counts'][f]
    assert len(items)==66 and len(hints)==64;write(OUT/'items.json',items);write(OUT/'groups.json',group_rows);write(OUT/'hint-poses.json',hints);elapsed=time.perf_counter()-start;assert elapsed<120;write(OUT/'generation.json',{'seconds':elapsed,'mandatory_parts':len(items),'hint_parts':len(hints),'unhinted_mandatory_brackets':2,'orientation_option_groups':len(group_rows),'per_copy_modes':sum(len(i['allowed_modes']) for i in items),'within_group_order_constraints':sum(len(v['items'])-1 for v in group_rows),'positions_fixed':0,'solver_calls':0,'H5_complete':False});print(load(OUT/'generation.json'),flush=True)
if __name__=='__main__':main()
