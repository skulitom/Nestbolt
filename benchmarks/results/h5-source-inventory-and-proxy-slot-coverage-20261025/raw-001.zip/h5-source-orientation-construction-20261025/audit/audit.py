"""Independent finite-inventory, group symmetry and all64 source-hint audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-orientation-construction-20261025';OLD=ROOT/'output/h5-alias-source-hints-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');g=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');items=load(BASE/'items.json');groups=load(BASE/'groups.json');hints=load(BASE/'hint-poses.json');sourcepath=ROOT/plan['hint_source'];source=load(sourcepath)['placements'];jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';job=load(jobpath);parts={p['id']:p for p in job['parts']};disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');aliases=load(OLD/'aliases.json')['aliases'];manifest=ROOT/'benchmarks/results/h5-orientation-aliases-and-source-hints-20261025/raw-manifest.json';mf=load(manifest);files=mf['files']+mf.get('aliases',[]);provenance=[]
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    for p in [OLD/'geometry.json',OLD/'propagation.json',OLD/'aliases.json',OLD/'audit/checks.json',OLD/'solve/result.json',OLD/'next-source-orientations/census.json',sourcepath,jobpath,ROOT/'output/h5-cog-center-capacity-20261020/disk.json']:
        matches=[r for r in files if r['sha256']==digest(p)];assert matches,p;provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':matches[0]['path']})
    assert digest(BASE/'geometry.json')==digest(OLD/'geometry.json') and digest(BASE/'propagation.json')==digest(OLD/'propagation.json');assert load(OLD/'audit/checks.json')['passed'];assert load(OLD/'solve/result.json')['status']=='UNKNOWN';assert Counter(i['family'] for i in items)==Counter(plan['required_counts']);assert len(items)==66 and len(groups)==10 and len(hints)==64 and len(source)==64;assert [i['index'] for i in items]==list(range(66));byitem={r['item']:r for r in hints};assert len(byitem)==64;coverage=[]
    for group in groups:
        rows=[items[i] for i in group['items']];assert rows and all(r['group']==group['group'] and r['family']==group['family'] and r['allowed_modes']==group['allowed_modes'] for r in rows);coverage+=group['items'];keys=[byitem[r['index']]['key'] for r in rows if r['index'] in byitem];assert keys==sorted(keys)
    assert sorted(coverage)==list(range(66));assert len({(r['family'],tuple(r['allowed_modes'])) for r in groups})==10;assert sum(len(r['items'])-1 for r in groups)==56
    for family,n in plan['required_counts'].items():assert sorted(i['copy'] for i in items if i['family']==family)==list(range(n))
    free=[i for i in items if i['source_index'] is None];assert len(free)==2 and all(i['family']=='bracket' and i['group']=='bracket-additional-free' and i['allowed_modes']==[m['index'] for m in g['modes'] if m['family']=='bracket'] for i in free);assert sorted(i['source_index'] for i in items if i['source_index'] is not None)==list(range(64));assert all(i['index'] not in byitem for i in free)
    sourcecounts=Counter(p['part_id'] for p in source);assert sourcecounts=={'frame':18,'bracket':10,'insert':21,'cog':15};inventory=Counter();center=[float(F(*v)) for v in disk['center']];stockbounds=[[float(F(*v)) for v in b] for b in g['stock_bounds_rational']];shapes=[];rectangles=[];areas=[0,0];maxerr=0;matrices=[(1,0,0,1),(0,-1,1,0),(-1,0,0,-1),(0,1,-1,0)]
    for item in items:
        if item['source_index'] is None:continue
        p=source[item['source_index']];f=p['part_id'];t=p['transform'];r=byitem[item['index']];sheet=int(p['sheet_id'][-1]);c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];shape=affine_transform(Polygon(parts[f]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,tx,ty]);shapes.append((sheet,shape));b=shape.bounds;bounds=stockbounds[sheet];assert b[0]>=bounds[0]-1e-7 and b[1]>=bounds[1]-1e-7 and b[2]<=bounds[2]+1e-7 and b[3]<=bounds[3]+1e-7
        if f=='cog':
            assert not t['mirrored'];xy=[tx+c*center[0]-s*center[1],ty+s*center[0]+c*center[1]];assert item['fixed_representative_class'] is None and item['allowed_modes']==[0,1];mode=sheet;rep=None;original_class=None;boxrange=g['cog_center_bounds'][sheet];offsets=aux['cog_inner_components']
        else:
            k=round(t['rotation_radians']*2/math.pi)%4;assert abs(math.remainder(t['rotation_radians']-k*math.pi/2,2*math.pi))<1e-12 and (not t['mirrored'] or parts[f]['allow_mirror']);cl=next(o for o in g['classes'] if o['family']==f and o['quarter_turn']==k and o['mirrored']==t['mirrored']);a=next(a for a in aliases if a['original_class']==cl['index'] and a['sheet']==sheet);rep=a['representative_class'];original_class=cl['index'];assert rep==item['fixed_representative_class'];allowed=[m['index'] for m in g['modes'] if m['family']==f and m['class']==rep];assert item['allowed_modes']==allowed;mode=a['representative_mode'];boxrange=next(m['coordinate_bounds'] for m in g['modes'] if m['index']==mode);aa,bb,dd,ee=matrices[k];pts=[(aa*mi*x+bb*y,dd*mi*x+ee*y) for x,y in parts[f]['geometry'][0]['outer']];xy=[tx+min(x for x,y in pts),ty+min(y for x,y in pts)];maxerr=max(maxerr,shape.hausdorff_distance(Polygon([(x+tx,y+ty) for x,y in pts])));offsets=aux['inner_non_cog_components'][rep]['components'];inventory[(f,g['classes'][rep]['quarter_turn'],g['classes'][rep]['mirrored'])]+=1
        x,y=map(lambda z:math.floor(z*100),xy);assert boxrange[0]<=x<=boxrange[2] and boxrange[1]<=y<=boxrange[3];expected={'family':f,'source_index':item['source_index'],'source_copy':p['copy_index'],'original_class':original_class,'representative_class':rep,'sheet':sheet,'mode':mode,'allowed_modes':item['allowed_modes'],'x_units':x,'y_units':y,'key':sheet*150001*300001+y*150001+x,'eligible':True,'omission_reasons':[],'copy':item['copy'],'group':item['group'],'item':item['index']};assert r==expected;areas[sheet]+=aux['part_areas'][f]['lower_units']
        for arm,o in enumerate(offsets):rectangles.append({'item':item['index'],'sheet':sheet,'arm':arm,'bounds':[x+o[0],y+o[1],x+o[2],y+o[3]]})
    expected_inventory={(r['family'],r['normalized_quarter_turn'],r['mirrored']):r['quantity'] for r in load(OLD/'next-source-orientations/census.json')['normalized_orientation_inventory']};assert dict(inventory)==expected_inventory and maxerr<1e-9;original_pairs=proxy_pairs=0;minimum=float('inf')
    for (sa,a),(sb,b) in combinations(shapes,2):
        if sa!=sb:continue
        d=a.distance(b);assert d>=job['clearance']-1e-7;minimum=min(minimum,d);original_pairs+=1
    for a,b in combinations(rectangles,2):
        if a['sheet']!=b['sheet']:continue
        x,y=a['bounds'],b['bounds'];assert x[2]<=y[0] or y[2]<=x[0] or x[3]<=y[1] or y[3]<=x[1];proxy_pairs+=1
    profiles=[]
    for sheet in [0,1]:
        assert areas[sheet]<=aux['sheet_capacities'][sheet]['upper_area_units']
        for axis in [0,1]:
            events=defaultdict(int)
            for row in rectangles:
                if row['sheet']!=sheet:continue
                r=row['bounds'];d=r[3-axis]-r[1-axis];events[r[axis]]+=d;events[r[axis+2]]-=d
            current=peak=0
            for z in sorted(events):current+=events[z];assert current>=0;peak=max(peak,current)
            assert not current;cap=aux['sheet_capacities'][sheet]['height_upper_coordinate_units' if axis==0 else 'width_upper_coordinate_units'];assert peak<=cap;profiles.append({'sheet':sheet,'axis':axis,'peak':peak,'capacity':cap})
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance});write(OUT/'source-inner-rectangles.json',rectangles);write(OUT/'profiles.json',profiles);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'committed_input_matches':len(provenance),'mandatory_parts':66,'source_hint_parts':64,'unhinted_mandatory_brackets':2,'orientation_groups':10,'within_equal_group_orders':56,'per_copy_modes':sum(len(i['allowed_modes']) for i in items),'source_original_polygon_pairs':original_pairs,'source_minimum_gap_mm':minimum,'source_proxy_component_pairs':proxy_pairs,'source_hint_inner_rectangles':len(rectangles),'maximum_quarter_turn_error_mm':maxerr,'partial_source_area_units':areas,'complete_profiles_checked':4,'all_positions_and_sheets_unfixed':True,'finite_orientation_inventory_not_unrestricted_relaxation':True,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
