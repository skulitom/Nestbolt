"""Freeze a distinct runner and candidate reader for the audited model-v3 bytes."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];assert json.loads((ROOT/'output/h5-source-projection-short-core-20261029/model-audit/checks.json').read_bytes())['passed']
for old,new in [('run_h5_source_pair_short_core_20261029.py','run_h5_source_projection_short_core_20261029.py'),('check_h5_source_pair_short_core_candidate_20261029.py','check_h5_source_projection_short_core_candidate_20261029.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace("output/h5-source-pair-short-core-20261029'","output/h5-source-projection-short-core-20261029'").replace('h5_source_pair_short_core_reader_20261029','h5_source_projection_short_core_reader_20261029').replace('check_h5_source_pair_short_core_candidate_20261029','check_h5_source_projection_short_core_candidate_20261029').replace("MODEL=BASE/'model'","MODEL=BASE/'model-v3'").replace("BASE/'model/","BASE/'model-v3/").replace("ROOT/'output/h5-strip-capacity-short-core-20261029/cog-source-separation/audit'","BASE/'preflight-v2/audit'")
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Distinct runner and candidate reader prepared; no call opened yet.')
