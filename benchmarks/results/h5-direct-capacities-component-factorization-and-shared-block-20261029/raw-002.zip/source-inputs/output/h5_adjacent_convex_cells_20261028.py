"""Conservative cells with deterministic shared-edge convex merging."""
from fractions import Fraction as F
from collections import defaultdict
from heapq import heappush,heappop
import shapely
from shapely.geometry import mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from h5_source_convex_cells_20261028 import selected_cell
def vertices(g):return list(g.exterior.coords)[:-1]
def edges(g):
    vv=vertices(g);return [tuple(sorted((a,b))) for a,b in zip(vv,vv[1:]+vv[:1])]
def exact_convex(g):
    vv=[tuple(F(str(v)) for v in p) for p in vertices(orient(g,sign=1))]
    return all((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>=0 for a,b in zip(vv,vv[1:]+vv[:1]) for p in vv)
def encode(region):
    triangles=list(shapely.constrained_delaunay_triangles(region).geoms);assert triangles and unary_union(triangles).equals(region);live={};owners=defaultdict(set);queue=[];nextid=0;merges=0
    def add(g):
        nonlocal nextid
        i=nextid;nextid+=1;live[i]=g
        for e in edges(g):
            for other in owners[e]:heappush(queue,tuple(sorted((i,other))))
            owners[e].add(i)
    def remove(i):
        for e in edges(live[i]):owners[e].remove(i)
        del live[i]
    for g in triangles:add(g)
    while queue:
        i,j=heappop(queue)
        if i not in live or j not in live:continue
        g=live[i].union(live[j])
        if g.geom_type!='Polygon' or g.interiors or not g.equals(g.convex_hull) or not exact_convex(g):continue
        remove(i);remove(j);add(g);merges+=1
    pieces=[live[i] for i in sorted(live)];assert unary_union(pieces).equals(region);cells=[]
    for p in pieces:
        p=orient(p,sign=1);assert p.equals(p.convex_hull) and exact_convex(p);vv=vertices(p);planes=[]
        for u,v in zip(vv,vv[1:]+vv[:1]):
            px,py=map(lambda x:F(str(x)),u);qx,qy=map(lambda x:F(str(x)),v);nx,ny=py-qy,qx-px;scale=max(abs(nx),abs(ny));nx/=scale;ny/=scale;aa=round(nx*10**9);bb=round(ny*10**9);error=abs(F(aa)-nx*10**9)*1600000+abs(F(bb)-ny*10**9)*3100000;value=(nx*px+ny*py)*10**12+error;cc=-((-value.numerator)//value.denominator)+1;planes.append([aa,bb,cc])
        cells.append({'geometry':mapping(p),'halfplanes':planes})
    return {'cells':cells,'domain_geometry':mapping(region),'partition':{'method':'deterministic shared-edge convex merging with exact rational convexity checks','initial_triangles':len(triangles),'accepted_merges':merges,'convex_pieces':len(pieces)}}
