"""Fresh fixed-ten free regions for the adjacent-bracket, three-mover construction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_vector_source_minkowski_20261028 import triangles,obstacle
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';INV=ROOT/'output/h5-short-fixed10-inventory-20261028';OUT=ROOT/'output/h5-short-adjacent-exchange-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';MODE_SOURCE=ROOT/'output/h5-short-cog-transfer-20261028/modes.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for c in getattr(g,'geoms',[]) for p in polygons(c)]
def prepare():
    OUT.mkdir();(OUT/'new-obstacles').mkdir();(OUT/'free').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(INV/'audit/checks.json')['passed'] and load(OLD/'preflight-v2/checks.json')['passed']
    inputs=[Path(__file__),ROOT/'output/h5_vector_source_minkowski_20261028.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,MODE_SOURCE,INV/'audit/plan.json',INV/'audit/checks.json',INV/'cases/38.json',INV/'inventory-variants.json',INV/'case-summary.json',OLD/'plan.json',OLD/'preflight-v2/plan.json',OLD/'preflight-v2/checks.json',OLD/'modes.json',OLD/'fixed-types.json',OLD/'obstacle-index.json']+sorted((OLD/'obstacles').glob('*.json'))
    sourceplan=load(OLD/'plan.json');plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_stock':sourceplan['source_stock'],'required_pair_gap_mm':sourceplan['required_pair_gap_mm'],'stock_guard_mm':sourceplan['stock_guard_mm'],'new_moving_stock_extra_mm':sourceplan['new_moving_stock_extra_mm'],'construction_obstacle_radius_mm':sourceplan['construction_obstacle_radius_mm'],'independent_required_obstacle_radius_mm':sourceplan['independent_required_obstacle_radius_mm'],'geometry_preparation_seconds':120,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'maximum_joint_cog_bracket_anchors':10000,'retry_permitted':False,'selected_geometry_case':'38','inventory_variants':[48,59],
        'method':'Keep the ten unchanged original poses after releasing adjacent brackets 10 and 11. First try inventory 48: add cog 0, bracket 11 and insert 0; bracket 10 belongs to the mandatory first-sheet complement. Inventory 59 is the geometry-identical copy swap and receives no separate search. Reuse only hash-verified original-type obstacles whose source poses/modes are unchanged; build all missing bracket obstacles from original filled polygons. Recompute every fixed-ten free region. After an independent complete geometry audit, enumerate cog modes 0..35, then sorted representative points and ring vertices of each free region. For each cog pose enumerate bracket modes 36..43 and the same ordered points of its residual region. Subtract both posed moving obstacles from insert modes 44,45, testing each component representative by descending area then coordinates. Stop at first source-valid13, 10000 joint anchors or60 algorithm seconds within90 shared. Validate all13 original rings and reconcile all66 identities for both equivalent inventory variants. No all-angle or original infeasibility follows from failure.'}
    write(OUT/'plan.json',plan)
    def budget():assert time.perf_counter()-start<120,'geometry preparation budget exhausted'
    job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(MODE_SOURCE);assert len(modes)==46 and [m['index'] for m in modes]==list(range(46));assert [m for m in modes if m['family']!='bracket']==load(OLD/'modes.json');write(OUT/'modes.json',modes)
    fixed=load(OLD/'fixed-types.json');write(OUT/'fixed-types.json',fixed)
    def source(family,a,mir,offset=(0.,0.)):
        c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1
        return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in parts[family]['geometry'][0]['outer']])
    ft={f['id']:triangles(source(f['family'],f['angle'],f['mirrored'])) for f in fixed};mg={};mt={}
    for m in modes:
        g=source(m['family'],m['angle'],m['mirrored'],m['source_translation_offset']);assert g.equals_exact(shape(m['geometry']),1e-10);mg[m['index']]=g;mt[m['index']]=triangles(g)
    obs={};records=[];newhulls=0
    for r in load(OLD/'obstacle-index.json'):
        if r['kind']=='fixed-moving':kind,a,b='fixed-moving',r['fixed_type'],r['moving_mode']
        else:kind,a,b='cog-insert',r['cog_mode'],r['insert_mode']
        path=OLD/'obstacles'/r['file'];obs[kind,a,b]=shape(load(path)['geometry']);records.append({'kind':kind,'left':a,'right':b,'source_path':path.relative_to(ROOT).as_posix(),'sha256':digest(path),'reused_source_audit':True,'hulls':r['hulls']})
    missing=[('fixed-moving',f['id'],b,ft[f['id']],mt[b]) for f in fixed for b in range(36,44)]+[('cog-bracket',a,b,mt[a],mt[b]) for a in range(36) for b in range(36,44)]+[('bracket-insert',a,b,mt[a],mt[b]) for a in range(36,44) for b in [44,45]]
    for kind,a,b,left,right in missing:
        budget();g,n=obstacle(left,right,plan['construction_obstacle_radius_mm']);path=OUT/'new-obstacles'/f'{kind}-{a:02d}-{b:02d}.json';write(path,{'kind':kind,'left':a,'right':b,'hulls':n,'geometry':mapping(g)});obs[kind,a,b]=g;newhulls+=n;records.append({'kind':kind,'left':a,'right':b,'source_path':path.relative_to(ROOT).as_posix(),'sha256':digest(path),'reused_source_audit':False,'hulls':n})
    write(OUT/'obstacle-index.json',records)
    case=load(INV/'cases/38.json');types={(f['family'],f['angle'],f['mirrored']):f['id'] for f in fixed};refs=[]
    for r in case['fixed10']:
        t=r['transform'];refs.append({'identity':[r['part_id'],r['copy_index']],'fixed_type':types[r['part_id'],t['rotation_radians'],t['mirrored']],'translation':t['translation']})
    case['fixed_references']=refs;write(OUT/'case.json',case);v=load(INV/'inventory-variants.json');write(OUT/'selected-inventories.json',[v[i] for i in [48,59]])
    counts={'cog':0,'bracket':0,'insert':0};samples=[];stock=plan['source_stock'];extra=plan['new_moving_stock_extra_mm']
    for mi,m in enumerate(modes):
        budget();a,b,c,d=mg[mi].bounds;bounds=[stock[0]+extra-a,stock[1]+extra-b,stock[2]-extra-c,stock[3]-extra-d];free=box(*bounds).difference(unary_union([translate(obs['fixed-moving',r['fixed_type'],mi],*r['translation']) for r in refs]));assert free.is_valid;write(OUT/'free'/f'{mi:02d}.json',{'mode':mi,'anchor_stock_bounds_mm':bounds,'geometry':mapping(free)});counts[m['family']]+=int(not free.is_empty)
        for region in polygons(free):
            xy=list(region.representative_point().coords[0]);copy={'cog':0,'bracket':11,'insert':0}[m['family']];moving={'part_id':m['family'],'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in [0,1]]}};read=audit(job,case['fixed10']+[moving],{'sheet-1':stock},plan['required_pair_gap_mm'],plan['stock_guard_mm']);assert read['valid'];samples.append({'mode':mi,'anchor':xy,'source_originals':11,'minimum_pair_gap_mm':read['minimum_pair_gap_mm'],'minimum_extra_stock_mm':read['minimum_extra_stock_mm']})
    write(OUT/'source-samples.json',samples);budget();write(OUT/'prepared.json',{'passed':True,'closed':True,'seconds':time.perf_counter()-start,'fixed10_source_originals':10,'inventory_variants':2,'source_modes':46,'reused_verified_obstacles':262,'new_source_obstacles':len(missing),'new_convex_minkowski_hulls':newhulls,'total_obstacles':len(records),'fixed10_free_domains':46,'nonempty_free_domains':counts,'source_representative_controls':len(samples),'independent_audit_pending':True,'construction_opened':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'),flush=True)
if __name__=='__main__':
    try:prepare()
    except Exception as e:
        if OUT.exists():write(OUT/'preparation-failure.json',{'closed':True,'exception_type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'retry_permitted':False})
        raise
