"""Append only observed owner/mode collision cases; inactive modes remain unconstrained."""
from h5_lazy_cp_builder_20261028 import linear
def add_cases(model,mapping,cases,relative):
    existing={(p['left'],p['right'],g['left_mode'],g['right_mode']) for p in mapping['pairs'] for g in p['groups']};added=[]
    for li,ri,a,b in sorted(set(tuple(v) for v in cases)):
        assert li<ri and (li,ri,a,b) not in existing;left,right=mapping['items'][li],mapping['items'][ri]
        oa=next(o for o in left['options'] if o['mode']==a);ob=next(o for o in right['options'] if o['mode']==b);sign=1 if a<=b else -1;domains=relative[min(a,b),max(a,b)]
        x1,y1=[model.get_int_var_from_proto_index(left[k]) for k in ['x','y']];x2,y2=[model.get_int_var_from_proto_index(right[k]) for k in ['x','y']]
        ss=[model.new_bool_var(f'pair_{li}_{ri}_{a}_{b}_{k}') for k in range(len(domains))];va=model.get_int_var_from_proto_index(oa['selector']);vb=model.get_int_var_from_proto_index(ob['selector'])
        choices=[linear(model,sum(ss)-va,hi=0),linear(model,sum(ss)-vb,hi=0),linear(model,sum(ss)-va-vb,lo=-1)]
        planes=[[linear(model,sign*(aa*(x2-x1)+bb*(y2-y1)),lo=cc,on=sv) for aa,bb,cc in cell['halfplanes']] for cell,sv in zip(domains,ss)]
        group={'left_mode':a,'right_mode':b,'cells':[v.index for v in ss],'choice_constraints':choices,'plane_constraints':planes}
        pair=next((p for p in mapping['pairs'] if (p['left'],p['right'])==(li,ri)),None)
        if pair is None:pair={'left':li,'right':ri,'groups':[]};mapping['pairs'].append(pair)
        pair['groups'].append(group);existing.add((li,ri,a,b));added.append([li,ri,a,b])
    assert model.validate()==''
    return added
