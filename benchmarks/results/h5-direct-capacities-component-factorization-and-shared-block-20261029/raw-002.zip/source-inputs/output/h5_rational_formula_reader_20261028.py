"""Independent minimal SMT parser, source-field reader and exact Fraction evaluator."""
from fractions import Fraction as F
from itertools import combinations
import re
def parse(text):
    tokens=re.findall(r'\(|\)|[^\s()]+',text);assert ''.join(tokens)==re.sub(r'\s+','',text);stack=[];roots=[]
    for token in tokens:
        if token=='(':
            node=[]
            if stack:stack[-1].append(node)
            else:roots.append(node)
            stack.append(node)
        elif token==')':assert stack;stack.pop()
        else:assert stack;stack[-1].append(token)
    assert not stack;return roots
def evaluate(node,values):
    if isinstance(node,str):
        if node in values:return values[node]
        return F(node)
    op,*args=node;v=[evaluate(a,values) for a in args]
    if op=='and':assert all(isinstance(x,bool) for x in v);return all(v)
    if op=='or':assert all(isinstance(x,bool) for x in v);return any(v)
    if op=='not':assert len(v)==1 and isinstance(v[0],bool);return not v[0]
    if op=='=>':assert len(v)==2 and all(isinstance(x,bool) for x in v);return not v[0] or v[1]
    if op=='=':assert len(v)==2 and type(v[0])==type(v[1]);return v[0]==v[1]
    assert all(isinstance(x,F) for x in v)
    if op=='>=':assert len(v)==2;return v[0]>=v[1]
    if op=='<=':assert len(v)==2;return v[0]<=v[1]
    if op=='+':return sum(v,F(0))
    if op=='-':assert len(v)==1;return -v[0]
    if op=='*':assert len(v)==2;return v[0]*v[1]
    raise AssertionError(op)
def linear(node):
    if isinstance(node,str):
        if re.fullmatch(r'[0-9]+',node):return {},F(node)
        assert re.fullmatch(r'[xy]_[0-9]+',node);return {node:F(1)},F(0)
    op,*args=node
    if op=='-':assert len(args)==1;d,c=linear(args[0]);return {k:-v for k,v in d.items()},-c
    if op=='+':
        terms={};constant=F(0)
        for a in args:
            d,c=linear(a);constant+=c
            for k,v in d.items():terms[k]=terms.get(k,F(0))+v
        return {k:v for k,v in terms.items() if v},constant
    if op=='*':
        assert len(args)==2;a,c=linear(args[0]);b,d=linear(args[1]);assert not a or not b
        return ({k:v*d for k,v in a.items()},c*d) if a else ({k:v*c for k,v in b.items()},c*d)
    raise AssertionError(op)
def inspect(text,mp,remaining,modes,free,relative,cases,control):
    forms=parse(text);assert forms[0]==['set-logic','QF_LRA'];decls={};assertions=[];asserts_started=False
    for form in forms[1:]:
        if form[0]=='declare-fun':
            assert not asserts_started and len(form)==4 and form[2]==[] and form[3] in ['Bool','Real'] and form[1] not in decls;decls[form[1]]=form[3]
        else:assert form[0]=='assert' and len(form)==2;asserts_started=True;assertions.append(form[1])
    used=set();variables={};values={}
    def claim(i):assert i not in used and 0<=i<len(assertions);used.add(i);return assertions[i]
    def var(name,sort):assert name not in variables;variables[name]=sort
    def halfplane(tree,terms,c):
        assert len(tree)==3 and tree[0]=='>=';d,offset=linear(tree[1]);rhs,constant=linear(tree[2]);assert not rhs and d=={k:F(v) for k,v in terms.items() if v} and offset==0 and constant==c
    assert len(mp['items'])==len(remaining)==25
    for i,(item,r) in enumerate(zip(mp['items'],remaining)):
        assert (item['index'],item['family'],item['copy_index'])==(i,r['family'],r['copy_index']);p,x,y=item['presence'],item['x'],item['y'];assert (p,x,y)==(f'present_{i}',f'x_{i}',f'y_{i}');var(p,'Bool');var(x,'Real');var(y,'Real');assert claim(item['mandatory_assertion'])==p
        assert claim(item['bounds_assertion'])==['and',['>=',x,'0'],['<=',x,'1500000'],['>=',y,'0'],['<=',y,'3000000']]
        known=next((v for v in control if (v['family'],v['copy_index'])==(r['family'],r['copy_index'])),None);values[p]=known is not None;values[x],values[y]=map(F,known['anchor_um'] if known else [0,0])
        assert [o['mode'] for o in item['options']]==[m['index'] for m in modes if m['family']==r['family']]
        for o in item['options']:
            mi,s=o['mode'],o['selector'];assert s==f'mode_{i}_{mi}';var(s,'Bool');values[s]=known is not None and known['mode']==mi;tree=claim(o['free_assertion']);assert tree[:2]==['=>',s] and len(tree)==3 and tree[2][0]=='or' and len(tree[2])-1==len(free[mi])
            for cell,domain in zip(tree[2][1:],free[mi]):
                assert cell[0]=='and' and len(cell)-1==len(domain['halfplanes'])
                for plane,(a,b,c) in zip(cell[1:],domain['halfplanes']):halfplane(plane,{x:a,y:b},c)
        assert claim(item['mode_choice_assertion'])==['=',p,['or',*[o['selector'] for o in item['options']]]]
        pairs=list(combinations(item['options'],2));assert len(pairs)==len(item['exclusive'])
        for row,(a,b) in zip(item['exclusive'],pairs):assert row['modes']==[a['mode'],b['mode']] and claim(row['assertion'])==['not',['and',a['selector'],b['selector']]]
    orders=[(a,b) for f in ['bracket','cog','insert'] for group in [[it for it in mp['items'] if it['family']==f]] for a,b in zip(group,group[1:])];assert len(orders)==len(mp['orders'])==22
    for row,(a,b) in zip(mp['orders'],orders):assert [row['left'],row['right']]==[a['index'],b['index']] and claim(row['assertion'])==['<=',a['x'],b['x']]
    assert len(mp['cases'])==len(cases)==len(set(map(tuple,cases)))
    for row,(li,ri,a,b) in zip(mp['cases'],cases):
        assert [row['left'],row['right'],row['left_mode'],row['right_mode']]==[li,ri,a,b] and li<ri;left,right=mp['items'][li],mp['items'][ri];oa=next(o for o in left['options'] if o['mode']==a);ob=next(o for o in right['options'] if o['mode']==b);sign=1 if a<=b else -1;domains=relative[min(a,b),max(a,b)];tree=claim(row['assertion']);assert tree[:2]==['=>',['and',oa['selector'],ob['selector']]] and len(tree)==3 and tree[2][0]=='or' and len(tree[2])-1==len(domains)
        for cell,domain in zip(tree[2][1:],domains):
            assert cell[0]=='and' and len(cell)-1==len(domain['halfplanes'])
            for plane,(aa,bb,cc) in zip(cell[1:],domain['halfplanes']):halfplane(plane,{right['x']:sign*aa,left['x']:-sign*aa,right['y']:sign*bb,left['y']:-sign*bb},cc)
    assert used==set(range(len(assertions))) and variables==decls and set(values)==set(decls)
    failed=[i for i,a in enumerate(assertions) if not evaluate(a,values)];disabled=[it['mandatory_assertion'] for it in mp['items'] if it['family']!='cog'];assert sorted(failed)==sorted(disabled) and len(disabled)==10
    partial=list(assertions)
    for i in disabled:partial[i]=['not',partial[i]]
    assert all(evaluate(a,values) for a in partial)
    return {'passed':True,'real_coordinates':sum(v=='Real' for v in decls.values()),'boolean_variables':sum(v=='Bool' for v in decls.values()),'assertions_verified':len(assertions),'mandatory_originals':25,'target_originals':66,'mode_cases':len(cases),'all_formula_fields_verified':True,'partial_control_fails_exactly10_mandatory_assertions':True,'partial56_control_passes_after_only10_presence_negations':True},assertions,values,decls
