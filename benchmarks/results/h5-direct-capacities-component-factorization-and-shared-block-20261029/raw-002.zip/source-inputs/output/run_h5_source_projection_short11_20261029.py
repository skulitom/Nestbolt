"""One declared 60/90-second global short11 necessary-model call."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';MODEL=BASE/'model';OUT=BASE/'search';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child(started):
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    from h5_source_projection_short_core_reader_20261029 import violations
    ma=load(BASE/'model-audit/checks.json');assert ma['passed'] and load(PRE/'audit/checks.json')['passed']
    for folder in [BASE,MODEL,BASE/'model-audit',ROOT/'output/h5-source-projection-short-core-20261029/preflight-v2/audit',PRE/'audit']:
        for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    model=cp_model.CpModel();assert model.proto.parse_text_format((MODEL/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and digest(OUT/'model.pb')==ma['model_sha256']
    remaining=60-(time.perf_counter()-started)-3;assert remaining>0;solver=cp_model.CpSolver();params={'max_time_in_seconds':remaining,'num_search_workers':4,'random_seed':0,'log_search_progress':True,'log_to_stdout':False,'ignore_subsolvers':['fj']}
    for k,v in params.items():
        if isinstance(v,list):getattr(solver.parameters,k).extend(v)
        else:setattr(solver.parameters,k,v)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');inputs=[Path(__file__),ROOT/'output/h5_source_projection_short_core_reader_20261029.py',ROOT/'output/check_h5_source_projection_short11_candidate_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',BASE/'plan.json',MODEL/'plan.json',MODEL/'model.pb',MODEL/'mapping.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',PRE/'audit/plan.json',PRE/'audit/checks.json']
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'model_sha256':ma['model_sha256'],'maximum_calls':1,'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':3,'parameters':params,'candidate_phase_order_degrees':[7.0]+[k/2 for k in range(36) if k!=14],'candidate_maximum_phase_pairs':1296,'candidate_validation_stops_at_algorithm_deadline':True,'retry_permitted':False})
    class Capture(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.count=0
        def on_solution_callback(self):
            write(OUT/'incumbents'/f'{self.count:03d}.json',{'sequence':self.count,'solver_wall_seconds':self.wall_time,'values':[self.value(model.get_int_var_from_proto_index(i)) for i in range(len(model.proto.variables))]});self.count+=1
    capture=Capture()
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());begin=time.perf_counter();status=solver.solve(model,capture);elapsed=time.perf_counter()-begin
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString());source_valid=False
    if response.solution:
        values=list(response.solution);write(OUT/'assignment.json',values);p=cp_model_pb2.CpModelProto();p.ParseFromString((OUT/'model.pb').read_bytes());checked=violations(p,values);assert not checked['failed_constraints'];write(OUT/'assignment-check.json',checked)
        child_result=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(ROOT/'output/check_h5_source_projection_short11_candidate_20261029.py'),str(started)],cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-started)));(OUT/'source-check-stdout.txt').write_bytes(child_result.stdout);(OUT/'source-check-stderr.txt').write_bytes(child_result.stderr);assert child_result.returncode==0,child_result.stderr.decode(errors='replace');source_valid=load(OUT/'source-response/checks.json')['source_valid11']
    algorithm=time.perf_counter()-started;write(OUT/'result.json',{'status':solver.status_name(status),'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'allocated_solve_seconds':remaining,'returned_response_branches':response.num_branches,'returned_response_conflicts':response.num_conflicts,'has_solution':bool(response.solution),'incumbents_recorded':capture.count,'returned_solve_soft_overrun_seconds':max(0.,elapsed-remaining),'algorithm_seconds':algorithm,'algorithm_soft_overrun_seconds':max(0.,algorithm-60),'solver_calls':1,'closed':True,'source_short11_verified':source_valid,'source_full66_verified':False,'original_source_feasibility_excluded':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();(OUT/'incumbents').mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'algorithm_includes_process_startup_input_checks_solve_and_candidate_source_readback':True,'source_validation_reserve_seconds':3})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child',str(start)],cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-start)));(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False,'closed':True}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-start,'timeout':True,'closed':True}
    write(OUT/'process.json',process);print(process,flush=True);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final response; call remains closed.',flush=True)
if __name__=='__main__':child(float(sys.argv[2])) if '--child' in sys.argv else main()
