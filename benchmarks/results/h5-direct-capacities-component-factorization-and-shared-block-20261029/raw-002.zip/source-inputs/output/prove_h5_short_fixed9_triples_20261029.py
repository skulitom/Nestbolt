"""Necessary triple-core predicates for the five surviving fixed-nine geometries."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product,combinations
from collections import Counter
import json,shutil,time
from prove_h5_short_exchange_all_angle_20261028 import hull
from h5_multiple_core_coverage_20261029 import certificate
ROOT=Path(__file__).resolve().parents[1];INV=ROOT/'output/h5-short-fixed9-inventory-20261029';PAIR=ROOT/'output/h5-short-fixed9-joint-20261029';PRE=ROOT/'output/h5-short-joint-core-20261028';BOUND=ROOT/'output/h5-short-two-cog-exchange-20261028/all-angle-bound';OUT=ROOT/'output/h5-short-fixed9-triples-20261029';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def corners(r):return [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]
OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter();assert load(PAIR/'audit/checks.json')['passed']
survivors=[s for s in load(PAIR/'geometry-summary.json') if not s['geometry_excluded']];assert [s['geometry_case'] for s in survivors]==['027','072','108','136','164'];specs=[]
for s in survivors:
    gi=s['geometry_case'];counts=Counter(k[0] for k in s['removed_parent_identities'])
    if counts['cog']:
        assert counts['bracket']==2;specs.extend((gi,[None,None,mi]) for mi in s['unexcluded_pair_modes'] if mi is not None)
    else:
        assert counts['bracket']==3;specs.extend((gi,[None,a,b]) for a,b in product(s['unexcluded_pair_modes'],repeat=2))
assert len(specs)==15
inputs=[Path(__file__),ROOT/'output/prove_h5_short_exchange_all_angle_20261028.py',ROOT/'output/h5_multiple_core_coverage_20261029.py',INV/'audit/plan.json',INV/'audit/checks.json',INV/'inventory-variants.json',PAIR/'audit/plan.json',PAIR/'audit/checks.json',PAIR/'geometry-summary.json',PAIR/'case-summary.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'stock-hull-core.json',PRE/'bracket-cores.json',BOUND/'moving-core.json',BOUND/'fixed-core-rectangles.json']+[INV/'cases'/f"{s['geometry_case']}.json" for s in survivors]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each surviving fixed-nine geometry, require three moving cores simultaneously: cog/bracket/bracket after three parent brackets were released, or cog/cog/bracket after two brackets and the existing cog were released. Include every remaining bracket mode, including depth-limited pair cases, and every ordered bracket-mode pair; modes removed by complete audited pair proofs cannot occur in a valid triple. Include fixed-obstacle predicates and all three moving-pair predicates. Every cog angle stays arbitrary. Source-stock and source-contained core prerequisites are unchanged. A triple witness is only a necessary relaxation, not a source placement.','cases':15,'max_nodes_per_case':100000,'max_depth':60,'shared_proof_wall_seconds':120,'retry_permitted':False,'construction_calls':0,'solver_calls':0,'native_calls':0})
core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};cb=load(PRE/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];bc={r['mode']:r for r in load(PRE/'bracket-cores.json')};summaries=[]
for gi,mi in specs:
    name=gi+'-'+'-'.join('cg' if i is None else str(i) for i in mi);case=load(INV/'cases'/f'{gi}.json');rr=[r for p in case['fixed9'] for r in fixed[key(p)]];pieces=[[core] if i is None else [corners(r) for r in bc[i]['rectangles_um']] for i in mi];bb=[cb if i is None else bc[i]['relaxed_anchor_bounds_um'] for i in mi];bounds=[v for b in bb for v in b[:2]]+[v for b in bb for v in b[2:]];obs=[]
    for i,pp in enumerate(pieces):
        for r in rr:
            for p in pp:obs.append({'first':i,'second':None,'vertices_um':hull([(x-u,y-v) for x,y in corners(r) for u,v in p])})
    for i,j in combinations(range(3),2):
        for p in pieces[i]:
            for q in pieces[j]:obs.append({'first':i,'second':j,'vertices_um':hull([(x-u,y-v) for x,y in p for u,v in q])})
    write(OUT/'cases'/f'{name}-inputs.json',{'geometry_case':gi,'moving_modes':mi,'bounds_um':bounds,'obstacles':obs});cert=certificate(bounds,obs,100000,60,start+120);write(OUT/'cases'/f'{name}-certificate.json',cert);r={'case':name,'geometry_case':gi,'moving_modes':mi,'covered':cert['covered'],'nodes':len(cert['nodes']),'relaxation_witness_um':cert['relaxation_witness_um'],'limit':cert['limit']};summaries.append(r);print(r,flush=True)
geometry=[]
for s in survivors:
    cases=[r for r in summaries if r['geometry_case']==s['geometry_case']];geometry.append({'geometry_case':s['geometry_case'],'removed_parent_identities':s['removed_parent_identities'],'inventory_variants':s['inventory_variants'],'triple_cases':len(cases),'excluded':all(r['covered'] for r in cases),'unexcluded_triple_cases':[r['case'] for r in cases if not r['covered']]})
write(OUT/'case-summary.json',summaries);write(OUT/'geometry-summary.json',geometry);write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-start,'triple_cases':15,'covered_triple_cases':sum(r['covered'] for r in summaries),'witness_cases':sum(r['relaxation_witness_um'] is not None for r in summaries),'limited_cases':sum(r['limit'] is not None for r in summaries),'additional_excluded_geometries':sum(g['excluded'] for g in geometry),'remaining_unexcluded_geometries':sum(not g['excluded'] for g in geometry),'remaining_unexcluded_identity_variants':sum(len(g['inventory_variants']) for g in geometry if not g['excluded']),'independent_audit_pending':True,'source_valid13':False,'source_valid66':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'full_allocation_or_original_job_excluded':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
