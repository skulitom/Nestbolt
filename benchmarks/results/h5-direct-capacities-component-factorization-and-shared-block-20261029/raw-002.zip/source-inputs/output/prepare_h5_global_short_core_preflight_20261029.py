"""Freeze a new all-movable short13 necessary model with exact source-core controls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import combinations
from math import gcd
import json,math,shutil,time
from shapely.geometry import Polygon,box
from prove_h5_short_exchange_all_angle_20261028 import hull
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-short-fixed9-triples-20261029';OUT=PARENT/'global-short-preflight';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';JOINT=ROOT/'output/h5-short-joint-core-20261028';PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda r:(r['part_id'],r['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(points,a,mir,offset=(0.,0.)):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1
    return [(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in points]
def parity(p,vv):
    inside=False
    for a,b in zip(vv,vv[1:]+vv[:1]):
        if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<a[0]+(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1]):inside=not inside
    return inside
def hit(a,b,r):
    lo,hi=F(0),F(1)
    for k in [0,1]:
        d=b[k]-a[k]
        if d==0:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            u,v=sorted(((r[k]-a[k])/d,(r[k+2]-a[k])/d));lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
def normals(vertices):
    out=set()
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        nx,ny=b[1]-a[1],a[0]-b[0];d=gcd(abs(nx),abs(ny));out.add((nx//d,ny//d))
    return sorted(out)
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/prove_h5_short_exchange_all_angle_20261028.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,PARENT/'audit/plan.json',PARENT/'audit/checks.json',OLD/'plan.json',OLD/'cases/03.json',BOUND/'moving-core.json',BOUND/'audit/plan.json',BOUND/'audit/checks.json',JOINT/'stock-hull-core.json',JOINT/'audit/plan.json',JOINT/'audit/checks.json',PRE/'parent-source12.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A genuinely new necessary short-sheet model makes all13 original poses movable:5 brackets,6 inserts,2 cogs. Keep all8 bracket rotation/mirror modes and all4 insert quarter rotations. Cog collision uses the proven rotation-invariant filled-source core; stock uses the larger proven hull disk. Give every physical original its own anchor and mode. Each orthogonal core piece has rectangle coordinates determined by its mode and anchor. One global NoOverlap2D handles16 orthogonal pieces. For32 cog/orthogonal-piece pairs use the36 complete Minkowski facet directions with variable rectangle supports, and one cog/cog no-fit polygon. All13 presences remain mandatory; disabling missing presences is allowed only for explicit positive-control evaluation. This necessary relaxation supplies candidate anchors or a scoped allocation bound, never an original-source layout by itself.','coordinate_unit_mm':0.001,'maximum_rounding_per_coordinate_um':0.5,'source_to_model_rounding_proof_required':True,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'CP_model_created':False,'search_opened':False,'solver_calls':0,'native_calls':0,'no_original_job_infeasibility_claim':True})
job=load(JOB);parts={p['id']:p for p in job['parts']};sp=load(OLD/'plan.json');stock=sp['source_stock'];target=load(OLD/'cases/03.json');short=list(map(tuple,target['target_short_identities']));first=list(map(tuple,target['mandatory_first_identities']));allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};assert len(short)==13 and len(first)==53 and set(short)|set(first)==allids and not set(short)&set(first)
coredata=load(BOUND/'moving-core.json');core=coredata['vertices_um'];center=list(map(F,coredata['source_center_mm']));cgstock=load(JOINT/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];modes=[];edges=rects_checked=0
for family in ['bracket','insert']:
    legal=parts[family]['rotations'];assert legal=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]}
    for mir in ([False,True] if family=='bracket' else [False]):
        for q in range(4):
            angle=q*math.pi/2;raw=transform(parts[family]['geometry'][0]['outer'],angle,mir);offset=[-min(v[k] for v in raw) for k in [0,1]];vv=transform(parts[family]['geometry'][0]['outer'],angle,mir,offset);exact=[tuple(F(str(v)) for v in p) for p in vv];assert Polygon(vv).is_valid
            pieces=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]] if family=='bracket' else [parts[family]['geometry'][0]['outer']];rr=[]
            for piece in pieces:
                a,b,c,d=Polygon(transform(piece,angle,mir,offset)).bounds;r=[math.ceil(a*1000)+2,math.ceil(b*1000)+2,math.floor(c*1000)-2,math.floor(d*1000)-2];er=[F(v,1000) for v in r];assert all(parity(p,exact) for p in [(er[0],er[1]),(er[2],er[1]),(er[2],er[3]),(er[0],er[3])])
                for a,b in zip(exact,exact[1:]+exact[:1]):assert not hit(a,b,er);edges+=1
                rr.append(r);rects_checked+=1
            a,b,c,d=Polygon(vv).bounds;bounds=[math.floor((stock[0]-a)*1000)-2,math.floor((stock[1]-b)*1000)-2,math.ceil((stock[2]-c)*1000)+2,math.ceil((stock[3]-d)*1000)+2]
            modes.append({'family':family,'mode':len([m for m in modes if m['family']==family]),'quarter':q,'angle':angle,'mirrored':mir,'source_translation_offset':offset,'source_outer':vv,'rectangles_um':rr,'anchor_stock_bounds_um':bounds})
write(OUT/'orthogonal-modes.json',modes);write(OUT/'cog-core.json',coredata);write(OUT/'inventory.json',{'short13_identities':short,'mandatory_first53_identities':first,'all66_accounted_once':True,'cog_center_stock_bounds_um':cgstock,'all13_short_poses_independently_movable':True})
rectangle_normals=normals(core)+[(1,0),(-1,0),(0,1),(0,-1)];rectangle_normals=sorted(set(rectangle_normals));facets=[{'normal':[a,b],'negative_cog_support':max(-a*x-b*y for x,y in core)} for a,b in rectangle_normals];assert len(facets)==36
cgdiff=hull([(x-u,y-v) for x,y in core for u,v in core]);pairfacets=[{'normal':[a,b],'support':max(a*x+b*y for x,y in cgdiff)} for a,b in normals(cgdiff)]
write(OUT/'cog-rectangle-facets.json',facets);write(OUT/'cog-pair-facets.json',pairfacets);write(OUT/'cog-pair-no-fit.json',cgdiff)
mode_lookup={(m['family'],m['quarter'],m['mirrored']):m for m in modes}
def mapped(row):
    t=row['transform'];family=row['part_id'];k=key(row)
    if family=='cog':
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);p=[float(center[0])*c-float(center[1])*s+t['translation'][0],float(center[0])*s+float(center[1])*c+t['translation'][1]];a=[round(v*1000) for v in p];return {'identity':k,'family':family,'anchor_um':a,'mode':None,'rectangles_um':[],'stock_bounds_um':cgstock}
    q=round(t['rotation_radians']/(math.pi/2))%4;m=mode_lookup[family,q,t['mirrored']];a=[round((t['translation'][i]-m['source_translation_offset'][i])*1000) for i in [0,1]];rr=[[r[0]+a[0],r[1]+a[1],r[2]+a[0],r[3]+a[1]] for r in m['rectangles_um']];return {'identity':k,'family':family,'anchor_um':a,'mode':m['mode'],'rectangles_um':rr,'stock_bounds_um':m['anchor_stock_bounds_um']}
def failures(rows):
    stockbad=orthbad=cgrectbad=cgpairbad=0
    for r in rows:
        x,y=r['anchor_um'];a,b,c,d=r['stock_bounds_um'];stockbad+=not(a<=x<=c and b<=y<=d)
    for a,b in combinations(rows,2):
        if a['family']!='cog' and b['family']!='cog':
            for aa in a['rectangles_um']:
                for bb in b['rectangles_um']:orthbad+=not(aa[2]<=bb[0] or bb[2]<=aa[0] or aa[3]<=bb[1] or bb[3]<=aa[1])
        elif a['family']==b['family']=='cog':
            dx,dy=[b['anchor_um'][i]-a['anchor_um'][i] for i in [0,1]];cgpairbad+=not any(f['normal'][0]*dx+f['normal'][1]*dy>=f['support']+1 for f in pairfacets)
        else:
            cg,ort=(a,b) if a['family']=='cog' else (b,a);x,y=cg['anchor_um']
            for aa in ort['rectangles_um']:
                separated=False
                for f in facets:
                    nx,ny=f['normal'];support=nx*(aa[2] if nx>=0 else aa[0])+ny*(aa[3] if ny>=0 else aa[1])+f['negative_cog_support'];separated|=nx*x+ny*y>=support+1
                cgrectbad+=not separated
    return {'stock':int(stockbad),'orthogonal_piece_pairs':int(orthbad),'cog_rectangle_pairs':int(cgrectbad),'cog_pair':int(cgpairbad)}
parent=load(PRE/'parent-source12.json');positive=[p for p in parent if key(p)!=('bracket',3)];assert set(map(key,positive))<set(short);read=audit(job,positive,{'sheet-1':stock},sp['required_pair_gap_mm'],sp['stock_guard_mm'],[key(p) for p in positive]);assert read['valid'];mappedpositive=[mapped(p) for p in positive];assert not any(failures(mappedpositive).values());write(OUT/'positive-source11.json',positive);write(OUT/'positive-source11-checks.json',read);write(OUT/'positive-model11.json',mappedpositive)
negative=[]
for family,copy in short:
    if family=='cog':t={'rotation_radians':0.,'mirrored':False,'translation':[700.-float(center[0]),160.-float(center[1])]}
    else:m=mode_lookup[family,0,False];t={'rotation_radians':0.,'mirrored':False,'translation':[700.+m['source_translation_offset'][0],6.525+m['source_translation_offset'][1]]}
    negative.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-1','transform':t})
negativecheck=audit(job,negative,{'sheet-1':stock},sp['required_pair_gap_mm'],sp['stock_guard_mm'],short);assert not negativecheck['valid'] and negativecheck['pair_failures']>0 and negativecheck['stock_failures']==0;mappednegative=[mapped(p) for p in negative];bad=failures(mappednegative);assert bad['stock']==0 and bad['orthogonal_piece_pairs']>0 and bad['cog_rectangle_pairs']>0 and bad['cog_pair']==1;write(OUT/'negative-source13.json',negative);write(OUT/'negative-source13-checks.json',negativecheck);write(OUT/'negative-model13.json',mappednegative)
gap=F(str(sp['required_pair_gap_mm']))*1000;assert gap>F(1415,1000)
write(OUT/'rounding-proof.json',{'coordinate_rounding_um':0.5,'one_original_translation_error_upper_um':'0.708','two_original_relative_translation_error_upper_um':'1.416','original_required_gap_um':str(gap),'argument':'Every original source-valid placement has strictly positive pair gap greater than211um. Replace each continuous normalized orthogonal anchor or transformed cog center by its nearest integer micrometre. Each translation changes by at most sqrt(0.5^2+0.5^2)<0.708um, so every pair retains positive gap after a relative change<1.416um. All collision cores were contained in the source outers before that common translation. Closed no-fit polygons therefore remain avoided; integer facet expressions strictly outside them satisfy at least support+1. The stock bounds are rounded outward by2um and contain the at-most0.5um coordinate change. This proves a source-valid13 placement maps into the proposed necessary integer model, with no sampled cog-angle restriction. It does not prove the reverse mapping or original feasibility.'})
write(OUT/'controls.json',{'positive_originals':11,'positive_missing_short_identities':sorted(set(short)-set(map(key,positive))),'positive_core_failures':failures(mappedpositive),'negative_originals':13,'negative_source_pair_failures':negativecheck['pair_failures'],'negative_core_failures':bad,'expected_identity_arguments_normalized_to_tuples':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'target_originals':13,'mandatory_first_sheet_originals':53,'all66_accounted_once':True,'all13_anchors_independently_movable':True,'legal_bracket_modes':8,'legal_insert_modes':4,'strict_orthogonal_mode_rectangles':rects_checked,'exact_source_edge_checks':edges,'mandatory_orthogonal_core_pieces':16,'cog_rectangle_pair_predicates':32,'cog_rectangle_facet_directions':len(facets),'cog_pair_facet_directions':len(pairfacets),'positive_source11_and_core_control_passed':True,'negative_full13_rejected':True,'independent_model_and_geometry_audit_pending':True,'CP_model_created':False,'search_opened':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
