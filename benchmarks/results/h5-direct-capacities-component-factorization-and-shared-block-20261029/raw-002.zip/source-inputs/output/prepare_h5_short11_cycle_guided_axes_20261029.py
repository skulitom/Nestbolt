"""Expand axis choices by exact contradictory cycles, without a placement solver."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';SIX=ROOT/'output/h5-short11-six-axis-choices-20261029';BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';OUT=BASE/'preflight';PRE=SOURCE/'source-translation-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(SIX/'fixed-row-cycle-audit/checks.json')['restricted_model_infeasibility_certified_without_search'];BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();old=load(SOURCE/'source-translation-audit/axis-subsystem.json');edges=old['edges'];weights=[F(e['weight']) for e in edges];selected=set(load(SIX/'model/mapping.json')['removed_parent_rows']);initial=sorted(selected);certificates=[]
inputs=[Path(__file__),SOURCE/'source-translation-audit/plan.json',SOURCE/'source-translation-audit/axis-subsystem.json',SIX/'fixed-row-cycle-audit/plan.json',SIX/'fixed-row-cycle-audit/checks.json',SIX/'model/mapping.json',PRE/'plan.json',PRE/'audit/plan.json',PRE/'world-pieces.json',PRE/'planes.json',PRE/'variable-bounds.json',SOURCE/'preflight/inventory.json'];write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Start with the six prepared axis-choice rows. While fixed axis-aligned consequences contain a negative cycle, verify its exact rational sum and make every pair row in that cycle eligible for all original convex-piece axes. At most128 cycles or20 seconds of cycle discovery. Verify final absence of fixed-axis cycles with exact rational Bellman-Ford. This does not prove full model feasibility. Build and independently audit a distinct sufficient mixed-integer source model before its sole128-node60/90-second call. No closed model is retried.','algorithm_seconds':60,'shared_seconds':90,'node_limit':128,'maximum_calls':1,'retry_permitted':False,'source_validation_reserve_seconds':3})
def find_cycle(exact):
    active=[i for i,e in enumerate(edges) if e['source'].get('plane') not in selected];dist=[F(0) if exact else 0.]*23;pred=[None]*23;changed=None
    for _ in range(23):
        changed=None
        for k in active:
            e=edges[k];value=dist[e['from']]+(weights[k] if exact else float(weights[k]))
            if dist[e['to']]>value+(0 if exact else 1e-10):dist[e['to']]=value;pred[e['to']]=k;changed=e['to']
        if changed is None:return None,active
    v=changed
    for _ in range(23):assert pred[v] is not None;v=edges[pred[v]]['from']
    first=v;cycle=[]
    while True:
        k=pred[v];cycle.append(k);v=edges[k]['from']
        if v==first:break
        assert len(cycle)<=23
    cycle.reverse();assert all(edges[cycle[i]]['to']==edges[cycle[(i+1)%len(cycle)]]['from'] for i in range(len(cycle))) and sum(weights[k] for k in cycle)<0;return cycle,active
stopped=None
for iteration in range(128):
    if time.perf_counter()-started>=20:stopped='cycle discovery time limit';break
    cycle,active=find_cycle(False)
    if cycle is None:cycle,active=find_cycle(True)
    if cycle is None:break
    added=sorted({edges[k]['source']['plane'] for k in cycle if 'plane' in edges[k]['source']});assert added and not set(added)&selected;certificates.append({'iteration':iteration,'edge_indices':cycle,'negative_sum_mm':str(sum(weights[k] for k in cycle)),'new_choice_planes':added});selected.update(added)
else:stopped='cycle discovery count limit'
last,active=find_cycle(True);assert last is None and stopped is None,'Incomplete preflight: preserve it without opening a solver call';write(OUT/'cycle-expansion.json',{'initial_choice_planes':initial,'cycles':certificates,'final_choice_planes':sorted(selected),'remaining_fixed_axis_edges':active,'exact_final_fixed_axis_graph_has_no_negative_cycle':True,'full_linear_feasibility_not_established':True})
world=load(PRE/'world-pieces.json');planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');choices=[];cornerchecks=0
for index in sorted(selected):
    row=planes[index];a,b=row['owners'];ai,bi=row['pieces'];A=np.asarray(world[a]['pieces'][ai]);B=np.asarray(world[b]['pieces'][bi]);edgevectors=np.concatenate([np.roll(A,-1,axis=0)-A,np.roll(B,-1,axis=0)-B]);normals=np.stack([-edgevectors[:,1],edgevectors[:,0]],axis=1);normals=normals/np.linalg.norm(normals,axis=1)[:,None];normals=np.concatenate([normals,-normals]);gaps=(B@normals.T).min(axis=0)-(A@normals.T).max(axis=0);variants=[]
    for k,n in enumerate(normals):
        rhs=float(gaps[k]-.225);indices=[2*a,2*a+1,2*b,2*b+1];co=[float(n[0]),float(n[1]),float(-n[0]),float(-n[1])];maximum=sum(max(c*float(bounds[i][0]),c*float(bounds[i][1])) for i,c in zip(indices,co));M=max(0,maximum-rhs)+1e-8
        for corner in product(*[bounds[i] for i in indices]):assert sum(c*v for c,v in zip(co,corner))<=rhs+M+1e-9;cornerchecks+=1
        variants.append({'variant':k,'normal':n.tolist(),'source_projection_gap_mm':float(gaps[k]),'upper_delta_difference_mm':rhs,'variable_indices':indices,'coefficients':co,'deactivation_M_mm':M})
    original=int(np.argmax(gaps));assert variants[original]['normal']==row['normal'] and variants[original]['upper_delta_difference_mm']==row['upper_delta_difference_mm'];choices.append({'plane':index,'owners':row['owners'],'pieces':row['pieces'],'original_variant':original,'variants':variants})
write(OUT/'choices.json',choices);nv=sum(len(c['variants']) for c in choices);seconds=time.perf_counter()-started;write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'plan.json',PRE/'world-pieces.json',PRE/'planes.json',PRE/'variable-bounds.json',SOURCE/'source-translation-audit/axis-subsystem.json']},'solver_calls':0});write(OUT/'checks.json',{'passed':True,'seconds':seconds,'exact_negative_cycles_used':len(certificates),'initial_choice_groups':6,'final_choice_groups':len(choices),'candidate_axis_variants':nv,'stock_domain_corner_checks':cornerchecks,'remaining_fixed_pair_rows':8726-len(choices),'remaining_fixed_axis_edges':len(active),'exact_final_fixed_axis_graph_has_no_negative_cycle':True,'full_linear_feasibility_not_established':True,'all_original_branch_options_retained':True,'future_variables':23+nv,'future_rows':8770+nv,'independent_audit_pending':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
