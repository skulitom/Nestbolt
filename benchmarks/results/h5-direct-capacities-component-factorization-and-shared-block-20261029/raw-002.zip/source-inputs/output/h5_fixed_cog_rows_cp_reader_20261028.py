"""Pure field audit for the six-equality conditional construction and new hints."""
from h5_row_bracket_cp_reader_20261028 import control_values,violations
def inspect(p,mp,old,oldmp,fixed,relative,typed,control,negative,hints_saved,sol_saved,bad_saved):
    extras={'fixed_row_equalities','fixed_base_variable_count','fixed_base_constraint_count'};changed='control_disabled_mandatory_constraints';assert set(mp)==set(oldmp)|extras and {k:v for k,v in mp.items() if k not in extras|{changed}}=={k:v for k,v in oldmp.items() if k!=changed}
    assert {f.name for f,v in p.ListFields()}=={f.name for f,v in old.ListFields()}=={'variables','constraints','solution_hint'};assert len(p.variables)==len(old.variables)==mp['fixed_base_variable_count']==7932;assert len(old.constraints)==mp['fixed_base_constraint_count']==35015
    for a,b in zip(p.variables,old.variables):assert a.SerializeToString()==b.SerializeToString()
    for a,b in zip(p.constraints,old.constraints):assert a.SerializeToString()==b.SerializeToString()
    expected=[(row,axis,value) for row in fixed for axis,value in zip(['x','y'],row['anchor_um'])];assert len(expected)==len(mp['fixed_row_equalities'])==6 and [row['block'] for row in fixed]==[40,41,42];seen=set(range(len(old.constraints)))
    for entry,(row,axis,value) in zip(mp['fixed_row_equalities'],expected):
        assert set(entry)=={'block','axis','value_um','constraint'} and (entry['block'],entry['axis'],entry['value_um'])==(row['block'],axis,value);ix=entry['constraint'];assert ix not in seen and ix>=35015;seen.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'linear'} and list(ct.linear.vars)==[mp['items'][row['block']][axis]] and list(ct.linear.coeffs)==[1] and list(ct.linear.domain)==[value,value]
    assert seen==set(range(len(p.constraints))) and len(p.constraints)==35021;values=control_values(p,mp,relative,typed,control);bad=control_values(p,mp,relative,typed,negative);assert values==sol_saved and bad==bad_saved;known={r['block'] for r in control};assert known==set(range(5,43));hints={}
    for item in mp['items']:
        hints[item['presence']]=1
        if item['index'] in known:
            for key in ['x','y']:hints[item[key]]=values[item[key]]
            for o in item['options']:hints[o['selector']]=values[o['selector']]
    for pair in mp['row_pairs']:
        if pair['left'] in known and pair['right'] in known:
            for s in pair['selectors']:hints[s]=values[s]
    for pair in mp['row_bracket_pairs']:
        if pair['row'] in known and pair['bracket'] in known:
            for o in pair['options']:
                for s in o['cells']:hints[s]=values[s]
    assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in hints_saved.items()} and len(p.solution_hint.vars)==len(hints)==622;disabled=[i['mandatory'] for i in mp['items'] if i['index'] not in known];assert disabled==mp[changed] and len(disabled)==5
    return {'passed':True,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'old_variables_and_constraints_byte_identical':True,'only6_row_anchor_equalities_added':True,'extra_variables':0,'mandatory_blocks':43,'movable_orthogonal_blocks':40,'fixed_first_sheet_cogs':14,'fixed_short_originals':12,'target_originals':66,'partial_hints_verified':len(hints),'all_new_fields_verified':True},disabled
