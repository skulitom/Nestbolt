"""Prepare finite convex free regions for all 55 original-part relative positions."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, box, mapping
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
OUT = SOURCE / 'relative-free-region-preflight'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def rational(vertices):
    return [tuple(map(F, p)) for p in vertices]

def area(vertices):
    return sum((a[0]*b[1]-a[1]*b[0] for a, b in zip(vertices, vertices[1:]+vertices[:1])), F(0))/2

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def hull(vertices):
    points = sorted(set(vertices))
    chains = []
    for sequence in [points, list(reversed(points))]:
        chain = []
        for p in sequence:
            while len(chain) >= 2 and cross(chain[-2], chain[-1], p) <= 0:
                chain.pop()
            chain.append(p)
        chains.append(chain)
    return chains[0][:-1]+chains[1][:-1]

def merge_exact(polygons):
    active = {i: rational(list(p.exterior.coords)[:-1]) for i, p in enumerate(polygons)}
    for i, p in active.items():
        if area(p) < 0:
            active[i] = list(reversed(p))
    merges = 0
    while True:
        owners = {}
        candidates = []
        for i, p in active.items():
            for a, b in zip(p, p[1:]+p[:1]):
                edge = tuple(sorted([a, b]))
                if edge in owners:
                    candidates.append((owners[edge], i))
                else:
                    owners[edge] = i
        changed = False
        for a, b in candidates:
            if a not in active or b not in active:
                continue
            combined = hull(active[a]+active[b])
            if area(combined) == area(active[a])+area(active[b]):
                active[a] = combined
                del active[b]
                merges += 1
                changed = True
        if not changed:
            break
    return [[[float(x), float(y)] for x, y in p] for p in active.values()], merges

assert load(SOURCE / 'response-audit/checks.json')['passed']
assert not OUT.exists()
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'prepare.py')
started = time.perf_counter()
world = load(SOURCE / 'world-pieces.json')
bounds = np.load(SOURCE / 'model.npz')['bounds'][:22]
groups, obstacles = [], []
radius = .226/math.cos(math.pi/32)
total_initial = total_merges = 0
for a, b in combinations(world, 2):
    ia, ib = a['owner'], b['owner']
    x0 = bounds[2*ib, 0]-bounds[2*ia, 1]
    x1 = bounds[2*ib, 1]-bounds[2*ia, 0]
    y0 = bounds[2*ib+1, 0]-bounds[2*ia+1, 1]
    y1 = bounds[2*ib+1, 1]-bounds[2*ia+1, 0]
    domain = box(x0, y0, x1, y1)
    pair_obstacles = []
    for av in a['pieces']:
        for bv in b['pieces']:
            difference = (np.asarray(av)[:, None, :]-np.asarray(bv)[None, :, :]).reshape(-1, 2)
            pair_obstacles.append(MultiPoint(difference).convex_hull)
    raw = unary_union(pair_obstacles)
    forbidden = raw.buffer(radius, quad_segs=8)
    assert raw.is_valid and forbidden.is_valid and forbidden.covers(raw)
    free = domain.difference(forbidden)
    assert free.is_valid and not free.is_empty
    triangles = list(shapely.constrained_delaunay_triangles(free).geoms)
    assert triangles and all(len(p.exterior.coords) == 4 and p.area > 0 for p in triangles)
    triangle_union = unary_union(triangles)
    triangulation_difference = triangle_union.symmetric_difference(free).area
    assert triangulation_difference < 1e-7
    regions, merges = merge_exact(triangles)
    merged_union = unary_union([Polygon(p) for p in regions])
    merge_difference = merged_union.symmetric_difference(triangle_union).area
    assert merge_difference < 1e-7 and len(regions)+merges == len(triangles)
    total_initial += len(triangles)
    total_merges += merges
    groups.append({'owners': [ia, ib], 'identities': [a['identity'], b['identity']],
                   'relative_variable': 'delta_b_minus_delta_a', 'domain': [float(x0), float(y0), float(x1), float(y1)],
                   'source_piece_pairs': len(pair_obstacles), 'initial_triangles': len(triangles),
                   'exact_convex_merges': merges, 'regions': regions,
                   'triangulation_symmetric_difference_mm2': triangulation_difference,
                   'merge_symmetric_difference_mm2': merge_difference,
                   'free_area_mm2': free.area})
    obstacles.append({'owners': [ia, ib], 'raw_configuration_obstacle': mapping(raw),
                      'inflated_obstacle': mapping(forbidden), 'bounded_free_region': mapping(free)})
    assert time.perf_counter()-started < 30, 'Preparation cap reached; no solver may be opened.'
write(OUT / 'groups.json', groups)
write(OUT / 'obstacles.json', obstacles)
elapsed = time.perf_counter()-started
inputs = [Path(__file__), SOURCE / 'plan.json', SOURCE / 'audit/plan.json', SOURCE / 'audit/checks.json',
          SOURCE / 'response-audit/plan.json', SOURCE / 'response-audit/checks.json', SOURCE / 'world-pieces.json',
          SOURCE / 'model.npz', SOURCE / 'inventory.json', SOURCE / 'preparation-charges.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'For each original pair, union convex-piece Minkowski differences A-B, inflate with a circumscribed 32-segment round buffer for 0.226 mm clearance, and subtract from the relative translation rectangle deltaB-deltaA. Constrained triangulation partitions the free region; adjacent triangles merge only when exact rational convex-hull area equals their summed areas. This changes the formulation to one region choice per original pair. Before any model, independently certify every entire convex region against every original convex-piece pair using exact rational support inequalities for at least 0.225 mm clearance. Check coverage and all identities, then independently audit any new model. Float Boolean/triangulation construction and fixed modes/phases restrict negative conclusions. The closed 128-node all-pair call is never retried.',
    'buffer_target_mm': .226, 'buffer_radius_mm': radius, 'buffer_quad_segs': 8,
    'independent_required_gap_mm': .225, 'geometry_preparation_cap_seconds': 30,
    'solver_calls': 0, 'model_created': False,
})
checks = {'passed': True, 'seconds': elapsed, 'original_pair_groups': len(groups),
          'original_piece_pairs': sum(g['source_piece_pairs'] for g in groups),
          'initial_triangles': total_initial, 'exact_convex_merges': total_merges,
          'convex_regions': sum(len(g['regions']) for g in groups),
          'maximum_regions_per_pair': max(len(g['regions']) for g in groups),
          'independent_exact_clearance_audit_pending': True, 'new_model_created': False,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
