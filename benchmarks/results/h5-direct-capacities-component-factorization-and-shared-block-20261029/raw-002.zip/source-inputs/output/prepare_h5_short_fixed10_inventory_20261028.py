"""New fixed-ten source inventory and bounded necessary all-angle cog preflight."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
from prove_h5_short_exchange_all_angle_20261028 import obstacle,certificate
from h5_legacy64_source_readback import audit

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound'
PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight'
OUT=ROOT/'output/h5-short-fixed10-inventory-20261028'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
key=lambda r:(r['part_id'],r['copy_index'])

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

OUT.mkdir();(OUT/'cases').mkdir();(OUT/'source-checks').mkdir();(OUT/'certificates').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
assert load(BOUND/'audit/checks.json')['passed'] and load(OLD/'finite-construction-closure.json')['closed']
inputs=[Path(__file__),ROOT/'output/prove_h5_short_exchange_all_angle_20261028.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,OLD/'plan.json',BOUND/'plan.json',BOUND/'audit/plan.json',BOUND/'audit/checks.json',BOUND/'moving-core.json',BOUND/'fixed-core-rectangles.json',BOUND/'result.json',PRE/'parent-source12.json']+sorted((OLD/'cases').glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each of the six independently excluded fixed-eleven cases, release exactly one additional existing original. Preserve all 66 target identities, including the released part as a mandatory third short-sheet mover. Deduplicate identical fixed-ten geometry by its pair of removed parent identities, retaining every ordered inventory variant. Test necessary continuous cog-center coverage with the previously proved rotation-invariant source core and unchanged fixed-source rectangles. Each case stops at its first uncovered core center, full coverage or the frozen cap. A witness leaves only a necessary relaxation open; it is not an original source placement.','source_short_target_counts':[5,6,2],'source_first_target_counts':[18,7,15,13],'max_nodes_per_geometry':100000,'max_depth':30,'retry_permitted':False,'optimizer_calls':0,'native_calls':0,'construction_calls':0})
job=load(JOB);allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};parent=load(PRE/'parent-source12.json');sourceplan=load(OLD/'plan.json');core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};bounds=load(BOUND/'result.json')['relaxed_continuous_center_bounds_um']
groups={};variants=[]
for cp in sorted((OLD/'cases').glob('*.json')):
    case=load(cp);primary=case['removed_short_bracket_copy']
    for second in sorted(case['fixed11'],key=key):
        removed=tuple(sorted([('bracket',primary),key(second)]));rows=[r for r in parent if key(r) not in removed];assert len(rows)==10
        movers=[list(key(second)),['cog',0],['insert',0]];short={key(r) for r in rows}|{tuple(k) for k in movers};first={tuple(k) for k in case['mandatory_first_identities']}
        assert len(short)==13 and len(first)==53 and not short&first and short|first==allids
        assert Counter(k[0] for k in short)=={'bracket':5,'insert':6,'cog':2} and Counter(k[0] for k in first)=={'frame':18,'bracket':7,'insert':15,'cog':13}
        variant={'index':len(variants),'primary_bracket_to_first':primary,'extra_released_original':list(key(second)),'moving_short_originals':movers,'mandatory_short_identities':sorted(short),'mandatory_first_identities':sorted(first),'removed_parent_identities':removed,'all66_accounted_once':True}
        variants.append(variant);groups.setdefault(removed,{'fixed10':rows,'variants':[]})['variants'].append(variant['index'])
assert len(variants)==66 and len(groups)==51
summaries=[]
for idx,(removed,group) in enumerate(sorted(groups.items())):
    name=f'{idx:02d}';rows=group['fixed10'];result=audit(job,rows,{'sheet-1':sourceplan['source_stock']},sourceplan['required_pair_gap_mm'],sourceplan['stock_guard_mm']);assert result['valid'] and result['originals']==10
    write(OUT/'source-checks'/f'{name}.json',result)
    for vi in group['variants']:variants[vi]['geometry_case']=name
    write(OUT/'cases'/f'{name}.json',{'geometry_case':name,'removed_parent_identities':removed,'fixed10':rows,'inventory_variant_indices':group['variants']})
    obs=[obstacle(rect,core) for row in rows for rect in fixed[key(row)]];write(OUT/'obstacles'/f'{name}.json',obs)
    cert=certificate(bounds,obs,100000,30);write(OUT/'certificates'/f'{name}.json',cert)
    summaries.append({'geometry_case':name,'removed_parent_identities':removed,'inventory_variants':group['variants'],'fixed_source_originals':10,'necessary_obstacles':len(obs),'nodes':len(cert['nodes']),'all_angle_additional_cog_excluded':cert['covered'],'relaxation_witness_um':cert['relaxation_witness_um'],'limit':cert['limit']})
write(OUT/'inventory-variants.json',variants);write(OUT/'case-summary.json',summaries)
write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'parent_source_originals':12,'identity_variants':len(variants),'distinct_fixed10_geometries':len(summaries),'source_valid_fixed10_cases':len(summaries),'necessary_core_excluded_geometries':sum(c['all_angle_additional_cog_excluded'] for c in summaries),'necessary_core_witness_geometries':sum(c['relaxation_witness_um'] is not None for c in summaries),'limited_geometries':sum(c['limit'] is not None for c in summaries),'covered_inventory_variants':sum(len(c['inventory_variants']) for c in summaries if c['all_angle_additional_cog_excluded']),'unexcluded_inventory_variants':sum(len(c['inventory_variants']) for c in summaries if not c['all_angle_additional_cog_excluded']),'relaxed_center_bounds_um':bounds,'independent_audit_pending':True,'construction_calls':0,'solver_calls':0,'native_calls':0,'full_allocation_or_original_job_excluded':False,'H5_complete':False})
print(load(OUT/'result.json'),flush=True)
