"""Freeze the full active-piece envelope and sweep controls for cog strip propagation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-coarse-short-core-20261029';BASE=ROOT/'output/h5-strip-capacity-short-core-20261029';OUT=BASE/'preflight';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';STRIP=OLD/'cog-strip-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def sweep(rectangles,axis):
    events={}
    for r in rectangles:
        demand=r[3-axis]-r[1-axis]
        for coordinate,sign in [(r[axis],1),(r[axis+2],-1)]:events[coordinate]=events.get(coordinate,0)+sign*demand
    live=peak=0
    for coordinate,delta in sorted(events.items()):live+=delta;peak=max(peak,live)
    assert live==0
    return peak
assert not BASE.exists();BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(OLD/'response-audit/checks.json')['passed'] and load(STRIP/'audit/checks.json')['passed'] and load(PRE/'audit/checks.json')['passed']
inputs=[Path(__file__),OLD/'model/plan.json',OLD/'model/model.pb',OLD/'model/model.pbtxt',OLD/'model/mapping.json',OLD/'model-audit/plan.json',OLD/'model-audit/checks.json',OLD/'response-audit/plan.json',OLD/'response-audit/checks.json',STRIP/'plan.json',STRIP/'strips.json',STRIP/'necessity-proof.json',STRIP/'audit/plan.json',STRIP/'audit/checks.json',PRE/'audit/plan.json',PRE/'modes.json',PRE/'inventory.json',PRE/'positive-core11.json',PRE/'negative-core13.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Retain every parent model variable, constraint and hint. Append32 translated cog-strip rectangles to a second global48-piece NoOverlap2D constraint, plus two redundant cumulative constraints. Capacity constants come only from independently audited active-piece envelopes across every legal mode and anchor domain, including coarse rounding and expanded stock. All13 owners remain mandatory and all26 anchors movable. No source geometry, clearance, inventory or mode is changed. The previous UNKNOWN calls remain closed.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'num_search_workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'retry_permitted':False,'model_created':False,'solver_calls':0,'native_calls':0})
modes=load(PRE/'modes.json');inventory=load(PRE/'inventory.json');strips=load(STRIP/'strips.json');envelopes=[]
for m in modes:
    bounds=m['anchor_stock_bounds_grid_units']
    for i,r in enumerate(m['rectangles_um']):envelopes.append({'family':m['family'],'mode':m['mode'],'component':i,'anchor_bounds_grid_units':bounds,'local_rectangle_um':r,'world_envelope_um':[100*bounds[0]+r[0],100*bounds[1]+r[1],100*bounds[2]+r[2],100*bounds[3]+r[3]]})
bounds=inventory['cog_center_stock_bounds_grid_units']
for i,r in enumerate(strips):envelopes.append({'family':'cog','mode':None,'component':i,'anchor_bounds_grid_units':bounds,'local_rectangle_um':r,'world_envelope_um':[100*bounds[0]+r[0],100*bounds[1]+r[1],100*bounds[2]+r[2],100*bounds[3]+r[3]]})
assert len(envelopes)==36;box=[min(v['world_envelope_um'][k] for v in envelopes) if k<2 else max(v['world_envelope_um'][k] for v in envelopes) for k in range(4)];capacities={'x_intervals_height_capacity_um':box[3]-box[1],'y_intervals_width_capacity_um':box[2]-box[0]};assert min(capacities.values())>0
write(OUT/'envelopes.json',envelopes);write(OUT/'bounds.json',{'anchor_unit_um':100,'common_box_um':box,**capacities,'active_orthogonal_piece_bounds_use_selected_mode_table_and_stock_constraints':True,'absent_owners_do_not_consume_capacity':True})
controls=[]
for name,count in [('positive',11),('negative',13)]:
    rr=[]
    for row in load(PRE/f'{name}-core{count}.json'):
        x,y=row['anchor_um'];rr.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in strips] if row['family']=='cog' else row['world_rectangles_um'])
    assert all(box[0]<=r[0]<r[2]<=box[2] and box[1]<=r[1]<r[3]<=box[3] for r in rr);peaks=[sweep(rr,k) for k in [0,1]];good=[peaks[0]<=capacities['x_intervals_height_capacity_um'],peaks[1]<=capacities['y_intervals_width_capacity_um']]
    assert all(good) if name=='positive' else not any(good)
    controls.append({'name':name,'originals':count,'pieces':len(rr),'peak_sum_heights_um':peaks[0],'peak_sum_widths_um':peaks[1],'cumulative_constraints_pass':good})
write(OUT/'controls.json',controls)
write(OUT/'necessity-proof.json',{'mode_envelope':'For a present bracket or insert, its selected table row supplies both local rectangle endpoints and anchor stock bounds. Each world endpoint is100 times its anchor plus that local endpoint. Enumerating all legal rows gives an envelope containing each active piece, without mixing a tighter mode bound with another mode geometry. Cog anchor domains and fixed strip offsets give their exact envelopes.','capacity':'All48 active rectangles fit within the union bounding box. At any x, NoOverlap2D makes their active y interiors disjoint, so their height sum is at most the common box height. At any y, active x interiors are disjoint, so width sum is at most the box width. Endpoint equality uses half-open interval semantics. Absent owners contribute nothing. The two cumulative constraints follow from the existing core disjunctions and do not change feasible assignments.','limits':'These are necessary core constraints, not original source placements. A feasible response must still pass the original source and identity checks; a full66 candidate is required before native validation. Neither earlier call is reopened.'})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',*inputs]}})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'mode_piece_envelopes':36,'common_box_um':box,**capacities,'positive_controls_pass':True,'negative_controls_rejected':True,'independent_audit_pending':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
