"""Freeze a sufficient fixed-orientation source translation model from the rejected witness."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';OUT=BASE/'source-translation-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SOURCE=BASE/'search/source-response/baseline-source11.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'source-audit-v2/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();job=load(JOB);parts={p['id']:p for p in job['parts']};rows=load(SOURCE);inv=load(BASE/'preflight/inventory.json');assert len(rows)==11 and {(r['part_id'],r['copy_index']) for r in rows}==set(map(tuple,inv['short11_identities']));canonical={};coverage=[]
for family in ['bracket','insert','cog']:
    outer=parts[family]['geometry'][0]['outer'];shape=Polygon(outer)
    if family=='bracket':pp=[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]]
    elif family=='insert':pp=[outer]
    else:
        center=[139.723742,139.723742];assert len(outer)==80 and shape.contains(Polygon(outer).centroid);pp=[[center,outer[i],outer[(i+1)%len(outer)]] for i in range(len(outer))]
    polygons=[Polygon(p) for p in pp];assert all(g.is_valid and g.area>0 and g.equals(g.convex_hull) for g in polygons);joined=unary_union(polygons);difference=shape.symmetric_difference(joined).area;overlap=sum(g.area for g in polygons)-joined.area;assert difference<1e-7 and abs(overlap)<1e-7;canonical[family]=pp;coverage.append({'family':family,'pieces':len(pp),'source_area_mm2':shape.area,'symmetric_difference_mm2':difference,'internal_overlap_mm2':overlap})
world=[]
for i,row in enumerate(rows):
    family=row['part_id'];t=row['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1
    def pose(points):return [[sign*x*co-y*si+t['translation'][0],sign*x*si+y*co+t['translation'][1]] for x,y in points]
    pieces=[pose(p) for p in canonical[family]];outline=pose(parts[family]['geometry'][0]['outer']);shape=Polygon(outline);joined=unary_union([Polygon(p) for p in pieces]);assert shape.symmetric_difference(joined).area<1e-7;world.append({'index':i,'identity':[family,row['copy_index']],'pieces':pieces,'outline':outline,'bounds':list(shape.bounds)})
sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');stock=sp['source_stock'];gap=.225;stock_extra=.025;assert gap>sp['required_pair_gap_mm'] and stock_extra>sp['stock_guard_mm'];planes=[]
for a,b in combinations(world,2):
    for ai,aa in enumerate(a['pieces']):
        A=np.asarray(aa)
        for bi,bb in enumerate(b['pieces']):
            B=np.asarray(bb);edges=np.concatenate([np.roll(A,-1,axis=0)-A,np.roll(B,-1,axis=0)-B]);normals=np.stack([-edges[:,1],edges[:,0]],axis=1);lengths=np.linalg.norm(normals,axis=1);assert np.all(lengths>1e-9);normals=normals/lengths[:,None];normals=np.concatenate([normals,-normals]);pa=A@normals.T;pb=B@normals.T;gaps=pb.min(axis=0)-pa.max(axis=0);k=int(np.argmax(gaps));n=normals[k];planes.append({'owners':[a['index'],b['index']],'pieces':[ai,bi],'normal':n.tolist(),'seed_projection_gap_mm':float(gaps[k]),'upper_delta_difference_mm':float(gaps[k]-gap)})
assert len(world)==11 and sum(len(r['pieces']) for r in world)==174 and len(planes)==8726
bounds=[]
for r in world:
    x0,y0,x1,y1=r['bounds'];bounds.extend([[stock[0]+stock_extra-x0,stock[2]-stock_extra-x1],[stock[1]+stock_extra-y0,stock[3]-stock_extra-y1]])
assert all(a<b for a,b in bounds);bounds.append([0,1500]);write(OUT/'canonical-pieces.json',canonical);write(OUT/'source-coverage.json',coverage);write(OUT/'world-pieces.json',world);write(OUT/'planes.json',planes);write(OUT/'variable-bounds.json',bounds);write(OUT/'seed-source11.json',rows)
proof={'method':'All eleven original outlines have fixed source orientations: the nine orthogonal modes from the rejected witness and7-degree phases for both cogs. All22 translations remain variable. Exact outline partitions use two rectangles per bracket, one per insert and80 center-fan triangles per cog. Holes are filled for PIH-off separation. Every pair of pieces from different originals gets one separating axis selected once from the seed by maximum signed projection gap. A linear inequality requires at least0.225mm separation on that unit axis. Original outline bounds require0.025mm stock clearance. Feasible solutions therefore have sufficient original-outline clearance, subject to independent original-source validation.','objective':'Minimize maximum absolute coordinate movement using one auxiliary variable, without fixing any active original.','limits':'This fixes modes, cog phases and one axis branch per convex-piece pair. Infeasibility excludes only this frozen translation system, never the allocation or any other orientation/topology. This is a new independent construction method, not a retry of the closed necessary-model call. First55 remains mandatory but is not constructed here.'};write(OUT/'method.json',proof)
inputs=[Path(__file__),JOB,SOURCE,BASE/'source-audit-v2/plan.json',BASE/'source-audit-v2/checks.json',BASE/'preflight/inventory.json',ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':proof,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'preparation_seconds':time.perf_counter()-started,'source_validation_reserve_seconds':3});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'originals':11,'orthogonal_originals':9,'cogs':2,'convex_pieces':174,'inter_original_piece_pairs':8726,'translation_variables':22,'max_move_auxiliary_variables':1,'target_gap_mm':gap,'target_stock_extra_mm':stock_extra,'source_partition_coverage_verified':True,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
