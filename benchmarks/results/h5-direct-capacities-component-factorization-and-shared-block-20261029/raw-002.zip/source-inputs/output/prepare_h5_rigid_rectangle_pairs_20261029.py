"""Conservative rigid source-component rectangles for every legal orthogonal mode."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'rigid-rectangle-preflight';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'response-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();canonical=load(PIECES);modes=load(BASE/'integer-preparation/family-modes.json');instances=load(BASE/'instances.json');records={}
for family,items in modes.items():
    assert len(canonical[family])==({'bracket':2,'insert':1}[family]);records[family]=[]
    for mode in items:
        c,s=F(math.cos(mode['rotation_radians'])),F(math.sin(mode['rotation_radians']));sign=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left']);rects=[]
        for pi,piece in enumerate(canonical[family]):
            pts=[(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in piece];bounds=[min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)]
            offsets=[math.floor(bounds[0]*1000),math.floor(bounds[1]*1000),math.ceil(bounds[2]*1000),math.ceil(bounds[3]*1000)]
            rects.append({'piece':pi,'exact_affine_bounds_mm':[str(v) for v in bounds],'outward_offsets_um':offsets})
        records[family].append({'mode':mode['mode'],'geometry':mode['normalized_geometry'],'rectangles':rects})
components=[{'component':n,'owner':i,'identity':row['identity'],'piece':pi} for n,(i,row,pi) in enumerate((i,row,pi) for i,row in enumerate(instances) for pi in range(len(canonical[row['identity'][0]])))]
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']]
assert len(components)==20 and len(pairs)==183
for name,value in [('mode-rectangles.json',records),('components.json',components),('component-pairs.json',pairs)]:write(OUT/name,value)
inputs=[Path(__file__),JOB,PIECES,BASE/'plan.json',BASE/'instances.json',BASE/'inventory.json',BASE/'integer-preparation/family-modes.json',BASE/'source-region-audit/plan.json',BASE/'source-region-audit/checks.json',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use the original two-rectangle filled partition of each L-bracket and the single rectangle of each insert. For every legal source mode, transform each original convex component using exact rational arithmetic on source vertices and binary64 trigonometric/translation coefficients, then round its bounds outward to integer micrometres. Tie every component coordinate rigidly to its original owner position and selected source mode. For every component pair belonging to different originals, choose one of four axis separations of at least226micrometres. Components of the same original are not separated from each other. Preserve all source unary cog-site regions, exactly two empty sites, all13 original identities and all80 source modes. Independently certify source partition coverage, outward bounds, rigidity and the complete model before a distinct bounded call.','grid_units_per_mm':1000,'required_component_gap_um':226,'orthogonal_originals':13,'rigid_components':20,'different_owner_component_pairs':183,'future_direction_selectors':732,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'new_model_created':False,'solver_calls':0})
result={'passed':True,'seconds':time.perf_counter()-started,'source_modes':12,'instance_source_mode_options':80,'rigid_components':20,'different_owner_component_pairs':183,'direction_selectors_needed':732,'prior_pair_region_selectors_replaced':12276,'independent_source_partition_and_bound_audit_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
