"""Pure SMT-LIB emitter: legal modes and conservative halfplane disjunctions."""
from itertools import combinations
def number(v):
    assert isinstance(v,int)
    return str(v) if v>=0 else f'(- {-v})'
def form(op,*args):return '('+op+(' '+' '.join(args) if args else '')+')'
def expression(terms):
    ts=[form('*',number(c),v) for v,c in terms if c]
    return number(0) if not ts else ts[0] if len(ts)==1 else form('+',*ts)
def build(remaining,modes,free,relative,cases):
    declarations=[];assertions=[];items=[];mapping={'items':items,'orders':[],'cases':[]}
    def declare(name,sort):declarations.append((name,sort));return name
    def add(expr):i=len(assertions);assertions.append(expr);return i
    for i,row in enumerate(remaining):
        p=declare(f'present_{i}','Bool');x=declare(f'x_{i}','Real');y=declare(f'y_{i}','Real');options=[]
        mandatory=add(p);bounds=add(form('and',form('>=',x,'0'),form('<=',x,'1500000'),form('>=',y,'0'),form('<=',y,'3000000')))
        for m in [m for m in modes if m['family']==row['family']]:
            mi=m['index'];s=declare(f'mode_{i}_{mi}','Bool');domains=[]
            for cell in free[mi]:domains.append(form('and',*[form('>=',expression([(x,a),(y,b)]),number(c)) for a,b,c in cell['halfplanes']]))
            options.append({'mode':mi,'selector':s,'free_assertion':add(form('=>',s,form('or',*domains)))})
        choice=add(form('=',p,form('or',*[o['selector'] for o in options])));exclusive=[]
        for a,b in combinations(options,2):exclusive.append({'modes':[a['mode'],b['mode']],'assertion':add(form('not',form('and',a['selector'],b['selector'])))})
        items.append({'index':i,'family':row['family'],'copy_index':row['copy_index'],'presence':p,'x':x,'y':y,'mandatory_assertion':mandatory,'bounds_assertion':bounds,'mode_choice_assertion':choice,'exclusive':exclusive,'options':options})
    for family in ['bracket','cog','insert']:
        group=[i for i in items if i['family']==family]
        for a,b in zip(group,group[1:]):mapping['orders'].append({'left':a['index'],'right':b['index'],'assertion':add(form('<=',a['x'],b['x']))})
    seen=set()
    for li,ri,a,b in cases:
        assert 0<=li<ri<len(items) and (li,ri,a,b) not in seen;seen.add((li,ri,a,b));left,right=items[li],items[ri];oa=next(o for o in left['options'] if o['mode']==a);ob=next(o for o in right['options'] if o['mode']==b);sign=1 if a<=b else -1;domains=[]
        for cell in relative[min(a,b),max(a,b)]:
            domains.append(form('and',*[form('>=',expression([(right['x'],sign*aa),(left['x'],-sign*aa),(right['y'],sign*bb),(left['y'],-sign*bb)]),number(cc)) for aa,bb,cc in cell['halfplanes']]))
        mapping['cases'].append({'left':li,'right':ri,'left_mode':a,'right_mode':b,'assertion':add(form('=>',form('and',oa['selector'],ob['selector']),form('or',*domains)))})
    text='(set-logic QF_LRA)\n'+''.join(f'(declare-fun {name} () {sort})\n' for name,sort in declarations)+''.join(f'(assert {s})\n' for s in assertions)
    return text,mapping
