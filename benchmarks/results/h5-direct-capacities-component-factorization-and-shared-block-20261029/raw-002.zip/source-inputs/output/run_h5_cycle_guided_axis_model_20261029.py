"""One declared mixed-integer source construction with at most128 nodes and60/90 seconds."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';MODEL=BASE/'model';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child(started):
    import numpy as np
    import scipy
    from scipy.optimize import milp,Bounds,LinearConstraint
    from scipy.sparse import csc_matrix
    from h5_legacy64_source_readback import audit
    ma=load(BASE/'model-audit/checks.json');assert ma['passed'] and digest(MODEL/'model.npz')==ma['model_sha256']
    for folder in [BASE,MODEL,BASE/'model-audit',BASE/'preflight/audit']:
        for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    data=np.load(MODEL/'model.npz');A,lo,hi,c,bounds,integrality=[data[n] for n in ['A','lower','upper','c','bounds','integrality']];mp=load(MODEL/'mapping.json');remaining=60-(time.perf_counter()-started)-3;assert remaining>0;options={'time_limit':remaining,'node_limit':128,'mip_rel_gap':0.0,'presolve':True,'disp':True};inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',BASE/'plan.json',MODEL/'plan.json',MODEL/'model.npz',MODEL/'mapping.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'preflight/audit/plan.json',SOURCE/'source-translation-preflight/seed-source11.json',SOURCE/'preflight/inventory.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json'];write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':3,'retry_permitted':False,'node_limit':128,'options':options,'scipy_version':scipy.__version__,'model_sha256':digest(MODEL/'model.npz'),'preparation_seconds_charged':load(MODEL/'built.json')['preparation_seconds_charged']});begin=time.perf_counter();r=milp(c,integrality=integrality,bounds=Bounds(bounds[:,0],bounds[:,1]),constraints=LinearConstraint(csc_matrix(A),lo,hi),options=options);solve=time.perf_counter()-begin;source_valid=False
    if r.x is not None:
        values=np.asarray(r.x);write(OUT/'assignment.json',values.tolist());evaluated=A@values;lower_error=float(np.max(lo-evaluated));upper_error=float(np.max(evaluated-hi));bound_error=float(max(np.max(bounds[:,0]-values),np.max(values-bounds[:,1])));integer_error=float(np.max(np.abs(values[23:]-np.round(values[23:]))));assert max(lower_error,upper_error,bound_error,integer_error)<1e-7;groups=[]
        for group in mp['groups']:
            selected=[i for i in group['selectors'] if values[i]>.5];assert len(selected)==1;groups.append({'plane':group['plane'],'variant':group['selectors'].index(selected[0])})
        write(OUT/'assignment-check.json',{'passed':True,'lower_row_error_mm':lower_error,'upper_row_error_mm':upper_error,'bound_error':bound_error,'integer_error':integer_error,'selected_variants':groups});rows=load(SOURCE/'source-translation-preflight/seed-source11.json')
        for i,row in enumerate(rows):row['transform']['translation']=[row['transform']['translation'][k]+float(values[2*i+k]) for k in [0,1]]
        job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');inv=load(SOURCE/'preflight/inventory.json');check=audit(job,rows,{'sheet-1':sp['source_stock']},sp['required_pair_gap_mm'],sp['stock_guard_mm'],list(map(tuple,inv['short11_identities'])));write(OUT/'candidate-source11.json',rows);write(OUT/'candidate-source11-checks.json',check);source_valid=check['valid']
    elapsed=time.perf_counter()-started
    def finite(key):
        value=getattr(r,key,None)
        return float(value) if value is not None and np.isfinite(value) else None
    write(OUT/'result.json',{'closed':True,'solver_calls':1,'status_code':int(r.status),'success':bool(r.success),'message':str(r.message),'returned_solve_seconds':solve,'allocated_solve_seconds':remaining,'returned_solve_overrun_seconds':max(0,solve-remaining),'has_assignment':r.x is not None,'objective_max_translation_mm':finite('fun'),'mip_node_count':finite('mip_node_count'),'mip_gap':finite('mip_gap'),'mip_dual_bound':finite('mip_dual_bound'),'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0,elapsed-60),'preparation_seconds_charged':load(MODEL/'built.json')['preparation_seconds_charged'],'source_valid11':source_valid,'first55_created':False,'source_valid66':False,'any_allocation_excluded':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');charge=load(MODEL/'built.json')['preparation_seconds_charged'];start=time.perf_counter()-charge;write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'node_limit':128,'retry_permitted':False,'source_validation_reserve_seconds':3,'preparation_seconds_charged':charge})
    try:
        r=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child',str(start)],cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-start)));(OUT/'stdout.txt').write_bytes(r.stdout);(OUT/'stderr.txt').write_bytes(r.stderr);process={'seconds_including_preparation':time.perf_counter()-start,'exit_code':r.returncode,'timeout':False,'closed':True}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds_including_preparation':time.perf_counter()-start,'timeout':True,'closed':True}
    write(OUT/'process.json',process);print(process,flush=True);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final result; this call remains closed.',flush=True)
if __name__=='__main__':child(float(sys.argv[2])) if '--child' in sys.argv else main()
