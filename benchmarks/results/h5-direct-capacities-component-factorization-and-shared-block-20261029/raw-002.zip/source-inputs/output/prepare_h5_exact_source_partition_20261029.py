"""Merge source fan triangles only when exact rational hull area proves unchanged coverage."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
import json,shutil,time
from shapely.geometry import Polygon
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';OUT=BASE/'exact-source-partition-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def hull(points):
    points=sorted(set(points));lo=[];hi=[]
    for p in points:
        while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
        lo.append(p)
    for p in reversed(points):
        while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
        hi.append(p)
    return lo[:-1]+hi[:-1]
def encoded(poly):return [[str(x),str(y)] for x,y in poly]
assert load(BASE/'response-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();job=load(JOB);parts={p['id']:p for p in job['parts']};outer=[tuple(map(F,p)) for p in parts['cog']['geometry'][0]['outer']];assert len(outer)==80 and Polygon([(float(x),float(y)) for x,y in outer]).is_valid
if area(outer)<0:outer=list(reversed(outer))
center=(F(139.723742),F(139.723742));assert all(cross(a,b,center)>0 for a,b in zip(outer,outer[1:]+outer[:1]));original=[{'members':[i],'vertices':[center,outer[i],outer[(i+1)%80]]} for i in range(80)];pieces=[{'members':r['members'][:],'vertices':r['vertices'][:]} for r in original];merges=[]
while True:
    found=False
    for i,j in combinations(range(len(pieces)),2):
        a,b=pieces[i],pieces[j]
        if len(set(a['vertices'])&set(b['vertices']))<2:continue
        candidate=hull(a['vertices']+b['vertices'])
        if area(candidate)!=area(a['vertices'])+area(b['vertices']):continue
        members=sorted(a['members']+b['members']);merges.append({'left_members':a['members'],'right_members':b['members'],'result_members':members,'result_vertices':encoded(candidate),'result_area_mm2':str(area(candidate))});pieces[i]={'members':members,'vertices':candidate};pieces.pop(j);found=True;break
    if not found:break
assert sum((area(p['vertices']) for p in pieces),F(0))==area(outer) and sorted(i for p in pieces for i in p['members'])==list(range(80));polygons=[Polygon([(float(x),float(y)) for x,y in p['vertices']]) for p in pieces];joined=unary_union(polygons);difference=joined.symmetric_difference(Polygon([(float(x),float(y)) for x,y in outer])).area;assert difference<1e-7
result={'source_outer_binary_rationals':encoded(outer),'fan_center_binary_rationals':list(map(str,center)),'initial_fan_triangles':[{'members':p['members'],'vertices':encoded(p['vertices'])} for p in original],'merges':merges,'final_convex_pieces':[{'members':p['members'],'vertices':encoded(p['vertices']),'area_mm2':str(area(p['vertices']))} for p in pieces],'exact_source_area_mm2':str(area(outer))};write(OUT/'cog-partition.json',result)
orth_pieces=14;cg=len(pieces);paircount=86+2*orth_pieces*cg+cg*cg;write(OUT/'next-method.json',{'intent':'Use this smaller exact original-cog partition to prepare a new fixed-orientation source construction with broader separation choices. Verify every merge, original source coverage, all posed pieces and all11/55 identities independently first. Then derive complete pair configuration-space or convex-piece separation alternatives over the original stock domains, without retaining the failed seed directions. Declare and audit a distinct bounded model before any further call.','scope':'All source contours and clearances remain unchanged. The nine orthogonal modes and both7-degree cog phases may remain fixed initially; a negative from that family cannot exclude other modes/phases or the allocation. Complete66/native/material and H5 validation remain required.','no_new_model_or_call':True})
inputs=[Path(__file__),JOB,BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',BASE/'oblique-cycle-audit/plan.json',BASE/'oblique-cycle-audit/checks.json',SOURCE/'preflight/inventory.json',SOURCE/'source-translation-preflight/plan.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'initial_cog_triangles':80,'exact_area_preserving_merges':len(merges),'final_cog_convex_pieces':cg,'all_original_triangles_accounted_once':True,'exact_source_area_preserved':True,'secondary_float_symmetric_difference_mm2':difference,'future_total_pieces_for_short11':orth_pieces+2*cg,'future_inter_original_piece_pairs':paircount,'previous_inter_original_piece_pairs':8726,'independent_partition_audit_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
