"""Pure exhaustive reader for every fixed61/five-bracket model field."""
from h5_transfer43_cp_reader_20261028 import violations
def inspect(p,mp,modes,free,control,negative,hints_saved,sol_saved,bad_saved):
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'};seenvars=set();seencts=set();values={};bad={};hints={};xs=[];ys=[];control={r['block']:r for r in control};negative={r['block']:r for r in negative};MIN=-9223372036854775808;MAX=9223372036854775807
    def var(ix,name,domain):
        assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'}
    def linear(ix,coeffs,lo=MIN,hi=MAX,on=()):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and {f.name for f,z in ct.ListFields()}<= {'linear','enforcement_literal'};assert list(ct.enforcement_literal)==list(on) and dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
    def expr(e,v,offset):assert e.offset==offset and list(e.vars)==([] if v is None else [v]) and list(e.coeffs)==([] if v is None else [1]) and {f.name for f,z in e.ListFields()}<= {'vars','coeffs','offset'}
    def interval(ix,name,v,a,b,s):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'name','enforcement_literal','interval'} and ct.name==name and list(ct.enforcement_literal)==[s];expr(ct.interval.start,v,a);expr(ct.interval.size,None,b-a);expr(ct.interval.end,v,b)
    assert len(mp['items'])==5
    for i,item in enumerate(mp['items']):
        assert item['index']==item['block']==i and item['copy_index']==7+i;pr,x,y=item['presence'],item['x'],item['y'];var(pr,f'present_{i}',[0,1]);var(x,f'x_{i}',[0,1500000]);var(y,f'y_{i}',[0,3000000]);linear(item['mandatory'],{pr:1},1,1);known=control.get(i);values[pr]=int(known is not None);bad[pr]=1;hints[pr]=1;values[x],values[y]=known['anchor_um'] if known else [0,0];bad[x],bad[y]=negative[i]['anchor_um']
        if known:hints[x],hints[y]=known['anchor_um']
        assert [o['mode'] for o in item['options']]==list(range(2,10))
        for o in item['options']:
            mi=o['mode'];s=o['selector'];var(s,f'mode_{i}_{mi}',[0,1]);active=known is not None and known['mode']==mi;badactive=negative[i]['mode']==mi;values[s]=int(active);bad[s]=int(badactive)
            if known:hints[s]=values[s]
            selected=next((k for k,c in enumerate(free[mi]) if active and all(a*known['anchor_um'][0]+b*known['anchor_um'][1]>=v for a,b,v in c['halfplanes'])),None);bs=next((k for k,c in enumerate(free[mi]) if badactive and all(a*negative[i]['anchor_um'][0]+b*negative[i]['anchor_um'][1]>=v for a,b,v in c['halfplanes'])),None);assert not active or selected is not None;assert not badactive or bs is not None
            assert len(o['cells'])==len(o['plane_constraints'])==len(free[mi])
            for k,(cell,sv,cts) in enumerate(zip(free[mi],o['cells'],o['plane_constraints'])):
                var(sv,f'cell_{i}_{mi}_{k}',[0,1]);values[sv]=int(active and k==selected);bad[sv]=int(badactive and k==bs)
                if known:hints[sv]=values[sv]
                assert len(cts)==len(cell['halfplanes'])
                for ix,(a,b,v) in zip(cts,cell['halfplanes']):linear(ix,{ix:c for ix,c in [(x,a),(y,b)] if c},lo=v,on=[sv])
            linear(o['cell_choice'],{**{sv:1 for sv in o['cells']},s:-1},0,0);assert len(o['components'])==len(modes[mi]['cover_rectangles_um'])==2
            for k,(r,(a,b,c,d)) in enumerate(zip(o['components'],modes[mi]['cover_rectangles_um'])):
                assert r['component']==k;interval(r['x_interval'],f'cover_x_{i}_{mi}_{k}',x,a,c,s);interval(r['y_interval'],f'cover_y_{i}_{mi}_{k}',y,b,d,s);xs.append(r['x_interval']);ys.append(r['y_interval'])
        linear(item['choice'],{**{o['selector']:1 for o in item['options']},pr:-1},0,0)
    ix=mp['no_overlap_2d'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'no_overlap_2d'} and list(ct.no_overlap_2d.x_intervals)==xs and list(ct.no_overlap_2d.y_intervals)==ys;assert len(mp['orders'])==4
    for r,(a,b) in zip(mp['orders'],zip(mp['items'],mp['items'][1:])):assert (r['left'],r['right'])==(a['index'],b['index']);linear(r['constraint'],{a['x']:1,b['x']:-1},hi=0,on=[a['presence'],b['presence']])
    assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)));assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in hints_saved.items()} and len(p.solution_hint.vars)==len(hints);assert sol_saved==[values[i] for i in range(len(p.variables))] and bad_saved==[bad[i] for i in range(len(p.variables))];disabled=[r['mandatory'] for r in mp['items'] if r['index'] not in control];assert disabled==mp['control_disabled_mandatory_constraints'] and len(disabled)==4
    return {'passed':True,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'mandatory_moving_brackets':5,'fixed_originals':61,'target_originals':66,'mode_choices':40,'cell_selectors':sum(len(o['cells']) for r in mp['items'] for o in r['options']),'all_model_fields_verified':True,'hints_verified':len(hints)},disabled
