"""Exact inward halfplanes over a complete constrained triangulation; no greedy merging."""
from fractions import Fraction as F
import shapely
from shapely.geometry import mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from h5_source_convex_cells_20261028 import selected_cell
def encode(region):
    pieces=list(shapely.constrained_delaunay_triangles(region).geoms);assert pieces and unary_union(pieces).equals(region);cells=[]
    for piece in pieces:
        piece=orient(piece,sign=1);assert piece.equals(piece.convex_hull);points=list(piece.exterior.coords)[:-1];planes=[]
        for p,q in zip(points,points[1:]+points[:1]):
            px,py=map(lambda v:F(str(v)),p);qx,qy=map(lambda v:F(str(v)),q);nx,ny=py-qy,qx-px;scale=max(abs(nx),abs(ny));nx/=scale;ny/=scale;aa=round(nx*10**9);bb=round(ny*10**9);error=abs(F(aa)-nx*10**9)*1600000+abs(F(bb)-ny*10**9)*3100000;value=(nx*px+ny*py)*10**12+error;cc=-((-value.numerator)//value.denominator)+1;planes.append([aa,bb,cc])
        cells.append({'geometry':mapping(piece),'halfplanes':planes})
    return {'cells':cells,'domain_geometry':mapping(region)}
