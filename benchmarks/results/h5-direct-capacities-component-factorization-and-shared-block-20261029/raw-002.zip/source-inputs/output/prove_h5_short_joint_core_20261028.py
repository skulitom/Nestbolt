"""Joint necessary cog/bracket or cog/cog coverage for the seven surviving fixed-ten layouts."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon
from prove_h5_short_exchange_all_angle_20261028 import hull,obstacle,source,rect_inward
from h5_joint_core_coverage_20261028 import certificate
ROOT=Path(__file__).resolve().parents[1];INV=ROOT/'output/h5-short-fixed10-inventory-20261028';ADJ=ROOT/'output/h5-short-adjacent-exchange-20261028';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';OUT=ROOT/'output/h5-short-joint-core-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda r:(r['part_id'],r['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter()
assert load(INV/'audit/checks.json')['passed'] and load(ADJ/'response-audit/checks.json')['passed'] and load(BOUND/'audit/checks.json')['passed']
survivors=[s for s in load(INV/'case-summary.json') if not s['all_angle_additional_cog_excluded']];assert len(survivors)==7
inputs=[Path(__file__),ROOT/'output/prove_h5_short_exchange_all_angle_20261028.py',ROOT/'output/h5_joint_core_coverage_20261028.py',JOB,INV/'audit/plan.json',INV/'audit/checks.json',INV/'case-summary.json',INV/'inventory-variants.json',ADJ/'response-audit/plan.json',ADJ/'response-audit/checks.json',ADJ/'modes.json',OLD/'plan.json',BOUND/'audit/plan.json',BOUND/'audit/checks.json',BOUND/'moving-core.json',BOUND/'fixed-core-rectangles.json']+[INV/'cases'/f"{s['geometry_case']}.json" for s in survivors]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'max_nodes_per_case':50000,'max_depth':40,'shared_proof_wall_seconds':120,'case_order':'Adjacent-bracket geometry38: all8 bracket modes36..43, then ascending IDs of the six cog-release geometries.','method':'Prove an angle-independent stock-center bound from a disk contained in the original cog convex hull. Keep the smaller filled-source cog core for collisions. Cover the full continuous four-variable rectangle for two necessary moving cores using exact fixed-obstacle and relative pair no-fit polygons. Every covered leaf is contained in a single forbidden predicate. Stop on full coverage, first necessary-relaxation witness or frozen limit. A witness is not a source placement; inconclusive cases stay open. No extra pair clearance or coordinate grid.','retry_permitted':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'full_allocation_or_original_job_excluded':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};coredata=load(BOUND/'moving-core.json');core=coredata['vertices_um'];center=list(map(F,coredata['source_center_mm']));vv=[tuple(F(str(v)) for v in p) for p in parts['cog']['geometry'][0]['outer']];ch=hull(vv);dist=[]
for a,b in zip(ch,ch[1:]+ch[:1]):
    dx,dy=b[0]-a[0],b[1]-a[1];cross=dx*(center[1]-a[1])-dy*(center[0]-a[0]);assert cross>0;dist.append(cross*cross/(dx*dx+dy*dy))
r=math.floor(math.sqrt(float(min(dist)))*1000)-2;assert F(r*r,1000000)<min(dist)
stock=load(OLD/'plan.json')['source_stock'];cb=[math.floor(stock[0]*1000)+r-2,math.floor(stock[1]*1000)+r-2,math.ceil(stock[2]*1000)-r+2,math.ceil(stock[3]*1000)-r+2]
write(OUT/'stock-hull-core.json',{'source_center_mm':list(map(str,center)),'hull_vertices_mm':[list(map(str,p)) for p in ch],'minimum_hull_edge_distance_squared_mm2':str(min(dist)),'contained_hull_disk_radius_um':r,'relaxed_cog_center_bounds_um':cb,'used_for_stock_only':True})
fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};modes=load(ADJ/'modes.json');brcores=[]
for mi in range(36,44):
    m=modes[mi];t={'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']};pieces=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]];rects=[rect_inward(Polygon(source(p,t)).bounds) for p in pieces];g=Polygon(source(parts['bracket']['geometry'][0]['outer'],t));a,b,c,d=g.bounds
    bb=[math.floor((stock[0]-a)*1000)-2,math.floor((stock[1]-b)*1000)-2,math.ceil((stock[2]-c)*1000)+2,math.ceil((stock[3]-d)*1000)+2];brcores.append({'mode':mi,'rectangles_um':rects,'relaxed_anchor_bounds_um':bb})
write(OUT/'bracket-cores.json',brcores);bc={r['mode']:r for r in brcores}
specs=[('38',mi) for mi in range(36,44)]+[(s['geometry_case'],None) for s in survivors if s['geometry_case']!='38'];summaries=[]
for gi,mi in specs:
    name=f'{gi}-'+('cog' if mi is None else f'br{mi}');case=load(INV/'cases'/f'{gi}.json');rr=[r for p in case['fixed10'] for r in fixed[key(p)]];obs=[{'kind':'fixed0','vertices_um':obstacle(r,core)} for r in rr]
    if mi is None:
        obs += [{'kind':'fixed1','vertices_um':obstacle(r,core)} for r in rr]
        obs += [{'kind':'pair','vertices_um':hull([(u[0]-v[0],u[1]-v[1]) for u in core for v in core])}];bb=cb
    else:
        moving=bc[mi]['rectangles_um'];bb=bc[mi]['relaxed_anchor_bounds_um']
        for a,b,c,d in rr:
            for e,f,g,h in moving:obs.append({'kind':'fixed1','vertices_um':[(a-g,b-h),(c-e,b-h),(c-e,d-f),(a-g,d-f)]})
        for a,b,c,d in moving:
            obs.append({'kind':'pair','vertices_um':hull([(u[0]-x,u[1]-y) for u in core for x,y in [(a,b),(c,b),(c,d),(a,d)]])})
    bounds=[cb[0],cb[1],bb[0],bb[1],cb[2],cb[3],bb[2],bb[3]];write(OUT/'cases'/f'{name}-inputs.json',{'geometry_case':gi,'second_mover_bracket_mode':mi,'bounds_um':bounds,'obstacles':obs})
    cert=certificate(bounds,obs,50000,40,start+120);write(OUT/'cases'/f'{name}-certificate.json',cert)
    row={'case':name,'geometry_case':gi,'second_mover_bracket_mode':mi,'covered':cert['covered'],'nodes':len(cert['nodes']),'relaxation_witness_um':cert['relaxation_witness_um'],'limit':cert['limit']};summaries.append(row);print(row,flush=True)
write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-start,'necessary_joint_cases':len(summaries),'covered_cases':sum(r['covered'] for r in summaries),'witness_cases':sum(r['relaxation_witness_um'] is not None for r in summaries),'limited_cases':sum(r['limit'] is not None for r in summaries),'cases':summaries,'independent_audit_pending':True,'source_valid13':False,'source_valid66':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
