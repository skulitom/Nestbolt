"""Partition orthogonal placement domains by the at-most-two cog sites they require empty."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, box, mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import merge_exact
ROOT=Path(__file__).resolve().parents[1];FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';OUT=ROOT/'output/h5-first55-cog-site-masks-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygonal(g):
    if g.is_empty:return Polygon()
    if g.geom_type=='Polygon':return g
    children=[polygonal(p) for p in g.geoms] if hasattr(g,'geoms') else []
    return unary_union([p for p in children if not p.is_empty]) if children else Polygon()
assert load(SLOTS/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');(OUT/'geometries').mkdir();started=time.perf_counter()
library=load(FIRST/'geometry-library.json');all_modes=load(FIRST/'family-modes.json');modes={k:v for k,v in all_modes.items() if k!='cog'};sites=load(SLOTS/'source-cog-sites.json');inventory=load(SLOTS/'inventory.json')
instances=[{'identity':identity,'mode_count':len(modes[identity[0]])} for identity in inventory['moving13_orthogonal_identities']]
assert len(instances)==13 and sum(r['mode_count'] for r in instances)==80
cog=library[10];cgmode=all_modes['cog'][0];anchors=[]
for site in sites:
    assert site['transform']['rotation_radians']==cgmode['rotation_radians'] and site['transform']['mirrored']==cgmode['mirrored']
    anchors.append([site['transform']['translation'][k]-cgmode['translation_from_lower_left'][k] for k in [0,1]])
geometry_modes={m['normalized_geometry']:m for items in modes.values() for m in items};assert set(geometry_modes)==set(range(10))
square=np.asarray([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]])
geometries=[];obstacle_records=[]
for gid in range(10):
    geom=library[gid];mode=geometry_modes[gid];bounds=mode['lower_left_bounds'];domain=[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
    obstacles=[];relative=[]
    for c in cog['pieces']:
        for a in geom['pieces']:
            points=(np.asarray(c)[:,None,:]-np.asarray(a)[None,:,:]).reshape(-1,2)
            relative.append(MultiPoint((points[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    relative=unary_union(relative)
    from shapely.affinity import translate
    for x,y in anchors:obstacles.append(translate(relative,xoff=x,yoff=y))
    states={0:box(*domain)};split_counts=[]
    for slot,obstacle in enumerate(obstacles):
        updated={}
        for mask,space in states.items():
            outside=polygonal(space.difference(obstacle))
            if not outside.is_empty and outside.area>0:updated[mask]=outside
            if mask.bit_count()<2:
                inside=polygonal(space.intersection(obstacle))
                if not inside.is_empty and inside.area>0:updated[mask|(1<<slot)]=inside
        states=updated;split_counts.append({'site':slot,'nonempty_masks':len(states),'retained_area_mm2':sum(g.area for g in states.values())})
    regions=[];masks=[]
    for mask,space in sorted(states.items()):
        triangles=[p for p in shapely.constrained_delaunay_triangles(space).geoms if p.area>0]
        assert all(p.geom_type=='Polygon' and len(p.exterior.coords)==4 for p in triangles)
        convex,merges=merge_exact(triangles) if triangles else ([],0)
        polygons=[Polygon(p) for p in convex];error=unary_union(polygons).symmetric_difference(space).area if polygons else space.area
        assert error<1e-6,(gid,mask,error)
        indices=[]
        for vertices in convex:
            index=len(regions);regions.append({'region':index,'required_empty_mask':mask,'required_empty_sites':[i for i in range(15) if mask&(1<<i)],'vertices':vertices});indices.append(index)
        masks.append({'mask':mask,'required_empty_sites':[i for i in range(15) if mask&(1<<i)],'area_mm2':space.area,'initial_triangles':len(triangles),'exact_convex_merges':merges,'regions':indices,'free_space_coverage_error_mm2':error})
    record={'geometry':gid,'domain':domain,'split_counts':split_counts,'masks':masks,'regions':regions}
    write(OUT/'geometries'/f'{gid:02d}.json',record);geometries.append(record)
    obstacle_records.append({'geometry':gid,'site_obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Geometry preparation cap reached; no model/search may open.'
write(OUT/'obstacles.json',obstacle_records);write(OUT/'family-modes.json',modes);write(OUT/'instances.json',instances);write(OUT/'inventory.json',inventory);write(OUT/'cog-site-lower-lefts.json',anchors)
elapsed=time.perf_counter()-started
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py']+[FIRST/n for n in ['plan.json','family-modes.json','geometry-library.json','audit/plan.json','audit/checks.json']]+[SLOTS/n for n in ['plan.json','checks.json','source-cog-sites.json','inventory.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each of ten orthogonal filled geometries, partition its first-sheet stock domain by fifteen original cog-site Minkowski obstacles inflated with a0.226mm halfwidth square. Track exactly which sites intersect a placement cell and discard cells needing more than the two permitted empty sites. Triangulate and exactly convex-merge each remaining mask cell. A selected placement region implies every site in its mask is empty; globally select exactly two empty sites. All105 site pairs remain simultaneous choices, all13 orthogonal originals and80 source-mode options remain. Independently certify every rounded region against every cog site not in its mask, then audit integer coordinates and all mover-pair constraints before one bounded call. Floating overlay and conservative inflation restrict negative conclusions.','candidate_cog_sites':15,'required_empty_sites':2,'site_pairs_retained':105,'square_half_width_mm':.226,'required_source_gap_mm':.225,'geometry_preparation_cap_seconds':30,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'new_model_created':False,'search_opened':False})
checks={'passed':True,'seconds':elapsed,'moving_originals':13,'source_mode_options':80,'filled_geometries':10,'cog_sites':15,'maximum_required_empty_sites':2,'cached_nonempty_masks':sum(len(g['masks']) for g in geometries),'cached_regions':sum(len(g['regions']) for g in geometries),'expanded_owner_region_choices':sum(sum(len(geometries[i]['regions']) for i in {m['normalized_geometry'] for m in modes[r['identity'][0]]}) for r in instances),'independent_source_region_audit_pending':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
