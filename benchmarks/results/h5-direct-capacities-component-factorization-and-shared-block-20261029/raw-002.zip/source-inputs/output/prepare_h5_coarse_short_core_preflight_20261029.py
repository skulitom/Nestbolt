"""Prepare a distinct 0.1mm necessary lattice and identical-copy x ordering."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-short-core-20261029';OUT=BASE/'coarse-preflight';PRE=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();UNIT=100
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def coarse_bounds(b):return [math.ceil(F(b[0]-50,100)),math.ceil(F(b[1]-50,100)),math.floor(F(b[2]+50,100)),math.floor(F(b[3]+50,100))]
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'search/result.json')['status']=='UNKNOWN' and load(PRE/'audit/checks.json')['passed']
inputs=[Path(__file__),JOB,BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',BASE/'response-audit/unexercised-source-reader-defect.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'inventory.json',PRE/'orthogonal-modes.json',PRE/'cog-core.json',PRE/'cog-rectangle-facets.json',PRE/'cog-pair-facets.json',PRE/'positive-source11.json',PRE/'positive-source11-checks.json',PRE/'negative-source13.json',PRE/'negative-source13-checks.json',OLD/'plan.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A distinct necessary model uses0.1mm anchor coordinates while retaining exact micrometre core rectangles and facet constants. Every actual source-valid placement maps to this coarser lattice because its positive gap exceeds the maximum relative rounding displacement. Transform stock bounds to include every nearest rounded anchor. Add x-order constraints only between identical copies of each family, justified by relabeling their complete poses. All13 originals remain mandatory and movable; all8 bracket and4 insert modes remain. This is not a lossless coarsening of every arbitrary old core witness; it preserves the original source-feasible set through the proved map. The earlier1um solver call stays closed.','anchor_unit_um':100,'source_gap_unchanged':True,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'model_created':False,'search_opened':False,'solver_calls':0,'native_calls':0})
inventory=load(PRE/'inventory.json');modes=load(PRE/'orthogonal-modes.json');coredata=load(PRE/'cog-core.json');core=coredata['vertices_um'];center=list(map(F,coredata['source_center_mm']));cg_bounds=coarse_bounds(inventory['cog_center_stock_bounds_um']);converted=[]
for m in modes:converted.append({**m,'anchor_stock_bounds_grid_units':coarse_bounds(m['anchor_stock_bounds_um'])})
write(OUT/'modes.json',converted);write(OUT/'inventory.json',{**inventory,'anchor_unit_um':UNIT,'cog_center_stock_bounds_grid_units':cg_bounds})
orders=[]
for family in ['bracket','cog','insert']:
    ids=[i for i in inventory['short13_identities'] if i[0]==family]
    for a,b in zip(ids,ids[1:]):orders.append({'left_identity':a,'right_identity':b,'axis':'x','only_enforce_if_both_present':True})
assert len(orders)==10;write(OUT/'orders.json',orders)
bykey={(m['family'],m['quarter'],m['mirrored']):m for m in converted};controls=[];maxerror=F(0)
for name,count in [('positive',11),('negative',13)]:
    source=load(PRE/f'{name}-source{count}.json');mapped=[];shapes=[];keys=set()
    for r in source:
        family=r['part_id'];identity=[family,r['copy_index']];keys.add(tuple(identity));t=r['transform']
        if family=='cog':
            co,si=F(str(math.cos(t['rotation_radians']))),F(str(math.sin(t['rotation_radians'])));tx,ty=map(lambda v:F(str(v)),t['translation']);exact=[(co*center[0]-si*center[1]+tx)*1000,(si*center[0]+co*center[1]+ty)*1000];mode=None;bounds=cg_bounds
        else:
            q=round(t['rotation_radians']/(math.pi/2))%4;m=bykey[family,q,t['mirrored']];exact=[(F(str(t['translation'][i]))-F(str(m['source_translation_offset'][i])))*1000 for i in [0,1]];mode=m['mode'];bounds=m['anchor_stock_bounds_grid_units']
        units=[round(v/UNIT) for v in exact];xy=[v*UNIT for v in units];error=max(abs(F(v)-u) for v,u in zip(xy,exact));assert error<=50;maxerror=max(maxerror,error);assert bounds[0]<=units[0]<=bounds[2] and bounds[1]<=units[1]<=bounds[3]
        if family=='cog':rr=[];gg=[Polygon([(x+xy[0],y+xy[1]) for x,y in core])]
        else:rr=[[a+xy[0],b+xy[1],c+xy[0],d+xy[1]] for a,b,c,d in m['rectangles_um']];gg=[box(*v) for v in rr]
        mapped.append({'identity':identity,'family':family,'mode':mode,'source_anchor_um_exact':list(map(str,exact)),'anchor_grid_units':units,'anchor_um':xy,'stock_bounds_grid_units':bounds,'world_rectangles_um':rr});shapes.append((family,gg))
    mm={tuple(r['identity']):r for r in mapped};activeorders=0
    for o in orders:
        a,b=tuple(o['left_identity']),tuple(o['right_identity'])
        if a in mm and b in mm:assert mm[a]['anchor_grid_units'][0]<=mm[b]['anchor_grid_units'][0];activeorders+=1
    collisions={'orthogonal_piece_pairs':0,'cog_rectangle_pairs':0,'cog_pair':0}
    for (fa,aa),(fb,bb) in combinations(shapes,2):
        label='cog_pair' if fa==fb=='cog' else 'cog_rectangle_pairs' if 'cog' in [fa,fb] else 'orthogonal_piece_pairs'
        for a in aa:
            for b in bb:collisions[label]+=int(not a.disjoint(b) if 'cog' in [fa,fb] else a.intersection(b).area>0)
    if name=='positive':assert not any(collisions.values())
    else:assert all(collisions.values())
    write(OUT/f'{name}-core{count}.json',mapped);controls.append({'name':name,'originals':count,'active_order_constraints':activeorders,'core_collisions':collisions})
gap=F(str(load(OLD/'plan.json')['required_pair_gap_mm']))*1000;assert F(70711,1000)**2>2*50**2 and gap>F(141422,1000)
write(OUT/'source-mapping-proof.json',{'anchor_grid_um':100,'maximum_per_coordinate_rounding_um':50,'single_original_translation_bound_um':'70.711','pair_relative_translation_bound_um':'141.422','original_required_gap_um':str(gap),'rounding_argument':'Nearest0.1mm rounding moves each coordinate by at most50um. Its Euclidean displacement is less than70.711um, so the relative displacement of two originals is less than141.422um, below the unchanged211.70867250963943um required gap. The same strictly source-contained core pieces therefore stay disjoint. Keep core coordinates and no-fit facets in exact micrometres; only anchor variables use100um steps. New grid bounds are ceil((old_lower-50)/100) and floor((old_upper+50)/100), which contain every nearest rounded source anchor because the old bounds already contained every source anchor.',
 'copy_order_argument':'The benchmark defines one shared geometry, legal transformations and cutting parameters per part family, with a quantity of identical copies. Permuting the complete mode/anchor assignments among the mandatory short-sheet copies of one family preserves every source polygon, cutout, stock condition and pair gap; the selected short identities and first-sheet complement remain the same. Sort each family by normalized x anchor (cog center x for cogs), with any tie order. Nearest-grid rounding is monotone, so ten adjacent nondecreasing x inequalities do not exclude a source-feasible allocation. No cross-family ordering is imposed.',
 'limitations':'This does not preserve every1um core-only witness, and a coarse core solution is not an original source layout. The first53 originals still require placements. The old UNKNOWN call is not retried. A new model must be independently audited before its own frozen call. Future candidate readers must parse exact rational centers through Fraction and normalize expected identity pairs to tuples.'})
write(OUT/'controls.json',controls);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'anchor_unit_um':100,'all13_mandatory_and_independently_movable':True,'all8_bracket_and4_insert_modes_retained':True,'core_geometry_and_facet_units_remain_micrometres':True,'identical_copy_x_orders':10,'positive_source11_core_and8_active_orders_passed':True,'negative_source13_core_rejected_and10_orders_passed':True,'maximum_control_coordinate_rounding_error_um':str(maxerror),'source_gap_um':str(gap),'relative_rounding_bound_um':'141.422','source_feasibility_preserving_mapping_proved':True,'old_core_witness_set_preservation_claimed':False,'independent_preflight_audit_pending':True,'model_created':False,'search_opened':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
