"""New fixed-nine inventory with all-angle stock and single-cog necessary coverage."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import json,shutil,time
from prove_h5_short_exchange_all_angle_20261028 import obstacle,certificate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short-fixed9-inventory-20261029';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';JOINT=ROOT/'output/h5-short-joint-core-20261028';PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'cases').mkdir();(OUT/'source-checks').mkdir();(OUT/'obstacles').mkdir();(OUT/'certificates').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(JOINT/'audit/checks.json')['passed'] and load(JOINT/'audit/checks.json')['combined_fixed10_geometries_excluded']==51
inputs=[Path(__file__),ROOT/'output/prove_h5_short_exchange_all_angle_20261028.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,OLD/'plan.json',BOUND/'moving-core.json',BOUND/'fixed-core-rectangles.json',BOUND/'audit/plan.json',BOUND/'audit/checks.json',JOINT/'audit/plan.json',JOINT/'audit/checks.json',JOINT/'stock-hull-core.json',PRE/'parent-source12.json']+sorted((OLD/'cases').glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each of six parent brackets sent to the first sheet, release two additional distinct originals from the remaining eleven. Keep their identities mandatory as short-sheet movers alongside cog0 and insert0. Deduplicate by the unordered three removed parent identities. Reconstruct every fixed-nine source layout and its complete source-core no-fit predicates. Use the previously proved all-angle convex-hull stock bound, with the smaller filled-source core for collision. Each single-cog coverage test stops at its first necessary relaxation witness, full coverage,50000 nodes or depth30. No witness is a source-valid placement.','maximum_nodes_per_geometry':50000,'maximum_depth':30,'short_target_counts':[5,6,2],'first_target_counts':[18,7,15,13],'retry_permitted':False,'construction_calls':0,'solver_calls':0,'native_calls':0})
job=load(JOB);allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};parent=load(PRE/'parent-source12.json');sourceplan=load(OLD/'plan.json');core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};bounds=load(JOINT/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];groups={};variants=[]
for primary in [3,4,7,8,10,11]:
    remaining=sorted([p for p in parent if key(p)!=('bracket',primary)],key=key)
    for extra in combinations(remaining,2):
        removed=tuple(sorted([('bracket',primary)]+[key(p) for p in extra]));rows=[p for p in parent if key(p) not in removed];movers=[key(p) for p in extra]+[('cog',0),('insert',0)];ss={key(p) for p in rows}|set(movers);fs=allids-ss
        assert len(rows)==9 and len(ss)==13 and len(fs)==53 and not {key(p) for p in rows}&set(movers)
        assert Counter(k[0] for k in ss)=={'bracket':5,'insert':6,'cog':2} and Counter(k[0] for k in fs)=={'frame':18,'bracket':7,'insert':15,'cog':13}
        v={'index':len(variants),'primary_bracket_to_first':primary,'extra_released_originals':[key(p) for p in extra],'moving_short_originals':movers,'mandatory_short_identities':sorted(ss),'mandatory_first_identities':sorted(fs),'removed_parent_identities':removed,'all66_accounted_once':True};variants.append(v);groups.setdefault(removed,{'fixed9':rows,'variants':[]})['variants'].append(v['index'])
assert len(variants)==330 and len(groups)==200
summaries=[]
for i,(removed,g) in enumerate(sorted(groups.items())):
    name=f'{i:03d}';rows=g['fixed9'];sourcecheck=audit(job,rows,{'sheet-1':sourceplan['source_stock']},sourceplan['required_pair_gap_mm'],sourceplan['stock_guard_mm'],[key(p) for p in rows]);assert sourcecheck['valid'];write(OUT/'source-checks'/f'{name}.json',sourcecheck)
    for vi in g['variants']:variants[vi]['geometry_case']=name
    write(OUT/'cases'/f'{name}.json',{'geometry_case':name,'removed_parent_identities':removed,'fixed9':rows,'inventory_variant_indices':g['variants']});obs=[obstacle(r,core) for p in rows for r in fixed[key(p)]];write(OUT/'obstacles'/f'{name}.json',obs);cert=certificate(bounds,obs,50000,30);write(OUT/'certificates'/f'{name}.json',cert)
    summaries.append({'geometry_case':name,'removed_parent_identities':removed,'inventory_variants':g['variants'],'necessary_obstacles':len(obs),'nodes':len(cert['nodes']),'all_angle_additional_cog_excluded':cert['covered'],'relaxation_witness_um':cert['relaxation_witness_um'],'limit':cert['limit']})
write(OUT/'inventory-variants.json',variants);write(OUT/'case-summary.json',summaries)
write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-start,'identity_variants':330,'distinct_fixed9_geometries':200,'source_valid_fixed9_cases':200,'necessary_single_cog_excluded_geometries':sum(s['all_angle_additional_cog_excluded'] for s in summaries),'necessary_core_witness_geometries':sum(s['relaxation_witness_um'] is not None for s in summaries),'limited_geometries':sum(s['limit'] is not None for s in summaries),'covered_inventory_variants':sum(len(s['inventory_variants']) for s in summaries if s['all_angle_additional_cog_excluded']),'unexcluded_inventory_variants':sum(len(s['inventory_variants']) for s in summaries if not s['all_angle_additional_cog_excluded']),'relaxed_center_bounds_um':bounds,'independent_audit_pending':True,'construction_calls':0,'solver_calls':0,'native_calls':0,'full_allocation_or_original_job_excluded':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
