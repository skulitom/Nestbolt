"""Freeze one short11 call and an explicit11/55 source candidate reader."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();assert load(BASE/'model-audit/checks.json')['passed']
oldrun=ROOT/'output/run_h5_minimum_two_cog_core_20261029.py';oldcheck=ROOT/'output/check_h5_minimum_two_cog_candidate_20261029.py';runner=oldrun.read_text(encoding='utf-8');checker=oldcheck.read_text(encoding='utf-8')
runner=runner.replace("output/h5-five-bracket-two-cog-core-20261029'","output/h5-source-projection-short11-20261029'").replace('check_h5_minimum_two_cog_candidate_20261029','check_h5_source_projection_short11_candidate_20261029').replace('short7','short11').replace('source_valid7','source_valid11')
checker=checker.replace("output/h5-five-bracket-two-cog-core-20261029'","output/h5-source-projection-short11-20261029'");old="    if item['family']=='insert':\n        assert values[item['presence']]==0";new="    if item['index'] in mp['inactive_short_owners']:\n        assert item['family']=='insert' and values[item['presence']]==0";assert old in checker;checker=checker.replace(old,new)
for a,b in [('short7','short11'),('source7','source11'),('core7','core11'),('source_valid7','source_valid11'),('first59','first55'),('all7','all11'),('len(orth)==5','len(orth)==9'),('len(decoded)==7','len(decoded)==11'),('len(shortids)==7','len(shortids)==11'),('len(firstids)==59','len(firstids)==55'),("'originals':7","'originals':11"),('orthogonal-source5','orthogonal-source9'),('orthogonal_source5','orthogonal_source9')]:checker=checker.replace(a,b)
assert 'source_valid11' in runner and 'source_valid11' in checker and 'short7' not in checker and 'first59' not in checker and "len(shortids)==11 and len(firstids)==55" in checker
newrun=ROOT/'output/run_h5_source_projection_short11_20261029.py';newcheck=ROOT/'output/check_h5_source_projection_short11_candidate_20261029.py'
for p,s in [(newrun,runner),(newcheck,checker)]:compile(s,str(p),'exec');assert not p.exists()
for p,s in [(newrun,runner),(newcheck,checker)]:
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
out=BASE/'call-preparation';out.mkdir();inputs=[Path(__file__),oldrun,oldcheck,newrun,newcheck,BASE/'plan.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'preflight/plan.json']
with (out/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'short_required':11,'first_required':55,'inactive_short_owners':[7,8],'source_candidate_pipeline_not_yet_exercised':True,'solver_calls':0},f,indent=2);f.write('\n')
print('Distinct short11 runner and11/55 identity reader ready; no call opened.')
