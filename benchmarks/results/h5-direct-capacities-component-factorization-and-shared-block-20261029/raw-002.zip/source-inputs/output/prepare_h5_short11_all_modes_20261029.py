"""Prepare legal orthogonal orientation choices for the next broader construction."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, math, shutil, time
from shapely.geometry import Polygon
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
PRIOR = ROOT / 'output/h5-short11-region-convex-hull-model-20261029'
PART = ROOT / 'output/h5-short11-cycle-guided-axis-choices-20261029/core-teeth-partition-preflight'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
OUT = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def cyclic_key(vertices):
    rows = [tuple(p) for p in vertices]
    candidates = []
    for sequence in [rows, list(reversed(rows))]:
        candidates.extend(tuple(sequence[i:]+sequence[:i]) for i in range(len(sequence)))
    return min(candidates)

assert load(PRIOR / 'response-audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'prepare.py')
started = time.perf_counter()
job = load(JOB)
parts = {p['id']: p for p in job['parts']}
canonical = load(SOURCE / 'canonical-pieces.json')
inventory = load(SOURCE / 'inventory.json')
stock = load(STOCK)['source_stock']
width, height = stock[2]-stock[0]-.05, stock[3]-stock[1]-.05
family_modes = {}
geometry_keys = {}
geometry_library = []
maximum_coverage_error = maximum_source_pose_error = 0.
for family in ['bracket', 'insert', 'cog']:
    part = parts[family]
    if family == 'cog':
        assert part['rotations']['kind'] == 'free' and not part['allow_mirror']
        specifications = [(7., False)]
    else:
        degrees = part['rotations']['degrees']
        assert set(degrees) == {0, 90, 180, 270}
        specifications = [(float(angle), mirrored) for mirrored in ([False, True] if part['allow_mirror'] else [False]) for angle in degrees]
    modes = []
    for mode_index, (angle, mirrored) in enumerate(specifications):
        radians = math.radians(angle)
        if family == 'cog':
            cosine, sine = math.cos(radians), math.sin(radians)
        else:
            cosine, sine = [(1, 0), (0, 1), (-1, 0), (0, -1)][int(angle)//90]
        mirror = -1 if mirrored else 1
        def rotate(vertices):
            return [[mirror*x*cosine-y*sine, mirror*x*sine+y*cosine] for x, y in vertices]
        raw = rotate(part['geometry'][0]['outer'])
        minx, miny = min(x for x, y in raw), min(y for x, y in raw)
        outline = [[x-minx, y-miny] for x, y in raw]
        pieces = [[[x-minx, y-miny] for x, y in rotate(p)] for p in canonical[family]]
        dimensions = [max(x for x, y in outline), max(y for x, y in outline)]
        assert dimensions[0] < width and dimensions[1] < height
        coverage = Polygon(outline).symmetric_difference(unary_union([Polygon(p) for p in pieces])).area
        assert coverage < 1e-7
        maximum_coverage_error = max(maximum_coverage_error, coverage)
        # Record exact quarter-turn matrices; original-source readback retains the
        # legal angle and mirror flag and its ordinary floating-point transform.
        actual_c, actual_s = math.cos(radians), math.sin(radians)
        for (x, y), (a, b) in zip(part['geometry'][0]['outer'], outline):
            maximum_source_pose_error = max(maximum_source_pose_error,
                abs(mirror*x*actual_c-y*actual_s-minx-a), abs(mirror*x*actual_s+y*actual_c-miny-b))
        key = (family, cyclic_key(outline))
        if key not in geometry_keys:
            geometry_keys[key] = len(geometry_library)
            geometry_library.append({'id': len(geometry_library), 'family': family, 'outer': outline, 'pieces': pieces, 'dimensions': dimensions})
        modes.append({'mode': mode_index, 'rotation_degrees': angle, 'rotation_radians': radians,
                      'mirrored': mirrored, 'normalized_geometry': geometry_keys[key],
                      'translation_from_lower_left': [-minx, -miny],
                      'lower_left_bounds': [[stock[0]+.025, stock[2]-.025-dimensions[0]],
                                            [stock[1]+.025, stock[3]-.025-dimensions[1]]]})
    family_modes[family] = modes
assert [len(family_modes[f]) for f in ['bracket', 'insert', 'cog']] == [8, 4, 1]
assert len(geometry_library) == 11
short = list(map(tuple, inventory['short11_identities']))
first = list(map(tuple, inventory['mandatory_first55_identities']))
all_ids = {(p['id'], i) for p in job['parts'] for i in range(p['quantity'])}
assert len(short) == 11 and len(first) == 55 and not set(short) & set(first) and set(short+first) == all_ids
instances = [{'identity': list(identity), 'mode_count': len(family_modes[identity[0]])} for identity in short]
assert sum(r['mode_count'] for r in instances) == 58
write(OUT / 'family-modes.json', family_modes)
write(OUT / 'geometry-library.json', geometry_library)
write(OUT / 'instances.json', instances)
shutil.copyfile(SOURCE / 'inventory.json', OUT / 'inventory.json')
inputs = [Path(__file__), JOB, STOCK, PART / 'audit/plan.json', PART / 'audit/checks.json',
          SOURCE / 'plan.json', SOURCE / 'canonical-pieces.json', SOURCE / 'inventory.json',
          PRIOR / 'response-audit/plan.json', PRIOR / 'response-audit/checks.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'Next construction broadens all five brackets to every legal quarter-turn and mirror combination and all four inserts to every legal quarter-turn. The two cogs retain a declared 7-degree phase; no claim covers all free cog angles. Mode-specific lower-left stock domains preserve 0.025 mm clearance. Identical filled outer geometry is shared in an 11-entry library, while all legal source transforms and original holes remain distinct for final readback. Prepare and audit pair-mode free regions and their original-source support certificates; then couple each pair-region selector to both selected owner modes and verify the full model before declaring a new bounded call. Preserve every closed fixed-mode call. Full66 source/native/material checks, production integration and H5 matrix remain.',
    'new_model_created': False, 'search_opened': False, 'solver_calls': 0,
})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'short_originals': 11, 'mandatory_first_originals': 55,
          'bracket_modes_per_original': 8, 'insert_modes_per_original': 4, 'cog_phases_per_original': 1,
          'total_instance_mode_options': 58, 'unique_filled_geometries': 11,
          'maximum_source_partition_difference_mm2': maximum_coverage_error,
          'maximum_quarter_turn_source_pose_difference_mm': maximum_source_pose_error,
          'all_declared_modes_fit_short_stock_individually': True, 'independent_mode_audit_pending': True,
          'cog_phase_fixed_degrees': 7, 'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
