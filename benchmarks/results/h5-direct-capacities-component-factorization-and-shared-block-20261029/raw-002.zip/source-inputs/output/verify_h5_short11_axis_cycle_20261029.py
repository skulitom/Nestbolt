"""Independently reconstruct and sum the eight selected exact difference inequalities."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';PRE=BASE/'source-translation-preflight';AUDIT=BASE/'source-translation-audit';OUT=BASE/'source-translation-cycle-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'verify.py');assert load(AUDIT/'checks.json')['passed'];data=load(AUDIT/'axis-subsystem.json');planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');world=load(PRE/'world-pieces.json');indices=data['negative_cycle_edge_indices'];assert len(indices)==8;net=[0]*23;total=F(0);details=[];branchplanes=[]
for index in indices:
    e=data['edges'][index];src=e['source'];kind=src['kind']
    if kind=='stock_upper':v=src['variable'];assert e['from']==22 and e['to']==v;weight=F(bounds[v][1])
    elif kind=='stock_lower':v=src['variable'];assert e['from']==v and e['to']==22;weight=-F(bounds[v][0])
    else:
        assert kind=='conservative_axis_projection';plane=planes[src['plane']];axis=src['axis'];sign=src['normal_sign'];a,b=plane['owners'];n=list(map(F,plane['normal']));assert axis in [0,1] and sign in [-1,1];correction=F(0)
        for d in [0,1]:
            k=F(sign if d==axis else 0)-n[d];endpoints=[F(bounds[2*a+d][0])-F(bounds[2*b+d][1]),F(bounds[2*a+d][1])-F(bounds[2*b+d][0])];correction+=max(k*x for x in endpoints)
        assert correction==F(src['coefficient_error_allowance_mm']);weight=F(plane['upper_delta_difference_mm'])+correction+F(1,10**9);expected=(2*b+axis,2*a+axis) if sign==1 else (2*a+axis,2*b+axis);assert (e['from'],e['to'])==expected;branchplanes.append(src['plane'])
    assert weight==F(e['weight']);total+=weight;net[e['to']]+=1;net[e['from']]-=1;details.append({'edge':index,'from':'stock-origin' if e['from']==22 else [world[e['from']//2]['identity'],'xy'[e['from']%2]],'to':'stock-origin' if e['to']==22 else [world[e['to']//2]['identity'],'xy'[e['to']%2]],'weight_mm':str(weight),'weight_mm_approx':float(weight),'source':src})
assert not any(net) and total==F(data['negative_cycle_sum_mm']) and total<0;assert all(data['edges'][indices[i]]['to']==data['edges'][indices[(i+1)%8]]['from'] for i in range(8));write(OUT/'certificate.json',{'edges':details,'summed_left_coefficients':net,'summed_right_hand_side_mm':str(total),'summed_right_hand_side_mm_approx':float(total),'contradiction':'0 is at most a strictly negative rational number','constrained_branch_plane_indices':branchplanes,'scope':'These six chosen piece-pair axis branches and two stock bounds are inconsistent, even with arbitrary translations of all eleven parts. At least one chosen branch or an orientation must change. The parent allocation remains open; this certificate does not exclude different branch selections or cog phases.'})
inputs=[Path(__file__),AUDIT/'plan.json',AUDIT/'checks.json',AUDIT/'axis-subsystem.json',PRE/'planes.json',PRE/'variable-bounds.json',PRE/'world-pieces.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'independent_exact_rational_cycle_verified':True,'cycle_edges':8,'chosen_pair_branches':6,'stock_bounds':2,'all_left_coefficients_cancel':True,'negative_sum_mm':str(total),'negative_sum_mm_approx':float(total),'restricted_frozen_branch_infeasibility_certified':True,'allocation_excluded':False,'source_feasible11_created':False,'remaining_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
