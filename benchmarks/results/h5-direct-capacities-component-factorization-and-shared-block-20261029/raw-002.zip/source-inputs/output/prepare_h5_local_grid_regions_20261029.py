"""Exact conservative local-coordinate unary planes and rigid rectangles on a0.1mm grid."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=ROOT/'output/h5-first55-local-grid-regions-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRIOR/'source-region-audit/checks.json')['passed'] and load(PRIOR/'connected-capacity-bound/audit/checks.json')['passed'] and load(PRIOR/'rigid-rectangle-preflight/audit-v3/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
origin=[F(0),F(2100)];envelope=[F(1500),F(900)];grid=10;scale=10000;epsilon=F('1e-7')
allowed=load(PRIOR/'connected-capacity-bound/audit/allowed-empty-site-pairs.json');allowed_masks=[sum(1<<i for i in pair) for pair in allowed]
modes=load(PRIOR/'family-modes.json');rectangles=load(PRIOR/'rigid-rectangle-preflight/mode-rectangles.json')
converted={family:[{**m,'integer_lower_left_bounds':[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(m['lower_left_bounds'])]} for m in opts] for family,opts in modes.items()}
converted_rectangles={family:[{**m,'rectangles':[{**r,'outward_offsets_grid':[math.floor(F(v)*grid) if i<2 else math.ceil(F(v)*grid) for i,v in enumerate(r['exact_affine_bounds_mm'])]} for r in m['rectangles']]} for m in opts] for family,opts in rectangles.items()}
unary=[];removed=[];max_activity=0;max_error=F(0);planes=0
for old_template in load(PRIOR/'integer-preparation/unary-templates.json'):
    regions=[]
    for old in old_template['regions']:
        if not any(old['required_empty_mask']&~mask==0 for mask in allowed_masks):
            removed.append([old_template['geometry'],old['region']]);continue
        polygon=[tuple(map(F,v)) for v in old['hull_vertices']]
        region={k:old[k] for k in ['region','required_empty_mask','required_empty_sites','hull_vertices']};region['planes']=[]
        for edge,(a,b) in enumerate(zip(polygon,polygon[1:]+polygon[:1])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));assert den>0
            normal=[dy/den,-dx/den];raw=[round(n*scale) for n in normal]
            error=sum(abs(n-F(c,scale))*limit for n,c,limit in zip(normal,raw,envelope));rhs=sum(n*(x-o) for n,x,o in zip(normal,a,origin))
            divisor=math.gcd(*map(abs,raw));assert divisor>0
            coefficients=[v//divisor for v in raw];upper=math.floor((rhs-error-epsilon)*scale*grid)//divisor
            activity=sum(abs(c)*int(limit*grid) for c,limit in zip(coefficients,envelope));assert activity<2**31 and abs(upper)<2**31
            max_activity=max(max_activity,activity);max_error=max(max_error,error);planes+=1
            region['planes'].append({'edge':edge,'exact_infinity_normal':[str(n) for n in normal],'normalization_denominator':str(den),'unreduced_coefficients':raw,'divisor':divisor,'coefficients':coefficients,'upper':upper,'rounding_error_bound_mm':str(error)})
        regions.append(region)
    unary.append({'geometry':old_template['geometry'],'regions':regions})
for name,data in [('family-modes.json',converted),('mode-rectangles.json',converted_rectangles),('unary-templates.json',unary),('removed-regions.json',removed),('allowed-empty-site-pairs.json',allowed)]:write(OUT/name,data)
for name in ['instances.json','inventory.json']:shutil.copyfile(PRIOR/name,OUT/name)
for name in ['components.json','component-pairs.json']:shutil.copyfile(PRIOR/'rigid-rectangle-preflight'/name,OUT/name)
elapsed=time.perf_counter()-started
inputs=[Path(__file__),PRIOR/'plan.json',PRIOR/'checks.json',PRIOR/'family-modes.json',PRIOR/'instances.json',PRIOR/'inventory.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'source-region-audit/plan.json',PRIOR/'source-region-audit/checks.json',PRIOR/'rigid-rectangle-preflight/plan.json',PRIOR/'rigid-rectangle-preflight/mode-rectangles.json',PRIOR/'rigid-rectangle-preflight/components.json',PRIOR/'rigid-rectangle-preflight/component-pairs.json',PRIOR/'rigid-rectangle-preflight/audit-v3/plan.json',PRIOR/'rigid-rectangle-preflight/audit-v3/checks.json',PRIOR/'accessible-area-bound/plan.json',PRIOR/'accessible-area-bound/checks.json',PRIOR/'connected-capacity-bound/plan.json',PRIOR/'connected-capacity-bound/checks.json',PRIOR/'connected-capacity-bound/audit/plan.json',PRIOR/'connected-capacity-bound/audit/checks.json',PRIOR/'connected-capacity-bound/audit/allowed-empty-site-pairs.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use local origin(0,2100)mm,0.1mm position grid and exact rational infinity-normalized edge coefficients rounded at scale10000. Tighten each plane by its exact worst-case normal error over local1500x900mm plus1e-7mm before integer floor. Retain all source modes and all35 site choices. Remove only unary regions whose required-empty mask fits no surviving pair. Outward-round each exact original component rectangle to the same grid and require3grid units(0.3mm) between different-owner rectangles. Independently verify geometry implications and every model field before one new bounded call.','grid_units_per_mm':grid,'normal_scale':scale,'world_origin_mm':[str(v) for v in origin],'local_domain_envelope_mm':[str(v) for v in envelope],'plane_inset_mm':str(epsilon),'rectangle_gap_grid':3,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0,'new_model_created':False})
result={'passed':True,'seconds':elapsed,'retained_cached_regions':sum(len(t['regions']) for t in unary),'removed_cached_regions':len(removed),'integer_planes':planes,'source_mode_options':80,'retained_empty_site_pairs':35,'maximum_integer_plane_activity':max_activity,'maximum_normal_error_bound_mm':float(max_error),'grid_units_per_mm':grid,'normal_scale':scale,'source_region_hulls_unchanged':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'independent_audit_required':True,'H5_complete':False};write(OUT/'checks.json',result);print(result)
