"""One declared 60/90-second convex-combination relative-region construction, with no retry."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, subprocess, sys, time

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-region-convex-hull-model-20261029'
OUT = BASE / 'search'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def child(started):
    import numpy as np
    import scipy
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import csc_matrix
    from h5_legacy64_source_readback import audit
    audit_checks = load(BASE / 'audit/checks.json')
    assert audit_checks['passed'] and digest(BASE / 'model.npz') == audit_checks['model_sha256']
    for folder in [BASE, BASE / 'audit']:
        for name, expected in load(folder / 'plan.json')['inputs'].items():
            assert digest(ROOT / name) == expected, name
    model = np.load(BASE / 'model.npz')
    data, indices, indptr, shape, lower, upper, bounds, objective, integrality = [model[k] for k in ['data', 'indices', 'indptr', 'shape', 'lower', 'upper', 'bounds', 'c', 'integrality']]
    matrix = csc_matrix((data, indices, indptr), shape=tuple(shape))
    groups = load(BASE / 'mapping.json')
    remaining = 60-(time.perf_counter()-started)-3
    assert remaining > 0
    options = {'time_limit': remaining, 'node_limit': 128, 'mip_rel_gap': 0., 'presolve': True, 'disp': True}
    inputs = [Path(__file__), ROOT / 'output/h5_legacy64_source_readback.py', JOB, STOCK,
              BASE / 'plan.json', BASE / 'checks.json', BASE / 'audit/plan.json', BASE / 'audit/checks.json',
              BASE / 'model.npz', BASE / 'mapping.json', BASE / 'seed-source11.json', BASE / 'inventory.json']
    write(OUT / 'opened.json', {
        'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
        'maximum_calls': 1, 'algorithm_seconds': 60, 'shared_seconds': 90,
        'source_validation_reserve_seconds': 3, 'retry_permitted': False, 'node_limit': 128,
        'options': options, 'scipy_version': scipy.__version__, 'model_sha256': digest(BASE / 'model.npz'),
        'preparation_seconds_charged': load(BASE / 'checks.json')['preparation_seconds_charged'],
    })
    begin = time.perf_counter()
    result = milp(objective, integrality=integrality, bounds=Bounds(bounds[:, 0], bounds[:, 1]),
                  constraints=LinearConstraint(matrix, lower, upper), options=options)
    solve = time.perf_counter()-begin
    source_valid = False
    assignment_passed = False
    source_checker_calls = 0
    if result.x is not None:
        values = np.asarray(result.x)
        write(OUT / 'assignment.json', values.tolist())
        assert np.isfinite(values).all() and len(values) == len(bounds)
        evaluated = matrix@values
        lower_error = max(0., float(np.max(lower-evaluated)))
        upper_error = max(0., float(np.max(evaluated-upper)))
        bound_error = max(0., float(np.max(bounds[:, 0]-values)), float(np.max(values-bounds[:, 1])))
        integer_error = float(np.max(np.abs(values[22:717]-np.round(values[22:717]))))
        selected = []
        choices_pass = True
        for group in groups:
            chosen = [r['region'] for r in group['regions'] if values[r['selector']] > .5]
            choices_pass &= len(chosen) == 1
            selected.append({'owners': group['owners'], 'regions': chosen})
        assignment_passed = bool(choices_pass and max(lower_error, upper_error, bound_error, integer_error) <= 1e-6)
        write(OUT / 'assignment-check.json', {
            'passed': assignment_passed, 'tolerance': 1e-6, 'lower_row_error': lower_error,
            'upper_row_error': upper_error, 'bound_error': bound_error, 'integer_error': integer_error,
            'one_region_per_original_pair': choices_pass, 'selected_regions': selected,
        })
        rows = load(BASE / 'seed-source11.json')
        for owner, row in enumerate(rows):
            row['transform']['translation'] = [row['transform']['translation'][axis]+float(values[2*owner+axis]) for axis in [0, 1]]
        stock = load(STOCK)
        expected = list(map(tuple, load(BASE / 'inventory.json')['short11_identities']))
        check = audit(load(JOB), rows, {'sheet-1': stock['source_stock']}, stock['required_pair_gap_mm'], stock['stock_guard_mm'], expected)
        source_checker_calls = 1
        write(OUT / 'candidate-source11.json', rows)
        write(OUT / 'candidate-source11-checks.json', check)
        source_valid = bool(check['valid'] and assignment_passed)
    elapsed = time.perf_counter()-started
    def finite(name):
        value = getattr(result, name, None)
        return float(value) if value is not None and np.isfinite(value) else None
    write(OUT / 'result.json', {
        'closed': True, 'solver_calls': 1, 'status_code': int(result.status), 'success': bool(result.success),
        'message': str(result.message), 'returned_solve_seconds': solve, 'allocated_solve_seconds': remaining,
        'returned_solve_overrun_seconds': max(0, solve-remaining), 'has_assignment': result.x is not None,
        'assignment_passed': assignment_passed, 'objective': finite('fun'), 'mip_node_count': finite('mip_node_count'),
        'mip_gap': finite('mip_gap'), 'mip_dual_bound': finite('mip_dual_bound'),
        'algorithm_seconds_including_preparation': elapsed, 'algorithm_overrun_seconds': max(0, elapsed-60),
        'preparation_seconds_charged': load(BASE / 'checks.json')['preparation_seconds_charged'],
        'source_checker_calls': source_checker_calls, 'source_valid11': source_valid,
        'first55_created': False, 'source_valid66': False, 'any_allocation_excluded': False,
        'native_calls': 0, 'H5_complete': False,
    })

def main():
    assert load(BASE / 'audit/checks.json')['passed']
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'run.py')
    charge = load(BASE / 'checks.json')['preparation_seconds_charged']
    start = time.perf_counter()-charge
    write(OUT / 'budget.json', {
        'utc': datetime.now(timezone.utc).isoformat(), 'algorithm_seconds': 60, 'shared_seconds': 90,
        'maximum_calls': 1, 'node_limit': 128, 'retry_permitted': False,
        'source_validation_reserve_seconds': 3, 'preparation_seconds_charged': charge,
    })
    try:
        process = subprocess.run([str(ROOT / '.cache/shop-venv/Scripts/python.exe'), str(Path(__file__)), '--child', str(start)],
                                 cwd=ROOT, capture_output=True, timeout=max(.01, 90-(time.perf_counter()-start)))
        (OUT / 'stdout.txt').write_bytes(process.stdout)
        (OUT / 'stderr.txt').write_bytes(process.stderr)
        summary = {'seconds_including_preparation': time.perf_counter()-start, 'exit_code': process.returncode, 'timeout': False, 'closed': True}
    except subprocess.TimeoutExpired as error:
        (OUT / 'stdout.txt').write_bytes(error.stdout or b'')
        (OUT / 'stderr.txt').write_bytes(error.stderr or b'')
        summary = {'seconds_including_preparation': time.perf_counter()-start, 'timeout': True, 'closed': True}
    write(OUT / 'process.json', summary)
    print(summary, flush=True)
    print(load(OUT / 'result.json') if (OUT / 'result.json').exists() else 'No final result; the call remains closed.', flush=True)

if __name__ == '__main__':
    child(float(sys.argv[2])) if '--child' in sys.argv else main()
