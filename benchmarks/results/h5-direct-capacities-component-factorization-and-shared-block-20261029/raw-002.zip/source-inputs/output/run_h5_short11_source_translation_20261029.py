"""One fixed-axis source translation LP, with preparation charged to60/90-second limits."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';PRE=BASE/'source-translation-preflight';OUT=BASE/'source-translation-search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child(started):
    import numpy as np
    from scipy.optimize import linprog
    from h5_legacy64_source_readback import audit
    assert load(PRE/'audit/checks.json')['passed']
    for folder in [PRE,PRE/'audit']:
        for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');seed=load(PRE/'seed-source11.json');count=2*len(seed);assert count==22;A=np.zeros((len(planes)+2*count,count+1));b=np.zeros(len(A))
    for k,row in enumerate(planes):
        i,j=row['owners'];A[k,2*i:2*i+2]=row['normal'];A[k,2*j:2*j+2]=-np.asarray(row['normal']);b[k]=row['upper_delta_difference_mm']
    for i in range(count):A[len(planes)+2*i,i]=1;A[len(planes)+2*i,-1]=-1;A[len(planes)+2*i+1,i]=-1;A[len(planes)+2*i+1,-1]=-1
    c=np.zeros(count+1);c[-1]=1;np.savez(OUT/'model.npz',A=A,b=b,c=c,bounds=np.asarray(bounds));remaining=60-(time.perf_counter()-started)-3;assert remaining>0;options={'time_limit':remaining,'presolve':True};inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',PRE/'plan.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'planes.json',PRE/'variable-bounds.json',PRE/'seed-source11.json',BASE/'preflight/inventory.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json'];write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'method':'highs-ds','options':options,'rows':len(A),'variables':len(c),'model_sha256':digest(OUT/'model.npz'),'source_validation_reserve_seconds':3});begin=time.perf_counter();r=linprog(c,A_ub=A,b_ub=b,bounds=bounds,method='highs-ds',options=options);solve=time.perf_counter()-begin;source_valid=False
    if r.x is not None:
        values=r.x.tolist();write(OUT/'assignment.json',values);residual=float(np.max(A@r.x-b));assert residual<1e-7 and all(lo-1e-7<=v<=hi+1e-7 for v,(lo,hi) in zip(r.x,bounds));write(OUT/'assignment-check.json',{'passed':True,'maximum_inequality_residual_mm':residual,'stock_and_max_move_bounds_verified':True});rows=json.loads(json.dumps(seed))
        for i,row in enumerate(rows):row['transform']['translation']=[row['transform']['translation'][k]+values[2*i+k] for k in [0,1]]
        job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');inv=load(BASE/'preflight/inventory.json');check=audit(job,rows,{'sheet-1':sp['source_stock']},sp['required_pair_gap_mm'],sp['stock_guard_mm'],list(map(tuple,inv['short11_identities'])));write(OUT/'candidate-source11.json',rows);write(OUT/'candidate-source11-checks.json',check);source_valid=check['valid']
    elapsed=time.perf_counter()-started;write(OUT/'result.json',{'closed':True,'solver_calls':1,'status_code':int(r.status),'success':bool(r.success),'message':str(r.message),'returned_solve_seconds':solve,'allocated_solve_seconds':remaining,'returned_solve_overrun_seconds':max(0,solve-remaining),'iterations':int(r.nit),'has_assignment':r.x is not None,'objective_max_translation_mm':float(r.fun) if r.fun is not None else None,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0,elapsed-60),'preparation_seconds_charged':load(PRE/'checks.json')['seconds'],'source_valid11':source_valid,'first55_created':False,'source_valid66':False,'any_allocation_excluded':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');charge=load(PRE/'checks.json')['seconds'];start=time.perf_counter()-charge;write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'preparation_seconds_charged':charge,'source_validation_reserve_seconds':3})
    try:
        r=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child',str(start)],cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-start)));(OUT/'stdout.txt').write_bytes(r.stdout);(OUT/'stderr.txt').write_bytes(r.stderr);process={'seconds_including_preparation':time.perf_counter()-start,'exit_code':r.returncode,'timeout':False,'closed':True}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds_including_preparation':time.perf_counter()-start,'timeout':True,'closed':True}
    write(OUT/'process.json',process);print(process,flush=True);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final result; this call remains closed.',flush=True)
if __name__=='__main__':child(float(sys.argv[2])) if '--child' in sys.argv else main()
