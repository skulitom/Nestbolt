"""Bounded required-pair predicates for the 56 surviving fixed-nine source layouts."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
from prove_h5_short_exchange_all_angle_20261028 import hull,obstacle
from h5_joint_core_coverage_20261028 import certificate
ROOT=Path(__file__).resolve().parents[1];INV=ROOT/'output/h5-short-fixed9-inventory-20261029';PRE=ROOT/'output/h5-short-joint-core-20261028';BOUND=ROOT/'output/h5-short-two-cog-exchange-20261028/all-angle-bound';OUT=ROOT/'output/h5-short-fixed9-joint-20261029';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter();assert load(INV/'audit/checks.json')['passed'] and load(PRE/'audit/checks.json')['passed']
survivors=[s for s in load(INV/'case-summary.json') if not s['all_angle_additional_cog_excluded']];assert len(survivors)==56
specs=[]
for s in survivors:
    counts=Counter(k[0] for k in s['removed_parent_identities']);gi=s['geometry_case']
    if counts['cog']:specs.append((gi,None))
    if counts['bracket']>=2:specs.extend((gi,mi) for mi in range(36,44))
assert len(specs)==253
inputs=[Path(__file__),ROOT/'output/prove_h5_short_exchange_all_angle_20261028.py',ROOT/'output/h5_joint_core_coverage_20261028.py',INV/'audit/plan.json',INV/'audit/checks.json',INV/'case-summary.json',INV/'inventory-variants.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'stock-hull-core.json',PRE/'bracket-cores.json',BOUND/'moving-core.json',BOUND/'fixed-core-rectangles.json']+[INV/'cases'/f"{s['geometry_case']}.json" for s in survivors]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each single-cog survivor in ascending geometry order, test cog/cog if the parent cog was released, and all eight cog/bracket modes if at least one additional bracket must be returned. Execute both families when both are required. Reuse only the byte-verified all-angle stock disk, filled-source cog core and strict bracket/fixed rectangles; rebuild all fixed-nine constraints. A geometry closes if its cog/cog domain is covered or every legal bracket mode is covered. Otherwise it remains unexcluded, even if separate pair witnesses exist. No witness certifies originals or joint compatibility with remaining movers.','required_pair_cases':253,'max_nodes_per_case':50000,'max_depth':40,'shared_proof_wall_seconds':120,'retry_permitted':False,'construction_calls':0,'solver_calls':0,'native_calls':0})
core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};cb=load(PRE/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];bc={r['mode']:r for r in load(PRE/'bracket-cores.json')};rows=[]
for gi,mi in specs:
    name=f'{gi}-'+('cog' if mi is None else f'br{mi}');case=load(INV/'cases'/f'{gi}.json');rr=[r for p in case['fixed9'] for r in fixed[key(p)]];obs=[{'kind':'fixed0','vertices_um':obstacle(r,core)} for r in rr]
    if mi is None:
        obs.extend({'kind':'fixed1','vertices_um':obstacle(r,core)} for r in rr);obs.append({'kind':'pair','vertices_um':hull([(u[0]-v[0],u[1]-v[1]) for u in core for v in core])});bb=cb
    else:
        moving=bc[mi]['rectangles_um'];bb=bc[mi]['relaxed_anchor_bounds_um']
        for a,b,c,d in rr:
            for e,f,g,h in moving:obs.append({'kind':'fixed1','vertices_um':[(a-g,b-h),(c-e,b-h),(c-e,d-f),(a-g,d-f)]})
        for a,b,c,d in moving:obs.append({'kind':'pair','vertices_um':hull([(u-x,v-y) for u,v in core for x,y in [(a,b),(c,b),(c,d),(a,d)]])})
    bounds=[cb[0],cb[1],bb[0],bb[1],cb[2],cb[3],bb[2],bb[3]];write(OUT/'cases'/f'{name}-inputs.json',{'geometry_case':gi,'second_mover_bracket_mode':mi,'bounds_um':bounds,'obstacles':obs});cert=certificate(bounds,obs,50000,40,start+120);write(OUT/'cases'/f'{name}-certificate.json',cert);rows.append({'case':name,'geometry_case':gi,'second_mover_bracket_mode':mi,'covered':cert['covered'],'nodes':len(cert['nodes']),'relaxation_witness_um':cert['relaxation_witness_um'],'limit':cert['limit']})
    if len(rows)%40==0:print({'joint_cases':len(rows),'seconds':time.perf_counter()-start},flush=True)
summary=[]
for s in survivors:
    found=[r for r in rows if r['geometry_case']==s['geometry_case']];cg=[r for r in found if r['second_mover_bracket_mode'] is None];br=[r for r in found if r['second_mover_bracket_mode'] is not None];closed=bool(cg and cg[0]['covered']) or bool(len(br)==8 and all(r['covered'] for r in br));summary.append({'geometry_case':s['geometry_case'],'removed_parent_identities':s['removed_parent_identities'],'inventory_variants':s['inventory_variants'],'required_joint_cases':len(found),'cog_pair_excluded':bool(cg and cg[0]['covered']),'all_bracket_modes_excluded':bool(len(br)==8 and all(r['covered'] for r in br)),'geometry_excluded':closed,'unexcluded_pair_modes':[r['second_mover_bracket_mode'] for r in found if not r['covered']]})
write(OUT/'case-summary.json',rows);write(OUT/'geometry-summary.json',summary);write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-start,'joint_cases':len(rows),'covered_pair_cases':sum(r['covered'] for r in rows),'pair_witness_cases':sum(r['relaxation_witness_um'] is not None for r in rows),'limited_pair_cases':sum(r['limit'] is not None for r in rows),'input_geometries':56,'additional_excluded_geometries':sum(s['geometry_excluded'] for s in summary),'remaining_unexcluded_geometries':sum(not s['geometry_excluded'] for s in summary),'additional_excluded_identity_variants':sum(len(s['inventory_variants']) for s in summary if s['geometry_excluded']),'remaining_unexcluded_identity_variants':sum(len(s['inventory_variants']) for s in summary if not s['geometry_excluded']),'independent_audit_pending':True,'construction_calls':0,'solver_calls':0,'native_calls':0,'full_allocation_or_original_job_excluded':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
