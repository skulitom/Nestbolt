"""Integer unary placement planes and unchanged certified orthogonal pair templates."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json, math, shutil, time
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'integer-preparation';PRIOR=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'source-region-audit/checks.json')['passed'] and load(PRIOR/'geometry-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();grid=1000;scale=10**9
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');converted={family:[{**m,'integer_lower_left_bounds':[[math.ceil(F(lo)*grid),math.floor(F(hi)*grid)] for lo,hi in m['lower_left_bounds']]} for m in items] for family,items in modes.items()}
unary=[];planes=0
for gid in range(10):
    data=load(BASE/'geometries'/f'{gid:02d}.json');regions=[]
    for old in data['regions']:
        polygon=hull([tuple(F(round(v,9)) for v in p) for p in old['vertices']]);assert len(polygon)>=3
        region={'region':old['region'],'required_empty_mask':old['required_empty_mask'],'required_empty_sites':old['required_empty_sites'],'hull_vertices':[[str(x),str(y)] for x,y in polygon],'planes':[]}
        for edge,(a,b) in enumerate(zip(polygon,polygon[1:]+polygon[:1])):
            dx,dy=b[0]-a[0],b[1]-a[1];length=F(math.hypot(float(dx),float(dy)));normal=[dy/length,-dx/length];raw=[round(v*scale) for v in normal]
            error=sum(abs(n-F(c,scale))*limit for n,c,limit in zip(normal,raw,[1500,3000]));rhs=sum(n*x for n,x in zip(normal,a));divisor=math.gcd(abs(raw[0]),abs(raw[1]));assert divisor>0
            coefficients=[c//divisor for c in raw];upper=math.floor((rhs-error-F('1e-7'))*scale*grid)//divisor
            assert sum(abs(c)*limit for c,limit in zip(coefficients,[1500000,3000000]))<2**62 and abs(upper)<2**62
            region['planes'].append({'edge':edge,'coefficients':coefficients,'upper':upper,'unreduced_coefficients':raw,'divisor':divisor,'rounding_error_bound_mm':str(error)});planes+=1
        regions.append(region)
    unary.append({'geometry':gid,'regions':regions})
old_templates=load(PRIOR/'integer-templates.json');needed=sorted(i for i,t in enumerate(old_templates) if all(g<10 for g in t['geometries']));templates=[old_templates[i] for i in needed];lookup={tuple(t['geometries']):i for i,t in enumerate(templates)}
owner_pairs=[]
for ia,ib in combinations(range(13),2):
    options=[sorted({m['normalized_geometry'] for m in modes[instances[i]['identity'][0]]}) for i in [ia,ib]]
    keys=list(product(*options));owner_pairs.append({'owners':[ia,ib],'identities':[instances[i]['identity'] for i in [ia,ib]],'geometry_pairs':[list(k) for k in keys],'template_indices':[lookup[k] for k in keys]})
assert len(templates)==84 and len(owner_pairs)==78
for name,value in [('family-modes.json',converted),('unary-templates.json',unary),('pair-templates.json',templates),('pair-template-prior-indices.json',needed),('owner-pairs.json',owner_pairs)]:write(OUT/name,value)
elapsed=time.perf_counter()-started
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',BASE/'plan.json',BASE/'checks.json',BASE/'family-modes.json',BASE/'instances.json',BASE/'source-region-audit/plan.json',BASE/'source-region-audit/checks.json',PRIOR/'plan.json',PRIOR/'integer-templates.json',PRIOR/'geometry-audit/plan.json',PRIOR/'geometry-audit/checks.json']+[BASE/'geometries'/f'{i:02d}.json' for i in range(10)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Convert every source-certified unary region to inward integer halfplanes on a1micrometre grid. Bound normal quantization over absolute lower-left coordinates0..1500mm X and0..3000mm Y, tighten by that error plus1e-7mm, and round domains inward. Reuse the84 previously certified orthogonal-pair templates byte-for-byte, remapping only their template indices and the13 original owners. Independently audit all integer implications and identity/template mappings before building a new model.','grid_units_per_mm':grid,'normal_scale':scale,'absolute_unary_domain_envelope_mm':[1500,3000],'relative_pair_domain_envelope_mm':[1500,900],'solver_calls':0})
result={'passed':True,'seconds':elapsed,'unary_regions':sum(len(t['regions']) for t in unary),'unary_integer_planes':planes,'source_mode_options':80,'pair_templates':84,'original_mover_pairs':78,'expanded_pair_geometry_cases':sum(len(p['template_indices']) for p in owner_pairs),'pair_region_selectors':sum(len(templates[i]['regions']) for p in owner_pairs for i in p['template_indices']),'independent_integer_audit_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
