"""Conservative integer halfplanes for the audited variable-orientation free regions."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, math, shutil, time
from h5_exact_convex_partition_tools_20261029 import hull

ROOT = Path(__file__).resolve().parents[1]
MODES = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
REGIONS = MODES / 'pair-region-preflight'
PRIOR = ROOT / 'output/h5-short11-all-mode-region-model-20261029'
OUT = ROOT / 'output/h5-short11-integer-mode-regions-20261029'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
GRID = 1000
SCALE = 1_000_000_000

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(PRIOR / 'response-audit/checks.json')['passed'] and load(REGIONS / 'audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'prepare.py')
started = time.perf_counter()
family_modes = load(MODES / 'family-modes.json')
templates = load(REGIONS / 'templates.json')
integer_modes = {}
for family, modes in family_modes.items():
    integer_modes[family] = [{**mode, 'integer_lower_left_bounds': [[math.ceil(F(lo)*GRID), math.floor(F(hi)*GRID)] for lo, hi in mode['lower_left_bounds']]} for mode in modes]
    assert all(lo < hi for m in integer_modes[family] for lo, hi in m['integer_lower_left_bounds'])
integer_templates = []
plane_count = 0
for template in templates:
    record = {'geometries': template['geometries'], 'regions': []}
    for index, vertices in enumerate(template['regions']):
        rounded = [tuple(F(round(v, 9)) for v in point) for point in vertices]
        polygon = hull(rounded)
        assert len(polygon) >= 3
        region = {'region': index, 'hull_vertices': [[str(x), str(y)] for x, y in polygon], 'planes': []}
        for edge, (a, b) in enumerate(zip(polygon, polygon[1:]+polygon[:1])):
            dx, dy = b[0]-a[0], b[1]-a[1]
            length = F(math.hypot(float(dx), float(dy)))
            exact = [dy/length, -dx/length]
            integers = [round(v*SCALE) for v in exact]
            error = abs(exact[0]-F(integers[0], SCALE))*1500 + abs(exact[1]-F(integers[1], SCALE))*320
            rhs = exact[0]*a[0]+exact[1]*a[1]
            scaled_rhs = math.floor((rhs-error-F('1e-7'))*SCALE*GRID)
            divisor = math.gcd(abs(integers[0]), abs(integers[1]))
            assert divisor > 0
            coefficients = [v//divisor for v in integers]
            upper = scaled_rhs//divisor
            assert sum(abs(v)*1_500_000 for v in coefficients) < 2**62
            region['planes'].append({'edge': edge, 'coefficients': coefficients, 'upper': upper,
                                     'unreduced_coefficients': integers, 'divisor': divisor,
                                     'rounding_error_bound_mm': str(error)})
            plane_count += 1
        record['regions'].append(region)
    integer_templates.append(record)
write(OUT / 'family-modes.json', integer_modes)
write(OUT / 'integer-templates.json', integer_templates)
shutil.copyfile(REGIONS / 'owner-pairs.json', OUT / 'owner-pairs.json')
shutil.copyfile(MODES / 'instances.json', OUT / 'instances.json')
shutil.copyfile(MODES / 'inventory.json', OUT / 'inventory.json')
elapsed = time.perf_counter()-started
inputs = [Path(__file__), ROOT / 'output/h5_exact_convex_partition_tools_20261029.py', MODES / 'plan.json', MODES / 'checks.json',
          MODES / 'family-modes.json', MODES / 'instances.json', MODES / 'inventory.json', MODES / 'audit/plan.json', MODES / 'audit/checks.json',
          REGIONS / 'plan.json', REGIONS / 'checks.json', REGIONS / 'templates.json', REGIONS / 'owner-pairs.json',
          REGIONS / 'audit/plan.json', REGIONS / 'audit/checks.json', PRIOR / 'response-audit/plan.json', PRIOR / 'response-audit/checks.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'A distinct integer-position construction on a 1-micrometre grid, with all 58 legal source-mode options. Each chosen region enforces its convex-hull halfplanes directly, without continuous vertex weights or deactivation constants. Source-safe region vertices retain nine-decimal rounding. Rational edge normals are quantized at 1e9, tightened by a full relative-domain error bound plus 1e-7 mm, converted to integer micrometre coordinates, and reduced by the coefficient gcd with downward RHS rounding. Source-mode domains round inward. Mode/region consistency and identical-copy X order remain mandatory. Independently audit the geometry implication and full CP-SAT model before one 60/90-second call. The grid, fixed cog phase and conservative region construction restrict negative conclusions; no allocation exclusion or retry of a closed call.',
    'position_units_per_mm': GRID, 'normal_coefficient_scale': SCALE, 'relative_domain_envelope_mm': [1500, 320],
    'algorithm_seconds': 60, 'shared_seconds': 90, 'maximum_calls': 1, 'retry_permitted': False,
    'source_validation_reserve_seconds': 3, 'solver_calls': 0,
})
checks = {'passed': True, 'seconds': elapsed, 'legal_family_modes': 13, 'instance_mode_options': 58,
          'geometry_pair_templates': len(integer_templates), 'convex_region_hulls': sum(len(t['regions']) for t in integer_templates),
          'integer_halfplanes': plane_count, 'position_units_per_mm': GRID,
          'independent_geometry_audit_pending': True, 'new_model_created': False,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
