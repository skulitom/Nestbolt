"""Revalidate the four complete ancestor model stages without modifying evidence."""
import json
from ortools.sat import cp_model_pb2
from h5_transfer43_cp_reader_20261028 import inspect as inspect_original
from h5_hybrid43_cp_reader_20261028 import inspect as inspect_hybrid
from h5_row_bracket_cp_reader_20261028 import inspect as inspect_precise
from h5_row_capacity_cp_reader_20261028 import inspect as inspect_capacity
def inspect_ancestors(root):
    load=lambda p:json.loads(p.read_bytes())
    def proto(path):
        p=cp_model_pb2.CpModelProto();p.ParseFromString(path.read_bytes());return p
    original=root/'output/h5-transfer43-source-20261028';hybrid=root/'output/h5-hybrid43-guarded-source-20261028';precise=root/'output/h5-row-bracket-source-20261028';capacity=root/'output/h5-row-bracket-capacity-20261028';records=[]
    def saved(base,name):return load(base/'model'/name)
    p0=proto(original/'model/model.pb');m0=saved(original,'mapping.json');r,_=inspect_original(p0,m0,load(original/'blocks43.json'),load(original/'modes.json'),load(original/'control.json'),load(original/'negative.json'),saved(original,'partial-hints.json'),saved(original,'partial-control-assignment.json'),saved(original,'negative-assignment.json'));records.append({'stage':'original',**r})
    relative={k:load(precise/'relative'/f'{k}.json') for k in ['5-5','5-4']};typed={(ri,mi):load(precise/'row-bracket'/f'{ri:02d}-{mi:02d}.json') for ri in [12,13] for mi in range(2,10)};p1=proto(hybrid/'model/model.pb');m1=saved(hybrid,'mapping.json');r,_=inspect_hybrid(p1,m1,p0,m0,load(hybrid/'modes.json'),relative,load(hybrid/'control.json'),load(hybrid/'negative.json'),saved(hybrid,'partial-hints.json'),saved(hybrid,'partial-control-assignment.json'),saved(hybrid,'negative-assignment.json'));records.append({'stage':'hybrid',**r})
    p2=proto(precise/'model/model.pb');m2=saved(precise,'mapping.json');r,_=inspect_precise(p2,m2,p1,m1,load(precise/'modes.json'),relative,typed,load(precise/'control.json'),load(precise/'negative.json'),saved(precise,'partial-hints.json'),saved(precise,'partial-control-assignment.json'),saved(precise,'negative-assignment.json'));records.append({'stage':'precise',**r})
    p3=proto(capacity/'model/model.pb');m3=saved(capacity,'mapping.json');r=inspect_capacity(p3,m3,p2,m2,load(capacity/'mode-contained-rectangles.json'));records.append({'stage':'capacity',**r});return p3,m3,records
