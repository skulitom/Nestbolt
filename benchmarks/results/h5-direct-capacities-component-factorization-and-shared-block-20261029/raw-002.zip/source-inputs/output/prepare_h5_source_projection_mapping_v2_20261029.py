"""Map simultaneous source floor references and coarse anchors without fixing pair orders."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';OUT=BASE/'preflight-v2';LEGACY=ROOT/'output/h5-insert-order-projection-20261028';COARSE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';VARS=ROOT/'output/h5-short13-necessary-geometry-20261028';SRC=ROOT/'output/h5-rotation-independent-geometry-20261026';PARENT=ROOT/'output/h5-source-pair-short-core-20261029';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def inside(p,ring):
    cross=0
    for a,b in zip(ring,ring[1:]+ring[:1]):
        if min(a[1],b[1])<=p[1]<max(a[1],b[1]):cross+=int(a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])>p[0])
    return cross%2==1
def intersects(a,b,r):
    lo,hi=F(0),F(1)
    for k in [0,1]:
        d=b[k]-a[k]
        if not d:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            u,v=sorted(((r[k]-a[k])/d,(r[k+2]-a[k])/d));lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
assert load(BASE/'preflight/legacy-replay/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'];shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[Path(__file__),JOB,PARENT/'model/plan.json',PARENT/'model-audit/plan.json',PARENT/'response-audit/plan.json',BASE/'preflight/legacy-replay/plan.json',BASE/'preflight/legacy-replay/checks.json',LEGACY/'plan.json',LEGACY/'profiles.json',LEGACY/'pair-distances.json',LEGACY/'triple-insert-proof.json',COARSE/'plan.json',COARSE/'audit/plan.json',COARSE/'modes.json',COARSE/'inventory.json',GEOM/'cog-core.json',GEOM/'positive-source11.json',GEOM/'negative-source13.json',VARS/'variants.json',VARS/'plan.json',VARS/'audit/audit.py',VARS/'audit/checks.json',SRC/'original-cog-proof.json',SRC/'audit/plan.json',SRC/'audit/checks.json',ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json',ROOT/'output/h5-short13-source-sliding-20261028/prefix-bank.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Introduce auxiliary1um source reference-X coordinates linked within[-52,51]um of100 times each current coarse X plus its source reference offset. For a source-feasible layout these auxiliary coordinates can be the old floored source anchors/centers, simultaneously with the current nearest100um anchors. Keep the old directed pair distances on those auxiliary references, with independent freely chosen pair directions. Do not import prior within-family reference ordering, because bracket offsets depend on mode. All4 insert quarter turns remain. At most2 source-inner insert intervals can overlap any X, since3 minimum heights exceed the legacy relaxed stock height; encode that invariant as capacity2 on6 optional insert intervals, without assuming an insert sequence. Every parent variable/constraint remains. No model or search is created by this preparation.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'num_search_workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'retry_permitted':False,'model_created':False,'solver_calls':0,'native_calls':0})
profiles={p['variant']:p for p in load(LEGACY/'profiles.json')};variants={v['id']:v for v in load(VARS/'variants.json')};modes=load(COARSE/'modes.json');sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');stock=[F(str(v))*1000 for v in sp['source_stock']];mapping=[];edges=rectangles=0
for m in modes:
    variant=m['mode'] if m['family']=='bracket' else 9 if m['quarter']%2==0 else 8;v=variants[variant];p=profiles[variant];assert v['family']==m['family'] and v['mirrored']==m['mirrored']
    if m['family']=='bracket':assert v['quarter_turn']==m['quarter']
    ring=[[F(str(x))*1000,F(str(y))*1000] for x,y in m['source_outer']];mins=[min(v[k] for v in ring) for k in [0,1]];maxs=[max(v[k] for v in ring) for k in [0,1]];floors=[math.floor(stock[k]-mins[k]) for k in [0,1]]+[math.floor(stock[k+2]-maxs[k]) for k in [0,1]];assert all(p['anchor_domain_um'][k]<=floors[k] for k in [0,1]) and all(p['anchor_domain_um'][k]>=floors[k] for k in [2,3])
    for r in p['source_rectangles_um']:
        expanded=[F(r[0]-1),F(r[1]-1),F(r[2]+1),F(r[3]+1)]
        for pt in [(expanded[0],expanded[1]),(expanded[2],expanded[1]),(expanded[2],expanded[3]),(expanded[0],expanded[3])]:assert inside(pt,ring)
        for a,b in zip(ring,ring[1:]+ring[:1]):assert not intersects(a,b,expanded);edges+=1
        rectangles+=1
    mapping.append({'family':m['family'],'mode':m['mode'],'quarter':m['quarter'],'mirrored':m['mirrored'],'prior_variant':variant,'reference_offset_um':p['reference_x_um'],'prior_reference_domain_um':p['reference_x_domain_um'],'source_floor_anchor_domain_um':floors,'prior_anchor_domain_um':p['anchor_domain_um'],'insert_width_um':p['insert_width_um'] or 0})
original=load(SRC/'original-cog-proof.json');job=load(JOB);cog=next(p for p in job['parts'] if p['id']=='cog');oldcenter=list(map(F,original['center']));newcenter=list(map(F,load(GEOM/'cog-core.json')['source_center_mm']));assert [[F(x)-oldcenter[0],F(y)-oldcenter[1]] for x,y in cog['geometry'][0]['outer']]==[[F(*v) for v in row] for row in original['centered_vertices_rational']]
shift2=sum(((a-b)*1000)**2 for a,b in zip(oldcenter,newcenter));assert shift2<F(1,1000)**2;radius=original['all_angle_stock_support_radius_units1000'];assert radius==139270;p=profiles[12];floors=[math.floor(stock[k]+radius) for k in [0,1]]+[math.floor(stock[k+2]-radius) for k in [0,1]];assert all(p['anchor_domain_um'][k]<=floors[k] for k in [0,1]) and all(p['anchor_domain_um'][k]>=floors[k] for k in [2,3]);mapping.append({'family':'cog','mode':None,'prior_variant':12,'reference_offset_um':0,'prior_reference_domain_um':p['reference_x_domain_um'],'source_floor_anchor_domain_um':floors,'prior_anchor_domain_um':p['anchor_domain_um'],'insert_width_um':0})
write(OUT/'mode-map.json',mapping);write(OUT/'reference-link.json',{'coordinate_unit_um':100,'lower_delta_um':-52,'upper_delta_um':51,'maximum_nearest_coordinate_error_um':50,'floor_loss_less_than_um':1,'source_center_change_norm_less_than_um':'0.001','exact_center_change_norm_squared_um2':str(shift2),'formula':'legacy_reference_x -100*coarse_x -selected_reference_offset in[-52,51]','source_mapping_argument':'For noncogs use floor of the same oriented normalized source anchor; coarse nearest rounding changes it by at most50um and flooring by less than1um. All prior source rectangles expanded1um remain strictly inside every current oriented source outline, so they remain source-contained after flooring. For cogs use the exact previously proved source center; its change to the current rational center is less than0.001um in any rotated coordinate. The conservative integer link includes both cases. Old source-floor domains contain the full original source stock domain. Pointwise inclusion of every coarse core-only anchor in those old domains is not required and is not claimed.','ordering_argument':'Every old pair-order literal is chosen from its old auxiliary reference coordinates. No inherited reference-X symmetry is imposed on bracket copies. Current parent symmetry remains only the proved coarse-anchor ordering. The insert interval capacity applies to every triple without selecting a subsequence or imposing a new order.'})
pairs=load(LEGACY/'pair-distances.json');write(OUT/'pair-distances.json',pairs);triple=load(LEGACY/'triple-insert-proof.json');assert triple['three_minimum_heights_um']>triple['relaxed_stock_height_um'];write(OUT/'insert-capacity.json',{'capacity':2,'minimum_insert_height_um':min(triple['insert_heights_um'].values()),'three_minimum_heights_um':triple['three_minimum_heights_um'],'legacy_relaxed_stock_height_um':triple['relaxed_stock_height_um'],'width_by_prior_variant':triple['insert_widths_um'],'all_overlapping_insert_triples_excluded':True,'no_reference_order_assumed':True})
dist={tuple(r['profiles']):r['minimum_reference_distance_um'] for r in pairs};bykey={(m['family'],m['mode']):m for m in mapping};controls=[]
def evaluate(rows):
    bad=0;slack=10**9
    for a,b in combinations(rows,2):
        if a['reference_x_um']>b['reference_x_um']:a,b=b,a
        s=b['reference_x_um']-a['reference_x_um']-dist[a['prior_variant'],b['prior_variant']];slack=min(slack,s);bad+=s<0
    events={}
    for r in rows:
        if not r['insert_width_um']:continue
        x=r['reference_x_um'];events[x]=events.get(x,0)+1;events[x+r['insert_width_um']]=events.get(x+r['insert_width_um'],0)-1
    active=peak=0
    for x,d in sorted(events.items()):active+=d;peak=max(peak,active)
    assert active==0
    return {'directed_pair_failures':bad,'minimum_pair_slack_um':slack,'maximum_insert_interval_overlap':peak}
for name,count in [('positive',11),('negative',13)]:
    rows=[]
    for src in load(GEOM/f'{name}-source{count}.json'):
        t=src['transform'];family=src['part_id']
        if family=='cog':
            c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);actual=(F(str(c))*oldcenter[0]-F(str(s))*oldcenter[1]+F(str(t['translation'][0])))*1000;coarse_actual=(F(str(c))*newcenter[0]-F(str(s))*newcenter[1]+F(str(t['translation'][0])))*1000;key=(family,None)
        else:
            q=round(t['rotation_radians']/(math.pi/2))%4;m=next(m for m in modes if m['family']==family and m['quarter']==q and m['mirrored']==t['mirrored']);actual=(F(str(t['translation'][0]))-F(str(m['source_translation_offset'][0])))*1000;coarse_actual=actual;key=(family,m['mode'])
        match=bykey[key];x=round(coarse_actual/100);reference=math.floor(actual)+match['reference_offset_um'];delta=reference-100*x-match['reference_offset_um'];assert -52<=delta<=51 and match['prior_reference_domain_um'][0]<=reference<=match['prior_reference_domain_um'][1];rows.append({'identity':[family,src['copy_index']],'mode':key[1],'prior_variant':match['prior_variant'],'coarse_x_grid_units':x,'reference_x_um':reference,'reference_offset_um':match['reference_offset_um'],'link_delta_um':delta,'insert_width_um':match['insert_width_um']})
    checked=evaluate(rows)
    if name=='positive':assert checked['directed_pair_failures']==0 and checked['maximum_insert_interval_overlap']<=2
    else:assert checked['directed_pair_failures']>0 and checked['maximum_insert_interval_overlap']>2
    write(OUT/f'{name}-references{count}.json',rows);controls.append({'name':name,'originals':count,**checked})
prefixchecks=0;maxdelta=0
for row in load(ROOT/'output/h5-short13-source-sliding-20261028/prefix-bank.json'):
    for xy in row['anchors']:
        if xy is None:continue
        a=F(str(xy[0]))*1000;delta=math.floor(a)-100*round(a/100);assert -52<=delta<=51;maxdelta=max(maxdelta,abs(delta));prefixchecks+=1
write(OUT/'controls.json',controls);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'current_mode_mappings':13,'all8_bracket_and4_insert_modes_preserved':True,'prior_source_rectangles_with1um_expansion_verified':rectangles,'exact_current_source_edge_checks':edges,'source_stock_floor_domains_verified':13,'source_center_change_verified':True,'directed_pair_distances_retained_on_auxiliary_references':121,'old_reference_ordering_not_imported':True,'insert_capacity':2,'positive_and_negative_controls_verified':True,'legacy_source_prefix_anchor_links_checked':prefixchecks,'maximum_legacy_prefix_link_delta_um':maxdelta,'independent_mapping_audit_pending':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
