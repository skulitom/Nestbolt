"""Pure exhaustive protobuf reader for the whole-sheet row-cover construction."""
import math
from itertools import combinations

def inspect(p,mp,blocks,modes,control,negative,hints_saved,partial_saved,negative_saved):
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
    control={r['block']:r for r in control};negative={r['block']:r for r in negative};seenvars=set();seencts=set();allx=[];ally=[];widths=[];heights=[];hints={};values={};badvalues={};MIN=-9223372036854775808;MAX=9223372036854775807
    def var(ix,name,domain):
        assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'}
    def linear(ix,coeffs,lo=MIN,hi=MAX,on=()):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and {f.name for f,z in ct.ListFields()}<= {'linear','enforcement_literal'}
        assert list(ct.enforcement_literal)==list(on) and dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
    def expr(e,variable,offset):
        assert e.offset==offset and list(e.vars)==([] if variable is None else [variable]) and list(e.coeffs)==([] if variable is None else [1]) and {f.name for f,z in e.ListFields()}<= {'vars','coeffs','offset'}
    def interval(ix,name,variable,lo,hi,selector):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='interval' and ct.name==name and list(ct.enforcement_literal)==[selector] and {f.name for f,z in ct.ListFields()}=={'name','interval','enforcement_literal'}
        expr(ct.interval.start,variable,lo);expr(ct.interval.size,None,hi-lo);expr(ct.interval.end,variable,hi)
    assert len(mp['items'])==len(blocks)==39
    for i,(item,block) in enumerate(zip(mp['items'],blocks)):
        assert item['index']==i and item['source_block']==block;present,x,y=item['presence'],item['x'],item['y'];var(present,f'present_{i}',[0,1]);var(x,f'x_{i}',[0,1500000]);var(y,f'y_{i}',[0,3000000]);linear(item['mandatory'],{present:1},1,1);known=control.get(i);hints[present]=1
        values[present]=int(known is not None);values[x],values[y]=known['anchor_um'] if known else [0,0];badvalues[present]=1;badvalues[x],badvalues[y]=negative[i]['anchor_um']
        if known:hints[x],hints[y]=known['anchor_um']
        assert [o['mode'] for o in item['options']]==[m['id'] for m in modes if m['family']==block['family']]
        for o in item['options']:
            mi=o['mode'];m=modes[mi];s=o['selector'];var(s,f'mode_{i}_{mi}',[0,1]);a,b,c,d=m['source_bounds_mm'];linear(o['x_bound'],{x:1},math.ceil(6513-a*1000),math.floor(1493487-c*1000),[s]);linear(o['y_bound'],{y:1},math.ceil(6513-b*1000),math.floor(2993487-d*1000),[s]);values[s]=int(known is not None and known['mode']==mi);badvalues[s]=int(negative[i]['mode']==mi)
            if known:hints[s]=int(known['mode']==mi)
            assert len(o['components'])==len(m['cover_rectangles_um'])
            for k,(component,(a,b,c,d)) in enumerate(zip(o['components'],m['cover_rectangles_um'])):
                assert component['component']==k;ix,iy=component['x_interval'],component['y_interval'];interval(ix,f'cover_x_{i}_{mi}_{k}',x,a,c,s);interval(iy,f'cover_y_{i}_{mi}_{k}',y,b,d,s);allx.append(ix);ally.append(iy);widths.append(c-a);heights.append(d-b)
        linear(item['choice'],{**{o['selector']:1 for o in item['options']},present:-1},0,0)
    ix=mp['no_overlap_2d'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'no_overlap_2d'} and list(ct.no_overlap_2d.x_intervals)==allx and list(ct.no_overlap_2d.y_intervals)==ally
    for key,ints,demands,capacity in [('x_cumulative',allx,heights,2987202),('y_cumulative',ally,widths,1487202)]:
        assert mp[key.replace('cumulative','capacity_um')]==capacity;ix=mp[key];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'cumulative'} and list(ct.cumulative.intervals)==ints and len(ct.cumulative.demands)==len(demands);expr(ct.cumulative.capacity,None,capacity)
        for e,d in zip(ct.cumulative.demands,demands):expr(e,None,d)
    orders=[(a,b,'y' if f=='cog-row' else 'x') for f in ['bracket','frame','insert','cog-row'] for group in [[r for r in mp['items'] if r['source_block']['family']==f]] for a,b in zip(group,group[1:])];assert len(orders)==len(mp['orders'])==35
    for row,(a,b,axis) in zip(mp['orders'],orders):
        assert (row['left'],row['right'],row['axis'])==(a['index'],b['index'],axis);linear(row['constraint'],{a[axis]:1,b[axis]:-1},hi=0,on=[a['presence'],b['presence']])
    assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)))
    assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in hints_saved.items()} and len(p.solution_hint.vars)==len(hints)
    assert [values[i] for i in range(len(p.variables))]==partial_saved and [badvalues[i] for i in range(len(p.variables))]==negative_saved
    disabled=[r['mandatory'] for r in mp['items'] if r['index'] not in control];assert disabled==mp['control_disabled_mandatory_constraints'] and len(disabled)==11
    return {'passed':True,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'independent_anchor_coordinates':78,'mandatory_blocks':39,'target_originals':66,'mode_options_verified':sum(len(r['options']) for r in mp['items']),'component_options_verified':len(allx),'symmetry_orders_verified':35,'partial_hints_verified':len(hints),'all_model_fields_verified':True},disabled

def violations(model,solution):
    assert len(solution)==len(model.variables)
    for v,x in zip(model.variables,solution):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(v):return bool(solution[v]) if v>=0 else not bool(solution[-v-1])
    def present(ct):return all(truth(v) for v in ct.enforcement_literal)
    def ev(e):return e.offset+sum(c*solution[v] for v,c in zip(e.vars,e.coeffs))
    failed=[];pair_count=0;collisions=0
    for i,ct in enumerate(model.constraints):
        if not present(ct):continue
        kind=ct.WhichOneof('constraint');valid=True
        if kind=='linear':
            v=sum(c*solution[ix] for ix,c in zip(ct.linear.vars,ct.linear.coeffs));valid=any(a<=v<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='interval':valid=ev(ct.interval.start)+ev(ct.interval.size)==ev(ct.interval.end) and ev(ct.interval.size)>0
        elif kind=='no_overlap_2d':
            rects=[]
            for a,b in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
                x,y=model.constraints[a],model.constraints[b];assert present(x)==present(y)
                if present(x):rects.append([ev(x.interval.start),ev(y.interval.start),ev(x.interval.end),ev(y.interval.end)])
            for a,b in combinations(rects,2):
                pair_count+=1
                if not (a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]):collisions+=1;valid=False
        elif kind=='cumulative':
            events={}
            for ix,d in zip(ct.cumulative.intervals,ct.cumulative.demands):
                interval=model.constraints[ix]
                if not present(interval):continue
                begin,end,amount=ev(interval.interval.start),ev(interval.interval.end),ev(d);events[begin]=events.get(begin,0)+amount;events[end]=events.get(end,0)-amount
            total=0
            for where,delta in sorted(events.items()):total+=delta;valid &= 0<=total<=ev(ct.cumulative.capacity)
            assert total==0
        else:raise AssertionError(kind)
        if not valid:failed.append({'constraint':i,'kind':kind})
    return {'failed_constraints':failed,'cover_pairs_checked':pair_count,'cover_collisions':collisions}
