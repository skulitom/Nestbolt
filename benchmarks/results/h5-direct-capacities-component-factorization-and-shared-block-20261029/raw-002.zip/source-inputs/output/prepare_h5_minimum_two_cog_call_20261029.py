"""Freeze a single source7 call and a reader requiring all7/59 original identities."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-five-bracket-two-cog-core-20261029';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();assert load(BASE/'model-audit/checks.json')['passed']
oldrun=ROOT/'output/run_h5_source_projection_short12_20261029.py';oldcheck=ROOT/'output/check_h5_source_projection_short12_candidate_20261029.py';runner=oldrun.read_text(encoding='utf-8');checker=oldcheck.read_text(encoding='utf-8')
runner=runner.replace("output/h5-source-projection-short12-20261029'","output/h5-five-bracket-two-cog-core-20261029'").replace('check_h5_source_projection_short12_candidate_20261029','check_h5_minimum_two_cog_candidate_20261029').replace('short12','short7').replace('source_valid12','source_valid7')
checker=checker.replace("output/h5-source-projection-short12-20261029'","output/h5-five-bracket-two-cog-core-20261029'").replace("ROOT/'output/h5-source-projection-short-core-20261029/next-short12-preflight/inventory.json'","BASE/'preflight/inventory.json'")
old="    if item['identity']==['insert',0]:\n        assert values[item['presence']]==0 and item['index']==mp['inactive_short_owner'] and item['identity'] in inventory['mandatory_first54_identities'] and item['identity'] not in inventory['short12_identities'];continue"
new="    if item['family']=='insert':\n        assert values[item['presence']]==0 and item['index'] in mp['inactive_short_owners'] and item['identity'] in mp['inactive_short_identities'] and item['identity'] in inventory['mandatory_first59_identities'] and item['identity'] not in inventory['short7_identities'];continue"
assert old in checker;checker=checker.replace(old,new)
for a,b in [('short12','short7'),('source12','source7'),('core12','core7'),('source_valid12','source_valid7'),('first54','first59'),('all12','all7'),('len(orth)==10','len(orth)==5'),('len(decoded)==12','len(decoded)==7'),('len(shortids)==12','len(shortids)==7'),('len(firstids)==54','len(firstids)==59'),("'originals':12","'originals':7"),('orthogonal-source10','orthogonal-source5'),('orthogonal_source10','orthogonal_source5')]:checker=checker.replace(a,b)
assert 'source_valid7' in runner and 'source_valid7' in checker and 'short12' not in checker and 'first54' not in checker and "len(shortids)==7 and len(firstids)==59" in checker
newrun=ROOT/'output/run_h5_minimum_two_cog_core_20261029.py';newcheck=ROOT/'output/check_h5_minimum_two_cog_candidate_20261029.py'
for p,s in [(newrun,runner),(newcheck,checker)]:compile(s,str(p),'exec');assert not p.exists()
for p,s in [(newrun,runner),(newcheck,checker)]:
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
out=BASE/'call-preparation';out.mkdir();inputs=[Path(__file__),oldrun,oldcheck,newrun,newcheck,BASE/'plan.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'preflight/plan.json']
with (out/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'short_required':7,'first_required':59,'inactive_short_owners':list(range(7,13)),'source_candidate_pipeline_not_yet_exercised':True,'solver_calls':0},f,indent=2);f.write('\n')
print('Distinct source7 runner and7/59 identity reader ready; no call opened.')
