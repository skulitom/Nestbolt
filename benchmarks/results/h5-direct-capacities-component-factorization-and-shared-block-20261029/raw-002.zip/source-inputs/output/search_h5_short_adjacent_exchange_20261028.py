"""One frozen finite construction of three moving originals against fixed ten."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,traceback
from shapely.geometry import shape
from shapely.affinity import translate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-adjacent-exchange-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for child in getattr(g,'geoms',[]) for p in polygons(child)]
def anchors(g):
    pts=set()
    for p in polygons(g):
        pts.add(tuple(p.representative_point().coords[0]))
        for ring in [p.exterior,*p.interiors]:pts.update(tuple(xy) for xy in ring.coords[:-1])
    return sorted(pts)
class BudgetEnd(Exception):pass

def run():
    started=time.perf_counter();plan=load(OUT/'plan.json');assert plan['maximum_calls']==1 and plan['algorithm_seconds']==60 and plan['shared_seconds']==90
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(BASE/'audit/checks.json')['passed'];write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':plan['inputs'],'construction_calls':1,'algorithm_seconds':60,'shared_seconds':90,'maximum_joint_cog_bracket_anchors':10000,'retry_permitted':False})
    modes=load(BASE/'modes.json');case=load(BASE/'case.json');inventories=load(BASE/'selected-inventories.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');geometryplan=load(BASE/'plan.json');free={i:shape(load(BASE/'free'/f'{i:02d}.json')['geometry']) for i in range(46)}
    obstacles={(r['kind'],r['left'],r['right']):shape(load(ROOT/r['source_path'])['geometry']) for r in load(BASE/'obstacle-index.json') if r['kind']!='fixed-moving'}
    log=[];cogposes=joint=brregions=insertregions=sourcechecks=failures=0;found=None;reason=None
    def budget():
        if time.perf_counter()-started>=60:raise BudgetEnd()
    def posed(mi,xy,copy):
        m=modes[mi]
        return {'part_id':m['family'],'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in [0,1]]}}
    try:
        for ci in range(36):
            budget();modecogs=modejoints=modebrregions=modeinsertregions=0
            for cxy in anchors(free[ci]):
                budget();cogposes+=1;modecogs+=1;cg=posed(ci,cxy,0)
                insert_after_cog={ii:free[ii].difference(translate(obstacles['cog-insert',ci,ii],*cxy)) for ii in [44,45]}
                for bi in range(36,44):
                    budget();brfree=free[bi].difference(translate(obstacles['cog-bracket',ci,bi],*cxy));brregions+=len(polygons(brfree));modebrregions+=len(polygons(brfree))
                    for bxy in anchors(brfree):
                        budget()
                        if joint>=10000:reason='joint anchor cap';raise BudgetEnd()
                        joint+=1;modejoints+=1;br=posed(bi,bxy,11)
                        for ii in [44,45]:
                            budget();insfree=insert_after_cog[ii].difference(translate(obstacles['bracket-insert',bi,ii],*bxy));components=sorted(polygons(insfree),key=lambda p:(-p.area,*p.representative_point().coords[0]));insertregions+=len(components);modeinsertregions+=len(components)
                            for part in components:
                                budget();ixy=list(part.representative_point().coords[0]);rows=case['fixed10']+[cg,br,posed(ii,ixy,0)];sourcechecks+=1;read=audit(job,rows,{'sheet-1':geometryplan['source_stock']},geometryplan['required_pair_gap_mm'],geometryplan['stock_guard_mm'],inventories[0]['mandatory_short_identities'])
                                if read['valid']:
                                    found={'rows':rows,'source_check':read,'cog_mode':ci,'cog_anchor':list(cxy),'bracket_mode':bi,'bracket_anchor':list(bxy),'insert_mode':ii,'insert_anchor':ixy};reason='source-valid short13';break
                                failures+=1;write(OUT/f'source-rejection-{failures:05d}.json',{'rows':rows,'checks':read})
                            if found:break
                        if found:break
                    if found:break
                if found:break
            log.append({'cog_mode':ci,'cog_anchors':modecogs,'joint_cog_bracket_anchors':modejoints,'bracket_residual_components':modebrregions,'insert_residual_components':modeinsertregions,'seconds':time.perf_counter()-started,'mode_completed':found is None})
            print(log[-1],flush=True)
            if found:break
        if reason is None:reason='all declared finite anchors exhausted'
    except BudgetEnd:
        if reason is None:reason='algorithm time limit'
    elapsed=time.perf_counter()-started
    if found:
        write(OUT/'short13-variant48.json',found['rows']);write(OUT/'short13-variant48-source-checks.json',found['source_check'])
        remapped=json.loads(json.dumps(found['rows']))
        for r in remapped:
            if r['part_id']=='bracket' and r['copy_index']==11:r['copy_index']=10
        read=audit(job,remapped,{'sheet-1':geometryplan['source_stock']},geometryplan['required_pair_gap_mm'],geometryplan['stock_guard_mm'],inventories[1]['mandatory_short_identities']);assert read['valid'];write(OUT/'short13-variant59.json',remapped);write(OUT/'short13-variant59-source-checks.json',read)
        write(OUT/'selected-anchors.json',{k:v for k,v in found.items() if k not in ['rows','source_check']})
    write(OUT/'mode-progress.json',log)
    write(OUT/'result.json',{'closed':True,'reason':reason,'construction_calls':1,'solver_calls':0,'cog_anchors_evaluated':cogposes,'joint_cog_bracket_anchors':joint,'bracket_residual_components':brregions,'insert_residual_components':insertregions,'source13_checks':sourcechecks,'source13_rejections':failures,'source_valid_short13':found is not None,'equivalent_identity_variants_validated':2 if found else 0,'algorithm_seconds':elapsed,'algorithm_soft_overrun_seconds':max(0,elapsed-60),'algorithm_limit_seconds':60,'shared_limit_seconds':90,'all_finite_anchors_exhausted':reason=='all declared finite anchors exhausted','retry_permitted':False,'unused_time_not_reused':True,'original_or_all_angle_infeasibility_claimed':False,'source_valid66':False,'native_calls':0,'H5_complete':False})
    print(load(OUT/'result.json'),flush=True)
if __name__=='__main__':
    try:run()
    except Exception as e:
        write(OUT/'execution-failure.json',{'closed':True,'exception_type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'retry_permitted':False});raise
