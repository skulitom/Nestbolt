"""Verify every exact mixed source boundary and the complete short-sheet domains."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-necessary-geometry-20261028';OUT=BASE/'audit';ALLOC=ROOT/'output/h5-allocation-geometry-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
vs=load(ALLOC/'variants.json');assert load(BASE/'variants.json')==[v for v in vs if v['family'] in ['bracket','insert','cog']]
assert load(BASE/'domains.json')==[d for d in load(ALLOC/'domains.json') if d['allowed'] and d['sheet']==1 and vs[d['variant']]['family'] in ['bracket','insert','cog']]
assert load(BASE/'stock.json')==load(ALLOC/'stocks.json')[1]
proof=load(BASE/'source-proofs.json');octagon=proof['octagon']['vertices_um'];r=proof['octagon']['radius_um'];assert r==109113 and len(octagon)==8 and all(x*x+y*y<=r*r for x,y in octagon)
edge=proof['edge'];corner=proof['corner'];h=edge['rounded_center_support_lower_um'];L=edge['support_vertex_transverse_upper_um'];R=corner['rounded_vertex_radius_strict_upper_um'];pairs=corner['rounded_simultaneous_support_pairs_um']
assert h*h+L*L>=R*R and edge['strictly_smaller_core_radius_um']<r and R==140003
records=load(BASE/'components.json');expected={(v['id'],i) for v in vs[:10] for i in range(len(v['coarse_rectangles_um']))};assert {(q['variant'],q['component']) for q in records}==expected and len(records)==26
facets=point_checks=boxes=0
for q in records:
    v=vs[q['variant']];b=v['coarse_rectangles_um'][q['component']];assert b==q['source_rectangle_um'] and q['family']==v['family'];x,y,xx,yy=b;w=xx-x;height=yy-y
    assert min(w,height)>max(R-edge['strictly_smaller_core_radius_um'],2*L)
    points={(a-u,c-t) for a in [x,xx] for c in [y,yy] for u,t in octagon};vertices=q['octagon_vertices_um'];poly=q['forbidden'][0];assert poly['kind']=='inner_octagon' and len(vertices)==len(poly['faces'])==12
    assert all(tuple(p) in points for p in vertices)
    for k,((nx,ny,rhs),p) in enumerate(zip(poly['faces'],vertices)):
        following=vertices[(k+1)%len(vertices)];after=vertices[(k+2)%len(vertices)];dx,dy=following[0]-p[0],following[1]-p[1];g=math.gcd(abs(dx),abs(dy));assert [nx,ny,rhs]==[-dy//g,dx//g,(-dy*p[0]+dx*p[1])//g]
        assert dx*(after[1]-following[1])-dy*(after[0]-following[0])>0
        assert all(nx*a+ny*c>=rhs for a,c in points);point_checks+=len(points);facets+=1
    strips=[[x-h,y+L,xx+h,yy-L],[x+L,y-h,xx-L,yy+h]];assert q['edge_strips_um']==strips
    for entry,b in zip(q['forbidden'][1:3],strips):
        a,c,d,e=b;assert entry=={'kind':'source_edge_strip','box':b,'faces':[[1,0,a],[-1,0,-d],[0,1,c],[0,-1,-e]]}
    wanted=[]
    for pi,(px,py) in enumerate(pairs):
        a,c=max(0,R-w),max(0,R-height)
        if a>px or c>py:continue
        for sx,sy in [(1,1),(-1,1),(-1,-1),(1,-1)]:
            cx=x if sx==1 else xx;cy=y if sy==1 else yy;xb=sorted([cx-sx*a,cx-sx*px]);yb=sorted([cy-sy*c,cy-sy*py]);wanted.append({'support_pair':pi,'signs':[sx,sy],'corner_um':[cx,cy],'offset_range_um':[a,c,px,py],'closed_forbidden_box_um':[xb[0],yb[0],xb[1],yb[1]]})
    assert q['corner_boxes']==wanted and len(q['forbidden'])==3+len(wanted)
    for entry,wanted_box in zip(q['forbidden'][3:],wanted):
        b=wanted_box['closed_forbidden_box_um'];a,c,d,e=b;assert entry=={'kind':'source_corner_box','box':b,'faces':[[1,0,a-1],[-1,0,-d-1],[0,1,c-1],[0,-1,-e-1]]};boxes+=1
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_inner_components':26,'minkowski_facets':facets,'exact_minkowski_point_inequalities':point_checks,'source_edge_strips':52,'closed_source_corner_boxes':boxes,'strict_integer_corner_complements_verified':True,'source_variant_and_whole_stock_domains_exact':True,'all_real_cog_angles':True,'prior_source_containment_and_support_proof_hashes_preserved':True,'no_fixed_original_positions':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
