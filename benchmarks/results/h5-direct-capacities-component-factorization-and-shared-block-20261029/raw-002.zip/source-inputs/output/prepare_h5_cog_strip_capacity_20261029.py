"""Prepare exact cog-contained strips for future whole-sheet propagation."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from math import ceil,floor,gcd
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-coarse-short-core-20261029';OUT=BASE/'cog-strip-preflight';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'search/result.json')['status']=='UNKNOWN'
inputs=[Path(__file__),BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',GEOM/'cog-core.json',GEOM/'audit/plan.json',GEOM/'audit/checks.json',PRE/'audit/plan.json',PRE/'positive-core11.json',PRE/'negative-core13.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Partition the existing angle-independent filled-source cog core into16 horizontal bands. For each band, take the widest integer rectangle bounded by all exact core edge half-planes. Retain each band as a disjoint interior rectangle, sharing the original cog center and owner. These strips may be added to global NoOverlap2D and cumulative resource constraints alongside existing bracket/insert pieces. Existing exact cog facets must remain. This adds propagation without changing the necessary relaxation: strip rectangles are subsets of a cog core already separated from every other core. No model or search is opened.','bands_per_cog':16,'independent_audit_required':True,'model_created':False,'solver_calls':0,'native_calls':0})
core=load(GEOM/'cog-core.json')['vertices_um'];facets=[]
for a,b in zip(core,core[1:]+core[:1]):
    nx,ny=b[1]-a[1],a[0]-b[0];d=gcd(abs(nx),abs(ny));nx//=d;ny//=d;support=nx*a[0]+ny*a[1];assert all(nx*x+ny*y<=support for x,y in core);facets.append([nx,ny,support])
low=min(y for x,y in core)+1;high=max(y for x,y in core)-1;boundaries=[low+(high-low)*i//16 for i in range(17)];strips=[]
for lo,hi in zip(boundaries,boundaries[1:]):
    left=[];right=[]
    for nx,ny,support in facets:
        if nx<0:left.extend(F(support-ny*y,nx) for y in [lo,hi])
        elif nx>0:right.extend(F(support-ny*y,nx) for y in [lo,hi])
        else:assert max(ny*lo,ny*hi)<=support
    a,b=ceil(max(left)),floor(min(right));assert a<b and lo<hi;strips.append([a,lo,b,hi])
area=sum((r[2]-r[0])*(r[3]-r[1]) for r in strips);core_twice=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(core,core[1:]+core[:1]));assert 0<2*area<core_twice
write(OUT/'core-facets.json',facets);write(OUT/'strips.json',strips);write(OUT/'geometry.json',{'bands_per_cog':16,'rectangle_area_um2':area,'core_area_um2':str(F(core_twice,2)),'area_fraction':str(F(2*area,core_twice)),'total_new_intervals':64,'existing_orthogonal_pieces':16,'future_global_pieces':48,'per_cog_strip_interiors_disjoint':True,'unchanged_cog_facet_predicates_required':True})
write(OUT/'necessity-proof.json',{'subset':'Every rectangle corner satisfies every half-plane of the convex32-vertex filled-source cog core, hence the whole rectangle is contained. The16 strip interiors are mutually disjoint by their y intervals. Translation by the same center preserves both facts. Each source cog contains the whole core at every legal angle, as proved in the referenced source preflight.','global_no_overlap':'The existing exact core disjunctions already separate each cog core from all orthogonal pieces and the other cog core. Bracket/insert rectangles already obey global NoOverlap2D. Therefore adding the translated cog strips to that same global constraint is redundant for every feasible current necessary-model assignment, including absent-owner controls.','capacity':'For rectangles within one common bounding box, at every x the sum of active rectangle heights is at most the box height, and at every y the sum of active widths is at most its width. Any future cumulative constraints must use a single independently proved box containing every model rectangle, including the expanded stock and coarser anchor bounds. Using tighter original stock bounds without proof would be unsound.','limits':'Only local strip geometry and its necessity argument are prepared here. No cumulative capacity constant, CP model, solver call, source13 layout, source66 layout, native result or H5 completion is claimed. The two earlier solver calls remain closed.'})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'rectangles_per_cog':16,'future_total_global_pieces':48,'independent_audit_pending':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'geometry.json'),flush=True)
