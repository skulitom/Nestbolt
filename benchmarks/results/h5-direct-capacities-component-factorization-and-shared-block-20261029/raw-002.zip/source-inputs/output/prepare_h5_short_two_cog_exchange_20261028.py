"""Fresh source geometry for the six frozen short-sheet exchange variants."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_vector_source_minkowski_20261028 import triangles,obstacle
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight';OUT=ROOT/'output/h5-short-two-cog-exchange-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for child in getattr(g,'geoms',[]) for p in polygons(child)]
class PreparationBudget(Exception):pass
def prepare():
    OUT.mkdir();(OUT/'obstacles').mkdir();(OUT/'cases').mkdir();(OUT/'free').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();pre=load(PRE/'plan.json');assert load(PRE/'checks.json')['passed'] and pre['future_geometry_preparation_seconds']==120
    def budget():
        if time.perf_counter()-started>=120:raise PreparationBudget()
    for n,h in pre['inputs'].items():assert digest(ROOT/n)==h,n
    inputs=[PRE/'plan.json',PRE/'checks.json',PRE/'allocation-review.json',PRE/'parent-source12.json',PRE/'parent-source-checks.json',PRE/'proposed-mover-modes.json',PRE/'case-summary.json',JOB,Path(__file__),ROOT/'output/h5_vector_source_minkowski_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']+list((PRE/'cases').glob('*.json'));radius=(pre['required_pair_gap_mm']+pre['new_moving_stock_extra_mm'])/math.cos(math.pi/64)
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_stock':pre['source_stock'],'required_pair_gap_mm':pre['required_pair_gap_mm'],'stock_guard_mm':pre['stock_guard_mm'],'new_moving_stock_extra_mm':pre['new_moving_stock_extra_mm'],'construction_obstacle_radius_mm':radius,'independent_required_obstacle_radius_mm':pre['required_pair_gap_mm']/math.cos(math.pi/64)+1e-7,'geometry_preparation_seconds':120,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'cog_pose_cap':10000,'retry_permitted':False,'cog_mode_order':pre['future_cog_phase_mode_indices'],'insert_mode_order':pre['future_insert_mode_indices'],'method':'Reconstruct every fixed-type and moving-mode filled outline from the original job. Obtain complete constrained triangle partitions and vectorized convex Minkowski hulls; do not reuse a different fixed-world free region. Prepare all fixed-type/moving-mode and moving-cog/insert source obstacles with an explicit conservative mitred buffer. Clip all6x38 free domains to unchanged source stock plus the declared moving guard. Prove complete original-source obstacle containment independently before the frozen finite enumeration. Every unassigned original remains in the53-part first-sheet inventory.','target_short_counts':[5,6,2],'mandatory_first_counts':[18,7,15,13],'solver_calls':0,'native_calls':0,'H5_complete':False})
    job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(PRE/'proposed-mover-modes.json');mm={m['index']:m for m in modes};assert list(mm)==list(range(36))+[44,45];shutil.copyfile(PRE/'proposed-mover-modes.json',OUT/'modes.json');parent=load(PRE/'parent-source12.json')
    def polygon(family,angle,mirrored,offset=(0.,0.)):
        c,s=math.cos(angle),math.sin(angle);sign=-1 if mirrored else 1
        return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in parts[family]['geometry'][0]['outer']])
    keys=sorted({(r['part_id'],r['transform']['rotation_radians'],r['transform']['mirrored']) for r in parent});fixed=[];fg={};ft={};mg={};mt={};obs={};records=[];total_hulls=0
    for i,(family,a,mir) in enumerate(keys):
        g=polygon(family,a,mir);fg[i]=g;ft[i]=triangles(g);fixed.append({'id':i,'family':family,'angle':a,'mirrored':mir,'geometry':mapping(g),'source_triangles':len(ft[i])})
    for mi,m in mm.items():
        g=polygon(m['family'],m['angle'],m['mirrored'],m['source_translation_offset']);assert g.equals_exact(shape(m['geometry']),1e-10);mg[mi]=g;mt[mi]=triangles(g)
    write(OUT/'fixed-types.json',fixed)
    for f in fixed:
        for mi in mm:
            budget();g,count=obstacle(ft[f['id']],mt[mi],radius);name=f"fixed-{f['id']:02d}-move-{mi:02d}.json";write(OUT/'obstacles'/name,{'fixed_type':f['id'],'moving_mode':mi,'hulls':count,'geometry':mapping(g)});obs[f['id'],mi]=g;records.append({'kind':'fixed-moving','fixed_type':f['id'],'moving_mode':mi,'hulls':count,'file':name});total_hulls+=count
        print({'fixed_type_complete':f['id'],'seconds':time.perf_counter()-started},flush=True)
    for mi in range(36):
        for ii in [44,45]:
            budget();g,count=obstacle(mt[mi],mt[ii],radius);name=f'cog-{mi:02d}-insert-{ii:02d}.json';write(OUT/'obstacles'/name,{'cog_mode':mi,'insert_mode':ii,'hulls':count,'geometry':mapping(g)});records.append({'kind':'cog-insert','cog_mode':mi,'insert_mode':ii,'hulls':count,'file':name});total_hulls+=count
    write(OUT/'obstacle-index.json',records);cases=[];samples=[];nonempty_cog=nonempty_insert=0;stock=pre['source_stock'];extra=pre['new_moving_stock_extra_mm'];key_ids={k:i for i,k in enumerate(keys)}
    for summary in load(PRE/'case-summary.json'):
        removed=summary['removed_bracket_copy'];case=load(PRE/'cases'/f'{removed:02d}.json');refs=[{'fixed_type':key_ids[r['part_id'],r['transform']['rotation_radians'],r['transform']['mirrored']],'identity':[r['part_id'],r['copy_index']],'translation':r['transform']['translation']} for r in case['fixed11']];case['fixed_references']=refs;write(OUT/'cases'/f'{removed:02d}.json',case);folder=OUT/'free'/f'{removed:02d}';folder.mkdir()
        for mi,m in mm.items():
            budget();a,b,c,d=mg[mi].bounds;bounds=[stock[0]+extra-a,stock[1]+extra-b,stock[2]-extra-c,stock[3]-extra-d];legal=box(*bounds);world=[translate(obs[r['fixed_type'],mi],*r['translation']) for r in refs];free=legal.difference(unary_union(world));assert free.is_valid;write(folder/f'{mi:02d}.json',{'removed_bracket_copy':removed,'moving_mode':mi,'anchor_stock_bounds_mm':bounds,'geometry':mapping(free)});nonempty_cog+=int(mi<36 and not free.is_empty);nonempty_insert+=int(mi>=44 and not free.is_empty)
            for p in polygons(free):
                xy=list(p.representative_point().coords)[0];moving={'part_id':m['family'],'copy_index':dict(case['new_moving_originals'])[m['family']],'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in [0,1]]}};read=audit(job,case['fixed11']+[moving],{'sheet-1':stock},pre['required_pair_gap_mm'],pre['stock_guard_mm']);assert read['valid'];samples.append({'removed_bracket_copy':removed,'mode':mi,'anchor':xy,'source_originals':12,'minimum_pair_gap_mm':read['minimum_pair_gap_mm'],'minimum_extra_stock_mm':read['minimum_extra_stock_mm']})
        cases.append({'removed_bracket_copy':removed,'fixed_originals':11,'source_originals_required':13,'first_originals_required':53});print({'case_complete':removed,'seconds':time.perf_counter()-started},flush=True)
    budget();write(OUT/'case-summary.json',cases);write(OUT/'free-source-samples.json',samples);write(OUT/'prepared.json',{'passed':True,'seconds':time.perf_counter()-started,'preparation_closed':True,'fixed_source_types':len(fixed),'moving_source_modes':len(mm),'fixed_moving_obstacles':len(fixed)*len(mm),'moving_cog_insert_obstacles':72,'convex_minkowski_hulls':total_hulls,'fixed11_variants':6,'free_domains':6*len(mm),'cog_free_queries':216,'nonempty_cog_free_domains':nonempty_cog,'nonempty_insert_free_domains':nonempty_insert,'source_representative_samples':len(samples),'independent_preflight_pending':True,'construction_opened':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'),flush=True)
if __name__=='__main__':
    try:prepare()
    except Exception as e:
        if OUT.exists():write(OUT/'preparation-failure.json',{'exception_type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'closed':True,'construction_opened':False,'retry_permitted':False})
        raise
