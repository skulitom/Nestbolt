"""Prepare a fresh bounded runner and an explicit12/54 source reader."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short12-20261029';OLD=ROOT/'output/h5-source-projection-short-core-20261029';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();assert load(BASE/'model-audit/checks.json')['passed']
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
oldrunner=ROOT/'output/run_h5_source_projection_short_core_20261029.py';oldchecker=ROOT/'output/check_h5_source_projection_short_core_candidate_20261029.py';runner=oldrunner.read_text(encoding='utf-8');checker=oldchecker.read_text(encoding='utf-8')
for a,b in [("output/h5-source-projection-short-core-20261029'","output/h5-source-projection-short12-20261029'"),("MODEL=BASE/'model-v3'","MODEL=BASE/'model'"),('check_h5_source_projection_short_core_candidate_20261029','check_h5_source_projection_short12_candidate_20261029'),("BASE/'preflight-v2/audit'","ROOT/'output/h5-source-projection-short-core-20261029/preflight-v2/audit'"),('short13','short12'),('source_valid13','source_valid12')]:runner=replace(runner,a,b)
for a,b in [("output/h5-source-projection-short-core-20261029'","output/h5-source-projection-short12-20261029'"),("BASE/'model-v3/","BASE/'model/"),("inventory=load(PRE/'inventory.json')","inventory=load(ROOT/'output/h5-source-projection-short-core-20261029/next-short12-preflight/inventory.json')"),("PRE/'inventory.json',PRE/'modes.json'","ROOT/'output/h5-source-projection-short-core-20261029/next-short12-preflight/inventory.json',PRE/'modes.json'"),('short13','short12'),('source13','source12'),('core13','core12'),('source_valid13','source_valid12'),('all13','all12'),('first53','first54'),('len(orth)==11','len(orth)==10'),('len(decoded)==13','len(decoded)==12'),("'originals':13","'originals':12"),('orthogonal-source11','orthogonal-source10'),('orthogonal_source11','orthogonal_source10')]:
    # source13 and core13 replacements may have already changed some longer labels.
    if a in checker:checker=checker.replace(a,b)
    else:assert a in ['source_valid13'],a
checker=replace(checker,"    assert values[item['presence']]==1;family,copy=item['identity'];xy=", "    if item['identity']==['insert',0]:\n        assert values[item['presence']]==0 and item['index']==mp['inactive_short_owner'] and item['identity'] in inventory['mandatory_first54_identities'] and item['identity'] not in inventory['short12_identities'];continue\n    assert values[item['presence']]==1;family,copy=item['identity'];xy=")
checker=replace(checker,"piece_pairs=0", "allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};shortids=set(map(tuple,inventory['short12_identities']));firstids=set(map(tuple,inventory['mandatory_first54_identities']));assert len(shortids)==12 and len(firstids)==54 and not shortids&firstids and shortids|firstids==allids and mp['short12_identities']==inventory['short12_identities'] and mp['mandatory_first54_identities']==inventory['mandatory_first54_identities']\npiece_pairs=0")
assert 'source_valid12' in runner and 'source_valid12' in checker and 'source_short12_verified' in runner and 'short13_identities' not in checker and 'model-v3' not in checker
newrunner=ROOT/'output/run_h5_source_projection_short12_20261029.py';newchecker=ROOT/'output/check_h5_source_projection_short12_candidate_20261029.py'
for p,s in [(newrunner,runner),(newchecker,checker)]:compile(s,str(p),'exec');assert not p.exists()
for p,s in [(newrunner,runner),(newchecker,checker)]:
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
out=BASE/'call-preparation';out.mkdir();inputs=[Path(__file__),oldrunner,oldchecker,newrunner,newchecker,BASE/'plan.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',OLD/'next-short12-preflight/plan.json']
with (out/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'short_required':12,'first_required':54,'inactive_only':['insert',0],'candidate_cog_phases':[7.0]+[k/2 for k in range(36) if k!=14],'maximum_phase_pairs':1296,'source_center_parsed_with_fraction':True,'source_candidate_pipeline_not_yet_exercised':True,'solver_calls':0},f,indent=2);f.write('\n')
print('New short12 runner/reader prepared; all66 global identities explicitly required. No call opened.')
