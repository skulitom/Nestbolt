"""Create distinct runner and candidate reader after the extension audit passes."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-short-core-20261029';assert json.loads((BASE/'model-audit/checks.json').read_bytes())['passed']
for old,new in [('run_h5_coarse_short_core_20261029.py','run_h5_strip_capacity_short_core_20261029.py'),('check_h5_coarse_short_core_candidate_20261029.py','check_h5_strip_capacity_short_core_candidate_20261029.py')]:
    source=(ROOT/'output'/old).read_text(encoding='utf-8');assert "output/h5-coarse-short-core-20261029'" in source
    source=source.replace("output/h5-coarse-short-core-20261029'","output/h5-strip-capacity-short-core-20261029'").replace('h5_coarse_short_core_reader_20261029','h5_strip_capacity_short_core_reader_20261029').replace('check_h5_coarse_short_core_candidate_20261029','check_h5_strip_capacity_short_core_candidate_20261029')
    if old.startswith('run_'):
        source=source.replace("for folder in [BASE,MODEL,BASE/'model-audit',PRE/'audit']:","for folder in [BASE,MODEL,BASE/'model-audit',BASE/'preflight/audit',PRE/'audit']:")
    compile(source,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('Distinct runner and corrected candidate reader written. No search opened.')
