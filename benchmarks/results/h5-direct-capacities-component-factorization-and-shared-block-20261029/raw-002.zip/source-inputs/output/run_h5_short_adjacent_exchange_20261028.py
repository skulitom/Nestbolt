"""Freeze inputs and supervise exactly one construction inside the shared 90-second limit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-adjacent-exchange-20261028';OUT=BASE/'search';SCRIPT=ROOT/'output/search_h5_short_adjacent_exchange_20261028.py';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'] and not OUT.exists()
OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');shutil.copyfile(SCRIPT,OUT/'construct.py')
inputs=[Path(__file__),SCRIPT,ROOT/'output/h5_legacy64_source_readback.py',BASE/'plan.json',BASE/'audit/plan.json',BASE/'audit/checks.json',BASE/'modes.json',BASE/'case.json',BASE/'selected-inventories.json',BASE/'obstacle-index.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']+sorted((BASE/'free').glob('*.json'))+[ROOT/r['source_path'] for r in load(BASE/'obstacle-index.json')]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'algorithm_seconds':60,'shared_seconds':90,'maximum_joint_cog_bracket_anchors':10000,'retry_permitted':False})
start=time.perf_counter();timeout=False
with (OUT/'stdout.txt').open('x',encoding='utf-8',newline='\n') as out,(OUT/'stderr.txt').open('x',encoding='utf-8',newline='\n') as err:
    process=subprocess.Popen([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(SCRIPT)],cwd=ROOT,stdout=out,stderr=err)
    try:code=process.wait(timeout=90)
    except subprocess.TimeoutExpired:timeout=True;process.kill();code=process.wait()
elapsed=time.perf_counter()-start
write(OUT/'supervisor-result.json',{'closed':True,'child_returncode':code,'shared_seconds':elapsed,'shared_limit_seconds':90,'shared_soft_overrun_seconds':max(0,elapsed-90),'shared_timeout':timeout,'construction_calls':1,'retry_permitted':False})
print(load(OUT/'supervisor-result.json'),flush=True)
if (OUT/'result.json').exists():print(load(OUT/'result.json'),flush=True)
assert code==0 and not timeout
