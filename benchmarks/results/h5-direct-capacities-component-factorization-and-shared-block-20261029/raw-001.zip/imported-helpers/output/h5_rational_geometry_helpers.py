"""Exact rational containment and conservative trigonometric transform intervals."""
from fractions import Fraction as F
from functools import lru_cache
import math
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    v=[x*y for x in a for y in b];return min(v),max(v)
@lru_cache(None)
def trig(a):
    a=F(a);s=sum(((-1)**k*a**(2*k+1)/math.factorial(2*k+1) for k in range(30)),F(0));c=sum(((-1)**k*a**(2*k)/math.factorial(2*k) for k in range(30)),F(0));e=abs(a)**60/math.factorial(60);return (s-e,s+e),(c-e,c+e)
def point_bounds(point,t):
    x,y=map(F,point);s,c=trig(F(t['rotation_radians']));mi=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation']);return add(sub(mul((mi*x,mi*x),c),mul((y,y),s)),(tx,tx)),add(add(mul((mi*x,mi*x),s),mul((y,y),c)),(ty,ty))
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def contains(vertices,p):
    winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        cr=cross(a,b,p)
        if cr==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1]):return True
        if a[1]<=p[1]<b[1] and cr>0:winding+=1
        if b[1]<=p[1]<a[1] and cr<0:winding-=1
    return winding!=0
