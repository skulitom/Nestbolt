"""Deterministic exact four-dimensional rectangle coverage; no original-placement claim."""
from fractions import Fraction as F
import time

def planes(poly):
    return [(-(b[1]-a[1]),b[0]-a[0],-(b[1]-a[1])*a[0]+(b[0]-a[0])*a[1]) for a,b in zip(poly,poly[1:]+poly[:1])]
def project(r,kind):
    if kind=='fixed0':return [r[0],r[1],r[4],r[5]]
    if kind=='fixed1':return [r[2],r[3],r[6],r[7]]
    assert kind=='pair'
    return [r[2]-r[4],r[3]-r[5],r[6]-r[0],r[7]-r[1]]
def covered(r,pp):return all(a*(r[0] if a>=0 else r[2])+b*(r[1] if b>=0 else r[3])>=c for a,b,c in pp)
def contains(p,pp):return all(a*p[0]+b*p[1]>=c for a,b,c in pp)
def certificate(bounds,obstacles,max_nodes,max_depth,deadline):
    prepared=[]
    for o in obstacles:
        poly=o['vertices_um'];prepared.append((o['kind'],planes(poly),[min(p[0] for p in poly),min(p[1] for p in poly),max(p[0] for p in poly),max(p[1] for p in poly)]))
    nodes=[];pending=[(list(map(F,bounds)),0,None,None)];witness=None;limit=None
    while pending:
        if len(nodes)>=max_nodes:limit='node cap';break
        if time.perf_counter()>=deadline:limit='shared proof wall limit';break
        r,depth,parent,side=pending.pop();idx=len(nodes);node={'bounds_um':list(map(str,r)),'depth':depth};nodes.append(node)
        if parent is not None:nodes[parent][side]=idx
        projected={k:project(r,k) for k in ['fixed0','fixed1','pair']};found=None
        for oi,(kind,pp,bb) in enumerate(prepared):
            q=projected[kind]
            if q[0]>=bb[0] and q[1]>=bb[1] and q[2]<=bb[2] and q[3]<=bb[3] and covered(q,pp):found=oi;break
        if found is not None:node['covered_by']=found;continue
        middle=[(r[k]+r[k+4])/2 for k in range(4)]
        if all(not contains(middle[:2] if kind=='fixed0' else middle[2:] if kind=='fixed1' else [middle[2]-middle[0],middle[3]-middle[1]],pp) for kind,pp,bb in prepared):
            witness=list(map(str,middle));node['relaxation_witness_um']=witness;break
        if depth>=max_depth:limit='depth cap';node['unresolved']=True;break
        axis=max(range(4),key=lambda k:r[k+4]-r[k]);mid=(r[axis]+r[axis+4])/2;a=r[:];b=r[:];a[axis+4]=mid;b[axis]=mid;node['split_axis']=axis
        pending.append((b,depth+1,idx,'right'));pending.append((a,depth+1,idx,'left'))
    return {'covered':not pending and witness is None and limit is None,'nodes':nodes,'unprocessed_boxes':len(pending),'relaxation_witness_um':witness,'limit':limit}
