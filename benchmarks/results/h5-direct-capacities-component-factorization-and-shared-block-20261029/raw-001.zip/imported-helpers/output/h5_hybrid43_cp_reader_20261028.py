"""Pure full protobuf delta reader; every old and new field is accounted for."""
from itertools import combinations
from h5_transfer43_cp_reader_20261028 import violations
def inspect(p,mp,old,oldmp,modes,relative,control,negative,hints_saved,partial_saved,negative_saved):
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
    assert mp['items']==oldmp['items'] and mp['orders']==oldmp['orders'];assert mp['base_variable_count']==len(old.variables) and mp['base_constraint_count']==len(old.constraints)
    replaced=[oldmp[k] for k in ['no_overlap_2d','x_cumulative','y_cumulative']];assert mp['replaced_base_constraints']==replaced
    for i,v in enumerate(old.variables):assert p.variables[i]==v
    for i,ct in enumerate(old.constraints):
        if i not in replaced:assert p.constraints[i]==ct
    seenvars=set(range(len(old.variables)));seencts=set(range(len(old.constraints)))-set(replaced);control={r['block']:r for r in control};negative={r['block']:r for r in negative};values={};bad={};hints={};MIN=-9223372036854775808;MAX=9223372036854775807
    def linear(ix,coeffs,lo=MIN,hi=MAX,on=()):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and {f.name for f,v in ct.ListFields()}<= {'linear','enforcement_literal'};assert list(ct.enforcement_literal)==list(on) and dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
    covered=set()
    for row,group in zip([40,41,42],mp['collision_groups']):
        assert group['row']==row;xs=[];ys=[];widths=[];heights=[];owners=[]
        for item in mp['items']:
            if item['source_block']['family']=='cog-row' and item['index']!=row:continue
            owners.append(item['index'])
            for option in item['options']:
                for component,(a,b,c,d) in zip(option['components'],modes[option['mode']]['cover_rectangles_um']):xs.append(component['x_interval']);ys.append(component['y_interval']);widths.append(c-a);heights.append(d-b)
        covered.update(combinations(owners,2));assert (group['xs'],group['ys'],group['widths'],group['heights'])==(xs,ys,widths,heights)
        ix,xc,yc=group['constraints'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'} and list(ct.no_overlap_2d.x_intervals)==xs and list(ct.no_overlap_2d.y_intervals)==ys
        for ix,intervals,demands,cap in [(xc,xs,heights,2987202),(yc,ys,widths,1487202)]:
            assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'cumulative'} and list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(demands);assert ct.cumulative.capacity.offset==cap and {f.name for f,v in ct.cumulative.capacity.ListFields()}=={'offset'}
            for e,d in zip(ct.cumulative.demands,demands):assert e.offset==d and {f.name for f,v in e.ListFields()}=={'offset'}
    assert len(mp['collision_groups'])==3 and mp['collision_groups'][0]['constraints']==replaced
    for item in mp['items']:
        i=item['index'];known=control.get(i);values[item['presence']]=int(known is not None);bad[item['presence']]=1;hints[item['presence']]=1
        for axis,j in [('x',0),('y',1)]:
            values[item[axis]]=known['anchor_um'][j] if known else 0;bad[item[axis]]=negative[i]['anchor_um'][j]
            if known:hints[item[axis]]=values[item[axis]]
        for option in item['options']:
            values[option['selector']]=int(known is not None and known['mode']==option['mode']);bad[option['selector']]=int(negative[i]['mode']==option['mode'])
            if known:hints[option['selector']]=values[option['selector']]
    assert [(r['left'],r['right']) for r in mp['row_pairs']]==[(40,41),(40,42),(41,42)]
    for pair in mp['row_pairs']:
        li,ri=pair['left'],pair['right'];a,b=mp['items'][li],mp['items'][ri];key=f"{a['source_block']['row_size']}-{b['source_block']['row_size']}";assert pair['region']==key;cells=relative[key]['cells'];assert len(cells)==len(pair['selectors'])==len(pair['plane_constraints']);delta=[control[ri]['anchor_um'][j]-control[li]['anchor_um'][j] for j in [0,1]];selected=next(k for k,c in enumerate(cells) if all(aa*delta[0]+bb*delta[1]>=cc for aa,bb,cc in c['halfplanes']))
        for k,(cell,s,cts) in enumerate(zip(cells,pair['selectors'],pair['plane_constraints'])):
            assert s not in seenvars;seenvars.add(s);v=p.variables[s];assert v.name==f'row_pair_{li}_{ri}_cell_{k}' and list(v.domain)==[0,1] and {f.name for f,z in v.ListFields()}=={'name','domain'};values[s]=int(k==selected);bad[s]=0;hints[s]=values[s];assert len(cts)==len(cell['halfplanes'])
            for ix,(aa,bb,cc) in zip(cts,cell['halfplanes']):linear(ix,{v:c for v,c in [(a['x'],-aa),(b['x'],aa),(a['y'],-bb),(b['y'],bb)] if c},lo=cc,on=[s])
        linear(pair['choice'],{s:1 for s in pair['selectors']},1,1);covered.add((li,ri))
    assert covered==set(combinations(range(43),2)) and len(covered)==903
    assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)))
    assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in hints_saved.items()} and len(p.solution_hint.vars)==len(hints)
    assert partial_saved==[values[i] for i in range(len(p.variables))] and negative_saved==[bad[i] for i in range(len(p.variables))]
    disabled=[r['mandatory'] for r in mp['items'] if r['index'] not in control];assert disabled==mp['control_disabled_mandatory_constraints'] and len(disabled)==5
    return {'passed':True,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'mandatory_blocks':43,'originals':66,'covered_block_pairs':903,'all_old_fields_preserved_except3_collision_constraints_and_hints':True,'all_new_fields_verified':True,'control_missing_brackets':5,'hints_verified':len(hints)},disabled
