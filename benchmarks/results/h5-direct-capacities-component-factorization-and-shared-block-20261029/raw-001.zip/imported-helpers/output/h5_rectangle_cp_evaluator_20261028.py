"""Pure saved-protobuf assignment evaluator; no solver or filesystem operations."""
from itertools import combinations
def evaluate(model,solution,objective):
    assert len(solution)==len(model.variables)
    for v,x in zip(model.variables,solution):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(v):return bool(solution[v]) if v>=0 else not bool(solution[-v-1])
    def ev(e):return e.offset+sum(c*solution[v] for v,c in zip(e.vars,e.coeffs))
    def present(ct):return all(truth(v) for v in ct.enforcement_literal)
    pairs=inactive=0
    for ct in model.constraints:
        if not present(ct):inactive+=1;continue
        kind=ct.WhichOneof('constraint')
        if kind=='linear':
            value=sum(c*solution[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='exactly_one':assert sum(truth(v) for v in ct.exactly_one.literals)==1
        elif kind=='interval':assert ev(ct.interval.start)+ev(ct.interval.size)==ev(ct.interval.end) and ev(ct.interval.size)>0
        elif kind=='no_overlap_2d':
            rectangles=[]
            for a,b in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
                x,y=model.constraints[a],model.constraints[b];assert present(x)==present(y)
                if present(x):rectangles.append([ev(x.interval.start),ev(y.interval.start),ev(x.interval.end),ev(y.interval.end)])
            for a,b in combinations(rectangles,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
        elif kind=='cumulative':
            events={}
            for ix,d in zip(ct.cumulative.intervals,ct.cumulative.demands):
                interval=model.constraints[ix]
                if not present(interval):continue
                begin,end,amount=ev(interval.interval.start),ev(interval.interval.end),ev(d)
                events[begin]=events.get(begin,0)+amount;events[end]=events.get(end,0)-amount
            total=0;capacity=ev(ct.cumulative.capacity)
            for where,delta in sorted(events.items()):total+=delta;assert 0<=total<=capacity
            assert total==0
        else:raise AssertionError(kind)
    result=model.objective.scaling_factor*(model.objective.offset+sum(c*solution[v] for v,c in zip(model.objective.vars,model.objective.coeffs)))
    assert result==objective
    return {'variables':len(solution),'constraints':len(model.constraints),'inactive':inactive,'expanded_pairs':pairs}
