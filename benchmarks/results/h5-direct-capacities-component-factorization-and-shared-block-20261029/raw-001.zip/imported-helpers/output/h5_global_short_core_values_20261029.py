"""Pure complete assignments for saved global short-sheet controls."""
def control_values(variable_count,mapping,modes,control):
    known={tuple(r['identity']):r for r in control};byfamily={f:{m['mode']:m for m in modes if m['family']==f} for f in ['bracket','insert']};values={}
    for item in mapping['items']:
        row=known.get(tuple(item['identity']));present=int(row is not None);values[item['presence']]=present
        if item['family']=='cog':
            anchor=row['anchor_um'] if row else item['stock_bounds_um'][:2];values[item['x']],values[item['y']]=anchor
        else:
            mi=row['mode'] if row else 0;m=byfamily[item['family']][mi];values[item['mode']]=mi;anchor=row['anchor_um'] if row else m['anchor_stock_bounds_um'][:2];values[item['x']],values[item['y']]=anchor
            for ix,v in zip(item['stock_variables'],m['anchor_stock_bounds_um']):values[ix]=v
            for component,r in zip(item['pieces'],m['rectangles_um']):
                for ix,v in zip(component['local_variables'],r):values[ix]=v
                a,b,c,d=r;world=[anchor[0]+a,anchor[1]+b,anchor[0]+c,anchor[1]+d,c-a,d-b]
                for ix,v in zip(component['world_variables'],world):values[ix]=v
    for pair in mapping['facet_pairs']:
        active=all(values[p] for p in pair['presences']);selected=False
        for f in pair['facets']:
            good=sum(c*values[int(v)] for v,c in f['coefficients'].items())>=f['lower_bound'];chosen=int(active and good and not selected);values[f['selector']]=chosen;selected|=bool(chosen)
    assert set(values)==set(range(variable_count))
    return [values[i] for i in range(variable_count)]
