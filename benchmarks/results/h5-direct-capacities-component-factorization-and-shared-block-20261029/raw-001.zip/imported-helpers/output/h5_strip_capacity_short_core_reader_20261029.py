"""Independent strip-model extension reader and exact cumulative assignment checks."""
from h5_coarse_short_core_reader_20261029 import violations as core_violations
def inspect(p,parent,mp,parent_mp,strips,bounds,pos,neg,oldpos,oldneg,hints):
    n,m,h=len(parent.variables),len(parent.constraints),len(parent.solution_hint.vars);assert mp['parent_counts']=={'variables':n,'constraints':m,'hints':h}
    prefix=type(p)();prefix.CopyFrom(p);del prefix.variables[n:];del prefix.constraints[m:];del prefix.solution_hint.vars[h:];del prefix.solution_hint.values[h:];assert prefix==parent
    keys=['parent_counts','common_box_um','cog_strips','strip_global_no_overlap','capacity_x','capacity_y'];assert {k:v for k,v in mp.items() if k not in keys}==parent_mp and mp['common_box_um']==bounds['common_box_um']
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'} and pos[:n]==oldpos and neg[:n]==oldneg;seenvars=set();seencts=set();allx=[];ally=[];dx=[];dy=[];extra={}
    for item in parent_mp['items']:
        for piece in item['pieces']:allx.append(piece['x_interval']);ally.append(piece['y_interval']);dx.append(('var',piece['world_variables'][5]));dy.append(('var',piece['world_variables'][4]))
    def ct(ix,kind,on=(),name=None):
        assert ix>=m and ix not in seencts;seencts.add(ix);c=p.constraints[ix];assert c.WhichOneof('constraint')==kind and list(c.enforcement_literal)==list(on) and {f.name for f,v in c.ListFields()}=={kind}|({'enforcement_literal'} if on else set())|({'name'} if name else set())
        if name:assert c.name==name
        return c
    def expr(e,value):
        kind,term=value
        if kind=='var':assert list(e.vars)==[term] and list(e.coeffs)==[1] and e.offset==0 and {f.name for f,v in e.ListFields()}=={'vars','coeffs'}
        else:assert not e.vars and not e.coeffs and e.offset==term and {f.name for f,v in e.ListFields()}=={'offset'}
    expected=[(i,k,r) for i in parent_mp['items'] if i['family']=='cog' for k,r in enumerate(strips)];assert len(mp['cog_strips'])==len(expected)==32
    for piece,(owner,k,r) in zip(mp['cog_strips'],expected):
        assert piece['owner']==owner['index'] and piece['component']==k and piece['local_rectangle_um']==r;wv=piece['world_variables'];links=piece['link_constraints'];assert len(wv)==len(links)==4;b=owner['stock_bounds_grid_units']
        for axis,(ix,local,link) in enumerate(zip(wv,r,links)):
            ai=axis%2;anchor=owner['x' if ai==0 else 'y'];assert ix>=n and ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==f'strip_world_{owner["index"]}_{k}_{axis}' and list(v.domain)==[100*b[ai]+local,100*b[ai+2]+local] and {f.name for f,z in v.ListFields()}=={'name','domain'}
            c=ct(link,'linear');assert dict(zip(c.linear.vars,c.linear.coeffs))=={ix:1,anchor:-100} and len(c.linear.vars)==2 and list(c.linear.domain)==[local,local]
            assert pos[ix]==100*oldpos[anchor]+local and neg[ix]==100*oldneg[anchor]+local
            if oldpos[owner['presence']]:extra[ix]=pos[ix]
        width,height=r[2]-r[0],r[3]-r[1]
        for axis,a,d,bv in [('x',wv[0],width,wv[2]),('y',wv[1],height,wv[3])]:
            c=ct(piece[axis+'_interval'],'interval',[owner['presence']],f'strip_{axis}_{owner["index"]}_{k}');expr(c.interval.start,('var',a));expr(c.interval.size,('constant',d));expr(c.interval.end,('var',bv))
        allx.append(piece['x_interval']);ally.append(piece['y_interval']);dx.append(('constant',height));dy.append(('constant',width))
    c=ct(mp['strip_global_no_overlap'],'no_overlap_2d');assert list(c.no_overlap_2d.x_intervals)==allx and list(c.no_overlap_2d.y_intervals)==ally and len(allx)==48
    for key,intervals,demands,capacity in [('capacity_x',allx,dx,bounds['x_intervals_height_capacity_um']),('capacity_y',ally,dy,bounds['y_intervals_width_capacity_um'])]:
        c=ct(mp[key],'cumulative');assert list(c.cumulative.intervals)==intervals and len(c.cumulative.demands)==48;expr(c.cumulative.capacity,('constant',capacity))
        for e,v in zip(c.cumulative.demands,demands):expr(e,v)
    assert seenvars==set(range(n,len(p.variables))) and seencts==set(range(m,len(p.constraints))) and len(pos)==len(neg)==len(p.variables)
    assert dict(zip(p.solution_hint.vars[h:],p.solution_hint.values[h:]))==extra=={int(k):v for k,v in hints.items()} and len(p.solution_hint.vars)==h+len(extra)
    return {'passed':True,'unchanged_parent_variables':n,'unchanged_parent_constraints':m,'unchanged_parent_hints':h,'new_variables_verified':len(seenvars),'new_constraints_verified':len(seencts),'new_hints_verified':len(extra),'translated_cog_strips_verified':32,'new_global_piece_count':48,'cumulative_constraints_verified':2,'all_model_fields_exhaustively_verified':True}
def violations(p,values,ignored=()):
    q=type(p)();q.CopyFrom(p);del q.constraints[-2:];result=core_violations(q,values,ignored);capacities=[]
    def ev(e):return e.offset+sum(c*values[ix] for ix,c in zip(e.vars,e.coeffs))
    def truth(ix):return bool(values[ix]) if ix>=0 else not bool(values[-ix-1])
    for ix in range(len(p.constraints)-2,len(p.constraints)):
        c=p.constraints[ix];assert c.WhichOneof('constraint')=='cumulative' and not c.enforcement_literal;events={}
        for interval,demand in zip(c.cumulative.intervals,c.cumulative.demands):
            item=p.constraints[interval];assert item.WhichOneof('constraint')=='interval'
            if not all(truth(v) for v in item.enforcement_literal):continue
            start,end,d=ev(item.interval.start),ev(item.interval.end),ev(demand);assert start<end and d>0
            events[start]=events.get(start,0)+d;events[end]=events.get(end,0)-d
        active=peak=0
        for point,delta in sorted(events.items()):active+=delta;peak=max(peak,active)
        assert active==0;capacity=ev(c.cumulative.capacity);capacities.append({'constraint':ix,'capacity':capacity,'peak_demand':peak,'passed':peak<=capacity})
        if peak>capacity and ix not in ignored:result['failed_constraints'].append({'constraint':ix,'kind':'cumulative'})
    result['cumulative_checks']=capacities;return result
