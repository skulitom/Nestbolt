"""Bounded continuous-center proof using an all-angle source-contained cog core."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime, timezone
import json, math, shutil, time
from shapely.geometry import Polygon, box

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short-two-cog-exchange-20261028'
OUT = BASE / 'all-angle-bound'
PRE = ROOT / 'output/h5-fixed-cog-rows-20261028/short-exchange-preflight'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

def cross(o, a, b):
    return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])

def hull(points):
    points = sorted(set(map(tuple, points))); lower = []; upper = []
    for p in points:
        while len(lower) > 1 and cross(lower[-2], lower[-1], p) <= 0: lower.pop()
        lower.append(p)
    for p in reversed(points):
        while len(upper) > 1 and cross(upper[-2], upper[-1], p) <= 0: upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]

def planes(vertices):
    return [(- (b[1]-a[1]), b[0]-a[0], -(b[1]-a[1])*a[0]+(b[0]-a[0])*a[1])
            for a, b in zip(vertices, vertices[1:]+vertices[:1])]

def inside(point, vertices):
    x, y = point; result = False
    for a, b in zip(vertices, vertices[1:]+vertices[:1]):
        if (a[1] > y) != (b[1] > y):
            if x < a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]): result = not result
    return result

def source(points, transform):
    c, s = math.cos(transform['rotation_radians']), math.sin(transform['rotation_radians'])
    sign = -1 if transform['mirrored'] else 1; tx, ty = transform['translation']
    return [(sign*x*c-y*s+tx, sign*x*s+y*c+ty) for x,y in points]

def rect_inward(bounds):
    a,b,c,d = bounds
    return [math.ceil(a*1000)+2, math.ceil(b*1000)+2, math.floor(c*1000)-2, math.floor(d*1000)-2]

def all_rects(row, parts):
    family = row['part_id']; t = row['transform']; poly = Polygon(source(parts[family]['geometry'][0]['outer'], t))
    if family == 'bracket':
        pieces = [[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]]
        return [rect_inward(Polygon(source(p,t)).bounds) for p in pieces]
    if family == 'insert': return [rect_inward(poly.bounds)]
    assert family == 'cog' and t['rotation_radians'] == 0
    a,b,c,d = poly.bounds; strips = []
    for j in range(math.floor(b/5), math.ceil(d/5)):
        run = None
        for i in range(math.floor(a/5), math.ceil(c/5)+1):
            yes = i < math.ceil(c/5) and poly.covers(box(i*5,j*5,(i+1)*5,(j+1)*5))
            if yes and run is None: run = i
            if not yes and run is not None:
                strips.append([run*5,j*5,i*5,(j+1)*5]); run = None
    return [rect_inward(r) for r in strips]

def obstacle(rect, core):
    a,b,c,d = rect
    return hull([(x-u,y-v) for x,y in [(a,b),(c,b),(c,d),(a,d)] for u,v in core])

def enc(rect): return [str(v) for v in rect]

def covered_rectangle(rect, pp):
    return all(A*(rect[0] if A >= 0 else rect[2])+B*(rect[1] if B >= 0 else rect[3]) >= C for A,B,C in pp)

def point_in(p, pp): return all(A*p[0]+B*p[1] >= C for A,B,C in pp)

def certificate(bounds, polygons, max_nodes, max_depth):
    pp = [planes(p) for p in polygons]
    bb = [(min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)) for p in polygons]
    tree = []; pending = [(list(map(F,bounds)),0,None,None)]; witness = None; limit = None
    while pending:
        if len(tree) >= max_nodes: limit = 'node cap'; break
        rect, depth, parent, side = pending.pop(); idx = len(tree)
        node = {'bounds_um':enc(rect),'depth':depth}; tree.append(node)
        if parent is not None: tree[parent][side] = idx
        candidates = [i for i,b in enumerate(bb) if not (b[2]<rect[0] or b[0]>rect[2] or b[3]<rect[1] or b[1]>rect[3])]
        cover = next((i for i in candidates if covered_rectangle(rect,pp[i])),None)
        if cover is not None: node['covered_by'] = cover; continue
        center = [(rect[0]+rect[2])/2,(rect[1]+rect[3])/2]
        if not any(point_in(center,pp[i]) for i in candidates):
            witness = [str(v) for v in center]; node['relaxation_witness_um'] = witness; break
        if depth >= max_depth: limit = 'depth cap'; node['unresolved'] = True; break
        axis = 0 if rect[2]-rect[0] >= rect[3]-rect[1] else 1
        midpoint = (rect[axis]+rect[axis+2])/2; left=rect[:]; right=rect[:]
        left[axis+2]=midpoint; right[axis]=midpoint; node['split_axis']=axis
        pending.append((right,depth+1,idx,'right')); pending.append((left,depth+1,idx,'left'))
    return {'covered':not pending and witness is None and limit is None,
            'nodes':tree,'unprocessed_rectangles':len(pending),'limit':limit,'relaxation_witness_um':witness}

def main():
    OUT.mkdir(); shutil.copyfile(__file__,OUT/'construct.py'); started=time.perf_counter()
    assert load(BASE/'preflight-v2/checks.json')['passed'] and load(BASE/'finite-construction-closure.json')['closed']
    inputs=[Path(__file__),JOB,BASE/'plan.json',BASE/'preflight-v2/plan.json',BASE/'preflight-v2/checks.json',BASE/'finite-construction-closure.json',PRE/'parent-source12.json',PRE/'parent-source-checks.json']+sorted((BASE/'cases').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'max_nodes_per_case':100000,'max_depth':30,'fixed_grid_mm':5,'inward_rounding_um':2,'outward_stock_rounding_um':2,'core_vertices_requested':32,
        'method':'A polygon strictly inside a source-centered disk is contained in the filled cog at every real angle. Exact integer no-fit hulls with fixed source-contained rectangles form necessary forbidden continuous-center regions. Bisect the entire relaxed stock-center rectangle deterministically. A leaf is covered only when all its corners lie in one convex obstacle. Stop each case at the first uncovered relaxation center, node cap, depth cap or complete coverage. No enlarged clearance, coordinate grid on placement, optimizer or retry. Independent exact source/core and complete tree audit required.',
        'optimizer_calls':0,'native_calls':0,'retry_permitted':False,'full_allocation_or_global_infeasibility_claimed':False})
    job=load(JOB); parts={p['id']:p for p in job['parts']}; center=[F('139.723742')]*2
    vv=[tuple(F(str(v)) for v in p) for p in parts['cog']['geometry'][0]['outer']]; assert inside(center,vv)
    distances=[]
    for a,b in zip(vv,vv[1:]+vv[:1]):
        q=[a[i]-center[i] for i in [0,1]]; d=[b[i]-a[i] for i in [0,1]]; dd=sum(v*v for v in d); dot=sum(q[i]*d[i] for i in [0,1])
        t=max(F(0),min(F(1),-dot/dd)); distances.append(sum((q[i]+t*d[i])**2 for i in [0,1]))
    min_d2=min(distances); radius=math.floor(math.sqrt(float(min_d2))*1000)-2
    core=hull([(math.trunc(radius*math.cos(k*math.tau/32)),math.trunc(radius*math.sin(k*math.tau/32))) for k in range(32)])
    assert len(core)==32 and all(F(x*x+y*y,1000000)<min_d2 for x,y in core)
    write(OUT/'moving-core.json',{'source_center_mm':list(map(str,center)),'minimum_segment_distance_squared_mm2':str(min_d2),'radius_um':radius,'vertices_um':core,'all_angle_containment_pending_independent_audit':True})
    parent=load(PRE/'parent-source12.json'); fixed=[{'identity':[r['part_id'],r['copy_index']],'rectangles_um':all_rects(r,parts)} for r in parent]
    write(OUT/'fixed-core-rectangles.json',fixed); fixedmap={tuple(r['identity']):r['rectangles_um'] for r in fixed}
    stock=load(BASE/'plan.json')['source_stock']; bounds=[math.floor(stock[0]*1000)-min(x for x,y in core)-2,math.floor(stock[1]*1000)-min(y for x,y in core)-2,math.ceil(stock[2]*1000)-max(x for x,y in core)+2,math.ceil(stock[3]*1000)-max(y for x,y in core)+2]
    summaries=[]
    for cp in sorted((BASE/'cases').glob('*.json')):
        case=load(cp); obs=[obstacle(r,core) for row in case['fixed11'] for r in fixedmap[row['part_id'],row['copy_index']]]
        cert=certificate(bounds,obs,100000,30); write(OUT/(cp.stem+'-obstacles.json'),obs); write(OUT/(cp.stem+'-certificate.json'),cert)
        row={'removed_bracket_copy':case['removed_short_bracket_copy'],'obstacles':len(obs),'nodes':len(cert['nodes']),'all_continuous_centers_covered':cert['covered'],'relaxation_witness_um':cert['relaxation_witness_um'],'limit':cert['limit']};summaries.append(row);print(row,flush=True)
    existing=next(r for r in parent if r['part_id']=='cog'); positive=[(center[i]+F(str(existing['transform']['translation'][i])))*1000 for i in [0,1]]
    otherobs=[obstacle(r,core) for row in fixed if row['identity']!=['cog',14] for r in row['rectangles_um']]
    assert all(not point_in(positive,planes(p)) for p in otherobs)
    ownobs=[obstacle(r,core) for r in fixedmap['cog',14]];assert any(point_in(positive,planes(p)) for p in ownobs)
    write(OUT/'controls.json',{'positive_existing_cog_center_um':list(map(str,positive)),'positive_control_parent_other11_obstacles':len(otherobs),'positive_outside_every_obstacle':True,'negative_same_center_existing_cog_obstacles':len(ownobs),'negative_occupied_center_rejected':True})
    write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'relaxed_continuous_center_bounds_um':bounds,'source_contained_fixed_rectangles':sum(len(r['rectangles_um']) for r in fixed),'cases':summaries,'covered_cases':sum(r['all_continuous_centers_covered'] for r in summaries),'independent_audit_pending':True,'optimizer_calls':0,'native_calls':0,'all_angle_original_cog_claim_requires_audit':True,'full_allocation_or_global_job_excluded':False,'H5_complete':False})
    print(load(OUT/'result.json'),flush=True)

if __name__=='__main__': main()
