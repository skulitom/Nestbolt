"""Exact polygonal clearance envelope with a circumscribed regular disk."""
import math
import numpy as np
from shapely.geometry import MultiPoint,Point,Polygon,LineString
from shapely.ops import unary_union
from diagnose_h5_concave_gaps import polygons
from conservative_h5_round_obstacles import raw_obstacle
SIDES=128

def disk_vertices(clearance,margin=.0001):
    radius=(clearance+margin)/math.cos(math.pi/SIDES)
    return np.asarray([(radius*math.cos(math.tau*i/SIDES),radius*math.sin(math.tau*i/SIDES)) for i in range(SIDES)])

def expand(raw,clearance,margin=.0001):
    disk=disk_vertices(clearance,margin);pieces=[raw]
    # P + K = P union (boundary(P) + K) for convex K containing zero:
    # a segment from p in P to p+k outside P first crosses the boundary;
    # the remaining offset is still in K. Every boundary segment + K is
    # the convex hull of K translated to its two endpoints. Hole rings count.
    for poly in polygons(raw):
        for ring in [poly.exterior,*poly.interiors]:
            xy=list(ring.coords)
            for a,b in zip(xy,xy[1:]):pieces.append(MultiPoint(np.concatenate([disk+np.asarray(a),disk+np.asarray(b)])).convex_hull)
    return unary_union(pieces)

def obstacle(fixed,moving,clearance,margin=.0001):return expand(raw_obstacle(fixed,moving),clearance,margin)

def circle_check(clearance,margin=.0001):
    xy=list(disk_vertices(clearance,margin));origin=Point(0,0);distances=[origin.distance(LineString([a,b])) for a,b in zip(xy,xy[1:]+xy[:1])]
    assert len(distances)==SIDES and min(distances)>=clearance+margin-1e-14
    return {'sides':SIDES,'construction_radius_mm':float(np.linalg.norm(xy[0])),'minimum_chord_distance_mm':min(distances),'required_clearance_plus_margin_mm':clearance+margin,'all_128_chords_conservative':True,'offset_algorithm':'Union the original polygon with every boundary segment Minkowski-summed with the explicit circumscribed 128-gon; no round/mitre buffer tessellation.'}
