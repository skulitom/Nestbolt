"""Conservative round clearance without mitre amplification of floating-point slivers."""
import math
import numpy as np
from shapely.geometry import MultiPoint,Point
from shapely.ops import unary_union
from diagnose_h5_concave_gaps import convex_pieces
QUAD_SEGS=32

def raw_obstacle(fixed,moving):
    hulls=[]
    for fp in convex_pieces(fixed):
        a=np.asarray(fp.exterior.coords)[:-1]
        for mp in convex_pieces(moving):
            b=np.asarray(mp.exterior.coords)[:-1];hulls.append(MultiPoint((a[:,None,:]-b[None,:,:]).reshape(-1,2)).convex_hull)
    return unary_union(hulls)

def obstacle(fixed,moving,clearance,margin=.0001):
    # A round segment spans at most pi/(2*QUAD_SEGS). Inflate its radius so
    # every chord stays outside the requested clearance-plus-margin circle.
    radius=(clearance+margin)/math.cos(math.pi/(4*QUAD_SEGS))
    return raw_obstacle(fixed,moving).buffer(radius,quad_segs=QUAD_SEGS,join_style='round')

def circle_check(clearance,margin=.0001):
    from shapely.geometry import LineString
    radius=(clearance+margin)/math.cos(math.pi/(4*QUAD_SEGS));origin=Point(0,0);ring=origin.buffer(radius,quad_segs=QUAD_SEGS).exterior;xy=list(ring.coords);distances=[origin.distance(LineString([a,b])) for a,b in zip(xy,xy[1:])]
    assert len(distances)==4*QUAD_SEGS and min(distances)>=clearance+margin-1e-14
    return {'quad_segs':QUAD_SEGS,'construction_radius_mm':radius,'minimum_chord_distance_mm':min(distances),'required_clearance_plus_margin_mm':clearance+margin,'all_128_chords_conservative':True}
