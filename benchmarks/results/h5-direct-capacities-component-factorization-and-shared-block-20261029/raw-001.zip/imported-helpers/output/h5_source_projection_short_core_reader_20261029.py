"""Independently read every appended source-reference variable and constraint."""
from itertools import combinations
MIN=-9223372036854775808
MAX=9223372036854775807
def inspect(p,parent,mp,parentmp,mapping,distances,link,posrefs,negrefs,pos,neg,oldpos,oldneg,hints):
    n,m,h=len(parent.variables),len(parent.constraints),len(parent.solution_hint.vars);assert mp['projection_parent_counts']=={'variables':n,'constraints':m,'hints':h};prefix=type(p)();prefix.CopyFrom(p);del prefix.variables[n:];del prefix.constraints[m:];del prefix.solution_hint.vars[h:];del prefix.solution_hint.values[h:];assert prefix==parent
    added=['projection_parent_counts','projection_items','projection_pairs','insert_projection_intervals','insert_projection_capacity'];assert {k:v for k,v in mp.items() if k not in added}==parentmp and {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
    seenvars=set();seencts=set();good={i:v for i,v in enumerate(oldpos)};bad={i:v for i,v in enumerate(oldneg)};extra={};known={tuple(r['identity']):r for r in posrefs};wrong={tuple(r['identity']):r for r in negrefs};dist={tuple(r['profiles']):r['minimum_reference_distance_um'] for r in distances}
    def var(ix,name,domain,a,b,hint=False):
        assert ix>=n and ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'};good[ix]=a;bad[ix]=b
        if hint:extra[ix]=a
    def ct(ix,kind,on=(),name=None):
        assert ix>=m and ix not in seencts;seencts.add(ix);c=p.constraints[ix];assert c.WhichOneof('constraint')==kind and list(c.enforcement_literal)==list(on) and {f.name for f,z in c.ListFields()}=={kind}|({'enforcement_literal'} if on else set())|({'name'} if name else set())
        if name:assert c.name==name
        return c
    def linear(ix,co,lo=MIN,hi=MAX,on=()):
        c=ct(ix,'linear',on);assert dict(zip(c.linear.vars,c.linear.coeffs))==co and len(c.linear.vars)==len(co) and list(c.linear.domain)==[lo,hi]
    def expr(e,kind,v):
        if kind=='var':assert list(e.vars)==[v] and list(e.coeffs)==[1] and not e.offset and {f.name for f,z in e.ListFields()}=={'vars','coeffs'}
        else:assert not e.vars and not e.coeffs and e.offset==v and {f.name for f,z in e.ListFields()}=={'offset'}
    def table(ix,variables,rows):
        c=ct(ix,'table');assert not c.table.negated and not c.table.vars and len(c.table.exprs)==len(variables) and list(c.table.values)==[v for row in rows for v in row]
        for e,v in zip(c.table.exprs,variables):expr(e,'var',v)
    assert len(mp['projection_items'])==13
    for rec,item in zip(mp['projection_items'],mp['items']):
        i=item['index'];assert rec['owner']==i;family=item['family'];fm=[r for r in mapping if r['family']==family];present=tuple(item['identity']) in known;row=known.get(tuple(item['identity']));wrongrow=wrong[tuple(item['identity'])];gm=next(r for r in fm if r['mode']==(None if family=='cog' else oldpos[item['mode']]));bm=next(r for r in fm if r['mode']==(None if family=='cog' else oldneg[item['mode']]));lo=min(r['prior_reference_domain_um'][0] for r in fm);hi=max(r['prior_reference_domain_um'][1] for r in fm);a=row['reference_x_um'] if row else max(lo,min(hi,100*oldpos[item['x']]+gm['reference_offset_um']));rx=rec['reference_x'];v=rec['variant'];var(rx,f'legacy_x_{i}',[lo,hi],a,wrongrow['reference_x_um'],present);var(v,f'legacy_variant_{i}',[min(r['prior_variant'] for r in fm),max(r['prior_variant'] for r in fm)],gm['prior_variant'],bm['prior_variant'],present);assert rec['profile_ids']==sorted({r['prior_variant'] for r in fm})
        if row:assert row['coarse_x_grid_units']==oldpos[item['x']]
        assert wrongrow['coarse_x_grid_units']==oldneg[item['x']]
        if family=='cog':assert len(rec['links'])==1 and 'selected_fields' not in rec and 'mode_table' not in rec;linear(rec['links'][0],{rx:1,item['x']:-100},link['lower_delta_um'],link['upper_delta_um'],[item['presence']])
        else:
            fields=[('offset',lambda r:r['reference_offset_um']),('lower',lambda r:r['prior_reference_domain_um'][0]),('upper',lambda r:r['prior_reference_domain_um'][1]),('width',lambda r:r['insert_width_um'])];vv=rec['selected_fields'];assert len(vv)==4 and len(rec['links'])==3
            for ix,(label,fn) in zip(vv,fields):var(ix,f'legacy_{label}_{i}',[min(fn(r) for r in fm),max(fn(r) for r in fm)],fn(gm),fn(bm),present)
            rows=[[r['mode'],r['prior_variant'],r['reference_offset_um'],*r['prior_reference_domain_um'],r['insert_width_um']] for r in fm];table(rec['mode_table'],[item['mode'],v,*vv],rows);on=[item['presence']];linear(rec['links'][0],{rx:1,vv[1]:-1},lo=0,on=on);linear(rec['links'][1],{rx:1,vv[2]:-1},hi=0,on=on);linear(rec['links'][2],{rx:1,item['x']:-100,vv[0]:-1},link['lower_delta_um'],link['upper_delta_um'],on)
    expected=list(combinations(mp['projection_items'],2));assert len(expected)==len(mp['projection_pairs'])==78
    for rec,(a,b) in zip(mp['projection_pairs'],expected):
        i,j=a['owner'],b['owner'];assert rec['owners']==[i,j];oi,oj=mp['items'][i],mp['items'][j];rows=[[x,y,dist[x,y],dist[y,x]] for x in a['profile_ids'] for y in b['profile_ids']];knownpair=tuple(oi['identity']) in known and tuple(oj['identity']) in known;df,db,order=rec['forward'],rec['backward'],rec['order'];var(df,f'legacy_forward_{i}_{j}',[min(r[2] for r in rows),max(r[2] for r in rows)],dist[good[a['variant']],good[b['variant']]],dist[bad[a['variant']],bad[b['variant']]],knownpair);var(db,f'legacy_backward_{i}_{j}',[min(r[3] for r in rows),max(r[3] for r in rows)],dist[good[b['variant']],good[a['variant']]],dist[bad[b['variant']],bad[a['variant']]],knownpair);var(order,f'legacy_before_{i}_{j}',[0,1],int(good[a['reference_x']]<=good[b['reference_x']]),int(bad[a['reference_x']]<=bad[b['reference_x']]),knownpair);table(rec['distance_table'],[a['variant'],b['variant'],df,db],rows);on=[oi['presence'],oj['presence']];assert len(rec['constraints'])==2;linear(rec['constraints'][0],{b['reference_x']:1,a['reference_x']:-1,df:-1},lo=0,on=on+[order]);linear(rec['constraints'][1],{a['reference_x']:1,b['reference_x']:-1,db:-1},lo=0,on=on+[-order-1])
    expected=[r for r in mp['projection_items'] if mp['items'][r['owner']]['family']=='insert'];assert len(expected)==len(mp['insert_projection_intervals'])==6;intervals=[]
    for saved,r in zip(mp['insert_projection_intervals'],expected):
        i=r['owner'];assert saved['owner']==i;item=mp['items'][i];rx=r['reference_x'];width=r['selected_fields'][3];end=saved['end'];xd=list(p.variables[rx].domain);wd=list(p.variables[width].domain);var(end,f'legacy_insert_end_{i}',[xd[0]+wd[0],xd[1]+wd[1]],good[rx]+good[width],bad[rx]+bad[width],tuple(item['identity']) in known);linear(saved['link'],{end:1,rx:-1,width:-1},0,0);c=ct(saved['interval'],'interval',[item['presence']],f'legacy_insert_{i}');expr(c.interval.start,'var',rx);expr(c.interval.size,'var',width);expr(c.interval.end,'var',end);intervals.append(saved['interval'])
    c=ct(mp['insert_projection_capacity'],'cumulative');assert list(c.cumulative.intervals)==intervals and len(c.cumulative.demands)==6;expr(c.cumulative.capacity,'constant',2)
    for e in c.cumulative.demands:expr(e,'constant',1)
    assert seenvars==set(range(n,len(p.variables))) and seencts==set(range(m,len(p.constraints))) and pos==[good[i] for i in range(len(p.variables))] and neg==[bad[i] for i in range(len(p.variables))]
    assert dict(zip(p.solution_hint.vars[h:],p.solution_hint.values[h:]))==extra=={int(k):v for k,v in hints.items()} and len(p.solution_hint.vars)==h+len(extra)
    return {'passed':True,'all1566_parent_variables_and1620_parent_constraints_unchanged':True,'new_variables_verified':len(seenvars),'new_constraints_verified':len(seencts),'new_hints_verified':len(extra),'all13_reference_links_verified':True,'all11_mode_mapping_tables_verified':True,'all78_pair_distance_tables_verified':True,'all156_guarded_directed_pair_rows_verified':True,'all6_optional_insert_intervals_and_capacity2_verified':True,'no_legacy_reference_symmetry_imposed':True,'all_model_fields_exhaustively_verified':True}

def violations(p,values,ignored=()):
    assert len(values)==len(p.variables)
    for v,x in zip(p.variables,values):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(ix):return bool(values[ix]) if ix>=0 else not bool(values[-ix-1])
    def active(c):return all(truth(ix) for ix in c.enforcement_literal)
    def ev(e):return e.offset+sum(a*values[ix] for ix,a in zip(e.vars,e.coeffs))
    failed=[];rectangle_pairs=rectangle_collisions=0;tables=0;capacities=[]
    for ix,c in enumerate(p.constraints):
        if ix in ignored or not active(c):continue
        kind=c.WhichOneof('constraint');ok=True
        if kind=='linear':v=sum(a*values[i] for i,a in zip(c.linear.vars,c.linear.coeffs));ok=any(a<=v<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='table':
            assert not c.table.negated and not c.table.vars;row=tuple(ev(e) for e in c.table.exprs);n=len(row);ok=row in {tuple(c.table.values[k:k+n]) for k in range(0,len(c.table.values),n)};tables+=1
        elif kind=='bool_or':ok=any(truth(i) for i in c.bool_or.literals)
        elif kind=='interval':ok=ev(c.interval.start)+ev(c.interval.size)==ev(c.interval.end) and ev(c.interval.size)>0
        elif kind=='no_overlap_2d':
            rr=[]
            for xi,yi in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                x,y=p.constraints[xi],p.constraints[yi];assert active(x)==active(y)
                if active(x):rr.append([ev(x.interval.start),ev(y.interval.start),ev(x.interval.end),ev(y.interval.end)])
            for a,b in combinations(rr,2):
                rectangle_pairs+=1
                if not(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]):rectangle_collisions+=1;ok=False
        elif kind=='cumulative':
            events={}
            for interval,demand in zip(c.cumulative.intervals,c.cumulative.demands):
                item=p.constraints[interval];assert item.WhichOneof('constraint')=='interval'
                if not active(item):continue
                start,end,d=ev(item.interval.start),ev(item.interval.end),ev(demand);assert start<end and d>0;events[start]=events.get(start,0)+d;events[end]=events.get(end,0)-d
            live=peak=0
            for coordinate,delta in sorted(events.items()):live+=delta;peak=max(peak,live)
            assert live==0;capacity=ev(c.cumulative.capacity);ok=peak<=capacity;capacities.append({'constraint':ix,'capacity':capacity,'peak_demand':peak,'passed':ok})
        else:raise AssertionError(kind)
        if not ok:failed.append({'constraint':ix,'kind':kind})
    return {'failed_constraints':failed,'all_mode_tables_evaluated':tables,'orthogonal_piece_pairs_checked':rectangle_pairs,'orthogonal_piece_collisions':rectangle_collisions,'cumulative_checks':capacities}
