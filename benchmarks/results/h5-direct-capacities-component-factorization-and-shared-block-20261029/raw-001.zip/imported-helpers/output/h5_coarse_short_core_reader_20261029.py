"""Pure exhaustive protobuf and assignment reader for the global short13 relaxation."""
from itertools import combinations
MIN=-9223372036854775808
MAX=9223372036854775807

def inspect(p,mp,inventory,modes,orders,rectfacets,cgfacets,positive,negative,hints_saved,positive_saved,negative_saved):
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
    seenvars=set();seencts=set();allx=[];ally=[];good={};bad={};known={tuple(r['identity']):r for r in positive};wrong={tuple(r['identity']):r for r in negative};families={f:[m for m in modes if m['family']==f] for f in ['bracket','insert']};hints={}
    def var(ix,name,domain):
        assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'}
    def ct(ix,kind,on=(),name=None):
        assert ix not in seencts;seencts.add(ix);c=p.constraints[ix];assert c.WhichOneof('constraint')==kind and list(c.enforcement_literal)==list(on)
        allowed={kind}|({'enforcement_literal'} if on else set())|({'name'} if name else set());assert {f.name for f,z in c.ListFields()}==allowed
        if name:assert c.name==name
        return c
    def linear(ix,coeffs,lo=MIN,hi=MAX,on=()):
        c=ct(ix,'linear',on);assert dict(zip(c.linear.vars,c.linear.coeffs))==coeffs and len(c.linear.vars)==len(coeffs) and list(c.linear.domain)==[lo,hi]
    def expr(e,ix):assert list(e.vars)==[ix] and list(e.coeffs)==[1] and e.offset==0 and {f.name for f,z in e.ListFields()}=={'vars','coeffs'}
    assert len(mp['items'])==13 and mp['mandatory_first53_identities']==inventory['mandatory_first53_identities']
    for i,(item,identity) in enumerate(zip(mp['items'],inventory['short13_identities'])):
        assert item['index']==i and item['identity']==identity and item['family']==identity[0];family=identity[0];pi,x,y=item['presence'],item['x'],item['y'];fm=families.get(family,[]);bounds=[inventory['cog_center_stock_bounds_grid_units']] if family=='cog' else [m['anchor_stock_bounds_grid_units'] for m in fm]
        var(pi,f'present_{i}',[0,1]);var(x,f'x_{i}',[min(b[0] for b in bounds),max(b[2] for b in bounds)]);var(y,f'y_{i}',[min(b[1] for b in bounds),max(b[3] for b in bounds)]);linear(item['mandatory'],{pi:1},1,1);row=known.get(tuple(identity));negative_row=wrong[tuple(identity)];good[pi]=int(row is not None);bad[pi]=1;hints[pi]=1
        if family=='cog':
            assert item['stock_bounds_grid_units']==inventory['cog_center_stock_bounds_grid_units'] and item['pieces']==[];a=row['anchor_grid_units'] if row else bounds[0][:2];good[x],good[y]=a;bad[x],bad[y]=negative_row['anchor_grid_units']
        else:
            mi=item['mode'];var(mi,f'mode_{i}',[0,len(fm)-1]);good[mi]=row['mode'] if row else 0;bad[mi]=negative_row['mode'];gm=fm[good[mi]];bm=fm[bad[mi]];good[x],good[y]=row['anchor_grid_units'] if row else gm['anchor_stock_bounds_grid_units'][:2];bad[x],bad[y]=negative_row['anchor_grid_units'];sv=item['stock_variables'];assert len(sv)==4
            for k,ix in enumerate(sv):var(ix,f'stock_{i}_{k}',[min(b[k] for b in bounds),max(b[k] for b in bounds)]);good[ix]=gm['anchor_stock_bounds_grid_units'][k];bad[ix]=bm['anchor_stock_bounds_grid_units'][k]
            ss=item['stock_constraints'];assert len(ss)==4;linear(ss[0],{x:1,sv[0]:-1},lo=0,on=[pi]);linear(ss[1],{y:1,sv[1]:-1},lo=0,on=[pi]);linear(ss[2],{x:1,sv[2]:-1},hi=0,on=[pi]);linear(ss[3],{y:1,sv[3]:-1},hi=0,on=[pi]);tablevars=[mi,*sv];tablerows=[[m['mode'],*m['anchor_stock_bounds_grid_units']] for m in fm];assert len(item['pieces'])==(2 if family=='bracket' else 1)
            for k,piece in enumerate(item['pieces']):
                assert piece['component']==k;rr=[m['rectangles_um'][k] for m in fm];lv=piece['local_variables'];wv=piece['world_variables'];links=piece['link_constraints'];assert len(lv)==4 and len(wv)==len(links)==6;tablevars.extend(lv)
                for tr,r in zip(tablerows,rr):tr.extend(r)
                for axis,ix in enumerate(lv):var(ix,f'local_{i}_{k}_{axis}',[min(r[axis] for r in rr),max(r[axis] for r in rr)]);good[ix]=gm['rectangles_um'][k][axis];bad[ix]=bm['rectangles_um'][k][axis]
                for axis in range(4):
                    ai=axis%2;anchor=x if ai==0 else y;lo=100*min(b[ai] for b in bounds)+min(r[axis] for r in rr);hi=100*max(b[ai+2] for b in bounds)+max(r[axis] for r in rr);var(wv[axis],f'world_{i}_{k}_{axis}',[lo,hi]);linear(links[axis],{wv[axis]:1,anchor:-100,lv[axis]:-1},0,0);good[wv[axis]]=100*good[anchor]+good[lv[axis]];bad[wv[axis]]=100*bad[anchor]+bad[lv[axis]]
                var(wv[4],f'width_{i}_{k}',[min(r[2]-r[0] for r in rr),max(r[2]-r[0] for r in rr)]);var(wv[5],f'height_{i}_{k}',[min(r[3]-r[1] for r in rr),max(r[3]-r[1] for r in rr)]);linear(links[4],{wv[4]:1,lv[2]:-1,lv[0]:1},0,0);linear(links[5],{wv[5]:1,lv[3]:-1,lv[1]:1},0,0)
                for v in [good,bad]:v[wv[4]]=v[lv[2]]-v[lv[0]];v[wv[5]]=v[lv[3]]-v[lv[1]]
                for axis,start,size,end in [('x',wv[0],wv[4],wv[2]),('y',wv[1],wv[5],wv[3])]:
                    ix=piece[axis+'_interval'];c=ct(ix,'interval',[pi],f'core_{axis}_{i}_{k}');expr(c.interval.start,start);expr(c.interval.size,size);expr(c.interval.end,end)
                allx.append(piece['x_interval']);ally.append(piece['y_interval'])
            assert item['table_variables']==tablevars;c=ct(item['mode_table'],'table');assert not c.table.negated and not c.table.vars and len(c.table.exprs)==len(tablevars) and list(c.table.values)==[v for row in tablerows for v in row]
            for e,ix in zip(c.table.exprs,tablevars):expr(e,ix)
        if row:
            own=[x,y]
            if family!='cog':own += [item['mode'],*item['stock_variables']]+[v for piece in item['pieces'] for v in piece['local_variables']+piece['world_variables']]
            for ix in own:hints[ix]=good[ix]
    c=ct(mp['no_overlap_2d'],'no_overlap_2d');assert list(c.no_overlap_2d.x_intervals)==allx and list(c.no_overlap_2d.y_intervals)==ally and len(allx)==16
    items=mp['items'];cogs=[i for i in items if i['family']=='cog'];orth=[i for i in items if i['family']!='cog'];expected=[('cog-rectangle',cg,owner,piece) for cg in cogs for owner in orth for piece in owner['pieces']]+[('cog-cog',cogs[0],cogs[1],None)];assert len(mp['facet_pairs'])==len(expected)==33
    for j,(pair,(kind,a,b,piece)) in enumerate(zip(mp['facet_pairs'],expected)):
        on=[a['presence'],b['presence']];assert pair['kind']==kind and pair['left']==a['index'] and pair['right']==b['index'] and pair['component']==(piece['component'] if piece else None) and pair['presences']==on;ff=rectfacets if piece else cgfacets;assert len(pair['facets'])==len(ff);selectors=[];chosen_good=chosen_bad=False
        for k,(saved,f) in enumerate(zip(pair['facets'],ff)):
            nx,ny=f['normal'];terms=[(a['x'],100*nx),(a['y'],100*ny),(piece['world_variables'][2] if nx>=0 else piece['world_variables'][0],-nx),(piece['world_variables'][3] if ny>=0 else piece['world_variables'][1],-ny)] if piece else [(b['x'],100*nx),(a['x'],-100*nx),(b['y'],100*ny),(a['y'],-100*ny)];coeffs={}
            for ix,v in terms:
                if v:coeffs[ix]=coeffs.get(ix,0)+v
            lower=f['negative_cog_support' if piece else 'support']+1;assert saved['coefficients']=={str(ix):v for ix,v in coeffs.items()} and saved['lower_bound']==lower;sel=saved['selector'];var(sel,f'sep_{j}_{k}',[0,1]);selectors.append(sel);linear(saved['constraint'],coeffs,lo=lower,on=on+[sel]);good_possible=all(good[v] for v in on) and sum(v*good[ix] for ix,v in coeffs.items())>=lower;bad_possible=sum(v*bad[ix] for ix,v in coeffs.items())>=lower;good[sel]=int(good_possible and not chosen_good);bad[sel]=int(bad_possible and not chosen_bad);chosen_good|=bool(good[sel]);chosen_bad|=bool(bad[sel])
            if all(tuple(items[i]['identity']) in known for i in [pair['left'],pair['right']]):hints[sel]=good[sel]
        c=ct(pair['choice'],'bool_or',on);assert list(c.bool_or.literals)==selectors
    assert mp['anchor_unit_um']==100 and len(mp['copy_orders'])==len(orders)==10
    byid={tuple(i['identity']):i for i in items}
    for saved,order in zip(mp['copy_orders'],orders):
        a,b=byid[tuple(order['left_identity'])],byid[tuple(order['right_identity'])];assert saved=={**order,'left':a['index'],'right':b['index'],'constraint':saved['constraint']};linear(saved['constraint'],{a['x']:1,b['x']:-1},hi=0,on=[a['presence'],b['presence']])
    assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints))) and set(good)==set(bad)==seenvars
    assert [good[i] for i in range(len(p.variables))]==positive_saved and [bad[i] for i in range(len(p.variables))]==negative_saved
    assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in hints_saved.items()} and len(p.solution_hint.vars)==len(hints)
    missing=[i['mandatory'] for i in items if tuple(i['identity']) not in known];assert missing==mp['control_disabled_mandatory_constraints'] and len(missing)==2
    return {'passed':True,'anchor_unit_um':100,'copy_orders_verified':10,'variables_verified':len(seenvars),'constraints_verified':len(seencts),'all_model_fields_exhaustively_verified':True,'mandatory_originals':13,'independent_anchor_coordinates':26,'mode_tables_verified':11,'optional_intervals_with_mandatory_owners_verified':32,'global_no_overlap_pieces':16,'complete_cog_rectangle_predicates':32,'complete_cog_pair_predicates':1,'facet_selectors_verified':1184,'partial_hints_verified':len(hints),'positive_missing_mandatory_constraints':missing}

def violations(p,values,ignored=()):
    assert len(values)==len(p.variables)
    for v,x in zip(p.variables,values):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(ix):return bool(values[ix]) if ix>=0 else not bool(values[-ix-1])
    def active(c):return all(truth(ix) for ix in c.enforcement_literal)
    def ev(e):return e.offset+sum(a*values[ix] for ix,a in zip(e.vars,e.coeffs))
    failed=[];rectangle_pairs=rectangle_collisions=0;tables=0
    for ix,c in enumerate(p.constraints):
        if ix in ignored or not active(c):continue
        kind=c.WhichOneof('constraint');ok=True
        if kind=='linear':v=sum(a*values[i] for i,a in zip(c.linear.vars,c.linear.coeffs));ok=any(a<=v<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='table':
            assert not c.table.negated and not c.table.vars;row=tuple(ev(e) for e in c.table.exprs);n=len(row);ok=row in {tuple(c.table.values[k:k+n]) for k in range(0,len(c.table.values),n)};tables+=1
        elif kind=='bool_or':ok=any(truth(i) for i in c.bool_or.literals)
        elif kind=='interval':ok=ev(c.interval.start)+ev(c.interval.size)==ev(c.interval.end) and ev(c.interval.size)>0
        elif kind=='no_overlap_2d':
            rr=[]
            for xi,yi in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                x,y=p.constraints[xi],p.constraints[yi];assert active(x)==active(y)
                if active(x):rr.append([ev(x.interval.start),ev(y.interval.start),ev(x.interval.end),ev(y.interval.end)])
            for a,b in combinations(rr,2):
                rectangle_pairs+=1
                if not(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]):rectangle_collisions+=1;ok=False
        else:raise AssertionError(kind)
        if not ok:failed.append({'constraint':ix,'kind':kind})
    return {'failed_constraints':failed,'all_mode_tables_evaluated':tables,'orthogonal_piece_pairs_checked':rectangle_pairs,'orthogonal_piece_collisions':rectangle_collisions}
