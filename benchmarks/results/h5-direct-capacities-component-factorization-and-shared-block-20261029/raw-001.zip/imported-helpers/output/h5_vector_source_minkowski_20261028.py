"""Vectorized triangle Minkowski sums of complete original filled polygons."""
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.ops import unary_union
def triangles(p):
    pieces=list(shapely.constrained_delaunay_triangles(p).geoms)
    assert pieces and all(g.geom_type=='Polygon' and len(g.exterior.coords)==4 and g.equals(g.convex_hull) for g in pieces) and unary_union(pieces).equals(p)
    return np.asarray([list(g.exterior.coords)[:-1] for g in pieces],dtype=float)
def obstacle(fixed_triangles,moving_triangles,radius):
    points=(fixed_triangles[:,None,:,None,:]-moving_triangles[None,:,None,:,:]).reshape(-1,9,2)
    hulls=shapely.convex_hull(shapely.multipoints(points));raw=shapely.union_all(hulls);buffered=raw.buffer(radius,join_style='mitre',mitre_limit=5)
    assert raw.is_valid and buffered.is_valid and buffered.covers(raw)
    return buffered,len(hulls)
