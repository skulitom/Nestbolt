"""Independent exact 16-corner readback of complete or partial 4D certificates."""
from fractions import Fraction as F
from itertools import product
from math import lcm

def inside(poly,p,scale=1):
    return all((b[0]-a[0])*(p[1]-a[1]*scale)-(b[1]-a[1])*(p[0]-a[0]*scale)>=0 for a,b in zip(poly,poly[1:]+poly[:1]))
def project(p,kind):
    if kind=='fixed0':return p[:2]
    if kind=='fixed1':return p[2:]
    assert kind=='pair';return [p[2]-p[0],p[3]-p[1]]
def verify(cert,bounds,obstacles,max_nodes=50000,max_depth=40):
    nodes=cert['nodes'];seen=set();leaves=missing=witnesses=unresolved=checks=0
    def visit(idx,expected,depth):
        nonlocal leaves,missing,witnesses,unresolved,checks
        assert type(idx)==int and 0<=idx<len(nodes) and idx not in seen;seen.add(idx);n=nodes[idx];r=list(map(F,n['bounds_um']));assert r==expected and n['depth']==depth and depth<=max_depth
        if 'covered_by' in n:
            assert set(n)=={'bounds_um','depth','covered_by'};oi=n['covered_by'];assert type(oi)==int and 0<=oi<len(obstacles);o=obstacles[oi];scale=lcm(*(x.denominator for x in r));ints=[x.numerator*(scale//x.denominator) for x in r]
            for p in product(*[(ints[k],ints[k+4]) for k in range(4)]):assert inside(o['vertices_um'],project(p,o['kind']),scale);checks+=len(o['vertices_um'])
            leaves+=1
        elif 'relaxation_witness_um' in n:
            assert set(n)=={'bounds_um','depth','relaxation_witness_um'};p=list(map(F,n['relaxation_witness_um']));assert p==[(r[k]+r[k+4])/2 for k in range(4)] and n['relaxation_witness_um']==cert['relaxation_witness_um']
            scale=lcm(*(x.denominator for x in p));ints=[x.numerator*(scale//x.denominator) for x in p]
            assert all(not inside(o['vertices_um'],project(ints,o['kind']),scale) for o in obstacles);witnesses+=1
        elif 'unresolved' in n:
            assert set(n)=={'bounds_um','depth','unresolved'} and n['unresolved'] is True and depth==max_depth and cert['limit']=='depth cap';unresolved+=1
        else:
            assert set(n)<={'bounds_um','depth','split_axis','left','right'} and 'split_axis' in n;axis=max(range(4),key=lambda k:r[k+4]-r[k]);assert n['split_axis']==axis
            mid=(r[axis]+r[axis+4])/2;a=r[:];b=r[:];a[axis+4]=mid;b[axis]=mid
            for side,child in [('left',a),('right',b)]:
                if side in n:visit(n[side],child,depth+1)
                else:missing+=1
    visit(0,list(map(F,bounds)),0)
    assert len(seen)==len(nodes)<=max_nodes and missing==cert['unprocessed_boxes']
    assert cert['covered']==(missing==witnesses==unresolved==0 and cert['limit'] is None)
    assert witnesses==(0 if cert['relaxation_witness_um'] is None else 1)
    if cert['limit'] is not None:assert cert['limit']=='depth cap' and unresolved==1 and witnesses==0
    else:assert unresolved==0
    return {'nodes':len(nodes),'covered_leaves':leaves,'exact_vertex_plane_checks':checks,'pending_boxes':missing,'relaxation_witnesses':witnesses,'unresolved_depth_leaves':unresolved,'covered':cert['covered']}
