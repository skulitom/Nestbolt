"""Independently verify all old model bytes and every added source-capacity field."""
from h5_row_bracket_cp_reader_20261028 import control_values,violations
def inspect(p,mp,old,oldmp,rects):
    extras={'capacity_base_variable_count','capacity_base_constraint_count','source_capacities','source_x_cumulative','source_y_cumulative'}
    assert set(mp)==set(oldmp)|extras and {k:v for k,v in mp.items() if k not in extras}==oldmp
    assert {f.name for f,v in p.ListFields()}=={f.name for f,v in old.ListFields()}=={'variables','constraints','solution_hint'}
    assert len(p.variables)==len(old.variables)==mp['capacity_base_variable_count']==7932
    assert p.solution_hint.SerializeToString()==old.solution_hint.SerializeToString()
    for a,b in zip(p.variables,old.variables):assert a.SerializeToString()==b.SerializeToString()
    base=len(old.constraints);assert base==mp['capacity_base_constraint_count']==32137
    for a,b in zip(p.constraints[:base],old.constraints):assert a.SerializeToString()==b.SerializeToString()
    expected=[(i,o) for i in oldmp['items'] for o in i['options']];assert len(expected)==len(mp['source_capacities']);seen=set(range(base));xs=[];ys=[];ww=[];hh=[]
    def expr(e,variable,offset):
        assert e.offset==offset and list(e.vars)==([] if variable is None else [variable]) and list(e.coeffs)==([] if variable is None else [1]) and {f.name for f,v in e.ListFields()}<= {'vars','coeffs','offset'}
    for row,(item,option) in zip(mp['source_capacities'],expected):
        mi=option['mode'];assert set(row)=={'block','mode','selector','components'} and (row['block'],row['mode'],row['selector'])==(item['index'],mi,option['selector']);source=rects[mi];assert source['mode']==mi and len(row['components'])==len(source['components'])
        for k,(r,s) in enumerate(zip(row['components'],source['components'])):
            assert set(r)=={'component','source_instance','x_interval','y_interval'} and r['component']==k and r['source_instance']==s['source_instance'];a,b,c,d=s['rectangle_um'];assert a<c and b<d;xs.append(r['x_interval']);ys.append(r['y_interval']);ww.append(c-a);hh.append(d-b)
            for axis,lo,hi in [('x',a,c),('y',b,d)]:
                ix=r[axis+'_interval'];assert ix not in seen and ix>=base;seen.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'name','interval','enforcement_literal'} and ct.name==f'inner_{axis}_{item["index"]}_{mi}_{k}' and list(ct.enforcement_literal)==[option['selector']];expr(ct.interval.start,item[axis],lo);expr(ct.interval.size,None,hi-lo);expr(ct.interval.end,item[axis],hi)
    for key,intervals,demands,capacity in [('source_x_cumulative',xs,hh,2987000),('source_y_cumulative',ys,ww,1487000)]:
        ix=mp[key];assert ix not in seen and ix>=base;seen.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'cumulative'} and list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(demands);expr(ct.cumulative.capacity,None,capacity)
        for e,d in zip(ct.cumulative.demands,demands):expr(e,None,d)
    assert len(xs)==1438 and len(seen)==35015 and seen==set(range(len(p.constraints)))
    return {'passed':True,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'prior_variables_constraints_and_hints_byte_identical':True,'all_new_fields_verified':True,'optional_source_components':len(xs),'added_interval_constraints':2*len(xs),'added_global_cumulatives':2,'extra_variables':0,'mandatory_blocks':43,'first_sheet_originals':54,'fixed_short_originals':12,'target_originals':66}
