"""Conservative whole-polygon square expansion and disjoint slab covers."""
import math
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.ops import unary_union

def square_expand(outer,pad_mm):
    # P + square = P union the square sweep of its boundary. The square is convex
    # and contains zero, so an exterior translated point is covered at its first
    # boundary crossing. This operates on the complete filled outer polygon.
    polygon=Polygon(outer);pieces=[polygon]
    for a,b in zip(outer,outer[1:]+outer[:1]):
        pieces.append(MultiPoint([(x+dx,y+dy) for x,y in [a,b] for dx in [-pad_mm,pad_mm] for dy in [-pad_mm,pad_mm]]).convex_hull)
    return unary_union(pieces)

def slab_cover(expanded,step_um):
    xmin,ymin,xmax,ymax=expanded.bounds;left=math.floor(xmin*1000)-1;end=math.ceil(xmax*1000)+1;rectangles=[];active={};slabs=[]
    while left<end:
        right=min(end,left+step_um);cut=expanded.intersection(box(left/1000,ymin-1,right/1000,ymax+1))
        def polygons(g):
            if g.is_empty:return []
            if g.geom_type=='Polygon':return [g]
            return [p for child in getattr(g,'geoms',[]) for p in polygons(child)]
        spans=sorted((math.floor(p.bounds[1]*1000)-1,math.ceil(p.bounds[3]*1000)+1) for p in polygons(cut));merged=[]
        for lo,hi in spans:
            if merged and lo<=merged[-1][1]:merged[-1][1]=max(hi,merged[-1][1])
            else:merged.append([lo,hi])
        new={}
        for lo,hi in merged:
            key=(lo,hi)
            if key in active and rectangles[active[key]][2]==left:ix=active[key];rectangles[ix][2]=right
            else:ix=len(rectangles);rectangles.append([left,lo,right,hi])
            new[key]=ix
        slabs.append({'left_um':left,'right_um':right,'spans_um':merged});active=new;left=right
    return rectangles,slabs

def rectangle_union(rectangles):return unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rectangles])
