"""Deterministic exact-area merges of adjacent convex polygon pieces."""
from fractions import Fraction as F

def area(p):
    return sum((a[0]*b[1]-a[1]*b[0] for a, b in zip(p, p[1:]+p[:1])), F(0))/2

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def hull(vertices):
    points = sorted(set(vertices))
    chains = []
    for sequence in [points, list(reversed(points))]:
        chain = []
        for p in sequence:
            while len(chain) >= 2 and cross(chain[-2], chain[-1], p) <= 0:
                chain.pop()
            chain.append(p)
        chains.append(chain)
    return chains[0][:-1]+chains[1][:-1]

def merge_exact(polygons):
    active = {i: [tuple(map(F, p)) for p in polygon.exterior.coords[:-1]] for i, polygon in enumerate(polygons)}
    for i, p in active.items():
        if area(p) < 0:
            active[i] = list(reversed(p))
    merges = 0
    while True:
        owners, candidates = {}, []
        for i, p in active.items():
            for a, b in zip(p, p[1:]+p[:1]):
                edge = tuple(sorted([a, b]))
                if edge in owners:
                    candidates.append((owners[edge], i))
                else:
                    owners[edge] = i
        changed = False
        for a, b in candidates:
            if a not in active or b not in active:
                continue
            combined = hull(active[a]+active[b])
            if area(combined) == area(active[a])+area(active[b]):
                active[a] = combined
                del active[b]
                merges += 1
                changed = True
        if not changed:
            break
    return [[[float(x), float(y)] for x, y in p] for p in active.values()], merges
