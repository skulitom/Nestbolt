"""Reconstruct original transforms independently from original vertices and row pitch."""
import math
def reconstruct(job,blocks,modes,poses,short):
    parts={p['id']:p for p in job['parts']};result=list(short);seen=set();maximum_offset_error=0
    for pose in poses:
        i=pose['block'];assert i not in seen;seen.add(i);block=blocks[i];m=modes[pose['mode']];assert m['family']==block['family'];ax,ay=[v/1000 for v in pose['anchor_um']]
        if block['family']=='cog-row':
            angle=math.radians(7);c,s=math.cos(angle),math.sin(angle);transformed=[(c*x-s*y,s*x+c*y) for x,y in parts['cog']['geometry'][0]['outer']];lo=[min(p[k] for p in transformed) for k in [0,1]]
            specs=[('cog',copy,angle,False,[relative*258.9-lo[0],-lo[1]],m['source_instances'][relative]['translation']) for relative,copy in enumerate(block['copy_indices'])]
        else:
            family=block['family'];q=m['quarter'];assert q in range(4) and (not m['mirrored'] or parts[family]['allow_mirror']);c,s=[(1,0),(0,1),(-1,0),(0,-1)][q];sign=-1 if m['mirrored'] else 1
            points=[(sign*x*c-y*s,sign*x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']];offset=[-min(p[k] for p in points) for k in [0,1]];specs=[(family,block['copy_index'],q*math.pi/2,m['mirrored'],offset,m['source_translation_offset'])]
        for family,copy,angle,mirror,offset,stored in specs:
            error=max(abs(a-b) for a,b in zip(offset,stored));maximum_offset_error=max(error,maximum_offset_error);assert error<1e-9
            result.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':mirror,'translation':[ax+offset[0],ay+offset[1]]}})
    assert len(result)==len({(r['part_id'],r['copy_index']) for r in result})
    return result,maximum_offset_error
