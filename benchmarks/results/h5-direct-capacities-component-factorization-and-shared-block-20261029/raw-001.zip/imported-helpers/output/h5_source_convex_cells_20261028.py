"""Exact rational error margins for integer anchors inside convex source cells."""
from fractions import Fraction as F
from shapely.geometry import mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from diagnose_h5_concave_gaps import polygons,convex_pieces

def encode(region):
    pieces=[p for component in polygons(region) for p in convex_pieces(component)]
    assert pieces and unary_union(pieces).equals(region)
    cells=[]
    for piece in pieces:
        piece=orient(piece,sign=1);points=list(piece.exterior.coords)[:-1];planes=[]
        for a,b in zip(points,points[1:]+points[:1]):
            px,py=map(lambda v:F(str(v)),a);qx,qy=map(lambda v:F(str(v)),b);nx,ny=py-qy,qx-px;scale=max(abs(nx),abs(ny));nx/=scale;ny/=scale
            aa=round(nx*10**9);bb=round(ny*10**9);error=abs(F(aa)-nx*10**9)*1600000+abs(F(bb)-ny*10**9)*3100000;value=(nx*px+ny*py)*10**12+error;cc=-((-value.numerator)//value.denominator)+1;planes.append([aa,bb,cc])
        cells.append({'geometry':mapping(piece),'halfplanes':planes})
    return {'cells':cells,'domain_geometry':mapping(region)}

def selected_cell(cells,x,y):
    return next((i for i,c in enumerate(cells) if all(a*x+b*y>=k for a,b,k in c['halfplanes'])),None)
