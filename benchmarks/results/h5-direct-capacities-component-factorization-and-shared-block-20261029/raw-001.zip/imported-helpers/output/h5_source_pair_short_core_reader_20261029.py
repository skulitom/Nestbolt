"""Read the one source-distance extension and all parent constraints."""
from h5_strip_capacity_short_core_reader_20261029 import violations as parent_violations
def inspect(p,parent,mp,parentmp,bound):
    prefix=type(p)();prefix.CopyFrom(p);del prefix.constraints[-1:];assert prefix==parent and len(p.constraints)==1620 and len(p.variables)==1566
    saved=mp['source_pair_separation'];assert {k:v for k,v in mp.items() if k!='source_pair_separation'}==parentmp;a,b=[next(i for i in mp['items'] if i['identity']==key) for key in bound['cog_order_identities']];ix=len(parent.constraints);steps=bound['required_ordered_center_x_difference_grid_units'];assert saved=={'left':a['index'],'right':b['index'],'constraint':ix,'minimum_x_grid_units':steps}
    c=p.constraints[ix];assert {f.name for f,v in c.ListFields()}=={'linear','enforcement_literal'} and list(c.enforcement_literal)==[a['presence'],b['presence']] and dict(zip(c.linear.vars,c.linear.coeffs))=={a['x']:-1,b['x']:1} and len(c.linear.vars)==2 and list(c.linear.domain)==[steps,9223372036854775807]
    return {'passed':True,'all1566_parent_variables_and1619_parent_constraints_unchanged':True,'all_parent_hints_unchanged':True,'new_source_pair_constraint_verified':True,'minimum_cog_x_difference_grid_units':steps,'all_model_fields_exhaustively_verified':True}
def violations(p,values,ignored=()):
    q=type(p)();q.CopyFrom(p);del q.constraints[-1:];result=parent_violations(q,values,ignored);ix=len(p.constraints)-1;c=p.constraints[ix];assert c.WhichOneof('constraint')=='linear'
    active=all(bool(values[v]) if v>=0 else not bool(values[-v-1]) for v in c.enforcement_literal);total=sum(values[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));passed=not active or c.linear.domain[0]<=total<=c.linear.domain[1];result['original_source_pair_check']={'constraint':ix,'active':active,'x_difference_grid_units':total,'passed':passed}
    if not passed and ix not in ignored:result['failed_constraints'].append({'constraint':ix,'kind':'linear'})
    return result
