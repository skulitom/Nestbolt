"""Read original rings independently of the sliding geometry and optimizer."""
from collections import Counter
from itertools import combinations
import math
from shapely.geometry import Polygon
def audit(job,rows,stocks,required,guard,expected=None):
    parts={p['id']:p for p in job['parts']};keys=[(r['part_id'],r['copy_index']) for r in rows];assert len(keys)==len(set(keys))
    if expected is not None:assert sorted(keys)==sorted(expected)
    shapes=[];stock_checks=[];holes=vertices=0
    for p in rows:
        part=parts[p['part_id']];assert 0<=p['copy_index']<part['quantity'];t=p['transform'];assert not t['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees'])
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=part['geometry'][0]
        def ring(r):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in r]
        filled=Polygon(ring(g['outer']));full=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])]);assert filled.is_valid and full.is_valid and abs(filled.area-Polygon(g['outer']).area)<1e-6 and abs(full.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6
        b=filled.bounds;st=stocks[p['sheet_id']];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];stock_checks.append({'key':[p['part_id'],p['copy_index']],'extra_mm':extra,'passed':min(extra)>guard});shapes.append((p['sheet_id'],[p['part_id'],p['copy_index']],filled));holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]))
    pair_checks=[]
    for (sa,ka,a),(sb,kb,b) in combinations(shapes,2):
        if sa!=sb:continue
        d=a.distance(b);pair_checks.append({'keys':[ka,kb],'distance_mm':d,'intersection_area_mm2':a.intersection(b).area,'passed':a.disjoint(b) and d>required})
    failed_pairs=[p for p in pair_checks if not p['passed']];failed_stocks=[p for p in stock_checks if not p['passed']]
    return {'valid':not failed_pairs and not failed_stocks,'originals':len(rows),'family_counts':dict(Counter(r['part_id'] for r in rows)),'same_sheet_pairs':len(pair_checks),'stock_edges':4*len(rows),'cutouts':holes,'hole_vertices':vertices,'pair_failures':len(failed_pairs),'stock_failures':len(failed_stocks),'minimum_pair_gap_mm':min((r['distance_mm'] for r in pair_checks),default=None),'minimum_extra_stock_mm':min((min(r['extra_mm']) for r in stock_checks),default=None),'pairs':pair_checks,'stock':stock_checks}
