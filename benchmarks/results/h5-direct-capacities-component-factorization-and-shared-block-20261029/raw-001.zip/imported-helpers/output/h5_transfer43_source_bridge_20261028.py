"""Independent original-vertex transforms with strict row cardinality checking."""
import math
def reconstruct(job,blocks,modes,poses,short):
    parts={p['id']:p for p in job['parts']};result=list(short);seen=set();maximum_offset_error=0
    for pose in poses:
        i=pose['block'];assert i not in seen;seen.add(i);b=blocks[i];m=modes[pose['mode']];assert b['family']==m['family'];ax,ay=[v/1000 for v in pose['anchor_um']]
        if b['family']=='cog-row':
            assert b['row_size']==m['row_size']==len(b['copy_indices'])==len(m['source_instances']) and b['row_size'] in [4,5]
            a=math.radians(7);c,s=math.cos(a),math.sin(a);v=[(c*x-s*y,s*x+c*y) for x,y in parts['cog']['geometry'][0]['outer']];lo=[min(p[k] for p in v) for k in [0,1]];specs=[('cog',copy,a,False,[j*258.9-lo[0],-lo[1]],m['source_instances'][j]['translation']) for j,copy in enumerate(b['copy_indices'])]
        else:
            family=b['family'];q=m['quarter'];assert q in range(4) and (not m['mirrored'] or parts[family]['allow_mirror']);c,s=[(1,0),(0,1),(-1,0),(0,-1)][q];sign=-1 if m['mirrored'] else 1;v=[(sign*x*c-y*s,sign*x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']];offset=[-min(p[k] for p in v) for k in [0,1]];specs=[(family,b['copy_index'],q*math.pi/2,m['mirrored'],offset,m['source_translation_offset'])]
        for family,copy,a,mirror,offset,stored in specs:
            error=max(abs(x-y) for x,y in zip(offset,stored));assert error<1e-9;maximum_offset_error=max(maximum_offset_error,error);result.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':mirror,'translation':[ax+offset[0],ay+offset[1]]}})
    assert len(result)==len({(r['part_id'],r['copy_index']) for r in result});return result,maximum_offset_error
