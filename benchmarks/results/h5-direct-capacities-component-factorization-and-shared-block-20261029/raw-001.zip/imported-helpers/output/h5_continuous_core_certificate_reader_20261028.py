"""Exact reader for complete or interrupted deterministic rectangle certificates."""
from fractions import Fraction as F

def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])

def contains(poly,p):return all(cross(a,b,p)>=0 for a,b in zip(poly,poly[1:]+poly[:1]))

def check_obstacles(rects,core,polys):
    assert len(rects)==len(polys);sums=0
    for r,poly in zip(rects,polys):
        pp=[tuple(p) for p in poly];assert len(pp)>=3 and len(set(pp))==len(pp) and all(type(v)==int for p in pp for v in p)
        expected={(x-u,y-v) for x,y in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])] for u,v in core}
        assert all(p in expected for p in pp)
        for a,b in zip(pp,pp[1:]+pp[:1]):assert all(cross(a,b,p)>0 for p in pp if p not in (a,b))
        assert all(contains(pp,p) for p in expected);sums+=len(expected)
    return sums

def check_certificate(cert,bounds,polys,max_nodes=100000,max_depth=30):
    nodes=cert['nodes'];seen=set();leaves=witnesses=missing=corner_planes=0
    def visit(index,expected,depth):
        nonlocal leaves,witnesses,missing,corner_planes
        assert type(index)==int and 0<=index<len(nodes) and index not in seen;seen.add(index);n=nodes[index]
        r=list(map(F,n['bounds_um']));assert r==expected and n['depth']==depth and depth<=max_depth
        if 'covered_by' in n:
            assert set(n)=={'bounds_um','depth','covered_by'};oi=n['covered_by'];assert type(oi)==int and 0<=oi<len(polys)
            pp=polys[oi]
            for p in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]:
                assert contains(pp,p);corner_planes+=len(pp)
            leaves+=1
        elif 'relaxation_witness_um' in n:
            assert set(n)=={'bounds_um','depth','relaxation_witness_um'}
            p=list(map(F,n['relaxation_witness_um']));assert p==[(r[0]+r[2])/2,(r[1]+r[3])/2] and n['relaxation_witness_um']==cert['relaxation_witness_um']
            assert all(not contains(pp,p) for pp in polys);witnesses+=1
        else:
            assert set(n)<= {'bounds_um','depth','split_axis','left','right'} and 'split_axis' in n
            axis=0 if r[2]-r[0]>=r[3]-r[1] else 1;assert n['split_axis']==axis
            mid=(r[axis]+r[axis+2])/2;a=r[:];b=r[:];a[axis+2]=mid;b[axis]=mid
            for label,child in [('left',a),('right',b)]:
                if label in n:visit(n[label],child,depth+1)
                else:missing+=1
    visit(0,list(map(F,bounds)),0)
    assert len(seen)==len(nodes)<=max_nodes and cert['limit'] is None and missing==cert['unprocessed_rectangles']
    assert cert['covered']==(missing==0 and witnesses==0)
    assert witnesses==(0 if cert['relaxation_witness_um'] is None else 1)
    return {'nodes':len(nodes),'covered_leaves':leaves,'relaxation_witnesses':witnesses,'pending_children':missing,'corner_plane_checks':corner_planes,'complete_coverage':cert['covered']}
