"""Pure whole-model delta audit and independent assignment reconstruction."""
from itertools import combinations,product
from h5_transfer43_cp_reader_20261028 import violations
def control_values(p,mp,relative,typed,poses):
    known={v['block']:v for v in poses};values=[0]*len(p.variables)
    for item in mp['items']:
        row=known.get(item['index'])
        if row is None:continue
        values[item['presence']]=1;values[item['x']],values[item['y']]=row['anchor_um']
        for o in item['options']:values[o['selector']]=int(o['mode']==row['mode'])
    for pair in mp['row_pairs']:
        if pair['left'] not in known or pair['right'] not in known:continue
        a,b=known[pair['left']],known[pair['right']];dx,dy=[b['anchor_um'][j]-a['anchor_um'][j] for j in [0,1]];selected=next((k for k,c in enumerate(relative[pair['region']]['cells']) if all(aa*dx+bb*dy>=cc for aa,bb,cc in c['halfplanes'])),None)
        for k,sv in enumerate(pair['selectors']):values[sv]=int(k==selected)
    for pair in mp['row_bracket_pairs']:
        if pair['row'] not in known or pair['bracket'] not in known:continue
        a,b=known[pair['row']],known[pair['bracket']];dx,dy=[b['anchor_um'][j]-a['anchor_um'][j] for j in [0,1]]
        for option in pair['options']:
            if option['mode']!=b['mode']:continue
            selected=next((k for k,c in enumerate(typed[(pair['row_mode'],option['mode'])]['cells']) if all(aa*dx+bb*dy>=cc for aa,bb,cc in c['halfplanes'])),None)
            for k,sv in enumerate(option['cells']):values[sv]=int(k==selected)
    return values
def inspect(p,mp,old,oldmp,modes,relative,typed,control,negative,hints_saved,partial_saved,negative_saved):
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'};assert mp['items']==oldmp['items'] and mp['orders']==oldmp['orders'] and mp['row_pairs']==oldmp['row_pairs'];assert mp['base_variable_count']==len(old.variables) and mp['base_constraint_count']==len(old.constraints);replaced=[ix for g in oldmp['collision_groups'] for ix in g['constraints']];assert mp['replaced_base_constraints']==replaced
    for i,v in enumerate(old.variables):assert p.variables[i]==v
    for i,ct in enumerate(old.constraints):
        if i not in replaced:assert p.constraints[i]==ct
    seenvars=set(range(len(old.variables)));seencts=set(range(len(old.constraints)))-set(replaced);covered=set();MIN=-9223372036854775808;MAX=9223372036854775807
    def linear(ix,coeffs,lo=MIN,hi=MAX,on=()):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and {f.name for f,v in ct.ListFields()}<= {'linear','enforcement_literal'} and list(ct.enforcement_literal)==list(on) and dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
    assert len(mp['collision_groups'])==4
    for row,g in zip([40,41,42,None],mp['collision_groups']):
        assert g['row']==row;members=[i for i in mp['items'] if (i['source_block']['family']!='cog-row' if row is None else i['source_block']['family'] in ['frame','insert'] or i['index']==row)];assert g['members']==[i['index'] for i in members];covered.update(combinations(g['members'],2));xs=[];ys=[];ww=[];hh=[]
        for item in members:
            for o in item['options']:
                for c,(a,b,d,e) in zip(o['components'],modes[o['mode']]['cover_rectangles_um']):xs.append(c['x_interval']);ys.append(c['y_interval']);ww.append(d-a);hh.append(e-b)
        assert (g['xs'],g['ys'],g['widths'],g['heights'])==(xs,ys,ww,hh)
        if row is not None:assert g['constraints']==next(v['constraints'] for v in oldmp['collision_groups'] if v['row']==row)
        ix,xc,yc=g['constraints'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'} and list(ct.no_overlap_2d.x_intervals)==xs and list(ct.no_overlap_2d.y_intervals)==ys
        for ix,ints,demands,cap in [(xc,xs,hh,2987202),(yc,ys,ww,1487202)]:
            assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,v in ct.ListFields()}=={'cumulative'} and list(ct.cumulative.intervals)==ints and len(ct.cumulative.demands)==len(demands) and ct.cumulative.capacity.offset==cap and {f.name for f,v in ct.cumulative.capacity.ListFields()}=={'offset'}
            for e,d in zip(ct.cumulative.demands,demands):assert e.offset==d and {f.name for f,v in e.ListFields()}=={'offset'}
    covered.update((v['left'],v['right']) for v in mp['row_pairs']);assert [(g['row'],g['bracket']) for g in mp['row_bracket_pairs']]==list(product([40,41,42],range(5)))
    for g in mp['row_bracket_pairs']:
        row,br=mp['items'][g['row']],mp['items'][g['bracket']];rm=row['options'][0]['mode'];assert g['row_mode']==rm and [o['mode'] for o in g['options']]==list(range(2,10));covered.add(tuple(sorted((g['row'],g['bracket']))))
        for o,brmode in zip(g['options'],br['options']):
            mi=o['mode'];assert mi==brmode['mode'] and o['mode_selector']==brmode['selector'];cells=typed[(rm,mi)]['cells'];assert len(cells)==len(o['cells'])==len(o['plane_constraints'])
            for k,(cell,sv,cts) in enumerate(zip(cells,o['cells'],o['plane_constraints'])):
                assert sv not in seenvars;seenvars.add(sv);v=p.variables[sv];assert v.name==f"row_bracket_{g['row']}_{g['bracket']}_{mi}_{k}" and list(v.domain)==[0,1] and {f.name for f,z in v.ListFields()}=={'name','domain'};assert len(cts)==len(cell['halfplanes'])
                for ix,(a,b,c) in zip(cts,cell['halfplanes']):linear(ix,{v:k for v,k in [(br['x'],a),(row['x'],-a),(br['y'],b),(row['y'],-b)] if k},lo=c,on=[sv])
            linear(o['choice'],{**{sv:1 for sv in o['cells']},o['mode_selector']:-1},0,0)
    assert covered==set(combinations(range(43),2)) and len(covered)==903;assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)));values=control_values(p,mp,relative,typed,control);bad=control_values(p,mp,relative,typed,negative);assert values==partial_saved and bad==negative_saved;known={v['block'] for v in control};hints={}
    for item in mp['items']:
        hints[item['presence']]=1
        if item['index'] in known:
            for k in ['x','y']:hints[item[k]]=values[item[k]]
            for o in item['options']:hints[o['selector']]=values[o['selector']]
    for v in mp['row_pairs']:
        if v['left'] in known and v['right'] in known:
            for s in v['selectors']:hints[s]=values[s]
    for g in mp['row_bracket_pairs']:
        if g['row'] in known and g['bracket'] in known:
            for o in g['options']:
                for s in o['cells']:hints[s]=values[s]
    assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in hints_saved.items()} and len(p.solution_hint.vars)==len(hints);disabled=[i['mandatory'] for i in mp['items'] if i['index'] not in known];assert disabled==mp['control_disabled_mandatory_constraints'] and len(disabled)==14
    return {'passed':True,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'mandatory_blocks':43,'target_originals':66,'independent_anchor_coordinates':86,'all903_block_pairs_covered':True,'row_bracket_owner_pairs':15,'row_bracket_mode_cases':120,'row_bracket_cell_selectors':len(p.variables)-len(old.variables),'all_prior_fields_preserved_except9_cover_constraints_and_hints':True,'all_new_fields_verified':True,'partial_hints_verified':len(hints)},disabled
