"""Source-cell CP construction. No solver calls; explicit base and incremental APIs."""
from itertools import combinations
from ortools.sat.python import cp_model
def linear(model,expr,lo=None,hi=None,on=None):
    c=model.add(expr>=lo) if hi is None else model.add(expr<=hi) if lo is None else model.add_linear_constraint(expr,lo,hi)
    if on is not None:c.only_enforce_if(on)
    return c.index
def selected(cells,x,y):
    return next(k for k,c in enumerate(cells) if all(a*x+b*y>=v for a,b,v in c['halfplanes']))
def build(remaining,modes,free,fixed,rects,control):
    model=cp_model.CpModel();items=[];hints={};values={};components=[];xs=[];ys=[];widths=[];heights=[]
    def interval_record(owner,r,x=0,y=0,present=None):
        k=len(components);a,b,c,d=r
        if present is None:
            ix=model.new_fixed_size_interval_var(x+a,c-a,f'capacity_x_{k}');iy=model.new_fixed_size_interval_var(y+b,d-b,f'capacity_y_{k}')
        else:
            ix=model.new_optional_fixed_size_interval_var(x+a,c-a,present,f'capacity_x_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,d-b,present,f'capacity_y_{k}')
        xs.append(ix);ys.append(iy);widths.append(c-a);heights.append(d-b)
        components.append({'index':k,**owner,'rectangle_um':r,'x_interval':ix.index,'y_interval':iy.index,'presence':None if present is None else present.index})
    for r in fixed:interval_record({'fixed_owner':r['owner'],'source_component':r['component']},r['rectangle_um'])
    for i,r in enumerate(remaining):
        family,copy=r['family'],r['copy_index'];known=next((v for v in control if (v['family'],v['copy_index'])==(family,copy)),None)
        p=model.new_bool_var(f'present_{i}');x=model.new_int_var(0,1500000,f'x_{i}');y=model.new_int_var(0,3000000,f'y_{i}')
        mandatory=linear(model,p,1,1);hints[p.index]=1;values[p.index]=int(known is not None);values[x.index],values[y.index]=known['anchor_um'] if known else [0,0]
        if known:hints[x.index],hints[y.index]=known['anchor_um']
        options=[]
        for mode in [m['index'] for m in modes if m['family']==family]:
            mv=model.new_bool_var(f'mode_{i}_{mode}');cs=[model.new_bool_var(f'free_{i}_{mode}_{k}') for k in range(len(free[mode]))]
            choice=linear(model,sum(cs)-mv,0,0);planes=[];active=known is not None and known['mode']==mode;sc=selected(free[mode],*known['anchor_um']) if active else None
            values[mv.index]=int(active)
            if known:hints[mv.index]=int(active)
            for k,(cell,sv) in enumerate(zip(free[mode],cs)):
                planes.append([linear(model,a*x+b*y,lo=c,on=sv) for a,b,c in cell['halfplanes']]);values[sv.index]=int(active and k==sc)
                if known:hints[sv.index]=values[sv.index]
            options.append({'mode':mode,'selector':mv.index,'cells':[v.index for v in cs],'choice_constraint':choice,'plane_constraints':planes})
            for k,rr in enumerate(rects[mode]['rectangles_um']):interval_record({'item':i,'mode':mode,'source_component':k},rr,x,y,mv)
        choice=linear(model,sum(model.get_int_var_from_proto_index(o['selector']) for o in options)-p,0,0)
        items.append({'index':i,'family':family,'copy_index':copy,'presence':p.index,'mandatory':mandatory,'x':x.index,'y':y.index,'choice':choice,'options':options})
    xc=model.add_cumulative(xs,heights,2987000).index;yc=model.add_cumulative(ys,widths,1487000).index;orders=[]
    for family in ['bracket','cog','insert']:
        group=[r for r in items if r['family']==family]
        for a,b in zip(group,group[1:]):orders.append({'left':a['index'],'right':b['index'],'constraint':linear(model,model.get_int_var_from_proto_index(a['x'])-model.get_int_var_from_proto_index(b['x']),hi=0)})
    for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
    assert model.validate()==''
    return model,{'items':items,'components':components,'x_cumulative':xc,'y_cumulative':yc,'orders':orders,'pairs':[]},hints,[values[i] for i in range(len(model.proto.variables))]
def add_pairs(model,mapping,pair_indices,relative):
    existing={(p['left'],p['right']) for p in mapping['pairs']};added=[]
    for left_ix,right_ix in sorted(set(tuple(sorted(v)) for v in pair_indices)):
        assert left_ix<right_ix and (left_ix,right_ix) not in existing
        left,right=mapping['items'][left_ix],mapping['items'][right_ix];x1,y1=[model.get_int_var_from_proto_index(left[k]) for k in ['x','y']];x2,y2=[model.get_int_var_from_proto_index(right[k]) for k in ['x','y']];groups=[]
        for oa in left['options']:
            for ob in right['options']:
                a,b=oa['mode'],ob['mode'];sign=1 if a<=b else -1;cells=relative[min(a,b),max(a,b)]
                ss=[model.new_bool_var(f'pair_{left_ix}_{right_ix}_{a}_{b}_{k}') for k in range(len(cells))];va=model.get_int_var_from_proto_index(oa['selector']);vb=model.get_int_var_from_proto_index(ob['selector'])
                choices=[linear(model,sum(ss)-va,hi=0),linear(model,sum(ss)-vb,hi=0),linear(model,sum(ss)-va-vb,lo=-1)]
                planes=[[linear(model,sign*(aa*(x2-x1)+bb*(y2-y1)),lo=cc,on=sv) for aa,bb,cc in cell['halfplanes']] for cell,sv in zip(cells,ss)]
                groups.append({'left_mode':a,'right_mode':b,'cells':[v.index for v in ss],'choice_constraints':choices,'plane_constraints':planes})
        row={'left':left_ix,'right':right_ix,'groups':groups};mapping['pairs'].append(row);added.append(row);existing.add((left_ix,right_ix))
    assert model.validate()==''
    return added
