"""Bounded exact continuous coverage of several source-contained moving cores."""
from fractions import Fraction as F
import time
def project(r,count,i,j):
    if j is None:return [r[2*i],r[2*i+1],r[count+2*i],r[count+2*i+1]]
    return [r[2*j]-r[count+2*i],r[2*j+1]-r[count+2*i+1],r[count+2*j]-r[2*i],r[count+2*j+1]-r[2*i+1]]
def point(p,i,j):return p[2*i:2*i+2] if j is None else [p[2*j]-p[2*i],p[2*j+1]-p[2*i+1]]
def certificate(bounds,obstacles,max_nodes,max_depth,deadline):
    n=len(bounds)//2;prepared=[]
    for o in obstacles:
        p=o['vertices_um'];pp=[(-(b[1]-a[1]),b[0]-a[0],-(b[1]-a[1])*a[0]+(b[0]-a[0])*a[1]) for a,b in zip(p,p[1:]+p[:1])];bb=[min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)];prepared.append((o['first'],o['second'],pp,bb))
    nodes=[];pending=[(list(map(F,bounds)),0,None,None)];witness=None;limit=None
    while pending:
        if len(nodes)>=max_nodes:limit='node cap';break
        if time.perf_counter()>=deadline:limit='shared proof wall limit';break
        r,depth,parent,side=pending.pop();idx=len(nodes);node={'bounds_um':list(map(str,r)),'depth':depth};nodes.append(node)
        if parent is not None:nodes[parent][side]=idx
        projections={(i,j):project(r,n,i,j) for i,j,pp,bb in prepared};found=None
        for oi,(i,j,pp,bb) in enumerate(prepared):
            q=projections[i,j]
            if q[0]>=bb[0] and q[1]>=bb[1] and q[2]<=bb[2] and q[3]<=bb[3] and all(a*(q[0] if a>=0 else q[2])+b*(q[1] if b>=0 else q[3])>=c for a,b,c in pp):found=oi;break
        if found is not None:node['covered_by']=found;continue
        mid=[(r[k]+r[k+n])/2 for k in range(n)]
        if all(not all(a*point(mid,i,j)[0]+b*point(mid,i,j)[1]>=c for a,b,c in pp) for i,j,pp,bb in prepared):witness=list(map(str,mid));node['relaxation_witness_um']=witness;break
        if depth>=max_depth:limit='depth cap';node['unresolved']=True;break
        axis=max(range(n),key=lambda k:r[k+n]-r[k]);m=(r[axis]+r[axis+n])/2;left=r[:];right=r[:];left[axis+n]=m;right[axis]=m;node['split_axis']=axis
        pending.append((right,depth+1,idx,'right'));pending.append((left,depth+1,idx,'left'))
    return {'covered':not pending and witness is None and limit is None,'nodes':nodes,'unprocessed_boxes':len(pending),'relaxation_witness_um':witness,'limit':limit}
