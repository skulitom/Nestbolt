"""Independent exact clipping and interval-event proof of fine-band exclusions."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-fine-band-capacity-20261029';OUT=BASE/'audit';COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029/accessible-area-bound'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clip(poly,above,cut):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[1]>=cut if above else a[1]<=cut;inb=b[1]>=cut if above else b[1]<=cut
        if ina:out.append(a)
        if ina!=inb:out.append((a[0]+(b[0]-a[0])*(cut-a[1])/(b[1]-a[1]),cut))
    return out
def merge(intervals):
    events={}
    for lo,hi in intervals:
        assert lo<hi
        events[lo]=events.get(lo,0)+1;events[hi]=events.get(hi,0)-1
    result=[];balance=0;start=None
    for x,d in sorted(events.items()):
        old=balance;balance+=d;assert balance>=0
        if old==0 and balance>0:start=x
        if old>0 and balance==0:result.append((start,x));start=None
    assert balance==0 and start is None
    return result
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
source_rows=load(COUNT/'all25-filtered-bounds.json');source_parts=load(PRIOR/'swept-covers.json');parts=load(BASE/'source-fine-covers.json');rows=load(BASE/'all25-fine-band-bounds.json')
needed={tuple(a[:4]) for r in source_rows for a in r['region_component_assignments']}
expected_indices=[i for i,p in enumerate(source_parts) if (p['family'],p['mode'],p['geometry'],p['region']) in needed]
assert [p['source_index'] for p in parts]==expected_indices
cache={};regions={};corners=clipped_bands=source_spans=0
for part in parts:
    source=source_parts[part['source_index']];key=tuple(part['source_key']);assert key==(source['family'],source['mode'],source['geometry'],source['region']) and part['piece']==source['piece']
    hull=tuple(tuple(v) for v in part['outward_hull_tenths_mm']);assert all(isinstance(v,int) for p in hull for v in p) and len(hull)>=3
    edges=list(zip(hull,hull[1:]+hull[:1]))
    for a,b in edges:
        assert a!=b and all((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>=0 for p in hull)
    assert sum(a[0]*b[1]-b[0]*a[1] for a,b in edges)>0
    for sx,sy in source['swept_hull']:
        x,y=F(sx)*10,F(sy)*10
        assert all((b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>=0 for a,b in edges);corners+=1
    spans=part['band_spans_tenths_mm'];source_spans+=len(spans)
    if hull not in cache:
        ymin=min(y for x,y in hull);ymax=max(y for x,y in hull)
        assert spans and [v[0] for v in spans]==list(range(spans[0][0],spans[-1][0]+1)) and spans[0][0]*20<=ymin and (spans[-1][0]+1)*20>=ymax
        poly=[tuple(map(F,p)) for p in hull]
        for row,lo,hi in spans:
            assert lo<hi
            clipped=clip(clip(poly,True,F(row*20)),False,F((row+1)*20));assert clipped and all(lo<=x<=hi for x,y in clipped)
            # Tightness is optional for validity; verify the exact outward rounding too.
            xmin=min(p[0] for p in clipped);xmax=max(p[0] for p in clipped)
            assert F(lo)<=xmin<F(lo+1) and F(hi-1)<xmax<=F(hi);clipped_bands+=1
        cache[hull]=spans
    else:assert spans==cache[hull]
    byrow=regions.setdefault(key,{})
    for y,lo,hi in spans:byrow.setdefault(y,[]).append((lo,hi))
assert set(regions)==needed
regions={k:{y:merge(v) for y,v in byrow.items()} for k,byrow in regions.items()}
certificates=removed_count=initial_count=remaining_count=group_count=subsets=0;allowed=[];excluded=[];improvements=[]
for row,source in zip(rows,source_rows):
    assert row['empty_sites']==source['empty_sites'] and row['initial_distributions']==source['remaining_distributions'] and row['scan_complete'];groups=source['groups'];supports=[{} for g in groups]
    for f,m,gid,ri,gi in source['region_component_assignments']:
        for y,spans in regions[(f,m,gid,ri)].items():supports[gi].setdefault(y,[]).extend(spans)
    supports=[{y:merge(v) for y,v in byrow.items()} for byrow in supports];assert len(row['groups'])==len(groups)
    for saved,g,byrow in zip(row['groups'],groups,supports):
        area=F(sum(hi-lo for spans in byrow.values() for lo,hi in spans),5)
        assert saved=={'family':g['family'],'family_component':g['family_component'],'area_upper_mm2':str(area),'old_area_upper_mm2':g['area_upper_mm2'],'band_spans_tenths_mm':[[y,lo,hi] for y,v in sorted(byrow.items()) for lo,hi in v]}
        group_count+=1;improvements.append(F(g['area_upper_mm2'])-area)
    possible={tuple(v) for v in row['initial_distributions']};initial_count+=len(possible)
    for cert in row['certificates']:
        selected=cert['groups'];assert selected==sorted(set(selected)) and selected and all(0<=i<len(groups) for i in selected);union={}
        for i in selected:
            for y,spans in supports[i].items():union.setdefault(y,[]).extend(spans)
        upper=F(sum(hi-lo for v in union.values() for lo,hi in merge(v)),5)
        coeff=[F(g['source_area_lower_mm2']) if i in selected else F(0) for i,g in enumerate(groups)]
        assert cert['upper_area_mm2']==str(upper) and cert['coefficients_mm2']==[str(v) for v in coeff]
        removed={v for v in possible if sum(n*c for n,c in zip(v,coeff))>upper}
        assert removed and cert['distributions_removed']==[list(v) for v in sorted(removed)]
        possible-=removed;certificates+=1;removed_count+=len(removed)
    assert row['remaining_distributions']==[list(v) for v in sorted(possible)] and row['restricted_construction_excluded']==(not possible)
    remaining_count+=len(possible);(allowed if possible else excluded).append(row['empty_sites']);subsets+=(1<<len(groups))-1
assert len(rows)==len(source_rows)==25 and certificates==26 and removed_count==40 and initial_count==82 and remaining_count==42 and len(allowed)==18 and len(excluded)==7
original=load(BASE/'checks.json');assert original['scan_complete'] and original['cap_overrun_seconds']==0 and original['subset_areas_examined']==subsets and original['source_band_spans']==source_spans
for name,values in [('allowed-empty-site-pairs.json',allowed),('excluded-empty-site-pairs.json',excluded),('source-bindings.json',bindings)]:write(OUT/name,values)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','source-fine-covers.json','all25-fine-band-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_swept_pieces_verified':len(parts),'source_swept_vertices_enclosed':corners,'unique_integer_hulls_verified':len(cache),'source_band_spans_verified':source_spans,'independent_exact_polygon_band_clippings':clipped_bands,'source_options_verified':len(needed),'group_supports_reconstructed':group_count,'minimum_group_area_reduction_mm2':str(min(improvements)),'maximum_group_area_reduction_mm2':str(max(improvements)),'necessary_subset_certificates_verified':certificates,'all_recorded_exclusions_independently_verified':True,'initial_count_distributions':initial_count,'count_distributions_excluded':removed_count,'remaining_count_distributions':remaining_count,'new_restricted_site_exclusions':len(excluded),'excluded_empty_site_pairs':excluded,'restricted_pairs_remaining':len(allowed),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
