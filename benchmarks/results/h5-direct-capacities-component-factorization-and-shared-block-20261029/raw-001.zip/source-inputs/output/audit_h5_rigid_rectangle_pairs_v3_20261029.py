"""Exact source-boundary cancellation and outward-mode bounds for rigid rectangle components."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter,defaultdict
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRE=BASE/'rigid-rectangle-preflight';OUT=PRE/'audit-v3';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(p):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))/2
def oriented(points):
    p=[tuple(map(F,r)) for r in points]
    return p if area(p)>0 else list(reversed(p))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(PRE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
parts={p['id']:p for p in load(JOB)['parts']};pieces=load(PIECES);modes=load(BASE/'integer-preparation/family-modes.json');records=load(PRE/'mode-rectangles.json');instances=load(BASE/'instances.json');partition_proofs=[];maximum_padding=F(0);mode_count=rectangles=0
for family in ['bracket','insert']:
    source=oriented(parts[family]['geometry'][0]['outer']);components=[oriented(p) for p in pieces[family]];lines=defaultdict(set)
    for ring in [source]+components:
        for a,b in zip(ring,ring[1:]+ring[:1]):
            assert (a[0]==b[0])!=(a[1]==b[1]);axis=1 if a[0]==b[0] else 0;fixed=a[1-axis];lines[axis,fixed].update([a[axis],b[axis]])
    def boundary(rings):
        result=Counter()
        for ring in rings:
            for a,b in zip(ring,ring[1:]+ring[:1]):
                axis=1 if a[0]==b[0] else 0;fixed=a[1-axis];lo,hi=sorted([a[axis],b[axis]]);cuts=sorted(x for x in lines[axis,fixed] if lo<=x<=hi);sign=1 if b[axis]>a[axis] else -1
                for x,y in zip(cuts,cuts[1:]):result[axis,fixed,x,y]+=sign
        return {k:v for k,v in result.items() if v}
    expected,actual=boundary([source]),boundary(components);assert actual==expected and all(abs(v)==1 for v in actual.values())
    boxes=[]
    for poly in components:
        xs,ys=sorted({p[0] for p in poly}),sorted({p[1] for p in poly});assert len(poly)==4 and len(xs)==len(ys)==2 and set(poly)=={(x,y) for x in xs for y in ys};boxes.append([xs[0],ys[0],xs[1],ys[1]])
    for a,b in combinations(boxes,2):assert max(F(0),min(a[2],b[2])-max(a[0],b[0]))*max(F(0),min(a[3],b[3])-max(a[1],b[1]))==0
    assert sum(area(p) for p in components)==area(source)
    partition_proofs.append({'family':family,'source_area_mm2':str(area(source)),'filled_components':len(components),'matching_exact_boundary_subedges':len(actual),'source_partition_exact':True})
    assert len(records[family])==len(modes[family])
    for mode,record in zip(modes[family],records[family]):
        assert record['mode']==mode['mode'] and record['geometry']==mode['normalized_geometry'] and len(record['rectangles'])==len(components)
        c,s=map(F,[math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians'])]);m=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left'])
        for pi,(component,saved) in enumerate(zip(components,record['rectangles'])):
            assert saved['piece']==pi;transformed=[(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in component];bounds=[min(p[0] for p in transformed),min(p[1] for p in transformed),max(p[0] for p in transformed),max(p[1] for p in transformed)];assert list(map(F,saved['exact_affine_bounds_mm']))==bounds
            out=saved['outward_offsets_um'];assert out==[math.floor(bounds[0]*1000),math.floor(bounds[1]*1000),math.ceil(bounds[2]*1000),math.ceil(bounds[3]*1000)]
            for x,y in transformed:assert F(out[0],1000)<=x<=F(out[2],1000) and F(out[1],1000)<=y<=F(out[3],1000)
            pads=[bounds[0]-F(out[0],1000),bounds[1]-F(out[1],1000),F(out[2],1000)-bounds[2],F(out[3],1000)-bounds[3]];assert all(0<=v<F(1,1000) for v in pads);maximum_padding=max(maximum_padding,*pads);rectangles+=1
        mode_count+=1
components=load(PRE/'components.json');pairs=load(PRE/'component-pairs.json');expected=[(i,pi) for i,r in enumerate(instances) for pi in range(len(pieces[r['identity'][0]]))]
assert [(c['owner'],c['piece']) for c in components]==expected
for i,c in enumerate(components):assert c['component']==i and c['identity']==instances[c['owner']]['identity']
assert pairs==[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']]
assert len(components)==20 and len(pairs)==183 and mode_count==12 and rectangles==20
write(OUT/'source-partition-proofs.json',partition_proofs)
inputs=[Path(__file__),ROOT/'output/audit_h5_rigid_rectangle_pairs_v2_20261029.py',ROOT/'output/audit_h5_rigid_rectangle_pairs_20261029.failed.txt',ROOT/'output/audit_h5_rigid_rectangle_pairs_20261029.py',JOB,PIECES,BASE/'instances.json',BASE/'integer-preparation/family-modes.json']+[PRE/n for n in ['plan.json','checks.json','mode-rectangles.json','components.json','component-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Split every source and component boundary at the combined exact rational axis endpoints. Verify cancellation leaves exactly the original outer boundary, component interiors are disjoint and areas sum exactly. Independently transform each component with exact rational affine coefficients for every source mode and verify every vertex lies in its outward micrometre rectangle. Check all183 and only different-owner component pairs. The model must still tie each rectangle rigidly to its original owner pose and selected mode.'})
result={'passed':True,'seconds':time.perf_counter()-started,'exact_source_filled_partitions_verified':2,'source_modes_verified':12,'mode_component_rectangles_verified':20,'maximum_outward_padding_mm':float(maximum_padding),'all_original_vertices_covered_exactly':True,'rigid_instance_components':20,'different_owner_pairs_verified':183,'direction_choices_needed':732,'independent_complete_model_audit_still_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
