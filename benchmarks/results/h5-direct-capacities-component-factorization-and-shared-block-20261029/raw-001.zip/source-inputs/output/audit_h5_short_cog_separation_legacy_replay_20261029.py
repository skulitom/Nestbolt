"""Independent exact full-circle and capsule proof; no GEOS or floating distance in proof."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
from h5_rational_geometry_helpers import trig,mul,add,sub
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-pair-rotation-certificate-20261026';SRC=ROOT/'output/h5-rotation-independent-geometry-20261026';OUT=ROOT/'output/h5-strip-capacity-short-core-20261029/cog-source-separation/legacy-replay'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda v:[v.numerator,v.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def atan_interval(x,n=120):
    s=sum(((-1)**k*x**(2*k+1)/(2*k+1) for k in range(n)),F(0));term=(-1)**n*x**(2*n+1)/(2*n+1);return min(s,s+term),max(s,s+term)
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def point_far(p,a,b,r2):
    dx,dy=b[0]-a[0],b[1]-a[1];ux,uy=p[0]-a[0],p[1]-a[1];length=dx*dx+dy*dy;t=ux*dx+uy*dy
    if t<=0:return ux*ux+uy*uy>r2
    if t>=length:return (p[0]-b[0])**2+(p[1]-b[1])**2>r2
    return (dx*uy-dy*ux)**2>r2*length
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and BASE/'audit' not in p.parents}|{'output/h5_rational_geometry_helpers.py':digest(ROOT/'output/h5_rational_geometry_helpers.py')},'method':'Use exact Machin arctangent alternating-series bounds for pi, exact rational Taylor sin/cos bounds, integer segment distances and winding topology. Each inverse-midpoint segment has a radius0.615mm capsule strictly inside the original polygon. Rotation across its entire cell moves every point at most140.001*0.004364mm; inverse endpoint rounding error is below0.000001mm. Prove this sum is less than0.615mm, so the entire horizontal segment is inside every original rotation in its cell. Verify full angle coverage and every stored pair witness. No reliance on GEOS erosion or regular tooth symmetry.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SRC/'audit/checks.json')['passed'];p=load(SRC/'original-cog-proof.json');vs=[tuple(F(*v) for v in row) for row in p['centered_vertices_rational']];phases=list(map(F,load(BASE/'phases-radians.json')));plan=load(BASE/'plan.json');half=F(*plan['phase_half_width_radians_rational']);rho=F(*plan['audit_capsule_radius_mm_rational']);R=F(140001,1000);error=F(1,1000000);assert R*half+error<rho and len(phases)==720 and phases==sorted(phases)
# Machin's identity follows from tan(2 arctan(1/5))=5/12,
# tan(4 arctan(1/5))=120/119 and tan(4a-arctan(1/239))=1.
# The angle is in(0,pi/2), hence4a-arctan(1/239)=pi/4.
a=atan_interval(F(1,5));b=atan_interval(F(1,239));pi=(16*a[0]-4*b[1],16*a[1]-4*b[0]);assert phases[0]-half<=0 and phases[-1]+half>=2*pi[1] and all(v-u<=2*half for u,v in zip(phases,phases[1:]));assert F(3)<pi[0]<pi[1]<F(22,7)
scale=math.lcm(10**9,200,*(v.denominator for pt in vs for v in pt));vertices=[tuple(int(v*scale) for v in pt) for pt in vs];edges=list(zip(vertices,vertices[1:]+vertices[:1]));radius=int(rho*scale);r2=radius*radius;assert F(radius,scale)==rho
trigs=[]
for phase in phases:
    si,co=trig(phase);den=10**15;trigs.append(tuple((F(math.floor(lo*den),den),F(math.ceil(hi*den),den)) for lo,hi in [si,co]))
rows=load(BASE/'segments.json');certs={};edge_checks=0;max_error=F(0)
for row in rows:
    k,j,side=row['phase'],row['level'],row['side'];key=(k,j,side);assert key not in certs and side in ['left','right'];certs[key]=row;x,y=map(lambda v:F(v,1000),row['endpoint_units1000']);assert y==F(plan['section_levels_units1000'][j],1000) and (x>0 if side=='right' else x<0) and x*x+y*y<=R*R;si,co=trigs[k];q=row['inverse_segment_endpoints_units1e9']
    for original,rounded in zip([(F(0),y),(x,y)],q):
        u,v=original;exact=(add(mul((u,u),co),mul((v,v),si)),sub(mul((v,v),co),mul((u,u),si)));er=sum(max(abs(t-F(rounded[d],10**9)) for t in exact[d])**2 for d in [0,1]);assert er<error*error;max_error=max(max_error,er)
    aa,bb=[tuple(int(F(v,10**9)*scale) for v in pt) for pt in q];assert aa!=bb
    # The first endpoint is inside the certified109.115mm inner disk.
    assert aa[0]**2+aa[1]**2<(F(109115,1000)*scale)**2
    for c,d in edges:
        e1,e2=cross(aa,bb,c),cross(aa,bb,d);f1,f2=cross(c,d,aa),cross(c,d,bb)
        assert (e1>0 and e2>0) or (e1<0 and e2<0) or (f1>0 and f2>0) or (f1<0 and f2<0),'midpoint segment crosses source boundary'
        assert point_far(aa,c,d,r2) and point_far(bb,c,d,r2) and point_far(c,aa,bb,r2) and point_far(d,aa,bb,r2),'capsule reaches source boundary';edge_checks+=1
    assert time.perf_counter()-start<180,'Exact audit cap reached; no pass'
witness=(BASE/'pair-witness-levels.bin').read_bytes();assert len(witness)==720*720;minimum=None
for i in range(720):
    for j in range(720):
        level=witness[i*720+j];a=certs[i,level,'right'];b=certs[j,level,'left'];assert a['endpoint_units1000'][1]==b['endpoint_units1000'][1];reach=a['endpoint_units1000'][0]-b['endpoint_units1000'][0];assert reach>=254300;minimum=reach if minimum is None else min(minimum,reach)
write(OUT/'necessity-proof.json',{'original_cog_center_separation_units1000':254300,'rounded_center_separation_units1000':254297,'source_vertices':80,'all_original_angles':True,'all_phase_pairs':518400,'exact_pi_bounds':[ratio(v) for v in pi],'max_inverse_rounding_error_squared_mm2':ratio(max_error),'statement':'The720 overlapping closed angle cells cover[0,2pi] using independently bounded pi. Each used horizontal segment has endpoints whose inverse-midpoint transforms differ from the stored nanometre points by less than1e-6mm. Exact integer segment intersections and distances prove its radius0.615mm capsule strictly within the original source polygon, starting inside the certified inner disk. Every segment point has norm<=140.001mm, so rotation across a cell changes its inverse position by at most140.001*0.004364mm; adding rounding error stays below0.615mm. The entire segment thus belongs to every cog orientation in that cell. For every ordered cell pair there is a common horizontal level with rightA-leftB>=254.3mm. At any positive center separation d<254.3mm, the segment[0,rightA] overlaps[d+leftB,d], proving intersection. Coincident centers intersect by the inner disks. A simultaneous world rotation aligns any center displacement with the positive X axis without restricting either original angle. Every nonintersecting original cog pair therefore has center distance>=254.3mm at arbitrary rotations. Relative1micrometre flooring loses less than sqrt(2) units; a conservative3 units gives254297.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'full_circle_cells_verified':720,'independent_pi_coverage_verified':True,'robust_segments_verified':len(rows),'integer_capsule_edge_checks':edge_checks,'ordered_phase_pairs_verified':518400,'minimum_certified_pair_reach_units1000':minimum,'original_all_angle_center_separation_units1000':254300,'rounded_center_separation_units1000':254297,'no_rotational_symmetry_assumed':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
