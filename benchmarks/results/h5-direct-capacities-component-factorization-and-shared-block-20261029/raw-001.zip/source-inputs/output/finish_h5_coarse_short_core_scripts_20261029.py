"""Finish the two files omitted by a too-strict source-replacement assertion."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for stem in ['check_h5_global_short_core_candidate_20261029','run_h5_global_short_core_20261029']:
    s=(ROOT/(stem+'.py')).read_text(encoding='utf-8').replace('h5_global_short_core_','h5_coarse_short_core_').replace("output/h5-global-short-core-20261029'","output/h5-coarse-short-core-20261029'").replace("PRE=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight'","GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight'").replace("PRE/'cog-core.json'","GEOM/'cog-core.json'").replace('orthogonal-modes.json','modes.json')
    if stem.startswith('check_'):
        assert "center=list(map(float,coredata['source_center_mm']))" in s
        s=s.replace("center=list(map(float,coredata['source_center_mm']))","center=[float(F(v)) for v in coredata['source_center_mm']]").replace("xy=[values[item[k]] for k in ['x','y']]","xy=[100*values[item[k]] for k in ['x','y']]")
    name=stem.replace('global','coarse')+'.py';compile(s,name,'exec')
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Created candidate checker and runner; no model or solver was opened.')
