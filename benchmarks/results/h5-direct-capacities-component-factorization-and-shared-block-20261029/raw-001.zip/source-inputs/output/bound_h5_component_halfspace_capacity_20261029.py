"""Whole-bracket capacity from mandatory material inside component halfspaces."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'component-halfspace-bound';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
assert load(PRIOR/'connected-capacity-bound/audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter();modes=load(PRIOR/'family-modes.json')['bracket'];pieces=load(PIECES)['bracket'];rects=[]
for mode in modes:
    c=F(math.cos(mode['rotation_radians']));s=F(math.sin(mode['rotation_radians']));m=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left']);inner=[]
    for piece in pieces:
        p=[(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in piece]
        if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))<0:p.reverse()
        bounds=[min(x for x,y in p)+F('1e-6'),min(y for x,y in p)+F('1e-6'),max(x for x,y in p)-F('1e-6'),max(y for x,y in p)-F('1e-6')];l,b,r,t=bounds
        assert l<r and b<t and all(cross(a,z,q)>=0 for a,z in zip(p,p[1:]+p[:1]) for q in [(l,b),(l,t),(r,b),(r,t)])
        inner.append(bounds)
    rects.append(inner)
regions={}
unary=load(PRIOR/'integer-preparation/unary-templates.json')
for record in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if record['family']!='bracket':continue
    key=(record['mode'],record['geometry'],record['region']);bits=0
    for row,a,b in record['grid_row_spans']:bits|=((1<<(b-a+1))-1)<<((row-200)*150+a)
    if key not in regions:
        poly=[tuple(map(F,p)) for p in unary[record['geometry']]['regions'][record['region']]['hull_vertices']]
        regions[key]={'mask':record['required_empty_mask'],'bits':0,'bounds':[min(p[0] for p in poly),min(p[1] for p in poly),max(p[0] for p in poly),max(p[1] for p in poly)]}
    regions[key]['bits']|=bits
@lru_cache(None)
def mandatory(mode,axis,above,offset,cut):
    total=F(0)
    for box in rects[mode]:
        lo,hi=box[axis]+offset,box[axis+2]+offset;length=max(F(0),hi-max(lo,cut)) if above else max(F(0),min(hi,cut)-lo)
        total+=length*(box[3-axis]-box[1-axis])
    return total
rows=[];certificate_count=0
for prior in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json'):
    if prior['restricted_construction_excluded']:continue
    empty=sum(1<<i for i in prior['empty_sites']);components=[int(v,16) for v in prior['components_hex']];ranges=[{} for _ in components];assignments=[]
    for key,record in regions.items():
        if record['mask']&~empty:continue
        candidates=[i for i,bits in enumerate(components) if record['bits']&~bits==0];assert len(candidates)==1
        ci=candidates[0];mode=key[0];bounds=record['bounds'];assignments.append([*key,ci])
        if mode not in ranges[ci]:ranges[ci][mode]=bounds[:]
        else:ranges[ci][mode]=[min(ranges[ci][mode][i],bounds[i]) if i<2 else max(ranges[ci][mode][i],bounds[i]) for i in range(4)]
    records=[]
    for ci,bits in enumerate(components):
        assert time.perf_counter()-started<60,'Diagnostic preparation cap reached; no completed proof claim'
        xs=[0]*150;ys=[0]*100
        for i in range(15000):
            if bits>>i&1:y,x=divmod(i,150);xs[x]+=1;ys[y]+=1
        total=bits.bit_count()*100;capacity=total//40000;best={'method':'total_area','upper_area_mm2':total,'capacity':capacity};tested=0
        for axis,counts,origin in [(0,xs,0),(1,ys,2000)]:
            below_count=0
            for index in range(len(counts)+1):
                cut=F(origin+10*index)
                for above in [False,True]:
                    available=(bits.bit_count()-below_count if above else below_count)*100
                    choices={mode:mandatory(mode,axis,above,bounds[axis if above else axis+2],cut) for mode,bounds in ranges[ci].items()}
                    least=min(choices.values()) if choices else F(0);tested+=1
                    if least>0:
                        bound=int(F(available)/least)
                        if bound<capacity:
                            capacity=bound;best={'method':'halfspace','axis':axis,'above':above,'threshold_mm':str(cut),'upper_area_mm2':available,'per_mode_minimum_area_mm2':{str(m):str(v) for m,v in choices.items()},'minimum_bracket_area_mm2':str(least),'capacity':bound}
                if index<len(counts):below_count+=counts[index]
        records.append({'component':ci,'mode_position_bounds_mm':{str(m):[str(v) for v in b] for m,b in ranges[ci].items()},'total_area_upper_bound_mm2':total,'prior_capacity':total//40000,'capacity_upper_bound':capacity,'strongest_certificate':best,'halfspaces_examined':tested});certificate_count+=best['method']=='halfspace'
    total_capacity=sum(r['capacity_upper_bound'] for r in records)
    rows.append({'empty_sites':prior['empty_sites'],'region_component_assignments':assignments,'components':records,'total_bracket_capacity_upper_bound':total_capacity,'required_brackets':7,'restricted_construction_excluded':total_capacity<7})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),PIECES,PRIOR/'family-modes.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'rigid-rectangle-preflight/audit-v3/plan.json',PRIOR/'rigid-rectangle-preflight/audit-v3/checks.json',PRIOR/'accessible-area-bound/plan.json',PRIOR/'accessible-area-bound/audit/plan.json',PRIOR/'accessible-area-bound/audit/checks.json',PRIOR/'accessible-area-bound/swept-covers.json',PRIOR/'connected-capacity-bound/plan.json',PRIOR/'connected-capacity-bound/audit/plan.json',PRIOR/'connected-capacity-bound/audit/checks.json',PRIOR/'connected-capacity-bound/all105-capacity-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Assign every conditional bracket swept region to its unique audited grid connected component. For each component and legal mode, take conservative extrema of all lower-left positions. Contained axis rectangles with1e-6mm inset give a lower bound on source occupied area in each halfspace. Above-cut area is monotone in position and below-cut area antitone, so extrema bound every allowed position. Divide the component grid area in that halfspace by the minimum over all modes to bound whole-bracket count. Keep the strongest certificate per component. Sum capacities to bound the seven original brackets. This applies only to the saved conservative site-mask construction.','preparation_cap_seconds':60,'solver_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'source-inner-rectangles.json',[[[str(v) for v in b] for b in mode] for mode in rects]);write(OUT/'all35-halfspace-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'site_pairs_examined':len(rows),'improved_component_certificates':certificate_count,'additional_restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'capacity_range':[min(r['total_bracket_capacity_upper_bound'] for r in rows),max(r['total_bracket_capacity_upper_bound'] for r in rows)],'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
