"""Independently verify the stronger source-pair bound on the current coarse grid."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-short-core-20261029/cog-source-separation';OUT=BASE/'audit';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';SRC=ROOT/'output/h5-rotation-independent-geometry-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,BASE/'legacy-replay',PRE/'audit',SRC/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
replay=load(BASE/'legacy-replay/checks.json');assert replay['passed'] and replay['ordered_phase_pairs_verified']==518400 and replay['integer_capsule_edge_checks']==2307200
job=load(JOB);cog=next(p for p in job['parts'] if p['id']=='cog');proof=load(SRC/'original-cog-proof.json');old=list(map(F,proof['center']));new=list(map(F,load(GEOM/'cog-core.json')['source_center_mm']));assert [[F(x)-old[0],F(y)-old[1]] for x,y in cog['geometry'][0]['outer']]==[[F(*v) for v in row] for row in proof['centered_vertices_rational']]
b=load(BASE/'bound.json');shift=sum(((a-z)*1000)**2 for a,z in zip(old,new));assert shift==F(b['source_center_shift_norm_squared_um2'])<F(b['source_center_shift_bound_um'])**2
assert F(b['single_rounding_norm_bound_um'])**2>50**2+50**2;error=2*(F(b['single_rounding_norm_bound_um'])+F(b['source_center_shift_bound_um']));assert error==F(b['relative_center_error_bound_um']);original=load(BASE/'legacy-replay/necessity-proof.json')['original_cog_center_separation_units1000'];assert original==b['original_source_center_distance_um']==254300
d=b['rounded_center_distance_lower_bound_um'];assert d<=original-error<d+1;stock=load(PRE/'inventory.json')['cog_center_stock_bounds_grid_units'];assert stock==b['center_stock_bounds_grid_units'];dy=100*(stock[3]-stock[1]);assert dy==b['maximum_rounded_center_y_difference_um'];steps=b['required_ordered_center_x_difference_grid_units'];assert (100*(steps-1))**2+dy**2<d*d and (100*steps)**2+dy**2>=d*d and 100*steps==b['required_ordered_center_x_difference_um']
assert {'left_identity':['cog',0],'right_identity':['cog',14],'axis':'x','only_enforce_if_both_present':True} in load(PRE/'orders.json');sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');source_stock=sp['source_stock'];controls=load(BASE/'controls.json')
for control in controls:
    rows=load(BASE/f'{control["name"]}-source2.json');shapes=[];rounded=[]
    for p in rows:
        t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);x,y=t['translation'];shapes.append(Polygon([(u*co-v*si+x,u*si+v*co+y) for u,v in cog['geometry'][0]['outer']]));cx=co*float(new[0])-si*float(new[1])+x;cy=si*float(new[0])+co*float(new[1])+y;rounded.append([round(cx*10),round(cy*10)])
    assert rounded==control['rounded_centers_grid_units']
    for a in shapes:
        lo,bo,hi,to=a.bounds;assert min(lo-source_stock[0],bo-source_stock[1],source_stock[2]-hi,source_stock[3]-to)>sp['stock_guard_mm']
    sourcegood=shapes[0].disjoint(shapes[1]) and shapes[0].distance(shapes[1])>sp['required_pair_gap_mm'];assert sourcegood==control['source_valid']==control['passes_new_necessary_bound'];assert control['ordered_x_difference_grid_units']==rounded[1][0]-rounded[0][0];assert (rounded[1][0]-rounded[0][0]>=steps)==sourcegood
inputs=[Path(__file__),BASE/'legacy-replay/plan.json',SRC/'audit/plan.json',PRE/'audit/plan.json']+list(BASE.glob('*.json'));write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fresh_all_angle_certificate_replay_verified':True,'original80_vertices_exactly_verified':True,'rational_center_change_and_coarse_rounding_verified':True,'original_pair_distance_um':original,'coarse_pair_distance_lower_bound_um':d,'maximum_coarse_y_difference_um':dy,'minimum_ordered_x_difference_grid_units':steps,'positive_and_negative_source_pairs_independently_verified':True,'old_core_witness_set_preservation_claimed':False,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
