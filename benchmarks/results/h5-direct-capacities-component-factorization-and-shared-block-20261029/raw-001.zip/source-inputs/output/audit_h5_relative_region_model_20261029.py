"""Verify every sparse model row and exact implication into certified free regions."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, math, shutil, time
import numpy as np
from scipy.sparse import csc_matrix

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
PRE = SOURCE / 'relative-free-region-preflight'
BASE = ROOT / 'output/h5-short11-relative-region-model-20261029'
OUT = BASE / 'audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for folder in [BASE, PRE / 'audit']:
    for name, expected in load(folder / 'plan.json')['inputs'].items():
        assert digest(ROOT / name) == expected, name
assert load(PRE / 'audit/checks.json')['passed']
groups = load(PRE / 'groups.json')
mapping = load(BASE / 'mapping.json')
model = np.load(BASE / 'model.npz')
data, indices, indptr, shape, lower, upper, bounds, objective, integrality = [model[k] for k in ['data', 'indices', 'indptr', 'shape', 'lower', 'upper', 'bounds', 'c', 'integrality']]
matrix = csc_matrix((data, indices, indptr), shape=tuple(shape)).tocsr()
assert matrix.shape == (2328, 717) and matrix.nnz == 10968
assert np.array_equal(bounds[:22], np.load(SOURCE / 'model.npz')['bounds'][:22])
assert np.array_equal(bounds[22:], np.tile([0., 1.], (695, 1)))
assert np.array_equal(objective, np.zeros(717))
assert np.array_equal(integrality, np.r_[np.zeros(22), np.ones(695)])
assert load(BASE / 'inventory.json') == load(SOURCE / 'inventory.json')
assert load(BASE / 'seed-source11.json') == load(SOURCE / 'seed-source11.json')
assert len(groups) == len(mapping) == 55
used_rows, selectors, pairs = set(), set(), set()
minimum_inset = minimum_inactive_slack = None
planes = 0

def check_row(index, coefficients, lo, hi):
    assert index not in used_rows
    used_rows.add(index)
    start, end = matrix.indptr[index:index+2]
    actual = dict(zip(map(int, matrix.indices[start:end]), map(float, matrix.data[start:end])))
    assert actual == {i: float(v) for i, v in coefficients.items() if v != 0}
    assert lower[index] == lo and upper[index] == hi

for group, record in zip(groups, mapping):
    ia, ib = group['owners']
    assert record['owners'] == [ia, ib] and (ia, ib) not in pairs
    pairs.add((ia, ib))
    assert len(group['regions']) == len(record['regions'])
    variable_indices = [2*ia, 2*ia+1, 2*ib, 2*ib+1]
    domain = [[F(v) for v in bounds[i]] for i in variable_indices]
    relative = [[domain[2][0]-domain[0][1], domain[2][1]-domain[0][0]],
                [domain[3][0]-domain[1][1], domain[3][1]-domain[1][0]]]
    group_selectors = []
    for index, (vertices, region) in enumerate(zip(group['regions'], record['regions'])):
        assert region['region'] == index and len(region['planes']) == len(vertices)
        selector = region['selector']
        assert 22 <= selector < 717 and selector not in selectors
        selectors.add(selector)
        group_selectors.append(selector)
        points = [tuple(map(F, p)) for p in vertices]
        for edge, (a, b, plane) in enumerate(zip(points, points[1:]+points[:1], region['planes'])):
            assert plane['edge'] == edge
            ex, ey = b[0]-a[0], b[1]-a[1]
            length = F(math.hypot(float(ex), float(ey)))
            exact_normal = [ey/length, -ex/length]
            nx, ny = map(F, plane['normal'])
            assert plane['normal'] == [round(float(v), 12) for v in exact_normal]
            error = sum(abs(v-w)*max(abs(d[0]), abs(d[1])) for v, w, d in zip(exact_normal, [nx, ny], relative))
            assert float(error) == plane['rounding_error_bound_mm']
            exact_rhs = exact_normal[0]*a[0]+exact_normal[1]*a[1]
            row_index = plane['row']
            rhs, M = plane['rhs'], plane['M']
            actual_upper = float(rhs+M)
            inset = exact_rhs-(F(actual_upper)-F(M))-error
            assert inset > F('0.00000009999')
            minimum_inset = inset if minimum_inset is None else min(minimum_inset, inset)
            coefficients = [-nx, -ny, nx, ny]
            domain_maximum = sum(c*d[1 if c >= 0 else 0] for c, d in zip(coefficients, domain))
            slack = F(actual_upper)-domain_maximum
            assert slack > 0
            minimum_inactive_slack = slack if minimum_inactive_slack is None else min(minimum_inactive_slack, slack)
            coefficient_map = dict(zip(variable_indices, coefficients))
            coefficient_map[selector] = M
            check_row(row_index, coefficient_map, -np.inf, actual_upper)
            planes += 1
    check_row(record['one_of_row'], {i: 1. for i in group_selectors}, 1., 1.)
assert used_rows == set(range(2328)) and selectors == set(range(22, 717))
assert pairs == {(a, b) for a in range(11) for b in range(a+1, 11)}
assert not np.any((np.abs(data) > 0) & (np.abs(data) <= 1e-9))
inputs = [Path(__file__), BASE / 'plan.json', BASE / 'checks.json', BASE / 'model.npz', BASE / 'mapping.json',
          BASE / 'seed-source11.json', BASE / 'inventory.json', SOURCE / 'audit/plan.json',
          SOURCE / 'audit/checks.json', PRE / 'groups.json', PRE / 'audit/plan.json',
          PRE / 'audit/checks.json', PRE / 'audit/support-certificates.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'whole_original_pairs': len(pairs),
          'convex_region_selectors': len(selectors), 'region_edge_planes': planes,
          'all2328_rows_and717_variables_verified': True, 'all22_stock_domains_unchanged': True,
          'all11_short_and55_first_identities_unchanged': True,
          'exact_active_plane_implications_into_certified_regions': planes,
          'minimum_plane_inset_after_rounding_mm': float(minimum_inset),
          'minimum_inactive_domain_slack_mm': float(minimum_inactive_slack),
          'tiny_matrix_coefficients': 0, 'zero_objective_verified': True,
          'model_sha256': digest(BASE / 'model.npz'), 'negative_result_cannot_exclude_allocation': True,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
