"""Independently verify swept convex hulls and exact clipped-band area covers."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';BOUND=BASE/'accessible-area-bound';OUT=BOUND/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def clip(poly,y,above):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=(a[1]>=y if above else a[1]<=y);inb=(b[1]>=y if above else b[1]<=y)
        if ina:result.append(a)
        if ina!=inb:result.append((a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]),y))
    return result
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BOUND/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts)
        assert digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
unary=load(BASE/'integer-preparation/unary-templates.json');modes=load(BASE/'rigid-rectangle-preflight/mode-rectangles.json')
family_modes=load(BASE/'family-modes.json');partitions=load(BASE/'rigid-rectangle-preflight/audit-v3/source-partition-proofs.json')
assert {p['family']:F(p['source_area_mm2']) for p in partitions}=={'bracket':40000,'insert':19800}
for opts in family_modes.values():
    for opt in opts:
        c=F(math.cos(opt['rotation_radians']));s=F(math.sin(opt['rotation_radians']))
        assert c*c+s*s>=1,'Original filled area is a lower bound under these exact affine constants'
expected={}
for family,opts in modes.items():
    for opt in opts:
        for r in unary[opt['geometry']]['regions']:
            if len(r['hull_vertices'])<3:continue
            for rect in opt['rectangles']:expected[(family,opt['mode'],opt['geometry'],r['region'],rect['piece'])]=(r,rect)
groups={family:{} for family in modes};total_rows=0
for record in load(BOUND/'swept-covers.json'):
    key=tuple(record[k] for k in ['family','mode','geometry','region','piece']);region,rect=expected.pop(key)
    assert region['required_empty_mask']==record['required_empty_mask']
    hp=[tuple(map(F,v)) for v in region['hull_vertices']]
    l,b,r,t=[F(v,1000) for v in rect['outward_offsets_um']]
    sums={(x+dx,y+dy) for x,y in hp for dx,dy in [(l,b),(l,t),(r,b),(r,t)]}
    poly=[tuple(map(F,v)) for v in record['swept_hull']]
    assert len(poly)>=3 and len(set(poly))==len(poly) and set(poly)<=sums
    assert all(cross(poly[i-2],poly[i-1],poly[i])>0 for i in range(len(poly)))
    assert all(cross(a,b,p)>=0 for a,b in zip(poly,poly[1:]+poly[:1]) for p in sums)
    assert all(0<=x<1500 and 2000<=y<3000 for x,y in poly)
    first=int(min(y for x,y in poly)//10);last=int(max(y for x,y in poly)//10)
    assert [r[0] for r in record['grid_row_spans']]==list(range(first,last+1))
    bits=0
    for row,left,right in record['grid_row_spans']:
        section=clip(clip(poly,F(row*10),True),F((row+1)*10),False)
        assert section
        assert left==int(min(x for x,y in section)//10) and right==int(max(x for x,y in section)//10)
        assert 0<=left<=right<150 and 200<=row<300
        for column in range(left,right+1):bits|=1<<((row-200)*150+column)
        total_rows+=1
    family=record['family'];mask=record['required_empty_mask']
    groups[family][mask]=groups[family].get(mask,0)|bits
assert not expected
assert {k:{str(m):hex(v) for m,v in g.items()} for k,g in groups.items()}==load(BOUND/'family-mask-covers.json')
results=load(BOUND/'all105-area-bounds.json');assert [r['empty_sites'] for r in results]==[list(p) for p in combinations(range(15),2)]
for r in results:
    empty=set(r['empty_sites']);assert r['occupied_sites']==[i for i in range(15) if i not in empty]
    mask=sum(1<<i for i in empty);covers={}
    for family,g in groups.items():
        bits=0
        for required,v in g.items():
            if (required|mask)==mask:bits|=v
        covers[family]=bits
    upper={k:bin(v).count('1')*100 for k,v in covers.items()}
    upper['combined']=bin(covers['bracket']|covers['insert']).count('1')*100
    assert upper==r['area_upper_bounds_mm2']
    required={'bracket':280000,'insert':118800,'combined':398800};assert r['area_required_mm2']==required
    contradictions=[k for k in required if upper[k]<required[k]]
    assert contradictions==r['contradictions'] and bool(contradictions)==r['restricted_construction_excluded']
checks=load(BOUND/'checks.json');excluded=sum(r['restricted_construction_excluded'] for r in results)
assert excluded==checks['restricted_pairs_excluded']==68 and checks['cap_overrun_seconds']==0
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),BOUND/'plan.json']+[BOUND/n for n in ['checks.json','swept-covers.json','family-mask-covers.json','all105-area-bounds.json']]+[BASE/'family-modes.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in results if not r['restricted_construction_excluded']])
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'swept_convex_hulls_verified':3286,'exact_clipped_bands_verified':total_rows,'empty_site_pairs_verified':105,'restricted_pairs_excluded':excluded,'restricted_pairs_remaining':105-excluded,'all_68_exclusions_from_bracket_area':all(r['contradictions']==['bracket'] for r in results if r['restricted_construction_excluded']),'no_global_allocation_exclusion':True,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
