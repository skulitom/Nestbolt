"""Independent original66 acceptance for a serialized whole-sheet assignment."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_transfer43_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';OUT=BASE/'search/source-response';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');start=time.perf_counter();plan=load(BASE/'plan.json');mp=load(BASE/'model/mapping.json');values=load(BASE/'search/assignment.json');poses=[]
for item in mp['items']:
    assert values[item['presence']]==1;choices=[o['mode'] for o in item['options'] if values[o['selector']]];assert len(choices)==1;poses.append({'block':item['index'],'mode':choices[0],'anchor_um':[values[item['x']],values[item['y']]]})
job=load(JOB);rows,error=reconstruct(job,load(BASE/'blocks43.json'),load(BASE/'modes.json'),load(BASE/'fixed-poses.json')+poses,load(BASE/'short12.json'));assert len(poses)==5 and len(rows)==66
checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])]);assert checked['cutouts']==90 and checked['hole_vertices']==10026
write(OUT/'selected-poses.json',poses);write(OUT/'source66.json',rows);write(OUT/'source-audit.json',checked)
inputs=[BASE/n for n in ['plan.json','model/mapping.json','blocks43.json','modes.json','short12.json','fixed-poses.json','fixed-source61.json','search/assignment.json']]+[JOB,ROOT/'output/h5_transfer43_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals':66,'maximum_offset_error_mm':error,'source_valid':checked['valid'],'source_collisions':checked['pair_failures'],'source_stock_failures':checked['stock_failures'],'holes':checked['cutouts'],'hole_vertices':checked['hole_vertices'],'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
