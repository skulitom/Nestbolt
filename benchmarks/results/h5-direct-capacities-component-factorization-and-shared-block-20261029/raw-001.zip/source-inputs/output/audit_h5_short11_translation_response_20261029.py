"""Read the closed LP and inspect an independently derived axis-aligned subsystem."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';PRE=BASE/'source-translation-preflight';SEARCH=BASE/'source-translation-search';OUT=BASE/'source-translation-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();opened=load(SEARCH/'opened.json')
for p in [PRE/'plan.json',PRE/'audit/plan.json',SEARCH/'opened.json']:
    for n,h in load(p).get('inputs',{}).items():assert digest(ROOT/n)==h,n
assert load(PRE/'audit/checks.json')['passed'] and digest(SEARCH/'model.npz')==opened['model_sha256'];planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');data=np.load(SEARCH/'model.npz');A,b,c,bb=[data[n] for n in ['A','b','c','bounds']];assert A.shape==(8770,23) and b.shape==(8770,) and c.tolist()==[0]*22+[1] and bb.tolist()==bounds
for k,row in enumerate(planes):
    expected=np.zeros(23);i,j=row['owners'];expected[2*i:2*i+2]=row['normal'];expected[2*j:2*j+2]=-np.asarray(row['normal']);assert np.array_equal(A[k],expected) and b[k]==row['upper_delta_difference_mm']
for i in range(22):
    for offset,sign in [(0,1),(1,-1)]:
        k=8726+2*i+offset;expected=np.zeros(23);expected[i]=sign;expected[-1]=-1;assert np.array_equal(A[k],expected) and b[k]==0
r=load(SEARCH/'result.json');process=load(SEARCH/'process.json');budget=load(SEARCH/'budget.json');assert r['closed'] and r['solver_calls']==1 and r['status_code']==2 and not r['success'] and not r['has_assignment'] and not r['source_valid11'] and not r['source_valid66'] and not r['any_allocation_excluded'] and r['native_calls']==0 and process['closed'] and process['exit_code']==0 and not process['timeout']
assert opened['method']=='highs-ds' and opened['maximum_calls']==1 and not opened['retry_permitted'] and opened['options']['presolve'] and opened['options']['time_limit']==r['allocated_solve_seconds'];assert r['preparation_seconds_charged']==budget['preparation_seconds_charged']==load(PRE/'checks.json')['seconds'] and r['returned_solve_overrun_seconds']==r['algorithm_overrun_seconds']==0 and r['algorithm_seconds_including_preparation']<60 and process['seconds_including_preparation']<90
assert (SEARCH/'stderr.txt').read_text()=='' and not (SEARCH/'assignment.json').exists() and not (SEARCH/'candidate-source11.json').exists();edges=[]
def edge(a,z,weight,source):edges.append({'from':a,'to':z,'weight':F(weight),'source':source})
for i,(lo,hi) in enumerate(bounds[:22]):edge(22,i,F(hi),{'kind':'stock_upper','variable':i});edge(i,22,-F(lo),{'kind':'stock_lower','variable':i})
for k,row in enumerate(planes):
    n=row['normal'];axis=0 if abs(n[0])>1-1e-12 and abs(n[1])<1e-12 else 1 if abs(n[1])>1-1e-12 and abs(n[0])<1e-12 else None
    if axis is None:continue
    sign=1 if n[axis]>0 else -1;i,j=row['owners'];error=F(0)
    for d in [0,1]:
        coefficient=F(sign if d==axis else 0)-F(n[d]);low=F(bounds[2*i+d][0])-F(bounds[2*j+d][1]);high=F(bounds[2*i+d][1])-F(bounds[2*j+d][0]);error+=max(coefficient*low,coefficient*high)
    weight=F(row['upper_delta_difference_mm'])+error+F(1,10**9);a,z=(2*j+axis,2*i+axis) if sign==1 else (2*i+axis,2*j+axis);edge(a,z,weight,{'kind':'conservative_axis_projection','plane':k,'axis':axis,'normal_sign':sign,'coefficient_error_allowance_mm':str(error),'extra_rounding_allowance_mm':'1/1000000000'})
dist=[F(0)]*23;pred=[None]*23;changed=None
for iteration in range(23):
    changed=None
    for k,e in enumerate(edges):
        if dist[e['to']]>dist[e['from']]+e['weight']:dist[e['to']]=dist[e['from']]+e['weight'];pred[e['to']]=k;changed=e['to']
    if changed is None:break
cycle=[]
if changed is not None:
    v=changed
    for _ in range(23):assert pred[v] is not None;v=edges[pred[v]]['from']
    first=v
    while True:
        k=pred[v];cycle.append(k);v=edges[k]['from']
        if v==first:break
        assert len(cycle)<=23
    cycle.reverse();assert sum(edges[k]['weight'] for k in cycle)<0 and all(edges[cycle[i]]['to']==edges[cycle[(i+1)%len(cycle)]]['from'] for i in range(len(cycle)))
serialized=[{**e,'weight':str(e['weight'])} for e in edges];write(OUT/'axis-subsystem.json',{'variables':23,'edges':serialized,'negative_cycle_edge_indices':cycle,'negative_cycle_sum_mm':str(sum((edges[k]['weight'] for k in cycle),F(0))) if cycle else None,'negative_cycle_found':bool(cycle),'scope':'Necessary axis-aligned consequences of this frozen LP only; no allocation/global infeasibility claim.'})
inputs=[Path(__file__),PRE/'plan.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'planes.json',PRE/'variable-bounds.json',SEARCH/'opened.json']+[SEARCH/n for n in ['model.npz','result.json','process.json','budget.json','stdout.txt','stderr.txt']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'closed_lp_calls':1,'solver_reported_status':'INFEASIBLE','all8770_matrix_rows_and23_variables_verified':True,'all8726_piece_pair_rows_verified':True,'stock_and_max_move_domains_verified':True,'preparation_seconds_charged':r['preparation_seconds_charged'],'returned_solve_seconds':r['returned_solve_seconds'],'algorithm_seconds_including_preparation':r['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'all_overruns_seconds':0,'assignments':0,'source_checks':0,'axis_subsystem_edges':len(edges),'axis_negative_cycle_found':bool(cycle),'axis_negative_cycle_length':len(cycle),'allocation_excluded':False,'whole_job_excluded':False,'remaining_candidates':440,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
