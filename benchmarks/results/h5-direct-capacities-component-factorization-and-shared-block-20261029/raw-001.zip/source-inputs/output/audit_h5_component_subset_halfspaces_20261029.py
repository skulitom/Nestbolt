"""Independent rational polygon-clipping readback of every subset halfspace exclusion."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-separated-component-capacity-20261029';BOUND=BASE/'subset-halfspaces';OUT=BOUND/'audit';JOINT=ROOT/'output/h5-first55-joint-component-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if poly else F(0)
def clipped(poly,axis,above,cut):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[axis]>=cut if above else a[axis]<=cut;inb=b[axis]>=cut if above else b[axis]<=cut
        if ina:out.append(a)
        if ina!=inb:
            t=(cut-a[axis])/(b[axis]-a[axis]);out.append(tuple(a[k]+t*(b[k]-a[k]) for k in [0,1]))
    return out
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BOUND/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(BASE/'audit/checks.json')['passed'];inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(JOINT/'source-inner-rectangles.json').items()}
prior=load(BASE/'all29-separated-bounds.json');rows=load(BOUND/'all29-subset-halfspaces.json');assert len(rows)==len(prior)==29
certificates=removed_count=initial_count=remaining_count=clipping_cases=0;allowed=[]
for row,old in zip(rows,prior):
    assert row['empty_sites']==old['empty_sites'] and row['initial_distributions']==old['remaining_distributions'];groups=old['groups'];possible={tuple(v) for v in row['initial_distributions']};initial_count+=len(possible)
    for cert in row['certificates']:
        selected=cert['groups'];assert selected==sorted(set(selected)) and all(0<=i<len(groups) for i in selected) and {groups[i]['family'] for i in selected}=={'bracket','insert'}
        axis=cert['axis'];above=cert['above'];cut=F(cert['threshold_mm']);assert axis in [0,1] and type(above) is bool and cut%10==0
        support=set()
        for i in selected:
            bits=int(groups[i]['support_hex'],16);support.update(j for j in range(15000) if bits>>j&1)
        available=0
        for j in support:
            y,x=divmod(j,150);lo=F(10*x if axis==0 else 2000+10*y)
            if (lo>=cut if above else lo+10<=cut):available+=100
        values={};coefficients=[F(0)]*len(groups)
        for i in selected:
            g=groups[i];values[str(i)]={}
            for m,limits in g['mode_position_bounds_mm'].items():
                shift=F(limits[axis if above else axis+2]);occupied=F(0)
                for l,b,r,t in inner[g['family']][int(m)]:
                    poly=[(l,b),(r,b),(r,t),(l,t)];poly=[tuple(p[k]+(shift if k==axis else 0) for k in [0,1]) for p in poly];occupied+=area(clipped(poly,axis,above,cut));clipping_cases+=1
                values[str(i)][m]=str(occupied)
            coefficients[i]=min(map(F,values[str(i)].values()))
        assert cert['upper_area_mm2']==available and cert['selected_group_mode_minimum_area_mm2']==values and cert['coefficients_mm2']==[str(v) for v in coefficients]
        removed={v for v in possible if sum(n*c for n,c in zip(v,coefficients))>available};assert removed and cert['distributions_removed']==[list(v) for v in sorted(removed)];possible-=removed;removed_count+=len(removed);certificates+=1
    assert row['remaining_distributions']==[list(v) for v in sorted(possible)] and row['restricted_construction_excluded']==(not possible)
    nb=sum(g['family']=='bracket' for g in groups);ni=len(groups)-nb;expected_subsets=((1<<nb)-1)*((1<<ni)-1)
    assert 0<=row['mixed_subsets_completed']<=expected_subsets and row['halfspaces_examined']>=504*row['mixed_subsets_completed']
    if row['scan_complete']:assert row['mixed_subsets_completed']==expected_subsets and row['halfspaces_examined']==504*expected_subsets
    remaining_count+=len(possible)
    if possible:allowed.append(row['empty_sites'])
checks0=load(BOUND/'checks.json');assert checks0['initial_distributions']==initial_count and checks0['remaining_distributions']==remaining_count and checks0['count_distributions_excluded']==removed_count and checks0['certificates']==certificates
assert checks0['additional_restricted_pairs_excluded']==29-len(allowed) and checks0['scan_complete']==all(r['scan_complete'] for r in rows)
write(OUT/'allowed-empty-site-pairs.json',allowed);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BOUND/n for n in ['plan.json','checks.json','all29-subset-halfspaces.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'initial_count_distributions':initial_count,'remaining_count_distributions':remaining_count,'count_distributions_excluded':removed_count,'necessary_halfspace_certificates_verified':certificates,'independent_exact_polygon_clippings':clipping_cases,'all_recorded_exclusions_independently_verified':True,'unrecorded_halfspace_values_independently_recomputed':False,'new_restricted_site_exclusions':29-len(allowed),'restricted_pairs_remaining':len(allowed),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
