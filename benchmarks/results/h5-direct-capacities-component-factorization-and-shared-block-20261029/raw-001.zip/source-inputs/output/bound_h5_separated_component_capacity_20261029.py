"""Keep each family's continuous components separate in mixed necessary area bounds."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,shutil,time,itertools
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';AXIS=ROOT/'output/h5-first55-local-grid-regions-20261029/component-halfspace-bound';JOINT=ROOT/'output/h5-first55-joint-component-capacity-20261029';OUT=ROOT/'output/h5-first55-separated-component-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(JOINT/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(JOINT/'source-inner-rectangles.json').items()};families=['bracket','insert'];unary=load(PRIOR/'integer-preparation/unary-templates.json');regions={}
for r in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if r['family'] not in families:continue
    key=(r['family'],r['mode'],r['geometry'],r['region']);bits=0
    for y,a,b in r['grid_row_spans']:bits|=((1<<(b-a+1))-1)<<((y-200)*150+a)
    if key not in regions:
        p=[tuple(map(F,v)) for v in unary[r['geometry']]['regions'][r['region']]['hull_vertices']]
        regions[key]={'mask':r['required_empty_mask'],'bits':0,'bounds':[min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)]}
    regions[key]['bits']|=bits
full=(1<<15000)-1;no_left=full^sum(1<<(150*y) for y in range(100));no_right=full^sum(1<<(150*y+149) for y in range(100))
def components(bits):
    result=[]
    while bits:
        c=bits&-bits
        while True:
            h=c|((c&no_left)>>1)|((c&no_right)<<1);new=(h|(h>>150)|(h<<150))&bits
            if c==new:break
            c=new
        result.append(c);bits^=c
    return result
@lru_cache(None)
def mandatory(f,m,axis,above,shift,cut):
    value=F(0)
    for box in inner[f][m]:
        lo,hi=box[axis]+shift,box[axis+2]+shift
        length=max(F(0),hi-max(lo,cut)) if above else max(F(0),min(hi,cut)-lo)
        value+=length*(box[3-axis]-box[1-axis])
    return value
allowed=load(AXIS/'audit/allowed-empty-site-pairs.json');old_axis={tuple(r['empty_sites']):r for r in load(AXIS/'all35-halfspace-bounds.json')};old_conn={tuple(r['empty_sites']):r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json')}
rows=[];all_initial=0;all_remaining=0;total_certs=0;total_halfspaces=0;total_subsets=0;scan_complete=True
for sites in allowed:
    empty=sum(1<<i for i in sites);active={k:r for k,r in regions.items() if not r['mask']&~empty};supports={f:0 for f in families}
    for k,r in active.items():supports[k[0]]|=r['bits']
    groups=[]
    for f in families:
        for fi,bits in enumerate(components(supports[f])):groups.append({'family':f,'family_component':fi,'bits':bits,'ranges':{}})
    bracket_groups=[g for g in groups if g['family']=='bracket'];assert [hex(g['bits']) for g in bracket_groups]==old_conn[tuple(sites)]['components_hex']
    assignments=[]
    for k,r in active.items():
        dest=[i for i,g in enumerate(groups) if g['family']==k[0] and r['bits']&~g['bits']==0];assert len(dest)==1;gi=dest[0];assignments.append([*k,gi]);ranges=groups[gi]['ranges'];m=k[1];old=ranges.get(m);ranges[m]=r['bounds'][:] if old is None else [fun(a,b) for fun,a,b in zip([min,min,max,max],old,r['bounds'])]
    for g in groups:
        f=g['family'];g['lower']=min(sum((b[2]-b[0])*(b[3]-b[1]) for b in inner[f][m]) for m in g['ranges']);g['cap']=min(7 if f=='bracket' else 6,int(F(g['bits'].bit_count()*100)//g['lower']))
        if f=='bracket':g['cap']=min(g['cap'],old_axis[tuple(sites)]['components'][g['family_component']]['capacity_upper_bound'])
    nb=len(bracket_groups);bcounts=[v for v in itertools.product(*(range(g['cap']+1) for g in groups[:nb])) if sum(v)==7];icounts=[v for v in itertools.product(*(range(g['cap']+1) for g in groups[nb:])) if sum(v)==6]
    possible={b+i for b in bcounts for i in icounts};initial=sorted(possible);all_initial+=len(initial);certs=[];subset_count=0;halfspace_count=0;complete=True
    for selected_mask in range(1,1<<len(groups)):
        if time.perf_counter()-started>=58:complete=False;scan_complete=False;break
        selected=[i for i in range(len(groups)) if selected_mask>>i&1];bits=0
        for i in selected:bits|=groups[i]['bits']
        coefficients=[g['lower'] if i in selected else F(0) for i,g in enumerate(groups)];available=bits.bit_count()*100
        removed=sorted(v for v in possible if sum(n*a for n,a in zip(v,coefficients))>available);subset_count+=1;total_subsets+=1
        if removed:certs.append({'kind':'subset_area','groups':selected,'upper_area_mm2':available,'coefficients_mm2':[str(v) for v in coefficients],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
    union=supports['bracket']|supports['insert'];xs=[0]*150;ys=[0]*100;bits=union
    while bits:
        low=bits&-bits;y,x=divmod(low.bit_length()-1,150);xs[x]+=1;ys[y]+=1;bits^=low
    for axis,counts,origin in [(0,xs,0),(1,ys,2000)]:
        below=0
        for index in range(len(counts)+1):
            if time.perf_counter()-started>=58:complete=False;scan_complete=False;break
            cut=F(origin+10*index)
            for above in [False,True]:
                available=(union.bit_count()-below if above else below)*100;values=[{m:mandatory(g['family'],m,axis,above,bounds[axis if above else axis+2],cut) for m,bounds in g['ranges'].items()} for g in groups];coefficients=[min(v.values()) for v in values]
                removed=sorted(v for v in possible if sum(n*a for n,a in zip(v,coefficients))>available);halfspace_count+=1;total_halfspaces+=1
                if removed:certs.append({'kind':'global_halfspace','axis':axis,'above':above,'threshold_mm':str(cut),'upper_area_mm2':available,'per_group_mode_minimum_area_mm2':[{str(m):str(v) for m,v in vals.items()} for vals in values],'coefficients_mm2':[str(v) for v in coefficients],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
            if index<len(counts):below+=counts[index]
        if not complete:break
    total_certs+=len(certs);all_remaining+=len(possible)
    group_records=[{'family':g['family'],'family_component':g['family_component'],'support_hex':hex(g['bits']),'area_upper_mm2':g['bits'].bit_count()*100,'source_area_lower_mm2':str(g['lower']),'capacity':g['cap'],'mode_position_bounds_mm':{str(m):[str(v) for v in b] for m,b in g['ranges'].items()}} for g in groups]
    rows.append({'empty_sites':sites,'groups':group_records,'region_component_assignments':assignments,'initial_distributions':[list(v) for v in initial],'certificates':certs,'remaining_distributions':[list(v) for v in sorted(possible)],'subset_areas_examined':subset_count,'halfspaces_examined':halfspace_count,'scan_complete':complete,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),JOINT/'plan.json',JOINT/'audit/plan.json',JOINT/'audit/checks.json',JOINT/'source-inner-rectangles.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'accessible-area-bound/swept-covers.json',AXIS/'all35-halfspace-bounds.json',AXIS/'audit/allowed-empty-site-pairs.json',PRIOR/'connected-capacity-bound/all105-capacity-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Retain every conservative connected component of each family separately. Enumerate all integer distributions of seven brackets and six inserts within audited component capacities. A necessary area inequality is tested for every subset of these component supports. Global halfspace inequalities retain separate per-component mandatory occupied-area minima over all source modes and unary hull positions. Record the first verified necessary inequality excluding each count distribution. A fixed-site choice is excluded only if every distribution is removed.','preparation_cap_seconds':60,'stop_new_bounds_after_seconds':58,'unprocessed_distributions_retained':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'all29-separated-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'discovery_scan_complete':scan_complete,'site_pairs_examined':len(rows),'initial_distributions':all_initial,'remaining_distributions':all_remaining,'count_distributions_excluded':all_initial-all_remaining,'certificates':total_certs,'subset_area_bounds_examined':total_subsets,'halfspaces_examined':total_halfspaces,'additional_restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
