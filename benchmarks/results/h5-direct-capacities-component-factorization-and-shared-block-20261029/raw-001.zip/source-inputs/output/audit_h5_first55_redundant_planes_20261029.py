"""Verify every proposed deletion with independent exact corner bounds and copy-order paths."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
import json, shutil, time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';PRE=BASE/'redundant-plane-preflight';OUT=PRE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(PRE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
assert load(BASE/'model-audit-v2/checks.json')['passed']
mapping=load(BASE/'model/mapping.json');templates=load(BASE/'integer-templates.json');certs=load(PRE/'certificates.json');owners=mapping['owners']
assert len(templates)==len(certs)==95
ordered={(r['owners'][0],r['owners'][1]) for r in mapping['symmetry_constraints']}
same_pairs=0;drop_ids=[];kept_ids=[];cached=set()
for pair in mapping['pairs']:
    ia,ib=pair['owners'];a,b=owners[ia],owners[ib];same=a['identity'][0]==b['identity'][0]
    if same:
        peers=sorted((o for o in owners if o['identity'][0]==a['identity'][0]),key=lambda o:o['identity'][1]);indices=[o['owner'] for o in peers];start,end=indices.index(ia),indices.index(ib)
        assert start<end and all((x,y) in ordered for x,y in zip(indices[start:end],indices[start+1:end+1]))
        same_pairs+=1
    for region in pair['regions']:
        ti,ri=region['template'],region['region'];template=templates[ti];cert=certs[ti];ga,gb=template['geometries'];assert region['geometries']==[ga,gb]==cert['geometries']
        am=[m for m in a['modes'] if m['normalized_geometry']==ga];bm=[m for m in b['modes'] if m['normalized_geometry']==gb];assert am and bm
        domains=[]
        for ma,mb in product(am,bm):
            ab,bb=ma['integer_lower_left_bounds'],mb['integer_lower_left_bounds'];d=[[bb[k][0]-ab[k][1],bb[k][1]-ab[k][0]] for k in [0,1]]
            if same:d[0][0]=max(d[0][0],0)
            domains.append(d)
        assert all(d==cert['integer_relative_domain'] for d in domains) and cert['same_family_x_order_used']==same
        pc=cert['regions'][ri];assert pc['region']==ri and len(pc['planes'])==len(region['plane_constraints'])==len(template['regions'][ri]['planes'])
        for pi,(plane,saved,ci) in enumerate(zip(template['regions'][ri]['planes'],pc['planes'],region['plane_constraints'])):
            assert saved['plane']==pi and saved['upper']==plane['upper']
            corners=list(product(*domains[0]));maximum=max(sum(c*x for c,x in zip(plane['coefficients'],corner)) for corner in corners)
            assert maximum==saved['maximum_domain_activity'] and saved['redundant']==(maximum<=plane['upper'])
            (drop_ids if saved['redundant'] else kept_ids).append(ci);cached.add((ti,ri,pi))
assert len(drop_ids)==len(set(drop_ids))==144938 and len(kept_ids)==len(set(kept_ids))==170054 and len(cached)==4965
assert not set(drop_ids)&set(kept_ids)
write(OUT/'verified-deletions.json',sorted(drop_ids))
inputs=[Path(__file__),PRE/'plan.json',PRE/'checks.json',PRE/'certificates.json',BASE/'model/mapping.json',BASE/'model-audit-v2/plan.json',BASE/'model-audit-v2/checks.json',BASE/'integer-templates.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'cached_integer_plane_bounds_verified':len(cached),'expanded_redundant_constraints_verified':len(drop_ids),'expanded_required_constraints_retained':len(kept_ids),'same_family_transitive_order_paths_verified':same_pairs,'all_mode_alias_bounds_verified':True,'conditional_stock_and_both_owner_mode_coupling_basis_verified':True,'all93_modes_and88690_region_selectors_retained':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
