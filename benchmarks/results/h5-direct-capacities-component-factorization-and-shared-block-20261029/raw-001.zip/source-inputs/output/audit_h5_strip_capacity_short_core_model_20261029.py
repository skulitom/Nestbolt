"""Audit the unchanged parent and every strip/capacity extension field."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_strip_capacity_short_core_reader_20261029 import inspect,violations
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-short-core-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit';OLD=ROOT/'output/h5-coarse-short-core-20261029';STRIP=OLD/'cog-strip-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,MODEL,BASE/'preflight/audit',OLD/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'preflight/audit/checks.json')['passed'] and load(OLD/'model-audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());parent=cp_model_pb2.CpModelProto();parent.ParseFromString((OLD/'model/model.pb').read_bytes());mp=load(MODEL/'mapping.json');pos=load(MODEL/'positive-control-assignment.json');neg=load(MODEL/'negative-assignment.json')
checked=inspect(p,parent,mp,load(OLD/'model/mapping.json'),load(STRIP/'strips.json'),load(BASE/'preflight/bounds.json'),pos,neg,load(OLD/'model/positive-control-assignment.json'),load(OLD/'model/negative-assignment.json'),load(MODEL/'extra-hints.json'))
positive=violations(p,pos);assert sorted(r['constraint'] for r in positive['failed_constraints'])==sorted(mp['control_disabled_mandatory_constraints']) and positive['orthogonal_piece_collisions']==0
relaxed=violations(p,pos,mp['control_disabled_mandatory_constraints']);assert not relaxed['failed_constraints'];negative=violations(p,neg);assert len(negative['failed_constraints'])==37 and negative['orthogonal_piece_collisions']==436 and [c['passed'] for c in negative['cumulative_checks']]==[False,False]
controls=load(BASE/'preflight/audit/controls.json');assert [c['peak_demand'] for c in positive['cumulative_checks']]==[controls[0]['peak_sum_heights_um'],controls[0]['peak_sum_widths_um']] and [c['peak_demand'] for c in negative['cumulative_checks']]==[controls[1]['peak_sum_heights_um'],controls[1]['peak_sum_widths_um']]
write(OUT/'controls.json',{'positive_full_target':positive,'positive_only_two_missing_requirements_disabled':relaxed,'negative_full_target':negative})
inputs=[Path(__file__),ROOT/'output/h5_strip_capacity_short_core_reader_20261029.py',ROOT/'output/h5_coarse_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',BASE/'preflight/audit/plan.json',OLD/'model-audit/plan.json']+[MODEL/n for n in ['model.pb','model.pbtxt','mapping.json','built.json','positive-control-assignment.json','negative-assignment.json','extra-hints.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-start,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'positive_control_fails_only_two_missing_original_requirements':True,'positive_control_with_only_missing_requirements_disabled_passes_all_constraints':True,'negative_failed_constraints':37,'negative_rectangle_collisions':436,'capacity_control_peaks_match_independent_geometric_audit':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
