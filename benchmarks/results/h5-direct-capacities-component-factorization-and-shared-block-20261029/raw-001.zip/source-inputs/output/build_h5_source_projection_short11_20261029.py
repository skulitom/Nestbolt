"""Derive the eleven-mandatory-owner model without restricting any active pose."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-source-projection-short-core-20261029';BASE=ROOT/'output/h5-source-projection-short11-20261029';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'preflight/checks.json')['passed'] and load(OLD/'model-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();model=cp_model.CpModel();assert model.proto.parse_text_format((OLD/'model-v3/model.pbtxt').read_text()) and model.validate()=='';assert model.export_to_file(str(OUT/'parent-copy.pb')) and digest(OUT/'parent-copy.pb')==digest(OLD/'model-v3/model.pb')
mp=load(OLD/'model-v3/mapping.json');inv=load(BASE/'preflight/inventory.json');pos=load(OLD/'model-v3/positive-control-assignment.json');neg=load(OLD/'model-v3/negative-assignment.json');changed=[];presences=[]
for item in mp['items']:
    if item['index'] not in inv['inactive_short_owners']:continue
    assert item['family']=='insert';ct=model.proto.constraints[item['mandatory']];assert list(ct.linear.vars)==[item['presence']] and list(ct.linear.coeffs)==[1] and list(ct.linear.domain)==[1,1] and not ct.enforcement_literal;ct.linear.domain.clear();ct.linear.domain.extend([0,0]);changed.append(item['mandatory']);presences.append(item['presence']);pos[item['presence']]=neg[item['presence']]=0
hint_changes=[]
for i,v in enumerate(list(model.proto.solution_hint.vars)):
    if v in presences and model.proto.solution_hint.values[i]!=0:hint_changes.append({'index':i,'variable':v,'before':model.proto.solution_hint.values[i],'after':0});model.proto.solution_hint.values[i]=0
assert changed==[112,126] and model.validate()=='';assert mp.pop('mandatory_first53_identities')+inv['moved_originals']==inv['mandatory_first55_identities'];mp['mandatory_first55_identities']=inv['mandatory_first55_identities'];mp['short11_identities']=inv['short11_identities'];mp['inactive_short_owners']=inv['inactive_short_owners'];mp['inactive_short_identities']=inv['moved_originals'];mp['control_disabled_mandatory_constraints']=[110]
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mp);write(OUT/'positive-control-assignment.json',pos);write(OUT/'negative-assignment.json',neg);write(OUT/'hint-changes.json',hint_changes)
inputs=[Path(__file__),BASE/'plan.json',BASE/'preflight/plan.json',BASE/'preflight/inventory.json',OLD/'model-audit/plan.json',OLD/'model-audit/checks.json']+[OLD/'model-v3'/n for n in ['plan.json','model.pb','model.pbtxt','mapping.json','positive-control-assignment.json','negative-assignment.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0});write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'changed_constraints':changed,'changed_presence_variables':presences,'changed_hints':len(hint_changes),'short_required_originals':11,'first_required_originals':55,'validation':model.validate(),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
