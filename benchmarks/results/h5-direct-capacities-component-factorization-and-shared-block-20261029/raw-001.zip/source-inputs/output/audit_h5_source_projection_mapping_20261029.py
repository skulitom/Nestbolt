"""Independently check source rectangles, floor domains and simultaneous reference links."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';PRE=BASE/'preflight-v2';OUT=PRE/'audit';LEGACY=ROOT/'output/h5-insert-order-projection-20261028';COARSE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';SRC=ROOT/'output/h5-rotation-independent-geometry-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def segments_intersect(a,b,c,d):return all(max(min(a[k],b[k]),min(c[k],d[k]))<=min(max(a[k],b[k]),max(c[k],d[k])) for k in [0,1]) and cross(a,b,c)*cross(a,b,d)<=0 and cross(c,d,a)*cross(c,d,b)<=0
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'preflight/legacy-replay',LEGACY,COARSE/'audit',SRC/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'preflight/legacy-replay/checks.json')['passed'] and load(COARSE/'audit/checks.json')['passed'];profiles={r['variant']:r for r in load(LEGACY/'profiles.json')};modes=load(COARSE/'modes.json');saved=load(PRE/'mode-map.json');assert len(saved)==13;bykey={(r['family'],r['mode']):r for r in saved};stock=[F(str(v))*1000 for v in load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json')['source_stock']];edges=rects=0
for mode in modes:
    variant=mode['mode'] if mode['family']=='bracket' else [9,8,9,8][mode['quarter']];p=profiles[variant];r=bykey[mode['family'],mode['mode']];assert r['prior_variant']==variant and r['reference_offset_um']==p['reference_x_um'] and r['prior_reference_domain_um']==p['reference_x_domain_um'] and r['prior_anchor_domain_um']==p['anchor_domain_um'] and r['insert_width_um']==(p['insert_width_um'] or 0) and r['quarter']==mode['quarter'] and r['mirrored']==mode['mirrored']
    ring=[(F(str(x))*1000,F(str(y))*1000) for x,y in mode['source_outer']]
    for rect in p['source_rectangles_um']:
        a,b,c,d=rect;vv=[(F(a-1),F(b-1)),(F(c+1),F(b-1)),(F(c+1),F(d+1)),(F(a-1),F(d+1))];center=(F(a+c,2),F(b+d,2));winding=0
        for u,v in zip(ring,ring[1:]+ring[:1]):
            if u[1]<=center[1]<v[1] and cross(u,v,center)>0:winding+=1
            if v[1]<=center[1]<u[1] and cross(u,v,center)<0:winding-=1
            for x,y in zip(vv,vv[1:]+vv[:1]):assert not segments_intersect(u,v,x,y);edges+=1
        assert abs(winding)==1;rects+=1
    true=[stock[k]-min(v[k] for v in ring) for k in [0,1]]+[stock[k+2]-max(v[k] for v in ring) for k in [0,1]];domain=r['source_floor_anchor_domain_um'];assert all(F(a)<=b<F(a+1) for a,b in zip(domain,true)) and all(p['anchor_domain_um'][k]<=domain[k] for k in [0,1]) and all(domain[k]<=p['anchor_domain_um'][k] for k in [2,3])
job=load(JOB);cog=next(p for p in job['parts'] if p['id']=='cog');original=load(SRC/'original-cog-proof.json');oldcenter=list(map(F,original['center']));newcenter=list(map(F,load(GEOM/'cog-core.json')['source_center_mm']));assert [[F(x)-oldcenter[0],F(y)-oldcenter[1]] for x,y in cog['geometry'][0]['outer']]==[[F(*v) for v in row] for row in original['centered_vertices_rational']]
link=load(PRE/'reference-link.json');shift=sum(((x-y)*1000)**2 for x,y in zip(oldcenter,newcenter));assert shift==F(link['exact_center_change_norm_squared_um2'])<F(link['source_center_change_norm_less_than_um'])**2 and link['coordinate_unit_um']==100 and link['maximum_nearest_coordinate_error_um']==50 and link['floor_loss_less_than_um']==1
assert F(link['lower_delta_um'])<=-50-1-F('0.001') and F(link['upper_delta_um'])>=50+F('0.001');p=profiles[12];r=bykey['cog',None];assert r['reference_offset_um']==0 and r['prior_variant']==12 and r['prior_reference_domain_um']==p['reference_x_domain_um'];radius=original['all_angle_stock_support_radius_units1000'];true=[stock[k]+radius for k in [0,1]]+[stock[k+2]-radius for k in [0,1]];domain=r['source_floor_anchor_domain_um'];assert all(F(a)<=b<F(a+1) for a,b in zip(domain,true)) and all(p['anchor_domain_um'][k]<=domain[k] for k in [0,1]) and all(domain[k]<=p['anchor_domain_um'][k] for k in [2,3])
assert load(PRE/'pair-distances.json')==load(LEGACY/'pair-distances.json');dist={tuple(v['profiles']):v['minimum_reference_distance_um'] for v in load(PRE/'pair-distances.json')};assert len(dist)==121
capacity=load(PRE/'insert-capacity.json');triple=load(LEGACY/'triple-insert-proof.json');assert capacity['capacity']==2 and capacity['width_by_prior_variant']==triple['insert_widths_um'] and capacity['three_minimum_heights_um']==3*capacity['minimum_insert_height_um']>capacity['legacy_relaxed_stock_height_um']==triple['relaxed_stock_height_um']
controls=[];totalpairs=slabs=0
for name,count in [('positive',11),('negative',13)]:
    source=load(GEOM/f'{name}-source{count}.json');rows=load(PRE/f'{name}-references{count}.json');assert len(rows)==len(source)==count
    for src,row in zip(source,rows):
        assert row['identity']==[src['part_id'],src['copy_index']];t=src['transform'];family=src['part_id']
        if family=='cog':
            c,s=F(str(math.cos(t['rotation_radians']))),F(str(math.sin(t['rotation_radians'])));a=(c*oldcenter[0]-s*oldcenter[1]+F(str(t['translation'][0])))*1000;z=(c*newcenter[0]-s*newcenter[1]+F(str(t['translation'][0])))*1000;m=bykey[family,None]
        else:
            q=round(t['rotation_radians']/(math.pi/2))%4;mode=next(v for v in modes if v['family']==family and v['quarter']==q and v['mirrored']==t['mirrored']);a=(F(str(t['translation'][0]))-F(str(mode['source_translation_offset'][0])))*1000;z=a;m=bykey[family,mode['mode']]
        x=row['coarse_x_grid_units'];reference=row['reference_x_um'];assert abs(100*x-z)<=50 and F(reference-m['reference_offset_um'])<=a<F(reference-m['reference_offset_um']+1) and m['prior_reference_domain_um'][0]<=reference<=m['prior_reference_domain_um'][1];assert row['prior_variant']==m['prior_variant'] and row['insert_width_um']==m['insert_width_um'] and row['link_delta_um']==reference-100*x-m['reference_offset_um'] and link['lower_delta_um']<=row['link_delta_um']<=link['upper_delta_um']
    bad=0;slack=10**9
    for a,b in combinations(rows,2):
        if a['reference_x_um']>b['reference_x_um']:a,b=b,a
        s=b['reference_x_um']-a['reference_x_um']-dist[a['prior_variant'],b['prior_variant']];bad+=s<0;slack=min(slack,s);totalpairs+=1
    intervals=[(r['reference_x_um'],r['reference_x_um']+r['insert_width_um']) for r in rows if r['insert_width_um']];points=sorted({x for r in intervals for x in r});peak=0
    for a,b in zip(points,points[1:]):t=F(a+b,2);peak=max(peak,sum(lo<t<hi for lo,hi in intervals));slabs+=1
    controls.append({'name':name,'originals':count,'directed_pair_failures':bad,'minimum_pair_slack_um':slack,'maximum_insert_interval_overlap':peak})
assert controls==load(PRE/'controls.json') and controls[0]['directed_pair_failures']==0 and controls[0]['maximum_insert_interval_overlap']<=2 and controls[1]['directed_pair_failures']>0 and controls[1]['maximum_insert_interval_overlap']>2
prefixlinks=0
for row in load(ROOT/'output/h5-short13-source-sliding-20261028/prefix-bank.json'):
    for xy in row['anchors']:
        if xy is not None:a=F(str(xy[0]))*1000;d=math.floor(a)-100*round(a/100);assert link['lower_delta_um']<=d<=link['upper_delta_um'];prefixlinks+=1
write(OUT/'controls.json',controls);inputs=[Path(__file__),BASE/'plan.json',BASE/'preflight/failure.json',BASE/'preflight/legacy-replay/plan.json']+list(PRE.glob('*.json'));write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'mode_mappings_verified':13,'all8_bracket_and4_insert_modes_verified':True,'source_rectangles_expanded1um_verified':rects,'exact_source_rectangle_edge_pair_checks':edges,'full_source_floor_stock_domains_verified':13,'coarse_and_legacy_reference_link_verified':True,'link_delta_um':[link['lower_delta_um'],link['upper_delta_um']],'source_controls_pair_checks':totalpairs,'insert_control_midpoint_slabs':slabs,'legacy_prefix_anchor_links_verified':prefixlinks,'unchanged121_directed_distances_verified':True,'insert_interval_capacity2_verified':True,'no_legacy_reference_symmetry_required':True,'missing_historical_plan_failure_preserved':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
