"""Audit convex-combination equalities and original-source safety of rounded vertices."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, math, shutil, time
import numpy as np
from scipy.sparse import csc_matrix

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
PRE = SOURCE / 'relative-free-region-preflight'
BASE = ROOT / 'output/h5-short11-region-convex-hull-model-20261029'
OUT = BASE / 'audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for name, expected in load(BASE / 'plan.json')['inputs'].items():
    assert digest(ROOT / name) == expected, name
groups, mapping = load(PRE / 'groups.json'), load(BASE / 'mapping.json')
certificates = load(PRE / 'audit/support-certificates.json')
world = load(SOURCE / 'world-pieces.json')
model = np.load(BASE / 'model.npz')
data, indices, indptr, shape, lower, upper, bounds, objective, integrality = [model[k] for k in ['data', 'indices', 'indptr', 'shape', 'lower', 'upper', 'bounds', 'c', 'integrality']]
matrix = csc_matrix((data, indices, indptr), shape=tuple(shape)).tocsr()
assert matrix.shape == (860, 2990) and matrix.nnz == 8423
assert np.array_equal(bounds[:22], np.load(SOURCE / 'model.npz')['bounds'][:22])
assert np.array_equal(bounds[22:], np.tile([0., 1.], (2968, 1)))
assert np.array_equal(integrality, np.r_[np.zeros(22), np.ones(695), np.zeros(2273)])
assert np.array_equal(objective, np.zeros(2990))
assert load(BASE / 'inventory.json') == load(SOURCE / 'inventory.json')
assert load(BASE / 'seed-source11.json') == load(SOURCE / 'seed-source11.json')
assert len(groups) == len(mapping) == len(certificates) == 55
used_rows, selectors, weights, pairs = set(), set(), set(), set()
source_checks = 0
minimum_gap = math.inf
rounding_error = F(0)

def check_row(index, coefficients, value):
    assert index not in used_rows
    used_rows.add(index)
    start, end = matrix.indptr[index:index+2]
    actual = dict(zip(map(int, matrix.indices[start:end]), map(float, matrix.data[start:end])))
    assert actual == {i: float(v) for i, v in coefficients.items() if v != 0}
    assert lower[index] == upper[index] == value

for group, record, certificate in zip(groups, mapping, certificates):
    ia, ib = group['owners']
    assert record['owners'] == certificate['owners'] == [ia, ib] and (ia, ib) not in pairs
    pairs.add((ia, ib))
    assert len(group['regions']) == len(record['regions'])
    coordinate_rows = [{2*ia: 1., 2*ib: -1.}, {2*ia+1: 1., 2*ib+1: -1.}]
    group_selectors = []
    rounded_regions = []
    for region_index, (vertices, region) in enumerate(zip(group['regions'], record['regions'])):
        assert region['region'] == region_index
        assert region['vertices'] == [[round(v, 9) for v in point] for point in vertices]
        selector = region['selector']
        assert 22 <= selector < 717 and selector not in selectors
        selectors.add(selector)
        group_selectors.append(selector)
        assert len(region['lambdas']) == len(vertices) == len(region['vertices'])
        for column, rounded, original in zip(region['lambdas'], region['vertices'], vertices):
            assert 717 <= column < 2990 and column not in weights
            weights.add(column)
            for axis in [0, 1]:
                coordinate_rows[axis][column] = rounded[axis]
                rounding_error = max(rounding_error, abs(F(rounded[axis])-F(original[axis])))
        check_row(region['lambda_sum_row'], {selector: -1., **{i: 1. for i in region['lambdas']}}, 0.)
        rounded_regions.append([tuple(map(F, p)) for p in region['vertices']])
    check_row(record['one_of_row'], {i: 1. for i in group_selectors}, 1.)
    assert len(record['coordinate_rows']) == 2
    for row_index, coefficients in zip(record['coordinate_rows'], coordinate_rows):
        check_row(row_index, coefficients, 0.)
    expected_proofs = {(r, ai, bi) for r in range(len(record['regions']))
                       for ai in range(len(world[ia]['pieces'])) for bi in range(len(world[ib]['pieces']))}
    seen_proofs = set()
    for region_index, ai, bi, nx, ny in certificate['proofs']:
        key = (region_index, ai, bi)
        assert key in expected_proofs and key not in seen_proofs
        seen_proofs.add(key)
        nx, ny = F(nx), F(ny)
        A = [tuple(map(F, p)) for p in world[ia]['pieces'][ai]]
        B = [tuple(map(F, p)) for p in world[ib]['pieces'][bi]]
        support = min(x*nx+y*ny for x, y in rounded_regions[region_index])+min(x*nx+y*ny for x, y in B)-max(x*nx+y*ny for x, y in A)
        norm2 = nx*nx+ny*ny
        assert support > 0 and support*support >= F('.225')**2*norm2
        minimum_gap = min(minimum_gap, float(support)/math.sqrt(float(norm2)))
        source_checks += 1
    assert seen_proofs == expected_proofs
assert used_rows == set(range(860)) and selectors == set(range(22, 717)) and weights == set(range(717, 2990))
assert pairs == {(a, b) for a in range(11) for b in range(a+1, 11)}
assert not np.any((np.abs(data) > 0) & (np.abs(data) <= 1e-9))
inputs = [Path(__file__), BASE / 'plan.json', BASE / 'checks.json', BASE / 'model.npz', BASE / 'mapping.json',
          BASE / 'seed-source11.json', BASE / 'inventory.json', PRE / 'groups.json', PRE / 'audit/plan.json',
          PRE / 'audit/checks.json', PRE / 'audit/support-certificates.json', SOURCE / 'world-pieces.json',
          SOURCE / 'audit/plan.json', SOURCE / 'audit/checks.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'original_pairs': len(pairs),
          'binary_region_selectors': len(selectors), 'continuous_vertex_weights': len(weights),
          'all860_rows_and2990_variables_verified': True, 'exact_rounded_region_support_proofs': source_checks,
          'minimum_certified_source_gap_mm': minimum_gap, 'maximum_vertex_rounding_mm': float(rounding_error),
          'nonnegative_weights_sum_to_selected_region': True, 'relative_translation_equals_convex_combination': True,
          'all22_stock_domains_unchanged': True, 'all11_short_and55_first_identities_unchanged': True,
          'deactivation_constants': 0, 'tiny_coefficients': 0, 'zero_objective_verified': True,
          'model_sha256': digest(BASE / 'model.npz'), 'negative_result_cannot_exclude_allocation': True,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
