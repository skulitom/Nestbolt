"""Independent geometry, exact domain/projection, coverage and sparse-model audit."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json, math, shutil, time
import numpy as np
from scipy.sparse import csc_matrix

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
OUT = BASE / 'audit'
PART = ROOT / 'output/h5-short11-cycle-guided-axis-choices-20261029/core-teeth-partition-preflight'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert not OUT.exists()
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for name, expected in load(BASE / 'plan.json')['inputs'].items():
    assert digest(ROOT / name) == expected, name
partition_audit = load(PART / 'audit/checks.json')
assert partition_audit['passed'] and partition_audit['remaining_boundary_equals_all80_source_edges']
job = load(JOB)
parts = {p['id']: p for p in job['parts']}
canonical, world, groups, seed = [load(BASE / n) for n in ['canonical-pieces.json', 'world-pieces.json', 'groups.json', 'seed-source11.json']]
partition = load(PART / 'partition.json')
source_cog = parts['cog']['geometry'][0]['outer']
assert canonical['cog'] == [[source_cog[i] for i in p['source_vertex_indices']] for p in partition['pieces']]
assert parts['bracket']['geometry'][0]['outer'] == [[0, 0], [300, 0], [300, 75], [100, 75], [100, 250], [0, 250]]
assert canonical['bracket'] == [[[0, 0], [300, 0], [300, 75], [0, 75]], [[0, 75], [100, 75], [100, 250], [0, 250]]]
assert canonical['insert'] == [parts['insert']['geometry'][0]['outer']]
inventory = load(BASE / 'inventory.json')
all_ids = {(p['id'], i) for p in job['parts'] for i in range(p['quantity'])}
short = list(map(tuple, inventory['short11_identities']))
first = list(map(tuple, inventory['mandatory_first55_identities']))
assert len(short) == len(set(short)) == 11 and len(first) == len(set(first)) == 55
assert not set(short) & set(first) and set(short+first) == all_ids
assert {tuple(p['identity']) for p in world} == set(short)
assert [(p['part_id'], p['copy_index']) for p in seed] == [tuple(p['identity']) for p in world]
assert all(p['sheet_id'] == 'sheet-1' for p in seed)
model = np.load(BASE / 'model.npz')
data, indices, indptr, shape, lower, upper, bounds, objective, integrality = [model[k] for k in ['data', 'indices', 'indptr', 'shape', 'lower', 'upper', 'bounds', 'c', 'integrality']]
matrix = csc_matrix((data, indices, indptr), shape=tuple(shape)).tocsr()
assert matrix.shape == (16193, 15248) and matrix.nnz == 88704
assert len(bounds) == 15248 and len(lower) == len(upper) == 16193
assert np.array_equal(objective, np.zeros(15248))
assert np.array_equal(integrality, np.r_[np.zeros(22), np.ones(15226)])
assert np.array_equal(bounds[22:], np.tile([0., 1.], (15226, 1)))
stock = list(map(F, load(STOCK)['source_stock']))
pose_error = F(0)
minimum_stock = None
for owner, (row, posed) in enumerate(zip(seed, world)):
    assert posed['owner'] == owner
    transform = row['transform']
    c, s = F(math.cos(transform['rotation_radians'])), F(math.sin(transform['rotation_radians']))
    mirror = -1 if transform['mirrored'] else 1
    tx, ty = map(F, transform['translation'])
    canonical_arrays = [parts[row['part_id']]['geometry'][0]['outer']] + canonical[row['part_id']]
    posed_arrays = [posed['outline']] + posed['pieces']
    assert len(canonical_arrays) == len(posed_arrays)
    for original, transformed in zip(canonical_arrays, posed_arrays):
        assert len(original) == len(transformed)
        for (x, y), (a, b) in zip(original, transformed):
            x, y, a, b = map(F, [x, y, a, b])
            pose_error = max(pose_error, abs(mirror*x*c-y*s+tx-a), abs(mirror*x*s+y*c+ty-b))
    ox, oy = zip(*posed['outline'])
    limits = list(map(F, [min(ox), min(oy), max(ox), max(oy)]))
    assert limits == list(map(F, posed['bounds']))
    lx, ux = map(F, bounds[2*owner])
    ly, uy = map(F, bounds[2*owner+1])
    clearances = [limits[0]+lx-stock[0], limits[1]+ly-stock[1], stock[2]-limits[2]-ux, stock[3]-limits[3]-uy]
    value = min(clearances)
    minimum_stock = value if minimum_stock is None else min(minimum_stock, value)
assert pose_error < F('0.000000000002') and minimum_stock > F('.024999999998')

def row_coefficients(index):
    start, end = matrix.indptr[index:index+2]
    return dict(zip(map(int, matrix.indices[start:end]), map(float, matrix.data[start:end])))

def check_row(index, coefficients, lo, hi):
    assert index not in used_rows
    used_rows.add(index)
    assert row_coefficients(index) == {i: float(v) for i, v in coefficients.items() if v != 0}
    assert lower[index] == lo and upper[index] == hi

expected_pairs = {(a['owner'], b['owner'], ai, bi) for a, b in combinations(world, 2)
                  for ai in range(len(a['pieces'])) for bi in range(len(b['pieces']))}
seen_pairs, used_rows, used_selectors = set(), set(), set()
exact_projection_checks = exact_domain_checks = reference_checks = 0
minimum_active_margin = None
minimum_inactive_slack = None
axis_deviation = 0.
for group in groups:
    ia, ib = group['owners']
    pa, pb = group['pieces']
    key = (ia, ib, pa, pb)
    assert key in expected_pairs and key not in seen_pairs
    seen_pairs.add(key)
    A, B = world[ia]['pieces'][pa], world[ib]['pieces'][pb]
    variable_indices = [2*ia, 2*ia+1, 2*ib, 2*ib+1]
    assert group['variable_indices'] == variable_indices
    expected_refs = {(side, edge, sign) for side, vertices in enumerate([A, B]) for edge in range(len(vertices)) for sign in [1, -1]}
    actual_refs = set()
    used_axes = set()
    for side, edge, sign, axis_index in group['edge_axis_references']:
        reference = (side, edge, sign)
        assert reference in expected_refs and reference not in actual_refs
        actual_refs.add(reference)
        used_axes.add(axis_index)
        vertices = [A, B][side]
        p, q = vertices[edge], vertices[(edge+1) % len(vertices)]
        dx, dy = q[0]-p[0], q[1]-p[1]
        length = math.hypot(dx, dy)
        raw = [-dy/length*sign, dx/length*sign]
        rounded = [round(v, 12) for v in raw]
        norm = math.hypot(*rounded)
        axis = group['variants'][axis_index]['normal']
        assert axis == [v/norm for v in rounded]
        axis_deviation = max(axis_deviation, *(abs(x-y) for x, y in zip(raw, axis)))
        reference_checks += 1
    assert actual_refs == expected_refs and used_axes == set(range(len(group['variants'])))
    possible, guaranteed = [], []
    selectors = []
    for axis_index, variant in enumerate(group['variants']):
        nx, ny = map(F, variant['normal'])
        coeff = [nx, ny, -nx, -ny]
        norm2 = nx*nx+ny*ny
        assert abs(norm2-1) < F('0.000000000001')
        support = min(F(x)*nx+F(y)*ny for x, y in B)-max(F(x)*nx+F(y)*ny for x, y in A)
        rhs = F(variant['rhs'])
        # Extra 1e-7 mm absorbs support arithmetic and sparse row rounding.
        assert support-rhs > 0 and (support-rhs)**2 > F('.225')**2*norm2
        exact_projection_checks += 1
        domain = [[F(v) for v in bounds[i]] for i in variable_indices]
        minimum = sum(c*d[0 if c >= 0 else 1] for c, d in zip(coeff, domain))
        maximum = sum(c*d[1 if c >= 0 else 0] for c, d in zip(coeff, domain))
        assert abs(minimum-F(variant['domain_min'])) < F('0.00000000001')
        assert abs(maximum-F(variant['domain_max'])) < F('0.00000000001')
        classification = variant['classification']
        if classification == 'guaranteed':
            assert maximum < rhs
            guaranteed.append(axis_index)
        elif classification == 'impossible':
            assert minimum > rhs
        else:
            assert classification == 'possible'
            possible.append(axis_index)
        exact_domain_checks += 1
        if group['guaranteed_axis'] is not None or classification != 'possible':
            assert not any(k in variant for k in ['row', 'M', 'selector'])
            continue
        values = dict(zip(variable_indices, map(float, coeff)))
        M = variant['M']
        if len(group['possible_axes']) > 1:
            selector = variant['selector']
            assert selector not in used_selectors and 22 <= selector < len(bounds)
            used_selectors.add(selector)
            selectors.append(selector)
            values[selector] = M
            effective_upper = float(variant['rhs']+M)
            slack = F(effective_upper)-maximum
            assert slack > 0
            minimum_inactive_slack = slack if minimum_inactive_slack is None else min(minimum_inactive_slack, slack)
            effective_rhs = F(effective_upper)-F(M)
        else:
            assert variant['selector'] is None and M == 0
            effective_upper = variant['rhs']
            effective_rhs = rhs
        margin = support-effective_rhs
        assert margin > 0 and margin*margin > F('.225')**2*norm2
        minimum_active_margin = margin if minimum_active_margin is None else min(minimum_active_margin, margin)
        check_row(variant['row'], values, -np.inf, effective_upper)
    assert possible == group['possible_axes']
    assert group['guaranteed_axis'] == (guaranteed[0] if guaranteed else None)
    if selectors:
        check_row(group['one_of_row'], {i: 1. for i in selectors}, 1., 1.)
    else:
        assert 'one_of_row' not in group
assert seen_pairs == expected_pairs and len(seen_pairs) == 1115
assert used_rows == set(range(len(lower))) and used_selectors == set(range(22, len(bounds)))
assert axis_deviation < 1e-12
inputs = [Path(__file__), JOB, STOCK, PART / 'audit/plan.json', PART / 'audit/checks.json', PART / 'partition.json',
          BASE / 'plan.json', BASE / 'checks.json', BASE / 'model.npz', BASE / 'canonical-pieces.json',
          BASE / 'world-pieces.json', BASE / 'groups.json', BASE / 'seed-source11.json', BASE / 'inventory.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'original_source_identities': 11,
          'mandatory_first_sheet_identities': 55, 'partition_pieces': 56, 'piece_pairs_verified': len(seen_pairs),
          'source_edge_sign_references_verified': reference_checks, 'exact_projection_checks': exact_projection_checks,
          'exact_domain_classifications_verified': exact_domain_checks, 'matrix_rows_verified': len(used_rows),
          'binary_selectors_verified': len(used_selectors), 'minimum_inactive_slack_mm': float(minimum_inactive_slack),
          'minimum_active_projected_gap_mm': float(minimum_active_margin), 'maximum_axis_rounding_deviation': axis_deviation,
          'maximum_exact_pose_rounding_error_mm': float(pose_error), 'minimum_stock_clearance_mm': float(minimum_stock),
          'zero_objective_verified': True, 'no_seed_directions_retained_as_fixed_requirements': True,
          'fixed_modes_and_rounded_directions_restrict_negative_result': True, 'allocation_excluded': False,
          'model_sha256': digest(BASE / 'model.npz'), 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
