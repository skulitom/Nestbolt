"""Independent full audit of source-mode choices, region coupling, stock and symmetry."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, shutil, time
import numpy as np
from scipy.sparse import csc_matrix

ROOT = Path(__file__).resolve().parents[1]
MODES = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
PRE = MODES / 'pair-region-preflight'
BASE = ROOT / 'output/h5-short11-all-mode-region-model-20261029'
OUT = BASE / 'audit'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for folder in [BASE, MODES / 'audit', PRE / 'audit']:
    for name, expected in load(folder / 'plan.json')['inputs'].items():
        assert digest(ROOT / name) == expected, name
assert load(MODES / 'audit/checks.json')['passed'] and load(PRE / 'audit/checks.json')['passed']
family_modes, library, instances = [load(MODES / n) for n in ['family-modes.json', 'geometry-library.json', 'instances.json']]
templates, expected_pairs = [load(PRE / n) for n in ['templates.json', 'owner-pairs.json']]
mapping = load(BASE / 'mapping.json')
owners, pairs = mapping['owners'], mapping['pairs']
job, stock = load(JOB), load(STOCK)['source_stock']
parts = {p['id']: p for p in job['parts']}
model = np.load(BASE / 'model.npz')
data, indices, indptr, shape, lower, upper, bounds, objective, integrality = [model[k] for k in ['data', 'indices', 'indptr', 'shape', 'lower', 'upper', 'bounds', 'c', 'integrality']]
matrix = csc_matrix((data, indices, indptr), shape=tuple(shape)).tocsr()
assert matrix.shape == (8260, 33208) and matrix.nnz == 107950
assert mapping['binary_start'] == 22 and mapping['binary_stop'] == mapping['weight_start'] == 7634 and mapping['weight_stop'] == 33208
assert np.array_equal(bounds[22:], np.tile([0., 1.], (33186, 1)))
assert np.array_equal(integrality, np.r_[np.zeros(22), np.ones(7612), np.zeros(25574)])
assert np.array_equal(objective, np.zeros(33208))
assert load(BASE / 'inventory.json') == load(MODES / 'inventory.json')
inventory = load(BASE / 'inventory.json')
short, first = list(map(tuple, inventory['short11_identities'])), list(map(tuple, inventory['mandatory_first55_identities']))
assert [tuple(o['identity']) for o in owners] == short and len(first) == 55
assert len(short) == len(set(short)) == 11 and len(first) == len(set(first)) == 55
assert not set(short) & set(first) and set(short+first) == {(p['id'], i) for p in job['parts'] for i in range(p['quantity'])}
used_rows, source_selectors, region_selectors, weights = set(), set(), set(), set()

def check_row(index, coefficients, lo, hi):
    assert index not in used_rows
    used_rows.add(index)
    start, end = matrix.indptr[index:index+2]
    actual = dict(zip(map(int, matrix.indices[start:end]), map(float, matrix.data[start:end])))
    assert actual == {i: float(v) for i, v in coefficients.items() if v != 0}
    assert lower[index] == lo and upper[index] == hi

for index, (owner, instance) in enumerate(zip(owners, instances)):
    assert owner['owner'] == index and owner['identity'] == instance['identity']
    modes = family_modes[owner['identity'][0]]
    assert len(owner['modes']) == len(modes)
    for actual, expected in zip(owner['modes'], modes):
        assert {k: v for k, v in actual.items() if k != 'selector'} == expected
        selector = actual['selector']
        assert 22 <= selector < 80 and selector not in source_selectors
        source_selectors.add(selector)
    check_row(owner['one_mode_row'], {m['selector']: 1. for m in owner['modes']}, 1., 1.)
    assert len(owner['stock_rows']) == 2
    for axis in [0, 1]:
        assert bounds[2*index+axis].tolist() == [min(m['lower_left_bounds'][axis][0] for m in modes), max(m['lower_left_bounds'][axis][1] for m in modes)]
        coefficients = {2*index+axis: 1., **{m['selector']: library[m['normalized_geometry']]['dimensions'][axis] for m in owner['modes']}}
        check_row(owner['stock_rows'][axis], coefficients, -np.inf, stock[axis+2]-.025)

seen_pairs = set()
mode_marginals = template_case_uses = 0
for actual, expected in zip(pairs, expected_pairs):
    ia, ib = actual['owners']
    assert actual['owners'] == expected['owners'] and (ia, ib) not in seen_pairs
    seen_pairs.add((ia, ib))
    expected_regions = [(t, r) for t in expected['template_indices'] for r in range(len(templates[t]['regions']))]
    assert [(r['template'], r['region']) for r in actual['regions']] == expected_regions
    template_case_uses += len(expected['template_indices'])
    coordinates = [{2*ia: 1., 2*ib: -1.}, {2*ia+1: 1., 2*ib+1: -1.}]
    for region in actual['regions']:
        template = templates[region['template']]
        assert region['geometries'] == template['geometries']
        selector = region['selector']
        assert 80 <= selector < 7634 and selector not in region_selectors
        region_selectors.add(selector)
        vertices = [[round(v, 9) for v in p] for p in template['regions'][region['region']]]
        assert len(region['lambdas']) == len(vertices)
        for column, vertex in zip(region['lambdas'], vertices):
            assert 7634 <= column < 33208 and column not in weights
            weights.add(column)
            for axis in [0, 1]:
                coordinates[axis][column] = vertex[axis]
        check_row(region['lambda_sum_row'], {selector: -1., **{i: 1. for i in region['lambdas']}}, 0., 0.)
    check_row(actual['one_region_row'], {r['selector']: 1. for r in actual['regions']}, 1., 1.)
    assert len(actual['coordinate_rows']) == 2
    for row_index, coefficients in zip(actual['coordinate_rows'], coordinates):
        check_row(row_index, coefficients, 0., 0.)
    expected_marginals = [(side, owner, geometry) for side, owner in enumerate([ia, ib]) for geometry in sorted({m['normalized_geometry'] for m in owners[owner]['modes']})]
    assert [(m['side'], m['owner'], m['geometry']) for m in actual['mode_marginals']] == expected_marginals
    for marginal in actual['mode_marginals']:
        side, owner, geometry = marginal['side'], marginal['owner'], marginal['geometry']
        ms = [m['selector'] for m in owners[owner]['modes'] if m['normalized_geometry'] == geometry]
        rs = [r['selector'] for r in actual['regions'] if r['geometries'][side] == geometry]
        assert ms == marginal['mode_selectors'] and rs == marginal['region_selectors'] and ms and rs
        check_row(marginal['row'], {**{i: -1. for i in ms}, **{i: 1. for i in rs}}, 0., 0.)
        mode_marginals += 1
assert len(pairs) == len(expected_pairs) == 55 and seen_pairs == set(combinations(range(11), 2))
assert template_case_uses == 1081 and mode_marginals == 500
expected_symmetry = []
for family in ['bracket', 'insert', 'cog']:
    same = sorted((o for o in owners if o['identity'][0] == family), key=lambda o: o['identity'][1])
    for a, b in zip(same, same[1:]):
        assert a['identity'][1] != b['identity'][1] and a['identity'][1] < parts[family]['quantity'] and b['identity'][1] < parts[family]['quantity']
        assert [{k: v for k, v in m.items() if k != 'selector'} for m in a['modes']] == [{k: v for k, v in m.items() if k != 'selector'} for m in b['modes']]
        expected_symmetry.append((family, [a['owner'], b['owner']]))
assert [(s['family'], s['owners']) for s in mapping['symmetry_rows']] == expected_symmetry
for symmetry in mapping['symmetry_rows']:
    a, b = symmetry['owners']
    check_row(symmetry['row'], {2*a: 1., 2*b: -1.}, -np.inf, 0.)
assert used_rows == set(range(8260)) and source_selectors == set(range(22, 80))
assert region_selectors == set(range(80, 7634)) and weights == set(range(7634, 33208))
assert not np.any((np.abs(data) > 0) & (np.abs(data) <= 1e-9))
write(OUT / 'symmetry-review.json', {
    'identical_original_families': ['bracket', 'insert', 'cog'], 'short_sheet_only': True,
    'source_mode_sets_and_stock_domains_equal_within_family': True,
    'ordered_adjacent_copy_pairs': expected_symmetry,
    'scope': 'For the underlying source packing problem, identical short-sheet copies can be relabelled in nondecreasing lower-left X order without changing geometry, legal source transforms, stock, roles or holes. First-sheet identities are untouched. The conservative floating region representation remains a restriction; no exact global infeasibility or allocation exclusion is inferred from this model.',
})
inputs = [Path(__file__), JOB, STOCK, BASE / 'plan.json', BASE / 'checks.json', BASE / 'model.npz', BASE / 'mapping.json', BASE / 'inventory.json',
          MODES / 'family-modes.json', MODES / 'geometry-library.json', MODES / 'instances.json', MODES / 'audit/plan.json', MODES / 'audit/checks.json',
          PRE / 'templates.json', PRE / 'owner-pairs.json', PRE / 'audit/plan.json', PRE / 'audit/checks.json', PRE / 'audit/rounded-region-support-certificates.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'all8260_rows_and33208_variables_verified': True,
          'all_legal_source_mode_selectors': len(source_selectors), 'region_selectors_verified': len(region_selectors),
          'nonnegative_vertex_weights_verified': len(weights), 'original_pair_groups': len(seen_pairs),
          'expanded_mode_geometry_pair_cases_verified': template_case_uses, 'both_owner_mode_marginal_rows_verified': mode_marginals,
          'mode_dependent_stock_rows_verified': 22, 'identical_copy_order_rows_verified': 8,
          'all11_short_and55_first_identities_verified': True, 'source_transform_aliases_preserved': True,
          'deactivation_constants': 0, 'tiny_matrix_coefficients': 0, 'zero_objective_verified': True,
          'model_sha256': digest(BASE / 'model.npz'), 'negative_result_cannot_exclude_allocation': True,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
