"""Prove exact model equivalence after removal of independently implied rows."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';MODEL=BASE/'reduced-model';PRIOR=BASE/'model';PRE=BASE/'redundant-plane-preflight';OUT=BASE/'reduced-model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(PRE/'audit/checks.json')['passed'] and load(BASE/'model-audit-v2/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((PRIOR/'model.pb').read_bytes());q=cp_model_pb2.CpModelProto();q.ParseFromString((MODEL/'model.pb').read_bytes())
assert q==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
drop=set(load(PRE/'audit/verified-deletions.json')); retained=[i for i in range(len(p.constraints)) if i not in drop]
assert len(q.variables)==len(p.variables)==88835 and len(q.constraints)==len(retained)==172639
assert all(a==b for a,b in zip(p.variables,q.variables))
assert all(p.constraints[i]==q.constraints[j] for j,i in enumerate(retained))
old=cp_model_pb2.CpModelProto();old.CopyFrom(p);old.ClearField('constraints');new=cp_model_pb2.CpModelProto();new.CopyFrom(q);new.ClearField('constraints');assert old==new
indices={i:j for j,i in enumerate(retained)};assert {int(k):v for k,v in load(MODEL/'constraint-index-map.json').items()}==indices
mapping=load(MODEL/'mapping.json');saved=load(PRIOR/'mapping.json');reverse={v:k for k,v in indices.items()}
for owner in mapping['owners']:
    owner['one_mode_constraint']=reverse[owner['one_mode_constraint']]
    for mode in owner['modes']:mode['stock_constraints']=[reverse[i] for i in mode['stock_constraints']]
for pair,original in zip(mapping['pairs'],saved['pairs']):
    pair['one_region_constraint']=reverse[pair['one_region_constraint']]
    for marginal in pair['mode_marginals']:marginal['constraint']=reverse[marginal['constraint']]
    for region,old_region in zip(pair['regions'],original['regions']):
        kept=region.pop('retained_source_plane_indices');expected=[i for i,c in enumerate(old_region['plane_constraints']) if c not in drop]
        assert kept==expected and [reverse[i] for i in region['plane_constraints']]==[old_region['plane_constraints'][i] for i in expected]
        region['plane_constraints']=old_region['plane_constraints']
for row in mapping['symmetry_constraints']:row['constraint']=reverse[row['constraint']]
assert mapping==saved
assert load(MODEL/'checks.json')['preparation_seconds_charged']==sum(load(MODEL/'preparation-charges.json').values())
inputs=[Path(__file__),MODEL/'plan.json',MODEL/'checks.json',MODEL/'model.pb',MODEL/'model.pbtxt',MODEL/'mapping.json',MODEL/'constraint-index-map.json',MODEL/'preparation-charges.json',PRIOR/'model.pb',PRIOR/'mapping.json',BASE/'model-audit-v2/plan.json',BASE/'model-audit-v2/checks.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'audit/verified-deletions.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'unchanged_variables_verified':88835,'unchanged_retained_constraints_verified':172639,'independently_implied_deleted_constraints':144938,'all_other_model_fields_identical':True,'all_mapping_indices_verified':True,'model_equivalent_to_audited_full_model':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
