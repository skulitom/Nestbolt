"""Exact rational grid upper covers of occupied area for the fixed cog-site construction.

Each convex unary hull is swept by each outward source-component rectangle.
A closed 10 mm grid cell containing any swept point is included. Area of the
union of included cells bounds all possible nonoverlapping filled originals.
This is a necessary condition only for the saved restricted construction.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'accessible-area-bound'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    points=sorted(set(points));low=[];high=[]
    for p in points:
        while len(low)>1 and cross(low[-2],low[-1],p)<=0:low.pop()
        low.append(p)
    for p in reversed(points):
        while len(high)>1 and cross(high[-2],high[-1],p)<=0:high.pop()
        high.append(p)
    return low[:-1]+high[:-1]
def grid_cover(poly):
    assert all(0<=x<1500 and 2000<=y<3000 for x,y in poly)
    spans=[];bits=0
    for row in range(int(min(y for x,y in poly)//10),int(max(y for x,y in poly)//10)+1):
        bottom=F(10*row);top=bottom+10
        xs=[x for x,y in poly if bottom<=y<=top]
        for (x1,y1),(x2,y2) in zip(poly,poly[1:]+poly[:1]):
            if y1==y2:continue
            for y in [bottom,top]:
                if min(y1,y2)<=y<=max(y1,y2):xs.append(x1+(y-y1)*(x2-x1)/(y2-y1))
        assert xs
        a=int(min(xs)//10);b=int(max(xs)//10)
        spans.append([row,a,b]);bits|=((1<<(b-a+1))-1)<<((row-200)*150+a)
    return bits,spans
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py')
inputs=[Path(__file__),BASE/'integer-preparation/plan.json',BASE/'integer-preparation/unary-templates.json',BASE/'integer-audit/plan.json',BASE/'integer-audit/checks.json',BASE/'rigid-rectangle-preflight/plan.json',BASE/'rigid-rectangle-preflight/mode-rectangles.json',BASE/'rigid-rectangle-preflight/audit-v3/plan.json',BASE/'rigid-rectangle-preflight/audit-v3/checks.json',BASE/'rigid-rectangle-preflight/audit-v3/source-partition-proofs.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'grid_cell_side_mm':10,'grid_extent_mm':[0,2000,1500,3000],'preparation_cap_seconds':60,'solver_calls':0,'global_allocation_exclusion_permitted':False})
assert load(BASE/'integer-audit/checks.json')['passed'] and load(BASE/'rigid-rectangle-preflight/audit-v3/checks.json')['passed']
started=time.perf_counter();unary=load(BASE/'integer-preparation/unary-templates.json');modes=load(BASE/'rigid-rectangle-preflight/mode-rectangles.json')
groups={family:{} for family in modes};records=[]
for family,opts in modes.items():
    for opt in opts:
        for r in unary[opt['geometry']]['regions']:
            hp=[tuple(map(F,v)) for v in r['hull_vertices']]
            if len(hp)<3:continue
            for rect in opt['rectangles']:
                assert time.perf_counter()-started<60,'Preparation cap reached; no proof claim permitted'
                l,b,rt,t=[F(x,1000) for x in rect['outward_offsets_um']]
                swept=hull([(x+dx,y+dy) for x,y in hp for dx,dy in [(l,b),(l,t),(rt,b),(rt,t)]])
                bits,spans=grid_cover(swept);mask=r['required_empty_mask']
                groups[family][mask]=groups[family].get(mask,0)|bits
                records.append({'family':family,'mode':opt['mode'],'geometry':opt['geometry'],'region':r['region'],'piece':rect['piece'],'required_empty_mask':mask,'swept_hull':[[str(x),str(y)] for x,y in swept],'grid_row_spans':spans})
requirements={p['family']:F(p['source_area_mm2'])*({'bracket':7,'insert':6}[p['family']]) for p in load(BASE/'rigid-rectangle-preflight/audit-v3/source-partition-proofs.json')}
assert requirements=={'bracket':F(280000),'insert':F(118800)}
results=[]
for a,b in combinations(range(15),2):
    mask=(1<<a)|(1<<b);covers={}
    for family,group in groups.items():
        bits=0
        for required,value in group.items():
            if required&~mask==0:bits|=value
        covers[family]=bits
    upper={k:v.bit_count()*100 for k,v in covers.items()}
    upper['combined']=(covers['bracket']|covers['insert']).bit_count()*100
    required={k:int(v) for k,v in requirements.items()};required['combined']=sum(required.values())
    contradictions=[k for k in required if upper[k]<required[k]]
    results.append({'empty_sites':[a,b],'occupied_sites':[i for i in range(15) if i not in [a,b]],'area_upper_bounds_mm2':upper,'area_required_mm2':required,'contradictions':contradictions,'restricted_construction_excluded':bool(contradictions)})
elapsed=time.perf_counter()-started
write(OUT/'swept-covers.json',records)
write(OUT/'family-mask-covers.json',{k:{str(mask):hex(v) for mask,v in group.items()} for k,group in groups.items()})
write(OUT/'all105-area-bounds.json',results)
checks={'passed':True,'seconds':elapsed,'cap_seconds':60,'cap_overrun_seconds':max(0,elapsed-60),'swept_component_regions':len(records),'empty_site_pairs':len(results),'restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in results),'upper_bound_ranges_mm2':{k:[min(r['area_upper_bounds_mm2'][k] for r in results),max(r['area_upper_bounds_mm2'][k] for r in results)] for k in ['bracket','insert','combined']},'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False,'independent_audit_required':True}
write(OUT/'checks.json',checks);print(checks)
