"""Delete only independently certified redundant rows; retain variables and all other fields."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';PRIOR=BASE/'model';PRE=BASE/'redundant-plane-preflight';OUT=BASE/'reduced-model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRE/'audit/checks.json')['passed'] and load(BASE/'response-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
p=cp_model_pb2.CpModelProto();p.ParseFromString((PRIOR/'model.pb').read_bytes());drop=set(load(PRE/'audit/verified-deletions.json'))
q=cp_model_pb2.CpModelProto();q.CopyFrom(p);q.ClearField('constraints');indices={}
for i,c in enumerate(p.constraints):
    if i not in drop:indices[i]=len(q.constraints);q.constraints.add().CopyFrom(c)
assert len(q.variables)==88835 and len(q.constraints)==172639
model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(q))
validation=model.validate();assert validation==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping=load(PRIOR/'mapping.json')
for owner in mapping['owners']:
    owner['one_mode_constraint']=indices[owner['one_mode_constraint']]
    for mode in owner['modes']:mode['stock_constraints']=[indices[i] for i in mode['stock_constraints']]
for pair in mapping['pairs']:
    pair['one_region_constraint']=indices[pair['one_region_constraint']]
    for marginal in pair['mode_marginals']:marginal['constraint']=indices[marginal['constraint']]
    for region in pair['regions']:
        old=region['plane_constraints'];region['retained_source_plane_indices']=[i for i,v in enumerate(old) if v not in drop];region['plane_constraints']=[indices[v] for v in old if v not in drop]
for row in mapping['symmetry_constraints']:row['constraint']=indices[row['constraint']]
write(OUT/'mapping.json',mapping);write(OUT/'constraint-index-map.json',indices);write(OUT/'validation.json',{'validation':validation})
elapsed=time.perf_counter()-started
charges={'prior_complete_model_preparation_including_short11_seconds':load(PRIOR/'checks.json')['preparation_seconds_charged'],'redundancy_preparation_seconds':load(PRE/'checks.json')['seconds'],'reduced_model_build_seconds':elapsed}
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),PRIOR/'plan.json',PRIOR/'checks.json',PRIOR/'model.pb',PRIOR/'mapping.json',PRE/'plan.json',PRE/'checks.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'audit/verified-deletions.json',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Remove144938 independently certified redundant guarded planes from the closed complete model. Keep every variable, mode, region selector, other constraint and all remaining protobuf fields exactly. The next one-call construction disables presolve and LP linearization explicitly to avoid the previous presolve-only outcome; no extension or reseed of the closed call. Charge the full earlier model preparation including the short11 construction, plus redundancy preparation and this model conversion. Independently verify all retained bytes and index remapping before opening the reduced-model call.','maximum_calls':1,'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'retry_permitted':False,'intended_solver_parameter_changes':{'cp_model_presolve':False,'linearization_level':0},'solver_calls':0})
result={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(q.variables),'constraints':len(q.constraints),'deleted_proven_redundant_constraints':len(drop),'all_variables_unchanged':True,'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
