"""Prepare exactly the count distributions retained by independent strip certificates."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029';OUT=ROOT/'output/h5-first55-strip-filtered-components-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(SOURCE/'audit/checks.json')['passed'] and load(STRIP/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'filter.py');started=time.perf_counter()
proof={tuple(r['empty_sites']):r for r in load(STRIP/'all29-strip-bounds.json')};rows=[]
for r in load(SOURCE/'all29-vectorized-bounds.json'):
    bounds=proof[tuple(r['empty_sites'])];assert bounds['initial_distributions']==r['remaining_distributions']
    if bounds['restricted_construction_excluded']:assert bounds['remaining_distributions']==[];continue
    assert bounds['remaining_distributions'] and all(v in r['remaining_distributions'] for v in bounds['remaining_distributions'])
    rows.append({**r,'remaining_distributions':bounds['remaining_distributions']})
assert len(rows)==25 and sum(len(r['remaining_distributions']) for r in rows)==82
write(OUT/'all25-filtered-bounds.json',rows);write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in rows]);elapsed=time.perf_counter()-started
inputs=[Path(__file__),SOURCE/'plan.json',SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',SOURCE/'all29-vectorized-bounds.json',STRIP/'plan.json',STRIP/'audit/plan.json',STRIP/'audit/checks.json',STRIP/'audit/allowed-empty-site-pairs.json',STRIP/'all29-strip-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Preserve every source component and source-mode attribution for each retained empty-site pair. Replace only its remaining count list with the independently audited strip result. Omit a site pair only when its complete count list has a verified exclusion. Required model preparation also charges generic count construction and strip discovery.','solver_calls':0,'native_calls':0})
checks={'passed':True,'seconds':elapsed,'restricted_site_pairs':25,'count_distributions':82,'new_source_geometry':False,'generic_count_construction_seconds_required':load(SOURCE/'checks.json')['seconds'],'strip_bound_seconds_required':load(STRIP/'checks.json')['seconds'],'independent_audit_required':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
