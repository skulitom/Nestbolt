"""Build one sufficient all-pair source model from the exact core/teeth partition."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json, math, shutil, time
import numpy as np
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/h5-short11-all-pair-separators-20261029'
SOURCE = ROOT / 'output/h5-source-projection-short11-20261029'
PART = ROOT / 'output/h5-short11-cycle-guided-axis-choices-20261029/core-teeth-partition-preflight'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(PART / 'audit/checks.json')['passed']
assert not OUT.exists()
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'build.py')
started = time.perf_counter()
job = load(JOB)
parts = {p['id']: p for p in job['parts']}
seed = load(SOURCE / 'source-translation-preflight/seed-source11.json')
inventory = load(SOURCE / 'preflight/inventory.json')
canonical = {
    'bracket': [[[0, 0], [300, 0], [300, 75], [0, 75]], [[0, 75], [100, 75], [100, 250], [0, 250]]],
    'insert': [parts['insert']['geometry'][0]['outer']],
    'cog': [[[float(F(x)), float(F(y))] for x, y in p['vertices']] for p in load(PART / 'partition.json')['pieces']],
}
world = []
stock = load(STOCK)['source_stock']
bounds = []
for owner, row in enumerate(seed):
    transform = row['transform']
    cosine, sine = math.cos(transform['rotation_radians']), math.sin(transform['rotation_radians'])
    sign = -1 if transform['mirrored'] else 1
    def pose(vertices):
        return [[sign*x*cosine-y*sine+transform['translation'][0],
                 sign*x*sine+y*cosine+transform['translation'][1]] for x, y in vertices]
    outline = pose(parts[row['part_id']]['geometry'][0]['outer'])
    array = np.asarray(outline)
    limits = [float(array[:, 0].min()), float(array[:, 1].min()),
              float(array[:, 0].max()), float(array[:, 1].max())]
    world.append({'owner': owner, 'identity': [row['part_id'], row['copy_index']],
                  'outline': outline, 'pieces': [pose(p) for p in canonical[row['part_id']]], 'bounds': limits})
    bounds.extend([[stock[0]+.025-limits[0], stock[2]-.025-limits[2]],
                   [stock[1]+.025-limits[1], stock[3]-.025-limits[3]]])
assert bounds == load(SOURCE / 'source-translation-preflight/variable-bounds.json')[:22]
assert len(world) == 11 and sum(len(p['pieces']) for p in world) == 56
assert set(map(tuple, inventory['short11_identities'])) == {tuple(p['identity']) for p in world}
base_bounds = np.asarray(bounds)
groups, sparse_rows, sparse_cols, sparse_values, lower, upper = [], [], [], [], [], []
variable_count = 22

def add_row(coefficients, lo, hi):
    row_index = len(lower)
    for variable, coefficient in coefficients.items():
        if coefficient != 0:
            sparse_rows.append(row_index)
            sparse_cols.append(variable)
            sparse_values.append(coefficient)
    lower.append(lo)
    upper.append(hi)
    return row_index

for a, b in combinations(world, 2):
    ia, ib = a['owner'], b['owner']
    indices = [2*ia, 2*ia+1, 2*ib, 2*ib+1]
    domain = base_bounds[indices]
    for ai, av in enumerate(a['pieces']):
        A = np.asarray(av)
        for bi, bv in enumerate(b['pieces']):
            B = np.asarray(bv)
            # All source edge normals, both signs, mapped to explicit finite axes.
            # Rounding is documented; negative results cannot exclude the allocation.
            axes, references = [], []
            seen = {}
            for side, vertices in enumerate([A, B]):
                for edge, (p, q) in enumerate(zip(vertices, np.roll(vertices, -1, axis=0))):
                    dx, dy = q-p
                    length = math.hypot(dx, dy)
                    assert length > 1e-9
                    for orientation in [1, -1]:
                        key = (round(float(-dy/length*orientation), 12), round(float(dx/length*orientation), 12))
                        if key not in seen:
                            norm = math.hypot(*key)
                            axis = [v/norm for v in key]
                            seen[key] = len(axes)
                            axes.append(axis)
                        references.append([side, edge, orientation, seen[key]])
            variants = []
            guaranteed = []
            possible = []
            for axis_index, normal in enumerate(axes):
                n = np.asarray(normal)
                coeff = np.r_[n, -n]
                rhs = float((B@n).min()-(A@n).max()-(.225+1e-7))
                minimum = float(np.sum(np.where(coeff >= 0, domain[:, 0], domain[:, 1])*coeff))
                maximum = float(np.sum(np.where(coeff >= 0, domain[:, 1], domain[:, 0])*coeff))
                classification = 'guaranteed' if maximum < rhs-1e-8 else 'impossible' if minimum > rhs+1e-8 else 'possible'
                record = {'normal': normal, 'rhs': rhs, 'domain_min': minimum, 'domain_max': maximum,
                          'classification': classification}
                if classification == 'guaranteed':
                    guaranteed.append(axis_index)
                elif classification == 'possible':
                    possible.append(axis_index)
                variants.append(record)
            assert guaranteed or possible, (ia, ib, ai, bi)
            group = {'owners': [ia, ib], 'pieces': [ai, bi], 'variable_indices': indices,
                     'edge_axis_references': references, 'variants': variants,
                     'guaranteed_axis': guaranteed[0] if guaranteed else None, 'possible_axes': possible}
            if not guaranteed:
                selectors = []
                for axis_index in possible:
                    v = variants[axis_index]
                    nx, ny = v['normal']
                    coefficients = dict(zip(indices, [nx, ny, -nx, -ny]))
                    if len(possible) == 1:
                        v['selector'] = None
                        v['M'] = 0
                        v['row'] = add_row(coefficients, -np.inf, v['rhs'])
                    else:
                        M = max(0., v['domain_max']-v['rhs'])+1e-8
                        v['M'] = M
                        v['selector'] = variable_count
                        coefficients[variable_count] = M
                        selectors.append(variable_count)
                        variable_count += 1
                        v['row'] = add_row(coefficients, -np.inf, v['rhs']+M)
                if selectors:
                    group['one_of_row'] = add_row({i: 1. for i in selectors}, 1., 1.)
            groups.append(group)
assert len(groups) == 1115
matrix = coo_matrix((sparse_values, (sparse_rows, sparse_cols)), shape=(len(lower), variable_count)).tocsc()
full_bounds = np.vstack([base_bounds, np.tile([0., 1.], (variable_count-22, 1))])
np.savez(OUT / 'model.npz', data=matrix.data, indices=matrix.indices, indptr=matrix.indptr,
         shape=np.asarray(matrix.shape), lower=lower, upper=upper, bounds=full_bounds,
         c=np.zeros(variable_count), integrality=np.r_[np.zeros(22, dtype=int), np.ones(variable_count-22, dtype=int)])
write(OUT / 'canonical-pieces.json', canonical)
write(OUT / 'world-pieces.json', world)
write(OUT / 'groups.json', groups)
write(OUT / 'seed-source11.json', seed)
write(OUT / 'inventory.json', inventory)
elapsed = time.perf_counter()-started
charges = {'exact_partition_preparation_seconds': load(PART / 'checks.json')['seconds'],
           'all_pair_model_preparation_seconds': elapsed}
write(OUT / 'preparation-charges.json', charges)
inputs = [Path(__file__), JOB, STOCK, PART / 'plan.json', PART / 'partition.json',
          PART / 'checks.json', PART / 'audit/plan.json', PART / 'audit/checks.json',
          SOURCE / 'source-translation-preflight/plan.json',
          SOURCE / 'source-translation-preflight/seed-source11.json',
          SOURCE / 'source-translation-preflight/variable-bounds.json', SOURCE / 'preflight/inventory.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'Sufficient fixed-orientation original-source construction. All 22 translations are free. Every one of 1115 inter-original convex piece pairs offers both signs of every source edge normal, rounded to 12 decimal places and renormalized. Directions impossible over stock domains are removed; guaranteed pairs need no row. Every other pair selects one possible direction with a domain-derived deactivation bound. Required projected separation is 0.2250001 mm and stock clearance is 0.025 mm. Objective is zero: the first feasible witness is sufficient. All 11 short and 55 first-sheet identities remain mandatory. The finite rounded directions and fixed modes/phases restrict this experiment; a negative result never excludes the allocation. Original-source readback is mandatory for an assignment; full66/native/material checks remain.',
    'maximum_calls': 1, 'retry_permitted': False, 'algorithm_seconds': 60, 'shared_seconds': 90,
    'node_limit': 128, 'source_validation_reserve_seconds': 3,
})
checks = {'passed': True, 'seconds': elapsed, 'preparation_seconds_charged': sum(charges.values()),
          'source_originals': 11, 'convex_pieces': 56, 'piece_pairs': len(groups),
          'axis_variants': sum(len(g['variants']) for g in groups),
          'guaranteed_pairs': sum(g['guaranteed_axis'] is not None for g in groups),
          'single_axis_pairs': sum(g['guaranteed_axis'] is None and len(g['possible_axes']) == 1 for g in groups),
          'choice_groups': sum('one_of_row' in g for g in groups),
          'domain_impossible_axes': sum(v['classification'] == 'impossible' for g in groups for v in g['variants']),
          'variables': variable_count, 'binary_selectors': variable_count-22, 'rows': len(lower),
          'matrix_nonzeros': matrix.nnz, 'model_sha256': digest(OUT / 'model.npz'),
          'independent_audit_pending': True, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
