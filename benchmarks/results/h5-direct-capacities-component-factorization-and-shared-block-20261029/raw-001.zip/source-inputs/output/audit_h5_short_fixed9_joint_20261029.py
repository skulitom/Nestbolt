"""Independent required-pair inventory, exact obstacle and 4D coverage audit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
from h5_joint_core_certificate_reader_20261029 import verify
from h5_continuous_core_certificate_reader_20261028 import cross,contains
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-fixed9-joint-20261029';OUT=BASE/'audit';INV=ROOT/'output/h5-short-fixed9-inventory-20261029';PRE=ROOT/'output/h5-short-joint-core-20261028';BOUND=ROOT/'output/h5-short-two-cog-exchange-20261028/all-angle-bound';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def corners(r):return [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for p in [BASE/'plan.json',INV/'audit/plan.json',PRE/'audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(INV/'audit/checks.json')['passed'] and load(PRE/'audit/checks.json')['passed']
survivors=[s for s in load(INV/'case-summary.json') if not s['all_angle_additional_cog_excluded']];expected=set()
for s in survivors:
    count=Counter(k[0] for k in s['removed_parent_identities']);gi=s['geometry_case']
    if count['cog']:expected.add((gi,None))
    if count['bracket']>=2:expected|={(gi,m) for m in range(36,44)}
assert len(expected)==253
core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};cb=load(PRE/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];bc={r['mode']:r for r in load(PRE/'bracket-cores.json')};summaries=load(BASE/'case-summary.json');result=load(BASE/'result.json');seen=set();cache={};sums=refs=0;checks=[]
for s in summaries:
    gi=s['geometry_case'];mi=s['second_mover_bracket_mode'];spec=(gi,mi);assert spec in expected and spec not in seen;seen.add(spec);data=load(BASE/'cases'/f"{s['case']}-inputs.json");assert (data['geometry_case'],data['second_mover_bracket_mode'])==spec;case=load(INV/'cases'/f'{gi}.json');rr=[r for p in case['fixed9'] for r in fixed[key(p)]];ee=[]
    for r in rr:ee.append(('fixed0',[(x-u,y-v) for x,y in corners(r) for u,v in core]))
    if mi is None:
        for r in rr:ee.append(('fixed1',[(x-u,y-v) for x,y in corners(r) for u,v in core]))
        ee.append(('pair',[(u[0]-v[0],u[1]-v[1]) for u in core for v in core]));bb=cb
    else:
        moving=bc[mi]['rectangles_um'];bb=bc[mi]['relaxed_anchor_bounds_um']
        for r in rr:
            for m in moving:ee.append(('fixed1',[(x-u,y-v) for x,y in corners(r) for u,v in corners(m)]))
        for m in moving:ee.append(('pair',[(u-x,v-y) for u,v in core for x,y in corners(m)]))
    obs=data['obstacles'];assert len(obs)==len(ee)
    for (kind,points),o in zip(ee,obs):
        assert o['kind']==kind;pointset=tuple(sorted(set(points)));poly=list(map(tuple,o['vertices_um']))
        if pointset in cache:assert poly==cache[pointset]
        else:
            assert len(poly)>=3 and len(set(poly))==len(poly) and all(type(v)==int for p in poly for v in p) and all(p in pointset for p in poly)
            for a,b in zip(poly,poly[1:]+poly[:1]):assert all(cross(a,b,p)>0 for p in poly if p not in (a,b))
            assert all(contains(poly,p) for p in pointset);cache[pointset]=poly;sums+=len(pointset)
        refs+=1
    bounds=[cb[0],cb[1],bb[0],bb[1],cb[2],cb[3],bb[2],bb[3]];assert bounds==data['bounds_um'];cert=load(BASE/'cases'/f"{s['case']}-certificate.json");checked=verify(cert,bounds,obs);assert checked['nodes']==s['nodes'] and checked['covered']==s['covered'] and cert['relaxation_witness_um']==s['relaxation_witness_um'] and cert['limit']==s['limit'];checks.append({'case':s['case'],'geometry_case':gi,'second_mover_bracket_mode':mi,**checked})
assert seen==expected
geometry=load(BASE/'geometry-summary.json');closed=closedvariants=0;open_geometries=[]
for g,s in zip(geometry,survivors):
    gi=s['geometry_case'];assert g['geometry_case']==gi and g['removed_parent_identities']==s['removed_parent_identities'] and g['inventory_variants']==s['inventory_variants'];cc=[r for r in checks if r['geometry_case']==gi];cg=[r for r in cc if r['second_mover_bracket_mode'] is None];br=[r for r in cc if r['second_mover_bracket_mode'] is not None];cgclosed=bool(cg and cg[0]['covered']);brclosed=bool(len(br)==8 and all(r['covered'] for r in br));done=cgclosed or brclosed
    assert done==g['geometry_excluded'] and cgclosed==g['cog_pair_excluded'] and brclosed==g['all_bracket_modes_excluded'] and len(cc)==g['required_joint_cases'];closed+=int(done);closedvariants+=len(g['inventory_variants']) if done else 0
    if not done:open_geometries.append(gi)
assert len(geometry)==56 and closed==result['additional_excluded_geometries']==51 and closedvariants==result['additional_excluded_identity_variants']==72 and result['remaining_unexcluded_geometries']==5 and result['remaining_unexcluded_identity_variants']==14
assert sum(r['covered'] for r in checks)==result['covered_pair_cases']==205 and sum(r['relaxation_witnesses'] for r in checks)==result['pair_witness_cases']==28 and sum(r['unresolved_depth_leaves'] for r in checks)==result['limited_pair_cases']==20
assert result['seconds']<120 and result['closed'];inputs=[Path(__file__),ROOT/'output/h5_joint_core_certificate_reader_20261029.py',ROOT/'output/h5_continuous_core_certificate_reader_20261028.py',BASE/'plan.json',INV/'audit/plan.json',PRE/'audit/plan.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'case-checks.json',checks)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'required_pair_cases':253,'unique_exact_no_fit_polygons':len(cache),'unique_exact_vertex_sums':sums,'exact_obstacle_references_verified':refs,'exact_certificate_nodes':sum(r['nodes'] for r in checks),'covered_hyperrectangle_leaves':sum(r['covered_leaves'] for r in checks),'exact_leaf_vertex_plane_checks':sum(r['exact_vertex_plane_checks'] for r in checks),'covered_pair_cases':205,'exact_relaxation_witnesses_verified':28,'depth40_partial_cases_retained':20,'additional_fixed9_geometries_excluded':51,'combined_fixed9_geometries_excluded':195,'combined_identity_variants_excluded':316,'remaining_unexcluded_geometries':open_geometries,'remaining_unexcluded_identity_variants':14,'separate_pair_witnesses_not_claimed_jointly_compatible':True,'all_angle_or_original_job_infeasibility_claimed':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
