"""Read all26 movers and combine them with the fixed29 and validshort11 originals."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, sys, time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';SEARCH=BASE/'reduced-search';OUT=SEARCH/'source-response'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir()
values=load(SEARCH/'assignment.json');mapping=load(BASE/'reduced-model/mapping.json');rows=[];chosen=[]
for owner in mapping['owners']:
    selected=[m for m in owner['modes'] if values[m['selector']]==1];assert len(selected)==1
    mode=selected[0];position=[values[v]/mapping['position_units_per_mm'] for v in owner['positions']]
    rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[position[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
    chosen.append({'owner':owner['owner'],'identity':owner['identity'],'mode':mode['mode'],'geometry':mode['normalized_geometry'],'lower_left_mm':position})
for pair in mapping['pairs']:
    selected=[r for r in pair['regions'] if values[r['selector']]==1]
    assert len(selected)==1 and selected[0]['geometries']==[chosen[i]['geometry'] for i in pair['owners']]
inventory=load(BASE/'inventory.json');spec=load(FIRST/'plan.json');job=load(JOB)
assert len(rows)==26 and sorted((r['part_id'],r['copy_index']) for r in rows)==sorted(map(tuple,inventory['moving26_identities']))
rows+=load(FIRST/'partial40.json');expected=list(map(tuple,inventory['full66_identities']))
assert len(rows)==66
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert check['cutouts']==90 and check['hole_vertices']==10026 and check['same_sheet_pairs']==1540 and check['stock_edges']==264
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-modes.json',chosen);write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',FIRST/'partial40.json',BASE/'reduced-model/mapping.json',BASE/'inventory.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'source_valid66':check['valid'],'originals':66,'first_originals':55,'short_originals':11,'same_sheet_pairs':check['same_sheet_pairs'],'stock_edges':check['stock_edges'],'cutouts':check['cutouts'],'hole_vertices':check['hole_vertices'],'source_checker_calls':1,'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
