"""Necessary joint-family capacities over continuous conservative source supports."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';AXIS=ROOT/'output/h5-first55-local-grid-regions-20261029/component-halfspace-bound';OUT=ROOT/'output/h5-first55-joint-component-capacity-20261029';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
assert load(AXIS/'audit/checks.json')['passed'] and load(PRIOR/'accessible-area-bound/audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
modes=load(PRIOR/'family-modes.json');pieces=load(PIECES);inner={};families=['bracket','insert']
for family in families:
    inner[family]=[]
    for mode in modes[family]:
        c,s=map(F,[math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians'])]);m=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left']);boxes=[]
        for piece in pieces[family]:
            p=[(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in piece]
            if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))<0:p.reverse()
            box=[min(x for x,y in p)+F('1e-6'),min(y for x,y in p)+F('1e-6'),max(x for x,y in p)-F('1e-6'),max(y for x,y in p)-F('1e-6')];l,b,r,t=box
            assert l<r and b<t and all(cross(a,z,q)>=0 for a,z in zip(p,p[1:]+p[:1]) for q in [(l,b),(l,t),(r,b),(r,t)])
            boxes.append(box)
        inner[family].append(boxes)
regions={};unary=load(PRIOR/'integer-preparation/unary-templates.json')
for r in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if r['family'] not in families:continue
    key=(r['family'],r['mode'],r['geometry'],r['region']);bits=0
    for row,lo,hi in r['grid_row_spans']:bits|=((1<<(hi-lo+1))-1)<<((row-200)*150+lo)
    if key not in regions:
        poly=[tuple(map(F,p)) for p in unary[r['geometry']]['regions'][r['region']]['hull_vertices']]
        regions[key]={'mask':r['required_empty_mask'],'bits':0,'bounds':[min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly)]}
    regions[key]['bits']|=bits
full=(1<<15000)-1;no_left=full^sum(1<<(150*y) for y in range(100));no_right=full^sum(1<<(150*y+149) for y in range(100))
def components(bits):
    result=[]
    while bits:
        c=bits&-bits
        while True:
            horizontal=c|((c&no_left)>>1)|((c&no_right)<<1)
            expanded=(horizontal|(horizontal>>150)|(horizontal<<150))&bits
            if c==expanded:break
            c=expanded
        result.append(c);bits^=c
    return result
@lru_cache(None)
def mandatory(family,mode,axis,above,shift,cut):
    total=F(0)
    for box in inner[family][mode]:
        lo,hi=box[axis]+shift,box[axis+2]+shift
        length=max(F(0),hi-max(lo,cut)) if above else max(F(0),min(hi,cut)-lo)
        total+=length*(box[3-axis]-box[1-axis])
    return total
allowed=load(AXIS/'audit/allowed-empty-site-pairs.json');old_axis={tuple(r['empty_sites']):r for r in load(AXIS/'all35-halfspace-bounds.json')};old_conn={tuple(r['empty_sites']):r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json')}
rows=[];total_cuts=0;total_certificates=0;scan_complete=True
for empty_sites in allowed:
    mask=sum(1<<i for i in empty_sites);active={key:r for key,r in regions.items() if not r['mask']&~mask};supports={f:0 for f in families}
    for key,r in active.items():supports[key[0]]|=r['bits']
    comps=components(supports['bracket']|supports['insert']);ranges=[{f:{} for f in families} for _ in comps];assignments=[]
    for key,r in active.items():
        matches=[i for i,c in enumerate(comps) if r['bits']&~c==0];assert len(matches)==1;ci=matches[0];assignments.append([*key,ci]);f,m,_,_=key;bounds=r['bounds'];old=ranges[ci][f].get(m)
        ranges[ci][f][m]=bounds[:] if old is None else [fun(a,b) for fun,a,b in zip([min,min,max,max],old,bounds)]
    prior_components=[int(v,16) for v in old_conn[tuple(empty_sites)]['components_hex']];prior_caps=[r['capacity_upper_bound'] for r in old_axis[tuple(empty_sites)]['components']]
    bracket_caps=[0]*len(comps);prior_assignments=[]
    for old_i,(bits,cap) in enumerate(zip(prior_components,prior_caps)):
        targets=[i for i,c in enumerate(comps) if bits&~c==0];assert len(targets)==1;bracket_caps[targets[0]]+=cap;prior_assignments.append([old_i,targets[0],cap])
    records=[];reachable={(0,0)}
    for ci,c in enumerate(comps):
        family_area={f:(supports[f]&c).bit_count()*100 for f in families};total_area=c.bit_count()*100
        lower={f:min((sum((b[2]-b[0])*(b[3]-b[1]) for b in inner[f][mode]) for mode in ranges[ci][f]),default=F(0)) for f in families}
        caps={f:min(7 if f=='bracket' else 6,int(F(family_area[f])//lower[f])) if lower[f]>0 else 0 for f in families};caps['bracket']=min(caps['bracket'],bracket_caps[ci])
        possible={(b,i) for b in range(caps['bracket']+1) for i in range(caps['insert']+1) if b*lower['bracket']+i*lower['insert']<=total_area};initial=sorted(possible);certificates=[];cuts=0
        xs=[0]*150;ys=[0]*100;bits=c
        while bits:
            lowbit=bits&-bits;idx=lowbit.bit_length()-1;y,x=divmod(idx,150);xs[x]+=1;ys[y]+=1;bits^=lowbit
        complete=True
        for axis,counts,origin in [(0,xs,0),(1,ys,2000)]:
            below_count=0
            for index in range(len(counts)+1):
                if time.perf_counter()-started>=58:complete=False;scan_complete=False;break
                cut=F(origin+10*index)
                for above in [False,True]:
                    available=(c.bit_count()-below_count if above else below_count)*100;values={f:{m:mandatory(f,m,axis,above,bounds[axis if above else axis+2],cut) for m,bounds in ranges[ci][f].items()} for f in families};least={f:min(values[f].values(),default=F(0)) for f in families};cuts+=1;total_cuts+=1
                    removed=sorted((b,i) for b,i in possible if b*least['bracket']+i*least['insert']>available)
                    if removed:
                        certificates.append({'axis':axis,'above':above,'threshold_mm':str(cut),'upper_area_mm2':available,'per_family_mode_minimum_area_mm2':{f:{str(m):str(v) for m,v in values[f].items()} for f in families},'family_minimum_area_mm2':{f:str(v) for f,v in least.items()},'count_pairs_removed':[list(p) for p in removed]});possible.difference_update(removed)
                if index<len(counts):below_count+=counts[index]
            if not complete:break
        total_certificates+=len(certificates)
        records.append({'component':ci,'grid_cells':c.bit_count(),'area_upper_mm2':total_area,'family_area_upper_mm2':family_area,'family_source_area_lower_mm2':{f:str(v) for f,v in lower.items()},'inherited_bracket_capacity':bracket_caps[ci],'count_caps':caps,'mode_position_bounds_mm':{f:{str(m):[str(v) for v in b] for m,b in ranges[ci][f].items()} for f in families},'initial_count_pairs':[list(p) for p in initial],'halfspace_certificates':certificates,'allowed_count_pairs':[list(p) for p in sorted(possible)],'halfspaces_examined':cuts,'scan_complete':complete})
        reachable={(b+x,i+y) for b,i in reachable for x,y in possible if b+x<=7 and i+y<=6}
    rows.append({'empty_sites':empty_sites,'family_supports_hex':{f:hex(v) for f,v in supports.items()},'joint_components_hex':[hex(c) for c in comps],'region_component_assignments':assignments,'inherited_bracket_component_assignments':prior_assignments,'components':records,'reachable_count_pairs':[list(p) for p in sorted(reachable)],'required_counts':[7,6],'restricted_construction_excluded':(7,6) not in reachable})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),PIECES,PRIOR/'family-modes.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'accessible-area-bound/plan.json',PRIOR/'accessible-area-bound/audit/plan.json',PRIOR/'accessible-area-bound/audit/checks.json',PRIOR/'accessible-area-bound/swept-covers.json',PRIOR/'connected-capacity-bound/audit/plan.json',PRIOR/'connected-capacity-bound/audit/checks.json',PRIOR/'connected-capacity-bound/all105-capacity-bounds.json',AXIS/'plan.json',AXIS/'audit/plan.json',AXIS/'audit/checks.json',AXIS/'audit/allowed-empty-site-pairs.json',AXIS/'all35-halfspace-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Union the audited possible occupied-material covers of both families for each retained empty-site pair. Every connected filled source pose stays within one conservative eight-neighbour grid component. Assign every unary source-mode region to its unique component. Enumerate bracket/insert counts subject to family area, joint area and inherited bracket capacities, then exact necessary halfspace inequalities using contained source rectangles and per-mode position extrema. Sum component count sets by exact integer dynamic programming. Exclusion applies only to this saved continuous conservative construction, not overall allocations.','preparation_cap_seconds':60,'stop_starting_halfspaces_after_seconds':58,'unprocessed_counts_retained':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'source-inner-rectangles.json',{f:[[[str(v) for v in box] for box in boxes] for boxes in opts] for f,opts in inner.items()});write(OUT/'all29-joint-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_seconds':60,'cap_overrun_seconds':max(0,elapsed-60),'discovery_scan_complete':scan_complete,'site_pairs_examined':len(rows),'joint_components':sum(len(r['components']) for r in rows),'halfspaces_examined':total_cuts,'strengthened_count_certificates':total_certificates,'additional_restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
