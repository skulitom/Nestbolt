"""Independently exhaust the saved finite anchors and audit the closed response."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from shapely.geometry import shape
from shapely.affinity import translate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-adjacent-exchange-20261028';DATA=BASE/'search';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for c in getattr(g,'geoms',[]) for p in polygons(c)]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for file in [DATA/'plan.json',DATA/'opened.json',BASE/'audit/plan.json']:
    for n,h in load(file)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'audit/checks.json')['passed']
result=load(DATA/'result.json');supervisor=load(DATA/'supervisor-result.json');progress=load(DATA/'mode-progress.json')
assert result['closed'] and result['all_finite_anchors_exhausted'] and result['reason']=='all declared finite anchors exhausted' and result['construction_calls']==1 and not result['retry_permitted'] and not result['source_valid_short13']
assert supervisor['closed'] and supervisor['child_returncode']==0 and not supervisor['shared_timeout'] and supervisor['construction_calls']==1
assert result['algorithm_seconds']<60 and supervisor['shared_seconds']<90 and result['algorithm_soft_overrun_seconds']==supervisor['shared_soft_overrun_seconds']==0
assert (DATA/'stderr.txt').read_text()=='' and not list(DATA.glob('source-rejection-*.json')) and not list(DATA.glob('short13-*.json')) and not (DATA/'execution-failure.json').exists()
records={(r['kind'],r['left'],r['right']):r for r in load(BASE/'obstacle-index.json')};free={i:shape(load(BASE/'free'/f'{i:02d}.json')['geometry']) for i in range(46)};observed=[];count=0;queries=0
for ci in range(36):
    points=[]
    for p in polygons(free[ci]):
        points.append(tuple(p.representative_point().coords[0]))
        for ring in [p.exterior,*p.interiors]:points.extend(tuple(v) for v in ring.coords[:-1])
    unique=sorted(set(points));count+=len(unique)
    for bi in range(36,44):
        r=records['cog-bracket',ci,bi];path=ROOT/r['source_path'];assert digest(path)==r['sha256'];obstacle=shape(load(path)['geometry'])
        for x,y in unique:
            residual=free[bi].difference(translate(obstacle,x,y));assert residual.is_empty;queries+=1
    p=progress[ci];assert p['cog_mode']==ci and p['cog_anchors']==len(unique) and p['mode_completed'] and p['joint_cog_bracket_anchors']==p['bracket_residual_components']==p['insert_residual_components']==0
    observed.append({'cog_mode':ci,'finite_cog_anchors':len(unique),'all8_bracket_domains_empty_at_every_anchor':True})
assert len(progress)==36 and count==result['cog_anchors_evaluated']==335 and queries==2680
assert all(result[n]==0 for n in ['joint_cog_bracket_anchors','bracket_residual_components','insert_residual_components','source13_checks','source13_rejections','solver_calls','native_calls'])
# Review finds an unexercised candidate identity representation defect. Preserve the closed script;
# prove that it cannot have influenced the empty-region result and require correction in any new study.
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');rows=load(BASE/'case.json')['fixed10'];plan=load(BASE/'plan.json');expected=[[r['part_id'],r['copy_index']] for r in rows]
try:audit(job,rows,{'sheet-1':plan['source_stock']},plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected)
except AssertionError:representation_defect_reproduced=True
else:raise AssertionError('Expected the documented list/tuple comparison defect')
fixed_expected=list(map(tuple,expected));control=audit(job,rows,{'sheet-1':plan['source_stock']},plan['required_pair_gap_mm'],plan['stock_guard_mm'],fixed_expected);assert control['valid']
write(OUT/'unexercised-candidate-validator-defect.json',{'observed':True,'detail':'The frozen constructor passes JSON identity lists to an audit helper that compares tuple keys. Any candidate reaching that check would raise before acceptance. All 2680 residual bracket queries independently prove empty, so no joint anchor or source13 call existed and this did not change the reported finite-region result. Preserve the original closed script and response. A future distinct construction must normalize expected identities with list(map(tuple, expected)) before calling the source helper.','failing_representation_control_reproduced':representation_defect_reproduced,'normalized_identity_control_valid':True,'candidate_checks_executed':0,'closed_script_unchanged':True,'search_retried':False})
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',BASE/'audit/plan.json',DATA/'plan.json',DATA/'opened.json',DATA/'result.json',DATA/'supervisor-result.json',DATA/'mode-progress.json',DATA/'stdout.txt',DATA/'stderr.txt']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'mode-checks.json',observed)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_construction_calls':1,'declared_cog_modes':36,'all_finite_cog_anchors_independently_reconstructed':335,'complete_residual_bracket_domain_queries':2680,'all_residual_bracket_domains_empty':True,'joint_cog_bracket_anchors':0,'source13_checks':0,'unexercised_candidate_identity_defect_retained':True,'full_source_search_completeness_claimed':False,'original_or_all_angle_infeasibility_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
