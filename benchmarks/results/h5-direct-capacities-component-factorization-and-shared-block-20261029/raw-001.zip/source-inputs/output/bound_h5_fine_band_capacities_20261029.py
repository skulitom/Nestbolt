"""Exact conservative 2mm-band/0.1mm-horizontal swept support capacities."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029/accessible-area-bound';OUT=ROOT/'output/h5-first55-fine-band-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def convex(points):
    points=sorted(set(points))
    def half(points):
        result=[]
        for p in points:
            while len(result)>1:
                a,b=result[-2:]
                if (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>0:break
                result.pop()
            result.append(p)
        return result
    return half(points)[:-1]+half(points[::-1])[:-1]
def merge(intervals):
    result=[]
    for lo,hi in sorted(intervals):
        if result and lo<=result[-1][1]:result[-1]=(result[-1][0],max(hi,result[-1][1]))
        else:result.append((lo,hi))
    return result
@lru_cache(None)
def cover(hull):
    spans=[]
    for row in range(min(y for x,y in hull)//20,math.ceil(max(y for x,y in hull)/20)):
        low,high=20*row,20*(row+1);xs=[]
        for a,b in zip(hull,hull[1:]+hull[:1]):
            if low<=a[1]<=high:xs.append((a[0],a[0]))
            if a[1]!=b[1]:
                for cut in [low,high]:
                    if min(a[1],b[1])<=cut<=max(a[1],b[1]):
                        num=a[0]*(b[1]-a[1])+(cut-a[1])*(b[0]-a[0]);den=b[1]-a[1]
                        if den<0:num,den=-num,-den
                        xs.append((num//den,-((-num)//den)))
        assert xs
        spans.append((row,min(v[0] for v in xs),max(v[1] for v in xs)))
    return tuple(spans)
assert load(COUNT/'audit/checks.json')['passed'] and load(PRIOR/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter();source_rows=load(COUNT/'all25-filtered-bounds.json')
needed={tuple(a[:4]) for r in source_rows for a in r['region_component_assignments']};parts=[];regions={};complete=True
for index,source in enumerate(load(PRIOR/'swept-covers.json')):
    key=(source['family'],source['mode'],source['geometry'],source['region'])
    if key not in needed:continue
    if time.perf_counter()-started>=58:complete=False;break
    boxes=[]
    for sx,sy in source['swept_hull']:
        x,y=F(sx)*10,F(sy)*10;boxes.extend((a,b) for a in [math.floor(x),math.ceil(x)] for b in [math.floor(y),math.ceil(y)])
    hull=tuple(convex(boxes));spans=cover(hull);part_index=len(parts)
    parts.append({'source_index':index,'source_key':list(key),'piece':source['piece'],'outward_hull_tenths_mm':[list(p) for p in hull],'band_spans_tenths_mm':[list(v) for v in spans]})
    byrow=regions.setdefault(key,{})
    for y,lo,hi in spans:byrow.setdefault(y,[]).append((lo,hi))
if complete:
    assert set(regions)==needed
    regions={k:{y:merge(v) for y,v in byrow.items()} for k,byrow in regions.items()}
rows=[];initial=remaining=certificates=subsets=0
for source in source_rows:
    possible={tuple(v) for v in source['remaining_distributions']};initial+=len(possible);groups=source['groups'];supports=[{} for g in groups];records=[];group_records=[];row_complete=complete
    if complete:
        for f,m,gid,ri,gi in source['region_component_assignments']:
            for y,spans in regions[(f,m,gid,ri)].items():supports[gi].setdefault(y,[]).extend(spans)
        supports=[{y:merge(v) for y,v in byrow.items()} for byrow in supports]
        for g,byrow in zip(groups,supports):
            area=F(sum(hi-lo for v in byrow.values() for lo,hi in v),5)
            group_records.append({'family':g['family'],'family_component':g['family_component'],'area_upper_mm2':str(area),'old_area_upper_mm2':g['area_upper_mm2'],'band_spans_tenths_mm':[[y,lo,hi] for y,v in sorted(byrow.items()) for lo,hi in v]})
        for mask in range(1,1<<len(groups)):
            if time.perf_counter()-started>=58:row_complete=False;complete=False;break
            selected=[i for i in range(len(groups)) if mask>>i&1];union={}
            for i in selected:
                for y,spans in supports[i].items():union.setdefault(y,[]).extend(spans)
            area=F(sum(hi-lo for v in union.values() for lo,hi in merge(v)),5)
            coeff=[F(g['source_area_lower_mm2']) if i in selected else F(0) for i,g in enumerate(groups)]
            removed=sorted(v for v in possible if sum(n*c for n,c in zip(v,coeff))>area)
            if removed:records.append({'groups':selected,'upper_area_mm2':str(area),'coefficients_mm2':[str(v) for v in coeff],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
            subsets+=1
    certificates+=len(records);remaining+=len(possible)
    rows.append({'empty_sites':source['empty_sites'],'initial_distributions':source['remaining_distributions'],'groups':group_records,'certificates':records,'remaining_distributions':[list(v) for v in sorted(possible)],'scan_complete':row_complete,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),COUNT/'plan.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all25-filtered-bounds.json',PRIOR/'plan.json',PRIOR/'audit/plan.json',PRIOR/'audit/checks.json',PRIOR/'swept-covers.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Each exact rational swept-hull vertex is enclosed by its four enclosing 0.1mm lattice corners. Their integer convex hull therefore contains the whole original swept hull. In each 2mm horizontal band, bound the integer hull X extrema at vertices and boundary intersections, rounding X outwards to 0.1mm. Union these conservative interval covers by original source component, then by each selected component subset. Their exact area upper bounds constrain the unchanged count distributions using the existing contained-source-rectangle material lower bounds. No source mode or component attribution is removed.','horizontal_unit_mm':'1/10','band_height_mm':2,'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_distributions_retained':True,'floating_exclusions_permitted':False,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'source-fine-covers.json',parts);write(OUT/'all25-fine-band-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':complete and all(r['scan_complete'] for r in rows),'source_swept_pieces':len(parts),'unique_integer_hulls':cover.cache_info().currsize,'source_band_spans':sum(len(p['band_spans_tenths_mm']) for p in parts),'source_options':len(needed),'site_pairs_retained_in_table':len(rows),'initial_count_distributions':initial,'remaining_count_distributions':remaining,'count_distributions_excluded':initial-remaining,'certificates':certificates,'subset_areas_examined':subsets,'new_restricted_site_exclusions':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
