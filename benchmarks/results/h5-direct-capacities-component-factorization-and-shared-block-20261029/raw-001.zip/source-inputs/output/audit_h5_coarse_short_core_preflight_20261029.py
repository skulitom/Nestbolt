"""Read coarse source mapping, stock, identities and symmetry independently."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';OUT=BASE/'audit';PRE=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,PRE,PRE/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PRE/'audit/checks.json')['passed'] and load(BASE/'checks.json')['passed']
inventory=load(BASE/'inventory.json');oldinv=load(PRE/'inventory.json');modes=load(BASE/'modes.json');oldmodes=load(PRE/'orthogonal-modes.json');proof=load(BASE/'source-mapping-proof.json');orders=load(BASE/'orders.json');job=load(JOB);parts={p['id']:p for p in job['parts']}
assert inventory=={**oldinv,'anchor_unit_um':100,'cog_center_stock_bounds_grid_units':inventory['cog_center_stock_bounds_grid_units']}
short=list(map(tuple,inventory['short13_identities']));first=list(map(tuple,inventory['mandatory_first53_identities']));assert len(set(short))==13 and len(set(first))==53 and not set(short)&set(first) and set(short+first)=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
assert Counter(k[0] for k in short)=={'bracket':5,'cog':2,'insert':6}
def verify_bounds(old,new):
    assert len(old)==len(new)==4
    for k,(a,b) in enumerate(zip(old,new)):
        target=F(a-50 if k<2 else a+50,100)
        # Direct neighboring-integer inequalities verify floor/ceiling without using the constructor's formula.
        assert (b-1<target<=b) if k<2 else (b<=target<b+1)
verify_bounds(oldinv['cog_center_stock_bounds_um'],inventory['cog_center_stock_bounds_grid_units'])
assert len(modes)==len(oldmodes)==12
for old,new in zip(oldmodes,modes):
    assert new=={**old,'anchor_stock_bounds_grid_units':new['anchor_stock_bounds_grid_units']};verify_bounds(old['anchor_stock_bounds_um'],new['anchor_stock_bounds_grid_units'])
expected=[]
for family in ['bracket','cog','insert']:
    ids=[list(k) for k in short if k[0]==family]
    assert parts[family]['quantity']>=len(ids) and isinstance(parts[family]['geometry'],list)
    expected.extend({'left_identity':a,'right_identity':b,'axis':'x','only_enforce_if_both_present':True} for a,b in zip(ids,ids[1:]))
assert orders==expected and len(orders)==10
gap=F(str(load(OLD/'plan.json')['required_pair_gap_mm']))*1000
assert proof['anchor_grid_um']==100 and proof['maximum_per_coordinate_rounding_um']==50
single=F(proof['single_original_translation_bound_um']);relative=F(proof['pair_relative_translation_bound_um'])
assert single**2>50**2+50**2 and relative==2*single and gap==F(proof['original_required_gap_um'])>relative
assert gap-relative>70 # micrometres of strictly positive remaining source separation
coredata=load(PRE/'cog-core.json');center=list(map(F,coredata['source_center_mm']));core=coredata['vertices_um'];bykey={(m['family'],m['quarter'],m['mirrored']):m for m in modes};controls=[];maximum=F(0)
for name,count in [('positive',11),('negative',13)]:
    source=load(PRE/f'{name}-source{count}.json');mapped=load(BASE/f'{name}-core{count}.json');assert len(source)==len(mapped)==count;shapes=[];source_shapes=[];known={}
    for p,r in zip(source,mapped):
        family=p['part_id'];identity=(family,p['copy_index']);assert tuple(r['identity'])==identity and r['family']==family and identity in short and identity not in known;known[identity]=r;t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1
        source_shapes.append(Polygon([(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in parts[family]['geometry'][0]['outer']]))
        if family=='cog':
            assert not t['mirrored'] and r['mode'] is None;co,si=F(str(c)),F(str(s));tx,ty=map(lambda v:F(str(v)),t['translation']);exact=[(co*center[0]-si*center[1]+tx)*1000,(si*center[0]+co*center[1]+ty)*1000];bounds=inventory['cog_center_stock_bounds_grid_units'];rects=[]
        else:
            q=round(t['rotation_radians']/(math.pi/2))%4;m=bykey[family,q,t['mirrored']];assert r['mode']==m['mode'];exact=[1000*(F(str(t['translation'][k]))-F(str(m['source_translation_offset'][k]))) for k in [0,1]];bounds=m['anchor_stock_bounds_grid_units'];rects=m['rectangles_um']
        assert list(map(F,r['source_anchor_um_exact']))==exact and r['stock_bounds_grid_units']==bounds;units=r['anchor_grid_units'];xy=r['anchor_um'];assert all(type(v)==int for v in units) and xy==[100*v for v in units]
        for k in [0,1]:
            err=abs(xy[k]-exact[k]);assert err<=50 and bounds[k]<=units[k]<=bounds[k+2];maximum=max(maximum,err)
        world=[[a+xy[0],b+xy[1],c+xy[0],d+xy[1]] for a,b,c,d in rects];assert world==r['world_rectangles_um'];shapes.append((family,[box(*v) for v in world] if rects else [Polygon([(x+xy[0],y+xy[1]) for x,y in core])]))
    active=0
    for order in orders:
        a,b=tuple(order['left_identity']),tuple(order['right_identity'])
        if a in known and b in known:assert known[a]['anchor_grid_units'][0]<=known[b]['anchor_grid_units'][0];active+=1
    bad={'orthogonal_piece_pairs':0,'cog_rectangle_pairs':0,'cog_pair':0}
    for (fa,aa),(fb,bb) in combinations(shapes,2):
        label='cog_pair' if fa==fb=='cog' else 'cog_rectangle_pairs' if 'cog' in [fa,fb] else 'orthogonal_piece_pairs'
        for a in aa:
            for b in bb:bad[label]+=int(not a.disjoint(b) if 'cog' in [fa,fb] else a.intersection(b).area>0)
    sourcebad=sum(int(not a.disjoint(b) or a.distance(b)<=float(gap/1000)) for a,b in combinations(source_shapes,2))
    if name=='positive':assert not any(bad.values()) and sourcebad==0 and active==8
    else:assert all(bad.values()) and sourcebad==78 and active==10
    controls.append({'name':name,'originals':count,'active_order_constraints':active,'core_collisions':bad})
assert controls==load(BASE/'controls.json')
write(OUT/'control-checks.json',controls)
inputs=[Path(__file__),JOB,PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'cog-core.json',PRE/'positive-source11.json',PRE/'negative-source13.json',OLD/'plan.json']+list(BASE.glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all66_identities_and_complement_verified':True,'all12_modes_and_exact_micrometre_cores_unchanged':True,'stock_bound_conversions_independently_verified':13,'copy_family_order_constraints_verified':10,'positive_control_originals':11,'negative_control_originals':13,'source_controls_independently_reconstructed':True,'maximum_control_coordinate_error_um':str(maximum),'strict_source_gap_remaining_after_rounding_um':str(gap-relative),'source_feasibility_preserving_rounding_and_relabeling_verified':True,'old_core_witness_set_preservation_claimed':False,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'),flush=True)
