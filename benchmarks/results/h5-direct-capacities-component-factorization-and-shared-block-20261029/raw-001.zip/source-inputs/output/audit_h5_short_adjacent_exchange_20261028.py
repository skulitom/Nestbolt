"""Read all unchanged obstacle bindings and independently prove the new source regions."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from datetime import datetime,timezone
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,shape,box
from shapely.affinity import translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-adjacent-exchange-20261028';OUT=BASE/'audit';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';INV=ROOT/'output/h5-short-fixed10-inventory-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for child in getattr(g,'geoms',[]) for p in polygons(child)]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for file in [BASE/'plan.json',OLD/'preflight-v2/plan.json',INV/'audit/plan.json']:
    for n,h in load(file)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'preflight-v2/checks.json')['passed'] and load(INV/'audit/checks.json')['passed']
prepared=load(BASE/'prepared.json');assert prepared['passed'] and prepared['closed'] and prepared['seconds']<120
job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');fixed=load(BASE/'fixed-types.json');assert modes==load(ROOT/'output/h5-short-cog-transfer-20261028/modes.json') and fixed==load(OLD/'fixed-types.json')
def original(family,a,mir,offset=(0.,0.)):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1
    return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in parts[family]['geometry'][0]['outer']])
def partition(g):
    pp=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(pp).equals(g) and all(len(p.exterior.coords)==4 and p.equals(p.convex_hull) for p in pp)
    return [list(p.exterior.coords)[:-1] for p in pp]
fg={f['id']:original(f['family'],f['angle'],f['mirrored']) for f in fixed};ft={k:partition(g) for k,g in fg.items()};mg={};mt={}
for m in modes:
    g=original(m['family'],m['angle'],m['mirrored'],m['source_translation_offset']);assert g.equals_exact(shape(m['geometry']),1e-10);mg[m['index']]=g;mt[m['index']]=partition(g)
records=load(BASE/'obstacle-index.json');obs={};reused=new=hulls=0;checks=[]
oldrecords={('fixed-moving',r['fixed_type'],r['moving_mode']) if r['kind']=='fixed-moving' else ('cog-insert',r['cog_mode'],r['insert_mode']):r for r in load(OLD/'obstacle-index.json')}
expected={('fixed-moving',f['id'],i) for f in fixed for i in range(46)}|{('cog-bracket',c,b) for c in range(36) for b in range(36,44)}|{('cog-insert',c,i) for c in range(36) for i in [44,45]}|{('bracket-insert',b,i) for b in range(36,44) for i in [44,45]}
for r in records:
    key=(r['kind'],r['left'],r['right']);assert key in expected and key not in obs;p=ROOT/r['source_path'];assert digest(p)==r['sha256'];data=load(p);g=shape(data['geometry']);assert g.is_valid and data['hulls']==r['hulls']
    if r['reused_source_audit']:
        old=oldrecords[key];assert p==OLD/'obstacles'/old['file'] and data['hulls']==old['hulls'];reused+=1
    else:
        left=ft[r['left']] if r['kind']=='fixed-moving' else mt[r['left']];right=mt[r['right']]
        points=np.asarray([[(u[0]-v[0],u[1]-v[1]) for u in a for v in b] for a in left for b in right]);hh=shapely.convex_hull(shapely.multipoints(points));required=shapely.union_all(hh).buffer(plan['independent_required_obstacle_radius_mm'],quad_segs=16)
        assert g.covers(required) and len(hh)==r['hulls'];hulls+=len(hh);new+=1
    obs[key]=g;checks.append({'kind':r['kind'],'left':r['left'],'right':r['right'],'complete_source_obstacle_verified':True,'reused_unchanged_independent_source_audit':r['reused_source_audit']})
assert set(obs)==expected and reused==262 and new==344 and hulls==92864
case=load(BASE/'case.json');prior=load(INV/'cases/38.json');assert {k:v for k,v in case.items() if k!='fixed_references'}==prior
variants=load(BASE/'selected-inventories.json');allvariants=load(INV/'inventory-variants.json');assert variants==[allvariants[48],allvariants[59]]
allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
for v in variants:
    ss=set(map(tuple,v['mandatory_short_identities']));fs=set(map(tuple,v['mandatory_first_identities']));assert len(ss)==13 and len(fs)==53 and ss|fs==allids and not ss&fs
refs=case['fixed_references'];world=[]
for row,ref in zip(case['fixed10'],refs):
    t=row['transform'];f=fixed[ref['fixed_type']];assert ref['identity']==[row['part_id'],row['copy_index']] and ref['translation']==t['translation'] and (f['family'],f['angle'],f['mirrored'])==(row['part_id'],t['rotation_radians'],t['mirrored']);world.append(original(row['part_id'],t['rotation_radians'],t['mirrored'],t['translation']))
assert len(world)==len(refs)==10
samples=[];stock=plan['source_stock'];extra=plan['new_moving_stock_extra_mm'];counts={'cog':0,'bracket':0,'insert':0}
for mi,m in enumerate(modes):
    a,b,c,d=mg[mi].bounds;bounds=[stock[0]+extra-a,stock[1]+extra-b,stock[2]-extra-c,stock[3]-extra-d];saved=load(BASE/'free'/f'{mi:02d}.json');assert saved['mode']==mi and saved['anchor_stock_bounds_mm']==bounds
    free=shape(saved['geometry']);expectedfree=box(*bounds).difference(unary_union([translate(obs['fixed-moving',r['fixed_type'],mi],*r['translation']) for r in refs]));assert free.equals(expectedfree);counts[m['family']]+=int(not free.is_empty)
    for region in polygons(free):
        xy=list(region.representative_point().coords[0]);g=translate(mg[mi],*xy);allshapes=world+[g];gaps=[];extras=[]
        for a,b in combinations(allshapes,2):assert a.disjoint(b) and a.distance(b)>plan['required_pair_gap_mm'];gaps.append(a.distance(b))
        for p in allshapes:
            b=p.bounds;extras.append(min(b[0]-stock[0],b[1]-stock[1],stock[2]-b[2],stock[3]-b[3]))
        assert min(extras)>plan['stock_guard_mm'];samples.append({'mode':mi,'anchor':xy,'source_originals':11,'minimum_pair_gap_mm':min(gaps),'minimum_extra_stock_mm':min(extras)})
assert samples==load(BASE/'source-samples.json') and len(samples)==46 and counts=={'cog':36,'bracket':8,'insert':2}
inputs=[Path(__file__),BASE/'plan.json',OLD/'preflight-v2/plan.json',INV/'audit/plan.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'obstacle-checks.json',checks);write(OUT/'source-sample-checks.json',samples)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'reused_complete_source_obstacles_hash_verified':262,'new_complete_source_obstacles_independently_verified':344,'new_independent_convex_hulls':92864,'all46_fixed10_free_domains_reconstructed':True,'source_valid11_representative_controls':46,'both_target13_first53_identity_partitions_verified':True,'all66_originals_mandatory':True,'construction_opened':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
