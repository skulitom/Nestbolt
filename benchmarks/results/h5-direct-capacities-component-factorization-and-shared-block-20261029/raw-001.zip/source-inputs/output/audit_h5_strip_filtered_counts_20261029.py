"""Independent readback of the filtered counts and unchanged source-mode component attribution."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029';BASE=ROOT/'output/h5-first55-strip-filtered-components-20261029';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(SOURCE/'audit/checks.json')['passed'] and load(STRIP/'audit/checks.json')['passed'];original={tuple(r['empty_sites']):r for r in load(SOURCE/'all29-vectorized-bounds.json')};proof={tuple(r['empty_sites']):r for r in load(STRIP/'all29-strip-bounds.json')};rows=load(BASE/'all25-filtered-bounds.json');allowed=load(STRIP/'audit/allowed-empty-site-pairs.json');assert [r['empty_sites'] for r in rows]==allowed==load(BASE/'allowed-empty-site-pairs.json')
aliases=unique=0
for r in rows:
    old=original[tuple(r['empty_sites'])];p=proof[tuple(r['empty_sites'])]
    assert {k:v for k,v in r.items() if k!='remaining_distributions'}=={k:v for k,v in old.items() if k!='remaining_distributions'}
    assert r['remaining_distributions']==p['remaining_distributions'] and r['remaining_distributions'] and not p['restricted_construction_excluded']
    lookup={}
    for f,m,gid,ri,ci in r['region_component_assignments']:lookup.setdefault((f,gid,ri),set()).add(ci);aliases+=1
    assert all(len(v)==1 for v in lookup.values());unique+=len(lookup)
assert len(rows)==25 and sum(len(r['remaining_distributions']) for r in rows)==82
for pair,p in proof.items():assert (list(pair) not in allowed)==p['restricted_construction_excluded']==(not p['remaining_distributions'])
write(OUT/'allowed-empty-site-pairs.json',allowed);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','all25-filtered-bounds.json','allowed-empty-site-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_geometry_and_attributions_unchanged':True,'all_source_mode_aliases_agree_on_component':True,'source_mode_attributions_verified':aliases,'unique_family_geometry_region_attributions':unique,'only_independently_excluded_distributions_removed':True,'restricted_site_pairs':25,'count_distributions':82,'solver_calls':0,'native_calls':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
