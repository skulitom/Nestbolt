"""Independently enumerate active mode corners and midpoint capacity controls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-short-core-20261029';PRE=BASE/'preflight';OUT=PRE/'audit';COARSE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';STRIP=ROOT/'output/h5-coarse-short-core-20261029/cog-strip-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,PRE,COARSE/'audit',STRIP/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(COARSE/'audit/checks.json')['passed'] and load(STRIP/'audit/checks.json')['passed'];modes=load(COARSE/'modes.json');inventory=load(COARSE/'inventory.json');strips=load(STRIP/'strips.json');envelopes=load(PRE/'envelopes.json');bounds=load(PRE/'bounds.json');box=bounds['common_box_um'];expected=[];allpoints=[];cornerchecks=0
for m in modes:expected.extend((m['family'],m['mode'],k,m['anchor_stock_bounds_grid_units'],r) for k,r in enumerate(m['rectangles_um']))
expected.extend(('cog',None,k,inventory['cog_center_stock_bounds_grid_units'],r) for k,r in enumerate(strips));assert len(expected)==len(envelopes)==36
for saved,(family,mode,component,b,r) in zip(envelopes,expected):
    points=[(100*x+u,100*y+v) for x in [b[0],b[2]] for y in [b[1],b[3]] for u in [r[0],r[2]] for v in [r[1],r[3]]];exact=[min(x for x,y in points),min(y for x,y in points),max(x for x,y in points),max(y for x,y in points)]
    assert saved=={'family':family,'mode':mode,'component':component,'anchor_bounds_grid_units':b,'local_rectangle_um':r,'world_envelope_um':exact}
    for x,y in points:assert box[0]<=x<=box[2] and box[1]<=y<=box[3];cornerchecks+=1
    allpoints.extend(points)
assert box==[min(x for x,y in allpoints),min(y for x,y in allpoints),max(x for x,y in allpoints),max(y for x,y in allpoints)]
assert bounds['x_intervals_height_capacity_um']==box[3]-box[1] and bounds['y_intervals_width_capacity_um']==box[2]-box[0]
controls=[];slabs=0
for name,count in [('positive',11),('negative',13)]:
    rr=[]
    for row in load(COARSE/f'{name}-core{count}.json'):
        x,y=row['anchor_um'];rr.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in strips] if row['family']=='cog' else row['world_rectangles_um'])
    peaks=[]
    for axis in [0,1]:
        points=sorted({r[k] for r in rr for k in [axis,axis+2]});maximum=0
        for a,b in zip(points,points[1:]):
            t=F(a+b,2);total=sum(r[3-axis]-r[1-axis] for r in rr if r[axis]<t<r[axis+2]);maximum=max(maximum,total);slabs+=1
        peaks.append(maximum)
    controls.append({'name':name,'originals':count,'pieces':len(rr),'peak_sum_heights_um':peaks[0],'peak_sum_widths_um':peaks[1],'cumulative_constraints_pass':[peaks[0]<=box[3]-box[1],peaks[1]<=box[2]-box[0]]})
assert controls==load(PRE/'controls.json') and controls[0]['cumulative_constraints_pass']==[True,True] and controls[1]['cumulative_constraints_pass']==[False,False]
write(OUT/'controls.json',controls);inputs=[Path(__file__),COARSE/'audit/plan.json',STRIP/'audit/plan.json']+list(PRE.glob('*.json'));write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all36_mode_piece_envelopes_verified':True,'exact_anchor_local_corner_checks':cornerchecks,'common_box_um':box,'x_intervals_height_capacity_um':box[3]-box[1],'y_intervals_width_capacity_um':box[2]-box[0],'independent_midpoint_slabs_checked':slabs,'positive_and_negative_source_controls_verified':True,'expanded_stock_and_coarse_rounding_included':True,'cumulative_constraints_necessary_for_all_active_core_assignments':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
