"""Verify every protobuf variable, site mask, mode coupling and original-pair constraint."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRE=BASE/'integer-preparation';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [PRE,MODEL,BASE/'integer-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(BASE/'integer-audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'} and len(p.variables)==23102 and len(p.constraints)==109655
mapping=load(MODEL/'mapping.json');modes=load(PRE/'family-modes.json');unary=load(PRE/'unary-templates.json');templates=load(PRE/'pair-templates.json');groups=load(PRE/'owner-pairs.json');instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json');owners=mapping['owners']
assert len(owners)==len(instances)==13 and mapping['position_units_per_mm']==1000 and [o['identity'] for o in owners]==inventory['moving13_orthogonal_identities']
used_vars=set();used_ct=set();false_clauses=0
def variable(i,name,domain):
    assert i not in used_vars;used_vars.add(i);v=p.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,x in v.ListFields()}=={'name','domain'}
def linear(i,coeff,lo,hi,guard=None):
    global false_clauses
    assert i not in used_ct;used_ct.add(i);c=p.constraints[i];co={j:v for j,v in coeff.items() if v}
    assert list(c.enforcement_literal)==([] if guard is None else [guard])
    if not co and not lo<=0<=hi:
        assert c.WhichOneof('constraint')=='bool_or' and not c.bool_or.literals and {f.name for f,x in c.ListFields()}=={'bool_or'}|({'enforcement_literal'} if guard is not None else set());false_clauses+=1;return
    assert c.WhichOneof('constraint')=='linear' and {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert dict(zip(c.linear.vars,c.linear.coeffs))==co and len(c.linear.vars)==len(co) and list(c.linear.domain)==[lo,hi]
mode_count=unary_count=unary_planes=mask_links=0
for i,(owner,instance) in enumerate(zip(owners,instances)):
    assert owner['owner']==i and owner['identity']==instance['identity'] and owner['positions']==[2*i,2*i+1]
    expected=modes[owner['identity'][0]];assert len(owner['modes'])==len(expected)
    for k in [0,1]:variable(2*i+k,f'{"x" if k==0 else "y"}_{i}_um',[min(m['integer_lower_left_bounds'][k][0] for m in expected),max(m['integer_lower_left_bounds'][k][1] for m in expected)])
    for actual,source in zip(owner['modes'],expected):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source
        selector=actual['selector'];assert 26<=selector<106;variable(selector,f'mode_{i}_{source["mode"]}',[0,1]);assert len(actual['stock_constraints'])==2
        for k in [0,1]:linear(actual['stock_constraints'][k],{2*i+k:1},*source['integer_lower_left_bounds'][k],selector)
        mode_count+=1
    linear(owner['one_mode_constraint'],{m['selector']:1 for m in owner['modes']},1,1)
empty=mapping['empty_site_selectors'];assert empty==list(range(106,121))
for site,var in enumerate(empty):variable(var,f'empty_cog_site_{site}',[0,1])
linear(mapping['exactly_two_empty_sites_constraint'],{v:1 for v in empty},2,2)
assert len(list(combinations(empty,2)))==105
for i,owner in enumerate(owners):
    geometries=sorted({m['normalized_geometry'] for m in owner['modes']});expected=[(gid,r['region']) for gid in geometries for r in unary[gid]['regions']]
    assert [(r['geometry'],r['region']) for r in owner['unary_regions']]==expected
    for region in owner['unary_regions']:
        gid,ri=region['geometry'],region['region'];source=unary[gid]['regions'][ri];selector=region['selector'];assert 121<=selector<10826
        variable(selector,f'unary_{i}_{gid}_{ri}',[0,1]);assert region['required_empty_sites']==source['required_empty_sites'] and len(region['plane_constraints'])==len(source['planes'])
        for ci,plane in zip(region['plane_constraints'],source['planes']):
            nx,ny=plane['coefficients'];linear(ci,{2*i:nx,2*i+1:ny},MIN,plane['upper'],selector);unary_planes+=1
        assert len(region['empty_site_constraints'])==len(source['required_empty_sites'])
        for ci,site in zip(region['empty_site_constraints'],source['required_empty_sites']):linear(ci,{selector:1,empty[site]:-1},MIN,0);mask_links+=1
        unary_count+=1
    linear(owner['one_unary_region_constraint'],{r['selector']:1 for r in owner['unary_regions']},1,1)
    assert [m['geometry'] for m in owner['unary_geometry_marginals']]==geometries
    for marginal in owner['unary_geometry_marginals']:
        gid=marginal['geometry'];ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in owner['unary_regions'] if r['geometry']==gid]
        assert marginal['mode_selectors']==ms and marginal['region_selectors']==rs and ms and rs;linear(marginal['constraint'],{**{v:-1 for v in ms},**{v:1 for v in rs}},0,0)
pair_count=pair_planes=marginals=0
assert [r['owners'] for r in mapping['pairs']]==[list(k) for k in combinations(range(13),2)]
for pair,group in zip(mapping['pairs'],groups):
    ia,ib=pair['owners'];assert pair['owners']==group['owners'];expected=[(ti,r['region']) for ti in group['template_indices'] for r in templates[ti]['regions']]
    assert [(r['template'],r['region']) for r in pair['regions']]==expected
    for region in pair['regions']:
        ti,ri=region['template'],region['region'];source=templates[ti]['regions'][ri];selector=region['selector'];assert 10826<=selector<23102 and region['geometries']==templates[ti]['geometries']
        variable(selector,f'pair_{ia}_{ib}_{ti}_{ri}',[0,1]);assert len(region['plane_constraints'])==len(source['planes'])
        for ci,plane in zip(region['plane_constraints'],source['planes']):
            nx,ny=plane['coefficients'];linear(ci,{2*ia:-nx,2*ia+1:-ny,2*ib:nx,2*ib+1:ny},MIN,plane['upper'],selector);pair_planes+=1
        pair_count+=1
    linear(pair['one_region_constraint'],{r['selector']:1 for r in pair['regions']},1,1)
    expected=[(side,owner,g) for side,owner in enumerate([ia,ib]) for g in sorted({m['normalized_geometry'] for m in owners[owner]['modes']})];assert [(m['side'],m['owner'],m['geometry']) for m in pair['mode_marginals']]==expected
    for marginal in pair['mode_marginals']:
        owner,side,gid=marginal['owner'],marginal['side'],marginal['geometry'];ms=[m['selector'] for m in owners[owner]['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in pair['regions'] if r['geometries'][side]==gid]
        assert marginal['mode_selectors']==ms and marginal['region_selectors']==rs and ms and rs;linear(marginal['constraint'],{**{v:-1 for v in ms},**{v:1 for v in rs}},0,0);marginals+=1
expected=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1]);expected.extend((family,[a['owner'],b['owner']]) for a,b in zip(peers,peers[1:]))
assert [(r['family'],r['owners']) for r in mapping['symmetry_constraints']]==expected
for row in mapping['symmetry_constraints']:
    a,b=row['owners'];linear(row['constraint'],{2*a:1,2*b:-1},MIN,0)
assert used_vars==set(range(23102)) and used_ct==set(range(109655)) and mode_count==80 and unary_count==10705 and unary_planes==43721 and mask_links==17686 and pair_count==12276 and pair_planes==47088 and marginals==816
assert load(MODEL/'checks.json')['preparation_seconds_charged']==sum(load(MODEL/'preparation-charges.json').values())
inputs=[Path(__file__),BASE/'plan.json',BASE/'instances.json',BASE/'inventory.json',BASE/'integer-audit/plan.json',BASE/'integer-audit/checks.json']+[PRE/n for n in ['plan.json','family-modes.json','unary-templates.json','pair-templates.json','owner-pairs.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'variables_verified':len(used_vars),'constraints_verified':len(used_ct),'original_moving_parts':13,'source_mode_selectors_verified':mode_count,'empty_site_selectors_verified':15,'exactly_two_empty_sites_verified':True,'unary_regions_verified':unary_count,'unary_planes_verified':unary_planes,'empty_site_implications_verified':mask_links,'pair_regions_verified':pair_count,'pair_planes_verified':pair_planes,'pair_geometry_marginals_verified':marginals,'disabled_region_empty_clauses_verified':false_clauses,'same_family_order_constraints_verified':11,'all_model_fields_exhaustively_verified':True,'binary_and_text_models_identical':True,'all105_empty_site_pairs_represented':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
