"""Verify all210 exact convex intersections and source-boundary cancellation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';SOURCE=ROOT/'output/h5-source-projection-short11-20261029';PRE=BASE/'core-teeth-partition-preflight';OUT=PRE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum((a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])),F(0))/2 if p else F(0)
def intersection(subject,clip):
    subject=subject[:]
    for a,b in zip(clip,clip[1:]+clip[:1]):
        old=subject;subject=[]
        if not old:break
        for p,q in zip(old,old[1:]+old[:1]):
            dp,dq=cross(a,b,p),cross(a,b,q);ip,iq=dp>=0,dq>=0
            if ip:subject.append(p)
            if ip!=iq:
                t=dp/(dp-dq);subject.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return subject
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(PRE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);source=[tuple(map(F,p)) for p in next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer']];data=load(PRE/'partition.json');assert [tuple(map(F,p)) for p in data['source_outer_binary_rationals']]==source;pieces=[];boundary=Counter();expected=Counter(zip(source,source[1:]+source[:1]))
for record in data['pieces']:
    p=[tuple(map(F,v)) for v in record['vertices']];assert p==[source[i] for i in record['source_vertex_indices']] and area(p)==F(record['exact_area_mm2'])>0 and all(cross(a,b,c)>0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2]));pieces.append(p);boundary.update(zip(p,p[1:]+p[:1]))
assert len(pieces)==21 and len(pieces[0])==40 and all(len(p)==4 for p in pieces[1:]);intersections=0
for a,b in combinations(pieces,2):assert area(intersection(a,b))==0;intersections+=1
cancelled=0
for a,b in list(boundary):
    opposite=(b,a)
    if boundary[a,b] and boundary[opposite]:n=min(boundary[a,b],boundary[opposite]);boundary[a,b]-=n;boundary[opposite]-=n;cancelled+=n
assert +boundary==expected and cancelled==20 and sum((area(p) for p in pieces),F(0))==area(source)==F(data['exact_source_area_mm2']) and intersections==210
inv=load(SOURCE/'preflight/inventory.json');short=list(map(tuple,inv['short11_identities']));first=list(map(tuple,inv['mandatory_first55_identities']));allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};assert len(short)==11 and len(first)==55 and not set(short)&set(first) and set(short+first)==allids;counts=[2 if family=='bracket' else 1 if family=='insert' else 21 for family,copy in short];pairs=sum(a*b for a,b in combinations(counts,2));assert sum(counts)==56 and pairs==1115
inputs=[Path(__file__),JOB,PRE/'plan.json',PRE/'partition.json',PRE/'checks.json',SOURCE/'preflight/inventory.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_vertices_matched_exactly':80,'strictly_convex_pieces_verified':21,'exact_pair_intersections_zero_area':210,'internal_edges_cancelled_exactly':20,'remaining_boundary_equals_all80_source_edges':True,'exact_source_area_preserved':True,'all11_short_and55_first_identities_verified':True,'short11_total_convex_pieces':56,'short11_inter_original_piece_pairs':1115,'old_piece_pairs':8726,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
