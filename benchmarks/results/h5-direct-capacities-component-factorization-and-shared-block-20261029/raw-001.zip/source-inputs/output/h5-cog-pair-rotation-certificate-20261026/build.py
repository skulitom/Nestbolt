"""Build full-circle horizontal-segment certificates for a stronger cog separation bound."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,LineString
from shapely.affinity import rotate
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-rotation-independent-geometry-20261026';SCREEN=ROOT/'output/h5-cog-pair-rotation-screen-20261026';OUT=ROOT/'output/h5-cog-pair-rotation-certificate-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[SRC/'original-cog-proof.json',SRC/'audit/checks.json',SCREEN/'plan.json',SCREEN/'result.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_seconds':120,'phase_cells':720,'phase_half_width_radians_rational':[1091,250000],'target_separation_units1000':254300,'section_levels_units1000':list(range(-40000,40001,500)),'segment_endpoint_rounding_units_per_mm':1000,'inverse_endpoint_rounding_units_per_mm':1000000000,'audit_capsule_radius_mm_rational':[123,200],'method':'Build candidate horizontal source-contained segments for all720 half-degree rotation cells over the full circle, with no assumed rotational symmetry. Floating GEOS erosion0.62mm only proposes endpoints. Round them inward another0.001mm and store inverse-midpoint endpoints on a nanometre grid. For every720x720 phase-cell pair retain one common-Y right/left segment witness whose summed reach exceeds254.3mm. Independent integer capsule containment and rational trig error checks must certify each used segment for every angle in its cell; exact coverage of[0,2pi] and all518400 pairs is mandatory. No solver call and no formal bound before audit.'})
p=load(SRC/'original-cog-proof.json');g=Polygon([(a/b,c/d) for (a,b),(c,d) in p['centered_vertices_rational']]);ys=list(range(-40000,40001,500));left=[];right=[];phases=[]
for k in range(720):
    angle=math.radians((k+.5)*.5);phases.append(angle);shape=rotate(g,angle,use_radians=True,origin=(0,0)).buffer(-.62);ls=[];rs=[]
    for yy in ys:
        y=yy/1000;section=shape.intersection(LineString([(-150,y),(150,y)]));parts=[section] if section.geom_type=='LineString' else list(section.geoms);s=next(t for t in parts if t.bounds[0]<=0<=t.bounds[2]);ls.append(math.ceil(s.bounds[0]*1000)+1);rs.append(math.floor(s.bounds[2]*1000)-1)
    left.append(ls);right.append(rs);assert time.perf_counter()-start<120
left=np.asarray(left,dtype=np.int64);right=np.asarray(right,dtype=np.int64);best=np.full((720,720),-1,dtype=np.int64);witness=np.zeros((720,720),dtype=np.uint8)
for j,y in enumerate(ys):
    candidate=right[:,j,None]-left[None,:,j];mask=candidate>best;best[mask]=candidate[mask];witness[mask]=j
assert int(best.min())>=254300;used=[]
for k,angle in enumerate(phases):
    c,s=math.cos(angle),math.sin(angle)
    for side,js in [('right',sorted(set(map(int,witness[k,:])))),('left',sorted(set(map(int,witness[:,k]))))]:
        for j in js:
            x=int((right if side=='right' else left)[k,j]);y=ys[j];points=[(0,y/1000),(x/1000,y/1000)];q=[[round((c*u+s*v)*10**9),round((-s*u+c*v)*10**9)] for u,v in points];used.append({'phase':k,'side':side,'level':j,'endpoint_units1000':[x,y],'inverse_segment_endpoints_units1e9':q})
write(OUT/'phases-radians.json',phases);write(OUT/'segments.json',used);(OUT/'pair-witness-levels.bin').write_bytes(witness.tobytes(order='C'));write(OUT/'result.json',{'seconds':time.perf_counter()-start,'phase_cells':720,'phase_pairs':720**2,'used_segment_certificates':len(used),'minimum_pair_reach_units1000':int(best.min()),'proposed_separation_units1000':254300,'exact_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
