"""Independent exact source/hull, no-fit and 4D coverage audit of the joint core bound."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
from h5_continuous_core_certificate_reader_20261028 import cross,contains
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-joint-core-20261028';OUT=BASE/'audit';INV=ROOT/'output/h5-short-fixed10-inventory-20261028';ADJ=ROOT/'output/h5-short-adjacent-exchange-20261028';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def parity(p,vv):
    n=0
    for a,b in zip(vv,vv[1:]+vv[:1]):
        if min(a[1],b[1])<=p[1]<max(a[1],b[1]):n+=int(a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])>p[0])
    return n%2==1
def hits(a,b,r):
    low,high=F(0),F(1)
    for k in [0,1]:
        delta=b[k]-a[k]
        if delta==0:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            u,v=sorted(((r[k]-a[k])/delta,(r[k+2]-a[k])/delta));low=max(low,u);high=min(high,v)
            if low>high:return False
    return True
def source(points,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1
    return [tuple(F(str(v)) for v in (sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1])) for x,y in points]
def corners(r):return [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]
def verify_polygon(poly,expected):
    pp=list(map(tuple,poly));expected=set(expected);assert len(pp)>=3 and len(set(pp))==len(pp) and all(type(v)==int for p in pp for v in p)
    assert all(p in expected for p in pp)
    for a,b in zip(pp,pp[1:]+pp[:1]):assert all(cross(a,b,p)>0 for p in pp if p not in (a,b))
    assert all(contains(pp,p) for p in expected)
    return len(expected)
def projected(point,kind):
    if kind=='fixed0':return point[:2]
    if kind=='fixed1':return point[2:]
    assert kind=='pair';return [point[2]-point[0],point[3]-point[1]]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for file in [BASE/'plan.json',INV/'audit/plan.json',BOUND/'audit/plan.json']:
    for n,h in load(file)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(INV/'audit/checks.json')['passed'] and load(BOUND/'audit/checks.json')['passed'] and load(ADJ/'response-audit/checks.json')['passed']
job=load(JOB);parts={p['id']:p for p in job['parts']};assert parts['cog']['rotations']['kind']=='free' and parts['bracket']['rotations']=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]} and parts['bracket']['allow_mirror']
coredata=load(BOUND/'moving-core.json');core=coredata['vertices_um'];center=list(map(F,coredata['source_center_mm']));hull=load(BASE/'stock-hull-core.json');hh=[tuple(map(F,p)) for p in hull['hull_vertices_mm']];vv=[tuple(F(str(v)) for v in p) for p in parts['cog']['geometry'][0]['outer']]
assert list(map(F,hull['source_center_mm']))==center and all(p in vv for p in hh) and len(set(hh))==len(hh) and hull['used_for_stock_only']
ds=[]
for a,b in zip(hh,hh[1:]+hh[:1]):
    assert all(cross(a,b,p)>0 for p in hh if p not in (a,b)) and all(cross(a,b,p)>=0 for p in vv)
    d=cross(a,b,center);assert d>0;ds.append(d*d/((b[0]-a[0])**2+(b[1]-a[1])**2))
assert min(ds)==F(hull['minimum_hull_edge_distance_squared_mm2']);radius=hull['contained_hull_disk_radius_um'];assert type(radius)==int and F(radius*radius,1000000)<min(ds)
st=[F(str(v)) for v in load(OLD/'plan.json')['source_stock']];cb=hull['relaxed_cog_center_bounds_um']
assert cb[0]<=st[0]*1000+radius and cb[1]<=st[1]*1000+radius and cb[2]>=st[2]*1000-radius and cb[3]>=st[3]*1000-radius
modes=load(ADJ/'modes.json');br=load(BASE/'bracket-cores.json');assert [r['mode'] for r in br]==list(range(36,44));legal=set();brchecks=0
for row in br:
    m=modes[row['mode']];q=round(m['angle']/(math.pi/2));assert q in range(4) and abs(m['angle']-q*math.pi/2)<1e-12;legal.add((q,m['mirrored']))
    t={'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']};p=source(parts['bracket']['geometry'][0]['outer'],t);assert Polygon(p).is_valid
    for r in row['rectangles_um']:
        assert all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3];rr=[F(v,1000) for v in r]
        assert all(parity(c,p) for c in corners(rr))
        for a,b in zip(p,p[1:]+p[:1]):assert not hits(a,b,rr);brchecks+=1
    bb=row['relaxed_anchor_bounds_um'];assert bb[0]<=st[0]*1000-min(v[0] for v in p)*1000 and bb[1]<=st[1]*1000-min(v[1] for v in p)*1000 and bb[2]>=st[2]*1000-max(v[0] for v in p)*1000 and bb[3]>=st[3]*1000-max(v[1] for v in p)*1000
assert legal=={(q,mi) for q in range(4) for mi in [False,True]};bc={r['mode']:r for r in br};fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};result=load(BASE/'result.json');expected={('38',i) for i in range(36,44)}|{(s['geometry_case'],None) for s in load(INV/'case-summary.json') if not s['all_angle_additional_cog_excluded'] and s['geometry_case']!='38'};seen_specs=set();casechecks=[];sums=planes=0
for summary in result['cases']:
    name=summary['case'];data=load(BASE/'cases'/f'{name}-inputs.json');gi=data['geometry_case'];mi=data['second_mover_bracket_mode'];spec=(gi,mi);assert spec in expected and spec not in seen_specs;seen_specs.add(spec)
    case=load(INV/'cases'/f'{gi}.json');rr=[r for p in case['fixed10'] for r in fixed[key(p)]];obs=data['obstacles'];expected_obs=[]
    for r in rr:expected_obs.append(('fixed0',[(x-u,y-v) for x,y in corners(r) for u,v in core]))
    if mi is None:
        for r in rr:expected_obs.append(('fixed1',[(x-u,y-v) for x,y in corners(r) for u,v in core]))
        expected_obs.append(('pair',[(u[0]-v[0],u[1]-v[1]) for u in core for v in core]));bb=cb
        assert ['cog',14] in case['removed_parent_identities']
    else:
        moving=bc[mi]['rectangles_um'];bb=bc[mi]['relaxed_anchor_bounds_um'];assert case['removed_parent_identities']==[['bracket',10],['bracket',11]]
        for r in rr:
            for m in moving:expected_obs.append(('fixed1',[(x-u,y-v) for x,y in corners(r) for u,v in corners(m)]))
        for m in moving:expected_obs.append(('pair',[(u-x,v-y) for u,v in core for x,y in corners(m)]))
    assert len(expected_obs)==len(obs)
    for (kind,points),o in zip(expected_obs,obs):assert kind==o['kind'];sums+=verify_polygon(o['vertices_um'],points)
    bounds=[cb[0],cb[1],bb[0],bb[1],cb[2],cb[3],bb[2],bb[3]];assert bounds==data['bounds_um'];cert=load(BASE/'cases'/f'{name}-certificate.json');nodes=cert['nodes'];visited=set();leaves=[]
    def visit(idx,bounds,depth):
        global planes
        assert type(idx)==int and 0<=idx<len(nodes) and idx not in visited;visited.add(idx);node=nodes[idx];r=list(map(F,node['bounds_um']));assert r==bounds and node['depth']==depth and depth<=40
        if 'covered_by' in node:
            assert set(node)=={'bounds_um','depth','covered_by'};oi=node['covered_by'];assert type(oi)==int and 0<=oi<len(obs);o=obs[oi]
            # All16 actual hyperrectangle corners, not the constructor's projected-box shortcut.
            for p in product(*[(r[k],r[k+4]) for k in range(4)]):
                q=projected(p,o['kind']);assert contains(o['vertices_um'],q);planes+=len(o['vertices_um'])
            leaves.append(idx)
        else:
            assert set(node)=={'bounds_um','depth','split_axis','left','right'};axis=max(range(4),key=lambda k:r[k+4]-r[k]);assert node['split_axis']==axis
            mid=(r[axis]+r[axis+4])/2;a=r[:];b=r[:];a[axis+4]=mid;b[axis]=mid;visit(node['left'],a,depth+1);visit(node['right'],b,depth+1)
    visit(0,list(map(F,bounds)),0)
    assert len(visited)==len(nodes)==summary['nodes'] and len(nodes)<=50000 and cert['covered'] and summary['covered'] and cert['limit'] is None and cert['relaxation_witness_um'] is None and cert['unprocessed_boxes']==0
    casechecks.append({'case':name,'source_case':gi,'bracket_mode':mi,'exact_nodes':len(nodes),'covered_hyperrectangle_leaves':len(leaves),'all_continuous_joint_core_placements_excluded':True})
assert seen_specs==expected and len(casechecks)==result['covered_cases']==result['necessary_joint_cases']==14 and result['seconds']<120
# Positive source pair confirms stock and cog/cog no-fit direction; coincident cores are rejected.
sourceplan=load(OLD/'plan.json');positive=[]
for i,xy in enumerate([(200.,160.),(1200.,160.)]):positive.append({'part_id':'cog','copy_index':i,'sheet_id':'sheet-1','transform':{'rotation_radians':0.,'mirrored':False,'translation':[xy[k]-float(center[k]) for k in [0,1]]}})
control=audit(job,positive,{'sheet-1':sourceplan['source_stock']},sourceplan['required_pair_gap_mm'],sourceplan['stock_guard_mm'],[('cog',0),('cog',1)]);assert control['valid'];write(OUT/'positive-source-cog-pair.json',control)
pairpoly=next(o['vertices_um'] for o in load(BASE/'cases/05-cog-inputs.json')['obstacles'] if o['kind']=='pair')
assert not contains(pairpoly,[1000000,0]) and contains(pairpoly,[0,0]) and all(cb[0]<=x<=cb[2] and cb[1]<=y<=cb[3] for x,y in [(200000,160000),(1200000,160000)])
# A real existing cog/bracket pair passes when removed from the fixed obstacles, proving relative signs.
parent=load(ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight/parent-source12.json');cg=next(p for p in parent if key(p)==('cog',14));bp=next(p for p in parent if key(p)==('bracket',11));m=modes[41];assert bp['transform']['rotation_radians']==m['angle'] and bp['transform']['mirrored']==m['mirrored']
pc=[(center[k]+F(str(cg['transform']['translation'][k])))*1000 for k in [0,1]];pb=[(F(str(bp['transform']['translation'][k]))-F(str(m['source_translation_offset'][k])))*1000 for k in [0,1]]
pairpolys=[o['vertices_um'] for o in load(BASE/'cases/38-br41-inputs.json')['obstacles'] if o['kind']=='pair'];assert all(not contains(p,[pb[0]-pc[0],pb[1]-pc[1]]) for p in pairpolys)
proof={'hull_stock_bound':'Every convex hull vertex is an original source vertex, all source vertices satisfy its exact inward half-planes, and exact rational distances prove a disk of the declared radius lies inside that hull. Rotation preserves the disk. Any original cog inside a rectangular stock has its convex hull inside the stock too; therefore its center must satisfy these necessary bounds at every angle. This larger disk is used only for stock, never as collision-filled geometry.',
 'collision_cores':'The smaller filled-source cog core and all fixed-source rectangles retain their previously verified hashes. Every new bracket rectangle is strictly source-contained by exact corner parity and edge clipping. Exact convex no-fit polygons are reconstructed from all vertex differences. The pair predicate uses second anchor minus first center; its sign and the cog-pair predicate pass positive source controls and an occupied-center negative control.',
 'coverage':'Each four-dimensional root contains all possible continuous center/anchor combinations. Every child pair exactly partitions its parent rational hyperrectangle. All16 actual leaf vertices satisfy one convex forbidden predicate, so the entire leaf is forbidden. Every node is reached once, and all leaves are covered. All eight legal bracket rotation/mirror modes are included; both cog angles remain arbitrary real values.',
 'combined_scope':'The single-cog bound excludes44 of51 distinct fixed-ten geometries (58 of66 identity variants). This joint bound excludes the remaining seven geometries (eight variants): the adjacent-bracket case in all eight bracket modes, and six cases requiring two moving cogs. Thus no proposed target13 short-sheet completion can retain ten of these twelve exact parent poses while releasing one bracket to the first sheet. This allocation must change at least three parent poses, or use a different parent/arrangement. The5-bracket/6-insert/2-cog allocation and the original66-part job remain unexcluded.'}
write(OUT/'necessity-proof.json',proof);write(OUT/'case-checks.json',casechecks)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_continuous_core_certificate_reader_20261028.py',BASE/'plan.json',INV/'audit/plan.json',BOUND/'audit/plan.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'cog_hull_vertices':len(hh),'hull_stock_disk_radius_um':radius,'exact_bracket_source_edge_checks':brchecks,'legal_bracket_modes':8,'joint_cases':14,'exact_no_fit_vertex_sums':sums,'exact_hyperrectangle_nodes':sum(c['exact_nodes'] for c in casechecks),'covered_hyperrectangle_leaves':sum(c['covered_hyperrectangle_leaves'] for c in casechecks),'exact_leaf_vertex_plane_checks':planes,'all14_continuous_joint_cases_excluded':True,'combined_fixed10_geometries_excluded':51,'combined_identity_variants_excluded':66,'minimum_parent_poses_that_must_change':3,'positive_source_cog_pair_passed':True,'positive_existing_cog_bracket_pair_passed':True,'negative_coincident_cog_centers_rejected':True,'full_allocation_or_original_job_excluded':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
