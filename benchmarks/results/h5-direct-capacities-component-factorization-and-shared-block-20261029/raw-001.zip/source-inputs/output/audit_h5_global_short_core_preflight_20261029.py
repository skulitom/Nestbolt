"""Independent source-mode, symbolic no-fit facet and rounding audit for short13."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
from math import gcd
import json,math,shutil,time
from shapely.geometry import Polygon,MultiPoint,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';OUT=BASE/'audit';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';JOINT=ROOT/'output/h5-short-joint-core-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def independent_hull(points):
    vv=list(MultiPoint(points).convex_hull.exterior.coords)[:-1];assert all(float(v).is_integer() for p in vv for v in p);vv=[tuple(int(v) for v in p) for p in vv]
    if sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(vv,vv[1:]+vv[:1]))<0:vv.reverse()
    assert all(v in points for v in vv)
    for a,b in zip(vv,vv[1:]+vv[:1]):assert all(cross(a,b,p)>=0 for p in points) and all(cross(a,b,p)>0 for p in vv if p not in (a,b))
    facets={}
    for a,b in zip(vv,vv[1:]+vv[:1]):
        nx,ny=b[1]-a[1],a[0]-b[0];d=gcd(abs(nx),abs(ny));nx//=d;ny//=d;facets[nx,ny]=nx*a[0]+ny*a[1]
    return vv,facets
def parity(point,vv):
    n=0
    for a,b in zip(vv,vv[1:]+vv[:1]):
        if min(a[1],b[1])<=point[1]<max(a[1],b[1]):n+=int(a[0]+(point[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])>point[0])
    return n%2==1
def hits(a,b,r):
    lo,hi=F(0),F(1)
    for k in [0,1]:
        d=b[k]-a[k]
        if d==0:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            u,v=sorted(((r[k]-a[k])/d,(r[k+2]-a[k])/d));lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for file in [BASE/'plan.json',JOINT/'audit/plan.json']:
    for n,h in load(file)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(JOINT/'audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};inventory=load(BASE/'inventory.json');short=set(map(tuple,inventory['short13_identities']));first=set(map(tuple,inventory['mandatory_first53_identities']));allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};assert len(short)==13 and len(first)==53 and not short&first and short|first==allids
assert Counter(k[0] for k in short)=={'bracket':5,'insert':6,'cog':2} and Counter(k[0] for k in first)=={'frame':18,'bracket':7,'insert':15,'cog':13}
coredata=load(BASE/'cog-core.json');assert coredata==load(OLD/'all-angle-bound/moving-core.json');core=coredata['vertices_um'];center=list(map(F,coredata['source_center_mm']));cb=inventory['cog_center_stock_bounds_um'];hull=load(JOINT/'stock-hull-core.json');assert cb==hull['relaxed_cog_center_bounds_um'];stock=list(map(lambda v:F(str(v)),load(OLD/'plan.json')['source_stock']));radius=hull['contained_hull_disk_radius_um']
assert cb[0]<=stock[0]*1000+radius-F(1,2) and cb[1]<=stock[1]*1000+radius-F(1,2) and cb[2]>=stock[2]*1000-radius+F(1,2) and cb[3]>=stock[3]*1000-radius+F(1,2)
assert F(708,1000)**2>F(1,2) and F(str(load(OLD/'plan.json')['required_pair_gap_mm']))*1000>2*F(708,1000)
modes=load(BASE/'orthogonal-modes.json');seen=set();edges=rectcount=0;rectangles=[]
for m in modes:
    family=m['family'];q=m['quarter'];mir=m['mirrored'];assert (family,q,mir) not in seen;seen.add((family,q,mir));assert m['angle']==q*math.pi/2 and (not mir or parts[family]['allow_mirror'])
    c,s=math.cos(m['angle']),math.sin(m['angle']);sign=-1 if mir else 1;raw=[(sign*x*c-y*s,sign*x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']];offset=[-min(p[k] for p in raw) for k in [0,1]];assert offset==m['source_translation_offset'];vv=[(x+offset[0],y+offset[1]) for x,y in raw];assert [list(v) for v in vv]==m['source_outer'];exact=[tuple(F(str(v)) for v in p) for p in vv]
    for r in m['rectangles_um']:
        assert all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3];er=[F(v,1000) for v in r]
        for p in [(er[0],er[1]),(er[2],er[1]),(er[2],er[3]),(er[0],er[3])]:assert parity(p,exact)
        for a,b in zip(exact,exact[1:]+exact[:1]):assert not hits(a,b,er);edges+=1
        rectangles.append(r);rectcount+=1
    assert len(m['rectangles_um'])==(2 if family=='bracket' else 1)
    bb=m['anchor_stock_bounds_um'];assert bb[0]<=stock[0]*1000-min(p[0] for p in exact)*1000-F(1,2) and bb[1]<=stock[1]*1000-min(p[1] for p in exact)*1000-F(1,2) and bb[2]>=stock[2]*1000-max(p[0] for p in exact)*1000+F(1,2) and bb[3]>=stock[3]*1000-max(p[1] for p in exact)*1000+F(1,2)
assert seen=={('bracket',q,mir) for q in range(4) for mir in [False,True]}|{('insert',q,False) for q in range(4)} and rectcount==20
rf=load(BASE/'cog-rectangle-facets.json');normals={tuple(f['normal']):f['negative_cog_support'] for f in rf};assert len(normals)==len(rf)==36
checks=[];sums=0
for r in rectangles:
    points={(x-u,y-v) for x,y in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])] for u,v in core};poly,actual=independent_hull(points);assert set(actual)==set(normals)
    for (nx,ny),support in actual.items():assert normals[nx,ny]==max(-nx*x-ny*y for x,y in core) and support==nx*(r[2] if nx>=0 else r[0])+ny*(r[3] if ny>=0 else r[1])+normals[nx,ny]
    sums+=len(points);checks.append({'rectangle_um':r,'complete_facet_directions':len(actual),'variable_rectangle_support_formula_exact':True})
cgpoints={(x-u,y-v) for x,y in core for u,v in core};cgpoly,cgfacets=independent_hull(cgpoints);pf=load(BASE/'cog-pair-facets.json');assert {tuple(f['normal']):f['support'] for f in pf}==cgfacets and set(map(tuple,load(BASE/'cog-pair-no-fit.json')))==set(cgpoly)
# Read saved source controls independently and check their rounded core representations geometrically.
controls=[]
for name in ['positive','negative']:
    count=11 if name=='positive' else 13;source=load(BASE/f'{name}-source{count}.json');mapped=load(BASE/f'{name}-model{count}.json');assert len(source)==len(mapped)==count;source_shapes=[];core_shapes=[];mode_by_key={(m['family'],m['quarter'],m['mirrored']):m for m in modes}
    for p,r in zip(source,mapped):
        assert r['identity']==[p['part_id'],p['copy_index']] and tuple(r['identity']) in short;t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;family=p['part_id'];actual=Polygon([(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in parts[family]['geometry'][0]['outer']]);assert actual.is_valid;source_shapes.append(actual)
        if family=='cog':
            expected=[round((float(center[0])*c-float(center[1])*s+t['translation'][0])*1000),round((float(center[0])*s+float(center[1])*c+t['translation'][1])*1000)];assert r['anchor_um']==expected and r['stock_bounds_um']==cb;core_shapes.append((family,[Polygon([(x+expected[0],y+expected[1]) for x,y in core])]))
        else:
            q=round(t['rotation_radians']/(math.pi/2))%4;m=mode_by_key[family,q,t['mirrored']];expected=[round((t['translation'][k]-m['source_translation_offset'][k])*1000) for k in [0,1]];assert r['anchor_um']==expected and r['mode']==m['mode'] and r['stock_bounds_um']==m['anchor_stock_bounds_um'];rr=[[a+expected[0],b+expected[1],c+expected[0],d+expected[1]] for a,b,c,d in m['rectangles_um']];assert rr==r['rectangles_um'];core_shapes.append((family,[box(*v) for v in rr]))
        x,y=r['anchor_um'];a,b,c,d=r['stock_bounds_um'];assert a<=x<=c and b<=y<=d
    sourcebad=0;bad={'orthogonal_piece_pairs':0,'cog_rectangle_pairs':0,'cog_pair':0}
    for a,b in combinations(source_shapes,2):sourcebad+=int(not a.disjoint(b) or a.distance(b)<=float(load(OLD/'plan.json')['required_pair_gap_mm']))
    for (fa,aa),(fb,bb) in combinations(core_shapes,2):
        label='cog_pair' if fa==fb=='cog' else 'cog_rectangle_pairs' if 'cog' in [fa,fb] else 'orthogonal_piece_pairs'
        for a in aa:
            for b in bb:bad[label]+=int(not a.disjoint(b))
    saved=load(BASE/'controls.json')
    if name=='positive':assert sourcebad==0 and not any(bad.values()) and len(short-set(map(lambda p:(p['part_id'],p['copy_index']),source)))==2
    else:assert sourcebad==saved['negative_source_pair_failures']>0 and all(bad[k]==saved['negative_core_failures'][k]>0 for k in bad)
    controls.append({'name':name,'originals':count,'independent_source_failed_pairs':sourcebad,'independent_core_collisions':bad})
write(OUT/'facet-checks.json',checks);write(OUT/'control-checks.json',controls);inputs=[Path(__file__),BASE/'plan.json',JOINT/'audit/plan.json']+[p for p in BASE.glob('*.json')];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all13_short_and53_first_original_identities_verified':True,'all8_bracket_and4_insert_modes_verified':True,'exact_source_contained_mode_rectangles':20,'exact_source_edge_checks':edges,'complete_cog_rectangle_no_fit_polygons':20,'exact_cog_rectangle_vertex_sums':sums,'all36_symbolic_cog_rectangle_facet_formulas_verified':True,'complete_cog_pair_facet_formulas':len(cgfacets),'source_to_integer_core_mapping_proved_with_positive_gap_and_expanded_stock':True,'original_source_controls_independently_read':2,'unexercised_candidate_identity_bug_not_reused':True,'CP_model_created':False,'search_opened':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
