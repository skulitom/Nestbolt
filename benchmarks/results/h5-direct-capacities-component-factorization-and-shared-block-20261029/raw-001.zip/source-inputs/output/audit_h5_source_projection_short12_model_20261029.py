"""Independently audit the exact delta and every dependency of the inactive owner."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_source_projection_short_core_reader_20261029 import violations
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-source-projection-short-core-20261029';BASE=ROOT/'output/h5-source-projection-short12-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit';PRE=OLD/'next-short12-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def variables(message):
    out=set()
    for field,value in message.ListFields():
        if field.name in ['vars','literals','enforcement_literal']:out.update(i if i>=0 else -i-1 for i in value)
        elif field.message_type:
            for item in value if field.is_repeated else [value]:out.update(variables(item))
    return out
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,OLD/'model-audit',PRE]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'model-audit/checks.json')['passed'] and load(PRE/'checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model-v3/model.pb').read_bytes());mp=load(MODEL/'mapping.json');om=load(OLD/'model-v3/mapping.json');pos=load(MODEL/'positive-control-assignment.json');neg=load(MODEL/'negative-assignment.json');op=load(OLD/'model-v3/positive-control-assignment.json');on=load(OLD/'model-v3/negative-assignment.json');inv=load(PRE/'inventory.json')
assert len(p.variables)==1876 and len(p.constraints)==1913;assert [i for i,(a,b) in enumerate(zip(p.constraints,old.constraints)) if a!=b]==[112]
c=p.constraints[112];assert not c.enforcement_literal and list(c.linear.vars)==[146] and list(c.linear.coeffs)==[1] and list(c.linear.domain)==[0,0] and {f.name for f,v in c.ListFields()}=={'linear'}
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(p);restored.constraints[112].CopyFrom(old.constraints[112]);assert restored==old
restoredmp=json.loads(json.dumps(mp));assert restoredmp.pop('inactive_short_identity')==['insert',0] and restoredmp.pop('inactive_short_owner')==7;assert restoredmp.pop('short12_identities')==inv['short12_identities'];first=restoredmp.pop('mandatory_first54_identities');assert first==inv['mandatory_first54_identities'] and first[-1]==['insert',0];restoredmp['mandatory_first53_identities']=first[:-1];assert restoredmp['control_disabled_mandatory_constraints']==[110];restoredmp['control_disabled_mandatory_constraints']=[110,112];assert restoredmp==om
assert pos==op and [i for i,(a,b) in enumerate(zip(neg,on)) if a!=b]==[146] and neg[146]==pos[146]==0
short=set(map(tuple,inv['short12_identities']));first=set(map(tuple,first));job=load(JOB);allids={(part['id'],i) for part in job['parts'] for i in range(part['quantity'])};assert len(short)==12 and len(first)==54 and not short&first and short|first==allids and Counter(a for a,b in short)=={'bracket':5,'insert':5,'cog':2} and Counter(a for a,b in first)=={'frame':18,'bracket':7,'insert':16,'cog':13}
for item in mp['items']:
    c=p.constraints[item['mandatory']];expected=0 if item['identity']==['insert',0] else 1;assert not c.enforcement_literal and list(c.linear.vars)==[item['presence']] and list(c.linear.coeffs)==[1] and list(c.linear.domain)==[expected,expected]
item=mp['items'][7];assert item['identity']==['insert',0];dummy={item['presence'],item['x'],item['y'],item['mode'],*item['stock_variables']}
for piece in item['pieces']:dummy.update(piece['local_variables']);dummy.update(piece['world_variables'])
reference=mp['projection_items'][7];assert reference['owner']==7;dummy.update([reference['reference_x'],reference['variant'],*reference['selected_fields']])
interval=next(r for r in mp['insert_projection_intervals'] if r['owner']==7);dummy.add(interval['end']);pair_tables={}
for pair in mp['projection_pairs']:
    if 7 in pair['owners']:dummy.update([pair['forward'],pair['backward'],pair['order']]);pair_tables[pair['distance_table']]=pair
for pair in mp['facet_pairs']:
    if 7 in [pair['left'],pair['right']]:dummy.update(f['selector'] for f in pair['facets'])
classified=[];global_intervals=[];cross_rows=0
for ix,c in enumerate(p.constraints):
    kind=c.WhichOneof('constraint');used=variables(c);touch=bool(used&dummy)
    if kind in ['no_overlap_2d','cumulative']:
        lists=[list(c.no_overlap_2d.x_intervals),list(c.no_overlap_2d.y_intervals)] if kind=='no_overlap_2d' else [list(c.cumulative.intervals)]
        found=[]
        for ids in lists:
            for k,j in enumerate(ids):
                ci=p.constraints[j];assert ci.WhichOneof('constraint')=='interval'
                if variables(ci)&dummy:
                    assert list(ci.enforcement_literal)==[146] and variables(ci)<=dummy;found.append(j)
                    if kind=='cumulative':assert variables(c.cumulative.demands[k])<=dummy
        if found:global_intervals.append({'constraint':ix,'kind':kind,'inactive_intervals':found})
        if touch:assert found and kind=='cumulative'
        continue
    if not touch:continue
    if ix==112:classification='explicit first-sheet transfer'
    elif 146 in c.enforcement_literal:classification='disabled by inactive owner'
    elif kind=='bool_or' and -147 in c.bool_or.literals:classification='true because owner absent'
    elif used<=dummy:classification='local dummy assignment independent of every active owner'
    elif ix in pair_tables:
        pair=pair_tables[ix];assert kind=='table' and not c.enforcement_literal and not c.table.negated and len(c.table.exprs)==4
        vv=[]
        for e in c.table.exprs:assert len(e.vars)==1 and list(e.coeffs)==[1] and not e.offset;vv.append(e.vars[0])
        refs=[mp['projection_items'][k] for k in pair['owners']];assert vv==[refs[0]['variant'],refs[1]['variant'],pair['forward'],pair['backward']];which=pair['owners'].index(7);other=1-which;rows=[list(c.table.values[k:k+4]) for k in range(0,len(c.table.values),4)];fixed=pos[vv[which]]
        assert set(r[other] for r in rows if r[which]==fixed)==set(refs[other]['profile_ids'])
        for row in rows:
            for vi,value in zip(vv,row):assert any(lo<=value<=hi for lo,hi in zip(p.variables[vi].domain[::2],p.variables[vi].domain[1::2]))
        cross_rows+=len(rows);classification='complete active-mode table; dummy distance auxiliaries freely extend each row'
    else:raise AssertionError((ix,kind,sorted(used&dummy),sorted(used-dummy)))
    classified.append({'constraint':ix,'kind':kind,'classification':classification})
assert len(pair_tables)==12 and len(global_intervals)==5
# Existing positive dummy assignments satisfy all own constraints and domains.
positive=violations(p,pos);relaxed=violations(p,pos,[110]);negative=violations(p,neg);assert [r['constraint'] for r in positive['failed_constraints']]==[110] and not relaxed['failed_constraints'];assert negative['failed_constraints'] and positive['cumulative_checks'][-1]['peak_demand']==2 and negative['cumulative_checks'][-1]['peak_demand']==5
for r in classified:
    if r['classification'].startswith('local dummy'):assert r['constraint'] not in {a['constraint'] for a in positive['failed_constraints']}
write(OUT/'inactive-owner-proof.json',{'dummy_variables':sorted(dummy),'classified_constraints':classified,'global_optional_interval_uses':global_intervals,'cross_pair_tables':len(pair_tables),'cross_pair_table_rows_checked':cross_rows,'argument':'Take any source-feasible short12 layout and use the previously proved mappings for its12 active owners. The remaining original insert0 is required on first54. Assign its inactive local variables from the verified positive control. All cross geometry/order/reference inequalities are guarded off, global constraints ignore its optional intervals, and each cross pair table permits every active mode while freely choosing dummy distance auxiliaries. Thus the inactive slot cannot remove a source12 placement. Remaining within-family coarse-X orders follow by relabeling the12 active copies; no reference-X order is imposed. All other parent necessity arguments apply unchanged.'})
write(OUT/'controls.json',{'positive_full_target':positive,'positive_only_missing_cog0_disabled':relaxed,'negative_full_target':negative})
inputs=[Path(__file__),ROOT/'output/h5_source_projection_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',OLD/'model-audit/plan.json',OLD/'model-audit/checks.json',PRE/'plan.json',PRE/'checks.json',PRE/'inventory.json',JOB]+[MODEL/n for n in ['model.pb','model.pbtxt','mapping.json','positive-control-assignment.json','negative-assignment.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'all_model_fields_verified_by_exact_parent_comparison':True,'sole_changed_constraint':112,'all1876_variables_and1071_hints_unchanged':True,'other1912_constraints_unchanged':True,'all12_short_and54_first_identities_verified':True,'inactive_owner_extension_proved':True,'inactive_variables':len(dummy),'inactive_touching_constraints_classified':len(classified),'global_optional_interval_uses':len(global_intervals),'cross_pair_tables_complete':len(pair_tables),'cross_pair_rows_checked':cross_rows,'positive11_fails_only_missing_cog0':True,'positive11_with_only_cog0_requirement_disabled_passes':True,'negative12_failed_constraints':len(negative['failed_constraints']),'positive_insert_peak':2,'negative_insert_peak':5,'source12_mapping_necessary':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
