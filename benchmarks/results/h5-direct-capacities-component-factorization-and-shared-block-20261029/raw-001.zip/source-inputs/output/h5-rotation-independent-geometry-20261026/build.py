"""Necessary inner geometry for all continuous cog rotations and anchor rounding."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import Polygon,Point,box,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-rotation-independent-geometry-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    pts=sorted(set(points));lower=[];upper=[]
    for p in pts:
        while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    for p in pts[::-1]:
        while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
def distance2(a,b):
    v=(b[0]-a[0],b[1]-a[1]);n=v[0]**2+v[1]**2;t=max(F(0),min(F(1),-(a[0]*v[0]+a[1]*v[1])/n));return (a[0]+t*v[0])**2+(a[1]+t*v[1])**2
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240;source=load(SOURCE/'plan.json');originals=load(SOURCE/'profiles.json');job=load(JOB);cog=next(p for p in job['parts'] if p['id']=='cog');assert cog['rotations']['kind']=='free' and not cog['allow_mirror'];center=originals[9]['original_center'];pts=[(F(x)-F(center[0]),F(y)-F(center[1])) for x,y in cog['geometry'][0]['outer']];shape=Polygon([(float(x),float(y)) for x,y in pts]);assert len(pts)==80 and shape.is_valid and shape.contains(Point(0,0));outline_edges=list(zip(pts,pts[1:]+pts[:1]));convex=hull(pts);convex_edges=list(zip(convex,convex[1:]+convex[:1]));r2=min(distance2(a,b) for a,b in outline_edges);h2=min(distance2(a,b) for a,b in convex_edges);r0=math.isqrt(r2.numerator*1000000//r2.denominator);h0=math.isqrt(h2.numerator*1000000//h2.denominator);inner=r0-2
assert F(r0,1000)**2<=r2<F(r0+1,1000)**2 and F(h0,1000)**2<=h2<F(h0+1,1000)**2 and F(r0-inner,1000)**2>F(2,1000000)
stock=[F(*r) for r in source['stock_bounds_rational']];relaxed=[stock[0]-F(1,50),stock[1]-F(1,50),stock[2]+F(1,50),stock[3]+F(1,50)]
paths=[JOB,SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',ROOT/'output/h5-rectangle-direction-projection-20261026/response-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'construction_limit_seconds':240,'audit_limit_seconds':240,'coordinate_units_per_mm':1000,'stock_relaxation_mm':[1,50],'stock_bounds_rational':source['stock_bounds_rational'],'relaxed_stock_bounds_rational':[ratio(v) for v in relaxed],'cog_angles':'Every real angle, without finite sampling or phase flags','required_original_counts':{'bracket':4,'insert':1,'cog':4},'required_originals':[21,22,25,26,37,53,63,64,65],'method':'Use original filled outers, with part-in-part disabled. Prove a centered inscribed disk by exact distances to every original cog edge and origin containment; its radius minus2micrometres absorbs flooring both continuous anchor coordinates. Inscribe a fixed rational128-gon in that smaller disk, valid for every real cog rotation. Separately prove an inscribed disk in the original convex hull; this radius supplies necessary stock support in every direction, never a collision proxy. Rebuild all8 bracket and2 insert inner grid rectangles with2micrometre insets to absorb the same floor rounding. Use stock relaxed outward by0.020mm and outward-rounded integer anchor domains, with no finite-angle source stock guard or coefficient reuse. Construct exact rational Minkowski hulls for all10 non-cog/cog proxy pairs and the symmetric cog pair. Whole central forbidden rectangles provide necessary side bounds for all Y. Every full continuous stock-contained, filled-outer-disjoint placement maps to these inner subsets at integer anchors. No native acceptance claim or solver call.'})
write(OUT/'original-cog-proof.json',{'center':center,'centered_vertices_rational':[[ratio(x),ratio(y)] for x,y in pts],'edge_distance_squared_mm2':[ratio(distance2(a,b)) for a,b in outline_edges],'minimum_edge_distance_squared_mm2':ratio(r2),'original_inscribed_radius_units1000':r0,'quantization_safe_radius_units1000':inner,'convex_hull_vertices_rational':[[ratio(x),ratio(y)] for x,y in convex],'hull_edge_distance_squared_mm2':[ratio(distance2(a,b)) for a,b in convex_edges],'minimum_hull_distance_squared_mm2':ratio(h2),'all_angle_stock_support_radius_units1000':h0})
profiles=[];components={};bounds={}
for p in originals:
    if p['family']=='cog':continue
    poly=Polygon(p['vertices']);levels=[sorted({round(v[a]*1000) for v in p['vertices']}) for a in range(2)];rects=[]
    for xl,xh in zip(levels[0],levels[0][1:]):
        for yl,yh in zip(levels[1],levels[1][1:]):
            if not poly.contains(Point((xl+xh)/2000,(yl+yh)/2000)):continue
            b=[xl+2,yl+2,xh-2,yh-2];r=box(*(v/1000 for v in b));assert poly.contains(r) and r.distance(poly.boundary)>.00199999;rects.append(b)
    shapes=[box(*(v/1000 for v in b)) for b in rects];g=unary_union(shapes);profiles.append({'index':p['index'],'family':p['family'],'proxy':'quantization-safe inner rectangles','rectangles_units1000':rects,'geometry':mapping(g),'bounds':list(g.bounds),'original_bounds':p['bounds']});components[p['index']]=[[(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3])] for b in rects];ob=[F(v) for v in p['bounds']];bounds[str(p['index'])]=[math.floor((relaxed[a]-ob[a])*1000) for a in range(2)]+[math.floor((relaxed[a+2]-ob[a+2])*1000) for a in range(2)]
ring=[(math.trunc(inner*math.cos(2*math.pi*k/128)),math.trunc(inner*math.sin(2*math.pi*k/128))) for k in range(128)];ring=hull(ring);assert len(ring)==128 and all(x*x+y*y<=inner*inner for x,y in ring) and set(ring)=={(-x,-y) for x,y in ring};g=Polygon([(x/1000,y/1000) for x,y in ring]);profiles.append({'index':11,'family':'cog','proxy':'all-angle common inner128-gon','vertices_units1000':ring,'geometry':mapping(g),'bounds':list(g.bounds),'all_real_rotations':True});components[11]=[ring];bounds['11']=[math.floor(relaxed[a]*1000+ h0) for a in range(2)]+[math.floor(relaxed[a+2]*1000-h0) for a in range(2)]
write(OUT/'profiles.json',profiles);write(OUT/'anchor-bounds.json',bounds);cases=[]
for pa in [p['index'] for p in profiles]:
    assert time.perf_counter()<deadline
    hulls=[hull([(a[0]-b[0],a[1]-b[1]) for a in part for b in ring]) for part in components[pa]];obstacle=unary_union([Polygon([(x/1000,y/1000) for x,y in h]) for h in hulls]);aa,bb=bounds[str(pa)],bounds['11'];lo,hi=bb[1]-aa[3],bb[3]-aa[1];rings=[obstacle.exterior] if obstacle.geom_type=='Polygon' else [g.exterior for g in obstacle.geoms];ys=sorted({F(lo,1000),F(hi,1000)}|{F(y) for r in rings for x,y in r.coords if lo<=y*1000<=hi});samples=[]
    from shapely.geometry import LineString
    for y in ys:
        cut=obstacle.intersection(LineString([(-3000,float(y)),(3000,float(y))]));assert not cut.is_empty;samples.append([float(y),cut.bounds[0],cut.bounds[2]])
    L=math.ceil(max(r[1] for r in samples)*1000);R=math.floor(min(r[2] for r in samples)*1000);rectangle=box((L+1)/1000,lo/1000,(R-1)/1000,hi/1000);contained=obstacle.contains(rectangle) and obstacle.boundary.distance(rectangle)>1e-8
    cases.append({'profiles':[pa,11],'convex_hulls_units1000':hulls,'forbidden_geometry':mapping(obstacle),'relative_y_units1000':[lo,hi],'samples':samples,'left_maximum_dx_units1000':L,'right_minimum_dx_units1000':R,'central_rectangle_contained':contained,'boundary_margin_mm':obstacle.boundary.distance(rectangle)})
write(OUT/'pair-bounds.json',cases);assert all(r['central_rectangle_contained'] for r in cases);gap=cases[-1]['right_minimum_dx_units1000'];assert gap>0 and cases[-1]['profiles']==[11,11]
write(OUT/'profile-bounds.json',[{'profile':r['profiles'][0],'left_maximum_dx_units1000':r['left_maximum_dx_units1000'],'right_minimum_dx_units1000':r['right_minimum_dx_units1000'],'common_cog_dx_units1000':gap,'order_contradiction_margin_units1000':r['right_minimum_dx_units1000']+gap-r['left_maximum_dx_units1000']} for r in cases[:-1]])
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'original_inscribed_radius_mm':r0/1000,'quantization_safe_radius_mm':inner/1000,'all_angle_stock_support_radius_mm':h0/1000,'proxy_profiles':len(profiles),'exact_minkowski_cases':len(cases),'central_forbidden_rectangles':len(cases),'all_real_cog_angles':True,'continuous_anchor_rounding_relaxation':True,'cog_minimum_dx_units1000':gap,'minimum_forbidden_rectangle_margin_mm':min(r['boundary_margin_mm'] for r in cases),'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
