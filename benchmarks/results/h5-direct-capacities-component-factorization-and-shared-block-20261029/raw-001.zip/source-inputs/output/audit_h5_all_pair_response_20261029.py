"""Verify the closed node-limited response without treating it as infeasibility."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, re, shutil, time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
SEARCH = BASE / 'search'
OUT = BASE / 'response-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
queue = [BASE / 'plan.json', BASE / 'audit/plan.json', SEARCH / 'opened.json']
seen, bindings = set(), {}
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    for name, expected in load(path).get('inputs', {}).items():
        source = ROOT / name
        assert source.is_relative_to(ROOT) and not {'.claude', '.cache'} & set(source.parts)
        assert digest(source) == expected, name
        bindings[name] = expected
        if source.name in ['plan.json', 'opened.json']:
            queue.append(source)
opened, result, process, budget = [load(SEARCH / n) for n in ['opened.json', 'result.json', 'process.json', 'budget.json']]
assert load(BASE / 'audit/checks.json')['passed']
assert digest(BASE / 'model.npz') == opened['model_sha256'] == load(BASE / 'audit/checks.json')['model_sha256']
log = (SEARCH / 'stdout.txt').read_text()
assert (SEARCH / 'stderr.txt').read_text() == ''
assert re.search(r'^  Status\s+Solution limit reached$', log, re.M)
assert re.search(r'^  Nodes\s+128$', log, re.M)
assert re.search(r'^  Primal bound\s+inf$', log, re.M)
assert re.search(r'^  Dual bound\s+0$', log, re.M)
assert result['status_code'] == 4 and 'HiGHS Status 16' in result['message'] and 'Solution limit reached' in result['message']
assert result['closed'] and result['solver_calls'] == 1 and not result['success']
assert not result['has_assignment'] and result['source_checker_calls'] == 0
assert not result['source_valid11'] and not result['source_valid66'] and not result['any_allocation_excluded']
assert result['native_calls'] == 0 and not (SEARCH / 'assignment.json').exists()
assert not (SEARCH / 'candidate-source11.json').exists()
assert process['closed'] and process['exit_code'] == 0 and not process['timeout']
assert process['seconds_including_preparation'] < 90 and result['algorithm_seconds_including_preparation'] < 60
assert result['algorithm_overrun_seconds'] == result['returned_solve_overrun_seconds'] == 0
assert opened['maximum_calls'] == budget['maximum_calls'] == 1
assert not opened['retry_permitted'] and not budget['retry_permitted']
assert opened['node_limit'] == budget['node_limit'] == 128
assert opened['options'] == {'time_limit': result['allocated_solve_seconds'], 'node_limit': 128, 'mip_rel_gap': 0., 'presolve': True, 'disp': True}
assert opened['preparation_seconds_charged'] == budget['preparation_seconds_charged'] == result['preparation_seconds_charged'] == load(BASE / 'checks.json')['preparation_seconds_charged']
data = np.load(BASE / 'model.npz')['data']
tiny = int(np.sum((np.abs(data) > 0) & (np.abs(data) <= 1e-9)))
assert tiny == 0 and 'WARNING' not in log
milp_path = ROOT / '.cache/shop-venv/Lib/site-packages/scipy/optimize/_milp.py'
assert "'mip_max_nodes': options.pop(\"node_limit\", None)" in milp_path.read_text()
write(OUT / 'status-interpretation.json', {
    'raw_highs_status': 'Solution limit reached', 'raw_highs_status_code': 16, 'raw_scipy_status_code': 4,
    'logged_nodes': 128, 'declared_node_limit': 128, 'incumbent': None,
    'meaning': 'The declared node cap was reached with no incumbent. This is an unresolved bounded construction search, not an infeasibility proof. The wrapper returns no assignment. Do not retry or extend this call.',
    'installed_scipy_node_limit_maps_to_mip_max_nodes': True, 'installed_milp_source_sha256': digest(milp_path),
})
write(OUT / 'source-bindings.json', bindings)
inputs = [Path(__file__), BASE / 'plan.json', BASE / 'model.npz', BASE / 'audit/plan.json', BASE / 'audit/checks.json'] + [SEARCH / n for n in ['opened.json', 'budget.json', 'result.json', 'process.json', 'stdout.txt', 'stderr.txt']]
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'recursive_input_bindings_verified': len(bindings),
          'closed_solver_calls': 1, 'raw_solver_status': 'Solution limit reached', 'scipy_status_code': 4,
          'outcome': 'NODE_LIMIT_NO_ASSIGNMENT', 'infeasibility_proven': False,
          'logged_nodes': 128, 'declared_node_limit': 128, 'tiny_coefficients_ignored': 0,
          'preparation_seconds_charged': result['preparation_seconds_charged'],
          'returned_solve_seconds': result['returned_solve_seconds'],
          'algorithm_seconds_including_preparation': result['algorithm_seconds_including_preparation'],
          'shared_seconds_including_preparation': process['seconds_including_preparation'],
          'all_overruns_seconds': 0, 'assignments': 0, 'source_checker_calls': 0,
          'any_allocation_excluded': False, 'remaining_candidates': 440, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
