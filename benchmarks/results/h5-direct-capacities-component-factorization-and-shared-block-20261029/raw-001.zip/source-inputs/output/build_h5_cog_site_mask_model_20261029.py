"""One simultaneous cog-site choice with complete orthogonal source-mode and pair coupling."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRE=BASE/'integer-preparation';OUT=BASE/'model';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';PRIOR=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';SLOTS=PRIOR/'cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'integer-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(PRE/'family-modes.json');instances=load(BASE/'instances.json');unary=load(PRE/'unary-templates.json');templates=load(PRE/'pair-templates.json');owner_pairs=load(PRE/'owner-pairs.json');model=cp_model.CpModel()
def linear(co,lo,hi,guard=None):
    expression=sum(c*model.get_int_var_from_proto_index(i) for i,c in co.items() if c)
    ct=model.add_linear_constraint(expression,lo,hi)
    if guard is not None:ct.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return ct.index
owners=[]
for i,instance in enumerate(instances):
    fm=modes[instance['identity'][0]];positions=[]
    for axis in [0,1]:positions.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm),f'{"x" if axis==0 else "y"}_{i}_um').index)
    owners.append({'owner':i,'identity':instance['identity'],'positions':positions,'modes':[],'unary_regions':[],'unary_geometry_marginals':[]})
for owner in owners:
    for mode in modes[owner['identity'][0]]:
        selector=model.new_bool_var(f'mode_{owner["owner"]}_{mode["mode"]}').index;record={**mode,'selector':selector,'stock_constraints':[]}
        for axis,var in enumerate(owner['positions']):
            lo,hi=mode['integer_lower_left_bounds'][axis];record['stock_constraints'].append(linear({var:1},lo,hi,selector))
        owner['modes'].append(record)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
empty=[model.new_bool_var(f'empty_cog_site_{i}').index for i in range(15)];exact_two=linear({v:1 for v in empty},2,2)
unary_plane_count=mask_links=0
for owner in owners:
    i=owner['owner'];geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    for gid in geometries:
        for region in unary[gid]['regions']:
            selector=model.new_bool_var(f'unary_{i}_{gid}_{region["region"]}').index
            record={'geometry':gid,'region':region['region'],'selector':selector,'required_empty_sites':region['required_empty_sites'],'plane_constraints':[],'empty_site_constraints':[]}
            for plane in region['planes']:
                nx,ny=plane['coefficients'];record['plane_constraints'].append(linear({2*i:nx,2*i+1:ny},cp_model.INT_MIN,plane['upper'],selector));unary_plane_count+=1
            for site in region['required_empty_sites']:
                record['empty_site_constraints'].append(linear({selector:1,empty[site]:-1},cp_model.INT_MIN,0));mask_links+=1
            owner['unary_regions'].append(record)
    owner['one_unary_region_constraint']=linear({r['selector']:1 for r in owner['unary_regions']},1,1)
    for gid in geometries:
        ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in owner['unary_regions'] if r['geometry']==gid]
        owner['unary_geometry_marginals'].append({'geometry':gid,'mode_selectors':ms,'region_selectors':rs,'constraint':linear({**{i:-1 for i in ms},**{i:1 for i in rs}},0,0)})
pairs=[];pair_plane_count=0
for group in owner_pairs:
    ia,ib=group['owners'];record={'owners':[ia,ib],'regions':[],'mode_marginals':[]}
    for ti in group['template_indices']:
        template=templates[ti]
        for region in template['regions']:
            selector=model.new_bool_var(f'pair_{ia}_{ib}_{ti}_{region["region"]}').index;r={'template':ti,'region':region['region'],'geometries':template['geometries'],'selector':selector,'plane_constraints':[]}
            for plane in region['planes']:
                nx,ny=plane['coefficients'];r['plane_constraints'].append(linear({2*ia:-nx,2*ia+1:-ny,2*ib:nx,2*ib+1:ny},cp_model.INT_MIN,plane['upper'],selector));pair_plane_count+=1
            record['regions'].append(r)
    record['one_region_constraint']=linear({r['selector']:1 for r in record['regions']},1,1)
    for side,owner in enumerate([ia,ib]):
        for gid in sorted({m['normalized_geometry'] for m in owners[owner]['modes']}):
            ms=[m['selector'] for m in owners[owner]['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in record['regions'] if r['geometries'][side]==gid]
            record['mode_marginals'].append({'owner':owner,'side':side,'geometry':gid,'mode_selectors':ms,'region_selectors':rs,'constraint':linear({**{i:-1 for i in ms},**{i:1 for i in rs}},0,0)})
    pairs.append(record)
symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):symmetry.append({'family':family,'owners':[a['owner'],b['owner']],'constraint':linear({2*a['owner']:1,2*b['owner']:-1},cp_model.INT_MIN,0)})
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert validation==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'empty_site_selectors':empty,'exactly_two_empty_sites_constraint':exact_two,'pairs':pairs,'symmetry_constraints':symmetry,'position_units_per_mm':1000};write(OUT/'mapping.json',mapping)
elapsed=time.perf_counter()-started
charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'site_mask_region_preparation_seconds':load(BASE/'checks.json')['seconds'],'reused_pair_region_preparation_seconds':load(FIRST/'compact-pair-regions-v2/checks.json')['seconds'],'reused_pair_integer_preparation_seconds':load(PRIOR/'checks.json')['seconds'],'mask_integer_preparation_seconds':load(PRE/'checks.json')['seconds'],'cp_model_build_seconds':elapsed};write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'instances.json',BASE/'inventory.json',BASE/'integer-audit/plan.json',BASE/'integer-audit/checks.json',FIRST/'checks.json',FIRST/'compact-pair-regions-v2/checks.json',PRIOR/'checks.json',SLOTS/'checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json']+[PRE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','pair-templates.json','owner-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Select exactly two of15 empty cog sites. Every one of13 original moving parts selects one source mode and one original-source-certified unary region; geometry marginals tie each region to its source mode and mask implications require all blocked cog sites empty. All78 moving-part pairs independently select certified pair regions tied to both owner modes. Preserve same-family X order and source-mode stock domains. No objective, hints or deactivation constants. Independently audit every field before the sole60/90-second call.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0})
result={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'original_moving_parts':13,'source_mode_selectors':80,'empty_site_selectors':15,'required_empty_sites':2,'unary_region_selectors':sum(len(o['unary_regions']) for o in owners),'unary_integer_planes':unary_plane_count,'empty_site_mask_implications':mask_links,'pair_region_selectors':sum(len(p['regions']) for p in pairs),'pair_integer_planes':pair_plane_count,'pair_geometry_marginals':sum(len(p['mode_marginals']) for p in pairs),'same_family_order_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
