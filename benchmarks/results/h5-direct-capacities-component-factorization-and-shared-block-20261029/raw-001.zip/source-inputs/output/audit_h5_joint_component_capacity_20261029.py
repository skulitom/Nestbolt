"""Independent source attribution, component and count audit; halfspace scan is diagnostic only."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from collections import deque
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-joint-component-capacity-20261029';OUT=BASE/'audit';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';AXIS=ROOT/'output/h5-first55-local-grid-regions-20261029/component-halfspace-bound';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
families=['bracket','insert'];inner={f:[[[F(x) for x in box] for box in mode] for mode in opts] for f,opts in load(BASE/'source-inner-rectangles.json').items()};modes=load(PRIOR/'family-modes.json');pieces=load(PIECES);corners=0
for f in families:
    assert len(inner[f])==len(modes[f])
    for boxes,mode in zip(inner[f],modes[f]):
        c,s=map(F,[math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians'])]);sign=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left']);assert len(boxes)==len(pieces[f])
        for box,piece in zip(boxes,pieces[f]):
            poly=[(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in piece];orient=1 if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1]))>0 else -1
            expected=[min(x for x,y in poly)+F('1e-6'),min(y for x,y in poly)+F('1e-6'),max(x for x,y in poly)-F('1e-6'),max(y for x,y in poly)-F('1e-6')];assert box==expected
            assert box[0]<box[2] and box[1]<box[3]
            for x in [box[0],box[2]]:
                for y in [box[1],box[3]]:assert all(orient*cross(a,b,(x,y))>=0 for a,b in zip(poly,poly[1:]+poly[:1]));corners+=1
regions={};unary=load(PRIOR/'integer-preparation/unary-templates.json')
for r in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if r['family'] not in families:continue
    key=(r['family'],r['mode'],r['geometry'],r['region']);cells={(y-200)*150+x for y,lo,hi in r['grid_row_spans'] for x in range(lo,hi+1)}
    if key not in regions:regions[key]={'required':{i for i in range(15) if r['required_empty_mask']>>i&1},'cells':set(),'poly':[tuple(map(F,p)) for p in unary[r['geometry']]['regions'][r['region']]['hull_vertices']]}
    regions[key]['cells'].update(cells)
axis_rows={tuple(r['empty_sites']):r for r in load(AXIS/'all35-halfspace-bounds.json')};conn_rows={tuple(r['empty_sites']):r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json')};allowed=load(AXIS/'audit/allowed-empty-site-pairs.json');rows=load(BASE/'all29-joint-bounds.json');assert [r['empty_sites'] for r in rows]==allowed
assignments=0;component_count=0;cell_count=0;cuts=0
for row in rows:
    empty=set(row['empty_sites']);active={k:v for k,v in regions.items() if v['required']<=empty};supports={f:set().union(*(v['cells'] for k,v in active.items() if k[0]==f)) for f in families};remaining=supports['bracket']|supports['insert'];comps=[]
    for f in families:assert int(row['family_supports_hex'][f],16)==sum(1<<i for i in supports[f])
    while remaining:
        first=min(remaining);remaining.remove(first);component={first};q=deque([first])
        while q:
            v=q.popleft();y,x=divmod(v,150)
            for dy in [-1,0,1]:
                for dx in [-1,0,1]:
                    if not(0<=y+dy<100 and 0<=x+dx<150):continue
                    n=(y+dy)*150+x+dx
                    if n in remaining:remaining.remove(n);component.add(n);q.append(n)
        comps.append(component)
    assert row['joint_components_hex']==[hex(sum(1<<i for i in comp)) for comp in comps];component_count+=len(comps);cell_count+=sum(map(len,comps));bounds=[{f:{} for f in families} for c in comps];expected=[]
    for k,v in active.items():
        destinations=[i for i,c in enumerate(comps) if v['cells']<=c];assert len(destinations)==1;ci=destinations[0];expected.append([*k,ci]);assignments+=1
        limits=[min(x for x,y in v['poly']),min(y for x,y in v['poly']),max(x for x,y in v['poly']),max(y for x,y in v['poly'])];f,m,_,_=k;old=bounds[ci][f].get(m);bounds[ci][f][m]=limits if old is None else [fun(a,b) for fun,a,b in zip([min,min,max,max],old,limits)]
    assert expected==row['region_component_assignments'];prior_c=conn_rows[tuple(row['empty_sites'])]['components_hex'];prior_caps=[r['capacity_upper_bound'] for r in axis_rows[tuple(row['empty_sites'])]['components']];caps=[0]*len(comps);mapped=[]
    for i,(h,cap) in enumerate(zip(prior_c,prior_caps)):
        cells={j for j in range(15000) if int(h,16)>>j&1};target=[j for j,c in enumerate(comps) if cells<=c];assert len(target)==1;caps[target[0]]+=cap;mapped.append([i,target[0],cap])
    assert mapped==row['inherited_bracket_component_assignments'];reachable={(0,0)}
    for ci,(c,r) in enumerate(zip(comps,row['components'])):
        areas={f:len(supports[f]&c)*100 for f in families};lower={f:min((sum((b[2]-b[0])*(b[3]-b[1]) for b in inner[f][m]) for m in bounds[ci][f]),default=F(0)) for f in families};maxcounts={f:min(7 if f=='bracket' else 6,int(F(areas[f])//lower[f])) if lower[f]>0 else 0 for f in families};maxcounts['bracket']=min(maxcounts['bracket'],caps[ci])
        assert r['component']==ci and r['grid_cells']==len(c) and r['area_upper_mm2']==len(c)*100 and r['family_area_upper_mm2']==areas and r['family_source_area_lower_mm2']=={f:str(v) for f,v in lower.items()} and r['inherited_bracket_capacity']==caps[ci] and r['count_caps']==maxcounts
        assert r['mode_position_bounds_mm']=={f:{str(m):[str(v) for v in b] for m,b in bounds[ci][f].items()} for f in families}
        counts=[]
        for b in range(maxcounts['bracket']+1):
            for i in range(maxcounts['insert']+1):
                if b*lower['bracket']+i*lower['insert']<=len(c)*100:counts.append([b,i])
        assert r['initial_count_pairs']==r['allowed_count_pairs']==counts and r['halfspace_certificates']==[]
        assert r['scan_complete'] and r['halfspaces_examined']==504;cuts+=504
        next_counts=set()
        for b,i in reachable:
            for nb,ni in counts:
                if b+nb<=7 and i+ni<=6:next_counts.add((b+nb,i+ni))
        reachable=next_counts
    assert row['reachable_count_pairs']==[list(p) for p in sorted(reachable)] and row['required_counts']==[7,6] and not row['restricted_construction_excluded'] and (7,6) in reachable
write(OUT/'source-bindings.json',bindings);write(OUT/'allowed-empty-site-pairs.json',allowed)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','source-inner-rectangles.json','all29-joint-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_inner_rectangle_corners_verified':corners,'joint_components_verified':component_count,'component_cells_verified':cell_count,'source_region_attributions_verified':assignments,'initial_and_final_count_sets_independently_verified':True,'exact_count_dynamic_program_verified':True,'halfspace_scan_shape_verified':cuts,'all_halfspace_values_independently_recomputed':False,'diagnostic_only_no_claim_of_exhaustive_bound_optimality':True,'new_restricted_exclusions':0,'restricted_pairs_remaining':29,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
