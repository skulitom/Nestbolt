"""Audit the sole closed UNKNOWN response and retain an unused source-reader defect."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-short-core-20261029';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit';PRE=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,MODEL,BASE/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
opened=load(SEARCH/'opened.json')
for n,h in opened['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'] and digest(SEARCH/'model.pb')==digest(MODEL/'model.pb')==opened['model_sha256']
r=cp_model_pb2.CpSolverResponse();r.ParseFromString((SEARCH/'response.pb').read_bytes());result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());log=(SEARCH/'solver.log').read_text();m=re.search(r'Starting search at ([0-9.]+)s',log);assert m
assert r.status==cp_model_pb2.UNKNOWN and not r.solution and result['status']=='UNKNOWN' and not result['has_solution'] and result['solver_calls']==1 and result['closed']
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and result['algorithm_seconds']<60
assert params.num_search_workers==4 and params.random_seed==0 and list(params.ignore_subsolvers)==['fj'] and params.max_time_in_seconds==result['allocated_solve_seconds']==opened['parameters']['max_time_in_seconds']
assert params.log_search_progress and not params.log_to_stdout and opened['source_validation_reserve_seconds']==3 and opened['maximum_calls']==1 and not opened['retry_permitted']
assert result['returned_solve_soft_overrun_seconds']==max(0,result['returned_solve_seconds']-result['allocated_solve_seconds']) and result['algorithm_soft_overrun_seconds']==0 and result['solver_wall_seconds']==r.wall_time and result['returned_response_branches']==r.num_branches and result['returned_response_conflicts']==r.num_conflicts
assert result['incumbents_recorded']==0 and not list((SEARCH/'incumbents').iterdir()) and not (SEARCH/'assignment.json').exists() and not (SEARCH/'source-response').exists() and not (SEARCH/'source-check-stdout.txt').exists() and (SEARCH/'stderr.txt').read_text()==''
assert not result['source_short13_verified'] and not result['source_full66_verified'] and not result['original_source_feasibility_excluded'] and result['native_calls']==0
# Candidate lifting was never reached. Document the rational-string parsing defect before any reuse.
checker=ROOT/'output/check_h5_global_short_core_candidate_20261029.py';source=checker.read_text(encoding='utf-8');assert "center=list(map(float,coredata['source_center_mm']))" in source;encoded=load(PRE/'cog-core.json')['source_center_mm'];failures=0
for v in encoded:
    try:float(v)
    except ValueError:failures+=1
assert failures==2;correct=[float(F(v)) for v in encoded];assert all(F(str(v))==F(s) for v,s in zip(correct,encoded))
write(OUT/'unexercised-source-reader-defect.json',{'observed':True,'detail':'The frozen candidate checker tries float() on exact rational source-center strings such as69861871/500000. That raises ValueError. No core assignment, incumbent or source-check invocation existed, so it did not affect the UNKNOWN solver result. Preserve the original closed script. A future distinct checker must parse each string with Fraction before converting to float.','float_parse_failures_reproduced':failures,'correct_fraction_parse_mm':correct,'source_checker_executed':False,'closed_script_unchanged':True,'solver_retried':False})
inputs=[Path(__file__),BASE/'plan.json',MODEL/'plan.json',BASE/'model-audit/plan.json',checker,PRE/'cog-core.json']+[SEARCH/n for n in ['opened.json','budget.json','parameters.pbtxt','model.pb','response.pb','solver.log','stdout.txt','stderr.txt','process.json','result.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_solver_calls':1,'status':'UNKNOWN','audited_model_bytes_identical':True,'search_started_seconds':float(m.group(1)),'returned_solve_seconds':result['returned_solve_seconds'],'allocated_solve_seconds':result['allocated_solve_seconds'],'solver_wall_seconds':r.wall_time,'returned_solve_soft_overrun_seconds':result['returned_solve_soft_overrun_seconds'],'algorithm_seconds':result['algorithm_seconds'],'shared_seconds':process['seconds'],'algorithm_soft_overrun_seconds':0,'shared_soft_overrun_seconds':0,'returned_response_branches':r.num_branches,'returned_response_conflicts':r.num_conflicts,'incumbents':0,'assignments':0,'source_checker_calls':0,'unexercised_rational_reader_defect_preserved':True,'original_or_all_angle_feasibility_excluded':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
