"""Independently verify first55 identity allocation, unchanged fixed poses and every mode-domain corner."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from itertools import product
from collections import Counter
import json, math, shutil, time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first55-after-source-valid11-20261029'; OUT=BASE/'audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OLD=ROOT/'output/h5-oblique64-source-20261028/source64.json'
MODES=ROOT/'output/h5-short11-all-modes-preflight-20261029'
load=lambda p:json.loads(p.read_bytes()); digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
job=load(JOB); parts={p['id']:p for p in job['parts']}; original=load(OLD)
fixed=load(BASE/'fixed29.json'); partial=load(BASE/'partial40.json'); inv=load(BASE/'inventory.json')
original_by_key={(r['part_id'],r['copy_index']):r for r in original}
relabels=load(BASE/'insert-identity-relabels.json')
mapping={r['first55_copy_index']:r['source_copy_index'] for r in relabels}
assert len(mapping)==11 and len(set(mapping.values()))==11
for row in fixed:
    key=(row['part_id'], mapping[row['copy_index']] if row['part_id']=='insert' else row['copy_index'])
    old=original_by_key[key]
    assert row['sheet_id']==old['sheet_id']=='sheet-0' and row['transform']==old['transform']
assert Counter(r['part_id'] for r in fixed)=={'frame':18,'insert':11}
sets={k:set(map(tuple,v)) for k,v in inv.items()}
assert sets['fixed29_identities'].isdisjoint(sets['moving26_identities'])
assert sets['fixed29_identities']|sets['moving26_identities']==sets['mandatory_first55_identities']
assert sets['mandatory_first55_identities'].isdisjoint(sets['valid_short11_identities'])
assert sets['mandatory_first55_identities']|sets['valid_short11_identities']==sets['full66_identities']
assert sets['full66_identities']=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
assert partial[:29]==fixed and len(partial)==40
spec=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json')
assert plan['source_stocks']=={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':spec['source_stock']}
assert plan['required_pair_gap_mm']==spec['required_pair_gap_mm'] and plan['stock_guard_mm']==spec['stock_guard_mm']
check=audit(job,partial,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected=list(sets['fixed29_identities']|sets['valid_short11_identities']))
assert check['valid'] and check==load(BASE/'partial40-source-checks.json')
def outer(row):
    t=row['transform']; c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']); m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[row['part_id']]['geometry'][0]['outer']])
max_y=max(outer(r).bounds[3] for r in fixed)
assert max_y==plan['fixed_original_max_y']
stock=plan['construction_stock'];assert stock==[6.5,max_y+.2,1493.5,2993.5]
modes=load(BASE/'family-modes.json'); previous=load(MODES/'family-modes.json'); library=load(BASE/'geometry-library.json')
assert library==load(MODES/'geometry-library.json')
for family,items in modes.items():
    assert len(items)==len(previous[family])
    for mode,old in zip(items,previous[family]):
        assert {k:v for k,v in mode.items() if k!='lower_left_bounds'}=={k:v for k,v in old.items() if k!='lower_left_bounds'}
        w,h=library[mode['normalized_geometry']]['dimensions']
        assert mode['lower_left_bounds']==[[stock[0]+.025,stock[2]-.025-w],[stock[1]+.025,stock[3]-.025-h]]
instances=load(BASE/'instances.json');assert [tuple(r['identity']) for r in instances]==sorted(sets['moving26_identities'])
controls=[]
for instance in instances:
    family,idx=instance['identity'];assert instance['mode_count']==len(modes[family])
    for mode in modes[family]:
        for xy in product(*mode['lower_left_bounds']):
            row={'part_id':family,'copy_index':idx,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[i]+mode['translation_from_lower_left'][i] for i in range(2)]}}
            result=audit(job,fixed+[row],plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected=list(sets['fixed29_identities']|{(family,idx)}))
            assert result['valid']
            b=outer(row).bounds
            assert b[1]-max_y>plan['required_pair_gap_mm']
            controls.append({'identity':[family,idx],'mode':mode['mode'],'lower_left':xy,'source_bounds':b,'fixed_to_mover_y_gap_mm':b[1]-max_y,'valid':True})
assert len(controls)==372
write(OUT/'corner-controls.json',controls)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,OLD,MODES/'family-modes.json',MODES/'geometry-library.json']+[BASE/n for n in ['plan.json','checks.json','fixed29.json','partial40.json','partial40-source-checks.json','inventory.json','instances.json','family-modes.json','geometry-library.json','insert-identity-relabels.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Verify all66 identities as a disjoint fixed29/moving26/short11 partition, unchanged fixed-source transforms with declared identical-copy relabelling, exact stock and mode domains, and every one of 372 original-source mode-domain corners against all29 fixed originals. Linear affine translation and rectangle-domain bounds extend the Y-separation and stock controls throughout each mode domain. This does not establish packing of the26 movers.'})
result={'passed':True,'seconds':time.perf_counter()-started,'all66_identities_partitioned':True,'unchanged_fixed_source_transforms':29,'identical_insert_relabels':11,'source_valid_partial40':True,'partial_same_sheet_pairs':check['same_sheet_pairs'],'partial_cutouts':check['cutouts'],'partial_hole_vertices':check['hole_vertices'],'moving_mode_options':93,'original_source_domain_corner_controls':len(controls),'minimum_fixed_to_mover_y_separation_mm':min(r['fixed_to_mover_y_gap_mm'] for r in controls),'first55_constructed':False,'source_valid66':False,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
