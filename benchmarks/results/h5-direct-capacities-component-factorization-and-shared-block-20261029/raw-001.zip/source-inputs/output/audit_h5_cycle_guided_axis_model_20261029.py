"""Read every selector, source axis, deactivation bound and unchanged parent row."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
from collections import Counter
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';PRE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029/preflight';BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,PRE,SOURCE/'source-translation-preflight/audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'source-translation-preflight/audit/checks.json')['passed'];old=np.load(SOURCE/'source-translation-search/model.npz');data=np.load(MODEL/'model.npz');assert set(data.files)=={'A','lower','upper','c','bounds','integrality'};A,lo,hi,c,bounds,integrality=[data[n] for n in ['A','lower','upper','c','bounds','integrality']];mp=load(MODEL/'mapping.json');choices=load(PRE/'choices.json');world=load(SOURCE/'source-translation-preflight/world-pieces.json');parentplanes=load(SOURCE/'source-translation-preflight/planes.json');selected=sorted(load(PRE/'cycle-expansion.json')['final_choice_planes']);assert selected==mp['removed_parent_rows']==[g['plane'] for g in choices] and len(selected)==11;kept=[i for i in range(8770) if i not in selected];assert kept==mp['retained_parent_rows'] and len(kept)==8759
assert A.shape==(8930,183) and lo.shape==hi.shape==(8930,) and np.array_equal(A[:8759,:23],old['A'][kept]) and np.all(A[:8759,23:]==0) and np.array_equal(hi[:8759],old['b'][kept]) and np.all(np.isneginf(lo[:8759]));assert np.array_equal(c[:23],old['c']) and np.all(c[23:]==0) and np.array_equal(bounds[:23],old['bounds']) and np.array_equal(bounds[23:],np.tile([0,1],(160,1))) and integrality.tolist()==[0]*23+[1]*160 and mp['continuous_translation_variables']==list(range(22)) and mp['max_movement_variable']==22 and mp['binary_variables']==list(range(23,183))
row=8759;variable=23;corners=0;minimum_inactive_slack=math.inf;maximum_projection_error=0
for group,record in zip(choices,mp['groups']):
    assert record['plane']==group['plane'] and record['original_variant']==group['original_variant'];original=parentplanes[group['plane']];assert group['owners']==original['owners'] and group['pieces']==original['pieces'];a,b=group['owners'];ai,bi=group['pieces'];PA=world[a]['pieces'][ai];PB=world[b]['pieces'][bi];axes=[]
    for poly in [PA,PB]:
        for p,q in zip(poly,poly[1:]+poly[:1]):
            ex,ey=q[0]-p[0],q[1]-p[1];length=math.hypot(ex,ey);axes.append([-ey/length,ex/length])
    axes+= [[-x,-y] for x,y in axes];assert len(axes)==len(group['variants']);selectors=[];variantrows=[]
    for k,(axis,variant) in enumerate(zip(axes,group['variants'])):
        n=variant['normal'];assert variant['variant']==k and max(abs(a-b) for a,b in zip(axis,n))<1e-12 and abs(sum(v*v for v in n)-1)<1e-12;gap=min(sum(x*y for x,y in zip(p,n)) for p in PB)-max(sum(x*y for x,y in zip(p,n)) for p in PA);err=abs(gap-variant['source_projection_gap_mm']);maximum_projection_error=max(maximum_projection_error,err);assert err<1e-9 and abs(variant['upper_delta_difference_mm']-(gap-.225))<1e-9
        indices=[2*a,2*a+1,2*b,2*b+1];co=[n[0],n[1],-n[0],-n[1]];assert variant['variable_indices']==indices and variant['coefficients']==co;M=variant['deactivation_M_mm'];rhs=variant['upper_delta_difference_mm'];expected=np.zeros(183)
        for i,value in zip(indices,co):expected[i]=value
        expected[variable]=M;assert np.array_equal(A[row],expected) and np.isneginf(lo[row]) and hi[row]==rhs+M
        for corner in product(*[bounds[i] for i in indices]):
            slack=hi[row]-sum(value*x for value,x in zip(co,corner));minimum_inactive_slack=min(minimum_inactive_slack,slack);assert slack>0;corners+=1
        # Selecting this binary cancels M. Its source row and sign are retained.
        assert abs((hi[row]-A[row,variable])-rhs)<1e-9;selectors.append(variable);variantrows.append(row);row+=1;variable+=1
    assert record['selectors']==selectors and record['variant_rows']==variantrows and record['one_of_row']==row;expected=np.zeros(183);expected[selectors]=1;assert np.array_equal(A[row],expected) and lo[row]==hi[row]==1;row+=1;originalvariant=group['variants'][group['original_variant']];assert originalvariant['normal']==original['normal'] and originalvariant['upper_delta_difference_mm']==original['upper_delta_difference_mm']
assert row==8930 and variable==183 and corners==2560
inv=load(SOURCE/'preflight/inventory.json');short=set(map(tuple,mp['short11_identities']));first=set(map(tuple,mp['mandatory_first55_identities']));job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};assert mp['short11_identities']==inv['short11_identities'] and mp['mandatory_first55_identities']==inv['mandatory_first55_identities'] and len(short)==11 and len(first)==55 and not short&first and short|first==allids and Counter(a for a,b in short)=={'bracket':5,'insert':4,'cog':2}
charges=load(MODEL/'preparation-charges.json');assert charges['source_geometry_seconds']==load(SOURCE/'source-translation-preflight/checks.json')['seconds'] and charges['cycle_expansion_seconds']==load(PRE/'checks.json')['seconds'] and charges['initial_axis_choice_seconds']==load(SOURCE/'source-axis-choice-preflight/checks.json')['seconds'] and sum(charges.values())==load(MODEL/'built.json')['preparation_seconds_charged']
inputs=[Path(__file__),BASE/'plan.json',MODEL/'plan.json',PRE/'plan.json',PRE/'choices.json',SOURCE/'source-translation-preflight/audit/plan.json',SOURCE/'source-translation-preflight/world-pieces.json',SOURCE/'source-translation-preflight/planes.json',SOURCE/'source-translation-search/model.npz',PRE/'cycle-expansion.json',SOURCE/'preflight/inventory.json']+[MODEL/n for n in ['model.npz','mapping.json','preparation-charges.json','built.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'all8930_rows_and183_variables_verified':True,'retained_parent_rows_exact':8759,'original_source_axis_variants_verified':160,'one_of_groups_verified':11,'binary_selectors_verified':160,'deactivation_corner_checks':corners,'minimum_inactive_row_slack_mm':minimum_inactive_slack,'maximum_projection_replay_error_mm':maximum_projection_error,'all_original_branch_options_retained':True,'all11_short_and55_first_identities_verified':True,'fixed_modes_and_cog_phases_preserved':True,'source_separation_sufficient_only':True,'negative_result_would_not_exclude_allocation':True,'preparation_seconds_charged':sum(charges.values()),'model_sha256':digest(MODEL/'model.npz'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
