"""Independent queue-based readback of grid connected-component capacity bounds."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import deque
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';AREA=BASE/'accessible-area-bound';BOUND=BASE/'connected-capacity-bound';OUT=BOUND/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
assert load(AREA/'audit/checks.json')['passed']
queue=[BOUND/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
groups={int(k):int(v,16) for k,v in load(AREA/'family-mask-covers.json')['bracket'].items()};rows=load(BOUND/'all105-capacity-bounds.json');prior=load(AREA/'all105-area-bounds.json');cells_verified=0
for row,old in zip(rows,prior):
    assert row['empty_sites']==old['empty_sites'] and row['previously_excluded_by_total_area']==old['restricted_construction_excluded']
    empty=set(row['empty_sites']);bits=0
    for mask,v in groups.items():
        if {i for i in range(15) if mask>>i&1}<=empty:bits|=v
    remaining={i for i in range(15000) if bits>>i&1};components=[];cells_verified+=len(remaining)
    while remaining:
        first=min(remaining);pending=deque([first]);component={first};remaining.remove(first)
        while pending:
            p=pending.popleft();y,x=divmod(p,150)
            for dx in [-1,0,1]:
                for dy in [-1,0,1]:
                    if not 0<=x+dx<150 or not 0<=y+dy<100:continue
                    q=(y+dy)*150+x+dx
                    if q in remaining:remaining.remove(q);component.add(q);pending.append(q)
        components.append(component)
    assert [hex(sum(1<<i for i in c)) for c in components]==row['components_hex']
    areas=[len(c)*100 for c in components];capacity=[a//40000 for a in areas]
    assert areas==row['component_area_upper_bounds_mm2'] and capacity==row['component_bracket_capacity_upper_bounds']
    assert row['total_bracket_capacity_upper_bound']==sum(capacity) and row['required_brackets']==7
    assert row['restricted_construction_excluded']==(sum(capacity)<7)
assert len(rows)==105
checks=load(BOUND/'checks.json');excluded=sum(r['restricted_construction_excluded'] for r in rows)
assert excluded==70==checks['restricted_pairs_excluded']
write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in rows if not r['restricted_construction_excluded']])
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BOUND/n for n in ['plan.json','checks.json','all105-capacity-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'empty_site_pairs_verified':105,'grid_cells_verified':cells_verified,'eight_neighbour_component_partitions_exact':True,'restricted_pairs_excluded':70,'new_restricted_pairs_excluded':2,'restricted_pairs_remaining':35,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
