"""Certify every whole convex free region against original source-piece pairs."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, shape
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
BASE = SOURCE / 'relative-free-region-preflight'
OUT = BASE / 'audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for name, expected in load(BASE / 'plan.json')['inputs'].items():
    assert digest(ROOT / name) == expected, name
assert load(SOURCE / 'audit/checks.json')['passed']
world = load(SOURCE / 'world-pieces.json')
groups = load(BASE / 'groups.json')
obstacles = load(BASE / 'obstacles.json')
bounds = np.load(SOURCE / 'model.npz')['bounds'][:22]
expected = {(a, b) for a, b in combinations(range(11), 2)}
seen, certificates = set(), []
total_proofs = regions_checked = 0
minimum_gap = math.inf
maximum_coverage_error = 0.
for group, obstacle_record in zip(groups, obstacles):
    ia, ib = group['owners']
    assert (ia, ib) in expected and (ia, ib) not in seen
    seen.add((ia, ib))
    assert obstacle_record['owners'] == [ia, ib]
    assert group['identities'] == [world[ia]['identity'], world[ib]['identity']]
    assert group['relative_variable'] == 'delta_b_minus_delta_a'
    expected_domain = [bounds[2*ib, 0]-bounds[2*ia, 1], bounds[2*ib+1, 0]-bounds[2*ia+1, 1],
                       bounds[2*ib, 1]-bounds[2*ia, 0], bounds[2*ib+1, 1]-bounds[2*ia+1, 0]]
    assert group['domain'] == expected_domain
    source_pairs = []
    for ai, av in enumerate(world[ia]['pieces']):
        for bi, bv in enumerate(world[ib]['pieces']):
            nfp = MultiPoint((np.asarray(av)[:, None, :]-np.asarray(bv)[None, :, :]).reshape(-1, 2)).convex_hull
            source_pairs.append((ai, bi, [tuple(map(F, p)) for p in av], [tuple(map(F, p)) for p in bv], nfp))
    assert len(source_pairs) == group['source_piece_pairs']
    polygons, proofs = [], []
    for region_index, vertices in enumerate(group['regions']):
        p = [tuple(map(F, v)) for v in vertices]
        assert len(p) >= 3 and all(cross(a, b, c) > 0 for a, b, c in zip(p, p[1:]+p[:1], p[2:]+p[:2]))
        region = Polygon(vertices)
        assert region.is_valid and region.area > 0 and region.equals(region.convex_hull)
        for x, y in p:
            assert F(expected_domain[0])-F('1e-10') <= x <= F(expected_domain[2])+F('1e-10')
            assert F(expected_domain[1])-F('1e-10') <= y <= F(expected_domain[3])+F('1e-10')
        polygons.append(region)
        for ai, bi, A, B, nfp in source_pairs:
            segment = list(shapely.shortest_line(nfp, region).coords)
            assert len(segment) == 2
            nx, ny = segment[1][0]-segment[0][0], segment[1][1]-segment[0][1]
            length = math.hypot(nx, ny)
            assert length > 0
            axis = [nx/length, ny/length]
            nx, ny = map(F, axis)
            norm2 = nx*nx+ny*ny
            gap = min(x*nx+y*ny for x, y in p)+min(x*nx+y*ny for x, y in B)-max(x*nx+y*ny for x, y in A)
            # The exact support test proves the entire region, independent of GEOS distances.
            assert gap > 0 and gap*gap >= F('.225')**2*norm2, (ia, ib, region_index, ai, bi, float(gap))
            minimum_gap = min(minimum_gap, float(gap)/math.sqrt(float(norm2)))
            proofs.append([region_index, ai, bi, *axis])
            total_proofs += 1
        regions_checked += 1
    combined = unary_union(polygons)
    free = shape(obstacle_record['bounded_free_region'])
    coverage_error = combined.symmetric_difference(free).area
    assert coverage_error < 1e-7
    assert abs(sum(p.area for p in polygons)-combined.area) < 1e-7
    maximum_coverage_error = max(maximum_coverage_error, coverage_error)
    certificates.append({'owners': [ia, ib], 'proofs': proofs})
assert seen == expected and len(groups) == len(obstacles) == 55 and regions_checked == 695
inventory = load(SOURCE / 'inventory.json')
assert len(inventory['short11_identities']) == 11 and len(inventory['mandatory_first55_identities']) == 55
write(OUT / 'support-certificates.json', certificates)
inputs = [Path(__file__), SOURCE / 'audit/plan.json', SOURCE / 'audit/checks.json', SOURCE / 'world-pieces.json',
          SOURCE / 'model.npz', SOURCE / 'inventory.json', BASE / 'plan.json', BASE / 'groups.json',
          BASE / 'obstacles.json', BASE / 'checks.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'original_pairs': len(seen),
          'strictly_convex_regions': regions_checked, 'exact_whole_region_source_support_proofs': total_proofs,
          'minimum_certified_region_gap_mm': minimum_gap, 'required_source_gap_mm': .225,
          'maximum_float_free_region_coverage_error_mm2': maximum_coverage_error,
          'all55_relative_domains_and_identities_verified': True,
          'support_certificates_independent_of_float_collision_verdict': True,
          'original_source_readback_required_for_any_assignment': True,
          'negative_result_restricted_by_fixed_modes_and_float_free_region_construction': True,
          'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
