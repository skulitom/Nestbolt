"""Independently audit all cog strip corners and the original source controls."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-coarse-short-core-20261029/cog-strip-preflight';OUT=BASE/'audit';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for p in [BASE/'plan.json',PRE/'audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
core=load(GEOM/'cog-core.json')['vertices_um'];rr=load(BASE/'strips.json');geom=load(BASE/'geometry.json');assert len(rr)==16;planes=0
for r in rr:
    assert all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3]
    for x,y in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]:
        for a,b in zip(core,core[1:]+core[:1]):assert (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>=0;planes+=1
def overlap(a,b):return a[0]<b[2] and b[0]<a[2] and a[1]<b[3] and b[1]<a[3]
assert not any(overlap(a,b) for a,b in combinations(rr,2));area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rr);corearea=F(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(core,core[1:]+core[:1])),2);assert area==geom['rectangle_area_um2'] and corearea==F(geom['core_area_um2']) and F(area)/corearea==F(geom['area_fraction'])
controls=[]
for name,count in [('positive',11),('negative',13)]:
    rows=load(PRE/f'{name}-core{count}.json');world=[]
    for r in rows:
        x,y=r['anchor_um'];pieces=[[a+x,b+y,c+x,d+y] for a,b,c,d in rr] if r['family']=='cog' else r['world_rectangles_um'];world.extend(pieces)
    bad=sum(overlap(a,b) for a,b in combinations(world,2))
    if name=='positive':assert bad==0 and len(world)==31
    else:assert bad>0 and len(world)==48
    controls.append({'name':name,'source_originals':count,'global_pieces':len(world),'global_piece_pairs':len(world)*(len(world)-1)//2,'overlapping_rectangle_pairs':bad})
write(OUT/'controls.json',controls);inputs=[Path(__file__),PRE/'audit/plan.json']+list(BASE.glob('*.json'));write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'cog_rectangles_verified':16,'exact_corner_edge_checks':planes,'internal_rectangle_pairs_verified':120,'positive_source11_global_pieces':31,'positive_rectangle_pairs_checked':465,'positive_overlaps':0,'negative_source13_global_pieces':48,'negative_rectangle_pairs_checked':1128,'negative_overlaps':controls[1]['overlapping_rectangle_pairs'],'subset_and_disjointness_proved':True,'unchanged_existing_facets_required':True,'capacity_domain_constants_not_prepared':True,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
