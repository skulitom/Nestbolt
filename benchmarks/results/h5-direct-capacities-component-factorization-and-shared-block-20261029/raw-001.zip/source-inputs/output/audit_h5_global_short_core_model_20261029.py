"""Audit every saved model field and both original-source-derived control assignments."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_global_short_core_reader_20261029 import inspect,violations
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-short-core-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit';PRE=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,MODEL,PRE/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PRE/'audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');pos=load(MODEL/'positive-control-assignment.json');neg=load(MODEL/'negative-assignment.json');result=inspect(p,mp,load(PRE/'inventory.json'),load(PRE/'orthogonal-modes.json'),load(PRE/'cog-rectangle-facets.json'),load(PRE/'cog-pair-facets.json'),load(PRE/'positive-model11.json'),load(PRE/'negative-model13.json'),load(MODEL/'partial-hints.json'),pos,neg)
positive=violations(p,pos);assert sorted(r['constraint'] for r in positive['failed_constraints'])==sorted(mp['control_disabled_mandatory_constraints']) and positive['orthogonal_piece_collisions']==0
relaxed=violations(p,pos,set(mp['control_disabled_mandatory_constraints']));assert not relaxed['failed_constraints'];negative=violations(p,neg);assert len(negative['failed_constraints'])==34 and sum(r['kind']=='bool_or' for r in negative['failed_constraints'])==33 and sum(r['kind']=='no_overlap_2d' for r in negative['failed_constraints'])==1 and negative['orthogonal_piece_collisions']==95
write(OUT/'control-checks.json',{'positive11_full_target':positive,'positive11_only_two_missing_requirements_disabled':relaxed,'negative13_full_target':negative})
inputs=[Path(__file__),ROOT/'output/h5_global_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',PRE/'audit/plan.json']+[MODEL/n for n in ['model.pb','model.pbtxt','mapping.json','built.json','positive-control-assignment.json','negative-assignment.json','partial-hints.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{**result,'seconds':time.perf_counter()-start,'positive11_fails_only_two_missing_mandatory_originals':True,'positive11_with_only_those_two_requirements_disabled_passes_every_constraint':True,'negative13_failed_constraints':34,'negative13_orthogonal_piece_collisions':95,'source_geometry_and_rounding_preflight_verified_by_hash':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
