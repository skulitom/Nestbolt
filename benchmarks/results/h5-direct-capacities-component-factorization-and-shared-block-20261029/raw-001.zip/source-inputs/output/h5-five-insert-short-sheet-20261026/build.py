"""Use two inter-part bracket gaps and a three-insert stack on the short sheet."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-two-insert-short-sheet-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PROFILES=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json';OUT=ROOT/'output/h5-five-insert-short-sheet-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(g,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;return affine_transform(g,[mi*c,-s,mi*s,c,*t['translation']])
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[OLD/n for n in ['first-sheet-placements.json','partial64-placements.json','audit/checks.json']]+[SRC/'items.json',SRC/'geometry.json',JOB,PROFILES,ROOT/'output/h5-fourteen-cog-necessary-model-20261026/response-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Move original inserts32/34/35 from first to short, retaining their identities and every other first transform. Raise the upper arm of each of the first two bracket pairs to Y19mm and widen each pair to create a180mm-wide gap with0.225mm clearance; place inserts32/34 between the separate bracket filled outers. Keep the third bracket pair compact. Place cog65 next, then two rotated110x180 inserts36/37 side by side and horizontal insert35 above them. All12 short originals must pass full filled-outer pairs and guarded stock boundaries; this is not part-in-hole nesting. The changed first52 plus short12 remain64 originals, with cogs63/64 mandatory. No old fixed43 exclusion is transferred to the new fixed40 non-cog arrangement.'})
assert load(OLD/'audit/checks.json')['passed'] and load(ROOT/'output/h5-fourteen-cog-necessary-model-20261026/response-audit/checks.json')['status']=='INFEASIBLE';job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};profiles={p['index']:p for p in load(PROFILES)};short=[];anchors=[]
def placed(item,profile,x,y):
    p=profiles[profile];t={'rotation_radians':p['rotation_radians'],'mirrored':p['mirrored'],'translation':[x-p['rotated_original_min'][0],y-p['rotated_original_min'][1]]};short.append({'part_id':items[item]['family'],'copy_index':items[item]['copy'],'sheet_id':'sheet-1','transform':t});anchors.append({'item':item,'profile':profile,'lower_left':[x,y]})
left=6.525
for pair,brs in enumerate([[21,22],[25,26],[28,29]]):
    widen=pair<2;placed(brs[0],7,left,19.0 if widen else 6.525);placed(brs[1],5,left+(80.45 if widen else 75.225),6.525)
    if widen:placed([32,34][pair],10,left+75.225,106.75)
    left+=330.45+.225 if widen else 325.225+.225
cog=Polygon(families['cog']['geometry'][0]['outer']);b=cog.bounds;cogx=left;cogt={'rotation_radians':0.,'mirrored':False,'translation':[cogx-b[0],6.525-b[1]]};short.append({'part_id':'cog','copy_index':items[65]['copy'],'sheet_id':'sheet-1','transform':cogt});anchors.append({'item':65,'rotation_radians':0.,'lower_left':[cogx,6.525]});insertx=cogx+b[2]-b[0]+.225;placed(36,8,insertx,6.525);placed(37,8,insertx+110.225,6.525);placed(35,10,insertx,186.75)
first=[p for p in load(OLD/'first-sheet-placements.json') if ids[p['part_id'],p['copy_index']] not in [32,34,35]];assert len(first)==52 and len(short)==12 and Counter(p['part_id'] for p in short)=={'bracket':6,'insert':5,'cog':1};allp=first+short;placedids=[ids[p['part_id'],p['copy_index']] for p in allp];assert len(set(placedids))==64 and sorted(placedids+[63,64])==list(range(66));stocks=[[float(F(*v)) for v in row] for row in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};holes=vertices=0;pairs=[];edges=[]
for p in allp:
    i=ids[p['part_id'],p['copy_index']];f=families[p['part_id']];t=p['transform'];assert not t['mirrored'] or f['allow_mirror'];assert f['rotations']['kind']=='free' or any(abs(math.degrees(t['rotation_radians'])%360-d)<1e-8 for d in f['rotations']['degrees']);g=f['geometry'][0];filled=transform(Polygon(g['outer']),t);full=transform(Polygon(g['outer'],g.get('holes',[])),t);assert filled.is_valid and full.is_valid and len(full.interiors)==len(g.get('holes',[]));holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]));sheet=int(p['sheet_id'].split('-')[1]);polys[i]=(sheet,filled);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;edges.append({'item':i,'extra_margins_mm':extra})
for a,b in combinations(sorted(polys),2):
    sa,pa=polys[a];sb,pb=polys[b]
    if sa==sb:
        d=pa.distance(pb);assert pa.intersection(pb).area==0 and d>gap;pairs.append({'items':[a,b],'sheet_id':f'sheet-{sa}','distance_mm':d})
write(OUT/'first-sheet-placements.json',first);write(OUT/'short-sheet-placements.json',short);write(OUT/'short-sheet-anchors.json',anchors);write(OUT/'partial64-placements.json',allp);write(OUT/'placed-identities.json',placedids);write(OUT/'mandatory-first-additions.json',[63,64]);write(OUT/'original-pair-checks.json',pairs);write(OUT/'original-stock-checks.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':64,'first_sheet_originals':52,'short_sheet_originals':12,'short_counts':dict(Counter(p['part_id'] for p in short)),'moved_first_inserts':[32,34,35],'first52_transforms_unchanged':True,'two_inserts_between_separate_bracket_filled_outers':True,'part_in_hole_used':False,'mandatory_first_additions':[63,64],'all66_identities_accounted_once':True,'original_pair_checks':len(pairs),'stock_edge_checks':4*len(edges),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_original_pair_gap_mm':min(r['distance_mm'] for r in pairs),'required_native_pair_gap_mm':gap,'minimum_extra_stock_margin_mm':min(min(r['extra_margins_mm']) for r in edges),'short_highest_outer_y_mm':max(g.bounds[3] for s,g in polys.values() if s==1),'short_rightmost_outer_x_mm':max(g.bounds[2] for s,g in polys.values() if s==1),'old_fixed43_exclusion_not_applied':True,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
