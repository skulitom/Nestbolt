"""Independent implications of unary integer planes and exact reuse of pair geometry."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRE=BASE/'integer-preparation';OUT=BASE/'integer-audit';PRIOR=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(PRE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
assert load(BASE/'source-region-audit/checks.json')['passed'] and load(PRIOR/'geometry-audit/checks.json')['passed']
original=load(BASE/'family-modes.json');modes=load(PRE/'family-modes.json');instances=load(BASE/'instances.json');grid=1000;scale=10**9;mode_count=0
for family,items in original.items():
    assert len(items)==len(modes[family])
    for a,b in zip(items,modes[family]):
        assert {k:v for k,v in b.items() if k!='integer_lower_left_bounds'}==a
        assert b['integer_lower_left_bounds']==[[math.ceil(F(lo)*grid),math.floor(F(hi)*grid)] for lo,hi in a['lower_left_bounds']]
        for k,(lo,hi) in enumerate(b['integer_lower_left_bounds']):assert 0<=lo<hi<=[1500000,3000000][k]
        mode_count+=1
assert modes=={k:v for k,v in load(PRIOR/'family-modes.json').items() if k!='cog'}
templates=load(PRE/'unary-templates.json');assert len(templates)==10;regions=planes=0;minimum=None;maximum_activity=0
for gid,template in enumerate(templates):
    source=load(BASE/'geometries'/f'{gid:02d}.json');assert template['geometry']==source['geometry']==gid and len(template['regions'])==len(source['regions'])
    for converted,old in zip(template['regions'],source['regions']):
        assert converted['region']==old['region'] and converted['required_empty_mask']==old['required_empty_mask'] and converted['required_empty_sites']==old['required_empty_sites']
        assert converted['required_empty_mask'].bit_count()<=2 and converted['required_empty_sites']==[i for i in range(15) if converted['required_empty_mask']&(1<<i)]
        points=[tuple(F(round(v,9)) for v in p) for p in old['vertices']];polygon=[tuple(map(F,p)) for p in converted['hull_vertices']]
        assert len(polygon)>=3 and set(polygon)<=set(points) and len(polygon)==len(converted['planes'])
        assert all(cross(a,b,c)>0 for a,b,c in zip(polygon,polygon[1:]+polygon[:1],polygon[2:]+polygon[:2]))
        assert all(cross(a,b,p)>=0 for a,b in zip(polygon,polygon[1:]+polygon[:1]) for p in points)
        for edge,(a,b,plane) in enumerate(zip(polygon,polygon[1:]+polygon[:1],converted['planes'])):
            assert plane['edge']==edge;dx,dy=b[0]-a[0],b[1]-a[1];length=F(math.hypot(float(dx),float(dy)));normal=[dy/length,-dx/length]
            divisor=plane['divisor'];assert divisor>0 and plane['unreduced_coefficients']==[v*divisor for v in plane['coefficients']]
            error=sum(abs(n-F(c*divisor,scale))*limit for n,c,limit in zip(normal,plane['coefficients'],[1500,3000]));assert error==F(plane['rounding_error_bound_mm'])
            inset=sum(n*x for n,x in zip(normal,a))-F(plane['upper']*divisor,scale*grid)-error;assert inset>=F('1e-7')
            minimum=inset if minimum is None else min(minimum,inset)
            activity=sum(abs(c)*limit for c,limit in zip(plane['coefficients'],[1500000,3000000]));assert activity<2**62 and abs(plane['upper'])<2**62;maximum_activity=max(maximum_activity,activity);planes+=1
        regions+=1
prior=load(PRIOR/'integer-templates.json');indices=load(PRE/'pair-template-prior-indices.json');pairs=load(PRE/'pair-templates.json')
assert indices==[i for i,t in enumerate(prior) if all(g<10 for g in t['geometries'])] and pairs==[prior[i] for i in indices] and len(pairs)==84
lookup={tuple(p['geometries']):i for i,p in enumerate(pairs)};owners=load(PRE/'owner-pairs.json');assert [r['owners'] for r in owners]==[list(k) for k in combinations(range(13),2)]
for pair in owners:
    ia,ib=pair['owners'];assert pair['identities']==[instances[i]['identity'] for i in [ia,ib]]
    options=[sorted({m['normalized_geometry'] for m in modes[instances[i]['identity'][0]]}) for i in [ia,ib]];keys=list(product(*options));assert pair['geometry_pairs']==[list(k) for k in keys] and pair['template_indices']==[lookup[k] for k in keys]
assert regions==1643 and planes==6723 and mode_count==12
inputs=[Path(__file__),BASE/'source-region-audit/plan.json',BASE/'source-region-audit/checks.json',BASE/'family-modes.json',BASE/'instances.json',PRIOR/'family-modes.json',PRIOR/'integer-templates.json',PRIOR/'geometry-audit/plan.json',PRIOR/'geometry-audit/checks.json']+[PRE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','pair-templates.json','pair-template-prior-indices.json','owner-pairs.json']]+[BASE/'geometries'/f'{i:02d}.json' for i in range(10)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'source_mode_domains_verified':12,'unary_region_hulls_verified':regions,'exact_integer_unary_implications_verified':planes,'minimum_inset_after_rounding_mm':float(minimum),'maximum_integer_activity':maximum_activity,'all_activities_within_int64':True,'unchanged_source_pair_templates_verified':84,'all78_original_pair_mappings_verified':True,'source_mode_options_preserved':80,'empty_site_masks_preserved':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
