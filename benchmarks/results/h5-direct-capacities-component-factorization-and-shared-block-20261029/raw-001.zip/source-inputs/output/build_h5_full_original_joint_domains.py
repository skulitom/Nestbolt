"""Constructive allowed domains and full-original mutual collision disjunctions."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
import json,math,shutil,time,traceback
from shapely.geometry import shape,mapping,MultiPoint,GeometryCollection
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand
from build_h5_strong_pair_domains import convex_faces

ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-guarded-source-adjustment-20261025'
REG=SOURCE/'original-regions';INVENTORY=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Q=1000;SCALE=10**7;MAXX=1500000;MAXY=3000000;EPS=.000001
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def inequalities(poly,inside):
    pts=list(orient(poly,sign=1).exterior.coords);rows=[]
    for p,q in zip(pts,pts[1:]):
        x,y=map(F,p);u,v=map(F,q);a,b=v-y,x-u
        if not a and not b:continue
        unit=max(abs(a),abs(b));a/=unit;b/=unit;c=a*x+b*y;A,B=round(a*SCALE),round(b*SCALE)
        error=abs(F(A)-a*SCALE)*MAXX+abs(F(B)-b*SCALE)*MAXY+1
        bound=math.floor(c*Q*SCALE-error) if inside else math.ceil(c*Q*SCALE+error)
        assert (A or B) and max(abs(bound),2*(abs(A)*MAXX+abs(B)*MAXY))<2**60
        rows.append({'edge':[list(p),list(q)],'a':A,'b':B,'bound':bound,'sense':'le' if inside else 'ge',
                     'coefficient_error_bound':[error.numerator,error.denominator]})
    assert len(rows)>=3;return rows

def main():
    assert load(REG/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed']
    OUT.mkdir();(OUT/'queries').mkdir();(OUT/'mutual').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    spec=load(INVENTORY/'plan.json');profiles=load(REG/'profiles.json');queries=load(REG/'plan.json')['queries']
    parts=[]
    for item in spec['movable_parts']:
        qs=[q['index'] for q in queries if q['family']==item['family'] and q['mode'] in item['allowed_modes']]
        assert sorted(queries[i]['mode'] for i in qs)==item['allowed_modes']
        parts.append({**item,'part':len(parts),'queries':qs,'profiles':sorted({queries[i]['profile'] for i in qs})})
    profile_pairs=sorted({(pa,pb) for a,b in combinations(parts,2) for pa,pb in product(a['profiles'],b['profiles'])})
    mutual=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(profile_pairs)];assert len(mutual)==82 and len(parts)==9
    inputs=[REG/n for n in ['plan.json','profiles.json','adjusted-fixed-originals.json','audit/checks.json','clearance-envelope.json']]
    inputs += [SOURCE/'audit/checks.json',INVENTORY/'plan.json',SRC/'propagation.json',ROOT/'benchmarks/results/h5-guarded-source-adjustment-20261025/raw-manifest.json']
    inputs += [ROOT/'output'/n for n in ['conservative_h5_round_obstacles.py','conservative_h5_polygon_obstacles.py','diagnose_h5_concave_gaps.py','build_h5_strong_pair_domains.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'original_query_hashes':{str(q['index']):digest(REG/'queries'/f"{q['index']:03d}.json") for q in queries},
        'construction_limit_seconds':240,'maximum_convex_faces':200000,'per_geometry_merge_attempt_limit':10000,
        'coordinate_units_per_mm':Q,'normal_coefficient_scale':SCALE,'coordinate_maxima':[MAXX,MAXY],
        'allowed_face_inset_mm':EPS,'forbidden_face_square_padding_mm':EPS,'construction_clearance_mm':.2125,'clearance_envelope_extra_mm':.0001,
        'parts':parts,'queries':queries,'mutual_cases':mutual,'fixed_items':spec['fixed_items'],
        'fixed_original_area_units_per_sheet':spec['fixed_original_area_units_per_sheet'],'required_original_counts':spec['required_original_counts'],
        'method':'Prepare the complete recorded nine-original constructive inventory on the adjusted57-original source. All20 allowed regions are decomposed into convex faces with every raw face retained in records; each is inset by1e-6mm, checked inside the original free region, and represented by inward rational integer halfplanes on the1-micrometre grid. Empty insets or empty inward grid boxes are recorded explicitly. Raw-union coverage differences are preserved; this is a constructive subset, not an exhaustive relaxation. Build all82 ordered moving-profile pairs actually needed by the36 physical pairs using full original Minkowski obstacles and the conservative polygonal clearance envelope. Convex forbidden faces expand by a1e-6mm square and their union must cover the whole obstacle. Avoiding every face is a conjunction of edge-separation disjunctions; the vector is anchorB-anchorA. Round each outside inequality conservatively outward using exact coefficient-error bounds. No outward allowed-domain rounding, omitted physical parts, partial-count objective or solver call.'})
    start=time.perf_counter();deadline=start+240;write(OUT/'profiles.json',profiles)
    qsummary=[];msummary=[];total=0
    for q in queries:
        if time.perf_counter()>=deadline or total>=200000:break
        original=load(REG/'queries'/f"{q['index']:03d}.json");region=shape(original['free_region']);faces,merge=convex_faces(region,deadline)
        raw_union=unary_union(faces);missing=region.difference(raw_union);domains=[];discarded=[]
        for i,raw in enumerate(faces):
            inset=raw.buffer(-EPS,join_style='mitre')
            if inset.is_empty:
                discarded.append({'index':i,'raw_face':mapping(raw),'reason':'empty conservative inset'});continue
            assert inset.geom_type=='Polygon' and inset.equals(inset.convex_hull) and region.covers(inset)
            a,b,c,d=inset.bounds;bounds=[math.ceil(F(a)*Q),math.ceil(F(b)*Q),math.floor(F(c)*Q),math.floor(F(d)*Q)]
            if bounds[0]>bounds[2] or bounds[1]>bounds[3]:
                discarded.append({'index':i,'raw_face':mapping(raw),'inset_face':mapping(inset),'coordinate_bounds':bounds,'reason':'empty inward grid bounding box'});continue
            assert 0<=bounds[0]<=bounds[2]<=MAXX and 0<=bounds[1]<=bounds[3]<=MAXY
            domains.append({'index':i,'raw_face':mapping(raw),'inset_face':mapping(inset),'coordinate_bounds':bounds,'halfplanes':inequalities(inset,True)})
        assert len(domains)+len(discarded)==len(faces);total+=len(faces)
        write(OUT/'queries'/f"{q['index']:03d}.json",{'query':q,'source_query_sha256':digest(REG/'queries'/f"{q['index']:03d}.json"),
            'raw_union_covers_whole_region':raw_union.covers(region),'raw_uncovered_geometry':mapping(missing),'raw_uncovered_area_mm2':missing.area,
            'raw_faces':len(faces),'merge':merge,'domains':domains,'discarded_faces':discarded})
        qsummary.append({'query':q['index'],'raw_faces':len(faces),'domains':len(domains),'discarded_faces':len(discarded),
            'raw_uncovered_area_mm2':missing.area,'raw_whole_region_coverage':raw_union.covers(region),**merge})
    write(OUT/'pending-queries.json',queries[len(qsummary):])
    if len(qsummary)==20:
        for case in mutual:
            if time.perf_counter()>=deadline or total>=200000:break
            pa=shape(profiles[case['profile_a']]['geometry']);pb=shape(profiles[case['profile_b']]['geometry'])
            raw=raw_obstacle(pa,pb);forbidden=expand(raw,.2125,.0001);faces,merge=convex_faces(forbidden,deadline);expanded=[];records=[]
            for i,face in enumerate(faces):
                pts=list(face.exterior.coords)[:-1]
                poly=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(pts,[(-EPS,-EPS),(-EPS,EPS),(EPS,EPS),(EPS,-EPS)])]).convex_hull,sign=1)
                assert poly.covers(face);expanded.append(poly);records.append({'index':i,'raw_face':mapping(face),'expanded_face':mapping(poly),'outside_halfplanes':inequalities(poly,False)})
            assert unary_union(expanded).covers(forbidden);total+=len(faces)
            write(OUT/'mutual'/f"{case['index']:03d}.json",{'case':case,'raw_forbidden':mapping(raw),'expanded_forbidden':mapping(forbidden),
                'merge':merge,'faces':records,'complete_forbidden_covered':True})
            msummary.append({**case,'faces':len(faces),'outside_halfplanes':sum(len(r['outside_halfplanes']) for r in records),**merge})
            if len(msummary)%20==0:print({'mutual_cases':len(msummary),'total_faces':total,'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'pending-mutual.json',mutual[len(msummary):]);write(OUT/'query-summary.json',qsummary);write(OUT/'mutual-summary.json',msummary)
    result={'seconds':time.perf_counter()-start,'queries_planned':20,'queries_completed':len(qsummary),'queries_pending':20-len(qsummary),
        'allowed_raw_faces':sum(r['raw_faces'] for r in qsummary),'allowed_domains':sum(r['domains'] for r in qsummary),
        'discarded_allowed_faces':sum(r['discarded_faces'] for r in qsummary),'allowed_raw_queries_with_uncovered_area':sum(r['raw_uncovered_area_mm2']>0 for r in qsummary),
        'mutual_cases_planned':82,'mutual_cases_completed':len(msummary),'mutual_cases_pending':82-len(msummary),
        'forbidden_convex_faces':sum(r['faces'] for r in msummary),'outside_halfplanes':sum(r['outside_halfplanes'] for r in msummary),
        'merge_cap_geometries':sum(r['merge_cap_reached'] for r in qsummary+msummary),'merge_time_geometries':sum(r['merge_time_reached'] for r in qsummary+msummary),
        'face_cap_reached':total>=200000,'independent_audit_pending':True,'full_original_joint_solver_calls':0,
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
