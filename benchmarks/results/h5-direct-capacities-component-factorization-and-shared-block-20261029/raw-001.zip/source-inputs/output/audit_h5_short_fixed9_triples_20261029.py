"""Independent complete 64-corner audit of the required triple-core certificates."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product,combinations
from collections import Counter
from datetime import datetime,timezone
from math import lcm
import json,shutil,time
from h5_legacy64_source_readback import audit
from h5_continuous_core_certificate_reader_20261028 import cross,contains
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-fixed9-triples-20261029';OUT=BASE/'audit';INV=ROOT/'output/h5-short-fixed9-inventory-20261029';PAIR=ROOT/'output/h5-short-fixed9-joint-20261029';PRE=ROOT/'output/h5-short-joint-core-20261028';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def corners(r):return [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]
def project(p,i,j):return p[2*i:2*i+2] if j is None else [p[2*j]-p[2*i],p[2*j+1]-p[2*i+1]]
def integer_inside(poly,p,scale):return all((b[0]-a[0])*(p[1]-a[1]*scale)-(b[1]-a[1])*(p[0]-a[0]*scale)>=0 for a,b in zip(poly,poly[1:]+poly[:1]))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for file in [BASE/'plan.json',PAIR/'audit/plan.json',INV/'audit/plan.json',PRE/'audit/plan.json']:
    for n,h in load(file)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PAIR/'audit/checks.json')['passed'] and load(INV/'audit/checks.json')['passed'] and load(PRE/'audit/checks.json')['passed']
survivors=[s for s in load(PAIR/'geometry-summary.json') if not s['geometry_excluded']];pairrows=load(PAIR/'case-summary.json');expected=set()
for s in survivors:
    gi=s['geometry_case'];counts=Counter(k[0] for k in s['removed_parent_identities']);unexcluded=[r for r in pairrows if r['geometry_case']==gi and not r['covered']];brmodes=[r['second_mover_bracket_mode'] for r in unexcluded if r['second_mover_bracket_mode'] is not None]
    if counts['cog']:
        assert counts['bracket']==2 and any(r['second_mover_bracket_mode'] is None for r in unexcluded);expected|={(gi,(None,None,mi)) for mi in brmodes}
    else:
        assert counts['bracket']==3;expected|={(gi,(None,a,b)) for a,b in product(brmodes,repeat=2)}
assert len(expected)==15
core=load(BOUND/'moving-core.json')['vertices_um'];center=list(map(F,load(BOUND/'moving-core.json')['source_center_mm']));fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};cb=load(PRE/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];bc={r['mode']:r for r in load(PRE/'bracket-cores.json')};cache={};sums=refs=vertex_checks=0;casechecks=[];seen_specs=set()
for s in load(BASE/'case-summary.json'):
    name=s['case'];data=load(BASE/'cases'/f'{name}-inputs.json');gi=data['geometry_case'];mi=tuple(data['moving_modes']);assert (gi,mi) in expected and (gi,mi) not in seen_specs;seen_specs.add((gi,mi));case=load(INV/'cases'/f'{gi}.json');rr=[r for p in case['fixed9'] for r in fixed[key(p)]];pieces=[[core] if i is None else [corners(r) for r in bc[i]['rectangles_um']] for i in mi];bb=[cb if i is None else bc[i]['relaxed_anchor_bounds_um'] for i in mi];bounds=[v for b in bb for v in b[:2]]+[v for b in bb for v in b[2:]];assert bounds==data['bounds_um'];ee=[]
    for i,pp in enumerate(pieces):
        for r in rr:
            for p in pp:ee.append((i,None,[(x-u,y-v) for x,y in corners(r) for u,v in p]))
    for i,j in combinations(range(3),2):
        for p in pieces[i]:
            for q in pieces[j]:ee.append((i,j,[(x-u,y-v) for x,y in p for u,v in q]))
    obs=data['obstacles'];assert len(obs)==len(ee)
    for (i,j,points),o in zip(ee,obs):
        assert (o['first'],o['second'])==(i,j);pointset=tuple(sorted(set(points)));poly=list(map(tuple,o['vertices_um']))
        if pointset in cache:assert poly==cache[pointset]
        else:
            assert len(poly)>=3 and len(set(poly))==len(poly) and all(type(v)==int for p in poly for v in p) and all(p in pointset for p in poly)
            for a,b in zip(poly,poly[1:]+poly[:1]):assert all(cross(a,b,p)>0 for p in poly if p not in (a,b))
            assert all(contains(poly,p) for p in pointset);cache[pointset]=poly;sums+=len(pointset)
        refs+=1
    cert=load(BASE/'cases'/f'{name}-certificate.json');nodes=cert['nodes'];visited=set();leaves=[]
    def visit(idx,expectedbounds,depth):
        global vertex_checks
        assert type(idx)==int and 0<=idx<len(nodes) and idx not in visited;visited.add(idx);node=nodes[idx];r=list(map(F,node['bounds_um']));assert r==expectedbounds and node['depth']==depth and depth<=60
        if 'covered_by' in node:
            assert set(node)=={'bounds_um','depth','covered_by'};oi=node['covered_by'];assert type(oi)==int and 0<=oi<len(obs);o=obs[oi];scale=lcm(*(v.denominator for v in r));ints=[v.numerator*(scale//v.denominator) for v in r]
            for p in product(*[(ints[k],ints[k+6]) for k in range(6)]):assert integer_inside(o['vertices_um'],project(p,o['first'],o['second']),scale);vertex_checks+=len(o['vertices_um'])
            leaves.append(idx)
        else:
            assert set(node)=={'bounds_um','depth','split_axis','left','right'};axis=max(range(6),key=lambda k:r[k+6]-r[k]);assert node['split_axis']==axis;m=(r[axis]+r[axis+6])/2;a=r[:];b=r[:];a[axis+6]=m;b[axis]=m;visit(node['left'],a,depth+1);visit(node['right'],b,depth+1)
    visit(0,list(map(F,bounds)),0)
    assert len(visited)==len(nodes)==s['nodes'] and len(nodes)<=100000 and cert['covered'] and s['covered'] and cert['unprocessed_boxes']==0 and cert['limit'] is None and cert['relaxation_witness_um'] is None
    casechecks.append({'case':name,'geometry_case':gi,'moving_modes':list(mi),'exact_nodes':len(nodes),'covered_hyperrectangle_leaves':len(leaves),'all_continuous_triple_core_placements_excluded':True})
assert seen_specs==expected
geometry=load(BASE/'geometry-summary.json');assert len(geometry)==5
for g,s in zip(geometry,survivors):
    assert g['geometry_case']==s['geometry_case'] and g['inventory_variants']==s['inventory_variants'] and g['removed_parent_identities']==s['removed_parent_identities'];cc=[r for r in casechecks if r['geometry_case']==g['geometry_case']];assert len(cc)==g['triple_cases'] and g['excluded'] and not g['unexcluded_triple_cases']
# Original-source positive triples independently check both role arrangements and all pair signs.
job=load(JOB);sourceplan=load(OLD/'plan.json');modes=load(ROOT/'output/h5-short-adjacent-exchange-20261028/modes.json');controls=[]
for name,ms,xy in [('164-cg-cg-36',[None,None,36],[(200.,160.),(700.,160.),(1100.,20.)]),('027-cg-43-43',[None,43,43],[(200.,160.),(600.,10.),(1000.,10.)])]:
    rows=[];copies=Counter()
    for mi,p in zip(ms,xy):
        family='cog' if mi is None else 'bracket';copy=copies[family];copies[family]+=1
        if mi is None:t={'rotation_radians':0.,'mirrored':False,'translation':[p[k]-float(center[k]) for k in [0,1]]}
        else:m=modes[mi];t={'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[p[k]+m['source_translation_offset'][k] for k in [0,1]]}
        rows.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-1','transform':t})
    checked=audit(job,rows,{'sheet-1':sourceplan['source_stock']},sourceplan['required_pair_gap_mm'],sourceplan['stock_guard_mm'],[key(p) for p in rows]);assert checked['valid'];write(OUT/f'positive-source-{name}.json',checked);flat=[int(v*1000) for p in xy for v in p];pairpred=[o for o in load(BASE/'cases'/f'{name}-inputs.json')['obstacles'] if o['second'] is not None];assert all(not contains(o['vertices_um'],project(flat,o['first'],o['second'])) for o in pairpred);controls.append({'case':name,'source_triple_valid':True,'all_three_pair_predicates_pass':True})
negative=next(o for o in load(BASE/'cases/164-cg-cg-36-inputs.json')['obstacles'] if o['first']==0 and o['second']==1);assert contains(negative['vertices_um'],[0,0])
result=load(BASE/'result.json');assert result['closed'] and result['covered_triple_cases']==15 and result['additional_excluded_geometries']==5 and result['remaining_unexcluded_geometries']==0 and result['seconds']<120
write(OUT/'case-checks.json',casechecks);write(OUT/'controls.json',controls)
write(OUT/'necessity-proof.json',{'scope':'The fixed-nine inventory enumerates every choice of one parent bracket sent to the first sheet and two further released parent originals. Single-cog proofs exclude144 geometries; required-pair proofs exclude51 more. The remaining five require either one moving cog and two moving brackets, or two cogs and one bracket. Every mode omitted here has a complete audited pair exclusion; depth-limited modes remain included. All ordered mode combinations are present, so no label symmetry is assumed.',
 'exact_geometry':'Previously verified source-contained cores and all-angle stock bounds are unchanged by hash. Every fixed and moving-pair no-fit polygon is independently reconstructed from the full exact vertex-difference set. Pair direction is second anchor minus first anchor. Two original-source positive triple controls cover both mover-role arrangements; coincident cog centers fail the negative control.',
 'continuous_coverage':'Each root is the full continuous six-variable domain of its three mover anchors. Every child pair exactly partitions its parent rational hyperrectangle. All64 actual vertices of every covered leaf satisfy one convex forbidden predicate; exact integer scaling preserves every rational value. Every saved node is reached once, and all leaves are covered. Cog rotations remain arbitrary real values.',
 'conclusion':'All200 fixed-nine geometries and all330 identity variants are excluded for this target13 short-sheet allocation. A completion cannot retain nine of these twelve parent poses: at least four must change. The5-bracket/6-insert/2-cog allocation, other parent layouts and the original66-part job are not excluded. No construction, solver or native call is made by this proof.'})
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_continuous_core_certificate_reader_20261028.py',BASE/'plan.json',PAIR/'audit/plan.json',INV/'audit/plan.json',PRE/'audit/plan.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all15_required_triple_cases_verified':True,'unique_exact_no_fit_polygons':len(cache),'unique_exact_vertex_sums':sums,'exact_obstacle_references_verified':refs,'exact_six_dimensional_nodes':sum(c['exact_nodes'] for c in casechecks),'covered_hyperrectangle_leaves':sum(c['covered_hyperrectangle_leaves'] for c in casechecks),'exact_64_corner_plane_checks':vertex_checks,'all5_remaining_fixed9_geometries_excluded':True,'combined_fixed9_geometries_excluded':200,'combined_identity_variants_excluded':330,'minimum_parent_poses_that_must_change':4,'positive_source_triple_controls':2,'negative_coincident_cog_control_passed':True,'full_allocation_or_original_job_excluded':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
