"""Necessary mixed-component strip bounds over exact unions of unary projection intervals."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import itertools,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';COUNT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';OUT=ROOT/'output/h5-first55-component-strip-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(COUNT/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(COUNT/'source-inner-rectangles.json').items()};unary=load(PRIOR/'integer-preparation/unary-templates.json')
strips=[];axis_offsets=[]
for axis,n,origin in [(0,151,0),(1,101,2000)]:
    axis_offsets.append(len(strips));strips.extend((axis,origin+10*a,origin+10*b,a,b) for a,b in itertools.combinations(range(n),2))
axis_offsets.append(len(strips));assert len(strips)==16375
def merge(intervals):
    result=[]
    for lo,hi in sorted(intervals):
        if result and lo<=result[-1][1]:result[-1]=(result[-1][0],max(hi,result[-1][1]))
        else:result.append((lo,hi))
    return tuple(result)
@lru_cache(None)
def estimated_mode(f,m,axis,intervals):
    local=strips[axis_offsets[axis]:axis_offsets[axis+1]];left=np.array([s[1] for s in local],dtype=np.float64);right=np.array([s[2] for s in local],dtype=np.float64);minimum=np.full(len(local),np.inf)
    boxes=[[float(v) for v in b] for b in inner[f][m]]
    for lo,hi in intervals:
        l,h=float(lo),float(hi);candidates=[np.full(len(local),l),np.full(len(local),h)]
        for box in boxes:
            for edge in [box[axis],box[axis+2]]:candidates.extend([np.clip(left-edge,l,h),np.clip(right-edge,l,h)])
        for shift in candidates:
            amount=np.zeros(len(local))
            for box in boxes:amount+=np.maximum(0.,np.minimum(right,box[axis+2]+shift)-np.maximum(left,box[axis]+shift))*(box[3-axis]-box[1-axis])
            minimum=np.minimum(minimum,amount)
    return minimum
@lru_cache(None)
def exact_mode(f,m,axis,intervals,left,right):
    least=None;tested=0
    for lo,hi in intervals:
        candidates={lo,hi}
        for box in inner[f][m]:
            for cut in [left,right]:
                for edge in [box[axis],box[axis+2]]:
                    shift=cut-edge
                    if lo<=shift<=hi:candidates.add(shift)
        for shift in candidates:
            amount=sum(max(F(0),min(right,box[axis+2]+shift)-max(left,box[axis]+shift))*(box[3-axis]-box[1-axis]) for box in inner[f][m]);tested+=1
            least=amount if least is None else min(least,amount)
    assert least is not None
    return least,tested
rows=[];initial_total=remaining_total=cert_count=0;subsets_done=strips_screened=exact_strips=source_breakpoints=0;all_complete=True
for prior in load(COUNT/'all29-vectorized-bounds.json'):
    groups=prior['groups'];possible={tuple(v) for v in prior['remaining_distributions']};initial_total+=len(possible);records=[];complete=True;completed_subsets=screened=checked=breakpoints=0
    raw=[{} for g in groups]
    for f,m,gid,ri,gi in prior['region_component_assignments']:
        p=[tuple(map(F,v)) for v in unary[gid]['regions'][ri]['hull_vertices']];raw[gi].setdefault(m,[[],[]])
        for axis in [0,1]:raw[gi][m][axis].append((min(v[axis] for v in p),max(v[axis] for v in p)))
    projection=[{m:[merge(intervals) for intervals in axes] for m,axes in by_mode.items()} for by_mode in raw]
    estimates=np.zeros((16375,len(groups)))
    if time.perf_counter()-started<58:
        for gi,g in enumerate(groups):
            for axis in [0,1]:
                values=[estimated_mode(g['family'],m,axis,axes[axis]) for m,axes in projection[gi].items()];estimates[axis_offsets[axis]:axis_offsets[axis+1],gi]=np.min(np.array(values),axis=0)
    else:complete=False;all_complete=False
    for selected_mask in range(1,1<<len(groups)):
        selected=[i for i in range(len(groups)) if selected_mask>>i&1]
        if {groups[i]['family'] for i in selected}!={'bracket','insert'}:continue
        if not complete or time.perf_counter()-started>=58:complete=False;all_complete=False;break
        union=0
        for i in selected:union|=int(groups[i]['support_hex'],16)
        xs=[0]*150;ys=[0]*100;bits=union
        while bits:
            low=bits&-bits;y,x=divmod(low.bit_length()-1,150);xs[x]+=1;ys[y]+=1;bits^=low
        prefix=[np.concatenate(([0],np.cumsum(values,dtype=np.int64))) for values in [xs,ys]];available=np.array([(prefix[axis][b]-prefix[axis][a])*100 for axis,l,r,a,b in strips],dtype=np.int64);screened+=len(strips);strips_screened+=len(strips)
        if possible:
            counts=np.array(sorted(possible),dtype=np.float64);estimate=counts[:,selected]@estimates[:,selected].T;candidate_indices=np.flatnonzero(np.any((estimate>available-1e-4)&(estimate>1e-4),axis=0))
        else:candidate_indices=[]
        for si in candidate_indices:
            if time.perf_counter()-started>=58:complete=False;all_complete=False;break
            axis,left,right,_,_=strips[int(si)];values={};coefficients=[F(0)]*len(groups);case_count=0
            for gi in selected:
                g=groups[gi];values[str(gi)]={}
                for m,axes in projection[gi].items():
                    minimum,cases=exact_mode(g['family'],m,axis,axes[axis],F(left),F(right));values[str(gi)][str(m)]=str(minimum);case_count+=cases
                coefficients[gi]=min(map(F,values[str(gi)].values()))
            checked+=1;exact_strips+=1;breakpoints+=case_count;source_breakpoints+=case_count
            removed=sorted(v for v in possible if sum(v[i]*coefficients[i] for i in selected)>int(available[int(si)]))
            if removed:records.append({'groups':selected,'axis':axis,'strip_mm':[left,right],'upper_area_mm2':int(available[int(si)]),'selected_group_mode_minimum_area_mm2':values,'coefficients_mm2':[str(v) for v in coefficients],'source_breakpoint_cases':case_count,'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
        if not complete:break
        completed_subsets+=1;subsets_done+=1
    cert_count+=len(records);remaining_total+=len(possible)
    rows.append({'empty_sites':prior['empty_sites'],'initial_distributions':prior['remaining_distributions'],'projection_intervals_mm':[{str(m):[[[str(v) for v in interval] for interval in axis] for axis in axes] for m,axes in by_mode.items()} for by_mode in projection],'certificates':records,'remaining_distributions':[list(v) for v in sorted(possible)],'mixed_subsets_completed':completed_subsets,'strips_screened':screened,'strips_recomputed_exactly':checked,'source_breakpoint_cases':breakpoints,'scan_complete':complete,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),COUNT/'plan.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all29-vectorized-bounds.json',COUNT/'source-inner-rectangles.json',PRIOR/'integer-preparation/unary-templates.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Project every original convex unary hull onto each axis and merge exact overlapping intervals by family component and source mode. A contained rectangle contributes strip area that is piecewise linear in translation. Minimize the sum of source-piece strip areas over every allowed interval at its endpoints and all source-edge/strip-boundary breakpoints, then take the minimum over legal modes. For each mixed component subset, compare count-weighted mandatory area against its exact grid-cell strip area. Floating vectorization only screens prospective violations; each recorded exclusion uses exact rational minima.','axis_strips_per_mixed_subset':16375,'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_distributions_retained':True,'floating_exclusions_permitted':False,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'all29-strip-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':all_complete,'site_pairs_retained_in_table':len(rows),'initial_count_distributions':initial_total,'remaining_count_distributions':remaining_total,'count_distributions_excluded':initial_total-remaining_total,'certificates':cert_count,'mixed_subsets_completed':subsets_done,'strips_screened':strips_screened,'strips_recomputed_exactly':exact_strips,'source_breakpoint_cases':source_breakpoints,'new_restricted_site_exclusions':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
