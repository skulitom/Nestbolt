from pathlib import Path
import json, numpy as np, shapely
from shapely.geometry import Polygon, MultiPoint, box, mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull, merge_exact
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[1]
namespace={}
src=(ROOT/'output/prepare_h5_first55_compact_regions_20261029.py').read_text(encoding='utf-8')
namespace['__file__']=str(ROOT/'output/prepare_h5_first55_compact_regions_20261029.py')
exec(compile(src.split("assert load(PRIOR/")[0],'<helper definitions>','exec'),namespace)
lib=json.loads((ROOT/'output/h5-first55-after-source-valid11-20261029/geometry-library.json').read_bytes())
ga,gb=4,8;r=.226;square=np.asarray([[-r,-r],[r,-r],[r,r],[-r,r]])
stock=[6.5,2107.85,1493.5,2993.5]
bounds=lambda g:[[stock[0]+.025,stock[2]-.025-g['dimensions'][0]],[stock[1]+.025,stock[3]-.025-g['dimensions'][1]]]
A,B=bounds(lib[ga]),bounds(lib[gb]);domain=[B[0][0]-A[0][1],B[1][0]-A[1][1],B[0][1]-A[0][0],B[1][1]-A[1][0]]
pieces=[MultiPoint((((np.asarray(a)[:,None,:]-np.asarray(b)[None,:,:]).reshape(-1,2))[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull for a in lib[ga]['pieces'] for b in lib[gb]['pieces']]
inflated=unary_union(pieces);envelope=inflated.convex_hull
outer=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]])
regions=[p for a,b in zip(outer,outer[1:]+outer[:1]) if (p:=namespace['clip_exterior'](domain,a,b)) is not None]
pockets=envelope.difference(inflated).intersection(box(*domain))
tri=list(shapely.constrained_delaunay_triangles(pockets).geoms);merged,count=merge_exact(tri)
exterior=unary_union([Polygon(p) for p in regions]);combined=unary_union([Polygon(p) for p in regions+merged]);free=box(*domain).difference(inflated)
data={'domain':domain,'pockets':mapping(pockets),'pocket_area':pockets.area,'triangle_area':sum(p.area for p in tri),'merged_area':sum(Polygon(p).area for p in merged),'exterior_intersection_envelope':exterior.intersection(envelope).area,'missing_area':free.difference(combined).area,'extra_area':combined.difference(free).area,'difference':mapping(combined.symmetric_difference(free)),'outer_hull':[list(map(float,p)) for p in outer]}
out=ROOT/'output/h5-first55-after-source-valid11-20261029/compact-pair-regions/failure-diagnostic.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
print({k:v for k,v in data.items() if k not in ['pockets','difference','outer_hull']})
