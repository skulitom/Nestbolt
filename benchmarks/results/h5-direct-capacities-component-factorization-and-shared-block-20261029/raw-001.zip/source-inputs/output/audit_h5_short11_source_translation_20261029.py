"""Independently verify source coverage, every frozen axis, signs and stock bounds."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from fractions import Fraction as F
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';PRE=BASE/'source-translation-preflight';OUT=PRE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(PRE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);parts={p['id']:p for p in job['parts']};rows=load(PRE/'seed-source11.json');canonical=load(PRE/'canonical-pieces.json');world=load(PRE/'world-pieces.json');planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');stock=sp['source_stock'];gap=.225;extra=.025;assert gap>sp['required_pair_gap_mm'] and extra>sp['stock_guard_mm'];assert len(rows)==len(world)==11
for family,pieces in canonical.items():
    outline=parts[family]['geometry'][0]['outer'];g=Polygon(outline);polys=[Polygon(p) for p in pieces];assert all(p.area>0 and p.is_valid and p.equals(p.convex_hull) for p in polys);u=unary_union(polys);assert u.symmetric_difference(g).area<1e-7 and abs(sum(p.area for p in polys)-u.area)<1e-7
    if family=='cog':
        assert len(pieces)==80
        for i,p in enumerate(pieces):assert p==[[float(F(69861871,500000))]*2,outline[i],outline[(i+1)%80]]
for i,(row,saved) in enumerate(zip(rows,world)):
    assert saved['index']==i and saved['identity']==[row['part_id'],row['copy_index']];t=row['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mirror=-1 if t['mirrored'] else 1
    def posed(points):return [[mirror*x*co-y*si+t['translation'][0],mirror*x*si+y*co+t['translation'][1]] for x,y in points]
    assert saved['outline']==posed(parts[row['part_id']]['geometry'][0]['outer']) and saved['pieces']==[posed(p) for p in canonical[row['part_id']]];b=Polygon(saved['outline']).bounds;assert list(b)==saved['bounds'];expected=[[stock[0]+extra-b[0],stock[2]-extra-b[2]],[stock[1]+extra-b[1],stock[3]-extra-b[3]]];assert bounds[2*i:2*i+2]==expected
assert bounds[-1]==[0,1500] and len(bounds)==23 and all(lo<hi for lo,hi in bounds);expectedpairs=[(a['index'],b['index'],ai,bi) for a,b in combinations(world,2) for ai in range(len(a['pieces'])) for bi in range(len(b['pieces']))];assert len(expectedpairs)==len(planes)==8726;negative_seed_rows=0;largest_error=0
for row,key in zip(planes,expectedpairs):
    a,b,ai,bi=key;assert row['owners']==[a,b] and row['pieces']==[ai,bi];A=world[a]['pieces'][ai];B=world[b]['pieces'][bi];n=row['normal'];assert abs(sum(x*x for x in n)-1)<1e-12
    def project(p):return p[0]*n[0]+p[1]*n[1]
    actual=min(map(project,B))-max(map(project,A));err=abs(actual-row['seed_projection_gap_mm']);largest_error=max(largest_error,err);assert err<1e-9 and abs(row['upper_delta_difference_mm']-(actual-gap))<1e-9
    candidates=[]
    for poly in [A,B]:
        for p,q in zip(poly,poly[1:]+poly[:1]):
            x,y=q[0]-p[0],q[1]-p[1];length=math.hypot(x,y)
            for normal in [(-y/length,x/length),(y/length,-x/length)]:candidates.append(min(v[0]*normal[0]+v[1]*normal[1] for v in B)-max(v[0]*normal[0]+v[1]*normal[1] for v in A))
    assert abs(actual-max(candidates))<1e-9;negative_seed_rows+=actual<gap
    # Each independently reconstructed row accepts a one-mm-safe translation
    # and rejects a one-mm-unsafe translation. These are per-row sign controls.
    safe=[v*(gap-actual+1) for v in n];unsafe=[v*(gap-actual-1) for v in n];assert -sum(x*y for x,y in zip(n,safe))<row['upper_delta_difference_mm'] and -sum(x*y for x,y in zip(n,unsafe))>row['upper_delta_difference_mm']
inputs=[Path(__file__),JOB,PRE/'plan.json',BASE/'source-audit-v2/plan.json']+[PRE/n for n in ['canonical-pieces.json','world-pieces.json','planes.json','variable-bounds.json','seed-source11.json','checks.json','method.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'original_source_poses':11,'convex_partition_pieces':174,'source_coverage_verified':True,'all_piece_pair_axes_and_rows_verified':8726,'per_row_positive_and_negative_controls':8726,'stock_translation_domains_verified':22,'all_original_translations_free':True,'frozen_cog_phases_degrees':[7,7],'target_gap_mm':gap,'target_stock_extra_mm':extra,'seed_rows_below_target_gap':negative_seed_rows,'largest_projection_replay_error_mm':largest_error,'sufficient_source_separation_system_only':True,'infeasibility_would_not_exclude_allocation':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
