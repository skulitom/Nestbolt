"""Build a CP-SAT source construction with conditional exact integer region planes."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from ortools.sat.python import cp_model

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-first55-integer-mode-regions-v2-20261029'
PRIOR = ROOT / 'output/h5-first55-after-source-valid11-20261029'
SHORT = ROOT / 'output/h5-short11-integer-mode-regions-20261029'
OUT = BASE / 'model'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(BASE / 'geometry-audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'build.py')
started = time.perf_counter()
family_modes, instances, templates, owner_pairs = [load(BASE / n) for n in ['family-modes.json', 'instances.json', 'integer-templates.json', 'owner-pairs.json']]
model = cp_model.CpModel()
owners, pairs = [], []
for owner, instance in enumerate(instances):
    modes = family_modes[instance['identity'][0]]
    position_vars = []
    for axis in [0, 1]:
        lo = min(m['integer_lower_left_bounds'][axis][0] for m in modes)
        hi = max(m['integer_lower_left_bounds'][axis][1] for m in modes)
        variable = model.new_int_var(lo, hi, f'{"x" if axis == 0 else "y"}_{owner}_um')
        assert variable.index == 2*owner+axis
        position_vars.append(variable.index)
    owners.append({'owner': owner, 'identity': instance['identity'], 'positions': position_vars, 'modes': []})

def linear(coefficients, lo, hi, guard=None):
    expression = sum(value*model.get_int_var_from_proto_index(index) for index, value in coefficients.items() if value)
    constraint = model.add_linear_constraint(expression, lo, hi)
    if guard is not None:
        constraint.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return constraint.index

for owner in owners:
    for mode in family_modes[owner['identity'][0]]:
        selector = model.new_bool_var(f'mode_{owner["owner"]}_{mode["mode"]}')
        record = {**mode, 'selector': selector.index, 'stock_constraints': []}
        for axis, variable in enumerate(owner['positions']):
            lo, hi = mode['integer_lower_left_bounds'][axis]
            record['stock_constraints'].append(linear({variable: 1}, lo, hi, selector.index))
        owner['modes'].append(record)
    owner['one_mode_constraint'] = linear({m['selector']: 1 for m in owner['modes']}, 1, 1)
assert len(model.proto.variables) == 145
plane_count = 0
for expected in owner_pairs:
    ia, ib = expected['owners']
    record = {'owners': [ia, ib], 'regions': [], 'mode_marginals': []}
    for template_index in expected['template_indices']:
        template = templates[template_index]
        for region in template['regions']:
            selector = model.new_bool_var(f'region_{ia}_{ib}_{template_index}_{region["region"]}')
            saved = {'template': template_index, 'region': region['region'], 'geometries': template['geometries'], 'selector': selector.index, 'plane_constraints': []}
            for plane in region['planes']:
                nx, ny = plane['coefficients']
                coefficients = {2*ia: -nx, 2*ia+1: -ny, 2*ib: nx, 2*ib+1: ny}
                saved['plane_constraints'].append(linear(coefficients, cp_model.INT_MIN, plane['upper'], selector.index))
                plane_count += 1
            record['regions'].append(saved)
    record['one_region_constraint'] = linear({r['selector']: 1 for r in record['regions']}, 1, 1)
    for side, owner in enumerate([ia, ib]):
        for geometry in sorted({m['normalized_geometry'] for m in owners[owner]['modes']}):
            ms = [m['selector'] for m in owners[owner]['modes'] if m['normalized_geometry'] == geometry]
            rs = [r['selector'] for r in record['regions'] if r['geometries'][side] == geometry]
            coefficients = {**{i: -1 for i in ms}, **{i: 1 for i in rs}}
            record['mode_marginals'].append({'owner': owner, 'side': side, 'geometry': geometry,
                                             'mode_selectors': ms, 'region_selectors': rs,
                                             'constraint': linear(coefficients, 0, 0)})
    pairs.append(record)
symmetry = []
for family in ['bracket', 'insert', 'cog']:
    same = sorted((o for o in owners if o['identity'][0] == family), key=lambda o: o['identity'][1])
    for a, b in zip(same, same[1:]):
        symmetry.append({'family': family, 'owners': [a['owner'], b['owner']],
                         'constraint': linear({2*a['owner']: 1, 2*b['owner']: -1}, cp_model.INT_MIN, 0)})
validation = model.validate()
write(OUT / 'validation.json', {'validation': validation})
assert validation == '' and len(model.proto.variables) == 88835
assert model.export_to_file(str(OUT / 'model.pb')) and model.export_to_file(str(OUT / 'model.pbtxt'))
write(OUT / 'mapping.json', {'owners': owners, 'pairs': pairs, 'symmetry_constraints': symmetry, 'position_units_per_mm': 1000})
elapsed = time.perf_counter()-started
charges = {'source_valid_short11_shared_seconds': load(SHORT / 'response-audit/checks.json')['shared_seconds_including_preparation'],
           'first_sheet_mode_preparation_seconds': load(PRIOR / 'checks.json')['seconds'],
           'compact_pair_region_preparation_seconds': load(PRIOR / 'compact-pair-regions-v2/checks.json')['seconds'],
           'integer_plane_preparation_seconds': load(BASE / 'checks.json')['seconds'], 'cp_model_build_seconds': elapsed}
write(OUT / 'preparation-charges.json', charges)
inputs = [Path(__file__), PRIOR / 'checks.json', PRIOR / 'compact-pair-regions-v2/checks.json', SHORT / 'response-audit/plan.json', SHORT / 'response-audit/checks.json', BASE / 'plan.json', BASE / 'checks.json',
          BASE / 'geometry-audit/plan.json', BASE / 'geometry-audit/checks.json'] + [BASE / n for n in ['family-modes.json', 'instances.json', 'integer-templates.json', 'owner-pairs.json', 'inventory.json']]
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}, 'solver_calls': 0})
checks = {'passed': True, 'seconds': elapsed, 'preparation_seconds_charged': sum(charges.values()),
          'variables': len(model.proto.variables), 'constraints': len(model.proto.constraints),
          'source_mode_options': 93, 'region_selectors': 88690, 'conditional_integer_region_planes': plane_count,
          'guarded_mode_stock_domains': 186, 'both_owner_mode_marginals': 2025, 'identity_symmetry_constraints': 23,
          'continuous_weights': 0, 'deactivation_constants': 0, 'model_sha256': digest(OUT / 'model.pb'),
          'model_validation_passed': True, 'independent_model_audit_pending': True,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
