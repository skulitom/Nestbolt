"""Independently check every13-of15 site allocation against original source contours."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json, math, shutil, time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';OUT=BASE/'audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OLD=ROOT/'output/h5-oblique64-source-20261028/source64.json';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(FIRST/'plan.json');fixed=load(FIRST/'fixed29.json');sites=load(BASE/'source-cog-sites.json');short=load(SHORT);cases=load(BASE/'all105-site-subsets.json');inventory=load(BASE/'inventory.json')
source_cogs=[r for r in load(OLD) if r['part_id']=='cog' and r['sheet_id']=='sheet-0'];source_cogs.sort(key=lambda r:(r['transform']['translation'][1],r['transform']['translation'][0]));assert sites==source_cogs and len(sites)==15
assert len(cases)==105 and [tuple(r['selected_slots']) for r in cases]==list(combinations(range(15),13))
records=[]
for group,rows in [('fixed',fixed),('site',sites),('short',short)]:
    for i,row in enumerate(rows):
        part=parts[row['part_id']];g=part['geometry'][0];t=row['transform'];assert 0<=row['copy_index']<part['quantity'] and (not t['mirrored'] or part['allow_mirror'])
        assert part['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees'])
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;matrix=[sign*c,-s,sign*s,c,*t['translation']]
        raw=Polygon(g['outer']);full=Polygon(g['outer'],g.get('holes',[]));outer=affine_transform(raw,matrix);filled=affine_transform(full,matrix)
        assert outer.is_valid and filled.is_valid and abs(outer.area-raw.area)<1e-6 and abs(filled.area-full.area)<1e-6 and len(filled.interiors)==len(g.get('holes',[]))
        bounds=outer.bounds;stock=spec['source_stocks'][row['sheet_id']];clearance=[bounds[0]-stock[0],bounds[1]-stock[1],stock[2]-bounds[2],stock[3]-bounds[3]];assert min(clearance)>spec['stock_guard_mm']
        records.append({'group':group,'index':i,'row':row,'shape':outer,'stock':clearance,'cutouts':len(g.get('holes',[])),'hole_vertices':sum(len(h) for h in g.get('holes',[]))})
gap={};pair_proofs=[]
for ai,bi in combinations(range(len(records)),2):
    a,b=records[ai],records[bi]
    if a['row']['sheet_id']!=b['row']['sheet_id']:continue
    distance=a['shape'].distance(b['shape']);assert a['shape'].disjoint(b['shape']) and distance>spec['required_pair_gap_mm']
    gap[ai,bi]=distance;pair_proofs.append({'first':[a['group'],a['index']],'second':[b['group'],b['index']],'distance_mm':distance})
assert len(gap)==1001
all_ids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};missing=set(map(tuple,inventory['moving13_orthogonal_identities']));assert Counter(f for f,i in missing)=={'bracket':7,'insert':6}
reports=[]
for number,case in enumerate(cases):
    assert case['case']==number and case['empty_slots']==sorted(set(range(15))-set(case['selected_slots'])) and case['cog_copy_indices_in_slot_order']==list(range(1,14))
    indices=list(range(29))+[29+i for i in case['selected_slots']]+list(range(44,55));assert len(indices)==53
    keys={(r['part_id'],r['copy_index']) for r in fixed+short}|{('cog',i) for i in case['cog_copy_indices_in_slot_order']}
    assert len(keys)==53 and not keys&missing and keys|missing==all_ids
    distances=[gap[a,b] for a,b in combinations(sorted(indices),2) if (a,b) in gap]
    holes=sum(records[i]['cutouts'] for i in indices);vertices=sum(records[i]['hole_vertices'] for i in indices)
    assert len(distances)==916 and holes==63 and vertices==6732
    reports.append({'case':number,'source_valid53':True,'same_sheet_pairs':len(distances),'stock_edges':212,'cutouts':holes,'hole_vertices':vertices,'minimum_pair_gap_mm':min(distances),'minimum_extra_stock_mm':min(min(records[i]['stock']) for i in indices),'all66_identities_partitioned':True})
control=load(BASE/'partial53-control.json');expected=fixed.copy()
for slot,copy in zip(cases[0]['selected_slots'],cases[0]['cog_copy_indices_in_slot_order']):expected.append({**sites[slot],'copy_index':copy})
expected+=short;assert control==expected
oldcheck=load(BASE/'partial53-source-checks.json');assert oldcheck['valid'] and abs(reports[0]['minimum_pair_gap_mm']-oldcheck['minimum_pair_gap_mm'])<1e-9
write(OUT/'source-pool-pair-proofs.json',pair_proofs);write(OUT/'all105-subset-checks.json',reports)
inputs=[Path(__file__),JOB,OLD,SHORT,FIRST/'plan.json',FIRST/'fixed29.json']+[BASE/n for n in ['plan.json','checks.json','source-cog-sites.json','all105-site-subsets.json','inventory.json','partial53-control.json','partial53-source-checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read original rings and legal transforms through an independent affine path. Check all1001 relevant source-pool pairs and every stock edge once, then verify each of105 site subsets inherits exactly916 required same-sheet pair checks with all63 holes and6732 hole vertices. Verify every full66 identity partition and the declared identical-cog relabelling. No orthogonal mover is considered placed by these partial controls.'})
result={'passed':True,'seconds':time.perf_counter()-started,'unchanged_source_cog_poses':15,'source_pool_pair_checks':1001,'all105_source_valid53_subsets_verified':True,'subset_pair_checks_inherited':105*916,'all105_full66_identity_partitions_verified':True,'all_original_cutouts_and_hole_vertices_verified':True,'orthogonal_movers_still_unplaced':13,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
