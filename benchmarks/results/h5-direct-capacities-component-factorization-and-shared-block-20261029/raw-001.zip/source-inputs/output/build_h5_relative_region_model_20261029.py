"""Build a smaller whole-part relative-region formulation with conservative planes."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, math, shutil, time
import numpy as np
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
PRE = SOURCE / 'relative-free-region-preflight'
OUT = ROOT / 'output/h5-short11-relative-region-model-20261029'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(PRE / 'audit/checks.json')['passed']
assert not OUT.exists()
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'build.py')
started = time.perf_counter()
groups = load(PRE / 'groups.json')
bounds = np.load(SOURCE / 'model.npz')['bounds'][:22]
ri, ci, values, lower, upper, mapped = [], [], [], [], [], []
variable = 22

def row(coeff, lo, hi):
    index = len(lower)
    for column, value in coeff.items():
        if value:
            ri.append(index)
            ci.append(column)
            values.append(value)
    lower.append(lo)
    upper.append(hi)
    return index

for group in groups:
    ia, ib = group['owners']
    indices = [2*ia, 2*ia+1, 2*ib, 2*ib+1]
    domain = bounds[indices]
    # Compute the exact relative rectangle from binary-rational variable bounds.
    relative = [[F(bounds[2*ib, 0])-F(bounds[2*ia, 1]), F(bounds[2*ib, 1])-F(bounds[2*ia, 0])],
                [F(bounds[2*ib+1, 0])-F(bounds[2*ia+1, 1]), F(bounds[2*ib+1, 1])-F(bounds[2*ia+1, 0])]]
    record = {'owners': [ia, ib], 'regions': []}
    for region_index, vertices in enumerate(group['regions']):
        selector = variable
        variable += 1
        region = {'region': region_index, 'selector': selector, 'planes': []}
        points = [tuple(map(F, p)) for p in vertices]
        for edge, (a, b) in enumerate(zip(points, points[1:]+points[:1])):
            ex, ey = b[0]-a[0], b[1]-a[1]
            length = F(math.hypot(float(ex), float(ey)))
            exact_normal = [ey/length, -ex/length]
            normal = [round(float(v), 12) for v in exact_normal]
            error = sum(abs(v-F(w))*max(abs(d[0]), abs(d[1])) for v, w, d in zip(exact_normal, normal, relative))
            exact_rhs = exact_normal[0]*a[0]+exact_normal[1]*a[1]
            rhs = float(exact_rhs-error-F('1e-7'))
            nx, ny = normal
            coefficients = [-nx, -ny, nx, ny]
            maximum = float(sum(c*d[1 if c >= 0 else 0] for c, d in zip(coefficients, domain)))
            M = max(0., maximum-rhs)+1e-8
            values_by_index = dict(zip(indices, coefficients))
            values_by_index[selector] = M
            row_index = row(values_by_index, -np.inf, rhs+M)
            region['planes'].append({'edge': edge, 'normal': normal, 'rhs': rhs, 'M': M,
                                     'rounding_error_bound_mm': float(error), 'row': row_index})
        record['regions'].append(region)
    record['one_of_row'] = row({r['selector']: 1. for r in record['regions']}, 1., 1.)
    mapped.append(record)
matrix = coo_matrix((values, (ri, ci)), shape=(len(lower), variable)).tocsc()
assert variable == 717 and len(mapped) == 55
np.savez(OUT / 'model.npz', data=matrix.data, indices=matrix.indices, indptr=matrix.indptr,
         shape=np.asarray(matrix.shape), lower=lower, upper=upper,
         bounds=np.vstack([bounds, np.tile([0., 1.], (variable-22, 1))]),
         c=np.zeros(variable), integrality=np.r_[np.zeros(22, dtype=int), np.ones(variable-22, dtype=int)])
write(OUT / 'mapping.json', mapped)
shutil.copyfile(SOURCE / 'seed-source11.json', OUT / 'seed-source11.json')
shutil.copyfile(SOURCE / 'inventory.json', OUT / 'inventory.json')
elapsed = time.perf_counter()-started
# Charge all previous source/all-axis preparation as well, even though the regions
# only consume its geometry and stock bounds. The closed solve itself is separate.
charges = {'source_geometry_and_all_axis_preparation_seconds': load(SOURCE / 'checks.json')['preparation_seconds_charged'],
           'free_region_preparation_seconds': load(PRE / 'checks.json')['seconds'],
           'region_model_build_seconds': elapsed}
write(OUT / 'preparation-charges.json', charges)
inputs = [Path(__file__), SOURCE / 'plan.json', SOURCE / 'checks.json', SOURCE / 'model.npz',
          SOURCE / 'seed-source11.json', SOURCE / 'inventory.json', PRE / 'plan.json', PRE / 'checks.json',
          PRE / 'groups.json', PRE / 'audit/plan.json', PRE / 'audit/checks.json', PRE / 'audit/support-certificates.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'Sufficient whole-part construction with one of 695 certified convex free regions selected for each of 55 original pairs. All 22 translations vary over original stock domains. Exact rational edge normals are rounded to 12 decimal places; each plane is tightened by its complete relative-domain rounding error plus 1e-7 mm, so an active modeled region lies inside the certified region. Every inactive plane is relaxed over full stock domains. Objective zero, no fixed seed directions. This is a new region formulation, not a retry of the closed piece-pair search. Fixed source orientations and conservative floating free-space construction restrict negative conclusions; no allocation exclusion. Original-source readback is mandatory for any assignment.',
    'algorithm_seconds': 60, 'shared_seconds': 90, 'node_limit': 128,
    'maximum_calls': 1, 'retry_permitted': False, 'source_validation_reserve_seconds': 3,
})
checks = {'passed': True, 'seconds': elapsed, 'preparation_seconds_charged': sum(charges.values()),
          'original_pair_groups': 55, 'convex_region_selectors': 695, 'variables': variable,
          'rows': len(lower), 'matrix_nonzeros': matrix.nnz,
          'model_sha256': digest(OUT / 'model.npz'), 'independent_audit_pending': True,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
