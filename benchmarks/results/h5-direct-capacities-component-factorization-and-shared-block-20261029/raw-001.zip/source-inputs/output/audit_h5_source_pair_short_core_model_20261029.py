"""Independently audit the source-pair extension and unchanged controls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_source_pair_short_core_reader_20261029 import inspect,violations
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-pair-short-core-20261029';OLD=ROOT/'output/h5-strip-capacity-short-core-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,MODEL,OLD/'model-audit',OLD/'cog-source-separation/audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'model-audit/checks.json')['passed'] and load(OLD/'cog-source-separation/audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());parent=cp_model_pb2.CpModelProto();parent.ParseFromString((OLD/'model/model.pb').read_bytes());mp=load(MODEL/'mapping.json');checked=inspect(p,parent,mp,load(OLD/'model/mapping.json'),load(OLD/'cog-source-separation/bound.json'))
for n in ['positive-control-assignment.json','negative-assignment.json']:assert digest(MODEL/n)==digest(OLD/'model'/n)
pos=load(MODEL/'positive-control-assignment.json');neg=load(MODEL/'negative-assignment.json');positive=violations(p,pos);relaxed=violations(p,pos,mp['control_disabled_mandatory_constraints']);negative=violations(p,neg)
assert [r['constraint'] for r in positive['failed_constraints']]==mp['control_disabled_mandatory_constraints'] and not relaxed['failed_constraints'];assert len(negative['failed_constraints'])==38 and not negative['original_source_pair_check']['passed'];write(OUT/'controls.json',{'positive_full':positive,'positive_only_two_missing_requirements_disabled':relaxed,'negative_full':negative})
inputs=[Path(__file__),ROOT/'output/h5_source_pair_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',OLD/'model-audit/plan.json',OLD/'cog-source-separation/audit/plan.json']+[MODEL/n for n in ['model.pb','model.pbtxt','mapping.json','built.json','positive-control-assignment.json','negative-assignment.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-start,'variables_verified':1566,'constraints_verified':1620,'positive11_with_only_missing_requirements_disabled_passes':True,'negative13_failed_constraints':38,'separate_positive_and_negative_original_cog_pairs_audited':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
