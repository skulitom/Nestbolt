"""Independent exact source-containment and continuous coverage certificate audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime, timezone
import json, math, shutil, time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-short-two-cog-exchange-20261028'
DATA=BASE/'all-angle-bound'; OUT=DATA/'audit'
PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def turn(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])

def parity(p,vv):
    n=0
    for a,b in zip(vv,vv[1:]+vv[:1]):
        if min(a[1],b[1])<=p[1]<max(a[1],b[1]):
            intersection=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
            n+=int(intersection>p[0])
    return n%2==1

def segment_touches_rect(a,b,r):
    low,high=F(0),F(1)
    for k in (0,1):
        delta=b[k]-a[k]
        if not delta:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            t0,t1=sorted(((r[k]-a[k])/delta,(r[k+2]-a[k])/delta))
            low=max(low,t0);high=min(high,t1)
            if low>high:return False
    return True

def transformed(points,t):
    co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']); sign=-1 if t['mirrored'] else 1
    return [tuple(F(str(v)) for v in (sign*x*co-y*si+t['translation'][0],sign*x*si+y*co+t['translation'][1])) for x,y in points]

def contains_convex(vertices,p):return all(turn(a,b,p)>=0 for a,b in zip(vertices,vertices[1:]+vertices[:1]))

OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
plan=load(DATA/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert plan['max_nodes_per_case']==100000 and plan['max_depth']==30 and not plan['retry_permitted']
job=load(JOB);parts={p['id']:p for p in job['parts']};assert parts['cog']['rotations']['kind']=='free'
coredata=load(DATA/'moving-core.json');center=list(map(F,coredata['source_center_mm']));core=[tuple(p) for p in coredata['vertices_um']]
original=[tuple(F(str(v)) for v in p) for p in parts['cog']['geometry'][0]['outer']]
assert Polygon(original).is_valid and parity(center,original) and len(core)==32 and len(set(core))==32
assert all(type(v)==int for p in core for v in p)
distances=[]
for a,b in zip(original,original[1:]+original[:1]):
    dx,dy=b[0]-a[0],b[1]-a[1]; dd=dx*dx+dy*dy;assert dd>0
    projection=(center[0]-a[0])*dx+(center[1]-a[1])*dy
    if projection<=0:dist=(center[0]-a[0])**2+(center[1]-a[1])**2
    elif projection>=dd:dist=(center[0]-b[0])**2+(center[1]-b[1])**2
    else:dist=turn(a,b,center)**2/dd
    distances.append(dist)
assert min(distances)==F(coredata['minimum_segment_distance_squared_mm2'])
for p in core:assert F(p[0]*p[0]+p[1]*p[1],1000000)<min(distances)
for a,b in zip(core,core[1:]+core[:1]):
    assert all(turn(a,b,p)>0 for p in core if p not in (a,b)) and turn(a,b,(0,0))>0
parent=load(PRE/'parent-source12.json');sourceplan=load(BASE/'plan.json');stock=sourceplan['source_stock']
parentcheck=audit(job,parent,{'sheet-1':stock},sourceplan['required_pair_gap_mm'],sourceplan['stock_guard_mm']);assert parentcheck['valid'] and parentcheck['originals']==12
write(OUT/'parent-source-checks.json',parentcheck)
fixed=load(DATA/'fixed-core-rectangles.json');assert len(fixed)==12
source_rows={(r['part_id'],r['copy_index']):r for r in parent}
assert {tuple(r['identity']) for r in fixed}==set(source_rows)
rects={};edge_checks=0;corner_checks=0
for row in fixed:
    key=tuple(row['identity']);pose=source_rows[key];vv=transformed(parts[key[0]]['geometry'][0]['outer'],pose['transform']);assert Polygon(vv).is_valid
    rr=row['rectangles_um'];assert rr
    for r in rr:
        assert all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3]
        exact=[F(v,1000) for v in r]
        for p in [(exact[0],exact[1]),(exact[2],exact[1]),(exact[2],exact[3]),(exact[0],exact[3])]:assert parity(p,vv);corner_checks+=1
        for a,b in zip(vv,vv[1:]+vv[:1]):assert not segment_touches_rect(a,b,exact);edge_checks+=1
    rects[key]=rr
result=load(DATA/'result.json');bounds=result['relaxed_continuous_center_bounds_um']
assert bounds[0]<bounds[2] and bounds[1]<bounds[3]
assert F(bounds[0])<=F(str(stock[0]))*1000-min(p[0] for p in core)
assert F(bounds[1])<=F(str(stock[1]))*1000-min(p[1] for p in core)
assert F(bounds[2])>=F(str(stock[2]))*1000-max(p[0] for p in core)
assert F(bounds[3])>=F(str(stock[3]))*1000-max(p[1] for p in core)
casechecks=[];total_leaves=total_nodes=total_sums=total_corner_planes=0
for entry in result['cases']:
    copy=entry['removed_bracket_copy'];case=load(BASE/'cases'/f'{copy:02d}.json');expected=[p for p in parent if (p['part_id'],p['copy_index'])!=('bracket',copy)]
    assert case['fixed11']==expected and len(expected)==11
    rr=[r for p in expected for r in rects[p['part_id'],p['copy_index']]]
    obs=load(DATA/f'{copy:02d}-obstacles.json');assert len(obs)==len(rr)==117
    for r,poly in zip(rr,obs):
        poly=[tuple(p) for p in poly];assert len(poly)>=3 and len(set(poly))==len(poly)
        points={(x-u,y-v) for x,y in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])] for u,v in core}
        # Every saved vertex is a sum of core vertices; its convex hull is necessarily forbidden.
        assert all(p in points for p in poly)
        for a,b in zip(poly,poly[1:]+poly[:1]):assert all(turn(a,b,p)>0 for p in poly if p not in (a,b))
        # Conversely verify all pairwise sums, confirming the complete exact convex no-fit hull.
        assert all(contains_convex(poly,p) for p in points);total_sums+=len(points)
    cert=load(DATA/f'{copy:02d}-certificate.json');nodes=cert['nodes'];seen=set();leaves=[]
    def verify_node(idx,expected_bounds,depth):
        global total_corner_planes
        assert type(idx)==int and 0<=idx<len(nodes) and idx not in seen;seen.add(idx);node=nodes[idx]
        r=list(map(F,node['bounds_um']));assert r==expected_bounds and node['depth']==depth and depth<=30
        if 'covered_by' in node:
            assert set(node)=={'bounds_um','depth','covered_by'};oi=node['covered_by'];assert type(oi)==int and 0<=oi<len(obs)
            poly=obs[oi]
            for corner in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]:
                for a,b in zip(poly,poly[1:]+poly[:1]):assert turn(a,b,corner)>=0;total_corner_planes+=1
            leaves.append(idx)
        else:
            assert set(node)=={'bounds_um','depth','split_axis','left','right'}
            axis=0 if r[2]-r[0]>=r[3]-r[1] else 1;assert node['split_axis']==axis
            mid=(r[axis]+r[axis+2])/2;left=r[:];right=r[:];left[axis+2]=mid;right[axis]=mid
            verify_node(node['left'],left,depth+1);verify_node(node['right'],right,depth+1)
    verify_node(0,list(map(F,bounds)),0)
    assert len(seen)==len(nodes)==entry['nodes'] and len(nodes)<=100000 and cert['covered'] and cert['unprocessed_rectangles']==0 and cert['limit'] is None and cert['relaxation_witness_um'] is None
    total_leaves+=len(leaves);total_nodes+=len(nodes)
    casechecks.append({'removed_bracket_copy':copy,'fixed_originals':11,'exact_obstacles':len(obs),'continuous_coverage_nodes':len(nodes),'covered_leaves':len(leaves),'adding_original_cog_at_any_real_angle_or_continuous_center_excluded':True})
controls=load(DATA/'controls.json');existing=source_rows['cog',14];assert existing['transform']['rotation_radians']==0
positive=[(center[k]+F(str(existing['transform']['translation'][k])))*1000 for k in (0,1)]
assert list(map(F,controls['positive_existing_cog_center_um']))==positive
def exact_control_collision(r):
    # Reconstruct a convex hull independently through Shapely; integer cross-products decide containment.
    points=[(x-u,y-v) for x,y in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])] for u,v in core]
    vv=[tuple(int(v) for v in p) for p in Polygon(points).convex_hull.exterior.coords[:-1]]
    signed=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(vv,vv[1:]+vv[:1]))
    if signed<0:vv.reverse()
    return contains_convex(vv,positive)
assert all(not exact_control_collision(r) for key,rr in rects.items() if key!=('cog',14) for r in rr)
assert any(exact_control_collision(r) for r in rects['cog',14])
assert len(casechecks)==result['covered_cases']==6
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',DATA/'plan.json',BASE/'preflight-v2/plan.json']+sorted(DATA.glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'case-checks.json',casechecks)
write(OUT/'necessity-proof.json',{'moving_core':'The exact center is interior to the simple original filled outer. Exact point-to-segment squared distances prove a closed disk around it lies inside that outer. Every vertex of the convex integer core lies strictly inside this disk, so the complete core does too. Rotating the original around its origin and translating it moves the disk center to R*C+t while leaving the disk itself rotationally invariant. Thus the same world-aligned core is contained at every real cog angle. Holes remain reserved under common-line PIH off.',
    'fixed_core':'Exact rational ray parity for every rectangle corner and clipping against every transformed source edge prove each closed rectangle lies strictly inside its original filled outer. The parent 12 source placements are independently valid. Every case removes precisely its named bracket and keeps the other 11 exact source poses.',
    'forbidden_centers':'For a fixed rectangle and the moving convex core, the exact convex hull of all vertex differences is their no-fit polygon, including contact. Any center in that hull makes the contained closed shapes intersect, which contradicts the required positive gap between their original filled outers. No extra gap is imposed in this necessary test.',
    'coverage':'The outward-rounded bounds contain every continuous source-valid cog center. Every tree child pair exactly partitions its parent rational rectangle. Every leaf has all four corners inside one convex no-fit polygon, proved by exact cross-products, hence its complete area is forbidden. Every node is reachable exactly once and all leaves are covered. No placement coordinate discretization or sampled-angle assumption is used.',
    'scope':'All six fixed 11-part short-sheet configurations exclude adding a cog at any real angle and continuous center, even before the additional insert. More existing poses must change to pursue the 5-bracket/6-insert/2-cog allocation. This does not exclude that allocation, any other fixed layout, or the complete original job.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_cog_edges':len(original),'all_angle_core_vertices':len(core),'core_radius_um':coredata['radius_um'],'strict_fixed_rectangles':sum(len(rr) for rr in rects.values()),'exact_fixed_source_edge_checks':edge_checks,'exact_fixed_corner_checks':corner_checks,'exact_no_fit_vertex_sums':total_sums,'continuous_coverage_nodes':total_nodes,'covered_leaves':total_leaves,'exact_leaf_corner_plane_checks':total_corner_planes,'all6_fixed11_cases_excluded_for_any_cog_angle':True,'positive_parent_cog_control_passed':True,'negative_occupied_center_control_passed':True,'integer_placement_grid_restriction':False,'full_allocation_or_global_job_excluded':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'),flush=True)
