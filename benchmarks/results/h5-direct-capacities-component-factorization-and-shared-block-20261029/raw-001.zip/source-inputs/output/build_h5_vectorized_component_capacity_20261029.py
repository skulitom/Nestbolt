"""Regenerate generic component bounds; vectorized estimates only screen exact certificates."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,math,shutil,time,itertools
import numpy as np
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';AXIS=ROOT/'output/h5-first55-local-grid-regions-20261029/component-halfspace-bound';OUT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
assert load(AXIS/'audit/checks.json')['passed'] and load(PRIOR/'accessible-area-bound/audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(PRIOR/'family-modes.json');pieces=load(PIECES);inner={};families=['bracket','insert']
for family in families:
    inner[family]=[]
    for mode in modes[family]:
        c,s=map(F,[math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians'])]);m=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left']);boxes=[]
        for piece in pieces[family]:
            p=[(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in piece]
            if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))<0:p.reverse()
            box=[min(x for x,y in p)+F('1e-6'),min(y for x,y in p)+F('1e-6'),max(x for x,y in p)-F('1e-6'),max(y for x,y in p)-F('1e-6')];l,b,r,t=box
            assert l<r and b<t and all(cross(a,z,q)>=0 for a,z in zip(p,p[1:]+p[:1]) for q in [(l,b),(l,t),(r,b),(r,t)])
            boxes.append(box)
        inner[family].append(boxes)
regions={};unary=load(PRIOR/'integer-preparation/unary-templates.json')
for r in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if r['family'] not in families:continue
    key=(r['family'],r['mode'],r['geometry'],r['region']);bits=0
    for row,lo,hi in r['grid_row_spans']:bits|=((1<<(hi-lo+1))-1)<<((row-200)*150+lo)
    if key not in regions:
        poly=[tuple(map(F,p)) for p in unary[r['geometry']]['regions'][r['region']]['hull_vertices']]
        regions[key]={'mask':r['required_empty_mask'],'bits':0,'bounds':[min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly)]}
    regions[key]['bits']|=bits
full=(1<<15000)-1;no_left=full^sum(1<<(150*y) for y in range(100));no_right=full^sum(1<<(150*y+149) for y in range(100))
def components(bits):
    result=[]
    while bits:
        c=bits&-bits
        while True:
            horizontal=c|((c&no_left)>>1)|((c&no_right)<<1)
            expanded=(horizontal|(horizontal>>150)|(horizontal<<150))&bits
            if c==expanded:break
            c=expanded
        result.append(c);bits^=c
    return result
@lru_cache(None)
def mandatory(family,mode,axis,above,shift,cut):
    total=F(0)
    for box in inner[family][mode]:
        lo,hi=box[axis]+shift,box[axis+2]+shift
        length=max(F(0),hi-max(lo,cut)) if above else max(F(0),min(hi,cut)-lo)
        total+=length*(box[3-axis]-box[1-axis])
    return total
allowed=load(AXIS/'audit/allowed-empty-site-pairs.json');old_axis={tuple(r['empty_sites']):r for r in load(AXIS/'all35-halfspace-bounds.json')};old_conn={tuple(r['empty_sites']):r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json')}
cuts=[(axis,above,origin+10*i) for axis,n,origin in [(0,151,0),(1,101,2000)] for i in range(n) for above in [False,True]]
rows=[];initial_total=after_area_total=remaining_total=0;area_certs=halfspace_certs=0;subset_areas=screened_halfspaces=exact_halfspaces=0
for sites in allowed:
    assert time.perf_counter()-started<58,'Preparation cap reached before a complete result; no model or solver may consume it'
    empty=sum(1<<i for i in sites);active={k:r for k,r in regions.items() if not r['mask']&~empty};supports={f:0 for f in families}
    for k,r in active.items():supports[k[0]]|=r['bits']
    groups=[]
    for f in families:
        for fi,bits in enumerate(components(supports[f])):groups.append({'family':f,'family_component':fi,'bits':bits,'ranges':{}})
    nb=sum(g['family']=='bracket' for g in groups);assert [hex(g['bits']) for g in groups[:nb]]==old_conn[tuple(sites)]['components_hex'];assignments=[]
    for k,r in active.items():
        dest=[i for i,g in enumerate(groups) if g['family']==k[0] and r['bits']&~g['bits']==0];assert len(dest)==1;gi=dest[0];assignments.append([*k,gi]);old=groups[gi]['ranges'].get(k[1]);groups[gi]['ranges'][k[1]]=r['bounds'][:] if old is None else [fun(a,b) for fun,a,b in zip([min,min,max,max],old,r['bounds'])]
    for g in groups:
        f=g['family'];g['lower']=min(sum((b[2]-b[0])*(b[3]-b[1]) for b in inner[f][m]) for m in g['ranges']);g['cap']=min(7 if f=='bracket' else 6,int(F(g['bits'].bit_count()*100)//g['lower']))
        if f=='bracket':g['cap']=min(g['cap'],old_axis[tuple(sites)]['components'][g['family_component']]['capacity_upper_bound'])
    bc=[v for v in itertools.product(*(range(g['cap']+1) for g in groups[:nb])) if sum(v)==7];ic=[v for v in itertools.product(*(range(g['cap']+1) for g in groups[nb:])) if sum(v)==6]
    possible={b+i for b in bc for i in ic};initial=sorted(possible);initial_total+=len(possible);certs=[];subset_info=[]
    for selected_mask in range(1,1<<len(groups)):
        selected=[i for i in range(len(groups)) if selected_mask>>i&1];bits=0
        for i in selected:bits|=groups[i]['bits']
        available=bits.bit_count()*100;coefficients=[g['lower'] if i in selected else F(0) for i,g in enumerate(groups)];removed=sorted(v for v in possible if sum(n*a for n,a in zip(v,coefficients))>available);subset_areas+=1
        if removed:certs.append({'kind':'subset_area','groups':selected,'upper_area_mm2':available,'coefficients_mm2':[str(v) for v in coefficients],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
        if {groups[i]['family'] for i in selected}=={'bracket','insert'}:subset_info.append((selected,bits))
    after_area=sorted(possible);after_area_total+=len(possible);area_certs+=len(certs)
    estimates=np.zeros((504,len(groups)),dtype=np.float64)
    for gi,g in enumerate(groups):
        offset=0
        for axis,n,origin in [(0,151,0),(1,101,2000)]:
            cv=np.repeat(origin+10*np.arange(n,dtype=np.float64),2);av=np.tile(np.array([False,True]),n);mode_estimates=[]
            for m,bounds in g['ranges'].items():
                shift=np.where(av,float(bounds[axis]),float(bounds[axis+2]));amount=np.zeros(2*n)
                for b in inner[g['family']][m]:
                    lo=float(b[axis])+shift;hi=float(b[axis+2])+shift
                    amount+=np.where(av,np.maximum(0.,hi-np.maximum(lo,cv)),np.maximum(0.,np.minimum(hi,cv)-lo))*float(b[3-axis]-b[1-axis])
                mode_estimates.append(amount)
            estimates[offset:offset+2*n,gi]=np.min(np.array(mode_estimates),axis=0);offset+=2*n
    halfcerts=[];exact_cache={};candidate_tests=0
    for selected,bits in subset_info:
        xs=[0]*150;ys=[0]*100;rest=bits
        while rest:
            low=rest&-rest;y,x=divmod(low.bit_length()-1,150);xs[x]+=1;ys[y]+=1;rest^=low
        available=[]
        for counts in [xs,ys]:
            below=0
            for j in range(len(counts)+1):
                available.extend([below*100,(bits.bit_count()-below)*100])
                if j<len(counts):below+=counts[j]
        screened_halfspaces+=504
        if not possible:continue
        counts=np.array(sorted(possible),dtype=np.float64);estimated=counts[:,selected]@estimates[:,selected].T
        candidate_indices=np.flatnonzero(np.any((estimated>np.array(available)-1e-4)&(estimated>1e-4),axis=0))
        for ci in candidate_indices:
            axis,above,cut=cuts[int(ci)];coefficients=[F(0)]*len(groups);values={};candidate_tests+=1;exact_halfspaces+=1
            for gi in selected:
                key=(gi,int(ci))
                if key not in exact_cache:
                    g=groups[gi];vals={str(m):mandatory(g['family'],m,axis,above,bounds[axis if above else axis+2],F(cut)) for m,bounds in g['ranges'].items()};exact_cache[key]=(min(vals.values()),{m:str(v) for m,v in vals.items()})
                coefficients[gi],values[str(gi)]=exact_cache[key]
            removed=sorted(v for v in possible if sum(v[i]*coefficients[i] for i in selected)>available[int(ci)])
            if removed:halfcerts.append({'groups':selected,'axis':axis,'above':above,'threshold_mm':str(cut),'upper_area_mm2':available[int(ci)],'selected_group_mode_minimum_area_mm2':values,'coefficients_mm2':[str(v) for v in coefficients],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
    halfspace_certs+=len(halfcerts);remaining_total+=len(possible)
    saved_groups=[{'family':g['family'],'family_component':g['family_component'],'support_hex':hex(g['bits']),'area_upper_mm2':g['bits'].bit_count()*100,'source_area_lower_mm2':str(g['lower']),'capacity':g['cap'],'mode_position_bounds_mm':{str(m):[str(v) for v in b] for m,b in g['ranges'].items()}} for g in groups]
    rows.append({'empty_sites':sites,'groups':saved_groups,'region_component_assignments':assignments,'initial_distributions':[list(v) for v in initial],'subset_area_certificates':certs,'after_subset_area_distributions':[list(v) for v in after_area],'subset_halfspace_certificates':halfcerts,'remaining_distributions':[list(v) for v in sorted(possible)],'mixed_subsets_screened':len(subset_info),'halfspaces_screened':504*len(subset_info),'halfspaces_recomputed_exactly':candidate_tests,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started;assert elapsed<60
inputs=[Path(__file__),PIECES,PRIOR/'family-modes.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'accessible-area-bound/plan.json',PRIOR/'accessible-area-bound/audit/plan.json',PRIOR/'accessible-area-bound/audit/checks.json',PRIOR/'accessible-area-bound/swept-covers.json',PRIOR/'connected-capacity-bound/audit/plan.json',PRIOR/'connected-capacity-bound/audit/checks.json',PRIOR/'connected-capacity-bound/all105-capacity-bounds.json',AXIS/'plan.json',AXIS/'audit/plan.json',AXIS/'audit/checks.json',AXIS/'audit/allowed-empty-site-pairs.json',AXIS/'all35-halfspace-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Regenerate contained source rectangles and family support components from original geometric inputs. Enumerate every necessary subset-area count inequality. For all mixed subsets and all504 axis halfspaces, vectorized floating estimates identify prospective violations using a1e-4mm2 near-threshold margin. Recompute each proposed exclusion with exact Fractions and record its complete witness; floating estimates never authorize an exclusion. Independently verify source/evidence equivalence before model use. No list of discovered cuts is used as an input.','preparation_cap_seconds':60,'floating_screening_only':True,'floating_exclusions_permitted':False,'source_valid_equivalence_audit_required':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'source-inner-rectangles.json',{f:[[[str(v) for v in b] for b in opts] for opts in modes] for f,modes in inner.items()});write(OUT/'all29-vectorized-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'initial_count_distributions':initial_total,'after_subset_area_distributions':after_area_total,'remaining_count_distributions':remaining_total,'subset_area_certificates':area_certs,'subset_halfspace_certificates':halfspace_certs,'subset_areas_examined':subset_areas,'halfspaces_screened':screened_halfspaces,'halfspaces_recomputed_exactly':exact_halfspaces,'floating_estimates_never_authorize_exclusion':True,'source_rectangles_and_components_regenerated':True,'new_restricted_site_exclusions':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
