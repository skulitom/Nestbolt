"""Joint legal source-mode and relative-region convex-combination model."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, shutil, time
import numpy as np
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parents[1]
MODES = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
PRE = MODES / 'pair-region-preflight'
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
OUT = ROOT / 'output/h5-short11-all-mode-region-model-20261029'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(MODES / 'audit/checks.json')['passed'] and load(PRE / 'audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'build.py')
started = time.perf_counter()
family_modes, library, instances, inventory = [load(MODES / n) for n in ['family-modes.json', 'geometry-library.json', 'instances.json', 'inventory.json']]
templates, owner_pairs = [load(PRE / n) for n in ['templates.json', 'owner-pairs.json']]
stock = load(STOCK)['source_stock']
mode_count = sum(len(family_modes[r['identity'][0]]) for r in instances)
region_count = sum(len(templates[t]['regions']) for pair in owner_pairs for t in pair['template_indices'])
mode_variable = 22
region_variable = 22+mode_count
weight_variable = 22+mode_count+region_count
ri, ci, values, lower, upper = [], [], [], [], []
global_bounds, owners, pairs = [], [], []

def row(coefficients, lo, hi):
    index = len(lower)
    for column, coefficient in coefficients.items():
        if coefficient:
            ri.append(index)
            ci.append(column)
            values.append(coefficient)
    lower.append(lo)
    upper.append(hi)
    return index

for owner, instance in enumerate(instances):
    modes = family_modes[instance['identity'][0]]
    record = {'owner': owner, 'identity': instance['identity'], 'modes': []}
    for mode in modes:
        record['modes'].append({**mode, 'selector': mode_variable})
        mode_variable += 1
    record['one_mode_row'] = row({m['selector']: 1. for m in record['modes']}, 1., 1.)
    record['stock_rows'] = []
    for axis in [0, 1]:
        global_bounds.append([min(m['lower_left_bounds'][axis][0] for m in modes), max(m['lower_left_bounds'][axis][1] for m in modes)])
        coefficients = {2*owner+axis: 1.}
        coefficients.update({m['selector']: library[m['normalized_geometry']]['dimensions'][axis] for m in record['modes']})
        record['stock_rows'].append(row(coefficients, -np.inf, stock[axis+2]-.025))
    owners.append(record)
assert mode_variable == 80
for owner_pair in owner_pairs:
    ia, ib = owner_pair['owners']
    record = {'owners': [ia, ib], 'regions': [], 'mode_marginals': []}
    coordinates = [{2*ia: 1., 2*ib: -1.}, {2*ia+1: 1., 2*ib+1: -1.}]
    for template_index in owner_pair['template_indices']:
        template = templates[template_index]
        for region_index, vertices in enumerate(template['regions']):
            selector = region_variable
            region_variable += 1
            rounded = [[round(v, 9) for v in p] for p in vertices]
            lambdas = list(range(weight_variable, weight_variable+len(rounded)))
            weight_variable += len(rounded)
            region = {'template': template_index, 'region': region_index,
                      'geometries': template['geometries'], 'selector': selector, 'lambdas': lambdas}
            region['lambda_sum_row'] = row({selector: -1., **{i: 1. for i in lambdas}}, 0., 0.)
            for column, vertex in zip(lambdas, rounded):
                for axis in [0, 1]:
                    coordinates[axis][column] = vertex[axis]
            record['regions'].append(region)
    record['one_region_row'] = row({r['selector']: 1. for r in record['regions']}, 1., 1.)
    record['coordinate_rows'] = [row(c, 0., 0.) for c in coordinates]
    for side, owner in enumerate([ia, ib]):
        for geometry in sorted({m['normalized_geometry'] for m in owners[owner]['modes']}):
            source_modes = [m['selector'] for m in owners[owner]['modes'] if m['normalized_geometry'] == geometry]
            pair_regions = [r['selector'] for r in record['regions'] if r['geometries'][side] == geometry]
            coefficients = {i: -1. for i in source_modes}
            coefficients.update({i: 1. for i in pair_regions})
            record['mode_marginals'].append({'owner': owner, 'side': side, 'geometry': geometry,
                                             'mode_selectors': source_modes, 'region_selectors': pair_regions,
                                             'row': row(coefficients, 0., 0.)})
    pairs.append(record)
symmetry = []
for family in ['bracket', 'insert', 'cog']:
    same = sorted((o for o in owners if o['identity'][0] == family), key=lambda o: o['identity'][1])
    for a, b in zip(same, same[1:]):
        index = row({2*a['owner']: 1., 2*b['owner']: -1.}, -np.inf, 0.)
        symmetry.append({'family': family, 'owners': [a['owner'], b['owner']], 'row': index})
assert region_variable == 22+mode_count+region_count and len(symmetry) == 8
binary_stop = region_variable
matrix = coo_matrix((values, (ri, ci)), shape=(len(lower), weight_variable)).tocsc()
np.savez(OUT / 'model.npz', data=matrix.data, indices=matrix.indices, indptr=matrix.indptr,
         shape=np.asarray(matrix.shape), lower=lower, upper=upper,
         bounds=np.vstack([global_bounds, np.tile([0., 1.], (weight_variable-22, 1))]),
         c=np.zeros(weight_variable), integrality=np.r_[np.zeros(22, dtype=int), np.ones(binary_stop-22, dtype=int), np.zeros(weight_variable-binary_stop, dtype=int)])
write(OUT / 'mapping.json', {'owners': owners, 'pairs': pairs, 'symmetry_rows': symmetry,
                            'binary_start': 22, 'binary_stop': binary_stop, 'weight_start': binary_stop, 'weight_stop': weight_variable})
shutil.copyfile(MODES / 'inventory.json', OUT / 'inventory.json')
elapsed = time.perf_counter()-started
charges = {'source_geometry_and_previous_axis_preparation_seconds': load(SOURCE / 'checks.json')['preparation_seconds_charged'],
           'all_mode_preparation_seconds': load(MODES / 'checks.json')['seconds'],
           'pair_template_preparation_seconds': load(PRE / 'checks.json')['seconds'],
           'joint_model_build_seconds': elapsed}
write(OUT / 'preparation-charges.json', charges)
inputs = [Path(__file__), JOB, STOCK, SOURCE / 'checks.json', MODES / 'plan.json', MODES / 'checks.json',
          MODES / 'family-modes.json', MODES / 'geometry-library.json', MODES / 'instances.json', MODES / 'inventory.json',
          MODES / 'audit/plan.json', MODES / 'audit/checks.json', PRE / 'plan.json', PRE / 'checks.json',
          PRE / 'templates.json', PRE / 'owner-pairs.json', PRE / 'audit/plan.json', PRE / 'audit/checks.json',
          PRE / 'audit/rounded-region-support-certificates.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'Joint source-mode and convex-combination relative-region construction. Each of 11 originals selects exactly one of its legal source modes, retaining all 58 options. Pair-region marginals equal the selected owner filled-geometry modes on both sides, including source-mode aliases. Nonnegative vertex weights sum to each region selector; equalities reconstruct relative lower-left positions. Mode-dependent stock inequalities use original dimensions. Copies of the same original family are ordered by lower-left X; this only removes interchangeable identity permutations because their geometry, legal modes, stock and role requirements are identical. No deactivation constants. This broadens bracket and insert orientations beyond all closed fixed-mode searches; it is a distinct model. Cogs retain 7-degree phases and conservative floating free-region construction, so negative results never exclude the allocation. Independent source readback follows any assignment; first55/full66/native/material and complete H5 remain.',
    'algorithm_seconds': 60, 'shared_seconds': 90, 'node_limit': 4096, 'maximum_calls': 1,
    'retry_permitted': False, 'source_validation_reserve_seconds': 3,
})
checks = {'passed': True, 'seconds': elapsed, 'preparation_seconds_charged': sum(charges.values()),
          'originals': 11, 'source_mode_selectors': mode_count, 'original_pair_groups': len(pairs),
          'region_selectors': region_count, 'mode_marginal_rows': sum(len(g['mode_marginals']) for g in pairs),
          'identity_symmetry_rows': len(symmetry), 'binary_variables': binary_stop-22,
          'continuous_vertex_weights': weight_variable-binary_stop, 'variables': weight_variable,
          'rows': len(lower), 'matrix_nonzeros': matrix.nnz, 'model_sha256': digest(OUT / 'model.npz'),
          'independent_model_audit_pending': True, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
