"""Compare every frontier row against the preserved parent and exact deletion closure."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';QUAL=BASE/'source-necessity-audit';OUT=BASE/'frontier-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
OUT.mkdir();prior=ROOT/'benchmarks/results/h5-seven-bracket-source-and-bound-20261028/updated-allocations.json';old=load(prior);new=load(QUAL/'updated-allocations.json');assert len(old)==len(new)==4576 and load(QUAL/'checks.json')['passed'];changes=[]
for a,b in zip(old,new):
    assert a['short_counts']==b['short_counts'] and a['first_counts']==b['first_counts'];key=tuple(a['short_counts']);must_change=a['excluded_by'] is None and min(key[0]-5,key[1]-6,key[2]-2)>=0
    if must_change:assert b=={**a,'excluded_by':'source_reference_short_5_6_2_20261029'};changes.append(list(key))
    else:assert a==b
assert changes==[[5,6,2],[5,7,2],[5,8,2]] and sum(r['excluded_by'] is None for r in new)==441
survivors={tuple(r['short_counts']) for r in new if r['excluded_by'] is None};pareto=set(map(tuple,load(QUAL/'pareto-necessary-counts.json')));assert len(pareto)==32 and pareto<=survivors
for a in survivors:
    dominates=[b for b in survivors if b!=a and all(x>=y for x,y in zip(b,a))];assert (a in pareto)==(not dominates)
assert {(7,4,1),(8,5,0),(6,5,1),(5,5,2)}<=survivors and (5,5,2) in pareto
result={'passed':True,'all4576_rows_compared':True,'only_new_exclusions':changes,'all_old_exclusion_labels_and_complements_preserved':True,'remaining_necessary_allocations':441,'pareto_counts_verified':32,'new_maximal_5_5_2_retained':True,'known_source_counts_retained':True,'whole_job_excluded':False,'solver_calls':0,'native_calls':0}
for name,data in [('checks.json',result),('plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),prior,QUAL/'plan.json',QUAL/'checks.json',QUAL/'updated-allocations.json',QUAL/'pareto-necessary-counts.json']}})]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
print(result)
