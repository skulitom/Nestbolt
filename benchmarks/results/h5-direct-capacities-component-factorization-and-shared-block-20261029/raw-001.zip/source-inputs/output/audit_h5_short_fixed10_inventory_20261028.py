"""Independent original identity/source and exact necessary fixed-ten preflight audit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from itertools import combinations
import json,shutil,time
from shapely.geometry import Polygon
import math
from h5_continuous_core_certificate_reader_20261028 import check_obstacles,check_certificate

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-fixed10-inventory-20261028';OUT=BASE/'audit';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda r:(r['part_id'],r['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for plan in [BASE/'plan.json',BOUND/'audit/plan.json',BOUND/'plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BOUND/'audit/checks.json')['passed']
job=load(JOB);parts={p['id']:p for p in job['parts']};parent=load(PRE/'parent-source12.json');allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};stockplan=load(OLD/'plan.json');st=stockplan['source_stock'];parentmap={key(p):p for p in parent}
variants=load(BASE/'inventory-variants.json');summaries=load(BASE/'case-summary.json');result=load(BASE/'result.json');core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')};bounds=load(BOUND/'result.json')['relaxed_continuous_center_bounds_um'];assert result['relaxed_center_bounds_um']==bounds
expected={(primary,key(p)) for primary in [3,4,7,8,10,11] for p in parent if key(p)!=('bracket',primary)};observed=set();linked={}
for i,v in enumerate(variants):
    assert v['index']==i;primary=v['primary_bracket_to_first'];second=tuple(v['extra_released_original']);assert (primary,second) in expected and (primary,second) not in observed;observed.add((primary,second))
    removed=sorted([('bracket',primary),second]);assert list(map(tuple,v['removed_parent_identities']))==removed
    movers=[second,('cog',0),('insert',0)];assert list(map(tuple,v['moving_short_originals']))==movers
    fixedkeys=set(parentmap)-set(removed);short=fixedkeys|set(movers);first=allids-short
    assert len(fixedkeys)==10 and len(short)==13 and len(first)==53 and not fixedkeys&set(movers)
    assert list(map(tuple,v['mandatory_short_identities']))==sorted(short) and list(map(tuple,v['mandatory_first_identities']))==sorted(first)
    assert Counter(k[0] for k in short)=={'bracket':5,'insert':6,'cog':2} and Counter(k[0] for k in first)=={'frame':18,'bracket':7,'insert':15,'cog':13}
    linked.setdefault(v['geometry_case'],[]).append(i)
assert observed==expected and len(observed)==66
groups_seen=set();cases=[];sourcepairs=vertexsums=0
for s in summaries:
    name=s['geometry_case'];case=load(BASE/'cases'/f'{name}.json');removed=tuple(map(tuple,case['removed_parent_identities']));assert removed not in groups_seen;groups_seen.add(removed)
    rows=[p for p in parent if key(p) not in removed];assert rows==case['fixed10'] and len(rows)==10 and linked[name]==case['inventory_variant_indices']==s['inventory_variants']
    shapes=[]
    for p in rows:
        t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mirror=-1 if t['mirrored'] else 1
        poly=Polygon([(mirror*x*co-y*si+t['translation'][0],mirror*x*si+y*co+t['translation'][1]) for x,y in parts[p['part_id']]['geometry'][0]['outer']]);assert poly.is_valid;b=poly.bounds
        assert min(b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3])>stockplan['stock_guard_mm'];shapes.append(poly)
    for a,b in combinations(shapes,2):assert a.disjoint(b) and a.distance(b)>stockplan['required_pair_gap_mm'];sourcepairs+=1
    savedsource=load(BASE/'source-checks'/f'{name}.json');assert savedsource['valid'] and savedsource['originals']==10 and savedsource['same_sheet_pairs']==45
    rr=[r for p in rows for r in fixed[key(p)]];obs=load(BASE/'obstacles'/f'{name}.json');vertexsums+=check_obstacles(rr,core,obs)
    checked=check_certificate(load(BASE/'certificates'/f'{name}.json'),bounds,obs);assert checked['nodes']==s['nodes'] and checked['complete_coverage']==s['all_angle_additional_cog_excluded']
    cases.append({'geometry_case':name,'inventory_variants':linked[name],**checked})
assert len(cases)==len(groups_seen)==51 and len(linked)==51
excluded=sum(c['complete_coverage'] for c in cases);open_cases=sum(c['relaxation_witnesses'] for c in cases)
assert excluded==result['necessary_core_excluded_geometries']==44 and open_cases==result['necessary_core_witness_geometries']==7 and result['limited_geometries']==0
assert sum(len(c['inventory_variants']) for c in cases if c['complete_coverage'])==result['covered_inventory_variants']==58
assert sum(len(c['inventory_variants']) for c in cases if not c['complete_coverage'])==result['unexcluded_inventory_variants']==8
inputs=[Path(__file__),ROOT/'output/h5_continuous_core_certificate_reader_20261028.py',BASE/'plan.json',BOUND/'audit/plan.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'case-checks.json',cases)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all66_inventory_variants_account_for_all66_originals':True,'distinct_source_fixed10_geometries':51,'independent_source_pair_checks':sourcepairs,'exact_no_fit_vertex_sums':vertexsums,'exact_certificate_nodes':sum(c['nodes'] for c in cases),'covered_leaves':sum(c['covered_leaves'] for c in cases),'exact_corner_plane_checks':sum(c['corner_plane_checks'] for c in cases),'source_core_previous_full_audit_hashes_verified':True,'all_angle_fixed10_excluded_geometries':44,'excluded_inventory_variants':58,'unexcluded_geometries':7,'unexcluded_inventory_variants':8,'all7_relaxation_witnesses_outside_every_necessary_obstacle':True,'core_witness_is_not_original_source_placement':True,'full_allocation_or_job_excluded':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'),flush=True)
