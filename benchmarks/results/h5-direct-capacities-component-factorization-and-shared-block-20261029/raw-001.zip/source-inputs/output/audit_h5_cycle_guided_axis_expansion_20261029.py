"""Verify each exact cycle and provide an exact potential for the remaining fixed graph."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';PRE=BASE/'preflight';OUT=PRE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,PRE]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
expansion=load(PRE/'cycle-expansion.json');edges=load(SOURCE/'source-translation-audit/axis-subsystem.json')['edges'];planes=load(SOURCE/'source-translation-preflight/planes.json');bounds=load(SOURCE/'source-translation-preflight/variable-bounds.json');selected=set(expansion['initial_choice_planes']);assert selected=={0,112,633,684,948,1021};weights=[]
# Recompute every edge, including those not present in any recorded cycle.
for e in edges:
    s=e['source']
    if s['kind']=='stock_upper':i=s['variable'];assert (e['from'],e['to'])==(22,i);w=F(bounds[i][1])
    elif s['kind']=='stock_lower':i=s['variable'];assert (e['from'],e['to'])==(i,22);w=-F(bounds[i][0])
    else:
        p=planes[s['plane']];a,b=p['owners'];axis=s['axis'];sign=s['normal_sign'];assert axis in [0,1] and sign in [-1,1];error=F(0)
        for d in [0,1]:
            coefficient=F(sign if d==axis else 0)-F(p['normal'][d]);ends=[F(bounds[2*a+d][0])-F(bounds[2*b+d][1]),F(bounds[2*a+d][1])-F(bounds[2*b+d][0])];error+=max(coefficient*v for v in ends)
        assert error==F(s['coefficient_error_allowance_mm']);w=F(p['upper_delta_difference_mm'])+error+F(1,10**9);assert (e['from'],e['to'])==((2*b+axis,2*a+axis) if sign==1 else (2*a+axis,2*b+axis))
    assert w==F(e['weight']);weights.append(w)
for i,cert in enumerate(expansion['cycles']):
    assert cert['iteration']==i;ids=cert['edge_indices'];net=[0]*23;total=F(0)
    for k in ids:
        e=edges[k];assert e['source'].get('plane') not in selected;net[e['from']]-=1;net[e['to']]+=1;total+=weights[k]
    assert not any(net) and total==F(cert['negative_sum_mm']) and total<0 and all(edges[ids[j]]['to']==edges[ids[(j+1)%len(ids)]]['from'] for j in range(len(ids)));added={edges[k]['source']['plane'] for k in ids if 'plane' in edges[k]['source']};assert added==set(cert['new_choice_planes']) and not added&selected;selected.update(added)
assert len(expansion['cycles'])==5 and sorted(selected)==expansion['final_choice_planes'] and len(selected)==11;active=[i for i,e in enumerate(edges) if e['source'].get('plane') not in selected];assert active==expansion['remaining_fixed_axis_edges'] and len(active)==2012;potential=[F(0)]*23
for iteration in range(23):
    changed=False
    for k in active:
        e=edges[k];v=potential[e['from']]+weights[k]
        if potential[e['to']]>v:potential[e['to']]=v;changed=True
    if not changed:break
assert not changed and all(potential[edges[k]['to']]<=potential[edges[k]['from']]+weights[k] for k in active);choices=load(PRE/'choices.json');assert [g['plane'] for g in choices]==sorted(selected) and sum(len(g['variants']) for g in choices)==160;write(OUT/'fixed-axis-potential.json',{'potential_mm':list(map(str,potential)),'verified_edges':len(active),'scope':'A satisfying potential for the remaining fixed axis-aligned consequences, not for the full LP or original source layout.'})
inputs=[Path(__file__),BASE/'plan.json',PRE/'plan.json',PRE/'cycle-expansion.json',PRE/'choices.json',SOURCE/'source-translation-audit/axis-subsystem.json',SOURCE/'source-translation-preflight/planes.json',SOURCE/'source-translation-preflight/variable-bounds.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'all_original_axis_edges_rederived':len(edges),'exact_cycles_verified':5,'final_choice_groups':11,'variants':160,'remaining_fixed_axis_edges':len(active),'exact_remaining_graph_potential_verified':True,'full_model_feasibility_not_established':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
