"""Mixed-family halfspace capacities restricted to each subset's possible occupied area."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-separated-component-capacity-20261029';JOINT=ROOT/'output/h5-first55-joint-component-capacity-20261029';OUT=BASE/'subset-halfspaces'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter();inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(JOINT/'source-inner-rectangles.json').items()}
@lru_cache(None)
def mandatory(f,m,axis,above,shift,cut):
    value=F(0)
    for box in inner[f][m]:
        lo,hi=box[axis]+shift,box[axis+2]+shift;length=max(F(0),hi-max(lo,cut)) if above else max(F(0),min(hi,cut)-lo);value+=length*(box[3-axis]-box[1-axis])
    return value
rows=[];total_certs=0;total_halfspaces=0;total_subsets=0;initial_total=0;remaining_total=0;all_complete=True
for prior in load(BASE/'all29-separated-bounds.json'):
    groups=prior['groups'];possible={tuple(v) for v in prior['remaining_distributions']};initial_total+=len(possible);certs=[];subsets=0;halfspaces=0;complete=True;cached={}
    for selected_mask in range(1,1<<len(groups)):
        selected=[i for i in range(len(groups)) if selected_mask>>i&1]
        if {groups[i]['family'] for i in selected}!={'bracket','insert'}:continue
        if time.perf_counter()-started>=58:complete=False;all_complete=False;break
        union=0
        for i in selected:union|=int(groups[i]['support_hex'],16)
        xs=[0]*150;ys=[0]*100;bits=union
        while bits:
            low=bits&-bits;y,x=divmod(low.bit_length()-1,150);xs[x]+=1;ys[y]+=1;bits^=low
        finished=True
        for axis,counts,origin in [(0,xs,0),(1,ys,2000)]:
            below=0
            for index in range(len(counts)+1):
                if time.perf_counter()-started>=58:finished=False;complete=False;all_complete=False;break
                cut=F(origin+10*index)
                for above in [False,True]:
                    available=(union.bit_count()-below if above else below)*100;coefficients=[F(0)]*len(groups);mode_values={}
                    for gi in selected:
                        key=(gi,axis,above,index)
                        if key not in cached:
                            g=groups[gi];vals={m:mandatory(g['family'],int(m),axis,above,F(bounds[axis if above else axis+2]),cut) for m,bounds in g['mode_position_bounds_mm'].items()};cached[key]=(min(vals.values()),{m:str(v) for m,v in vals.items()})
                        coefficients[gi],mode_values[str(gi)]=cached[key]
                    removed=sorted(v for v in possible if sum(v[i]*coefficients[i] for i in selected)>available);halfspaces+=1;total_halfspaces+=1
                    if removed:certs.append({'groups':selected,'axis':axis,'above':above,'threshold_mm':str(cut),'upper_area_mm2':available,'selected_group_mode_minimum_area_mm2':mode_values,'coefficients_mm2':[str(v) for v in coefficients],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
                if index<len(counts):below+=counts[index]
            if not finished:break
        if finished:subsets+=1;total_subsets+=1
        if not finished:break
    total_certs+=len(certs);remaining_total+=len(possible)
    rows.append({'empty_sites':prior['empty_sites'],'initial_distributions':prior['remaining_distributions'],'certificates':certs,'remaining_distributions':[list(v) for v in sorted(possible)],'mixed_subsets_completed':subsets,'halfspaces_examined':halfspaces,'scan_complete':complete,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),BASE/'plan.json',BASE/'audit/plan.json',BASE/'audit/checks.json',BASE/'all29-separated-bounds.json',JOINT/'source-inner-rectangles.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each mixed-family subset of independently audited source-support components, bound the occupied area available inside every grid-aligned axis halfspace. Each selected component contributes count times the minimum contained-source area over all its legal modes and all source unary hull translations. Remove a count distribution only when this mandatory lower area exceeds the subset support upper area. Preserve unprocessed distributions on the fixed discovery cap.','preparation_cap_seconds':60,'stop_new_bounds_after_seconds':58,'unprocessed_distributions_retained':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'all29-subset-halfspaces.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':all_complete,'site_pairs_retained_in_table':len(rows),'initial_distributions':initial_total,'remaining_distributions':remaining_total,'count_distributions_excluded':initial_total-remaining_total,'certificates':total_certs,'mixed_subsets_completed':total_subsets,'halfspaces_examined':total_halfspaces,'additional_restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
