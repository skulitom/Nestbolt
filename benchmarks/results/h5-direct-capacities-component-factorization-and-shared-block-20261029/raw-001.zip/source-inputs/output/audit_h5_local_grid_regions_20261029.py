"""Prove local-grid halfplanes imply the unchanged original-source-certified hulls."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'geometry-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def floor(v):return v.numerator//v.denominator
def ceil(v):return -floor(-v)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
spec=load(BASE/'plan.json');assert spec['grid_units_per_mm']==10 and spec['normal_scale']==10000 and spec['rectangle_gap_grid']==3
origin=list(map(F,spec['world_origin_mm']));limit=list(map(F,spec['local_domain_envelope_mm']));assert origin==[0,2100] and limit==[1500,900]
modes=load(BASE/'family-modes.json');prior_modes=load(PRIOR/'family-modes.json');mode_count=0
for family,opts in modes.items():
    assert len(opts)==len(prior_modes[family])
    for m,old in zip(opts,prior_modes[family]):
        assert {k:v for k,v in m.items() if k!='integer_lower_left_bounds'}==old
        for axis in [0,1]:
            a,b=map(F,old['lower_left_bounds'][axis]);lo,hi=m['integer_lower_left_bounds'][axis]
            assert [lo,hi]==[ceil((a-origin[axis])*10),floor((b-origin[axis])*10)]
            assert 0<=lo<=hi<=limit[axis]*10 and F(lo,10)+origin[axis]>=a and F(hi,10)+origin[axis]<=b
        mode_count+=1
allowed=load(PRIOR/'connected-capacity-bound/audit/allowed-empty-site-pairs.json');assert len(allowed)==35 and allowed==load(BASE/'allowed-empty-site-pairs.json')
old_unary=load(PRIOR/'integer-preparation/unary-templates.json');new_unary=load(BASE/'unary-templates.json');removed=[];planes=0;insets=[];activities=[]
for old,actual in zip(old_unary,new_unary):
    assert old['geometry']==actual['geometry'];keep=[r for r in old['regions'] if any(set(r['required_empty_sites'])<=set(pair) for pair in allowed)]
    removed.extend([old['geometry'],r['region']] for r in old['regions'] if r not in keep)
    assert [r['region'] for r in keep]==[r['region'] for r in actual['regions']]
    for source,r in zip(keep,actual['regions']):
        assert {k:v for k,v in r.items() if k!='planes'}=={k:v for k,v in source.items() if k!='planes'}
        poly=[tuple(map(F,p)) for p in r['hull_vertices']];assert len(r['planes'])==len(poly)
        for k,(a,b,plane) in enumerate(zip(poly,poly[1:]+poly[:1],r['planes'])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));n=[dy/den,-dx/den];assert plane['edge']==k and list(map(F,plane['exact_infinity_normal']))==n and F(plane['normalization_denominator'])==den
            raw=plane['unreduced_coefficients'];div=plane['divisor'];co=plane['coefficients'];assert all(c*div==v for c,v in zip(co,raw))
            delta=[n[i]-F(raw[i],10000) for i in range(2)];error=sum(abs(delta[i])*limit[i] for i in range(2));assert error==F(plane['rounding_error_bound_mm'])
            rhs=sum(n[i]*(a[i]-origin[i]) for i in range(2));upper=plane['upper']
            assert upper==floor((rhs-error-F('1e-7'))*100000)//div
            # Selected integer row implies exact source halfplane for every local coordinate.
            certified_inset=rhs-(F(div*upper,100000)+error);assert certified_inset>=F('1e-7')
            insets.append(certified_inset);activity=sum(abs(c)*int(v*10) for c,v in zip(co,limit));assert activity<2**31 and abs(upper)<2**31;activities.append(activity);planes+=1
assert removed==load(BASE/'removed-regions.json') and len(removed)==527
old_rect=load(PRIOR/'rigid-rectangle-preflight/mode-rectangles.json');new_rect=load(BASE/'mode-rectangles.json');padding=[];rectangle_count=0
for family,opts in new_rect.items():
    for actual,old in zip(opts,old_rect[family]):
        assert {k:v for k,v in actual.items() if k!='rectangles'}=={k:v for k,v in old.items() if k!='rectangles'}
        for a,b in zip(actual['rectangles'],old['rectangles']):
            assert {k:v for k,v in a.items() if k!='outward_offsets_grid'}==b
            for i,(value,tick) in enumerate(zip(a['exact_affine_bounds_mm'],a['outward_offsets_grid'])):
                exact=F(value);assert tick==(floor(exact*10) if i<2 else ceil(exact*10))
                gap=(exact-F(tick,10)) if i<2 else (F(tick,10)-exact);assert 0<=gap<F('0.1');padding.append(gap)
            rectangle_count+=1
for n in ['instances.json','inventory.json']:assert digest(BASE/n)==digest(PRIOR/n)
for n in ['components.json','component-pairs.json']:assert digest(BASE/n)==digest(PRIOR/'rigid-rectangle-preflight'/n)
assert F(spec['rectangle_gap_grid'],10)>F('0.225')
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','family-modes.json','mode-rectangles.json','unary-templates.json','removed-regions.json','allowed-empty-site-pairs.json','instances.json','inventory.json','components.json','component-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_family_modes_verified':mode_count,'cached_regions_verified':sum(len(t['regions']) for t in new_unary),'exact_integer_plane_implications':planes,'minimum_certified_inset_mm':float(min(insets)),'maximum_integer_plane_activity':max(activities),'mode_component_rectangles_verified':rectangle_count,'maximum_outward_padding_mm':float(max(padding)),'removed_regions_verified':527,'remaining_empty_site_pairs_verified':35,'same_source_hulls_and_modes':True,'positive_construction_only_no_global_coverage_claim':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
