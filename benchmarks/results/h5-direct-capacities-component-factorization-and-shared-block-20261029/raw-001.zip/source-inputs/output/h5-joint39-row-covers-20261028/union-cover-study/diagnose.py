"""Read the failed study's containment assumption without changing source geometry."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil
from shapely.geometry import Polygon
from shapely.ops import unary_union
from h5_outer_cover_geometry_20261028 import square_expand,slab_cover,rectangle_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-row-covers-20261028';OUT=BASE/'union-cover-study';load=lambda p:json.loads(p.read_bytes())
m=load(BASE/'modes.json')[-1];job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');expanded=[]
for r in m['source_instances']:
    c,s=math.cos(r['angle']),math.sin(r['angle']);x,y=r['translation'];expanded.append(square_expand([(c*a-s*b+x,s*a+c*b+y) for a,b in part['geometry'][0]['outer']],.112))
joined=unary_union(expanded);rects,slabs=slab_cover(joined,5000);cover=rectangle_union(rects);hull=rectangle_union(m['cover_rectangles_um']);result={'full_expanded_union_covered':cover.covers(joined),'new_cover_subset_of_hull_cover':hull.covers(cover),'uncovered_expansion_mm2':joined.difference(cover).area,'new_cover_outside_old_hull_cover_mm2':cover.difference(hull).area,'new_cover_bounds_mm':list(cover.bounds),'old_hull_cover_bounds_mm':list(hull.bounds),'new_first_slab_left_um':slabs[0]['left_um'],'old_first_rectangle_left_um':min(r[0] for r in m['cover_rectangles_um']),'new_cover_components':len(rects),'solver_calls':0,'original_study_closed_before_model_or_plan_creation':True}
shutil.copyfile(__file__,OUT/'diagnose.py')
with (OUT/'failure-diagnosis.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(result)
