"""Audit the seven-owner model and prove all six inactive slots freely extend it."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_source_projection_short_core_reader_20261029 import violations
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-source-projection-short-core-20261029';BASE=ROOT/'output/h5-five-bracket-two-cog-core-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def variables(message):
    out=set()
    for field,value in message.ListFields():
        if field.name in ['vars','literals','enforcement_literal']:out.update(i if i>=0 else -i-1 for i in value)
        elif field.message_type:
            for item in value if field.is_repeated else [value]:out.update(variables(item))
    return out
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,BASE/'preflight',OLD/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'model-audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model-v3/model.pb').read_bytes());mp=load(MODEL/'mapping.json');om=load(OLD/'model-v3/mapping.json');pos=load(MODEL/'positive-control-assignment.json');neg=load(MODEL/'negative-assignment.json');op=load(OLD/'model-v3/positive-control-assignment.json');on=load(OLD/'model-v3/negative-assignment.json');inv=load(BASE/'preflight/inventory.json');inactive=set(inv['inactive_short_owners']);presences={mp['items'][i]['presence'] for i in inactive};changed=[mp['items'][i]['mandatory'] for i in sorted(inactive)];assert inactive==set(range(7,13)) and changed==[112,126,140,154,168,182]
assert len(p.variables)==1876 and len(p.constraints)==1913 and [i for i,(a,b) in enumerate(zip(p.constraints,old.constraints)) if a!=b]==changed;restored=cp_model_pb2.CpModelProto();restored.CopyFrom(p)
for item in mp['items']:
    c=p.constraints[item['mandatory']];expected=0 if item['index'] in inactive else 1;assert not c.enforcement_literal and list(c.linear.vars)==[item['presence']] and list(c.linear.coeffs)==[1] and list(c.linear.domain)==[expected,expected] and {f.name for f,v in c.ListFields()}=={'linear'}
    if item['index'] in inactive:restored.constraints[item['mandatory']].CopyFrom(old.constraints[item['mandatory']])
assert list(p.solution_hint.vars)==list(old.solution_hint.vars);hintchanges=[]
for i,v in enumerate(p.solution_hint.vars):
    expected=0 if v in presences else old.solution_hint.values[i];assert p.solution_hint.values[i]==expected
    if expected!=old.solution_hint.values[i]:hintchanges.append({'index':i,'variable':v,'before':old.solution_hint.values[i],'after':expected})
assert hintchanges==load(MODEL/'hint-changes.json') and len(hintchanges)==6;restored.solution_hint.CopyFrom(old.solution_hint);assert restored==old
restoredmp=json.loads(json.dumps(mp));assert set(restoredmp.pop('inactive_short_owners'))==inactive and restoredmp.pop('inactive_short_identities')==inv['moved_originals'] and restoredmp.pop('short7_identities')==inv['short7_identities'];first=restoredmp.pop('mandatory_first59_identities');assert first==inv['mandatory_first59_identities'] and first[53:]==inv['moved_originals'];restoredmp['mandatory_first53_identities']=first[:53];assert restoredmp['control_disabled_mandatory_constraints']==[110];restoredmp['control_disabled_mandatory_constraints']=[110,112];assert restoredmp==om
for i in range(len(pos)):assert pos[i]==(0 if i in presences else op[i]) and neg[i]==(0 if i in presences else on[i])
short=set(map(tuple,inv['short7_identities']));first=set(map(tuple,first));job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');allids={(part['id'],i) for part in job['parts'] for i in range(part['quantity'])};assert len(short)==7 and len(first)==59 and not short&first and short|first==allids and Counter(a for a,b in short)=={'bracket':5,'cog':2} and Counter(a for a,b in first)=={'frame':18,'bracket':7,'insert':21,'cog':13}
dummy=set();pair_tables={}
for i in inactive:
    item=mp['items'][i];dummy.update([item['presence'],item['x'],item['y'],item['mode'],*item['stock_variables']])
    for piece in item['pieces']:dummy.update(piece['local_variables']);dummy.update(piece['world_variables'])
    reference=mp['projection_items'][i];assert reference['owner']==i;dummy.update([reference['reference_x'],reference['variant'],*reference['selected_fields']]);dummy.add(next(r['end'] for r in mp['insert_projection_intervals'] if r['owner']==i))
for pair in mp['projection_pairs']:
    if inactive.intersection(pair['owners']):dummy.update([pair['forward'],pair['backward'],pair['order']]);pair_tables[pair['distance_table']]=pair
for pair in mp['facet_pairs']:
    if inactive.intersection([pair['left'],pair['right']]):dummy.update(f['selector'] for f in pair['facets'])
classified=[];global_intervals=[];cross_tables=cross_rows=0
for ix,c in enumerate(p.constraints):
    kind=c.WhichOneof('constraint');used=variables(c);touch=bool(used&dummy)
    if kind in ['no_overlap_2d','cumulative']:
        lists=[list(c.no_overlap_2d.x_intervals),list(c.no_overlap_2d.y_intervals)] if kind=='no_overlap_2d' else [list(c.cumulative.intervals)];found=[]
        for ids in lists:
            for k,j in enumerate(ids):
                ci=p.constraints[j];assert ci.WhichOneof('constraint')=='interval'
                if variables(ci)&dummy:
                    assert len(ci.enforcement_literal)==1 and ci.enforcement_literal[0] in presences and variables(ci)<=dummy;found.append(j)
                    if kind=='cumulative':assert variables(c.cumulative.demands[k])<=dummy
        if found:global_intervals.append({'constraint':ix,'kind':kind,'inactive_intervals':found})
        if touch:assert found and kind=='cumulative'
        continue
    if not touch:continue
    if ix in changed:classification='explicit first-sheet transfer'
    elif presences.intersection(c.enforcement_literal):classification='disabled by inactive owner'
    elif kind=='bool_or' and {-v-1 for v in presences}.intersection(c.bool_or.literals):classification='true because owner absent'
    elif used<=dummy:classification='local joint dummy assignment independent of every active owner'
    elif ix in pair_tables:
        pair=pair_tables[ix];assert kind=='table' and not c.enforcement_literal and not c.table.negated and len(c.table.exprs)==4;vv=[]
        for e in c.table.exprs:assert len(e.vars)==1 and list(e.coeffs)==[1] and not e.offset;vv.append(e.vars[0])
        refs=[mp['projection_items'][k] for k in pair['owners']];assert vv==[refs[0]['variant'],refs[1]['variant'],pair['forward'],pair['backward']];indices=[k for k,owner in enumerate(pair['owners']) if owner in inactive];assert len(indices)==1;which=indices[0];other=1-which;rows=[list(c.table.values[k:k+4]) for k in range(0,len(c.table.values),4)];fixed=pos[vv[which]];assert set(r[other] for r in rows if r[which]==fixed)==set(refs[other]['profile_ids'])
        for row in rows:
            for vi,value in zip(vv,row):assert any(lo<=value<=hi for lo,hi in zip(p.variables[vi].domain[::2],p.variables[vi].domain[1::2]))
        cross_tables+=1;cross_rows+=len(rows);classification='complete active-mode table with freely chosen dummy distance auxiliaries'
    else:raise AssertionError((ix,kind,sorted(used&dummy),sorted(used-dummy)))
    classified.append({'constraint':ix,'kind':kind,'classification':classification})
assert len(pair_tables)==57 and cross_tables==42 and cross_rows==504 and len(global_intervals)==5;positive=violations(p,pos);relaxed=violations(p,pos,[110]);negative=violations(p,neg);assert [r['constraint'] for r in positive['failed_constraints']]==[110] and not relaxed['failed_constraints'] and negative['failed_constraints'] and positive['cumulative_checks'][-1]['peak_demand']==negative['cumulative_checks'][-1]['peak_demand']==0
write(OUT/'inactive-owner-proof.json',{'inactive_presences':sorted(presences),'dummy_variables':sorted(dummy),'classified_constraints':classified,'global_optional_interval_uses':global_intervals,'cross_pair_tables':cross_tables,'cross_pair_table_rows':cross_rows,'argument':'Any source-feasible five-bracket/two-cog layout supplies all seven active mappings under the previously audited necessity proof. Assign all six inactive insert slots jointly from the positive control, with presence zero. Every cross geometry/order inequality is disabled, every optional insert interval is absent, and each active/dummy table freely extends every active variant. All remaining joint dummy constraints pass on that fixed control. The59 first-sheet originals explicitly include every removed insert. Complete active poses may be relabelled by coarse X. No active anchor, orientation or legal cog angle is fixed.'});write(OUT/'controls.json',{'positive_full_target':positive,'positive_only_missing_cog0_disabled':relaxed,'negative_full_target':negative})
inputs=[Path(__file__),ROOT/'output/h5_source_projection_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',BASE/'preflight/plan.json',BASE/'preflight/checks.json',BASE/'preflight/inventory.json',OLD/'model-audit/plan.json',OLD/'model-audit/checks.json']+[MODEL/n for n in ['model.pb','model.pbtxt','mapping.json','positive-control-assignment.json','negative-assignment.json','hint-changes.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'all1876_variables_unchanged':True,'only6_presence_constraints_and6_hints_changed':True,'other1907_constraints_unchanged':True,'all7_short_and59_first_identities_verified':True,'all_inactive_owner_dependencies_classified':True,'inactive_variables':len(dummy),'inactive_touching_constraints_classified':len(classified),'global_optional_interval_uses':5,'complete_cross_pair_tables':42,'cross_pair_rows':504,'positive6_fails_only_missing_cog0':True,'positive6_with_only_cog0_requirement_disabled_passes':True,'negative7_failed_constraints':len(negative['failed_constraints']),'insert_capacity_peak_zero_both_controls':True,'source7_mapping_necessary':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
