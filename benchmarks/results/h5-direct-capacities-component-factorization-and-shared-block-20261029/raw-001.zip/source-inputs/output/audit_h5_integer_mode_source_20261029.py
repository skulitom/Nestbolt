"""Independent affine-transform and original-ring replay of the eleven-part witness."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, math, shutil, time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-integer-mode-regions-20261029'
SEARCH = BASE / 'search'
OUT = BASE / 'source-audit'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(BASE / 'response-audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
job, stock_plan = load(JOB), load(STOCK)
parts = {p['id']: p for p in job['parts']}
stock = stock_plan['source_stock']
rows = load(SEARCH / 'source-response/candidate-source11.json')
saved = load(SEARCH / 'source-response/original-source-checks.json')
mapping, values, inventory = load(BASE / 'model/mapping.json'), load(SEARCH / 'assignment.json'), load(BASE / 'inventory.json')
keys = [(r['part_id'], r['copy_index']) for r in rows]
short, first = list(map(tuple, inventory['short11_identities'])), list(map(tuple, inventory['mandatory_first55_identities']))
assert len(keys) == len(set(keys)) == 11 and set(keys) == set(short)
assert len(first) == 55 and not set(first) & set(short) and set(first+short) == {(p['id'], i) for p in job['parts'] for i in range(p['quantity'])}
shapes, stock_checks = [], []
holes = vertices = 0
for owner, row in zip(mapping['owners'], rows):
    assert row['sheet_id'] == 'sheet-1' and list((row['part_id'], row['copy_index'])) == owner['identity']
    selected = [m for m in owner['modes'] if values[m['selector']] == 1]
    assert len(selected) == 1
    mode = selected[0]
    expected = {'rotation_radians': mode['rotation_radians'], 'mirrored': mode['mirrored'],
                'translation': [values[owner['positions'][k]]/1000+mode['translation_from_lower_left'][k] for k in [0, 1]]}
    assert row['transform'] == expected
    part, t = parts[row['part_id']], row['transform']
    assert not t['mirrored'] or part['allow_mirror']
    assert part['rotations']['kind'] == 'free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a), math.tau)) < 1e-12 for a in part['rotations']['degrees'])
    c, s, sign = math.cos(t['rotation_radians']), math.sin(t['rotation_radians']), (-1 if t['mirrored'] else 1)
    matrix = [sign*c, -s, sign*s, c, *t['translation']]
    geometry = part['geometry'][0]
    raw = Polygon(geometry['outer'])
    full = Polygon(geometry['outer'], geometry.get('holes', []))
    filled, transformed_full = affine_transform(raw, matrix), affine_transform(full, matrix)
    assert filled.is_valid and transformed_full.is_valid and abs(filled.area-raw.area) < 1e-6 and abs(transformed_full.area-full.area) < 1e-6
    assert len(transformed_full.interiors) == len(geometry.get('holes', []))
    holes += len(geometry.get('holes', []))
    vertices += sum(len(h) for h in geometry.get('holes', []))
    bounds = filled.bounds
    clearance = [bounds[0]-stock[0], bounds[1]-stock[1], stock[2]-bounds[2], stock[3]-bounds[3]]
    assert min(clearance) > stock_plan['stock_guard_mm']
    stock_checks.append({'identity': owner['identity'], 'clearances_mm': clearance})
    shapes.append((owner['identity'], filled))
pair_checks = []
for (ia, a), (ib, b) in combinations(shapes, 2):
    distance = a.distance(b)
    assert a.disjoint(b) and distance > stock_plan['required_pair_gap_mm']
    pair_checks.append({'identities': [ia, ib], 'distance_mm': distance, 'intersection_area_mm2': a.intersection(b).area})
assert holes == saved['cutouts'] == 21 and vertices == saved['hole_vertices'] == 2718
assert len(pair_checks) == saved['same_sheet_pairs'] == 55 and 4*len(stock_checks) == saved['stock_edges'] == 44
minimum_gap = min(p['distance_mm'] for p in pair_checks)
minimum_stock = min(min(p['clearances_mm']) for p in stock_checks)
assert abs(minimum_gap-saved['minimum_pair_gap_mm']) < 1e-9 and abs(minimum_stock-saved['minimum_extra_stock_mm']) < 1e-9
write(OUT / 'replayed-source-checks.json', {'valid': True, 'pairs': pair_checks, 'stock': stock_checks, 'cutouts': holes, 'hole_vertices': vertices})
inputs = [Path(__file__), JOB, STOCK, BASE / 'response-audit/plan.json', BASE / 'response-audit/checks.json',
          BASE / 'model/mapping.json', BASE / 'inventory.json', SEARCH / 'assignment.json', SEARCH / 'source-response/plan.json',
          SEARCH / 'source-response/candidate-source11.json', SEARCH / 'source-response/original-source-checks.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'source_valid11': True, 'original_transforms_rederived': 11,
          'original_source_pair_checks': 55, 'original_stock_edges': 44, 'original_cutouts_preserved': holes,
          'original_hole_vertices_preserved': vertices, 'minimum_pair_gap_mm': minimum_gap, 'minimum_extra_stock_mm': minimum_stock,
          'all11_short_and55_first_identities_verified': True, 'first55_constructed': False, 'source_valid66': False,
          'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
