"""Verify the entire corrected reference-projection model and both controls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_source_projection_short_core_reader_20261029 import inspect,violations
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';MODEL=BASE/'model-v3';PRE=BASE/'preflight-v2';OLD=ROOT/'output/h5-source-pair-short-core-20261029';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,PRE/'audit',OLD/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PRE/'audit/checks.json')['passed'] and load(OLD/'model-audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());parent=cp_model_pb2.CpModelProto();parent.ParseFromString((OLD/'model/model.pb').read_bytes());mp=load(MODEL/'mapping.json');pos=load(MODEL/'positive-control-assignment.json');neg=load(MODEL/'negative-assignment.json');checked=inspect(p,parent,mp,load(OLD/'model/mapping.json'),load(PRE/'mode-map.json'),load(PRE/'pair-distances.json'),load(PRE/'reference-link.json'),load(PRE/'positive-references11.json'),load(PRE/'negative-references13.json'),pos,neg,load(OLD/'model/positive-control-assignment.json'),load(OLD/'model/negative-assignment.json'),load(MODEL/'extra-hints.json'))
positive=violations(p,pos);relaxed=violations(p,pos,mp['control_disabled_mandatory_constraints']);negative=violations(p,neg);assert [v['constraint'] for v in positive['failed_constraints']]==mp['control_disabled_mandatory_constraints'] and not relaxed['failed_constraints'];assert len(negative['failed_constraints'])==102 and negative['cumulative_checks'][-1]['peak_demand']==6 and positive['cumulative_checks'][-1]['peak_demand']==2
write(OUT/'controls.json',{'positive_full_target':positive,'positive_only_two_missing_requirements_disabled':relaxed,'negative_full_target':negative})
inputs=[Path(__file__),ROOT/'output/h5_source_projection_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',PRE/'audit/plan.json',OLD/'model-audit/plan.json',BASE/'preflight/failure.json',BASE/'model/failure.json',BASE/'model-v2/failure.json']+[MODEL/n for n in ['model.pb','model.pbtxt','mapping.json','built.json','construction-diagnostics.json','positive-control-assignment.json','negative-assignment.json','extra-hints.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-started,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'positive11_fails_only_two_missing_requirements':True,'positive11_with_only_missing_requirements_disabled_passes':True,'negative13_failed_constraints':102,'positive_insert_peak':2,'negative_insert_peak':6,'initial_preparation_and_both_build_failures_preserved':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
