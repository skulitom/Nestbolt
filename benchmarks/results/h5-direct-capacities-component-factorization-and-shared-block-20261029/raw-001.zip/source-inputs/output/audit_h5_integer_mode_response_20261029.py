"""Verify the sole CP response, complete integer assignment and preserved budget evidence."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2, sat_parameters_pb2

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-integer-mode-regions-20261029'
MODEL, SEARCH, OUT = BASE / 'model', BASE / 'search', BASE / 'response-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
queue = [BASE / 'plan.json', MODEL / 'plan.json', BASE / 'model-audit/plan.json', SEARCH / 'opened.json', SEARCH / 'source-response/plan.json']
seen, bindings = set(), {}
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    for name, expected in load(path).get('inputs', {}).items():
        source = ROOT / name
        assert source.is_relative_to(ROOT) and not {'.claude', '.cache'} & set(source.parts)
        assert digest(source) == expected, name
        bindings[name] = expected
        if source.name in ['plan.json', 'opened.json']:
            queue.append(source)
opened, result, process, budget = [load(SEARCH / n) for n in ['opened.json', 'result.json', 'process.json', 'budget.json']]
assert load(BASE / 'model-audit/checks.json')['passed']
assert digest(MODEL / 'model.pb') == digest(SEARCH / 'model.pb') == opened['model_sha256'] == load(BASE / 'model-audit/checks.json')['model_sha256']
model = cp_model_pb2.CpModelProto()
model.ParseFromString((SEARCH / 'model.pb').read_bytes())
response = cp_model_pb2.CpSolverResponse()
response.ParseFromString((SEARCH / 'response.pb').read_bytes())
assert response.status == cp_model_pb2.OPTIMAL and result['status'] == 'OPTIMAL'
values = list(response.solution)
assert values == load(SEARCH / 'assignment.json') and len(values) == len(model.variables) == 7634
assert len(list((SEARCH / 'incumbents').glob('*.json'))) == result['incumbents_recorded'] == 1
assert load(SEARCH / 'incumbents/000.json')['values'] == values
for variable, value in zip(model.variables, values):
    assert any(lo <= value <= hi for lo, hi in zip(variable.domain[::2], variable.domain[1::2]))
active = inactive = 0
for constraint in model.constraints:
    assert constraint.WhichOneof('constraint') == 'linear'
    enabled = all(values[i] == 1 if i >= 0 else values[-i-1] == 0 for i in constraint.enforcement_literal)
    if enabled:
        lhs = sum(c*values[v] for v, c in zip(constraint.linear.vars, constraint.linear.coeffs))
        assert any(lo <= lhs <= hi for lo, hi in zip(constraint.linear.domain[::2], constraint.linear.domain[1::2]))
        active += 1
    else:
        inactive += 1
assert active+inactive == 26264
parameters = text_format.Parse((SEARCH / 'parameters.pbtxt').read_text(), sat_parameters_pb2.SatParameters())
assert {f.name for f, v in parameters.ListFields()} == {'max_time_in_seconds', 'num_search_workers', 'random_seed', 'log_search_progress', 'log_to_stdout', 'ignore_subsolvers'}
assert parameters.max_time_in_seconds == opened['parameters']['max_time_in_seconds'] == result['allocated_solve_seconds']
assert parameters.num_search_workers == 4 and parameters.random_seed == 0 and parameters.log_search_progress and not parameters.log_to_stdout
assert list(parameters.ignore_subsolvers) == ['fj']
assert response.num_branches == result['returned_response_branches'] == 80234
assert response.num_conflicts == result['returned_response_conflicts'] == 8176 and response.wall_time == result['solver_wall_seconds']
assert result['closed'] and result['solver_calls'] == 1 and result['has_assignment'] and result['source_valid11']
assert result['source_checker_calls'] == 1 and not result['source_valid66'] and not result['any_allocation_excluded']
assert process['closed'] and process['exit_code'] == 0 and not process['timeout']
assert result['algorithm_seconds_including_preparation'] < 60 and process['seconds_including_preparation'] < 90
assert result['algorithm_overrun_seconds'] == result['returned_solve_overrun_seconds'] == 0
assert opened['maximum_calls'] == budget['maximum_calls'] == 1 and not opened['retry_permitted'] and not budget['retry_permitted']
assert opened['preparation_seconds_charged'] == budget['preparation_seconds_charged'] == result['preparation_seconds_charged'] == load(MODEL / 'checks.json')['preparation_seconds_charged']
assert (SEARCH / 'stderr.txt').read_text() == (SEARCH / 'source-check-stderr.txt').read_text() == ''
assert not load(SEARCH / 'assignment-check.json')['failed_constraints']
assert load(SEARCH / 'source-response/original-source-checks.json')['valid']
write(OUT / 'source-bindings.json', bindings)
inputs = [Path(__file__), BASE / 'plan.json', MODEL / 'plan.json', BASE / 'model-audit/plan.json', BASE / 'model-audit/checks.json'] + [SEARCH / n for n in ['opened.json', 'budget.json', 'model.pb', 'parameters.pbtxt', 'response.pb', 'assignment.json', 'assignment-check.json', 'incumbents/000.json', 'result.json', 'process.json', 'solver.log', 'stdout.txt', 'stderr.txt', 'source-response/plan.json', 'source-response/checks.json', 'source-response/candidate-source11.json', 'source-response/original-source-checks.json']]
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'recursive_input_bindings_verified': len(bindings),
          'closed_solver_calls': 1, 'solver_status': 'OPTIMAL', 'satisfaction_model_without_objective': True,
          'assignment_variables_verified': len(values), 'active_constraints_verified': active, 'inactive_guarded_constraints_verified': inactive,
          'single_incumbent_matches_response': True, 'branches': response.num_branches, 'conflicts': response.num_conflicts,
          'preparation_seconds_charged': result['preparation_seconds_charged'], 'returned_solve_seconds': result['returned_solve_seconds'],
          'algorithm_seconds_including_preparation': result['algorithm_seconds_including_preparation'],
          'shared_seconds_including_preparation': process['seconds_including_preparation'], 'all_overruns_seconds': 0,
          'source_valid11': True, 'independent_source_replay_pending': True, 'source_valid66': False,
          'any_allocation_excluded': False, 'remaining_candidates': 440, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
