"""Verify all legal owner/mode mappings and exact clearance of rounded template regions."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations, product
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, shape
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
MODES = ROOT / 'output/h5-first55-after-source-valid11-20261029'
BASE = MODES / 'pair-region-preflight'
OUT = BASE / 'audit'
STOCK = MODES / 'plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for name, expected in load(BASE / 'plan.json')['inputs'].items():
    assert digest(ROOT / name) == expected, name
assert load(MODES / 'audit/checks.json')['passed']
library, modes, instances = [load(MODES / n) for n in ['geometry-library.json', 'family-modes.json', 'instances.json']]
templates, obstacles, owner_pairs, geometry_bounds = [load(BASE / n) for n in ['templates.json', 'obstacles.json', 'owner-pairs.json', 'geometry-stock-bounds.json']]
stock = load(STOCK)['construction_stock']
options = [sorted({m['normalized_geometry'] for m in modes[row['identity'][0]]}) for row in instances]
expected_pairs = set(combinations(range(26), 2))
seen_pairs, used_templates = set(), set()
template_lookup = {tuple(t['geometries']): i for i, t in enumerate(templates)}
assert len(template_lookup) == len(templates) == len(obstacles) == 95
expanded_cases = 0
for group in owner_pairs:
    ia, ib = group['owners']
    assert (ia, ib) in expected_pairs and (ia, ib) not in seen_pairs
    seen_pairs.add((ia, ib))
    assert group['identities'] == [instances[ia]['identity'], instances[ib]['identity']]
    expected = [list(v) for v in product(options[ia], options[ib])]
    assert group['geometry_pairs'] == expected
    assert group['template_indices'] == [template_lookup[tuple(v)] for v in expected]
    used_templates.update(group['template_indices'])
    expanded_cases += len(expected)
assert seen_pairs == expected_pairs and used_templates == set(range(95)) and expanded_cases == 3038
for geometry in library:
    assert geometry_bounds[str(geometry['id'])] == [[stock[0]+.025, stock[2]-.025-geometry['dimensions'][0]], [stock[1]+.025, stock[3]-.025-geometry['dimensions'][1]]]
certificates = []
regions_checked = proofs_checked = 0
minimum_gap = math.inf
max_rounding = F(0)
max_coverage = 0.
for template, obstacle_record in zip(templates, obstacles):
    ga, gb = template['geometries']
    assert obstacle_record['geometries'] == [ga, gb]
    assert template['relative_variable'] == 'lower_left_b_minus_lower_left_a'
    A, B = geometry_bounds[str(ga)], geometry_bounds[str(gb)]
    expected_domain = [B[0][0]-A[0][1], B[1][0]-A[1][1], B[0][1]-A[0][0], B[1][1]-A[1][0]]
    assert template['domain'] == expected_domain
    source_pairs = []
    for ai, av in enumerate(library[ga]['pieces']):
        for bi, bv in enumerate(library[gb]['pieces']):
            nfp = MultiPoint((np.asarray(av)[:, None, :]-np.asarray(bv)[None, :, :]).reshape(-1, 2)).convex_hull
            source_pairs.append((ai, bi, [tuple(map(F, p)) for p in av], [tuple(map(F, p)) for p in bv], nfp))
    assert len(source_pairs) == template['piece_pairs']
    polygons, proofs = [], []
    for region_index, vertices in enumerate(template['regions']):
        original = [tuple(map(F, v)) for v in vertices]
        assert len(original) >= 3 and all(cross(a, b, c) > 0 for a, b, c in zip(original, original[1:]+original[:1], original[2:]+original[:2]))
        rounded = [tuple(F(round(v, 9)) for v in point) for point in vertices]
        for a, b in zip(original, rounded):
            max_rounding = max(max_rounding, abs(a[0]-b[0]), abs(a[1]-b[1]))
        region = Polygon(vertices)
        assert region.is_valid and region.area > 0
        polygons.append(region)
        for ai, bi, source_a, source_b, nfp in source_pairs:
            segment = list(shapely.shortest_line(nfp, region).coords)
            assert len(segment) == 2
            nx, ny = segment[1][0]-segment[0][0], segment[1][1]-segment[0][1]
            length = math.hypot(nx, ny)
            assert length > 0
            normal = [nx/length, ny/length]
            nx, ny = map(F, normal)
            gap = min(x*nx+y*ny for x, y in rounded)+min(x*nx+y*ny for x, y in source_b)-max(x*nx+y*ny for x, y in source_a)
            norm2 = nx*nx+ny*ny
            assert gap > 0 and gap*gap >= F('.225')**2*norm2, (ga, gb, region_index, ai, bi, float(gap))
            minimum_gap = min(minimum_gap, float(gap)/math.sqrt(float(norm2)))
            proofs.append([region_index, ai, bi, *normal])
            proofs_checked += 1
        regions_checked += 1
    combined = unary_union(polygons)
    free = shape(obstacle_record['bounded_free_region'])
    coverage = combined.symmetric_difference(free).area
    assert coverage < 1e-7 and abs(sum(p.area for p in polygons)-combined.area) < 1e-7
    max_coverage = max(max_coverage, coverage)
    certificates.append({'geometries': [ga, gb], 'rounded_vertex_decimals': 9, 'proofs': proofs})
assert regions_checked == sum(len(t['regions']) for t in templates)
write(OUT / 'rounded-region-support-certificates.json', certificates)
inputs = [Path(__file__), STOCK, MODES / 'plan.json', MODES / 'audit/plan.json', MODES / 'audit/checks.json',
          MODES / 'family-modes.json', MODES / 'geometry-library.json', MODES / 'instances.json',
          BASE / 'plan.json', BASE / 'checks.json', BASE / 'templates.json', BASE / 'obstacles.json',
          BASE / 'owner-pairs.json', BASE / 'geometry-stock-bounds.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'original_owner_pairs_verified': 325,
          'geometry_pair_templates_verified': 95, 'expanded_original_geometry_pair_cases_verified': expanded_cases,
          'rounded_convex_region_hulls_verified': regions_checked, 'exact_rounded_region_source_support_proofs': proofs_checked,
          'minimum_certified_source_gap_mm': minimum_gap, 'maximum_vertex_rounding_mm': float(max_rounding),
          'maximum_float_free_space_coverage_error_mm2': max_coverage,
          'all_legal_modes_map_to_regions_through_filled_geometry': True,
          'all_mode_specific_relative_stock_domains_verified': True,
          'negative_result_restricted_by_fixed_cog_phase_and_conservative_free_space': True,
          'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
