"""Check whether unchanged rows alone already contradict the proposed six-choice model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';BASE=ROOT/'output/h5-short11-six-axis-choices-20261029';OUT=BASE/'fixed-row-cycle-audit';PRE=SOURCE/'source-translation-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');assert load(BASE/'model-audit/checks.json')['passed'];mp=load(BASE/'model/mapping.json');removed=set(mp['removed_parent_rows']);old=load(SOURCE/'source-translation-audit/axis-subsystem.json');edges=[e for e in old['edges'] if e['source'].get('plane') not in removed];dist=[F(0)]*23;pred=[None]*23;changed=None
for iteration in range(23):
    changed=None
    for k,e in enumerate(edges):
        if dist[e['to']]>dist[e['from']]+F(e['weight']):dist[e['to']]=dist[e['from']]+F(e['weight']);pred[e['to']]=k;changed=e['to']
    if changed is None:break
cycle=[];details=[];net=[0]*23;total=F(0);planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');world=load(PRE/'world-pieces.json');model=np.load(BASE/'model/model.npz');retained={oldrow:newrow for newrow,oldrow in enumerate(mp['retained_parent_rows'])}
if changed is not None:
    v=changed
    for _ in range(23):assert pred[v] is not None;v=edges[pred[v]]['from']
    first=v
    while True:
        k=pred[v];cycle.append(k);v=edges[k]['from']
        if v==first:break
        assert len(cycle)<=23
    cycle.reverse()
    for k in cycle:
        e=edges[k];src=e['source']
        if src['kind']=='stock_upper':i=src['variable'];assert e['from']==22 and e['to']==i and model['bounds'][i,1]==bounds[i][1];weight=F(bounds[i][1])
        elif src['kind']=='stock_lower':i=src['variable'];assert e['from']==i and e['to']==22 and model['bounds'][i,0]==bounds[i][0];weight=-F(bounds[i][0])
        else:
            oldrow=src['plane'];assert oldrow not in removed and oldrow in retained;plane=planes[oldrow];a,b=plane['owners'];axis=src['axis'];sign=src['normal_sign'];expected=np.zeros(113)
            expected[2*a:2*a+2]=plane['normal'];expected[2*b:2*b+2]=-np.asarray(plane['normal']);assert np.array_equal(model['A'][retained[oldrow]],expected) and model['upper'][retained[oldrow]]==plane['upper_delta_difference_mm'] and np.isneginf(model['lower'][retained[oldrow]])
            error=F(0)
            for d in [0,1]:
                coefficient=F(sign if axis==d else 0)-F(plane['normal'][d]);ends=[F(bounds[2*a+d][0])-F(bounds[2*b+d][1]),F(bounds[2*a+d][1])-F(bounds[2*b+d][0])];error+=max(coefficient*z for z in ends)
            assert error==F(src['coefficient_error_allowance_mm']);weight=F(plane['upper_delta_difference_mm'])+error+F(1,10**9);assert (e['from'],e['to'])==((2*b+axis,2*a+axis) if sign==1 else (2*a+axis,2*b+axis))
        assert weight==F(e['weight']);total+=weight;net[e['to']]+=1;net[e['from']]-=1;details.append({'from':'stock-origin' if e['from']==22 else [world[e['from']//2]['identity'],'xy'[e['from']%2]],'to':'stock-origin' if e['to']==22 else [world[e['to']//2]['identity'],'xy'[e['to']%2]],'weight_mm':str(weight),'source':src})
    assert total<0 and not any(net) and all(edges[cycle[i]]['to']==edges[cycle[(i+1)%len(cycle)]]['from'] for i in range(len(cycle)))
write(OUT/'certificate.json',{'fixed_edges':len(edges),'cycle':details,'negative_sum_mm':str(total) if cycle else None,'negative_sum_mm_approx':float(total) if cycle else None,'all_left_coefficients_cancel':not any(net),'only_retained_rows_and_stock_bounds_used':True,'scope':'A verified cycle proves this restricted six-choice model impossible independently of its ninety selectors. It does not exclude the allocation or different source separation branches/orientations.'})
inputs=[Path(__file__),BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'model/model.npz',BASE/'model/mapping.json',SOURCE/'source-translation-audit/plan.json',SOURCE/'source-translation-audit/axis-subsystem.json',PRE/'planes.json',PRE/'variable-bounds.json',PRE/'world-pieces.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'retained_axis_edges':len(edges),'negative_cycle_found':bool(cycle),'cycle_edges':len(cycle),'negative_sum_mm_approx':float(total) if cycle else None,'restricted_model_infeasibility_certified_without_search':bool(cycle),'all_selected_rows_still_fixed_in_exact_model':True,'all_left_coefficients_cancel':not any(net),'solver_call_needed':not bool(cycle),'solver_calls':0,'native_calls':0,'allocation_excluded':False,'remaining_candidates':440,'H5_complete':False});print(load(OUT/'checks.json'))
