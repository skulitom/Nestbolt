"""Complete independent source-obstacle containment and all228 free-region checks."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,shape,box
from shapely.affinity import translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-two-cog-exchange-20261028';OUT=BASE/'preflight-v2';PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for c in getattr(g,'geoms',[]) for p in polygons(c)]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'prepared.json');assert prepared['passed'] and prepared['preparation_closed'] and prepared['seconds']<120
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);parts={p['id']:p for p in job['parts']};modes={m['index']:m for m in load(BASE/'modes.json')};fixed=load(BASE/'fixed-types.json');assert list(modes)==list(range(36))+[44,45] and len(fixed)==5
def original(family,a,mir,offset=(0.,0.)):
    vertices=[(-x if mir else x,y) for x,y in parts[family]['geometry'][0]['outer']];c,s=math.cos(a),math.sin(a);ox,oy=offset
    return Polygon([(c*x-s*y+ox,s*x+c*y+oy) for x,y in vertices])
def partition(g):
    pieces=list(shapely.constrained_delaunay_triangles(g).geoms);assert pieces and unary_union(pieces).equals(g) and all(p.equals(p.convex_hull) for p in pieces);return [list(p.exterior.coords)[:-1] for p in pieces]
fg={};ft={};mg={};mt={}
for f in fixed:
    g=original(f['family'],f['angle'],f['mirrored']);assert g.equals_exact(shape(f['geometry']),1e-10);fg[f['id']]=g;ft[f['id']]=partition(g);assert len(ft[f['id']])==f['source_triangles']
for mi,m in modes.items():
    g=original(m['family'],m['angle'],m['mirrored'],m['source_translation_offset']);assert g.equals_exact(shape(m['geometry']),1e-10);mg[mi]=g;mt[mi]=partition(g)
expected={('fixed-moving',f['id'],mi) for f in fixed for mi in modes}|{('cog-insert',mi,ii) for mi in range(36) for ii in [44,45]};records=load(BASE/'obstacle-index.json');seen=set();hulls_count=0;obstacles={};checks=[]
for record in records:
    if record['kind']=='fixed-moving':kind,a,b='fixed-moving',record['fixed_type'],record['moving_mode'];left,right=ft[a],mt[b]
    else:kind,a,b='cog-insert',record['cog_mode'],record['insert_mode'];left,right=mt[a],mt[b]
    key=(kind,a,b);assert key in expected and key not in seen;seen.add(key);saved=load(BASE/'obstacles'/record['file']);obstacle=shape(saved['geometry']);assert saved['hulls']==record['hulls']==len(left)*len(right)
    # Reconstruct from original vertices with explicit scalar differences, independently of the broadcast constructor.
    points=np.asarray([[(u[0]-v[0],u[1]-v[1]) for u in l for v in r] for l in left for r in right]);hulls=shapely.convex_hull(shapely.multipoints(points));required=shapely.union_all(hulls).buffer(plan['independent_required_obstacle_radius_mm'],quad_segs=16);assert obstacle.is_valid and obstacle.covers(required),key;obstacles[key]=obstacle;hulls_count+=len(hulls);checks.append({'kind':kind,'left':a,'right':b,'independent_hulls':len(hulls),'required_source_clearance_contained':True})
    if len(checks)%38==0:print({'obstacles_verified':len(checks),'seconds':time.perf_counter()-started},flush=True)
assert seen==expected and hulls_count==prepared['convex_minkowski_hulls'];write(OUT/'obstacle-checks.json',checks);source_ids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};stock=plan['source_stock'];extra=plan['new_moving_stock_extra_mm'];free_count=cog_empty=insert_nonempty=0;samples=[]
for summary in load(BASE/'case-summary.json'):
    removed=summary['removed_bracket_copy'];case=load(BASE/'cases'/f'{removed:02d}.json');old=load(PRE/'cases'/f'{removed:02d}.json');assert {k:v for k,v in case.items() if k!='fixed_references'}==old;refs=case['fixed_references'];assert len(refs)==len(case['fixed11'])==11;fixed_world=[]
    for p,ref in zip(case['fixed11'],refs):
        t=p['transform'];f=fixed[ref['fixed_type']];assert (f['family'],f['angle'],f['mirrored'])==(p['part_id'],t['rotation_radians'],t['mirrored']) and ref['translation']==t['translation'] and ref['identity']==[p['part_id'],p['copy_index']];fixed_world.append(original(p['part_id'],t['rotation_radians'],t['mirrored'],t['translation']))
    short={tuple(v) for v in case['target_short_identities']};first={tuple(v) for v in case['mandatory_first_identities']};assert len(short)==13 and len(first)==53 and short.isdisjoint(first) and short|first==source_ids
    for mi,m in modes.items():
        saved=load(BASE/'free'/f'{removed:02d}'/f'{mi:02d}.json');a,b,c,d=mg[mi].bounds;bounds=[stock[0]+extra-a,stock[1]+extra-b,stock[2]-extra-c,stock[3]-extra-d];assert saved['anchor_stock_bounds_mm']==bounds and saved['moving_mode']==mi and saved['removed_bracket_copy']==removed;free=shape(saved['geometry']);expected_free=box(*bounds).difference(unary_union([translate(obstacles['fixed-moving',ref['fixed_type'],mi],*ref['translation']) for ref in refs]));assert free.equals(expected_free);free_count+=1;cog_empty+=int(mi<36 and free.is_empty);insert_nonempty+=int(mi>=44 and not free.is_empty)
        for region in polygons(free):
            xy=list(region.representative_point().coords[0]);g=translate(mg[mi],*xy);bb=g.bounds;minimum_stock=min(bb[0]-stock[0],bb[1]-stock[1],stock[2]-bb[2],stock[3]-bb[3]);assert minimum_stock>plan['stock_guard_mm'];all_shapes=fixed_world+[g];gaps=[]
            for a,b in combinations(all_shapes,2):assert a.disjoint(b) and a.distance(b)>plan['required_pair_gap_mm'];gaps.append(a.distance(b))
            actual=min([minimum_stock]+[min(p.bounds[0]-stock[0],p.bounds[1]-stock[1],stock[2]-p.bounds[2],stock[3]-p.bounds[3]) for p in fixed_world]);samples.append({'removed_bracket_copy':removed,'mode':mi,'anchor':xy,'source_originals':12,'minimum_pair_gap_mm':min(gaps),'minimum_extra_stock_mm':actual})
assert samples==load(BASE/'free-source-samples.json') and free_count==228 and cog_empty==216 and insert_nonempty==prepared['nonempty_insert_free_domains']==4;write(OUT/'source-sample-checks.json',samples)
inputs=[Path(__file__),ROOT/'output/audit_h5_short_two_cog_exchange_20261028.py',BASE/'preflight/audit.py',BASE/'preflight/obstacle-checks.json',BASE/'preflight/retained-incomplete-audit.json',BASE/'plan.json',BASE/'prepared.json',BASE/'modes.json',BASE/'fixed-types.json',BASE/'obstacle-index.json',BASE/'case-summary.json',BASE/'free-source-samples.json',JOB]+[p for folder in ['obstacles','cases','free'] for p in (BASE/folder).rglob('*.json')];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'complete_source_obstacles_verified':len(checks),'independent_minkowski_hulls':hulls_count,'source_modes_verified':len(modes),'fixed_source_types_verified':len(fixed),'complete_free_domains_verified':free_count,'empty_cog_free_domains_verified':cog_empty,'source_representative_controls_verified':len(samples),'all6_full66_identity_partitions_verified':True,'finite_construction_has_no_cog_anchor_candidates':True,'all_angle_or_original_feasibility_excluded':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False});write(BASE/'finite-construction-closure.json',{'closed':True,'reason':'Independent complete region audit proves all216 declared cog domains empty, leaving no anchor for the frozen enumeration. Close this finite conservative construction at preflight without an empty search invocation.','declared_cog_cases':216,'cog_anchor_candidates':0,'source_short13_candidates':0,'construction_calls':0,'solver_calls':0,'unused_search_time_not_reused':True,'retry_permitted':False,'all_angle_or_original_infeasibility_claimed':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
