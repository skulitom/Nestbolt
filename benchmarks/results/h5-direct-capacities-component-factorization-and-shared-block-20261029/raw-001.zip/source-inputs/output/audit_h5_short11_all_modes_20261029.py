"""Verify every legal orientation, alias, identity and original-source stock-domain corner."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
import json, math, shutil, time
from shapely.geometry import Polygon
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
OUT = BASE / 'audit'
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def ring_key(vertices):
    rows = [tuple(p) for p in vertices]
    return min(tuple(s[i:]+s[:i]) for s in [rows, list(reversed(rows))] for i in range(len(s)))

def area(vertices):
    return sum((a[0]*b[1]-a[1]*b[0] for a, b in zip(vertices, vertices[1:]+vertices[:1])), F(0))/2

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for name, expected in load(BASE / 'plan.json')['inputs'].items():
    assert digest(ROOT / name) == expected, name
job, stock_plan = load(JOB), load(STOCK)
parts = {p['id']: p for p in job['parts']}
modes, library, instances, inventory = [load(BASE / n) for n in ['family-modes.json', 'geometry-library.json', 'instances.json', 'inventory.json']]
canonical = load(SOURCE / 'canonical-pieces.json')
stock = stock_plan['source_stock']
short = list(map(tuple, inventory['short11_identities']))
first = list(map(tuple, inventory['mandatory_first55_identities']))
assert len(short) == len(set(short)) == 11 and len(first) == len(set(first)) == 55
assert not set(short) & set(first) and set(short+first) == {(p['id'], i) for p in job['parts'] for i in range(p['quantity'])}
assert [tuple(r['identity']) for r in instances] == short
assert [g['id'] for g in library] == list(range(11))
geometry_users = Counter()
verified_modes = 0
for family in ['bracket', 'insert', 'cog']:
    part = parts[family]
    expected = {(7., False)} if family == 'cog' else {(float(a), mirrored) for a in part['rotations']['degrees'] for mirrored in ([False, True] if part['allow_mirror'] else [False])}
    assert {(m['rotation_degrees'], m['mirrored']) for m in modes[family]} == expected
    assert len(modes[family]) == len(expected)
    for index, mode in enumerate(modes[family]):
        assert mode['mode'] == index and mode['rotation_radians'] == math.radians(mode['rotation_degrees'])
        geometry = library[mode['normalized_geometry']]
        assert geometry['family'] == family
        angle = mode['rotation_degrees']
        c, s = (math.cos(math.radians(angle)), math.sin(math.radians(angle))) if family == 'cog' else [(1, 0), (0, 1), (-1, 0), (0, -1)][int(angle)//90]
        sign = -1 if mode['mirrored'] else 1
        def rotated(vertices):
            return [[sign*x*c-y*s, sign*x*s+y*c] for x, y in vertices]
        outer = rotated(part['geometry'][0]['outer'])
        ox, oy = min(p[0] for p in outer), min(p[1] for p in outer)
        normalized = [[x-ox, y-oy] for x, y in outer]
        assert mode['translation_from_lower_left'] == [-ox, -oy]
        assert ring_key(normalized) == ring_key(geometry['outer'])
        expected_pieces = [[[x-ox, y-oy] for x, y in rotated(p)] for p in canonical[family]]
        assert sorted(ring_key(p) for p in expected_pieces) == sorted(ring_key(p) for p in geometry['pieces'])
        dimensions = [max(x for x, y in normalized), max(y for x, y in normalized)]
        assert dimensions == geometry['dimensions']
        assert mode['lower_left_bounds'] == [[stock[0]+.025, stock[2]-.025-dimensions[0]], [stock[1]+.025, stock[3]-.025-dimensions[1]]]
        assert all(lo < hi for lo, hi in mode['lower_left_bounds'])
        geometry_users[geometry['id']] += 1
        verified_modes += 1

exact_piece_boundaries = 0
for geometry in library:
    boundary = Counter()
    pieces = []
    for vertices in geometry['pieces']:
        p = [tuple(map(F, v)) for v in vertices]
        if area(p) < 0:
            p.reverse()
        assert area(p) > 0 and all(cross(a, b, c) > 0 for a, b, c in zip(p, p[1:]+p[:1], p[2:]+p[:2]))
        pieces.append(p)
        boundary.update(zip(p, p[1:]+p[:1]))
    for a, b in list(boundary):
        count = min(boundary[a, b], boundary[b, a])
        boundary[a, b] -= count
        boundary[b, a] -= count
    outer = [tuple(map(F, v)) for v in geometry['outer']]
    if area(outer) < 0:
        outer.reverse()
    # Bracket rectangle decomposition splits one collinear outside edge. Compare
    # exact area plus source coverage, while the cog has exact original edges.
    assert sum((area(p) for p in pieces), F(0)) == area(outer)
    source = Polygon(geometry['outer'])
    union = unary_union([Polygon(p) for p in geometry['pieces']])
    assert source.symmetric_difference(union).area < 1e-8
    if geometry['family'] in ['cog', 'insert']:
        assert +boundary == Counter(zip(outer, outer[1:]+outer[:1]))
        exact_piece_boundaries += 1
assert set(geometry_users) == set(range(11)) and verified_modes == 13
assert sum(g['family'] == 'insert' for g in library) == 2

controls = []
minimum_stock = math.inf
total_mode_options = 0
for instance in instances:
    family, copy = instance['identity']
    assert instance['mode_count'] == len(modes[family])
    total_mode_options += instance['mode_count']
    for mode in modes[family]:
        for x in mode['lower_left_bounds'][0]:
            for y in mode['lower_left_bounds'][1]:
                row = {'part_id': family, 'copy_index': copy, 'sheet_id': 'sheet-1',
                       'transform': {'rotation_radians': mode['rotation_radians'], 'mirrored': mode['mirrored'],
                                     'translation': [x+mode['translation_from_lower_left'][0], y+mode['translation_from_lower_left'][1]]}}
                result = audit(job, [row], {'sheet-1': stock}, stock_plan['required_pair_gap_mm'], stock_plan['stock_guard_mm'], [(family, copy)])
                assert result['valid'] and result['cutouts'] == len(parts[family]['geometry'][0].get('holes', []))
                minimum_stock = min(minimum_stock, result['minimum_extra_stock_mm'])
                controls.append({'identity': instance['identity'], 'mode': mode['mode'], 'lower_left': [x, y],
                                 'valid': result['valid'], 'minimum_stock_mm': result['minimum_extra_stock_mm'],
                                 'cutouts': result['cutouts'], 'hole_vertices': result['hole_vertices']})
assert len(controls) == 232 and total_mode_options == 58
write(OUT / 'source-domain-corner-controls.json', controls)
inputs = [Path(__file__), ROOT / 'output/h5_legacy64_source_readback.py', JOB, STOCK, SOURCE / 'canonical-pieces.json',
          BASE / 'plan.json', BASE / 'checks.json', BASE / 'family-modes.json', BASE / 'geometry-library.json', BASE / 'instances.json', BASE / 'inventory.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'legal_family_modes_verified': 13,
          'instance_mode_options_verified': 58, 'unique_filled_geometries_verified': 11,
          'original_source_domain_corner_controls': 232, 'minimum_original_source_stock_clearance_mm': minimum_stock,
          'all11_short_and55_first_identities_verified': True, 'all_source_holes_preserved_in_controls': True,
          'insert_outer_aliases_verified': True, 'cog_phase_fixed_degrees': 7,
          'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
