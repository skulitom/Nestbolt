"""Bound connected whole-bracket counts in the exact audited accessible-area covers."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';AREA=BASE/'accessible-area-bound';OUT=BASE/'connected-capacity-bound'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(AREA/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
all_cells=(1<<15000)-1;left_column=sum(1<<(150*r) for r in range(100));right_column=left_column<<149
def components(bits):
    result=[]
    while bits:
        c=bits&-bits
        while True:
            horizontal=c|((c&~right_column)<<1)|((c&~left_column)>>1)
            expanded=(horizontal|(horizontal<<150)|(horizontal>>150))&bits&all_cells
            if expanded==c:break
            c=expanded
        result.append(c);bits&=~c
    return result
groups={int(k):int(v,16) for k,v in load(AREA/'family-mask-covers.json')['bracket'].items()};rows=[]
for prior in load(AREA/'all105-area-bounds.json'):
    mask=sum(1<<i for i in prior['empty_sites']);bits=0
    for required,v in groups.items():
        if required&~mask==0:bits|=v
    cc=components(bits);areas=[c.bit_count()*100 for c in cc];capacities=[a//40000 for a in areas]
    rows.append({'empty_sites':prior['empty_sites'],'components_hex':[hex(c) for c in cc],'component_area_upper_bounds_mm2':areas,'component_bracket_capacity_upper_bounds':capacities,'total_bracket_capacity_upper_bound':sum(capacities),'required_brackets':7,'restricted_construction_excluded':sum(capacities)<7,'previously_excluded_by_total_area':prior['restricted_construction_excluded']})
elapsed=time.perf_counter()-started
inputs=[Path(__file__)]+[AREA/n for n in ['plan.json','family-mask-covers.json','all105-area-bounds.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Every original filled L-bracket is connected and has at least40000mm2 area. Its entire swept occupied shape lies in one eight-neighbour connected component of the audited conservative10mm grid cover. Positive pair spacing makes distinct originals disjoint. Sum floor(component cell area /40000) bounds whole bracket count. Eight-neighbour connectivity conservatively merges cells touching only at corners. Bound applies only to the saved source-mask construction.','solver_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'all105-capacity-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'empty_site_pairs':105,'restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in rows),'new_restricted_pairs_excluded':sum(r['restricted_construction_excluded'] and not r['previously_excluded_by_total_area'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'capacity_range':[min(r['total_bracket_capacity_upper_bound'] for r in rows),max(r['total_bracket_capacity_upper_bound'] for r in rows)],'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'independent_audit_required':True,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
