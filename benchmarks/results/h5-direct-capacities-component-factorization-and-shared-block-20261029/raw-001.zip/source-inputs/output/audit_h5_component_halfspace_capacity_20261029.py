"""Independently verify component attribution, contained source rectangles and slice certificates."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';BOUND=BASE/'component-halfspace-bound';OUT=BOUND/'audit';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1])))/2 if p else F(0)
def clipped(poly,axis,above,cut):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[axis]>=cut if above else a[axis]<=cut;inb=b[axis]>=cut if above else b[axis]<=cut
        if ina:result.append(a)
        if ina!=inb:
            t=(cut-a[axis])/(b[axis]-a[axis]);result.append(tuple(a[k]+t*(b[k]-a[k]) for k in [0,1]))
    return result
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BOUND/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
inner=[[[F(v) for v in b] for b in opts] for opts in load(BOUND/'source-inner-rectangles.json')];modes=load(PRIOR/'family-modes.json')['bracket'];pieces=load(PIECES)['bracket'];source_corners=0
assert len(inner)==len(modes)==8
for mode,boxes in zip(modes,inner):
    c,s=map(F,[math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians'])]);mirror=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left'])
    for box,piece in zip(boxes,pieces):
        points=[(mirror*F(x)*c-F(y)*s+tx,mirror*F(x)*s+F(y)*c+ty) for x,y in piece]
        orientation=1 if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points,points[1:]+points[:1]))>0 else -1
        for x in [box[0],box[2]]:
            for y in [box[1],box[3]]:
                assert all(orientation*cross(a,b,(x,y))>=0 for a,b in zip(points,points[1:]+points[:1]));source_corners+=1
        expected=[min(x for x,y in points)+F('1e-6'),min(y for x,y in points)+F('1e-6'),max(x for x,y in points)-F('1e-6'),max(y for x,y in points)-F('1e-6')];assert box==expected
regions={};unary=load(PRIOR/'integer-preparation/unary-templates.json')
for r in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if r['family']!='bracket':continue
    key=(r['mode'],r['geometry'],r['region']);bits=0
    for row,lo,hi in r['grid_row_spans']:
        for column in range(lo,hi+1):bits|=1<<((row-200)*150+column)
    if key not in regions:
        poly=[tuple(map(F,v)) for v in unary[r['geometry']]['regions'][r['region']]['hull_vertices']]
        regions[key]={'required':set(r['required_empty_sites']) if 'required_empty_sites' in r else {i for i in range(15) if r['required_empty_mask']>>i&1},'points':poly,'bits':0}
    regions[key]['bits']|=bits
prior_rows=[r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json') if not r['restricted_construction_excluded']];rows=load(BOUND/'all35-halfspace-bounds.json');assert len(rows)==len(prior_rows)==35
certificates=0;assigned=0
for row,prior in zip(rows,prior_rows):
    assert row['empty_sites']==prior['empty_sites'];components=[int(v,16) for v in prior['components_hex']];empty=set(row['empty_sites']);expected=[];bounds=[{} for _ in components]
    for key,r in regions.items():
        if not r['required']<=empty:continue
        indices=[i for i,cover in enumerate(components) if (cover|r['bits'])==cover];assert len(indices)==1;ci=indices[0];expected.append([*key,ci]);assigned+=1
        limits=[min(p[0] for p in r['points']),min(p[1] for p in r['points']),max(p[0] for p in r['points']),max(p[1] for p in r['points'])]
        if key[0] not in bounds[ci]:bounds[ci][key[0]]=limits
        else:bounds[ci][key[0]]=[f(a,b) for f,a,b in zip([min,min,max,max],bounds[ci][key[0]],limits)]
    assert expected==row['region_component_assignments'] and len(row['components'])==len(components)
    capacities=[]
    for record,bits,mode_bounds in zip(row['components'],components,bounds):
        assert record['mode_position_bounds_mm']=={str(k):[str(v) for v in b] for k,b in mode_bounds.items()}
        total=bits.bit_count()*100;assert record['total_area_upper_bound_mm2']==total and record['prior_capacity']==total//40000
        cert=record['strongest_certificate']
        if cert['method']=='total_area':assert cert=={'method':'total_area','upper_area_mm2':total,'capacity':total//40000}
        else:
            assert cert['method']=='halfspace';axis=cert['axis'];above=cert['above'];cut=F(cert['threshold_mm']);assert axis in [0,1] and cut%10==0
            count=0
            for i in range(15000):
                if not bits>>i&1:continue
                y,x=divmod(i,150);low=F(10*x if axis==0 else 2000+10*y)
                if (low>=cut if above else low+10<=cut):count+=1
            available=count*100;assert cert['upper_area_mm2']==available
            values={}
            for mode,limits in mode_bounds.items():
                shift=limits[axis if above else axis+2];occupied=F(0)
                for l,b,r,t in inner[mode]:
                    poly=[(l,b),(r,b),(r,t),(l,t)];poly=[tuple(p[k]+(shift if k==axis else 0) for k in [0,1]) for p in poly]
                    occupied+=area(clipped(poly,axis,above,cut))
                values[str(mode)]=str(occupied)
            assert values==cert['per_mode_minimum_area_mm2'];least=min(map(F,values.values()));assert least>0 and str(least)==cert['minimum_bracket_area_mm2']
            assert cert['capacity']==F(available)//least<total//40000;certificates+=1
        assert record['capacity_upper_bound']==cert['capacity'];capacities.append(cert['capacity'])
    assert row['total_bracket_capacity_upper_bound']==sum(capacities) and row['required_brackets']==7 and row['restricted_construction_excluded']==(sum(capacities)<7)
assert certificates==8 and sum(r['restricted_construction_excluded'] for r in rows)==6
allowed=[r['empty_sites'] for r in rows if not r['restricted_construction_excluded']];assert len(allowed)==29
write(OUT/'allowed-empty-site-pairs.json',allowed);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BOUND/n for n in ['plan.json','checks.json','source-inner-rectangles.json','all35-halfspace-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'contained_inner_rectangle_corners_verified':source_corners,'source_region_component_assignments_verified':assigned,'halfspace_certificates_verified':certificates,'remaining_site_pairs_examined':35,'additional_restricted_pairs_excluded':6,'restricted_pairs_remaining':29,'total_restricted_pairs_excluded':76,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
