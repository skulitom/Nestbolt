"""Independent inventory, source and exact coverage readback for all fixed-nine cases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from h5_continuous_core_certificate_reader_20261028 import check_obstacles,check_certificate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-fixed9-inventory-20261029';OUT=BASE/'audit';OLD=ROOT/'output/h5-short-two-cog-exchange-20261028';BOUND=OLD/'all-angle-bound';JOINT=ROOT/'output/h5-short-joint-core-20261028';PRE=ROOT/'output/h5-fixed-cog-rows-20261028/short-exchange-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();key=lambda p:(p['part_id'],p['copy_index'])
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for file in [BASE/'plan.json',JOINT/'audit/plan.json',BOUND/'audit/plan.json']:
    for n,h in load(file)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(JOINT/'audit/checks.json')['passed'] and load(BOUND/'audit/checks.json')['passed']
job=load(JOB);parts={p['id']:p for p in job['parts']};parent=load(PRE/'parent-source12.json');parentmap={key(p):p for p in parent};allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};sourceplan=load(OLD/'plan.json');st=sourceplan['source_stock'];bounds=load(JOINT/'stock-hull-core.json')['relaxed_cog_center_bounds_um'];core=load(BOUND/'moving-core.json')['vertices_um'];fixed={tuple(r['identity']):r['rectangles_um'] for r in load(BOUND/'fixed-core-rectangles.json')}
expected={(primary,tuple(sorted(extra))) for primary in [3,4,7,8,10,11] for extra in combinations(sorted(set(parentmap)-{('bracket',primary)}),2)};variants=load(BASE/'inventory-variants.json');seen=set();linked={}
for i,v in enumerate(variants):
    primary=v['primary_bracket_to_first'];extra=tuple(map(tuple,v['extra_released_originals']));assert v['index']==i and (primary,extra) in expected and (primary,extra) not in seen;seen.add((primary,extra));removed=sorted([('bracket',primary),*extra]);assert list(map(tuple,v['removed_parent_identities']))==removed
    movers=[*extra,('cog',0),('insert',0)];assert list(map(tuple,v['moving_short_originals']))==movers;retained=set(parentmap)-set(removed);ss=retained|set(movers);fs=allids-ss;assert len(retained)==9 and len(ss)==13 and len(fs)==53 and not retained&set(movers)
    assert list(map(tuple,v['mandatory_short_identities']))==sorted(ss) and list(map(tuple,v['mandatory_first_identities']))==sorted(fs)
    assert Counter(k[0] for k in ss)=={'bracket':5,'insert':6,'cog':2} and Counter(k[0] for k in fs)=={'frame':18,'bracket':7,'insert':15,'cog':13};linked.setdefault(v['geometry_case'],[]).append(i)
assert seen==expected and len(seen)==330
result=load(BASE/'result.json');summaries=load(BASE/'case-summary.json');assert result['relaxed_center_bounds_um']==bounds;groups=set();casechecks=[];pairs=obstacle_references=unique_sums=0;obstacle_cache={};world={}
for k,p in parentmap.items():
    t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;g=Polygon([(sign*x*co-y*si+t['translation'][0],sign*x*si+y*co+t['translation'][1]) for x,y in parts[p['part_id']]['geometry'][0]['outer']]);assert g.is_valid;b=g.bounds;assert min(b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3])>sourceplan['stock_guard_mm'];world[k]=g
for s in summaries:
    name=s['geometry_case'];case=load(BASE/'cases'/f'{name}.json');removed=tuple(map(tuple,case['removed_parent_identities']));assert removed not in groups;groups.add(removed);rows=[p for p in parent if key(p) not in removed];assert rows==case['fixed9'] and len(rows)==9 and linked[name]==case['inventory_variant_indices']==s['inventory_variants']
    for a,b in combinations(rows,2):ga,gb=world[key(a)],world[key(b)];assert ga.disjoint(gb) and ga.distance(gb)>sourceplan['required_pair_gap_mm'];pairs+=1
    saved=load(BASE/'source-checks'/f'{name}.json');assert saved['valid'] and saved['originals']==9 and saved['same_sheet_pairs']==36
    rects=[r for p in rows for r in fixed[key(p)]];obs=load(BASE/'obstacles'/f'{name}.json');assert len(rects)==len(obs)==s['necessary_obstacles']
    for r,poly in zip(rects,obs):
        rk=tuple(r)
        if rk not in obstacle_cache:unique_sums+=check_obstacles([r],core,[poly]);obstacle_cache[rk]=poly
        else:assert obstacle_cache[rk]==poly
        obstacle_references+=1
    checked=check_certificate(load(BASE/'certificates'/f'{name}.json'),bounds,obs,max_nodes=50000,max_depth=30);assert checked['nodes']==s['nodes'] and checked['complete_coverage']==s['all_angle_additional_cog_excluded'];casechecks.append({'geometry_case':name,'inventory_variants':linked[name],**checked})
assert len(groups)==len(casechecks)==len(linked)==200 and pairs==7200
excluded=sum(c['complete_coverage'] for c in casechecks);witnesses=sum(c['relaxation_witnesses'] for c in casechecks);coveredvariants=sum(len(c['inventory_variants']) for c in casechecks if c['complete_coverage'])
assert excluded==result['necessary_single_cog_excluded_geometries']==144 and witnesses==result['necessary_core_witness_geometries']==56 and coveredvariants==result['covered_inventory_variants']==244 and result['unexcluded_inventory_variants']==86 and result['limited_geometries']==0
inputs=[Path(__file__),ROOT/'output/h5_continuous_core_certificate_reader_20261028.py',BASE/'plan.json',JOINT/'audit/plan.json',BOUND/'audit/plan.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'case-checks.json',casechecks)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all330_inventory_variants_account_for_all66_originals':True,'distinct_source_fixed9_geometries':200,'independent_source_pair_checks':pairs,'unique_exact_no_fit_obstacles':len(obstacle_cache),'unique_exact_vertex_sums':unique_sums,'exact_obstacle_references_verified':obstacle_references,'exact_certificate_nodes':sum(c['nodes'] for c in casechecks),'covered_leaves':sum(c['covered_leaves'] for c in casechecks),'exact_corner_plane_checks':sum(c['corner_plane_checks'] for c in casechecks),'source_and_stock_core_previous_full_audit_hashes_verified':True,'all_angle_fixed9_single_cog_excluded_geometries':144,'excluded_inventory_variants':244,'unexcluded_geometries':56,'unexcluded_inventory_variants':86,'all56_relaxation_witnesses_outside_every_necessary_obstacle':True,'full_allocation_or_original_job_excluded':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
