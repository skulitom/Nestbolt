"""Build the distinct short12 allocation by moving exactly insert0 to first54."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-source-projection-short-core-20261029';PRE=OLD/'next-short12-preflight';BASE=ROOT/'output/h5-source-projection-short12-20261029';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRE/'checks.json')['passed'] and load(OLD/'model-audit/checks.json')['passed'];BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
inputs=[Path(__file__),PRE/'plan.json',PRE/'checks.json',PRE/'inventory.json',OLD/'model-v3/plan.json',OLD/'model-audit/plan.json',OLD/'model-audit/checks.json',OLD/'source-necessity-audit/plan.json',OLD/'frontier-audit/plan.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'Short12=5 brackets/5 inserts/2 cogs; first54=18 frames/7 brackets/16 inserts/13 cogs. Move only insert0 to first. Keep all other original short owners mandatory and movable, all legal modes and arbitrary cog phases. No whole-job claim without all66 source/native validation.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'source_validation_reserve_seconds':3})
model=cp_model.CpModel();assert model.proto.parse_text_format((OLD/'model-v3/model.pbtxt').read_text()) and model.validate()=='';assert model.export_to_file(str(OUT/'parent-copy.pb')) and digest(OUT/'parent-copy.pb')==digest(OLD/'model-v3/model.pb')
mp=load(OLD/'model-v3/mapping.json');inventory=load(PRE/'inventory.json');item=next(i for i in mp['items'] if i['identity']==['insert',0]);assert item['index']==7 and item['presence']==146 and item['mandatory']==112
ct=model.proto.constraints[item['mandatory']];assert list(ct.linear.vars)==[146] and list(ct.linear.coeffs)==[1] and list(ct.linear.domain)==[1,1] and not ct.enforcement_literal
ct.linear.domain.clear();ct.linear.domain.extend([0,0]);assert model.validate()==''
oldfirst=mp.pop('mandatory_first53_identities');assert oldfirst+[['insert',0]]==inventory['mandatory_first54_identities'];mp['mandatory_first54_identities']=inventory['mandatory_first54_identities'];mp['short12_identities']=inventory['short12_identities'];mp['inactive_short_identity']=['insert',0];mp['inactive_short_owner']=7;mp['control_disabled_mandatory_constraints']=[110]
pos=load(OLD/'model-v3/positive-control-assignment.json');neg=load(OLD/'model-v3/negative-assignment.json');assert pos[146]==0 and neg[146]==1;neg[146]=0
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mp);write(OUT/'positive-control-assignment.json',pos);write(OUT/'negative-assignment.json',neg)
inputs=[Path(__file__),BASE/'plan.json',PRE/'inventory.json']+[OLD/'model-v3'/n for n in ['plan.json','model.pb','model.pbtxt','mapping.json','positive-control-assignment.json','negative-assignment.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'changed_constraint':112,'changed_presence_variable':146,'short_required_originals':12,'first_required_originals':54,'inactive_bookkeeping_identity':['insert',0],'unchanged_hints':len(model.proto.solution_hint.vars),'validation':model.validate(),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'),flush=True)
