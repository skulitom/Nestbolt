"""Read a core witness, then attempt only the frozen finite original-cog phase lift."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
from hashlib import sha256
import json,math,sys,time,shutil
from shapely.geometry import Polygon,box
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';SEARCH=BASE/'search';OUT=SEARCH/'source-response';GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');started=float(sys.argv[1]);local_start=time.perf_counter();job=load(JOB);parts={p['id']:p for p in job['parts']};mp=load(BASE/'model/mapping.json');values=load(SEARCH/'assignment.json');inventory=load(BASE/'preflight/inventory.json');modes=load(PRE/'modes.json');mode_map={(m['family'],m['mode']):m for m in modes};coredata=load(GEOM/'cog-core.json');core=coredata['vertices_um'];center=[float(F(v)) for v in coredata['source_center_mm']];sp=load(ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json');stock=sp['source_stock'];required=sp['required_pair_gap_mm'];guard=sp['stock_guard_mm'];orth=[];cogs=[];cores=[];decoded=[]
for item in mp['items']:
    if item['index'] in mp['inactive_short_owners']:
        assert item['family']=='insert' and values[item['presence']]==0 and item['index'] in mp['inactive_short_owners'] and item['identity'] in mp['inactive_short_identities'] and item['identity'] in inventory['mandatory_first55_identities'] and item['identity'] not in inventory['short11_identities'];continue
    assert values[item['presence']]==1;family,copy=item['identity'];xy=[100*values[item[k]] for k in ['x','y']]
    if family=='cog':
        cogs.append({'identity':item['identity'],'center_um':xy});cores.append((family,[Polygon([(x+xy[0],y+xy[1]) for x,y in core])]))
    else:
        m=mode_map[family,values[item['mode']]];row={'part_id':family,'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]/1000+m['source_translation_offset'][k] for k in [0,1]]}};orth.append(row);rr=[[r[0]+xy[0],r[1]+xy[1],r[2]+xy[0],r[3]+xy[1]] for r in m['rectangles_um']];cores.append((family,[box(*r) for r in rr]))
    decoded.append({'identity':item['identity'],'family':family,'anchor_um':xy,'mode':None if family=='cog' else values[item['mode']]})
assert len(orth)==9 and len(cogs)==2 and len(decoded)==11 and {tuple(r['identity']) for r in decoded}==set(map(tuple,inventory['short11_identities']))
allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};shortids=set(map(tuple,inventory['short11_identities']));firstids=set(map(tuple,inventory['mandatory_first55_identities']));assert len(shortids)==11 and len(firstids)==55 and not shortids&firstids and shortids|firstids==allids and mp['short11_identities']==inventory['short11_identities'] and mp['mandatory_first55_identities']==inventory['mandatory_first55_identities']
piece_pairs=0
for (fa,aa),(fb,bb) in combinations(cores,2):
    for a in aa:
        for b in bb:
            if 'cog' in [fa,fb]:assert a.disjoint(b)
            else:assert a.intersection(b).area==0
            piece_pairs+=1
write(OUT/'decoded-core11.json',decoded);write(OUT/'core-checks.json',{'passed':True,'originals':11,'all11_presences_and_original_identities_verified':True,'independent_core_piece_pair_checks':piece_pairs,'source_original_geometry_not_yet_verified':True})
expected_orth=[(p['part_id'],p['copy_index']) for p in orth];orthcheck=audit(job,orth,{'sheet-1':stock},required,guard,expected_orth);write(OUT/'orthogonal-source9.json',orth);write(OUT/'orthogonal-source9-checks.json',orthcheck)
angles=[7.0]+[k/2 for k in range(36) if k!=14];assert len(angles)==36
def posed(cg,degrees):
    angle=math.radians(degrees);co,si=math.cos(angle),math.sin(angle);xy=[v/1000 for v in cg['center_um']];return {'part_id':'cog','copy_index':cg['identity'][1],'sheet_id':'sheet-1','transform':{'rotation_radians':angle,'mirrored':False,'translation':[xy[0]-co*center[0]+si*center[1],xy[1]-si*center[0]-co*center[1]]}}
def filled(row):
    t=row['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;return Polygon([(sign*x*co-y*si+t['translation'][0],sign*x*si+y*co+t['translation'][1]) for x,y in parts[row['part_id']]['geometry'][0]['outer']])
baseline=orth+[posed(cg,7) for cg in cogs];baselinecheck=audit(job,baseline,{'sheet-1':stock},required,guard,list(map(tuple,inventory['short11_identities'])));write(OUT/'baseline-source11.json',baseline);write(OUT/'baseline-source11-checks.json',baselinecheck);valid=baselinecheck['valid'];selected=baseline if valid else None;reason='baseline source11 valid' if valid else None;phasechecks=[];pairchecks=[];time_limited=False
if not valid and not orthcheck['valid']:reason='frozen orthogonal source anchors already fail; cog angle changes cannot repair them'
elif not valid:
    worlds=[filled(r) for r in orth];accepted=[]
    for cg in cogs:
        choices=[]
        for degrees in angles:
            if time.perf_counter()-started>=60:time_limited=True;break
            row=posed(cg,degrees);g=filled(row);b=g.bounds;extra=min(b[0]-stock[0],b[1]-stock[1],stock[2]-b[2],stock[3]-b[3]);gaps=[g.distance(p) for p in worlds];good=g.is_valid and extra>guard and all(g.disjoint(p) for p in worlds) and min(gaps)>required;phasechecks.append({'identity':cg['identity'],'degrees':degrees,'source_stock_extra_mm':extra,'minimum_gap_to_orthogonals_mm':min(gaps),'passed':good})
            if good:choices.append((degrees,row,g))
        accepted.append(choices)
        if time_limited:break
    if not time_limited:
        for da,ra,a in accepted[0]:
            for db,rb,b in accepted[1]:
                if time.perf_counter()-started>=60:time_limited=True;break
                gap=a.distance(b);good=a.disjoint(b) and gap>required;pairchecks.append({'degrees':[da,db],'gap_mm':gap,'passed':good})
                if good:
                    candidate=orth+[ra,rb];check=audit(job,candidate,{'sheet-1':stock},required,guard,list(map(tuple,inventory['short11_identities'])));write(OUT/'selected-source11-checks.json',check)
                    if check['valid']:selected=candidate;valid=True;reason='finite cog phase lift source11 valid';break
                    raise AssertionError('Independent full source readback contradicted the phase filters')
            if valid or time_limited:break
    if not valid:reason='source phase validation time limit' if time_limited else 'declared finite cog phases cannot realize the frozen core anchors'
if valid:write(OUT/'source11.json',selected)
write(OUT/'phase-checks.json',phasechecks);write(OUT/'cog-pair-checks.json',pairchecks)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',BASE/'model/mapping.json',BASE/'model-audit/plan.json',SEARCH/'opened.json',SEARCH/'assignment.json',PRE/'audit/plan.json',BASE/'preflight/inventory.json',PRE/'modes.json',GEOM/'cog-core.json',JOB];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'cog_phase_order_degrees':angles,'maximum_phase_pairs':1296,'no_anchor_optimization_or_solver_retry':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-local_start,'closed':True,'necessary_core11_geometry_valid':True,'original_orthogonal_source9_valid':orthcheck['valid'],'original_orthogonal_source_pair_failures':orthcheck['pair_failures'],'original_orthogonal_source_stock_failures':orthcheck['stock_failures'],'baseline_source11_valid':baselinecheck['valid'],'baseline_source11_pair_failures':baselinecheck['pair_failures'],'baseline_source11_stock_failures':baselinecheck['stock_failures'],'finite_cog_phase_checks':len(phasechecks),'finite_cog_pair_checks':len(pairchecks),'source_valid11':valid,'reason':reason,'source_validation_time_limited':time_limited,'first55_layout_created':False,'source_valid66':False,'original_or_all_angle_infeasibility_claimed':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
