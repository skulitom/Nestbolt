"""Build the new necessary all-movable short13 model without calling a solver."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
from h5_coarse_short_core_values_20261029 import control_values
ROOT=Path(__file__).resolve().parents[1];GEOM=ROOT/'output/h5-short-fixed9-triples-20261029/global-short-preflight';PRE=ROOT/'output/h5-global-short-core-20261029/coarse-preflight';BASE=ROOT/'output/h5-coarse-short-core-20261029';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRE/'audit/checks.json')['passed'] and not BASE.exists();BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
for folder in [PRE,PRE/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
inputs=[Path(__file__),ROOT/'output/h5_coarse_short_core_values_20261029.py',PRE/'plan.json',PRE/'audit/plan.json']+[p for p in PRE.glob('*.json')]+[PRE/'audit/checks.json',GEOM/'cog-rectangle-facets.json',GEOM/'cog-pair-facets.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'All13 short-sheet anchors and every legal orthogonal mode remain independently movable and mandatory. Use table-selected strict source-core rectangles, optional intervals with forced-present original owners, one global NoOverlap2D,32 exact symbolic cog/rectangle disjunctions and one exact cog/cog disjunction. All anchor variables use100um grid steps while local/world rectangles and facet support constants remain exact micrometres. Ten within-family adjacent x orders break identical-copy permutation symmetry by the audited source relabeling proof. No fixed poses, extra clearances or objective. The source gap exceeds the bounded relative rounding displacement; this preserves source feasibility, not every arbitrary1um core witness. Independent exhaustive protobuf and source mapping audits precede its sole call.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'num_search_workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'retry_permitted':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
inventory=load(PRE/'inventory.json');modes=load(PRE/'modes.json');byfamily={f:[m for m in modes if m['family']==f] for f in ['bracket','insert']};rectfacets=load(GEOM/'cog-rectangle-facets.json');cgfacets=load(GEOM/'cog-pair-facets.json');model=cp_model.CpModel();items=[];allx=[];ally=[]
def var(name,lo,hi):return model.new_int_var(lo,hi,name)
def linear(expr,lower=None,upper=None,on=()):
    ct=model.add(expr==lower) if lower is not None and upper==lower else model.add(expr>=lower) if lower is not None and upper is None else model.add(expr<=upper) if lower is None else model.add_linear_constraint(expr,lower,upper)
    if on:ct.only_enforce_if(on)
    return ct.index
for i,identity in enumerate(inventory['short13_identities']):
    family=identity[0];stock=inventory['cog_center_stock_bounds_grid_units'] if family=='cog' else None;fm=byfamily.get(family,[]);bounds=[stock] if stock else [m['anchor_stock_bounds_grid_units'] for m in fm];p=model.new_bool_var(f'present_{i}');x=var(f'x_{i}',min(b[0] for b in bounds),max(b[2] for b in bounds));y=var(f'y_{i}',min(b[1] for b in bounds),max(b[3] for b in bounds));item={'index':i,'identity':identity,'family':family,'presence':p.index,'x':x.index,'y':y.index,'mandatory':linear(p,1,1),'pieces':[]}
    if family=='cog':item['stock_bounds_grid_units']=stock
    else:
        mi=var(f'mode_{i}',0,len(fm)-1);item['mode']=mi.index;stockvars=[var(f'stock_{i}_{k}',min(b[k] for b in bounds),max(b[k] for b in bounds)) for k in range(4)];item['stock_variables']=[v.index for v in stockvars]
        item['stock_constraints']=[linear(x-stockvars[0],0,on=[p]),linear(y-stockvars[1],0,on=[p]),linear(x-stockvars[2],upper=0,on=[p]),linear(y-stockvars[3],upper=0,on=[p])]
        tablevars=[mi,*stockvars];rows=[[m['mode'],*m['anchor_stock_bounds_grid_units']] for m in fm]
        for k in range(2 if family=='bracket' else 1):
            rr=[m['rectangles_um'][k] for m in fm];local=[var(f'local_{i}_{k}_{axis}',min(r[axis] for r in rr),max(r[axis] for r in rr)) for axis in range(4)];tablevars.extend(local)
            for row,r in zip(rows,rr):row.extend(r)
            starts=[x,y,x,y];world=[];links=[]
            for axis in range(4):
                ai=0 if axis%2==0 else 1;low=100*min(b[ai] for b in bounds)+min(r[axis] for r in rr);high=100*max(b[ai+2] for b in bounds)+max(r[axis] for r in rr);v=var(f'world_{i}_{k}_{axis}',low,high);world.append(v);links.append(linear(v-100*starts[axis]-local[axis],0,0))
            width=var(f'width_{i}_{k}',min(r[2]-r[0] for r in rr),max(r[2]-r[0] for r in rr));height=var(f'height_{i}_{k}',min(r[3]-r[1] for r in rr),max(r[3]-r[1] for r in rr));links.extend([linear(width-local[2]+local[0],0,0),linear(height-local[3]+local[1],0,0)]);world.extend([width,height]);ix=model.new_optional_interval_var(world[0],width,world[2],p,f'core_x_{i}_{k}');iy=model.new_optional_interval_var(world[1],height,world[3],p,f'core_y_{i}_{k}');allx.append(ix);ally.append(iy);item['pieces'].append({'component':k,'local_variables':[v.index for v in local],'world_variables':[v.index for v in world],'link_constraints':links,'x_interval':ix.index,'y_interval':iy.index})
        item['table_variables']=[v.index for v in tablevars];item['mode_table']=model.add_allowed_assignments(tablevars,rows).index
    items.append(item)
no_overlap=model.add_no_overlap_2d(allx,ally).index;pairs=[]
def add_pair(kind,left,right,component,facets):
    pi=model.get_bool_var_from_proto_index(left['presence']);pj=model.get_bool_var_from_proto_index(right['presence']);row={'kind':kind,'left':left['index'],'right':right['index'],'component':component,'presences':[pi.index,pj.index],'facets':[]};selectors=[]
    for k,(coeffs,lower) in enumerate(facets):
        sel=model.new_bool_var(f'sep_{len(pairs)}_{k}');selectors.append(sel);expr=sum(c*model.get_int_var_from_proto_index(v) for v,c in coeffs.items());ix=linear(expr,lower,on=[pi,pj,sel]);row['facets'].append({'selector':sel.index,'constraint':ix,'coefficients':{str(v):c for v,c in coeffs.items()},'lower_bound':lower})
    ct=model.add_bool_or(selectors);ct.only_enforce_if([pi,pj]);row['choice']=ct.index;pairs.append(row)
cogs=[i for i in items if i['family']=='cog'];orth=[i for i in items if i['family']!='cog']
for cg in cogs:
    for owner in orth:
        for piece in owner['pieces']:
            rr=piece['world_variables'];ff=[]
            for f in rectfacets:
                nx,ny=f['normal'];coeffs={}
                for ix,c in [(cg['x'],100*nx),(cg['y'],100*ny),(rr[2] if nx>=0 else rr[0],-nx),(rr[3] if ny>=0 else rr[1],-ny)]:
                    if c:coeffs[ix]=coeffs.get(ix,0)+c
                ff.append((coeffs,f['negative_cog_support']+1))
            add_pair('cog-rectangle',cg,owner,piece['component'],ff)
a,b=cogs;ff=[]
for f in cgfacets:
    nx,ny=f['normal'];coeffs={}
    for ix,c in [(b['x'],100*nx),(a['x'],-100*nx),(b['y'],100*ny),(a['y'],-100*ny)]:
        if c:coeffs[ix]=coeffs.get(ix,0)+c
    ff.append((coeffs,f['support']+1))
add_pair('cog-cog',a,b,None,ff)
orders=[];byid={tuple(i['identity']):i for i in items}
for o in load(PRE/'orders.json'):
    a,b=byid[tuple(o['left_identity'])],byid[tuple(o['right_identity'])];x=model.get_int_var_from_proto_index(a['x']);y=model.get_int_var_from_proto_index(b['x']);on=[model.get_bool_var_from_proto_index(i['presence']) for i in [a,b]];orders.append({**o,'left':a['index'],'right':b['index'],'constraint':linear(x-y,upper=0,on=on)})
mapping={'anchor_unit_um':100,'copy_orders':orders,'items':items,'no_overlap_2d':no_overlap,'facet_pairs':pairs,'mandatory_first53_identities':inventory['mandatory_first53_identities']};positive=load(PRE/'positive-core11.json');negative=load(PRE/'negative-core13.json');values=control_values(len(model.proto.variables),mapping,modes,positive);badvalues=control_values(len(model.proto.variables),mapping,modes,negative);known={tuple(r['identity']) for r in positive};hints={};disabled=[]
for item in items:
    hints[item['presence']]=1
    if tuple(item['identity']) not in known:disabled.append(item['mandatory']);continue
    own=[item['x'],item['y']]
    if item['family']!='cog':own += [item['mode'],*item['stock_variables']]+[v for p in item['pieces'] for v in p['local_variables']+p['world_variables']]
    for ix in own:hints[ix]=values[ix]
for pair in pairs:
    if all(tuple(items[i]['identity']) in known for i in [pair['left'],pair['right']]):
        for f in pair['facets']:hints[f['selector']]=values[f['selector']]
for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
mapping['control_disabled_mandatory_constraints']=disabled;assert len(disabled)==2 and len(items)==13 and len(allx)==16 and len(pairs)==33 and model.validate()==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mapping);write(OUT/'positive-control-assignment.json',values);write(OUT/'negative-assignment.json',badvalues);write(OUT/'partial-hints.json',{str(k):v for k,v in hints.items()});write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',*inputs]},'solver_calls':0})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'anchor_unit_um':100,'within_family_copy_orders':len(orders),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_originals':13,'independently_movable_anchor_coordinates':26,'legal_bracket_modes':8,'legal_insert_modes':4,'mode_tables':11,'mandatory_orthogonal_pieces':16,'global_no_overlap_constraints':1,'cog_rectangle_pairs':32,'cog_pair_constraints':1,'facet_selectors':sum(len(p['facets']) for p in pairs),'hints':len(hints),'positive_control_originals':11,'positive_missing_mandatory_constraints':len(disabled),'negative_originals':13,'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'),flush=True)
