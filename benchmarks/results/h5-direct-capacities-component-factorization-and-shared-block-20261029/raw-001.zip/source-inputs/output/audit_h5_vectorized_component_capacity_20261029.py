"""Verify exact equivalence of regenerated source components and every exclusion witness."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';OUT=BASE/'audit';JOINT=ROOT/'output/h5-first55-joint-component-capacity-20261029';OLD=ROOT/'output/h5-first55-separated-component-capacity-20261029';SUBSET=OLD/'subset-halfspaces'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json',JOINT/'audit/plan.json',OLD/'audit/plan.json',SUBSET/'audit/plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
for folder in [JOINT,OLD,SUBSET]:assert load(folder/'audit/checks.json')['passed']
assert digest(BASE/'source-inner-rectangles.json')==digest(JOINT/'source-inner-rectangles.json')
rows=load(BASE/'all29-vectorized-bounds.json');old=load(OLD/'all29-separated-bounds.json');sub=load(SUBSET/'all29-subset-halfspaces.json');assert len(rows)==len(old)==len(sub)==29
aliases=regions=certificates=initial=remaining=screened=0
for r,a,b in zip(rows,old,sub):
    assert r['empty_sites']==a['empty_sites']==b['empty_sites'] and r['groups']==a['groups'] and r['region_component_assignments']==a['region_component_assignments']
    assert r['initial_distributions']==a['initial_distributions'] and r['after_subset_area_distributions']==a['remaining_distributions']==b['initial_distributions'] and r['remaining_distributions']==b['remaining_distributions']
    assert r['subset_area_certificates']==[c for c in a['certificates'] if c['kind']=='subset_area'] and len(a['certificates'])==len(r['subset_area_certificates'])
    assert r['subset_halfspace_certificates']==b['certificates']
    assert r['mixed_subsets_screened']==b['mixed_subsets_completed'] and r['halfspaces_screened']==b['halfspaces_examined']
    assert r['restricted_construction_excluded']==b['restricted_construction_excluded']==False
    attribution={}
    for family,mode,gid,region,component in r['region_component_assignments']:attribution.setdefault((family,gid,region),set()).add(component);aliases+=1
    assert all(len(values)==1 for values in attribution.values()),r['empty_sites'];regions+=len(attribution)
    certificates+=len(r['subset_area_certificates'])+len(r['subset_halfspace_certificates']);initial+=len(r['initial_distributions']);remaining+=len(r['remaining_distributions']);screened+=r['halfspaces_screened']
assert certificates==39 and initial==329 and remaining==132 and screened==214200
check=load(BASE/'checks.json');assert check['halfspaces_recomputed_exactly']==7 and check['subset_area_certificates']==33 and check['subset_halfspace_certificates']==6 and check['cap_overrun_seconds']==0
write(OUT/'source-bindings.json',bindings);write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in rows])
inputs=[Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'source-inner-rectangles.json',BASE/'all29-vectorized-bounds.json',JOINT/'audit/plan.json',JOINT/'audit/checks.json',OLD/'audit/plan.json',OLD/'audit/checks.json',SUBSET/'audit/plan.json',SUBSET/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_inner_rectangle_bytes_identical':True,'all_family_components_and_source_attributions_identical':True,'source_mode_attributions_verified':aliases,'unique_family_geometry_region_attributions':regions,'all_source_mode_aliases_agree_on_component':True,'exact_certificates_identical_to_independently_verified_witnesses':certificates,'initial_count_distributions':initial,'remaining_count_distributions':remaining,'all_retained_count_sets_identical':True,'halfspaces_screened':screened,'generic_preparation_seconds':check['seconds'],'floating_estimates_authorize_no_exclusion':True,'restricted_pairs_remaining':29,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
