"""Independently reconstruct family components and every recorded count-exclusion certificate."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from collections import deque
import json,itertools,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-separated-component-capacity-20261029';OUT=BASE/'audit';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';AXIS=ROOT/'output/h5-first55-local-grid-regions-20261029/component-halfspace-bound';JOINT=ROOT/'output/h5-first55-joint-component-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if poly else F(0)
def clipped(poly,axis,above,cut):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[axis]>=cut if above else a[axis]<=cut;inb=b[axis]>=cut if above else b[axis]<=cut
        if ina:out.append(a)
        if ina!=inb:
            t=(cut-a[axis])/(b[axis]-a[axis]);out.append(tuple(a[k]+t*(b[k]-a[k]) for k in [0,1]))
    return out
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(JOINT/'audit/checks.json')['passed'] and load(JOINT/'audit/checks.json')['source_inner_rectangle_corners_verified']==80
families=['bracket','insert'];inner={f:[[[F(x) for x in b] for b in mode] for mode in opts] for f,opts in load(JOINT/'source-inner-rectangles.json').items()};regions={};unary=load(PRIOR/'integer-preparation/unary-templates.json')
for r in load(PRIOR/'accessible-area-bound/swept-covers.json'):
    if r['family'] not in families:continue
    key=(r['family'],r['mode'],r['geometry'],r['region']);cells={(y-200)*150+x for y,lo,hi in r['grid_row_spans'] for x in range(lo,hi+1)}
    if key not in regions:regions[key]={'required':{i for i in range(15) if r['required_empty_mask']>>i&1},'cells':set(),'poly':[tuple(map(F,v)) for v in unary[r['geometry']]['regions'][r['region']]['hull_vertices']]}
    regions[key]['cells'].update(cells)
axis_rows={tuple(r['empty_sites']):r for r in load(AXIS/'all35-halfspace-bounds.json')};allowed=load(AXIS/'audit/allowed-empty-site-pairs.json');rows=load(BASE/'all29-separated-bounds.json');assert [r['empty_sites'] for r in rows]==allowed
assigned=components_verified=certs=excluded=initial_total=remaining_total=0
for row in rows:
    active={k:v for k,v in regions.items() if v['required']<=set(row['empty_sites'])};groups=[]
    for family in families:
        remaining=set().union(*(v['cells'] for k,v in active.items() if k[0]==family));fi=0
        while remaining:
            first=min(remaining);remaining.remove(first);cells={first};q=deque([first])
            while q:
                y,x=divmod(q.popleft(),150)
                for yy in range(max(0,y-1),min(100,y+2)):
                    for xx in range(max(0,x-1),min(150,x+2)):
                        n=yy*150+xx
                        if n in remaining:remaining.remove(n);cells.add(n);q.append(n)
            groups.append({'family':family,'family_component':fi,'cells':cells,'ranges':{}});fi+=1
    expected=[];components_verified+=len(groups)
    for k,v in active.items():
        dest=[i for i,g in enumerate(groups) if g['family']==k[0] and v['cells']<=g['cells']];assert len(dest)==1;gi=dest[0];expected.append([*k,gi]);assigned+=1
        limits=[min(x for x,y in v['poly']),min(y for x,y in v['poly']),max(x for x,y in v['poly']),max(y for x,y in v['poly'])];old=groups[gi]['ranges'].get(k[1]);groups[gi]['ranges'][k[1]]=limits if old is None else [fun(a,b) for fun,a,b in zip([min,min,max,max],old,limits)]
    assert expected==row['region_component_assignments'] and len(groups)==len(row['groups'])
    for g,saved in zip(groups,row['groups']):
        f=g['family'];g['lower']=min(sum((b[2]-b[0])*(b[3]-b[1]) for b in inner[f][mode]) for mode in g['ranges']);g['cap']=min(7 if f=='bracket' else 6,int(F(len(g['cells'])*100)//g['lower']))
        if f=='bracket':g['cap']=min(g['cap'],axis_rows[tuple(row['empty_sites'])]['components'][g['family_component']]['capacity_upper_bound'])
        assert saved=={'family':f,'family_component':g['family_component'],'support_hex':hex(sum(1<<i for i in g['cells'])),'area_upper_mm2':len(g['cells'])*100,'source_area_lower_mm2':str(g['lower']),'capacity':g['cap'],'mode_position_bounds_mm':{str(m):[str(v) for v in b] for m,b in g['ranges'].items()}}
    possible=set()
    for counts in itertools.product(*(range(g['cap']+1) for g in groups)):
        if sum(n for n,g in zip(counts,groups) if g['family']=='bracket')==7 and sum(n for n,g in zip(counts,groups) if g['family']=='insert')==6:possible.add(counts)
    assert row['initial_distributions']==[list(v) for v in sorted(possible)];initial_total+=len(possible)
    for cert in row['certificates']:
        if cert['kind']=='subset_area':
            selected=cert['groups'];assert selected==sorted(set(selected)) and selected and all(0<=i<len(groups) for i in selected)
            support=set().union(*(groups[i]['cells'] for i in selected));available=len(support)*100;coefficients=[g['lower'] if i in selected else F(0) for i,g in enumerate(groups)]
        else:
            assert cert['kind']=='global_halfspace';axis=cert['axis'];above=cert['above'];cut=F(cert['threshold_mm']);assert axis in [0,1] and cut%10==0
            support=set().union(*(g['cells'] for g in groups));available=0
            for cell in support:
                y,x=divmod(cell,150);lo=F(10*x if axis==0 else 2000+10*y)
                if lo>=cut if above else lo+10<=cut:available+=100
            vals=[]
            for g in groups:
                choices={}
                for m,bounds in g['ranges'].items():
                    shift=bounds[axis if above else axis+2];v=F(0)
                    for l,b,r,t in inner[g['family']][m]:
                        poly=[(l,b),(r,b),(r,t),(l,t)];poly=[tuple(p[k]+(shift if k==axis else 0) for k in [0,1]) for p in poly];v+=area(clipped(poly,axis,above,cut))
                    choices[str(m)]=str(v)
                vals.append(choices)
            assert vals==cert['per_group_mode_minimum_area_mm2'];coefficients=[min(map(F,v.values())) for v in vals]
        assert cert['upper_area_mm2']==available and cert['coefficients_mm2']==[str(v) for v in coefficients]
        removed={v for v in possible if sum(n*c for n,c in zip(v,coefficients))>available};assert removed and cert['distributions_removed']==[list(v) for v in sorted(removed)];possible-=removed;excluded+=len(removed);certs+=1
    assert row['remaining_distributions']==[list(v) for v in sorted(possible)] and row['restricted_construction_excluded']==(not possible)
    assert row['scan_complete'] and row['subset_areas_examined']==(1<<len(groups))-1 and row['halfspaces_examined']==504
    remaining_total+=len(possible)
assert initial_total==329 and remaining_total==139 and excluded==190 and certs==33 and all(not r['restricted_construction_excluded'] for r in rows)
write(OUT/'source-bindings.json',bindings);write(OUT/'allowed-empty-site-pairs.json',allowed)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','all29-separated-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'family_components_verified':components_verified,'source_region_component_assignments_verified':assigned,'initial_distributions_independently_enumerated':initial_total,'necessary_area_certificates_verified':certs,'count_distributions_excluded':excluded,'remaining_count_distributions':remaining_total,'all_recorded_exclusions_independently_verified':True,'unrecorded_halfspace_values_independently_recomputed':False,'new_restricted_site_exclusions':0,'restricted_pairs_remaining':29,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
