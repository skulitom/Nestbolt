"""Project every fixed oblique row through stock domains and verify any negative cycle exactly."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-source-projection-short11-20261029';BASE=ROOT/'output/h5-short11-cycle-guided-axis-choices-20261029';PRE=SOURCE/'source-translation-preflight';OUT=BASE/'oblique-cycle-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed'];mp=load(BASE/'model/mapping.json');removed=set(mp['removed_parent_rows']);retained={old:new for new,old in enumerate(mp['retained_parent_rows'])};planes=load(PRE/'planes.json');bounds=load(PRE/'variable-bounds.json');model=np.load(BASE/'model/model.npz');world=load(PRE/'world-pieces.json');edges=[]
def add(a,b,w,source):edges.append({'from':a,'to':b,'weight_mm':str(w),'source':source})
for i,(lo,hi) in enumerate(bounds[:22]):add(22,i,F(hi),{'kind':'stock_upper','variable':i});add(i,22,-F(lo),{'kind':'stock_lower','variable':i})
for index,p in enumerate(planes):
    if index in removed:continue
    a,b=p['owners'];n=list(map(F,p['normal']));rhs=F(p['upper_delta_difference_mm']);actual=np.zeros(183);actual[2*a:2*a+2]=p['normal'];actual[2*b:2*b+2]=-np.asarray(p['normal']);assert np.array_equal(model['A'][retained[index]],actual) and model['upper'][retained[index]]==p['upper_delta_difference_mm'] and np.isneginf(model['lower'][retained[index]])
    for axis in [0,1]:
        if abs(n[axis])<F(1,10**8):continue
        other=1-axis;ends=[F(bounds[2*a+other][0])-F(bounds[2*b+other][1]),F(bounds[2*a+other][1])-F(bounds[2*b+other][0])];minimum_other=min(n[other]*v for v in ends);w=(rhs-minimum_other)/abs(n[axis]);sign=1 if n[axis]>0 else -1;u,v=(2*b+axis,2*a+axis) if sign==1 else (2*a+axis,2*b+axis);add(u,v,w,{'kind':'stock_projected_pair_axis','plane':index,'axis':axis,'sign':sign,'minimum_other_axis_term_mm':str(minimum_other),'divisor':str(abs(n[axis]))})
weights=[F(e['weight_mm']) for e in edges];floats=list(map(float,weights));dist=[0.]*23;pred=[None]*23;changed=None
for iteration in range(23):
    changed=None
    for k,e in enumerate(edges):
        value=dist[e['from']]+floats[k]
        if dist[e['to']]>value+1e-10:dist[e['to']]=value;pred[e['to']]=k;changed=e['to']
    if changed is None:break
cycle=[];total=F(0);details=[]
if changed is not None:
    v=changed
    for _ in range(23):assert pred[v] is not None;v=edges[pred[v]]['from']
    first=v
    while True:
        k=pred[v];cycle.append(k);v=edges[k]['from']
        if v==first:break
        assert len(cycle)<=23
    cycle.reverse();net=[0]*23
    for k in cycle:
        e=edges[k];net[e['from']]-=1;net[e['to']]+=1;total+=weights[k];details.append({'edge':k,**e,'from_identity':'stock-origin' if e['from']==22 else [world[e['from']//2]['identity'],'xy'[e['from']%2]],'to_identity':'stock-origin' if e['to']==22 else [world[e['to']//2]['identity'],'xy'[e['to']%2]]})
    assert total<0 and not any(net) and all(edges[cycle[i]]['to']==edges[cycle[(i+1)%len(cycle)]]['from'] for i in range(len(cycle)))
write(OUT/'projected-edges.json',edges);write(OUT/'certificate.json',{'cycle':details,'negative_sum_mm':str(total) if cycle else None,'negative_sum_mm_approx':float(total) if cycle else None,'all_left_coefficients_cancel':True if cycle else None,'derivation':'For each fixed n_x*(dx_a-dx_b)+n_y*(dy_a-dy_b)<=rhs, bound the other-axis term below over exact stock domains, then divide by the absolute target coefficient. This gives a necessary difference inequality with exact rational coefficients. A negative cycle is an exact contradiction of retained input rows and stock bounds, independent of solver coefficient dropping.','scope':'Restricted fixed-orientation branch model only. Different axis choices or source orientations and the allocation remain open.'})
inputs=[Path(__file__),BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',BASE/'model-audit/plan.json',BASE/'model/model.npz',BASE/'model/mapping.json',PRE/'planes.json',PRE/'variable-bounds.json',PRE/'world-pieces.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'fixed_piece_rows_verified':len(planes)-len(removed),'projected_difference_edges':len(edges),'negative_cycle_found':bool(cycle),'cycle_edges':len(cycle),'negative_sum_mm_approx':float(total) if cycle else None,'exact_restricted_model_contradiction_verified':bool(cycle),'independent_of_highs_tiny_coefficient_dropping':bool(cycle),'allocation_excluded':False,'remaining_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
