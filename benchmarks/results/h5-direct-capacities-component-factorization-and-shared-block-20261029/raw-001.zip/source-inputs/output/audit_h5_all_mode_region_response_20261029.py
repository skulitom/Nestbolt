"""Read the closed variable-orientation MIP response and preserve its solve-slice overrun."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, re, shutil, time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short11-all-mode-region-model-20261029'
SEARCH = BASE / 'search'
OUT = BASE / 'response-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
queue = [BASE / 'plan.json', BASE / 'audit/plan.json', SEARCH / 'opened.json']
seen, bindings = set(), {}
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    for name, expected in load(path).get('inputs', {}).items():
        source = ROOT / name
        assert source.is_relative_to(ROOT) and not {'.claude', '.cache'} & set(source.parts)
        assert digest(source) == expected, name
        bindings[name] = expected
        if source.name in ['plan.json', 'opened.json']:
            queue.append(source)
opened, result, process, budget = [load(SEARCH / n) for n in ['opened.json', 'result.json', 'process.json', 'budget.json']]
assert load(BASE / 'audit/checks.json')['passed']
assert digest(BASE / 'model.npz') == opened['model_sha256'] == load(BASE / 'audit/checks.json')['model_sha256']
log = (SEARCH / 'stdout.txt').read_text()
assert (SEARCH / 'stderr.txt').read_text() == ''
assert re.search(r'^  Status\s+Time limit reached$', log, re.M)
assert re.search(r'^  Nodes\s+214$', log, re.M) and re.search(r'^  Primal bound\s+inf$', log, re.M)
assert result['status_code'] == 1 and 'HiGHS Status 13' in result['message']
assert result['closed'] and result['solver_calls'] == 1 and not result['success'] and not result['has_assignment']
assert result['source_checker_calls'] == 0 and not result['source_valid11'] and not result['source_valid66']
assert not result['any_allocation_excluded'] and result['native_calls'] == 0
assert not (SEARCH / 'assignment.json').exists() and not (SEARCH / 'candidate-source11.json').exists()
assert process['closed'] and process['exit_code'] == 0 and not process['timeout']
assert process['seconds_including_preparation'] < 90 and result['algorithm_seconds_including_preparation'] < 60
overrun = max(0., result['returned_solve_seconds']-result['allocated_solve_seconds'])
assert result['returned_solve_overrun_seconds'] == overrun and overrun > 0 and result['algorithm_overrun_seconds'] == 0
assert opened['maximum_calls'] == budget['maximum_calls'] == 1 and not opened['retry_permitted'] and not budget['retry_permitted']
assert opened['node_limit'] == budget['node_limit'] == 4096
assert opened['options'] == {'time_limit': result['allocated_solve_seconds'], 'node_limit': 4096, 'mip_rel_gap': 0., 'presolve': True, 'disp': True}
assert opened['preparation_seconds_charged'] == budget['preparation_seconds_charged'] == result['preparation_seconds_charged'] == load(BASE / 'checks.json')['preparation_seconds_charged']
data = np.load(BASE / 'model.npz')['data']
assert not np.any((np.abs(data) > 0) & (np.abs(data) <= 1e-9)) and 'WARNING' not in log
write(OUT / 'source-bindings.json', bindings)
inputs = [Path(__file__), BASE / 'plan.json', BASE / 'model.npz', BASE / 'audit/plan.json', BASE / 'audit/checks.json'] + [SEARCH / n for n in ['opened.json', 'budget.json', 'result.json', 'process.json', 'stdout.txt', 'stderr.txt']]
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'recursive_input_bindings_verified': len(bindings),
          'closed_solver_calls': 1, 'outcome': 'TIME_LIMIT_NO_ASSIGNMENT', 'raw_solver_status': 'Time limit reached',
          'scipy_status_code': 1, 'infeasibility_proven': False, 'logged_nodes': 214, 'declared_node_limit': 4096,
          'tiny_coefficients_ignored': 0, 'preparation_seconds_charged': result['preparation_seconds_charged'],
          'returned_solve_seconds': result['returned_solve_seconds'], 'allocated_solve_seconds': result['allocated_solve_seconds'],
          'solve_slice_overrun_seconds': overrun, 'algorithm_seconds_including_preparation': result['algorithm_seconds_including_preparation'],
          'shared_seconds_including_preparation': process['seconds_including_preparation'],
          'algorithm_and_shared_overruns_seconds': 0, 'assignments': 0, 'source_checker_calls': 0,
          'any_allocation_excluded': False, 'remaining_candidates': 440, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
