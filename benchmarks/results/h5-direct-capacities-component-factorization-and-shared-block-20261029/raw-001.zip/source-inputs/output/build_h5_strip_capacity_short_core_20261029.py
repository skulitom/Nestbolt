"""Append cog strips and proved redundant capacities to the unchanged parent model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-short-core-20261029';PRE=BASE/'preflight';OUT=BASE/'model';OLD=ROOT/'output/h5-coarse-short-core-20261029';STRIP=OLD/'cog-strip-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
for folder in [BASE,PRE,PRE/'audit',OLD/'model',OLD/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
model=cp_model.CpModel();assert model.proto.parse_text_format((OLD/'model/model.pbtxt').read_text()) and model.validate()=='';assert model.export_to_file(str(OUT/'parent-copy.pb')) and digest(OUT/'parent-copy.pb')==digest(OLD/'model/model.pb')
parent_counts={'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'hints':len(model.proto.solution_hint.vars)};mp=load(OLD/'model/mapping.json');pos=load(OLD/'model/positive-control-assignment.json');neg=load(OLD/'model/negative-assignment.json');strips=load(STRIP/'strips.json');bounds=load(PRE/'bounds.json');mp['parent_counts']=parent_counts;mp['common_box_um']=bounds['common_box_um'];mp['cog_strips']=[];extra_hints={};allx=[];ally=[];demandsx=[];demandsy=[]
iv=lambda ix:model.get_int_var_from_proto_index(ix)
for item in mp['items']:
    for piece in item['pieces']:
        allx.append(model.get_interval_var_from_proto_index(piece['x_interval']));ally.append(model.get_interval_var_from_proto_index(piece['y_interval']));demandsx.append(iv(piece['world_variables'][5]));demandsy.append(iv(piece['world_variables'][4]))
for owner in [item for item in mp['items'] if item['family']=='cog']:
    b=owner['stock_bounds_grid_units'];present=model.get_bool_var_from_proto_index(owner['presence'])
    for k,r in enumerate(strips):
        world=[];links=[]
        for axis,local in enumerate(r):
            ai=axis%2;anchor=owner['x' if ai==0 else 'y'];v=model.new_int_var(100*b[ai]+local,100*b[ai+2]+local,f'strip_world_{owner["index"]}_{k}_{axis}');world.append(v);links.append(model.add(v-100*iv(anchor)==local).index);assert v.index==len(pos)==len(neg);pos.append(100*pos[anchor]+local);neg.append(100*neg[anchor]+local)
            if pos[owner['presence']]:model.add_hint(v,pos[v.index]);extra_hints[v.index]=pos[v.index]
        width=r[2]-r[0];height=r[3]-r[1];xi=model.new_optional_interval_var(world[0],width,world[2],present,f'strip_x_{owner["index"]}_{k}');yi=model.new_optional_interval_var(world[1],height,world[3],present,f'strip_y_{owner["index"]}_{k}');allx.append(xi);ally.append(yi);demandsx.append(height);demandsy.append(width);mp['cog_strips'].append({'owner':owner['index'],'component':k,'local_rectangle_um':r,'world_variables':[v.index for v in world],'link_constraints':links,'x_interval':xi.index,'y_interval':yi.index})
mp['strip_global_no_overlap']=model.add_no_overlap_2d(allx,ally).index;mp['capacity_x']=model.add_cumulative(allx,demandsx,bounds['x_intervals_height_capacity_um']).index;mp['capacity_y']=model.add_cumulative(ally,demandsy,bounds['y_intervals_width_capacity_um']).index
assert len(mp['cog_strips'])==32 and len(allx)==48 and len(pos)==len(model.proto.variables)==1566 and len(model.proto.constraints)==1619 and model.validate()==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mp);write(OUT/'positive-control-assignment.json',pos);write(OUT/'negative-assignment.json',neg);write(OUT/'extra-hints.json',{str(k):v for k,v in extra_hints.items()})
inputs=[Path(__file__),BASE/'plan.json',PRE/'plan.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'bounds.json',STRIP/'strips.json',OLD/'model/plan.json',OLD/'model-audit/plan.json',OLD/'model/model.pb',OLD/'model/model.pbtxt',OLD/'model/mapping.json',OLD/'model/positive-control-assignment.json',OLD/'model/negative-assignment.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'parent_variables_retained':parent_counts['variables'],'parent_constraints_retained':parent_counts['constraints'],'parent_hints_retained':parent_counts['hints'],'new_world_variables':128,'new_link_constraints':128,'new_optional_intervals':64,'new_global_no_overlap_pieces':48,'new_cumulative_constraints':2,'common_box_um':bounds['common_box_um'],'x_intervals_height_capacity_um':bounds['x_intervals_height_capacity_um'],'y_intervals_width_capacity_um':bounds['y_intervals_width_capacity_um'],'new_hints':len(extra_hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'),flush=True)
