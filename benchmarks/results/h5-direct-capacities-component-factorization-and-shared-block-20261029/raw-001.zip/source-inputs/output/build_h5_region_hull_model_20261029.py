"""Convex-combination disjunctive formulation of the certified relative regions."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
import numpy as np
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
PRE = SOURCE / 'relative-free-region-preflight'
PRIOR = ROOT / 'output/h5-short11-relative-region-model-20261029'
OUT = ROOT / 'output/h5-short11-region-convex-hull-model-20261029'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(PRE / 'audit/checks.json')['passed'] and load(PRIOR / 'response-audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'build.py')
started = time.perf_counter()
groups = load(PRE / 'groups.json')
stock_bounds = np.load(SOURCE / 'model.npz')['bounds'][:22]
binary_count = sum(len(g['regions']) for g in groups)
binary = 22
continuous = 22+binary_count
mapped, ri, ci, values, lower, upper = [], [], [], [], [], []

def row(coefficients, value):
    index = len(lower)
    for column, coefficient in coefficients.items():
        if coefficient:
            ri.append(index)
            ci.append(column)
            values.append(coefficient)
    lower.append(value)
    upper.append(value)
    return index

for group in groups:
    ia, ib = group['owners']
    record = {'owners': [ia, ib], 'regions': []}
    coordinate_rows = [{2*ia: 1., 2*ib: -1.}, {2*ia+1: 1., 2*ib+1: -1.}]
    for region_index, vertices in enumerate(group['regions']):
        selector = binary
        binary += 1
        rounded = [[round(value, 9) for value in point] for point in vertices]
        lambdas = list(range(continuous, continuous+len(vertices)))
        continuous += len(vertices)
        region = {'region': region_index, 'selector': selector, 'vertices': rounded, 'lambdas': lambdas}
        region['lambda_sum_row'] = row({selector: -1., **{i: 1. for i in lambdas}}, 0.)
        for column, point in zip(lambdas, rounded):
            for axis in [0, 1]:
                coordinate_rows[axis][column] = point[axis]
        record['regions'].append(region)
    record['one_of_row'] = row({r['selector']: 1. for r in record['regions']}, 1.)
    record['coordinate_rows'] = [row(coefficients, 0.) for coefficients in coordinate_rows]
    mapped.append(record)
matrix = coo_matrix((values, (ri, ci)), shape=(len(lower), continuous)).tocsc()
assert binary == 717 and continuous == 2990 and len(lower) == 860
np.savez(OUT / 'model.npz', data=matrix.data, indices=matrix.indices, indptr=matrix.indptr,
         shape=np.asarray(matrix.shape), lower=lower, upper=upper,
         bounds=np.vstack([stock_bounds, np.tile([0., 1.], (continuous-22, 1))]),
         c=np.zeros(continuous), integrality=np.r_[np.zeros(22, dtype=int), np.ones(binary_count, dtype=int), np.zeros(continuous-binary, dtype=int)])
write(OUT / 'mapping.json', mapped)
shutil.copyfile(SOURCE / 'seed-source11.json', OUT / 'seed-source11.json')
shutil.copyfile(SOURCE / 'inventory.json', OUT / 'inventory.json')
elapsed = time.perf_counter()-started
charges = {'source_geometry_and_all_axis_preparation_seconds': load(SOURCE / 'checks.json')['preparation_seconds_charged'],
           'free_region_preparation_seconds': load(PRE / 'checks.json')['seconds'],
           'convex_hull_model_build_seconds': elapsed}
write(OUT / 'preparation-charges.json', charges)
inputs = [Path(__file__), SOURCE / 'plan.json', SOURCE / 'checks.json', SOURCE / 'model.npz',
          SOURCE / 'world-pieces.json', SOURCE / 'seed-source11.json', SOURCE / 'inventory.json',
          PRE / 'plan.json', PRE / 'checks.json', PRE / 'groups.json', PRE / 'audit/plan.json',
          PRE / 'audit/checks.json', PRE / 'audit/support-certificates.json',
          PRIOR / 'response-audit/plan.json', PRIOR / 'response-audit/checks.json', PRIOR / 'slice-capacity-diagnostic/checks.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'A distinct convex-combination formulation of certified relative-position regions. Each original pair chooses one binary region. Nonnegative vertex weights for each region sum to its selector. Two equality rows set deltaB-deltaA to the weighted sum of all region vertices. Thus integral selectors place the relative translation in exactly one convex region; no deactivation constants are used. Region coordinates are rounded to nine decimals, requiring an independent exact original-source support audit of every rounded region. All 22 stock domains and fixed source orientations remain. Objective zero. This changes the LP relaxation, not the budgets or an earlier closed call. No negative result excludes the allocation; any assignment needs original-source readback.',
    'algorithm_seconds': 60, 'shared_seconds': 90, 'node_limit': 128,
    'maximum_calls': 1, 'retry_permitted': False, 'source_validation_reserve_seconds': 3,
})
checks = {'passed': True, 'seconds': elapsed, 'preparation_seconds_charged': sum(charges.values()),
          'original_pair_groups': 55, 'binary_region_selectors': 695, 'vertex_weight_variables': 2273,
          'variables': continuous, 'rows': len(lower), 'matrix_nonzeros': matrix.nnz,
          'model_sha256': digest(OUT / 'model.npz'), 'independent_audit_pending': True,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
