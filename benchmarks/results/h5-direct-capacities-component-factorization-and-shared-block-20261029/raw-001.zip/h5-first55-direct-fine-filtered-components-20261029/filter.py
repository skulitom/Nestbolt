"""Filter the original generic components through directly regenerated fine certificates."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';OUT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert all(load(p/'audit/checks.json')['passed'] for p in [SOURCE,FINE,STRIP]);OUT.mkdir();shutil.copyfile(__file__,OUT/'filter.py');started=time.perf_counter()
fine={tuple(r['empty_sites']):r for r in load(FINE/'all29-fine-band-bounds.json')};strip={tuple(r['empty_sites']):r for r in load(STRIP/'all22-fine-strip-bounds.json')};rows=[]
for r in load(SOURCE/'all29-vectorized-bounds.json'):
    key=tuple(r['empty_sites']);area=fine[key];assert area['initial_distributions']==r['remaining_distributions']
    if area['restricted_construction_excluded']:assert area['remaining_distributions']==[] and key not in strip;continue
    bounds=strip[key];assert bounds['initial_distributions']==area['remaining_distributions']
    if bounds['restricted_construction_excluded']:assert bounds['remaining_distributions']==[];continue
    assert bounds['remaining_distributions'] and all(v in r['remaining_distributions'] for v in bounds['remaining_distributions'])
    rows.append({**r,'remaining_distributions':bounds['remaining_distributions']})
assert len(rows)==18 and sum(len(r['remaining_distributions']) for r in rows)==42
write(OUT/'all18-filtered-bounds.json',rows);write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in rows]);elapsed=time.perf_counter()-started
inputs=[Path(__file__),SOURCE/'plan.json',SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',SOURCE/'all29-vectorized-bounds.json',FINE/'plan.json',FINE/'audit/plan.json',FINE/'audit/checks.json',FINE/'all29-fine-band-bounds.json',STRIP/'plan.json',STRIP/'audit/plan.json',STRIP/'audit/checks.json',STRIP/'audit/allowed-empty-site-pairs.json',STRIP/'all22-fine-strip-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Preserve every original generic source component and mode attribution. Apply only the directly regenerated fine-area and fine-strip exclusions. Charge the generic source chain, both direct bound constructions and this filter; the superseded coarse strip/filter/fine discovery chain is not required.','solver_calls':0,'native_calls':0})
checks={'passed':True,'seconds':elapsed,'restricted_site_pairs':18,'count_distributions':42,'new_source_geometry':False,'generic_count_construction_seconds_required':load(SOURCE/'checks.json')['seconds'],'direct_fine_area_seconds_required':load(FINE/'checks.json')['seconds'],'direct_fine_strip_seconds_required':load(STRIP/'checks.json')['seconds'],'all_generic_source_chain_charges_still_required':True,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
