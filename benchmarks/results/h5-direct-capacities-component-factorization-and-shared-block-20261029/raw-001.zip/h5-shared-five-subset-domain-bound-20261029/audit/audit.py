"""Independent continuous pair bounds, subset certificates and complete multiset readback."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,combinations_with_replacement
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';BASE=ROOT/'output/h5-shared-five-subset-domain-bound-20261029';OUT=BASE/'audit';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';COVER=PRIOR/'accessible-area-bound';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';BLOCK=ROOT/'output/h5-shared-five-block-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
nodes=load(PAIR/'nodes.json');keys=load(BLOCK/'model/mapping.json')['source_options'];assert [n['key'] for n in nodes]==keys and len(nodes)==81
inner=load(GENERIC/'source-inner-rectangles.json');unary=load(PRIOR/'integer-preparation/unary-templates.json');bounds=[];boxes=[];areas=[]
for n in nodes:
    f,m,gid,ri=n['key'];hull=[tuple(map(F,p)) for p in next(r for r in unary[gid]['regions'] if r['region']==ri)['hull_vertices']]
    expected=[fn(p[k] for p in hull) for fn in [min,max] for k in [0,1]];assert list(map(F,n['translation_bounds_mm']))==expected and n['contained_rectangles_mm']==inner[f][m]
    bounds.append(expected);pieces=[tuple(map(F,b)) for b in inner[f][m]];boxes.append(pieces);areas.append(sum((r-l)*(t-b) for l,b,r,t in pieces))
margin=F(149,1000);required=F(load(FIRST/'plan.json')['required_pair_gap_mm']);assert 2*margin**2<required**2
compat=[0]*len(nodes);expected_conflicts=[]
for i,A in enumerate(bounds):
    for j in range(i,len(nodes)):
        B=bounds[j];relative=[B[0]-A[2],B[1]-A[3],B[2]-A[0],B[3]-A[1]];witness=None
        for pi,a in enumerate(boxes[i]):
            for pj,b in enumerate(boxes[j]):
                possible=[relative[2]>=a[2]-b[0]+margin,relative[0]<=a[0]-b[2]-margin,relative[3]>=a[3]-b[1]+margin,relative[1]<=a[1]-b[3]-margin]
                if not any(possible):witness={'nodes':[i,j],'pieces':[pi,pj],'maximum_axis_gaps_mm':[str(v) for v in [relative[2]+b[0]-a[2],-relative[0]+a[0]-b[2],relative[3]+b[1]-a[3],-relative[1]+a[1]-b[3]]]};break
            if witness:break
        if witness:expected_conflicts.append(witness)
        else:compat[i]|=1<<j;compat[j]|=1<<i
assert expected_conflicts==load(PAIR/'conflicts.json') and [hex(v) for v in compat]==load(PAIR/'compatibility.json') and len(expected_conflicts)==835
bykey={}
for row in load(COVER/'swept-covers.json'):
    key=(row['family'],row['mode'],row['geometry'],row['region'])
    if list(key) not in keys:continue
    cells=bykey.setdefault(key,set())
    for y,lo,hi in row['grid_row_spans']:cells.update((y-200)*150+x for x in range(lo,hi+1))
support=[sum(1<<v for v in bykey[tuple(n['key'])]) for n in nodes]
assert [hex(v) for v in support]==load(BASE/'node-supports.json') and [str(v) for v in areas]==load(BASE/'node-source-areas.json')
bad=set();certificates=load(BASE/'subset-certificates.json')
for cert in certificates:
    indices=tuple(cert['nodes']);assert indices==tuple(sorted(indices)) and 1<=len(indices)<=5 and all(0<=i<81 for i in indices) and indices not in bad
    union=0
    for i in indices:union|=support[i]
    upper=union.bit_count()*100;lower=sum(areas[i] for i in indices)
    assert cert['support_hex']==hex(union) and cert['upper_support_area_mm2']==upper and cert['lower_source_area_mm2']==str(lower) and lower>upper;bad.add(indices)
assert len(bad)==90422
br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];pair_records=[];pair_survivors=0;retained=[]
for a,b in combinations_with_replacement(br,2):
    if not compat[a]>>b&1:continue
    candidates=[i for i in ins if compat[a]>>i&1 and compat[b]>>i&1];triples=0
    for c,d,e in combinations_with_replacement(candidates,3):
        if not (compat[c]>>d&1 and compat[c]>>e&1 and compat[d]>>e&1):continue
        triples+=1;whole=(a,b,c,d,e)
        if not any(tuple(part) in bad for k in range(1,6) for part in combinations(whole,k)):retained.append(list(whole))
    pair_records.append({'bracket_nodes':[a,b],'candidate_insert_nodes_hex':hex(sum(1<<i for i in candidates)),'compatible_insert_triples':triples});pair_survivors+=triples
assert pair_records==load(PAIR/'bracket-pair-counts.json') and pair_survivors==139124 and len(retained)==36802
assert load(PAIR/'checks.json')['enumeration_complete'] and load(BASE/'checks.json')['enumeration_complete'] and load(PAIR/'checks.json')['cap_overrun_seconds']==load(BASE/'checks.json')['cap_overrun_seconds']==0
write(OUT/'retained-option-multisets.json',retained);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[PAIR/n for n in ['plan.json','checks.json','nodes.json','conflicts.json','compatibility.json','bracket-pair-counts.json']]+[BASE/n for n in ['plan.json','checks.json','subset-certificates.json','node-supports.json','node-source-areas.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'original_continuous_source_options_verified':81,'necessary_pair_incompatibilities_verified':835,'exact_subset_certificates_verified':90422,'necessary_pair_compatible_multisets':pair_survivors,'subset_excluded_option_multisets':pair_survivors-len(retained),'necessary_option_multisets_remaining':len(retained),'all_nonnegative_multisets_independently_enumerated':True,'repeated_options_supported':True,'continuous_source_block_excluded':False,'any_placement_proven':False,'count_distributions_remaining':42,'restricted_site_choices_remaining':18,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
