"""Exact support-cell subset capacities for every necessary common-block option multiset."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';COVER=ROOT/'output/h5-first55-cog-site-masks-20261029/accessible-area-bound';OUT=ROOT/'output/h5-shared-five-subset-domain-bound-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(COVER/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter();nodes=load(PAIR/'nodes.json');compatible=[int(s,16) for s in load(PAIR/'compatibility.json')];bykey={}
for row in load(COVER/'swept-covers.json'):
    key=(row['family'],row['mode'],row['geometry'],row['region']);bits=bykey.get(key,0)
    for y,lo,hi in row['grid_row_spans']:bits|=((1<<(hi-lo+1))-1)<<((y-200)*150+lo)
    bykey[key]=bits
bits=[bykey[tuple(n['key'])] for n in nodes];area=[sum((F(r)-F(l))*(F(t)-F(b)) for l,b,r,t in n['contained_rectangles_mm']) for n in nodes];cache={};certs=[];prefixes=[0]*6;leaves=0;sample=None;complete=True;cache_hits=0
def violation(indices):
    global cache_hits
    if indices in cache:cache_hits+=1;return cache[indices]
    support=0
    for i in indices:support|=bits[i]
    upper=100*support.bit_count();lower=sum(area[i] for i in indices);bad=lower>upper;cache[indices]=bad
    if bad:certs.append({'nodes':list(indices),'upper_support_area_mm2':upper,'lower_source_area_mm2':str(lower),'support_hex':hex(support)})
    return bad
br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];families=[br,br,ins,ins,ins]
def visit(selected):
    global leaves,sample,complete
    if time.perf_counter()-started>=58:complete=False;return
    depth=len(selected);prefixes[depth]+=1
    if depth==5:
        leaves+=1
        if sample is None:sample=selected[:]
        return
    for i in families[depth]:
        if depth in [1,3,4] and i<selected[-1]:continue
        if any(not compatible[j]>>i&1 for j in selected):continue
        bad=False
        for mask in range(1<<depth):
            indices=tuple([j for k,j in enumerate(selected) if mask>>k&1]+[i])
            if violation(indices):bad=True;break
        if not bad:visit(selected+[i])
        if not complete:return
visit([]);elapsed=time.perf_counter()-started
inputs=[Path(__file__),PAIR/'plan.json',PAIR/'checks.json',PAIR/'nodes.json',PAIR/'compatibility.json',COVER/'plan.json',COVER/'audit/plan.json',COVER/'audit/checks.json',COVER/'swept-covers.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Enumerate the complete nondecreasing two-bracket/three-insert option domain using the necessary continuous pair graph. At each prefix, check every source-option subset involving its new node. The summed exact contained-rectangle material cannot exceed the area of its original conservative10mm swept support-cell union. Each failing subset is an exact rational certificate; repeated node options retain their multiplicity in the required area and appear only once in support unions. Keep every unprocessed branch after the fixed cap. No packing solver is called.','discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_domain_retained':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'subset-certificates.json',certs);write(OUT/'node-supports.json',[hex(v) for v in bits]);write(OUT/'node-source-areas.json',[str(v) for v in area])
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'enumeration_complete':complete,'prefixes_visited_by_depth':prefixes,'unique_subsets_checked':len(cache),'cached_subset_visits':cache_hits,'positive_subset_certificates':len(certs),'necessary_option_multisets_remaining':leaves,'sample_necessary_option_multiset':sample,'source_block_excluded_pending_independent_audit':complete and leaves==0,'independent_audit_required':True,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
