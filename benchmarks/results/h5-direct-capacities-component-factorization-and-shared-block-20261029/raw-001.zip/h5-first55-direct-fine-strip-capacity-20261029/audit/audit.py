"""Independent interval-union and exact polygon-clipping proof of every strip exclusion."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';OUT=BASE/'audit';COUNT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';PREVIOUS=ROOT/'output/h5-first55-fine-band-filtered-components-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clipped(poly,axis,above,cut):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[axis]>=cut if above else a[axis]<=cut;inb=b[axis]>=cut if above else b[axis]<=cut
        if ina:out.append(a)
        if ina!=inb:
            t=(cut-a[axis])/(b[axis]-a[axis]);out.append(tuple(a[k]+t*(b[k]-a[k]) for k in [0,1]))
    return out
def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if poly else F(0)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(COUNT/'audit/checks.json')['passed'] and load(FINE/'audit/checks.json')['passed']
fine={tuple(r['empty_sites']):r for r in load(FINE/'all29-fine-band-bounds.json') if r['remaining_distributions']}
source_rows=[{**r,'remaining_distributions':fine[tuple(r['empty_sites'])]['remaining_distributions']} for r in load(COUNT/'all29-vectorized-bounds.json') if tuple(r['empty_sites']) in fine]
rows=load(BASE/'all22-fine-strip-bounds.json');assert len(rows)==len(source_rows)==22
inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(COUNT/'source-inner-rectangles.json').items()};unary=load(PRIOR/'integer-preparation/unary-templates.json')
raw_intervals=union_intervals=certificates=removed_count=initial_count=remaining_count=breakpoints=clippings=0;allowed=[];excluded=[]
for row,source in zip(rows,source_rows):
    assert row['empty_sites']==source['empty_sites'] and row['initial_distributions']==source['remaining_distributions'];groups=source['groups'];events=[{} for g in groups]
    for family,mode,gid,ri,gi in source['region_component_assignments']:
        raw=next(r for r in unary[gid]['regions'] if r['region']==ri);points=[tuple(map(F,p)) for p in raw['hull_vertices']];events[gi].setdefault(mode,[{},{}])
        for axis in [0,1]:
            lo=min(p[axis] for p in points);hi=max(p[axis] for p in points);assert lo<hi;raw_intervals+=1
            e=events[gi][mode][axis];e[lo]=e.get(lo,0)+1;e[hi]=e.get(hi,0)-1
    projections=[]
    for gi,by_mode in enumerate(events):
        result={}
        for mode,axes in by_mode.items():
            merged=[]
            for axis,e in enumerate(axes):
                balance=0;start=None;intervals=[]
                for x,delta in sorted(e.items()):
                    old=balance;balance+=delta;assert balance>=0
                    if old==0 and balance>0:start=x
                    if old>0 and balance==0:assert start is not None;intervals.append((start,x));start=None
                assert balance==0 and start is None and intervals
                bound=list(map(F,groups[gi]['mode_position_bounds_mm'][str(mode)]));assert intervals[0][0]==bound[axis] and intervals[-1][1]==bound[axis+2]
                merged.append(intervals);union_intervals+=len(intervals)
            result[mode]=merged
        projections.append(result)
    assert row['projection_intervals_mm']==[{str(m):[[[str(v) for v in interval] for interval in axis] for axis in axes] for m,axes in by_mode.items()} for by_mode in projections]
    possible={tuple(v) for v in row['initial_distributions']};initial_count+=len(possible)
    for cert in row['certificates']:
        selected=cert['groups'];assert selected==sorted(set(selected)) and all(0<=i<len(groups) for i in selected) and {groups[i]['family'] for i in selected}=={'bracket','insert'}
        axis=cert['axis'];left,right=map(F,cert['strip_mm']);assert axis in [0,1] and left<right and left%10==right%10==0
        bands={}
        for gi in selected:
            for y,lo,hi in fine[tuple(row['empty_sites'])]['groups'][gi]['band_spans_tenths_mm']:
                e=bands.setdefault(y,{});e[lo]=e.get(lo,0)+1;e[hi]=e.get(hi,0)-1
        available=F(0)
        for y,events in bands.items():
            balance=0;start=None
            for x,delta in sorted(events.items()):
                old=balance;balance+=delta;assert balance>=0
                if old==0 and balance>0:start=x
                if old>0 and balance==0:
                    l,r=F(start,10),F(x,10);b,t=F(2*y),F(2*(y+1));poly=[(l,b),(r,b),(r,t),(l,t)]
                    available+=area(clipped(clipped(poly,axis,True,left),axis,False,right));clippings+=2;start=None
            assert balance==0 and start is None
        vals={};coefficients=[F(0)]*len(groups);cases=0
        for gi in selected:
            f=groups[gi]['family'];vals[str(gi)]={}
            for mode,axes in projections[gi].items():
                polygons=[[(l,b),(r,b),(r,t),(l,t)] for l,b,r,t in inner[f][mode]];minimum=None
                for lo,hi in axes[axis]:
                    shifts={lo,hi}
                    for poly in polygons:
                        for vertex in poly:
                            for cut in [left,right]:
                                shift=cut-vertex[axis]
                                if lo<=shift<=hi:shifts.add(shift)
                    for shift in shifts:
                        occupied=F(0);cases+=1
                        for poly in polygons:
                            translated=[tuple(p[k]+(shift if k==axis else 0) for k in [0,1]) for p in poly]
                            occupied+=area(clipped(clipped(translated,axis,True,left),axis,False,right));clippings+=2
                        minimum=occupied if minimum is None else min(minimum,occupied)
                assert minimum is not None;vals[str(gi)][str(mode)]=str(minimum)
            coefficients[gi]=min(map(F,vals[str(gi)].values()))
        assert cert['upper_area_mm2']==str(available) and cert['selected_group_mode_minimum_area_mm2']==vals and cert['coefficients_mm2']==[str(v) for v in coefficients] and cert['source_breakpoint_cases']==cases
        removed={v for v in possible if sum(n*c for n,c in zip(v,coefficients))>available};assert removed and cert['distributions_removed']==[list(v) for v in sorted(removed)];possible-=removed;certificates+=1;removed_count+=len(removed);breakpoints+=cases
    assert row['remaining_distributions']==[list(v) for v in sorted(possible)] and row['restricted_construction_excluded']==(not possible);remaining_count+=len(possible)
    nb=sum(g['family']=='bracket' for g in groups);ni=len(groups)-nb;subsets=((1<<nb)-1)*((1<<ni)-1)
    assert row['scan_complete'] and row['mixed_subsets_completed']==subsets and row['strips_screened']==16375*subsets
    (allowed if possible else excluded).append(row['empty_sites'])
assert certificates==4 and removed_count==5 and initial_count==47 and remaining_count==42 and len(allowed)==18 and len(excluded)==4
checks0=load(BASE/'checks.json');assert checks0['certificates']==certificates and checks0['count_distributions_excluded']==removed_count and checks0['remaining_count_distributions']==remaining_count and checks0['new_restricted_site_exclusions']==len(excluded) and checks0['cap_overrun_seconds']==0
previous=load(PREVIOUS/'all18-filtered-bounds.json');retained=[r for r in rows if r['remaining_distributions']]
assert [(r['empty_sites'],r['remaining_distributions']) for r in retained]==[(r['empty_sites'],r['remaining_distributions']) for r in previous]
write(OUT/'allowed-empty-site-pairs.json',allowed);write(OUT/'excluded-empty-site-pairs.json',excluded);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),PREVIOUS/'plan.json',PREVIOUS/'audit/plan.json',PREVIOUS/'audit/checks.json',PREVIOUS/'all18-filtered-bounds.json']+[BASE/n for n in ['plan.json','checks.json','all22-fine-strip-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_hull_projection_intervals_verified':raw_intervals,'merged_projection_intervals_verified':union_intervals,'necessary_strip_certificates_verified':certificates,'exact_breakpoint_evaluations_for_certificates':breakpoints,'independent_polygon_clipping_operations':clippings,'all_recorded_exclusions_independently_verified':True,'unrecorded_screened_strip_values_independently_recomputed':False,'retained_domain_matches_previous_checkpoint':True,'initial_count_distributions':initial_count,'count_distributions_excluded':removed_count,'remaining_count_distributions':remaining_count,'new_restricted_site_exclusions':len(excluded),'excluded_empty_site_pairs':excluded,'restricted_pairs_remaining':len(allowed),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
