from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_strip_component_model_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-strip-components-model-20261029','h5-first55-fine-components-model-20261029'),("COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029'","COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029'"),("STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029'","STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029'"),('all25-filtered-bounds.json','all18-filtered-bounds.json'),('assert len(forbidden)==80','assert len(forbidden)==87'),("'retained_empty_site_pairs':25,'forbidden_site_pair_constraints':80","'retained_empty_site_pairs':18,'forbidden_site_pair_constraints':87"),("'component_strip_bound_seconds':load(STRIP/'checks.json')['seconds']","'direct_fine_area_bound_seconds':load(FINE/'checks.json')['seconds'],'direct_fine_strip_bound_seconds':load(STRIP/'checks.json')['seconds']"),("inputs=[Path(__file__),","inputs=[Path(__file__),FINE/'plan.json',FINE/'checks.json',FINE/'audit/plan.json',FINE/'audit/checks.json',")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
s=s.replace('unary_plane_count=mask_links=0','unary_plane_count=mask_links=mask_pruned_unary_count=0')
needle="        for region in unary[gid]['regions']:\n            selector="
assert s.count(needle)==1;s=s.replace(needle,"        for region in unary[gid]['regions']:\n            if not any(set(region['required_empty_sites'])<=set(sites) for sites in allowed):mask_pruned_unary_count+=1;continue\n            selector=")
s=s.replace('and25 audited surviving empty-site pairs, with all82 independently verified component-count distributions','and18 audited surviving empty-site pairs, with all42 independently verified component-count distributions')
s=s.replace('Local0.1mm-grid positions use the exact audited source hull implications.','Local0.1mm-grid positions use the exact audited source hull implications. Remove only unary selectors whose required-empty mask is incompatible with every retained site pair; this eliminates1876 impossible owner-region choices without changing any feasible placement in the retained domain.')
s=s.replace("'unary_region_selectors':sum(len(o['unary_regions']) for o in owners)","'unary_site_mask_pruned_selectors':mask_pruned_unary_count,'unary_region_selectors':sum(len(o['unary_regions']) for o in owners)")
s=s.replace('"""Local0.1mm-grid construction with audited source implications and all35 site choices."""','"""Fine-capacity canonical model with provably impossible unary mask choices removed."""')
p=ROOT/'output/build_h5_fine_component_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'expected_variables':6520,'expected_constraints':32928,'impossible_unary_selectors_removed':1876})
