"""Reconstruct the common source block and check each of its three 58-part partial layouts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from copy import deepcopy
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-five-block-20261029';SEARCH=BASE/'search';OUT=SEARCH/'source-response';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir();mapping=load(BASE/'model/mapping.json');values=load(SEARCH/'assignment.json');inventory=load(GEO/'inventory.json');sites=load(SLOTS/'source-cog-sites.json');block=[];selected=[]
for owner in mapping['owners']:
    modes=[m for m in owner['modes'] if values[m['selector']]];regions=[r for r in owner['unary_regions'] if values[r['selector']]];assert len(modes)==len(regions)==1;mode,region=modes[0],regions[0];assert region['geometry']==mode['normalized_geometry']
    xy=[values[v]/10+mapping['world_origin_mm'][k] for k,v in enumerate(owner['positions'])]
    block.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
    selected.append({'identity':owner['identity'],'mode':mode['mode'],'geometry':region['geometry'],'region':region['region'],'lower_left_mm':xy})
missing={('bracket',i) for i in [2,3,5,6,9]}|{('insert',i) for i in [18,19,20]};expected=[tuple(i) for i in inventory['full66_identities'] if tuple(i) not in missing];assert len(expected)==58
job=load(JOB);spec=load(FIRST/'plan.json');checks=[]
for use in mapping['compatible_uses']:
    empty=use['empty_sites'];occupied=[i for i in range(15) if i not in empty];rows=load(FIRST/'fixed29.json')
    for site,identity in zip(occupied,inventory['required_cog13_identities']):
        row=deepcopy(sites[site]);assert identity[0]=='cog';row['copy_index']=identity[1];rows.append(row)
    rows+=load(SHORT);rows+=deepcopy(block);assert len(rows)==58
    result=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
    assert result['same_sheet_pairs']==1136 and result['stock_edges']==232 and result['cutouts']==72
    name='empty-'+'-'.join(map(str,empty));write(OUT/(name+'-source58.json'),rows);write(OUT/(name+'-checks.json'),result);checks.append({'empty_sites':empty,'source_file':name+'-source58.json','checks_file':name+'-checks.json','source_valid58':result['valid']})
write(OUT/'shared-source5.json',block);write(OUT/'selected-modes.json',selected)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',SLOTS/'source-cog-sites.json',GEO/'inventory.json',BASE/'model/mapping.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'source_valid58':all(c['source_valid58'] for c in checks),'compatible_uses':checks,'partial_originals_per_use':58,'same_sheet_pairs_per_use':1136,'stock_edges_per_use':232,'cutouts_per_use':72,'shared_block_originals':5,'remaining_originals':8,'source_checker_calls':1,'original_source_audits':3,'algorithm_seconds_including_preparation':time.perf_counter()-started,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
