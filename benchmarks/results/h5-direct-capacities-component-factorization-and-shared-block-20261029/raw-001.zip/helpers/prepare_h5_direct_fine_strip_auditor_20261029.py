from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_component_strips_20261029.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first55-component-strip-capacity-20261029'","BASE=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029'")
s=s.replace("load=lambda p:","FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';PREVIOUS=ROOT/'output/h5-first55-fine-band-filtered-components-20261029'\nload=lambda p:")
old="assert load(COUNT/'audit/checks.json')['passed'];source_rows=load(COUNT/'all29-vectorized-bounds.json');rows=load(BASE/'all29-strip-bounds.json');assert len(rows)==len(source_rows)==29"
new="""assert load(COUNT/'audit/checks.json')['passed'] and load(FINE/'audit/checks.json')['passed']
fine={tuple(r['empty_sites']):r for r in load(FINE/'all29-fine-band-bounds.json') if r['remaining_distributions']}
source_rows=[{**r,'remaining_distributions':fine[tuple(r['empty_sites'])]['remaining_distributions']} for r in load(COUNT/'all29-vectorized-bounds.json') if tuple(r['empty_sites']) in fine]
rows=load(BASE/'all22-fine-strip-bounds.json');assert len(rows)==len(source_rows)==22"""
assert old in s;s=s.replace(old,new)
a=s.index('        support=set()');b=s.index('        vals={}',a)
s=s[:a]+'''        bands={}
        for gi in selected:
            for y,lo,hi in fine[tuple(row['empty_sites'])]['groups'][gi]['band_spans_tenths_mm']:
                e=bands.setdefault(y,{});e[lo]=e.get(lo,0)+1;e[hi]=e.get(hi,0)-1
        available=F(0)
        for y,events in bands.items():
            balance=0;start=None
            for x,delta in sorted(events.items()):
                old=balance;balance+=delta;assert balance>=0
                if old==0 and balance>0:start=x
                if old>0 and balance==0:
                    l,r=F(start,10),F(x,10);b,t=F(2*y),F(2*(y+1));poly=[(l,b),(r,b),(r,t),(l,t)]
                    available+=area(clipped(clipped(poly,axis,True,left),axis,False,right));clippings+=2;start=None
            assert balance==0 and start is None
''' +s[b:]
s=s.replace("cert['upper_area_mm2']==available","cert['upper_area_mm2']==str(available)")
s=s.replace('certificates==24 and removed_count==50 and initial_count==132 and remaining_count==82 and len(allowed)==25 and len(excluded)==4','certificates==4 and removed_count==5 and initial_count==47 and remaining_count==42 and len(allowed)==18 and len(excluded)==4')
s=s.replace("'all29-strip-bounds.json'","'all22-fine-strip-bounds.json'")
s=s.replace("write(OUT/'allowed-empty-site-pairs.json',allowed);", """previous=load(PREVIOUS/'all18-filtered-bounds.json');retained=[r for r in rows if r['remaining_distributions']]
assert [(r['empty_sites'],r['remaining_distributions']) for r in retained]==[(r['empty_sites'],r['remaining_distributions']) for r in previous]
write(OUT/'allowed-empty-site-pairs.json',allowed);""")
s=s.replace("inputs=[Path(__file__)]", "inputs=[Path(__file__),PREVIOUS/'plan.json',PREVIOUS/'audit/plan.json',PREVIOUS/'audit/checks.json',PREVIOUS/'all18-filtered-bounds.json']")
s=s.replace("'unrecorded_screened_strip_values_independently_recomputed':False,", "'unrecorded_screened_strip_values_independently_recomputed':False,'retained_domain_matches_previous_checkpoint':True,")
p=ROOT/'output/audit_h5_direct_fine_strips_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name})
