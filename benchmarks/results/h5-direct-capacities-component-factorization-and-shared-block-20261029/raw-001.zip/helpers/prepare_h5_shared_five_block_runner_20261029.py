from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_fine_component_model_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-first55-fine-components-model-20261029','h5-shared-five-block-20261029').replace('check_h5_fine_component_candidate_20261029.py','check_h5_shared_five_block_candidate_20261029.py')
s=s.replace("source_valid = load(OUT / 'source-response/checks.json')['source_valid66']","source_valid = load(OUT / 'source-response/checks.json')['source_valid58']")
s=s.replace("'source_checker_calls': source_checks, 'source_valid66': source_valid,","'source_checker_calls': source_checks, 'source_valid58': source_valid, 'source_valid66': False,")
s=s.replace('One declared 60/90-second CP-SAT source construction with source-hull positions and audited component counts.','One declared 60/90-second partial construction of a common independent five-part source block.')
p=ROOT/'output/run_h5_shared_five_block_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'maximum_calls':1,'partial58_only':True})
