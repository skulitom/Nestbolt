"""Complete byte-verified multipart ZIP evidence with explicit identical-content aliases."""
from hashlib import sha256
import json,zipfile
def digest(path):return sha256(path.read_bytes()).hexdigest()
def pack(root,out,name,members):
    canonical={};aliases=[];files=[];staging=root/'output'/f'{name}-raw-staging.zip'
    with zipfile.ZipFile(staging,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for member,path in sorted(members.items()):
            row={'path':member,'bytes':path.stat().st_size,'sha256':digest(path)};key=(row['bytes'],row['sha256'])
            if key in canonical:aliases.append({**row,'canonical':canonical[key]})
            else:canonical[key]=member;z.write(path,member);files.append(row)
    archives=[];lookup={r['path']:r for r in files}
    with zipfile.ZipFile(staging) as source:
        assert source.testzip() is None;groups=[];group=[];size=0
        for info in source.infolist():
            assert info.compress_size<44*1024*1024,(info.filename,info.compress_size)
            if group and size+info.compress_size>44*1024*1024:groups.append(group);group=[];size=0
            group.append(info.filename);size+=info.compress_size
        if group:groups.append(group)
        for number,group in enumerate(groups,1):
            path=out/f'raw-{number:03d}.zip'
            with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for member in group:
                    data=source.read(member);assert len(data)==lookup[member]['bytes'] and sha256(data).hexdigest()==lookup[member]['sha256'];z.writestr(member,data);lookup[member]['archive']=path.name
            assert path.stat().st_size<50*1024*1024
            with zipfile.ZipFile(path) as z:
                assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(group)
                for member in group:assert sha256(z.read(member)).hexdigest()==lookup[member]['sha256']
            archives.append({'path':path.name,'bytes':path.stat().st_size,'sha256':digest(path)})
    for r in aliases:
        target=lookup[r['canonical']];assert target['bytes']==r['bytes'] and target['sha256']==r['sha256'];r['archive']=target['archive']
    manifest={'archives':archives,'files':files,'aliases':aliases,'format':'Each ZIP part is independently readable. Every file names its archive. Identical bytes are stored once, with each alias naming its canonical member, archive, exact length and SHA-256. All original paths and evidence remain represented.'}
    with (out/'raw-manifest.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(manifest,f,indent=2);f.write('\n')
    return {'archive_parts':len(archives),'archive_members':len(files),'verified_aliases':len(aliases),'archive_bytes':sum(v['bytes'] for v in archives)},manifest
