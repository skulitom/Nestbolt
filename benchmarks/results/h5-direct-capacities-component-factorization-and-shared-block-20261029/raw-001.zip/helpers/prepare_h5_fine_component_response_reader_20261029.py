from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_strip_component_response_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-strip-components-model-20261029','h5-first55-fine-components-model-20261029'),('len(model.variables)==8443 and len(model.constraints)==44837','len(model.variables)==6520 and len(model.constraints)==32928'),("result['returned_response_branches']==84586","result['returned_response_branches']==39749"),("result['returned_response_conflicts']==11411","result['returned_response_conflicts']==51"),("'max_lp':          0            0       1         0  2'178           0","'max_lp':          0            0       2         0  4'737           0"),("'default_lp':          1            0       0         0    145           0","'default_lp':          0            0       0         0      8           0"),("'max_lp_cut_propagations':0,'max_lp_cut_equal_propagations':0,'max_lp_adjust_statistic':1,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':2178,'default_lp_cut_propagations':1,'default_lp_adjust_statistic':0,'default_lp_bad_statistic':145","'max_lp_cut_propagations':0,'max_lp_cut_equal_propagations':0,'max_lp_adjust_statistic':2,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':4737,'default_lp_cut_propagations':0,'default_lp_adjust_statistic':0,'default_lp_bad_statistic':8")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/audit_h5_fine_component_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'closed_call_overrun_preserved':True})
