from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_fine_band_filtered_counts_20261029.py').read_text(encoding='utf-8')
changes=[("SOURCE=ROOT/'output/h5-first55-strip-filtered-components-20261029'","SOURCE=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'"),("STRIP=ROOT/'output/h5-first55-fine-band-capacity-20261029'","STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029'"),("BASE=ROOT/'output/h5-first55-fine-band-filtered-components-20261029'","BASE=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029'"),("SOURCE/'all25-filtered-bounds.json'","SOURCE/'all29-vectorized-bounds.json'"),('all25-fine-band-bounds.json','all22-fine-strip-bounds.json')]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
s=s.replace("write(OUT/'allowed-empty-site-pairs.json',allowed);", """previous=ROOT/'output/h5-first55-fine-band-filtered-components-20261029'
assert digest(BASE/'all18-filtered-bounds.json')==digest(previous/'all18-filtered-bounds.json')
write(OUT/'allowed-empty-site-pairs.json',allowed);""")
s=s.replace("inputs=[Path(__file__)]", "inputs=[Path(__file__),previous/'plan.json',previous/'audit/plan.json',previous/'audit/checks.json',previous/'all18-filtered-bounds.json']")
s=s.replace("'only_independently_excluded_distributions_removed':True,", "'only_independently_excluded_distributions_removed':True,'source_and_retained_count_bytes_identical_to_previous_checkpoint':True,")
p=ROOT/'output/audit_h5_direct_fine_filtered_counts_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name})
