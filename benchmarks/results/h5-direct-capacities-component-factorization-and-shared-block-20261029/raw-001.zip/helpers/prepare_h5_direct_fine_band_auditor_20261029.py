from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_fine_band_capacities_20261029.py').read_text(encoding='utf-8')
changes=[("BASE=ROOT/'output/h5-first55-fine-band-capacity-20261029'","BASE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029'"),("COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029'","COUNT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'"),('all25-filtered-bounds.json','all29-vectorized-bounds.json'),('all25-fine-band-bounds.json','all29-fine-band-bounds.json'),('len(rows)==len(source_rows)==25 and certificates==26 and removed_count==40 and initial_count==82 and remaining_count==42 and len(allowed)==18','len(rows)==len(source_rows)==29 and certificates==50 and removed_count==85 and initial_count==132 and remaining_count==47 and len(allowed)==22')]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/audit_h5_direct_fine_band_capacities_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name})
