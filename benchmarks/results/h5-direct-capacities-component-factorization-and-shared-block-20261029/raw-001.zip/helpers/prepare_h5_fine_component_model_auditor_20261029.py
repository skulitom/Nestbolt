from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_strip_component_model_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-strip-components-model-20261029','h5-first55-fine-components-model-20261029'),("COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029'","COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029'"),("STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029'","STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029'"),('all25-filtered-bounds.json','all18-filtered-bounds.json'),('8443','6520'),('44837','32928'),('7524','5648'),('7528','5652'),('7604','5728'),('7608','5732'),('7403','5527'),('30208','22439'),('11568','7935'),('len(allowed)==25 and len(expected_forbidden)==80','len(allowed)==18 and len(expected_forbidden)==87'),('len(choices)==len(source_choices)==25','len(choices)==len(source_choices)==18'),('len(all_p)==25 and len(all_d)==82 and component_equalities==100','len(all_p)==18 and len(all_d)==42 and component_equalities==72'),('canonical_equalities==325 and lexicographic_constraints==740','canonical_equalities==234 and lexicographic_constraints==373'),("expected_charges['component_strip_bound_seconds']=load(STRIP/'checks.json')['seconds']","expected_charges['direct_fine_area_bound_seconds']=load(FINE/'checks.json')['seconds'];expected_charges['direct_fine_strip_bound_seconds']=load(STRIP/'checks.json')['seconds']"),("inputs=[Path(__file__),","inputs=[Path(__file__),FINE/'plan.json',FINE/'checks.json',FINE/'audit/plan.json',FINE/'audit/checks.json',"),("'canonical_owner_component_equalities_verified':325,'within_component_lexicographic_order_constraints_verified':740","'canonical_owner_component_equalities_verified':234,'within_component_lexicographic_order_constraints_verified':373"),("'all25_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':80,'component_pair_selectors_verified':25,'count_distribution_selectors_verified':82,'conditional_component_equalities_verified':100","'all18_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':87,'component_pair_selectors_verified':18,'count_distribution_selectors_verified':42,'conditional_component_equalities_verified':72")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
needle="expected=[(gid,r['region']) for gid in geometries for r in unary[gid]['regions']]"
assert s.count(needle)==1
s=s.replace(needle,"expected=[(gid,r['region']) for gid in geometries for r in unary[gid]['regions'] if any(set(r['required_empty_sites'])<=set(sites) for sites in allowed)]")
marker="assert load(MODEL/'checks.json')['preparation_seconds_charged']=="
addition="""pruned=[]
for owner in owners:
    geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    represented={(r['geometry'],r['region']) for r in owner['unary_regions']}
    for gid in geometries:
        for region in unary[gid]['regions']:
            compatible=[sites for sites in allowed if all(site in sites for site in region['required_empty_sites'])]
            assert ((gid,region['region']) in represented)==bool(compatible)
            if not compatible:pruned.append({'owner':owner['owner'],'geometry':gid,'region':region['region'],'required_empty_sites':region['required_empty_sites']})
assert len(pruned)==1876 and load(MODEL/'checks.json')['unary_site_mask_pruned_selectors']==1876
write(OUT/'impossible-unary-mask-choices.json',pruned)
"""
assert marker in s;s=s.replace(marker,addition+marker)
s=s.replace("'all_model_fields_exhaustively_verified':True,","'all_model_fields_exhaustively_verified':True,'pruned_unary_choices_impossible_for_every_retained_site_pair':True,'unary_mask_pruned_selectors_verified':1876,")
p=ROOT/'output/audit_h5_fine_component_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'all_fields_and_mask_pruning_to_be_checked':True})
