from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_fine_component_response_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-fine-components-model-20261029','h5-shared-five-block-20261029'),('len(model.variables)==6520 and len(model.constraints)==32928','len(model.variables)==259 and len(model.constraints)==708'),("response.status==cp_model_pb2.UNKNOWN and result['status']=='UNKNOWN'","response.status==cp_model_pb2.INFEASIBLE and result['status']=='INFEASIBLE'"),("result['returned_response_branches']==39749","result['returned_response_branches']==59"),("result['returned_response_conflicts']==51","result['returned_response_conflicts']==17"),("max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds'])>0","max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds'])==0"),("'status: UNKNOWN'","'status: INFEASIBLE'"),("'solver_status':'UNKNOWN'","'solver_status':'INFEASIBLE'")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
a=s.index("lp_diagnostics = log[");b=s.index("write(OUT/'source-bindings.json'",a)
s=s[:a]+s[b:]
a=s.index("'max_lp_cut_propagations':");b=s.index("'assignments':0",a)
s=s[:a]+s[b:]
s=s.replace("'infeasibility_proven':False,","'infeasibility_proven':False,'restricted_grid_model_solver_reports_infeasible':True,'independent_unsat_certificate_available':False,'continuous_source_domain_excluded':False,'source_valid58':False,")
p=ROOT/'output/audit_h5_shared_five_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'solver_report_is_scoped_to_audited_grid_model':True})
