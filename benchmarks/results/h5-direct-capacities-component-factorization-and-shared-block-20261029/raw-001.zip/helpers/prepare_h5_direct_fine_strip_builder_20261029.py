from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/bound_h5_fine_band_strips_20261029.py').read_text(encoding='utf-8')
changes=[("OUT=ROOT/'output/h5-first55-fine-band-strip-capacity-20261029'","OUT=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029'"),("FILTER=ROOT/'output/h5-first55-strip-filtered-components-20261029'","FILTER=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'"),("FINE=ROOT/'output/h5-first55-fine-band-capacity-20261029'","FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029'"),('all25-filtered-bounds.json','all29-vectorized-bounds.json'),('all25-fine-band-bounds.json','all29-fine-band-bounds.json'),('all18-fine-band-strip-bounds.json','all22-fine-strip-bounds.json')]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/bound_h5_direct_fine_strips_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name})
