from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/seal_h5_fine_band_checkpoint_20261029.py').read_text(encoding='utf-8')
archive=old[old.index('OUT.mkdir();members='):old.index('copies=[')]
archive=archive.replace('for folder in [DIAG,DIAGMATH,BOX,CONVEX,WINMATH,FINE,FINESTRIP,FILTER]:','for folder in [AREA,STRIP,FILTER,BASE,FACTOR,BLOCK,PAIR,DOMAIN]:')
a=archive.index('helpers=set()');b=archive.index('while queue:')
archive=archive[:a]+'''helpers=set()
for pattern in ['*h5*direct_fine*20261029.py','*h5*fine_component*20261029.py','*h5*component_factorization*20261029.py','*h5*shared_five*20261029.py','*h5*direct_block*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
add('publication/prior-push-receipt.json',ROOT/'output/h5-fine-band-main-sync-20261029/receipt.json')
'''+archive[b:]
header='''"""Seal direct capacity regeneration, component factorization and two closed audited calls."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
AREA=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';FILTER=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';BASE=ROOT/'output/h5-first55-fine-components-model-20261029';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';BLOCK=ROOT/'output/h5-shared-five-block-20261029';PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';DOMAIN=ROOT/'output/h5-shared-five-subset-domain-bound-20261029';PUB=BASE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-direct-capacities-component-factorization-and-shared-block-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write(v)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='cf2c4d7de18d5f135b0cd1c6b601fabed3c6be58' and not git('diff','HEAD','--name-only')
assert load(AREA/'audit/checks.json')['passed'] and load(AREA/'audit/checks.json')['necessary_subset_certificates_verified']==50
strip=load(STRIP/'audit/checks.json');assert strip['passed'] and strip['necessary_strip_certificates_verified']==4 and strip['retained_domain_matches_previous_checkpoint']
assert load(FILTER/'audit/checks.json')['passed'] and load(FILTER/'audit/checks.json')['source_and_retained_count_bytes_identical_to_previous_checkpoint']
for folder in [AREA,STRIP]:assert load(folder/'checks.json')['cap_overrun_seconds']==0 and load(folder/'checks.json')['scan_complete']
model=load(BASE/'model-audit/checks.json');assert model['passed'] and model['all_model_fields_exhaustively_verified'] and model['variables_verified']==6520 and model['constraints_verified']==32928 and model['unary_mask_pruned_selectors_verified']==1876 and model['pruned_unary_choices_impossible_for_every_retained_site_pair']
response=load(BASE/'response-audit/checks.json');assert response['passed'] and response['solver_status']=='UNKNOWN' and response['closed_solver_calls']==1 and response['assignments']==0 and response['source_checker_calls']==response['native_calls']==0 and response['solve_slice_overrun_seconds']>0 and response['overall_algorithm_shared_overruns_seconds']==0
factor=load(FACTOR/'audit/checks.json');assert factor['passed'] and factor['model_clearance_preserved_between_blocks'] and factor['all_support_band_rectangle_pairs_verified']==7856737 and factor['site_choices_with_independent_blocks']==8 and factor['count_distributions_with_independent_blocks']==23
block=load(BLOCK/'model-audit/checks.json');assert block['passed'] and block['all_model_fields_exhaustively_verified'] and block['variables_verified']==259 and block['constraints_verified']==708 and block['every_compatible_use_has_identical_source_options']
blockresponse=load(BLOCK/'response-audit/checks.json');assert blockresponse['passed'] and blockresponse['solver_status']=='INFEASIBLE' and blockresponse['closed_solver_calls']==1 and blockresponse['assignments']==0 and blockresponse['source_checker_calls']==blockresponse['native_calls']==0 and blockresponse['overall_algorithm_shared_overruns_seconds']==0 and not blockresponse['independent_unsat_certificate_available'] and not blockresponse['continuous_source_domain_excluded']
domain=load(DOMAIN/'audit/checks.json');assert domain['passed'] and domain['necessary_pair_incompatibilities_verified']==835 and domain['exact_subset_certificates_verified']==90422 and domain['subset_excluded_option_multisets']==102322 and domain['necessary_option_multisets_remaining']==36802 and not domain['continuous_source_block_excluded']
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-fine-band-capacities-and-spatial-diagnostics-20261029/publication-review.json');production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];remote=load(PUB/'main.json')['commit']['sha'];assert remote==ci['head_sha']==head and ci['id']==40846115291 and ci['status']=='completed' and ci['conclusion']=='success'
assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
'''
footer='''copies=[(AREA/'checks.json','direct-area-preparation.json'),(AREA/'audit/checks.json','direct-area-audit.json'),(STRIP/'checks.json','direct-strip-preparation.json'),(STRIP/'audit/checks.json','direct-strip-audit.json'),(FILTER/'checks.json','filtered-count-preparation.json'),(FILTER/'audit/checks.json','filtered-count-audit.json'),(BASE/'model/checks.json','model.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'model/preparation-charges.json','preparation-charges.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/lp-diagnostics.txt','lp-diagnostics.txt'),(FACTOR/'checks.json','factorization-preparation.json'),(FACTOR/'audit/checks.json','factorization-audit.json'),(FACTOR/'all18-factorizations.json','all18-factorizations.json'),(BLOCK/'model/checks.json','shared-block-model.json'),(BLOCK/'model-audit/checks.json','shared-block-model-audit.json'),(BLOCK/'response-audit/checks.json','shared-block-response-audit.json'),(PAIR/'checks.json','shared-pair-domain-preparation.json'),(DOMAIN/'checks.json','shared-subset-domain-preparation.json'),(DOMAIN/'audit/checks.json','shared-domain-audit.json'),(BASE/'next-step.json','next-step.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':remote,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40846115291,'main_all6_pass':True,'successful_jobs_at_snapshot':6,'normal_push_still_requires_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'direct_capacities_preserve_source_count_bytes':True,'remaining_count_distributions':42,'restricted_site_pairs_remaining':18,'pruned_unary_choices_verified':1876,'global_model_fields_exhaustively_verified':True,'shared_block_model_fields_exhaustively_verified':True,'closed_new_solver_calls':2,'global_model_status':'UNKNOWN','shared_block_grid_model_status':'INFEASIBLE','independent_unsat_certificate_available':False,'assignments':0,'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,'independent_component_distributions':23,'source_option_subset_certificates_verified':90422,'shared_five_block_option_multisets_remaining':36802,'source_checker_calls':0,'native_calls':0,'continuous_source_block_excluded':False,'new_count_distribution_exclusions':0,'new_restricted_site_exclusions':0,'new_allocation_exclusions':0,'remaining_candidates':440,'source_valid_short11_preserved':True,'valid64_preserved':True,'source_valid66_created':False,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [fine-band capacities and spatial diagnostics](../benchmarks/results/h5-fine-band-capacities-and-spatial-diagnostics-20261029.md).';new=f'Latest H5 evidence: [direct capacities, component factorization and shared block](../benchmarks/results/{NAME}.md).';assert s.count(old)==1
with status.open('w',encoding='utf-8',newline='\\n') as f:f.write(s.replace(old,new,1))
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'closed_calls':2,'remaining_count_distributions':42,'restricted_site_pairs_remaining':18,'shared_block_option_multisets':36802,'remaining_allocations':440,'completion_percent':60})
'''
s=header+archive+footer;p=ROOT/'output/seal_h5_direct_block_checkpoint_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
v=(ROOT/'output/verify_h5_fine_band_archive_20261029.py').read_text(encoding='utf-8').replace('h5-fine-band-capacities-and-spatial-diagnostics-20261029','h5-direct-capacities-component-factorization-and-shared-block-20261029')
with (ROOT/'output/verify_h5_direct_block_archive_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(v)
print({'prepared':p.name})
