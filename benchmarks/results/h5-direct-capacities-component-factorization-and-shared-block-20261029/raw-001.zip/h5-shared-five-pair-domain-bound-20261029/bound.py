"""Necessary continuous-region pair compatibility for the common five-part source block."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BLOCK=ROOT/'output/h5-shared-five-block-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';OUT=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BLOCK/'model-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter();keys=load(BLOCK/'model/mapping.json')['source_options'];unary=load(PRIOR/'integer-preparation/unary-templates.json');inner=load(GENERIC/'source-inner-rectangles.json');required=F(load(FIRST/'plan.json')['required_pair_gap_mm']);q=F(149,1000);assert 2*q*q<required*required
nodes=[]
for family,mode,gid,ri in keys:
    source=next(r for r in unary[gid]['regions'] if r['region']==ri);p=[tuple(map(F,v)) for v in source['hull_vertices']];bounds=[min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)];boxes=[tuple(map(F,b)) for b in inner[family][mode]]
    nodes.append({'key':[family,mode,gid,ri],'bounds':bounds,'boxes':boxes})
compatible=[0]*len(nodes);conflicts=[]
for ai,A in enumerate(nodes):
    for bi in range(ai,len(nodes)):
        B=nodes[bi];a,b=A['bounds'],B['bounds'];witness=None
        for api,ap in enumerate(A['boxes']):
            for bpi,bp in enumerate(B['boxes']):
                gaps=[b[2]+bp[0]-a[0]-ap[2],a[2]+ap[0]-b[0]-bp[2],b[3]+bp[1]-a[1]-ap[3],a[3]+ap[1]-b[1]-bp[3]]
                if max(gaps)<q:witness={'nodes':[ai,bi],'pieces':[api,bpi],'maximum_axis_gaps_mm':[str(v) for v in gaps]};break
            if witness:break
        if witness:conflicts.append(witness)
        else:compatible[ai]|=1<<bi;compatible[bi]|=1<<ai
br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];ins_mask=sum(1<<i for i in ins);pair_records=[];count=0;sample=None;complete=True
for ia,a in enumerate(br):
    for b in br[ia:]:
        if time.perf_counter()-started>=58:complete=False;break
        if not compatible[a]>>b&1:continue
        candidates=ins_mask&compatible[a]&compatible[b];triples=0
        for i in ins:
            if not candidates>>i&1:continue
            later=candidates&compatible[i]&~((1<<i)-1)
            while later:
                bit=later&-later;j=bit.bit_length()-1;later^=bit;last=candidates&compatible[i]&compatible[j]&~((1<<j)-1);n=last.bit_count();triples+=n
                if n and sample is None:sample=[a,b,i,j,(last&-last).bit_length()-1]
        pair_records.append({'bracket_nodes':[a,b],'candidate_insert_nodes_hex':hex(candidates),'compatible_insert_triples':triples});count+=triples
    if not complete:break
elapsed=time.perf_counter()-started
inputs=[Path(__file__),BLOCK/'model/plan.json',BLOCK/'model/mapping.json',BLOCK/'model-audit/plan.json',BLOCK/'model-audit/checks.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',GENERIC/'plan.json',GENERIC/'audit/plan.json',GENERIC/'audit/checks.json',GENERIC/'source-inner-rectangles.json',FIRST/'plan.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use original continuous source-hull translation extrema, never the inward-rounded local grid. For every mode/region option pair, bound the largest possible gap in all four axis directions for each pair of contained source rectangles. A Euclidean gap at least the required source gap implies an L-infinity gap at least0.149mm because2*(0.149)^2 is strictly smaller than the required squared gap. If one rectangle pair cannot reach that gap in any axis direction, the two options are incompatible. Enumerate every nondecreasing two-bracket/three-insert option multiset in the resulting necessary compatibility graph, including repeat options when self-compatible. Zero survivors is a source-construction exclusion only after independent audit; any survivor is only a necessary-domain witness, not a placement.','necessary_axis_gap_mm':str(q),'required_euclidean_gap_mm':str(required),'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_domain_retained':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'nodes.json',[{'key':n['key'],'translation_bounds_mm':[str(v) for v in n['bounds']],'contained_rectangles_mm':[[str(v) for v in b] for b in n['boxes']]} for n in nodes]);write(OUT/'conflicts.json',conflicts);write(OUT/'compatibility.json',[hex(v) for v in compatible]);write(OUT/'bracket-pair-counts.json',pair_records)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'enumeration_complete':complete,'nodes':len(nodes),'bracket_nodes':len(br),'insert_nodes':len(ins),'pair_incompatibilities':len(conflicts),'compatible_bracket_pairs':len(pair_records),'necessary_option_multisets_remaining':count,'sample_necessary_option_multiset':sample,'source_block_excluded_pending_independent_audit':complete and count==0,'independent_audit_required':True,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
