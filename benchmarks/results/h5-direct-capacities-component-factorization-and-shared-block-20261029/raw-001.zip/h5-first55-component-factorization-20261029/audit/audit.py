"""Independent all-band-pair integer distance audit of component factorization."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-component-factorization-20261029';OUT=BASE/'audit';COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
inner=load(GENERIC/'source-inner-rectangles.json');rects=load(GEO/'mode-rectangles.json');extension=load(BASE/'piece-extension-bounds.json');checked=[]
for family,modes in rects.items():
    for mode in modes:
        for piece,record in enumerate(mode['rectangles']):
            l,b,r,t=map(F,inner[family][mode['mode']][piece]);L,B,R,T=[F(v,10) for v in record['outward_offsets_grid']]
            assert all(l-F(3,20)<=x<=r+F(3,20) and b-F(3,20)<=y<=t+F(3,20) for x in [L,R] for y in [B,T])
            actual=max(max(F(0),l-x,x-r,b-y,y-t) for x in [L,R] for y in [B,T])
            checked.append({'family':family,'mode':mode['mode'],'piece':piece,'maximum_extension_mm':str(actual)})
assert extension==checked and len(extension)==20
source=load(COUNT/'all18-filtered-bounds.json');fine={tuple(r['empty_sites']):r for r in load(FINE/'all29-fine-band-bounds.json')};rows=load(BASE/'all18-factorizations.json');assert len(rows)==len(source)==18
distances=[];pair_count=band_pair_count=nonedges=split_choices=split_counts=0;largest=[]
for row,src in zip(rows,source):
    assert row['empty_sites']==src['empty_sites'] and row['groups']==[[g['family'],g['family_component']] for g in src['groups']]
    supports=[g['band_spans_tenths_mm'] for g in fine[tuple(row['empty_sites'])]['groups']]
    rectangles=[np.array([(lo,20*y,hi,20*(y+1)) for y,lo,hi in bands],dtype=np.int64) for bands in supports]
    edges=[];parent=list(range(len(rectangles)))
    def root(i):
        while parent[i]!=i:i=parent[i]
        return i
    for a,A in enumerate(rectangles):
        for b in range(a+1,len(rectangles)):
            B=rectangles[b]
            dx=np.maximum(0,np.maximum(A[:,0,None]-B[None,:,2],B[None,:,0]-A[:,2,None]))
            dy=np.maximum(0,np.maximum(A[:,1,None]-B[None,:,3],B[None,:,1]-A[:,3,None]))
            minimum=int(np.min(np.maximum(dx,dy)));pair_count+=1;band_pair_count+=len(A)*len(B)
            if minimum<=6:edges.append([a,b]);parent[root(b)]=root(a)
            else:nonedges+=1
            distances.append({'empty_sites':row['empty_sites'],'groups':[a,b],'minimum_support_Linf_distance_tenths_mm':minimum})
    assert [e['groups'] for e in row['interaction_edges']]==edges
    for e in row['interaction_edges']:
        a,b=e['groups'];y,lo,hi,yy,l,h=e['support_band_witness'];assert [y,lo,hi] in supports[a] and [yy,l,h] in supports[b]
        assert max(0,lo-h,l-hi,20*y-20*(yy+1),20*yy-20*(y+1))<=6
    blocks={}
    for i in range(len(rectangles)):blocks.setdefault(root(i),[]).append(i)
    blocks=sorted(blocks.values(),key=lambda v:v[0]);assert row['independent_blocks']==blocks
    assert [r['counts'] for r in row['distributions']]==src['remaining_distributions']
    for record in row['distributions']:
        counts=record['counts'];totals=[sum(counts[i] for i in block) for block in blocks]
        families=[{f:sum(counts[i] for i in block if src['groups'][i]['family']==f) for f in ['bracket','insert']} for block in blocks]
        assert record['block_copy_totals']==totals and record['block_family_totals']==families and record['largest_block_copies']==max(totals) and sum(totals)==13
        if len(blocks)>1:largest.append(max(totals))
    if len(blocks)>1:split_choices+=1;split_counts+=len(row['distributions'])
assert split_choices==8 and split_counts==23 and [min(largest),max(largest)]==[8,11]
write(OUT/'exact-group-distances.json',distances);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','piece-extension-bounds.json','all18-factorizations.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'outward_piece_extension_bounds_verified':20,'maximum_piece_extension_mm':str(max(F(v['maximum_extension_mm']) for v in extension)),'model_clearance_preserved_between_blocks':True,'support_separation_mm':'3/5','piece_extension_limit_mm':'3/20','required_model_gap_mm':'3/10','group_pairs_verified':pair_count,'all_support_band_rectangle_pairs_verified':band_pair_count,'noninteracting_group_pairs_verified':nonedges,'site_choices':18,'count_distributions':42,'site_choices_with_independent_blocks':split_choices,'count_distributions_with_independent_blocks':split_counts,'split_largest_block_copy_range':[8,11],'existence_of_block_placements_proven':False,'new_count_exclusions':0,'new_restricted_site_exclusions':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
