"""Conservative support-separation graph for independently placeable component blocks."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';OUT=ROOT/'output/h5-first55-component-factorization-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert all(load(p/'audit/checks.json')['passed'] for p in [COUNT,FINE]) and load(GEO/'geometry-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
inner=load(GENERIC/'source-inner-rectangles.json');model_rects=load(GEO/'mode-rectangles.json');margins=[]
for family,modes in model_rects.items():
    for mode in modes:
        for piece,record in enumerate(mode['rectangles']):
            box=list(map(F,inner[family][mode['mode']][piece]));outer=[F(v,10) for v in record['outward_offsets_grid']]
            extension=max(F(0),box[0]-outer[0],box[1]-outer[1],outer[2]-box[2],outer[3]-box[3]);assert extension<=F(3,20)
            margins.append({'family':family,'mode':mode['mode'],'piece':piece,'maximum_extension_mm':str(extension)})
fine={tuple(r['empty_sites']):r for r in load(FINE/'all29-fine-band-bounds.json')};rows=[];split_choices=split_counts=0
for source in load(COUNT/'all18-filtered-bounds.json'):
    groups=source['groups'];proof=fine[tuple(source['empty_sites'])];supports=[]
    for g in proof['groups']:
        byrow={}
        for y,lo,hi in g['band_spans_tenths_mm']:byrow.setdefault(y,[]).append((lo,hi))
        supports.append(byrow)
    edges=[]
    for a in range(len(groups)):
        for b in range(a+1,len(groups)):
            witness=None
            for y,spans in supports[a].items():
                for yy in [y-1,y,y+1]:
                    for lo,hi in spans:
                        for l,h in supports[b].get(yy,[]):
                            if lo<=h+6 and l<=hi+6:witness=[y,lo,hi,yy,l,h];break
                        if witness:break
                    if witness:break
                if witness:break
            if witness:edges.append({'groups':[a,b],'support_band_witness':witness})
    unseen=set(range(len(groups)));blocks=[]
    while unseen:
        start=min(unseen);unseen.remove(start);block={start};queue=[start]
        while queue:
            u=queue.pop()
            for e in edges:
                a,b=e['groups'];v=b if a==u else a if b==u else None
                if v in unseen:unseen.remove(v);block.add(v);queue.append(v)
        blocks.append(sorted(block))
    distributions=[]
    for counts in source['remaining_distributions']:
        totals=[sum(counts[i] for i in block) for block in blocks];families=[{f:sum(counts[i] for i in block if groups[i]['family']==f) for f in ['bracket','insert']} for block in blocks]
        distributions.append({'counts':counts,'block_copy_totals':totals,'block_family_totals':families,'largest_block_copies':max(totals)})
    if len(blocks)>1:split_choices+=1;split_counts+=len(distributions)
    rows.append({'empty_sites':source['empty_sites'],'groups':[[g['family'],g['family_component']] for g in groups],'interaction_edges':edges,'independent_blocks':blocks,'distributions':distributions})
elapsed=time.perf_counter()-started;inputs=[Path(__file__),COUNT/'plan.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all18-filtered-bounds.json',FINE/'plan.json',FINE/'audit/plan.json',FINE/'audit/checks.json',FINE/'all29-fine-band-bounds.json',GENERIC/'plan.json',GENERIC/'audit/plan.json',GENERIC/'audit/checks.json',GENERIC/'source-inner-rectangles.json',GEO/'geometry-audit/plan.json',GEO/'geometry-audit/checks.json',GEO/'mode-rectangles.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Connect two source component groups when any conservative fine-band rectangles have L-infinity distance at most0.6mm. A possible close pair can only use the same or neighboring2mm rows; test their X intervals with exact0.1mm integers. Distinct graph components have all support points more than0.6mm apart. Every outward model piece lies within0.15mm L-infinity expansion of its audited contained source rectangle. Therefore any two model pieces in different graph components are more than0.3mm apart and satisfy the model axis-separation clearance. For a fixed site pair and count distribution, the graph components can be placed independently, then combined; the existence of any such placement is not established here.','support_separation_mm':'3/5','maximum_piece_extension_mm':'3/20','model_pair_clearance_mm':'3/10','solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'piece-extension-bounds.json',margins);write(OUT/'all18-factorizations.json',rows)
checks={'passed':True,'seconds':elapsed,'piece_extension_bounds_verified':len(margins),'maximum_piece_extension_mm':str(max(F(r['maximum_extension_mm']) for r in margins)),'site_choices':len(rows),'count_distributions':sum(len(r['distributions']) for r in rows),'site_choices_with_independent_blocks':split_choices,'count_distributions_with_independent_blocks':split_counts,'split_largest_block_copy_range':[min(d['largest_block_copies'] for r in rows if len(r['independent_blocks'])>1 for d in r['distributions']),max(d['largest_block_copies'] for r in rows if len(r['independent_blocks'])>1 for d in r['distributions'])],'independent_audit_required':True,'new_count_exclusions':0,'new_restricted_site_exclusions':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
