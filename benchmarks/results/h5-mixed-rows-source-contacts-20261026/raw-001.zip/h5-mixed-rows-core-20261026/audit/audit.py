"""Read original vertices, verify exact inventory and all core pairs, compare history."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-core-20261026';OUT=BASE/'audit';SRC=ROOT/'output/h5-source-orientation-construction-20261025';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};rows=load(BASE/'placements.json');first=[p for p in rows if p['sheet_id']=='sheet-0'];short=[p for p in rows if p['sheet_id']=='sheet-1'];assert len(first)==18 and len(short)==15 and short==load(ROOT/'output/h5-nine-insert-short-sheet-20261026/short-sheet-placements.json')
stocks=[[float(F(*v)) for v in r] for r in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);shapes={};stock=[];holes=vertices=0
def rings(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;x,y=t['translation'];g=parts[p['part_id']]['geometry'][0]
    return [[(m*u*c-v*s+x,m*u*s+v*c+y) for u,v in ring] for ring in [g['outer']]+g.get('holes',[])]
for p in rows:
    i=ids[p['part_id'],p['copy_index']];assert i not in shapes;t=p['transform'];part=parts[p['part_id']];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);r=rings(p);g=Polygon(r[0]);full=Polygon(r[0],r[1:]);assert g.is_valid and full.is_valid;assert abs(g.area-Polygon(part['geometry'][0]['outer']).area)<1e-6;assert abs(full.area-Polygon(part['geometry'][0]['outer'],part['geometry'][0].get('holes',[])).area)<1e-6
    sheet=int(p['sheet_id'].split('-')[1]);st=stocks[sheet];b=g.bounds;extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;stock.append({'original':i,'extra_mm':extra});shapes[i]=(sheet,g);holes+=len(r)-1;vertices+=sum(len(h) for h in r[1:])
    if sheet==0:
        assert i<18 and not t['mirrored']
        if i<12:row,col=divmod(i,4);x=F('6.525')+col*F('350.225');y=F('6.525')+row*F('450.225');a=math.pi/2
        else:row,col=divmod(i-12,3);x=F('6.525')+col*F('450.225');y=F('1357.2')+row*F('350.225');a=0.
        assert t['rotation_radians']==a and max(abs(b[0]-float(x)),abs(b[1]-float(y)))<1e-9
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>required;pairs.append({'originals':[i,j],'distance_mm':d})
remaining=sorted(set(range(66))-set(shapes));assert remaining==[18,19,20,23,24,27]+list(range(38,50))+list(range(51,66))==load(BASE/'mandatory-remaining-originals.json')
history=ROOT/'output/h5-expanded-frame-group-coverage-20261023/mapping.json';mapping=load(history);source=ROOT/mapping['source_pool'];oldpool=load(source)
def key(p):return (p['sheet_id'],*(round(x,6) for x in Polygon(rings(p)[0]).bounds))
newkeys=sorted(key(p) for p in first);matches=[];compared=[]
for group in mapping['frame_groups']:
    placements=[oldpool[i]['placement'] for i in group['candidates']];keys=sorted(key(p) for p in placements);same=keys==newkeys
    compared.append({'group':group['index'],'same_bounds_at_1e_6_mm':same,'sources':group['sources']})
    if same:matches.append(group['index'])
write(OUT/'historical-comparison.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [history,source]},'groups_compared':len(compared),'matching_groups':matches,'comparison':'sorted sheet and original-filled-outer bounds rounded to 1e-6 mm; this is a topology/placement diagnostic, not a bitwise transform assertion','groups':compared})
inventory={'fixed_first_originals':list(range(18)),'fixed_first_placements':first,'fixed_short_originals':sorted(ids[p['part_id'],p['copy_index']] for p in short),'fixed_short_placements':short,'mandatory_moving_first_originals':remaining,'mandatory_moving_first_cogs':list(range(51,66)),'mandatory_moving_first_noncogs':remaining[:18],'mandatory_moving_family_counts':{'bracket':6,'insert':12,'cog':15},'all33_movers_mandatory':True,'all66_originals_accounted_once':True,'old_domains_or_exclusions_transferred':False}
write(OUT/'next-neighborhood.json',inventory);write(OUT/'pairs.json',pairs);write(OUT/'stock.json',stock)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_verified':33,'fixed_first_originals':18,'fixed_short_originals':15,'mandatory_remaining_counts':inventory['mandatory_moving_family_counts'],'same_sheet_pairs':len(pairs),'stock_edge_checks':4*len(rows),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'minimum_extra_stock_mm':min(min(p['extra_mm']) for p in stock),'highest_fixed_first_y_mm':max(g.bounds[3] for s,g in shapes.values() if s==0),'historical_matching_frame_groups':matches,'all66_originals_accounted_once':True,'old64_partials_preserved':True,'part_in_hole_used':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
