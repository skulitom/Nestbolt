"""Illustrate the checked33-original core without implying a complete layout."""
from pathlib import Path
import json,math,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Patch
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-core-20261026';OUT=BASE/'visual';OUT.mkdir()
load=lambda p:json.loads(p.read_bytes())
assert load(BASE/'audit/checks.json')['passed'];shutil.copyfile(__file__,OUT/'plot.py')
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};poses=load(BASE/'placements.json');colors={'frame':'#74A9CF','bracket':'#F3A353','insert':'#7CBF9D'}
fig=plt.figure(figsize=(8,11),facecolor='white');grid=fig.add_gridspec(2,1,height_ratios=[3000,325.92690233],hspace=.25);axes=[fig.add_subplot(grid[i]) for i in range(2)]
for ax,sheet,height in zip(axes,['sheet-0','sheet-1'],[3000,325.92690233]):
    ax.add_patch(Rectangle((0,0),1500,height,facecolor='#F6F7FA',edgecolor='#384355',linewidth=1))
    for p in poses:
        if p['sheet_id']!=sheet:continue
        t=p['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        def transform(points):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in points]
        for shape in parts[p['part_id']]['geometry']:
            ax.add_patch(Polygon(transform(shape['outer']),closed=True,facecolor=colors[p['part_id']],edgecolor='#243245',linewidth=.6))
            for hole in shape['holes']:ax.add_patch(Polygon(transform(hole),closed=True,facecolor='#F6F7FA',edgecolor='#243245',linewidth=.35))
    ax.set(xlim=(-10,1510),ylim=(-10,height+10),aspect='equal',xlabel='mm',ylabel='mm')
    ax.tick_params(labelsize=8);ax.spines[['top','right']].set_visible(False)
axes[0].set_title('First sheet: 18 frames; all 33 movers still required',fontsize=11)
axes[1].set_title('Preserved short sheet: 6 brackets, 9 inserts',fontsize=11)
fig.suptitle('Mixed-row construction: 33 of 66 originals',fontsize=14,y=.98)
fig.legend(handles=[Patch(facecolor=v,label=k.title()) for k,v in colors.items()],loc='upper center',bbox_to_anchor=(.5,.952),ncol=3,frameon=False)
fig.text(.5,.02,'6 brackets, 12 inserts and 15 cogs remain mandatory. Holes stay reserved for packing.\nThis core is an alternative to the earlier 64-part partial, not a complete fit.',ha='center',fontsize=9)
fig.subplots_adjust(top=.90,bottom=.10)
fig.savefig(OUT/'core.png',dpi=160);plt.close(fig);print(str(OUT/'core.png'))
