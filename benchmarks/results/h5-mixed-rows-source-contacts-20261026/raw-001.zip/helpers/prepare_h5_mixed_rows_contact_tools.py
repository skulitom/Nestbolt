"""Derive a new bounded source experiment; do not execute or reopen prior calls."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
def replace(s,a,b):
    assert a in s,a[:100]
    return s.replace(a,b)
def save(name,s):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'build_h5_staggered_core_contact_pool.py').read_text()
s=replace(s,'h5-staggered-core-contact-pool-20261026','h5-mixed-rows-contact-pool-20261026');s=replace(s,'h5-staggered-frame-bracket-core-repaired-20261026','h5-mixed-rows-core-20261026')
s=replace(s,"caps={'cog':1400,'bracket':300,'insert':300}","caps={'cog':2200,'bracket':1000,'insert':1000}")
a=s.index("'method':'New fixed26/");b=s.index("})\ndef shape",a)
s=s[:a]+"'method':'New mixed-row eighteen-frame core and unchanged short fifteen. All33 movers remain mandatory:6 brackets,12 inserts,15 cogs. Fixed-boundary seeds and independent source-cog radial closure are followed by contacts around64 spread cog parents, reserving noncog quota for mutual bracket/insert contacts around64 stratified parents. Reject obstacle interior representatives and require distance from the generating parent before applying any candidate quota. Cog-parent stage admits at most450 per noncog family; mutual contacts may fill the1000 caps. Every candidate must satisfy the current18 fixed filled outers and stock. Spatial25mm bins and orientation phases are finite sampling, not unrestricted coverage. Retain all proposal queues and rejection counts. A fresh full original-pair graph and independent readback must precede one exact6/12/15 joint call. No inherited source exclusions or solver retries. No native call for incomplete layouts.'"+s[b:]
s=replace(s,"def consider(p,origin):\n    family=p['part_id'];key=identity(p)","def consider(p,origin):\n    family=p['part_id'];key=identity(p)\n    if origin['kind'] in ['noncog_contact','mutual_contact']:\n        if origin.get('proposal_kind')=='representative':return None,'obstacle_interior'\n        if shape(p).distance(shape(pool[origin['parent']]['placement']))<=required:return None,'generating_parent_conflict'")
s=replace(s,"if counts[o['family']]>=caps[o['family']]:pending.setdefault('capped_noncog_contact_lists'","if counts[o['family']]>=450:pending.setdefault('capped_noncog_contact_lists'")
s=replace(s,"'orientation':oi,'proposal':k})","'orientation':oi,'proposal':k,'proposal_kind':q['proposals'][k]['kind']})")
a=s.index("pending['unfinished_noncog_contact_lists']=list(q2);write(OUT/'candidates.json'")
b=s.index("write(OUT/'result.json'",a)
extra="""pending['unfinished_noncog_contact_lists']=list(q2)
# Source contacts among noncogs reserve room for interlocking bracket pairs and inserts.
mutual_parents=[]
for oi in range(4,len(orient)):
    o=orient[oi];ids=sorted([r['index'] for r in pool if r['placement']['part_id']==o['family'] and r['placement']['transform']['rotation_radians']==o['angle'] and r['placement']['transform']['mirrored']==o['mirrored']],key=lambda i:(shape(pool[i]['placement']).bounds[1],shape(pool[i]['placement']).bounds[0]))
    quota=4 if o['family']=='bracket' else 16
    mutual_parents.extend((ids[k],oi) for k in sorted(set(np.linspace(0,len(ids)-1,min(quota,len(ids)),dtype=int).tolist())))
write(OUT/'mutual-parent-indices.json',mutual_parents);mutual={}
for ai in sorted(set(oi for _,oi in mutual_parents)):
    for bi in range(4,len(orient)):
        if time.perf_counter()>=deadline:pending.setdefault('unbuilt_mutual_queries',[]).append([ai,bi]);continue
        obstacle=geom.obstacle(shape(pose(orient[ai],[0.,0.])),shape(pose(orient[bi],[0.,0.])),.225);q={'parent_orientation':ai,'child_orientation':bi,'geometry':mapping(obstacle),'proposals':proposals(obstacle)};mutual[ai,bi]=q;write(OUT/'regions'/f'mutual-{ai:02d}-{bi:02d}.json',q)
q3=deque((parent,ai,bi,0) for parent,ai in mutual_parents for bi in range(4,len(orient)) if (ai,bi) in mutual and mutual[ai,bi]['proposals'])
while q3 and time.perf_counter()<deadline:
    parent,ai,bi,k=q3.popleft();o=orient[bi];q=mutual[ai,bi]
    if counts[o['family']]>=caps[o['family']]:pending.setdefault('capped_mutual_lists',[]).append([parent,ai,bi,k]);continue
    xy=q['proposals'][k]['point'];translation=pool[parent]['placement']['transform']['translation'];attempt(pose(o,[xy[d]+translation[d] for d in range(2)]),{'kind':'mutual_contact','parent':parent,'parent_orientation':ai,'orientation':bi,'proposal':k,'proposal_kind':q['proposals'][k]['kind']})
    if k+1<len(q['proposals']):q3.append((parent,ai,bi,k+1))
pending['unfinished_mutual_lists']=list(q3);write(OUT/'candidates.json',pool);write(OUT/'events.json',events);write(OUT/'pending.json',pending)
"""
s=s[:a]+extra+s[b:]
s=replace(s,"'fixed_first_originals':26","'fixed_first_originals':18");s=replace(s,"'mandatory_moving_counts':{'bracket':3,'insert':7,'cog':15}","'mandatory_moving_counts':{'bracket':6,'insert':12,'cog':15},'mutual_queries':len(mutual),'mutual_parents':len(mutual_parents)")
s=replace(s,'all25 remaining originals','all33 remaining originals')
save('build_h5_mixed_rows_contact_pool.py',s)
s=(O/'build_h5_staggered_contact_graph.py').read_text().replace('h5-staggered-core-contact-pool-20261026','h5-mixed-rows-contact-pool-20261026').replace('assert n==2000','assert 0<n<=4200').replace('for2000 fresh poses','for the fresh mixed-row poses')
save('build_h5_mixed_rows_contact_graph.py',s)
s=(O/'audit_h5_staggered_contact_graph_repaired.py').read_text().replace('h5-staggered-core-contact-pool-20261026','h5-mixed-rows-contact-pool-20261026').replace('h5-staggered-frame-bracket-core-repaired-20261026','h5-mixed-rows-core-20261026').replace("OUT=BASE/'audit-provenance-repaired'","OUT=BASE/'audit'").replace("{'bracket':3,'insert':7,'cog':15}","{'bracket':6,'insert':12,'cog':15}")
a=s.index("        if query[name]['proposals'][o['proposal']]['kind']=='representative'");b=s.index("    else:raise AssertionError(o)",a)
s=s[:a]+"""        assert query[name]['proposals'][o['proposal']]['kind']!='representative' and g.distance(shapes[o['parent']])>required
    elif o['kind']=='mutual_contact':
        assert o['parent']<i and p['part_id'] in ['bracket','insert'];name=f"mutual-{o['parent_orientation']:02d}-{o['orientation']:02d}.json"
        if name not in query:query[name]=load(BASE/'regions'/name)
        point=query[name]['proposals'][o['proposal']]['point'];parent=pool[o['parent']]['placement'];a=parent['transform']['translation'];assert max(abs(t['translation'][k]-a[k]-point[k]) for k in range(2))<1e-9;orientation=plan['orientations'][o['orientation']];po=plan['orientations'][o['parent_orientation']];pt=parent['transform'];assert pt['rotation_radians']==po['angle'] and pt['mirrored']==po['mirrored'] and parent['part_id']==po['family'];assert t['rotation_radians']==orientation['angle'] and t['mirrored']==orientation['mirrored']
        assert query[name]['proposals'][o['proposal']]['kind']!='representative' and g.distance(shapes[o['parent']])>required
"""+s[b:]
s=replace(s,"assert counts=={'cog':1400,'bracket':300,'insert':300};n=len(pool)","assert dict(counts)==load(BASE/'result.json')['candidate_counts'] and all(counts[f]<=plan['candidate_caps'][f] for f in counts);n=len(pool)")
s=replace(s,"conflicts==result['conflicts']==573329 and paircount==1999000","conflicts==result['conflicts'] and paircount==n*(n-1)//2")
s=replace(s,"'fixed_original_pair_checks':26*n","'fixed_original_pair_checks':18*n")
s=s.replace("BASE/'graph/cliques.json'","BASE/'fast-cover/cliques.json'").replace("BASE/'graph/residual-pairs.json'","BASE/'fast-cover/residual-pairs.json'").replace('for record in [plan,graphplan]:',"for record in [plan,graphplan,load(BASE/'fast-cover/plan.json')]:")
save('audit_h5_mixed_rows_contact_graph.py',s)
s=(O/'prepare_h5_staggered_contact_selection.py').read_text().replace('h5-staggered-core-contact-pool-20261026','h5-mixed-rows-contact-pool-20261026').replace('h5-staggered-frame-bracket-core-repaired-20261026','h5-mixed-rows-core-20261026').replace('audit-provenance-repaired','audit').replace("{'bracket':3,'insert':7,'cog':15}","{'bracket':6,'insert':12,'cog':15}").replace(';assert not left;',';').replace('original25-mover','original33-mover').replace('All2000 candidate','All fresh candidate').replace('require3 brackets,7 inserts','require6 brackets,12 inserts').replace('current26 first-sheet','current18 first-sheet')
s=replace(s,"assert model.validate()==''", "for i,j in left:model.add_at_most_one([variables[i],variables[j]])\nassert model.validate()==''")
s=replace(s,"assert expected==saved", "for i,j in left:expected.constraints.add().at_most_one.literals.extend([i,j])\nassert expected==saved")
s=replace(s,'assert covered==graph',"for i,j in left:assert (graph[i]>>j)&1;covered[i]|=1<<j;covered[j]|=1<<i\nassert covered==graph")
s=s.replace("BASE/'graph/cliques.json'","BASE/'fast-cover/cliques.json'").replace("BASE/'graph/residual-pairs.json'","BASE/'fast-cover/residual-pairs.json'")
save('prepare_h5_mixed_rows_contact_selection.py',s)
s=(O/'run_h5_staggered_contact_selection.py').read_text().replace('h5-staggered-core-contact-pool-20261026','h5-mixed-rows-contact-pool-20261026').replace('all25_movers_mandatory','all33_movers_mandatory')
save('run_h5_mixed_rows_contact_selection.py',s)
print('Prepared five new tools; no experiment executed.')
