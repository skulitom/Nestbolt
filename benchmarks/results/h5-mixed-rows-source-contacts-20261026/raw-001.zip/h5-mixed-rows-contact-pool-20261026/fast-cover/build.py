"""Linear bitset clique extension for the saved graph; preserve its initial cover."""
from pathlib import Path
from hashlib import sha256
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-contact-pool-20261026';OUT=BASE/'fast-cover';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();n=len(load(BASE/'candidates.json'));nb=(n+7)//8;raw=gzip.decompress((BASE/'graph/graph.bin.gz').read_bytes());graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];remaining=list(graph);cliques=load(BASE/'graph/cliques.json')
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'graph/graph.bin.gz',BASE/'graph/cliques.json',BASE/'graph/result.json']},'cover_seconds_limit':30,'method':'Keep every original candidate and conflict. Extend the initial saved clique cover with first-bit greedy cliques seeded by descending original degree. Each added clique is verified against the original graph. Any remaining uncovered edge is retained as an explicit binary exclusion. This changes compression only, not finite source feasibility, and makes no solver call.'})
def remove(clique):
    mask=sum(1<<i for i in clique)
    for i in clique:assert graph[i]&(mask^(1<<i))==mask^(1<<i);remaining[i]&=~mask
for clique in cliques:remove(clique)
old=len(cliques);deadline=time.perf_counter()+30
for v in sorted(range(n),key=lambda i:(-graph[i].bit_count(),i)):
    while remaining[v] and time.perf_counter()<deadline:
        clique=[v];candidates=remaining[v]
        while candidates:
            low=candidates&-candidates;u=low.bit_length()-1;clique.append(u);candidates&=graph[u]
        remove(clique);cliques.append(clique)
    if time.perf_counter()>=deadline:break
elapsed=time.perf_counter()-start
def bits(mask):
    while mask:low=mask&-mask;yield low.bit_length()-1;mask-=low
left=[[i,j] for i,row in enumerate(remaining) for j in bits(row) if i<j];covered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:covered[i]|=mask^(1<<i)
for i,j in left:covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph
write(OUT/'cliques.json',cliques);write(OUT/'residual-pairs.json',left);write(OUT/'checks.json',{'passed':True,'cover_work_seconds':elapsed,'total_seconds':time.perf_counter()-start,'initial_cliques':old,'cliques':len(cliques),'residual_edges':len(left),'conflicts':sum(r.bit_count() for r in graph)//2,'exact_graph_cover':True,'solver_calls':0});print(load(OUT/'checks.json'))
