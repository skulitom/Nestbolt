"""Complete original-outline graph for the fresh mixed-row poses and a certified clique cover."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-contact-pool-20261026';OUT=BASE/'graph';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();pool=load(BASE/'candidates.json');plan=load(BASE/'plan.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']};required=plan['required_pair_gap_mm'];n=len(pool);assert 0<n<=4200;shapes=[]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'candidates.json',BASE/'result.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']},'graph_seconds_limit':120,'clique_cover_seconds_limit':20,'method':'Evaluate every unordered original-filled-outer pair at the required native-guard distance. Retain a symmetric bit graph withzero diagonal. Compress only by verified original-graph cliques; if the20-second cover limit leaves edges, retain each as a binary exclusion. No candidate or required quantity is removed.'})
for row in pool:
    p=row['placement'];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;shapes.append(affine_transform(parts[p['part_id']],[m*c,-s,m*s,c,*t['translation']]))
shapes=np.asarray(shapes,dtype=object);adj=np.zeros((n,n),dtype=np.bool_);checks=0
for i in range(n):
    assert time.perf_counter()-start<120
    conflicts=shapely.distance(shapes[i],shapes[i+1:])<=required;adj[i,i+1:]=conflicts;adj[i+1:,i]=conflicts;checks+=n-i-1
raw=np.packbits(adj,axis=1,bitorder='little').tobytes();assert len(raw)==n*((n+7)//8)
with gzip.open(OUT/'graph.bin.gz','xb') as f:f.write(raw)
rowbytes=(n+7)//8;graph=[int.from_bytes(raw[i*rowbytes:(i+1)*rowbytes],'little') for i in range(n)];edges=sum(x.bit_count() for x in graph)//2;residual=list(graph);cliques=[];coverstart=time.perf_counter()
def bits(value):
    while value:l=value&-value;yield l.bit_length()-1;value-=l
while time.perf_counter()-coverstart<20:
    v=max(range(n),key=lambda i:residual[i].bit_count())
    if not residual[v]:break
    clique=[v];candidates=residual[v]
    while candidates:
        u=max(bits(candidates),key=lambda i:(graph[i]&candidates).bit_count());clique.append(u);candidates&=graph[u]
    assert len(clique)>=2;mask=sum(1<<i for i in clique)
    for i in clique:assert mask^(1<<i)==graph[i]&(mask^(1<<i));residual[i]&=~mask
    cliques.append(clique)
left=[[i,j] for i in range(n) for j in bits(residual[i]) if i<j];covered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:covered[i]|=mask^(1<<i)
for i,j in left:covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph
write(OUT/'cliques.json',cliques);write(OUT/'residual-pairs.json',left);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidates':n,'unordered_source_pair_checks':checks,'conflicts':edges,'graph_uncompressed_sha256':sha256(raw).hexdigest(),'graph_uncompressed_bytes':len(raw),'cliques':len(cliques),'residual_edges':len(left),'clique_cover_seconds':time.perf_counter()-coverstart,'complete_graph_coverage':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
