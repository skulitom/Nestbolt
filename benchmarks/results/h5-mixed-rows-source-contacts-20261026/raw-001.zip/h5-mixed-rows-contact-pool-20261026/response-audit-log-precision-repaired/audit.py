"""Read back the only finite original-geometry selection; never rerun its solver."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-contact-pool-20261026';SEARCH=BASE/'search';OUT=BASE/'response-audit-log-precision-repaired';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();check=load(BASE/'model/checks.json');assert check['passed']
for record in [load(BASE/'model/plan.json'),load(BASE/'plan.json')]:
    for n,h in record['inputs'].items():assert digest(ROOT/n)==h,n
assert digest(SEARCH/'model.pb')==check['model_sha256'];opened=load(SEARCH/'opened.json');assert opened['maximum_calls']==1 and opened['solver_seconds']==60 and opened['shared_seconds']==90
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=60.,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False)
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90
status=cp_model_pb2.CpSolverStatus.Name(response.status);assert status==result['status'] and status in ['UNKNOWN','INFEASIBLE','FEASIBLE','OPTIMAL'];assert result['solver_calls']==1 and result['closed'];assert response.num_branches==result['branches'] and response.num_conflicts==result['conflicts'] and response.wall_time==result['solver_wall_seconds']
assert 0<response.wall_time<=result['returned_solve_seconds']<=process['seconds'];assert result['solver_soft_overrun_seconds']==max(0.,response.wall_time-60) and result['returned_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-60)
log=(SEARCH/'solver.log').read_text();walltext=re.findall(r'^walltime:\s+([0-9.]+)',log,re.M)[-1];wall=float(walltext);digits=len(walltext.split('.')[1]) if '.' in walltext else 0;assert abs(wall-response.wall_time)<=.5*10**(-digits)+1e-12
worker_stats=[]
if 'Search stats' in log:
    stats=log.split('Search stats',1)[1].split('SAT formula',1)[0]
    for name,bools,conflicts,branches in re.findall(r"^\s+'([^']+)':\s+([0-9']+)\s+([0-9']+)\s+([0-9']+)",stats,re.M):worker_stats.append({'worker':name,'booleans':int(bools.replace("'",'')),'conflicts':int(conflicts.replace("'",'')),'branches':int(branches.replace("'",''))})
pool=load(BASE/'candidates.json');selected=None
if status in ['OPTIMAL','FEASIBLE']:
    assert len(response.solution)==len(pool) and all(v in [0,1] for v in response.solution);selected=[i for i,v in enumerate(response.solution) if v];assert selected==result['selected'];assert dict(Counter(pool[i]['placement']['part_id'] for i in selected))==check['exact_family_counts'];n=len(pool);nb=(n+7)//8;raw=gzip.decompress((BASE/'graph/graph.bin.gz').read_bytes());mask=sum(1<<i for i in selected)
    for i in selected:assert not(int.from_bytes(raw[i*nb:(i+1)*nb],'little')&mask)
    write(OUT/'selected-candidates.json',[pool[i] for i in selected])
else:assert not response.solution and result['selected'] is None
write(OUT/'worker-stats.json',worker_stats)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'solver_calls':1,'closed':True,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'shared_budget_honored':True,'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'search_started':'Starting search at ' in log,'closed_by_presolve':'Problem closed by presolve.' in log,'response_lp_iterations':response.num_lp_iterations,'worker_stats':worker_stats,'returned_response_branches':response.num_branches,'all33_movers_required':True,'mandatory_counts':check['exact_family_counts'],'selected':selected,'finite_pool_only':True,'unrestricted_source_exclusion':False,'formal_unsat_certificate_claimed':False,'full66_source_audit_pending':selected is not None,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
