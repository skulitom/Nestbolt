"""Fresh finite original-shape contact closure with all33 remaining originals required."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter,deque
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,mapping
from shapely.affinity import affine_transform,translate
import diagnose_h5_concave_gaps as geom
from build_h5_cog_free_regions import proposals,identity
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-mixed-rows-contact-pool-20261026';CORE=ROOT/'output/h5-mixed-rows-core-20261026/audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+180;spec=load(CORE/'next-neighborhood.json');assert load(CORE/'checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};source={k:Polygon(v['geometry'][0]['outer']) for k,v in parts.items()};guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);caps={'cog':2200,'bracket':1000,'insert':1000};phases=[0.,4.5,9.,13.5]
orient=[{'family':'cog','angle':math.radians(a),'mirrored':False} for a in phases]+[{'family':'bracket','angle':q*math.pi/2,'mirrored':m} for m in [False,True] for q in range(4)]+[{'family':'insert','angle':q*math.pi/2,'mirrored':False} for q in range(2)]
inputs=[JOB,CORE/'next-neighborhood.json',CORE/'checks.json',Path(geom.__file__),ROOT/'output/build_h5_cog_free_regions.py',ROOT/'output/h5-original-cog-phase-lattice-20261026/wheel-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'generation_seconds':180,'candidate_caps':caps,'orientations':orient,'required_pair_gap_mm':required,'required_extra_stock_mm':guard,'radial_cog_contacts':{'angles_degrees':list(range(0,360,15)),'bisection_steps':32,'initial_radius_bracket_mm':[0,300],'pair_target_gap_mm':.225,'extra_radial_margin_mm':.001,'maximum_parent_depth':3},'spatial_quota':{'bin_mm':25,'maximum_per_family_orientation_bin':2},'fixed_boundary_seed_caps':{'cog':160,'bracket':150,'insert':150},'noncog_contact_parents':64,'method':'New mixed-row eighteen-frame core and unchanged short fifteen. All33 movers remain mandatory:6 brackets,12 inserts,15 cogs. Fixed-boundary seeds and independent source-cog radial closure are followed by contacts around64 spread cog parents, reserving noncog quota for mutual bracket/insert contacts around64 stratified parents. Reject obstacle interior representatives and require distance from the generating parent before applying any candidate quota. Cog-parent stage admits at most450 per noncog family; mutual contacts may fill the1000 caps. Every candidate must satisfy the current18 fixed filled outers and stock. Spatial25mm bins and orientation phases are finite sampling, not unrestricted coverage. Retain all proposal queues and rejection counts. A fresh full original-pair graph and independent readback must precede one exact6/12/15 joint call. No inherited source exclusions or solver retries. No native call for incomplete layouts.'})
def shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(source[p['part_id']],[m*c,-s,m*s,c,*t['translation']])
def pose(o,xy):return {'part_id':o['family'],'sheet_id':'sheet-0','transform':{'rotation_radians':o['angle'],'mirrored':o['mirrored'],'translation':list(xy)}}
def centered_cog(phase):
    a=math.radians(phase);c,s=math.cos(a),math.sin(a);return shape(pose({'family':'cog','angle':a,'mirrored':False},[-139.723742*c+139.723742*s,-139.723742*s-139.723742*c]))
def cog_pose(pi,center):
    a=math.radians(phases[pi]);c,s=math.cos(a),math.sin(a);return pose(orient[pi],[center[0]-139.723742*c+139.723742*s,center[1]-139.723742*s-139.723742*c])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];bounds=[m['left']+edge+guard,m['bottom']+edge+guard,stock['width']-m['right']-edge-guard,stock['height']-m['top']-edge-guard];geom.EPS=.0126
pool=[];seen={};buckets=Counter();counts=Counter();events=[];queries=[];pending={}
def consider(p,origin):
    family=p['part_id'];key=identity(p)
    if origin['kind'] in ['noncog_contact','mutual_contact']:
        if origin.get('proposal_kind')=='representative':return None,'obstacle_interior'
        if shape(p).distance(shape(pool[origin['parent']]['placement']))<=required:return None,'generating_parent_conflict'
    if counts[family]>=caps[family]:return None,'family_cap'
    if key in seen:return seen[key],'exact_duplicate'
    g=shape(p);b=g.bounds;t=p['transform'];bucket=(family,t['rotation_radians'],t['mirrored'],math.floor(b[0]/25),math.floor(b[1]/25))
    if buckets[bucket]>=2:return None,'spatial_quota'
    if not(b[0]>bounds[0] and b[1]>bounds[1] and b[2]<bounds[2] and b[3]<bounds[3]):return None,'stock'
    ds=shapely.distance(g,fixed)
    if float(np.min(ds))<=required:return None,'fixed_geometry'
    index=len(pool);seen[key]=index;pool.append({'index':index,'placement':p,'source':origin,'fixed_minimum_distance_mm':float(np.min(ds))});counts[family]+=1;buckets[bucket]+=1;return index,'added'
def attempt(p,origin):
    index,status=consider(p,origin);events.append({'source':origin,'candidate':index,'result':status});return index,status
for oi,o in enumerate(orient):
    if time.perf_counter()>=deadline:pending['unbuilt_fixed_queries']=list(range(oi,len(orient)));break
    region=geom.regions(shape(pose(o,[0.,0.])),list(fixed),stock,edge,required);q={'index':oi,'orientation':o,'geometry':mapping(region),'proposals':proposals(region)};queries.append(q);write(OUT/'regions'/f'fixed-{oi:02d}.json',q)
queue=deque((q['index'],0) for q in queries if q['proposals']);seeds=Counter()
while queue and time.perf_counter()<deadline:
    qi,point=queue.popleft();q=queries[qi];family=q['orientation']['family']
    if seeds[family]<(160 if family=='cog' else 150):
        i,status=attempt(pose(q['orientation'],q['proposals'][point]['point']),{'kind':'fixed_boundary','query':qi,'proposal':point,'depth':0})
        if status=='added':seeds[family]+=1
        if point+1<len(q['proposals']):queue.append((qi,point+1))
    else:pending.setdefault('capped_fixed_boundary_lists',[]).append([qi,point])
pending['unfinished_fixed_boundary_lists']=list(queue);write(OUT/'seed-counts.json',dict(seeds));cg=[centered_cog(p) for p in phases];contacts=[]
for ai in range(4):
    for degrees in range(0,360,15):
        for bi in range(4):
            if time.perf_counter()>=deadline:raise RuntimeError('Preparation exceeded declared generation limit before contact table completion')
            a=math.radians(degrees);ux,uy=math.cos(a),math.sin(a);lo,hi=0.,300.
            for _ in range(32):
                mid=(lo+hi)/2;distance=cg[ai].distance(translate(cg[bi],xoff=mid*ux,yoff=mid*uy))
                if distance>.225:hi=mid
                else:lo=mid
            radius=hi+.001;actual=cg[ai].distance(translate(cg[bi],xoff=radius*ux,yoff=radius*uy));assert actual>.225
            contacts.append({'index':len(contacts),'parent_phase':ai,'child_phase':bi,'direction_degrees':degrees,'bracket_mm':[lo,hi],'radius_mm':radius,'offset_mm':[radius*ux,radius*uy],'verified_gap_mm':actual})
write(OUT/'radial-contacts.json',contacts);by_phase={i:[r for r in contacts if r['parent_phase']==i] for i in range(4)}
def cog_center(r):
    t=r['placement']['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);x,y=t['translation'];return [x+139.723742*c-139.723742*s,y+139.723742*s+139.723742*c]
frontier=deque((r['index'],0,0) for r in pool if r['placement']['part_id']=='cog')
while frontier and counts['cog']<caps['cog'] and time.perf_counter()<deadline:
    parent,k,depth=frontier.popleft();r=pool[parent];pi=next(i for i,o in enumerate(orient[:4]) if o['angle']==r['placement']['transform']['rotation_radians']);contact=by_phase[pi][k];center=cog_center(r);center=[center[d]+contact['offset_mm'][d] for d in range(2)];index,status=attempt(cog_pose(contact['child_phase'],center),{'kind':'cog_contact','parent':parent,'contact':contact['index'],'depth':depth+1})
    if k+1<len(by_phase[pi]):frontier.append((parent,k+1,depth))
    if status=='added' and depth+1<3:frontier.append((index,0,depth+1))
pending['cog_contact_frontier']=list(frontier)
cog_indices=sorted([r['index'] for r in pool if r['placement']['part_id']=='cog'],key=lambda i:(*cog_center(pool[i])[::-1],pool[i]['placement']['transform']['rotation_radians']));parent_indices=[cog_indices[i] for i in sorted(set(np.linspace(0,len(cog_indices)-1,min(64,len(cog_indices)),dtype=int).tolist()))] if cog_indices else [];write(OUT/'noncog-parent-indices.json',parent_indices)
contact_queries={}
for pi in range(4):
    for oi in range(4,len(orient)):
        if time.perf_counter()>=deadline:pending.setdefault('unbuilt_noncog_queries',[]).append([pi,oi]);continue
        obstacle=geom.obstacle(cg[pi],shape(pose(orient[oi],[0.,0.])),.225);q={'parent_phase':pi,'orientation_index':oi,'geometry':mapping(obstacle),'proposals':proposals(obstacle)};contact_queries[pi,oi]=q;write(OUT/'regions'/f'contact-{pi}-{oi:02d}.json',q)
q2=deque()
for parent in parent_indices:
    pi=next(i for i,o in enumerate(orient[:4]) if o['angle']==pool[parent]['placement']['transform']['rotation_radians'])
    for oi in range(4,len(orient)):
        if (pi,oi) in contact_queries:q2.append((parent,pi,oi,0))
while q2 and time.perf_counter()<deadline:
    parent,pi,oi,k=q2.popleft();o=orient[oi];q=contact_queries[pi,oi]
    if counts[o['family']]>=450:pending.setdefault('capped_noncog_contact_lists',[]).append([parent,pi,oi,k]);continue
    xy=q['proposals'][k]['point'];center=cog_center(pool[parent]);attempt(pose(o,[xy[d]+center[d] for d in range(2)]),{'kind':'noncog_contact','parent':parent,'parent_phase':pi,'orientation':oi,'proposal':k,'proposal_kind':q['proposals'][k]['kind']})
    if k+1<len(q['proposals']):q2.append((parent,pi,oi,k+1))
pending['unfinished_noncog_contact_lists']=list(q2)
# Source contacts among noncogs reserve room for interlocking bracket pairs and inserts.
mutual_parents=[]
for oi in range(4,len(orient)):
    o=orient[oi];ids=sorted([r['index'] for r in pool if r['placement']['part_id']==o['family'] and r['placement']['transform']['rotation_radians']==o['angle'] and r['placement']['transform']['mirrored']==o['mirrored']],key=lambda i:(shape(pool[i]['placement']).bounds[1],shape(pool[i]['placement']).bounds[0]))
    quota=4 if o['family']=='bracket' else 16
    mutual_parents.extend((ids[k],oi) for k in sorted(set(np.linspace(0,len(ids)-1,min(quota,len(ids)),dtype=int).tolist())))
write(OUT/'mutual-parent-indices.json',mutual_parents);mutual={}
for ai in sorted(set(oi for _,oi in mutual_parents)):
    for bi in range(4,len(orient)):
        if time.perf_counter()>=deadline:pending.setdefault('unbuilt_mutual_queries',[]).append([ai,bi]);continue
        obstacle=geom.obstacle(shape(pose(orient[ai],[0.,0.])),shape(pose(orient[bi],[0.,0.])),.225);q={'parent_orientation':ai,'child_orientation':bi,'geometry':mapping(obstacle),'proposals':proposals(obstacle)};mutual[ai,bi]=q;write(OUT/'regions'/f'mutual-{ai:02d}-{bi:02d}.json',q)
q3=deque((parent,ai,bi,0) for parent,ai in mutual_parents for bi in range(4,len(orient)) if (ai,bi) in mutual and mutual[ai,bi]['proposals'])
while q3 and time.perf_counter()<deadline:
    parent,ai,bi,k=q3.popleft();o=orient[bi];q=mutual[ai,bi]
    if counts[o['family']]>=caps[o['family']]:pending.setdefault('capped_mutual_lists',[]).append([parent,ai,bi,k]);continue
    xy=q['proposals'][k]['point'];translation=pool[parent]['placement']['transform']['translation'];attempt(pose(o,[xy[d]+translation[d] for d in range(2)]),{'kind':'mutual_contact','parent':parent,'parent_orientation':ai,'orientation':bi,'proposal':k,'proposal_kind':q['proposals'][k]['kind']})
    if k+1<len(q['proposals']):q3.append((parent,ai,bi,k+1))
pending['unfinished_mutual_lists']=list(q3);write(OUT/'candidates.json',pool);write(OUT/'events.json',events);write(OUT/'pending.json',pending)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidate_counts':dict(counts),'candidates':len(pool),'event_counts':dict(Counter(e['result'] for e in events)),'fixed_queries':len(queries),'radial_source_contacts':len(contacts),'noncog_contact_queries':len(contact_queries),'noncog_contact_parents':len(parent_indices),'fixed_first_originals':18,'fixed_short_originals':15,'mandatory_moving_counts':{'bracket':6,'insert':12,'cog':15},'mutual_queries':len(mutual),'mutual_parents':len(mutual_parents),'all66_originals_required':True,'rigid_lattice_required':False,'independent_graph_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
