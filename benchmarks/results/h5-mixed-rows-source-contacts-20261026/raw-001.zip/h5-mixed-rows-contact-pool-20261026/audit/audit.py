"""Reconstruct every pose, provenance link, source pair and complete graph cover."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-contact-pool-20261026';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');graphplan=load(BASE/'graph/plan.json')
for record in [plan,graphplan,load(BASE/'fast-cover/plan.json')]:
    for n,h in record['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};pool=load(BASE/'candidates.json');core=load(ROOT/'output/h5-mixed-rows-core-20261026/audit/next-neighborhood.json');assert core['mandatory_moving_family_counts']=={'bracket':6,'insert':12,'cog':15}
guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);assert required==plan['required_pair_gap_mm'];st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];bounds=[m['left']+edge,m['bottom']+edge,st['width']-m['right']-edge,st['height']-m['top']-edge]
def source_shape(p):
    part=parts[p['part_id']];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sgn=-1 if t['mirrored'] else 1;x,y=t['translation'];return Polygon([(sgn*u*c-v*s+x,sgn*u*s+v*c+y) for u,v in part['geometry'][0]['outer']])
def center(p):
    t=p['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);x,y=t['translation'];return [x+139.723742*c-139.723742*s,y+139.723742*s+139.723742*c]
fixed=np.asarray([source_shape(p) for p in core['fixed_first_placements']],dtype=object);shapes=[];seen=set();minimum=math.inf;minstock=math.inf;counts=Counter();contacts=load(BASE/'radial-contacts.json');query={};provenance=Counter();parent_conflicts=[];interior_proposals=0
for i,r in enumerate(pool):
    assert r['index']==i;p=r['placement'];part=parts[p['part_id']];t=p['transform'];assert p['sheet_id']=='sheet-0' and (not t['mirrored'] or part['allow_mirror']);assert part['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees'])
    key=(p['part_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(v).hex() for v in t['translation']));assert key not in seen;seen.add(key);g=source_shape(p);assert g.is_valid and abs(g.area-Polygon(part['geometry'][0]['outer']).area)<1e-6;b=g.bounds;stockmin=min(b[0]-bounds[0],b[1]-bounds[1],bounds[2]-b[2],bounds[3]-b[3]);assert stockmin>guard;minstock=min(minstock,stockmin);ds=shapely.distance(g,fixed);dist=float(np.min(ds));assert dist>required and abs(dist-r['fixed_minimum_distance_mm'])<1e-8;minimum=min(minimum,dist);shapes.append(g);counts[p['part_id']]+=1;o=r['source'];provenance[o['kind']]+=1
    if o['kind']=='fixed_boundary':
        name=f"fixed-{o['query']:02d}.json"
        if name not in query:query[name]=load(BASE/'regions'/name)
        q=query[name];assert t['translation']==q['proposals'][o['proposal']]['point'] and t['rotation_radians']==q['orientation']['angle'] and t['mirrored']==q['orientation']['mirrored']
    elif o['kind']=='cog_contact':
        assert o['parent']<i and p['part_id']=='cog';parent=pool[o['parent']]['placement'];contact=contacts[o['contact']];assert t['rotation_radians']==math.radians([0,4.5,9,13.5][contact['child_phase']]) and parent['transform']['rotation_radians']==math.radians([0,4.5,9,13.5][contact['parent_phase']]);a=center(parent);b=center(p);assert max(abs(b[k]-a[k]-contact['offset_mm'][k]) for k in range(2))<1e-9 and g.distance(shapes[o['parent']])>.225-1e-9
    elif o['kind']=='noncog_contact':
        assert o['parent']<i and p['part_id'] in ['bracket','insert'];name=f"contact-{o['parent_phase']}-{o['orientation']:02d}.json"
        if name not in query:query[name]=load(BASE/'regions'/name)
        point=query[name]['proposals'][o['proposal']]['point'];a=center(pool[o['parent']]['placement']);assert max(abs(t['translation'][k]-a[k]-point[k]) for k in range(2))<1e-9;orientation=plan['orientations'][o['orientation']];assert t['rotation_radians']==orientation['angle'] and t['mirrored']==orientation['mirrored']
        assert query[name]['proposals'][o['proposal']]['kind']!='representative' and g.distance(shapes[o['parent']])>required
    elif o['kind']=='mutual_contact':
        assert o['parent']<i and p['part_id'] in ['bracket','insert'];name=f"mutual-{o['parent_orientation']:02d}-{o['orientation']:02d}.json"
        if name not in query:query[name]=load(BASE/'regions'/name)
        point=query[name]['proposals'][o['proposal']]['point'];parent=pool[o['parent']]['placement'];a=parent['transform']['translation'];assert max(abs(t['translation'][k]-a[k]-point[k]) for k in range(2))<1e-9;orientation=plan['orientations'][o['orientation']];po=plan['orientations'][o['parent_orientation']];pt=parent['transform'];assert pt['rotation_radians']==po['angle'] and pt['mirrored']==po['mirrored'] and parent['part_id']==po['family'];assert t['rotation_radians']==orientation['angle'] and t['mirrored']==orientation['mirrored']
        assert query[name]['proposals'][o['proposal']]['kind']!='representative' and g.distance(shapes[o['parent']])>required
    else:raise AssertionError(o)
assert dict(counts)==load(BASE/'result.json')['candidate_counts'] and all(counts[f]<=plan['candidate_caps'][f] for f in counts);n=len(pool);rowbytes=(n+7)//8;raw=gzip.decompress((BASE/'graph/graph.bin.gz').read_bytes());result=load(BASE/'graph/result.json');assert sha256(raw).hexdigest()==result['graph_uncompressed_sha256'] and len(raw)==n*rowbytes;graph=[int.from_bytes(raw[i*rowbytes:(i+1)*rowbytes],'little') for i in range(n)];shapes=np.asarray(shapes,dtype=object);paircount=0;conflicts=0
for i in range(n):
    assert not (graph[i]>>i)&1
    actual=shapely.distance(shapes[i],shapes[i+1:])<=required;bits=np.unpackbits(np.frombuffer(raw[i*rowbytes:(i+1)*rowbytes],dtype=np.uint8),bitorder='little')[:n];assert np.array_equal(actual,bits[i+1:].astype(bool));conflicts+=int(np.sum(actual));paircount+=n-i-1
    for j in range(i+1,n):assert ((graph[i]>>j)&1)==((graph[j]>>i)&1)
for parent,child in parent_conflicts:assert (graph[parent]>>child)&1
covered=[0]*n;cliques=load(BASE/'fast-cover/cliques.json');left=load(BASE/'fast-cover/residual-pairs.json')
for clique in cliques:
    assert len(set(clique))==len(clique)>=2 and all(0<=i<n for i in clique);mask=sum(1<<i for i in clique)
    for i in clique:others=mask^(1<<i);assert graph[i]&others==others;covered[i]|=others
for i,j in left:assert (graph[i]>>j)&1;covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph and conflicts==result['conflicts'] and paircount==n*(n-1)//2
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'candidate_counts':dict(counts),'source_provenance_counts':dict(provenance),'obstacle_interior_representatives':interior_proposals,'conflicting_parent_edges_verified':len(parent_conflicts),'fixed_original_pair_checks':18*n,'stock_edge_checks':4*n,'unordered_original_pair_checks':paircount,'conflicts_verified':conflicts,'cliques_verified':len(cliques),'residual_edges':len(left),'graph_exactly_reconstructed':True,'complete_conflict_coverage':True,'minimum_fixed_pair_gap_mm':minimum,'minimum_extra_stock_mm':minstock,'mandatory_moving_counts':core['mandatory_moving_family_counts'],'all66_originals_required':True,'independent_cog_centers':True,'full66_target_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
