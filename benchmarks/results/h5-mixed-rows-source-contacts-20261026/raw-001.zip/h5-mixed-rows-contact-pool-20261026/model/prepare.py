"""One mandatory original33-mover selection, with independent exact model reconstruction."""
from pathlib import Path
from hashlib import sha256
import gzip,json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-contact-pool-20261026';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();audit=load(BASE/'audit/checks.json');assert audit['passed'] and audit['all66_originals_required'];pool=load(BASE/'candidates.json');cliques=load(BASE/'fast-cover/cliques.json');left=load(BASE/'fast-cover/residual-pairs.json');core=load(ROOT/'output/h5-mixed-rows-core-20261026/audit/next-neighborhood.json');counts=core['mandatory_moving_family_counts'];assert counts=={'bracket':6,'insert':12,'cog':15};n=len(pool)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'candidates.json',BASE/'fast-cover/cliques.json',BASE/'fast-cover/residual-pairs.json',BASE/'graph/graph.bin.gz',BASE/'audit/checks.json',ROOT/'output/h5-mixed-rows-core-20261026/audit/next-neighborhood.json']},'method':'All fresh candidate poses are Boolean choices. Exact family cardinalities require6 brackets,12 inserts and15 cogs. All verified source-conflict cliques impose at-most-one. The current18 first-sheet and15 short originals remain fixed. No objective, hint, quantity reduction or inherited stale pose. Audit complete model and graph-cover equality before one60-second solver call in90 shared seconds. All prior calls remain closed. A positive requires full66 source/native/material readback; a negative excludes only this finite pool.','maximum_calls':1,'solver_seconds':60,'shared_seconds':90,'workers':4,'seed':0})
model=cp_model.CpModel();variables=[model.new_bool_var(f'candidate_{i}') for i in range(n)]
for family,quantity in counts.items():model.add(sum(variables[i] for i,r in enumerate(pool) if r['placement']['part_id']==family)==quantity)
for clique in cliques:model.add_at_most_one([variables[i] for i in clique])
for i,j in left:model.add_at_most_one([variables[i],variables[j]])
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));saved=cp_model_pb2.CpModelProto();saved.ParseFromString((OUT/'model.pb').read_bytes());assert text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())==saved
expected=cp_model_pb2.CpModelProto()
for i in range(n):expected.variables.add(name=f'candidate_{i}',domain=[0,1])
for family,quantity in counts.items():
    ids=[i for i,r in enumerate(pool) if r['placement']['part_id']==family];row=expected.constraints.add().linear;row.vars.extend(ids);row.coeffs.extend([1]*len(ids));row.domain.extend([quantity,quantity])
for clique in cliques:expected.constraints.add().at_most_one.literals.extend(clique)
for i,j in left:expected.constraints.add().at_most_one.literals.extend([i,j])
assert expected==saved and not saved.HasField('objective') and not saved.solution_hint.vars
raw=gzip.decompress((BASE/'graph/graph.bin.gz').read_bytes());nb=(n+7)//8;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];covered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:others=mask^(1<<i);assert graph[i]&others==others;covered[i]|=others
for i,j in left:assert (graph[i]>>j)&1;covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(saved.variables),'constraints':len(saved.constraints),'exact_family_counts':counts,'original_graph_conflicts':sum(x.bit_count() for x in graph)//2,'exact_graph_projection':True,'complete_independent_proto_reconstruction':True,'model_sha256':digest(OUT/'model.pb'),'source_audit_sha256':digest(BASE/'audit/checks.json'),'solver_calls':0,'all66_originals_required':True,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
