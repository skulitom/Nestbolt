"""Independent exclusion provenance, clique witnesses, remaining covers and exact areas."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import horizontal_areas

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-conditional-frontier-20261108';OUT=BASE/'audit'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108';PILOT=ROOT/'output/h5-fixed29-conditional-area-pilot-20261108'
POINT=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108';GROUP=ROOT/'output/h5-fixed29-group-pointwise-pilot-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2);stream.write('\n')

OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,PILOT/'audit-v2',POINT/'audit',GROUP/'audit',DOM/'audit',COVER/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for name,expected in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==expected;bindings[name]=expected
for path in [Path(__file__)]+list(BASE.glob('*.json')):bindings[path.relative_to(ROOT).as_posix()]=digest(path)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently derive the exact union of certified inventory-conditional exclusions from each proof kind and its permitted transfer scope. Check every root-clique directed pair directly in packed graph bytes, whole-family coverage, and source self-collision inequalities. Replay each supplied simultaneous clique implication against the active set before that round, using direct graph bits and set intersections; retain every unexcluded node, with no additional completeness claim about unrecorded implications. Reconstruct all remaining source-mode closed-cover sweeps and replay nine exact global areas by horizontal interval merging. Verify all current positions/source labels and unchanged reserved-hole/clearance semantics.'})
cases=load(COVER/'audit/remaining-cases.json');saved=load(BASE/'case-results.json');assert len(cases)==len(saved)==3
geometry=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um']
causes={case['refinement_index']:{} for case in cases}
for folder,kind in [(PILOT/'audit-v2','graph'),(POINT/'audit','point'),(GROUP/'audit','group')]:
    for proof in load(folder/'pivot-results.json'):
        strict_deficit=any(value<need for value,need in zip([proof['family_area_upper_um2']['bracket'],proof['family_area_upper_um2']['insert'],proof['joint_area_upper_um2']],[279993000000,158392000000,438385000000]))
        assert strict_deficit==(proof['reference_group_excluded'] if kind=='group' else proof['reference_cell_excluded'])
        if not strict_deficit:continue
        if kind=='graph':targets=proof['dominated_current_bracket_positions_excluded']
        elif kind=='point':assert not proof['dominance_transfer_permitted'];targets=[proof['pivot_current_position']]
        else:assert not proof['dominance_transfer_permitted'];targets=proof['reference_group_current_positions']
        for position in targets:causes[proof['refinement_index']].setdefault(position,set()).add((kind,proof['pivot_current_position']))
assert sum(map(len,causes.values()))==11
results=[];clique_pairs=self_checks=implication_checks=0
for case,row in zip(cases,saved):
    index=case['refinement_index'];dominance=load(DOM/f'choice-{index:02d}-dominance.json');graph=ROOT/dominance['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(graph/'conflicts.bin').read_bytes();record=load(BASE/f'choice-{index:02d}-frontier.json');original=load(COVER/f'choice-{index:02d}-covers.json');root_covers=load(graph/'root-covers.json')
    assert record['original_current_node_count']==N and len(original)==N and len(root_covers)==2
    assert all(entry['current_graph_position']==i and entry['source_node_label']==nodes[i]['node'] for i,entry in enumerate(original))
    assert len(record['source_self_collision_components'])==N
    for node,component_index in zip(nodes,record['source_self_collision_components']):
        box=node['bounds_um'];component=geometry[node['geometry']]['inner_rectangles_um'][component_index]
        assert box[2]-box[0]<component[2]-component[0] and box[3]-box[1]<component[3]-component[1];self_checks+=1
    for family,groups in enumerate(root_covers):
        covered=set()
        for group in groups:
            assert len(set(group))==len(group) and all(0<=position<N and nodes[position]['family']==family for position in group)
            for position in group:
                for other in group:
                    if position!=other:assert (raw[position*width+other//8]>>(other%8))&1;clique_pairs+=1
            covered.update(group)
        assert covered=={i for i,node in enumerate(nodes) if node['family']==family}
    seed=record['seed_exclusions'];assert [entry['current_position'] for entry in seed]==sorted(causes[index])
    for entry in seed:
        position=entry['current_position'];assert entry['source_node_label']==nodes[position]['node'] and nodes[position]['family']==0
        assert {(cause['proof_kind'],cause['proof_pivot']) for cause in entry['causes']}==causes[index][position]
    active=set(range(N))-set(causes[index]);rounds=record['clique_rounds'];assert 1<=len(rounds)<=8
    for iteration,round_record in enumerate(rounds):
        assert round_record['round']==iteration;removed=round_record['removed'];positions=[entry['current_position'] for entry in removed]
        assert len(set(positions))==len(positions) and set(positions)<=active
        for entry in removed:
            position=entry['current_position'];allowed={other for other in active if other!=position and not (raw[position*width+other//8]>>(other%8))&1}
            upper=[sum(bool(allowed.intersection(group)) for group in groups) for groups in root_covers]
            required=[7,8] if nodes[position]['family']==0 else [8,7]
            assert entry['remaining_family_upper_counts']==upper and entry['required_remaining_counts']==required and any(value<need for value,need in zip(upper,required));implication_checks+=1
        active.difference_update(positions)
        if not removed:assert iteration==len(rounds)-1
    retained=sorted(active);assert retained==record['remaining_current_positions'];regions={'bracket':set(),'insert':set()}
    for position in retained:
        source=geometry[nodes[position]['geometry']]
        for left,bottom,right,top in original[position]['remaining_closed_anchor_boxes_um']:
            for x0,y0,x1,y1 in source['all_alias_component_outer_rectangles_um']:
                rectangle=(max(left+x0,stock[0]),max(bottom+y0,stock[1]),min(right+x1,stock[2]),min(top+y1,stock[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[source['family']].add(rectangle)
    regions={family:sorted(rectangles) for family,rectangles in regions.items()}
    assert record['family_component_regions_um']=={family:[list(rectangle) for rectangle in rows] for family,rows in regions.items()}
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um'];areas=horizontal_areas(regions['bracket'],regions['insert'],fixed)
    previous=[case['family_area_upper_um2'][family] for family in ['bracket','insert']]+[case['joint_area_upper_um2']];assert all(new<=old for new,old in zip(areas,previous))
    global_upper=[sum(bool(active.intersection(group)) for group in groups) for groups in root_covers];excluded=any(count<8 for count in global_upper) or any(value<need for value,need in zip(areas,[319992000000,158392000000,478384000000]))
    expected={'refinement_index':index,'empty_sites':case['empty_sites'],'original_current_nodes':N,'seed_exclusions':len(seed),'clique_implication_exclusions':sum(len(round['removed']) for round in rounds),'remaining_current_nodes':len(retained),'remaining_bracket_nodes':sum(nodes[i]['family']==0 for i in retained),'remaining_insert_nodes':sum(nodes[i]['family']==1 for i in retained),'global_clique_upper_counts':global_upper,'family_area_upper_um2':dict(zip(['bracket','insert'],areas[:2])),'joint_area_upper_um2':areas[2],'required_joint_area_lower_um2':478384000000,'joint_area_reduction_um2':previous[2]-areas[2],'provisional_fixed_scope_excluded':excluded}
    assert expected==row;results.append({**row,'fixed_scope_excluded':excluded});print(results[-1],flush=True)
process=load(ROOT/'output/h5-fixed29-conditional-frontier-process-20261108/process.json');assert process['closed'] and process['passed'];charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[row for row in results if not row['fixed_scope_excluded']]
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':3,'seed_exclusions_verified':11,'self_collision_witnesses_verified':self_checks,'directed_root_clique_edges_verified':clique_pairs,'clique_implication_witnesses_verified':implication_checks,'exact_area_bounds_verified':9,'new_fixed_scope_exclusions':3-len(remaining),'remaining_fixed29_cases':len(remaining),'remaining_current_nodes':sum(row['remaining_current_nodes'] for row in results),'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
