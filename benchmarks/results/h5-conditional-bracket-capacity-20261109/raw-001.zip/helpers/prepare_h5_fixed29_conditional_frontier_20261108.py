"""Reconcile conditional exclusions, deterministic clique implications and full areas."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-conditional-frontier-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108';PILOT=ROOT/'output/h5-fixed29-conditional-area-pilot-20261108'
POINT=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108';GROUP=ROOT/'output/h5-fixed29-group-pointwise-pilot-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2);stream.write('\n')

OUT.mkdir();began=time.perf_counter();cases=load(COVER/'audit/remaining-cases.json')
parents=[PILOT/'audit-v2',POINT/'audit',GROUP/'audit',DOM/'audit',COVER/'audit']
assert all(load(folder/'checks.json')['passed'] for folder in parents)
inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',OLD/'geometries.json',OLD/'stock-cover.json']
for folder in parents:inputs.extend([folder/'checks.json',folder/'plan.json'])
inputs.extend([PILOT/'audit-v2/pivot-results.json',POINT/'audit/pivot-results.json',GROUP/'audit/pivot-results.json',COVER/'audit/remaining-cases.json'])
for case in cases:
    index=case['refinement_index'];graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph']
    inputs.extend([DOM/f'choice-{index:02d}-dominance.json',COVER/f'choice-{index:02d}-covers.json',COVER/f'choice-{index:02d}-regions.json',graph/'nodes.json',graph/'conflicts.bin',graph/'root-covers.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Union only independently certified inventory-conditional reference-cell exclusions. Graph-only deficits may transfer by the recorded dominance mapping; pose-specific deficits only remove their own cell; group deficits remove exactly their complete listed source-parent group. Preserve current graph positions and source labels. Verify all root covers as actual pairwise conflict cliques covering their whole family and verify source self collision. For at most8 simultaneous rounds, remove a candidate only if choosing it leaves a complete clique-cover upper bound below the required remaining7/8 or8/7 inventory. Stop at the first unchanged round. These are necessary deterministic implications, not an optimizer. Recompute all8bracket8insert occupied-envelope areas from the complete remaining pointwise covers, against unchanged fixed clearance regions. All claims require common-line holes reserved.','maximum_clique_rounds':8,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':load(GROUP/'audit/checks.json')['complete_preparation_seconds_if_consumed']})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];ledger={case['refinement_index']:{} for case in cases}
for folder,kind in [(PILOT/'audit-v2','graph'),(POINT/'audit','point'),(GROUP/'audit','group')]:
    for row in load(folder/'pivot-results.json'):
        accepted=row['reference_group_excluded'] if kind=='group' else row['reference_cell_excluded']
        if not accepted:continue
        targets=row['dominated_current_bracket_positions_excluded'] if kind=='graph' else row['reference_group_current_positions'] if kind=='group' else [row['pivot_current_position']]
        for position in targets:ledger[row['refinement_index']].setdefault(position,[]).append({'proof_kind':kind,'proof_pivot':row['pivot_current_position']})
assert sum(map(len,ledger.values()))==11
results=[]
for case in cases:
    index=case['refinement_index'];dominance=load(DOM/f'choice-{index:02d}-dominance.json');graph=ROOT/dominance['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(graph/'conflicts.bin').read_bytes();mask=(1<<N)-1;rows=[int.from_bytes(raw[i*width:(i+1)*width],'little')&mask for i in range(N)]
    original=load(COVER/f'choice-{index:02d}-covers.json');root_covers=load(graph/'root-covers.json');assert len(root_covers)==2
    self_proofs=[]
    for position,node in enumerate(nodes):
        box=node['bounds_um'];geometry=geometries[node['geometry']]
        component=next(k for k,rect in enumerate(geometry['inner_rectangles_um']) if box[2]-box[0]<rect[2]-rect[0] and box[3]-box[1]<rect[3]-rect[1])
        self_proofs.append(component);rows[position]|=1<<position
    cliques=[]
    for family,groups in enumerate(root_covers):
        masks=[];covered=set()
        for group in groups:
            assert len(set(group))==len(group) and all(nodes[position]['family']==family for position in group)
            bits=sum(1<<position for position in group)
            for position in group:assert rows[position]&bits==bits
            masks.append(bits);covered.update(group)
        assert covered=={i for i,node in enumerate(nodes) if node['family']==family};cliques.append(masks)
    seed=sorted(ledger[index]);assert all(nodes[position]['family']==0 for position in seed)
    active=mask^sum(1<<position for position in seed);rounds=[]
    for iteration in range(8):
        removed=[]
        for position,node in enumerate(nodes):
            if not active>>position&1:continue
            companions=active&~rows[position]
            upper=[sum(bool(bits&companions) for bits in family) for family in cliques]
            required=[8-(node['family']==0),8-(node['family']==1)]
            if any(bound<need for bound,need in zip(upper,required)):
                removed.append({'current_position':position,'remaining_family_upper_counts':upper,'required_remaining_counts':required})
        rounds.append({'round':iteration,'removed':removed})
        if not removed:break
        active&=~sum(1<<row['current_position'] for row in removed)
    retained=[i for i in range(N) if active>>i&1];regions={'bracket':set(),'insert':set()}
    for position in retained:
        node=nodes[position];geometry=geometries[node['geometry']]
        for box in original[position]['remaining_closed_anchor_boxes_um']:
            for component in geometry['all_alias_component_outer_rectangles_um']:
                value=[box[k]+component[k] for k in range(4)];rectangle=(max(value[0],stock[0]),max(value[1],stock[1]),min(value[2],stock[2]),min(value[3],stock[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[geometry['family']].add(rectangle)
    regions={family:sorted(rectangles) for family,rectangles in regions.items()};fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um'];areas=vertical_areas(regions['bracket'],regions['insert'],fixed)
    previous=[case['family_area_upper_um2'][family] for family in ['bracket','insert']]+[case['joint_area_upper_um2']];assert all(new<=old for new,old in zip(areas,previous));global_upper=[sum(bool(bits&active) for bits in family) for family in cliques];excluded=any(count<8 for count in global_upper) or any(value<need for value,need in zip(areas,[319992000000,158392000000,478384000000]))
    write(OUT/f'choice-{index:02d}-frontier.json',{'original_current_node_count':N,'seed_exclusions':[{'current_position':position,'source_node_label':nodes[position]['node'],'causes':ledger[index][position]} for position in seed],'source_self_collision_components':self_proofs,'clique_rounds':rounds,'remaining_current_positions':retained,'family_component_regions_um':{family:[list(rectangle) for rectangle in rows] for family,rows in regions.items()}})
    row={'refinement_index':index,'empty_sites':case['empty_sites'],'original_current_nodes':N,'seed_exclusions':len(seed),'clique_implication_exclusions':sum(len(round['removed']) for round in rounds),'remaining_current_nodes':len(retained),'remaining_bracket_nodes':sum(nodes[i]['family']==0 for i in retained),'remaining_insert_nodes':sum(nodes[i]['family']==1 for i in retained),'global_clique_upper_counts':global_upper,'family_area_upper_um2':dict(zip(['bracket','insert'],areas[:2])),'joint_area_upper_um2':areas[2],'required_joint_area_lower_um2':478384000000,'joint_area_reduction_um2':previous[2]-areas[2],'provisional_fixed_scope_excluded':excluded}
    results.append(row);print(row,flush=True)
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':3,'seed_exclusions':11,'clique_implication_exclusions':sum(r['clique_implication_exclusions'] for r in results),'provisional_fixed_scope_exclusions':sum(r['provisional_fixed_scope_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
