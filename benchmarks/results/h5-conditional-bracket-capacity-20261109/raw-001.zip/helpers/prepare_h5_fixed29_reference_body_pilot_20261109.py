"""Full reserved-envelope conservation for surviving conditional bracket queries."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-reference-body-pilot-20261109'
FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108';POINT=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2);stream.write('\n')

OUT.mkdir();began=time.perf_counter();parent=load(FRONT/'audit/checks.json');assert parent['passed'] and parent['remaining_fixed29_cases']==2
remaining=load(FRONT/'audit/remaining-cases.json');active={case['refinement_index']:set(load(FRONT/f"choice-{case['refinement_index']:02d}-frontier.json")['remaining_current_positions']) for case in remaining}
queries=[query for query in load(POINT/'audit/pivot-results.json') if not query['reference_cell_excluded'] and query['refinement_index'] in active and query['pivot_current_position'] in active[query['refinement_index']]]
assert 0<len(queries)<=5
inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',FRONT/'audit/checks.json',FRONT/'audit/plan.json',FRONT/'audit/remaining-cases.json',POINT/'audit/checks.json',POINT/'audit/plan.json',POINT/'audit/pivot-results.json',OLD/'geometries.json',OLD/'stock-cover.json',OLD/'source-alias-envelopes.json',OLD/'audit/checks.json']
for query in queries:
    index=query['refinement_index'];pivot=query['pivot_current_position'];graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph']
    inputs.extend([FRONT/f'choice-{index:02d}-frontier.json',DOM/f'choice-{index:02d}-dominance.json',graph/'nodes.json',COVER/f'choice-{index:02d}-covers.json',COVER/f'choice-{index:02d}-regions.json',POINT/f'choice-{index:02d}-pivot-{pivot:04d}-regions.json',POINT/f'choice-{index:02d}-pivot-{pivot:04d}-covers.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':[[query['refinement_index'],query['pivot_current_position']] for query in queries],'method':'For every still-open conditional pointwise reference query in a surviving whole scope/current node, let U be its complete companion occupied-envelope sweep, F ONLY the fixed0.2mm forbidden regions, and W the original reference outer-component envelopes swept over ALL certified closed anchor covers for its current cell. The actual reference bracket has occupied envelope area>=39999mm2 and is disjoint fromF. Therefore its compulsory occupancy insideR=U minusF is at least max(0,39999-area(W minus(U unionF))). All7otherbrackets8inserts need438385mm2 inR disjoint from this reference. Compute exact areaR before any common-reference subtraction, and the exact outsideW complement. The earlier common-moving-buffer capacity remains an alternative bound, never an additive deduction or part ofF. Pose-dependent deficits exclude only this actual reference cell. Allholesreservedforcommon-line; no net-material/ordinaryhole-nesting claim.','process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})
geometry=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];results=[]
for query in queries:
    index=query['refinement_index'];pivot=query['pivot_current_position'];key=f'choice-{index:02d}-pivot-{pivot:04d}'
    graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph'];node=load(graph/'nodes.json')[pivot];source=geometry[node['geometry']]
    assert source['family']=='bracket';reference_cover=load(COVER/f'choice-{index:02d}-covers.json')[pivot];possible=set()
    for box in reference_cover['remaining_closed_anchor_boxes_um']:
        for component in source['all_alias_component_outer_rectangles_um']:
            value=[box[k]+component[k] for k in range(4)];rect=(max(value[0],stock[0]),max(value[1],stock[1]),min(value[2],stock[2]),min(value[3],stock[3]))
            if rect[0]<rect[2] and rect[1]<rect[3]:possible.add(rect)
    possible=sorted(possible);regions=load(POINT/(key+'-regions.json'));fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    fixed_only=vertical_areas(regions['bracket'],regions['insert'],fixed)[2]
    outside=vertical_areas(possible,[],regions['bracket']+regions['insert']+fixed)[0]
    compulsory=max(0,39999*10**6-outside);upper=fixed_only-compulsory
    assert fixed_only>=query['joint_area_upper_um2']
    write(OUT/(key+'-reference-cover.json'),{'reference_current_position':pivot,'reference_source_node_label':node['node'],'complete_reference_anchor_boxes_um':reference_cover['remaining_closed_anchor_boxes_um'],'possible_reference_occupied_regions_um':[list(rect) for rect in possible]})
    row={'refinement_index':index,'empty_sites':query['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':node['node'],'fixed_only_companion_area_upper_um2':fixed_only,'reference_possible_area_outside_companion_and_fixed_um2':outside,'reference_occupied_area_lower_um2':39999*10**6,'compulsory_reference_occupancy_in_companion_um2':compulsory,'full_body_companion_area_upper_um2':upper,'prior_common_buffer_companion_area_upper_um2':query['joint_area_upper_um2'],'combined_companion_area_upper_um2':min(upper,query['joint_area_upper_um2']),'required_other_joint_area_lower_um2':438385000000,'provisional_reference_cell_excluded':upper<438385000000,'dominance_transfer_permitted':False}
    results.append(row);print(row,flush=True)
write(OUT/'pivot-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'fixed_queries':len(queries),'exact_area_bounds':2*len(queries),'provisional_excluded_reference_queries':sum(row['provisional_reference_cell_excluded'] for row in results),'whole_fixed_scope_exclusions':0,'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
