"""Eight frozen pointwise companion proofs conditioned on an actual bracket cell."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108'
PILOT=ROOT/'output/h5-fixed29-conditional-area-pilot-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
HELPER=ROOT/'output/h5_exact_rectangle_areas_20261108.py'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')
def subtract_closed(box,forbidden):
    left,bottom,right,top=box
    lowx,lowy,highx,highy=forbidden
    if right<=lowx or left>=highx or top<=lowy or bottom>=highy:
        return [box]
    pieces=[]
    if left<=lowx:pieces.append((left,bottom,min(right,lowx),top))
    if right>=highx:pieces.append((max(left,highx),bottom,right,top))
    midleft,midright=max(left,lowx),min(right,highx)
    if midleft<=midright:
        if bottom<=lowy:pieces.append((midleft,bottom,midright,min(top,lowy)))
        if top>=highy:pieces.append((midleft,max(bottom,highy),midright,top))
    return pieces

OUT.mkdir();began=time.perf_counter()
parent=load(PILOT/'audit-v2/checks.json')
assert parent['passed'] and parent['excluded_reference_queries']==1
queries=[q for q in load(PILOT/'audit-v2/pivot-results.json') if not q['reference_cell_excluded']]
assert len(queries)==8
inputs=[Path(__file__),HELPER,PILOT/'audit-v2/checks.json',PILOT/'audit-v2/plan.json',PILOT/'audit-v2/pivot-results.json',COVER/'audit/checks.json',COVER/'audit/plan.json',OLD/'geometries.json',OLD/'stock-cover.json']
for query in queries:
    index=query['refinement_index'];pivot=query['pivot_current_position']
    dominance=load(DOM/f'choice-{index:02d}-dominance.json')
    inputs.extend([DOM/f'choice-{index:02d}-dominance.json',ROOT/dominance['graph']/'nodes.json',COVER/f'choice-{index:02d}-covers.json',COVER/f'choice-{index:02d}-regions.json',PILOT/f'choice-{index:02d}-pivot-{pivot:04d}-regions.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':'Exactly the8 surviving queries from the independently audited nine-query pilot. No adaptive additions or optimizer calls.','method':'Intersect each original-common inner component of the reference bracket over its whole original closed anchor cell. The resulting rectangles are inside its occupied outer envelope for EVERY reference anchor and alias. Expand them141um per axis, strictly inside original0.2mm clearance. Other moving occupied envelopes must avoid these common forbidden regions. Subtract the corresponding OPEN forbidden anchor rectangles from every previously allowed CLOSED companion cover, preserving boundary points/lines. Recompute exact7bracket+8insert area capacities after subtracting both fixed and common-moving forbidden regions. A failure excludes only this actual reference cell: graph dominance does NOT transfer the new pose-dependent geometry to other cells. Previously proved4 graph-only cell exclusions remain separate. Common-line holes are reserved; no net-material or ordinary part-in-hole claim.','process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um']
results=[]
for query in queries:
    index=query['refinement_index'];pivot=query['pivot_current_position'];key=f'choice-{index:02d}-pivot-{pivot:04d}'
    dominance=load(DOM/f'choice-{index:02d}-dominance.json')
    nodes=load(ROOT/dominance['graph']/'nodes.json');covers=load(COVER/f'choice-{index:02d}-covers.json')
    prior=load(PILOT/(key+'-regions.json'));allowed=prior['allowed_current_positions']
    reference=nodes[pivot];left,bottom,right,top=reference['bounds_um']
    common=[]
    for component_index,(x0,y0,x1,y1) in enumerate(geometries[reference['geometry']]['inner_rectangles_um']):
        rectangle=[right+x0,top+y0,left+x1,bottom+y1]
        if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:
            common.append({'source_component':component_index,'bounds_um':rectangle})
    buffered=[[r['bounds_um'][k]+(-141 if k<2 else 141) for k in range(4)] for r in common]
    forbidden=[]
    for geometry in geometries:
        forbidden.append(sorted({(fixed[0]-component[2],fixed[1]-component[3],fixed[2]-component[0],fixed[3]-component[1]) for fixed in buffered for component in geometry['inner_rectangles_um']}))
    records=[];regions={'bracket':set(),'insert':set()}
    for current in allowed:
        node=nodes[current];geometry=geometries[node['geometry']]
        pieces=[tuple(box) for box in covers[current]['remaining_closed_anchor_boxes_um']]
        for obstacle in forbidden[node['geometry']]:
            pieces=sorted({piece for box in pieces for piece in subtract_closed(box,obstacle)})
        records.append({'current_position':current,'remaining_closed_anchor_boxes_um':[list(box) for box in pieces]})
        for box in pieces:
            for component in geometry['all_alias_component_outer_rectangles_um']:
                corners=[box[k]+component[k] for k in range(4)]
                rectangle=(max(corners[0],stock[0]),max(corners[1],stock[1]),min(corners[2],stock[2]),min(corners[3],stock[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[geometry['family']].add(rectangle)
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    regions={family:sorted(rectangles) for family,rectangles in regions.items()}
    areas=vertical_areas(regions['bracket'],regions['insert'],fixed+buffered)
    previous=[query['family_area_upper_um2'][family] for family in ['bracket','insert']]+[query['joint_area_upper_um2']]
    assert all(new<=old for new,old in zip(areas,previous))
    required=[279993000000,158392000000,438385000000]
    failures=[i for i,(value,lower) in enumerate(zip(areas,required)) if value<lower]
    write(OUT/(key+'-covers.json'),{'reference_current_position':pivot,'reference_source_node_label':reference['node'],'reference_closed_anchor_box_um':reference['bounds_um'],'common_occupied_envelope_rectangles':common,'common_moving_clearance_regions_um':buffered,'open_forbidden_companion_anchor_rectangles_um':[[list(rect) for rect in rows] for rows in forbidden],'companion_covers':records})
    write(OUT/(key+'-regions.json'),{family:[list(rect) for rect in rows] for family,rows in regions.items()})
    row={'refinement_index':index,'empty_sites':query['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':reference['node'],'allowed_current_nodes':len(allowed),'common_reference_rectangles':len(common),'conditional_companion_boxes':sum(len(r['remaining_closed_anchor_boxes_um']) for r in records),'family_area_upper_um2':dict(zip(['bracket','insert'],areas[:2])),'joint_area_upper_um2':areas[2],'required_joint_area_lower_um2':438385000000,'joint_area_reduction_um2':previous[2]-areas[2],'failing_area_indices':failures,'provisional_reference_cell_excluded':bool(failures),'dominance_transfer_permitted':False}
    results.append(row);print(row,flush=True)
write(OUT/'pivot-results.json',results)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'fixed_queries':8,'exact_area_bounds':24,'provisional_excluded_reference_queries':sum(r['provisional_reference_cell_excluded'] for r in results),'whole_fixed_scope_exclusions':0,'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
