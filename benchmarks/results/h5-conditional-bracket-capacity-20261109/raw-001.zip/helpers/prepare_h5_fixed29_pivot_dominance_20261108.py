"""Complete minimal conflict-row cover for one required bracket in each scope."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-pivot-dominance-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';PRIOR=ROOT/'benchmarks/results/h5-fixed29-pointwise-capacity-20261108';GRAPH=ROOT/'output/h5-exact-circle-graphs-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();assert load(PRIOR/'scope-finalization-checks.json')['passed'];cases=load(COVER/'audit/remaining-cases.json');assert len(cases)==3;inputs=[Path(__file__),PRIOR/'checks.json',PRIOR/'scope-finalization-checks.json',PRIOR/'occupancy-scope/plan.json',PRIOR/'occupancy-scope/checks.json',COVER/'audit/checks.json',COVER/'audit/plan.json',COVER/'audit/remaining-cases.json',OLD/'geometries.json',GRAPH/'audit/checks.json',GRAPH/'audit/plan.json']+[p for r in cases for p in [GRAPH/f"choice-{r['refinement_index']:02d}"/'nodes.json',GRAPH/f"choice-{r['refinement_index']:02d}"/'conflicts.bin',GRAPH/f"choice-{r['refinement_index']:02d}"/'checks.json',COVER/f"choice-{r['refinement_index']:02d}-covers.json"]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A common-line layout requires8original brackets. Choose any one required bracket; its current complete graph cell must be one of the enumerated bracket cells. All7other brackets and8inserts lie outside that cell conflict row. Verify source-common inner occupied-envelope rectangles make two brackets in the same closed cell collide; explicitly include self in the forbidden row. Order bracket rows by cardinality then current position. Retain only rows containing no earlier retained row as a subset. Map EVERY bracket position to a retained subset row. For pivotP mapped toA, allowed companions forP are a subset of allowed companions forA; thus exact area insufficiency for7+8 overA would excludeP. This stage verifies coverage only, not areas/exclusions. All holes are reserved; no ordinary part-in-hole claim.','process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':load(PRIOR/'checks.json')['complete_preparation_seconds_if_consumed']})
geometries=load(OLD/'geometries.json');results=[]
for case in cases:
    index=case['refinement_index'];folder=GRAPH/f'choice-{index:02d}';nodes=load(folder/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(folder/'conflicts.bin').read_bytes();assert len(raw)==N*width;mask=(1<<N)-1;rows=[int.from_bytes(raw[i*width:(i+1)*width],'little')&mask for i in range(N)];pivots=[i for i,n in enumerate(nodes) if n['family']==0];certificates=[]
    for i in pivots:
        n=nodes[i];g=geometries[n['geometry']];l,b,r,t=n['bounds_um'];component=next((k for k,(a,c,d,e) in enumerate(g['inner_rectangles_um']) if r-l<d-a and t-b<e-c),None);assert component is not None;certificates.append({'current_position':i,'source_node_label':n['node'],'component':component});rows[i]|=1<<i
    order=sorted(pivots,key=lambda i:(rows[i].bit_count(),i));representatives=[];mapping={};comparisons=0
    for i in order:
        selected=None
        for a in representatives:
            comparisons+=1
            if rows[a]&~rows[i]==0:selected=a;break
        if selected is None:selected=i;representatives.append(i)
        mapping[i]=selected
    record={'refinement_index':index,'empty_sites':case['empty_sites'],'graph':folder.relative_to(ROOT).as_posix(),'current_nodes':N,'bracket_pivots':len(pivots),'representative_current_positions':representatives,'pivot_to_representative':[[i,mapping[i]] for i in pivots],'source_self_collision_certificates':certificates,'representative_forbidden_cardinalities':[rows[i].bit_count() for i in representatives],'required_other_brackets':7,'required_other_inserts':8,'required_other_joint_area_lower_um2':(7*39999+8*19799)*10**6};write(OUT/f'choice-{index:02d}-dominance.json',record);results.append({'refinement_index':index,'empty_sites':case['empty_sites'],'current_nodes':N,'bracket_pivots':len(pivots),'minimal_rows':len(representatives),'subset_comparisons':comparisons,'fixed_scope_excluded':False});print(results[-1],flush=True)
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':3,'bracket_pivots':sum(r['bracket_pivots'] for r in results),'minimal_rows':sum(r['minimal_rows'] for r in results),'independent_audit_pending':True,'area_bounds_computed':0,'optimizer_calls':0,'H5_complete':False})
