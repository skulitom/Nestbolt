"""Independently verify every pivot mapping, antichain and source self collision."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-pivot-dominance-20261108';OUT=BASE/'audit';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';GRAPH=ROOT/'output/h5-exact-circle-graphs-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,COVER/'audit',GRAPH/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Read compact graph bit rows and verify every source label/current position, every actual source-common inner-component self-collision, every complete current pivot cover and every supplied subset mapping directly. Pairwise compare all retained representatives to prove no row contains another. Do not reuse producer sorted-greedy selection. A complete actual8bracket layout selects a pivot and leaves exactly7brackets8inserts. Allowed companion domains for the pivot are subsets of its mapped representative domains. All claims require common-line reserved outer envelopes. No area or exclusion is established in this stage.'})
geometry=load(OLD/'geometries.json');cases=load(COVER/'audit/remaining-cases.json');saved=load(BASE/'case-results.json');assert len(cases)==len(saved)==3;results=[];subsetchecks=antichainchecks=selfchecks=0
for case,row in zip(cases,saved):
    index=case['refinement_index'];data=load(BASE/f'choice-{index:02d}-dominance.json');folder=ROOT/data['graph'];nodes=load(folder/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(folder/'conflicts.bin').read_bytes();assert len(raw)==N*width;mask=(1<<N)-1;rows=[int.from_bytes(raw[i*width:(i+1)*width],'little')&mask for i in range(N)];pivots=[i for i,n in enumerate(nodes) if n['family']==0];covers=load(COVER/f'choice-{index:02d}-covers.json');assert len(covers)==N and all(c['current_graph_position']==i and c['source_node_label']==nodes[i]['node'] and c['remaining_closed_anchor_boxes_um'] for i,c in enumerate(covers));certs=data['source_self_collision_certificates'];assert len(certs)==len(pivots)
    for i,c in zip(pivots,certs):
        assert c['current_position']==i and c['source_node_label']==nodes[i]['node'];box=nodes[i]['bounds_um'];component=geometry[nodes[i]['geometry']]['inner_rectangles_um'][c['component']];dx=box[2]-box[0];dy=box[3]-box[1];assert dx<component[2]-component[0] and dy<component[3]-component[1];rows[i]|=1<<i;selfchecks+=1
    representatives=data['representative_current_positions'];assert len(set(representatives))==len(representatives) and all(i in pivots for i in representatives);mapping=dict(data['pivot_to_representative']);assert len(mapping)==len(data['pivot_to_representative'])==len(pivots) and set(mapping)==set(pivots)
    for p,a in mapping.items():assert a in representatives and rows[a]&rows[p]==rows[a];subsetchecks+=1
    for ai,a in enumerate(representatives):
        assert mapping[a]==a
        for b in representatives[ai+1:]:assert rows[a]&rows[b] not in [rows[a],rows[b]];antichainchecks+=1
    assert data['representative_forbidden_cardinalities']==[rows[i].bit_count() for i in representatives];assert data['required_other_brackets']==7 and data['required_other_inserts']==8 and data['required_other_joint_area_lower_um2']==438385000000;assert data['current_nodes']==N and data['bracket_pivots']==len(pivots) and data['empty_sites']==case['empty_sites'];assert row['current_nodes']==N and row['bracket_pivots']==len(pivots) and row['minimal_rows']==len(representatives);results.append({**row,'complete_pivot_coverage_verified':True})
process=load(ROOT/'output/h5-fixed29-pivot-dominance-process-20261108/process.json');assert process['closed'] and process['passed'];charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'case-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':3,'bracket_pivots_verified':selfchecks,'subset_mappings_verified':subsetchecks,'antichain_pairs_verified':antichainchecks,'minimal_representative_rows':sum(r['minimal_rows'] for r in results),'area_bounds_computed':0,'new_fixed_scope_exclusions':0,'remaining_fixed29_cases':3,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'complete_preparation_seconds_if_consumed':charge,'optimizer_allowed_from_current_lineage':False,'full_algorithm_budget_satisfied':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
