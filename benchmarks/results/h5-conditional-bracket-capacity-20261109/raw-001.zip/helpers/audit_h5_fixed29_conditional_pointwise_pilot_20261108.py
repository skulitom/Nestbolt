"""Independent common-envelope witnesses, complete boundary classes and exact areas."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time
import numpy as np
from h5_exact_rectangle_areas_20261108 import horizontal_areas

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108';OUT=BASE/'audit'
PILOT=ROOT/'output/h5-fixed29-conditional-area-pilot-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')
def axis(cuts):
    values=np.array(sorted(cuts),dtype=np.int64)
    representatives=np.empty(2*len(values)-1,dtype=np.int64)
    representatives[::2]=2*values;representatives[1::2]=values[:-1]+values[1:]
    return representatives
def cover(rows,xx,yy,closed):
    grid=np.zeros((len(yy),len(xx)),dtype=bool)
    for left,bottom,right,top in rows:
        lowx=int(np.searchsorted(xx,2*left,side='left' if closed else 'right'))
        highx=int(np.searchsorted(xx,2*right,side='right' if closed else 'left'))
        lowy=int(np.searchsorted(yy,2*bottom,side='left' if closed else 'right'))
        highy=int(np.searchsorted(yy,2*top,side='right' if closed else 'left'))
        grid[lowy:highy,lowx:highx]=True
    return grid

OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,PILOT/'audit-v2',COVER/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for name,expected in load(folder/'plan.json')['inputs'].items():
        assert digest(ROOT/name)==expected;bindings[name]=expected
for path in [Path(__file__)]+list(BASE.glob('*.json')):bindings[path.relative_to(ROOT).as_posix()]=digest(path)
write(OUT/'plan.json',{'inputs':bindings,'method':'Verify every common-reference rectangle corner against the actual reference inner component translated at every corner of the whole reference cell, covering all continuous anchors and aliases by convexity. Verify the141um buffer corners are strictly within200um, and derive every open forbidden companion anchor rectangle independently. For each allowed current node, prove its original CLOSED cover minus OPEN forbidden union equals the saved CLOSED cover on every point/open-interval Cartesian class; producer subtraction is not reused. Reconstruct all original alias-component sweeps and replay all24area bounds with horizontal interval merging, independent of vertical prefix sweeps. The pose-dependent proof excludes only its own reference cell, never graph-dominated cells. Common-line outer envelopes reserve all holes.'})
queries=[query for query in load(PILOT/'audit-v2/pivot-results.json') if not query['reference_cell_excluded']]
saved=load(BASE/'pivot-results.json');assert len(queries)==len(saved)==8
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um']
classes=common_checks=companion_checks=0;results=[]
assert all(x*x+y*y<200**2 for x,y in product([-141,141],repeat=2))
for query,row in zip(queries,saved):
    index=query['refinement_index'];pivot=query['pivot_current_position'];key=f'choice-{index:02d}-pivot-{pivot:04d}'
    dominance=load(DOM/f'choice-{index:02d}-dominance.json')
    nodes=load(ROOT/dominance['graph']/'nodes.json');covers=load(COVER/f'choice-{index:02d}-covers.json')
    allowed=load(PILOT/(key+'-regions.json'))['allowed_current_positions']
    record=load(BASE/(key+'-covers.json'));reference=nodes[pivot];reference_box=reference['bounds_um'];reference_geometry=geometries[reference['geometry']]
    assert record['reference_current_position']==pivot and record['reference_source_node_label']==reference['node'] and record['reference_closed_anchor_box_um']==reference_box
    common=record['common_occupied_envelope_rectangles'];assert len({entry['source_component'] for entry in common})==len(common)
    for entry in common:
        rectangle=entry['bounds_um'];component=reference_geometry['inner_rectangles_um'][entry['source_component']]
        assert rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]
        for anchorx,anchory in product([reference_box[0],reference_box[2]],[reference_box[1],reference_box[3]]):
            for pointx,pointy in product([rectangle[0],rectangle[2]],[rectangle[1],rectangle[3]]):
                assert component[0]<=pointx-anchorx<=component[2] and component[1]<=pointy-anchory<=component[3]
                common_checks+=1
    buffered=record['common_moving_clearance_regions_um']
    assert buffered==[[entry['bounds_um'][k]+(-141 if k<2 else 141) for k in range(4)] for entry in common]
    forbidden=record['open_forbidden_companion_anchor_rectangles_um'];assert len(forbidden)==10
    for geometry in geometries:
        expected=set()
        for left,bottom,right,top in geometry['inner_rectangles_um']:
            for bx0,by0,bx1,by1 in buffered:expected.add((bx0-right,by0-top,bx1-left,by1-bottom))
        assert forbidden[geometry['geometry']]==[list(rectangle) for rectangle in sorted(expected)]
    records=record['companion_covers'];assert [entry['current_position'] for entry in records]==allowed
    regions={'bracket':set(),'insert':set()}
    for current,entry in zip(allowed,records):
        node=nodes[current];geometry=geometries[node['geometry']]
        original=covers[current]['remaining_closed_anchor_boxes_um'];remaining=entry['remaining_closed_anchor_boxes_um'];obstacles=forbidden[node['geometry']]
        left,bottom,right,top=node['bounds_um'];assert all(left<=rect[0]<=rect[2]<=right and bottom<=rect[1]<=rect[3]<=top for rect in remaining)
        rows=original+remaining+obstacles
        xx=axis({left,right}|{rect[k] for rect in rows for k in [0,2] if left<=rect[k]<=right})
        yy=axis({bottom,top}|{rect[k] for rect in rows for k in [1,3] if bottom<=rect[k]<=top})
        assert len(xx)*len(yy)<4000000
        assert np.array_equal(cover(original,xx,yy,True)&~cover(obstacles,xx,yy,False),cover(remaining,xx,yy,True)),(key,current)
        classes+=len(xx)*len(yy);companion_checks+=1
        for box in remaining:
            for component in geometry['all_alias_component_outer_rectangles_um']:
                corners=[box[k]+component[k] for k in range(4)]
                rectangle=(max(corners[0],stock[0]),max(corners[1],stock[1]),min(corners[2],stock[2]),min(corners[3],stock[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[geometry['family']].add(rectangle)
    regions={family:sorted(rectangles) for family,rectangles in regions.items()}
    assert load(BASE/(key+'-regions.json'))=={family:[list(rectangle) for rectangle in rows] for family,rows in regions.items()}
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    areas=horizontal_areas(regions['bracket'],regions['insert'],fixed+buffered)
    previous=[query['family_area_upper_um2'][family] for family in ['bracket','insert']]+[query['joint_area_upper_um2']]
    assert all(new<=old for new,old in zip(areas,previous))
    required=[279993000000,158392000000,438385000000];failures=[i for i,(value,lower) in enumerate(zip(areas,required)) if value<lower]
    expected={'refinement_index':index,'empty_sites':query['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':reference['node'],'allowed_current_nodes':len(allowed),'common_reference_rectangles':len(common),'conditional_companion_boxes':sum(len(entry['remaining_closed_anchor_boxes_um']) for entry in records),'family_area_upper_um2':dict(zip(['bracket','insert'],areas[:2])),'joint_area_upper_um2':areas[2],'required_joint_area_lower_um2':438385000000,'joint_area_reduction_um2':previous[2]-areas[2],'failing_area_indices':failures,'provisional_reference_cell_excluded':bool(failures),'dominance_transfer_permitted':False}
    assert expected==row;results.append({**row,'reference_cell_excluded':bool(failures)});print({'case':index,'pivot':pivot,'joint_area_um2':areas[2],'excluded':bool(failures)},flush=True)
process=load(ROOT/'output/h5-fixed29-conditional-pointwise-pilot-process-20261108/process.json')
assert process['closed'] and process['passed']
charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'pivot-results.json',results)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'fixed_queries_verified':8,'common_reference_corner_checks':common_checks,'conditional_companion_covers_verified':companion_checks,'complete_point_and_open_interval_classes_verified':classes,'exact_area_bounds_verified':24,'excluded_reference_queries':sum(row['reference_cell_excluded'] for row in results),'dominance_transfer_permitted':False,'whole_fixed_scope_exclusions':0,'remaining_fixed29_cases':3,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
