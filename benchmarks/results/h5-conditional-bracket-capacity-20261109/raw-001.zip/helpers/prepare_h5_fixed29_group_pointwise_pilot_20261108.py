"""Eight frozen pointwise companion proofs conditioned on an actual bracket cell."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-fixed29-group-pointwise-pilot-20261108'
PILOT=ROOT/'output/h5-fixed29-conditional-area-pilot-20261108'
PREVIOUS=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
HELPER=ROOT/'output/h5_exact_rectangle_areas_20261108.py'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')
def subtract_closed(box,forbidden):
    left,bottom,right,top=box
    lowx,lowy,highx,highy=forbidden
    if right<=lowx or left>=highx or top<=lowy or bottom>=highy:
        return [box]
    pieces=[]
    if left<=lowx:pieces.append((left,bottom,min(right,lowx),top))
    if right>=highx:pieces.append((max(left,highx),bottom,right,top))
    midleft,midright=max(left,lowx),min(right,highx)
    if midleft<=midright:
        if bottom<=lowy:pieces.append((midleft,bottom,midright,min(top,lowy)))
        if top>=highy:pieces.append((midleft,max(bottom,highy),midright,top))
    return pieces

OUT.mkdir();began=time.perf_counter()
parent=load(PREVIOUS/'audit/checks.json')
assert parent['passed'] and parent['excluded_reference_queries']==3
queries=[q for q in load(PREVIOUS/'audit/pivot-results.json') if q['reference_cell_excluded']]
assert len(queries)==3
inputs=[Path(__file__),HELPER,PREVIOUS/'audit/checks.json',PREVIOUS/'audit/plan.json',PREVIOUS/'audit/pivot-results.json',PILOT/'audit-v2/checks.json',PILOT/'audit-v2/plan.json',PILOT/'audit-v2/pivot-results.json',COVER/'audit/checks.json',COVER/'audit/plan.json',OLD/'geometries.json',OLD/'stock-cover.json']
for query in queries:
    index=query['refinement_index'];pivot=query['pivot_current_position']
    dominance=load(DOM/f'choice-{index:02d}-dominance.json')
    inputs.extend([DOM/f'choice-{index:02d}-dominance.json',ROOT/dominance['graph']/'nodes.json',ROOT/dominance['graph']/'conflicts.bin',COVER/f'choice-{index:02d}-covers.json',COVER/f'choice-{index:02d}-regions.json',PILOT/f'choice-{index:02d}-pivot-{pivot:04d}-regions.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':'Exactly the3 successful pose-dependent reference queries from the preceding pilot. For each seed, include EVERY current bracket node with the same source parent_node and geometry. No adaptive extension or optimizer.','method':'The reference group covers all current child cells of its original source region. Any actual chosen bracket in the group has an anchor in their enclosing closed box and the same complete source-mode aliases. Intersect graph conflict rows over ALL group members, including each member own position through the certified self collision. All7other brackets and8inserts may occupy only nodes outside this intersection. Derive common occupied-envelope rectangles over the whole enclosing group box, expand141um within original0.2mm clearance, and apply complete pointwise companion-cover subtraction plus exact area bounds. A deficit excludes EVERY actual reference cell in this explicit group; no graph-dominance transfer is made. Common-line holes remain reserved.','process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um']
results=[]
for query in queries:
    index=query['refinement_index'];pivot=query['pivot_current_position'];key=f'choice-{index:02d}-pivot-{pivot:04d}'
    dominance=load(DOM/f'choice-{index:02d}-dominance.json')
    nodes=load(ROOT/dominance['graph']/'nodes.json');covers=load(COVER/f'choice-{index:02d}-covers.json')
    reference=nodes[pivot]
    members=[i for i,node in enumerate(nodes) if node['family']==0 and node['geometry']==reference['geometry'] and node['parent_node']==reference['parent_node']]
    assert pivot in members
    group_box=[(min if k<2 else max)(nodes[i]['bounds_um'][k] for i in members) for k in range(4)]
    count=len(nodes);width=(count+7)//8;raw=(ROOT/dominance['graph']/'conflicts.bin').read_bytes();intersection=(1<<count)-1
    for member in members:intersection&=int.from_bytes(raw[member*width:(member+1)*width],'little')|(1<<member)
    allowed=[i for i in range(count) if not intersection>>i&1]
    left,bottom,right,top=group_box
    common=[]
    for component_index,(x0,y0,x1,y1) in enumerate(geometries[reference['geometry']]['inner_rectangles_um']):
        rectangle=[right+x0,top+y0,left+x1,bottom+y1]
        if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:
            common.append({'source_component':component_index,'bounds_um':rectangle})
    buffered=[[r['bounds_um'][k]+(-141 if k<2 else 141) for k in range(4)] for r in common]
    forbidden=[]
    for geometry in geometries:
        forbidden.append(sorted({(fixed[0]-component[2],fixed[1]-component[3],fixed[2]-component[0],fixed[3]-component[1]) for fixed in buffered for component in geometry['inner_rectangles_um']}))
    records=[];regions={'bracket':set(),'insert':set()}
    for current in allowed:
        node=nodes[current];geometry=geometries[node['geometry']]
        pieces=[tuple(box) for box in covers[current]['remaining_closed_anchor_boxes_um']]
        for obstacle in forbidden[node['geometry']]:
            pieces=sorted({piece for box in pieces for piece in subtract_closed(box,obstacle)})
        records.append({'current_position':current,'remaining_closed_anchor_boxes_um':[list(box) for box in pieces]})
        for box in pieces:
            for component in geometry['all_alias_component_outer_rectangles_um']:
                corners=[box[k]+component[k] for k in range(4)]
                rectangle=(max(corners[0],stock[0]),max(corners[1],stock[1]),min(corners[2],stock[2]),min(corners[3],stock[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[geometry['family']].add(rectangle)
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    regions={family:sorted(rectangles) for family,rectangles in regions.items()}
    areas=vertical_areas(regions['bracket'],regions['insert'],fixed+buffered)
    previous=[query['family_area_upper_um2'][family] for family in ['bracket','insert']]+[query['joint_area_upper_um2']]
    assert all(new>=old for new,old in zip(areas,previous))
    required=[279993000000,158392000000,438385000000]
    failures=[i for i,(value,lower) in enumerate(zip(areas,required)) if value<lower]
    write(OUT/(key+'-covers.json'),{'reference_current_position':pivot,'reference_source_node_label':reference['node'],'reference_closed_anchor_box_um':group_box,'reference_group_current_positions':members,'reference_source_parent_node':reference['parent_node'],'common_occupied_envelope_rectangles':common,'common_moving_clearance_regions_um':buffered,'open_forbidden_companion_anchor_rectangles_um':[[list(rect) for rect in rows] for rows in forbidden],'companion_covers':records})
    write(OUT/(key+'-regions.json'),{family:[list(rect) for rect in rows] for family,rows in regions.items()})
    row={'refinement_index':index,'empty_sites':query['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':reference['node'],'reference_group_current_positions':members,'allowed_current_nodes':len(allowed),'common_reference_rectangles':len(common),'conditional_companion_boxes':sum(len(r['remaining_closed_anchor_boxes_um']) for r in records),'family_area_upper_um2':dict(zip(['bracket','insert'],areas[:2])),'joint_area_upper_um2':areas[2],'required_joint_area_lower_um2':438385000000,'joint_area_increase_from_single_reference_um2':areas[2]-previous[2],'failing_area_indices':failures,'provisional_reference_group_excluded':bool(failures),'dominance_transfer_permitted':False}
    results.append(row);print(row,flush=True)
write(OUT/'pivot-results.json',results)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'fixed_queries':3,'exact_area_bounds':9,'provisional_excluded_reference_groups':sum(r['provisional_reference_group_excluded'] for r in results),'whole_fixed_scope_exclusions':0,'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
