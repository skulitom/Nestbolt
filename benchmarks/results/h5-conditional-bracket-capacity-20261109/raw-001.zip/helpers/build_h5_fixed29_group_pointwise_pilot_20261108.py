"""Freeze three complete original-parent groups around newly excluded reference cells."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(path,text):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
for kind in ['prepare','audit']:
    source=(ROOT/f'output/{kind}_h5_fixed29_conditional_pointwise_pilot_20261108.py').read_text(encoding='utf-8')
    source=source.replace('h5-fixed29-conditional-pointwise-pilot-20261108','h5-fixed29-group-pointwise-pilot-20261108')
    source=source.replace('h5-fixed29-conditional-pointwise-pilot-process-20261108','h5-fixed29-group-pointwise-pilot-process-20261108')
    before="DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108'"
    source=source.replace(before,"PREVIOUS=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108'\n"+before)
    if kind=='prepare':
        source=source.replace("parent=load(PILOT/'audit-v2/checks.json')\nassert parent['passed'] and parent['excluded_reference_queries']==1\nqueries=[q for q in load(PILOT/'audit-v2/pivot-results.json') if not q['reference_cell_excluded']]\nassert len(queries)==8", "parent=load(PREVIOUS/'audit/checks.json')\nassert parent['passed'] and parent['excluded_reference_queries']==3\nqueries=[q for q in load(PREVIOUS/'audit/pivot-results.json') if q['reference_cell_excluded']]\nassert len(queries)==3")
        source=source.replace("inputs=[Path(__file__),HELPER,", "inputs=[Path(__file__),HELPER,PREVIOUS/'audit/checks.json',PREVIOUS/'audit/plan.json',PREVIOUS/'audit/pivot-results.json',")
        source=source.replace("ROOT/dominance['graph']/'nodes.json',COVER/", "ROOT/dominance['graph']/'nodes.json',ROOT/dominance['graph']/'conflicts.bin',COVER/")
        start=source.index("write(OUT/'plan.json'");end=source.index('\ngeometries=',start)
        source=source[:start]+'''write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':'Exactly the3 successful pose-dependent reference queries from the preceding pilot. For each seed, include EVERY current bracket node with the same source parent_node and geometry. No adaptive extension or optimizer.','method':'The reference group covers all current child cells of its original source region. Any actual chosen bracket in the group has an anchor in their enclosing closed box and the same complete source-mode aliases. Intersect graph conflict rows over ALL group members, including each member own position through the certified self collision. All7other brackets and8inserts may occupy only nodes outside this intersection. Derive common occupied-envelope rectangles over the whole enclosing group box, expand141um within original0.2mm clearance, and apply complete pointwise companion-cover subtraction plus exact area bounds. A deficit excludes EVERY actual reference cell in this explicit group; no graph-dominance transfer is made. Common-line holes remain reserved.','process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})'''+source[end:]
        source=source.replace("prior=load(PILOT/(key+'-regions.json'));allowed=prior['allowed_current_positions']\n    reference=nodes[pivot];left,bottom,right,top=reference['bounds_um']", """reference=nodes[pivot]
    members=[i for i,node in enumerate(nodes) if node['family']==0 and node['geometry']==reference['geometry'] and node['parent_node']==reference['parent_node']]
    assert pivot in members
    group_box=[(min if k<2 else max)(nodes[i]['bounds_um'][k] for i in members) for k in range(4)]
    count=len(nodes);width=(count+7)//8;raw=(ROOT/dominance['graph']/'conflicts.bin').read_bytes();intersection=(1<<count)-1
    for member in members:intersection&=int.from_bytes(raw[member*width:(member+1)*width],'little')|(1<<member)
    allowed=[i for i in range(count) if not intersection>>i&1]
    left,bottom,right,top=group_box""")
        source=source.replace('assert all(new<=old for new,old in zip(areas,previous))','assert all(new>=old for new,old in zip(areas,previous))')
        source=source.replace("'reference_closed_anchor_box_um':reference['bounds_um']", "'reference_closed_anchor_box_um':group_box,'reference_group_current_positions':members,'reference_source_parent_node':reference['parent_node']")
        source=source.replace("'pivot_source_label':reference['node'],'allowed_current_nodes':len(allowed)", "'pivot_source_label':reference['node'],'reference_group_current_positions':members,'allowed_current_nodes':len(allowed)")
        source=source.replace("'joint_area_reduction_um2':previous[2]-areas[2]", "'joint_area_increase_from_single_reference_um2':areas[2]-previous[2]")
        source=source.replace("'provisional_reference_cell_excluded':bool(failures)", "'provisional_reference_group_excluded':bool(failures)")
        source=source.replace("'fixed_queries':8,'exact_area_bounds':24,'provisional_excluded_reference_queries':sum(r['provisional_reference_cell_excluded'] for r in results)", "'fixed_queries':3,'exact_area_bounds':9,'provisional_excluded_reference_groups':sum(r['provisional_reference_group_excluded'] for r in results)")
    else:
        source=source.replace("[BASE,PILOT/'audit-v2',COVER/'audit']", "[BASE,PREVIOUS/'audit',DOM/'audit',COVER/'audit']")
        source=source.replace("queries=[query for query in load(PILOT/'audit-v2/pivot-results.json') if not query['reference_cell_excluded']]", "queries=[query for query in load(PREVIOUS/'audit/pivot-results.json') if query['reference_cell_excluded']]")
        source=source.replace('assert len(queries)==len(saved)==8','assert len(queries)==len(saved)==3')
        source=source.replace("allowed=load(PILOT/(key+'-regions.json'))['allowed_current_positions']\n    record=load(BASE/(key+'-covers.json'));reference=nodes[pivot];reference_box=reference['bounds_um'];reference_geometry=geometries[reference['geometry']]", """record=load(BASE/(key+'-covers.json'));reference=nodes[pivot];reference_geometry=geometries[reference['geometry']]
    members=[i for i,node in enumerate(nodes) if node['family']==0 and node['parent_node']==reference['parent_node'] and node['geometry']==reference['geometry']]
    assert pivot in members and members==record['reference_group_current_positions'] and record['reference_source_parent_node']==reference['parent_node']
    reference_box=[min(nodes[i]['bounds_um'][k] for i in members) if k<2 else max(nodes[i]['bounds_um'][k] for i in members) for k in range(4)]
    width=(len(nodes)+7)//8;raw=(ROOT/dominance['graph']/'conflicts.bin').read_bytes()
    allowed=[i for i in range(len(nodes)) if not all(i==member or (raw[member*width+i//8]>>(i%8))&1 for member in members)]""")
        source=source.replace('assert all(new<=old for new,old in zip(areas,previous))','assert all(new>=old for new,old in zip(areas,previous))')
        source=source.replace("'pivot_source_label':reference['node'],'allowed_current_nodes':len(allowed)", "'pivot_source_label':reference['node'],'reference_group_current_positions':members,'allowed_current_nodes':len(allowed)")
        source=source.replace("'joint_area_reduction_um2':previous[2]-areas[2]", "'joint_area_increase_from_single_reference_um2':areas[2]-previous[2]")
        source=source.replace("'provisional_reference_cell_excluded':bool(failures)", "'provisional_reference_group_excluded':bool(failures)")
        source=source.replace("'reference_cell_excluded':bool(failures)", "'reference_group_excluded':bool(failures)")
        source=source.replace("'fixed_queries_verified':8", "'fixed_queries_verified':3").replace("'exact_area_bounds_verified':24", "'exact_area_bounds_verified':9")
        source=source.replace("'excluded_reference_queries':sum(row['reference_cell_excluded'] for row in results)", "'excluded_reference_groups':sum(row['reference_group_excluded'] for row in results),'excluded_current_reference_cells':sum(len(row['reference_group_current_positions']) for row in results if row['reference_group_excluded'])")
        source=source.replace("'method':'Verify every common-reference rectangle corner", "'method':'Independently enumerate EVERY current node with the exact original parent label and geometry of each seed. Verify the enclosing anchor box and intersected conflict condition bit by bit, without producer integer intersection. Verify every common-reference rectangle corner")
        source=source.replace('all24area bounds','all9area bounds').replace('The pose-dependent proof excludes only its own reference cell, never graph-dominated cells.', 'A strict deficit excludes exactly the enumerated reference group, never additional graph-dominated cells.')
    save(ROOT/f'output/{kind}_h5_fixed29_group_pointwise_pilot_20261108.py',source)
for suffix in ['', '_audit']:
    source=(ROOT/f'output/run_h5_fixed29_conditional_pointwise_pilot{suffix}_stage_20261108.py').read_text(encoding='utf-8').replace('conditional_pointwise_pilot','group_pointwise_pilot').replace('conditional-pointwise-pilot','group-pointwise-pilot')
    save(ROOT/f'output/run_h5_fixed29_group_pointwise_pilot{suffix}_stage_20261108.py',source)
print('Prepared three complete-parent-group queries; no numeric stage opened.')
