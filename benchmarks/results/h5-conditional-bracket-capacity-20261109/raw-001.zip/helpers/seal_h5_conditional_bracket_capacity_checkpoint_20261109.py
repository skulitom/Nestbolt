"""Seal audited conditional bracket capacity, one closed fixed scope and two survivors."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
stages=[('fixed29-pivot-dominance','20261108','audit'),('fixed29-conditional-area-pilot','20261108','audit-v2'),('fixed29-conditional-pointwise-pilot','20261108','audit'),('fixed29-group-pointwise-pilot','20261108','audit'),('fixed29-conditional-frontier','20261108','audit'),('fixed29-reference-body-pilot','20261109','audit')]
process_specs=[]
for name,date,audit in stages:
    process_specs.append((name,date,True))
    if audit=='audit-v2':process_specs.append((name+'-audit',date,False))
    process_specs.append((name+'-'+audit,date,True))
process_paths=[ROOT/'output'/f'h5-{name}-process-{date}' for name,date,passed in process_specs]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-conditional-bracket-capacity-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-fixed29-reference-body-pilot-20261109';F=BASE/'audit';D=ROOT/'output/h5-fixed29-conditional-frontier-20261108'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-fixed29-pointwise-capacity-20261108'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['fixed_queries_verified']==5 and front['remaining_fixed29_cases']==2 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[ROOT/'output'/f'h5-{name}-{date}' for name,date,audit in stages]+[ROOT/'output/h5-fixed29-capacity-main-sync-20261108']+process_paths",
"['*h5*mixed*mode*20261107.py']":"['*h5_fixed29_pivot_dominance*20261108.py','*h5_fixed29_conditional*20261108.py','*h5_fixed29_group_pointwise*20261108.py','*h5_fixed29_reference_body*20261109.py','*h5_conditional_bracket_capacity*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_conditional_bracket_capacity_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for before,after in changes.items():assert before in prefix,before;prefix=prefix.replace(before,after)
exec(prefix)
copies=[];process_table=[]
for name,date,audit in stages:
    folder=ROOT/'output'/f'h5-{name}-{date}';assert load(folder/audit/'checks.json')['passed']
    copies.extend([(folder/'plan.json',name+'-plan.json'),(folder/audit/'checks.json',name+'-audit.json')])
    for file in ['case-results.json','pivot-results.json']:
        if (folder/audit/file).is_file():copies.append((folder/audit/file,name+'-'+file))
copies.extend([(D/'audit/remaining-cases.json','remaining-fixed29-cases.json'),(ROOT/'output/h5-fixed29-conditional-area-pilot-audit-correction-20261108.json','failed-audit-correction.json'),(ROOT/'output/h5-fixed29-capacity-main-sync-20261108/receipt.json','prior-main-push-receipt.json')])
for (name,date,passed),folder in zip(process_specs,process_paths):
    process=load(folder/'process.json');assert process['closed'] and process['passed']==passed and process['job']['active_processes']==0
    copies.append((folder/'process.json',name+'-process.json'));process_table.append({'stage':name,'raw_date_suffix':date,'seconds':process['complete_seconds'],'cap_seconds':process['job']['maximum_ms']/1000,'passed':passed,'closed':True,'active_processes':0})
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'process-summary.json',process_table)
remaining=load(D/'audit/remaining-cases.json');assert [row['empty_sites'] for row in remaining]==[[0,5,10],[5,10,11]]
for row in load(D/'audit/case-results.json'):shutil.copyfile(D/f"choice-{row['refinement_index']:02d}-frontier.json",OUT/f"choice-{row['refinement_index']:02d}-frontier.json")
runtime=load(PARENT/'runtime-bindings.json')
for name,expected in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==expected
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42536487515','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='221574863990cbfcec7e43b9b0b2275f66b73042'
success=sum(job['conclusion']=='success' for job in ci['jobs']);live=sum(job['status']!='completed' for job in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
total=front['complete_preparation_seconds_if_consumed'];assert total>60
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'new_fixed29_scope_exclusions':1,'remaining_fixed29_choices':2,'fixed29_choices_excluded_of455':453,'zero_clearance_exclusions_of455':428,'older_first32_cores_closed':8,'separate_five_column_cores_closed':680,'seed_bracket_cell_exclusions':11,'additional_clique_cell_exclusions':14,'remaining_nodes_in_open_scopes':sum(row['remaining_current_nodes'] for row in remaining),'failed_audits_preserved':1,'all13_processes_closed':True,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'whole_allocations_remaining':440})
write(OUT/'next-step.json',{'status':'one_more_exact_fixed29_scope_excluded','newly_closed_fixed29_choice':[11,12,13],'remaining_fixed29_choices':[[0,5,10],[5,10,11]],'authoritative_current_position_masks':'output/h5-fixed29-conditional-frontier-20261108/choice-{01,09}-frontier.json remaining_current_positions','original_graph_positions_preserved':True,'source_labels_are_not_current_positions':True,'proposal':'Use only the two surviving scope masks. A prospective stronger proof may subdivide complete remaining reference-cell anchor domains, preserve every closed boundary, and compute tighter common-reference pointwise covers/full-envelope conservation for all children. Case09 reference1854 currently has only561.664440mm2 surplus under the pointwise necessary bound; every child would need an independently complete proof before excluding its parent. No subdivision has been prepared or opened. Alternatively prepare a genuinely complete parent-group proof set with explicit bounded stages; the pilots here do not cover all3942 minimal rows. Never reopen unchanged closed SAT/optimizer calls. Current numeric lineage cannot support any optimizer or timed H5 pass; an eventual timed constructor must independently recompute source inputs and pass a separate complete preparation-inclusive preflight.','common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'consumed_preparation_seconds':total,'optimizer_allowed_from_current_lineage':False,'new_optimizer_models_prepared':False,'closed_optimizer_calls_reopened':False,'whole_allocation_candidates_remaining':440,'source_valid66':False,'H5_complete':False})
process_rows='\n'.join(f"| {row['stage']} | {row['seconds']:.6f} | {row['cap_seconds']:.0f} | {'Pass' if row['passed'] else 'Preserved failure'} |" for row in process_table)
report=f'''# Conditional bracket capacity — 2026-11-09

**The exact fixed29 arrangement omitting cog sites `[11,12,13]` is excluded.**
After verified conditional cell removals, its available occupied-envelope area
is at most **469,860.310592 mm²**, below the required **478,384 mm²** by
**8,523.689408 mm²**. Only **`[0,5,10]` and `[5,10,11]` remain** in this family:
453 of455 arrangements are excluded at the original0.2mm clearance, including
428 already excluded at zero clearance. No whole allocation or orientation
class is excluded. H2/H5 remain open at **60% completed milestone weight**.

These are **common-line occupied outer envelopes with holes reserved**, not
net material. All90 original holes remain in cutting geometry. The preceding
[scope audit](h5-fixed29-pointwise-capacity-20261108/occupancy-scope/checks.json)
binds production policy, original outer-envelope areas and rejection of parts
inside holes. No ordinary part-in-hole configuration is excluded. The fixed29
and twelve fixed cog poses retain their original identities; the first-sheet
movers are eight brackets and eight inserts, with the validated short9 unchanged.

## Complete pivot coverage and bounded conditional queries

[The conflict-row audit]({NAME}/fixed29-pivot-dominance-audit.json) verifies all
**7,319 possible bracket reference cells**, their source self-collision witnesses
and complete mappings to **3,942 minimal rows**. A chosen bracket leaves seven
other brackets and eight inserts. If rowA is a subset of rowB, the allowed
companions forB are a subset of those forA. This permits graph-only area deficits
to transfer through the recorded mapping. Independent replay checks2,975,446
antichain pairs; current compact positions and stable source labels stay distinct.

[Exactly nine predetermined queries]({NAME}/fixed29-conditional-area-pilot-pivot-results.json)
sample the minimum, median and maximum forbidden-row cardinalities in each
case. All27 family/joint bounds replay by independent horizontal and vertical
rectangle sweeps. Case21 reference613 fails by7,066.696282mm²; the certified
subset mapping excludes current bracket positions613–616. This pilot does not
claim to cover every minimal row.

The initial independent audit matched six area queries, then a local coordinate
variable overwrote its dominance record when recording the first deficit.
[The failed audit and correction]({NAME}/failed-audit-correction.json) remain
preserved. The producer was not repeated. A separately frozen corrected audit
verifies all nine queries; the complete failed audit cost remains charged.

[Eight pointwise queries]({NAME}/fixed29-conditional-pointwise-pilot-audit.json)
then use occupied-envelope rectangles common to every position of the reference
bracket. Their141µm square buffers remain strictly within the original0.2mm
clearance. Open forbidden companion anchors are subtracted from closed covers,
preserving all boundary points and lines. Independent replay verifies256 common
rectangle/cell corner checks,17,025 companion covers,380,225 complete Cartesian
boundary/interior classes and24 exact areas. Three more individual reference
cells are excluded. These pose-dependent results **do not transfer through
graph dominance**.

[Three complete parent-region groups]({NAME}/fixed29-group-pointwise-pilot-pivot-results.json)
cover every current child with the seed's original parent label and geometry.
Intersecting all member conflict rows gives a companion domain valid for any
chosen member. Common occupied rectangles use the whole enclosing anchor box.
Case01 group `[317,318]` and case21 group `[1461,1462,1463,1464]` fail; group
`[661,662,663,664]` remains open, while its earlier singleton664 exclusion stands.
The union of permitted graph, singleton and group deductions contains **11
distinct bracket positions**, with their proof provenance retained.

## Reconciled full-domain exclusion

[Independent frontier readback]({NAME}/fixed29-conditional-frontier-audit.json)
verifies12,371 source self-collision witnesses and2,471,360 directed root-clique
edges. Fourteen further cells are removed only where selecting that cell leaves
a clique-cover upper bound below the remaining required part count. Each
simultaneous-round witness is checked against the prior active set. All other
cells remain in the complete source cover.

| Omitted sites | Seed removals | Further count implications | Full joint area upper (mm²) | Result |
|---|---:|---:|---:|---|
| [0,5,10] | 2 | 9 | 497,091.028543 | Open |
| [5,10,11] | 0 | 0 | 484,740.614909 | Open |
| [11,12,13] | 9 | 5 | 469,860.310592 | Excluded |

The required global area is478,384mm². [All three full-domain results]({NAME}/fixed29-conditional-frontier-case-results.json)
and [the two remaining cases]({NAME}/remaining-fixed29-cases.json) preserve exact
integer bounds. The surviving masks retain **8,903 current nodes**. Case21's
retained-node record is negative evidence preceding its whole-case exclusion,
not an open search domain. No new optimizer graph/model or call is opened.

[Five whole-reference-envelope checks]({NAME}/fixed29-reference-body-pilot-audit.json)
tighten three surviving conditional bounds but exclude no further reference
cell. LetR be the companion union minus **fixed** forbidden regions, before
common-reference subtraction. The reference's full occupied area is at least
39,999mm²; its possible area outsideR is bounded exactly. Its compulsory
occupancy insideR reduces the space left for the seven other brackets and
eight inserts. This remains separate from the earlier common-moving-buffer
bound, avoiding double subtraction. All ten exact areas independently replay.

## Closed processes and remaining work

| Bounded stage | Complete process (s) | Cap (s) | Result |
|---|---:|---:|---|
{process_rows}

[All thirteen processes close]({NAME}/process-summary.json) with zero children,
unchanged CCD1/thread controls and2GiB Windows Job limits. Raw filenames retain
their preparation-date suffix; each process also records its actual UTC opening.
Consumed numeric preparation is **{total:.6f}s**, including the failed audit.
No optimizer, timer reset or timed H5 acceptance is permitted from this lineage.

[Next]({NAME}/next-step.json), a complete subdivision proof could tighten
reference-cell bounds in the two surviving scopes. None has been prepared.
All440 whole-job allocations, full66 source/native/material validation,
production integration and the full H5 matrix remain open. The valid64 layout
stays best. The separate eight older first32 and680 five-column cores stay
closed. Product, README and release state are unchanged.

[The preceding checkpoint reached main22157486]({NAME}/prior-main-push-receipt.json).
[Its CI at review]({NAME}/main-ci-at-review.json) has **{success} passed / {live}
live jobs**; this checkpoint awaits the ordinary push gate.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve every consumed input.
'''
# Readable public prose; leave identifiers, raw scripts and JSON keys untouched.
for before,after in {'453 of455':'453 of 455','original0.2mm':'original 0.2 mm','All90':'All 90','rowA':'row A','rowB':'row B','forB':'for B','forA':'for A','checks2,975,446':'checks 2,975,446','All27':'All 27','Case21':'Case 21','Case01':'Case 01','reference613':'reference 613','by7,066.696282mm²':'by 7,066.696282 mm²','positions613–616':'positions 613–616','Their141µm':'Their 141 µm','verifies256':'verifies 256','checks,17,025':'checks, 17,025','covers,380,225':'covers, 380,225','and24':'and 24','singleton664':'singleton 664','verifies12,371':'verifies 12,371','and2,471,360':'and 2,471,360','is478,384mm²':'is 478,384 mm²','LetR':'Let R','outsideR':'outside R','insideR':'inside R','39,999mm²':'39,999 mm²','and2GiB':'and 2 GiB',f'**{total:.6f}s**':f'**{total:.6f} s**','All440':'All 440','full66':'full 66-part','valid64':'valid 64-part','and680':'and 680','main22157486':'main 22157486'}.items():report=report.replace(before,after)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
entry=f'**2026-11-09 H5 conditional bracket capacity:** [independent common-line occupied-envelope proofs]({{link}}) exclude fixed29 omitted sites [11,12,13] by 8,523.689408 mm². Only [0,5,10] and [5,10,11] remain; 453/455 are excluded at original 0.2 mm clearance, including 428 at zero clearance. Complete reference-cell mappings cover 7,319 bracket positions with 3,942 minimal rows. Fixed nine-query, eight-query pointwise and three-group pilots prove eleven distinct cell exclusions; fourteen certified clique-count implications then tighten the complete global cover. Independent replay checks 12,371 self-collision witnesses, 2,471,360 directed clique edges and all nine global areas. Five full-reference-envelope checks tighten three bounds without more exclusions. All thirteen processes close; the failed initial independent audit remains preserved and charged. Consumed preparation {total:.6f} s cannot reset or open an optimizer. Holes remain reserved for common-line mode; no ordinary part-in-hole or whole-allocation exclusion is claimed. All 440 whole allocations remain; the valid 64-part layout stays best and H2/H5 stay open at 60%. Main 22157486 has {success} passed/{live} live CI jobs at review; ordinary push pending. Product/releases unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [conditional bracket capacity](../benchmarks/results/{NAME}.md).
Common-line occupied-envelope proofs, with holes reserved, exclude omitted cog
sites [11,12,13] by 8,523.689408 mm². Only [0,5,10] and [5,10,11] remain in
this exact fixed29 family: 453/455 excluded, including 428 at zero clearance.
Eleven conditional cell exclusions and fourteen verified clique implications
tighten the complete global cover. The two surviving scopes retain 8,903 nodes.
No whole allocation or ordinary part-in-hole configuration is excluded.
All thirteen bounded processes close; the failed independent audit remains
preserved and charged. Consumed preparation is {total:.6f} s; no optimizer or
timer reset is permitted. All 440 whole-job allocations remain, the valid
64-part layout stays best, and H2/H5 remain open at 60% completed milestone weight.
The separate eight older first32 and 680 five-column cores remain closed.
Prior checkpoint reached main 22157486; its CI has {success} passed/{live} live
jobs at review. This checkpoint awaits ordinary push. Product/releases unchanged.
'''
content=content[:start]+intro+content[end:];content=content.replace('# Status — 2026-11-08','# Status — 2026-11-09',1)
status.write_text(content,encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'consumed_preparation_seconds':total,'remaining_fixed29_scopes':2,'main_ci_passed':success,'main_ci_live':live})
