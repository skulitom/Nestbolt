"""Independent exact full-bracket-envelope conservation without double subtraction."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import json,time
from h5_exact_rectangle_areas_20261108 import horizontal_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-reference-body-pilot-20261109';OUT=BASE/'audit'
FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108';POINT=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2);stream.write('\n')

OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,FRONT/'audit',POINT/'audit',OLD/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for name,expected in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==expected;bindings[name]=expected
for path in [Path(__file__)]+list(BASE.glob('*.json')):bindings[path.relative_to(ROOT).as_posix()]=digest(path)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently reconstruct the complete query selection from current surviving scopes/masks. Verify every original alias has occupied outer-envelope area>39999mm2 and every current reference anchor component is covered. Reconstruct W by source-component Minkowski rectangles, verify exact pointwise companionU and ONLYfixed forbiddenF input identity. Independently compute area(U minusF) and area(W minus(U unionF)) by horizontal interval merging, not producer vertical prefix sweeps. Replay compulsory reference-body overlap and separate alternative common-buffer bound. No common selected material is treated as fixed or deducted twice. Every exclusion is only for the actual selected source cell in common-line reserved-hole mode.'})
remaining=load(FRONT/'audit/remaining-cases.json');active={case['refinement_index']:set(load(FRONT/f"choice-{case['refinement_index']:02d}-frontier.json")['remaining_current_positions']) for case in remaining}
queries=[query for query in load(POINT/'audit/pivot-results.json') if not query['reference_cell_excluded'] and query['refinement_index'] in active and query['pivot_current_position'] in active[query['refinement_index']]]
saved=load(BASE/'pivot-results.json');assert len(saved)==len(queries) and load(BASE/'plan.json')['selection']==[[query['refinement_index'],query['pivot_current_position']] for query in queries]
geometry=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];aliases=load(OLD/'source-alias-envelopes.json');results=[]
for query,row in zip(queries,saved):
    index=query['refinement_index'];pivot=query['pivot_current_position'];key=f'choice-{index:02d}-pivot-{pivot:04d}'
    graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph'];node=load(graph/'nodes.json')[pivot];source=geometry[node['geometry']];assert source['family']=='bracket'
    for family,mode in source['aliases']:
        alias=next(entry for entry in aliases if entry['geometry']==node['geometry'] and entry['family']==family and entry['mode']==mode)
        assert Q(alias['exact_posed_source_area_mm2'])>39999 and alias['source_area_lower_mm2']==39999
    reference=load(COVER/f'choice-{index:02d}-covers.json')[pivot];assert reference['current_graph_position']==pivot and reference['source_node_label']==node['node'];possible=set()
    for left,bottom,right,top in reference['remaining_closed_anchor_boxes_um']:
        for x0,y0,x1,y1 in source['all_alias_component_outer_rectangles_um']:
            rectangle=(max(left+x0,stock[0]),max(bottom+y0,stock[1]),min(right+x1,stock[2]),min(top+y1,stock[3]))
            if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:possible.add(rectangle)
    possible=sorted(possible)
    assert load(BASE/(key+'-reference-cover.json'))=={'reference_current_position':pivot,'reference_source_node_label':node['node'],'complete_reference_anchor_boxes_um':reference['remaining_closed_anchor_boxes_um'],'possible_reference_occupied_regions_um':[list(rectangle) for rectangle in possible]}
    regions=load(POINT/(key+'-regions.json'));fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    fixed_only=horizontal_areas(regions['bracket'],regions['insert'],fixed)[2]
    outside=horizontal_areas(possible,[],regions['bracket']+regions['insert']+fixed)[0]
    compulsory=max(0,39999000000-outside);upper=fixed_only-compulsory
    assert fixed_only>=query['joint_area_upper_um2']
    expected={'refinement_index':index,'empty_sites':query['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':node['node'],'fixed_only_companion_area_upper_um2':fixed_only,'reference_possible_area_outside_companion_and_fixed_um2':outside,'reference_occupied_area_lower_um2':39999000000,'compulsory_reference_occupancy_in_companion_um2':compulsory,'full_body_companion_area_upper_um2':upper,'prior_common_buffer_companion_area_upper_um2':query['joint_area_upper_um2'],'combined_companion_area_upper_um2':min(upper,query['joint_area_upper_um2']),'required_other_joint_area_lower_um2':438385000000,'provisional_reference_cell_excluded':upper<438385000000,'dominance_transfer_permitted':False}
    assert expected==row;results.append({**row,'reference_cell_excluded':upper<438385000000});print({'case':index,'pivot':pivot,'body_upper_um2':upper,'excluded':upper<438385000000},flush=True)
process=load(ROOT/'output/h5-fixed29-reference-body-pilot-process-20261109/process.json');assert process['closed'] and process['passed'];charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'pivot-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'fixed_queries_verified':len(queries),'exact_area_bounds_verified':2*len(queries),'excluded_reference_queries':sum(row['reference_cell_excluded'] for row in results),'fixed_only_capacity_before_common_reference_subtraction':True,'common_reference_region_not_in_fixed_obstacles':True,'dominance_transfer_permitted':False,'whole_fixed_scope_exclusions':0,'remaining_fixed29_cases':2,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
