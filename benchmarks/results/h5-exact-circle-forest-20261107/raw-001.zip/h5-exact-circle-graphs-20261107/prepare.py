"""Exact Euclidean necessary constraints at the unchanged original clearance."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-exact-circle-graphs-20261107';UNION=ROOT/'output/h5-refined-polygon-union-20261107'
RAW=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
audit=load(UNION/'audit/checks.json');assert audit['passed'] and audit['remaining_fixed29_choices']==4
rows=audit['choices'];raw=load(RAW/'integer-source.json');templates=load(RAW/'collision-polygons.json');geom=load(SRC/'geometry-domains.json');assert load(RAW/'audit/checks.json')['passed'] and load(JOB)['clearance']==.2
inputs=[Path(__file__),UNION/'audit/plan.json',UNION/'audit/checks.json',RAW/'audit/plan.json',RAW/'audit/checks.json',RAW/'integer-source.json',RAW/'collision-polygons.json',SRC/'geometry-domains.json',JOB]
for row in rows:inputs.extend(ROOT/row['graph']/n for n in ['checks.json','nodes.json','conflicts.bin','root-covers.json'])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':rows,'required_clearance_mm':.2,'strict_radius_um':200,'query_scan_seconds':25,'per_case_graph_seconds':15,'preparation_seconds':85,'maximum_process_seconds':95,'solver_calls':0,'repeat_permitted':False,'method':'Use exact distance to unexpanded original source convex collision hulls and inner-rectangle differences. A cog closed-cell removal certifies each corner strictly within200um of one convex source hull; convexity covers the entire cell. A pair conflict certifies the full relative-anchor box strictly within200um of one unexpanded inner-rectangle difference. Preserve all inherited constraints, cells not certified, mode aliases and boundaries. No larger clearance or numerical validation guard is used.'})
D=int(raw['scaled_units_per_micrometre']);radius=200*D;radius2=radius*radius;shifts=[tuple(map(int,s['translation_scaled'])) for s in raw['sites']]
polys=[[tuple(map(int,p)) for p in t['vertices_scaled']] for t in templates]
cells=[];keys={};mappings=[]
for row in rows:
    ns=load(ROOT/row['graph']/'nodes.json');mapping=[];mask=((1<<15)-1)^sum(1<<s for s in row['empty_sites'])
    for node in ns:
        key=(node['geometry'],*node['bounds_um'])
        if key not in keys:keys[key]=len(cells);cells.append({'cell':len(cells),'geometry':node['geometry'],'bounds_um':node['bounds_um'],'present_sites':0})
        ci=keys[key];cells[ci]['present_sites']|=mask;mapping.append(ci)
    mappings.append(mapping)
write(OUT/'cells.json',cells);bounds=np.array([c['bounds_um'] for c in cells],dtype=np.float64);masks=np.array([c['present_sites'] for c in cells],dtype=np.int64)
bygeom={g:np.array([i for i,c in enumerate(cells) if c['geometry']==g],dtype=np.int64) for g in range(10)}
certificates=[];certmap={};scan_complete=True;candidates_checked=0
def corner_certificate(point,poly):
    if all(cross(a,b,point)>=0 for a,b in zip(poly,poly[1:]+poly[:1])):return {'inside':True}
    for edge,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
        dx,dy=b[0]-a[0],b[1]-a[1];vx,vy=point[0]-a[0],point[1]-a[1];length2=dx*dx+dy*dy;dot=vx*dx+vy*dy
        if dot<=0:
            if vx*vx+vy*vy<radius2:return {'edge':edge,'parameter':'0'}
        elif dot>=length2:
            if (point[0]-b[0])**2+(point[1]-b[1])**2<radius2:return {'edge':edge,'parameter':'1'}
        elif (dx*vy-dy*vx)**2<radius2*length2:return {'edge':edge,'numerator':str(dot),'denominator':str(length2)}
    return None
for t,poly in zip(templates,polys):
    ids=bygeom[t['geometry']];bs=bounds[ids];local=[min(x for x,y in poly)/D,min(y for x,y in poly)/D,max(x for x,y in poly)/D,max(y for x,y in poly)/D]
    for site,(sx,sy) in enumerate(shifts):
        if time.perf_counter()-start>=25:scan_complete=False;break
        dx,dy=sx/D,sy/D
        selected=(bs[:,0]>local[0]+dx-200-1e-6)&(bs[:,1]>local[1]+dy-200-1e-6)&(bs[:,2]<local[2]+dx+200+1e-6)&(bs[:,3]<local[3]+dy+200+1e-6)&((masks[ids]&(1<<site))!=0)
        for ci in ids[selected]:
            ci=int(ci)
            if (ci,site) in certmap:continue
            if time.perf_counter()-start>=25:scan_complete=False;break
            candidates_checked+=1;x0,y0,x1,y1=cells[ci]['bounds_um'];corners=[]
            for x,y in product([x0,x1],[y0,y1]):
                proof=corner_certificate((x*D-sx,y*D-sy),poly)
                if proof is None:break
                corners.append(proof)
            if len(corners)==4:
                certmap[ci,site]=len(certificates);certificates.append({'certificate':len(certificates),'cell':ci,'site':site,'template':t['template'],'corners':corners})
        if not scan_complete:break
    if not scan_complete:break
write(OUT/'certificates.json',certificates);results=[]
for row,mapping in zip(rows,mappings):
    case_start=time.perf_counter();old=ROOT/row['graph'];original=load(old/'nodes.json');N=len(original);folder=OUT/f"choice-{row['refinement_index']:02d}";folder.mkdir();removed=[]
    for ni,ci in enumerate(mapping):
        for site in range(15):
            if site not in row['empty_sites'] and (ci,site) in certmap:removed.append({'old_graph_node':ni,'certificate':certmap[ci,site]});break
    remove={r['old_graph_node'] for r in removed};kept=[i for i in range(N) if i not in remove];ns=[original[i] for i in kept];n=len(ns)
    matrix=np.unpackbits(np.frombuffer((old/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(N,(N+7)//8),axis=1,bitorder='little')[:,:N].astype(bool)
    inherited=matrix[np.ix_(kept,kept)];graph=inherited.copy();bs=np.array([r['bounds_um'] for r in ns],dtype=np.int64);assert np.max(np.abs(bs))<10**7
    assert max(abs(v) for g in geom for r in g['inner_rectangles_um'] for v in r)<10**7
    # Differences <4e7; sum of two squared distances <3.2e15 <2**63.
    groups={g:np.array([i for i,r in enumerate(ns) if r['geometry']==g],dtype=np.int64) for g in range(10)};edges={}
    for ga in range(10):
        for gb in range(ga,10):
            assert time.perf_counter()-case_start<15 and time.perf_counter()-start<85
            ia,ib=groups[ga],groups[gb]
            if not len(ia) or not len(ib):continue
            a,b=bs[ia],bs[ib];lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3];ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1];new=np.zeros((len(ia),len(ib)),dtype=bool)
            for ri,ra in enumerate(geom[ga]['inner_rectangles_um']):
                for rj,rb in enumerate(geom[gb]['inner_rectangles_um']):
                    dx=np.maximum(np.maximum(ra[0]-rb[2]-lx,ux-ra[2]+rb[0]),0);dy=np.maximum(np.maximum(ra[1]-rb[3]-ly,uy-ra[3]+rb[1]),0)
                    hit=(dx*dx+dy*dy<40000)&~inherited[np.ix_(ia,ib)]&~new
                    for ai,bi in zip(*np.nonzero(hit)):
                        u,v=int(ia[ai]),int(ib[bi])
                        if u==v:continue
                        left,right,ca,cb=(u,v,ri,rj) if u<v else(v,u,rj,ri);edges.setdefault((left,right),{'a':left,'b':right,'component_a':ca,'component_b':cb})
                    new|=hit
            graph[np.ix_(ia,ib)]|=new;graph[np.ix_(ib,ia)]|=new.T
    edges=[edges[k] for k in sorted(edges)];assert len(edges)==np.count_nonzero(np.triu(graph&~inherited,1))
    inverse={v:i for i,v in enumerate(kept)};covers=[[[inverse[i] for i in group if i in inverse] for group in family] for family in load(old/'root-covers.json')];covers=[[g for g in family if g] for family in covers]
    (folder/'conflicts.bin').write_bytes(np.packbits(graph,axis=1,bitorder='little').tobytes())
    for name,value in [('nodes.json',ns),('kept-old-node-ids.json',kept),('removed.json',removed),('added-edges.json',edges),('root-covers.json',covers)]:write(folder/name,value)
    result={'refinement_index':row['refinement_index'],'source_selection':row['source_selection'],'empty_sites':row['empty_sites'],'old_graph':row['graph'],'compact_nodes':n,'bracket_nodes':sum(r['family']==0 for r in ns),'insert_nodes':sum(r['family']==1 for r in ns),'row_bytes':(n+7)//8,'removed_nodes':len(removed),'added_edges':len(edges),'genuinely_stronger':bool(removed or edges),'combined_new_removals_including_union':len(removed)+row['removed_nodes'],'combined_genuinely_stronger':bool(removed or edges or row['removed_nodes']),'root_clique_counts':list(map(len,covers)),'conflict_bytes_sha256':digest(folder/'conflicts.bin'),'seconds':time.perf_counter()-case_start}
    write(folder/'checks.json',result);results.append(result);print(json.dumps(result),flush=True)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'choices':results,'source_cog_scan_complete':scan_complete,'candidate_cells_checked':candidates_checked,'source_cog_certificates':len(certificates),'removed_nodes':sum(r['removed_nodes'] for r in results),'added_edges':sum(r['added_edges'] for r in results),'solver_calls':0,'independent_audit_pending':True,'H5_complete':False})
