"""Freeze first factored models on four independently stronger source graphs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-forest-sat-batch-20261107';OUT.mkdir();GBASE=ROOT/'output/h5-exact-circle-graphs-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
audit=load(GBASE/'audit/checks.json');assert audit['passed'] and audit['cases_with_genuine_combined_source_changes']==4
controls=load(ROOT/'output/h5-sat-forest-controls-20261107/checks.json');assert controls['passed'] and controls['helper_sha256']==digest(ROOT/'output/h5_sat_forest_encoding_20261107.py')
names=['prepare_h5_clique_sat_model_20261107.py','audit_h5_clique_sat_model_20261107.py','solve_h5_clique_sat_20261107.py','run_h5_clique_sat_20261107.py','audit_h5_clique_sat_result_20261107.py']
templates={name:(ROOT/'output'/name).read_text(encoding='utf-8') for name in names}
prefix=(ROOT/'output/h5_forest_model_audit_prefix_20261107.py').read_text(encoding='utf-8')
rows=[]
for choice in audit['choices']:
    index=choice['refinement_index'];assert choice['combined_genuinely_stronger'];G=GBASE/f'choice-{index:02d}';gc=load(G/'checks.json');sites=choice['empty_sites']
    model=f'h5-forest-sat-{index:02d}-model-20261107';call=f'h5-forest-sat-{index:02d}-call-20261107';result=f'h5-forest-sat-{index:02d}-result-audit-20261107'
    renamed={name:name.replace('_20261107.py',f'_forest_{index:02d}_20261107.py') for name in names};scripts={}
    for name,original in templates.items():
        text=original
        if name.startswith('prepare_'):
            text=text.replace('from h5_sat_encoding_20261107 import threshold','from h5_sat_encoding_20261107 import threshold\nfrom h5_sat_forest_encoding_20261107 import forest')
            text=text.replace('h5-first57-frontier-refined-graphs-v2-20261106/choice-02',f'h5-exact-circle-graphs-20261107/choice-{index:02d}').replace('[0,5,11]',str(sites)).replace('==2135','=='+str(gc['compact_nodes']))
            text=text.replace("paths=[G/'checks.json'", "assert load(G.parent/'audit/checks.json')['passed'] and gc['combined_genuinely_stronger']\nassert load(ROOT/'output/h5-sat-forest-controls-20261107/checks.json')['passed']\npaths=[G.parent/'audit/plan.json',ROOT/'output/h5_sat_forest_encoding_20261107.py',ROOT/'output/h5-sat-forest-controls-20261107/checks.json',ROOT/'output/h5-sat-forest-controls-20261107/plan.json',G/'checks.json'")
            text=text.replace("'binary_proof_byte_limit':268435456","'binary_proof_byte_limit':67108864")
            text=text.replace("'method':'A fresh arrangement and explicit clique-count CNF. Preserve every certified pair clause. A Boolean group is equivalent to OR of the cells in each complete source-verified conflict clique. Each clique admits at most1 cell; count at least8 selected groups per family. This replaces the long all-cell threshold circuit by the exact equivalent group count on independent sets.'", "'method':'Factor every certified upper-triangle conflict neighborhood into a disjoint cover of complete interval-tree segments. Two forward child-to-parent implications force any selected leaf up its ancestor path. Each negative cell/segment clause forbids exactly the original cell with every covered neighbor. The existential projection onto original cells is exactly the original pair model. A complete source-verified clique partition and explicit group ORs still require at least8 selected groups per family.'")
            text=text.replace("'distinct_from_closed_pilot':{'old_empty_sites':[0,5,12],'new_empty_sites':"+str(sites)+",'old_pilot_repeated':False}","'source_strengthening':"+repr({'source_audit':'output/h5-exact-circle-graphs-20261107/audit/checks.json','combined_new_cell_removals':choice['combined_new_removals_including_union'],'new_source_edges':choice['added_edges'],'old_calls_repeated':False}))
            text=text.replace('top=n;groups=[];extras=[];families=[];gates=[]', "tree,blocks,factored,forest_top,implications=forest(n,rows)\nwrite('forest.json',tree);write('neighbor-blocks.json',blocks)\ntop=forest_top;groups=[];extras=[];families=[];gates=[]")
            begin=text.index('    for i,row in enumerate(rows):',text.index("with (OUT/'model.cnf')"));end=text.index('    for c in extras:',begin)
            text=text[:begin]+"    for c in factored:f.write(' '.join(map(str,c))+' 0\\n')\n"+text[end:]
            text=text.replace('edgecount+len(extras)','len(factored)+len(extras)')
            text=text.replace("'conflict_clauses':edgecount", "'original_graph_edges':edgecount,'forest_variables':forest_top-n,'forest_nodes':len(tree),'forest_implication_clauses':implications,'neighbor_block_clauses':sum(len(r['segments']) for r in blocks),'conflict_clauses':len(factored)")
        elif name=='audit_h5_clique_sat_model_20261107.py':
            begin=original.index('    for family in [0,1]:',original.index("with (OUT/'model.cnf')"))
            text=prefix+original[begin:]
            text=text.replace("edges==checks['conflict_clauses']","edges==checks['original_graph_edges']")
            text=text.replace("'conflict_clauses_verified':edges", "'source_conflict_pairs_verified':edges,'factored_conflict_clauses_verified':factor_count,'forest_segments_verified':len(tree)")
            text=text.replace('Every source-certified conflict clause remains.', 'Every original source conflict is covered exactly once by a negative cell/segment clause; acyclic forward implications force selected covered leaves to their segment variables. Conversely assigning each segment its actual leaf OR extends every independent set. Thus existential projection onto original selectors is exactly the original pair model.')
        elif name.startswith('solve_'):
            text=text.replace("'proof_bytes':(OUT/'proof.drat.bin').stat().st_size", "'proof_bytes_before_solver_destruction':(OUT/'proof.drat.bin').stat().st_size")
            text=text.replace("write('result.json',result);print(result)","result.update({'proof_bytes':(OUT/'proof.drat.bin').stat().st_size,'proof_sha256_after_solver_destruction':sha256((OUT/'proof.drat.bin').read_bytes()).hexdigest()})\nwrite('result.json',result);print(result)")
        elif name=='audit_h5_clique_sat_result_20261107.py':
            text=text.replace("ROOT/'output/h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json'","ROOT/'output/h5-polygon-sat-batch-20261107/audit/remaining-fixed29-choices.json'")
        text=text.replace('h5-first57-clique-sat-model-20261107',model).replace('h5-first57-clique-sat-call-20261107',call).replace('h5-first57-clique-sat-result-audit-20261107',result)
        for before,after in renamed.items():text=text.replace(before,after)
        p=ROOT/'output'/renamed[name];compile(text,str(p),'exec')
        with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
        scripts[name]={'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p)}
    rows.append({'graph_index':index,'empty_sites':sites,'compact_nodes':gc['compact_nodes'],'new_source_cell_removals':choice['combined_new_removals_including_union'],'new_source_edges':choice['added_edges'],'model':model,'call':call,'result_audit':result,'scripts':scripts})
rows.sort(key=lambda r:(r['compact_nodes'],r['graph_index']))
inputs=[Path(__file__),ROOT/'output/h5_forest_model_audit_prefix_20261107.py',GBASE/'audit/plan.json',GBASE/'audit/checks.json',ROOT/'output/h5-sat-forest-controls-20261107/plan.json',ROOT/'output/h5-sat-forest-controls-20261107/checks.json',ROOT/'output/h5-polygon-sat-batch-20261107/audit/remaining-fixed29-choices.json']+[ROOT/'output'/n for n in names]
plan={'utc':datetime.now(timezone.utc).isoformat(),'selection':rows,'cases':4,'baseline_fixed29_choices':4,'baseline_required_clearance_exclusions':451,'frozen_per_case_search_seconds':60,'frozen_conflict_budget':1000000,'frozen_binary_proof_bytes':67108864,'frozen_job_committed_memory_bytes':2147483648,'one_call_per_new_source_graph':True,'retry_permitted':False,'stage_caps_seconds':{'prepare':120,'model_audit':120,'call':100,'result_audit':90},'global_batch_seconds':1200,'full_job_construction_budget_claimed':False,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}}
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(plan,f,indent=2);f.write('\n')
runner=(ROOT/'output/run_h5_clique_sat_batch_20261107.py').read_text(encoding='utf-8').replace('h5-first57-clique-sat-batch-20261107','h5-forest-sat-batch-20261107')
with (ROOT/'output/run_h5_forest_sat_batch_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
print({'prepared':True,'cases':4,'order':[r['empty_sites'] for r in rows]})
