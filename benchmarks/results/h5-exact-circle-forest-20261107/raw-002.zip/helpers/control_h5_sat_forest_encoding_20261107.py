from pathlib import Path
from hashlib import sha256
from itertools import product,combinations
import json,time
from h5_sat_forest_encoding_20261107 import forest
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-sat-forest-controls-20261107';OUT.mkdir();start=time.perf_counter()
checks=0;extensions=0;n=5;pairs=list(combinations(range(n),2))
for graph_bits in range(1<<len(pairs)):
    rows=[1<<i for i in range(n)]
    for k,(a,b) in enumerate(pairs):
        if graph_bits>>k&1:rows[a]|=1<<b;rows[b]|=1<<a
    tree,blocks,clauses,top,imp=forest(n,rows);assert len(tree)==2*n-1 and top==2*n-1 and imp==2*(n-1)
    for bits in range(1<<n):
        source_valid=all(not(bits>>a&1 and bits>>b&1) for k,(a,b) in enumerate(pairs) if graph_bits>>k&1)
        exists=False
        for aux in range(1<<(top-n)):
            values={i+1:bool(bits>>i&1) for i in range(n)}|{n+i+1:bool(aux>>i&1) for i in range(top-n)}
            sat=all(any(values[abs(l)]==(l>0) for l in c) for c in clauses);extensions+=1
            exists|=sat
        assert exists==source_valid;checks+=1
result={'passed':True,'all_simple_five_vertex_graphs':1<<len(pairs),'original_selector_assignments':checks,'all_auxiliary_extensions_checked':extensions,'seconds':time.perf_counter()-start,'helper_sha256':sha256((ROOT/'output/h5_sat_forest_encoding_20261107.py').read_bytes()).hexdigest(),'solver_calls':0,'claim':'Exact existential projection onto original selectors for every five-vertex graph; full research models still require independent source/coverage/clause audits.'}
with (OUT/'checks.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'output/h5_sat_forest_encoding_20261107.py']}},f,indent=2);f.write('\n')
print(result)
