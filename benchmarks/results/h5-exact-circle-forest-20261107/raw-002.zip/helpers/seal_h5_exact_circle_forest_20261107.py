from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-exact-circle-forest-20261107';OUT=ROOT/'benchmarks/results'/NAME
B=ROOT/'output/h5-forest-sat-batch-20261107';F=B/'audit';U=ROOT/'output/h5-refined-polygon-union-20261107';G=ROOT/'output/h5-exact-circle-graphs-20261107';SYNC=ROOT/'output/h5-polygon-clearance-main-sync-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');union=load(U/'audit/checks.json');geometry=load(G/'audit/checks.json');controls=load(ROOT/'output/h5-sat-forest-controls-20261107/checks.json')
assert front['passed'] and front['remaining_fixed29_choices']==4 and front['accepted_proofs']==0 and front['limited_calls']==4
assert union['passed'] and union['new_removed_node_occurrences']==1
assert geometry['passed'] and geometry['combined_new_cell_removals']==3 and geometry['new_pair_conflicts']==15 and geometry['cases_with_genuine_combined_source_changes']==4
assert controls['passed'] and load(SYNC/'receipt.json')['new_main']=='909db92ea6e9225394cf4954dc08fe57e2015b75'
for stem in ['h5-polygon-limited-prefixes-20261107','h5-forest-limited-prefixes-20261107']:
    inspection=load(ROOT/'output'/stem/'checks.json');assert inspection['passed'] and inspection['complete_prefix_candidates']==0 and len(inspection['inspections'])==4
inventory_ast=ast.parse((ROOT/'output/seal_h5_polygon_clearance_proofs_20261107.py').read_text(encoding='utf-8')).body
def assignment(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
inventory_start=next(i for i,node in enumerate(inventory_ast) if assignment(node,'setup'));inventory_end=next(i for i,node in enumerate(inventory_ast) if assignment(node,'walker'))
exec(compile(ast.Module(body=inventory_ast[inventory_start:inventory_end],type_ignores=[]),'historical-parent-archives','exec'))
PARENTS.append(ROOT/'benchmarks/results/h5-polygon-clearance-proofs-20261107')
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[B,U,G,SYNC]+[ROOT/'output'/n for n in ['h5-refined-polygon-union-process-20261107','h5-exact-circle-graphs-process-20261107','h5-sat-forest-controls-20261107','h5-polygon-limited-prefixes-20261107','h5-forest-limited-prefixes-20261107']]
for row in load(B/'plan.json')['selection']:folders.extend(ROOT/'output'/row[key] for key in ['model','call','result_audit'])
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*refined_polygon_union*20261107.py','*h5*exact_circle*20261107.py','*h5*forest*20261107.py','*h5*limited_prefixes*20261107.py']:
    for p in (ROOT/'output').glob(pattern):
        if p.is_file():add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_polygon_clearance_proofs_20261107.py','push_h5_polygon_clearance_checkpoint_20261107.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','frontier-audit.json'),(F/'case-results.json','case-results.json'),(F/'remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(F/'remaining-source-graphs.json','remaining-source-graphs.json'),(F/'next-step.json','next-step.json'),(B/'process.json','batch-process.json'),(U/'audit/checks.json','union-audit.json'),(G/'audit/checks.json','circle-audit.json'),(ROOT/'output/h5-sat-forest-controls-20261107/checks.json','encoding-controls.json'),(ROOT/'output/h5-polygon-limited-prefixes-20261107/checks.json','previous-stream-inspection.json'),(ROOT/'output/h5-forest-limited-prefixes-20261107/checks.json','current-stream-inspection.json'),(SYNC/'receipt.json','main-sync-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Exact circular clearance and factored graph models — 2026-11-07

New source proofs remove **three impossible cells** and add **15 pair conflicts**
across the four remaining fixed29/current-cog arrangements. Every resulting
graph is genuinely stronger than its previous closed model. A more compact
Boolean encoding preserves all original conflicts, but its four new bounded
calls still reach their proof-size limits. **No further arrangement is excluded.**
The frontier stays at **four**, with **451 of 455 excluded at original 0.2 mm
clearance** and 427 even at zero clearance. All 440 whole allocations and full66
validation remain open. H2/H5 stay open at **60% completed milestone weight**.

## Exact unions on complete refined cells

[Independent subdivision replay]({NAME}/union-audit.json) checks 10,900 distinct
queries and 10,914 tree records on the four current refined domains. Both closed
children exactly cover every split, including their shared boundary. Three
closed leaves have 288 exact corner halfplane checks. One whole source cell
is proved covered by the union of the sixteen-direction cog collision polygons;
it is removed from [0,5,10]. All other cells remain, including every source
alias and boundary. The scan has seven exact splits, maximum depth two and no
query overrun. Preparation/audit processes close in 1.571373/1.747699 seconds.
The other three unchanged cases receive no call at this stage.

## Exact Euclidean clearance

[The new circular-distance audit]({NAME}/circle-audit.json) uses unexpanded
original cog/source-inner collision hulls and source-inner rectangle differences.
For each removed cell corner it supplies an exact rational point inside a source
hull or on one of its edges at distance strictly below 200 µm. Convex combinations
of those points stay inside the same hull, and convex combinations of their
error vectors stay inside the clearance disk. This proves the whole closed cell
impossible. Eight exact corner certificates remove two further cells, one each
from [5,10,11] and [10,11,12].

For pair conflicts, independent pointwise clamping checks all four corners of
the complete relative-anchor box against one original source-inner difference
rectangle. All 60 exact squared-distance tests are below 40,000 µm², certifying
15 new incompatible pairs. The same convexity argument covers the full box.
This uses the original required clearance, with no increased gap, numerical
validator guard or double expansion. All inherited conflicts remain; all
33,803,472 retained unordered graph pairs and complete clique partitions pass.
Preparation/audit processes close in 3.559523/0.888288 seconds.

## A compact, equivalent conflict encoding

A complete binary interval tree represents contiguous sets of original cell
selectors. Each internal segment has two forward child-to-parent implications.
Selecting a leaf therefore forces every ancestor segment true. Each cell's
larger-index conflict neighbors are partitioned into disjoint complete segments;
a negative cell/segment clause forbids exactly those original conflicts.
No segment contains a non-neighbor, every conflict is covered exactly once and
every internal segment is verified as the union of its two children.

Conversely, assigning each segment the actual OR of its leaves extends every
original independent set to these auxiliary variables. The existential
projection onto the original selectors is therefore exactly the original pair
model. Complete source conflict-clique partitions and explicit group ORs still
require eight selected brackets and eight selected inserts; source cell capacity
remains one. No original geometric constraint is omitted.

[Exhaustive controls]({NAME}/encoding-controls.json) verify every one of the
1,024 simple five-node graphs, all 32,768 original selector assignments and all
524,288 auxiliary extensions. The full research model audits independently
verify **15,208,033 original graph conflicts** represented by **2,637,822 factored
clauses**, including all child implications. Total model clauses are
**2,658,385**, with 1,088 threshold gates and 16,267 source cell-capacity proofs.
Every graph pair, segment cover, clause and threshold truth table is checked.

## Four closed calls and no accepted certificate

[The four-case batch]({NAME}/batch-process.json) retains the frozen per-case
60-second search, one-million-conflict, 64 MiB binary-proof and 2 GiB aggregate
memory limits. Complete process/stage caps and Windows Job Object descendant
closure are enforced. All four calls stop at the proof-byte limit. The complete
batch closes in **125.312357 seconds**, with zero active descendants.
[Per-case results]({NAME}/case-results.json) preserve every limit and original
model hash. No SAT witness, usable UNSAT response, accepted proof or source-valid
placement is claimed. These calls will not be repeated, reseeded or extended.

First read-only inspections of the [previous four limited streams]({NAME}/previous-stream-inspection.json)
and [these four new streams]({NAME}/current-stream-inspection.json) find no complete
prefix ending in an added empty clause. Every stream ends in truncated data;
no proof-checker call or exclusion follows. All original bytes stay preserved.

The [remaining graphs]({NAME}/remaining-source-graphs.json) correspond to empty
cog sites **[0,5,10], [5,10,11], [10,11,12] and [11,12,13]**.
[Next]({NAME}/next-step.json), assess selective complete refinement of anchor
cells or exact geometric constraints involving more than two cells. Preserve
all closed boundaries and aliases, and require genuinely new source constraints
before any distinct bounded call. All consumed preparation remains recorded;
no full-job 60/90-second construction claim or native validation follows.

The preceding verified checkpoint reached **main 909db92e** by normal atomic
fast-forward after all six checks and aggregate CI42321641931 passed. The
[push receipt]({NAME}/main-sync-receipt.json) verifies all 52 reconciled remote
files, unchanged refs before push and ordinary ancestry. No live run was
cancelled. New CI42325413099 is tracked separately; no release or registry
version is added.

[The manifest]({NAME}/raw-manifest.json) contains {archive['archive_members']}
new canonical members in {archive['archive_parts']} ZIP parts, totaling
{archive['archive_bytes']:,} bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) preserve original dependencies.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 exact circular clearance and factored conflicts:** [independent source/model audits]({link}) verify one refined polygon-union cell removal, two exact rational cog-distance removals and 15 exact Euclidean pair conflicts. Every one of the four source graphs is genuinely stronger; all 33,803,472 retained graph pairs and complete covers pass. Exhaustive interval-tree encoding controls check 1,024 graphs and 524,288 auxiliary extensions. Full audits cover 15,208,033 source conflicts with 2,637,822 factored clauses, 2,658,385 total clauses and 1,088 threshold gates. All four fresh calls reach their frozen 64 MiB proof limits; the batch closes in 125.312357 s with zero active descendants. First inspection of all eight previous/current limited streams finds no complete contradiction prefix. No further exclusion or placement follows: four arrangements and 440 whole allocations remain, with 451 of 455 fixed arrangements excluded at required 0.2 mm clearance and 427 even at zero clearance. Next assess selective complete refinement or higher-order source constraints; every closed call stays closed. H2/H5 remain open at 60%. The prior checkpoint reached main 909db92e after all six CI checks passed, preserving all 52 remote files; no release is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a='Latest H5 evidence: [stronger polygon clearance proofs](../benchmarks/results/h5-polygon-clearance-proofs-20261107.md).';assert s.count(a)==1
s=s.replace(a,f'Latest H5 evidence: [exact circular clearance and factored conflicts](../benchmarks/results/{NAME}.md).',1)
a='The latest six source-strengthened\nmodels yield two accepted proofs and four proof-size limits.';assert s.count(a)==1
s=s.replace(a,'After two earlier accepted proofs, exact circular distance and polygon-union\nchecks remove three more cells and add 15 conflicts. Four new factored models\nstill reach their proof-size limits, so these calls add no exclusion.',1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'remaining':4})
