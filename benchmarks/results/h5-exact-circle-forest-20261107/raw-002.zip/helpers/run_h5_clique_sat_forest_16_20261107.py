from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import time,json,subprocess
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-forest-sat-16-model-20261107';OUT=ROOT/'output/h5-forest-sat-16-call-20261107'
EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/h5-sat-venv-20261106/Scripts/python.exe';SCRIPT=ROOT/'output/solve_h5_clique_sat_forest_16_20261107.py'
load=lambda p:json.loads(p.read_bytes());plan=load(MODEL/'plan.json');assert load(MODEL/'audit.json')['passed'];assert load(ROOT/'output/h5-windows-job-external-stop-20261107/checks.json')['passed']
control=load(ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json');assert control['passed'] and sha256(EXE.read_bytes()).hexdigest()==control['runner_sha256'];OUT.mkdir()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
args=[str(EXE),str(plan['native_job_hard_wall_ms']),str(plan['solver_aggregate_committed_memory_bytes']),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(SCRIPT)]),str(ROOT),'version4']
write('opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [MODEL/'plan.json',MODEL/'audit.json',SCRIPT,Path(__file__),EXE]},'command':args,'retry_permitted':False,'maximum_complete_seconds':90,'maximum_search_seconds':60,'job_contains_launcher_and_descendants':True})
started=time.perf_counter();stop_reason=None
with (OUT/'runner-stdout.txt').open('xb') as stdout,(OUT/'runner-stderr.txt').open('xb') as stderr:
    p=subprocess.Popen(args,cwd=ROOT,stdout=stdout,stderr=stderr)
    while p.poll() is None:
        elapsed=time.perf_counter()-started;proof=OUT/'proof.drat.bin';phase=OUT/'search-started.json'
        if elapsed>plan['solver_complete_process_seconds']:
            stop_reason='outer-process-time-limit';p.kill();p.wait();break
        reason=None
        if proof.exists() and proof.stat().st_size>plan['binary_proof_byte_limit']:reason='proof-byte-limit'
        if phase.exists():
            try:data=load(phase)
            except json.JSONDecodeError:data=None
            if data and time.perf_counter()-data['perf_counter']>plan['solver_search_seconds']:reason='search-time-limit'
        if reason and stop_reason is None:stop_reason=reason;write('stop',{'reason':reason,'elapsed':elapsed})
        time.sleep(.02)
elapsed=time.perf_counter()-started;job=load(OUT/'job.json') if (OUT/'job.json').exists() else None
result={'closed':bool(job and job['closed'] and job['active_processes']==0),'exit_code':p.returncode,'limit_reason':stop_reason,'job':job,'complete_process_seconds':elapsed,'complete_process_cap_overrun_seconds':max(0,elapsed-plan['solver_complete_process_seconds']),'solver_calls_started':int((OUT/'search-started.json').exists()),'retry_permitted':False,'proof_status':'unverified','new_exclusions':0}
write('process.json',result);print(result)
