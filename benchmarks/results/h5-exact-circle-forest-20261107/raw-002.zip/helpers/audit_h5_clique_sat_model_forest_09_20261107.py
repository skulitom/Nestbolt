from pathlib import Path
from hashlib import sha256
from itertools import product,combinations
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-forest-sat-09-model-20261107'
load=lambda p:json.loads(p.read_bytes());start=time.perf_counter();plan=load(OUT/'plan.json');checks=load(OUT/'checks.json')
for name,h in plan['inputs'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
G=ROOT/plan['graph'];nodes=load(G/'nodes.json');gc=load(G/'checks.json');raw=(G/'conflicts.bin').read_bytes();n=len(nodes);rb=gc['row_bytes']
assert sha256(raw).hexdigest()==gc['conflict_bytes_sha256'] and sha256((OUT/'model.cnf').read_bytes()).hexdigest()==checks['model_sha256']
geometries=load(ROOT/'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json');capacities=[]
for i,node in enumerate(nodes):
    a=node['bounds_um'];rects=geometries[node['geometry']]['inner_rectangles_um'];matches=[j for j,r in enumerate(rects) if a[2]-a[0]<r[2]-r[0] and a[3]-a[1]<r[3]-r[1]]
    assert matches;capacities.append({'compact_node':i,'inner_component':matches[0]})
def conflict(a,b):return bool(raw[a*rb+b//8]>>(b%8)&1)
tree=load(OUT/'forest.json');blocks=load(OUT/'neighbor-blocks.json');groups=load(OUT/'groups.json');families=load(OUT/'families.json');gates=load(OUT/'threshold-gates.json')
assert len(tree)==2*n-1 and len(blocks)==n
counter=0;edges=0;cpairs=0;truthrows=0;top=n;gatepos=0;mask_by_node=[];parents=[0]*len(tree);leaves=[];implications=0
with (OUT/'model.cnf').open(encoding='ascii') as f:
    assert f.readline().split()==['p','cnf',str(checks['variables']),str(checks['clauses'])]
    def clause():
        global counter
        row=list(map(int,f.readline().split()));assert row and row[-1]==0 and all(0<abs(x)<=checks['variables'] for x in row[:-1]);counter+=1;return row[:-1]
    for i,node in enumerate(tree):
        assert node['node']==i and 0<=node['lo']<node['hi']<=n
        mask=((1<<node['hi'])-1)^((1<<node['lo'])-1);mask_by_node.append(mask)
        if node['hi']-node['lo']==1:
            assert node=={'node':i,'lo':node['lo'],'hi':node['hi'],'variable':node['lo']+1};leaves.append(node['lo'])
        else:
            top+=1;assert node['variable']==top;left,right=node['left'],node['right'];assert 0<=left<right<i
            a,b=tree[left],tree[right];assert a['lo']==node['lo'] and a['hi']==b['lo'] and b['hi']==node['hi']
            assert mask_by_node[left]&mask_by_node[right]==0 and mask_by_node[left]|mask_by_node[right]==mask
            parents[left]+=1;parents[right]+=1
            assert clause()==[-a['variable'],top] and clause()==[-b['variable'],top];implications+=2
    assert sorted(leaves)==list(range(n)) and parents==[1]*(len(tree)-1)+[0] and tree[-1]['lo']==0 and tree[-1]['hi']==n and top==2*n-1
    assert implications==checks['forest_implication_clauses'] and top-n==checks['forest_variables']
    for a,record in enumerate(blocks):
        assert record['cell']==a and conflict(a,a);expected=0
        for b in range(a+1,n):
            yes=conflict(a,b);assert yes==conflict(b,a)
            if yes:expected|=1<<b;edges+=1
        covered=0
        for segment in record['segments']:
            assert 0<=segment<len(tree);mask=mask_by_node[segment];assert not(mask&covered) and mask&expected==mask
            covered|=mask;assert clause()==[-(a+1),-tree[segment]['variable']]
        assert covered==expected
    factor_count=counter;assert factor_count==checks['conflict_clauses'] and factor_count-implications==checks['neighbor_block_clauses']
    for family in [0,1]:
        family_groups=[g for g in groups if g['family']==family];covered=[];variables=[]
        for index,g in enumerate(family_groups):
            top+=1;assert g['index']==index and g['variable']==top;cells=g['compact_nodes'];assert cells
            assert all(nodes[i]['family']==family for i in cells);covered.extend(cells);variables.append(top)
            for a,b in combinations(cells,2):assert conflict(a,b);cpairs+=1
            for cell in cells:assert clause()==[-(cell+1),top]
            assert clause()==[-top]+[cell+1 for cell in cells]
        assert sorted(covered)==[i for i,node in enumerate(nodes) if node['family']==family]
        assert families[family]['group_variables']==variables and len(variables)>=8
    assert top==checks['group_variable_top']
    for family in [0,1]:
        prev={0:True}
        for i,x in enumerate(families[family]['group_variables'],1):
            current={0:True}
            for j in range(1,min(i,8)+1):
                top+=1;y=top;a=prev.get(j,False);b=prev[j-1];g=gates[gatepos];gatepos+=1
                assert g=={'i':i,'j':j,'x':x,'a':a,'b':b,'y':y,'family':family}
                block=[clause() for _ in range(4-int(a is False)-int(b is True))];variables=sorted({v for v in [a,b,x,y] if type(v) is int})
                assert all(set(map(abs,c))<=set(variables) for c in block)
                for values in product([False,True],repeat=len(variables)):
                    assignment=dict(zip(variables,values));val=lambda v:v if type(v) is bool else assignment[v]
                    actual=all(any(assignment[abs(l)]==(l>0) for l in c) for c in block)
                    assert actual==(val(y)==(val(a) or(val(x) and val(b))));truthrows+=1
                current[j]=y
            prev=current
        assert clause()==[prev[8]] and families[family]['final']==prev[8]
    assert f.read()==''
assert gatepos==len(gates) and counter==checks['clauses'] and edges==checks['original_graph_edges'] and top==checks['variables']
elapsed=time.perf_counter()-start;assert elapsed<=plan['maximum_model_audit_seconds']
result={'passed':True,'every_graph_pair_checked':n*(n-1)//2,'all_clauses_verified':counter,'source_conflict_pairs_verified':edges,'factored_conflict_clauses_verified':factor_count,'forest_segments_verified':len(tree),'clique_partition_pairs_verified':cpairs,'complete_family_clique_counts':list(map(lambda f:len(f['group_variables']),families)),'OR_group_equivalences_verified':len(groups),'acyclic_threshold_gates':len(gates),'local_truth_table_rows':truthrows,'single_cell_capacity_proofs':len(capacities),'model_sha256':checks['model_sha256'],'seconds':elapsed,'solver_calls':0,
    'necessity_proof':'Full child covers and single-cell capacity produce distinct selectors for any legal continuous completion. Every group is a complete conflict clique, and all groups partition each family, so no independent set can select more than1 cell per group. The explicit OR equivalence makes selected group count equal selected cell count. At least8 groups each family is therefore equivalent to at least8 selected cells. Every original source conflict is covered exactly once by a negative cell/segment clause; acyclic forward implications force selected covered leaves to their segment variables. Conversely assigning each segment its actual leaf OR extends every independent set. Thus existential projection onto original selectors is exactly the original pair model. A valid continuous completion induces a satisfying assignment; only separately checked complete UNSAT excludes this fixed arrangement at original0.2mm clearance.'}
for name,value in [('single-cell-capacity.json',capacities),('audit.json',result)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(result)
