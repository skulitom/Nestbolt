from pathlib import Path
from hashlib import sha256
from itertools import product,combinations
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-clique-sat-model-20261107'
load=lambda p:json.loads(p.read_bytes());start=time.perf_counter();plan=load(OUT/'plan.json');checks=load(OUT/'checks.json')
for name,h in plan['inputs'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
G=ROOT/plan['graph'];nodes=load(G/'nodes.json');gc=load(G/'checks.json');raw=(G/'conflicts.bin').read_bytes();n=len(nodes);rb=gc['row_bytes']
assert sha256(raw).hexdigest()==gc['conflict_bytes_sha256'] and sha256((OUT/'model.cnf').read_bytes()).hexdigest()==checks['model_sha256']
geometries=load(ROOT/'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json');capacities=[]
for i,node in enumerate(nodes):
    a=node['bounds_um'];rects=geometries[node['geometry']]['inner_rectangles_um'];matches=[j for j,r in enumerate(rects) if a[2]-a[0]<r[2]-r[0] and a[3]-a[1]<r[3]-r[1]]
    assert matches;capacities.append({'compact_node':i,'inner_component':matches[0]})
def conflict(a,b):return bool(raw[a*rb+b//8]>>(b%8)&1)
tree=load(OUT/'forest.json');blocks=load(OUT/'neighbor-blocks.json');groups=load(OUT/'groups.json');families=load(OUT/'families.json');gates=load(OUT/'threshold-gates.json')
assert len(tree)==2*n-1 and len(blocks)==n
counter=0;edges=0;cpairs=0;truthrows=0;top=n;gatepos=0;mask_by_node=[];parents=[0]*len(tree);leaves=[];implications=0
with (OUT/'model.cnf').open(encoding='ascii') as f:
    assert f.readline().split()==['p','cnf',str(checks['variables']),str(checks['clauses'])]
    def clause():
        global counter
        row=list(map(int,f.readline().split()));assert row and row[-1]==0 and all(0<abs(x)<=checks['variables'] for x in row[:-1]);counter+=1;return row[:-1]
    for i,node in enumerate(tree):
        assert node['node']==i and 0<=node['lo']<node['hi']<=n
        mask=((1<<node['hi'])-1)^((1<<node['lo'])-1);mask_by_node.append(mask)
        if node['hi']-node['lo']==1:
            assert node=={'node':i,'lo':node['lo'],'hi':node['hi'],'variable':node['lo']+1};leaves.append(node['lo'])
        else:
            top+=1;assert node['variable']==top;left,right=node['left'],node['right'];assert 0<=left<right<i
            a,b=tree[left],tree[right];assert a['lo']==node['lo'] and a['hi']==b['lo'] and b['hi']==node['hi']
            assert mask_by_node[left]&mask_by_node[right]==0 and mask_by_node[left]|mask_by_node[right]==mask
            parents[left]+=1;parents[right]+=1
            assert clause()==[-a['variable'],top] and clause()==[-b['variable'],top];implications+=2
    assert sorted(leaves)==list(range(n)) and parents==[1]*(len(tree)-1)+[0] and tree[-1]['lo']==0 and tree[-1]['hi']==n and top==2*n-1
    assert implications==checks['forest_implication_clauses'] and top-n==checks['forest_variables']
    for a,record in enumerate(blocks):
        assert record['cell']==a and conflict(a,a);expected=0
        for b in range(a+1,n):
            yes=conflict(a,b);assert yes==conflict(b,a)
            if yes:expected|=1<<b;edges+=1
        covered=0
        for segment in record['segments']:
            assert 0<=segment<len(tree);mask=mask_by_node[segment];assert not(mask&covered) and mask&expected==mask
            covered|=mask;assert clause()==[-(a+1),-tree[segment]['variable']]
        assert covered==expected
    factor_count=counter;assert factor_count==checks['conflict_clauses'] and factor_count-implications==checks['neighbor_block_clauses']
