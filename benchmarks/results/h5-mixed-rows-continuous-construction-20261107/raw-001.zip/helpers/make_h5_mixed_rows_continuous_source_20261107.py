from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-mixed-roof-source','h5-mixed-rows-continuous-source')]
convert('prepare_h5_mixed_roof_source_20261107.py','prepare_h5_mixed_rows_continuous_source_20261107.py',common+[
    ('Mixed-orientation frame roof and a checked seventeen-site cog pool.','Historical mixed-row frame recipe with a source-only fifteen-cog grid.'),
    ("history=['h5-four-column", "history=['h5-mixed-rows-source-contacts-20261026','h5-four-column"),
    ("'method':'Change fixed obstacle geometry:","'method':'Reconcile the October26 mixed-row topology; its finite4200-pose contact model returned UNKNOWN and remains closed. This is not a new frame topology. Use the current0.23mm spacing rather than historical0.225mm, giving a top0.020mm higher. Assess a source-only15-cog grid for a continuous-domain model, not a repeat of the historical finite pool. Change fixed obstacle geometry:"),
    ('sixteen quarter-turned frames in four columns/four rows, then two unturned frames across the left roof','twelve quarter-turned frames in four columns/three rows, then six unturned frames in three columns/two rows'),
    ('Derive seventeen pair-compatible cog sites in two rectangles above the stepped frame roof: nine in a three-by-three left block, eight in a two-by-four right block','Derive fifteen pair-compatible cog sites in one five-by-three grid above the new frame roof'),
    ('Site count is candidate capacity, not permission to add two cog copies. One source48 control uses exactly the first fifteen sites','The source48 control uses exactly all fifteen original cogs'),
    ("'source_pool_sites':17","'source_pool_sites':15"),
    ('for row in range(4):frames.append','for row in range(3):frames.append'),
    ('base_top=safe[1]+4*450+3*gap;upper_bottom=base_top+gap;upper_top=upper_bottom+350;upper_right=safe[0]+2*450+gap','base_top=safe[1]+3*450+2*gap;upper_bottom=base_top+gap;upper_top=upper_bottom+2*350+gap;upper_right=safe[0]+3*450+2*gap'),
    ('for col in range(2):frames.append(place_frame(len(frames),0.,safe[0]+col*(450+gap),upper_bottom))','for col in range(3):\n    for row in range(2):frames.append(place_frame(len(frames),0.,safe[0]+col*(450+gap),upper_bottom+row*(350+gap)))'),
    ("[('left',origin_left,3,3),('right',origin_right,2,4)]","[('upper',origin_left,5,3)]"),
    ('len(sites)==17','len(sites)==15'),('range(17)','range(15)'),
    ("'base_rows':4","'base_rows':3"),("'roof_frames':2","'roof_frames':6,'roof_columns':3,'roof_rows':2"),
    ("'pair_compatible_cog_sites':17","'pair_compatible_cog_sites':15"),("'cog_site_pairs_checked':136","'cog_site_pairs_checked':105"),("'cog_site_frame_pairs_checked':306","'cog_site_frame_pairs_checked':270")])
convert('audit_h5_mixed_roof_source_20261107.py','audit_h5_mixed_rows_continuous_source_20261107.py',common+[
    ('if i<16:','if i<12:'),('divmod(i,4)','divmod(i,3)'),
    ('theta=0.;x=safe[0]+(i-16)*(450+gap);y=safe[1]+4*(450+gap);expected=[x,y,x+450,y+350]','col,rr=divmod(i-12,2);theta=0.;x=safe[0]+col*(450+gap);y=safe[1]+3*(450+gap)+rr*(350+gap);expected=[x,y,x+450,y+350]'),
    ('len(sites)==17','len(sites)==15'),
    ("group='left' if i<9 else 'right';index=i if i<9 else i-9;columns=3 if i<9 else 2;rr,cc=divmod(index,columns)\n    if group=='left':ox=safe[0]+radius+.000001;oy=safe[1]+4*(450+gap)+350+gap+radius+.000001\n    else:ox=safe[0]+2*(450+gap)+radius+.000001;oy=safe[1]+4*(450+gap)+radius+.000001", "group='upper';rr,cc=divmod(i,5);ox=safe[0]+radius+.000001;oy=safe[1]+3*(450+gap)+2*(350+gap)+radius+.000001"),
    ('len(pair_rows)==136','len(pair_rows)==105'),('range(17)','range(15)'),('len(frame_rows)==306','len(frame_rows)==270'),
    ('both source cog grids','the15-cog five-by-three source grid'),('136 site pairs and306 site/frame checks','105 site pairs and270 site/frame checks'),("'cog_sites_verified':17","'cog_sites_verified':15"),("'cog_site_pairs_verified':136","'cog_site_pairs_verified':105"),("'cog_site_frame_pairs_verified':306","'cog_site_frame_pairs_verified':270")])
for phase in ['preparation','audit']:
    convert(f'run_h5_mixed_roof_source_{phase}_20261107.py',f'run_h5_mixed_rows_continuous_source_{phase}_20261107.py',[
        ('h5-mixed-roof-source','h5-mixed-rows-continuous-source'),('h5_mixed_roof_source','h5_mixed_rows_continuous_source')])
