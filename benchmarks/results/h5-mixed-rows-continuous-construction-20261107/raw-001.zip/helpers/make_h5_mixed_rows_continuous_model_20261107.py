from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-movable-roof-source','h5-mixed-rows-hard-cells'),('h5-movable-roof-model','h5-mixed-rows-continuous-model'),('h5_movable_roof_readback','h5_mixed_rows_continuous_readback')]
convert('h5_movable_roof_readback_20261107.py','h5_mixed_rows_continuous_readback_20261107.py',[
    ('new35-owner','new33-owner'),("[['frame',16],['frame',17]]+",''),('len(fixed)==31','len(fixed)==33'),('==list(range(16))','==list(range(18))')])
convert('prepare_h5_movable_roof_initializer_20261107.py','prepare_h5_mixed_rows_continuous_initializer_20261107.py',common+[
    ('for35moving','for33moving'),('two movable roof-frame originals,35movers/85parameters/595pairs','the historically documented mixed-row fixed-frame recipe,33movers/81parameters/528pairs'),
    ('Preserve frame quarter-turn modes and both original holes.','All18 frames remain fixed with their original geometry and holes; retain all legal companion modes.'),('the17 unoptimized','the15 unoptimized'),('Initialize two frames and15cogs first','Initialize all15 source cogs first'),('All35centers','All33centers'),('8262','10692'),("'candidate_cap':10000","'candidate_cap':12000"),
    ("classes['frame']==[0,1,0,1] and len(set(classes['bracket']))==9 and classes['insert']==[0,1,0,1]", "classes['bracket']==list(range(10)) and classes['insert']==[0,1,2,0,1,2]"),
    ('len(placed)==17','len(placed)==15'),('len(placed)==35','len(placed)==33'),("'moving_originals':35","'moving_originals':33"),("'parameters':85","'parameters':81"),("'moving_pairs':595","'moving_pairs':528")])
convert('audit_h5_movable_roof_model_20261107.py','audit_h5_mixed_rows_continuous_model_20261107.py',common+[
    ('h5-movable-roof-initializer','h5-mixed-rows-continuous-initializer'),
    ("{'frame':[0,1,0,1],'bracket':list(range(9)),'insert':[0,1,0,1],'cog':[0]}","{'bracket':list(range(10)),'insert':[0,1,2,0,1,2],'cog':[0]}"),
    ('len(placed)==17','len(placed)==15'),('range(17)','range(15)'),('range(i+1,17)','range(i+1,15)'),('list(range(2,20))','list(range(18))'),('8262','10692'),
    ('70+i-20','66+i-18'),('if i>=20','if i>=18'),('own>=20','own>=18'),('70+own-20','66+own-18'),('bindings==125 and vectors==91','bindings==147 and vectors==115'),('np.zeros(85)','np.zeros(81)'),('np.arange(85)','np.arange(81)'),('range(85)','range(81)'),("'coordinates':85","'coordinates':81"),("'samples':170","'samples':162"),
    ('len(equivalence_controls)==114','len(equivalence_controls)==137'),("classes['insert'][0]==classes['insert'][2] and classes['frame'][0]==classes['frame'][2] and classes['frame'][0]!=classes['frame'][1]","classes['insert'][0]==classes['insert'][3] and classes['insert'][1]!=classes['insert'][2]"),
    ('len(keys)==62 and equivalent==14 and raw==90','len(keys)==78 and equivalent==12 and raw==114'),("'compound_equivalence_pair_controls':114","'compound_equivalence_pair_controls':137"),("'source_owner_options':125","'source_owner_options':147"),("'physical_owner_options':97","'physical_owner_options':111"),("'unique_single_owner_physical_neighbors':62","'unique_single_owner_physical_neighbors':78"),("'raw_current_equivalents':14","'raw_current_equivalents':12"),("'raw_alternatives':90","'raw_alternatives':114"),
    ("mm['owners'][20]['angle_coordinate']=71","mm['owners'][18]['angle_coordinate']=67"),("mm['parameters']=84","mm['parameters']=80"),
    ("'frame-clearance-supports.json'","'fixed-core-boxes.json'"),('125ownercompoundbindings/fullscores,91vectors,595pairs/85parameters including two movable frame owners','147ownercompoundbindings/fullscores,115vectors,528pairs/81parameters including all15 freely rotating cogs'),('170centralcoordinates at two steps (340samples)','162centralcoordinates at two steps (324samples)'),('114compoundequivalencecontrols','137compoundequivalencecontrols'),
    ("'independent_central_coordinates':170","'independent_central_coordinates':162"),("'independent_central_samples':340","'independent_central_samples':324"),("'compound_equivalence_controls':114","'compound_equivalence_controls':137"),("'frame_center_coordinates_verified':4","'fixed_frame_originals_verified':18")])
for phase in ['initializer','model_audit']:
    convert(f'run_h5_movable_roof_{phase}_20261107.py',f'run_h5_mixed_rows_continuous_{phase}_20261107.py',[
        ('h5-movable-roof','h5-mixed-rows-continuous'),('h5_movable_roof','h5_mixed_rows_continuous')])
