"""Archive the reconciled mixed-row source, continuous model and closed results."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-mixed-rows-continuous-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-mixed-rows-continuous-model-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-mixed-rows-hard-cells-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-six-upper-frames-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==52 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-mixed-rows-continuous-source-20261107']+[ROOT/'output'/n for n in ['h5-mixed-rows-continuous-source-preparation-process-20261107','h5-mixed-rows-continuous-source-audit-process-20261107','h5-mixed-rows-hard-cells-preparation-process-20261107','h5-mixed-rows-hard-cells-audit-process-20261107','h5-mixed-rows-continuous-initializer-process-20261107','h5-mixed-rows-continuous-model-audit-process-20261107','h5-mixed-rows-continuous-response-audit-process-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*mixed*rows*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_mixed_rows_continuous_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"archive,_=pack(ROOT,OUT,NAME,members)":"history=[ROOT/'benchmarks/results'/n for n in ['h5-mixed-rows-source-contacts-20261026.md','h5-retained64-allocation-source-search-20261026.md','separator-weight-cap-20261014.md']]+[ROOT/'crates/core/src/separate.rs']\nfor hp in history:bindings[hp.relative_to(ROOT).as_posix()]=digest(hp);add('source-inputs/'+hp.relative_to(ROOT).as_posix(),hp)\narchive,_=pack(ROOT,OUT,NAME,members)"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
S=ROOT/'output/h5-mixed-rows-continuous-source-20261107'
runtime={name:r['sha256'] for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items()}
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(S/'audit/checks.json','source-recipe-audit.json'),(S/'audit/frame-controls.json','frame-controls.json'),(D/'audit/checks.json','source-domain-audit.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/physical-mode-controls.json','physical-mode-controls.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/'round-02-collision-details.json','source-failures.json'),(BASE/'failure-diagnostic/checks.json','failure-diagnostic.json'),(BASE/'failure-diagnostic/records.json','failure-diagnostic-records.json'),(BASE/'search/process.json','closed-process.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'weighted_original_overlap_model_preflight_required','proposal':'Assess a separately specified bounded guided-local-search objective using positive per-pair weights on original and certified-clearance overlap. Keep all528 moving pairs and the existing audited hard fixed-part/stock domains. This is a new weighted model preflight, not an extension of this closed unweighted pipeline.','historical_context':{'guided_search_is_not_new':True,'report':'benchmarks/results/h5-retained64-allocation-source-search-20261026.md','closed_result':'The different57-mover/short9 finite-angle obstacle-penalty construction ended ITERATION_LIMIT with60 pair and10 stock failures; its100 updates and call stay closed.','weight_ceiling_report':'benchmarks/results/separator-weight-cap-20261014.md','production_weights_already_bounded':True},'reason':'Current unweighted candidates retain conflicts in every moving family and five cogs have blocked lower-y descent. Earlier guided weights operated on different surrogate geometry and soft stock terms. Exact original/clearance area with certified hard stock/fixed bounds and continuous cog angles requires its own weighted-gradient and state-transition audit. No novelty or success is assumed.','requirements':['Freeze a deterministic positive bounded weight rule before use; include every original pair term and prove that zero weighted overlap is equivalent to zero unweighted overlap. No weight may disable a constraint or overflow.','Use only the unoptimized original-source initializer, charging its complete9.012575599597767s preparation plus every new model/weight preparation. Consume no optimized closed candidate. Do not rerun the closed uniform-weight call.','Independently reconstruct every coefficient, pair mapping, owner mode and bound; compare weighted full scores, scalar gradients and both central-difference step sizes. Reject corrupted or missing coefficients.','Specify the complete finite algorithm, weight-update state, unweighted best-candidate accounting, mode choice policy, stop rules and aggregate60/90s limits before any optimizer. No existing call receives an extension, reseed, objective change or reset clock.','Every retained full66 candidate still needs original-source validation; only a valid witness qualifies for native/material checks and later product work.'],'new_weighted_model_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Mixed-row continuous construction — 2026-11-07

The historical mixed-row frame layout now has independently checked continuous
source domains and a complete original-geometry model. Its bounded search still
fails: the best candidate has **52 failing original pairs** and
**38,972.237088 mm² overlap**. Fixed-part and stock checks all pass. No native
call or allocation exclusion follows. H2/H5 remain open at **60%** completed
milestone weight.

## Historical recipe and new source control

The [October 26 construction](h5-mixed-rows-source-contacts-20261026.md) already
used twelve quarter-turned frames in four columns/three rows, followed by six
unturned frames in three columns/two rows. Its finite 4,200-pose source-contact
model returned UNKNOWN and stays closed. This checkpoint claims no new frame
topology. The current 0.23 mm spacing makes its top 2,057.445 mm, 0.020 mm higher
than the historical 0.225 mm recipe. All fifteen short-sheet originals remain.

[Independent recipe readback]({NAME}/source-recipe-audit.json) checks every
frame rectangle, 153 nominal frame-pair separations and the fixed 33 originals.
One source-only grid holds exactly fifteen cogs in five columns/three rows,
at the previously certified 6.75-degree phase and 261.766 mm contact pitches.
All 105 cog pairs and 270 cog/frame pairs pass; minimum gaps are 0.301548 and
0.268863 mm. The original 48-part control passes 633 pairs, 192 stock edges,
60 holes and 6,366 hole vertices. Six brackets and twelve inserts are still
missing. Complete source recipe preparation costs 4.160113 s.

## Hard domains and complete original model

The twelve-frame base and six-frame roof have separate outward-rounded
containing rectangles. [Exact source-domain checks]({NAME}/source-domain-audit.json)
verify 13 arrangements, 112 atomic cells, 54 whole-cell support proofs,
147 owner bindings and 708 source corner controls. The minimum certified axis
gap is 0.230001 mm. These are conservative safe domains, not complete coverage
of all legal source free space. Ten bracket cells, six insert cells and one
all-angle cog cell remain explicit. The fifteen source cog projections are at
most 1.414214 nm; the original 48-part control remains valid.

The complete model has **33 movers, 81 parameters and 528 moving pairs**.
All fifteen cog centers and angles remain free. One fresh initializer places
the source cogs first, then the eighteen companions on every declared 9×9 grid.
It consumes no optimized ancestor or historical finite contact pool.
[Independent model readback]({NAME}/model-audit.json) replays all **10,692 trial
scores, 147 owner/mode full scores and 115 vectors**. Canonical alias bounds
require no additional seed projection. There are 111 physical owner options
and 78 distinct single-owner neighbors; [137 equivalence controls]({NAME}/physical-mode-controls.json)
preserve both distinct vertical-insert regions.

Controls also verify 132 scalar gradient terms, **324 central samples over
162 coordinates**, three descent directions and eleven deliberately corrupted
models. [Both derivative step sizes pass]({NAME}/derivative-controls.json).
The initializer starts with 33 failing pairs and 74,476.597369 mm² overlap;
it is not valid. Complete consumed source/domain/initializer preparation is
**9.012576 s**. Verification work is recorded separately.

## Closed search and independently replayed failures

Three distinct physical vectors use declared 16/14/14-second slices within
preparation-inclusive 60/90-second limits. All later selected mode changes
affect inserts. [Response replay]({NAME}/response-audit.json) verifies **155
mode trials and 390 retained points**, reconciling 478 function-evaluation
counters. Each candidate reconstructs all 66 originals, 1,380 same-sheet pairs,
264 stock edges, 90 holes and 10,026 hole vertices. The candidates fail 48, 49
and 52 pairs; the third has the best declared objective. Fewer failing pairs
and lower total overlap are different measures and do not establish validity.

The best [source failures]({NAME}/source-failures.json) comprise 49 positive
intersections and three clearance-only failures. Algorithm/shared totals are
**56.181211/56.284123 s**; the source-check time stop closes the pipeline after
the third call. Slice overruns of 0.091584, 0.044335 and 0.011268 s remain
preserved. [All five search processes close]({NAME}/closed-process.json),
with 94,543,872 bytes peak aggregate committed memory. No call can resume.

[Read-only diagnostics]({NAME}/failure-diagnostic.json) attribute the best
candidate's overlap to bracket/insert (11,332.616199 mm²), bracket/cog
(7,014.549071), insert/insert (1,537.978812), cog/insert (14,102.662083) and
cog/cog (4,984.430922). Cogs move at most 42.846175 mm and rotate at most
7.200218 degrees from their source poses. Five have active lower y bounds
with negative local descent blocked. [The complete observations]({NAME}/failure-diagnostic-records.json)
describe these candidates only and prove no global exclusion.

## Next model preflight and repository state

[The next preflight]({NAME}/next-step.json) assesses bounded positive pair
weights on the exact original/clearance objective while retaining all hard
fixed-part and stock bounds. Guided weights are already used in Nestbolt and
in an [earlier H5 construction](h5-retained64-allocation-source-search-20261026.md);
that different finite-angle, soft-stock model also failed and remains closed.
The [weight-ceiling history](separator-weight-cap-20261014.md) is retained.
A weighted original-geometry model needs independent coefficient, gradient,
state-transition and zero-overlap-equivalence checks before any finite search.
Only the unoptimized source initializer may be consumed, with complete charge;
no closed uniform-weight call may be rerun. No new weighted model exists yet.

Four earlier fixed arrangements and 440 allocations remain unresolved. Full66
source/native/material validity, production parity and the unchanged H5 matrix
remain required. H2 retains its original gate and reserved vectors.
[Main CI at review]({NAME}/main-ci-at-review.json) has five passing jobs and
Windows native CI still running on bca9af73. Checkpoint 15f55b9a and this
checkpoint await the ordinary push gate. Production, README and releases are
unchanged. [Raw evidence]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json) and
[pinned runtime files]({NAME}/runtime-bindings.json) retain all inputs and outcomes.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 mixed-row continuous construction:** [source/model/response audits]({link}) reconcile the historical October 26 mixed-row frame topology and preserve its finite UNKNOWN call. One fifteen-cog grid passes all 105 cog pairs, 270 frame pairs and the full 48-part partial control. New continuous domains verify 112 atomic cells, 54 exact supports and 708 source corners. The 33-mover/81-parameter/528-pair model replays 10,692 initializer trials, 147 owner options, 115 vectors and 324 derivative samples. Three unique calls and 155 mode trials close at the source-check time stop; 390 retained points and 478 evaluation counters replay. The best objective candidate still fails 52 original pairs with 38,972.237088 mm² overlap; fixed-part and stock checks pass. Complete preparation is 9.012576 s and algorithm/shared totals are 56.181211/56.284123 s, with every process closed and all slice overruns retained. Failure diagnostics show overlap across all moving family combinations and five cogs with blocked lower-y descent. Next assess a separately specified bounded positive pair-weight model on exact original/clearance geometry, retaining hard stock/fixed domains and charging only an unoptimized source initializer; earlier guided-search history and every closed call remain preserved. No weighted model or call is prepared. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Main bca9af73 has five passed jobs and live Windows native CI; 15f55b9a and this checkpoint await the ordinary push gate. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [mixed-row continuous construction](../benchmarks/results/{NAME}.md).
The historical twelve-turned/six-unturned frame recipe and a fifteen-cog source
grid pass original checks. The full 33-mover model has 81 parameters and 528
pair interactions; audits verify 10,692 initializer trials, 147 owner options
and 324 derivative samples. Three calls close with 52 failing pairs in the best
objective candidate and 38,972.237088 mm² overlap; fixed-part and stock checks
pass. All 390 saved points replay and 478 recorded evaluations reconcile.
Complete preparation is 9.012576 s; algorithm/shared totals are
56.181211/56.284123 s. Every process closes and all slice overruns remain.
No full66 witness, native call or allocation exclusion follows. Next assess
bounded positive pair weights on exact source/clearance overlap with all hard
stock/fixed domains intact. Earlier guided-search history is retained; no new
weighted model or call is prepared and no closed call may resume.
Four earlier fixed arrangements and 440 allocations remain. H2/H5 stay at 60%
completed milestone weight. Main bca9af73 has five passing CI jobs and live
Windows native CI. Checkpoint 15f55b9a and this checkpoint await the ordinary
push gate. Full66 source/native/material checks, production parity and the
unchanged H5 matrix remain required. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
