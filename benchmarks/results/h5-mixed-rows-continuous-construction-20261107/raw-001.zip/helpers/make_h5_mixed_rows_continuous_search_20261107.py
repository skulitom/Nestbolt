from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-movable-roof-model','h5-mixed-rows-continuous-model'),('h5-movable-roof-source','h5-mixed-rows-hard-cells'),('h5-movable-roof-initializer','h5-mixed-rows-continuous-initializer'),('h5_movable_roof_readback','h5_mixed_rows_continuous_readback'),('range(85)','range(81)')]
convert('run_h5_movable_roof_search_20261107.py','run_h5_mixed_rows_continuous_search_20261107.py',common+[
    ("'parameters':85","'parameters':81"),
    ('broader movable-roof model. Two roof-frame originals now have free centers and legal quarter-turn modes, alongside6brackets,12inserts and15continuously rotating cogs. All35centers/15angles are optimized jointly:85parameters and595movingpairs. Only16baseframes and15short-sheet originals remainfixed.','historical mixed-row frame construction with fresh continuous domains. All18frames and15short-sheet originals remain fixed. Six brackets,12inserts and15cogs have free centers, with all15cog angles continuous:33movers,81parameters,528movingpairs. The October26 finite4200pose UNKNOWN call stays closed; no finite pool or old optimized point is consumed.'),
    ('fresh8262-trial','fresh10692-trial'),('single-owner frame/bracket/insert compound changes','single-owner bracket/insert compound changes'),('All35owners participate, with62distinct physicalneighbors and90raw alternatives','All33owners participate, with78distinct physicalneighbors and114raw alternatives'),('selected85coordinate','selected81coordinate')])
convert('audit_h5_movable_roof_response_20261107.py','audit_h5_mixed_rows_continuous_response_20261107.py',common+[
    ('len(evaluated)+len(skipped)==90','len(evaluated)+len(skipped)==114'),("opened_optimizer['parameters']==85","opened_optimizer['parameters']==81"),('70+i-20','66+i-18'),('if i>=20','if i>=18'),('len(moving_pairs)==595','len(moving_pairs)==528'),('85coordinategradients','81coordinategradients'),('All595movingpairs','All528movingpairs')])
convert('run_h5_movable_roof_response_audit_20261107.py','run_h5_mixed_rows_continuous_response_audit_20261107.py',[
    ('h5-movable-roof','h5-mixed-rows-continuous'),('h5_movable_roof','h5_mixed_rows_continuous')])
