"""Read-only failure composition and motion in the closed continuous search."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,math,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-rows-continuous-model-20261107';OUT=BASE/'failure-diagnostic'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'];result=load(BASE/'search/result.json');lib=load(BASE/'library.json');initial=load(BASE/'initial-mode-values.json');assert result['closed'];inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','search/result.json','library.json','initial-mode-values.json']];records=[]
for index in range(result['optimizer_calls']):
    folder=BASE/f'search/round-{index:02d}';model=load(folder/'model.json');response=load(folder/'response.json');source=load(folder/'original-source-checks.json');inputs += [folder/n for n in ['model.json','response.json','original-source-checks.json']];groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.});point=response['best_values'];owners=[]
    for p in source['pairs']:
        if p['passed']:continue
        key='/'.join(sorted(k[0] for k in p['keys']));g=groups[key];g['pair_failures']+=1;g['positive_intersections']+=p['intersection_area_mm2']>0;g['overlap_mm2']+=p['intersection_area_mm2']
    for i,o in enumerate(model['owners']):
        angle=o['angle_coordinate'];axes=[]
        for k in [2*i,2*i+1]:
            lo,hi=model['bounds'][k];active='lower' if abs(point[k]-lo)<1e-7 else ('upper' if abs(point[k]-hi)<1e-7 else None);grad=response['best_gradient'][k];axes.append({'axis':'x' if k%2==0 else 'y','active_bound':active,'gradient':grad,'negative_gradient_blocked':(active=='lower' and grad>1e-8) or (active=='upper' and grad<-1e-8)})
        owners.append({'identity':o['identity'],'mode_changed':o['mode']!=initial['modes'][i],'center_movement_mm':math.dist(point[2*i:2*i+2],initial['values'][2*i:2*i+2]),'angle_change_radians':(point[angle]-initial['values'][angle])/lib['angle_scale_mm'] if angle is not None else None,'axes':axes})
    assert sum(g['pair_failures'] for g in groups.values())==source['pair_failures'] and abs(sum(g['overlap_mm2'] for g in groups.values())-response['best_details']['original_overlap_area_mm2'])<1e-7
    records.append({'round':index,'family_failures':dict(groups),'owners':owners,'stock_failures':source['stock_failures']})
best=records[result['best_global']['round']];cogs=[o for o in best['owners'] if o['identity'][0]=='cog'];assert len(cogs)==15
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Summarize the independently replayed closed source failures, original center/angle changes and observed bound directions. No candidate mutation, new placement preparation, objective modification or optimizer. These candidate observations prove no continuous exclusion.','optimizer_calls':0,'closed_calls_resumed':False})
write(OUT/'records.json',records);checks={'passed':True,'seconds':time.perf_counter()-started,'closed_rounds_verified':len(records),'best_round':best['round'],'family_failures':best['family_failures'],'maximum_cog_center_movement_mm':max(o['center_movement_mm'] for o in cogs),'maximum_absolute_cog_angle_change_degrees':max(abs(o['angle_change_radians']) for o in cogs)*180/math.pi,'cog_lower_y_bounds_active':sum(o['axes'][1]['active_bound']=='lower' for o in cogs),'cog_lower_y_descent_blocked':sum(o['axes'][1]['active_bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
