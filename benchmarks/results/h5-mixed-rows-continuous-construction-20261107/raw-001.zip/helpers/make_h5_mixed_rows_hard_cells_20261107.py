from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-mixed-roof-source','h5-mixed-rows-continuous-source'),('h5-mixed-roof-hard-cells','h5-mixed-rows-hard-cells'),("[('base',range(16)),('roof',range(16,18))]","[('base',range(12)),('roof',range(12,18))]")]
convert('prepare_h5_mixed_roof_hard_cells_20261107.py','prepare_h5_mixed_rows_hard_cells_20261107.py',common+[
    ('with multiple all-angle cog domains','with all-angle cog domains'),('the16frame base and2frame roof','the12frame base and6frame roof'),
    ('Multiple cog cells are explicit compound options,notinterchangeable aliases.','Every retained cell is an explicit compound option; different domains are not interchangeable aliases.'),
    ("'first_cog_owner':18","'first_cog_owner':18,'angle_owners':list(range(18,33))")])
convert('audit_h5_mixed_roof_hard_cells_20261107.py','audit_h5_mixed_rows_hard_cells_20261107.py',common+[
    ("len(expected_modes['cog'])>1","len(expected_modes['cog'])>=1"),
    ("lib['first_cog_owner']==18","lib['first_cog_owner']==18 and lib['angle_owners']==list(range(18,33))"),
    ('Multiple cog cells preserved.','Every actual cell and distinct domain is preserved.')])
for phase in ['preparation','audit']:
    convert(f'run_h5_mixed_roof_hard_cells_{phase}_20261107.py',f'run_h5_mixed_rows_hard_cells_{phase}_20261107.py',[
        ('h5-mixed-roof-hard-cells','h5-mixed-rows-hard-cells'),('h5_mixed_roof_hard_cells','h5_mixed_rows_hard_cells')])
