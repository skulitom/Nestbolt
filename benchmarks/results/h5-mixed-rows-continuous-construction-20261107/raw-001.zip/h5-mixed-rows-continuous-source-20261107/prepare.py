"""Historical mixed-row frame recipe with a source-only fifteen-cog grid."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,time,copy,shutil
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-mixed-rows-continuous-source-20261107';PRIOR=ROOT/'output/h5-six-bracket-cog-source-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');checked=load(PRIOR/'audit/checks.json');lib=load(PRIOR/'library.json');assert checked['passed'] and checked['library_sha256']==digest(PRIOR/'library.json')
history=['h5-mixed-rows-source-contacts-20261026','h5-four-column-source-domains-20261107','h5-bracket-source-regions-and-fixed-layout-bound-20261028','h5-coordinated-contact-selection-20261020','h5-complete-pair-separation-and-relative-region-searches-20261029','h5-expanded-joint-and-staged-row-constructions-20261104']
inputs=[Path(__file__),JOB,ROOT/'output/h5_legacy64_source_readback.py']+[PRIOR/n for n in ['plan.json','library.json','short15-source.json','source-contact-pitches.json','audit/checks.json']]+[ROOT/'benchmarks/results'/(n+'.md') for n in history]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconcile the October26 mixed-row topology; its finite4200-pose contact model returned UNKNOWN and remains closed. This is not a new frame topology. Use the current0.23mm spacing rather than historical0.225mm, giving a top0.020mm higher. Assess a source-only15-cog grid for a continuous-domain model, not a repeat of the historical finite pool. Change fixed obstacle geometry: twelve quarter-turned frames in four columns/three rows, then six unturned frames in three columns/two rows. Preserve the independently audited short6-bracket/9-insert arrangement. Derive fifteen pair-compatible cog sites in one five-by-three grid above the new frame roof, using the previously exact-checked 6.75-degree source phase and 261.766mm pitches. The source48 control uses exactly all fifteen original cogs; six brackets and twelve inserts remain absent. No placement selection, optimizer or native call. No claim that mixed frames, contact sampling or finite cog pools are unprecedented; historical reports are bound. This geometry differs from the closed 5/5/4/4 all-turned source model and three-column source model. Every previous call stays closed.','complete_reused_source_preparation_seconds':checked['complete_preparation_seconds'],'consumed_optimized_ancestor':False,'gap_mm':.23,'source_stock_reserve_mm':.025,'source_seed_cases':1,'fixed_cog_angle_degrees':load(PRIOR/'source-contact-pitches.json')['phase_degrees'],'source_pool_sites':15,'original_cog_quantity':15,'source_optimizer_calls':0,'preparation_cap_seconds':15,'algorithm_seconds':60,'shared_seconds':90,'memory_bytes':2**31,'retry_permitted':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};stocks=lib['source_stocks'];safe=[stocks['sheet-0'][0]+.025,stocks['sheet-0'][1]+.025,stocks['sheet-0'][2]-.025,stocks['sheet-0'][3]-.025];gap=.23;frames=[]
def place_frame(index,angle,x,y):
    c,s=math.cos(angle),math.sin(angle);v=[(x0*c-y0*s,x0*s+y0*c) for x0,y0 in parts['frame']['geometry'][0]['outer']]
    return {'part_id':'frame','copy_index':index,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':False,'translation':[x-min(p[0] for p in v),y-min(p[1] for p in v)]}}
for col in range(4):
    for row in range(3):frames.append(place_frame(len(frames),math.pi/2,safe[0]+col*(350+gap),safe[1]+row*(450+gap)))
base_top=safe[1]+3*450+2*gap;upper_bottom=base_top+gap;upper_top=upper_bottom+2*350+gap;upper_right=safe[0]+3*450+2*gap
for col in range(3):
    for row in range(2):frames.append(place_frame(len(frames),0.,safe[0]+col*(450+gap),upper_bottom+row*(350+gap)))
short=load(PRIOR/'short15-source.json');fixed=frames+short;fixed_check=audit(job,fixed,stocks,lib['required_pair_gap_mm'],lib['stock_guard_mm']);assert fixed_check['valid'] and len(fixed)==33
write(OUT/'fixed33-source.json',fixed);write(OUT/'fixed33-checks.json',fixed_check)
contact=load(PRIOR/'source-contact-pitches.json');pitch=contact['pitches_mm'];theta=math.radians(contact['phase_degrees']);radius=lib['angle_scale_mm'];reserve=radius+.000001
origin_left=[safe[0]+reserve,upper_top+gap+reserve];origin_right=[upper_right+gap+reserve,base_top+gap+reserve];sites=[];cx,cy=lib['families']['cog']['source_center'];c,s=math.cos(theta),math.sin(theta)
for group,origin,ncols,nrows in [('upper',origin_left,5,3)]:
    for row in range(nrows):
        for col in range(ncols):
            x,y=origin[0]+col*pitch[0],origin[1]+row*pitch[1]
            sites.append({'site':len(sites),'group':group,'row':row,'column':col,'center':[x,y],'angle_radians':theta,'transform':{'rotation_radians':theta,'mirrored':False,'translation':[x-(cx*c-cy*s),y-(cx*s+cy*c)]}})
assert len(sites)==15
def shape(part,pose):
    c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation']
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in part['geometry'][0]['outer']])
polys=[shape(parts['cog'],row['transform']) for row in sites];pair_checks=[]
for i,j in combinations(range(15),2):
    a,b=polys[i],polys[j];distance=a.distance(b);overlap=a.intersection(b).area;assert distance>=lib['required_pair_gap_mm'] and overlap==0
    pair_checks.append({'sites':[i,j],'distance_mm':distance,'original_overlap_mm2':overlap})
fixed_checks=[]
for i,p in enumerate(polys):
    lo_x,lo_y,hi_x,hi_y=p.bounds;assert lo_x>=safe[0] and lo_y>=safe[1] and hi_x<=safe[2] and hi_y<=safe[3]
    for row in frames:
        f=shape(parts['frame'],row['transform']);distance=p.distance(f);overlap=p.intersection(f).area;assert distance>=lib['required_pair_gap_mm'] and overlap==0
        fixed_checks.append({'site':i,'frame':row['copy_index'],'distance_mm':distance,'original_overlap_mm2':overlap})
selected=sites[:15];control=fixed+[{'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':row['transform']} for i,row in enumerate(selected)];control_check=audit(job,control,stocks,lib['required_pair_gap_mm'],lib['stock_guard_mm']);assert control_check['valid'] and len(control)==48
write(OUT/'source48-control.json',control);write(OUT/'source48-checks.json',control_check);write(OUT/'cog-sites.json',sites);write(OUT/'site-pair-checks.json',pair_checks);write(OUT/'site-frame-checks.json',fixed_checks)
write(OUT/'source-geometry.json',{'families':lib['families'],'fixed_source_rows':fixed,'frame_recipe':{'base_columns':4,'base_rows':3,'base_rotation_radians':math.pi/2,'roof_frames':6,'roof_columns':3,'roof_rows':2,'roof_rotation_radians':0.,'gap_mm':gap,'base_top_mm':base_top,'roof_top_mm':upper_top,'roof_right_mm':upper_right},'source_stocks':stocks,'safe_stock_mm':safe,'required_pair_gap_mm':lib['required_pair_gap_mm'],'stock_guard_mm':lib['stock_guard_mm'],'all66_identities':lib['all66_identities'],'cog_pitch_mm':pitch,'cog_phase_radians':theta,'source_center':lib['families']['cog']['source_center'],'source_radius_mm':radius,'cog_pool':sites,'missing_identities':[['bracket',i] for i in range(6,12)]+[['insert',i] for i in list(range(11))+[20]],'complete_initializer_prepared':False})
result={'prepared':True,'seconds':time.perf_counter()-start,'fixed_originals':33,'fixed_source_valid':True,'pair_compatible_cog_sites':15,'cog_site_pairs_checked':105,'cog_site_frame_pairs_checked':270,'minimum_site_gap_mm':min(r['distance_mm'] for r in pair_checks),'minimum_site_frame_gap_mm':min(r['distance_mm'] for r in fixed_checks),'source_control_originals':48,'source_control_cogs':15,'source_control_valid':True,'missing_brackets':6,'missing_inserts':12,'complete_reused_source_preparation_seconds':checked['complete_preparation_seconds'],'source48_is_not_best_partial':True,'original_cog_quantity_preserved':True,'source_optimizer_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
