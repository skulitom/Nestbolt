"""Preserve source-valid partials and exact fixed-core capacity exclusions."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-one-three-transfer-capacity-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-one-three-inventory-20261107';F=BASE/'audit';D=ROOT/'output/h5-one-three-covers-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-five-six-roof-capacity-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['fixed_first32_cases']==19 and front['fixed_first32_plus_short_cog_exclusions']==19 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-one-three-transfers-20261107',ROOT/'output/h5-roof-transfer-main-sync-20261107']+[ROOT/'output'/('h5-one-three-'+n+'-process-20261107') for n in ['transfers','transfers-audit','covers','covers-audit','inventory','inventory-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_one_three*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_one_three_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
S=ROOT/'output/h5-one-three-transfers-20261107'
copies=[(S/'plan.json','source-plan.json'),(S/'audit/checks.json','source-audit.json'),(D/'plan.json','cover-plan.json'),(D/'audit/checks.json','cover-audit.json'),(D/'audit/class-controls.json','continuous-class-controls.json'),(D/'audit/capacity-results.json','fixed44-capacities.json'),(BASE/'plan.json','inventory-plan.json'),(F/'checks.json','inventory-audit.json'),(F/'capacity-results.json','fixed32-capacities.json'),(BASE/'fixed-short-cog-area.json','fixed-short-cog-area.json'),(BASE/'whole-part-splits.json','whole-part-splits.json'),(ROOT/'output/h5-roof-transfer-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for n in ['transfers','transfers-audit','covers','covers-audit','inventory','inventory-audit']:
    copies.append((ROOT/'output'/('h5-one-three-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42407459619','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='66192d0d0862eb2f30c974c305376437df252e97'
write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
write(OUT/'next-step.json',{'status':'all19_current_fixed_short_cog_cases_excluded','proposal':'Change frame/cog geometry before a full model. Eleven of these exact first32 cores are impossible even when the last cog is free. Eight remain unexcluded under that broader relaxation (four one-turned and four three-turned cases), but none may keep cog14 at its current short-sheet pose. First assess the original one-turned all15-cog first-sheet core under arbitrary bracket/insert splits using the newly complete zero-empty center covers, with independent area and material readback. It restores the omitted source site without any optimizer and gives one common first33 core, not four new searches. The three-turned16site pool has two disjoint conflicts; restoring either removed endpoint always leaves a conflict. A further source construction there must change an actual cog pose or frame arrangement and verify the full source before a model. Broader historical models exist; do not claim these classes globally untested. No closed call or exact excluded fixed core may be retried.','inherited_preparation_seconds':front['complete_preparation_seconds_if_consumed'],'charge_all_new_preparation':True,'current_fixed_short_cog_cases_remaining':0,'current_first32_unrestricted_survivors':8,'complete_model_prepared':False,'optimizer_calls':0,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'H5_complete':False})
report=f'''# One-/three-turned cog-transfer capacity — 2026-11-07

**Nineteen source-valid 44-part partials cannot extend to 66 parts.** Even
changing every bracket/insert allocation cannot rescue these exact first-sheet
frame/cog cores while the short-sheet cog stays fixed. Eleven cores also fail
when that last cog is free. No whole allocation or orientation class is excluded.
H2/H5 remain open at **60% completed milestone weight**; valid64 remains best.

[The source construction]({NAME}/source-plan.json) reuses the exact earlier
one-/three-turned upper-frame pools and puts original cog14 on the independently
verified short sheet. It screens all **135** choices of fourteen first-sheet
cog sites: fifteen choices from the one-turned pool and120 from the three-turned
pool. All pool contacts are recomputed from original polygons.

[Independent replay]({NAME}/source-audit.json) verifies **783 pool contacts**.
The three-turned pool has precisely two disjoint collided pairs, [3,14] and
[7,15]. Of120 choices,116 retain at least one witnessed collision. The four
surviving omission pairs are [3,7], [3,15], [7,14] and [14,15]. All fifteen
one-turned choices survive. Complete checks of the nineteen original44-part
partials verify **10,678 same-sheet pairs and1,064 original holes**. Every
remaining identity is retained: six brackets and sixteen inserts still need
placement. The116 negatives are preserved with their specific witnesses.

[New covers]({NAME}/cover-plan.json) rebuild every world obstacle and all24
full mode masks, including the eight one-turned bracket modes that could have
been reused after equality checks. Rebuilding keeps this proof self-contained.
Only audited local cog inner rectangles and source parameters are reused.
Each pool includes all eight quarter-turn/mirror bracket modes and four
quarter-turn insert modes in the full physical stock domain. Point/interval
classes allow one empty cog bit for the one-turned pool and two for the
three-turned pool, with no fixed-frame conflict.

[Independent exact readback]({NAME}/cover-audit.json) verifies **2,423 source
inner rectangles,20 component bounds,24 masks and49,247,076 continuous
classes**. Every retained class is covered exactly once. Original L-component
and insert sweeps, outward stock clipping and subtraction of definitely
occupied source interiors give **57** independently checked union-difference
areas. Boundary, duplicate-obstacle and area-rounding controls pass.

| Upper turned frames | Valid partials | Largest available companion area (mm²) | Required (mm²) |
|---|---:|---:|---:|
| One | 15 | 456,755.775318 | 556,778 |
| Three | 4 | 495,456.515617 | 556,778 |

[All nineteen fixed44 layouts are excluded]({NAME}/fixed44-capacities.json).
These proofs apply to the exact selected frames/cogs and short-sheet rows,
without running an optimizer.

[The inventory extension]({NAME}/inventory-plan.json) first keeps only the
eighteen frames and fourteen cogs on the first sheet, releasing all remaining
originals. The previous material proof bounds the entire other sheet by
465,326.048858 mm². Combined area and bracket-count bounds exclude eleven of
the nineteen cores even when the last cog is ignored. Eight remain unexcluded
under that broader relaxation; a surviving necessary bound is not feasibility.

The second scope additionally fixes original cog14 at its verified short-sheet
pose, but releases every bracket and insert on both sheets. [Rational source
area readback]({NAME}/fixed-short-cog-area.json) certifies at least **50,061 mm²**
for that cog's filled outer polygon, including a conservative80-vertex rounding
allowance. At most **415,265.048858 mm²** then remains for short-sheet companions.
Original holes stay preserved and are not nesting space.

[Every whole-part split]({NAME}/whole-part-splits.json) is checked. The largest
fitting bracket/insert inventory lower bound is only **399,990 mm²**, so the
first sheet must hold at least **495,777 mm²** of companion bodies. The largest
available first-sheet region is **495,456.515617 mm²**: a deficit of at least
**320.484383 mm²**. [Independent division-based inventory enumeration]({NAME}/inventory-audit.json)
verifies **5,434 split checks**, including every family and combined-area reason.
[All nineteen fixed first32 plus short-cog cases are excluded]({NAME}/fixed32-capacities.json),
regardless of which brackets and inserts go on each sheet. This second result
does not cover moving the last cog onto the first sheet or changing fixed poses.

| Bounded stage | Complete preparation (s) | Separate audit (s) |
|---|---:|---:|
| Source subsets and partials | 0.919201 | 1.199101 |
| Fresh covers and occupied area | 9.630416 | 12.924171 |
| Whole-part inventory | 0.384811 | 0.413790 |

The [source]({NAME}/transfers-process.json), [cover]({NAME}/covers-process.json)
and [inventory]({NAME}/inventory-process.json) preparations retain all inherited
work for **40.936341 s** total if consumed by a successor. Their separate
[source]({NAME}/transfers-audit-process.json), [cover]({NAME}/covers-audit-process.json)
and [inventory]({NAME}/inventory-audit-process.json) audits pass. All six Job
Objects close three processes within their caps,2 GiB,CCD1 and single-thread
controls. No optimizer or closed call is reopened.

[Next]({NAME}/next-step.json), test the original one-turned all15-cog first-sheet
core under arbitrary companion splits using zero-empty covers. Restoring the
missing site yields one common first33 core, not four separate searches. The
three-turned pool cannot restore either removed cog without reviving a known
collision, so any further source construction must change an actual pose.
Four earlier fixed arrangements and440 whole-job allocations remain. Full66
source/native/material checks, integration, parity and the H5 matrix remain open.

[Main66192d0d includes the preceding ordinary push]({NAME}/prior-main-push-receipt.json).
[CI at review]({NAME}/main-ci-at-review.json) records **{success} passed / {live}
live jobs**. This checkpoint and the five-/six-turned proof await the next
ordinary push gate. No product, README or release changes are warranted by
these research exclusions.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 one-/three-turned transfer capacity:** [source, cover and integer-inventory audits]({{link}}) check all135 source-site choices, retain116 witnessed failures and verify19 source-valid44 partials. Fresh world obstacles and24 mode masks verify49,247,076 continuous classes and57 exact component-area bounds; all19 fixed44 cases fail completion. Eleven exact first32 cores are also excluded with every other original free. Fixing the last cog at its valid short-sheet pose, while releasing every bracket and insert, excludes all19: 5,434 whole-part split checks force at least495,777 mm² of companions onto the first sheet, whose largest available region is495,456.515617 mm² (minimum deficit320.484383 mm²). Eight first32 cores remain unexcluded if the last cog is free; no whole allocation or orientation class is excluded. Consumed preparation totals40.936341 s; all bounded stages close and no optimizer runs. Next assess the common one-turned all15-cog first33 core with zero-empty covers and arbitrary companion splits; further three-turned work requires a changed source pose because restoring a removed site revives a collision. Four earlier arrangements and440 allocations remain; valid64 remains best and H2/H5 stay open at60%. Main66192d0d has{success} passed/{live} live CI jobs; this and the five-/six-turned checkpoint await the ordinary push gate. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [one-/three-turned transfer capacity](../benchmarks/results/{NAME}.md).
All135 site choices are checked:116 retain witnessed collisions and19 pass
full44-part source checks. Fresh covers verify49,247,076 continuous classes
and57 exact occupied-area bounds, excluding all19 fixed44 completions.
Eleven first32 cores are also excluded with all other originals free. Keeping
the last cog at its valid short-sheet pose,5,434 whole-part inventory checks
exclude all19 for every bracket/insert split: first-sheet companions require
at least495,777 mm² versus at most495,456.515617 mm² available. Eight cores
remain unexcluded if the last cog is free. No whole allocation or orientation
class is excluded; no optimizer runs and valid64 remains best. Consumed
preparation totals40.936341 s. Next assess the common one-turned all15-cog
first33 core with zero-empty covers; further three-turned work needs a changed
source pose. Four earlier arrangements and440 allocations remain. H2/H5 stay
open at60%. Main66192d0d has{success} passed/{live} live CI jobs; this and the
five-/six-turned proof await the ordinary push gate. Product and releases
remain unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings)})
