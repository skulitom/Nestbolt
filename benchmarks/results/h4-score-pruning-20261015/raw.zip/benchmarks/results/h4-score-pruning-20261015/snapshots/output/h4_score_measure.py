from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
from h4_quality import cases, guards

out = ROOT/'benchmarks/results/h4-score-pruning-20261015'
checks = json.loads((ROOT/'benchmarks/results/h4-score-checks-20261015/progress.json').read_bytes())
assert len(checks)==7 and all(r['exit_code']==0 for r in checks)
assert not (out/'measurement-plan.json').exists(), 'Refuse duplicate measurement'
replay=Path(sys.argv[1]).resolve(strict=True)
replay_plan=json.loads((replay/'plan.json').read_bytes())
replay_result=json.loads((replay/'results.json').read_bytes())
assert replay_plan['reference'] and replay_result['all_passed'] and replay_result['guards_unchanged']
assert all(r['identical_layout_counters_history_validation'] for r in replay_result['rows'])
files={k.replace('\\','/'):v for k,v in replay_plan['guards']['files'].items()}
assert files['target/release/nestbolt.exe']==sha256((ROOT/'target/release/nestbolt.exe').read_bytes()).hexdigest()
assert replay_plan['guards']['product']==source_digest()
snapshot = out/'snapshots'
for name in ['crates/core/src/separate.rs','crates/core/src/separate/score.rs']:
    assert (snapshot/name).read_bytes()==(ROOT/name).read_bytes()
for name in ['scripts/h4_quality.py','scripts/h6_material_cost.py','scripts/g5_browser.py',
             'scripts/sheets_batch.py','scripts/dataset_selection.py','scripts/h2_import_audit.py',
             'web/bench/run.mjs','output/h4_score_measure.py']:
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/name,target)
shutil.copytree(ROOT/'web/dist',snapshot/'site')
rows=cases()
before=guards(rows)
environment={k:os.environ.get(k) for k in ['NESTBOLT_SIMPLIFY','NESTBOLT_NO_FILL',
             'NESTBOLT_DEBUG','NESTBOLT_TRACE','RUSTFLAGS','CARGO_PROFILE_RELEASE_LTO']}
assert all(v is None for v in environment.values()), environment
plan={'scope':'Single bounded-score candidate, fixed eleven development jobs, seeds 0-2, 60 seconds; existing H4 method and thresholds.',
      'cases':rows,'guards':before,'checks':checks,'equal_work_replay':replay.relative_to(ROOT).as_posix(),
      'environment_overrides':environment,
      'recorded_utc':datetime.now(timezone.utc).isoformat(),
      'held_out_geometry_read':False,'H4_complete':False}
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
write(out/'measurement-plan.json',plan)
command=[sys.executable,'scripts/h4_quality.py']
started=time.perf_counter()
with (out/'measurement.log').open('w',encoding='utf-8',newline='\n') as log:
    process=subprocess.Popen(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                             text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
    for line in process.stdout:
        log.write(line);log.flush();print(line,end='',flush=True)
    code=process.wait()
unchanged=guards(rows)==before
write(out/'measurement-execution.json',{'command':command,'exit_code':code,
      'wall_seconds':time.perf_counter()-started,'guards_unchanged':unchanged,
      'finished_utc':datetime.now(timezone.utc).isoformat()})
assert code==0 and unchanged
