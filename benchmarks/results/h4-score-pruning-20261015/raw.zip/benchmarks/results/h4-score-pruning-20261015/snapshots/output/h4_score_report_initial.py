from pathlib import Path
from hashlib import sha256
import json
import re
import shutil
import statistics
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from h4_quality import guards

OUT=ROOT/'benchmarks/results/h4-score-pruning-20261015'
QUALITY=ROOT/'benchmarks/results/h4-quality-20261015T215607Z'
CHECKS=ROOT/'benchmarks/results/h4-score-checks-20261015'
REPLAYS=[ROOT/'benchmarks/results'/n for n in [
    'h4-score-replay-20261015T213757Z','h4-score-replay-20261015T214511Z',
    'h4-score-replay-20261015T215420Z']]
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,value):
    p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')

plan=load(QUALITY/'plan.json');data=load(QUALITY/'results.json')
assert guards(plan['cases'])==plan['guards']
assert data['summary']['passes_subset'] and data['summary']['guards_unchanged']
execution=load(OUT/'measurement-execution.json')
assert execution['exit_code']==0 and execution['guards_unchanged']
checks={'decision':'Retain bounded scoring; H4 remains incomplete.',
        'quality_directory':QUALITY.relative_to(ROOT).as_posix(),
        'quality':data['summary'],'product_source':plan['guards']['product'],
        'cli_sha256':digest(ROOT/'target/release/nestbolt.exe'),
        'wasm_sha256':digest(ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm'),
        'wasm_bytes':(ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm').stat().st_size,
        'completed_weight_percent':45,'held_out_geometry_read':False}
records=[r for rows in data['records'].values() for r in rows]
assert len(records)==99 and all(r['status']=='valid' for r in records)
checks['valid_layouts']=len(records)
checks['maximum_metric_roundtrip_difference']=max(r['maximum_metric_json_roundtrip_difference'] for r in records)
checks['public_example_validations']=sum('example-' in r['job'] for r in records)
checks['browser_batches']=[]
for engine in ['chrome','firefox']:
    for seed in [0,1,2]:
        folder=QUALITY/engine/f's{seed}'
        e=load(folder/'execution.json');b=load(folder/'browser.json')
        assert e['exit_code']==0 and not e['affinity_errors']
        checks['browser_batches'].append({'engine':engine,'seed':seed,'browser':b,
            'wall_seconds':e['wall_seconds'],'cpus':e['cpus'],'affinity_errors':e['affinity_errors']})
stages=load(CHECKS/'progress.json')
assert len(stages)==7 and all(r['exit_code']==0 for r in stages)
checks['tests']={}
for name in ['workspace-tests','score-release-tests','cli-release-tests']:
    text=(CHECKS/(name+'.log')).read_text(encoding='utf-8')
    matches=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
    checks['tests'][name]=dict(zip(['passed','failed','ignored'],[sum(r[i] for r in matches) for i in range(3)]))
assert checks['tests']['workspace-tests']=={'passed':297,'failed':0,'ignored':1}
assert checks['tests']['cli-release-tests']=={'passed':26,'failed':0,'ignored':0}
assert checks['tests']['score-release-tests']=={'passed':3,'failed':0,'ignored':0}
web=(CHECKS/'web-build-and-tests.log').read_text(encoding='utf-8')
assert '84 passed' in web and '4 skipped' in web
checks['tests']['browser']={'passed':84,'skipped':4}
checks['equal_work']={'valid_layouts':0,'exact_candidate_comparisons':0}
for folder in REPLAYS:
    r=load(folder/'results.json');assert r['all_passed'] and r['guards_unchanged']
    checks['equal_work']['valid_layouts']+=len(r['rows'])
    checks['equal_work']['exact_candidate_comparisons']+=sum(v.get('identical_layout_counters_history_validation',False) for v in r['rows'])
manifest=ROOT/'benchmarks/datasets/shop/manifest.json'
assert digest(manifest)=='02e1f40fe7ad6459cce801620d7de4a14c10d9a1fad435e6d1b45a68ac34c3b7'
inventory=load(manifest)['corpus_inventory']
assert all(digest(manifest.parent/r['path'])==r['sha256'] for r in inventory)
checks['frozen_inventory_files']=len(inventory)

prior=ROOT/'benchmarks/results/h4-lto-probe-20261015T211442Z'
integrity=load(prior/'integrity.json')
assert digest(prior/'raw.zip')==integrity['sha256']
comparison={'scope':'Historical seed-0 thin build versus this candidate, same H4 development jobs. Charged work is a trajectory-dependent diagnostic, not isolated kernel throughput.','browsers':{}}
with zipfile.ZipFile(prior/'raw.zip') as z:
    for engine in ['chrome','firefox']:
        rows=[]
        for case in plan['cases']:
            name=f'benchmarks/results/{prior.name}/thin/{engine}/s0/{case["id"]}/result.json'
            raw=z.read(name)
            assert sha256(raw).hexdigest()==integrity['members'][name]['sha256']
            before=json.loads(raw);after=load(QUALITY/engine/'s0'/case['id']/'result.json')
            rows.append({'job':case['id'],
                'material_difference_percent':100*(after['validation']['metrics']['normalized_material']/before['validation']['metrics']['normalized_material']-1),
                'charged_work_rate_difference_percent':100*((after['work']/after['elapsed_seconds'])/(before['work']/before['elapsed_seconds'])-1)})
        comparison['browsers'][engine]={'rows':rows,
            'median_material_difference_percent':statistics.median(r['material_difference_percent'] for r in rows),
            'median_charged_work_rate_difference_percent':statistics.median(r['charged_work_rate_difference_percent'] for r in rows)}
write(OUT/'historical-comparison.json',comparison)
write(OUT/'checks.json',checks)
shutil.copyfile(Path(__file__),OUT/'snapshots/output/h4_score_report.py')

roots=[OUT,QUALITY,CHECKS,*REPLAYS]
raw=sorted(p for root in roots for p in root.rglob('*') if p.is_file())
archive=OUT/'raw.zip';assert not archive.exists()
members={p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in raw}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in raw:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,v in members.items():
        b=z.read(name);assert len(b)==v['bytes'] and sha256(b).hexdigest()==v['sha256']
write(OUT/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,
    'crc_and_every_member_hash_verified':True,'members':members})
keep={'plan.json','results.json','progress.json','comparison.json','measurement-plan.json',
      'measurement-execution.json','environment.json','historical-comparison.json','checks.json'}
for p in raw:
    if p.parent in roots and p.name in keep:continue
    assert any(p.resolve().is_relative_to(root.resolve()) for root in roots)
    p.unlink()
print(json.dumps({'checks':checks,'historical_comparison':comparison,'archive':{
    'members':len(members),'bytes':archive.stat().st_size,'sha256':digest(archive)}},indent=2))
