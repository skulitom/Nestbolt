from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
out = ROOT/'benchmarks/results/h4-score-checks-20261015'
out.mkdir(exist_ok=False)
commands = [
    ('format', ['cargo','fmt','--all','--check']),
    ('clippy', ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
    ('workspace-tests', ['cargo','test','--workspace','--locked']),
    ('score-release-tests', ['cargo','test','--release','-p','nestbolt-core','--lib','separate::','--locked']),
    ('cli-release-tests', ['cargo','test','--release','-p','nestbolt-cli','--test','features','--locked']),
    ('native-build', ['cargo','build','--release','--locked','-p','nestbolt-cli','-p','nestbolt-mcp']),
    ('web-build-and-tests', [sys.executable,'scripts/build_web.py','--test']),
]
rows = []
for name, command in commands:
    started = time.perf_counter()
    with (out/(name+'.log')).open('wb') as log:
        result = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    row = dict(name=name,command=command,exit_code=result.returncode,
               wall_seconds=time.perf_counter()-started,
               log_sha256=sha256((out/(name+'.log')).read_bytes()).hexdigest())
    rows.append(row)
    (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(row),flush=True)
    if result.returncode:sys.exit(result.returncode)
print('All score checks passed',flush=True)
