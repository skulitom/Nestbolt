from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-post-exchange-fill-probe-20261018'
plan=json.loads((probe/'preparation.json').read_bytes())
proof=json.loads((probe/'regression-before.json').read_bytes())
assert proof['expected_assertion_failed'] and proof['one_authored_test_failed']
shutil.copyfile(probe/'preparation.json',probe/'preparation-before-counters.json')
path=probe/'candidate/crates/core/src/sheets.rs';text=path.read_text(encoding='utf-8')
needle='    pub paired_exchanges: u64,';assert text.count(needle)==1
text=text.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub post_exchange_fill_calls: u64,\n    #[serde(skip_serializing_if = "is_zero")]\n    pub post_exchange_fill_moves: u64,')
path.write_text(text,encoding='utf-8',newline='\n')
path=probe/'candidate/crates/core/src/sheets/vstrip.rs';text=path.read_text(encoding='utf-8')
needle='''                        let gap_moves = gaps
                            && timed("fill", || self.fill_gaps(&strip, &mut sep, shape)) > 0;
                        if exchanged > 0
                            || gap_moves'''
replacement='''                        let gap_moves = if gaps {
                            let moved = timed("fill", || self.fill_gaps(&strip, &mut sep, shape));
                            if exchanged > 0 {
                                self.stats.post_exchange_fill_calls += 1;
                                self.stats.post_exchange_fill_moves += moved as u64;
                            }
                            moved
                        } else {
                            0
                        };
                        if exchanged > 0
                            || gap_moves > 0'''
assert text.count(needle)==1
path.write_text(text.replace(needle,replacement),encoding='utf-8',newline='\n')
path=probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs';text=path.read_text(encoding='utf-8')
start=text.index('    fn accepted_exchange_still_fills_a_known_gap()')
prefix=text[:start];new=text[start:]
needle='                assert!(search.stats.direct_insertions > 0, "accepted exchange must retain gap filling: {:?}", search.stats);'
assert new.count(needle)==1
new=new.replace(needle,needle+'\n                assert!(search.stats.post_exchange_fill_calls > 0);\n                assert!(search.stats.post_exchange_fill_moves > 0);')
needle='                assert_eq!(search.stats.directed_exchanges, 0);';assert new.count(needle)==1
new=new.replace(needle,needle+'\n                assert_eq!(search.stats.post_exchange_fill_calls, 0);\n                assert_eq!(search.stats.post_exchange_fill_moves, 0);')
path.write_text(prefix+new,encoding='utf-8',newline='\n')
plan['changed_files'].append('crates/core/src/sheets.rs')
plan['observation_counters']='Omitted-zero post_exchange_fill_calls and post_exchange_fill_moves; no selection, work charges or deadlines depend on them.'
(probe/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Added omitted-zero counters and their accepted/disabled/expired regression checks')
