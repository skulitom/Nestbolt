"""Require the new authored regression to fail on the unchanged runtime."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import difflib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-post-exchange-fill-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());work=out/'candidate'
testrel='crates/core/src/sheets/vstrip/exchange.rs';runtime='crates/core/src/sheets/vstrip.rs'
old=Path(plan['old_probe'])/'candidate'
assert (work/runtime).read_bytes()==(old/runtime).read_bytes()
assert (work/testrel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(old/testrel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',plan['target'],
    'sheets::vstrip::exchange::tests::accepted_exchange_still_fills_a_known_gap','--','--exact','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (out/'regression-before.log').open('xb') as f:
    result=subprocess.run(command,cwd=work,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
log=(out/'regression-before.log').read_text(encoding='utf-8')
record={'command':command,'exit_code':result.returncode,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
    'log_sha256':sha256((out/'regression-before.log').read_bytes()).hexdigest(),
    'runtime_unchanged':True,'expected_assertion_failed':'accepted exchange must retain gap filling:' in log,
    'one_authored_test_failed':'0 passed; 1 failed' in log,'measured_searches':0}
(out/'regression-before.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result.returncode==101 and record['expected_assertion_failed'] and record['one_authored_test_failed'],record
shutil.copyfile(work/testrel,out/'regression-source-before-format.rs')
path=work/runtime;before=path.read_text(encoding='utf-8')
needle='''                        if exchanged > 0
                            || (gaps
                                && timed("fill", || self.fill_gaps(&strip, &mut sep, shape)) > 0)
                            || timed("relocate", || {'''
replacement='''                        // An accepted exchange may only rearrange parts. Keep
                        // the direct gap-fill opportunity in the new layout.
                        let gap_moves = gaps
                            && timed("fill", || self.fill_gaps(&strip, &mut sep, shape)) > 0;
                        if exchanged > 0
                            || gap_moves
                            || timed("relocate", || {'''
assert before.count(needle)==1
after=before.replace(needle,replacement)
path.write_text(after,encoding='utf-8',newline='\n')
(out/'runtime.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='rejected-pair-candidate',tofile='post-exchange-fill-candidate')),encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_balanced_group_v3.py').read_text(encoding='utf-8').replace('h5-balanced-group-probe-20261018','h5-post-exchange-fill-probe-20261018').replace("+'-v3.log'","+'.log'").replace('progress-v3.json','progress.json').replace('build-v2.json','build.json').replace('build-failure-v3.json','build-failure.json')
(root/'output/build_h5_post_exchange_fill.py').write_text(builder,encoding='utf-8',newline='\n')
print(json.dumps({'original_test_failed_as_expected':True,'isolated_runtime_patch_written':True}))
