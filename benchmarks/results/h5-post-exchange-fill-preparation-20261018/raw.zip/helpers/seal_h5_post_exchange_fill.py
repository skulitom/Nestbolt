from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-post-exchange-fill-probe-20261018'
out=root/'benchmarks/results/h5-post-exchange-fill-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');public=load(probe/'public-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed']
for row in public['records']:
    stats=row['stats'];calls=stats.get('post_exchange_fill_calls',0);moves=stats.get('post_exchange_fill_moves',0)
    assert type(calls) is int and type(moves) is int and moves<=stats.get('direct_insertions',0)
    if row['arm']=='candidate':assert calls==stats.get('directed_exchanges',0)
    else:assert calls==moves==0
assert '98 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
regression=load(probe/'regression-before.json')
assert regression['runtime_unchanged'] and regression['expected_assertion_failed'] and regression['one_authored_test_failed']
assert digest(probe/'regression-before.log')==regression['log_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
assert digest(probe/'rejected-pair-observer.exe')==plan['rejected_pair_observer_sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json')
assert digest(root/method['reference'])==method['reference_sha256']
assert digest(root/method['candidate_runner'])==method['runner_sha256']
exchange='crates/core/src/sheets/vstrip/exchange.rs'
before=(Path(plan['old_probe'])/'candidate'/exchange).read_text(encoding='utf-8')
after=(probe/'candidate'/exchange).read_text(encoding='utf-8')
assert before.split('#[cfg(test)]')[0]==after.split('#[cfg(test)]')[0]
assert after[after.index('#[cfg(test)]'):].startswith(before[before.index('#[cfg(test)]'):].rsplit('\n}',1)[0])
patch=[]
for rel in plan['changed_files']:
    before=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8')
    after=(probe/'candidate'/rel).read_text(encoding='utf-8')
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='rejected-pair/'+rel,tofile='post-exchange-fill/'+rel))
(probe/'candidate-final.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_post_exchange_fill.py','check_h5_post_exchange_fill_before.py',
    'add_h5_post_exchange_fill_counters.py','build_h5_post_exchange_fill.py','prepare_h5_post_exchange_fill_checks.py',
    'check_h5_post_exchange_fill_public.py','check_h5_post_exchange_fill_harness.py','seal_h5_post_exchange_fill.py',
    'record_h5_post_exchange_fill_preparation.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/pilot.py']=root/'scripts/h5_post_exchange_fill_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'all_members_and_crc_verified':True})
write(out/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':98,'all_97_previous_tests_retained':True,
    'new_regression_tests':1,'original_runtime_fails_new_regression':True,'strict_lint_pass':True,
    'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,
    'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'whole_exchange_implementation_unchanged':True,
    'production_files_unchanged':True,'binaries':build['binaries'],'measured_search_started':False,'H5_complete':False,'integrated':False,'completed_weight_percent':60})
for name in ['preparation.json','build.json','regression-before.json','runtime.patch','candidate-final.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
doc='''# Gap filling after accepted exchanges — preparation, 2026-10-18

The [identity/stage diagnosis](h5-balanced-stage-20261018.md) found three
accepted exchanges with no immediate material/extent decrease. Two preserved
per-sheet inventory. Source inspection showed that any accepted exchange
short-circuited the following direct gap-fill step. That finding alone did not
establish whether continuing it would improve final packing.

The isolated candidate now runs the existing direct gap-fill step after an
exchange, including successful exchanges, before deciding whether relocation
is needed. It preserves the old relocation short circuit when an exchange or
direct fill succeeds. The exchange algorithm, repair/acceptance rules, gap
sampler, clock/work charges and overall search limits remain. With no accepted
exchange, execution order remains the same. Production is unchanged.

Two omitted-zero counters report post-exchange fill calls and moved parts.
The original runtime fails a new authored regression: its exchange succeeds
but no direct insertion occurs. With the fix, the same test requires a small
part to reach a known earlier-sheet gap, preserves geometry/material, and
checks the new counters plus disabled/expired behavior. The original failed
test log and source are retained.

All 98 optimized core tests pass, including all 97 previous tests. Strict
lint/build, ten authored fixed-work observer outcomes, four public CLI
comparisons and five adversarial harness checks pass. Normal full output is
exact apart from wall duration; common-mode replays and independent metrics
agree. Source, binary, archive CRC and every member hash verify.

The paired pilot retains four jobs, two kerfs, three seeds, three rotating
sequential arms on eight physical CCD0 cores and 60-second search limits.
Block, scoring, case and measurement functions are AST-identical to the prior
pilot. All original failures and the +1% material limit remain. The full
13-job H5 gate is still required; no reserved files or integration.
H2/H5 remain open; completed weight stays 60%.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-post-exchange-fill-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:
    f.write('''

## 2026-10-18 — Qualify gap filling after accepted exchanges

[The isolated correction](benchmarks/results/h5-post-exchange-fill-preparation-20261018.md)
passes 98 optimized core tests, strict lint/build, ten authored observer
outcomes, four public CLI comparisons and five paired-harness checks.
An authored known-gap regression fails on the original runtime, then passes
after the existing gap-fill step is moved ahead of the accepted-exchange
short circuit. The original failure, all 97 old tests, original exchange
algorithm and every geometry/material/budget rule remain. Omitted-zero
counters record post-exchange fill calls and moved parts.

Normal output and common fixed-work replays pass. Four-job pairing/scoring
methods and the +1% limit stay unchanged. No measured improvement, production
change or H5 credit is claimed. H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':archive.stat().st_size}))
