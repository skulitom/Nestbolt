"""Isolate gap filling after accepted exchanges; retain the original rejected pair candidate."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,sys
root=Path(__file__).resolve().parents[1]
out=root/'output/h5-post-exchange-fill-probe-20261018';out.mkdir(exist_ok=False)
old=root/'output/h5-balanced-group-probe-20261018'
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
testrel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/testrel
text=path.read_text(encoding='utf-8')
start=text.index('    #[test]\n    fn window_search_reaches_exchange_before_gap_filling()')
end=text.index('    #[test]',start+12)
new=text[start:end].replace('window_search_reaches_exchange_before_gap_filling','accepted_exchange_still_fills_a_known_gap')
needle='''                assert!(search.stats.directed_exchanges > 0);'''
assert new.count(needle)==1
new=new.replace(needle,needle+'''
                assert!(search.stats.direct_insertions > 0, "accepted exchange must retain gap filling: {:?}", search.stats);
                assert!(search.best.0.placements.iter().any(|p| p.part_id == "gap-part" && p.sheet_id == "sheet-0"),
                    "the known gap part must reach the earlier sheet");''')
closing=text.rindex('\n}')
path.write_text(text[:closing]+'\n'+new+text[closing:],encoding='utf-8',newline='\n')
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
shutil.copyfile(old/'candidate-observer.exe',out/'rejected-pair-observer.exe')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),
    'changed_files':['crates/core/src/sheets/vstrip.rs',testrel],'added_files':{},'production_digest':source_digest(),
    'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'target':str(root/'output/h5-post-exchange-fill-target-20261018'),
    'baseline_observer_sha256':digest(out/'baseline-observer.exe'),'rejected_pair_observer_sha256':digest(out/'rejected-pair-observer.exe'),
    'policy':'Run existing gap filling before the accepted-exchange short circuit. With zero accepted exchanges, call order, random numbers, work charges and behavior remain unchanged. Existing exchange, gap sampler and relocation policies, overall search limits, normal mode and final validation/material guards remain.',
    'new_tests':1,'all_97_existing_tests_retained':True,'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'new_regression_test':1,'runtime_changed':False}))
