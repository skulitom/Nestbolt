from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-post-exchange-fill-probe-20261018'
source=root/'scripts/h5_balanced_group_pilot.py'
text=source.read_text(encoding='utf-8')
text=text.replace('h5-balanced-group-probe-20261018','h5-post-exchange-fill-probe-20261018')
text=text.replace('h5-balanced-group-preparation-20261018','h5-post-exchange-fill-preparation-20261018')
text=text.replace('build-v2.json','build.json')
text=text.replace('h5-return-reuse-pilot-20261018/results.json','h5-balanced-group-pilot-20261018/results.json')
text=text.replace('Isolated balanced incoming-pair candidate, common-line search bonus on','Isolated post-exchange gap-fill candidate, common-line search bonus on')
text=text.replace('h5-return-reuse-stage-diagnosis-20261018','h5-balanced-stage-20261018')
text=text.replace('h5_return_reuse_stage_diagnosis.py','h5_balanced_stage.py')
text=text.replace("['all_original_archives_and_traces_verified']","['all_original_archives_verified']")
end=text.index('"""',3)+3
text='''"""Paired development pilot for gap filling after accepted exchanges.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The candidate retains the rejected
balanced-pair experiment but runs its existing direct gap-fill step after an
accepted exchange. Original search budgets, samplers, geometry and material
acceptance rules remain. All earlier failed results stay. This pilot cannot
close H5 or justify a public comparative claim.
"""'''+text[end:]
needle="                  ROOT/'benchmarks/results/h5-return-frame-pilot-20261017/verification.json'])"
assert text.count(needle)==1
text=text.replace(needle,"                  ROOT/'benchmarks/results/h5-return-frame-pilot-20261017/verification.json',\n                  ROOT/'benchmarks/results/h5-balanced-stage-20261018/observed-exchanges.json',\n                  ROOT/'benchmarks/results/h5-balanced-stage-20261018/control-flow-review.json'])")
target=root/'scripts/h5_post_exchange_fill_pilot.py'
target.write_text(text,encoding='utf-8',newline='\n')
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)}
before,after=functions(source),functions(target)
names=['blocks','summarize','case','measure']
assert all(before[n]==after[n] for n in names)
method={'reference':source.relative_to(root).as_posix(),'reference_sha256':sha256(source.read_bytes()).hexdigest(),
    'candidate_runner':target.relative_to(root).as_posix(),'runner_sha256':sha256(target.read_bytes()).hexdigest(),
    'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
for suffix in ['public','harness']:
    p=root/f'output/check_h5_balanced_group_{suffix}.py'
    s=p.read_text(encoding='utf-8').replace('h5-balanced-group-probe-20261018','h5-post-exchange-fill-probe-20261018').replace('h5_balanced_group_pilot','h5_post_exchange_fill_pilot').replace('build-v2.json','build.json')
    (root/f'output/check_h5_post_exchange_fill_{suffix}.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
