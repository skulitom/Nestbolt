from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
checks=json.loads((root/'benchmarks/results/h5-post-exchange-fill-preparation-20261018/checks.json').read_bytes())
assert checks['all_functional_checks_pass'] and checks['original_runtime_fails_new_regression']
marker='**N4 post-exchange gap-fill preparation, 2026-10-18:**'
note='''**N4 post-exchange gap-fill preparation, 2026-10-18:** [the isolated correction](../benchmarks/results/h5-post-exchange-fill-preparation-20261018.md)
passes 98 optimized core tests, strict lint/build, ten authored observer outcomes,
four public CLI comparisons and five paired-harness checks. A new known-gap
regression fails on the unchanged runtime, then passes when direct gap filling
continues after an accepted exchange. Normal output stays exact and common
fixed-work replay passes. Original exchange, repair, geometry/material rules,
search limits and all 97 earlier tests remain. Counters track the follow-up
calls and moved parts. The committed 72-outcome pilot preserves its original
paired method and +1% limit. No measured improvement, production change or
H5 credit yet. H2/H5 remain open at 60%.
'''
paths=[root/n for n in ['docs/STATUS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']]
assert all(marker not in p.read_text(encoding='utf-8') for p in paths)
status=paths[0];text=status.read_text(encoding='utf-8');at=text.index('**N4 pair-identity diagnosis, 2026-10-18:**')
status.write_text(text[:at]+note+'\n'+text[at:],encoding='utf-8',newline='\n')
for p in paths[1:]:
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n'+note)
print('Prepared candidate recorded without milestone credit')
