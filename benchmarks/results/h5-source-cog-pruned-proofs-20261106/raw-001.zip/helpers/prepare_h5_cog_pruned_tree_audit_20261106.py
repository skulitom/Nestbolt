from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_union_augmented_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first57-union-augmented-trees-20261106'","BASE=ROOT/'output/h5-first57-cog-pruned-trees-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-joint-optional-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-union-augmented-trees-20261106'")
s=s.replace("AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'","AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'\nPRUNE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'")
s=s.replace('h5-first57-union-augmented-trees-process-20261106','h5-first57-cog-pruned-trees-process-20261106')
s=s.replace("inputs={Path(__file__),","inputs={Path(__file__),ROOT/'output/prepare_h5_cog_pruned_tree_audit_20261106.py',ROOT/'output/audit_h5_union_augmented_trees_20261106.py',PRUNE/'audit/stronger-model-candidates.json',PRUNE/'integer-source.json',PRUNE/'cells.json',PRUNE/'collision-polygons.json',PRUNE/'certificates.json',")
s=s.replace("FRONTIER/'audit',AUG/'audit']","FRONTIER/'audit',AUG/'audit',PRUNE/'audit']")
s=s.replace('[BR,INS,FRONTIER,AUG]','[BR,INS,FRONTIER,AUG,PRUNE]')
a="selection=[r['source_selection']|{'augmentation_index':r['augmentation_index']} for r in load(AUG/'audit/stronger-model-candidates.json')]\nassert len(selection)==52"
b="selection=[r['source_selection']|{'pruning_index':r['pruning_index']} for r in load(PRUNE/'audit/stronger-model-candidates.json')]\nassert len(selection)==39"
assert a in s;s=s.replace(a,b)
a="total_added=0;point_checks=[0]"
b="""total_added=0;point_checks=[0]
integer_source=load(PRUNE/'integer-source.json');scale=int(integer_source['scaled_units_per_micrometre']);assert scale>0
pruning_cells=load(PRUNE/'cells.json');pruning_certificates=load(PRUNE/'certificates.json')
pruning_templates=load(PRUNE/'collision-polygons.json')
pruning_polygons=[[tuple(map(int,p)) for p in t['vertices_scaled']] for t in pruning_templates]
pruning_shifts=[tuple(map(int,r['translation_scaled'])) for r in integer_source['sites']]
root_removals=0;root_corner_checks=0
"""
assert a in s;s=s.replace(a,b)
a="    evaluated=[0]\n    @lru_cache"
b="""    ppath=PRUNE/f"choice-{row['pruning_index']:02d}.json";inputs.add(ppath);pruning=load(ppath)
    assert pruning['empty_sites']==row['empty_sites'] and pruning['removed']
    assert data['original_source_removed_nodes']==len(pruning['removed'])
    assert pruning['original_bracket_node_count']==offset and len(pruning['node_cells'])==len(nodes)
    removed=set()
    for removal in pruning['removed']:
        n=removal['node'];assert 0<=n<len(nodes) and n not in removed;removed.add(n)
        proof=pruning_certificates[removal['certificate']]
        assert proof['cell']==pruning['node_cells'][n] and proof['site'] not in row['empty_sites']
        cell=pruning_cells[proof['cell']];template=pruning_templates[proof['template']]
        assert cell['geometry']==nodes[n]['geometry']==template['geometry'] and cell['bounds_um']==nodes[n]['bounds_um']
        shift=pruning_shifts[proof['site']]
        poly=[(x+shift[0],y+shift[1]) for x,y in pruning_polygons[proof['template']]]
        x0,y0,x1,y1=cell['bounds_um']
        for a,b in zip(poly,poly[1:]+poly[:1]):
            for x,y in product([x0*scale,x1*scale],[y0*scale,y1*scale]):
                assert (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>0;root_corner_checks+=1
    assert pruning['retained_bracket_nodes']==sorted(set(range(offset))-removed)
    assert pruning['retained_insert_nodes']==sorted(set(range(offset,len(nodes)))-removed)
    root_removals+=len(removed)
    evaluated=[0]
    @lru_cache"""
assert a in s;s=s.replace(a,b)
a="closed=replay(data['root'],[set(range(offset)),set(range(offset,len(nodes)))],[[],[]])"
b="closed=replay(data['root'],[set(pruning['retained_bracket_nodes']),set(pruning['retained_insert_nodes'])],[[],[]])"
assert a in s;s=s.replace(a,b)
s=s.replace("assert len(prior)==52","assert len(prior)==39")
s=s.replace("'previous_fixed29_choices_excluded':403","'previous_fixed29_choices_excluded':416").replace("'total_fixed29_choices_excluded':403+len(removed)","'total_fixed29_choices_excluded':416+len(removed)")
s=s.replace("'added_source_conflict_edges_verified':total_added,","'original_source_root_removals_verified':root_removals,'strict_root_corner_checks':root_corner_checks,'added_source_conflict_edges_verified':total_added,")
s=s.replace("Full root source covers remain unchanged; this is a genuinely stronger graph, including the former known-witness case.","Every root cover is the complete prior domain minus only independently certified original-source cog collisions. Every removed cell and present-site certificate is replayed with exact integer corner halfplanes, all other cells remain, and every case has a strictly smaller source-certified root domain. This is a genuinely stronger necessary problem; prior union edges are retained.")
with (O/'audit_h5_cog_pruned_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent root source-polygon and complete39-case tree replay.')
