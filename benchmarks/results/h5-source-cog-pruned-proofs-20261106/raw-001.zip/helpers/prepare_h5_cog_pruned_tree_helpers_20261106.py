from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_union_augmented_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace("OUT=ROOT/'output/h5-first57-union-augmented-trees-20261106'","OUT=ROOT/'output/h5-first57-cog-pruned-trees-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-optional-bracket-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-union-augmented-trees-20261106'")
s=s.replace("AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'","AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'\nPRUNE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'")
s=s.replace('[BR,INS,FRONTIER,AUG]','[BR,INS,FRONTIER,AUG,PRUNE]')
a="""selection=[r['source_selection']|{'augmentation_index':r['augmentation_index']} for r in load(AUG/'audit/stronger-model-candidates.json')]
assert len(selection)==52"""
b="""selection=[r['source_selection']|{'pruning_index':r['pruning_index']} for r in load(PRUNE/'audit/stronger-model-candidates.json')]
assert len(selection)==39"""
assert a in s;s=s.replace(a,b)
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_cog_pruned_tree_helpers_20261106.py',ROOT/'output/prepare_h5_union_augmented_trees_20261106.py',PRUNE/'audit/stronger-model-candidates.json',")
a='+[AUG/f"choice-{r[\'augmentation_index\']:02d}.json" for r in selection]'
assert a in s;s=s.replace(a,a+'+[PRUNE/f"choice-{r[\'pruning_index\']:02d}.json" for r in selection]')
start=s.index("    'method':");end=s.index('\nsummaries=[]',start)
s=s[:start]+"""    'method':'New necessary model on39 cases, each with strictly smaller source-certified root domains. Exact original-source cog collision polygons prove the removed cells impossible for the present cog sites. Preserve every other bracket/insert cell, all source aliases and all previous single-component and union conflict edges. The existing two-family proof tree runs once with fresh0.70/0.75-second case cutoffs,1500 nodes and50/55/65 global caps. Include/skip branches remain exhaustive over the certified retained domains. Only an independently complete closed tree excludes a fixed arrangement. Open leaves and graph witnesses remain unresolved; no prior process is extended or repeated.'})
""" + s[end:]
a="    root_available=[(1<<offset)-1,((1<<len(nodes))-1)^((1<<offset)-1)]"
b="""    pruning=load(PRUNE/f"choice-{row['pruning_index']:02d}.json")
    assert pruning['empty_sites']==row['empty_sites'] and pruning['removed']
    root_available=[sum(1<<n for n in pruning['retained_bracket_nodes']),sum(1<<n for n in pruning['retained_insert_nodes'])]"""
assert a in s;s=s.replace(a,b)
s=s.replace("'graph_complete':graph_complete,'added_source_conflict_edges':","'graph_complete':graph_complete,'original_source_removed_nodes':len(pruning['removed']),'added_source_conflict_edges':")
with (O/'prepare_h5_cog_pruned_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_union_augmented_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('union-augmented-trees','cog-pruned-trees').replace('prepare_h5_union_augmented_trees','prepare_h5_cog_pruned_trees')
with (O/'run_h5_cog_pruned_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a distinct39-case tree with original-source cog-pruned root domains.')
