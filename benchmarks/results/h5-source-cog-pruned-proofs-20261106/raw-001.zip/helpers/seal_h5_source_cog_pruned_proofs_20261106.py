from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-source-cog-pruned-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
PRUNE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';BASE=ROOT/'output/h5-first57-cog-pruned-trees-20261106'
SYNC=ROOT/'output/h5-union-augmented-main-sync-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
pa=load(PRUNE/'audit/checks.json');audit=load(BASE/'audit/checks.json')
assert pa['passed'] and audit['passed'] and pa['removed_node_occurrences_verified']==847 and pa['exact_collision_polygons_verified']==378
assert audit['new_fixed29_choices_excluded']==11 and audit['remaining_fixed29_choices']==28
assert audit['tree_records_verified']==19443 and audit['total_joint_graph_witnesses']==10 and len(audit['budget_limited_cases'])==18
assert load(SYNC/'receipt.json')['new_main']=='f543f08263797366abbbf6cea2e3193ff4fd84ad'
process_folders=[ROOT/'output'/f'h5-first57-{n}-process-20261106' for n in ['source-cog-cell-pruning','cog-pruned-trees']]
processes=[load(p/'process.json') for p in process_folders]
assert all(p['closed'] and p['exit_code']==0 and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert audit['case_complete_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106','h5-deferred-conflict-tree-20261106','h5-optional-bracket-trees-20261106','h5-joint-optional-trees-20261106','h5-union-augmented-proofs-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [PRUNE,BASE,SYNC]+process_folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_source_cog*20261106.py','*h5_cog_pruned*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-source-cog-pruned-proofs-report-20261106.md','push_h5_union_augmented_checkpoint_20261106.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(PRUNE/'audit/checks.json','polygon-audit.json'),(BASE/'audit/checks.json','tree-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/joint-graph-witnesses.json','joint-graph-witnesses.json'),(SYNC/'receipt.json','main-sync-receipt.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'new_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),
    'processes':processes,'independent_audit_seconds':[pa['seconds'],audit['seconds']],
    'tree_limited_cases':18,'all_processes_closed':True,'case_complete_cap_overrun_seconds':0,
    'placement_solver_calls':0,'native_calls':0,'full_construction_60_90_budget_claimed':False})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'current_cog_pruned_tree_process_closed':True,
    'remaining_fixed29_choices':28,'total_fixed29_choices_excluded':427,'joint_graph_witnesses':10,'limited_joint_cases':18,
    'next_method':'Assess finite exact subdivision certificates that several source collision polygons jointly cover a remaining closed anchor cell. Use the already certified integer collision polygons and present cog sites. At each node, a closed subbox strictly inside one source polygon is a closed leaf. Otherwise split along an axis at an exact interior rational/integer-scaled point; both closed children must cover the parent exactly. Every leaf must close to remove the original cell. Counterexample sample points outside all available open collision polygons, depth/node/time limits or unvisited children leave the whole parent cell retained. Freeze the subdivision depth/node/time limits and independently replay every parent/child boundary and source halfplane certificate. Cache only certificates whose present-site requirements are checked for every arrangement that consumes them. First measure genuinely new certified removals; do not rerun unchanged domains or any closed process. All consumed preparation remains chargeable before any construction claim.',
    'survivors':'output/h5-first57-cog-pruned-trees-20261106/audit/remaining-fixed29-choices.json',
    'joint_witnesses':'output/h5-first57-cog-pruned-trees-20261106/audit/joint-graph-witnesses.json',
    'exact_collision_polygons':'output/h5-first57-source-cog-cell-pruning-20261106/collision-polygons.json',
    'integer_source':'output/h5-first57-source-cog-cell-pruning-20261106/integer-source.json',
    'source_pruned_domains':'output/h5-first57-source-cog-cell-pruning-20261106',
    'bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104','insert_geometry':'output/h5-first57-broader-insert-covers-20261106',
    'new_union_subdivision_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded':11,'remaining_fixed29_choices':28,'total_fixed29_choices_excluded':427,'original_fixed29_choices':455,
    'exact_source_collision_polygons':378,'source_collision_certificates':173,'removed_source_node_occurrences':847,
    **{k:audit[k] for k in ['tree_records_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks','strict_source_inner_pair_evaluations']},
    'joint_graph_witnesses':10,'limited_joint_cases':18,'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-source-cog-pruned-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 original-source cog pruning:** [independent exact source and tree replay]({link}) verifies 378 convex collision polygons, 173 closed-cell certificates and 847 removed node occurrences across all 39 arrangements. All unproved cells and source aliases remain. The new retained-domain trees verify 19,443 records and 598,126 ordered removals; eleven complete trees exclude fixed29/cog choices, leaving 28 (427 of 455 excluded). Ten necessary graph witnesses and eighteen cutoff cases remain unresolved. Complete preparations take 0.931841 and 20.396204 s with no complete-case/process overrun or placement/native call. Next assess bounded exact subdivision proofs of coverage by unions of original-source collision polygons; incomplete cells must remain retained. No full construction budget is claimed and every prior process stays closed. The previous five checkpoints were pushed normally to main f543f082 after all six prior CI jobs passed; new CI has four passes and two live native checks. Full66 checks, 440 whole allocations and H2/H5 stay open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [exact union-augmented proofs](../benchmarks/results/h5-union-augmented-proofs-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [original-source cog pruning](../benchmarks/results/{NAME}.md).',1)
a='Exact component-union conflicts strengthen every remaining case; augmented\njoint trees exclude thirteen more. There are 39 remaining choices (416 of 455\nexcluded): 27 necessary joint graph witnesses and 12 cutoff cases. Whole-cell\ncollision proofs against original cog polygons are next. All prior calls and\nbounded processes stay closed.'
b='Exact component-union conflicts exclude thirteen more. Original cog polygon\nproofs remove847 impossible node occurrences; new joint trees exclude another\neleven, leaving28 choices (427 of455 excluded):10 necessary joint graph witnesses\nand18 cutoff cases. Exact subdivision proofs for unions of source collision\npolygons are next. All prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
