"""Independent exact edge-integral audit of every band demand and cell cover."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from functools import lru_cache
import json,math,shutil,time
from shapely.geometry import Polygon,shape
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-second-strip-band-capacity-20261026';SOURCE=ROOT/'output/h5-second-strip-four-cogs-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reconstruct all11 approved original profiles, exact stock and complete integer vertical-cell coverage. Independently integrate oriented polygon edges below each band boundary using rational arithmetic, without the builder piecewise-prefix helper. For every cell/band include all translated vertex breakpoints, recover each derivative line from two interior evaluations and include every interior stationary point. Recompute all42399 minima and conservative integer demands exactly, plus all63 capacities. Record the aggregate-count implication for any feasible guarded-source arrangement. No source solve and no raw unrestricted-rotation theorem.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
spec=load(BASE/'plan.json');source=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');families={p['id']:p for p in job['parts']};stock=[F(*v) for v in spec['stock_bounds_rational']];assert spec['stock_bounds_rational']==source['stock_bounds_rational'] and spec['required_original_counts']=={'bracket':4,'insert':2,'cog':4};bands=[[F(*v) for v in row] for row in spec['bands_mm']];assert len(bands)==63 and bands[0][0]==stock[1] and bands[-1][1]==stock[3] and all(a[1]==b[0] for a,b in zip(bands,bands[1:])) and all(b-a<=5 for a,b in bands)
assert load(BASE/'band-capacities.json')==[math.floor((stock[2]-stock[0])*(b-a)*1000) for a,b in bands];checked=cell_count=stationary=0;details=[]
for p in profiles:
    family=families[p['family']];angle=p['rotation_radians'];co,si=math.cos(angle),math.sin(angle);mi=-1 if p['mirrored'] else 1;assert not p['mirrored'] or family['allow_mirror']
    if p['family']=='cog':assert family['rotations']['kind']=='free';cx,cy=p['original_center'];tx,ty=-co*cx+si*cy,-si*cx-co*cy
    else:
        assert p['quarter_turn']*90. in family['rotations']['degrees'];rot=[(mi*x*co-y*si,mi*x*si+y*co) for x,y in family['geometry'][0]['outer']];tx,ty=-min(x for x,y in rot),-min(y for x,y in rot)
    original=affine_transform(Polygon(family['geometry'][0]['outer']),[mi*co,-si,mi*si,co,tx,ty]);assert original.hausdorff_distance(shape(p['geometry']))<1e-7
    pts=[tuple(F(v) for v in xy) for xy in p['geometry']['coordinates'][0]];twice=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(pts,pts[1:]));sign=1 if twice>0 else -1;edges=[]
    for a,b in zip(pts,pts[1:]):
        if a[1]==b[1]:continue
        multiplier=sign*(1 if b[1]>a[1] else -1);m=(b[0]-a[0])/(b[1]-a[1]);c=a[0]-m*a[1];edges.append((min(a[1],b[1]),max(a[1],b[1]),m,c,multiplier))
    ys=sorted(set(v[1] for v in pts));full=abs(twice)/2
    @lru_cache(None)
    def below(y):
        if y<=ys[0]:return F(0)
        if y>=ys[-1]:return full
        return sum(k*(m*(min(y,hi)**2-lo**2)/2+c*(min(y,hi)-lo)) for lo,hi,m,c,k in edges if y>lo)
    def width(y):return sum(k*(m*y+c) for lo,hi,m,c,k in edges if lo<y<hi)
    row=load(BASE/'profiles'/f"{p['index']:03d}.json");assert row['profile']==p['index'] and row['family']==p['family'] and F(*row['filled_outer_area_mm2'])==full;pad=F(.0125)+F(.000001);expected=[math.ceil((stock[1]+pad-F(p['bounds'][1]))*1000),math.floor((stock[3]-pad-F(p['bounds'][3]))*1000)];assert row['y_bounds_units1000']==expected;next_y=expected[0]
    for i,cell in enumerate(row['cells']):
        low,high=cell['y_bounds_units1000'];assert cell['index']==i and low==next_y and high==min(low+999,expected[1]);next_y=high+1;t0,t1=F(low,1000),F(high,1000);assert len(cell['band_lower_area_units'])==63
        for (a,b),want in zip(bands,cell['band_lower_area_units']):
            stops=sorted({t0,t1}|{bound-y for bound in [a,b] for y in ys if t0<bound-y<t1});candidates=list(stops)
            for u,v in zip(stops,stops[1:]):
                s1,s2=(2*u+v)/3,(u+2*v)/3;d1=width(a-s1)-width(b-s1);d2=width(a-s2)-width(b-s2);slope=(d2-d1)/(s2-s1)
                if slope:
                    root=s1-d1/slope
                    if u<root<v:candidates.append(root);stationary+=1
            exact=min(below(b-t)-below(a-t) for t in candidates);assert exact>=0 and math.floor(exact*1000)==want,(p['index'],i,a,b);checked+=1
        cell_count+=1
    assert next_y==expected[1]+1;details.append({'profile':p['index'],'cells':len(row['cells']),'passed':True})
assert checked==42399 and cell_count==673;write(OUT/'profile-checks.json',details);write(OUT/'implication.json',{'statement':'Assign each physical source part to its actual profile and unique vertical integer cell. Aggregate equal-family counts per cell. Every actual occupied band area is at least its independently verified cell minimum, and all filled profile outers are disjoint inside the guarded stock. Hence the sum of floored demand units cannot exceed the floored stock-band area. Three family sums retain every one of the ten mandatory originals. Removing horizontal coordinates, pair collisions and shared within-cell shifts only relaxes feasibility.','scope':'Current fixed cog orientation and source stock guard, with all eight bracket and both insert profiles. The three closed prescribed-orientation source models are contained in this necessary family allocation. No raw unrestricted-rotation or H5 acceptance claim.'});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_profiles_reconstructed':11,'complete_vertical_cells_verified':673,'exact_band_coefficients_recomputed':42399,'stock_bands_verified':63,'stationary_candidates_checked':stationary,'all_integer_anchor_values_covered':True,'aggregate_original_count_implication_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
