"""Seek a checkable rational weighted-band contradiction, separately from placement."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-second-strip-band-model-20261026';DATA=ROOT/'output/h5-second-strip-band-capacity-20261026';OUT=ROOT/'output/h5-second-strip-band-dual-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from ortools.linear_solver import pywraplp
    rows=load(MODEL/'mapping.json');caps=load(DATA/'band-capacities.json');counts={'bracket':4,'insert':2,'cog':4};solver=pywraplp.Solver.CreateSolver('GLOP');assert solver is not None;solver.SetTimeLimit(3000);weights=[solver.NumVar(0,1,f'w{j}') for j in range(63)];prices={f:solver.NumVar(0,solver.infinity(),f) for f in counts};solver.Add(sum(weights)==1)
    for row in rows:solver.Add(prices[row['family']]<=sum(a*w for a,w in zip(row['demands'],weights) if a))
    solver.Maximize(sum(counts[f]*p for f,p in prices.items())-sum(a*w for a,w in zip(caps,weights)));(OUT/'model.lp').write_text(solver.ExportModelAsLpFormat(False),encoding='utf-8',newline='\n');write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'solver':'GLOP','time_limit_ms':3000,'model_sha256':digest(OUT/'model.lp')});start=time.perf_counter();status=solver.Solve();elapsed=time.perf_counter()-start;record={'solver_status_code':status,'seconds':elapsed,'solver_calls':1,'objective':solver.Objective().Value() if status in [pywraplp.Solver.OPTIMAL,pywraplp.Solver.FEASIBLE] else None,'formal_float_solver_proof_claimed':False}
    if status in [pywraplp.Solver.OPTIMAL,pywraplp.Solver.FEASIBLE]:
        raw=[v.solution_value() for v in weights];w=[max(F(0),F(v).limit_denominator(1000000)) for v in raw];p={family:min(sum(F(a)*b for a,b in zip(row['demands'],w)) for row in rows if row['family']==family) for family in counts};demand=sum(counts[f]*p[f] for f in counts);capacity=sum(F(a)*b for a,b in zip(caps,w));write(OUT/'rational-candidate.json',{'raw_weights':raw,'weights':[[v.numerator,v.denominator] for v in w],'family_prices':{f:[v.numerator,v.denominator] for f,v in p.items()},'total_lower_demand':[demand.numerator,demand.denominator],'weighted_capacity':[capacity.numerator,capacity.denominator],'margin':[ (demand-capacity).numerator,(demand-capacity).denominator],'positive_exact_margin':demand>capacity});record['exact_candidate_positive']=demand>capacity
    write(OUT/'result.json',record)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'seek.py');assert load(ROOT/'output/h5-second-strip-band-search-20261026/audit/checks.json')['passed'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [MODEL/'mapping.json',MODEL/'audit/checks.json',DATA/'band-capacities.json',DATA/'audit/checks.json',ROOT/'output/h5-second-strip-band-search-20261026/audit/checks.json']},'method':'One new LP certificate search, not a placement retry. Choose nonnegative band weights summing to1 and family lower prices bounded by every audited cell demand dot weight. Maximize mandatory total price minus weighted stock capacity. One GLOP call at most3000milliseconds within15shared seconds. Rationalize weights only to propose a certificate; recompute each family price as an exact rational minimum over all673 cells. Only a separately independently verified strict positive rational margin proves the contradiction. Preserve nonpositive/unknown outcomes; no extension.'});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=15);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);r={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');r={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',r);print(r);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No result. Any opened call stays closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
