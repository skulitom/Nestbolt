"""Declare one new bounded call for the independently audited three-free-bracket model."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('run_h5_free_bracket_source_search.py','run_h5_three_free_brackets_search.py'),('audit_h5_free_bracket_source_search.py','audit_h5_three_free_brackets_search.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in [('h5-free-bracket-source-model-20261026','h5-three-free-brackets-model-20261026'),('h5-free-bracket-source-search-20261026','h5-three-free-brackets-search-20261026'),('h5-expanded-cog-joint-prepared-20261026','h5-free-bracket27-joint-prepared-20261026'),('h5-projected-expanded-model-20261026','h5-free-bracket27-source-model-20261026')]:s=s.replace(a,b)
    s=s.replace('223086','270671').replace('289926','351286').replace('==538','==954').replace(':538',':954').replace('all538','all954').replace('==12','==13').replace("'moving_originals':12","'moving_originals':13").replace("'fixed_originals':54","'fixed_originals':53").replace("'original_anchor_variables':24","'original_anchor_variables':26")
    s=s.replace('both_brackets_keep_all_source_options','all_three_brackets_keep_all_source_options').replace('Both brackets','All three brackets').replace('both brackets','all three brackets').replace('All24','All26').replace('all24','all26').replace('twelve-original','thirteen-original').replace('12 moving','13 moving').replace('54 fixed','53 fixed').replace('the54fixed','the53fixed')
    s=s.replace('The54 old hints are replaced by60 verified nonbinding partial hints.','The60 verified nonbinding partial hints are retained unchanged.').replace('two original-area rules and fresh capacity2','two original-area rules; selected non-bracket sheets independently satisfy the fresh capacity2')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
