"""Fresh source/main/upstream review for the strip-capacity checkpoint."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_partial59_final.py').read_text(encoding='utf-8').replace('h5-partial59-final-review-20261026','h5-second-strip-final-review-20261026').replace('fec3cd72205e16d3522a181bf4f29680b9e768e5','4817fefff0739e7d92a15cf0e710b6d29d6c51dc').replace('679e97e0d7fca4798ba2a1d690c044d72b8f72e2','c22d3e39e315b040b3afc694acae3e1beca685f8')
with (ROOT/'output/review_h5_second_strip_final.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
