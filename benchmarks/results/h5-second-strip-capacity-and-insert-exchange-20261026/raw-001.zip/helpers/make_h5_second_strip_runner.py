"""Run the three declared strip models once within their unchanged shared budget."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_bracket27_cross_family_probes.py').read_text(encoding='utf-8');s='"""Three predeclared ten-original strip models, one12second call each, sharing60seconds."""\n'+s[s.index('\n')+1:]
s=s.replace('h5-bracket27-cross-family-probes-20261026','h5-second-strip-four-cogs-probes-20261026').replace("-13:break","-17:break").replace("'num_search_workers':1","'num_search_workers':4").replace("'per_group_solver_seconds':8,'workers':1","'per_group_solver_seconds':12,'workers':4")
compile(s,'run_h5_second_strip_probes.py','exec')
with (ROOT/'output/run_h5_second_strip_probes.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
