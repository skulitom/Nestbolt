"""Retain a fresh CI observation and the single queued checkpoint."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-thirteen-part-checkpoint-queue-20261026';OUT.mkdir()
def call(args):return subprocess.check_output(args,cwd=ROOT).decode().strip()
call(['git','fetch','origin','main'])
ci=json.loads(call(['gh','run','view','40270374068','--json','databaseId,status,conclusion,headSha,jobs,url']))
head=call(['git','rev-parse','HEAD']);main=call(['git','rev-parse','origin/main'])
assert main==ci['headSha']=='c22d3e39e315b040b3afc694acae3e1beca685f8' and head=='4817fefff0739e7d92a15cf0e710b6d29d6c51dc' and call(['git','rev-list','--left-right','--count','origin/main...HEAD']).split()==['0','1'] and not call(['git','diff','HEAD','--name-only'])
record={'utc':datetime.now(timezone.utc).isoformat(),'queued_head':head,'main_head':main,'queued_commits':1,'main_ci_id':ci['databaseId'],'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion'],'passed_jobs':sum(j['conclusion']=='success' for j in ci['jobs']),'action':'Preserve current live CI. Normally fast-forward main with the verified queued commit once current checks finish and remote ancestry is rechecked. No force push.','next_step':'benchmarks/results/h5-thirteen-part-selection-and-sheet-exclusion-20261026/next-step.json','H5_complete':False}
for name,value in [('ci-observation.json',ci),('queue.json',record)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(record)
