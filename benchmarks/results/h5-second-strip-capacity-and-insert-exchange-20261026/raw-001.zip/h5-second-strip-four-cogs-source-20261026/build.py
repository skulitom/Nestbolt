"""Three new whole-strip orientation constructions with ten original parts."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations,product
import json,math,shutil,time
from shapely.geometry import Polygon,MultiPoint,shape,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-second-strip-four-cogs-source-20261026';EPS=.000001
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'mutual').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');job=load(JOB);families={p['id']:p for p in job['parts']};insert=Polygon(families['insert']['geometry'][0]['outer']);assert insert.bounds==(0.,0.,180.,110.)
profiles.append({'index':10,'family':'insert','quarter_turn':0,'mirrored':False,'rotation_radians':0.,'anchor':'oriented lower-left corner','rotated_original_min':[0,0],'original_vertex_count':len(families['insert']['geometry'][0]['outer']),'vertices':list(insert.exterior.coords)[:-1],'bounds':list(insert.bounds),'geometry':mapping(insert)})
items=load(SRC/'items.json');ids=[21,22,25,26,36,37,53,63,64,65];patterns=[[1,1,3,3,10,10,9,9,9,9],[0,0,2,2,10,10,9,9,9,9],[0,4,2,6,10,10,9,9,9,9]];used=sorted({i for row in patterns for i in row});pairs=sorted({(row[a],row[b]) for row in patterns for a,b in combinations(range(10),2)});old_cases={(c['profile_a'],c['profile_b']):c for c in spec['mutual_cases']};cases=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(pairs)];stock=load(SRC/'geometry.json')['stock_bounds_rational'][1];bounds={}
for pi in used:
    b=profiles[pi]['bounds'];st=[F(*v) for v in stock];pad=F(.0125)+F(EPS);bounds[pi]=[math.ceil((st[0]+pad-F(b[0]))*1000),math.ceil((st[1]+pad-F(b[1]))*1000),math.floor((st[2]-pad-F(b[2]))*1000),math.floor((st[3]-pad-F(b[3]))*1000)];assert bounds[pi][0]<=bounds[pi][2] and bounds[pi][1]<=bounds[pi][3]
paths=[JOB,SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',SRC/'items.json',SRC/'geometry.json',ROOT/'output/h5-three-free-brackets-search-20261026/search-audit/checks.json']+[SOURCE/'mutual'/f"{old_cases[p]['index']:03d}.json" for p in pairs if p in old_cases]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'parts':[{'part':i,'item':n,'family':items[n]['family'],'copy':items[n]['copy']} for i,n in enumerate(ids)],'orientation_patterns':patterns,'used_profiles':used,'anchor_bounds_units1000':bounds,'stock_bounds_rational':stock,'mutual_cases':cases,'construction_limit_seconds':240,'construction_clearance_mm':.2125,'clearance_envelope_extra_mm':.0001,'face_square_padding_mm':EPS,'extra_stock_margin_mm':.0125,'maximum_calls':3,'per_pattern_solver_seconds':12,'shared_solver_seconds':60,'solver_workers':4,'solver_seed':0,'method':'Distinct second-sheet-only constructive test: freely translate all four original second-sheet brackets21/22/25/26, both inserts36/37 and cogs63/64/65, and add first-sheet cog53. No old second-sheet pose is fixed; old fixed-shape capacity certificates do not apply. Three declared orientation patterns use current vertical bracket pairs, horizontal opposite pairs, or horizontal mirrored corners. Inserts use the job-approved zero-degree rectangle and all four cogs retain the original declared source angle. Keep native material-target stock bounds, original outlines, native guard and all45 physical collision pairs. Each pattern gets one12second call inside60shared seconds after geometry/model audits. A positive is only a ten-original sheet witness; the remaining56 originals and complete H5 acceptance remain required. A negative is limited to its prescribed orientations. No solver call during preparation.'})
write(OUT/'profiles.json',profiles);summary=[]
for c in cases:
    assert time.perf_counter()<deadline
    key=(c['profile_a'],c['profile_b'])
    if key in old_cases:
        p=SOURCE/'mutual'/f"{old_cases[key]['index']:03d}.json";r=load(p);old_case=r['case'];r['case']=c;r['reused_source_case']=old_case;r['reused_source_sha256']=digest(p);summary.append({**c,'reused':True,'faces':len(r['faces'])})
    else:
        a,b=[shape(profiles[k]['geometry']) for k in key];raw=raw_obstacle(a,b);guarded=expand(raw,.2125,.0001);faces,merge=convex_faces(guarded,deadline);records=[];expanded=[]
        for i,f in enumerate(faces):
            poly=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(list(f.exterior.coords)[:-1],[(-EPS,-EPS),(-EPS,EPS),(EPS,EPS),(EPS,-EPS)])]).convex_hull,sign=1);assert poly.covers(f);expanded.append(poly);records.append({'index':i,'raw_face':mapping(f),'expanded_face':mapping(poly),'outside_halfplanes':inequalities(poly,False)})
        assert unary_union(expanded).covers(guarded);r={'case':c,'raw_forbidden':mapping(raw),'expanded_forbidden':mapping(guarded),'merge':merge,'faces':records,'complete_forbidden_covered':True};summary.append({**c,'reused':False,'faces':len(records),**merge})
    assert r['complete_forbidden_covered'];write(OUT/'mutual'/f"{c['index']:03d}.json",r)
write(OUT/'case-summary.json',summary);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'patterns':3,'mandatory_sheet_originals':10,'brackets':4,'inserts':2,'cogs':4,'used_profiles':used,'pair_cases':len(cases),'cases_reused':sum(r['reused'] for r in summary),'cases_new':sum(not r['reused'] for r in summary),'full_guarded_faces':sum(r['faces'] for r in summary),'physical_pairs_per_pattern':45,'pending_cases':0,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'))
