"""Independent whole-parent, ten-domain, complete-choice and advisory-hint audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-three-free-brackets-model-20261026';PARENT=ROOT/'output/h5-free-bracket27-source-model-20261026';SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Check every input hash against immutable committed evidence; reconstruct all ten selected domain equalities from the current source partial-membership file. Independently verify all60 nonbinding hint values against current query bounds, source halfplanes and selected indices. Remove only the ten equalities and require whole-proto equality including every hint. Verify complete source choices for all three brackets and no appended constraint mentions any bracket variable. Real solver import/export must match. No solver call.'})
manifest=load(ROOT/'benchmarks/results/h5-thirteen-part-selection-and-sheet-exclusion-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
for path in [PARENT/'plan.json',PARENT/'audit/plan.json',SOURCE/'audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed'];model=proto(BASE/'model.pb');parent=proto(PARENT/'model.pb');assert len(model.variables)==270671 and len(model.constraints)==351286 and len(model.solution_hint.vars)==60
mapping=load(BASE/'mapping.json');spec=load(SOURCE/'plan.json');members=load(SOURCE/'audit/verified-partial-domain-membership.json');assert mapping==load(PARENT/'mapping.json') and (BASE/'necessary-rules.json').read_bytes()==(PARENT/'necessary-rules.json').read_bytes();records=[];values=[];hints=[]
for i,h in enumerate(members):
    p=next(p for p in mapping['parts'] if p['item']==h['item']);assert p['part']==i+3 and p['item']==spec['parts'][i+3]['index'];m=next(m for m in p['modes'] if m['query']==h['query']);row=min(d['row'] for d in h['matching_domains']);d=load(SOURCE/'queries'/f"{h['query']:03d}.json")['domains'][row];assert any(z['row']==row and z['domain_index']==d['index'] for z in h['matching_domains']);x,y=h['anchor_units1000'];q=spec['queries'][h['query']]
    for b in [d['coordinate_bounds'],q['anchor_bounds_units1000']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
    for plane in d['halfplanes']:assert plane['a']*x+plane['b']*y<=plane['bound']
    flag=m['domains'][row];ci=351276+i;c=cp_model_pb2.ConstraintProto();c.linear.vars.append(flag);c.linear.coeffs.append(1);c.linear.domain.extend([1,1]);assert model.constraints[ci]==c;records.append({'part':p['part'],'item':p['item'],'query':h['query'],'domain_row':row,'domain_index':d['index'],'flag':flag,'constraint':ci})
    v=[[p['sheet'],q['sheet']],[p['choice'],m['choice_offset']+row],[m['active'],1],[flag,1],[p['x'],x],[p['y'],y]];values+=v;hints.append({'item':p['item'],'part':p['part'],'query':h['query'],'domain_row':row,'values':v})
assert len(records)==10 and records==load(BASE/'selected-domains.json') and hints==load(BASE/'advisory-hints.json') and hints==load(PARENT/'advisory-hints.json');assert [v for v,n in values]==list(model.solution_hint.vars) and [n for v,n in values]==list(model.solution_hint.values)
for v,n in values:assert any(lo<=n<=hi for lo,hi in zip(model.variables[v].domain[::2],model.variables[v].domain[1::2]))
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(model);del restored.constraints[351276:];assert restored==parent;free=[]
for pi in [0,1,2]:
    p=mapping['parts'][pi];assert p['family']=='bracket' and [m['query'] for m in p['modes']]==spec['parts'][pi]['queries'];assert not any(p['variable_span'][0]<=r['flag']<p['variable_span'][1] for r in records);free.append({'part':pi,'item':p['item'],'source_queries':len(p['modes']),'source_domains':sum(len(m['domains']) for m in p['modes'])})
actual=cp_model.CpModel();assert actual.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and actual.validate()=='' and actual.export_to_file(str(OUT/'solver-import-roundtrip.pb'));assert proto(OUT/'solver-import-roundtrip.pb')==model;write(OUT/'free-brackets.json',free)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':270671,'constraints':351286,'hints':60,'complete_parent_restored_exactly':True,'selected_non_bracket_equalities_verified':10,'all_three_brackets_keep_all_source_options':True,'all60_nonbinding_hints_verified':True,'all26_original_coordinates_free':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':13,'fixed_originals':53,'full_source_pair_modes':954,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
