"""Free all three brackets while retaining ten verified partial-domain memberships."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-free-bracket27-source-model-20261026';SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';OUT=ROOT/'output/h5-three-free-brackets-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed']
paths=[PARENT/n for n in ['plan.json','model.pb','mapping.json','necessary-rules.json','advisory-hints.json','audit/checks.json','audit/plan.json']]+[SOURCE/n for n in ['plan.json','audit/checks.json','audit/plan.json','audit/verified-partial-domain-membership.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Retain the entire audited270671-variable/351276-constraint53-fixed full-source model, all954 pair modes, both original area rules and60 advisory hints. Append exactly ten domain-selector equalities from current verified partial-anchor memberships. All three brackets27/28/29 retain every current query/domain/quarter-turn/mirror choice. All26 coordinates remain free within their domains; no partial anchor is locked. Insert50 uses query16 row181, unlike the two prior failed master selections. This distinct conditional source subproblem is independently audited before one bounded call. All previous calls stay closed; no claim that old/new inward domain sets nest or that a scoped negative excludes unrestricted packing.'})
model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());mapping=load(PARENT/'mapping.json');members=load(SOURCE/'audit/verified-partial-domain-membership.json');records=[]
for h in members:
    p=next(p for p in mapping['parts'] if p['item']==h['item']);assert p['part']>=3;m=next(m for m in p['modes'] if m['query']==h['query']);d=min(h['matching_domains'],key=lambda d:d['row']);flag=m['domains'][d['row']];index=len(model.constraints);c=model.constraints.add();c.linear.vars.append(flag);c.linear.coeffs.append(1);c.linear.domain.extend([1,1]);records.append({'part':p['part'],'item':p['item'],'query':h['query'],'domain_row':d['row'],'domain_index':d['domain_index'],'flag':flag,'constraint':index})
assert [p['part'] for p in records]==list(range(3,13));assert records[0]['domain_row']==181
for n in ['mapping.json','necessary-rules.json','advisory-hints.json']:shutil.copyfile(PARENT/n,OUT/n)
write(OUT/'selected-domains.json',records);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'selected_non_bracket_domains':10,'free_bracket_parts':[0,1,2],'coordinate_values_fixed':0,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
