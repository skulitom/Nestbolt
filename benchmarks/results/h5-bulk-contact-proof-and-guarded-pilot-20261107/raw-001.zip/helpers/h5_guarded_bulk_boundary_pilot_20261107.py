"""Validation-only bulk correspondence pilot; shared/ambiguous groups fall back."""
import numpy as np
import shapely
from h5_cross_pair_boundary_gradient_20261107 import integrate_groups
from h5_screened_boundary_gradient_20261107 import boundary_gradients as fallback
from h5_original_overlap_gradient_v2_20261107 import line_parts

def boundary_gradients(vertices,lines,others,pivots,statistics=None):
    count=len(vertices);assert count==len(lines)==len(others)==len(pivots)
    if not count:return np.zeros((0,3)),np.zeros(0,dtype=np.int64),np.zeros(0)
    cache={};bounds=[];rows=[]
    for v,ll in zip(vertices,lines):
        key=id(v)
        if key not in cache:
            array=np.asarray(v,dtype=float).reshape((-1,2));edge=np.roll(array,-1,axis=0)-array
            cache[key]=(array,edge,np.sum(edge*edge,axis=1),shapely.multilinestrings(ll))
        rows.append(cache[key]);bounds.append(cache[key][3])
    other=np.asarray(others,dtype=object);boundaries=np.asarray(bounds,dtype=object)
    clipped=shapely.intersection(boundaries,other);common=shapely.intersection(boundaries,shapely.boundary(other));shared_lengths=shapely.length(common)
    fallback_indices=[];fast_rows=[];reasons={'shared':0,'ambiguous':0};fast=0
    for group,(v,edge,den,_) in enumerate(rows):
        if shared_lengths[group]>0:
            fallback_indices.append(group);reasons['shared']+=1;continue
        mapped=[];ambiguous=False
        for segment in line_parts(clipped[group]):
            coords=np.asarray(segment.coords,dtype=float)
            if len(coords)!=2 or segment.length<=0 or not len(v):ambiguous=True;break
            offset=coords[:,None,:]-v[None,:,:];t=np.sum(offset*edge[None,:,:],axis=2)/np.where(den>0,den,1.)[None,:]
            projected=v[None,:,:]+t[:,:,None]*edge[None,:,:];residual=np.max(np.sum((coords[:,None,:]-projected)**2,axis=2),axis=0)
            tolerance=1e-7;parameter_tolerance=tolerance/np.sqrt(np.where(den>0,den,1.))
            candidates=np.flatnonzero((den>0)&(residual<=tolerance*tolerance)&(np.min(t,axis=0)>=-parameter_tolerance)&(np.max(t,axis=0)<=1+parameter_tolerance))
            if len(candidates)!=1:ambiguous=True;break
            index=int(candidates[0]);mapped.append((group,index,float(np.min(t[:,index])),v[index],edge[index],pivots[group],segment))
        if ambiguous:fallback_indices.append(group);reasons['ambiguous']+=1
        else:fast+=1;fast_rows.extend(mapped)
    fast_rows.sort(key=lambda r:r[:3]);gradient=np.zeros((count,3));counts=np.zeros(count,dtype=np.int64);lengths=np.zeros(count)
    if fast_rows:
        starts=np.asarray([r[3] for r in fast_rows]);edges=np.asarray([r[4] for r in fast_rows]);edge_pivots=np.asarray([r[5] for r in fast_rows]);groups=np.asarray([r[0] for r in fast_rows]);geometries=np.asarray([r[6] for r in fast_rows],dtype=object)
        gradient,counts=integrate_groups(starts,edges,edge_pivots,groups,geometries,count)
    if fallback_indices:
        g,n,l=fallback(*[[values[i] for i in fallback_indices] for values in [vertices,lines,others,pivots]])
        gradient[fallback_indices]=g;counts[fallback_indices]=n;lengths[fallback_indices]=l
    if statistics is not None:statistics.update(directed_pairs=count,unique_owner_arrays=len(cache),fast_pairs=fast,fallback_pairs=len(fallback_indices),shared_fallback_pairs=reasons['shared'],ambiguous_fallback_pairs=reasons['ambiguous'],mapped_segments=len(fast_rows),mapping_tolerance_mm=1e-7)
    return gradient,counts,lengths
