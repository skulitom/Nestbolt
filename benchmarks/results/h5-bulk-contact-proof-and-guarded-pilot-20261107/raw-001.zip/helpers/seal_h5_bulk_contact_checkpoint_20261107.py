"""Preserve the exact contact proofs and the rejected complete-kernel pilot."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-bulk-contact-proof-and-guarded-pilot-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-bulk-contact-diagnostic-20261107';F=BASE/'audit';D=BASE/'guarded-pilot'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-screened-source-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['independent_exact_strip_proofs']==2 and front['one_ulp_controls']==6 and not front['unconditional_bulk_substitution_accepted'] and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/f'h5-bulk-contact-{stage}-process-20261107' for stage in ['diagnostic','audit','pilot']]+[ROOT/'output/h5-screened-objective-main-sync-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*bulk*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_bulk_contact_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
Z=ROOT/'output/h5-screened-source-preflight-20261107';runtime=load(Z/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'checks.json','contact-diagnostic.json'),(BASE/'rational-fixture-controls.json','rational-fixture-controls.json'),(BASE/'augmented-raw-and-rational.json','augmented-raw-and-rational.json'),(BASE/'original-raw-and-rational.json','original-raw-and-rational.json'),(F/'checks.json','independent-contact-proof.json'),(F/'exact-strip-proofs.json','exact-strip-proofs.json'),(F/'one-ulp-controls.json','one-ulp-controls.json'),(D/'checks.json','guarded-pilot.json'),(D/'controls.json','guarded-pilot-controls.json'),(D/'timings.json','guarded-pilot-timings.json'),(D/'observed-differences.json','guarded-pilot-differences.json'),(D/'plan.json','guarded-pilot-plan.json'),(PARENT/'closed-problems.json','closed-problems.json'),(ROOT/'output/h5-screened-objective-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['diagnostic','audit','pilot']:copies.append((ROOT/'output'/f'h5-bulk-contact-{stage}-process-20261107/process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
pilot=load(D/'checks.json');controls=load(D/'controls.json');timings=load(D/'timings.json')
assert pilot['pilot_complete'] and len(controls)==pilot['contexts']==20
assert all(r['gradient_exact'] and r['counts_exact'] and r['shared_lengths_exact'] and r['gradient_max_error']==0 for r in controls)
assert load(D/'observed-differences.json')==[]
assert len(timings)==24
totals={kind:[sum(r['complete_kernel_seconds'] for r in timings if r['kind']==kind and r['sequence']==sequence) for sequence in ([0,3] if kind=='old' else [1,2])] for kind in ['old','pilot']}
assert totals==pilot['aggregate_complete_kernel_seconds']
old_mean=sum(totals['old'])/2;pilot_mean=sum(totals['pilot'])/2;ratio=pilot_mean/old_mean
assert ratio>1 and sum(r['directed_pairs'] for r in controls[:6])==566 and sum(r['fallback_pairs'] for r in controls[:6])==62
processes={stage:load(OUT/(stage+'-process.json')) for stage in ['diagnostic','audit','pilot']}
for r in processes.values():assert r['closed'] and r['passed'] and r['exit_code']==0 and r['job']['closed'] and r['job']['active_processes']==0 and r['job']['peak_job_committed_memory']<2**31
closed=load(OUT/'closed-problems.json');assert len(closed)==len({r['key'] for r in closed})==25
decision={'passed':True,'meaning':'The readback and contact proof pass; the replacement kernel is rejected on measured cost. Narrow fixture agreement is not global equivalence.',
    'contexts_reconciled':20,'timed_geometry_contexts':6,'timing_rows_reconciled':24,'directed_pairs':566,'fast_pairs':504,'fallback_pairs':62,
    'exact_gradient_contexts':20,'maximum_gradient_difference':0.,'count_or_shared_length_mismatches':0,
    'old_complete_kernel_mean_seconds':old_mean,'pilot_complete_kernel_mean_seconds':pilot_mean,'pilot_to_old_ratio':ratio,
    'unconditional_bulk_substitution_accepted':False,'guarded_pilot_selected_for_replacement':False,'current_kernel_preserved':True,
    'reason':'The guarded pilot matches these 20 contexts but is slower in both complete-kernel samples, including construction, mapping, fallback and integration.',
    'full_objective_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'old_calls_resumed':False,'closed_problem_keys':25,
    'source_only_preparation_seconds_before_new_work':40.43863689946011,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False}
write(OUT/'pilot-decision.json',decision)
ci=json.loads(subprocess.check_output(['gh','run','view','42396069909','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='b4e16c74f77be961d6226e482e5116f8b1d7714f'
write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'next-step.json',{'status':'retain_screened_per_edge_kernel_and_review_construction_costs',
    'finding':'Exact rational clipping and an independent strip proof resolve the four prior filled/shared discrepancies: whole-boundary overlay invents a positive shared segment at each of two near-parallel contacts. A guarded prototype agrees on the finite fixture set but its complete measured kernel is slower; it is not selected for further objective integration.',
    'proposal':'Use the verified screened per-edge objective for the next feasibility investigation. Before spending further effort on clipping variants, reconcile the complete existing source-preparation/startup/selection/evaluation cost ledger and identify a concrete change with room inside the unchanged limits. A cost audit may read closed records but cannot run or reopen them. If no justified change follows, return to original-source geometric construction rather than launch another timed optimizer call.',
    'requirements':['All 25 mathematical objective/physical-mode/weight keys and previous finite pipelines remain closed. Code changes, timing samples and validation coordinates do not reopen a problem.','Do not round, translate or otherwise modify saved candidate coordinates to erase a geometry discrepancy. Exact source-edge membership alone is not a sufficient bulk correspondence test.','Preserve original/clearance geometry, 528 weighted areas, 15 auxiliary terms, 33 movers/15 angles, strict improvement and all three winner streams.','Any successor must use verified original unoptimized A/W input and charge the retained 40.43863689946011 s preparation plus every new cost. Full objective/source/budget evidence is needed before a finite search contract.','The original full66 validity, native/material checks, production parity and H5 matrix remain required. H2 retains the original denominator and unopened reserved vectors.'],
    'new_source_state_prepared':False,'new_search_contract_prepared':False,'optimizer_calls':0,'closed_problem_keys':25,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),'independent_contact_proofs':2,'one_ulp_controls':6,'pilot_contexts':20,'pilot_rejected_on_complete_cost':True,'optimizer_calls':0,'H5_complete':False})
report=f'''# Exact contact proof and guarded bulk pilot — 2026-11-07

The current per-edge clipping method agrees with two independent exact-coordinate
calculations. The whole-boundary shortcut introduces false shared segments in the
two saved near-touching cases. A guarded prototype matches all **20 tested
contexts**, but its complete kernel takes **{ratio:.3f} times** the current kernel
in the fixed observations. It is rejected as a replacement. No new layout or
optimizer call follows; H2/H5 remain open at **60% completed milestone weight**.

[The contact diagnosis]({NAME}/contact-diagnostic.json) retains both original
binary64 polygons, edge masks, full-precision WKT/WKB and exact rational segment
intervals: [augmented winner]({NAME}/augmented-raw-and-rational.json),
[original-area winner]({NAME}/original-raw-and-rational.json). All
[eight analytic fixtures]({NAME}/rational-fixture-controls.json) pass. Each case
has one real filled interval and zero shared length. The strict box filter is not
the cause: its omitted edge is disjoint, while the problematic edge is retained.

[Independent strip proofs]({NAME}/exact-strip-proofs.json) reduce each eight-edge
polygon over the owner's full x-range to its left, lower and sloping top edges.
They directly solve the sole filled interval and integrate it using squared
endpoint distances. The top drops exactly **1/2199023255552 mm** across 300 mm:
one binary64 y ULP. The disputed horizontal segment is outside except at the
common endpoint. [The proof audit]({NAME}/independent-contact-proof.json) agrees
with the current gradients to **2.593e-11**. The false shared segments measure
**60.774488 / 63.522505 mm**; applying them would add erroneous y-gradient terms
of **30.387244 / 31.761253**, despite the tiny coordinate gap.

[Six fixed ULP controls]({NAME}/one-ulp-controls.json) retain the failure at zero
shift and agreement at minus/plus one ULP. They are validation fixtures, not new
candidate states. Exact source-edge membership alone is insufficient: a valid
vertical intersection is slightly rounded while the false horizontal segment
lies exactly on an owner edge. Neither set-distance equality nor simple edge
membership establishes the intended integral.

[The guarded pilot contract]({NAME}/guarded-pilot-plan.json) falls back to the
unchanged screened per-edge kernel whenever a pair has positive bulk shared
length or ambiguous/nontrivial component mapping. Other components map to a
unique original edge within the declared 1e-7 mm correspondence tolerance, then
use original edges, pivots and integration order. This is a validation prototype;
these controls do not prove correctness for all geometries.

[All pilot controls]({NAME}/guarded-pilot-controls.json) cover the same three
saved states at both geometry levels, six ULP cases and eight synthetic cases.
There are 566 directed pairs in the six saved-state contexts: 504 take the bulk
path and 62 fall back because of shared length. All 20 gradients, clipped counts
and shared lengths match exactly; [recorded differences]({NAME}/guarded-pilot-differences.json)
are empty. [The rollup]({NAME}/guarded-pilot.json) remains explicit.

[Complete-kernel timings]({NAME}/guarded-pilot-timings.json) use the fixed
old/pilot/pilot/old order and include boundary construction, clipping, component
mapping, fallback and integration. Aggregate observations are
**{totals['old']} s** for the current kernel and **{totals['pilot']} s** for the
pilot; means are **{old_mean:.6f} / {pilot_mean:.6f} s**. The earlier clipping-only
speedup does not survive complete integration. [The decision]({NAME}/pilot-decision.json)
rejects this implementation on measured cost without claiming stable performance
statistics or global equivalence. No complete replacement objective is prepared.

The diagnostic, independent proof and pilot processes close in
**{processes['diagnostic']['complete_seconds']:.6f} / {processes['audit']['complete_seconds']:.6f} /
{processes['pilot']['complete_seconds']:.6f} s**, respectively, under CCD1/one-thread
and 2 GiB controls: [diagnostic]({NAME}/diagnostic-process.json),
[proof]({NAME}/audit-process.json), [pilot]({NAME}/pilot-process.json).
Peak committed memory is {max(r['job']['peak_job_committed_memory'] for r in processes.values()):,} bytes;
all descendants close. These are read-only diagnostics, not timed packing runs.

[Next]({NAME}/next-step.json), retain the screened per-edge objective and review
the complete construction cost ledger before another implementation choice.
[All 25 problem keys]({NAME}/closed-problems.json) remain closed. The latest source
attempt still has 53 failed pairs in its original-area winner and 52 in its other
winner. Four fixed arrangements and all 440 allocations remain unresolved;
retained source preparation is **40.43863689946011 s** before any new work.

Main b4e16c74 has {success} passed / {live} live jobs in the
[CI snapshot]({NAME}/main-ci-at-review.json). The prior
[ordinary push receipt]({NAME}/prior-main-push-receipt.json) preserves the six-job
gate and 52 remote files. This checkpoint changes evidence and status only.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical evidence]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the consumed evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 exact contact proof and guarded bulk pilot:** [independent rational/strip proofs and complete-kernel controls]({{link}}) confirm zero true shared length in both near-parallel cases. The unguarded bulk operation invents 60.774488/63.522505 mm shared segments; its replacement remains rejected. Eight analytic fixtures and six fixed ULP controls are preserved. The guarded pilot matches all 20 contexts exactly, including 566 saved-state directed pairs with 62 fallbacks, but complete-kernel means are {old_mean:.6f}/{pilot_mean:.6f} s current/pilot ({ratio:.3f} times the current cost), so it is not integrated. No source initializer or optimizer call is created. All 25 keys stay closed; retained source preparation is 40.438637 s. The latest winners still fail 53/52 pairs. Four arrangements and 440 allocations remain; H2/H5 stay open at 60%. Main b4e16c74 has {success} passed/{live} live CI jobs at review.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [exact contact proof and guarded bulk pilot](../benchmarks/results/{NAME}.md).
Two independent exact-coordinate calculations confirm the current per-edge
kernel at the near-parallel contacts. Whole-boundary clipping invents shared
segments of 60.77/63.52 mm. The guarded pilot matches all 20 tested contexts,
but its complete kernel takes {ratio:.3f} times as long in the fixed observations,
so it is rejected as a replacement. No new objective, initializer or optimizer
call follows. Next review complete construction costs using the current kernel.
All 25 exact problem keys remain closed; retained preparation is 40.438637 s.
The latest original-area winner still fails 53 source pairs and the distinct
augmented/unweighted winner fails 52. Four arrangements and 440 allocations
remain unresolved. H2/H5 stay open at 60%. Main b4e16c74 has {success} passed /
{live} live CI jobs at review. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings),'pilot_to_old_ratio':ratio})
