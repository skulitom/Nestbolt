"""Finite pilot only: full kernel results/costs and retained uncertain output."""
from pathlib import Path
from hashlib import sha256
import json,time,os,math
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_screened_augmented_objective_20261107 import Objective
from h5_screened_boundary_gradient_20261107 import boundary_gradients as old
from h5_guarded_bulk_boundary_pilot_20261107 import boundary_gradients as candidate
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bulk-contact-diagnostic-20261107';OUT=BASE/'guarded-pilot';Z=ROOT/'output/h5-screened-source-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';E=Z/'search/epoch-01'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert load(BASE/'audit/checks.json')['passed'] and affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
paths=[Path(__file__),ROOT/'output/h5_guarded_bulk_boundary_pilot_20261107.py',ROOT/'output/h5_screened_boundary_gradient_20261107.py',BASE/'audit/checks.json',BASE/'audit/plan.json',BASE/'audit/one-ulp-controls.json',BASE/'augmented-raw-and-rational.json',BASE/'original-raw-and-rational.json',Z/'selected-model.json',Z/'selected-state.json',Z/'response-audit/checks.json',E/'model.json',E/'response.json',A/'objective-identity.json',B/'regions.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Validation-only guarded whole-boundary pilot. Any positive bulk shared length or ambiguous/nontrivial source-edge component mapping falls back to the unchanged screened per-edge kernel. Unique source-edge mapping uses the predeclared1e-7mm geometric correspondence tolerance and reuses original edge projection/integration, sorting by directed pair/edge/parameter. Test every active directed pair in the same three saved states and both levels, plus all six one-ULP contact cases and the eight analytic boundary fixtures. Compare full gradients/counts/shared lengths, retaining differences rather than declaring automatic acceptance. Fixed old/pilot/pilot/old whole-kernel timings include boundary construction, clipping, mapping, fallback and integration. No full objective, source initializer or optimizer.','mapping_tolerance_mm':1e-7,'gradient_observation_tolerance_mm':1e-6,'cap_seconds':120,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
identity=load(A/'objective-identity.json');regions=load(B/'regions.json');model=load(E/'model.json');response=load(E/'response.json');states=[('source_initializer',load(Z/'selected-model.json'),load(Z/'selected-state.json')['values'])]
seen=set()
for label,r in response['winners'].items():
    point=tuple(r['values'])
    if point not in seen:states.append((label,model,r['values']));seen.add(point)
timings=[];controls=[];observations=[]
def compare(label,args,record_timing=False):
    before=old(*args);stats={};after=candidate(*args,stats);error=float(np.max(np.abs(before[0]-after[0]))) if before[0].size else 0.
    row={'context':label,**stats,'gradient_exact':bool(np.array_equal(before[0],after[0])),'gradient_max_error':error,'counts_exact':bool(np.array_equal(before[1],after[1])),'shared_lengths_exact':bool(np.array_equal(before[2],after[2])),'within_existing_gradient_tolerance':error<1e-6}
    controls.append(row)
    if record_timing:
        outputs=[]
        for sequence,kind in enumerate(['old','pilot','pilot','old']):
            began=time.perf_counter();got=(old if kind=='old' else candidate)(*args);elapsed=time.perf_counter()-began
            outputs.append(got);timings.append({'context':label,'sequence':sequence,'kind':kind,'complete_kernel_seconds':elapsed})
        assert all(np.array_equal(a,b) for a,b in zip(outputs[0],outputs[3])) and all(np.array_equal(a,b) for a,b in zip(outputs[1],outputs[2]))
    if not row['within_existing_gradient_tolerance'] or not row['counts_exact'] or not row['shared_lengths_exact']:
        observations.append({'context':label,'old_gradient':before[0].tolist(),'pilot_gradient':after[0].tolist(),'old_counts':before[1].tolist(),'pilot_counts':after[1].tolist(),'old_shared':before[2].tolist(),'pilot_shared':after[2].tolist()})
for label,m,point in states:
    obj=Objective(m,regions,identity)
    for level,entries in enumerate(obj.geometry(point)):
        polys=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(polys[obj.left],polys[obj.right]));args=[[],[],[],[]]
        for index in np.flatnonzero(areas>0):
            i,j=m['pairs'][index]
            for own,other in [(i,j),(j,i)]:
                v,_,lines,pivot=entries[own]
                for dest,value in zip(args,[v,lines,entries[other][1],pivot]):dest.append(value)
        compare(f'{label}-level-{level}',args,True)
for label in ['augmented','original']:
    raw=load(BASE/(label+'-raw-and-rational.json'));v=np.asarray(raw['owner_vertices']);other=Polygon(raw['other_vertices']);ulp=math.ulp(float(v[0,1]))
    for offset in [-1,0,1]:
        shifted=v.copy();shifted[:,1]+=offset*ulp;lines=shapely.linestrings(np.stack((shifted,np.roll(shifted,-1,axis=0)),axis=1));compare(f'{label}-ulp-{offset}',([shifted],[lines],[other],[[raw['pivot'][0],raw['pivot'][1]+offset*ulp]]))
def args_for(vertices,other):
    v=np.asarray(vertices,dtype=float).reshape((-1,2));ll=shapely.linestrings(np.stack((v,np.roll(v,-1,axis=0)),axis=1)) if len(v) else np.empty(0,dtype=object)
    return [v],[ll],[other],[[0.,0.]]
square=[[0.,0.],[2.,0.],[2.,2.],[0.,2.]]
synthetic=[('no_pairs',([],[],[],[])),('no_edges',args_for([],Polygon(square))),('identical',args_for(square,Polygon(square))),('contained',args_for(square,Polygon([[-1,-1],[3,-1],[3,3],[-1,3]]))),('disjoint',args_for(square,Polygon([[3,0],[5,0],[5,2],[3,2]]))),('corner_touch',args_for(square,Polygon([[2,2],[4,2],[4,4],[2,4]]))),('shared_edge',args_for(square,Polygon([[2,0],[4,0],[4,2],[2,2]]))),('zero_length_edge',args_for([[0,0]]+square,Polygon(square)))]
for label,args in synthetic:compare(label,args)
write(OUT/'controls.json',controls);write(OUT/'observed-differences.json',observations);write(OUT/'timings.json',timings)
totals={kind:[sum(r['complete_kernel_seconds'] for r in timings if r['kind']==kind and r['sequence']==sequence) for sequence in ([0,3] if kind=='old' else [1,2])] for kind in ['old','pilot']}
write(OUT/'checks.json',{'pilot_complete':True,'seconds':time.perf_counter()-start,'contexts':len(controls),'timed_contexts':6,'directed_pairs_in_geometry_contexts':sum(r['directed_pairs'] for r in controls[:6]),'fast_pairs_in_geometry_contexts':sum(r['fast_pairs'] for r in controls[:6]),'fallback_pairs_in_geometry_contexts':sum(r['fallback_pairs'] for r in controls[:6]),'shared_fallback_pairs_in_geometry_contexts':sum(r['shared_fallback_pairs'] for r in controls[:6]),'ambiguous_fallback_pairs_in_geometry_contexts':sum(r['ambiguous_fallback_pairs'] for r in controls[:6]),'max_gradient_difference':max(r['gradient_max_error'] for r in controls),'contexts_with_exact_gradients':sum(r['gradient_exact'] for r in controls),'contexts_with_count_mismatch':sum(not r['counts_exact'] for r in controls),'contexts_with_shared_length_mismatch':sum(not r['shared_lengths_exact'] for r in controls),'out_of_tolerance_contexts':len(observations),'aggregate_complete_kernel_seconds':totals,'full_objective_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
