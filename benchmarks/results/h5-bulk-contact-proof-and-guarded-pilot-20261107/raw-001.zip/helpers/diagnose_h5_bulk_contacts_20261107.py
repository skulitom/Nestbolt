"""Exact binary-coordinate segment clipping for the four retained bulk discrepancies."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,math,os
import numpy as np
import shapely
from h5_screened_augmented_objective_20261107 import Objective
from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients as dense
from h5_screened_boundary_gradient_20261107 import boundary_gradients as screened
from h5_original_overlap_gradient_v2_20261107 import line_parts
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-bulk-contact-diagnostic-20261107';Z=ROOT/'output/h5-screened-source-preflight-20261107';E=Z/'search/epoch-01';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-screened-source-construction-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def point(v):return tuple(F(float(x)) for x in v)
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def location(p,vertices):
    inside=False
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        d=sub(b,a);r=sub(p,a)
        if cross(d,r)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1]):return 'boundary'
        if (a[1]>p[1])!=(b[1]>p[1]):
            x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if x>p[0]:inside=not inside
    return 'inside' if inside else 'outside'
def merge(rows):
    out=[]
    for lo,hi in rows:
        if out and out[-1][1]==lo:out[-1]=(out[-1][0],hi)
        else:out.append((lo,hi))
    return out
def clip(p,q,vertices):
    d=sub(q,p);den=dot(d,d)
    if not den:return [],[],[]
    breaks={F(0),F(1)};relations=[]
    for index,(a,b) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
        edge=sub(b,a);r=sub(a,p);det=cross(d,edge);collinear=det==0 and cross(r,d)==0
        relation={'other_edge':index,'direction_cross':str(det),'start_line_cross':str(cross(d,r)),'end_line_cross':str(cross(d,sub(b,p))),'exact_collinear':collinear}
        if det:
            t=cross(r,edge)/det;s=cross(r,d)/det
            if 0<=t<=1 and 0<=s<=1:breaks.add(t)
        elif collinear:
            for z in [a,b]:
                t=dot(sub(z,p),d)/den
                if 0<=t<=1:breaks.add(t)
        relations.append(relation)
    filled=[];shared=[];ordered=sorted(breaks)
    for lo,hi in zip(ordered,ordered[1:]):
        middle=tuple(p[k]+((lo+hi)/2)*d[k] for k in [0,1]);where=location(middle,vertices)
        if where!='outside':filled.append((lo,hi))
        if where=='boundary':shared.append((lo,hi))
    return merge(filled),merge(shared),relations
def integrate(p,q,pivot,intervals):
    d=sub(q,p);out=[F(0),F(0),F(0)]
    for lo,hi in intervals:
        delta=tuple((hi-lo)*v for v in d);middle=tuple(p[k]+((lo+hi)/2)*d[k]-pivot[k] for k in [0,1])
        out[0]+=delta[1];out[1]-=delta[0];out[2]-=dot(middle,delta)
    return out
def geo(g):return {'type':g.geom_type,'wkt':shapely.to_wkt(g,rounding_precision=-1,trim=True),'wkb_hex':g.wkb_hex,'length_mm':float(g.length),'line_parts':[list(map(list,line.coords)) for line in line_parts(g)]}

OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(P/'archive-checks.json')['passed'] and load(Z/'response-audit/checks.json')['passed']
paths=[Path(__file__),P/'bulk-clipping-controls.json',P/'bulk-clipping-discrepancies.json',P/'next-step.json',P/'archive-checks.json',Z/'response-audit/checks.json',A/'objective-identity.json',B/'regions.json']+[E/n for n in ['model.json','response.json']]+[ROOT/'output'/n for n in ['h5_screened_augmented_objective_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_cross_pair_boundary_gradient_20261107.py','h5_original_overlap_gradient_v2_20261107.py']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Rebuild the exact two saved clearance owner11/owner5 cases and retain every binary64 vertex, source edge, strict-box mask and raw WKT/WKB filled/shared result, both unfiltered and screened per edge and whole MultiLineString. Independently clip source segments against the other polygon using exact Fraction arithmetic on binary64 coordinates: rational crossings, exact midpoint parity/boundary classification, connected intervals and rigid translation/rotation integrals. Record all line relations and compare component membership without relying on floating set-distance. Eight analytic synthetic controls precede the two cases. Diagnose only, no boundary/objective/search replacement.','states':['augmented','original'],'level':1,'owner':11,'other':5,'cap_seconds':120,'memory_bytes':2**31,'gradient_observation_tolerance_mm':1e-6,'optimizer_calls':0,'retry_permitted':False})
square=[(F(0),F(0)),(F(2),F(0)),(F(2),F(2)),(F(0),F(2))];quarter=[(F(1,4),F(3,4))];unit=[(F(0),F(1))];delta=F(1,2**40)
fixtures=[('horizontal_cross',(-1,1),(3,1),quarter,[]),('vertical_cross',(1,-1),(1,3),quarter,[]),('coincident_edge',(-1,0),(3,0),quarter,quarter),('inside',(F(1,2),F(1,2)),(F(3,2),F(3,2)),unit,[]),('corner_point',(0,0),(-1,-1),[],[]),('parallel_outside',(0,2+delta),(2,2+delta),[],[]),('parallel_inside',(0,2-delta),(2,2-delta),unit,[]),('zero_edge',(1,1),(1,1),[],[])]
fixture_controls=[]
for name,p,q,expected_full,expected_shared in fixtures:
    a=tuple(F(v) for v in p);b=tuple(F(v) for v in q);full,shared,_=clip(a,b,square);assert full==expected_full and shared==expected_shared
    fixture_controls.append({'case':name,'passed':True,'filled':[[str(v) for v in row] for row in full],'shared':[[str(v) for v in row] for row in shared]})
write(OUT/'rational-fixture-controls.json',fixture_controls)
model=load(E/'model.json');response=load(E/'response.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));summaries=[]
for label in ['augmented','original']:
    values=response['winners'][label]['values'];entries=obj.geometry(values)[1];v,a,lines,pivot=entries[11];ov,b,_,_=entries[5];vp=[point(z) for z in v];other=[point(z) for z in ov];rp=point(pivot)
    assert sum(cross(p,q) for p,q in zip(vp,vp[1:]+vp[:1]))>0
    left=shapely.bounds(lines);right=np.asarray(b.bounds);mask=~((left[:,0]>right[2])|(left[:,2]<right[0])|(left[:,1]>right[3])|(left[:,3]<right[1]))
    filled=shapely.intersection(lines,b);shared=shapely.intersection(lines,b.boundary);whole=shapely.multilinestrings(lines);bulk_filled=whole.intersection(b);bulk_shared=whole.intersection(b.boundary)
    dense_result=dense([v],[lines],[b],[pivot]);screened_result=screened([v],[lines],[b],[pivot]);assert all(np.array_equal(x,y) for x,y in zip(dense_result,screened_result))
    exact_g=[F(0),F(0),F(0)];filled_length=shared_length=0.;filled_count=shared_count=0;edge_rows=[]
    for index,(p,q) in enumerate(zip(vp,vp[1:]+vp[:1])):
        full,common,relations=clip(p,q,other);g1=integrate(p,q,rp,full);g2=integrate(p,q,rp,common)
        for k in range(3):exact_g[k]+=g1[k]-g2[k]/2
        norm=math.hypot(*map(float,sub(q,p)));fl=float(sum((hi-lo for lo,hi in full),F(0)))*norm;sl=float(sum((hi-lo for lo,hi in common),F(0)))*norm
        filled_length+=fl;shared_length+=sl;filled_count+=len(full);shared_count+=len(common)
        edge_rows.append({'edge':index,'start':list(map(float,p)),'end':list(map(float,q)),'exact_start':list(map(str,p)),'exact_end':list(map(str,q)),'strict_bbox_retained':bool(mask[index]),'raw_filled':geo(filled[index]),'raw_shared':geo(shared[index]),'rational_filled_intervals':[[str(z) for z in r] for r in full],'rational_shared_intervals':[[str(z) for z in r] for r in common],'rational_filled_length_mm':fl,'rational_shared_length_mm':sl,'other_edge_relations':relations})
    bulk_members=[]
    for kind,shape in [('filled',bulk_filled),('shared',bulk_shared)]:
        for segment in line_parts(shape):
            coordinates=[point(c) for c in segment.coords];members=[]
            for edge,(p,q) in enumerate(zip(vp,vp[1:]+vp[:1])):
                d=sub(q,p);den=dot(d,d)
                crosses=[cross(d,sub(z,p)) for z in coordinates];ts=[dot(sub(z,p),d)/den if den else F(-1) for z in coordinates]
                if all(z==0 for z in crosses) and all(0<=t<=1 for t in ts):members.append(edge)
            bulk_members.append({'kind':kind,'geometry':geo(segment),'exact_matching_source_edges':members})
    row={'state':label,'owner':11,'other':5,'owner_vertices':v.tolist(),'other_vertices':ov.tolist(),'pivot':pivot,'source_polygon':geo(a),'other_polygon':geo(b),'source_edges':edge_rows,'bulk_filled':geo(bulk_filled),'bulk_shared':geo(bulk_shared),'bulk_component_source_membership':bulk_members,'dense_gradient':dense_result[0][0].tolist(),'screened_gradient':screened_result[0][0].tolist(),'exact_rational_gradient':list(map(str,exact_g)),'exact_rational_gradient_float':list(map(float,exact_g)),'rational_filled_components':filled_count,'rational_shared_components':shared_count,'rational_filled_length_mm':filled_length,'rational_shared_length_mm':shared_length,'per_edge_clipped_count':int(dense_result[1][0]),'per_edge_shared_length_mm':float(dense_result[2][0]),'maximum_rational_gradient_difference':max(abs(float(z)-float(g)) for z,g in zip(exact_g,dense_result[0][0]))}
    write(OUT/(label+'-raw-and-rational.json'),row)
    summaries.append({'state':label,'source_edges':len(v),'other_edges':len(ov),'bbox_omitted_edges':int(np.count_nonzero(~mask)),'rational_filled_components':filled_count,'rational_shared_components':shared_count,'per_edge_shared_length_mm':float(dense_result[2][0]),'rational_shared_length_mm':shared_length,'bulk_shared_length_mm':float(bulk_shared.length),'bulk_components_without_exact_source_edge':sum(not z['exact_matching_source_edges'] for z in bulk_members),'maximum_rational_gradient_difference':row['maximum_rational_gradient_difference'],'per_edge_clipped_count':int(dense_result[1][0])})
write(OUT/'checks.json',{'diagnostic_complete':True,'seconds':time.perf_counter()-start,'rational_fixture_cases':len(fixture_controls),'states':summaries,'unconditional_bulk_substitution_accepted':False,'full_boundary_kernel_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
