"""Independent exact strip proof and one-ULP contact controls for saved discrepancies."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,math,os
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients
from h5_original_overlap_gradient_v2_20261107 import line_parts
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bulk-contact-diagnostic-20261107';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def vec(v):return [F(float(x)) for x in v]
def norm2(v):return sum(x*x for x in v)
OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
paths=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','rational-fixture-controls.json','augmented-raw-and-rational.json','original-raw-and-rational.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Independently prove both exact binary-coordinate cases by reducing the other eight-vertex polygon to its three boundaries on the entire x-range of the four-vertex owner: left vertical edge, lower horizontal edge and sloping top edge. Prove three owner edges have no positive clipped interval; directly solve the two intersections of the fourth edge. Integrate via squared endpoint distances, independent of the diagnostic segment/ray-crossing implementation. Prove false bulk horizontal segments are outside except at their common endpoint and derive their false half-boundary gradient contribution. Preserve raw GEOS behavior under fixed minus-one/zero/plus-one ULP rigid owner-y shifts. No coordinate change applied to any saved candidate or production code.','ulp_offsets':[-1,0,1],'optimizer_calls':0,'validation_only':True,'cap_seconds':120,'memory_bytes':2**31,'retry_permitted':False})
proofs=[];perturbations=[]
for label in ['augmented','original']:
    raw=load(BASE/(label+'-raw-and-rational.json'));v=[vec(p) for p in raw['owner_vertices']];w=[vec(p) for p in raw['other_vertices']];pivot=vec(raw['pivot'])
    assert len(v)==4 and len(w)==8
    lx=w[2][0];top=w[2][1];lo=w[3][1];rx=w[1][0];rtop=w[1][1];inner=w[4][0]
    assert w[3][0]==lx and w[4][1]==lo and rx>inner>max(p[0] for p in v)>lx
    # All other boundary pieces are strictly to the right of the complete owner.
    assert all(w[k][0]>max(p[0] for p in v) for k in [0,1,4,5,6,7])
    assert all(w[k][1]<=top for k in range(8)) and lo<rtop<top
    slope=(rtop-top)/(rx-lx);assert slope<0
    assert v[0][1]==v[1][1]==top and v[1][0]<lx<v[0][0]
    assert max(v[1][0],v[2][0])<lx and v[2][1]==v[3][1]<lo
    p=v[3];q=v[0];d=[q[k]-p[k] for k in [0,1]];assert d[1]>0 and min(p[0],q[0])>lx and max(p[0],q[0])<inner
    enter=(lo-p[1])/d[1];leave=(top+slope*(p[0]-lx)-p[1])/(d[1]-slope*d[0]);assert 0<enter<leave<1
    endpoints=[[p[k]+t*d[k] for k in [0,1]] for t in [enter,leave]]
    delta=[endpoints[1][k]-endpoints[0][k] for k in [0,1]];relative=[[z[k]-pivot[k] for k in [0,1]] for z in endpoints]
    gradient=[delta[1],-delta[0],-(norm2(relative[1])-norm2(relative[0]))/2]
    assert list(map(str,gradient))==raw['exact_rational_gradient']
    assert [[str(enter),str(leave)]]==raw['source_edges'][3]['rational_filled_intervals']
    assert raw['rational_shared_components']==0 and raw['rational_shared_length_mm']==0 and raw['rational_filled_components']==raw['per_edge_clipped_count']==1
    for edge in raw['source_edges']:assert edge['rational_shared_intervals']==[]
    for k in [0,1,2]:assert raw['source_edges'][k]['rational_filled_intervals']==[]
    # The false horizontal segment lies exactly on owner edge0, but strictly above
    # the other polygon for every x in (lx, owner_right]. This is an exact proof.
    length=v[0][0]-lx;mid=(v[0][0]+lx)/2;mid_gap=-(mid-lx)*slope;right_gap=-(v[0][0]-lx)*slope
    assert length>0 and 0<mid_gap<right_gap<F(math.ulp(float(top)))
    false_half_gradient=[F(0),length/2,(mid-pivot[0])*length/2]
    shared_members=[r for r in raw['bulk_component_source_membership'] if r['kind']=='shared'];assert len(shared_members)==1 and shared_members[0]['exact_matching_source_edges']==[0]
    a,b=[vec(z) for z in shared_members[0]['geometry']['line_parts'][0]];assert a==v[0] and b==[lx,top]
    assert float(length)==raw['bulk_shared']['length_mm']
    errors=[abs(float(g)-actual) for g,actual in zip(gradient,raw['dense_gradient'])];assert max(errors)<1e-6
    proofs.append({'state':label,'exact_strip_top_slope':str(slope),'exact_top_drop_mm':str(top-rtop),'exact_owner_edge0_intersection':'single endpoint only; no positive-length filled or shared interval','false_bulk_length_mm':float(length),'exact_false_bulk_length_mm':str(length),'midpoint_gap_mm':float(mid_gap),'exact_midpoint_gap_mm':str(mid_gap),'right_endpoint_gap_mm':float(right_gap),'exact_right_endpoint_gap_mm':str(right_gap),'coordinate_ulp_mm':math.ulp(float(top)),'entry_parameter':str(enter),'exit_parameter':str(leave),'exact_gradient':list(map(str,gradient)),'maximum_per_edge_gradient_error':max(errors),'false_naive_half_boundary_gradient':list(map(float,false_half_gradient)),'source_edge_membership_alone_rejects_false_segment':False,'independent_exact_proof_passed':True})
    other=Polygon(raw['other_vertices']);values=np.asarray(raw['owner_vertices'],dtype=float);ulp=math.ulp(float(top))
    for offset in [-1,0,1]:
        shifted=values.copy();shifted[:,1]+=offset*ulp;lines=shapely.linestrings(np.stack((shifted,np.roll(shifted,-1,axis=0)),axis=1));full=shapely.intersection(lines,other);shared=shapely.intersection(lines,other.boundary);whole=shapely.multilinestrings(lines)
        bulk_filled=whole.intersection(other);bulk_shared=whole.intersection(other.boundary);g,n,common=boundary_gradients([shifted],[lines],[other],[[raw['pivot'][0],raw['pivot'][1]+offset*ulp]])
        row={'state':label,'owner_y_ulp_offset':offset,'translation_mm':offset*ulp,'separate_filled_length_mm':float(sum(z.length for z in full)),'bulk_filled_length_mm':float(bulk_filled.length),'separate_shared_length_mm':float(sum(z.length for z in shared)),'bulk_shared_length_mm':float(bulk_shared.length),'per_edge_gradient':g[0].tolist(),'per_edge_clipped_count':int(n[0]),'per_edge_shared_length_mm':float(common[0]),'shared_bulk_wkt':shapely.to_wkt(bulk_shared,rounding_precision=-1,trim=True),'topologically_equal_filled':bool(shapely.equals(shapely.union_all(full),bulk_filled)),'topologically_equal_shared':bool(shapely.equals(shapely.union_all(shared),bulk_shared))}
        if offset==0:assert row['bulk_shared_length_mm']==raw['bulk_shared']['length_mm'] and row['per_edge_gradient']==raw['dense_gradient']
        perturbations.append(row)
write(OUT/'exact-strip-proofs.json',proofs);write(OUT/'one-ulp-controls.json',perturbations)
bindings={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
bindings.update(plan['inputs']);write(OUT/'source-bindings.json',bindings)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'independent_exact_strip_proofs':len(proofs),'original_source_edges_proved':8,'other_boundary_edges_retained':16,'analytic_segment_fixture_cases':len(load(BASE/'rational-fixture-controls.json')),'one_ulp_controls':len(perturbations),'unperturbed_bulk_discrepancies_reproduced':2,'unperturbed_exact_shared_length_mm':0.,'maximum_per_edge_gradient_error':max(r['maximum_per_edge_gradient_error'] for r in proofs),'false_shared_lengths_mm':[r['false_bulk_length_mm'] for r in proofs],'false_y_gradient_contributions':[r['false_naive_half_boundary_gradient'][1] for r in proofs],'source_edge_membership_alone_sufficient':False,'unconditional_bulk_substitution_accepted':False,'full_boundary_kernel_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
