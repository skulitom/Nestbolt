"""Independent region reconstruction and interval-event area/split readback."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,time
from h5_five_column_area_tools_20261107 import sweep
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-five-column-areas-20261107';OUT=BASE/'audit';MASK=ROOT/'output/h5-five-column-covers-v2-20261107';SOURCE=ROOT/'output/h5-five-column-cog-pool-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for folder in [MASK/'mask-audit',SOURCE/'audit']:
    assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile every independently certified source/mask input and every136 source-valid48 omitted pair. Reconstruct each component-swept stock-clipped family/combined region and every mandatory fixed obstacle. A separate1Dinterval-event sweep re-evaluates all408 occupied and pre-subtraction integer areas, independent of producer2Dprefix grids. Verify family count and joint area necessary bounds using all6remainingbrackets/12inserts. Preserve survivors as merely unexcluded, and preserve both failed preparation charges. No optimizer or full-job validity follows from a necessary bound.'})
cases=load(SOURCE/'cases.json');assert [r['omitted_sites'] for r in cases]==list(map(list,combinations(range(17),2))) and all(r['source48_valid'] for r in cases);g=load(MASK/'geometries.json');sb=load(MASK/'stock-cover.json')['outward_stock_rectangle_um'];sources=load(MASK/'turned-4/source-inner-rectangles.json');covers={i:load(MASK/'turned-4'/f'geometry-{i:02d}.json')['cover'] for i in range(12)};assert {r['site_bit'] for r in sources if r['kind']=='cog'}==set(range(17)) and all(r['site_bit']==17 for r in sources if r['kind']=='frame');assert load(MASK/'mask-audit/checks.json')['conservative_body_area_error_bound_mm2']<1;results=[]
assert sweep([[0,0,5,5]],[[1,1,3,3],[1,1,3,3]])==(21,25)
for case in cases:
    data=load(BASE/(case['case']+'-capacity.json'));missing=set(case['omitted_sites']);allowed=sum(1<<i for i in missing);fixed=[r['bounds_um'] for r in sources if r['kind']=='frame' or r['site_bit'] not in missing];assert fixed==data['fixed_inner_obstacles_um'];regions={};areas={}
    for family in ['bracket','insert']:
        rr=[]
        for mode in g:
            if mode['family']!=family:continue
            for label,l,b,r,t,*_ in covers[mode['geometry']]:
                bits={i for i in range(18) if label&(1<<i)}
                if not bits<=missing:continue
                assert not(label&~allowed)
                for a,c,d,e in mode['outer_component_bounds_um']:
                    q=[max(sb[0],l+a),max(sb[1],b+c),min(sb[2],r+d),min(sb[3],t+e)]
                    if q[2]>q[0] and q[3]>q[1]:rr.append(q)
        rr=list(map(list,sorted(set(map(tuple,rr)))));assert rr==data['family_regions_um'][family];regions[family]=rr;actual,before=sweep(rr,fixed);assert actual==data['family_area_upper_um2'][family] and before==data['family_area_before_fixed_subtraction_um2'][family];areas[family]=actual
    joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));assert joint==data['combined_regions_um'];combined,before=sweep(joint,fixed);assert combined==data['combined_area_upper_um2'] and before==data['combined_area_before_fixed_subtraction_um2'];bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);excluded=bc<6 or ic<12 or combined<477582*10**6;assert bc==data['first_bracket_capacity_upper'] and ic==data['first_insert_capacity_upper'] and excluded==data['provisional_fixed48_excluded'];results.append({'case':case['case'],'omitted_sites':case['omitted_sites'],'bracket_capacity_upper':bc,'insert_capacity_upper':ic,'combined_area_upper_mm2':combined/1e6,'required_area_lower_mm2':477582,'exact_fixed48_excluded':excluded,'whole_orientation_class_excluded':False,'whole_allocation_excluded':False})
process=load(ROOT/'output/h5-five-column-areas-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'capacity-results.json',results);write(OUT/'remaining-cases.json',[r for r in results if not r['exact_fixed48_excluded']]);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source48_cases':136,'exact_union_difference_areas_verified':408,'fixed48_cases_excluded':sum(r['exact_fixed48_excluded'] for r in results),'fixed48_cases_remaining':sum(not r['exact_fixed48_excluded'] for r in results),'largest_companion_area_upper_mm2':max(r['combined_area_upper_mm2'] for r in results),'complete_preparation_seconds_if_consumed':charge,'inherited_failed_preparation_seconds':2.2826125998981297+4.345238099806011,'algorithm60_seconds_remaining_before_any_future_stage':max(0,60-charge),'full_algorithm_budget_satisfied':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
