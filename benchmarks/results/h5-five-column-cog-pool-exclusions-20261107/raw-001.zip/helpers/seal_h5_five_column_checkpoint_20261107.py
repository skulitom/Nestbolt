"""Preserve all136 source partials, failed helpers and audited fixed-core proofs."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-five-column-cog-pool-exclusions-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-five-column-inventory-20261107';F=BASE;D=ROOT/'output/h5-five-column-areas-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-cog-return-and-four-row-capacity-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['all_companion_inventory_exclusions']==136 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-five-column-cog-pool-20261107',ROOT/'output/h5-five-column-covers-20261107',ROOT/'output/h5-five-column-covers-v2-20261107',ROOT/'output/h5-five-column-cover-repair-20261107',ROOT/'output/h5-one-three-main-sync-20261107']+[ROOT/'output'/('h5-five-column-'+n+'-process-20261107') for n in ['cog-pool','cog-pool-audit','covers','covers-v2','masks-audit','areas','areas-audit','inventory']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_five_column*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_five_column_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
S=ROOT/'output/h5-five-column-cog-pool-20261107';M=ROOT/'output/h5-five-column-covers-v2-20261107';process=load(ROOT/'output/h5-five-column-inventory-process-20261107/process.json');assert process['passed'] and process['closed'];total=front['inherited_preparation_seconds']+process['complete_seconds']
copies=[(S/'plan.json','source-plan.json'),(S/'audit/checks.json','source-audit.json'),(M/'plan.json','corrected-cover-plan.json'),(M/'mask-audit/checks.json','mask-audit.json'),(M/'mask-audit/class-controls.json','class-controls.json'),(ROOT/'output/h5-five-column-cover-repair-20261107/checks.json','helper-repair-review.json'),(D/'plan.json','area-plan.json'),(D/'audit/checks.json','area-audit.json'),(D/'audit/capacity-results.json','fixed48-capacities.json'),(BASE/'plan.json','inventory-plan.json'),(BASE/'checks.json','inventory-audit.json'),(BASE/'capacity-results.json','fixed33-capacities.json'),(ROOT/'output/h5-one-three-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for n in ['cog-pool','cog-pool-audit','covers','covers-v2','masks-audit','areas','areas-audit','inventory']:copies.append((ROOT/'output'/('h5-five-column-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,n in copies:shutil.copyfile(p,OUT/n)
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime);ci=json.loads(subprocess.check_output(['gh','run','view','42410023316','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='9eb6698eb3f734439be6c04bca5b5c9927de1edc';write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'complete_preparation_seconds_if_consumed':total,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'failed_preparation_stages_preserved':2,'full_algorithm_budget_satisfied':False})
write(OUT/'next-step.json',{'status':'all136_exact_first33_cores_excluded','proposal':'Assess the different allocation with14first-sheet cogs and originalcog14 on the verified short6bracket/5insert/1cog. The same17site pool gives680 choices with3empty sites. World geometry is unchanged, so the complete independently certified full masks may be reused after exact source/domain/mode comparisons; extract NEW complete covers allowing up to3empty cog bits and no framebit17. Old retained two-empty covers are insufficient. Use six remaining brackets/sixteen inserts for fixed short6/5/1, and the independently verified495777mm2 first-companion lower bound when all bracket/insert splits are released but shortcog stays fixed. Certify each selected original identity and exact shortcog pose; any purported full66 candidate still requires complete original-source/native/material checks. These are conditional geometry investigations only: this accumulated numeric lineage already exceeds60seconds, may not open an optimizer or claim the60second gate, and may not have its timer reset. Any later bounded construction must be separately specified and genuinely independent, recomputing all numerical input from original sources instead of treating this warm state as free. Old calls remain closed.','inherited_preparation_seconds':total,'failed_preparation_seconds_retained':6.62785069970414,'proposed_source_pool_sites':17,'proposed_first_cogs':14,'proposed_subsets':680,'three_empty_covers_prepared':False,'complete_model_prepared':False,'optimizer_allowed_from_current_charged_lineage':False,'optimizer_calls':0,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'H5_complete':False})
report=f'''# Five-column cog pool: all136 fixed cores excluded — 2026-11-07

**All136 source-valid48 partials from the expanded cog pool cannot extend to
66 parts.** The stronger bound excludes their exact eighteen-frame/fifteen-cog
first-sheet cores for every bracket/insert split between sheets. No whole
allocation or orientation class is excluded. H2/H5 remain open at **60%
completed milestone weight**; the preserved valid64 result remains best.

[Source construction]({NAME}/source-plan.json) extends the cog grid above the
four-turned fourth frame row and two-unturned cap from four to five columns,
with three rows and the same two side sites. All coordinates still derive from
original dimensions, gap, analytic phase, radius and axis pitch. Seventeen
anonymous sites yield136 choices of fifteen original first-sheet cogs; the
earlier short sheet keeps six brackets and nine inserts.

[Independent source replay]({NAME}/source-audit.json) verifies **442 pool
contacts,86,088 same-sheet pairs and8,160 original holes** across all136 valid
48-part partials. Six brackets and twelve inserts remain unplaced in each.
The pool size is not a claim about source quantities or packing capacity.

Two preparation failures are preserved. [The first process]({NAME}/covers-process.json)
stopped after **2.282613 s** because a helper-generation substitution changed
rectangle Y-coordinate indices from[1,3] to[4]. It produced no masks or
exclusions. [The repair review]({NAME}/helper-repair-review.json) corrects that
error and an unexecuted audit literal, and checks geometry-function syntax
trees against the prior verified implementations.

[The corrected preparation]({NAME}/corrected-cover-plan.json) produced all
twelve full masks, then [stopped after4.345238 s]({NAME}/covers-v2-process.json)
at an inconsistent source-case field name. No case areas or exclusions had
been produced. Those masks were retained and independently audited before
being consumed by a separate area-completion stage. Neither failed process
is retried, and both full runtime costs remain charged.

[Independent mask certification]({NAME}/mask-audit.json) verifies **1,327
source inner rectangles,20 component bounds,twelve full masks and21,026,872
continuous boundary/interval classes**. Source sites use bits0–16 and fixed
frames use distinct bit17. Controls distinguish site16 from the frame bit and
reject three-cog labels from the two-empty-site covers. Every retained class
is covered exactly once; all source containment and boundary controls pass.

[Separate area completion]({NAME}/area-plan.json) uses the actual
`source48_valid` case schema and consumes the certified full covers without
rebuilding them. Original L-component and insert sweeps are clipped to the
outward stock and have mandatory source interiors removed. [Independent
interval-event readback]({NAME}/area-audit.json) recomputes **408 exact
union-difference areas**, separately from the producer's prefix grids.

The largest available companion region is **382,919.280346 mm²**, below the
**477,582 mm²** required for six brackets and twelve inserts. [All136 fixed48
completions are excluded]({NAME}/fixed48-capacities.json).

[The inventory corollary]({NAME}/inventory-plan.json) releases every bracket
and insert while retaining only each exact first33 frame/cog core. The source
material definition, unchanged normal-seed target and outward short-sheet
bound are rechecked. Three sheets exceed the target; the mandatory first-sheet
frame is taller than the allowed short sheet, so the other sheet must be short.

[All136 exact first33 cores remain excluded]({NAME}/fixed33-capacities.json):
even adding the entire **465,326.048858 mm²** short-sheet rectangle to the
first-sheet companion region cannot hold **895,767 mm²** of original companion
bodies. [The minimum combined deficit]({NAME}/inventory-audit.json) is
**47,521.670796 mm²**. Changing only the bracket/insert allocation cannot rescue
these fixed frame/cog placements. Moving a cog or frame remains outside scope.

| Bounded stage | Complete process (s) | Outcome |
|---|---:|---|
| Source partial preparation | 5.062413 | Complete |
| Independent source audit | 5.782538 | Pass |
| First cover preparation | 2.282613 | Indexing failure preserved |
| Corrected cover preparation | 4.345238 | Masks complete; schema failure preserved |
| Independent mask audit | 5.884249 | Pass |
| Area completion | 4.329757 | Complete |
| Independent area audit | 5.409859 | Pass |
| Inventory corollary | 0.441669 | Pass |

[Source preparation]({NAME}/cog-pool-process.json) and its [audit]({NAME}/cog-pool-audit-process.json),
[mask audit]({NAME}/masks-audit-process.json), [area completion]({NAME}/areas-process.json)
and its [audit]({NAME}/areas-audit-process.json), and [inventory readback]({NAME}/inventory-process.json)
all close normally. Both failed preparations also close with their exit codes
and traces preserved. Every Job Object closes all three processes under the
unchanged CPU/thread and2 GiB controls.

**The accumulated preparation is {total:.6f} s**, including both failures and
all inherited work. This exceeds the60-second algorithm budget. These are
conditional geometry proofs, not a passing timed algorithm result. No
optimizer is opened and this charged lineage may not receive a reset timer.

[Next]({NAME}/next-step.json), assess the different allocation with fourteen
cogs from the same seventeen-site pool and one on the verified short6/5/1.
Its680 possible triples of empty sites require NEW complete three-empty
covers; the retained two-empty covers cannot be reused as if complete.
The unchanged full masks can be reused only after source/domain/mode equality
checks. This remains geometry research under the explicitly exhausted
lineage; any later timed construction needs its own genuinely independent
source computation and preflight before a search.

Four earlier fixed arrangements and440 whole-job allocations remain. Full66
source/native/material acceptance, product integration, parity and the H5
matrix remain open. [Main9eb6698e contains the earlier push]({NAME}/prior-main-push-receipt.json);
[fresh CI]({NAME}/main-ci-at-review.json) has **{success} passed / {live} live
jobs**. This and the preceding cog-return checkpoint await the next ordinary
push gate. Product code, README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve all evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 five-column cog-pool exclusions:** [source, mask, area and inventory audits]({{link}}) verify136 source-valid48 choices from17 anonymous cog sites,442 pool contacts and86,088 same-sheet pairs. Two helper failures are preserved (Y-index substitution, then case-schema mismatch); their full6.627851 s remains charged. Independently certified masks cover21,026,872 continuous classes with distinct cogsite16/framebit17. A separate area stage and independent408-area readback exclude all136 fixed48 completions: largest companion region382,919.280346 mm² versus477,582 required. Releasing every bracket and insert still excludes every exact first33 core, with at least47,521.670796 mm² combined deficit. No whole allocation or orientation class is excluded. Preparation totals{total:.6f} s, over60; no optimizer or timed-gate pass is claimed and this lineage may not reset its timer. Next investigate14-of17 choices with the verified short6/5/1 using new complete three-empty covers; existing full masks may be reused only after exact equality checks. Four earlier arrangements and440 allocations remain; valid64 remains best, H2/H5 stay open at60%. Main9eb6698e has{success} passed/{live} live CI jobs; this and the prior cog-return checkpoint await the ordinary push gate. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [five-column cog-pool exclusions](../benchmarks/results/{NAME}.md).
All136 source48 choices from17 cog sites pass original geometry checks, but
complete masks covering21,026,872 classes and408 independent area readbacks
exclude every fixed48 completion. Releasing all brackets and inserts still
excludes every exact first33 core, by at least47,521.670796 mm² combined area.
Two helper failures and their6.627851 s are preserved; certified completed
masks were reused without repeating their preparation. Total consumed
preparation is{total:.6f} s, exceeding60. No optimizer, timed-gate pass, whole
allocation or orientation-class exclusion is claimed; the timer may not reset.
Next assess14-of17 choices with short6/5/1 via new complete three-empty covers.
Four earlier arrangements and440 allocations remain; valid64 remains best.
H2/H5 stay open at60%. Main9eb6698e has{success} passed/{live} live CI jobs;
this and the prior cog-return checkpoint await the ordinary push gate.
Product and releases remain unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'total_consumed_preparation_seconds':total})
