"""Area completion after independent certification of the preserved full masks."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_five_column_area_tools_20261107 import difference_area
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-five-column-areas-20261107';MASK=ROOT/'output/h5-five-column-covers-v2-20261107';SOURCE=ROOT/'output/h5-five-column-cog-pool-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();prior=load(MASK/'mask-audit/checks.json');assert prior['passed'] and prior['complete_mode_masks_verified']==12;cases=load(SOURCE/'cases.json');assert len(cases)==136 and all(r['source48_valid'] for r in cases);inputs=[Path(__file__),MASK/'mask-audit/checks.json',MASK/'geometries.json',MASK/'stock-cover.json',MASK/'turned-4/source-inner-rectangles.json',SOURCE/'cases.json',SOURCE/'audit/checks.json',ROOT/'output/h5_five_column_area_tools_20261107.py']+[MASK/'turned-4'/f'geometry-{i:02d}.json' for i in range(12)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Consume only independently certified complete17site world masks and necessary center covers. Correct the explicit source-case schema to source48_valid. Do not repeat either failed preparation or rebuild its verified masks. For every136 source-valid48 choice, keep exactly15cogsites and18frames mandatory, select compatible zero/one/two-bit center covers, sweep original L/insert component bounds, clip to outward stock and subtract all mandatory source inner rectangles. Compute408 exact integer occupied-area bounds for6brackets/12inserts. Both failed preparation runtimes remain inherited. A separate interval-event area audit must precede all exclusions.','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'preparation_internal_cap_seconds':18,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'existing_verified_masks_reused':True})
g=load(MASK/'geometries.json');sb=load(MASK/'stock-cover.json')['outward_stock_rectangle_um'];sources=load(MASK/'turned-4/source-inner-rectangles.json');covers={i:load(MASK/'turned-4'/f'geometry-{i:02d}.json')['cover'] for i in range(12)};results=[]
for case in cases:
    omitted=case['omitted_sites'];assert len(omitted)==2 and all(0<=i<17 for i in omitted);allowed=sum(1<<i for i in omitted);fixed=[r['bounds_um'] for r in sources if r['site_bit']==17 or not(allowed&(1<<r['site_bit']))];regions={};areas={};before={}
    for family in ['bracket','insert']:
        rr=[]
        for mode in g:
            if mode['family']!=family:continue
            for label,l,b,r,t,*_ in covers[mode['geometry']]:
                if label&~allowed:continue
                for a,c,d,e in mode['outer_component_bounds_um']:
                    q=[max(l+a,sb[0]),max(b+c,sb[1]),min(r+d,sb[2]),min(t+e,sb[3])]
                    if q[0]<q[2] and q[1]<q[3]:rr.append(q)
        regions[family]=list(map(list,sorted(set(map(tuple,rr)))));areas[family],before[family]=difference_area(regions[family],fixed)
    joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));combined,old=difference_area(joint,fixed);bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);excluded=bc<6 or ic<12 or combined<477582*10**6
    result={'case':case['case'],'omitted_sites':omitted,'family_regions_um':regions,'combined_regions_um':joint,'fixed_inner_obstacles_um':fixed,'family_area_upper_um2':areas,'family_area_before_fixed_subtraction_um2':before,'combined_area_upper_um2':combined,'combined_area_before_fixed_subtraction_um2':old,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'provisional_fixed48_excluded':excluded,'independent_audit_pending':True};write(OUT/(case['case']+'-capacity.json'),result);results.append({'case':case['case'],'omitted_sites':omitted,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'combined_area_upper_mm2':combined/1e6,'provisional_fixed48_excluded':excluded});assert time.perf_counter()-began<18
write(OUT/'capacity-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source48_cases':136,'provisional_fixed48_exclusions':sum(r['provisional_fixed48_excluded'] for r in results),'provisional_remaining_cases':sum(not r['provisional_fixed48_excluded'] for r in results),'largest_combined_area_upper_mm2':max(r['combined_area_upper_mm2'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
