"""Two independent exact rectangle-area algorithms, without stage side effects."""

from bisect import bisect_left

from collections import defaultdict

import numpy as np

def difference_area(region,obstacles):
    rects=region+obstacles;xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});assert len(xs)*len(ys)<40000000
    def grid(rows):
        d=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for a,b,c,e in rows:
            i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
        return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]>0
    covered=grid(region);blocked=grid(obstacles);weight=np.diff(ys)[:,None]*np.diff(xs)[None,:];return int(np.sum(weight*(covered&~blocked),dtype=np.int64)),int(np.sum(weight*covered,dtype=np.int64))

def sweep(region,obstacles):
    if not region:return 0,0
    rects=region+obstacles;ys=sorted({r[k] for r in rects for k in [1,3]});events=defaultdict(list)
    for kind,rows in enumerate([region,obstacles]):
        for a,b,c,e in rows:events[a].append((kind,b,e,1));events[c].append((kind,b,e,-1))
    live=np.zeros((2,len(ys)-1),dtype=np.int32);height=np.diff(ys);xs=sorted(events);total=0;before=0
    for i,x in enumerate(xs):
        for kind,a,b,change in events[x]:live[kind,bisect_left(ys,a):bisect_left(ys,b)]+=change
        assert live.min()>=0
        if i+1<len(xs):
            w=xs[i+1]-x;covered=live[0]>0;available=covered&(live[1]==0);total+=w*int(height[available].sum());before+=w*int(height[covered].sum())
    assert not np.any(live);return total,before
