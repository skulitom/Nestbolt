"""Source-derived fourth frame row and two-frame cap, with one short cog."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-five-column-cog-pool-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-orientation-roofs-20261107';PRIOR=ROOT/'benchmarks/results/h5-cog-return-and-four-row-capacity-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def frame(i,angle,xy):
    c,s=math.cos(angle),math.sin(angle);v=[(x*c-y*s,x*s+y*c) for x,y in parts['frame']['geometry'][0]['outer']];return {'part_id':'frame','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':False,'translation':[xy[k]-min(p[k] for p in v) for k in range(2)]}}
def cog(i,site):return {'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':phase,'mirrored':False,'translation':[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)]}}
def world(r):
    t=r['transform'];cs,sn=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);assert not t['mirrored'];return Polygon([(x*cs-y*sn+t['translation'][0],x*sn+y*cs+t['translation'][1]) for x,y in parts[r['part_id']]['geometry'][0]['outer']])
OUT.mkdir();began=time.perf_counter();prior=load(PRIOR/'checks.json');assert prior['passed'] and load(SHORT/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),JOB,PRIOR/'checks.json',OLD/'source-recipe.json',OLD/'cog-derivation.json',OLD/'fixed27-source.json',OLD/'audit/checks.json',SHORT/'fixed27-source.json',SHORT/'audit/checks.json',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'benchmarks/results/h5-six-unturned-frame-construction-20261107/orientation-comparison.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Keep the verified four-turned fourth row and two-unturned cap. Expand the anonymous source cog grid from4x3 to5x3 above the cap, plus the two side sites, yielding17 proposed sites. Retain original source dimensions, gap, analytic phase, radius and axis pitch without a sweep. Recompute every pool stock/frame/pair contact and all136 choices of15 sites. Each choice assigns originalcogs0..14 on the first sheet and preserves the older verified short6bracket/9insert layout. Replay every complete original-source48 candidate including failures; preserve6brackets/12inserts unplaced. The17 anonymous sites are not extra sourcecopies or a packing capacity bound. Prior four-turned optimization calls remain closed; no global class novelty or optimizer authorization is claimed','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'new_orientation_class_claimed':False,'declared_source48_cases':136})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(OLD/'source-recipe.json');der=load(OLD/'cog-derivation.json');o=rec['origin'];gap=rec['gap_mm'];v=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in v)-min(p[0] for p in v);fh=max(p[1] for p in v)-min(p[1] for p in v);radius=der['radius_upper_mm'];pitch=der['axis_pitch_mm'];phase=der['rotation_radians'];c,s=math.cos(phase),math.sin(phase);cx,cy=der['source_center'];row1=o[1]+3*(fw+gap);row2=row1+fw+gap;top=row2+fh;right=o[0]+2*fw+gap;roof=[frame(12+i,math.pi/2,[o[0]+i*(fh+gap),row1]) for i in range(4)]+[frame(16+i,0.,[o[0]+i*(fw+gap),row2]) for i in range(2)];blocks=[(5,3,o[0]+radius,top+gap+radius),(2,1,right+gap+radius,row2+radius)];sites=[]
for block,(nx,ny,x0,y0) in enumerate(blocks):
    for yy in range(ny):
        for xx in range(nx):sites.append({'site':len(sites),'block':block,'grid':[xx,yy],'center':[x0+xx*pitch,y0+yy*pitch]})
base=[r for r in load(OLD/'fixed27-source.json') if r['sheet_id']=='sheet-0'];short=[r for r in load(SHORT/'fixed27-source.json') if r['sheet_id']=='sheet-1'];frames=base+roof;polys=[world(cog(i,site)) for i,site in enumerate(sites)];fps=list(map(world,frames));pairs=[];contacts=[];stockchecks=[];required=rec['required_pair_gap_mm'];guard=rec['stock_guard_mm'];st=rec['source_stocks']['sheet-0']
for i,j in combinations(range(17),2):
    g=polys[i].distance(polys[j]);pairs.append({'sites':[i,j],'gap_mm':g,'intersection_mm2':polys[i].intersection(polys[j]).area,'passed':g+1e-7>=required})
for i,p in enumerate(polys):
    for j,q in enumerate(fps):
        g=p.distance(q);contacts.append({'site':i,'frame':j,'gap_mm':g,'intersection_mm2':p.intersection(q).area,'passed':g+1e-7>=required})
    b=p.bounds;stockchecks.append({'site':i,'bounds':list(b),'passed':b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard})
for n,v in [('roof-source.json',roof),('sites.json',sites),('pool-checks.json',{'pairs':pairs,'frames':contacts,'stock':stockchecks})]:write(OUT/n,v)
allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};cases=[]
for missing in combinations(range(17),2):
    chosen=[site for site in sites if site['site'] not in missing];rows=frames+[cog(i,site) for i,site in enumerate(chosen)]+short;check=audit(job,rows,rec['source_stocks'],required,guard);ids={(row['part_id'],row['copy_index']) for row in rows};assert len(rows)==len(ids)==48;remaining=sorted(allids-ids);assert len(remaining)==18 and sum(f=='bracket' for f,i in remaining)==6 and sum(f=='insert' for f,i in remaining)==12
    name='omit-'+'-'.join(f'{i:02d}' for i in missing);write(OUT/(name+'-source.json'),rows);write(OUT/(name+'-checks.json'),check);cases.append({'case':name,'omitted_sites':list(missing),'source48_valid':check['valid'],'pair_failures':check['pair_failures'],'stock_failures':check['stock_failures']});assert time.perf_counter()-began<18
write(OUT/'cases.json',cases);write(OUT/'remaining-identities.json',remaining);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source48_cases':len(cases),'valid_source48_cases':sum(r['source48_valid'] for r in cases),'failed_pool_pairs':sum(not r['passed'] for r in pairs),'failed_pool_frame_contacts':sum(not r['passed'] for r in contacts),'failed_pool_stock_sites':sum(not r['passed'] for r in stockchecks),'independent_audit_pending':True,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
