"""Independently check actual source-world Minkowski clearance and every witness."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box,Point
from shapely.affinity import translate,scale
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-row-clearance-20261028';OLD=ROOT/'output/h5-hybrid43-guarded-source-20261028';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
process=load(BASE/'process.json');assert process['exit_code']==0 and process['closed'] and not process['timeout'] and process['seconds']<120
job=load(JOB);parts={p['id']:p for p in job['parts']};source=load(OLD/'control-source61.json');modes=load(OLD/'modes.json');blocks=load(OLD/'blocks43.json');poses=load(OLD/'control.json');instances=load(BASE/'fixed-instances.json');locals={k:shape(g) for k,g in load(BASE/'fixed-local-shapes.json').items()};world={};triangles={};hulls_count=0;pairs=0
def transform(family,a,mirrored,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mirrored else 1;return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in parts[family]['geometry'][0]['outer']])
for r in source:
    if r['sheet_id']!='sheet-0':continue
    t=r['transform'];g=transform(r['part_id'],t['rotation_radians'],t['mirrored'],t['translation']);world[(r['part_id'],r['copy_index'])]=g;tt=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(tt).equals(g);triangles[(r['part_id'],r['copy_index'])]=tt
assert len(instances)==len(world)==49 and {(r['family'],r['copy_index']) for r in instances}==set(world)
for r in instances:assert translate(locals[r['key']],*r['anchor_mm']).equals_exact(world[(r['family'],r['copy_index'])],1e-9)
rects=[]
for p in poses:
    m=modes[p['mode']];rects.extend({'block':p['block'],'rectangle_um':[a+p['anchor_um'][0],b+p['anchor_um'][1],c+p['anchor_um'][0],d+p['anchor_um'][1]]} for a,b,c,d in m['cover_rectangles_um'])
assert rects==load(BASE/'fixed-cover-rectangles.json') and len(rects)==746;records=[];witnesses=load(BASE/'witness-summary.json');summaries=load(BASE/'mode-summary.json');assert len(summaries)==len(witnesses)==8
for summary,witness in zip(summaries,witnesses):
    mi=summary['mode'];assert mi==witness['mode'];m=modes[mi];moving=transform('bracket',m['angle'],m['mirrored'],m['source_translation_offset']);assert moving.equals_exact(Polygon(m['outer_mm']),1e-9);mt=list(shapely.constrained_delaunay_triangles(moving).geoms);assert unary_union(mt).equals(moving);obstacles={k:shape(load(BASE/'obstacles'/f'{mi:02d}-{k}.json')) for k in locals};source_forbidden=[];cog_forbidden=[]
    for r in instances:
        fixed=world[(r['family'],r['copy_index'])];tt=triangles[(r['family'],r['copy_index'])];hulls=[MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(a.exterior.coords)[:-1] for v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(tt,mt)];hulls_count+=len(hulls);required=unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,quad_segs=16);stored=translate(obstacles[r['key']],*r['anchor_mm']);assert stored.covers(required),(mi,r['family'],r['copy_index'],required.difference(stored).area);source_forbidden.append(stored);pairs+=1
        if r['family']=='cog':cog_forbidden.append(stored)
    a,b,c,d=m['source_bounds_mm'];bounds=[math.ceil(6513-a*1000),math.ceil(6513-b*1000),math.floor(1493487-c*1000),math.floor(2993487-d*1000)];assert bounds==summary['stock_anchor_bounds_um'];stock=box(*(v/1000 for v in bounds));all_boxes=[];orth_boxes=[]
    for r in rects:
        fa,fb,fc,fd=r['rectangle_um']
        for ma,mb,mc,md in m['cover_rectangles_um']:
            rectangle=box(fa-mc,fb-md,fc-ma,fd-mb);all_boxes.append(rectangle)
            if blocks[r['block']]['family']!='cog-row':orth_boxes.append(rectangle)
    oldfree=stock.difference(scale(unary_union(all_boxes),xfact=.001,yfact=.001,origin=(0,0)));sourcefree=stock.difference(unary_union(source_forbidden));hybridfree=stock.difference(unary_union(cog_forbidden+[scale(unary_union(orth_boxes),xfact=.001,yfact=.001,origin=(0,0))]));gain=hybridfree.difference(oldfree)
    for key,g,area_key in [('source',sourcefree,'all_source_free_area_mm2'),('source-cogs-orthogonal-covers',hybridfree,'source_cogs_orthogonal_covers_free_area_mm2'),('all-covers',oldfree,'all_covers_free_area_mm2'),('row-cover-loss',gain,'row_cover_excluded_free_area_mm2')]:assert g.equals(shape(load(BASE/'regions'/f'{mi:02d}-{key}.json'))) and g.area==summary[area_key]
    assert oldfree.difference(hybridfree).area==summary['cover_free_outside_hybrid_area_mm2']==0
    components=list(gain.geoms) if hasattr(gain,'geoms') else [gain];components=sorted([g for g in components if g.geom_type=='Polygon' and g.area>0],key=lambda g:(-g.area,g.bounds));center=components[0].representative_point();nearest=[round(center.x*1000),round(center.y*1000)];offsets=sorted(product([-1,0,1],repeat=2),key=lambda p:(abs(p[0])+abs(p[1]),p));chosen=next([nearest[0]+dx,nearest[1]+dy] for dx,dy in offsets if gain.contains(Point((nearest[0]+dx)/1000,(nearest[1]+dy)/1000)));assert chosen==witness['pose']['anchor_um']
    rows=load(BASE/'witnesses'/f'{mi:02d}-source62.json');expected={(r['part_id'],r['copy_index']) for r in source}|{('bracket',7)};assert len(rows)==62 and rows[:len(source)]==source;checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert checked['valid'] and checked['same_sheet_pairs']==witness['source_pairs']==1291
    added=next(r for r in rows if r['part_id']=='bracket' and r['copy_index']==7);t=added['transform'];assert t['rotation_radians']==m['angle'] and t['mirrored']==m['mirrored'] and max(abs(t['translation'][j]-chosen[j]/1000-m['source_translation_offset'][j]) for j in [0,1])<1e-9
    collisions=[]
    for r in rects:
        fa,fb,fc,fd=r['rectangle_um']
        for k,(a,b,c,d) in enumerate(m['cover_rectangles_um']):
            a+=chosen[0];c+=chosen[0];b+=chosen[1];d+=chosen[1]
            if not(c<=fa or fc<=a or d<=fb or fd<=b):collisions.append({'fixed_block':r['block'],'moving_component':k,'fixed_rectangle_um':r['rectangle_um'],'moving_rectangle_um':[a,b,c,d]})
    assert collisions==load(BASE/'witnesses'/f'{mi:02d}-cover-collisions.json') and len(collisions)==witness['cover_collision_count'] and all(blocks[r['fixed_block']]['family']=='cog-row' for r in collisions);write(OUT/f'{mi:02d}-source-readback.json',checked);records.append({'mode':mi,'source_originals':62,'source_pairs':1291,'source_valid':True,'cover_collisions':len(collisions),'only_cog_row_cover_collisions':True,'minimum_source_gap_mm':checked['minimum_pair_gap_mm'],'cutouts':checked['cutouts'],'hole_vertices':checked['hole_vertices']})
write(OUT/'witnesses.json',records);inputs=[BASE/'plan.json',BASE/'process.json',BASE/'result.json',BASE/'fixed-local-shapes.json',BASE/'fixed-instances.json',BASE/'fixed-cover-rectangles.json',BASE/'mode-summary.json',BASE/'witness-summary.json',JOB,ROOT/'output/h5_legacy64_source_readback.py']+[p for folder in ['obstacles','regions','witnesses'] for p in (BASE/folder).glob('*.json')]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'bracket_modes':8,'source_world_pair_obstacles_verified':pairs,'independent_minkowski_hulls':hulls_count,'placement_regions_verified':32,'source62_witnesses_verified':8,'source_pair_readbacks':8*1291,'original_fixed61_poses_unchanged':True,'only_row_covers_reject_all8_witnesses':True,'original_source_thresholds_unchanged':True,'best64_preserved':True,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
