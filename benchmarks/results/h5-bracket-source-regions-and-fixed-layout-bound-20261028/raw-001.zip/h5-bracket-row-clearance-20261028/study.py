"""Frozen geometry-only comparison of source and cover bracket placement regions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-guarded-source-20261028';OUT=ROOT/'output/h5-bracket-row-clearance-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    import math
    import shapely
    from itertools import product
    from shapely.geometry import Polygon,MultiPoint,box,mapping,shape,Point
    from shapely.affinity import translate,scale
    from shapely.ops import unary_union
    from h5_transfer43_source_bridge_20261028 import reconstruct
    from h5_legacy64_source_readback import audit
    started=time.perf_counter();plan=load(OUT/'plan.json');job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');blocks=load(BASE/'blocks43.json');poses=load(BASE/'control.json');source=load(BASE/'control-source61.json');fixed={};instances=[];rects=[]
    for pose in poses:
        i=pose['block'];block=blocks[i];m=modes[pose['mode']];ax,ay=[v/1000 for v in pose['anchor_um']]
        rects.extend({'block':i,'rectangle_um':[a+pose['anchor_um'][0],b+pose['anchor_um'][1],c+pose['anchor_um'][0],d+pose['anchor_um'][1]]} for a,b,c,d in m['cover_rectangles_um'])
        if block['family']=='cog-row':
            a=math.radians(7);co,si=math.cos(a),math.sin(a);vv=[(x*co-y*si,x*si+y*co) for x,y in parts['cog']['geometry'][0]['outer']];lo=[min(p[k] for p in vv) for k in [0,1]];key='cog-phase7';fixed[key]=Polygon([(x-lo[0],y-lo[1]) for x,y in vv])
            instances.extend({'family':'cog','copy_index':copy,'block':i,'key':key,'anchor_mm':[ax+j*258.9,ay]} for j,copy in enumerate(block['copy_indices']))
        else:
            key=f"mode-{m['id']:02d}";fixed[key]=Polygon(m['outer_mm']);instances.append({'family':block['family'],'copy_index':block['copy_index'],'block':i,'key':key,'anchor_mm':[ax,ay]})
    assert len(instances)==49 and len(rects)==746
    write(OUT/'fixed-local-shapes.json',{k:mapping(v) for k,v in fixed.items()});write(OUT/'fixed-instances.json',instances);write(OUT/'fixed-cover-rectangles.json',rects)
    triangles={k:list(shapely.constrained_delaunay_triangles(g).geoms) for k,g in fixed.items()};assert all(unary_union(triangles[k]).equals(g) for k,g in fixed.items());summary=[];witnesses=[];obstacle_count=0;hull_count=0
    for m in [m for m in modes if m['family']=='bracket']:
        mi=m['id'];moving=Polygon(m['outer_mm']);tt=list(shapely.constrained_delaunay_triangles(moving).geoms);assert unary_union(tt).equals(moving);intrinsic={}
        for key,g in fixed.items():
            hulls=[MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(a.exterior.coords)[:-1] for v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(triangles[key],tt)];hull_count+=len(hulls);obstacle=unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1.1e-6,join_style='mitre',mitre_limit=5);intrinsic[key]=obstacle;write(OUT/'obstacles'/f'{mi:02d}-{key}.json',mapping(obstacle));obstacle_count+=1
        a,b,c,d=m['source_bounds_mm'];bounds=[math.ceil(6513-a*1000),math.ceil(6513-b*1000),math.floor(1493487-c*1000),math.floor(2993487-d*1000)];stock=box(*(v/1000 for v in bounds));source_forbidden=unary_union([translate(intrinsic[v['key']],*v['anchor_mm']) for v in instances]);cog_forbidden=unary_union([translate(intrinsic[v['key']],*v['anchor_mm']) for v in instances if v['family']=='cog']);all_boxes=[];orth_boxes=[]
        for r in rects:
            fa,fb,fc,fd=r['rectangle_um']
            for ma,mb,mc,md in m['cover_rectangles_um']:
                forbidden=box(fa-mc,fb-md,fc-ma,fd-mb);all_boxes.append(forbidden)
                if blocks[r['block']]['family']!='cog-row':orth_boxes.append(forbidden)
        cover_forbidden=scale(unary_union(all_boxes),xfact=.001,yfact=.001,origin=(0,0));orth_forbidden=scale(unary_union(orth_boxes),xfact=.001,yfact=.001,origin=(0,0));source_free=stock.difference(source_forbidden);hybrid_free=stock.difference(unary_union([cog_forbidden,orth_forbidden]));cover_free=stock.difference(cover_forbidden);gain=hybrid_free.difference(cover_free)
        for name,g in [('source',source_free),('source-cogs-orthogonal-covers',hybrid_free),('all-covers',cover_free),('row-cover-loss',gain)]:write(OUT/'regions'/f'{mi:02d}-{name}.json',mapping(g))
        components=list(gain.geoms) if hasattr(gain,'geoms') else [gain];components=sorted([g for g in components if g.geom_type=='Polygon' and g.area>0],key=lambda g:(-g.area,g.bounds));witness=None
        if components:
            point=components[0].representative_point();nearest=[round(point.x*1000),round(point.y*1000)];offsets=sorted(product([-1,0,1],repeat=2),key=lambda p:(abs(p[0])+abs(p[1]),p));candidate=next(([nearest[0]+dx,nearest[1]+dy] for dx,dy in offsets if gain.contains(Point((nearest[0]+dx)/1000,(nearest[1]+dy)/1000))),None)
            if candidate is not None:
                newpose={'block':next(i for i,b in enumerate(blocks) if b['family']=='bracket' and b['copy_index']==7),'mode':mi,'anchor_um':candidate};rows,error=reconstruct(job,blocks,modes,poses+[newpose],load(BASE/'short12.json'));expected={(r['part_id'],r['copy_index']) for r in source}|{('bracket',7)};checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert checked['valid'] and len(rows)==62
                collisions=[]
                for r in rects:
                    fa,fb,fc,fd=r['rectangle_um']
                    for k,(a,b,c,d) in enumerate(m['cover_rectangles_um']):
                        a+=candidate[0];c+=candidate[0];b+=candidate[1];d+=candidate[1]
                        if not(c<=fa or fc<=a or d<=fb or fd<=b):collisions.append({'fixed_block':r['block'],'moving_component':k,'fixed_rectangle_um':r['rectangle_um'],'moving_rectangle_um':[a,b,c,d]})
                assert collisions and all(blocks[r['fixed_block']]['family']=='cog-row' for r in collisions)
                witness={'mode':mi,'pose':newpose,'source_originals':62,'source_valid':True,'source_pairs':checked['same_sheet_pairs'],'cover_collision_count':len(collisions),'row_blocks':sorted(set(r['fixed_block'] for r in collisions)),'maximum_transform_error_mm':error};write(OUT/'witnesses'/f'{mi:02d}-source62.json',rows);write(OUT/'witnesses'/f'{mi:02d}-source-audit.json',checked);write(OUT/'witnesses'/f'{mi:02d}-cover-collisions.json',collisions);witnesses.append(witness)
        summary.append({'mode':mi,'quarter':m['quarter'],'mirrored':m['mirrored'],'stock_anchor_bounds_um':bounds,'all_source_free_area_mm2':source_free.area,'source_cogs_orthogonal_covers_free_area_mm2':hybrid_free.area,'all_covers_free_area_mm2':cover_free.area,'row_cover_excluded_free_area_mm2':gain.area,'cover_free_outside_hybrid_area_mm2':cover_free.difference(hybrid_free).area,'source_valid_cover_rejected_witness':witness is not None})
    write(OUT/'witness-summary.json',witnesses);write(OUT/'mode-summary.json',summary);write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'modes':8,'fixed_first_sheet_originals':49,'fixed_short_originals':12,'intrinsic_obstacles':obstacle_count,'minkowski_hulls':hull_count,'source62_witnesses':len(witnesses),'new_best_original_count':False,'target_originals':66,'missing_originals_in_each_witness':4,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'));print(summary)
def main():
    OUT.mkdir()
    for name in ['obstacles','regions','witnesses']:(OUT/name).mkdir()
    shutil.copyfile(__file__,OUT/'study.py');prior=load(BASE/'plan.json');assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'search/result.json')['closed']
    inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','short12.json','control.json','control-source61.json','source-bridge-audit/plan.json','source-bridge-audit/checks.json','response-audit/plan.json','response-audit/checks.json','search/result.json']]+[JOB,ROOT/'output/h5_transfer43_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'One geometry-only diagnostic of all8 bracket modes around the unchanged source61 control. Compute original-source placement regions against all49 first-sheet originals, hybrid regions using source cogs and unchanged orthogonal covers, and all-cover regions. The same13um stock model guard applies throughout. Exact rectangle no-overlap is compared on integer micrometre witnesses. Intrinsic source obstacles use original filled outers, triangle Minkowski unions and a conservative mitre clearance buffer. Independently verify against transformed source-world geometry. For each mode, at most one witness is taken from the largest row-cover-loss polygon: representative point rounded to1um, then at most9 predefined nearest-grid checks. No optimizer, packing search, closed-trial restart or full66 claim. Preserve existing valid64 and validate any source62 witness against the original job. Empty conservative regions or absent grid witnesses do not prove impossibility.','maximum_preparation_seconds':120,'maximum_runs':1,'retry_permitted':False,'source_stocks':prior['source_stocks'],'required_source_gap_mm':prior['required_source_gap_mm'],'native_stock_guard_mm':prior['native_stock_guard_mm'],'source_model_stock_guard_um':13,'source_buffer_radius':'required_source_gap_mm/cos(pi/64)+1.1e-6','maximum_witnesses_per_mode':1,'maximum_grid_points_per_mode':9,'solver_calls':0,'H5_complete':False})
    start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=120);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False,'closed':True}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-start,'timeout':True,'closed':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No complete result; preparation stays closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
