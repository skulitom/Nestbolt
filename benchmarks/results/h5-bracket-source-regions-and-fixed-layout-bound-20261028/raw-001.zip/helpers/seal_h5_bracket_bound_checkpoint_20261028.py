"""Seal original-source bracket regions and the independently proved fixed-layout exclusion."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';PUB=BASE/'publication';NAME='h5-bracket-source-regions-and-fixed-layout-bound-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='98a5651c0509e06d0e542aa114f64f59fb707155' and not git('diff','HEAD','--name-only')
assert load(STUDY/'audit/checks.json')['passed'] and load(STUDY/'result.json')['source62_witnesses']==8
for a in ['geometry-audit','cover-audit','model-audit','response-audit','necessary-envelope/audit']:assert load(BASE/a/'checks.json')['passed']
r=load(BASE/'search/result.json');assert r['closed'] and r['solver_calls']==1 and r['status']=='INFEASIBLE' and not r['has_solution'];bound=load(BASE/'necessary-envelope/audit/checks.json');assert bound['fixed61_two_sheet_completion_excluded'] and bound['maximum_additional_brackets_both_sheets']==4 and not bound['original_or_global_job_feasibility_excluded']
prior=load(ROOT/'benchmarks/results/h5-transfer-and-hybrid-row-clearance-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='608fecf12c287805fddcd8e64b9db7fef4950b70';jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [STUDY,BASE]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set()
for pattern in ['*fixed61*20261028.py','*bracket_row_clearance*20261028.py']:helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','verify_h5_bracket_bound_archive_20261028.py',Path(__file__).name])
for p in helpers:add('helpers/'+p.name,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('audit/checks.json','source-region-audit.json'),('mode-summary.json','source-region-summary.json'),('witness-summary.json','source62-witness-summary.json')]:shutil.copyfile(STUDY/a,OUT/b)
for a,b in [('geometry-audit/checks.json','source-cell-audit.json'),('cover-audit/checks.json','bracket-cover-audit.json'),('model-audit/checks.json','model-audit.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json'),('necessary-envelope/audit/checks.json','necessary-bound-audit.json'),('necessary-envelope/audit/necessity-proof.json','necessary-bound-proof.json'),('necessary-envelope/swept-envelope.json','first-sheet-envelope.json'),('necessary-envelope/audit/short-area-checks.json','short-sheet-area-checks.json')]:shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_prior_checkpoint':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40771628220,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False});write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False});write(OUT/'checks.json',{'passed':True,'source62_witnesses':8,'source_world_pair_obstacles_verified':392,'full_target_originals':66,'closed_solver_calls':1,'solver_status':'INFEASIBLE','solver_scope':'fixed61 conservative source-cell construction','fixed61_two_sheet_completion_independently_excluded':True,'necessary_bound_uses_continuous_anchors_and_no_extra_clearance':True,'original_or_global_job_excluded':False,'source_valid66_count':0,'valid64_preserved':True,'remaining_necessary_allocations':444,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
