"""Create new fixed61 search/readback helpers without altering closed whole-sheet trials."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed61-five-brackets-20261028/helper-generation';OUT.mkdir();digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
for name in ['run_h5_transfer43_model_20261028.py','check_h5_transfer43_candidate_20261028.py','audit_h5_transfer43_response_20261028.py']:
    source=ROOT/'output'/name;target=ROOT/'output'/name.replace('transfer43','fixed61_brackets');s=source.read_text(encoding='utf-8');changes=[('output/h5-transfer43-source-20261028','output/h5-fixed61-five-brackets-20261028')]
    if name.startswith('run_'):
        changes += [('source-bridge-audit','geometry-audit'),('row-identity-audit','cover-audit'),('check_h5_transfer43_candidate_20261028.py','check_h5_fixed61_brackets_candidate_20261028.py'),('output/h5_transfer43_cp_reader_20261028.py','output/h5_fixed61_brackets_cp_reader_20261028.py')]
    if name.startswith('check_'):
        changes += [("load(BASE/'modes.json'),poses,load(BASE/'short12.json')","load(BASE/'modes.json'),load(BASE/'fixed-poses.json')+poses,load(BASE/'short12.json')"),('len(poses)==43','len(poses)==5'),("'blocks43.json','modes.json','short12.json'","'blocks43.json','modes.json','short12.json','fixed-poses.json','fixed-source61.json'")]
    if name.startswith('audit_'):
        changes += [('from h5_transfer43_cp_reader_20261028 import inspect,violations','from h5_fixed61_brackets_cp_reader_20261028 import inspect,violations'),('source-bridge-audit','geometry-audit'),('row-identity-audit','cover-audit'),("inspect(p,mp,load(BASE/'blocks43.json'),load(BASE/'modes.json'),load(BASE/'control.json')","inspect(p,mp,load(BASE/'modes.json'),{mi:load(BASE/'free'/f'{mi:02d}.json')['cells'] for mi in range(2,10)},load(BASE/'control.json')"),("checked['expanded_pairs']==285390","checked['expanded_pairs']==45"),("'all43_blocks_mandatory':True,'movable_first_sheet_originals':54,'fixed_short_originals':12,'cover_components_per_complete_assignment':756,'cover_pairs_per_complete_assignment':285390","'all5_missing_brackets_mandatory':True,'movable_first_sheet_originals':5,'fixed_originals':61,'cover_components_per_complete_assignment':10,'cover_pairs_per_complete_assignment':45"),('output/h5_transfer43_cp_reader_20261028.py','output/h5_fixed61_brackets_cp_reader_20261028.py')]
    for a,b in changes:
        assert a in s,(name,a);s=s.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':digest(source),'target':target.relative_to(ROOT).as_posix(),'target_sha256':digest(target),'changes':changes})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'new_helpers':len(records),'closed_whole_sheet_trials_unchanged':True})
