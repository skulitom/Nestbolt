"""Prove each bracket cover contains half the original required-clearance disc."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';OUT=BASE/'cover-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');part=next(p for p in load(JOB)['parts'] if p['id']=='bracket');modes=load(BASE/'modes.json');records=[]
for m in [m for m in modes if m['family']=='bracket']:
    c,s=math.cos(m['angle']),math.sin(m['angle']);sign=-1 if m['mirrored'] else 1;tx,ty=m['source_translation_offset'];g=Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in part['geometry'][0]['outer']]);required=g.buffer(plan['required_source_gap_mm']/2/math.cos(math.pi/64)+1e-7,quad_segs=16);rectangles=[box(*(v/1000 for v in r)) for r in m['cover_rectangles_um']];cover=unary_union(rectangles);assert cover.covers(required) and len(rectangles)==2 and rectangles[0].intersection(rectangles[1]).area==0;records.append({'mode':m['id'],'independent_original_outline_and_half_clearance_contained':True,'same_owner_rectangles_have_disjoint_interiors':True})
assert len(records)==8;write(OUT/'modes.json',records);write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'modes.json',JOB]}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'modes_verified':8,'original_required_gap_mm':plan['required_source_gap_mm'],'disjoint_covers_imply_required_original_gap':True,'solver_calls':0,'native_calls':0});print(load(OUT/'checks.json'))
