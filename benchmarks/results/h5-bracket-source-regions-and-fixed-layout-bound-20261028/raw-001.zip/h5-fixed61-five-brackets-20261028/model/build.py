"""Build all five mandatory brackets using source free cells and bracket-only covers."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(BASE/'geometry-audit/checks.json')['passed']
for n,h in load(BASE/'geometry-audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
modes=load(BASE/'modes.json');free={mi:load(BASE/'free'/f'{mi:02d}.json')['cells'] for mi in range(2,10)};control={r['block']:r for r in load(BASE/'control.json')};negative={r['block']:r for r in load(BASE/'negative.json')};model=cp_model.CpModel();items=[];xs=[];ys=[];values={};bad={};hints={}
for i in range(5):
    present=model.new_bool_var(f'present_{i}');mandatory=model.add(present==1);x=model.new_int_var(0,1500000,f'x_{i}');y=model.new_int_var(0,3000000,f'y_{i}');known=control.get(i);values[present.index]=int(known is not None);bad[present.index]=1;hints[present.index]=1;values[x.index],values[y.index]=known['anchor_um'] if known else [0,0];bad[x.index],bad[y.index]=negative[i]['anchor_um'];options=[]
    if known:hints[x.index],hints[y.index]=known['anchor_um']
    for mi in range(2,10):
        select=model.new_bool_var(f'mode_{i}_{mi}');active=known is not None and known['mode']==mi;badactive=negative[i]['mode']==mi;values[select.index]=int(active);bad[select.index]=int(badactive)
        if known:hints[select.index]=int(active)
        selected=next((k for k,c in enumerate(free[mi]) if active and all(a*known['anchor_um'][0]+b*known['anchor_um'][1]>=v for a,b,v in c['halfplanes'])),None);badselected=next((k for k,c in enumerate(free[mi]) if badactive and all(a*negative[i]['anchor_um'][0]+b*negative[i]['anchor_um'][1]>=v for a,b,v in c['halfplanes'])),None);cellvars=[];planes=[]
        assert not active or selected is not None;assert not badactive or badselected is not None
        for k,cell in enumerate(free[mi]):
            s=model.new_bool_var(f'cell_{i}_{mi}_{k}');cellvars.append(s.index);values[s.index]=int(active and k==selected);bad[s.index]=int(badactive and k==badselected)
            if known:hints[s.index]=values[s.index]
            cts=[]
            for a,b,v in cell['halfplanes']:
                ct=model.add(a*x+b*y>=v);ct.only_enforce_if(s);cts.append(ct.index)
            planes.append(cts)
        choice=model.add(sum(model.get_int_var_from_proto_index(ix) for ix in cellvars)==select);components=[]
        for k,(a,b,c,d) in enumerate(modes[mi]['cover_rectangles_um']):
            ix=model.new_optional_fixed_size_interval_var(x+a,c-a,select,f'cover_x_{i}_{mi}_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,d-b,select,f'cover_y_{i}_{mi}_{k}');xs.append(ix.index);ys.append(iy.index);components.append({'component':k,'x_interval':ix.index,'y_interval':iy.index})
        options.append({'mode':mi,'selector':select.index,'cells':cellvars,'plane_constraints':planes,'cell_choice':choice.index,'components':components})
    choice=model.add(sum(model.get_int_var_from_proto_index(o['selector']) for o in options)==present);items.append({'index':i,'block':i,'copy_index':7+i,'presence':present.index,'mandatory':mandatory.index,'x':x.index,'y':y.index,'options':options,'choice':choice.index})
no=model.add_no_overlap_2d([model.get_interval_var_from_proto_index(i) for i in xs],[model.get_interval_var_from_proto_index(i) for i in ys]);orders=[]
for a,b in zip(items,items[1:]):
    ct=model.add(model.get_int_var_from_proto_index(a['x'])<=model.get_int_var_from_proto_index(b['x']));ct.only_enforce_if([model.get_int_var_from_proto_index(a['presence']),model.get_int_var_from_proto_index(b['presence'])]);orders.append({'left':a['index'],'right':b['index'],'constraint':ct.index})
for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'no_overlap_2d':no.index,'orders':orders,'control_disabled_mandatory_constraints':[r['mandatory'] for r in items if r['index'] not in control]});write(OUT/'partial-control-assignment.json',[values[i] for i in range(len(model.proto.variables))]);write(OUT/'negative-assignment.json',[bad[i] for i in range(len(model.proto.variables))]);write(OUT/'partial-hints.json',{str(k):v for k,v in hints.items()})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','control.json','negative.json','geometry-audit/plan.json','geometry-audit/checks.json']]+list((BASE/'free').glob('*.json'));write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_brackets':5,'fixed_originals':61,'target_originals':66,'mode_choices':40,'cell_selectors':290,'partial_hints':len(hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0});print(load(OUT/'built.json'))
