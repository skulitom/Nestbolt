"""Necessary fixed-layout area envelope using only source-contained rectangles."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon,box,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';OUT=BASE/'necessary-envelope';CAP=ROOT/'output/h5-free23-capacity-20261028';MODES=ROOT/'output/h5-free23-source-regions-20261028/modes.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygons(g):return [g] if g.geom_type=='Polygon' else [p for p in g.geoms if p.geom_type=='Polygon']
def transform(points,a,mir,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1;return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in points])
def inner(g):
    a,b,c,d=g.bounds;r=[math.ceil(a*1000)+2,math.ceil(b*1000)+2,math.floor(c*1000)-2,math.floor(d*1000)-2];assert g.contains(box(*(v/1000 for v in r)));return r
def exact_area(rectangles):
    xs=sorted(set(v for r in rectangles for v in [r[0],r[2]]));area=0
    for a,b in zip(xs,xs[1:]):
        intervals=sorted((r[1],r[3]) for r in rectangles if r[0]<=a and r[2]>=b);total=0;lo=hi=None
        for y0,y1 in intervals:
            if hi is None:lo,hi=y0,y1
            elif y0>hi:total+=hi-lo;lo,hi=y0,y1
            else:hi=max(hi,y1)
        if hi is not None:total+=hi-lo
        area+=(b-a)*total
    return area
OUT.mkdir();shutil.copyfile(__file__,OUT/'study.py');start=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'search/result.json')['status']=='INFEASIBLE';job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');source=load(BASE/'fixed-source61.json');cgmode=load(MODES)[0];cgrects=load(CAP/'mode-rectangles.json')[0]['rectangles_um'];assert load(CAP/'geometry-audit-corrected/checks.json')['passed'];inputs=[BASE/n for n in ['plan.json','modes.json','fixed-source61.json','response-audit/plan.json','response-audit/checks.json','search/result.json']]+[CAP/'plan.json',CAP/'mode-rectangles.json',CAP/'geometry-audit-corrected/plan.json',CAP/'geometry-audit-corrected/checks.json',MODES,JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Necessary fixed61-layout relaxation, with no packing optimizer. Use only rectangles strictly inside each original: the independently verified5mm-grid cog rectangles translated to actual fixed poses and rounded inward another2um; inward2um full rectangles for fixed frames/inserts; inward2um rectangles for the two components of every legal bracket mode. Ignore all pair clearance and all interactions among missing brackets when deriving allowed individual anchors. Relax stock anchor limits outward by2um from the unguarded6.5mm source bounds. Compute exact integer rectangle forbidden translations and their continuous complement. Decompose each anchor domain into exact orthogonal slabs. Sweep the moving contained rectangles over all allowed anchors and all8 modes, then compute the union envelope area by integer interval sweeps. Any original completion would place5 disjoint contained bracket sets inside this union; each has at least the minimum mode-contained area. An envelope smaller than5 times that minimum proves these fixed61 poses cannot be completed even with continuous anchors and without the positive clearance requirement. It says nothing about other original poses or global job feasibility. Exact source-edge containment, rectangle set construction, slab coverage and integer area arithmetic must be independently checked before making that restricted claim.','source_originals_fixed':61,'first_sheet_fixed_originals':49,'missing_brackets':5,'moving_modes':8,'extra_clearance_required_mm':0,'coordinate_grid_restriction':False,'source_inward_rounding_um':2,'stock_outward_relaxation_um':2,'solver_calls':0,'native_calls':0,'H5_complete':False})
fixed=[]
for row in source:
    if row['sheet_id']!='sheet-0':continue
    t=row['transform'];g=transform(parts[row['part_id']]['geometry'][0]['outer'],t['rotation_radians'],t['mirrored'],t['translation'])
    if row['part_id']=='cog':
        assert t['rotation_radians']==cgmode['angle'] and t['mirrored']==cgmode['mirrored'];dx,dy=[t['translation'][j]-cgmode['source_translation_offset'][j] for j in [0,1]];rr=[]
        for a,b,c,d in cgrects:
            r=[math.ceil(a+dx*1000)+2,math.ceil(b+dy*1000)+2,math.floor(c+dx*1000)-2,math.floor(d+dy*1000)-2];assert g.contains(box(*(v/1000 for v in r)));rr.append(r)
    else:assert row['part_id'] in ['frame','insert'];rr=[inner(g)]
    fixed.append({'family':row['part_id'],'copy_index':row['copy_index'],'rectangles_um':rr})
write(OUT/'fixed-inner-rectangles.json',fixed);allfixed=[r for v in fixed for r in v['rectangles_um']];moving=[];summary=[];swept=[]
source_rects=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]]
for m in [m for m in modes if m['family']=='bracket']:
    mi=m['id'];rr=[inner(transform(points,m['angle'],m['mirrored'],m['source_translation_offset'])) for points in source_rects];area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rr);moving.append({'mode':mi,'rectangles_um':rr,'contained_area_um2':area});width=300000 if m['quarter']%2==0 else 250000;height=250000 if m['quarter']%2==0 else 300000;bounds=[6498,6498,1493502-width,2993502-height];forbidden=[box(fa-mc,fb-md,fc-ma,fd-mb) for fa,fb,fc,fd in allfixed for ma,mb,mc,md in rr];free=box(*bounds).difference(unary_union(forbidden));xs=sorted(set(round(x) for p in polygons(free) for ring in [p.exterior,*p.interiors] for x,y in ring.coords));slabs=[]
    for a,b in zip(xs,xs[1:]):
        for p in polygons(free.intersection(box(a,bounds[1],b,bounds[3]))):
            if p.area==0:continue
            r=[round(v) for v in p.bounds];assert p.equals(box(*r));slabs.append(r)
    assert unary_union([box(*r) for r in slabs]).equals(free);mode_swept=[[a+ma,b+mb,c+mc,d+md] for a,b,c,d in slabs for ma,mb,mc,md in rr];swept.extend(mode_swept);write(OUT/f'{mi:02d}-necessary-anchor-domain.json',mapping(free));write(OUT/f'{mi:02d}-anchor-slabs.json',slabs);write(OUT/f'{mi:02d}-swept-rectangles.json',mode_swept);summary.append({'mode':mi,'anchor_bounds_um':bounds,'anchor_slabs':len(slabs),'anchor_domain_area_um2':exact_area(slabs),'swept_rectangles':len(mode_swept),'contained_area_um2':area})
envelope=unary_union([box(*r) for r in swept]);area=exact_area(swept);assert area==envelope.area;minimum=min(r['contained_area_um2'] for r in moving);required=5*minimum;write(OUT/'moving-inner-rectangles.json',moving);write(OUT/'modes-summary.json',summary);write(OUT/'swept-envelope.json',mapping(envelope));result={'closed':True,'seconds':time.perf_counter()-start,'fixed_source_originals':61,'fixed_first_sheet_originals':49,'fixed_inner_rectangles':len(allfixed),'moving_modes':8,'total_anchor_slabs':sum(r['anchor_slabs'] for r in summary),'swept_rectangles':len(swept),'minimum_bracket_contained_area_um2':minimum,'required_five_brackets_area_um2':required,'relaxed_envelope_area_um2':area,'area_deficit_um2':required-area,'candidate_fixed61_exclusion':area<required,'independent_audit_required':True,'source_poses_other_than_fixed61_excluded':False,'original_job_globally_excluded':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'result.json',result);print(result)
