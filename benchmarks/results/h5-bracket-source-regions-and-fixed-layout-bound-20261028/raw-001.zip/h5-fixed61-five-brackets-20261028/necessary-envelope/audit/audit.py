"""Exact containment and integer arrangement proof of a fixed61 two-sheet exclusion."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import shape,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';DATA=BASE/'necessary-envelope';OUT=DATA/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def source(points,a,mir,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1;return [tuple(F(str(v)) for v in (sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1])) for x,y in points]
def segment_hits(a,b,r):
    lo,hi=F(0),F(1)
    for axis in [0,1]:
        delta=b[axis]-a[axis]
        if delta==0:
            if not r[axis]<=a[axis]<=r[axis+2]:return False
        else:
            u,v=sorted([(r[axis]-a[axis])/delta,(r[axis+2]-a[axis])/delta]);lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
def inside(point,vv):
    x,y=point;result=False
    for a,b in zip(vv,vv[1:]+vv[:1]):
        if (a[1]>y)!=(b[1]>y):
            crossing=a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1])
            if x<crossing:result=not result
    return result
edge_checks=rectangle_checks=0
def contained(vv,rectangles):
    global edge_checks,rectangle_checks
    for r in rectangles:
        assert all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3];rr=[F(v,1000) for v in r];assert inside(rr[:2],vv)
        for a,b in zip(vv,vv[1:]+vv[:1]):assert not segment_hits(a,b,rr);edge_checks+=1
        rectangle_checks+=1
    for a,b in combinations(rectangles,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
def merged(intervals):
    out=[]
    for a,b in sorted(intervals):
        if not out or a>out[-1][1]:out.append([a,b])
        else:out[-1][1]=max(out[-1][1],b)
    return out
def positive_area(rectangles):
    xs=sorted(set(v for r in rectangles for v in [r[0],r[2]]));total=0
    for a,b in zip(xs,xs[1:]):total+=(b-a)*sum(d-c for c,d in merged([(r[1],r[3]) for r in rectangles if r[0]<=a and r[2]>=b]))
    return total
def polygon_area(g):
    pp=[g] if g.geom_type=='Polygon' else list(g.geoms);twice=0
    for p in pp:
        for i,ring in enumerate([p.exterior,*p.interiors]):
            vv=list(ring.coords)[:-1];assert all(float(v).is_integer() for point in vv for v in point);vv=[tuple(int(v) for v in point) for point in vv];a=abs(sum(x0*y1-x1*y0 for (x0,y0),(x1,y1) in zip(vv,vv[1:]+vv[:1])));twice+=a if i==0 else -a
    assert twice%2==0;return twice//2
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(DATA/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
inputs=[DATA/'plan.json',DATA/'result.json',DATA/'fixed-inner-rectangles.json',DATA/'moving-inner-rectangles.json',DATA/'modes-summary.json',DATA/'swept-envelope.json',BASE/'plan.json',BASE/'fixed-source61.json',BASE/'modes.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',JOB]+[p for p in DATA.glob('??-*.json')]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'Independently prove the necessary continuous first-sheet envelope and add a separate relaxed short-sheet area bound. The first-sheet result can force some missing brackets to the short sheet; the short bound counts how many could fit even ignoring all shape/clearance restrictions. No original pose is moved, no packing solver is called, and neither sheet result is generalized to other fixed layouts.','short_sheet_method':'Expand each stock edge by2um; round its area upward to an integer mm2. Compute exact decimal-Fraction shoelace areas of the12 fixed filled source outers, rounding each down to integer mm2. Divide remaining upper area by the minimum exactly verified contained area of any bracket mode. Original positive clearance and source stock guards only tighten this bound.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};assert parts['bracket']['rotations']=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]} and parts['bracket']['allow_mirror'];modes=load(BASE/'modes.json');ss=load(BASE/'fixed-source61.json');first={(r['part_id'],r['copy_index']):r for r in ss if r['sheet_id']=='sheet-0'};short=[r for r in ss if r['sheet_id']=='sheet-1'];fixed=load(DATA/'fixed-inner-rectangles.json');moving=load(DATA/'moving-inner-rectangles.json');summaries=load(DATA/'modes-summary.json');assert len(first)==len(fixed)==49 and len(short)==12 and len(moving)==len(summaries)==8;assert {(modes[r['mode']]['quarter'],modes[r['mode']]['mirrored']) for r in moving}=={(q,mir) for q in range(4) for mir in [False,True]}
for row in fixed:
    actual=first[(row['family'],row['copy_index'])];t=actual['transform'];vv=source(parts[row['family']]['geometry'][0]['outer'],t['rotation_radians'],t['mirrored'],t['translation']);contained(vv,row['rectangles_um'])
allfixed=[r for row in fixed for r in row['rectangles_um']];all_swept=[];modechecks=[];stripchecks=0
for row,summary in zip(moving,summaries):
    mi=row['mode'];assert mi==summary['mode'];m=modes[mi];vv=source(parts['bracket']['geometry'][0]['outer'],m['angle'],m['mirrored'],m['source_translation_offset']);rr=row['rectangles_um'];contained(vv,rr);area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rr);assert area==row['contained_area_um2']==summary['contained_area_um2'];bounds=summary['anchor_bounds_um'];width=300000 if m['quarter']%2==0 else 250000;height=250000 if m['quarter']%2==0 else 300000;assert bounds==[6498,6498,1493502-width,2993502-height]
    # These relaxed bounds contain every stock-valid continuous source anchor.
    assert F(bounds[0])<=6500-1000*min(v[0] for v in vv) and F(bounds[1])<=6500-1000*min(v[1] for v in vv);assert F(bounds[2])>=1493500-1000*max(v[0] for v in vv) and F(bounds[3])>=2993500-1000*max(v[1] for v in vv)
    forbidden=[[fa-mc,fb-md,fc-ma,fd-mb] for fa,fb,fc,fd in allfixed for ma,mb,mc,md in rr];slabs=load(DATA/f'{mi:02d}-anchor-slabs.json');assert all(all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3] and bounds[0]<=r[0]<r[2]<=bounds[2] and bounds[1]<=r[1]<r[3]<=bounds[3] for r in slabs)
    # Check every continuous X strip of the entire rectangle arrangement by exact integers.
    xs=sorted({bounds[0],bounds[2]}|{v for r in forbidden+slabs for v in [r[0],r[2]] if bounds[0]<v<bounds[2]});domain_area=0
    for a,b in zip(xs,xs[1:]):
        occupied=merged([(max(bounds[1],r[1]),min(bounds[3],r[3])) for r in forbidden if r[0]<=a and r[2]>=b and r[1]<bounds[3] and r[3]>bounds[1]]);free=[];lo=bounds[1]
        for y0,y1 in occupied:
            if lo<y0:free.append([lo,y0])
            lo=max(lo,y1)
        if lo<bounds[3]:free.append([lo,bounds[3]])
        got=merged([(r[1],r[3]) for r in slabs if r[0]<=a and r[2]>=b]);assert got==free,(mi,a,b,got,free);domain_area+=(b-a)*sum(y1-y0 for y0,y1 in free);stripchecks+=1
    domain=shape(load(DATA/f'{mi:02d}-necessary-anchor-domain.json'));assert unary_union([box(*r) for r in slabs]).equals(domain) and polygon_area(domain)==domain_area==summary['anchor_domain_area_um2']
    swept=load(DATA/f'{mi:02d}-swept-rectangles.json');assert swept==[[a+ma,b+mb,c+mc,d+md] for a,b,c,d in slabs for ma,mb,mc,md in rr];all_swept.extend(swept);modechecks.append({'mode':mi,'continuous_anchor_arrangement_verified':True,'anchor_slabs':len(slabs),'contained_area_um2':area})
envelope=shape(load(DATA/'swept-envelope.json'));assert unary_union([box(*r) for r in all_swept]).equals(envelope);envelope_area=positive_area(all_swept);assert polygon_area(envelope)==envelope_area;minimum=min(row['contained_area_um2'] for row in moving);result=load(DATA/'result.json');assert result['relaxed_envelope_area_um2']==envelope_area and result['minimum_bracket_contained_area_um2']==minimum and result['required_five_brackets_area_um2']==5*minimum and result['area_deficit_um2']==5*minimum-envelope_area>0;max_first=envelope_area//minimum;assert max_first==3
sourceplan=load(BASE/'plan.json');stock=sourceplan['source_stocks']['sheet-1'];left,bottom,right,top=[F(str(x)) for x in stock];expanded_area=(right-left+F(4,1000))*(top-bottom+F(4,1000));stock_area_upper=-((-expanded_area.numerator)//expanded_area.denominator);fixed_short_lower=0;shortchecks=[]
for r in short:
    t=r['transform'];vv=source(parts[r['part_id']]['geometry'][0]['outer'],t['rotation_radians'],t['mirrored'],t['translation']);area=abs(sum(u[0]*v[1]-u[1]*v[0] for u,v in zip(vv,vv[1:]+vv[:1])))/2;lower=area.numerator//area.denominator;fixed_short_lower+=lower;shortchecks.append({'family':r['part_id'],'copy_index':r['copy_index'],'exact_area_mm2_numerator':str(area.numerator),'exact_area_mm2_denominator':str(area.denominator),'lower_area_mm2':lower})
short_remaining=(stock_area_upper-fixed_short_lower)*1000000;max_short=short_remaining//minimum;assert max_short==1 and max_first+max_short<5
write(OUT/'mode-checks.json',modechecks);write(OUT/'short-area-checks.json',shortchecks);write(OUT/'necessity-proof.json',{'first_sheet':'Every retained rectangle is strictly inside its original filled outer, proved by exact source-edge clipping and ray parity. Any original placement with the positive required gap avoids every closed fixed/moving rectangle no-fit box. Expanded stock bounds contain every legal anchor. Exact integer X-strip complements include every feasible continuous anchor; interior strips suffice because strict rectangle containment and positive source gap prevent an isolated boundary-only feasible anchor. Sweeping each moving contained rectangle over these slabs gives the complete possible envelope. For5 physically disjoint originals the contained rectangles are disjoint, with total area at least5 times the smallest mode area. The exact envelope is smaller; at most3 additional brackets can occupy the first sheet while its49 originals remain fixed. No coordinate-grid assumption or extra clearance is imposed.','short_sheet':'The original12 fixed short-sheet polygons are already independently source-valid and disjoint. Their exact filled-outer areas are rounded downward; the expanded stock area is rounded upward. Remaining area can hold at most1 additional bracket even ignoring shape and clearance. Combining both sheets permits at most4 of the5 missing brackets.','scope':'Excludes completion of these61 fixed original poses on these two unchanged target stock bounds, including arbitrary reassignment of the5 missing brackets between them. It does not exclude the original job, other source poses, altered allocations/short bounds or any global layout.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':61,'first_sheet_fixed_originals':49,'short_sheet_fixed_originals':12,'exact_contained_rectangles_verified':rectangle_checks,'exact_source_segment_checks':edge_checks,'exact_continuous_x_strips_verified':stripchecks,'all8_legal_bracket_modes_verified':True,'integer_grid_restriction':False,'first_sheet_envelope_area_um2':envelope_area,'minimum_bracket_contained_area_um2':minimum,'five_bracket_required_area_um2':5*minimum,'first_sheet_area_deficit_um2':5*minimum-envelope_area,'maximum_additional_brackets_first_sheet':max_first,'expanded_short_stock_area_upper_mm2':stock_area_upper,'fixed_short_filled_area_lower_mm2':fixed_short_lower,'remaining_short_area_upper_um2':short_remaining,'maximum_additional_brackets_short_sheet':max_short,'maximum_additional_brackets_both_sheets':max_first+max_short,'missing_original_brackets':5,'fixed61_two_sheet_completion_excluded':True,'original_or_global_job_feasibility_excluded':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
