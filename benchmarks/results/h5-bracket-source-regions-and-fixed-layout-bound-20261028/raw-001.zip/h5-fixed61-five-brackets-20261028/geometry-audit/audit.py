"""Check every inward plane, fixed original and partial/negative source control."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
from shapely.geometry import shape
from shapely.ops import unary_union
from h5_transfer43_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';OLD=ROOT/'output/h5-bracket-row-clearance-20261028';OUT=BASE/'geometry-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'audit/checks.json')['passed'];counts={'modes':0,'cells':0,'planes':0}
for mi in range(2,10):
    d=load(BASE/'free'/f'{mi:02d}.json');domain=shape(d['domain_geometry']);assert domain.equals(shape(load(OLD/'regions'/f'{mi:02d}-source.json')));polys=[]
    for cell in d['cells']:
        p=shape(cell['geometry']);assert p.is_valid and not p.interiors and p.equals(p.convex_hull);polys.append(p);vv=[tuple(F(str(x)) for x in pt) for pt in list(p.exterior.coords)[:-1]];assert len(vv)==len(cell['halfplanes']) and sum(u[0]*v[1]-u[1]*v[0] for u,v in zip(vv,vv[1:]+vv[:1]))>0
        for (u,v),(aa,bb,cc) in zip(zip(vv,vv[1:]+vv[:1]),cell['halfplanes']):
            nx,ny=u[1]-v[1],v[0]-u[0];norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm;assert all(nx*(w[0]-u[0])+ny*(w[1]-u[1])>=0 for w in vv);assert aa==round(nx*10**9) and bb==round(ny*10**9);target=10**12*(nx*u[0]+ny*u[1]);error=abs(aa-10**9*nx)*1600000+abs(bb-10**9*ny)*3100000;assert F(cc)>target+error and F(cc-1)<=target+error+1;counts['planes']+=1
        counts['cells']+=1
    assert unary_union(polys).equals(domain);counts['modes']+=1
job=load(JOB);modes=load(BASE/'modes.json');blocks=load(BASE/'blocks43.json');fixed=load(BASE/'fixed-poses.json');short=load(BASE/'short12.json');source=load(BASE/'fixed-source61.json');expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};assert len(source)==61 and len(fixed)==38 and len(short)==12;assert [b['copy_index'] for b in blocks[:5]]==list(range(7,12)) and all(b['family']=='bracket' for b in blocks[:5]);cases=[]
for name,count,missing,valid,collisions in [('control',62,{('bracket',i) for i in range(8,12)},True,0),('negative',66,set(),False,10)]:
    rows,error=reconstruct(job,blocks,modes,fixed+load(BASE/(name+'.json')),short);saved=load(BASE/(name+f'-source{count}.json'));assert rows==saved and rows[:61]==source and len(rows)==count;checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected-missing);assert checked['valid']==valid and checked['pair_failures']==collisions and checked['stock_failures']==0;write(OUT/(name+'-source-readback.json'),checked);cases.append({'case':name,'originals':count,'valid':valid,'source_collisions':collisions,'source_pairs':checked['same_sheet_pairs'],'holes':checked['cutouts'],'hole_vertices':checked['hole_vertices']})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','short12.json','fixed-poses.json','fixed-source61.json','control.json','negative.json','control-source62.json','negative-source66.json']]+list((BASE/'free').glob('*.json'))+[OLD/'audit/plan.json',OLD/'audit/checks.json',ROOT/'output/h5_transfer43_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,**counts,'all_source_domains_independently_verified':True,'integer_halfplanes_proved_conservative':True,'fixed_originals':61,'mandatory_moving_originals':5,'target_originals':66,'source_cases':cases,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
