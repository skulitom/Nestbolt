"""Audit serialized model and distinguish missing-bracket control from full target."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_fixed61_brackets_cp_reader_20261028 import inspect,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed61-five-brackets-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,BASE/'geometry-audit',MODEL]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');sol=load(MODEL/'partial-control-assignment.json');bad=load(MODEL/'negative-assignment.json');built=load(MODEL/'built.json');assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256'];checked,disabled=inspect(p,mp,load(BASE/'modes.json'),{mi:load(BASE/'free'/f'{mi:02d}.json')['cells'] for mi in range(2,10)},load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),sol,bad);failure=violations(p,sol);assert failure['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in disabled] and failure['cover_collisions']==0;write(OUT/'partial-target-rejections.json',failure)
partial=cp_model_pb2.CpModelProto();partial.CopyFrom(p)
for ix in disabled:partial.constraints[ix].linear.domain[:]=[0,0]
valid=evaluate(partial,sol,0);assert valid['expanded_pairs']==1 and not violations(partial,sol)['failed_constraints'];write(OUT/'partial-control-check.json',valid);(OUT/'partial-control-model.pb').write_bytes(partial.SerializeToString())
for ix in disabled:partial.constraints[ix].linear.domain[:]=[1,1]
assert partial.SerializeToString()==p.SerializeToString();negative=violations(p,bad);assert negative['failed_constraints']==[{'constraint':mp['no_overlap_2d'],'kind':'no_overlap_2d'}] and negative['cover_collisions']==20;write(OUT/'negative-target-rejections.json',negative)
inputs=[BASE/'plan.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',MODEL/'plan.json',MODEL/'model.pb',MODEL/'mapping.json',MODEL/'partial-hints.json',MODEL/'partial-control-assignment.json',MODEL/'negative-assignment.json',ROOT/'output/h5_fixed61_brackets_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-start,'positive_control_originals':62,'positive_rejected_by_exactly4_mandatory_constraints':True,'negative66_rejected':True,'negative_cover_collisions':20,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
