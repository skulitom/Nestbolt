from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,time
from shapely.geometry import Polygon,shape
from h5_four_column_physical_modes_20261107 import family_classes,physical_key
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-four-column-direct-model-20261107';SOURCE=ROOT/'output/h5-four-column-source-domains-20261107';OUT=BASE/'physical-mode-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();lib=load(SOURCE/'library.json');classes=family_classes(lib);expected={};pair_controls=[]
for family,modes in lib['family_modes'].items():
    if family=='cog':expected[family]=[0];continue
    source=lib['families'][family]['original'];center=lib['families'][family]['source_center'];rings=[];classrings=[];ids=[]
    for mode in modes:
        q=round(mode['rotation_radians']*2/math.pi)%4;matrix=[(1,0,0,1),(0,-1,1,0),(-1,0,0,-1),(0,1,-1,0)][q];a,b,c,d=matrix;sign=-1 if mode['mirrored'] else 1;points=[(a*sign*(F(x)-F(center[0]))+b*(F(y)-F(center[1])),c*sign*(F(x)-F(center[0]))+d*(F(y)-F(center[1]))) for x,y in source];rotations=[tuple(v[k:]+v[:k]) for v in [points,points[::-1]] for k in range(len(points))];key=min(rotations);rings.append(key)
        if key not in classrings:classrings.append(key)
        ids.append(classrings.index(key))
    expected[family]=ids
    for i,j in combinations(range(len(modes)),2):
        equivalent=rings[i]==rings[j];assert equivalent==(classes[family][i]==classes[family][j])
        if not equivalent:continue
        discrepancies=[]
        for kind in ['original','clearance']:
            polygons=[]
            for mi in [i,j]:
                mode=modes[mi];c,s=math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians']);sign=-1 if mode['mirrored'] else 1;px,py=center;polygons.append(Polygon([(sign*(x-px)*c-(y-py)*s,sign*(x-px)*s+(y-py)*c) for x,y in lib['families'][family][kind]]))
            area=polygons[0].symmetric_difference(polygons[1]).area;distance=polygons[0].hausdorff_distance(polygons[1]);assert area<1e-7 and distance<1e-10;discrepancies.append({'kind':kind,'area_mm2':area,'boundary_distance_mm':distance})
        free=[shape(modes[mi]['free_geometry']) for mi in [i,j]];assert free[0].symmetric_difference(free[1]).area<1e-7;pair_controls.append({'family':family,'modes':[i,j],'exact_original_filled_equivalence':True,'numerical_controls':discrepancies,'domain_symmetric_difference_mm2':free[0].symmetric_difference(free[1]).area})
assert classes==expected=={'bracket':list(range(8)),'insert':[0,1,0,1],'cog':[0]};initial=load(BASE/'initial-mode-values.json')['modes'];base=physical_key(lib,classes,initial);groups={};equivalent_initial=0;raw=0
for i,identity in enumerate(lib['identities'][:27]):
    for mode in lib['family_modes'][identity[0]]:
        if mode['mode']==initial[i]:continue
        changed=initial.copy();changed[i]=mode['mode'];key=physical_key(lib,classes,changed);raw+=1
        if key==base:equivalent_initial+=1
        else:groups.setdefault(key,[]).append([i,mode['mode']])
assert raw==113 and equivalent_initial==19 and len(groups)==75;write(OUT/'equivalent-mode-controls.json',pair_controls);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'family_classes':classes,'source_owner_mode_options':152,'physical_owner_mode_options':114,'raw_single_owner_alternatives':113,'equivalent_to_current_alternatives':19,'distinct_physical_neighbors':75,'equivalent_family_pairs':len(pair_controls),'scope':'Exact nominal filled-outline collision equivalence under noPIH. Actual output retains its chosen legal source transform and all holes. No repeated physical mode vector may open an optimizer call; continuous cogangles remain free, not a phase-based restart permission.','source_optimizer_calls':0,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),ROOT/'output/h5_four_column_physical_modes_20261107.py',SOURCE/'library.json',BASE/'initial-mode-values.json']}});print(load(OUT/'checks.json'))
