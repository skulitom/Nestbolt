from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8').replace('h5-direct-pose-audit-process-20261107','h5-four-column-initializer-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]","stages=[('prepare','prepare_h5_four_column_initializer_20261107.py',15)]")
with (ROOT/'output/run_h5_four_column_initializer_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
