from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_direct_pose_checkpoint_20261107.py').read_text(encoding='utf-8')
for old,new in [('h5-direct-pose-main-sync-20261107','h5-four-column-main-sync-20261107'),('9118d6cb9b04731443a87f3268d23d18b1765089','30a26572b89a515cd7b22ac1c9c7211583bc1f8c'),('42346053948','42349009443'),("prefixes=('benchmarks/results/h5-target-cog-repair-and-source-gradients-20261107','benchmarks/results/h5-direct-source-pose-construction-20261107')","prefixes=('benchmarks/results/h5-mixed-direct-source-construction-20261107','benchmarks/results/h5-four-column-source-domains-20261107')")]:
    assert old in source;source=source.replace(old,new)
marker='OUT.mkdir();write(OUT/';index=source.index(marker);source=source[:index]+"for name in ['h5-mixed-direct-source-construction-20261107','h5-four-column-source-domains-20261107']:\n    assert json.loads((ROOT/'benchmarks/results'/name/'archive-checks.json').read_bytes())['passed']\n"+source[index:]
with (ROOT/'output/push_h5_four_column_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
