from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-four-column-continuous-search-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-four-column-direct-model-20261107';F=ROOT/'output/h5-four-column-direct-checkpoint-20261107';D=BASE","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-four-column-source-domains-20261107'","front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==69","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F]+[ROOT/'output'/n for n in ['h5-four-column-initializer-process-20261107','h5-four-column-model-audit-process-20261107','h5-four-column-physical-audit-process-20261107','h5-four-column-response-audit-process-20261107','h5-four-column-main-sync-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*four*column*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_four_column_direct_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'historical-allocation-scope.json','historical-allocation-scope.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/exact-contact-pitches.json','exact-contact-pitches.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/seed-descent-controls.json','seed-descent-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'physical-mode-audit/checks.json','physical-mode-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/mode-selection-controls.json','mode-selection-controls.json'),(BASE/'response-audit/round-reconciliation.json','round-reconciliation.json'),(BASE/'response-audit/round-02-collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json'),(ROOT/'output/h5-four-column-initializer-process-20261107/process.json','preparation-process.json'),(ROOT/'output/h5-four-column-model-audit-process-20261107/process.json','model-audit-process.json'),(ROOT/'output/h5-four-column-response-audit-process-20261107/process.json','response-audit-process.json'),(ROOT/'output/h5-four-column-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
rounds=load(BASE/'response-audit/round-reconciliation.json');table='\n'.join(f"| {r['round']} | {r['source_pair_failures']} | {r['moving_pair_failures']} | {r['fixed_moving_pair_failures']} | {r['total_original_overlap_mm2']:.3f} |" for r in rounds)
report=f'''# Four-column continuous-angle search — 2026-11-07

The new 39-mover model completes its frozen **three calls and 149 orientation
trials** without a valid layout. Its best objective candidate still fails
**69 source pairs: 57 moving pairs and 12 against fixed parts**. All stock
checks pass. The actual summed overlap, including fixed parts, is
**56,517.717179 mm²**; the moving-only objective component is smaller and must
not be reported as the full source overlap. H2/H5 remain open at **60%
completed milestone weight**. No native call, allocation exclusion or release
follows. Four fixed arrangements and 440 allocations remain.

## Complete source initialization and model

The preceding source construction fixed 18 quarter-turned frames and nine
short-sheet parts. This model jointly moves the remaining eight brackets,
nineteen inserts and twelve freely rotating cogs, using all 741 moving pairs
and 90 continuous parameters. All legal bracket/insert modes remain available.

The deterministic initializer uses the charged source-derived 6.75° tooth
phase. [Exact rational checks]({NAME}/exact-contact-pitches.json) reconstruct
both axis contact bounds from 441 convex-piece pairs each. Both upward-rounded
row pitches are 261.766 mm. Translating certified free-region vertex coordinates
by these pitches gives 114 cog candidate centers. Orthogonal parts use cell
vertices, centroids and a fixed 9×9 grid, with explicit deterministic ties.
Every one of the **18,762 trial scores and selections** independently replays.
The full seed fails 39 source pairs and no stock edges; it is not a packing
witness. Complete new preparation takes **7.647472 s**, including all trials,
initial scoring, source validation and serialization. With the previously
charged source construction, preparation totals **11.244113 s**.

The objective equally weights actual moving filled-outline intersection area
and certified clearance-contour intersection area. It also adds four times
the squared distance of each center outside its entire certified free region.
This domain penalty is a heuristic for fixed-part avoidance; a finite positive
value does not establish clearance. Hard source stock bounds remain enforced.
All original contours and holes are retained, and filled outers enforce noPIH.
Internal convex-cell seams are not treated as physical obstacles.

[The complete model audit]({NAME}/model-audit.json) verifies 152 owner/mode
bindings, 114 dynamic mode vectors, 152 independent full objective scores,
861 whole-region distance controls and 508 distance derivatives. It also
compares 156 scalar/batched source gradients, checks [180 central-coordinate
derivatives]({NAME}/derivative-controls.json), [three seed descent steps]({NAME}/seed-descent-controls.json)
and [ten deliberate corruptions]({NAME}/negative-controls.json). Shared-edge
and nonconvex nearest-point conventions remain explicit; no global convergence
claim is made. All model checks pass before optimization.

## Physical equivalence and one bounded pipeline

[An independent exact nominal-outline audit]({NAME}/physical-mode-audit.json)
groups equivalent insert orientations. It verifies that the 152 source mode
options reduce to 114 physical owner options for filled-outline collision
purposes. Of 113 single-owner alternatives, nineteen reproduce the current
physical geometry, and the others form 75 distinct physical neighbors.
Actual output still retains its selected legal transform and all holes.
Equivalent modes cannot reopen an optimized physical mode vector.

The frozen pipeline permits one initial call of at most16 seconds and at most
two changed-physical-mode calls of12 seconds each. Each later call selects the
lowest full-objective unvisited neighbor of the best saved candidate. The
neighbor need not improve before optimization; every worse result is retained
and compared with the global best. This policy was fixed before execution.
There are no random restarts, repeated physical vectors, adaptive weights or
extensions. The 60-second algorithm,90-second shared,2GiB and four-second
source-reserve limits include all consumed preparation and runtime.

All three calls stop on time and return no numerical convergence result.
[Independent replay]({NAME}/response-audit.json) verifies **240 saved points,
271 evaluations, 149 distinct mode trials**, all skipped equivalent/visited
vectors and every selected clamp. The third mode proposal initially increases
the objective by273.294814 mm², then reduces it during optimization; that
increase is preserved. The best combined objective falls from243,180.485079
to94,988.169864 mm², but the original-source results remain invalid:

| Call | Failed source pairs | Moving–moving | Fixed–moving | Total source overlap (mm²) |
| --- | ---: | ---: | ---: | ---: |
{table}

Every candidate is reconstructed from all66 originals:1,632 same-sheet pairs,
264 stock edges,90 holes and10,026 hole vertices. [The final failures]({NAME}/source-failures.json)
contain61 positive-area intersections and eight clearance-only failures.
Nine centers lie outside their certified free regions. The fixed-part
collisions contribute14,636.360306 mm² beyond the moving-only area of
41,881.356872 mm². Lower heuristic penalties do not imply source validity,
material savings or a better valid part count.

The three optimizer-slice overruns are **0.026402,0.141130 and0.152586 s**.
All are preserved within complete algorithm/shared totals of
**54.960524 /55.032120 s**. [All five processes close]({NAME}/closed-search-process.json),
with94,212,096 bytes peak committed memory. The separate [response audit]({NAME}/response-audit-process.json)
takes39.874351 s and also closes normally. The pipeline is closed by its
three-call limit; unused time does not authorize another call or a reset clock.

## Next scope and repository state

[Historical review]({NAME}/historical-allocation-scope.json) confirms an older
eight-bracket/five-insert short sheet and a closed fixed29 search for its
remaining four brackets, five inserts and fifteen cogs. That search allowed
four finite cog angles and failed40 pairs and five stock checks. Neither the
allocation nor its old initialization is claimed as new.

[Next reconcile the current allocation ledger]({NAME}/next-step.json) and assess
whether a source-derived model with all fifteen continuous cog angles provides
a genuinely different scope, with all24 movers and63 continuous parameters.
It would retain276 moving pairs. Its original geometry, complete provenance,
deterministic initialization and all controls must be established before a
new bounded search. No successor geometry, initializer, model or call is
prepared. The current candidate and all earlier calls remain closed.

All66 source validation, native acceptance, material, the unchanged H5 matrix
and production UI/CLI/MCP parity remain required. The H2 gate remains open
under the earlier user decision. [Prior checkpoints reached main89afabf2]({NAME}/prior-main-push-receipt.json)
after all six previous checks passed, preserving52 remote files. [Five current
CI jobs pass]({NAME}/main-ci-at-review.json); Windows native CI remains live at
review. This checkpoint awaits the ordinary push gate. Production, README and
releases are unchanged.

[Raw evidence]({NAME}/raw-manifest.json) preserves {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) preserve the full consumed
lineage. Independent archive readback is required before commit.
'''
for old,new in {'at most16':'at most 16','of12':'of 12','algorithm,90':'algorithm, 90','shared,2GiB':'shared, 2 GiB','by273':'by 273','from243':'from 243','to94':'to 94','all66':'all 66','originals:1,632':'originals: 1,632','edges,90':'edges, 90','and10,026':'and 10,026','contain61':'contain 61','contribute14':'contribute 14','0.026402,0.141130 and0.152586':'0.026402, 0.141130 and 0.152586','with94':'with 94','takes39':'takes 39','failed40':'failed 40','all24':'all 24','and63':'and 63','retain276':'retain 276','main89afabf2':'main 89afabf2','preserving52':'preserving 52'}.items():report=report.replace(old,new)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 four-column continuous-angle search:** [independent initializer/model/response audits]({link}) replay 18,762 initial choices, 152 owner/mode bindings, 861 region-distance controls, 508 region derivatives and 180 full-coordinate checks. Exact physical-mode equivalence prevents 180-degree insert repeats. Three distinct physical-vector calls and 149 orientation trials close at the declared call limit; all 240 saved points and 271 evaluations replay. The final candidate fails 69 source pairs: 57 moving pairs and 12 against fixed parts, with no stock failures. Actual full source overlap is 56,517.717179 mm², including 14,636.360306 mm² against fixed parts; the finite domain penalty does not prove clearance. Complete preparation is 11.244113 s and algorithm/shared totals are 54.960524/55.032120 s. All three slice overruns are preserved and every process closes. No native call or allocation exclusion follows. Next reconcile the historical eight-bracket/five-insert short allocation and assess a new all-fifteen-continuous-angle source model; no successor is prepared and no closed call is resumed. Four fixed arrangements and 440 allocations remain; H2/H5 stay at 60%. Main 89afabf2 has five passed jobs and live Windows native CI at review. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
path=ROOT/'docs/STATUS.md';s=path.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a);intro=f'''Latest H5 evidence: [four-column continuous-angle search](../benchmarks/results/{NAME}.md).
The complete 39-mover/90-parameter model passes independent source, initializer,
region-distance, physical-mode and gradient controls. Its frozen three-call search
closes without a valid layout after 149 orientation trials and 271 evaluations.
The final candidate fails 69 pairs, including 12 against fixed originals; all stock
checks pass. Actual full source overlap is 56,517.717179 mm². A lower finite domain
penalty does not prove fixed-part clearance. All calls and their slice overruns are
preserved within 54.960524/55.032120 s algorithm/shared totals, including preparation.
Next reconcile the historical eight-bracket/five-insert short-sheet allocation and
assess a changed source model with fifteen continuous cog angles and all 24 remaining
movers. No successor geometry, initializer, complete model or optimizer is prepared.
Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%.
Full source/native/material validation, production parity and the unchanged H5 matrix
remain required. Main 89afabf2 has five passed jobs and a live Windows native job.
This checkpoint awaits the ordinary push gate. No release qualifies.
''';path.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
