"""Source-center poses with full pair areas and whole-free-region distances."""
import math
import numpy as np
import shapely
from shapely.geometry import Polygon,shape,Point
from h5_direct_pose_model_20261107 import transformed,boundary_gradient
from h5_mixed_direct_pose_20261107 import source_pose,source_rows,owner_shapes,pair_energy

def compile_model(library,modes,values):
    n=len(library['identities']);parameters=library['continuous_parameters'];assert len(modes)==n and len(values)==parameters;owners=[];bounds=[]
    for i,(identity,mi) in enumerate(zip(library['identities'],modes)):
        mode=library['family_modes'][identity[0]][mi];assert mode['mode']==mi;bb=mode['stock_center_bounds'];bounds.extend([[bb[0],bb[2]],[bb[1],bb[3]]]);free=identity[0]=='cog';owners.append({'owner':i,'identity':identity,'mode':mi,'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'source_center':library['families'][identity[0]]['source_center'],'angle_coordinate':library['angle_coordinate_start']+i-library['first_cog_owner'] if free else None,'angle_scale_mm':library['angle_scale_mm'] if free else None,'free_geometry':mode['free_geometry']})
    bounds.extend(library['angle_bounds']);return {'families':library['families'],'owners':owners,'pairs':library['pairs'],'fixed_source_rows':library['fixed_source_rows'],'parameters':parameters,'bounds':bounds,'initial':np.clip(values,np.asarray(bounds)[:,0],np.asarray(bounds)[:,1]).tolist(),'objective_weights':{'original_area':1,'clearance_area':1,'free_region_squared_distance':4}}

def region_value_gradient(region,point):
    p=Point(point)
    if region.covers(p):return 0.,np.zeros(2)
    nearest=np.asarray(shapely.get_coordinates(shapely.shortest_line(p,region))[-1]);delta=np.asarray(point)-nearest;return float(delta@delta),2*delta

class Objective:
    def __init__(self,model):
        self.model=model;self.regions=[shape(o['free_geometry']) for o in model['owners']];self.left=np.asarray([p[0] for p in model['pairs']]);self.right=np.asarray([p[1] for p in model['pairs']])
    def geometry(self,values,lines=True):
        result=[]
        for kind in ['original','clearance']:
            entries=[]
            for o in self.model['owners']:
                v=transformed(self.model['families'][o['identity'][0]][kind],source_pose(o,values));entries.append((v,Polygon(v),shapely.linestrings(np.stack([v,np.roll(v,-1,axis=0)],axis=1)) if lines else None,[float(values[2*o['owner']]),float(values[2*o['owner']+1])]))
            result.append(entries)
        return result
    def evaluate(self,values,details=False):
        g=np.zeros(self.model['parameters']);levels=[];records=[];shared=0.;segments=0
        for kind,entries in zip(['original','clearance'],self.geometry(values)):
            shapes=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]));levels.append(float(np.sum(areas)))
            for index in np.flatnonzero(areas>0):
                i,j=self.model['pairs'][index]
                if details:records.append({'kind':kind,'owners':[i,j],'area_mm2':float(areas[index])})
                for own,other in [(i,j),(j,i)]:
                    v,poly,lines,pivot=entries[own];gg,n,coincident=boundary_gradient(v,lines,entries[other][1],pivot);g[2*own:2*own+2]+=gg[:2];o=self.model['owners'][own]
                    if o['angle_coordinate'] is not None:g[o['angle_coordinate']]+=gg[2]/o['angle_scale_mm']
                    shared+=coincident;segments+=n
        fixed=0.;violations=[];weight=self.model['objective_weights']['free_region_squared_distance']
        for i,region in enumerate(self.regions):
            value,gg=region_value_gradient(region,values[2*i:2*i+2]);fixed+=value;g[2*i:2*i+2]+=weight*gg
            if details and value>0:violations.append({'owner':i,'squared_distance_mm2':value,'unweighted_gradient':gg.tolist()})
        total=sum(levels)+weight*fixed;assert np.isfinite(total) and np.all(np.isfinite(g))
        if details:return total,g,{'original_overlap_area_mm2':levels[0],'clearance_overlap_area_mm2':levels[1],'free_region_squared_distance_mm2':fixed,'weighted_free_region_penalty_mm2':weight*fixed,'free_region_violations':violations,'positive_terms':records,'clipped_segments':segments,'coincident_boundary_length_mm':shared}
        return total,g
    def score(self,values):
        total=0.
        for entries in self.geometry(values,False):
            shapes=np.asarray([e[1] for e in entries],dtype=object);total+=float(np.sum(shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]))))
        return total+self.model['objective_weights']['free_region_squared_distance']*sum(region_value_gradient(region,values[2*i:2*i+2])[0] for i,region in enumerate(self.regions))
