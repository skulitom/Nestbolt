"""Exact nominal quarter-turn filled-outline equivalence for noPIH search."""
from fractions import Fraction as F
import math

def family_classes(library):
    result={}
    for family,modes in library['family_modes'].items():
        if family=='cog':result[family]=[0];continue
        source=library['families'][family]['original'];px,py=map(F,library['families'][family]['source_center']);seen=[];classes=[]
        for mode in modes:
            quarter=round(mode['rotation_radians']/(math.pi/2))%4;assert abs(math.remainder(mode['rotation_radians']-quarter*math.pi/2,math.tau))<1e-12;sign=-1 if mode['mirrored'] else 1;points=[]
            for x,y in source:
                x=sign*(F(x)-px);y=F(y)-py
                points.append([(x,y),(-y,x),(-x,-y),(y,-x)][quarter])
            edges=tuple(sorted(tuple(sorted([a,b])) for a,b in zip(points,points[1:]+points[:1])))
            if edges not in seen:seen.append(edges)
            classes.append(seen.index(edges))
        result[family]=classes
    return result

def physical_key(library,classes,modes):
    return tuple(classes[identity[0]][mi] for identity,mi in zip(library['identities'],modes))
