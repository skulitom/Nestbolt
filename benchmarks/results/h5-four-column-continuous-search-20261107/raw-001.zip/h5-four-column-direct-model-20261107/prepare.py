"""One fixed source-contact grid initializer and complete dynamic model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,LineString,Point,shape
from h5_four_column_direct_model_20261107 import compile_model,Objective,owner_shapes,pair_energy,source_rows
from h5_four_column_direct_readback_20261107 import verify
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-four-column-source-domains-20261107';PREVIOUS=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=ROOT/'output/h5-four-column-direct-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');checked=load(SOURCE/'audit/checks.json');assert checked['passed'];charge=checked['complete_preparation_seconds'];inputs=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_four_column_direct_model_20261107.py','h5_four_column_direct_readback_20261107.py','h5_direct_pose_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/checks.json']]+[PREVIOUS/n for n in ['partitions.json','short-analytic-phase.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_prior_preparation_seconds':charge,'method':'One deterministic initializer for the new39-mover source construction. Use the alreadycharged source-derived shortsheet toothphase;derive both horizontalandvertical pitches afresh fromall441sourceconvexpiece NFPsections with.23squaregap. Formcogcandidatecoordinate sets by translating everycertifiedfreepolygon vertex coordinate by integerpitchmultiples withinitsdomainbounds;crossandfilterbythewholefreegeometry. Place12cogs sequentially atminimum actualoriginal+clearance overlap,thenlowY/lowX. Place8brackets then19inserts,alllegalmodes:eachconvexcell vertices,centroidand9x9bboxgridpointsthatarecoveredbythatcell. Deduplicatepermode,scoreagainstpreviouslyplacedoriginals andselectby(score,mode,Y,X). Preserveallcandidatesandselections. No optimizer orreseed. Compile90parameters with741original+clearance pairareas plus4times squareddistance tothewholecertifiedfreeunion;hardworldstockbboxbounds. Sourcecenterpivots foralloriginals;12full2pi scaledangles. Nonconvexregionseams arenotobstacles. Fullmodel/gradient/regionreadback required before anyfutureboundedpipeline.','cog_order':'copyorder','orthogonal_order':'brackets theninserts inlibraryorder','orthogonal_grid_fractions':[i/8 for i in range(9)],'orthogonal_tie_order':['score_mm2','mode','center_y','center_x'],'cog_tie_order':['score_mm2','center_y','center_x'],'candidate_cap':30000,'preparation_internal_target_seconds':12,'preparation_process_cap_seconds':15,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib=load(SOURCE/'library.json');assert digest(SOURCE/'library.json')==checked['library_sha256'];angle=math.radians(load(PREVIOUS/'short-analytic-phase.json')['rotation_degrees']);c,s=math.cos(angle),math.sin(angle);pieces=[np.asarray([[x*c-y*s,x*s+y*c] for x,y in p]) for p in load(PREVIOUS/'partitions.json')['cog']['pieces']];square=np.array(list(product([-.23,.23],repeat=2)));horizontal=LineString([(-1000,0),(1000,0)]);vertical=LineString([(0,-1000),(0,1000)]);ends=[[],[]]
for a,b in product(pieces,pieces):
    diff=(a[:,None,:]-b[None,:,:]).reshape(-1,2);obstacle=MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull
    for k,line in enumerate([horizontal,vertical]):
        section=obstacle.intersection(line)
        if not section.is_empty:ends[k].append(section.bounds[k+2])
pitches=[math.ceil((max(v)+.000002)*1000)/1000 for v in ends];write(OUT/'source-contact-pitches.json',{'angle_radians':angle,'source_piece_pairs':441,'maximum_forbidden_translation_mm':[max(v) for v in ends],'pitches_mm':pitches})
cogmode=lib['family_modes']['cog'][0];region=shape(cogmode['free_geometry']);bb=cogmode['stock_center_bounds'];vertices=[v for cell in cogmode['convex_center_cells'] for v in cell];axes=[]
for k in [0,1]:
    coords=set()
    for point in vertices:
        for n in range(math.ceil((bb[k]-point[k])/pitches[k]),math.floor((bb[k+2]-point[k])/pitches[k])+1):coords.add(point[k]+n*pitches[k])
    axes.append(sorted(coords))
candidates=sorted(([x,y] for x,y in product(*axes) if region.covers(Point(x,y))),key=lambda p:(p[1],p[0]));assert candidates;write(OUT/'cog-contact-candidates.json',{'axes':axes,'centers':candidates});values=np.zeros(90);modes=[0]*39;placed=[];records=[];trialcount=0
for i in range(27,39):
    trials=[]
    for xy in candidates:
        value=pair_energy(owner_shapes(lib,'cog',0,xy,angle),placed);trials.append({'mode':0,'center':xy,'score_mm2':value});trialcount+=1
    best=min(trials,key=lambda t:(t['score_mm2'],t['center'][1],t['center'][0]));values[2*i:2*i+2]=best['center'];values[78+i-27]=lib['angle_scale_mm']*angle;placed.append(owner_shapes(lib,'cog',0,best['center'],angle));records.append({'owner':i,'identity':lib['identities'][i],'candidates':trials,'selected':best});assert trialcount<=30000 and time.perf_counter()-start<12
mode_candidates={}
for family in ['bracket','insert']:
    mode_candidates[family]=[]
    for mode in lib['family_modes'][family]:
        points=set()
        for cell in mode['convex_center_cells']:
            polygon=Polygon(cell);points.update(map(tuple,cell));points.add(tuple(polygon.centroid.coords[0]));x0,y0,x1,y1=polygon.bounds
            for xi,yi in product(range(9),repeat=2):
                point=(x0+xi/8*(x1-x0),y0+yi/8*(y1-y0))
                if polygon.covers(Point(point)):points.add(point)
        mode_candidates[family].append({'mode':mode['mode'],'centers':[list(p) for p in sorted(points,key=lambda p:(p[1],p[0]))]})
write(OUT/'orthogonal-candidates.json',mode_candidates)
for i in range(27):
    family=lib['identities'][i][0];trials=[]
    for option in mode_candidates[family]:
        for xy in option['centers']:
            value=pair_energy(owner_shapes(lib,family,option['mode'],xy),placed);trials.append({'mode':option['mode'],'center':xy,'score_mm2':value});trialcount+=1
    best=min(trials,key=lambda t:(t['score_mm2'],t['mode'],t['center'][1],t['center'][0]));modes[i]=best['mode'];values[2*i:2*i+2]=best['center'];placed.append(owner_shapes(lib,family,modes[i],best['center']));records.append({'owner':i,'identity':lib['identities'][i],'candidates':trials,'selected':best});assert trialcount<=30000 and time.perf_counter()-start<12
write(OUT/'initializer-trials.json',records);model=compile_model(lib,modes,values);assert verify(model,lib,modes,values);write(OUT/'initial-mode-values.json',{'modes':modes,'values':values.tolist()});write(OUT/'model.json',model);rows=source_rows(model,values);source=audit(load(JOB),rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert source['stock_failures']==0;write(OUT/'seed-source66.json',rows);write(OUT/'seed-source-checks.json',source);energy,g,details=Objective(model).evaluate(values,True);assert details['free_region_squared_distance_mm2']<1e-16;write(OUT/'initial-objective.json',{'energy_mm2':energy,'gradient':g.tolist(),**details});assert time.perf_counter()-start<12;checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_trials':trialcount,'cog_candidate_centers':len(candidates),'orthogonal_candidates_by_family':{f:sum(len(v['centers']) for v in a) for f,a in mode_candidates.items()},'originals':66,'moving_originals':39,'moving_pairs':741,'parameters':90,'initial_objective_mm2':energy,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'initial_free_region_penalty_mm2':details['weighted_free_region_penalty_mm2'],'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_valid66':source['valid'],'complete_prior_preparation_seconds':charge,'optimizer_calls':0,'model_sha256':digest(OUT/'model.json'),'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
