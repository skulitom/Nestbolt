from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,time,copy,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,Point,shape
from h5_exact_convex_partition_tools_20261029 import hull,cross
from h5_four_column_direct_model_20261107 import compile_model,Objective,region_value_gradient
from h5_four_column_direct_readback_20261107 import verify
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-four-column-source-domains-20261107';BASE=ROOT/'output/h5-four-column-direct-model-20261107';PREVIOUS=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(SOURCE/'library.json');checked=load(SOURCE/'audit/checks.json');assert checked['passed'] and digest(SOURCE/'library.json')==checked['library_sha256'];saved=load(BASE/'initial-mode-values.json');modes=saved['modes'];values=np.asarray(saved['values']);model=load(BASE/'model.json');assert model==compile_model(lib,modes,values) and verify(model,lib,modes,values);job=load(JOB);parts={p['id']:p for p in job['parts']};radius=lib['angle_scale_mm'];angle=math.radians(load(PREVIOUS/'short-analytic-phase.json')['rotation_degrees']);c,s=map(F,[math.cos(angle),math.sin(angle)]);pieces=[[(F(x)*c-F(y)*s,F(x)*s+F(y)*c) for x,y in p] for p in load(PREVIOUS/'partitions.json')['cog']['pieces']];square=list(product([-F(.23),F(.23)],repeat=2));maximum=[None,None]
for a,b in product(pieces,pieces):
    polygon=hull([(x[0]-y[0]+z[0],x[1]-y[1]+z[1]) for x,y,z in product(a,b,square)])
    for axis in [0,1]:
        other=1-axis;ends=[p[axis] for p in polygon if p[other]==0]
        for x,y in zip(polygon,polygon[1:]+polygon[:1]):
            if x[other]*y[other]<0:ends.append(x[axis]-x[other]*(y[axis]-x[axis])/(y[other]-x[other]))
        if ends:maximum[axis]=max([max(ends)]+([] if maximum[axis] is None else [maximum[axis]]))
contact=load(BASE/'source-contact-pitches.json');pitches=[math.ceil((float(v)+.000002)*1000)/1000 for v in maximum];assert contact['pitches_mm']==pitches and contact['angle_radians']==angle and contact['source_piece_pairs']==441 and all(abs(contact['maximum_forbidden_translation_mm'][i]-float(maximum[i]))<1e-9 and F(pitches[i])>maximum[i] for i in [0,1]);write(OUT/'exact-contact-pitches.json',{'maximum_forbidden_translation_mm':list(map(str,maximum)),'chosen_pitches_mm':pitches,'piece_pair_sections':882})
def independent_shapes(family,mi,xy,theta=0.):
    mm=lib['family_modes'][family][mi];theta=theta if family=='cog' else mm['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mm['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx=xy[0]-(sign*px*c-py*s);ty=xy[1]-(sign*px*s+py*c);return [Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']]
def independent_pair_score(polys,placed):return sum(p.intersection(other[k]).area for k,p in enumerate(polys) for other in placed)
cog=lib['family_modes']['cog'][0];region=shape(cog['free_geometry']);bb=cog['stock_center_bounds'];vertices=[v for cell in cog['convex_center_cells'] for v in cell];axes=[]
for k in [0,1]:
    vv=set()
    for p in vertices:
        for n in range(math.ceil((bb[k]-p[k])/pitches[k]),math.floor((bb[k+2]-p[k])/pitches[k])+1):vv.add(p[k]+n*pitches[k])
    axes.append(sorted(vv))
centers=sorted(([x,y] for x,y in product(*axes) if region.covers(Point(x,y))),key=lambda p:(p[1],p[0]));assert load(BASE/'cog-contact-candidates.json')=={'axes':axes,'centers':centers}
orth={}
for family in ['bracket','insert']:
    orth[family]=[]
    for mode in lib['family_modes'][family]:
        points=set()
        for cell in mode['convex_center_cells']:
            p=Polygon(cell);points.update(map(tuple,cell));points.add(tuple(p.centroid.coords[0]));x0,y0,x1,y1=p.bounds
            for xi,yi in product(range(9),repeat=2):
                point=(x0+xi/8*(x1-x0),y0+yi/8*(y1-y0))
                if p.covers(Point(point)):points.add(point)
        orth[family].append({'mode':mode['mode'],'centers':[list(p) for p in sorted(points,key=lambda p:(p[1],p[0]))]})
assert orth==load(BASE/'orthogonal-candidates.json');records=load(BASE/'initializer-trials.json');assert [r['owner'] for r in records]==list(range(27,39))+list(range(27));placed=[];trials=0;total=0.
for r in records:
    i=r['owner'];identity=lib['identities'][i];family=identity[0];assert r['identity']==identity;options=[{'mode':0,'centers':centers}] if family=='cog' else orth[family];expected=[]
    for option in options:
        for xy in option['centers']:
            ps=independent_shapes(family,option['mode'],xy,angle);value=independent_pair_score(ps,placed);actual=r['candidates'][len(expected)];assert actual['mode']==option['mode'] and actual['center']==xy and abs(actual['score_mm2']-value)<1e-7;expected.append(actual);trials+=1
    best=min(expected,key=lambda t:(t['score_mm2'],t['mode'],t['center'][1],t['center'][0]));assert best==r['selected'] and modes[i]==best['mode'] and values[2*i:2*i+2].tolist()==best['center'];placed.append(independent_shapes(family,modes[i],best['center'],angle));total+=best['score_mm2']
    if family=='cog':assert values[78+i-27]==radius*angle
assert trials==18762
def source_rows(mm,x):
    rows=lib['fixed_source_rows'].copy()
    for i,o in enumerate(mm['owners']):
        family=o['identity'][0];mode=lib['family_modes'][family][o['mode']];theta=x[78+i-27]/radius if family=='cog' else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];rows.append({'part_id':family,'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[x[2*i]-(sign*px*c-py*s),x[2*i+1]-(sign*px*s+py*c)]}})
    return rows
rows=source_rows(model,values.tolist());assert rows==load(BASE/'seed-source66.json');source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert source==load(BASE/'seed-source-checks.json') and source['stock_failures']==0 and source['pair_failures']==39;obj=Objective(model);energy,g,details=obj.evaluate(values,True);initial=load(BASE/'initial-objective.json');assert initial=={'energy_mm2':energy,'gradient':g.tolist(),**details} and abs(total-energy)<1e-7 and details['free_region_squared_distance_mm2']==0
# Independent point/segment oracle on the whole free union, including boundaries.
def rings(geometry):
    if geometry.geom_type=='Polygon':return [geometry.exterior]+list(geometry.interiors)
    return [r for child in geometry.geoms for r in rings(child)]
def winding(point,ring):
    x,y=map(F,point);pp=[tuple(map(F,p)) for p in list(ring.coords)];n=0
    for a,b in zip(pp,pp[1:]):
        side=cross(a,b,(x,y))
        if side==0 and min(a[0],b[0])<=x<=max(a[0],b[0]) and min(a[1],b[1])<=y<=max(a[1],b[1]):return None
        if a[1]<=y<b[1] and side>0:n+=1
        elif b[1]<=y<a[1] and side<0:n-=1
    return n
def covers(geometry,point):
    if geometry.geom_type!='Polygon':return any(covers(p,point) for p in geometry.geoms)
    outer=winding(point,geometry.exterior)
    if outer is None:return True
    if not outer:return False
    for ring in geometry.interiors:
        inner=winding(point,ring)
        if inner is None:return True
        if inner:return False
    return True
def domain_oracle(region,point):
    if covers(region,point):return 0.,np.zeros(2)
    possibilities=[];p=np.asarray(point)
    for ring in rings(region):
        vv=list(ring.coords)
        for a,b in zip(vv,vv[1:]):
            a=np.asarray(a);d=np.asarray(b)-a;tt=np.clip((p-a)@d/(d@d),0,1);delta=p-a-tt*d;possibilities.append((float(delta@delta),delta))
    best=min(possibilities,key=lambda x:x[0]);return best[0],2*best[1]
domain_controls=[];domain_derivatives=0
for family,options in lib['family_modes'].items():
    for mode in options:
        region=shape(mode['free_geometry']);points=[]
        for cell in mode['convex_center_cells']:
            poly=Polygon(cell);points.append(tuple(poly.centroid.coords[0]));points.extend(tuple(v) for v in cell)
            for a,b in zip(cell,cell[1:]+cell[:1]):points.append(((a[0]+b[0])/2,(a[1]+b[1])/2))
        for ring in rings(region):
            for x,y in list(ring.coords)[:-1]:points.extend([(x+dx,y+dy) for dx,dy in [(1.173,.217),(-1.173,.217),(.173,1.217),(.173,-1.217)]])
        for point in points:
            actual,gg=region_value_gradient(region,point);expected,eg=domain_oracle(region,point);assert abs(actual-expected)<1e-7 and np.max(np.abs(gg-eg))<1e-6
            if actual>1e-8:
                for k in [0,1]:
                    plus=list(point);minus=list(point);plus[k]+=1e-5;minus[k]-=1e-5;numeric=(domain_oracle(region,plus)[0]-domain_oracle(region,minus)[0])/2e-5;assert abs(numeric-gg[k])<.001+1e-6*abs(gg[k]);domain_derivatives+=1
            domain_controls.append({'family':family,'mode':mode['mode'],'point':point,'squared_distance_mm2':actual,'gradient':gg.tolist()})
write(OUT/'region-distance-controls.json',domain_controls)
def independent_energy(mm,x):
    ps=[independent_shapes(o['identity'][0],o['mode'],x[2*i:2*i+2],x[78+i-27]/radius if i>=27 else 0.) for i,o in enumerate(mm['owners'])];return sum(ps[i][k].intersection(ps[j][k]).area for i,j in lib['pairs'] for k in [0,1])+4*sum(domain_oracle(shape(o['free_geometry']),x[2*i:2*i+2])[0] for i,o in enumerate(mm['owners']))
vectors=1;bindings=0;scorecases=0
for i,identity in enumerate(lib['identities']):
    for m in lib['family_modes'][identity[0]]:
        chosen=modes.copy();chosen[i]=m['mode'];mm=compile_model(lib,chosen,values);assert verify(mm,lib,chosen,values);bindings+=1;vectors+=chosen!=modes;xx=mm['initial'];actual=Objective(mm).score(xx);assert abs(actual-independent_energy(mm,xx))<1e-6;scorecases+=1
assert vectors==114 and bindings==152
reference=np.zeros(90);gradient_cases=0
for entries in obj.geometry(values):
    for i,j in lib['pairs']:
        if entries[i][1].intersection(entries[j][1]).area<=0:continue
        for own,other in [(i,j),(j,i)]:
            gg,_,_=moving_boundary_gradient(entries[own][1],entries[other][1],entries[own][3]);reference[2*own:2*own+2]+=gg[:2]
            if own>=27:reference[78+own-27]+=gg[2]/radius
            gradient_cases+=1
assert np.max(np.abs(reference-g))<1e-7
derivatives=[]
for variation in [0,1]:
    chosen=modes.copy()
    if variation:chosen[:27]=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen[:27])]
    mm=compile_model(lib,chosen,values);bounds=np.asarray(mm['bounds']);margin=.03+np.arange(90)*.00037;point=np.clip(np.asarray(mm['initial'])+.137*np.sin(np.arange(90)*2**.5+.2+variation),bounds[:,0]+margin,bounds[:,1]-margin);val,gg=Objective(mm).evaluate(point);assert abs(val-independent_energy(mm,point))<1e-6;errors=[]
    for k in range(90):
        plus=point.copy();minus=point.copy();plus[k]+=1e-4;minus[k]-=1e-4;numeric=(independent_energy(mm,plus)-independent_energy(mm,minus))/2e-4;error=abs(numeric-gg[k]);assert error<.02+3e-6*abs(gg[k]),(variation,k,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':90,'maximum_absolute_error':max(errors)})
write(OUT/'derivative-controls.json',derivatives);directions=[];bounds=np.asarray(model['bounds'])
for step in [1e-7,1e-6,1e-5]:
    point=np.clip(values-step*g,bounds[:,0],bounds[:,1]);after=independent_energy(model,point);assert after<energy;directions.append({'step':step,'before':energy,'after':after})
write(OUT/'seed-descent-controls.json',directions);negatives=[]
for kind in ['mode','mirror','pivot','angle','domain','stock','coordinate','pair','parameter_count','domain_weight']:
    mm=copy.deepcopy(model)
    if kind=='mode':mm['owners'][0]['rotation_radians']+=.01
    elif kind=='mirror':mm['owners'][0]['mirrored']=not mm['owners'][0]['mirrored']
    elif kind=='pivot':mm['owners'][0]['source_center'][0]+=1
    elif kind=='angle':mm['owners'][27]['angle_coordinate']=79
    elif kind=='domain':mm['owners'][0]['free_geometry']['coordinates'][0][0][0]+=1
    elif kind=='stock':mm['bounds'][0][0]+=1
    elif kind=='coordinate':mm['initial'][0]+=1
    elif kind=='pair':mm['pairs'].pop()
    elif kind=='parameter_count':mm['parameters']=89
    else:mm['objective_weights']['free_region_squared_distance']=3
    caught=False
    try:verify(mm,lib,modes,values)
    except AssertionError:caught=True
    assert caught;negatives.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',negatives);oldtool=PREVIOUS/'audit';controls=load(oldtool/'optimizer-controls.json');provenance=load(oldtool/'tool-provenance.json');assert controls['passed']
for name,r in provenance['tool_files'].items():assert digest(ROOT/name)==r['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',provenance);prep=load(ROOT/'output/h5-four-column-initializer-process-20261107/prepare.json');assert prep['passed'] and prep['job']['closed'];charge=checked['complete_preparation_seconds']+prep['complete_seconds'];inputs=[Path(__file__),JOB,ROOT/'output/h5-four-column-initializer-process-20261107/prepare.json']+[ROOT/'output'/n for n in ['h5_four_column_direct_model_20261107.py','h5_four_column_direct_readback_20261107.py','h5_direct_pose_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_original_overlap_gradient_v2_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/checks.json']]+[BASE/n for n in ['plan.json','checks.json','model.json','source-contact-pitches.json','cog-contact-candidates.json','orthogonal-candidates.json','initializer-trials.json','initial-mode-values.json','initial-objective.json','seed-source66.json','seed-source-checks.json']]+[PREVIOUS/n for n in ['partitions.json','short-analytic-phase.json','audit/optimizer-controls.json','audit/tool-provenance.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'ExactsourceNFPaxis replay;independentdeterministiccandidate andall18762trialselection replay;all66originalsourceidentity/pose/pair/stock/holechecks. Independentlyverify90parameter model,152owner-mode bindings,114modevectors,all741moving pairs,whole-free-union inside/outside/cornerdistanceoracles andtheirderivatives,scalar/batchedsourcegradients,180centralcoordinates,3seeddescentstepsand10corruptions. Verificationonly;nooptimizercall.'});checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_trials_verified':trials,'source_nfp_axis_piece_sections':882,'source_owner_mode_bindings':bindings,'dynamic_mode_vectors':vectors,'independent_full_score_controls':scorecases,'region_distance_controls':len(domain_controls),'region_distance_derivative_controls':domain_derivatives,'scalar_batched_gradient_controls':gradient_cases,'independent_central_coordinates':180,'seed_descent_controls':3,'corruption_controls':10,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_valid66':False,'initial_objective_mm2':energy,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'complete_preparation_seconds':charge,'model_sha256':digest(BASE/'model.json'),'source_optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
