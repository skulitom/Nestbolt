"""Original filled-outline intersection area and rigid-pose boundary derivatives.

For an oriented boundary segment inside the other polygon, outward-normal
times length is (dy,-dx). Integrating rigid translation/rotation velocity over
that segment gives its area derivative. Endpoint velocity is affine, so the
midpoint is exact on a segment. Shared boundary segments are nonsmooth and
reported explicitly; callers must not treat them as certified derivatives.
At shared boundaries a half-weight symmetric convention is used and reported.
+It is not a unique classical derivative and requires directional controls.
+This is a heuristic overlap objective, not a clearance/stock validity test.
"""
import math
import numpy as np
from shapely.geometry import Polygon,LineString

def pose_polygon(part,pose):
    c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];outer=part['geometry'][0]['outer']
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in outer])

def line_parts(g):
    if g.is_empty:return []
    if g.geom_type=='LineString':return [g]
    if hasattr(g,'geoms'):return [p for child in g.geoms for p in line_parts(child)]
    return []

def moving_boundary_gradient(a,b,pivot):
    v=list(a.exterior.coords)[:-1]
    if sum(p[0]*q[1]-p[1]*q[0] for p,q in zip(v,v[1:]+v[:1]))<0:v.reverse()
    gradient=np.zeros(3);segments=0;coincident=0.
    for p,q in zip(v,v[1:]+v[:1]):
        edge=np.asarray(q)-p;den=float(edge@edge)
        if den==0:continue
        line=LineString([p,q]);coincident+=line.intersection(b.boundary).length
        # Shared boundary contributes half of the two one-sided conventions.
        # This matches symmetric coordinate differences, not a smooth derivative.
        for geometry,weight in [(line.intersection(b),1.),(line.intersection(b.boundary),-.5)]:
            for segment in line_parts(geometry):
                values=[float((np.asarray(x)-p)@edge/den) for x in segment.coords];lo=max(0.,min(values));hi=min(1.,max(values))
                if hi<=lo:continue
                d=weight*(hi-lo)*edge;normal=np.array([d[1],-d[0]]);mid=np.asarray(p)+(hi+lo)/2*edge;relative=mid-pivot;gradient[:2]+=normal;gradient[2]+=float(np.array([-relative[1],relative[0]])@normal);segments+=weight==1.
    return gradient,segments,coincident

def original_area_and_gradient(job,rows,moving,angular):
    parts={p['id']:p for p in job['parts']};shapes=[pose_polygon(parts[r['part_id']],r['transform']) for r in rows];identities=[(r['part_id'],r['copy_index']) for r in rows];indices={k:i for i,k in enumerate(moving)};angle_indices={k:2*len(moving)+i for i,k in enumerate(angular)};gradient=np.zeros(2*len(moving)+len(angular));energy=0.;records=[];segments=0;coincident=0.
    for i,a in enumerate(shapes):
        for j in range(i+1,len(shapes)):
            if rows[i]['sheet_id']!=rows[j]['sheet_id']:continue
            b=shapes[j];area=a.intersection(b).area;energy+=area
            if not area:continue
            record={'keys':[list(identities[i]),list(identities[j])],'area_mm2':area,'derivatives':[]}
            for n,own,other in [(i,a,b),(j,b,a)]:
                identity=identities[n]
                if identity not in indices:continue
                pivot=rows[n]['transform']['translation'];g,count,shared=moving_boundary_gradient(own,other,pivot);oi=indices[identity];gradient[2*oi:2*oi+2]+=g[:2]
                if identity in angle_indices:gradient[angle_indices[identity]]+=g[2]
                record['derivatives'].append({'identity':list(identity),'translation_and_rotation_about_source_origin':g.tolist(),'clipped_boundary_segments':count,'coincident_boundary_length_mm':shared});segments+=count;coincident+=shared
            records.append(record)
    return energy,gradient,records,{'clipped_boundary_segments':segments,'coincident_boundary_length_mm':coincident}
