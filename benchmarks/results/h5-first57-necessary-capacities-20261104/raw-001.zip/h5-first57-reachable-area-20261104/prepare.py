"""Bound reachable inner-body area for every three-empty-site selection."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import json,time,shutil
from shapely import box,union_all
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
OUT=ROOT/'output/h5-first57-reachable-area-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def deadline():assert time.perf_counter()-started<55,'Frozen preparation cap reached; no unaudited exclusion may be used.'
assert load(COVER/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed']
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__)]+[SOURCE/p for p in ['geometry-domains.json','world-cog-inner-rectangles.json','fixed-core-inner-rectangles.json','audit/plan.json','audit/checks.json']]+[COVER/p for p in ['audit/plan.json','audit/checks.json']]+[COVER/f'geometry-{g:02d}-cover.json' for g in range(10)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'For each of all455 selections, union every source-contained component swept over every eligible closed necessary anchor box. Subtract source-contained rectangles of all fixed obstacles. Distinct actual inner bodies have disjoint interiors and must fit within this reachable union. Its area is a necessary upper bound. GEOS area and polygon results are diagnostic until an independent exact rectangle-union audit. No previous positive construction restriction is used.',
    'coordinate_units_per_mm':1000,'required_brackets':8,'required_inserts':8,'preparation_cap_seconds':55,'maximum_process_seconds':75,'solver_calls':0,'certified_exclusions':0})
geometries=load(SOURCE/'geometry-domains.json')
sources=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
fixed=union_all([box(*r['bounds_um']) for r in sources if r['site_bit']==15])
cogs=[union_all([box(*r['bounds_um']) for r in sources if r['site_bit']==i]) for i in range(15)]
groups=[]
for g in geometries:
    bymask={}
    for row in load(COVER/f"geometry-{g['geometry']:02d}-cover.json"):
        m,x,y,z,w=row[:5]
        for a,b,c,d in g['inner_rectangles_um']:bymask.setdefault(m,[]).append([x+a,y+b,z+c,w+d])
    groups.append({m:union_all([box(*r) for r in rs]) for m,rs in bymask.items()})
area_min={family:min(sum((r[2]-r[0])*(r[3]-r[1]) for r in g['inner_rectangles_um']) for g in geometries if any(a[0]==family for a in g['aliases'])) for family in ['bracket','insert']}
write(OUT/'source-inner-area-minima.json',area_min)
records=[]
for index,empty in enumerate(combinations(range(15),3)):
    bits=sum(1<<i for i in empty)
    obstacle=union_all([fixed]+[cg for i,cg in enumerate(cogs) if i not in empty])
    reachable={}
    for family,gids in [('bracket',range(8)),('insert',range(8,10))]:
        u=union_all([p for gid in gids for m,p in groups[gid].items() if m&~bits==0]).difference(obstacle)
        reachable[family]=u
    both=union_all(list(reachable.values()))
    areas={f:float(p.area) for f,p in reachable.items()};areas['combined']=float(both.area)
    required={'bracket':8*area_min['bracket'],'insert':8*area_min['insert'],'combined':8*sum(area_min.values())}
    row={'index':index,'empty_sites':list(empty),'reachable_area_um2':areas,'required_area_um2':required,
         'diagnostic_excluded_by':[f for f in areas if areas[f]<required[f]],
         'components':{f:len(p.geoms) if hasattr(p,'geoms') else int(not p.is_empty) for f,p in reachable.items()},
         'bracket_capacity_area':int(areas['bracket']//area_min['bracket']),'insert_capacity_area':int(areas['insert']//area_min['insert'])}
    records.append(row)
    write(OUT/f'choice-{index:03d}.json',row)
    deadline()
    if index%50==0:print({'completed':index+1,'seconds':time.perf_counter()-started,'diagnostic_excluded':sum(bool(r['diagnostic_excluded_by']) for r in records)},flush=True)
write(OUT/'all-choices.json',records)
checks={'prepared':True,'seconds':time.perf_counter()-started,'choices':len(records),'diagnostic_excluded':sum(bool(r['diagnostic_excluded_by']) for r in records),
    'diagnostic_exclusion_reasons':dict(Counter(f for r in records for f in r['diagnostic_excluded_by'])),
    'minimum_area_capacity':{f:min(r[f+'_capacity_area'] for r in records) for f in ['bracket','insert']},
    'maximum_area_capacity':{f:max(r[f+'_capacity_area'] for r in records) for f in ['bracket','insert']},
    'independent_exact_audit_pending':True,'new_site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
