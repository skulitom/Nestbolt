"""Seal the independently audited continuous cover and direct capacity frontier."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-first57-necessary-capacities-20261104';OUT=ROOT/'benchmarks/results'/NAME
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
GLOBAL=ROOT/'output/h5-first57-reachable-area-20261104'
COMP=ROOT/'output/h5-first57-component-area-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104','h5-independent-cog-rows-and-expanded-domains-20261104','h5-expanded-joint-and-staged-row-constructions-20261104','h5-row-reductions-and-three-cog-allocation-20261104','h5-direct-short9-and-grouped-first57-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for folder in [SOURCE,COVER,GLOBAL,COMP]:assert load(folder/'audit/checks.json')['passed']
assert load(COMP/'audit/checks.json')['remaining_site_choices']==259
ga=load(GLOBAL/'audit/verified-choices.json');ca=load(COMP/'audit/verified-choices.json')
assert {r['index'] for r in ga if r['excluded']}<={r['index'] for r in ca if r['excluded']}
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
processes=[]
for stem in ['necessary-rectangles','necessary-mask-cover','reachable-area','component-area']:
    folder=ROOT/f'output/h5-first57-{stem}-20261104'
    process=ROOT/f'output/h5-first57-{stem}-process-20261104';processes.append(process)
    for directory in [folder,process]:
        for p in directory.rglob('*'):
            if p.is_file():add(directory.name+'/'+p.relative_to(directory).as_posix(),p)
for pattern in ['*h5_first57_necessary*20261104.py','*h5_first57_reachable_area*20261104.py','*h5_first57_component_area*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,'h5-first57-necessary-capacities-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(SOURCE/'audit/checks.json','source-containment-audit.json'),(COVER/'audit/checks.json','continuous-cover-audit.json'),
                    (GLOBAL/'audit/checks.json','global-area-audit.json'),(COMP/'audit/checks.json','component-area-audit.json'),
                    (COMP/'audit/retained-choices.json','retained-choices.json')]:shutil.copyfile(source,OUT/name)
records=[]
for p in processes:
    record=load(p/'process.json');assert record['closed'] and record['exit_code']==0 and not record['timeout'] and record['complete_process_cap_overrun_seconds']==0
    records.append({'process_directory':p.relative_to(ROOT).as_posix(),'opened':load(p/'opened.json'),'result':record})
write(OUT/'preparation-processes.json',records)
write(OUT/'next-step.json',{'closed_grouped_call_must_not_be_repeated':True,'direct_short9_is_source_valid':True,
    'necessary_source_cover_certified':True,'continuous_classes_verified':23278076,'original_first57_site_choices':455,'excluded_first57_site_choices':196,'remaining_first57_site_choices':259,
    'next_method':'Use the certified remaining necessary domains and component assignments to derive tighter source-based projection or mixed-part capacities, or a meaningfully smaller construction. The139 global area exclusions are contained in the196 direct component exclusions; neither is a positive construction. Preserve all8 bracket and8 insert identities, legal modes, the fixed29/source cog scope, full physical stock, actual required clearance, material target and complete60/90-second charged budget. Audit every new geometric or model implication before any call. Do not simply reseed, extend or restart the closed grouped model.',
    'new_model_prepared':False,'solver_calls':0,'native_calls':0,'older_fixed13_cog_frontier':{'site_choices':2,'count_distributions':3},'remaining_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'continuous_classes_verified':23278076,'necessary_cover_boxes':3275,'global_area_exclusions':139,'component_area_exclusions':196,'additional_component_exclusions':57,
    'component_areas_verified':1156,'cover_box_assignments_verified':23906,'remaining_first57_site_choices':259,
    'whole_allocations_excluded':0,'remaining_allocation_candidates':440,'new_solver_calls':0,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-first57-necessary-capacities-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 necessary domains and component capacities:** [independent exact audits]({link}) verify a full-stock continuous necessary cover for all 12 legal moving modes, including every boundary class. Exact replay checks 23,278,076 classes and 3,275 cover boxes. A separate integer area audit first excludes 139 of the 455 fixed-core twelve-cog selections. Direct component capacities then verify 1,156 exact areas and 23,906 anchor-box assignments, excluding 196 selections in total and leaving 259. These are continuous-source necessary bounds conditional on the fixed29 and current cog poses; all 440 whole-job allocations remain. All four preparation processes finish within their declared caps. No new solver/native call or full construction budget is claimed; prior calls remain closed. Full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [direct short9 and grouped first57](../benchmarks/results/h5-direct-short9-and-grouped-first57-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [necessary domains and component capacities](../benchmarks/results/{NAME}.md).',1)
a='A new direct 4/2/3 short sheet passes source checks in 0.297 s. Its grouped first57\nmodel retains all 455 twelve-cog selections but closes UNKNOWN without a placement.\nFresh necessary-source capacity bounds remain to prepare before further search.'
b='The direct 4/2/3 short sheet passes source checks in 0.297 s. Its grouped first57\ncall remains closed UNKNOWN. New exact continuous-source capacity proofs exclude\n196 of the 455 fixed-core twelve-cog selections, leaving 259. Stronger constraints\nor a meaningfully smaller construction remain to prepare before further search.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
