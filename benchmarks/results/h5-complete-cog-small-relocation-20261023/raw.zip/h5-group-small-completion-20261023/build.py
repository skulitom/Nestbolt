"""New bracket/insert contacts around the checked 58-part complete-cog subassembly."""
from collections import Counter,deque
from datetime import datetime,timezone
import copy,gzip,heapq,itertools,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import mapping
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import proposals,identity
from census_h5_one_part_moves import bits
from build_h5_group_choice import ROOT,SRC,load,write,digest,save_rows
SEED=ROOT/'output/h5-dense-group-blockers-20261023'
POOL=ROOT/'output/h5-dense-cog-completion-20261023'
OUT=ROOT/'output/h5-group-small-completion-20261023'
def graph(folder,ids,pool,geometry,clearance):
    gs=np.asarray([geometry[i] for i in ids],dtype=object);adj=[0]*len(ids);edges=[]
    for sheet in ['sheet-0','sheet-1']:
        local=np.asarray([j for j,i in enumerate(ids) if pool[i]['placement']['sheet_id']==sheet],dtype=int)
        if not len(local):continue
        pair=STRtree(gs[local]).query(gs[local],predicate='dwithin',distance=clearance+1e-7)
        a,b=local[pair[0]],local[pair[1]];take=a<b;a,b=a[take],b[take]
        take=shapely.distance(gs[a],gs[b])<clearance-1e-7
        for i,j in zip(a[take],b[take]):
            i,j=int(i),int(j);edges.append((i,j));adj[i]|=1<<j;adj[j]|=1<<i
    remaining=adj.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(adj) if a];heapq.heapify(heap)
    cliques=[];covered=0;start=time.perf_counter()
    while heap and time.perf_counter()-start<20:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]:continue
        choices=remaining[i];c=[i];mask=1<<i
        while choices:
            sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda j:((adj[j]&choices).bit_count(),-j))
            c.append(j);mask|=1<<j;choices&=adj[j]
        assert all(not((mask^(1<<j))&~adj[j]) for j in c);cliques.append(sorted(c))
        for j in c:
            before=remaining[j].bit_count();remaining[j]&=~mask;covered+=before-remaining[j].bit_count()
            if remaining[j]:heapq.heappush(heap,(-remaining[j].bit_count(),j))
    compressed=len(cliques);residual=0
    for i,mask in enumerate(remaining):
        for j in bits(mask&~((1<<(i+1))-1)):cliques.append([i,j]);residual+=1
    assert covered//2+residual==len(edges)
    save_rows(folder/'conflicts.jsonl.gz',sorted(edges));save_rows(folder/'cliques.jsonl.gz',sorted(set(map(tuple,cliques))))
    return {'conflicts':len(edges),'compressed_cliques':compressed,'residual_edges':residual,'compression_limit_reached':bool(heap)}
def main():
    OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[SRC/n for n in ['job.json','conditional-target.json']]+[SEED/n for n in ['best-subassembly.json','audit/checks.json']]+[POOL/'source-pool.json']
    assert load(SEED/'audit/checks.json')['passed']
    source_layout=load(SEED/'best-subassembly.json')
    planned=[{'sheet':sheet,'family':f,'rotation_radians':math.radians(a),'mirrored':m} for sheet in ['sheet-0','sheet-1'] for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for m in mirrors for a in angles]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'generation_seconds':120,'new_candidate_caps':{'bracket':1200,'insert':1000},'compression_seconds':20,'solve_seconds':30,'solve_calls':1,'workers':8,'seed':0,
      'fixed':'Exactly the checked 58 poses: 18 frames, 15 cogs, nine brackets and 16 inserts. Complete three brackets and five inserts. This is a new construction, not a production repair or an improvement over the saved 64-part partial.',
      'queries':planned,
      'generation':'Check remaining original filled area and stock first. Retain all compatible bracket/insert poses from the prior source pool, excluding the fixed poses themselves. Append any absent fixed cog by exact identity. Generate conservative actual-outline translation regions for all eight bracket orientations/reflections and two equivalent insert size classes on both sheets. Process representatives, vertices and edge midpoints round-robin; preserve all rejections and pending lists. Do not resume earlier capped lists or repeat earlier solves.',
      'new_pose_padding_mm':0.0126,'padding_scope':'Positive construction padding applies only to new poses; the fixed subassembly retains its original checked coordinates. Native margins remain unqualified.',
      'graph':'Recompute bracket/bracket, insert/insert and bracket/insert conflicts; preserve every residual edge after bounded compression. Independently audit original geometry and the complete model before one bounded solve.',
      'selection':'Maximize original filled area with caps of three brackets and five inserts. Zero new parts is the starting hint; retain all returned layouts and original CLI failures. An original 66-copy witness still needs native margins, the original production repair limits and budget, and full H5 gates.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=copy.deepcopy(load(POOL/'source-pool.json'));source_size=len(pool);job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    keys={identity(r['placement']):i for i,r in enumerate(pool)};selected=[];new_fixed=[]
    for p in source_layout['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');k=identity(p)
        if k not in keys:
            assert p['part_id']=='cog';i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'fixed-cog-from58'},'filled_area_mm2':shape(parts[p['part_id']],p['transform']).area});keys[k]=i;new_fixed.append(i)
        selected.append(keys[k])
    assert len(selected)==len(set(selected))==58
    fixed=sorted(selected);seed=[]
    assert Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15,bracket=9,insert=16)
    write(OUT/'source-pool.json',pool);write(OUT/'seed-mapping.json',{'source_pool_size':source_size,'new_fixed_candidates':new_fixed,'selected_candidates':sorted(selected)})
    oldsmall=[i for i,p in enumerate(pool) if p['placement']['part_id'] in ['bracket','insert'] and i not in fixed]
    geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixed+oldsmall}
    here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    stock=job['stocks'][0];target=load(SRC/'conditional-target.json');m=stock['margins'];edge=job['edge_clearance']
    from shapely.geometry import box
    from shapely.ops import unary_union
    available=[]
    for sheet in ['sheet-0','sheet-1']:
        height=stock['height'] if sheet=='sheet-0' else target['required_used_height_mm']
        domain=box(m['left']+edge,m['bottom']+edge,stock['width']-m['right']-edge,height-m['top']-edge)
        fixed_union=unary_union([geometry[i] for i in here[sheet]])
        assert domain.covers(fixed_union)
        available.append({'sheet':sheet,'usable_area_mm2':domain.area,'fixed_area_mm2':fixed_union.area,'free_area_mm2':domain.difference(fixed_union).area})
    need=sum(shape(parts[f],{'rotation_radians':0,'translation':[0,0],'mirrored':False}).area*n for f,n in [('bracket',3),('insert',5)])
    write(OUT/'area-preflight.json',{'sheets':available,'remaining_filled_area_mm2':need,'free_area_mm2':sum(r['free_area_mm2'] for r in available),'necessary_area_check_passes':sum(r['free_area_mm2'] for r in available)>=need,'scope':'Filled area only; excludes extra clearance cost and makes no packing claim.'})
    assert sum(r['free_area_mm2'] for r in available)>=need
    filters=[];eligible=[]
    for i in oldsmall:
        blockers=[j for j in here[pool[i]['placement']['sheet_id']] if geometry[i].distance(geometry[j])<job['clearance']-1e-7]
        filters.append({'candidate':i,'fixed_blockers':blockers})
        if not blockers:eligible.append(i)
    assert set(seed)<=set(eligible);keys={identity(p['placement']):i for i,p in enumerate(pool)};assert len(keys)==len(pool)
    target=load(SRC/'conditional-target.json');stock=job['stocks'][0];queries=[];planned=load(OUT/'plan.json')['queries'];gap.EPS=0.0126
    for item in planned:
        if time.perf_counter()-start>=120:break
        s,f,angle=item['sheet'],item['family'],item['rotation_radians'];this=copy.deepcopy(stock)
        if s=='sheet-1':this['height']=target['required_used_height_mm']
        moving=shape(parts[f],{'rotation_radians':angle,'translation':[0,0],'mirrored':item['mirrored']});beg=time.perf_counter()
        region=gap.regions(moving,[geometry[i] for i in here[s]],this,job['edge_clearance'],job['clearance'])
        query={'index':len(queries),'sheet':s,'family':f,'degrees':math.degrees(angle),'rotation_radians':angle,'mirrored':item['mirrored'],'seconds':time.perf_counter()-beg,
          'region':mapping(region),'region_area':region.area,'region_empty':region.is_empty,'proposals':proposals(region)}
        write(OUT/'regions'/f"query-{query['index']}.json",query);queries.append(query)
        print({k:query[k] for k in ['index','sheet','family','seconds','region_empty']},flush=True)
    queue=deque((q['index'],0) for q in queries if q['proposals']);events=[];added=[];counts=Counter();deferred=[];caps={'bracket':1200,'insert':1000}
    while queue and time.perf_counter()-start<120:
        qi,pi=queue.popleft();query=queries[qi];f=query['family']
        if counts[f]>=caps[f]:deferred.append([qi,pi]);continue
        p={'part_id':f,'sheet_id':query['sheet'],'transform':{'rotation_radians':query['rotation_radians'],'translation':query['proposals'][pi]['point'],'mirrored':query['mirrored']}}
        g=shape(parts[f],p['transform']);a,b,c,d=g.bounds;m=stock['margins'];edge=job['edge_clearance'];height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7
        blockers=[j for j in here[p['sheet_id']] if g.distance(geometry[j])<job['clearance']-1e-7];event={'query':qi,'proposal':pi}
        if outside or blockers:event.update(added=False,reason='geometry',outside=bool(outside),blockers=blockers)
        elif identity(p) in keys:event.update(added=False,reason='duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'group-small-completion','query':qi,'proposal':pi},'filled_area_mm2':g.area})
            keys[identity(p)]=i;geometry[i]=g;added.append(i);counts[f]+=1;event.update(added=True,candidate=i)
        events.append(event)
        if pi+1<len(query['proposals']):queue.append((qi,pi+1))
    elapsed=time.perf_counter()-start;ids=sorted(eligible+added)
    write(OUT/'candidates.json',pool);write(OUT/'old-filter.json',filters);write(OUT/'source-events.json',events)
    pending={'unbuilt_queries':planned[len(queries):],'proposals':sorted(deferred+list(map(list,queue)))};write(OUT/'pending.json',pending)
    write(OUT/'mapping.json',{'candidates':ids,'fixed_candidates':fixed,'seed_candidates':seed,'old_eligible':eligible,'new_candidates':added})
    result={'generation_seconds':elapsed,'queries':len(queries),'old_eligible':len(eligible),'new_candidates':dict(counts),'proposals_processed':len(events),
      'pending_queries':len(pending['unbuilt_queries']),'pending_proposal_lists':len(pending['proposals']),'generation_limit_reached':elapsed>=120,
      'retained_candidates':len(ids),**graph(OUT,ids,pool,geometry,job['clearance'])}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
