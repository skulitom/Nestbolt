"""Prepare a separate guarded normal push for the two verified queued checkpoints."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head.startswith('6b0a1d0b')
assert subprocess.check_output(['git','log','-1','--format=%s'],cwd=ROOT,text=True).strip()=='Prove continuous cog exclusion for six fixed short-sheet exchanges'
source=(ROOT/'output/push_h5_row_capacity_checkpoint_20261028.py').read_text(encoding='utf-8')
changes={
    'output/h5-row-capacity-main-sync-20261028':'output/h5-short-exchange-main-sync-20261028',
    "OLD='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58';NEW='83f3f51f7767d6ddd1e2eb34968d1502bb0ae3d8'":f"OLD='83f3f51f7767d6ddd1e2eb34968d1502bb0ae3d8';NEW='{head}'",
    "['benchmarks/results/h5-movable-row-bracket-and-capacity-20261028','benchmarks/results/h5-row-bracket-capacity-and-domain-studies-20261028']":"['benchmarks/results/h5-fixed-cog-rows-and-short-exchange-20261028','benchmarks/results/h5-short-exchange-continuous-bound-20261028']",
    '40777420353':'40783629977'
}
for old,new in changes.items():
    assert old in source,old
    source=source.replace(old,new)
with (ROOT/'output/push_h5_short_exchange_checkpoint_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'head':head,'prior_CI':40783629977,'guard_prepared':True})
