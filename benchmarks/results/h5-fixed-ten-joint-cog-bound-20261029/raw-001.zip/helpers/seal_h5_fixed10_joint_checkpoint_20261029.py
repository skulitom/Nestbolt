"""Seal the fixed-ten inventory, closed finite construction and audited joint bound."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
INV=ROOT/'output/h5-short-fixed10-inventory-20261028';ADJ=ROOT/'output/h5-short-adjacent-exchange-20261028';BASE=ROOT/'output/h5-short-joint-core-20261028';PUB=BASE/'publication';SYNC=ROOT/'output/h5-short-exchange-main-sync-20261028'
NAME='h5-fixed-ten-joint-cog-bound-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='6b0a1d0b2e2f5abdcddf9a3fb73c27cdb0d8e641' and not git('diff','HEAD','--name-only')
inventory=load(INV/'audit/checks.json');geometry=load(ADJ/'audit/checks.json');response=load(ADJ/'response-audit/checks.json');joint=load(BASE/'audit/checks.json')
assert all(r['passed'] for r in [inventory,geometry,response,joint])
assert inventory['all_angle_fixed10_excluded_geometries']==44 and inventory['unexcluded_geometries']==7 and inventory['unexcluded_inventory_variants']==8
assert response['all_finite_cog_anchors_independently_reconstructed']==335 and response['complete_residual_bracket_domain_queries']==2680 and response['all_residual_bracket_domains_empty']
search=load(ADJ/'search/result.json');supervisor=load(ADJ/'search/supervisor-result.json');assert search['construction_calls']==1 and search['closed'] and search['all_finite_anchors_exhausted'] and search['source13_checks']==0 and supervisor['child_returncode']==0 and not supervisor['shared_timeout']
assert joint['all14_continuous_joint_cases_excluded'] and joint['combined_fixed10_geometries_excluded']==51 and joint['combined_identity_variants_excluded']==66
prior=load(ROOT/'benchmarks/results/h5-short-exchange-continuous-bound-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert main==head==ci['head_sha'] and ci['status']=='in_progress' and len(jobs)==6
passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==4 and set(live)=={'checks (windows-latest)','checks (ubuntu-latest)'}
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [INV,ADJ,BASE,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_short_fixed10_inventory_20261028.py','audit_h5_short_fixed10_inventory_20261028.py','h5_continuous_core_certificate_reader_20261028.py','prepare_h5_short_adjacent_exchange_20261028.py','audit_h5_short_adjacent_exchange_20261028.py','search_h5_short_adjacent_exchange_20261028.py','run_h5_short_adjacent_exchange_20261028.py','audit_h5_short_adjacent_response_20261028.py','h5_joint_core_coverage_20261028.py','prove_h5_short_joint_core_20261028.py','audit_h5_short_joint_core_20261028.py','prepare_h5_short_exchange_push_20261028.py','push_h5_short_exchange_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_fixed10_joint_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(INV,'result.json','inventory-result.json'),(INV,'audit/checks.json','inventory-audit.json'),(INV,'case-summary.json','inventory-cases.json'),(ADJ,'prepared.json','geometry-prepared.json'),(ADJ,'audit/checks.json','geometry-audit.json'),(ADJ,'search/result.json','construction-result.json'),(ADJ,'search/supervisor-result.json','construction-supervisor.json'),(ADJ,'response-audit/checks.json','construction-audit.json'),(ADJ,'response-audit/unexercised-candidate-validator-defect.json','unexercised-candidate-validator-defect.json'),(BASE,'stock-hull-core.json','stock-hull-core.json'),(BASE,'result.json','joint-bound-result.json'),(BASE,'audit/checks.json','joint-bound-audit.json'),(BASE,'audit/case-checks.json','joint-bound-cases.json'),(BASE,'audit/necessity-proof.json','necessity-proof.json')]
for folder,a,b in copies:shutil.copyfile(folder/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');shutil.copyfile(SYNC/'receipt.json',OUT/'prior-push-receipt.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40789500705,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Prepare a genuinely new short-sheet construction that allows at least three of the twelve parent poses to change. First inventory the fixed-nine cases obtained by moving one parent bracket to the first sheet and releasing two further originals. Deduplicate geometry while retaining each mandatory identity assignment; the target remains5 brackets,6 inserts,2 cogs with the original first-sheet complement18 frames,7 brackets,15 inserts,13 cogs. Apply the audited all-angle stock/core and joint necessary predicates before committing a bounded original-source construction. Preserve every closed fixed-eleven/fixed-ten experiment. In new candidate validators normalize expected identity lists to tuples before the original-source check. A relaxed core witness alone never validates an original part. Native calls require all66 original-source-valid placements.','fixed9_inventory_prepared':False,'new_construction_opened':False,'full_allocation_or_original_job_excluded':False,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'inventory_variants':66,'distinct_fixed10_source_geometries':51,'single_cog_bound_excludes_geometries':44,'joint_bound_excludes_remaining_geometries':7,'combined_all51_geometries_and_all66_variants_excluded':True,'parent_poses_that_must_change_at_least':3,'finite_construction_calls':1,'finite_cog_anchors':335,'empty_residual_bracket_domains':2680,'joint_bound_cases':14,'joint_coverage_nodes':860,'joint_covered_leaves':437,'new_source_valid13':False,'new_source_valid66':False,'full_allocation_or_original_job_excluded':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'solver_calls':0,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
