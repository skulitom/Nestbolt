"""Restore missing quantities with explicit overlapping diagnostic poses."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from hashlib import sha256
import copy,gzip,itertools,json,math,shutil,subprocess,sys,traceback
import numpy as np
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1]
PRIOR=ROOT/'output/h5-outline-backfill-20261018'
OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest


def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')


def pose(poly,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(poly,[m*c,-s,m*s,c,*t['translation']])


def orientations(part):
    r=part['rotations']
    angles=list(range(0,360,15)) if r['kind']=='free' else r['degrees']
    assert r['kind'] in ['free','list']
    for mirror in ([False,True] if part['allow_mirror'] else [False]):
        for degrees in angles:yield {'rotation_radians':math.radians(degrees),'mirrored':mirror,'translation':[0.,0.]}


def main():
    OUT.mkdir(exist_ok=True);inputs=OUT/'inputs';inputs.mkdir(exist_ok=True)
    prior=load(PRIOR/'results.json');assert prior['complete']
    production=source_digest();assert production=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'production_digest':production,
        'input_results_sha256':digest(PRIOR/'results.json'),'script_sha256':digest(Path(__file__)),
        'method':'Preserve each saved incomplete layout and every existing pose. Restore missing original copies one at a time, largest filled area first. Try original discrete rotations/mirrors and 15-degree free angles on both original target beds. Sample an 11 by 11 uniform grid of legal translations plus bounding-box corner alignments to existing parts. Choose least original filled-area overlap, then least clearance deficit and number of conflicts, then stable sheet/y/x/angle/mirror order. These are deliberately invalid provisional placements for the existing joint repair helper. Preserve every sampled score and each selected insertion. Original library/request validation must reject only overlap/clearance issues, never quantities or outside-stock violations.',
        'native_probe_seed':0,'native_probe_work_seconds':12.0,
        'scope':'Mechanism witness only, not H5 quality/timing or a changed runtime budget. Publicly legal partial geometry may have native proxy loss because its extra separation is smaller than conversion_guard.',
        'new_Nestbolt_searches':0}
    write(OUT/'input-recovery-plan.json',plan);shutil.copyfile(__file__,OUT/'prepare-inputs-recovery.py');records=[]
    try:
        for result in prior['cases']:
            src=PRIOR/result['case'];folder=inputs/src.name;folder.mkdir(exist_ok=True)
            for name in ['job.json','library.json','request.json','original.json','conditional-target.json']:
                if (folder/name).exists():assert (folder/name).read_bytes()==(src/name).read_bytes()
                else:shutil.copyfile(src/name,folder/name)
            if (folder/'partial.json').exists():assert (folder/'partial.json').read_bytes()==(src/'layout.json').read_bytes()
            else:shutil.copyfile(src/'layout.json',folder/'partial.json')
            job=load(folder/'job.json');partial=load(folder/'partial.json');proposal=copy.deepcopy(partial);target=load(folder/'conditional-target.json')
            parts={p['id']:p for p in job['parts']};polys={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']}
            stocks={s['id']:s for s in job['stocks']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];gap=job['clearance']
            assert len(job['stocks'])==1 and not stock['outline'] and not stock['defects']
            expected=Counter({p['id']:p['quantity'] for p in job['parts']});current=Counter(p['part_id'] for p in partial['placements'])
            missing=expected-current;assert dict(missing)==result['remaining']
            copies=[(family,i) for family in sorted(missing,key=lambda k:(-polys[k].area,k)) for i in range(parts[family]['quantity']) if i not in {p['copy_index'] for p in partial['placements'] if p['part_id']==family}]
            inserted=[];attempts=0
            if (folder/'proposal.json').exists():
                proposal=load(folder/'proposal.json');inserted=load(folder/'insertions.json');attempts=sum(r['sampled_poses'] for r in inserted)
            else:
                with gzip.open(folder/'placement-scores.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                    for family,index in copies:
                        best=None;tested=0
                        for sheet,h in [('sheet-0',stock['height']),('sheet-1',target['required_used_height_mm'])]:
                            fixed=[pose(polys[p['part_id']],p['transform']) for p in proposal['placements'] if p['sheet_id']==sheet]
                            tree=STRtree(fixed)
                            for t in orientations(parts[family]):
                                local=pose(polys[family],t);x0,y0,x1,y1=local.bounds
                                # New provisional poses use a positive edge inset;
                                # original saved poses remain byte-for-byte intact.
                                xmin=m['left']+edge+.02-x0;xmax=stock['width']-m['right']-edge-.02-x1
                                ymin=m['bottom']+edge+.02-y0;ymax=h-m['top']-edge-.02-y1
                                if xmin>xmax or ymin>ymax:continue
                                candidates=set(itertools.product(np.linspace(xmin,xmax,11).tolist(),np.linspace(ymin,ymax,11).tolist()))
                                for f in fixed:
                                    a,b,c,d=f.bounds
                                    for x,y in [(a-x0,b-y0),(c-x1,b-y0),(a-x0,d-y1),(c-x1,d-y1)]:
                                        if xmin<=x<=xmax and ymin<=y<=ymax:candidates.add((x,y))
                                for x,y in sorted(candidates,key=lambda xy:(xy[1],xy[0])):
                                    moved=affine_transform(local,[1,0,0,1,x,y]);a,b,c,d=moved.bounds
                                    nearby=tree.query(Polygon([(a-gap,b-gap),(c+gap,b-gap),(c+gap,d+gap),(a-gap,d+gap)]))
                                    overlap=0.;deficit=0.;conflicts=0
                                    for j in nearby:
                                        f=fixed[int(j)];distance=moved.distance(f)
                                        if distance<gap:conflicts+=1;deficit+=gap-distance;overlap+=moved.intersection(f).area
                                    score=(overlap,deficit,conflicts,int(sheet[-1]),y,x,t['rotation_radians'],t['mirrored'])
                                    tested+=1;attempts+=1
                                    log.write(json.dumps([len(inserted),sheet,x,y,t['rotation_radians'],t['mirrored'],overlap,deficit,conflicts],separators=(',',':'))+'\n')
                                    if best is None or score<best[0]:best=(score,{'part_id':family,'copy_index':index,'sheet_id':sheet,'transform':{**t,'translation':[x,y]}})
                        assert best
                        proposal['placements'].append(best[1]);inserted.append({'part_id':family,'copy_index':index,'sampled_poses':tested,'selected':best[1],'score':best[0]})
            assert proposal['placements'][:len(partial['placements'])]==partial['placements']
            assert Counter(p['part_id'] for p in proposal['placements'])==expected
            assert len({(p['part_id'],p['copy_index']) for p in proposal['placements']})==len(proposal['placements'])
            if not (folder/'proposal.json').exists():write(folder/'proposal.json',proposal);write(folder/'insertions.json',inserted)
            cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
            assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
            command=[str(cli),'validate','--library',str(folder/'library.json'),'--request',str(folder/'request.json'),'--layout',str(folder/'proposal.json')]
            if (folder/'proposal-validation.json').exists():
                prior=load(folder/'proposal-validation-command.json');assert prior['command']==command
                report=load(folder/'proposal-validation.json');code=prior['exit_code']
            else:
                r=subprocess.run(command,capture_output=True,timeout=60);code=r.returncode
                (folder/'proposal-validation.json').write_bytes(r.stdout);(folder/'proposal-validation-stderr.log').write_bytes(r.stderr)
                write(folder/'proposal-validation-command.json',{'command':command,'exit_code':code});report=json.loads(r.stdout)
            assert not report['valid'] and code!=0
            # Keep the actual diagnostic codes; reject all non-geometric defects.
            codes=sorted({v['code'] for v in report['violations']})
            assert set(codes)<= {'overlap','clearance','total_overlap'},codes
            fixture={'job':job,'before':load(folder/'original.json'),'partial':partial,'proposal':proposal,
                'target_used_height_mm':target['required_used_height_mm'],'target_material_mm2':target['target_material_mm2'],'seed':0,'budget':12.0}
            write(folder/'fixture.json',fixture)
            record={'case':folder.name,'missing_copies_restored':len(inserted),'sampled_poses':attempts,
                'all_original_partial_poses_exact':True,'original_quantity_complete':True,'proposal_valid':False,
                'violation_codes':codes,'violation_count':report['violation_count'],'fixture_sha256':digest(folder/'fixture.json')}
            write(folder/'checks.json',record);records.append(record);print(json.dumps(record),flush=True)
        assert source_digest()==production and digest(PRIOR/'results.json')==plan['input_results_sha256']
        write(OUT/'input-checks.json',{'complete':True,'cases':records,'production_and_original_results_unchanged':True})
    except BaseException:
        write(OUT/'input-recovery-failure.json',{'error':traceback.format_exc(),'completed':records});raise


if __name__=='__main__':main()
