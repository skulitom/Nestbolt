"""Finish observer-schema corrections without repeating any geometry search or native repair."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
old=ROOT/'output/audit_h5_pattern_joint_witness_complete.py';new=ROOT/'output/audit_h5_pattern_joint_witness_verified.py'
assert (OUT/'audit-complete/failure.json').exists() and not new.exists()
source=OUT/'candidate-recovery/crates/core/src/sheets.rs'
assert '#[serde(skip_serializing_if = "is_zero")]\n    pub joint_repair_completed' in source.read_text(encoding='utf-8')
text=old.read_text(encoding='utf-8').replace("AUDIT=OUT/'audit-complete';","AUDIT=OUT/'audit-verified';")
needle="            assert r['target_height_mm']==h and r['target_material_mm2']==target['target_material_mm2']"
assert needle in text
text=text.replace(needle,"""            target_roundtrip=compare_roundtrip(r['target_height_mm'],h,'target_height_mm')+compare_roundtrip(r['target_material_mm2'],target['target_material_mm2'],'target_material_mm2')
            write(AUDIT/(case+'-target-roundtrip.json'),{'differences':target_roundtrip,
                'geometry_and_any_success_checked_against_original_target':True})""")
new.write_text(text,encoding='utf-8',newline='\n')
failures={p.relative_to(OUT).as_posix():sha256(p.read_bytes()).hexdigest() for p in OUT.glob('audit*/failure.json')}
record={'cause':'Native reports omit zero-valued stats and decimal JSON echoes can differ by one binary64 ULP, including target fields. The intermediate generator also used the incorrect predicate name zero instead of is_zero after writing its output.',
    'correction':'Use the declared is_zero serializer behavior. Record every input and target echo difference with an explicit one-ULP bound. Keep original geometry and target limits authoritative for independent checks; no acceptance threshold or source change.',
    'preserved_audit_failures':failures,'failed_generator_sha256':sha256((ROOT/'output/recover_h5_pattern_joint_zero_stats.py').read_bytes()).hexdigest(),
    'stats_source_sha256':sha256(source.read_bytes()).hexdigest(),'verified_auditor_sha256':sha256(new.read_bytes()).hexdigest(),
    'new_search_or_repair_runs':0}
with (OUT/'audit-final-recovery.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
for name in ['recover_h5_pattern_joint_audit.py','recover_h5_pattern_joint_zero_stats.py','finish_h5_pattern_joint_audit.py']:
    shutil.copyfile(ROOT/'output'/name,OUT/name)
print(json.dumps({'prepared':True,'failures_preserved':len(failures),'new_searches':0}))
