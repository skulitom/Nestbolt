"""Account for Stats' declared skip_serializing_if-zero fields; retain both audit failures."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
old=ROOT/'output/audit_h5_pattern_joint_witness_recovery.py';new=ROOT/'output/audit_h5_pattern_joint_witness_complete.py'
assert (OUT/'audit-recovery/failure.json').exists() and not new.exists()
text=old.read_text(encoding='utf-8').replace("AUDIT=OUT/'audit-recovery';","AUDIT=OUT/'audit-complete';")
for key in ['joint_repair_completed','joint_repair_expired','joint_repair_failed']:
    text=text.replace("r['stats']['"+key+"']","r['stats'].get('"+key+"',0)")
new.write_text(text,encoding='utf-8',newline='\n')
source=OUT/'candidate-recovery/crates/core/src/sheets.rs'
assert source.read_text(encoding='utf-8').count('#[serde(skip_serializing_if = "zero")]')>0
record={'cause':'Stats omits counters whose value is zero; the auditor indexed absent joint_repair_completed directly.',
    'correction':'Apply the actual serializer default of zero for omitted joint-repair counters. Preserve earlier audits and every native result; no reruns.',
    'previous_failure_sha256':sha256((OUT/'audit-recovery/failure.json').read_bytes()).hexdigest(),
    'stats_source_sha256':sha256(source.read_bytes()).hexdigest(),'auditor_sha256':sha256(new.read_bytes()).hexdigest(),
    'new_search_or_repair_runs':0}
with (OUT/'audit-zero-stats-recovery.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'prepared':True,'new_searches':0}))
