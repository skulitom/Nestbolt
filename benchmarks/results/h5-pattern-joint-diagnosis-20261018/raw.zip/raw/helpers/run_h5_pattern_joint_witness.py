"""Run each saved real-job repair fixture exactly once, serially on CCD0 CPU8."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,os,psutil,shutil,subprocess,time,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(OUT/'native-plan.json');build=load(OUT/'native-recovery-build.json');binary=OUT/'native-tests.exe'
assert build['exit_code']==0 and digest(binary)==build['binary_sha256']
dest=OUT/'native-runs';dest.mkdir();shutil.copyfile(__file__,dest/'run.py')
psutil.Process().cpu_affinity([8]);assert psutil.Process().cpu_affinity()==[8]
write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'cpu_affinity':[8],
    'cases':plan['cases'],'seed':0,'work_allowance_per_case':12.0,'binary_sha256':digest(binary),
    'runtime_unchanged':True,'quality_runs':0,'purpose':__doc__})
records=[]
try:
    for case in plan['cases']:
        folder=dest/case['case'];folder.mkdir();fixture=OUT/'inputs'/case['case']/'fixture.json'
        assert digest(fixture)==case['fixture_sha256']
        env=os.environ.copy();env['NESTBOLT_JOINT_FIXTURE']=str(fixture);env['NESTBOLT_JOINT_OUTPUT']=str(folder/'result.json')
        assert not env.get('NESTBOLT_SIMPLIFY')
        command=[str(binary),'--exact',plan['diagnostic_test'],'--ignored','--nocapture','--test-threads=1']
        write(folder/'command.json',{'command':command,'fixture_sha256':digest(fixture),'cpu_affinity':[8]})
        started=datetime.now(timezone.utc).isoformat();t=time.perf_counter()
        with (folder/'test.log').open('xb') as log:
            result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100)
        wall=time.perf_counter()-t
        record={'case':case['case'],'started':started,'finished':datetime.now(timezone.utc).isoformat(),
            'wall_seconds':wall,'exit_code':result.returncode,'log_sha256':digest(folder/'test.log')}
        if (folder/'result.json').exists():
            r=load(folder/'result.json');record.update({'success':r['success'],'stats':r['stats'],
                'work_seconds':r['finished']-r['started'],'result_sha256':digest(folder/'result.json')})
        write(folder/'check.json',record);records.append(record)
        print(json.dumps({k:record.get(k) for k in ['case','exit_code','success','wall_seconds','work_seconds']}),flush=True)
        assert result.returncode==0 and '1 passed; 0 failed' in (folder/'test.log').read_text(encoding='utf-8')
        assert digest(fixture)==case['fixture_sha256']
    assert digest(binary)==build['binary_sha256']
    write(dest/'checks.json',{'complete':True,'cases':records,'successes':sum(r['success'] for r in records),
        'serial_cpu':[8],'seed':0,'unchanged_work_budget':12.0,'all_diagnostics_recorded_once':True,'quality_runs':0})
except Exception as e:
    write(dest/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed':records});raise
