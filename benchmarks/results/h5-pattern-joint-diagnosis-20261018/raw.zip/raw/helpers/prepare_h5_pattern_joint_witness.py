"""Add one isolated real-job repair probe, without changing any runtime source."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import difflib, json, shutil, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'output/h5-frontier-probe-20261018/candidate'
OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
WORK=OUT/'candidate'; TARGET=ROOT/'output/h5-pattern-joint-target-20261018'
REL='crates/core/src/sheets/vstrip/exchange.rs'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

assert json.loads((OUT/'input-checks.json').read_bytes())['complete']
assert not WORK.exists() and not TARGET.exists()
assert digest(OLD/REL)=='cbc01299e120f2a4112dc556538388358f7d2d72d93f78fd06e3c146eb33e4ee'
shutil.copytree(OLD,WORK)
original=(OLD/REL).read_text(encoding='utf-8')
tests=r'''
    // BEGIN real-job partial-layout repair diagnostic; runtime is unchanged.
    #[test]
    #[ignore = "explicit saved-fixture diagnostic, not a quality acceptance test"]
    fn saved_partial_joint_repair_diagnostic() {
        let fixture_path = std::env::var("NESTBOLT_JOINT_FIXTURE").unwrap();
        let output_path = std::env::var("NESTBOLT_JOINT_OUTPUT").unwrap();
        let input: serde_json::Value = serde_json::from_slice(&std::fs::read(fixture_path).unwrap()).unwrap();
        let job: Job = serde_json::from_value(input["job"].clone()).unwrap();
        let before: Layout = serde_json::from_value(input["before"].clone()).unwrap();
        let partial: Layout = serde_json::from_value(input["partial"].clone()).unwrap();
        let proposal: Layout = serde_json::from_value(input["proposal"].clone()).unwrap();
        let target_height = input["target_used_height_mm"].as_f64().unwrap();
        let target_material = input["target_material_mm2"].as_f64().unwrap();
        let seed = input["seed"].as_u64().unwrap();
        let budget = input["budget"].as_f64().unwrap();
        assert_eq!(seed,0); assert_eq!(budget,12.0);
        let before_report = validate(&job,&before).unwrap();
        assert!(before_report.valid);
        let partial_report = validate(&job,&partial).unwrap();
        let proposal_report = validate(&job,&proposal).unwrap();
        assert!(!partial_report.valid && !proposal_report.valid);
        assert_eq!(proposal.placements.len(),job.parts.iter().map(|p|p.quantity as usize).sum::<usize>());
        let model=Model::new(&job).unwrap();
        let guard=crate::construct::conversion_guard(&job);
        let separation=(job.clearance+guard)/0.05_f64.cos();
        let expand=(job.clearance+guard)/2.0+separation/2.0-(job.edge_clearance+guard);
        let m=job.stocks[0].margins;
        let target_internal_exact=target_height-m.bottom-m.top+2.0*expand;
        let mut last=target_internal_exact as f32;
        if f64::from(last)>target_internal_exact {last=f32::from_bits(last.to_bits()-1);}
        assert!(last>0.0 && last<model.full_width);

        // Account for conversion margins before restoring the absent parts.
        // Loss observation has its own clock and never invokes separation.
        let observe_clock=Clock::new(Timing::Work,60.0);
        let observe_strip=Strip{model:&model,gap:2.0,clock:observe_clock.clone(),containers:Default::default()};
        let mut observations=vec![];
        for (name,layout) in [("partial",&partial),("proposal",&proposal)] {
            let sheets=model.sheets_of(layout).unwrap(); assert_eq!(sheets.len(),2);
            let mut per_sheet=vec![];
            for (i,sheet) in sheets.iter().enumerate() {
                let shape=Shape{sheets:1,last:if i==0 {model.full_width} else {last}};
                let mut local=JLayout::new(observe_strip.container(shape).unwrap());
                for p in sheet.layout().placed_items().values() {local.place_item(p.item(),p.d_transf());}
                let sep=Separator::new(local,0,EXPLORE,observe_clock.clone());
                let conflicts=sep.layout.placed_items().keys().filter(|&k|sep.tracker.loss(k)>0.0).count();
                per_sheet.push(serde_json::json!({"sheet":i,"items":sep.layout.placed_items().len(),
                    "loss":sep.tracker.total_loss(),"items_with_loss":conflicts}));
            }
            let whole=observe_strip.layout(&sheets,Shape{sheets:2,last}).unwrap();
            let mut sep=Separator::new(whole,0,EXPLORE,observe_clock.clone());
            sep.pin(blocker_index(&model));
            observations.push(serde_json::json!({"input":name,"per_sheet":per_sheet,
                "joined_pinned_loss":sep.tracker.total_loss()}));
        }
        let clock=Clock::new(Timing::Work,60.0);
        let strip=Strip{model:&model,gap:2.0,clock:clock.clone(),containers:Default::default()};
        let mut search=Search{model:&model,allow_exchange:true,
            rng:Xoshiro256PlusPlus::seed_from_u64(seed),clock:clock.clone(),
            best:(before.clone(),before_report.clone(),0.0),history:vec![],stats:Stats::default(),
            progress:|_:&Progress,_:&dyn Fn()->Option<Layout>|{},check_cost:0.0,check_every:5.0};
        let proposed=model.sheets_of(&proposal).unwrap();assert_eq!(proposed.len(),2);
        let receiver=JLayout::from_snapshot(&proposed[0].layout().save());
        let source=JLayout::from_snapshot(&proposed[1].layout().save());
        let started=clock.now();let until=started+budget;
        let repaired=search.joint_repair_pair(&strip,receiver,source,last,until).unwrap();
        let finished=clock.now();let work=clock.counts();
        let mut after:Option<Layout>=None;
        let mut after_report:Option<Report>=None;
        if let Some(snapshots)=repaired {
            let shape=Shape{sheets:2,last};
            let mut whole=JLayout::new(strip.container(shape).unwrap());
            for (i,snapshot) in snapshots.iter().enumerate() {
                let local=JLayout::from_snapshot(snapshot);
                for p in local.placed_items().values() {whole.place_item(p.item(),shift(p.d_transf(),strip.start(i)));}
            }
            strip.set_blocker(&mut whole,shape).unwrap();
            let layout=search.exchange_layout(&strip,&[],&whole,shape).unwrap();
            after_report=Some(validate(&job,&layout).unwrap());after=Some(layout);
        }
        let record=serde_json::json!({"job":job,"before":before,"partial":partial,"proposal":proposal,
            "before_report":before_report,"partial_report":partial_report,"proposal_report":proposal_report,
            "after":after,"after_report":after_report,"success":after.is_some(),"stats":search.stats,
            "native_loss_observations":observations,"observation_work":observe_clock.counts(),
            "conversion_guard_mm":guard,"model_separation":model.separation,"model_full_width":model.full_width,
            "target_height_mm":target_height,"target_material_mm2":target_material,
            "target_internal_exact":target_internal_exact,"target_internal_rounded_down":last,
            "seed":seed,"budget":budget,"started":started,"until":until,"finished":finished,"work":work});
        let bytes=serde_json::to_vec_pretty(&record).unwrap();
        use std::io::Write;
        let mut file=std::fs::OpenOptions::new().write(true).create_new(true).open(output_path).unwrap();
        file.write_all(&bytes).unwrap();file.write_all(b"\n").unwrap();
        if let Some(report)=after_report {
            assert!(report.valid,"{:?}",report.violations);
            assert!(report.metrics.unwrap().material_area<=target_material);
            assert!(finished<until);
        }
        assert_eq!(search.stats.joint_repair_attempts,1);
        assert_eq!(search.stats.joint_repair_attempts,search.stats.joint_repair_completed+
            search.stats.joint_repair_failed+search.stats.joint_repair_expired);
        eprintln!("REAL_JOB_JOINT_REPAIR_RESULT success={} work_seconds={}",after.is_some(),finished-started);
    }
    // END real-job partial-layout repair diagnostic.
'''
pos=original.rindex('\n}')
(WORK/REL).write_text(original[:pos]+'\n'+tests+original[pos:],encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=WORK,check=True)
current=(WORK/REL).read_text(encoding='utf-8')
assert current.startswith(original[:pos]) and current.endswith(original[pos:])
assert current.split('#[cfg(test)]\nmod tests',1)[0]==original.split('#[cfg(test)]\nmod tests',1)[0]
files=[{'path':p.relative_to(OLD).as_posix(),'sha256':digest(p)} for p in sorted(OLD.rglob('*')) if p.is_file()]
for r in files:
    if r['path']!=REL:assert digest(WORK/r['path'])==r['sha256']
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
write(OUT/'native-plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,
    'old_source':str(OLD),'source_files':files,'changed_file':REL,'production_digest':source_digest(),
    'target':str(TARGET),'candidate_changed_sha256':digest(WORK/REL),'all_prior_source_bytes_unchanged_except_appended_test':True,
    'runtime_unchanged':True,'seed':0,'work_seconds_per_case':12,'hard_seconds':60,'native_cpu':[8],
    'cases':[{'case':p.parent.name,'fixture_sha256':digest(p)} for p in sorted((OUT/'inputs').glob('*/fixture.json'))],
    'build_command':['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--no-run','--target-dir',str(TARGET)],
    'diagnostic_test':'sheets::vstrip::exchange::tests::saved_partial_joint_repair_diagnostic',
    'new_quality_runs':0,'scope':'Measure native proxy loss before missing parts are restored, then call unchanged existing repair once per original job. Failure is evidence; only complete original public and filled-outer target validation proves feasibility.'})
(OUT/'native-witness.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),current.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL)),encoding='utf-8',newline='\n')
shutil.copyfile(__file__,OUT/'prepare-native.py')
print(json.dumps({'prepared':True,'parent_files':len(files),'all_runtime_unchanged':True,'cases':4}))
