"""Retain the strict JSON-equality failure; explicitly audit one-ULP numeric round trips."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
old=ROOT/'output/audit_h5_pattern_joint_witness.py';new=ROOT/'output/audit_h5_pattern_joint_witness_recovery.py'
assert (OUT/'audit/failure.json').exists() and not new.exists() and not (OUT/'audit-recovery').exists()
text=old.read_text(encoding='utf-8').replace("AUDIT=OUT/'audit';","AUDIT=OUT/'audit-recovery';")
helper='''def compare_roundtrip(actual,expected,path=''):
    differences=[]
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and actual.keys()==expected.keys(),path
        for key in expected:differences.extend(compare_roundtrip(actual[key],expected[key],path+'/'+key))
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),path
        for i,(a,b) in enumerate(zip(actual,expected)):differences.extend(compare_roundtrip(a,b,path+'/'+str(i)))
    elif actual!=expected:
        assert isinstance(actual,float) and isinstance(expected,float),path
        error=abs(actual-expected);ulp=math.ulp(expected)
        assert error<=ulp,(path,actual,expected,error/ulp)
        differences.append({'path':path,'input':expected,'native_echo':actual,'absolute_error':error,'ULPs':error/ulp})
    return differences

'''
text=text.replace('def main():',helper+'def main():')
needle="            for key in ['job','before','partial','proposal']:assert r[key]==fixture[key]"
assert needle in text
text=text.replace(needle,"""            roundtrip=[]
            for key in ['job','before','partial','proposal']:roundtrip.extend(compare_roundtrip(r[key],fixture[key],key))
            echo_partial=geometry(job,r['partial'],h,False,True)
            echo_proposal=geometry(job,r['proposal'],h,True,False)
            assert echo_partial['counts']==partial_check['counts'] and echo_proposal['counts']==proposal_check['counts']
            write(AUDIT/(case+'-native-json-roundtrip.json'),{'differences':roundtrip,
                'input_files_unchanged':True,'each_difference_at_most_one_ULP':True,
                'native_echo_partial':echo_partial,'native_echo_proposal':echo_proposal})""")
text=text.replace("'native_loss_observations':r['native_loss_observations']", "'native_json_roundtrip_differences':len(roundtrip),'native_json_max_absolute_error':max((v['absolute_error'] for v in roundtrip),default=0.),'native_loss_observations':r['native_loss_observations']")
new.write_text(text,encoding='utf-8',newline='\n')
record={'cause':'Strict Python float equality rejected native JSON echoes. Every observed numeric difference is exactly one binary64 ULP; strings, booleans, keys and inventory are unchanged.',
    'correction':'Preserve original bytes and hash identity. Enumerate every echo difference, require at most one ULP, and independently recheck echoed geometry against original job coordinates with the unchanged 1e-7 mm tolerance. This is an observer serialization audit, not a scoring exception or native tolerance change.',
    'original_failure_sha256':sha256((OUT/'audit/failure.json').read_bytes()).hexdigest(),
    'original_auditor_sha256':sha256(old.read_bytes()).hexdigest(),'recovery_auditor_sha256':sha256(new.read_bytes()).hexdigest(),
    'new_search_or_repair_runs':0}
with (OUT/'audit-recovery-plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'prepared':True,'new_searches':0}))
