"""Resume input preparation, reusing the first complete provisional input."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/prepare_h5_partial_joint_inputs.py'
out=ROOT/'output/h5-pattern-joint-probe-20261018'
first=out/'inputs/m-mechanical-large-plates-k0.2-s0-candidate'
preserved={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in first.iterdir() if p.is_file()}
preserved['input-plan.json']=hashlib.sha256((out/'input-plan.json').read_bytes()).hexdigest()
preserved['input-failure.json']=hashlib.sha256((out/'input-failure.json').read_bytes()).hexdigest()
s=source.read_text(encoding='utf-8')
s=s.replace('OUT.mkdir();inputs=OUT/\'inputs\';inputs.mkdir()', 'OUT.mkdir(exist_ok=True);inputs=OUT/\'inputs\';inputs.mkdir(exist_ok=True)')
s=s.replace("write(OUT/'input-plan.json',plan);shutil.copyfile(__file__,OUT/'prepare-inputs.py');records=[]", "write(OUT/'input-recovery-plan.json',plan);shutil.copyfile(__file__,OUT/'prepare-inputs-recovery.py');records=[]")
s=s.replace("folder=inputs/src.name;folder.mkdir()", "folder=inputs/src.name;folder.mkdir(exist_ok=True)")
s=s.replace("                shutil.copyfile(src/name,folder/name)", "                if (folder/name).exists():assert (folder/name).read_bytes()==(src/name).read_bytes()\n                else:shutil.copyfile(src/name,folder/name)")
s=s.replace("            shutil.copyfile(src/'layout.json',folder/'partial.json')", "            if (folder/'partial.json').exists():assert (folder/'partial.json').read_bytes()==(src/'layout.json').read_bytes()\n            else:shutil.copyfile(src/'layout.json',folder/'partial.json')")
start=s.index("            with gzip.open(folder/'placement-scores.jsonl.gz'")
end=s.index("            assert proposal['placements']",start)
block=s[start:end]
s=s[:start]+"            if (folder/'proposal.json').exists():\n                proposal=load(folder/'proposal.json');inserted=load(folder/'insertions.json');attempts=sum(r['sampled_poses'] for r in inserted)\n            else:\n"+''.join('    '+line if line.strip() else line for line in block.splitlines(keepends=True))+s[end:]
s=s.replace("            write(folder/'proposal.json',proposal);write(folder/'insertions.json',inserted)", "            if not (folder/'proposal.json').exists():write(folder/'proposal.json',proposal);write(folder/'insertions.json',inserted)")
old="""            r=subprocess.run(command,capture_output=True,timeout=60);(folder/'proposal-validation.json').write_bytes(r.stdout);(folder/'proposal-validation-stderr.log').write_bytes(r.stderr)
            write(folder/'proposal-validation-command.json',{'command':command,'exit_code':r.returncode})
            report=json.loads(r.stdout)
            assert not report['valid'] and r.returncode!=0"""
new="""            if (folder/'proposal-validation.json').exists():
                prior=load(folder/'proposal-validation-command.json');assert prior['command']==command
                report=load(folder/'proposal-validation.json');code=prior['exit_code']
            else:
                r=subprocess.run(command,capture_output=True,timeout=60);code=r.returncode
                (folder/'proposal-validation.json').write_bytes(r.stdout);(folder/'proposal-validation-stderr.log').write_bytes(r.stderr)
                write(folder/'proposal-validation-command.json',{'command':command,'exit_code':code});report=json.loads(r.stdout)
            assert not report['valid'] and code!=0"""
assert old in s;s=s.replace(old,new)
s=s.replace("{'overlap','clearance'},codes", "{'overlap','clearance','total_overlap'},codes")
s=s.replace("write(OUT/'input-failure.json'", "write(OUT/'input-recovery-failure.json'")
generated=ROOT/'output/prepare_h5_partial_joint_inputs_recovery.py'
generated.write_text(s,encoding='utf-8',newline='\n')
with (out/'input-recovery-preservation.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'cause':'The checker omitted the expected aggregate total_overlap code for deliberately overlapping complete proposals.','first_proposal_and_scoring_reused':True,'preserved_files':preserved,'new_script_sha256':hashlib.sha256(generated.read_bytes()).hexdigest()},f,indent=2);f.write('\n')
