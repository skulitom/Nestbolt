"""Preserve the initial compile failure and repair the test-only Report ownership error."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(OUT/'native-plan.json');old=OUT/'candidate';work=OUT/'candidate-recovery';rel=plan['changed_file']
target=ROOT/'output/h5-pattern-joint-recovery-target-20261018'
assert load(OUT/'native-build.json')['exit_code']==101
assert not work.exists() and not target.exists()
shutil.copytree(old,work)
text=(old/rel).read_text(encoding='utf-8');needle='best: (before.clone(), before_report.clone(), 0.0),'
assert text.count(needle)==1
(work/rel).write_text(text.replace(needle,'best: (before.clone(), validate(&job, &before).unwrap(), 0.0),'),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=work,check=True)
assert (work/rel).read_text(encoding='utf-8')==text.replace(needle,'best: (before.clone(), validate(&job, &before).unwrap(), 0.0),')
for p in old.rglob('*'):
    if p.is_file() and p.relative_to(old).as_posix()!=rel:assert digest(p)==digest(work/p.relative_to(old))
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--no-run','--target-dir',str(target)]
write(OUT/'native-recovery-plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'cause':'Report does not implement Clone. The appended diagnostic obtains an equivalent second validation report for the existing Search initializer.',
    'prior_compile_record_sha256':digest(OUT/'native-build.json'),'prior_log_sha256':digest(OUT/'native-build.log'),
    'original_source_preserved':str(old),'old_test_source_sha256':digest(old/rel),'new_test_source_sha256':digest(work/rel),
    'work':str(work),'target':str(target),'command':command,'all_runtime_and_prior_tests_unchanged':True,'new_measurements_before_repair':0})
started=datetime.now(timezone.utc).isoformat()
with (OUT/'native-recovery-build.log').open('xb') as log:
    r=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode}
if r.returncode==0:
    bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
    shutil.copyfile(bins[0],OUT/'native-tests.exe');record['binary_sha256']=digest(OUT/'native-tests.exe')
write(OUT/'native-recovery-build.json',record);shutil.copyfile(__file__,OUT/'recover-build.py')
print(json.dumps(record),flush=True);assert r.returncode==0
