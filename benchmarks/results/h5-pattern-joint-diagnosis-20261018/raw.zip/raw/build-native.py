"""Compile the isolated appended test on CCD1; do not execute measurements."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
plan=json.loads((OUT/'native-plan.json').read_bytes());target=Path(plan['target']);assert not target.exists()
started=datetime.now(timezone.utc).isoformat()
with (OUT/'native-build.log').open('xb') as log:
    r=subprocess.run(plan['build_command'],cwd=OUT/'candidate',stdout=log,stderr=subprocess.STDOUT,timeout=1800)
record={'command':plan['build_command'],'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode}
if r.returncode==0:
    bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
    shutil.copyfile(bins[0],OUT/'native-tests.exe');record['binary_sha256']=sha256((OUT/'native-tests.exe').read_bytes()).hexdigest()
with (OUT/'native-build.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
shutil.copyfile(__file__,OUT/'build-native.py');print(json.dumps(record),flush=True)
assert r.returncode==0
