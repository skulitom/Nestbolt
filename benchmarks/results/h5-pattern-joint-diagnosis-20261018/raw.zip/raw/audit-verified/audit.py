"""Independently audit saved originals, restored copies, scores and any repaired full layouts."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import gzip,itertools,json,math,shutil,subprocess,sys,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pattern-joint-probe-20261018'
AUDIT=OUT/'audit-verified';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygon(part,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])
    assert not t['mirrored'] or part['allow_mirror']
    if part['rotations']['kind']=='list':
        assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
    assert len(part['geometry'])==1
    vertices=[]
    for x,y in part['geometry'][0]['outer']:
        if t['mirrored']:x=-x
        vertices.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
    g=Polygon(vertices);assert g.is_valid and g.area>0;return g
def geometry(job,layout,target_height,require_complete,require_separated):
    parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];e=job['edge_clearance']
    expected=Counter({p['id']:p['quantity'] for p in job['parts']});counts=Counter(p['part_id'] for p in layout['placements'])
    assert not counts-expected
    if require_complete:assert counts==expected
    assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
    assert len(layout['sheets'])==2 and {p['id'] for p in layout['sheets']}=={'sheet-0','sheet-1'}
    groups=[[],[]];tops=[0.,0.]
    for p in layout['placements']:
        assert 0<=p['copy_index']<parts[p['part_id']]['quantity']
        g=polygon(parts[p['part_id']],p['transform']);i=int(p['sheet_id'][-1]);a,b,c,d=g.bounds
        assert a>=m['left']+e-1e-7 and b>=m['bottom']+e-1e-7
        assert c<=stock['width']-m['right']-e+1e-7 and d<=[stock['height'],target_height][i]-m['top']-e+1e-7
        groups[i].append(g);tops[i]=max(tops[i],d)
    pairs=0;overlap=0.;conflicts=0;minimum=None
    for group in groups:
        for a,b in itertools.combinations(group,2):
            pairs+=1;distance=a.distance(b);area=a.intersection(b).area
            if distance<job['clearance']-1e-7:conflicts+=1
            overlap+=area;minimum=distance if minimum is None else min(minimum,distance)
            if require_separated:assert a.disjoint(b) and distance>=job['clearance']-1e-7
    material=stock['width']*(stock['height']+tops[1]+m['top']+e)
    return {'pairs':pairs,'conflicts':conflicts,'filled_overlap_mm2':overlap,'minimum_distance_mm':minimum,
        'counts':dict(counts),'missing':dict(expected-counts),'filled_material_mm2':material,'source_used_height_mm':tops[1]+m['top']+e}
def compare_roundtrip(actual,expected,path=''):
    differences=[]
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and actual.keys()==expected.keys(),path
        for key in expected:differences.extend(compare_roundtrip(actual[key],expected[key],path+'/'+key))
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),path
        for i,(a,b) in enumerate(zip(actual,expected)):differences.extend(compare_roundtrip(a,b,path+'/'+str(i)))
    elif actual!=expected:
        assert isinstance(actual,float) and isinstance(expected,float),path
        error=abs(actual-expected);ulp=math.ulp(expected)
        assert error<=ulp,(path,actual,expected,error/ulp)
        differences.append({'path':path,'input':expected,'native_echo':actual,'absolute_error':error,'ULPs':error/ulp})
    return differences

def main():
    AUDIT.mkdir();shutil.copyfile(__file__,AUDIT/'audit.py')
    plan=load(OUT/'native-plan.json');native=load(OUT/'native-runs/checks.json');assert native['complete']
    assert source_digest()==plan['production_digest']
    old=Path(plan['old_source']);rel=plan['changed_file'];recovery=load(OUT/'native-recovery-plan.json');work=Path(recovery['work'])
    for row in plan['source_files']:
        assert digest(old/row['path'])==row['sha256']
        if row['path']!=rel:assert digest(work/row['path'])==row['sha256']
    parent=(old/rel).read_text(encoding='utf-8');current=(work/rel).read_text(encoding='utf-8');pos=parent.rindex('\n}')
    assert current.startswith(parent[:pos]) and current.endswith(parent[pos:])
    assert digest(work/rel)==recovery['new_test_source_sha256']
    assert digest(OUT/'native-build.log')==recovery['prior_log_sha256']
    preserved=load(OUT/'input-recovery-preservation.json')
    for name,d in preserved['preserved_files'].items():assert digest(OUT/name)==d
    records=[]
    try:
        for row in native['cases']:
            case=row['case'];folder=OUT/'inputs'/case;job=load(folder/'job.json');partial=load(folder/'partial.json');proposal=load(folder/'proposal.json')
            target=load(folder/'conditional-target.json');h=target['required_used_height_mm'];parts={p['id']:p for p in job['parts']}
            assert proposal['placements'][:len(partial['placements'])]==partial['placements']
            assert (folder/'partial.json').read_bytes()==(ROOT/'output/h5-outline-backfill-20261018'/case/'layout.json').read_bytes()
            partial_check=geometry(job,partial,h,False,True);proposal_check=geometry(job,proposal,h,True,False)
            assert proposal_check['conflicts']>0 and proposal_check['filled_overlap_mm2']>0
            insertions=load(folder/'insertions.json');mins={};counts=Counter()
            with gzip.open(folder/'placement-scores.jsonl.gz','rt',encoding='utf-8') as f:
                for line in f:
                    idx,sheet,x,y,angle,mirror,area,deficit,n=json.loads(line)
                    score=[area,deficit,n,int(sheet[-1]),y,x,angle,mirror]
                    if idx not in mins or score<mins[idx]:mins[idx]=score
                    counts[idx]+=1
            running=list(partial['placements']);score_pairs=0
            for i,event in enumerate(insertions):
                assert event['score']==mins[i] and event['sampled_poses']==counts[i]
                selected=event['selected'];assert proposal['placements'][len(partial['placements'])+i]==selected
                g=polygon(parts[selected['part_id']],selected['transform']);area=0.;deficit=0.;n=0
                for p in running:
                    if p['sheet_id']!=selected['sheet_id']:continue
                    q=polygon(parts[p['part_id']],p['transform']);d=g.distance(q);score_pairs+=1
                    if d<job['clearance']:n+=1;deficit+=job['clearance']-d;area+=g.intersection(q).area
                assert abs(area-event['score'][0])<1e-6 and abs(deficit-event['score'][1])<1e-7 and n==event['score'][2]
                running.append(selected)
            public=load(folder/'proposal-validation.json');assert not public['valid']
            assert {v['code'] for v in public['violations']}<={'overlap','clearance','total_overlap'}
            r=load(OUT/'native-runs'/case/'result.json');assert r['seed']==0 and r['budget']==12
            fixture=load(folder/'fixture.json')
            roundtrip=[]
            for key in ['job','before','partial','proposal']:roundtrip.extend(compare_roundtrip(r[key],fixture[key],key))
            echo_partial=geometry(job,r['partial'],h,False,True)
            echo_proposal=geometry(job,r['proposal'],h,True,False)
            assert echo_partial['counts']==partial_check['counts'] and echo_proposal['counts']==proposal_check['counts']
            write(AUDIT/(case+'-native-json-roundtrip.json'),{'differences':roundtrip,
                'input_files_unchanged':True,'each_difference_at_most_one_ULP':True,
                'native_echo_partial':echo_partial,'native_echo_proposal':echo_proposal})
            assert r['target_internal_rounded_down']<=r['target_internal_exact']
            target_roundtrip=compare_roundtrip(r['target_height_mm'],h,'target_height_mm')+compare_roundtrip(r['target_material_mm2'],target['target_material_mm2'],'target_material_mm2')
            write(AUDIT/(case+'-target-roundtrip.json'),{'differences':target_roundtrip,
                'geometry_and_any_success_checked_against_original_target':True})
            assert r['stats']['joint_repair_attempts']==1
            after_check=None
            if r['success']:
                after_check=geometry(job,r['after'],h,True,True)
                assert after_check['filled_material_mm2']<=target['target_material_mm2']+1e-7
                dest=AUDIT/case;dest.mkdir();write(dest/'layout.json',r['after'])
                cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
                assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
                command=[str(cli),'validate','--library',str(folder/'library.json'),'--request',str(folder/'request.json'),'--layout',str(dest/'layout.json')]
                cp=subprocess.run(command,capture_output=True,timeout=60)
                (dest/'stdout.json').write_bytes(cp.stdout);(dest/'stderr.log').write_bytes(cp.stderr)
                write(dest/'command.json',{'command':command,'exit_code':cp.returncode});report=json.loads(cp.stdout)
                assert cp.returncode==0 and report['valid'] and report['metrics']['material_area']<=target['target_material_mm2']
            else:assert r['after'] is None and r['after_report'] is None and r['stats'].get('joint_repair_completed',0)==0
            records.append({'case':case,'partial':partial_check,'proposal':proposal_check,'inserted_parts':len(insertions),
                'scored_poses_checked':sum(counts.values()),'selected_score_pairs':score_pairs,'original_partial_poses_preserved':True,
                'native_json_roundtrip_differences':len(roundtrip),'native_json_max_absolute_error':max((v['absolute_error'] for v in roundtrip),default=0.),'native_loss_observations':r['native_loss_observations'],'conversion_guard_mm':r['conversion_guard_mm'],
                'success':r['success'],'after':after_check,'work_seconds':row['work_seconds'],'wall_seconds':row['wall_seconds'],
                'expired':r['stats'].get('joint_repair_expired',0),'failed':r['stats'].get('joint_repair_failed',0)})
        write(AUDIT/'checks.json',{'all_stated_scope_checks_passed':True,'cases':records,'production_digest':source_digest(),
            'all_runtime_and_previous_tests_preserved':True,'original_failures_preserved':True,'new_quality_runs':0,
            'complete_target_layouts':sum(r['success'] for r in records),'H5_complete':False})
        print(json.dumps({'verified':True,'cases':len(records),'complete_layouts':sum(r['success'] for r in records),
            'input_score_count':sum(r['scored_poses_checked'] for r in records)}),flush=True)
    except Exception as e:
        write(AUDIT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed':records});raise
if __name__=='__main__':main()
