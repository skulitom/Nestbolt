"""Seal the additional count exclusion and rejected seven-part source readback."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-source-projection-short12-20261029';MINIMUM=ROOT/'output/h5-five-bracket-two-cog-core-20261029';PUB=BASE/'publication';NAME='h5-short12-exclusion-and-seven-part-readback-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='f96cf8a2b3fed7be3b35dd4faa1c0b662b7d4595' and not git('diff','HEAD','--name-only')
for p in [BASE/'model-audit/checks.json',BASE/'response-audit/checks.json',BASE/'next-short11-preflight/checks.json',BASE/'next-short11-preflight/frontier-audit.json',MINIMUM/'preflight/checks.json',MINIMUM/'model-audit/checks.json',MINIMUM/'response-audit/checks.json',MINIMUM/'source-audit/checks.json']:assert load(p)['passed']
short=load(BASE/'response-audit/checks.json');small=load(MINIMUM/'response-audit/checks.json');assert short['status']=='INFEASIBLE' and short['new_excluded_counts']==[[5,5,2]] and short['remaining_candidates']==440 and small['status']=='OPTIMAL' and not small['source_valid7'] and not small['any_additional_allocation_excluded']
prior=load(ROOT/'benchmarks/results/h5-short-source-reference-exclusion-20261029/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert main=='3e33dedbed809b2fdd3b97a8784b50a25732c3c0' and ci['head_sha']==main and ci['id']==40800774981 and ci['status']=='completed' and ci['conclusion']=='success' and len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,MINIMUM]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['build_h5_source_projection_short12_20261029.py','audit_h5_source_projection_short12_model_20261029.py','prepare_h5_source_projection_short12_call_20261029.py','run_h5_source_projection_short12_20261029.py','check_h5_source_projection_short12_candidate_20261029.py','audit_h5_source_projection_short12_response_20261029.py','prepare_h5_minimum_two_cog_core_20261029.py','build_h5_minimum_two_cog_core_20261029.py','audit_h5_minimum_two_cog_core_20261029.py','prepare_h5_minimum_two_cog_call_20261029.py','run_h5_minimum_two_cog_core_20261029.py','check_h5_minimum_two_cog_candidate_20261029.py','audit_h5_minimum_two_cog_response_20261029.py','audit_h5_minimum_two_cog_source_20261029.py','prepare_h5_next_short11_inventory_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_short12_and_minimum_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(BASE,'model-audit/checks.json','short12-model-audit.json'),(BASE,'model-audit/inactive-owner-proof.json','short12-inactive-owner-proof.json'),(BASE,'response-audit/checks.json','short12-response-audit.json'),(BASE,'response-audit/source-necessity-proof.json','short12-necessity-proof.json'),(BASE,'response-audit/updated-allocations.json','updated-allocations.json'),(BASE,'response-audit/pareto-necessary-counts.json','pareto-necessary-counts.json'),(BASE,'next-short11-preflight/frontier-audit.json','frontier-audit.json'),(BASE,'next-short11-preflight/inventory.json','next-short11-inventory.json'),(BASE,'next-short11-preflight/checks.json','next-short11-preflight.json'),(MINIMUM,'preflight/checks.json','minimum7-preflight.json'),(MINIMUM,'model-audit/checks.json','minimum7-model-audit.json'),(MINIMUM,'model-audit/inactive-owner-proof.json','minimum7-inactive-owner-proof.json'),(MINIMUM,'response-audit/checks.json','minimum7-response-audit.json'),(MINIMUM,'source-audit/checks.json','minimum7-source-audit.json'),(MINIMUM,'source-audit/replayed-source7-checks.json','minimum7-source-failures.json'),(MINIMUM,'search/source-response/decoded-core7.json','minimum7-core-placement.json')]
for folder,a,b in copies:shutil.copyfile(folder/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40800774981,'main_all6_pass':True,'queued_commit_before_this_checkpoint':head,'normal_push_ready_after_local_evidence_commit':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Use the prepared short11=5 brackets/4 inserts/2 cogs and first55=18 frames/7 brackets/17 inserts/13 cogs inventory. Precisely insert0 and insert2 are inactive on short and mandatory on first. All11 other owners remain mandatory and movable. Build a distinct model with no fixed active poses, audit both inactive-slot dependencies, all66 identities, parent changes and positive10/negative11 controls, then use its sole declared60/90-second call. Preserve the closed excluded5/5/2 and5/6/2 calls. The closed5/0/2 necessary-model witness fails original-source checks and proves neither source feasibility nor infeasibility. No native call before an independently valid complete66 layout. Original/native/material validation, production integration and the full H5 matrix remain required.','next_short_originals':11,'next_first_originals':55,'new_short11_model_created':False,'new_short11_search_opened':False,'remaining_necessary_allocations':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'closed_solver_calls':2,'short12_status':'INFEASIBLE','short12_exclusion_qualified':True,'new_excluded_short_counts':[[5,5,2]],'previous_survivors':441,'remaining_necessary_allocations':440,'all4576_rows_preserved':True,'remaining_pareto_counts':32,'minimum7_status':'OPTIMAL','minimum7_satisfaction_model_only':True,'minimum7_original_source_valid':False,'minimum7_original_source_pair_failures':5,'minimum7_original_source_stock_failures':5,'incumbents':1,'assignments':1,'source_checker_calls':1,'all_calls_within_budgets':True,'native_calls':0,'source_valid66_created':False,'whole_job_excluded':False,'valid64_preserved':True,'next_short_originals':11,'next_first_originals':55,'next_all66_identities_verified':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [three short-sheet count vectors are excluded](../benchmarks/results/h5-short-source-reference-exclusion-20261029.md),\nleaving 441 necessary allocation candidates.';new=f'Latest H5 evidence: [the 5/5/2 short-sheet allocation is excluded](../benchmarks/results/{NAME}.md),\nleaving 440 necessary allocation candidates.';assert old in s;s=s.replace(old,new,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'remaining_candidates':440,'completion_percent':60})
