"""Observe the rejected larger-return candidate without changing decisions or work charges."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-stage-20261018'
old=root/'output/h5-larger-return-probe-20261018/candidate';work=out/'workspace'
out.mkdir();shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs';path=work/rel
original=path.read_text(encoding='utf-8');text=original;changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,(before,text.count(before))
    text=text.replace(before,after);changes.append((before,after))
# Reuse qualified identity/repair observations; the removed area filter is no
# longer an outcome. Every other sample partition remains identical.
prior=(root/'output/prepare_h5_mixed_stage.py').read_text(encoding='utf-8')
start=prior.index("# Reuse the already-qualified")
end=prior.index("exec(compile((root/'output/mixed_generation_instrumentation.py')")
exec(compile(prior[start:end],'<mixed stage observations>','exec'))
generation=(root/'output/mixed_generation_instrumentation.py').read_text(encoding='utf-8')
start=generation.index("replace('''        if area > incoming_area")
end=generation.index("replace('''    out",start)
generation=generation[:start]+'''replace('''+repr('        let area: f32 = victims.iter().map(|(_, (_, p))| p.item().area()).sum();\n        retain_proposal(')+','+repr('        let area: f32 = victims.iter().map(|(_, (_, p))| p.item().area()).sum();\n        generation.eligible += 1;\n        retain_proposal(')+')\n'+generation[end:]
exec(compile(generation,'<larger-return sampling observations>','exec'))
replace('''    pair_phase_remaining: Option<f64>,
    proposals:''','''    pair_phase_remaining: Option<f64>,
    total_elapsed: f64,
    baseline_elapsed: Option<f64>,
    entry_remaining: Option<f64>,
    choice_setup: Vec<serde_json::Value>,
    #[serde(skip)]
    started: Option<Instant>,
    proposals:''')
replace('''        eprintln!("BALANCED_DIAG {}",''','''        self.total_elapsed = self.started.as_ref().map_or(0.0, |t|t.elapsed().as_secs_f64());
        eprintln!("BALANCED_DIAG {}",''')
replace('''        let mut trace = BalancedTrace::default();''','''        let mut trace = BalancedTrace::default();
        let _ = trace.started.replace(Instant::now());''')
replace('''        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;''','''        trace.entry_remaining = Some(until - self.clock.now());
        let baseline_started = Instant::now();
        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;
        trace.baseline_elapsed = Some(baseline_started.elapsed().as_secs_f64());''')
replace('''                let offset = strip.start(target);''','''                let setup_started = Instant::now();
                let setup_remaining = exchange_until - self.clock.now();
                let offset = strip.start(target);''')
replace('''                let proposal_until = self.last_step(exchange_until);''','''                trace.choice_setup.push(serde_json::json!({"incoming_ids":members.iter().map(|(_,item,_)|item.idx()).collect::<Vec<_>>(),"paired":paired,"target":target,"start_remaining":setup_remaining,"elapsed":setup_started.elapsed().as_secs_f64()}));
                let proposal_until = self.last_step(exchange_until);''')
replace('''    source_elapsed: Option<f64>,
    after_material:''','''    source_elapsed: Option<f64>,
    attempt_setup_elapsed: Option<f64>,
    reconstruction_elapsed: Option<f64>,
    validation_elapsed: Option<f64>,
    accepted_phase_remaining: Option<f64>,
    accepted_total_remaining: Option<f64>,
    after_material:''')
replace('''                    let index = trace.attempts.len();''','''                    let attempt_started = Instant::now();
                    let index = trace.attempts.len();''')
replace('''                        source_remaining: None, source_elapsed: None,
                        after_material:''','''                        source_remaining: None, source_elapsed: None,
                        attempt_setup_elapsed: None, reconstruction_elapsed: None,
                        validation_elapsed: None, accepted_phase_remaining: None,
                        accepted_total_remaining: None,
                        after_material:''')
replace('''                    let receiver_started = Instant::now();''','''                    trace.attempts[index].attempt_setup_elapsed = Some(attempt_started.elapsed().as_secs_f64());
                    let receiver_started = Instant::now();''')
replace('''                    let mut trial = JLayout::from_snapshot(&sep.layout.save());''','''                    let reconstruction_started = Instant::now();
                    let mut trial = JLayout::from_snapshot(&sep.layout.save());''')
replace('''                    let report = self.exchange_report(strip, frozen, &trial, shape)?;''','''                    trace.attempts[index].reconstruction_elapsed = Some(reconstruction_started.elapsed().as_secs_f64());
                    let validation_started = Instant::now();
                    let report = self.exchange_report(strip, frozen, &trial, shape)?;
                    trace.attempts[index].validation_elapsed = Some(validation_started.elapsed().as_secs_f64());''')
replace('''                    trace.attempts[index].outcome = "accepted";''','''                    trace.attempts[index].outcome = "accepted";
                    trace.attempts[index].accepted_phase_remaining = Some(exchange_until - self.clock.now());
                    trace.attempts[index].accepted_total_remaining = Some(until - self.clock.now());''')
text=text.replace('BALANCED_DIAG ','LARGER_DIAG ').replace('MIXED_GENERATION ','LARGER_GENERATION ')
reverse=text.replace('LARGER_DIAG ','BALANCED_DIAG ').replace('LARGER_GENERATION ','MIXED_GENERATION ')
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n')
patch=list(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='rejected/'+rel,tofile='observed/'+rel))
changed=[rel]
# Observe only accepted exchanges, after the existing control-flow decision.
rel='crates/core/src/sheets/vstrip.rs';path=work/rel;original=path.read_text(encoding='utf-8');text=original
insertions=[]
for needle,stage in [('                        let gaps = std::env::var_os("NESTBOLT_NO_FILL").is_none();','after_exchange'),
                     ('                        if exchanged > 0\n                            || gap_moves > 0','after_fill')]:
    insert='''                        if exchanged > 0 {
                            let mut observed_sheets = frozen.to_vec();
                            observed_sheets.extend(strip.split(&sep.layout, shape.sheets)?);
                            let observed_layout = self.model.to_layout(&observed_sheets);
                            eprintln!("LARGER_LAYOUT {}", serde_json::json!({"stage":"'''+stage+'''","exchange_count":self.stats.directed_exchanges,"remaining":(t+1.2).min(budget)-self.clock.now(),"layout":observed_layout,"stats":&self.stats}));
                        }
'''
    assert text.count(needle)==1;text=text.replace(needle,insert+needle);insertions.append(insert)
reverse=text
for insert in insertions:assert reverse.count(insert)==1;reverse=reverse.replace(insert,'')
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n');changed.append(rel)
patch.extend(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='rejected/'+rel,tofile='observed/'+rel))
(out/'instrumentation.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
files=[{'path':p.relative_to(old).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(old.rglob('*')) if p.is_file()]
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_source':str(old),'changed_file':changed[0],'changed_files':changed,'source_files':files,
 'production_digest':source_digest(),'target':str(root/'output/h5-larger-stage-target-20261018'),'instrumentation_reversible_to_exact_original_text':True,
 'proposal_repair_acceptance_settings_unchanged':True,'original_tests':113,'measurement_planned':{'jobs':['m-mechanical-large-plates','m-mechanical-panel-hardware'],'kerfs':[.2,1.5],'seed':0,'seconds':60,'cpu':8,'serial':True}}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_mixed_stage.py').read_text(encoding='utf-8').replace('h5-mixed-stage','h5-larger-stage')
builder=builder.replace("if r['path']!=plan['changed_file']:","if r['path'] not in plan['changed_files']:")
builder=builder.replace("'source_sha256':digest(WORK/plan['changed_file'])","'source_sha256':digest(WORK/plan['changed_file']),'observed_sources':{rel:digest(WORK/rel) for rel in plan['changed_files']}")
(root/'output/build_h5_larger_stage.py').write_text(builder,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'instrumentation_reversible':True,'changed_files':changed,'original_tests':113,'other_files_exact':len(files)-2}))
