from pathlib import Path
import ast,json
from hashlib import sha256
root=Path(__file__).resolve().parents[1]
for old,new in [('finish_h5_mixed_stage.py','finish_h5_larger_stage.py'),('audit_h5_mixed_stage.py','audit_h5_larger_stage.py')]:
    text=(root/'output'/old).read_text(encoding='utf-8').replace('h5-mixed-stage','h5-larger-stage').replace('h5_mixed_stage','h5_larger_stage')
    text=text.replace('Mixed-pair sampling and repair observations','Larger-return sampling, timing and repair observations')
    (root/'output'/new).write_text(text,encoding='utf-8',newline='\n');compile(text,new,'exec')
runner=root/'scripts/h5_larger_stage.py';source=root/'scripts/h5_mixed_stage.py'
functions=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)}
assert functions(runner)['run']==functions(source)['run']
record={'measurement_function_AST_exact':True,'original_runner_sha256':sha256(source.read_bytes()).hexdigest(),'runner_sha256':sha256(runner.read_bytes()).hexdigest(),'quality_or_scoring_change':False,'qualification_guards_added':True}
(root/'output/h5-larger-stage-20261018/runner-method-qualified.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared descriptive finish/audit helpers; diagnostic run method remains exact.')
