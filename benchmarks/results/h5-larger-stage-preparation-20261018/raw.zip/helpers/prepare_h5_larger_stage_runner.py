"""Preserve the diagnostic method and validate the expanded observation schema."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1]
def adapt(s):
    return s.replace('h5-mixed-stage','h5-larger-stage').replace('h5_mixed_stage','h5_larger_stage').replace('h5-mixed-exchange-pilot','h5-larger-return-pilot').replace('h5_mixed_exchange_pilot','h5_larger_return_pilot').replace('MIXED_GENERATION ','LARGER_GENERATION ').replace('MIXED_DIAG ','LARGER_DIAG ')
text=adapt((root/'scripts/h5_mixed_stage.py').read_text(encoding='utf-8'))
text=text.replace('mixed-exchange candidate','larger-return candidate')
text=text.replace("                assert p['returned_area']<=p['incoming_area']\n",'')
needle="            assert g['seen']<=g['sample_total']";assert text.count(needle)==1
text=text.replace(needle,"            assert g['area_rejected']==0, 'The candidate has no paired area filter'\n"+needle)
needle="        ps=t['proposals'];seen=set()";assert text.count(needle)==1
extra='''
        assert type(t['total_elapsed']) in [int,float] and math.isfinite(t['total_elapsed']) and t['total_elapsed']>=0
        for key in ['entry_remaining','baseline_elapsed']:
            value=t[key]
            assert value is None or (type(value) in [int,float] and math.isfinite(value))
        assert t['baseline_elapsed'] is None or t['baseline_elapsed']>=0
        assert isinstance(t['choice_setup'],list) and isinstance(t['layouts'],list)
        for setup in t['choice_setup']:
            assert type(setup['paired']) is bool and type(setup['target']) is int and setup['target']>=0
            assert len(setup['incoming_ids'])==(2 if setup['paired'] else 1)
            assert all(type(i) is int and i>=0 for i in setup['incoming_ids'])
            for key in ['elapsed','start_remaining']:assert type(setup[key]) in [int,float] and math.isfinite(setup[key])
            assert setup['elapsed']>=0
        assert sum(s['paired'] for s in t['choice_setup'])==len(t['generations'])
        if t['layouts']:
            assert [v['stage'] for v in t['layouts']]==['after_exchange','after_fill']
            assert sum(a['outcome']=='accepted' for a in t['attempts'])==1
            counts=[v['exchange_count'] for v in t['layouts']]
            assert counts[0]==counts[1] and type(counts[0]) is int and counts[0]>0
            for view in t['layouts']:
                assert type(view['remaining']) in [int,float] and math.isfinite(view['remaining'])
                assert view['stats']['directed_exchanges']==counts[0]
                assert isinstance(view['layout']['placements'],list) and view['layout']['placements']
            assert t['layouts'][1]['stats']['post_exchange_fill_calls']==t['layouts'][0]['stats'].get('post_exchange_fill_calls',0)+1
'''
text=text.replace(needle,needle+extra)
needle="            outcome=a['outcome']";assert text.count(needle)==1
extra='''            for key in ['attempt_setup_elapsed','reconstruction_elapsed','validation_elapsed']:
                value=a[key]
                assert value is None or (type(value) in [int,float] and math.isfinite(value) and value>=0)
            assert (a['attempt_setup_elapsed'] is None)==(a['receiver_initial_loss'] is None)
            assert (a['reconstruction_elapsed'] is None)==(a['after_last_extent'] is None)
            assert (a['validation_elapsed'] is None)==(a['after_last_extent'] is None)
            for key in ['accepted_phase_remaining','accepted_total_remaining']:
                value=a[key]
                if a['outcome']=='accepted':assert type(value) in [int,float] and math.isfinite(value)
                else:assert value is None
'''
text=text.replace(needle,extra+needle)
needle="            trace['generations']=pending;pending=[];traces.append(trace)";assert text.count(needle)==1
text=text.replace(needle,"            trace['generations']=pending;trace['layouts']=[];pending=[];traces.append(trace)\n        elif line.startswith('LARGER_LAYOUT '):\n            assert traces and not pending, 'orphaned layout trace'\n            traces[-1]['layouts'].append(json.loads(line.removeprefix('LARGER_LAYOUT ')))")
needle="    return check_traces(traces,record.get('stats') if record['status']=='valid' else None)";assert text.count(needle)==1
text=text.replace(needle,"    summary=check_traces(traces,record.get('stats') if record['status']=='valid' else None)\n    assert sum(len(t['layouts']) for t in traces)==2*summary['outcomes'].get('accepted',0)\n    assert [t['layouts'][0]['exchange_count'] for t in traces if t['layouts']]==list(range(1,summary['outcomes'].get('accepted',0)+1))\n    return summary")
text=text.replace('Pair sample rejection partitions and one stage trace per invocation.', 'Pair sample rejection partitions, choice construction/attempt setup/reconstruction/validation duration, accepted phase and total remaining time, and complete after-exchange/after-fill layouts. Every inserted observation reverses exactly; no decision or work charge changes.')
path=root/'scripts/h5_larger_stage.py';assert not path.exists();path.write_text(text,encoding='utf-8',newline='\n');compile(text,str(path),'exec')
functions=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
original=(root/'scripts/h5_mixed_stage.py').read_text(encoding='utf-8')
assert functions(original)['run']==functions(text)['run']
out=root/'output/h5-larger-stage-20261018'
(out/'runner-method.json').write_text(json.dumps({'measurement_function_AST_exact':True,'original_runner_sha256':sha256(original.encode()).hexdigest(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),'quality_or_scoring_change':False},indent=2)+'\n',encoding='utf-8',newline='\n')
check=adapt((root/'output/check_h5_mixed_stage_reader.py').read_text(encoding='utf-8'))
check=check.replace('return_frame_keeps_incumbent_when_roundoff_increases_charged_material','return_frame_alternative_respects_strict_material_guard')
needle="             'mixed_pair_failed_return_room_preserves_incumbent']:";assert check.count(needle)==1
check=check.replace(needle,"             'mixed_pair_failed_return_room_preserves_incumbent',\n             'larger_return_moves_both_incoming_with_strict_material_guard',\n             'larger_return_disabled_or_expired_preserves_incumbent',\n             'larger_return_failed_room_preserves_incumbent',\n             'larger_return_preserves_a_frozen_sheet',\n             'accepted_exchange_still_fills_a_known_gap']:")
# The old single-proposal rounding rejection may be bypassed by a valid pair.
# Keep its observed truth value and separately execute the actual guard test.
needle="assert any(a['outcome']=='material_guard_failed' and a['after_material']>a['before_material'] for a in summary['attempt_rows'])";assert check.count(needle)==1
check=check.replace(needle,"strict_rejection=any(a['outcome']=='material_guard_failed' and a['after_material']>a['before_material'] for a in summary['attempt_rows'])")
check=check.replace("'strict_material_rejection_observed':True", "'strict_material_rejection_observed':strict_rejection,'direct_strict_guard_test_passed':True")
needle="record={'all_checks_pass':True";assert check.count(needle)==1
extra='''# Validate new timing/snapshot observations against adversarial mutations.
rejected += [
    rejects('negative attempt setup time',lambda t:modify_attempt(t,attempt_setup_elapsed=-1)),
    rejects('nonfinite accepted remaining time',lambda t:modify_attempt(t,accepted_total_remaining=float('nan'))),
    rejects_generation('removed area filter used',lambda g:g.update(area_rejected=1,eligible=max(0,g['eligible']-1))),
]
window=next(t for t in all_traces if t['layouts'])
for name,mutate in [
    ('reversed layout stages',lambda t:t['layouts'].reverse()),
    ('wrong exchange ordinal',lambda t:t['layouts'][1].update(exchange_count=999)),
    ('nonfinite fill allowance',lambda t:t['layouts'][1].update(remaining=float('nan'))),
    ('missing accepted layout stage',lambda t:t['layouts'].pop()),
    ('negative choice construction time',lambda t:t['choice_setup'][0].update(elapsed=-1)),
]:
    t=copy.deepcopy(window);mutate(t)
    try:runner.check_traces([t])
    except AssertionError:rejected.append(name)
    else:raise AssertionError('Reader accepted '+name)
try:runner.parse_log('LARGER_LAYOUT {}')
except AssertionError:rejected.append('orphaned layout trace')
else:raise AssertionError('Reader accepted orphaned layout trace')
name='exchange_material_guard_rejects_even_one_ulp_and_extra_sheets'
command=[str(binary),'--exact','sheets::vstrip::exchange::tests::'+name,'--nocapture']
r=subprocess.run(command,cwd=probe/'workspace',capture_output=True,timeout=120)
(out/(name+'-stdout.log')).write_bytes(r.stdout);(out/(name+'-stderr.log')).write_bytes(r.stderr)
assert r.returncode==0 and '1 passed; 0 failed' in r.stdout.decode()
runner.write(out/'strict-guard-command.json',{'command':command,'exit_code':r.returncode})
'''
check=check.replace(needle,extra+needle)
dest=root/'output/check_h5_larger_stage_reader.py';dest.write_text(check,encoding='utf-8',newline='\n');compile(check,str(dest),'exec')
print('Prepared unchanged diagnostic run method and expanded reader checks.')
