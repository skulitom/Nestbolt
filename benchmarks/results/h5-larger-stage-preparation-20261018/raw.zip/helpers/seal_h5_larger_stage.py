from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-stage-20261018'
out=root/'benchmarks/results/h5-larger-stage-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_larger_stage as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '113 passed; 0 failed' in (probe/'core-tests-v2.log').read_text(encoding='utf-8')
assert load(probe/'reconstruction.json')['all_formatted_files_exact']
assert runner.prior.source_digest()==plan['production_digest']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path'] not in plan['changed_files']:assert digest(probe/'workspace'/row['path'])==row['sha256']
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==14
assert len(reader['malformed_records_rejected'])==31 and reader['identity_multiset_checks']==4
assert reader['direct_strict_guard_test_passed'] and reader['reader_sha256']==digest(root/'scripts/h5_larger_stage.py')
method=load(probe/'runner-method-qualified.json');assert method['measurement_function_AST_exact'] and method['runner_sha256']==reader['reader_sha256']
binaries=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
assert digest(binaries[0])==reader['test_binary_sha256']
shutil.copyfile(binaries[0],probe/'authored-tests.exe')
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_larger_stage.py','build_h5_larger_stage.py','repair_h5_larger_stage_initialization.py','build_h5_larger_stage_v2.py',
 'prepare_h5_larger_stage_runner.py','check_h5_larger_stage_reader.py','check_h5_larger_stage_reconstruction.py','prepare_h5_larger_stage_reports.py',
 'seal_h5_larger_stage.py','record_h5_larger_stage_preparation.py','check_h5_larger_stage_layouts.py',
 'prepare_h5_mixed_stage.py','prepare_h5_balanced_stage.py','mixed_generation_instrumentation.py']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_larger_stage.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_qualified':True,'optimized_core_tests_passed':113,'strict_lint_passed':True,'observer_build_passed':True,
 'authored_test_traces':14,'malformed_records_rejected':31,'identity_multiset_checks':4,'direct_strict_guard_test_passed':True,
 'observed_sources':build['observed_sources'],'all_original_tests_unchanged':True,'exact_source_reconstruction':True,'unchanged_other_files':152,
 'first_compiler_failure_preserved':True,'production_and_rejected_candidate_unchanged':True,'measured_search_started':False,'quality_claim':False,'H5_complete':False}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','reconstruction.json','compile-repair.json','instrumentation-corrected.patch','runner-method-qualified.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'authored-trace-reader/checks.json',out/'reader-checks.json')
doc='''# Larger-return timing and intermediate layouts — preparation, 2026-10-18

The [larger-return pilot](h5-larger-return-pilot-20261018.md) validates all 72
layouts but fails five of eight material comparisons. Ten paired exchanges
succeed, including one mixed pair; panel hardware still attempts no mixed
exchange. Counts alone do not identify the expensive phases or later benefit.

This separate observer retains proposal/sample partitions, original-item
inventories, repair losses and immediate material. It adds elapsed times for
initial validation, receiver/source construction, per-attempt setup, trial
reconstruction and final validation, plus remaining phase/total time at an
acceptance. Accepted exchanges also save complete original-job layouts before
and after the existing gap-fill step. The follow-up must independently validate
each snapshot and check filled outer rings with the original kerf tolerance;
material change during filling is measured without assuming nonincrease.

The inserted observations reverse exactly. A fresh reconstruction from the
rejected source matches every one of 154 formatted files, with 152 unchanged
and only two instrumented files. All 113 original optimized core tests pass,
as do strict lint/build, fourteen actual authored trace cases and the direct
one-ULP/material-sheet guard test. The reader rejects 31 malformed observations
and checks four original-item multisets. The removed area filter must record
zero area rejections; larger returned area is allowed in the reader while
strict accepted-material and geometry conditions remain unchanged.

The first logger constructor failed Rust E0509 because functional update
syntax moved fields from a Drop implementation. Its source and failed build
are preserved. Initializing Default and setting only the observation timer
fixes it; no test or search ran before that correction.

Four serial seed-zero diagnostic searches use the two mechanical jobs, both
kerfs, 60 seconds and physical CCD0 CPU 8. The measurement function is
AST-identical to the previous diagnostic. Logging and snapshot conversion may
perturb wall-clock trajectories. Timings describe this instrumented execution,
not minimum repair time, a speedup or a replay of the failed quality pilot.
No algorithm, budget, gate, production source or reserved input changes.
H2/H5 remain open; completion stays 60%.

[Checks](h5-larger-stage-preparation-20261018/checks.json),
[reader cases](h5-larger-stage-preparation-20261018/reader-checks.json),
[exact reconstruction](h5-larger-stage-preparation-20261018/reconstruction.json)
and [archive integrity](h5-larger-stage-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-larger-stage-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size,'all_qualified':True}))
