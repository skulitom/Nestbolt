from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-stage-20261018';saved=out/'first-compile-failure';saved.mkdir()
shutil.copytree(out/'workspace',saved/'workspace')
for name in ['format.log','core-tests.log','progress.json','build-failure.json','exchange-before-format.rs','preparation.json','instrumentation.patch']:
    shutil.copyfile(out/name,saved/name)
for name in ['prepare_h5_larger_stage.py','build_h5_larger_stage.py']:shutil.copyfile(root/'output'/name,saved/name)
path=out/'workspace/crates/core/src/sheets/vstrip/exchange.rs';s=path.read_text(encoding='utf-8')
bad='''        let mut trace = BalancedTrace {
            started: Some(Instant::now()),
            ..BalancedTrace::default()
        };'''
good='''        let mut trace = BalancedTrace::default();
        let _ = trace.started.replace(Instant::now());'''
assert s.count(bad)==1;s=s.replace(bad,good);path.write_text(s,encoding='utf-8',newline='\n')
old_line='        let mut trace = BalancedTrace { started: Some(Instant::now()), ..BalancedTrace::default() };'
p=out/'exchange-before-format.rs';before=p.read_text(encoding='utf-8');assert before.count(old_line)==1
before=before.replace(old_line,good);p.write_text(before,encoding='utf-8',newline='\n')
p=root/'output/prepare_h5_larger_stage.py';script=p.read_text(encoding='utf-8');assert script.count(old_line)==1
script=script.replace(old_line,good);p.write_text(script,encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_larger_stage.py').read_text(encoding='utf-8')
builder=builder.replace("OUT/(label+'.log')","OUT/(label+'-v2.log')").replace("OUT/'progress.json'","OUT/'progress-v2.json'").replace("OUT/'build-failure.json'","OUT/'build-failure-v2.json'").replace("OUT/'build-opened.json'","OUT/'build-opened-v2.json'")
# Preserve the corrected pre-format source rather than copying formatted text.
builder=builder.replace("shutil.copyfile(WORK/plan['changed_file'],OUT/'exchange-before-format.rs')", "assert (OUT/'exchange-before-format.rs').exists()")
(root/'output/build_h5_larger_stage_v2.py').write_text(builder,encoding='utf-8',newline='\n')
p=root/'output/check_h5_larger_stage_reader.py';reader=p.read_text(encoding='utf-8')
assert reader.count('larger_return_without_return_room_preserves_incumbent')==1
p.write_text(reader.replace('larger_return_without_return_room_preserves_incumbent','larger_return_failed_room_preserves_incumbent'),encoding='utf-8',newline='\n')
record={'failure':'Rust E0509: functional update syntax moves fields from a Drop implementation.','fix':'Initialize the existing Default value, then set only its observation timer.','no_tests_or_searches_ran':True,
 'failed_source_sha256':sha256((saved/'workspace/crates/core/src/sheets/vstrip/exchange.rs').read_bytes()).hexdigest(),
 'only_formatted_source_difference':{'before':bad,'after':good},'failed_log_sha256':sha256((saved/'core-tests.log').read_bytes()).hexdigest()}
(out/'compile-repair.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'repair.py');print('Original compiler failure preserved; only logger initialization corrected.')
