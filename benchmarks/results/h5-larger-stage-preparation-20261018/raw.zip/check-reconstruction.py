"""Reconstruct the corrected observer from the immutable rejected source."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-stage-20261018'
helper=root/'output/prepare_h5_larger_stage.py'
text=helper.read_text(encoding='utf-8').replace("out=root/'output/h5-larger-stage-20261018'","out=root/'output/h5-larger-stage-reconstruction-20261018'")
text=text.replace("'output/build_h5_larger_stage.py'","'output/build_h5_larger_stage_reconstruction.py'")
copy=root/'output/reconstruct_h5_larger_stage.py';assert not copy.exists();copy.write_text(text,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,str(copy)],cwd=root,check=True)
reconstructed=root/'output/h5-larger-stage-reconstruction-20261018'
subprocess.run(['cargo','fmt','--all'],cwd=reconstructed/'workspace',check=True)
plan=json.loads((out/'preparation.json').read_bytes());rows=[]
for entry in plan['source_files']:
    rel=entry['path'];a=(reconstructed/'workspace'/rel).read_bytes();b=(out/'workspace'/rel).read_bytes()
    assert a==b,rel
    if rel not in plan['changed_files']:assert sha256(b).hexdigest()==entry['sha256']
    rows.append({'path':rel,'sha256':sha256(b).hexdigest()})
shutil.copyfile(reconstructed/'instrumentation.patch',out/'instrumentation-corrected.patch')
record={'exact_original_text_reversal':True,'corrected_constructor_reconstructed_from_original':True,'all_formatted_files_exact':True,
    'files':rows,'unchanged_other_files':len(rows)-len(plan['changed_files']),'changed_files':plan['changed_files'],
    'new_searches':0,'helper_sha256':sha256(helper.read_bytes()).hexdigest()}
(out/'reconstruction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check-reconstruction.py');print(json.dumps({'all_formatted_files_exact':len(rows),'unchanged_other_files':record['unchanged_other_files']}))
