"""Restore the omitted authored fixture in isolated copies; retain build failure."""
from pathlib import Path
from hashlib import sha256
import json, shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-obstruction-set-probe'
source=ROOT/'examples/validation-job.json';before=sha256((OUT/'candidate/crates/core/src/sheets/vstrip/exchange.rs').read_bytes()).hexdigest()
assert (OUT/'build-failure.json').exists()
for arm in ['baseline','candidate']:
    dest=OUT/arm/'examples/validation-job.json';assert not dest.exists()
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
    assert dest.read_bytes()==source.read_bytes()
(OUT/'fixture-repair.json').write_text(json.dumps({'reason':'Initial isolated copy omitted examples/validation-job.json required by existing include_str tests','original_build_failure_preserved':True,'fixture_sha256':sha256(source.read_bytes()).hexdigest(),'exchange_source_unchanged':before,'measurement_started':False},indent=2)+'\n',encoding='utf-8',newline='\n')
s=(ROOT/'output/build_h5_obstruction_sets.py').read_text(encoding='utf-8')
s=s.replace("'build-opened.json'", "'build-v2-opened.json'").replace("'progress.json'", "'progress-v2.json'").replace("'build.json'", "'build-v2.json'").replace("'build-failure.json'", "'build-v2-failure.json'")
s=s.replace("shutil.copyfile(OUT/'candidate/crates/core/src/sheets/vstrip/exchange.rs',OUT/'exchange-before-format.rs')", "assert load(OUT/'fixture-repair.json')['exchange_source_unchanged']==digest(OUT/'candidate/crates/core/src/sheets/vstrip/exchange.rs')")
s=s.replace("    run('candidate','format',['cargo','fmt','--all'])\n", '')
s=s.replace("log=OUT/(label+'.log')", "log=OUT/(label+'-v2.log')")
s=s.replace("    for r in plan['production_files']:assert digest(ROOT/r['path'])==r['sha256'],r['path']", "    for r in plan['production_files']:assert digest(ROOT/r['path'])==r['sha256'],r['path']\n    for arm in ['baseline','candidate']:assert digest(OUT/arm/'examples/validation-job.json')==load(OUT/'fixture-repair.json')['fixture_sha256']")
compile(s,'build_h5_obstruction_sets_v2.py','exec')
(ROOT/'output/build_h5_obstruction_sets_v2.py').write_text(s,encoding='utf-8',newline='\n')
print('Copied the unchanged authored fixture; preserved the original missing-file failure.')
