"""Prepare authored public-path checks for the set-exchange observers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/check_h5_early_public_v2.py').read_text(encoding='utf-8')
start=old.index('guards = ')
tail=old[start:].replace("'progress-v2.json'", "'progress.json'").replace("'failure-v2.json'", "'failure.json'")
header='''"""Authored fixed-work public checks only; no development performance run."""
from hashlib import sha256
from pathlib import Path
import copy,json,shutil,subprocess,traceback
import psutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-obstruction-set-probe';out=probe/'public-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\\n',encoding='utf-8',newline='\\n')
assert load(probe/'build-v2.json')['all_checks_passed']
stages=load(root/'output/depth-integration-20261016/progress.json')
assert any(r['label']=='native-build' and r['exit_code']==0 for r in stages)
out.mkdir();psutil.Process().cpu_affinity(list(range(16,32)))
for name in ['library.json','normal.json','common.json']:
    shutil.copyfile(root/'output/h5-exchange-probe/public-work-v7'/name,out/name)
cli=out/'nestbolt-validator.exe';shutil.copyfile(root/'target/release/nestbolt.exe',cli)
binaries={arm:probe/(arm+'-observer.exe') for arm in ['baseline','candidate']}
for arm,path in binaries.items():assert digest(path)==load(probe/'build-v2.json')['binaries'][arm]
assert digest(binaries['baseline'])!=digest(binaries['candidate'])
'''
s=header+tail
compile(s,'check_h5_obstruction_public.py','exec')
(ROOT/'output/check_h5_obstruction_public.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared functional checker; not executed.')
