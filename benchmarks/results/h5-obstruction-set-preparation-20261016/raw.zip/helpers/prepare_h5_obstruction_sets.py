"""Prepare an isolated atomic obstruction-set exchange after the saved diagnosis."""
from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-obstruction-set-probe'
OLD=ROOT/'output/h5-early-exchange-probe/candidate'
assert not OUT.exists()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
names=subprocess.check_output(['git','ls-files','-z','--','crates','.cargo','Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE','THIRD_PARTY_NOTICES'],cwd=ROOT).decode().split('\0')
rows=[]
for name in filter(None,names):
    rows.append({'path':name,'sha256':digest(ROOT/name)})
    for arm in ['baseline','candidate']:
        dest=OUT/arm/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,dest)
for name in ['crates/core/src/sheets.rs','crates/core/src/sheets/vstrip.rs','crates/core/src/sheets/vstrip/exchange.rs']:
    dest=OUT/'candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/name,dest)
# Match the new production tree configuration in both arms; only the candidate
# additionally has the previously isolated exchange hooks and the new set move.
p=OUT/'candidate/crates/core/src/sheets/vstrip.rs';s=p.read_text(encoding='utf-8')
root=(ROOT/'crates/core/src/sheets/vstrip.rs').read_text(encoding='utf-8')
a=root.index('        let mut cde = DEFAULT_SPARROW_CONFIG.cde_config;');b=root.index('        cde.quadtree_depth += ',a)
needle='        let mut cde = DEFAULT_SPARROW_CONFIG.cde_config;\n'
assert s.count(needle)==1 and 'cde.quadtree_depth = 3;' in root[a:b]
s=s.replace(needle,root[a:b]);p.write_text(s,encoding='utf-8',newline='\n')
p=OUT/'candidate/crates/core/src/sheets/vstrip/exchange.rs';s=p.read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace('    victim: PItemKey,','    victims: Vec<PItemKey>,')
replace('''fn proposals(''','''fn retain_proposal(out: &mut Vec<Proposal>, proposal: Proposal) {
    if let Some(previous) = out.iter().position(|p| p.victims == proposal.victims) {
        if out[previous].blockers <= proposal.blockers {
            return;
        }
        out.remove(previous);
    }
    out.push(proposal);
    out.sort_by(|a, b| {
        (a.blockers - a.victims.len())
            .cmp(&(b.blockers - b.victims.len()))
            .then(a.area.total_cmp(&b.area))
            .then(a.rank.cmp(&b.rank))
    });
    out.truncate(6);
}

fn proposals(''')
replace('''        // Stable receiver placement order, independent of tree traversal order.''','''        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one would leave one or two known collisions to repair.
        // Keep the original single-victim alternatives as a fallback.
        let blocked: Vec<_> = receiver.placed_items().iter().enumerate()
            .filter(|(_, (key, _))| collector.iter().any(
                |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == *key)))
            .collect();
        let area: f32 = blocked.iter().map(|(_, (_, p))| p.item().area()).sum();
        if blocked.len() > 1 && area < incoming.area() {
            retain_proposal(&mut out, Proposal {
                victims: blocked.iter().map(|(_, (key, _))| *key).collect(),
                incoming: dt, blockers: collector.len(), rank: blocked[0].0, area,
            });
        }
        // Stable receiver placement order, independent of tree traversal order.''')
replace('                victim: key,','                victims: vec![key],')
a=s.index('            if let Some(previous) = out.iter().position(|p| p.victim == key)')
b=s.index('            out.truncate(6);',a)+len('            out.truncate(6);')
s=s[:a]+'            retain_proposal(&mut out, proposal);'+s[b:]
replace('''                    let victim = receiver.placed_items()[proposal.victim].item().clone();
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    next_receiver.remove_item(proposal.victim);
                    next_receiver.place_item(&incoming_item, proposal.incoming);
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    next_source.place_item(
                        &victim,
                        convert_sample_to_closest_feasible(incoming_old, &victim),
                    );''','''                    let victims: Vec<_> = proposal.victims.iter().map(|&key| {
                        let p = &receiver.placed_items()[key];
                        (key, p.item().clone(), p.d_transf())
                    }).collect();
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    for &(key, _, _) in &victims {
                        next_receiver.remove_item(key);
                    }
                    next_receiver.place_item(&incoming_item, proposal.incoming);
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    let (from_x, from_y) = proposal.incoming.translation();
                    let (to_x, to_y) = incoming_old.translation();
                    for (_, victim, previous) in &victims {
                        let returned = if victims.len() == 1 {
                            convert_sample_to_closest_feasible(incoming_old, victim)
                        } else {
                            // Preserve the set's relative placement, rotations
                            // and reflections. Both sheets still need repair
                            // and the independent whole-job acceptance guard.
                            let (x, y) = previous.translation();
                            DTransformation::new(previous.rotation(),
                                (x + to_x - from_x, y + to_y - from_y))
                                .with_reflection(previous.reflected)
                        };
                        next_source.place_item(victim, returned);
                    }''')
test='''
    fn obstruction_set_fixture(count: usize, return_height: f64) -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.parts[1] = rectangle("return", 30.0, return_height);
        job.parts[1].quantity = count as u32;
        let template = layout.placements.iter().find(|p| p.part_id == "return").unwrap().clone();
        for copy in 1..count {
            let mut part = template.clone();
            part.copy_index = copy as u32;
            part.transform.translation[1] += copy as f64 * (return_height + 2.0);
            layout.placements.push(part);
        }
        (job, layout)
    }

    #[test]
    fn obstruction_set_moves_two_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(2, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(after.placements.iter().filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1").count(), 2);
        assert!(after.placements.iter().any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0"));
    }

    #[test]
    fn obstruction_set_moves_three_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(3, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(after.placements.iter().filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1").count(), 3);
    }

    #[test]
    fn obstruction_set_refuses_net_area_increase_without_mutation() {
        let (job, layout) = obstruction_set_fixture(3, 30.0);
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
    }
'''
assert s.endswith('}\n');s=s[:-2]+test+'}\n'
p.write_text(s,encoding='utf-8',newline='\n')
for arm in ['baseline','candidate']:
    dest=OUT/arm/'crates/core/examples/exchange_probe.rs';dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(OLD/'crates/core/examples/exchange_probe.rs',dest)
assert all(digest(ROOT/r['path'])==r['sha256'] for r in rows)
write(OUT/'preparation.json',{'scope':__doc__,'production_files':rows,'baseline':'Current isolated-tested depth-three production source, not yet released; integration checks are running','hypothesis':'After 35/37 observed attempts failed receiver repair with 2-3 blockers, try moving the complete smaller obstruction set atomically; retain original single-victim fallbacks. Prioritize fewer remaining known blockers.','return_initialization':'For multiple returned parts preserve receiver-relative translations, rotations and reflections, translated to the donor incoming origin; both sheets still require repair and independent validation','unchanged':['Original geometry, quantities and rotations','early hook and existing 1.2-second/shared relocation limit','six-proposal cap and <=3 actual blockers','repair budgets, work coefficients and whole-job geometry/material guard','all original failures and public defaults'],'tests_added':['two blockers transferred together','three blockers transferred together','net area increase rejected without incumbent mutation'],'source_sha256':digest(p),'root_unchanged':True,'held_out_geometry_read':False,'measured_search_started':False,'measurement_prerequisite':'Current H4 integration and its complete measured matrix/scale sequence terminal and sealed before any new H5 pilot; plan must be committed first','target_directories':{arm:str(ROOT/('output/h5-obstruction-set-'+arm+'-target')) for arm in ['baseline','candidate']}})
print(json.dumps({'copied':len(rows),'source_sha256':digest(p),'measured':False}))
