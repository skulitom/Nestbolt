"""Preserve complete authored/build evidence for the isolated obstruction-set candidate."""
from pathlib import Path
from hashlib import sha256
import json, re, shutil, sys, zipfile
ROOT=Path(__file__).resolve().parents[1];PROBE=ROOT/'output/h5-obstruction-set-probe'
OUT=ROOT/'benchmarks/results/h5-obstruction-set-preparation-20261016'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
plan=load(PROBE/'preparation.json');build=load(PROBE/'build-v2.json');public=load(PROBE/'public-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed']
assert '85 passed; 0 failed; 0 ignored' in (PROBE/'core-tests-v2.log').read_text(encoding='utf-8')
for r in plan['production_files']:
    assert digest(ROOT/r['path'])==r['sha256']
    assert digest(PROBE/'baseline'/r['path'])==r['sha256']
    if r['path'] not in ['crates/core/src/sheets.rs','crates/core/src/sheets/vstrip.rs']:
        assert digest(PROBE/'candidate'/r['path'])==r['sha256']
for arm in ['baseline','candidate']:
    assert digest(PROBE/(arm+'-observer.exe'))==build['binaries'][arm]
    assert digest(PROBE/arm/'examples/validation-job.json')==load(PROBE/'fixture-repair.json')['fixture_sha256']
assert digest(PROBE/'candidate/crates/core/src/sheets/vstrip/exchange.rs')==build['exchange_source_sha256']
for name,expected in load(PROBE/'public-checks/plan.json')['guards'].items():assert digest(ROOT/name)==expected
OUT.mkdir()
for name in ['prepare_h5_obstruction_sets.py','build_h5_obstruction_sets.py','repair_h5_obstruction_fixture.py','build_h5_obstruction_sets_v2.py','prepare_h5_obstruction_public_checker.py','check_h5_obstruction_public.py','seal_h5_obstruction_sets.py']:
    target=PROBE/'helpers'/name;target.parent.mkdir(exist_ok=True);shutil.copyfile(ROOT/'output'/name,target)
files=sorted(p for p in PROBE.rglob('*') if p.is_file());archive=OUT/'raw.zip'
inventory={p.relative_to(PROBE).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,p.relative_to(PROBE).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,r in inventory.items():
        data=z.read(name);assert len(data)==r['bytes'] and sha256(data).hexdigest()==r['sha256']
write(OUT/'integrity.json',{'sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'crc_and_every_member_verified':True})
write(OUT/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':85,'strict_lint_pass':True,
    'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,'candidate_common_repeatable':True,
    'production_source_digest':source_digest(),'production_files_unchanged':True,'candidate_exchange_source_sha256':build['exchange_source_sha256'],
    'binaries':build['binaries'],'original_missing_fixture_failure_preserved':True,'independent_validation_passed':True,
    'measured_search_started':False,'H5_complete':False,'integrated':False})
for name in ['preparation.json','fixture-repair.json','build-v2.json']:shutil.copyfile(PROBE/name,OUT/name)
report='''# Atomic obstruction-set exchange preparation — 2026-10-16

**All 85 optimized core tests, strict lint and authored public checks pass.**
No development quality measurement has started, and no exchange candidate is integrated.

The [stage diagnosis](h5-exchange-diagnosis-20261016.md) observed 35 receiving-sheet
repair failures among 37 proposals, all with two or three actual blockers while
the prior algorithm evicted only one. This candidate can move the full smaller
obstruction set together. Original single-victim alternatives remain. It ranks
proposals by remaining known blockers, then returned area and stable placement
order, retaining the six-proposal cap and at most three actual blockers.

The combined returned area must be smaller than the incoming part. Multiple
returned parts initially retain their relative placement, rotations and
reflections, translated to the incoming part's old origin. Both sheets still
need repair, followed by independent whole-job geometry/material validation.
The incumbent stays intact on failure. The early call, existing shared budget,
1.2-second cap, work coefficients, original geometry and public defaults remain.

Both baseline and candidate use the new tree-depth configuration; the candidate
alone adds the isolated exchange algorithm. Unique build targets prevent shared
cache confusion. New authored tests exercise atomic two- and three-blocker
transfers and rejection of a net area increase without mutation. Existing
expired/disabled, mirrored/frozen, failed-repair and defect tests also pass.

Public checks cover ten observer outcomes and four CLI comparisons on the same
authored 24-part request. Ordinary results agree exactly apart from elapsed wall
time; common-mode replays agree, with independent metrics/quantities validated.
These fixed-work functional checks do not establish material or speed gains.

The first isolated build omitted an existing authored test fixture and failed
to compile. Its log and failed state remain. The unchanged fixture was copied
into both isolated workspaces, after which all checks passed. No geometry or
test expectation was changed to obtain a pass.

[Checks](h5-obstruction-set-preparation-20261016/checks.json),
[build](h5-obstruction-set-preparation-20261016/build-v2.json),
[raw sources/binaries/logs](h5-obstruction-set-preparation-20261016/raw.zip),
[member verification](h5-obstruction-set-preparation-20261016/integrity.json).
CRC, every member size and SHA-256 pass. Production remains unchanged by this
experiment. A separately committed paired pilot must wait for the current H4
matrix and conditional scale sequence to finish and be sealed. Original H5
failures and all thresholds remain; completion stays 45%.
'''
(OUT.parent/(OUT.name+'.md')).write_text(report,encoding='utf-8',newline='\n')
print(json.dumps({'members':len(inventory),'bytes':archive.stat().st_size,'sha256':digest(archive)}))
