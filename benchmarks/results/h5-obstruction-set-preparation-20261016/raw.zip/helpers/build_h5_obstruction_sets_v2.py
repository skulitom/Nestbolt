"""Build/check the isolated set-exchange candidate, with no measured searches."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, subprocess, sys, traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-obstruction-set-probe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(OUT/'preparation.json');records=[]
write(OUT/'build-v2-opened.json',{'utc':datetime.now(timezone.utc).isoformat()})
assert load(OUT/'fixture-repair.json')['exchange_source_unchanged']==digest(OUT/'candidate/crates/core/src/sheets/vstrip/exchange.rs')
def guard():
    for r in plan['production_files']:assert digest(ROOT/r['path'])==r['sha256'],r['path']
    for arm in ['baseline','candidate']:assert digest(OUT/arm/'examples/validation-job.json')==load(OUT/'fixture-repair.json')['fixture_sha256']
def run(arm,label,args):
    guard();log=OUT/(label+'-v2.log');started=datetime.now(timezone.utc).isoformat()
    command=[sys.executable,str(ROOT/'output/ccd1.py'),*map(str,args)]
    with log.open('xb') as f:p=subprocess.run(command,cwd=OUT/arm,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
    row={'arm':arm,'label':label,'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'sha256':digest(log)}
    records.append(row);write(OUT/'progress-v2.json',records);print(json.dumps(row),flush=True)
    assert p.returncode==0,label
try:
    target=plan['target_directories']['candidate']
    run('candidate','core-tests',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',target])
    run('candidate','clippy',['cargo','clippy','--locked','-p','nestbolt-core','--lib','--example','exchange_probe','--target-dir',target,'--','-D','warnings'])
    for arm in ['candidate','baseline']:
        target=Path(plan['target_directories'][arm])
        run(arm,arm+'-observer',['cargo','build','--release','--locked','-p','nestbolt-core','--example','exchange_probe','--target-dir',target])
        shutil.copyfile(target/'release/examples/exchange_probe.exe',OUT/(arm+'-observer.exe'))
    guard();write(OUT/'build-v2.json',{'all_checks_passed':True,'stages':records,'production_unchanged':True,
        'exchange_source_sha256':digest(OUT/'candidate/crates/core/src/sheets/vstrip/exchange.rs'),
        'binaries':{arm:digest(OUT/(arm+'-observer.exe')) for arm in ['baseline','candidate']},'measured_search_started':False})
except BaseException:
    write(OUT/'build-v2-failure.json',{'error':traceback.format_exc(),'stages':records});raise
