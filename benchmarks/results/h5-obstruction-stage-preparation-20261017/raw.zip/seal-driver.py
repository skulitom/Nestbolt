from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import sys
import zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-obstruction-stage-diagnosis-20261017'
out=root/'benchmarks/results/h5-obstruction-stage-preparation-20261017'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');assert build['all_passed']
assert digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '85 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
plan=load(probe/'preparation.json')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
files['build-driver.py']=root/'output/build_h5_obstruction_stage_diagnosis.py'
files['seal-driver.py']=Path(__file__)
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:
    shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':85,'strict_lint_passed':True,
    'instrumented_observer_build_passed':True,'old_candidate_and_production_unchanged':True,
    'diagnostic_only':True,'quality_claim':False,'measured_search_started':False,
    'completed_weight_percent':60,'H5_complete':False})
(out.parent/(out.name+'.md')).write_text('''# Atomic-set proposal and repair instrumentation — 2026-10-17

An isolated copy of the rejected atomic-set candidate passes **85 optimized
core tests**, strict lint and its observer build. Only aggregate diagnostics
are added to `exchange.rs`; reversing those insertions reproduces the exact
original text before formatting. Every other source file, the original
candidate and production source remain unchanged. Source, binary, commands,
logs and the patch are archived with CRC and every member hash verified.

The next diagnostic distinguishes collision-free samples, over-three-blocker
samples, boundary collisions, complete sets rejected by the smaller-area
heuristic, and retained full/partial sets. Each actual attempt records receiving
and return-sheet repair losses, independent validation/material rejection and
acceptance. It emits one aggregate record per invocation. Original proposal
ordering, geometry, random choices, work coefficients and deadlines remain.
Trace overhead can perturb wall time; these observations cannot establish
quality improvement or replace the rejected paired pilot.

The separately committed plan fixes four searches: both mechanical development
jobs, both kerfs, seed zero, 60 seconds, serial CCD0 CPU 8. No reserved inputs,
production integration, release or milestone closure. H2/H5 remain open; 60%.
''',encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    f.write('\nbenchmarks/results/h5-obstruction-stage-preparation-20261017/** -text -whitespace\n')
    f.write('\nbenchmarks/results/h5-obstruction-stage-diagnosis-20261017/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-17 — Prepare atomic-set eligibility and repair diagnosis

[The isolated diagnostic build](benchmarks/results/h5-obstruction-stage-preparation-20261017.md)
passes 85 optimized core tests and strict lint. Aggregate-only instrumentation
records sample eligibility, complete-set area exclusions and actual repair/
validation outcomes without changing proposal choices or budgets. Reversing
insertions restores original source text; all other sources stay byte-identical.
The full source/binary/log archive passes CRC and every member hash. Four fixed
mechanical/kerf observations are planned, serial CPU 8 after the plan is committed.
No quality claim, held-out access, integration or H5 closure; completion stays 60%.
''')
print(json.dumps({'sealed_preparation':str(out),'archive_members':len(inventory),'archive_bytes':raw.stat().st_size}))
