"""Read source rings directly; verify inner rectangles and copy-equivalent strip metadata."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-source-cells-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';INNER=BASE/'inner-rectangles';OUT=INNER/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(INNER/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(GEO/'modes.json');ds=load(BASE/'domains.json');records=load(INNER/'rectangles.json');owned={};checks=[]
for r in records:
    d=ds[r['part_index']];m=modes[d['mode']];assert r['original']==d['original'] and r['family']==d['family'] and r['mode']==d['mode'];c,s=math.cos(m['angle']),math.sin(m['angle']);mi=-1 if m['mirrored'] else 1;tx,ty=m['source_translation_offset'];outer=[(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in parts[d['family']]['geometry'][0]['outer']];g=Polygon(outer);b=r['bounds_um'];assert all(isinstance(v,int) for v in b) and r['width_um']==b[2]-b[0]>0 and r['height_um']==b[3]-b[1]>0;rectangle=box(*[v/1000 for v in b]);assert g.covers(rectangle) and rectangle.difference(g).is_empty;owned.setdefault(d['original'],[]).append(rectangle);checks.append({'original':d['original'],'component':r['component'],'source_contained':True})
assert len(owned)==57 and len(records)==65 and all(len(v)==(2 if ds[next(i for i,d in enumerate(ds) if d['original']==k)]['family']=='bracket' else 1) for k,v in owned.items())
for rects in owned.values():assert all(a.disjoint(b) for a,b in combinations(rects,2))
groups=load(INNER/'identical-source-groups.json');expected={}
for i,d in enumerate(ds):expected.setdefault((d['family'],d['mode']),[]).append(i)
assert {(g['family'],g['mode']):g['part_indices'] for g in groups}=={k:v for k,v in expected.items() if len(v)>1}
for g in groups:
    first=ds[g['part_indices'][0]];assert all(ds[i]['family']==first['family'] and ds[i]['mode']==first['mode'] and ds[i]['lower_um']==first['lower_um'] and ds[i]['upper_um']==first['upper_um'] for i in g['part_indices'])
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_originals':57,'source_contained_rectangles':65,'same_original_components_disjoint':True,'copy_groups_verified':len(groups),'necessary_strip_width_um':1487000,'necessary_strip_height_um':2987000,'full_source_geometry_still_required':True,'finite_cell_subset_preserved':True,'solver_calls':0});print(load(OUT/'checks.json'))
