"""Necessary strip-capacity rectangles contained in original filled source outlines."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box,shape
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-source-cells-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=BASE/'inner-rectangles';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(GEO/'modes.json');ds=load(BASE/'domains.json');inputs=[BASE/'domains.json',GEO/'modes.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Necessary non-overlap and cumulative strip constraints for source-contained rectangles. Frame/insert filled outer rectangles are inset1um. Each L bracket contributes two disjoint stem/foot rectangles transformed by its legal quarter-turn/mirror. Each cog contains an axis-aligned153mm square about its source-center anchor, checked in its actual source mode. Inner rectangles must remain disjoint and their active widths/heights cannot exceed the stock strip. These necessary conditions do not substitute for the complete source-cell constraints or final all66 source/native acceptance. All coordinates are integer micrometres; original parts remain mandatory.'})
records=[];source_checks=[]
for i,d in enumerate(ds):
    mode=modes[d['mode']];g=shape(mode['geometry']);family=d['family'];parts_here=[]
    if family in ['frame','insert']:pieces=[g]
    elif family=='bracket':
        c,s=math.cos(mode['angle']),math.sin(mode['angle']);mi=-1 if mode['mirrored'] else 1;pieces=[affine_transform(r,[mi*c,-s,mi*s,c,*mode['source_translation_offset']]) for r in [box(0,0,100,250),box(100,0,300,75)]]
    else:assert family=='cog';pieces=[box(-76.5,-76.5,76.5,76.5)]
    for component,p in enumerate(pieces):
        a,b,c,e=p.bounds;bounds=[math.ceil(a*1000)+1,math.ceil(b*1000)+1,math.floor(c*1000)-1,math.floor(e*1000)-1];rect=box(*[v/1000 for v in bounds]);assert g.covers(rect) and rect.area>0;parts_here.append(rect);records.append({'part_index':i,'original':d['original'],'family':family,'mode':d['mode'],'component':component,'bounds_um':bounds,'width_um':bounds[2]-bounds[0],'height_um':bounds[3]-bounds[1]});source_checks.append({'original':d['original'],'component':component,'contained':True,'area_mm2':rect.area})
    assert all(a.disjoint(b) for a,b in combinations(parts_here,2))
groups={}
for i,d in enumerate(ds):groups.setdefault((d['family'],d['mode']),[]).append(i)
symmetry=[{'family':f,'mode':m,'part_indices':ii} for (f,m),ii in groups.items() if len(ii)>1]
for group in symmetry:
    first=ds[group['part_indices'][0]];assert all(ds[i]['lower_um']==first['lower_um'] and ds[i]['upper_um']==first['upper_um'] for i in group['part_indices'])
write(OUT/'rectangles.json',records);write(OUT/'containment-checks.json',source_checks);write(OUT/'identical-source-groups.json',symmetry);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'mandatory_originals':57,'source_contained_rectangles':len(records),'source_containment_checks':len(source_checks),'source_area_sum_mm2':sum(r['width_um']*r['height_um'] for r in records)/1e6,'source_equivalent_copy_groups':len(symmetry),'y_order_symmetry_pairs':sum(len(g['part_indices'])-1 for g in symmetry),'stock_width_um':1487000,'stock_height_um':2987000,'solver_opened':False});print(load(OUT/'prepared.json'))
