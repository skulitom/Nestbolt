"""Sufficient source-clearance cells for a different, joint discrete feasibility method."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,box,mapping
import shapely
from h5_global_sliding_objective import SlidingObjective
from diagnose_h5_concave_gaps import convex_pieces,polygons
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';PREVIOUS=ROOT/'output/h5-frame-block-exchange-20261026';SELECTED='mixed-12-turned-6-wide';OUT=ROOT/'output/h5-global-source-cells-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PREVIOUS/'result-audit/checks.json')['passed'];old=load(PREVIOUS/'search'/SELECTED/'result.json');assert old['closed'];best=load(PREVIOUS/'search'/SELECTED/'best.json');obj=SlidingObjective(GEO);modes=best['modes'];n=len(obj.moving);assert n==57
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in GEO.rglob('*') if p.is_file()}
for p in [PREVIOUS/'result-audit/checks.json',PREVIOUS/'search'/SELECTED/'best.json',PREVIOUS/'search'/SELECTED/'result.json',ROOT/'output/h5_global_sliding_objective.py',ROOT/'output/diagnose_h5_concave_gaps.py']:inputs[p.relative_to(ROOT).as_posix()]=digest(p)
proof=ROOT/'output/h5-mixed-frame-displacement-proof-20261026/audit/checks.json';assert load(proof)['passed'];inputs[proof.relative_to(ROOT).as_posix()]=digest(proof)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'preparation_seconds':180,'search_seconds':60,'shared_seconds':90,'units_per_mm':1000,'local_translation_radius_mm':None,'additional_obstacle_buffer_mm':.002,'fixed_source_modes':modes,'all57_first_originals_mandatory':True,'all9_short_originals_fixed':True,'method':'Different sufficient-geometry feasibility model, with no overlap objective or adaptive penalty search. The exact source-width certificate excludes even180mm local movement of a frame/insert clique. Therefore discard every local anchor bound and allow every one of57 originals the whole legal first stock. Keep only the saved original source modes and the checked9-part short sheet. This is a materially different global-domain feasibility model, with no fixed first position or maximum displacement. Original identities remain mandatory. For every one of1596 pairs, clip the relative-position box against its source Minkowski obstacle, expanded by .002mm before nearest-micrometre rounding. Decompose the remaining region into convex cells and retain only nondegenerate integer cells strictly disjoint from the original conservative obstacle and contained in the relative box. A selector must place every active pair displacement in one retained cell; every source original stays mandatory. These retained cells form a finite conservative sufficient subset even though coordinate domains cover the full stock. Infeasibility does not exclude all source layouts or other source orientations. Any assignment still requires independent all66 original-ring and native checks. One declared60/90-second call, no extension/reseed/retry.'})
domains=[]
for r,mi,xy in zip(obj.moving,modes,best['anchors']):
    a,b,c,d=obj.free[mi].bounds;lo=[math.ceil(1000*a),math.ceil(1000*b)];hi=[math.floor(1000*c),math.floor(1000*d)];assert all(lo[k]<=hi[k] for k in range(2));domains.append({'original':r['original'],'family':r['family'],'copy_index':r['copy_index'],'mode':mi,'lower_um':lo,'upper_um':hi,'hint_um':[min(hi[k],max(lo[k],round(xy[k]*1000))) for k in range(2)]})
pairs=[];total_cells=total_faces=discarded=0;minimum_distance=math.inf;unrestricted=empty=0
for i,j in combinations(range(n),2):
    assert time.perf_counter()-start<180
    a,b=domains[i],domains[j];bounds=[b['lower_um'][0]-a['upper_um'][0],b['lower_um'][1]-a['upper_um'][1],b['upper_um'][0]-a['lower_um'][0],b['upper_um'][1]-a['lower_um'][1]];region=box(*[v/1000 for v in bounds]);obstacle=obj.obstacles[modes[i]*len(obj.modes)+modes[j]];record={'left':i,'right':j,'originals':[a['original'],b['original']],'relative_bounds_um':bounds}
    if region.disjoint(obstacle):record['kind']='entire_box_safe';unrestricted+=1;pairs.append(record);continue
    free=region.difference(obstacle.buffer(.002,join_style='mitre'));cells=[]
    for polygon in polygons(free):
        for piece in convex_pieces(polygon):
            vertices=np.rint(np.asarray(piece.exterior.coords)[:-1]*1000).astype(np.int64).tolist();clean=[]
            for v in vertices:
                if not clean or v!=clean[-1]:clean.append(v)
            if len(clean)>1 and clean[0]==clean[-1]:clean.pop()
            if len(clean)<3:discarded+=1;continue
            cell=Polygon([[x/1000,y/1000] for x,y in clean])
            if not cell.is_valid or cell.area<=0 or not cell.equals(cell.convex_hull) or not region.covers(cell) or not cell.disjoint(obstacle):discarded+=1;continue
            area2=sum(clean[k][0]*clean[(k+1)%len(clean)][1]-clean[(k+1)%len(clean)][0]*clean[k][1] for k in range(len(clean)))
            if area2<0:clean.reverse();area2=-area2
            assert area2>0;faces=[]
            for p,q in zip(clean,clean[1:]+clean[:1]):
                dx,dy=q[0]-p[0],q[1]-p[1];g=math.gcd(abs(dx),abs(dy));assert g;nx,ny=-dy//g,dx//g;rhs=nx*p[0]+ny*p[1];assert all(nx*x+ny*y>=rhs for x,y in clean);faces.append([nx,ny,rhs])
            distance=cell.distance(obstacle);assert distance>0;minimum_distance=min(minimum_distance,distance);cells.append({'vertices_um':clean,'faces':faces,'area2_um2':area2,'distance_to_original_obstacle_mm':distance});total_faces+=len(faces)
    record.update({'kind':'convex_cell_disjunction','cells':cells});total_cells+=len(cells);empty+=not cells;pairs.append(record)
write(OUT/'domains.json',domains);write(OUT/'pairs.json',pairs);write(OUT/'fixed-short-placements.json',load(GEO/'inventory.json')['fixed_short_placements']);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'mandatory_first_originals':n,'integer_coordinates':2*n,'all_pairs':len(pairs),'entire_box_safe_pairs':unrestricted,'disjunctive_pairs':len(pairs)-unrestricted,'convex_cells':total_cells,'halfplanes':total_faces,'discarded_rounded_cells':discarded,'empty_disjunctions':empty,'minimum_cell_distance_to_conservative_obstacle_mm':minimum_distance,'finite_sufficient_subset':True,'solver_opened':False,'native_calls':0});print(load(OUT/'prepared.json'))
