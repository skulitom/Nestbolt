"""Read the single solver response and, if present, verify every serialized constraint."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
from itertools import combinations
import json,re,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-source-cells-model-20261026';SEARCH=BASE/'search';GEO=ROOT/'output/h5-global-source-cells-20261026';SOURCE=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and result['closed'] and result['solver_calls']==1;assert opened['parameters']['max_time_in_seconds']==60 and opened['maximum_calls']==1 and digest(SEARCH/'model.pb')==digest(BASE/'model.pb')==load(BASE/'model-audit/checks.json')['model_sha256'];response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());status=cp_model_pb2.CpSolverStatus.Name(response.status);assert status==result['status'] and status in ['UNKNOWN','FEASIBLE','OPTIMAL','INFEASIBLE'];assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts'];assert bool(response.solution)==result['has_solution'];log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log;printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1));assert abs(printed-Decimal(str(response.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12');verified=0
if response.solution:
    model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes());sol=list(response.solution);assert len(sol)==len(model.variables)
    for v,value in zip(model.variables,sol):assert any(lo<=value<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
    def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    def literal(i):return bool(sol[i]) if i>=0 else not bool(sol[-i-1])
    intervals={i:(expr(ct.interval.start),expr(ct.interval.end),expr(ct.interval.size)) for i,ct in enumerate(model.constraints) if ct.WhichOneof('constraint')=='interval'}
    for i,ct in enumerate(model.constraints):
        verified+=1
        if not all(literal(v) for v in ct.enforcement_literal):continue
        kind=ct.WhichOneof('constraint')
        if kind=='linear':
            value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert any(lo<=value<=hi for lo,hi in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='exactly_one':assert sum(literal(v) for v in ct.exactly_one.literals)==1
        elif kind=='interval':a,b,s=intervals[i];assert a+s==b and s>0
        elif kind=='no_overlap_2d':
            rectangles=[(*intervals[x][:2],*intervals[y][:2]) for x,y in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals)]
            for a,b in combinations(rectangles,2):assert a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2]
        elif kind=='cumulative':
            events={}
            for ix,dem in zip(ct.cumulative.intervals,ct.cumulative.demands):a,b,s=intervals[ix];d=expr(dem);events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
            amount=0;capacity=expr(ct.cumulative.capacity)
            for point in sorted(events):amount+=events[point];assert 0<=amount<=capacity
        else:raise AssertionError(kind)
    assignment=load(SEARCH/'assignment.json');assert assignment=={v.name:value for v,value in zip(model.variables,sol)};ds=load(GEO/'domains.json');modes=load(SOURCE/'modes.json');mapping=load(BASE/'mapping.json');rows=[]
    for d,xy in zip(ds,mapping['coordinate_indices']):
        m=modes[d['mode']];anchor=[sol[v]/1000 for v in xy];rows.append({'part_id':d['family'],'copy_index':d['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[anchor[k]+m['source_translation_offset'][k] for k in range(2)]}})
    rows+=load(GEO/'fixed-short-placements.json');assert len(rows)==66;write(OUT/'all66-unvalidated-placements.json',rows)
else:assert not (SEARCH/'assignment.json').exists()
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'closed':True,'presolve_closed_model':'Problem closed by presolve.' in log,'search_started':'Starting search at' in log,'returned_branches':response.num_branches,'returned_conflicts':response.num_conflicts,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'solver_calls':1,'all57_first_originals_required':True,'has_assignment':bool(response.solution),'serialized_constraints_verified_on_assignment':verified,'independent_source_readback_required':bool(response.solution),'finite_sufficient_cell_subset_only':True,'unrestricted_exclusion':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
