"""Full-stock source-cell feasibility with necessary source rectangle propagation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-global-source-cells-20261026';OUT=ROOT/'output/h5-global-source-cells-model-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'geometry-audit/checks.json')['passed'] and load(GEO/'inner-rectangles/audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs={p.relative_to(ROOT).as_posix():digest(p) for p in GEO.rglob('*') if p.is_file()};write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'objective':None,'hints':False,'all57_first_originals_required':True,'all9_short_originals_fixed':True,'coordinate_domains':'entire legal stock; no displacement bound','source_modes_fixed':True,'additional_propagation':'65 source-contained rectangles in NoOverlap2D and two cumulative constraints, plus nondecreasingY among identical-source same-mode copies with equal full-stock domains. These strip constraints are necessary for source geometry; all source-cell constraints remain.','finite_conservative_cell_subset_only':True})
ds=load(GEO/'domains.json');pairs=load(GEO/'pairs.json');rects=load(GEO/'inner-rectangles/rectangles.json');groups=load(GEO/'inner-rectangles/identical-source-groups.json');model=cp_model.CpModel();coords=[];records=[]
for d in ds:coords.append([model.new_int_var(d['lower_um'][k],d['upper_um'][k],f'{axis}_{d["original"]}') for k,axis in enumerate(['x','y'])])
for pair_index,p in enumerate(pairs):
    if p['kind']=='entire_box_safe':continue
    i,j=p['left'],p['right'];selectors=[model.new_bool_var(f'pair_{i}_{j}_cell_{c}') for c in range(len(p['cells']))];model.add_exactly_one(selectors);entry={'pair_index':pair_index,'selector_indices':[v.index for v in selectors],'cell_constraint_indices':[]}
    for cell,z in zip(p['cells'],selectors):
        indices=[]
        for nx,ny,rhs in cell['faces']:
            ct=model.add(nx*(coords[j][0]-coords[i][0])+ny*(coords[j][1]-coords[i][1])>=rhs);ct.only_enforce_if(z);indices.append(ct.index)
        entry['cell_constraint_indices'].append(indices)
    records.append(entry)
rectangle_records=[];x_intervals=[];y_intervals=[]
for k,r in enumerate(rects):
    i=r['part_index'];b=r['bounds_um'];x=model.new_fixed_size_interval_var(coords[i][0]+b[0],r['width_um'],f'inner_x_{k}');y=model.new_fixed_size_interval_var(coords[i][1]+b[1],r['height_um'],f'inner_y_{k}');x_intervals.append(x);y_intervals.append(y);rectangle_records.append({'rectangle_index':k,'interval_indices':[x.index,y.index]})
nonoverlap=model.add_no_overlap_2d(x_intervals,y_intervals);cumulative_x=model.add_cumulative(x_intervals,[r['height_um'] for r in rects],2987000);cumulative_y=model.add_cumulative(y_intervals,[r['width_um'] for r in rects],1487000);symmetry=[]
for g in groups:
    indices=g['part_indices']
    for i,j in zip(indices,indices[1:]):ct=model.add(coords[i][1]<=coords[j][1]);symmetry.append({'parts':[i,j],'constraint_index':ct.index})
assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',{'coordinate_indices':[[v.index for v in xy] for xy in coords],'pairs':records,'rectangles':rectangle_records,'no_overlap_2d_constraint':nonoverlap.index,'cumulative_constraint_indices':[cumulative_x.index,cumulative_y.index],'symmetry':symmetry});write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'coordinate_variables':114,'selector_variables':len(model.proto.variables)-114,'all57_mandatory':True,'source_rectangles':65,'interval_constraints':130,'no_overlap_2d_constraints':1,'cumulative_constraints':2,'source_copy_order_constraints':len(symmetry),'hints':0,'model_sha256':digest(OUT/'model.pb'),'model_validation':'','solver_calls':0});print(load(OUT/'built.json'))
