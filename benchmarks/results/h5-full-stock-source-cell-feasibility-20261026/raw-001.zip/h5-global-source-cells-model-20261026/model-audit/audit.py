"""Read the serialized model independently and reconstruct every expected constraint."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-global-source-cells-20261026';BASE=ROOT/'output/h5-global-source-cells-model-20261026';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
proto=cp_model_pb2.CpModelProto();proto.ParseFromString((BASE/'model.pb').read_bytes());assert not proto.HasField('objective') and not proto.HasField('floating_point_objective');ds=load(GEO/'domains.json');pairs=load(GEO/'pairs.json');mapping=load(BASE/'mapping.json');var_index=0;constraint_index=0;expected_hints=[]
for d,xy in zip(ds,mapping['coordinate_indices']):
    assert xy==[var_index,var_index+1]
    for k,axis in enumerate(['x','y']):
        v=proto.variables[var_index];assert v.name==f'{axis}_{d["original"]}' and list(v.domain)==[d['lower_um'][k],d['upper_um'][k]];var_index+=1
assert list(zip(proto.solution_hint.vars,proto.solution_hint.values))==expected_hints;records=iter(mapping['pairs']);halfplanes=disjunctions=0
for pair_index,p in enumerate(pairs):
    if p['kind']=='entire_box_safe':continue
    record=next(records);assert record['pair_index']==pair_index;i,j=p['left'],p['right'];selectors=list(range(var_index,var_index+len(p['cells'])));assert record['selector_indices']==selectors
    for c in range(len(p['cells'])):v=proto.variables[var_index];assert v.name==f'pair_{i}_{j}_cell_{c}' and list(v.domain)==[0,1];var_index+=1
    ct=proto.constraints[constraint_index];assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal and list(ct.exactly_one.literals)==selectors;constraint_index+=1;disjunctions+=1
    for cell,z,indices in zip(p['cells'],selectors,record['cell_constraint_indices']):
        assert indices==list(range(constraint_index,constraint_index+len(cell['faces'])))
        for nx,ny,rhs in cell['faces']:
            ct=proto.constraints[constraint_index];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==[z];xi,yi=mapping['coordinate_indices'][i];xj,yj=mapping['coordinate_indices'][j];expected={k:v for k,v in [(xi,-nx),(yi,-ny),(xj,nx),(yj,ny)] if v};assert dict(zip(ct.linear.vars,ct.linear.coeffs))==expected and list(ct.linear.domain)==[rhs,9223372036854775807];constraint_index+=1;halfplanes+=1
assert next(records,None) is None and var_index==len(proto.variables)
# Full-stock coverage is checked independently from the preparer's radius claim.
source=ROOT/'output/h5-legacy57-sliding-source-20261026'
for d in ds:
    ring=load(source/'free'/f"{d['mode']:02d}.json")['coordinates'][0];xs=[p[0] for p in ring];ys=[p[1] for p in ring]
    assert d['lower_um']==[math.ceil(min(xs)*1000),math.ceil(min(ys)*1000)] and d['upper_um']==[math.floor(max(xs)*1000),math.floor(max(ys)*1000)]
rects=load(GEO/'inner-rectangles/rectangles.json');assert len(rects)==65 and len(mapping['rectangles'])==65;xints=[];yints=[]
def expr(e,var,offset):
    assert dict(zip(e.vars,e.coeffs))==({var:1} if var is not None else {}) and e.offset==offset
for k,(r,record) in enumerate(zip(rects,mapping['rectangles'])):
    assert record['rectangle_index']==k and record['interval_indices']==[constraint_index,constraint_index+1];i=r['part_index'];b=r['bounds_um']
    for axis,length in [(0,r['width_um']),(1,r['height_um'])]:
        ct=proto.constraints[constraint_index];assert ct.WhichOneof('constraint')=='interval' and not ct.enforcement_literal;expr(ct.interval.start,mapping['coordinate_indices'][i][axis],b[axis]);expr(ct.interval.size,None,length);expr(ct.interval.end,mapping['coordinate_indices'][i][axis],b[axis]+length)
        (xints if axis==0 else yints).append(constraint_index);constraint_index+=1
assert mapping['no_overlap_2d_constraint']==constraint_index;ct=proto.constraints[constraint_index];assert ct.WhichOneof('constraint')=='no_overlap_2d' and not ct.enforcement_literal and list(ct.no_overlap_2d.x_intervals)==xints and list(ct.no_overlap_2d.y_intervals)==yints;constraint_index+=1
assert mapping['cumulative_constraint_indices']==[constraint_index,constraint_index+1]
for intervals,field,capacity in [(xints,'height_um',2987000),(yints,'width_um',1487000)]:
    ct=proto.constraints[constraint_index];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal and list(ct.cumulative.intervals)==intervals;expr(ct.cumulative.capacity,None,capacity);assert len(ct.cumulative.demands)==65
    for d,r in zip(ct.cumulative.demands,rects):expr(d,None,r[field])
    constraint_index+=1
groups=load(GEO/'inner-rectangles/identical-source-groups.json');expected_order=[(a,b) for g in groups for a,b in zip(g['part_indices'],g['part_indices'][1:])];assert len(mapping['symmetry'])==len(expected_order)==47
for (i,j),record in zip(expected_order,mapping['symmetry']):
    assert record['parts']==[i,j] and record['constraint_index']==constraint_index;ct=proto.constraints[constraint_index];assert ct.WhichOneof('constraint')=='linear' and not ct.enforcement_literal and dict(zip(ct.linear.vars,ct.linear.coeffs))=={mapping['coordinate_indices'][i][1]:1,mapping['coordinate_indices'][j][1]:-1} and list(ct.linear.domain)==[-9223372036854775808,0];constraint_index+=1
assert constraint_index==len(proto.constraints)

write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':var_index,'constraints_verified':constraint_index,'all57_required':True,'coordinate_domains_verified':114,'selector_variables_verified':var_index-114,'exactly_one_disjunctions_verified':disjunctions,'integer_halfplanes_verified':halfplanes,'hint_values_verified':len(expected_hints),'no_objective':True,'entire_stock_domains_verified':True,'source_rectangles_verified':65,'interval_constraints_verified':130,'no_overlap_2d_verified':True,'cumulative_constraints_verified':2,'source_copy_order_constraints_verified':47,'model_sha256':digest(BASE/'model.pb'),'finite_sufficient_subset':True,'solver_calls':0});print(load(OUT/'checks.json'))
