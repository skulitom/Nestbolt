"""Seal closed axis-choice results and the independently audited exact partition."""
from pathlib import Path
from datetime import datetime, timezone
import ast, json, shutil, subprocess, sys
from pack_h5_evidence_archive import pack, digest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from h2_import_audit import source_digest

BASE = ROOT / 'output/h5-short11-cycle-guided-axis-choices-20261029'
SIX = ROOT / 'output/h5-short11-six-axis-choices-20261029'
PUB = BASE / 'publication'
NAME = 'h5-axis-choice-rejection-and-exact-source-partition-20261029'
OUT = ROOT / 'benchmarks/results' / NAME
load = lambda p: json.loads(p.read_bytes())

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def append(p, value):
    with p.open('a', encoding='utf-8', newline='\n') as f:
        f.write(value)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

head = git('rev-parse', 'HEAD')
assert head == '625734f0bbdc236172c80f141f82c2edcb13932a'
assert not git('diff', 'HEAD', '--name-only')
for folder in ['model-audit', 'fixed-row-cycle-audit']:
    assert load(SIX / folder / 'checks.json')['passed']
for folder in ['preflight', 'preflight/audit', 'model-audit', 'response-audit',
               'oblique-cycle-audit', 'exact-source-partition-preflight',
               'core-teeth-partition-preflight', 'core-teeth-partition-preflight/audit']:
    assert load(BASE / folder / 'checks.json')['passed']
six = load(SIX / 'fixed-row-cycle-audit/checks.json')
response = load(BASE / 'response-audit/checks.json')
oblique = load(BASE / 'oblique-cycle-audit/checks.json')
partition = load(BASE / 'core-teeth-partition-preflight/audit/checks.json')
assert six['restricted_model_infeasibility_certified_without_search'] and six['solver_calls'] == 0
assert response['closed_solver_calls'] == 1 and response['solver_reported_status'] == 'INFEASIBLE'
assert response['tiny_coefficients_ignored'] == 814 and response['assignments'] == 0
assert response['all_overruns_seconds'] == 0 and not response['any_allocation_excluded']
assert not oblique['negative_cycle_found'] and oblique['seconds'] > 70
assert partition['exact_pair_intersections_zero_area'] == 210
assert partition['internal_edges_cancelled_exactly'] == 20
assert partition['short11_inter_original_piece_pairs'] == 1115
assert not partition['new_model_created'] and partition['solver_calls'] == 0

prior = load(ROOT / 'benchmarks/results/h5-short11-source-readback-and-translation-cycle-20261029/publication-review.json')
production = source_digest()
assert production == prior['production_digest']
readmes = {n: digest(ROOT / n) for n in prior['current_readmes']}
assert readmes == prior['current_readmes']
up = {'sparrow_head': load(PUB / 'sparrow-head.json')['sha'],
      'studio_head': load(PUB / 'studio-head.json')['sha'],
      'sparrow_release': load(PUB / 'sparrow-release.json')['tag_name'],
      'studio_latest_release': [r['tag_name'] for r in load(PUB / 'studio-releases.json')]}
assert all(up[k] == prior[k] for k in up)
assert [(r['tag_name'], r['prerelease'], r['draft']) for r in load(PUB / 'nestbolt-releases.json')] == [('v0.2.0-alpha.1', True, False), ('v0.1.0', False, False)]
main = load(PUB / 'main.json')['commit']['sha']
ci = load(PUB / 'main-ci.json')
jobs = load(PUB / 'main-ci-jobs.json')['jobs']
assert main == '9dab2f4e5290a72c208d132f6e21ad31340f365c'
assert ci['head_sha'] == main and ci['id'] == 40805531238
assert ci['status'] == 'completed' and ci['conclusion'] == 'success'
assert len(jobs) == 6 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs)
frontier = ROOT / 'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json'
rows = load(frontier)
assert len(rows) == 4576 and sum(r['excluded_by'] is None for r in rows) == 440
assert digest(ROOT / 'output/h5-oblique64-source-20261028/source64.json') == 'bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'

OUT.mkdir()
members, queue, seen, bindings = {}, [], set(), {}

def add(name, path):
    assert path.is_file() and '.claude' not in path.parts
    members[name] = path
    if path.name in ['plan.json', 'opened.json'] or path.suffix == '.py':
        queue.append(path)

for folder in [BASE, SIX]:
    for path in folder.rglob('*'):
        if path.is_file():
            add(folder.name + '/' + path.relative_to(folder).as_posix(), path)
helpers = [
    'build_h5_short11_six_axis_model_20261029.py',
    'audit_h5_short11_six_axis_model_20261029.py',
    'audit_h5_six_axis_fixed_rows_20261029.py',
    'prepare_h5_short11_cycle_guided_axes_20261029.py',
    'audit_h5_cycle_guided_axis_expansion_20261029.py',
    'build_h5_cycle_guided_axis_model_20261029.py',
    'prepare_h5_cycle_guided_model_reader_20261029.py',
    'audit_h5_cycle_guided_axis_model_20261029.py',
    'run_h5_cycle_guided_axis_model_20261029.py',
    'audit_h5_cycle_guided_response_20261029.py',
    'derive_h5_oblique_fixed_row_cycle_20261029.py',
    'prepare_h5_exact_source_partition_20261029.py',
    'prepare_h5_cog_core_teeth_partition_20261029.py',
    'audit_h5_cog_core_teeth_partition_20261029.py',
    'pack_h5_evidence_archive.py', 'ccd1.py',
    'verify_h5_axis_partition_archive_20261029.py', Path(__file__).name,
]
for name in helpers:
    add('helpers/' + name, ROOT / 'output' / name)
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    if path.name in ['plan.json', 'opened.json']:
        for name, expected in load(path).get('inputs', {}).items():
            source = ROOT / name
            assert source.is_relative_to(ROOT) and '.claude' not in source.parts and '.cache' not in source.parts
            assert digest(source) == expected, name
            bindings[name] = expected
            add('source-inputs/' + name, source)
    elif path.suffix == '.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules = [v.name for v in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:
                    continue
                for folder in ['output', 'scripts']:
                    source = ROOT / folder / (module + '.py')
                    if source.is_file():
                        add('imported-helpers/' + folder + '/' + source.name, source)

archive, _ = pack(ROOT, OUT, NAME, members)
write(OUT / 'source-bindings.json', bindings)
copies = [
    (SIX / 'model-audit/checks.json', 'six-choice-model-audit.json'),
    (SIX / 'fixed-row-cycle-audit/checks.json', 'six-choice-cycle-audit.json'),
    (SIX / 'fixed-row-cycle-audit/certificate.json', 'six-choice-cycle-certificate.json'),
    (BASE / 'preflight/audit/checks.json', 'choice-expansion-audit.json'),
    (BASE / 'preflight/cycle-expansion.json', 'choice-expansion.json'),
    (BASE / 'model-audit/checks.json', 'expanded-model-audit.json'),
    (BASE / 'response-audit/checks.json', 'response-audit.json'),
    (BASE / 'response-audit/coefficient-warning.json', 'coefficient-warning.json'),
    (BASE / 'oblique-cycle-audit/checks.json', 'oblique-diagnostic.json'),
    (BASE / 'exact-source-partition-preflight/checks.json', 'fan-merge-preflight.json'),
    (BASE / 'core-teeth-partition-preflight/partition.json', 'core-teeth-partition.json'),
    (BASE / 'core-teeth-partition-preflight/audit/checks.json', 'core-teeth-audit.json'),
    (PUB / 'main-ci-jobs.json', 'main-ci-snapshot.json'),
]
for source, name in copies:
    shutil.copyfile(source, OUT / name)
write(OUT / 'publication-review.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'source_head': head,
    'remote_main': main, 'production_digest': production, 'current_readmes': readmes,
    **up, 'upstream_heads_and_releases_unchanged': True, 'stable_release': 'v0.1.0',
    'preview_release': 'v0.2.0-alpha.1', 'main_CI': 40805531238, 'main_all6_pass': True,
    'normal_push_requires_fresh_head_and_live_run_checks': True,
    'unchanged_frontier_path': frontier.relative_to(ROOT).as_posix(),
    'unchanged_frontier_sha256': digest(frontier), 'reserved_H2_vectors_evaluated': 0,
    'completion_percent': 60, 'H2_complete': False, 'H5_complete': False,
    'new_release_qualified': False,
})
write(OUT / 'next-step.json', {
    'action': 'Build a new source construction model from the independently audited 21-piece cog partition, the five two-rectangle brackets and four inserts. Preserve all 11 short-sheet and 55 first-sheet identities, original stock domains and clearances. Provide separation alternatives for every relevant pair rather than retaining failed seed directions. Independently verify partition coverage, posed geometry, axes or forbidden-configuration coverage and any restrictions, numerical rounding, deactivation bounds and all model constraints before one declared bounded call. Charge construction preparation and reserve original-source readback time. Keep every closed call closed. A negative fixed-mode/phase construction cannot exclude the allocation. First55 construction, full66 original/native/material verification, production integration and the complete H5 matrix remain.',
    'cog_convex_pieces': 21, 'short11_convex_pieces': 56,
    'inter_original_piece_pairs': 1115, 'short_originals': 11, 'first_originals': 55,
    'model_created': False, 'search_opened': False, 'remaining_candidates': 440,
    'completion_percent': 60, 'H2_complete': False, 'H5_complete': False,
})
write(OUT / 'checks.json', {
    'passed': True, 'six_choice_model_exactly_rejected_without_solver': True,
    'six_choice_cycle_sum_mm': six['negative_sum_mm_approx'], 'expansion_exact_cycles': 5,
    'expanded_groups': 11, 'expanded_variants': 160, 'closed_new_solver_calls': 1,
    'solver_reported_status': 'INFEASIBLE', 'exact_expanded_model_certificate': False,
    'tiny_coefficients_ignored': 814, 'maximum_ignored_row_effect_mm': response['maximum_ignored_row_effect_mm'],
    'solver_call_overruns_seconds': 0, 'separate_oblique_diagnostic_seconds': oblique['seconds'],
    'independently_audited_cog_pieces': 21, 'future_piece_pairs': 1115,
    'new_partition_model_created': False, 'new_allocation_exclusions': 0,
    'remaining_candidates': 440, 'valid64_preserved': True, 'source_valid66_created': False,
    'native_calls': 0, 'completion_percent': 60, 'H2_complete': False, 'H5_complete': False,
    **archive,
})
report = (BASE / 'report-template.md').read_text(encoding='utf-8').format(
    name=NAME, files=archive['archive_members'], aliases=archive['verified_aliases'], bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write(report)
note = (BASE / 'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md', 'docs/PLAN_V1_1.md', 'docs/V1_1_RESEARCH.md', 'docs/STATUS.md']:
    append(ROOT / name, note.format(link=('' if name == 'BENCHMARKS.md' else '../') + f'benchmarks/results/{NAME}.md'))
status = ROOT / 'docs/STATUS.md'
content = status.read_text(encoding='utf-8')
old = 'Latest H5 evidence: [short11 source readback and a restricted translation contradiction](../benchmarks/results/h5-short11-source-readback-and-translation-cycle-20261029.md).'
new = f'Latest H5 evidence: [rejected axis choices and an exact smaller source partition](../benchmarks/results/{NAME}.md).'
assert content.count(old) == 1
with status.open('w', encoding='utf-8', newline='\n') as f:
    f.write(content.replace(old, new, 1))
append(ROOT / '.gitattributes', f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed': NAME, **archive, 'source_bindings': len(bindings),
       'remaining_candidates': 440, 'completion_percent': 60})
