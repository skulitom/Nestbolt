"""Archive the closed two-center pipeline and its read-only diagnosis."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-two-center-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-two-center-preflight-20261107';F=BASE/'response-audit';D=BASE/'outcome-diagnostic'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-two-center-preflight-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==2 and front['best_original']['pair_failures']==50 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-two-center-response-audit-process-20261107',ROOT/'output/h5-two-center-selector-profile-process-20261107',ROOT/'output/h5-two-center-main-sync-20261107']",
    "['*h5*mixed*mode*20261107.py']":"['*h5*two*center*20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_two_center_construction_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','center-combination-coverage.json','runtime-coverage-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-01/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-selection/checks.json','runtime-selection-audit.json'),(BASE/'search/epoch-01/selection.json','runtime-selection.json'),(BASE/'search/plan.json','search-plan.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-search-process.json'),(D/'checks.json','outcome-diagnostic.json'),(D/'family-failures.json','family-failures.json'),(D/'prior-comparisons.json','prior-comparisons.json'),(D/'runtime-coverage-and-time.json','runtime-coverage-and-time.json'),(BASE/'selector-profile/checks.json','selector-profile.json'),(BASE/'selector-profile/functions.json','profile-functions.json'),(BASE/'search/main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-two-center-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['response-audit','selector-profile']:copies.append((ROOT/'output'/f'h5-two-center-{stage}-process-20261107'/'process.json',stage+'-process.json'))
closed=load(BASE/'closed-problems.json')
for epoch in [0,1]:
    p=BASE/f'search/epoch-{epoch:02d}/closed-problem.json';copies.append((p,f'closed-problem-{epoch:02d}.json'));closed.append(load(p))
assert len(closed)==len({r['key'] for r in closed})==18
write(OUT/'closed-problems.json',closed)
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
diag=load(D/'checks.json');cover=load(D/'runtime-coverage-and-time.json');profile=load(BASE/'selector-profile/checks.json');ci=load(BASE/'search/main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);audit_process=load(OUT/'response-audit-process.json');profile_process=load(OUT/'selector-profile-process.json');result=load(BASE/'search/result.json');selection=load(BASE/'search/epoch-01/selection.json')['accepted_choice']
assert all(v['passed'] for v in [diag,cover,profile,audit_process,profile_process]) and result['status']=='TIME_STOP_AFTER_SOURCE_CHECK'
write(OUT/'next-step.json',{'status':'selector_performance_equivalence_preflight_required','finding':'The finite two-center pipeline closes after two calls without a valid full66 layout. The measured weight-update/selection/output/model interval is12.27282049995847s and the second optimizer allocation is2.563987500499934s. Complete same-context comparison and unchanged-selector profiling are validation only; the larger pool cannot be credited with a packing improvement.',
    'proposal':'Assess two computation-only changes in a separately versioned selector: build the pair index arrays once and gather the528losses in their existing order with NumPy; compute each complete problem digest once per physical vector in a cache local to this single immutable weight/identity context. The profile records23419problem-key calls taking2.6473797scumulative and23419pair-list constructions taking2.0650706sself. Preserve every grid center, raw proposal, score component, identity, exclusion, rank, deadline checkpoint and partial evidence. First establish equivalent complete outputs and independent score agreement in original-source and recorded runtime validation contexts, including different weights/identities and repeated calls to rule out stale keys. No replacement implementation, successor source state or new search is prepared.',
    'requirements':['All18closed complete objective/physical-mode/weight keys and the finite pipelines remain closed. Faster code does not authorize another call for the same key, and altered coordinates alone do not create a new problem.','Runtime or optimized values are validation-only. Any future initializer must be reconstructed from original unoptimized A/W source geometry, coordinates, angles and weights, with exact source-domain and model readback, all18exclusions and the entire33.769462099531665s inherited preparation charge plus any new preparation.','Do not change the9x9plusclamped center set, two distinct centers per111physical owner/mode,23419raw proposals,2854physical vectors,528weighted original/clearance terms,15coefficient1auxiliary terms, continuous cog angles or bounded area-only weight rule to rescue a closed search.','Profile measurements include instrumentation overhead. Measure any new complete selector and all output/model/source preparation before freezing a future finite60/90scontract. Keep cooperative deadline and partial-selection/no-candidate behavior; no call-count or time extensions.','Require full66source validity before native validation, material claims or H5credit. All four earlier arrangements and440allocation candidates remain unresolved.'],
    'source_only_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'closed_problem_keys':18,'new_source_state_prepared':False,'replacement_selector_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
rows='\n'.join(f"| {r['epoch']} | {r['function_evaluations']} | {r['saved_points']} | {r['source_readbacks']['original']['original_overlap_mm2']:,.6f} | {r['source_readbacks']['original']['pair_failures']} |" for r in result['epochs'])
functions=load(BASE/'selector-profile/functions.json');profile_rows='\n'.join(f"| `{Path(r['file']).name}:{r['line']} {r['function']}` | {r['total_calls']:,} | {r['self_seconds']:.6f} | {r['cumulative_seconds']:.6f} |" for r in functions[:12])
placement=('changes' if cover['selected_placement_changed'] else 'does not change')
report=f'''# Two-center construction — 2026-11-07

The finite pipeline closes after **two calls**, with **33,907.097540 mm² original
overlap and 50 failing source pairs** in its best candidate. Fixed-part and stock
checks pass, but no valid full66 layout is established. H2/H5 remain open at
**60% completed milestone weight**. No native call or allocation exclusion follows.

## Closed finite search and independent replay

The [source preflight](h5-two-center-preflight-20261107.md) supplies the original
unoptimized initializer and retains **{front['complete_preparation_seconds']:.6f} s**
of complete preparation. The [frozen contract]({NAME}/search-plan.json) permits
at most two 4 s calls, with the second shortened at the 54 s source-check boundary.
Selection and key grouping stop at 52 s. Algorithm/shared limits remain 60/90 s
including preparation, inside the verified 2 GiB Windows Job.

| Epoch | Optimizer evaluations | Saved improvements | Original overlap (mm²) | Failed source pairs |
| --- | ---: | ---: | ---: | ---: |
{rows}

[Independent response replay]({NAME}/response-audit.json) checks all
**{front['total_evaluation_records_verified']} evaluation records**, **{front['saved_points_verified']}
saved points**, all **528 updated weights**, every dynamic model and all three
winner streams. The three streams coincide within each epoch; all six full66
outputs remain preserved. Each source check reconstructs 66 original parts,
1,380 same-sheet pairs, 264 stock edges, 90 cutouts and 10,026 hole vertices.
Maximum independent evaluation score error is {front['max_independent_score_error_mm2']:.3e}
mm²; maximum scalar winner-gradient error is
{front['max_winner_scalar_gradient_error_mm']:.3e} mm under the recorded boundary conventions.

[Complete runtime reconstruction]({NAME}/runtime-selection-audit.json) verifies
all **9,102 center trials**, **23,419 raw proposals** and **2,854 complete key minima**:
32,521 full independently rebuilt scores. The runtime uses full recalculation,
with no original-source cache. The selected changes are **{selection['changes']}**.
All [eighteen problem keys]({NAME}/closed-problems.json) now stay closed; different
coordinates never authorize another call for an existing key.

The [closed result]({NAME}/closed-search-result.json) stops after its source checks.
Preparation-inclusive algorithm/shared totals are
**{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**. Recorded slice
overruns are **{front['slice_overruns_seconds'][0]:.6f}** and
**{front['slice_overruns_seconds'][1]:.6f} s**; neither overall limit is exceeded.
[All five processes close]({NAME}/closed-search-process.json), with peak aggregate
committed memory of {load(BASE/'search/process.json')['job']['peak_job_committed_memory']:,} bytes.
The separate [complete response audit]({NAME}/response-audit-process.json) closes
in {audit_process['complete_seconds']:.6f} s. This finite pipeline cannot resume.

## Coverage, residual geometry and runtime cost

[Same-context coverage]({NAME}/runtime-coverage-and-time.json) filters the recorded
pool to its exact 5,911 first-center proposals, retaining identical runtime state,
weights and exclusions. Using independent full scores, second-center combinations
strictly improve **{cover['eligible_keys_strictly_improved']} eligible key minima**.
The best eligible placement **{placement}**; its independent objective decrease is
**{cover['independent_best_eligible_improvement_mm2']:.6f} mm²**, and selected center ranks
are **{cover['selected_center_ranks_zero_based']}**. These scores do not establish a packing benefit.

The measured weight-update/selection/output/model interval is
**{cover['weight_update_selection_output_model_interval_seconds']:.6f} s**, leaving only
**{cover['second_optimizer_allocated_seconds']:.6f} s** for the second call. That interval
includes serialization and model verification; it is not a pure scoring-kernel timing.
The best candidate still fails more pairs than the preceding current-mode run
(50 versus 47), but [historical comparisons]({NAME}/prior-comparisons.json) are not
controlled experiments and do not establish a causal performance difference.

[Residual diagnosis]({NAME}/outcome-diagnostic.json) records {diag['positive_area_pairs']}
positive original/clearance pair terms, {diag['flat_available_pair_gradient_count']}
flat available pair gradients, {diag['bracket_bracket_source_failures']} bracket/bracket
source failures and {diag['cog_lower_y_negative_gradient_blocked']} cogs whose negative-gradient
descent is blocked at their lower-y bound. [Family failures]({NAME}/family-failures.json)
and the complete failed geometry are preserved. No diagnostic changes a candidate.

[Read-only profiling]({NAME}/selector-profile.json) runs the unchanged uncached
selector once in the already audited runtime context. Every returned proposal,
alias, center trial and selected center agrees exactly with the closed search.
Instrumented time is {profile['profiled_selector_seconds']:.6f} s; instrumentation adds
overhead, so this is function attribution, not a production speed claim.
[All profile functions]({NAME}/profile-functions.json) and raw profiler data are retained.

| Function | Calls | Self seconds | Cumulative seconds |
| --- | ---: | ---: | ---: |
{profile_rows}

Cumulative times overlap and must not be summed. The bounded profile process
[closes normally]({NAME}/selector-profile-process.json), with zero optimizer calls.
Repeated problem-key calculation accounts for 2.647380 s cumulative; constructing
the 528-entry pair-loss list for each proposal accounts for 2.065071 s self time.
These measured operations motivate local per-context digest reuse and ordered
NumPy pair gathering as the next implementation candidates. No speedup is yet measured.

[Next]({NAME}/next-step.json), assess equivalent selector computation using this
profile. No replacement implementation, successor source state or new search is
prepared. Complete output/score/deadline equivalence must precede any fresh
original-source preparation. Retain the full preparation cost and all eighteen
closed keys. Four earlier arrangements and all 440 allocation candidates remain.

The preceding checkpoints reached main **8dc99684** through an ordinary atomic
push after all six prior checks passed, preserving all 52 protected files.
The [push receipt]({NAME}/prior-main-push-receipt.json) and [current main CI snapshot]({NAME}/main-ci-at-review.json)
are retained ({success} passed jobs, {live} live jobs at review). This checkpoint
awaits the ordinary push gate. Product code, README claims and releases are unchanged.

[Archive verification]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 two-center construction:** [independent full response and source replay]({{link}}) verifies two closed calls, all {front["total_evaluation_records_verified"]} evaluation records, {front["saved_points_verified"]} saved points, 528 updated weights and 32,521 complete runtime scores over 2,854 key minima. The best candidate has 33,907.097540 mm² original overlap and 50 failing pairs; fixed-part and stock checks pass. No valid full66 layout, native call or allocation exclusion follows. Preparation is 33.769462 s and algorithm/shared totals are {front["algorithm_seconds"]:.6f}/{front["shared_seconds"]:.6f} s; slice overruns are preserved within both overall limits. Selection/output/model work takes 12.272820 s, shortening the second call to 2.563988 s. Same-context independent comparison finds {cover["eligible_keys_strictly_improved"]} eligible key minima improved by second-center combinations; the best eligible placement {placement}. Read-only profiling exactly reproduces the complete runtime output and identifies computation costs without a packing or speedup claim. Next assess equivalent selector computation; no replacement, successor source state or search is prepared. All eighteen keys and finite pipelines stay closed. Four earlier arrangements and 440 allocations remain; H2/H5 stay open at 60%. Prior checkpoints reached main 8dc99684 normally, preserving 52 files; CI has {success} passed and {live} live jobs at review. Product code, README and releases remain unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [two-center construction](../benchmarks/results/{NAME}.md).
Two bounded calls close without a valid full66 layout: the best candidate has
33,907.097540 mm² original overlap and 50 failing pairs. Fixed-part and stock
checks pass. Independent replay verifies all {front['total_evaluation_records_verified']} evaluation records, {front['saved_points_verified']} saved
points, 528 updated weights and 32,521 runtime scores over 2,854 key minima.
Preparation is 33.769462 s and algorithm/shared totals are
{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s. All processes close; slice overruns stay within overall limits.
Selection/output/model work takes 12.272820 s, leaving 2.563988 s for the second
call. The same-context two-center comparison improves {cover['eligible_keys_strictly_improved']} eligible key minima;
the best eligible placement {placement}. Read-only profiling exactly reproduces
all runtime output. Next assess equivalent selector computation, preserving all
scores, identities and deadline behavior. No replacement, successor state or
new search is prepared. All eighteen keys and finite pipelines stay closed.
Four earlier arrangements and 440 allocations remain; H2/H5 stay open at 60%.
The prior checkpoints reached main 8dc99684 normally, preserving 52 files.
CI has {success} passed and {live} live jobs at review; this checkpoint awaits the ordinary
push gate. Product code, README and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
