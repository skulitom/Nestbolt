"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_bracket_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-center-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==1
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-01/original-source-checks.json','search/epoch-01/response.json','search/epoch-01/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json',Q/'response-audit/checks.json',U/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-01/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-01/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-01/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P),('prior_best_admissible',Q),('prior_current_mode',U)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))



# Recorded runtime data only: no replacement candidate or fresh search state.
from collections import Counter
folder=BASE/'search/epoch-01';audit_folder=BASE/'response-audit/epoch-01-selection'
runtime_rows=load(folder/'neighbors.json');runtime_selections=load(folder/'center-selections.json');recorded_choice=load(folder/'selection.json')['accepted_choice'];scores={r['sequence']:r['augmented_objective_mm2'] for r in load(audit_folder/'proposal-score-controls.json')}
assert len(runtime_rows)==len(scores)==23419 and load(audit_folder/'checks.json')['passed']
centers={(r['owner'],r['mode']):[tuple(p['center']) for p in r['selected']] for r in runtime_selections};one_center=[];one_groups={};all_groups={};bindings=[]
def ordering(row):return row['augmented_objective_mm2'],row['modes'],len(row['changes']),row['changes'],row['centers'],row['sequence']
for row in runtime_rows:
    ranks=[centers[i,mi].index(tuple(center)) for (i,mi),center in zip(row['changes'],row['centers'])];assert all(v in [0,1] for v in ranks);all_groups.setdefault(row['key'],[]).append(row)
    if all(v==0 for v in ranks):one_center.append(row);one_groups.setdefault(row['key'],[]).append(row)
    bindings.append({'sequence':row['sequence'],'center_ranks_zero_based':ranks,'one_center_subset':all(v==0 for v in ranks)})
assert len(one_center)==5911 and len(one_groups)==len(all_groups)==2854 and Counter(map(len,one_groups.values()))=={562:1,33:78,1:2775}
comparisons=[]
for key,rows in sorted(all_groups.items()):
    old=min(one_groups[key],key=ordering);new=min(rows,key=ordering);old_oracle=min(scores[r['sequence']] for r in one_groups[key]);new_oracle=min(scores[r['sequence']] for r in rows)
    assert abs(scores[old['sequence']]-old_oracle)<1e-6 and abs(scores[new['sequence']]-new_oracle)<1e-6
    delta=scores[old['sequence']]-scores[new['sequence']];assert delta>=-1e-6
    comparisons.append({'key':key,'one_center_sequence':old['sequence'],'two_center_sequence':new['sequence'],'excluded':new['excluded'],'independent_improvement_mm2':delta,'strictly_improved':delta>1e-6})
old_best=min((r for r in one_center if not r['excluded']),key=ordering);new_best=min((r for r in runtime_rows if not r['excluded']),key=ordering);assert new_best==recorded_choice
delta=scores[old_best['sequence']]-scores[new_best['sequence']];assert delta>=-1e-6
selected_ranks=bindings[new_best['sequence']]['center_ranks_zero_based'];opened=load(folder/'opened.json');call=load(folder/'optimizer-opened.json');response=load(folder/'response.json');first_response=load(BASE/'search/epoch-00/response.json');process=load(BASE/'search/process.json');result=load(BASE/'search/result.json')
assert not result['runtime_neighbor_cache_used'] and not opened['runtime_neighbor_cache_used']
elapsed=call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'];assert elapsed>0
summary={'passed':True,'runtime_raw_proposals':len(runtime_rows),'one_center_subset_proposals':len(one_center),'additional_center_combinations':len(runtime_rows)-len(one_center),'same_context_key_comparisons':len(comparisons),'keys_strictly_improved':sum(r['strictly_improved'] for r in comparisons),'eligible_keys_strictly_improved':sum(r['strictly_improved'] and not r['excluded'] for r in comparisons),'old_best_eligible_sequence':old_best['sequence'],'new_best_eligible_sequence':new_best['sequence'],'selected_placement_changed':(old_best['changes'],old_best['centers'])!=(new_best['changes'],new_best['centers']),'independent_best_eligible_improvement_mm2':delta,'selected_center_ranks_zero_based':selected_ranks,'runtime_context_and_closed_keys_unchanged_in_comparison':True,'runtime_neighbor_cache_used':False,'weight_update_selection_output_model_interval_seconds':elapsed,'interval_scope':'From epoch1 opened record to second optimizer opened record; includes area-weight update, complete uncached neighbor scoring, output, key grouping and dynamic model verification. Not a pure scoring-kernel profile.','first_optimizer_returned_seconds':first_response['returned_seconds'],'second_optimizer_allocated_seconds':call['allocated_seconds'],'second_optimizer_returned_seconds':response['returned_seconds'],'preparation_seconds':result['complete_preparation_seconds'],'algorithm_seconds':result['algorithm_seconds_including_preparation'],'shared_seconds':process['seconds_including_preparation'],'optimizer_calls_in_diagnostic':0,'candidate_changed_by_diagnostic':False,'new_successor_seed_created':False,'H5_complete':False}
paths=[Path(__file__)]+[folder/n for n in ['neighbors.json','center-selections.json','selection.json','opened.json','optimizer-opened.json','response.json']]+[audit_folder/n for n in ['checks.json','proposal-score-controls.json']]+[BASE/n for n in ['search/epoch-00/response.json','search/process.json','search/result.json','response-audit/checks.json']]
write(OUT/'runtime-coverage-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Filter the complete recorded two-center runtime pool to its exact first-center subset, preserve current weights/state/closed keys, compare all key minima using independent full-score readbacks, and reconstruct the measured selection/output/model interval. No geometry proposal, optimizer, candidate mutation or seed.'})
write(OUT/'runtime-center-ranks.json',bindings);write(OUT/'runtime-key-improvement-controls.json',comparisons);write(OUT/'runtime-coverage-and-time.json',summary);print(summary)
