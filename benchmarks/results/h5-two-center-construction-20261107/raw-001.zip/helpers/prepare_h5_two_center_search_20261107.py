"""Version a finite two-by-four-second pipeline with uncached runtime selection."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_current_mode_search_20261107.py').read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107'":"BASE=ROOT/'output/h5-two-center-preflight-20261107'",
    'audit_h5_current_mode_response_20261107':'audit_h5_two_center_response_20261107',
    'run_h5_current_mode_response_stage_20261107':'run_h5_two_center_response_stage_20261107',
    'h5_current_mode_relocations_20261107':'h5_two_center_neighbors_20261107',
    'h5_current_mode_key_choice_20261107':'h5_two_center_key_choice_20261107',
    'h5_current_mode_key_readback_20261107':'h5_two_center_key_readback_20261107',
    'h5_current_mode_selection_readback_20261107':'h5_two_center_selection_readback_20261107',
    "'audit/source-domains/checks.json'":"'audit/inherited-source-domains.json','audit/cache-controls.json','coverage-audit/checks.json'",
    "'optimizer_slice_seconds':8.":"'optimizer_slice_seconds':4.",
    'Exclude all fourteen prior identities':'Exclude all sixteen prior identities',
    'At most two eight-second calls':'At most two four-second calls',
    'and5911raw augmented proposals':'and23419raw augmented proposals, retaining the first two distinct centers per physical owner/mode and all their single/joint combinations',
    'The27.20468939933926seconds of retained preparation and larger measured selector motivate the two-call ceiling':'The33.769462099531665seconds of retained preparation,9.188667400041595second complete uncached selector validation (before normal output/group I/O), and12.560903900070116second synthetic completion/serialization control motivate a maximum of two four-second slices. The second slice is shortened by the54second source boundary and may never open if selection reaches52seconds. This is a fixed ceiling, not a guarantee of two calls or a hard bound on any cooperative batch',
    "regions,visited,deadline=started+plan['selection_boundary_seconds'])":"regions,visited,deadline=started+plan['selection_boundary_seconds'],cached_trials=None)",
    "'weights_before_update':weights,'visited_keys'":"'weights_before_update':weights,'runtime_neighbor_cache_used':False,'visited_keys'",
    "'complete_runtime_centers':total_centers,'epochs'":"'complete_runtime_centers':total_centers,'runtime_neighbor_cache_used':False,'epochs'",
}
for a,b in changes.items():assert a in runner,a;runner=runner.replace(a,b)
runner=runner.replace('Deadline-aware selection includes current modes','Changed runtime states never use the original source cache. Deadline-aware selection includes current modes')

audit=(ROOT/'output/audit_h5_current_mode_response_20261107.py').read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107'":"BASE=ROOT/'output/h5-two-center-preflight-20261107'",
    'h5_current_mode_selection_readback_20261107':'h5_two_center_selection_readback_20261107',
    'h5_current_mode_key_readback_20261107':'h5_two_center_key_readback_20261107',
    'h5_current_mode_relocations_20261107':'h5_two_center_neighbors_20261107',
    'len(old_closed)==14':'len(old_closed)==16',
    "len(old_closed)==result['historical_closed_keys']==14":"len(old_closed)==result['historical_closed_keys']==16",
    "'prior_closed_keys':14":"'prior_closed_keys':16",
    "call['allocated_seconds']<=8":"call['allocated_seconds']<=4",
    "plan['optimizer_slice_seconds']==8":"plan['optimizer_slice_seconds']==4",
    "opened['epoch']==epoch and opened['incoming_values']":"opened['epoch']==epoch and not opened['runtime_neighbor_cache_used'] and opened['incoming_values']",
    "and not result['old_calls_resumed']":"and not result['runtime_neighbor_cache_used'] and not result['old_calls_resumed']",
    "'old_calls_resumed':False":"'runtime_neighbor_cache_used':False,'old_calls_resumed':False",
    "['plan.json','opened.json','plan-v2.json']":"['plan.json','opened.json','plan-v2.json','inherited-source-domains.json']",
}
for a,b in changes.items():assert a in audit,a;audit=audit.replace(a,b)
stage=(ROOT/'output/run_h5_current_mode_response_stage_20261107.py').read_text(encoding='utf-8').replace('h5-current-mode-relocation-','h5-two-center-').replace('audit_h5_current_mode_response_20261107.py','audit_h5_two_center_response_20261107.py')
outputs={'run_h5_two_center_search_20261107.py':runner,'audit_h5_two_center_response_20261107.py':audit,'run_h5_two_center_response_stage_20261107.py':stage}
for name,text in outputs.items():compile(text,name,'exec');assert not (ROOT/'output'/name).exists()
for name,text in outputs.items():
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
