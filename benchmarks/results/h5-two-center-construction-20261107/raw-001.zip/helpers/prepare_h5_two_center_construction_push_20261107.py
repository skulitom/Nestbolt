"""Pin the construction checkpoint push to the current main and its full CI."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_two_center_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-two-center-main-sync-20261107':'h5-two-center-construction-main-sync-20261107',
    'b8a14317a240988eb22b58a238e712bce2f0e061':'8dc996845c2dfa02bd3eea23aa8e7cd6241211ca',
    '42380700484':'42383126925',
    "prefixes=('benchmarks/results/h5-current-mode-relocation-construction-20261107','benchmarks/results/h5-two-center-preflight-20261107')":"prefixes=('benchmarks/results/h5-two-center-construction-20261107',)",
    "['h5-current-mode-relocation-construction-20261107','h5-two-center-preflight-20261107']":"['h5-two-center-construction-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
compile(source,'push_h5_two_center_construction_checkpoints_20261107.py','exec')
with (ROOT/'output/push_h5_two_center_construction_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
s=(ROOT/'output/verify_h5_two_center_staged_20261107.py').read_text(encoding='utf-8').replace("NAME='h5-two-center-preflight-20261107'","NAME='h5-two-center-construction-20261107'").replace('h5-two-center-staged-checks-20261107.json','h5-two-center-construction-staged-checks-20261107.json')
compile(s,'verify_h5_two_center_construction_staged_20261107.py','exec')
with (ROOT/'output/verify_h5_two_center_construction_staged_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Bounded push and exact staged-byte verifier prepared; neither executed.')
