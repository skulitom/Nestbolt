"""Read-only profiling of the closed runtime context; never a search seed."""
from pathlib import Path
from hashlib import sha256
import cProfile,json,pstats,time
from h5_two_center_neighbors_20261107 import neighbors
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-center-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';OUT=BASE/'selector-profile';E=BASE/'search/epoch-01'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'outcome-diagnostic/runtime-coverage-and-time.json')['passed']
OUT.mkdir();paths=[Path(__file__),ROOT/'output/h5_two_center_neighbors_20261107.py',A/'library.json',A/'objective-identity.json',B/'regions.json',BASE/'response-audit/checks.json',BASE/'outcome-diagnostic/runtime-coverage-and-time.json']+[E/n for n in ['opened.json','weight-transition.json','neighbors.json','owner-aliases.json','center-trials.json','center-selections.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'One cProfile pass of the unchanged uncached selector in the already independently audited runtime context. Compare all returned records exactly with the preserved closed search. Profiling overhead is included; function attribution is diagnostic, not an uninstrumented performance claim. No chosen candidate, geometry update, optimizer, successor state or fresh preparation.','selector_calls':1,'optimizer_calls':0,'cap_seconds':180,'validation_only':True})
opened=load(E/'opened.json');weights=load(E/'weight-transition.json')['after'];args=[load(A/'library.json'),opened['incoming_modes'],opened['incoming_values'],weights,load(A/'objective-identity.json'),load(B/'regions.json'),set(opened['visited_keys'])]
profiler=cProfile.Profile();start=time.perf_counter();profiler.enable()
actual=neighbors(*args,deadline=start+150,cached_trials=None)
profiler.disable();elapsed=time.perf_counter()-start;profiler.dump_stats(str(OUT/'selector.prof'))
for values,name in zip(actual,['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json']):assert values==load(E/name),name
rows=[]
for (file,line,function),(primitive,total,self_seconds,cumulative_seconds,callers) in pstats.Stats(profiler).stats.items():
    rows.append({'file':file,'line':line,'function':function,'primitive_calls':primitive,'total_calls':total,'self_seconds':self_seconds,'cumulative_seconds':cumulative_seconds})
write(OUT/'functions.json',sorted(rows,key=lambda r:(-r['cumulative_seconds'],r['file'],r['line'])))
summary={'passed':True,'validation_only':True,'profiled_selector_seconds':elapsed,'profiled_function_entries':len(rows),'complete_proposals_exactly_reproduced':len(actual[0]),'complete_center_trials_exactly_reproduced':len(actual[2]),'owner_mode_selections_exactly_reproduced':len(actual[3]),'runtime_neighbor_cache_used':False,'selector_calls':1,'optimizer_calls':0,'new_source_state_prepared':False,'candidate_changed':False,'H5_complete':False,'timing_scope':'Instrumented selector only; cProfile adds overhead and this does not measure production speedup.'}
write(OUT/'checks.json',summary);print(summary);print(json.dumps(sorted(rows,key=lambda r:-r['cumulative_seconds'])[:25],indent=2))
