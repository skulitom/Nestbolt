"""One closed augmented-objective call; preserve all evaluations and three winners."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-center-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'search';B=ROOT/'output/h5-bracket-collision-depth-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
METRICS={'augmented':'augmented_objective_mm2','original':'original_overlap_area_mm2','unweighted':'unweighted_objective_mm2'}

def run_epoch(folder,started,model,lib,identity,regions,key,plan):
    import numpy as np
    from scipy.optimize import minimize
    from h5_bracket_augmented_objective_20261107 import Objective
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_legacy64_source_readback import audit
    obj=Objective(model,regions,identity);bounds=np.array(model['bounds']);initial_x=np.array(model['initial']);winners={};saved=0;evaluations=0
    (folder/'points').mkdir();log=(folder/'evaluations.jsonl').open('x',encoding='utf-8',newline='\n')
    def record(x,value,g,details,evaluation):
        nonlocal saved
        r={'evaluation':evaluation,'values':x.tolist(),'gradient':g.tolist(),**{field:float(details[field]) for field in ['augmented_objective_mm2','original_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']}}
        assert value==r['augmented_objective_mm2'] and np.all(x>=bounds[:,0]) and np.all(x<=bounds[:,1])
        flags={name:name not in winners or r[field]<winners[name][field] for name,field in METRICS.items()};r['improved']=flags
        r['saved_sequence']=saved if any(flags.values()) else None
        log.write(json.dumps(r,allow_nan=False,separators=(',',':'))+'\n');log.flush()
        if any(flags.values()):
            write(folder/'points'/f'{saved:05d}.json',r);saved+=1
            for name,improved in flags.items():
                if improved:winners[name]=r
        return r
    value,g,details=obj.evaluate(initial_x,True);record(initial_x,value,g,details,0)
    options=load(A/'audit-v2/optimizer-controls.json')['options'];allocated=min(plan['optimizer_slice_seconds'],54-(time.perf_counter()-started));assert allocated>0
    write(folder/'optimizer-opened.json',{'key':key,'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'nonsmooth_convention':'existing source boundary convention and deterministic bracket nearest branch; not globally differentiable','parameters':81,'allocated_seconds':allocated,'model_sha256':digest(folder/'model.json'),'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'maximum_calls_for_problem':1,'retry_permitted':False,'algorithm_seconds_including_preparation':time.perf_counter()-started})
    class Deadline(Exception):pass
    def function(x):
        nonlocal evaluations
        if time.perf_counter()>=deadline:raise Deadline()
        value,g,d=obj.evaluate(x,True);evaluations+=1;record(x,value,g,d,evaluations);return value,g
    def callback(x):
        if winners['unweighted']['unweighted_objective_mm2']<=1e-16:raise StopIteration()
    before=time.perf_counter();deadline=before+allocated;numerical=None
    try:
        result=minimize(function,initial_x,jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options)
        status='RETURNED';numerical={'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'objective_mm2':float(result.fun),'values':result.x.tolist()}
    except Deadline:status='TIME_STOP'
    returned=time.perf_counter()-before;log.close();readbacks={};job=load(JOB);valid_witness=None
    for name,r in winners.items():
        value,g,d=obj.evaluate(r['values'],True)
        assert value==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
        rows=source_rows(model,r['values']);write(folder/(name+'-source66.json'),rows)
        checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])))
        write(folder/(name+'-source-checks.json'),checked)
        assert checked['stock_failures']==0 and checked['originals']==66
        readbacks[name]={'pair_failures':checked['pair_failures'],'source_valid66':checked['valid'],'original_overlap_mm2':d['original_overlap_area_mm2'],'unweighted_objective_mm2':d['unweighted_objective_mm2'],'augmented_objective_mm2':value,'auxiliary_bracket_depth_mm2':d['auxiliary_bracket_depth_mm2']}
        if checked['valid'] and valid_witness is None:valid_witness={'label':name,'source66_path':(folder/(name+'-source66.json')).relative_to(ROOT).as_posix()}
    elapsed=time.perf_counter()-started
    response={'closed':True,'status':status,'key':key,'numerical_result':numerical,'allocated_seconds':allocated,'returned_seconds':returned,'slice_overrun_seconds':max(0.,returned-allocated),'function_evaluations':evaluations,'total_evaluation_records':evaluations+1,'saved_points':saved,'winners':winners,'source_readbacks':readbacks,'source_valid66':valid_witness is not None,'valid_witness':valid_witness,'optimizer_calls':1,'mode_changes':0,'coefficient_updates':0,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'complete_preparation_seconds':plan['complete_preparation_seconds'],'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False}
    write(folder/'response.json',response);write(folder/'closed-problem.json',{'key':key,'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'closed':True,'retry_permitted':False,'response_sha256':digest(folder/'response.json')})
    return response

def child(started):
    import scipy
    from h5_bracket_augmented_objective_20261107 import compile_model,Objective,problem_key
    from h5_bracket_augmented_readback_20261107 import verify
    from h5_two_center_neighbors_20261107 import neighbors,apply_neighbor,SelectionDeadline
    from h5_weighted_original_model_20261107 import update_weights
    from h5_two_center_key_choice_20261107 import choose,KeySelectionDeadline
    from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
    from h5_checked_affinity_20261107 import affinity_mask
    assert scipy.__version__=='1.17.1' and affinity_mask()==4294901760
    assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
    plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
    initial=load(BASE/'selected-state.json');lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');classes=family_classes(lib)
    modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];old_closed={r['key'] for r in load(BASE/'closed-problems.json')};visited=set(old_closed)
    summaries=[];best_original=None;best_unweighted=None;valid_witness=None;stop='MAXIMUM_EPOCHS';total_trials=0;total_centers=0;updates=0
    for epoch in range(plan['maximum_optimizer_calls']):
        if time.perf_counter()-started>=plan['selection_boundary_seconds']:stop='TIME_STOP_BEFORE_EPOCH';break
        folder=OUT/f'epoch-{epoch:02d}';folder.mkdir();incoming=list(values)
        write(folder/'opened.json',{'epoch':epoch,'incoming_values':incoming,'incoming_modes':modes,'weights_before_update':weights,'runtime_neighbor_cache_used':False,'visited_keys':sorted(visited),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        if epoch:
            previous=compile_model(lib,modes,incoming,weights,identity);losses=Objective(previous,regions,identity).pair_losses(incoming).tolist();after=update_weights(weights,losses)
            write(folder/'weight-transition.json',{'before':weights,'pair_losses_mm2':losses,'after':after,'source':'previous_epoch_augmented_best','auxiliary_excluded_from_weight_update':True});weights=after;updates+=1
            try:
                records,aliases,trials,selections=neighbors(lib,modes,incoming,weights,identity,regions,visited,deadline=started+plan['selection_boundary_seconds'],cached_trials=None)
            except SelectionDeadline as exc:
                write(folder/'partial-selection.json',exc.evidence);stop='SELECTION_DEADLINE';break
            write(folder/'neighbors.json',records);write(folder/'owner-aliases.json',aliases);write(folder/'center-trials.json',trials);write(folder/'center-selections.json',selections);total_trials+=len(records);total_centers+=len(trials)
            try:
                selection,groups,minima=choose(records,deadline=started+plan['selection_boundary_seconds'])
            except KeySelectionDeadline as exc:
                write(folder/'partial-key-selection.json',exc.evidence);stop='KEY_SELECTION_DEADLINE';break
            write(folder/'selection.json',selection);write(folder/'group-members.json',groups);write(folder/'key-minima.json',minima)
            if not selection['strictly_improves_current']:stop='NO_IMPROVING_ADMISSIBLE';break
            chosen=selection['accepted_choice'];modes,model,point=apply_neighbor(lib,modes,incoming,weights,identity,chosen);incoming=point.tolist()
        else:
            model=compile_model(lib,modes,incoming,weights,identity);assert model==load(BASE/'selected-model.json')
        assert verify(model,lib,modes,incoming,weights,identity)
        key=problem_key(physical_key(lib,classes,modes),weights,identity);assert key not in visited
        if time.perf_counter()-started>=plan['source_reserve_boundary_seconds']:stop='TIME_STOP_BEFORE_CALL';break
        write(folder/'model.json',model);assert verify(load(folder/'model.json'),lib,modes,incoming,weights,identity)
        visited.add(key);response=run_epoch(folder,started,model,lib,identity,regions,key,plan)
        for label,field in [('original','original_overlap_area_mm2'),('unweighted','unweighted_objective_mm2')]:
            r=response['winners'][label];candidate={'epoch':epoch,'label':label,'metric':field,'score_mm2':r[field],'pair_failures':response['source_readbacks'][label]['pair_failures'],'source_valid66':response['source_readbacks'][label]['source_valid66']}
            if label=='original' and (best_original is None or candidate['score_mm2']<best_original['score_mm2']):best_original=candidate
            if label=='unweighted' and (best_unweighted is None or candidate['score_mm2']<best_unweighted['score_mm2']):best_unweighted=candidate
        if response['valid_witness'] is not None:valid_witness={'epoch':epoch,**response['valid_witness']}
        summary={'epoch':epoch,'key':key,'status':response['status'],'function_evaluations':response['function_evaluations'],'saved_points':response['saved_points'],'source_readbacks':response['source_readbacks'],'minimum_weight':min(weights),'maximum_weight':max(weights)}
        summaries.append(summary);print(summary,flush=True);values=response['winners']['augmented']['values']
        if valid_witness is not None:stop='SOURCE_VALID_CANDIDATE';break
        if time.perf_counter()-started>=plan['source_reserve_boundary_seconds']:stop='TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started
    result={'closed':True,'status':stop,'optimizer_calls':len(summaries),'unique_new_keys':len(visited)-len(old_closed),'historical_closed_keys':len(old_closed),'weight_updates':updates,'complete_runtime_proposals':total_trials,'complete_runtime_centers':total_centers,'runtime_neighbor_cache_used':False,'epochs':summaries,'best_original':best_original,'best_unweighted':best_unweighted,'source_valid66':valid_witness is not None,'valid_witness':valid_witness,'complete_preparation_seconds':plan['complete_preparation_seconds'],'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False}
    write(OUT/'result.json',result);print({k:v for k,v in result.items() if k!='epochs'})


def main():
    checked=load(BASE/'audit/checks.json');assert checked['passed'] and checked['strictly_improves_current'];OUT.mkdir();charge=checked['complete_preparation_seconds'];started=time.perf_counter()-charge
    inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','checks.json','selected-model.json','selected-state.json','selection.json','closed-problems.json','runtime-bindings.json','audit/plan.json','audit/checks.json','audit/deadline-controls.json','audit/selected-model-controls.json','audit/selection-replay/checks.json','audit/inherited-source-domains.json','audit/cache-controls.json','coverage-audit/checks.json','audit/policy-stop-controls.json']]+[A/n for n in ['library.json','objective-identity.json','audit-v2/optimizer-controls.json']]+[B/'regions.json']+[ROOT/'output'/n for n in ['audit_h5_two_center_response_20261107.py','run_h5_two_center_response_stage_20261107.py','h5_two_center_key_choice_20261107.py','h5_two_center_key_readback_20261107.py','h5_two_center_selection_readback_20261107.py','h5_two_center_neighbors_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_weighted_original_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_preparation_seconds':charge,'algorithm_seconds':60,'shared_seconds':90,'source_reserve_boundary_seconds':54,'selection_boundary_seconds':52,'memory_bytes':2**31,'cpu_affinity_mask':4294901760,'blas_threads':1,'maximum_optimizer_calls':2,'optimizer_slice_seconds':4.,'method':'One finite adaptive augmented pipeline from the independently audited new original-source admissible choice. All consumed source preparation is charged. Exclude all sixteen prior identities and close every new complete objective/physical-mode/weight key after one call. At most two four-second calls, each shortened at54seconds. After each call source-check all three winner streams and stop on valid66. Later epochs update the fixed bounded area-only weight rule from the preceding augmented winner inside this pipeline, retaining coefficient1 auxiliary terms. Changed runtime states never use the original source cache. Deadline-aware selection includes current modes and evaluates all9102source centers and23419raw augmented proposals, retaining the first two distinct centers per physical owner/mode and all their single/joint combinations. Independently audited grouping retains the minimum of every complete2854objective/physical-mode/weight key, excludes all visited keys, and accepts only a strict current-score improvement by1e-6. Keep raw single/joint diagnostics, all group members and key minima. Different coordinates never reopen a key. Stop at52seconds during neighborhood scoring or grouping, preserving partial evidence with no chosen candidate. The33.769462099531665seconds of retained preparation,9.188667400041595second complete uncached selector validation (before normal output/group I/O), and12.560903900070116second synthetic completion/serialization control motivate a maximum of two four-second slices. The second slice is shortened by the54second source boundary and may never open if selection reaches52seconds. This is a fixed ceiling, not a guarantee of two calls or a hard bound on any cooperative batch; neither the count nor time boundary can be extended. Verify every dynamic model before its call. Record every evaluation and all augmented/original/unweighted strict improvements. Global original and unweighted winners are comparable across epochs; augmented winners remain local to their weight vector. Source validity is authoritative. Stop on finite count, time, partial/no-improvement selection, valid source or inconsistency. No historical optimized seed, restart, reseed, grid refinement or native call.','retry_permitted':False,'restarts':0})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'complete_preparation_seconds':charge,'memory_bytes':2**31,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'retry_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No complete result; pipeline remains closed.')

if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
