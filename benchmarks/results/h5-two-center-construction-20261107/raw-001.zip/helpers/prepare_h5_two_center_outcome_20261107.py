"""Version residual diagnosis and attach read-only runtime coverage/timing audit."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/diagnose_h5_current_mode_outcome_20261107.py').read_text(encoding='utf-8');source=source[:source.index('# Executed after the independent complete response audit')]
changes={
    "BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107'":"BASE=ROOT/'output/h5-two-center-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107'",
    "Q/'response-audit/checks.json']":"Q/'response-audit/checks.json',U/'response-audit/checks.json']",
    "('prior_best_admissible',Q)]":"('prior_best_admissible',Q),('prior_current_mode',U)]",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
source+='\n'+(ROOT/'output/h5_two_center_runtime_coverage_20261107.py').read_text(encoding='utf-8')
compile(source,'diagnose_h5_two_center_outcome_20261107.py','exec')
with (ROOT/'output/diagnose_h5_two_center_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
