"""Freeze numerical/source preflight before constructing nominal regions."""
from pathlib import Path
from hashlib import sha256
import json,time,os
from h5_checked_affinity_20261107 import affinity_mask
from h5_bracket_collision_depth_20261107 import build_regions,POLICY
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-bracket-collision-depth-20261107'
W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter()
assert affinity_mask()==4294901760
assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
inputs=[Path(__file__),ROOT/'output/h5_bracket_collision_depth_20261107.py',ROOT/'output/audit_h5_bracket_collision_depth_20261107.py',ROOT/'output/h5_checked_affinity_20261107.py']
inputs += [W/n for n in ['library.json','model.json','initial-state.json','audit-v2/checks.json']]
inputs += [R/n for n in ['pair-plateau-diagnostic/checks.json','pair-plateau-diagnostic/flat-pair-probes.json','search/epoch-02/model.json','search/epoch-02/response.json','response-audit/checks.json']]
inputs += [ROOT/'benchmarks/results'/n for n in ['h5-outline-contact-direction-20261018.md','h5-terminal-repair-diagnosis-20261018.md','h5-target-cog-repair-and-source-gradients-20261107.md','h5-weighted-relocated-construction-20261107/next-step.json','h5-weighted-relocated-construction-20261107/archive-checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'policy':POLICY,
    'method':'Build all100 ordered nominal mode pairs from a source-proved two-rectangle decomposition; independently verify using a different two-rectangle decomposition, exact rational cell arrangement and boundary distances, direct source polygons and source-center float-error bounds. Retain all10 domain identities. This is auxiliary-only preflight; no augmented model or optimizer is constructed.',
    'controls':'All arrangement cell centers, edge midpoints and vertices with one exterior slab each side; exact rational distance to independent elementary boundary segments; unique-feature central derivatives and ties/concave corners via one-sided descent. Saved crossed-arm case is validation-only, never a seed.',
    'coefficient_fixed_before_measurement':1.,'value_tolerance_mm2':1e-8,'gradient_tolerance_mm':1e-6,'central_step_mm':1e-4,'central_tolerance':.002,'descent_step_mm':.001,
    'floating_error_method':'Binary64 gamma_8 bound per source-pose coordinate path, absolute intermediate sum at most C+2(Px+Py); plus measured exact rational trig coefficient deviation times abs centered coordinates. Include rounded subtraction of the two center coordinates. Compare twice Euclidean vertex bound plus relative-coordinate displacement against required_pair_gap_mm using exact rationals.',
    'optimizer_calls':0,'candidate_mutations':0,'new_model':False,'source_acceptance_unchanged':True,'cap_seconds':20,'memory_bytes':2**31,'retry_permitted':False})
library=load(W/'library.json');data=build_regions(library)
write(OUT/'regions.json',data)
runtime=load(ROOT/'benchmarks/results/h5-weighted-relocated-construction-20261107/runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'ordered_regions':len(data['regions']),'domain_modes':len(data['modes']),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
