"""Seal source collision-depth preflight, including its preserved audit failure."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-bracket-collision-depth-preflight-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-bracket-collision-depth-20261107';F=BASE/'audit-v2';D=BASE/'projection-diagnostic'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-weighted-relocated-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['ordered_regions']==100 and front['queries']==19544 and front['optimizer_calls']==0",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-bracket-collision-depth-preparation-process-20261107','h5-bracket-collision-depth-audit-process-20261107','h5-bracket-collision-depth-audit-v2-process-20261107']]",
    "['*h5*mixed*mode*20261107.py']":"['*h5*bracket*depth*20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_bracket_depth_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "load(F/'source-bindings.json').items()":"load(BASE/'plan.json')['inputs'].items()",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(F/'checks.json','geometry-audit.json'),(F/'source-controls.json','source-controls.json'),(F/'region-controls.json','region-controls.json'),(F/'floating-controls.json','floating-controls.json'),(F/'flat-pair-controls.json','flat-pair-controls.json'),(F/'objective-controls.json','objective-controls.json'),(F/'negative-controls.json','negative-controls.json'),(BASE/'plan.json','plan.json'),(BASE/'plan-v2.json','audit-correction.json'),(D/'checks.json','projection-diagnostic.json'),(D/'records.json','projection-records.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for folder,name in [('preparation','preparation-process.json'),('audit','preserved-failed-audit-process.json'),('audit-v2','audit-process.json')]:copies.append((ROOT/'output'/f'h5-bracket-collision-depth-{folder}-process-20261107'/'process.json',name))
for p,name in copies:shutil.copyfile(p,OUT/name)
charge=load(ROOT/'output/h5-weighted-mixed-rows-model-20261107/audit-v2/checks.json').get('complete_preparation_seconds')
assert charge==9.437443899689242
new_charge=load(OUT/'preparation-process.json')['complete_seconds'];complete_charge=charge+new_charge
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']},'complete_source_preparation_seconds_before_new_model':complete_charge,'new_geometry_preparation_seconds':new_charge})
write(OUT/'next-step.json',{'status':'augmented_area_plus_bracket_depth_model_preflight_required','proposal':'Construct a separately versioned 81-coordinate objective retaining all528 positively weighted original/clearance pairs and adding coefficient1 times the unweighted sum of all15 nominal bracket pair squared exit depths. Start only from the original unoptimized W source initializer. Bind the region table, kernel policy and complete objective identity in the model and closed-problem key. First independently verify all model fields, all legal mode scores and aggregate gradient controls. Only then consider a finite fully charged60/90-second construction. No augmented model or optimizer exists in this checkpoint.',
    'source_initializer':'output/h5-weighted-mixed-rows-model-20261107/initial-state.json','source_library':'output/h5-weighted-mixed-rows-model-20261107/library.json','complete_preparation_seconds_before_new_model':complete_charge,
    'requirements':['Keep all33 movers,81 coordinates,528 exact area-pair losses,15 auxiliary bracket pairs,positive bounded weights and every hard stock/fixed-part bound. Weight updates, if used, still consume only original-plus-clearance areas; the auxiliary coefficient stays1.','Preserve all7 closed weighted problems and all older calls. Objective identity must distinguish the supplementary loss; do not resume, alter, reset or extend a closed call. Any new search needs a declared finite contract and complete source/preparation accounting before launch.','Independently read back the entire augmented model. Verify objective score and combined gradient against independent source areas and rational bracket-boundary controls, including legal mode changes and nearest-feature ties. Central differences are only derivative controls where the function is differentiable.','The saved flat candidate is validation-only and may not seed optimization. Its two feasible pair-descent probes say nothing about whole-objective or packing improvement.','Use full original-source validation on all66parts for acceptance, with native validation only after a valid source witness. Keep both original-area and augmented-score winners explicit; a lower surrogate objective is not a valid layout.'],
    'new_auxiliary_kernel_prepared':True,'augmented_model_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Bracket collision-depth preflight — 2026-11-07

The source-derived auxiliary term passes independent geometry and derivative
checks. It supplies a separating direction for the previously flat crossed-arm
collision. This is a numerical preflight: **no augmented optimization model,
new search, full valid layout or allocation exclusion is produced**. H2/H5
remain open at **60% completed milestone weight**.

## Source geometry and fixed objective definition

[The frozen plan]({NAME}/plan.json) defines the supplementary term before
measurements: coefficient **1** times the sum of squared distances from an
interior relative bracket translation to the boundary of its nominal collision
region, and zero outside or on that boundary. It is added to the existing
weighted original-plus-clearance area objective. The area terms and their
positive weights remain unchanged; auxiliary coefficients are not reweighted.

The bracket is the original six-vertex L, with area40,000mm² and source center
(150,125)mm. The producer splits it into a horizontal rectangle and its
remaining vertical arm. The independent audit uses a different decomposition:
the full vertical column and remaining horizontal arm. Their exact integer
boundaries match the source under all quarter-turn/reflection modes.
[All ten mode/domain identities]({NAME}/source-controls.json) remain separate,
including aliases with different legal center domains.

For each of **100 ordered mode pairs**, the producer unions four component
Minkowski-difference rectangles. The independent audit builds a rational cell
arrangement from its alternate decomposition and extracts exposed elementary
edges. [Every region]({NAME}/region-controls.json) agrees in occupied area and
boundary. The audit checks **19,544** arrangement vertices, edge midpoints and
cell centers, including exterior slabs, against both exact rational distances
and direct original-polygon intersections. All values and selected gradients
at these rational controls agree exactly.

The [audit]({NAME}/geometry-audit.json) covers4,720 interior points and14,824
boundary/exterior points, with **8,376** central derivative coordinates.
Maximum central error is0.000050005mm, below the frozen0.002 tolerance.
All4,720 selected-gradient descent controls pass, including **532** points
with distinct tied nearest features and **516** reflex-corner projections.
At ties the returned vector is a deterministic selected branch, not a claim
that a unique classical derivative exists. Zero-length edges are rejected;
all actual region boundary rings are included.

## Floating source transforms and retained acceptance

Nominal exact quarter turns are not described as identical to floating source
transforms. [The reconciliation]({NAME}/floating-controls.json) derives a
binary64 arithmetic bound over every bracket hard domain, including source
center/pivot cancellation, trigonometric coefficient error and rounded relative
center subtraction. If the nominal translated shapes intersect, the actual
source distance is at most **1.557479e-11mm**. This is below the required
**0.211708672510mm** gap, so a source-valid gap-separated bracket pair has zero
auxiliary loss. Ninety actual source-pose corner/midpoint checks agree within
the bound; the largest observed Hausdorff error is4.547474e-13mm.
There are11,216 nominal source-safe controls as well.

[Two unchanged validation cases]({NAME}/objective-controls.json) retain all
**528** area pairs and add the **15** bracket terms. The original initializer
has10.643914mm² auxiliary loss; the saved closed candidate has8,016.700868mm².
Independent rational sums and both-owner gradient signs agree. Positive
existing weights remain in[1,64], so the nonnegative extra term cannot hide
an original overlap. Four corrupted pivot/mode/angle bindings are
[rejected]({NAME}/negative-controls.json). Source acceptance is unchanged.

## Preserved assertion failure and correction

The first audit passes all100 region checks, then fails an exact-equality
assertion on an arbitrary floating closest point. The
[failed process]({NAME}/preserved-failed-audit-process.json) remains preserved.
[Independent rational diagnosis]({NAME}/projection-diagnostic.json) finds one
projection coordinate discrepancy of **1.421085e-14mm**, with maximum squared
value error4.343973e-13mm². The selected boundary segment is an exact minimizing
feature in both positive validation pairs; the geometry and kernel are sound.

[Version2]({NAME}/audit-correction.json) requires the selected segment's exact
rational projection to minimize distance, then checks its computed coordinate
against half the original1e-6 gradient tolerance. It uses that exact projection
for the independent aggregate gradient. No kernel, geometry, case, model,
coefficient, sample or declared numerical tolerance changes. The passing
[audit process]({NAME}/audit-process.json) closes in6.153590s; the failed process
closes in6.891152s. Both are validation only and neither launches optimization.

## Flat-collision evidence and next construction

Brackets7 and8 still overlap by5,625mm² in the saved source candidate; their
combined original/clearance term is11,284.552900mm² and its available pair
gradient is zero within1e-7. [The added term]({NAME}/flat-pair-controls.json)
has depth **89.536031mm**, squared loss **8,016.700868mm²**, and relative-y
gradient **179.072062mm**. Both owner derivatives pass central checks.
Either moving the first bracket up0.001mm or the second down0.001mm stays
inside its hard bounds and reduces the supplementary pair loss to
8,016.521797mm² while the area term remains flat. These are read-only probes;
the saved candidate is unchanged and is never an optimizer seed. Whole-job
improvement does not follow from pair descent.

Earlier work already used collision exclusions and nearest-boundary directions:
[October18 contact geometry](h5-outline-contact-direction-20261018.md),
[terminal repair](h5-terminal-repair-diagnosis-20261018.md) and
[later surrogate diagnostics](h5-target-cog-repair-and-source-gradients-20261107.md).
The last records a decreasing distance surrogate with increasing true overlap.
This checkpoint therefore adds a specifically checked bracket term without
replacing exact areas or claiming a new general packing technique.

The [next step]({NAME}/next-step.json) is a separately identified augmented
model, its complete independent readback and a finite charged construction
from the original unoptimized source initializer. The new
[geometry preparation]({NAME}/preparation-process.json) costs **{new_charge:.6f}s**;
complete consumed source preparation is **{complete_charge:.6f}s** before any
new model. It includes the9.437444s source initializer, and excludes the
validation-only closed-candidate observations. All seven weighted calls and
all older calls remain closed. Four earlier arrangements and440 allocations
remain unresolved. The latest search still fails46 pairs with28,414.189788mm²
overlap; this preflight does not change that result.

All six jobs on main c7e4b305
[pass at review]({NAME}/main-ci-at-review.json); the previous and current
checkpoints can now proceed through the ordinary guarded push. Product code,
README claims and releases remain unchanged.

[Archive verification]({NAME}/archive-checks.json),
[manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve all new and reused evidence.
'''
# Keep prose readable without changing the underlying numerical records.
for a,b in [('area40','area 40'),('000mm','000 mm'),('(150,125)mm','(150, 125) mm'),('covers4','covers 4'),('and14','and 14'),('is0.','is 0.'),('005mm','005 mm'),('frozen0','frozen 0'),('All4','All 4'),('e-11mm','e-11 mm'),('510mm','510 mm'),('is4.','is 4.'),('e-13mm','e-13 mm'),('are11','are 11'),('has10','has 10'),('914mm','914 mm'),('has8','has 8'),('868mm','868 mm'),('in[','in ['),('all100','all 100'),('e-14mm','e-14 mm'),('error4','error 4'),('Version2','Version 2'),('original1','original 1'),('in6','in 6'),('Brackets7','Brackets 7'),('and8','and 8'),('by5','by 5'),('625mm','625 mm'),('is11','is 11'),('900mm','900 mm'),('within1','within 1'),('031mm','031 mm'),('062mm','062 mm'),('up0','up 0'),('down0','down 0'),('001mm','001 mm'),('797mm','797 mm'),('October18','October 18'),('the9','the 9'),('and440','and 440'),('fails46','fails 46'),('with28','with 28'),('788mm','788 mm')]:report=report.replace(a,b)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 bracket collision-depth preflight:** [independent rational geometry and derivative audit]({link}) verifies all 100 ordered mode regions, 19,544 source-polygon controls, 8,376 central derivative coordinates and 4,720 descent probes, including 532 tied nearest-feature points and 516 reflex-corner projections. Ten source/domain identities remain distinct. A floating-transform bound of 1.557479e-11 mm is far below the required source gap; 90 source-pose controls pass. The original exact-projection assertion failure and a 1.421085e-14 mm discrepancy are preserved; a versioned verifier uses the unchanged predeclared tolerance and independently proves the selected segment minimizes distance. All 528 area terms remain, with 15 nonnegative auxiliary terms at coefficient 1. The flat bracket pair now has a verified separating direction and two feasible 0.001 mm descent probes, without changing its saved candidate or claiming whole-job improvement. Geometry preparation is 1.565239 s; complete source charge is 11.002683 s before a new model. No augmented model or optimizer is opened. All seven weighted problems remain closed; the latest search still fails 46 source pairs. Next build and independently audit the full augmented model from the original unoptimized initializer. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. All six current main CI jobs pass, enabling the ordinary checkpoint push. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [bracket collision-depth preflight](../benchmarks/results/{NAME}.md).
Independent rational geometry and source-polygon checks verify all 100 ordered
mode regions and 19,544 control points. Derivative controls include medial ties
and concave corners. The preserved floating-projection assertion failure is
corrected without changing the kernel, cases or declared tolerances. Source
transform bounds reconcile nominal quarter turns with actual floating geometry.
All 528 original/clearance area pairs remain; 15 nonnegative bracket terms at
coefficient 1 supply a verified separating direction on the flat crossed-arm
pair. Two feasible probes reduce the new pair term, but no full-job improvement
is claimed and the saved candidate remains unchanged. No augmented model or
optimizer is opened. Complete source preparation is {complete_charge:.6f} s before
that model. Next independently audit the full augmented objective and a finite
construction from the original unoptimized initializer. All seven weighted
calls stay closed; the latest search still fails 46 pairs with 28,414.189788 mm²
overlap. Four earlier arrangements and 440 allocations remain; H2/H5 stay at
60% completed milestone weight. All six jobs on main c7e4b305 pass; the pending
checkpoints are ready for the ordinary guarded push. Product code, README and
releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n')
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings),'complete_source_charge':complete_charge})
