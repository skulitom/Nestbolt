"""Version only the overstrict projection assertion; preserve all old bytes."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'projection-diagnostic/checks.json')['passed']
old=ROOT/'output/audit_h5_bracket_collision_depth_20261107.py';new=ROOT/'output/audit_h5_bracket_collision_depth_v2_20261107.py'
source=old.read_text(encoding='utf-8')
replacements={
    "OUT=BASE/'audit'":"OUT=BASE/'audit-v2'",
    "data=load(BASE/'regions.json');library=":"for name,h in load(BASE/'plan-v2.json')['inputs'].items():assert digest(ROOT/name)==h,name\ndata=load(BASE/'regions.json');library=",
    "[Path(__file__),BASE/'plan.json',BASE/'regions.json']":"[Path(__file__),BASE/'plan.json',BASE/'plan-v2.json',BASE/'regions.json']",
    "            q=tuple(F(z) for z in row['closest']);assert q in qs":"            selected=data['regions'][f'{a}:{b}']['segments'][row['selected']]\n            exact_q,exact_value=projection(t,tuple(tuple(F(z) for z in p) for p in selected))\n            assert exact_q in qs and exact_value==v\n            computed_q=tuple(F(z) for z in row['closest'])\n            assert max(abs(computed_q[k]-exact_q[k]) for k in [0,1])<=F(plan['gradient_tolerance_mm'])/2\n            q=exact_q",
}
for a,b in replacements.items():assert source.count(a)==1,a;source=source.replace(a,b)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
runner=ROOT/'output/run_h5_bracket_collision_depth_stage_20261107.py';newrunner=ROOT/'output/run_h5_bracket_collision_depth_audit_v2_20261107.py'
text=runner.read_text(encoding='utf-8')
replacements={"stage=sys.argv[1];assert stage in ['preparation','audit']":"stage='audit-v2'", "'audit_h5_bracket_collision_depth_20261107.py'":"'audit_h5_bracket_collision_depth_v2_20261107.py'"}
for a,b in replacements.items():assert text.count(a)==1;text=text.replace(a,b)
with newrunner.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
inputs=[Path(__file__),old,new,runner,newrunner,BASE/'plan.json',BASE/'regions.json',BASE/'projection-diagnostic/checks.json',BASE/'projection-diagnostic/records.json',ROOT/'output/h5-bracket-collision-depth-audit-process-20261107/process.json',ROOT/'output/h5-bracket-collision-depth-audit-process-20261107/stderr.txt']
write(BASE/'plan-v2.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'correction':'The old verifier required exact equality between binary64 dot-projection coordinates and the rational nearest point at arbitrary source coordinates. One coordinate differs by1.4210854715202004e-14mm. The new verifier independently clamps the selected segment using Fractions, requires it to be an exact minimizing boundary feature, then checks binary64 coordinate error against half the original1e-6 gradient tolerance. Reference aggregate gradient uses the exact minimizer. All original geometry, controls, policy, cases, kernel, value/derivative tolerances and model bytes stay unchanged.','optimizer_calls':0,'geometry_reprepared':False,'old_failure_preserved':True})
print({'versioned_audit_prepared':True,'kernel_changed':False})
