"""Supplementary nominal bracket collision depth; research preflight only.

The original source-area objective and source acceptance remain authoritative.
At equal nearest features the returned vector is a selected branch gradient,
not a claim of a unique classical derivative.
"""
import math
import numpy as np
import shapely
from shapely.geometry import Polygon, box, shape, mapping

COEFFICIENT = 1.0
POLICY = {
    'version': 'nominal-bracket-collision-depth-v1-20261107',
    'coefficient': COEFFICIENT,
    'loss': 'unweighted_sum_squared_distance_from_interior_to_union_boundary',
    'outside_and_boundary': 0.0,
    'tie_rule': 'first_minimum_binary64_squared_distance_in_lexicographic_segment_order',
    'tie_derivative': 'selected_branch_only',
    'existing_pair_weights_and_updates': 'unchanged_area_losses_only',
    'final_acceptance': 'unchanged_full_original_source_validation',
}

def nominal_point(point, center, turns, mirrored):
    x, y = point[0] - center[0], point[1] - center[1]
    if mirrored:
        x = -x
    for _ in range(turns):
        x, y = -y, x
    return [x, y]

def build_regions(library):
    family = library['families']['bracket']
    assert family['original'] == [[0,0],[300,0],[300,75],[100,75],[100,250],[0,250]]
    assert family['source_center'] == [150,125]
    components = [[0,0,300,75], [0,75,100,250]]
    modes = []
    for mode in library['family_modes']['bracket']:
        turns = round(mode['rotation_radians'] / (math.pi / 2))
        assert mode['rotation_radians'] == turns * (math.pi / 2) and 0 <= turns <= 3
        rectangles = []
        for x0,y0,x1,y1 in components:
            vertices = [nominal_point(p, family['source_center'], turns, mode['mirrored'])
                        for p in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]]
            rectangles.append([min(p[0] for p in vertices), min(p[1] for p in vertices),
                               max(p[0] for p in vertices), max(p[1] for p in vertices)])
        modes.append({'binding': mode, 'source_center': family['source_center'],
                      'turns': turns, 'rectangles': rectangles})
    regions = {}
    for a in modes:
        for b in modes:
            differences = [[u[0]-v[2],u[1]-v[3],u[2]-v[0],u[3]-v[1]]
                           for u in a['rectangles'] for v in b['rectangles']]
            region = shapely.union_all([box(*r) for r in differences])
            assert region.is_valid and region.geom_type == 'Polygon' and region.area > 0
            segments = []
            for ring in [region.exterior, *region.interiors]:
                points = list(ring.coords)
                for p,q in zip(points, points[1:]):
                    assert p != q and (p[0] == q[0] or p[1] == q[1])
                    segments.append(sorted([list(p),list(q)]))
            segments.sort()
            key = f"{a['binding']['mode']}:{b['binding']['mode']}"
            regions[key] = {'modes': [a['binding']['mode'],b['binding']['mode']],
                            'component_differences': differences,
                            'geometry': mapping(region), 'segments': segments}
    return {'policy': POLICY, 'modes': modes, 'regions': regions}

class Region:
    def __init__(self, data):
        self.polygon = shape(data['geometry'])
        segments = np.asarray(data['segments'], dtype=float)
        self.starts = segments[:,0]
        self.edges = segments[:,1] - self.starts
        self.denominators = np.sum(self.edges * self.edges, axis=1)
        assert np.all(self.denominators > 0)

    def evaluate(self, relative):
        t = np.asarray(relative, dtype=float)
        assert t.shape == (2,) and np.all(np.isfinite(t))
        if not shapely.contains_xy(self.polygon, t[0], t[1]):
            return 0., np.zeros(2), {'inside': False, 'selected': None, 'ties': []}
        fractions = np.clip(np.sum((t-self.starts)*self.edges,axis=1)/self.denominators,0.,1.)
        closest = self.starts + fractions[:,None] * self.edges
        residuals = t - closest
        distances = np.sum(residuals*residuals,axis=1)
        index = int(np.argmin(distances))
        return float(distances[index]), 2*residuals[index], {
            'inside': True, 'selected': index,
            'ties': np.flatnonzero(distances == distances[index]).tolist(),
            'closest': closest[index].tolist(),
        }

class Auxiliary:
    def __init__(self, data):
        assert data['policy'] == POLICY
        self.data = data
        self.regions = {k: Region(v) for k,v in data['regions'].items()}

    def evaluate(self, model, values):
        x = np.asarray(values, dtype=float)
        assert len(x) == model['parameters']
        g = np.zeros(len(x)); total = 0.; records = []
        for index,(i,j) in enumerate(model['pairs']):
            a,b = model['owners'][i],model['owners'][j]
            if a['identity'][0] != 'bracket' or b['identity'][0] != 'bracket':
                continue
            for owner in [a,b]:
                binding = self.data['modes'][owner['mode']]
                assert owner['angle_coordinate'] is None
                assert owner['source_center'] == binding['source_center']
                for field in ['mode','source_mode','cell_index','rotation_radians','mirrored']:
                    assert owner[field] == binding['binding'][field], field
            value,gg,detail = self.regions[f"{a['mode']}:{b['mode']}"].evaluate(x[2*j:2*j+2]-x[2*i:2*i+2])
            total += COEFFICIENT * value
            g[2*i:2*i+2] -= COEFFICIENT * gg
            g[2*j:2*j+2] += COEFFICIENT * gg
            records.append({'pair_index':index,'owners':[i,j],'depth_squared_mm2':value,**detail})
        return total,g,records
