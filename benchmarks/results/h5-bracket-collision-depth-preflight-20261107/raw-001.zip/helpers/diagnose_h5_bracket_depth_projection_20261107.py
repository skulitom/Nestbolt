"""Quantify the preserved exact-equality failure without changing the kernel."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time
import numpy as np
from h5_bracket_collision_depth_20261107 import Auxiliary
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-collision-depth-20261107';OUT=BASE/'projection-diagnostic'
W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();data=load(BASE/'regions.json');aux=Auxiliary(data)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'plan.json',BASE/'regions.json',ROOT/'output/h5-bracket-collision-depth-audit-process-20261107/process.json',ROOT/'output/h5-bracket-collision-depth-audit-process-20261107/stderr.txt']},'method':'For all15 bracket pairs in each of the two frozen validation cases, compute exact rational nearest projections on the independently checked boundary segments and compare the saved binary64 projection. No optimizer or geometry changes.'})
records=[]
for label,m,x in [('source_initializer',load(W/'model.json'),load(W/'initial-state.json')['values']),('closed_flat_case',load(R/'search/epoch-02/model.json'),load(R/'search/epoch-02/response.json')['unweighted_best']['values'])]:
    _,_,rows=aux.evaluate(m,x)
    for row in rows:
        if not row['inside']:continue
        i,j=row['owners'];t=tuple(F(float(x[2*j+k])-float(x[2*i+k])) for k in [0,1]);key=f"{m['owners'][i]['mode']}:{m['owners'][j]['mode']}"
        projections=[]
        for a,b in data['regions'][key]['segments']:
            q=tuple(min(max(t[k],F(min(a[k],b[k]))),F(max(a[k],b[k]))) for k in [0,1]);d=sum((t[k]-q[k])**2 for k in [0,1]);projections.append((d,q))
        best=min(d for d,q in projections);qs=sorted({q for d,q in projections if d==best});got=tuple(F(v) for v in row['closest']);expected=min(qs,key=lambda q:sum((q[k]-got[k])**2 for k in [0,1]));error=max(abs(expected[k]-got[k]) for k in [0,1])
        records.append({'case':label,'owners':[i,j],'modes':key,'computed_closest':list(map(float,got)),'exact_closest':list(map(str,expected)),'maximum_projection_coordinate_error_mm':float(error),'value_error_mm2':float(abs(best-F(row['depth_squared_mm2']))),'exact_equality':got in qs,'selected_segment_is_exact_minimizer':projections[row['selected']][0]==best})
write(OUT/'records.json',records)
checks={'passed':all(r['maximum_projection_coordinate_error_mm']<=1e-6 and r['value_error_mm2']<=1e-8 and r['selected_segment_is_exact_minimizer'] for r in records),'seconds':time.perf_counter()-start,'positive_pairs':len(records),'exact_projection_equality_failures':sum(not r['exact_equality'] for r in records),'max_projection_error_mm':max(r['maximum_projection_coordinate_error_mm'] for r in records),'max_value_error_mm2':max(r['value_error_mm2'] for r in records),'kernel_changed':False,'models_changed':False,'optimizer_calls':0}
write(OUT/'checks.json',checks);print(checks)
