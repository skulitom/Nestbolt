"""Independent rational cell/boundary and original-source preflight."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,time,copy
import numpy as np
from shapely.geometry import Polygon,Point,box,shape
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_bracket_collision_depth_20261107 import Auxiliary,Region,POLICY
from h5_mixed_direct_pose_20261107 import owner_shapes
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_cross_pair_weighted_model_20261107 import Objective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-collision-depth-20261107';OUT=BASE/'audit-v2'
W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')

def transform(point,mode):
    # Independent integer matrices and a DIFFERENT source decomposition.
    theta=mode['rotation_radians'];quarter=[0.,math.pi/2,math.pi,3*math.pi/2].index(theta)
    c,s=[(1,0),(0,1),(-1,0),(0,-1)][quarter]
    xx=F(point[0])-150;yy=F(point[1])-125
    if mode['mirrored']:xx=-xx
    return (xx*c-yy*s,xx*s+yy*c)

def components(mode):
    rectangles=[]
    for x0,y0,x1,y1 in [(0,0,100,250),(100,0,300,75)]:
        v=[transform(p,mode) for p in [(x0,y0),(x0,y1),(x1,y1),(x1,y0)]]
        rectangles.append((min(p[0] for p in v),min(p[1] for p in v),max(p[0] for p in v),max(p[1] for p in v)))
    return rectangles

def arrangement(rectangles):
    xs=sorted({p[k] for p in rectangles for k in [0,2]});ys=sorted({p[k] for p in rectangles for k in [1,3]})
    xs=[xs[0]-1,*xs,xs[-1]+1];ys=[ys[0]-1,*ys,ys[-1]+1]
    def covered(x,y):return any(r[0]<x<r[2] and r[1]<y<r[3] for r in rectangles)
    occupied={(i,j) for i in range(len(xs)-1) for j in range(len(ys)-1) if covered((xs[i]+xs[i+1])/2,(ys[j]+ys[j+1])/2)}
    segments=[]
    for i,j in occupied:
        if (i-1,j) not in occupied:segments.append(((xs[i],ys[j]),(xs[i],ys[j+1])))
        if (i+1,j) not in occupied:segments.append(((xs[i+1],ys[j]),(xs[i+1],ys[j+1])))
        if (i,j-1) not in occupied:segments.append(((xs[i],ys[j]),(xs[i+1],ys[j])))
        if (i,j+1) not in occupied:segments.append(((xs[i],ys[j+1]),(xs[i+1],ys[j+1])))
    segments=sorted(tuple(sorted(s)) for s in segments)
    controls=sorted(product(sorted(set(xs+[(a+b)/2 for a,b in zip(xs,xs[1:])])),sorted(set(ys+[(a+b)/2 for a,b in zip(ys,ys[1:])]))))
    return covered,segments,controls,occupied,xs,ys

def projection(t,segment):
    a,b=segment
    # Axis aligned endpoint clamp, without the producer's dot/projection formula.
    q=tuple(min(max(t[k],min(a[k],b[k])),max(a[k],b[k])) for k in [0,1])
    return q,sum((t[k]-q[k])**2 for k in [0,1])

def rational_value(t,covered,segments):
    if not covered(*t):return F(0),[],[]
    choices=[projection(t,s) for s in segments];best=min(d for q,d in choices)
    closest=sorted({q for q,d in choices if d==best})
    return best,closest,choices

OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for name,h in load(BASE/'plan-v2.json')['inputs'].items():assert digest(ROOT/name)==h,name
data=load(BASE/'regions.json');library=load(W/'library.json');source=library['families']['bracket']['original'];modes=library['family_modes']['bracket']
assert data['policy']==POLICY and plan['policy']==POLICY and len(data['regions'])==100 and len(data['modes'])==10
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'plan.json',BASE/'plan-v2.json',BASE/'regions.json']},'frozen_plan_sha256':digest(BASE/'plan.json'),'optimizer_calls':0})
assert Polygon(source).area==40000
source_controls=[];nominal=[];refs={};results=[];totals={'queries':0,'interior':0,'exterior_or_boundary':0,'different_closest_ties':0,'central_derivative_coordinates':0,'descent_controls':0,'concave_corner_controls':0,'direct_polygon_controls':0,'source_safe_controls':0}
max_value_error=0.;max_gradient_error=0.;max_central_error=0.
for i,mode in enumerate(modes):
    assert mode['mode']==i and data['modes'][i]['binding']==mode and data['modes'][i]['source_center']==[150,125]
    p=Polygon([tuple(map(float,transform(v,mode))) for v in source]);nominal.append(p)
    rectangles=components(mode);union=unary_union([box(*map(float,r)) for r in rectangles])
    assert p.symmetric_difference(union).area==0 and p.boundary.hausdorff_distance(union.boundary)==0
    assert sum((r[2]-r[0])*(r[3]-r[1]) for r in rectangles)==40000
    assert box(*map(float,rectangles[0])).intersection(box(*map(float,rectangles[1]))).area==0
    source_controls.append({'mode':i,'source_mode':mode['source_mode'],'cell_index':mode['cell_index'],'rectangle_union_area_mm2':40000,'boundary_equal':True})

# A conservative bound on actual floating source-center transforms over ALL
# allowed centers, not just sampled values. Each output is a signed sum of C,
# two vertex products and two pivot products. Each route has <=8 roundings.
u=F(1,2**53);gamma8=8*u/(1-8*u)
center_limit=max(abs(F(v)) for m in modes for interval in m['center_bounds_mm'] for v in interval)
delta=max(max(abs(F(math.cos(m['rotation_radians']))-c),abs(F(math.sin(m['rotation_radians']))-s)) for m in modes for c,s in [[(1,0),(0,1),(-1,0),(0,-1)][round(m['rotation_radians']/(math.pi/2))]])
coordinate_bound=gamma8*(center_limit+1100)+275*delta
radius_bound=2*coordinate_bound # L1 bound also bounds Euclidean displacement.
relative_coordinate_bound=u*2*center_limit/(1-u)
pair_distance_bound=2*radius_bound+2*relative_coordinate_bound
assert pair_distance_bound<F(library['required_pair_gap_mm'])
max_observed_vertex_error=0.;float_controls=[]
for i,mode in enumerate(modes):
    coordinates=[sorted({F(a),F(b),(F(a)+F(b))/2}) for a,b in mode['center_bounds_mm']]
    for center in product(*coordinates):
        center=tuple(map(float,center));actual=owner_shapes(library,'bracket',i,center)[0];expected=translate(nominal[i],*center)
        err=actual.hausdorff_distance(expected);max_observed_vertex_error=max(max_observed_vertex_error,err)
        assert err<=float(radius_bound)
        float_controls.append({'mode':i,'center':center,'hausdorff_mm':err})

for a,b in product(range(10),repeat=2):
    rects=[(r[0]-s[2],r[1]-s[3],r[2]-s[0],r[3]-s[1]) for r in components(modes[a]) for s in components(modes[b])]
    covered,segments,controls,occupied,xs,ys=arrangement(rects);refs[a,b]=(covered,segments)
    record=data['regions'][f'{a}:{b}'];assert record['modes']==[a,b]
    kernel=Region(record);union=unary_union([box(float(xs[i]),float(ys[j]),float(xs[i+1]),float(ys[j+1])) for i,j in occupied])
    assert kernel.polygon.symmetric_difference(union).area==0
    assert kernel.polygon.boundary.hausdorff_distance(union.boundary)==0
    region_stats={'modes':[a,b],'queries':len(controls),'boundary_segments_reference':len(segments),'region_area_mm2':float(sum((xs[i+1]-xs[i])*(ys[j+1]-ys[j]) for i,j in occupied)),'interiors':0,'tie_points':0,'reflex_projection_points':0}
    assert region_stats['region_area_mm2']==kernel.polygon.area
    for t in controls:
        value,closest,choices=rational_value(t,covered,segments)
        x=np.array(list(map(float,t)));got,g,detail=kernel.evaluate(x)
        err=abs(got-float(value));max_value_error=max(max_value_error,err);assert err<=plan['value_tolerance_mm2']
        assert (got>0)==bool(value>0)
        actual_intersection=nominal[a].intersection(translate(nominal[b],*x)).area
        assert (actual_intersection>0)==bool(value>0)
        totals['direct_polygon_controls']+=1;totals['queries']+=1
        distance=nominal[a].distance(translate(nominal[b],*x))
        if distance>float(pair_distance_bound)+library['required_pair_gap_mm']:
            assert got==0;totals['source_safe_controls']+=1
        if not value:
            assert np.array_equal(g,np.zeros(2));totals['exterior_or_boundary']+=1;continue
        totals['interior']+=1;region_stats['interiors']+=1
        expected_vectors=[np.array([float(2*(t[k]-q[k])) for k in [0,1]]) for q in closest]
        error=min(float(np.max(np.abs(g-gg))) for gg in expected_vectors);max_gradient_error=max(max_gradient_error,error);assert error<=plan['gradient_tolerance_mm']
        chosen=tuple(F(v) for v in detail['closest']);assert chosen in closest
        # A projection with both residual coordinates nonzero is a reflex-corner
        # nearest feature; convex polygon corners cannot be nearest from inside.
        if all(t[k]!=chosen[k] for k in [0,1]):totals['concave_corner_controls']+=1;region_stats['reflex_projection_points']+=1
        if len(closest)>1:totals['different_closest_ties']+=1;region_stats['tie_points']+=1
        else:
            h=plan['central_step_mm']
            for axis in [0,1]:
                xp=x.copy();xm=x.copy();xp[axis]+=h;xm[axis]-=h
                derivative=(kernel.evaluate(xp)[0]-kernel.evaluate(xm)[0])/(2*h)
                central_error=abs(derivative-g[axis]);max_central_error=max(max_central_error,central_error);assert central_error<plan['central_tolerance']
                totals['central_derivative_coordinates']+=1
        # Directional control works also at medial ties, without asserting a
        # central derivative exists. The selected feature is a valid exit.
        depth=math.sqrt(got);step=min(plan['descent_step_mm'],depth/10)
        moved=kernel.evaluate(x-step*g/np.linalg.norm(g))[0]
        assert moved<got and moved<=(depth-step)**2+plan['value_tolerance_mm2']
        totals['descent_controls']+=1
    results.append(region_stats)
    if (a*10+b)%20==19:print({'regions_checked':a*10+b+1,'queries':totals['queries']},flush=True)

assert totals['different_closest_ties']>0 and totals['concave_corner_controls']>0
write(OUT/'source-controls.json',source_controls);write(OUT/'region-controls.json',results)
write(OUT/'floating-controls.json',{'per_coordinate_bound_mm':float(coordinate_bound),'euclidean_radius_bound_mm':float(radius_bound),'relative_subtraction_coordinate_bound_mm':float(relative_coordinate_bound),'pair_distance_bound_mm':float(pair_distance_bound),'required_pair_gap_mm':library['required_pair_gap_mm'],'gamma8_exact':str(gamma8),'maximum_trig_delta_exact':str(delta),'bound_exact':str(coordinate_bound),'max_observed_hausdorff_mm':max_observed_vertex_error,'controls':float_controls,'argument':'Actual source transform is C plus two vertex products minus two pivot products, each arithmetic route at most8 binary64 operations. The sum of absolute products is bounded by1100mm, absolute center by the maximum hard-domain coordinate. gamma8 bounds rounding of this sum;275*delta bounds trig deviation after exact pivot cancellation. L1 radius2*coordinate_bound bounds Euclidean Hausdorff distance. Rounded center subtraction has per-coordinate error at most2*C*u/(1-u). If nominal shapes intersect at this rounded relative translation, actual source distance cannot exceed twice the source radius plus the L1 relative error, far below required source gap. Thus any source-valid gap-separated bracket pair has auxiliary loss zero.'})

# Preserve all old fields and 528 exact-area terms; validate only summation and
# ownership, without creating an augmented optimization model or changing calls.
aux=Auxiliary(data);objective_controls=[];corruptions=[]
for label,model,values in [
    ('source_initializer',load(W/'model.json'),load(W/'initial-state.json')['values']),
    ('closed_flat_case',load(R/'search/epoch-02/model.json'),load(R/'search/epoch-02/response.json')['unweighted_best']['values'])]:
    frozen=json.dumps(model,sort_keys=True);frozen_x=list(values);assert len(model['pairs'])==528
    old=Objective(model);old_value,old_g,old_detail=old.evaluate(values,True)
    value,g,records=aux.evaluate(model,values);assert len(records)==15
    reference=F(0);reference_g=np.zeros(model['parameters']);relative_errors=[]
    for row in records:
        i,j=row['owners'];a=model['owners'][i]['mode'];b=model['owners'][j]['mode']
        # Relative translation is the producer's binary64 subtraction; also
        # preserve its exact real-coordinate subtraction error separately.
        t=tuple(F(float(values[2*j+k])-float(values[2*i+k])) for k in [0,1])
        exact_t=tuple(F(values[2*j+k])-F(values[2*i+k]) for k in [0,1])
        for k in [0,1]:assert abs(t[k]-exact_t[k])<=relative_coordinate_bound
        relative_errors.append(float(max(abs(t[k]-exact_t[k]) for k in [0,1])))
        v,qs,_=rational_value(t,*refs[a,b]);reference+=v
        assert abs(float(v)-row['depth_squared_mm2'])<=plan['value_tolerance_mm2']
        if v:
            selected=data['regions'][f'{a}:{b}']['segments'][row['selected']]
            exact_q,exact_value=projection(t,tuple(tuple(F(z) for z in p) for p in selected))
            assert exact_q in qs and exact_value==v
            computed_q=tuple(F(z) for z in row['closest'])
            assert max(abs(computed_q[k]-exact_q[k]) for k in [0,1])<=F(plan['gradient_tolerance_mm'])/2
            q=exact_q
            gg=np.array([float(2*(t[k]-q[k])) for k in [0,1]])
            reference_g[2*i:2*i+2]-=gg;reference_g[2*j:2*j+2]+=gg
    assert abs(float(reference)-value)<=plan['value_tolerance_mm2']
    assert np.max(np.abs(reference_g-g))<=plan['gradient_tolerance_mm']
    assert np.all(g[12:]==0) and np.max(np.abs(g[:12].reshape(6,2).sum(axis=0)))<1e-8
    losses=np.array(old_detail['pair_losses_mm2']);weights=np.array(model['pair_weights'])
    assert np.all(losses>=0) and np.all((weights>=1)&(weights<=64)) and value>=0
    for w in [weights,np.ones(528),np.full(528,64.)]:
        baseline=float(w@losses);assert baseline+value>=baseline
    assert json.dumps(model,sort_keys=True)==frozen and list(values)==frozen_x
    objective_controls.append({'case':label,'old_weighted_area_mm2':old_value,'auxiliary_mm2':value,'sum_mm2':old_value+value,'bracket_pairs':15,'all_area_pairs':528,'model_unchanged':True,'values_unchanged':True,'reference_sum_error_mm2':abs(float(reference)-value),'reference_gradient_error_mm':float(np.max(np.abs(reference_g-g))),'maximum_relative_subtraction_error_mm':max(relative_errors)})
    if label=='closed_flat_case':
        i,j=1,2;owners=[model['owners'][k] for k in [i,j]];assert [o['mode'] for o in owners]==[5,9]
        t=np.array(values[2*j:2*j+2])-np.array(values[2*i:2*i+2]);reg=aux.regions['5:9'];depth,grel,info=reg.evaluate(t)
        shapes=old.geometry(values);area=sum(shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]);area_grad=np.zeros(4)
        for own,other,pos in [(i,j,0),(j,i,2)]:
            for k in [0,1]:area_grad[pos:pos+2]+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],values[2*own:2*own+2])[0][:2]
        assert abs(area-11284.5529)<1e-7 and np.max(np.abs(area_grad))<1e-7 and depth>0
        pair_g=np.concatenate([-grel,grel]);probes=[]
        for own,gg in [(i,-grel),(j,grel)]:
            for axis in [0,1]:
                if abs(gg[axis])<1e-12:continue
                delta=-math.copysign(plan['descent_step_mm'],gg[axis]);coordinate=2*own+axis
                if not model['bounds'][coordinate][0]<=values[coordinate]+delta<=model['bounds'][coordinate][1]:continue
                newt=t.copy();newt[axis]+=delta*(1 if own==j else -1);newvalue=reg.evaluate(newt)[0]
                newarea=sum((translate(shapes[k][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[k][j if own==i else i][1]).area) for k in [0,1])
                assert newvalue<depth and abs(newarea-area)<1e-7
                probes.append({'owner':own,'axis':axis,'delta_mm':delta,'depth_squared_mm2':newvalue,'old_area_loss_mm2':newarea})
        assert probes
        # Each owner/sign is checked independently on the one pair, holding
        # the source-center coordinates of the other fixed.
        derivatives=[]
        for k in range(4):
            own=i if k<2 else j;axis=k%2;h=plan['central_step_mm'];tp=t.copy();tm=t.copy();sign=-1 if own==i else 1;tp[axis]+=sign*h;tm[axis]-=sign*h
            numeric=(reg.evaluate(tp)[0]-reg.evaluate(tm)[0])/(2*h)
            assert abs(numeric-pair_g[k])<plan['central_tolerance'];derivatives.append({'owner':own,'axis':axis,'analytic':float(pair_g[k]),'central':numeric})
        write(OUT/'flat-pair-controls.json',{'owners':[i,j],'identities':[o['identity'] for o in owners],'relative_translation_mm':t.tolist(),'old_original_area_mm2':5625.,'old_pair_area_loss_mm2':area,'old_pair_gradient':area_grad.tolist(),'depth_squared_mm2':depth,'depth_mm':math.sqrt(depth),'selected_relative_gradient':grel.tolist(),'selected_feature':info,'owner_derivatives':derivatives,'feasible_descent_probes':probes,'candidate_changed':False,'optimizer_seed':False,'no_full_objective_descent_claim':True})

# Interface rejection controls: mode aliases and center pivots remain bindings.
model=load(W/'model.json');values=load(W/'initial-state.json')['values']
for field,change in [('source_center',[0,0]),('mirrored',not model['owners'][0]['mirrored']),('cell_index',999),('angle_coordinate',66)]:
    bad=copy.deepcopy(model);bad['owners'][0][field]=change
    try:aux.evaluate(bad,values)
    except AssertionError:corruptions.append(field)
    else:raise AssertionError('corruption accepted: '+field)
write(OUT/'objective-controls.json',objective_controls);write(OUT/'negative-controls.json',corruptions)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes':10,'ordered_regions':100,**totals,'max_value_error_mm2':max_value_error,'max_selected_gradient_error_mm':max_gradient_error,'max_central_error':max_central_error,'float_source_pose_controls':len(float_controls),'float_pair_distance_bound_mm':float(pair_distance_bound),'original_area_pairs_preserved':528,'bracket_auxiliary_pairs':15,'objective_validation_cases':2,'corruptions_rejected':len(corruptions),'new_models':0,'optimizer_calls':0,'saved_candidate_changed':False,'H5_complete':False})
print(load(OUT/'checks.json'))
