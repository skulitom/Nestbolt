from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/audit_h5_hard_cell_direct_response_20261107.py').read_text(encoding='utf-8')
s=s.replace('from h5_hard_cell_direct_model_20261107 import compile_model,Objective','from h5_hard_cell_vector_model_20261107 import compile_model,Objective\nfrom h5_hard_cell_direct_model_20261107 import Objective as Reference')
s=s.replace("S=BASE/'search';OUT=BASE/'response-audit'","S=ROOT/'output/h5-joint-cell-search-20261107';OUT=S/'response-audit';JOINT=ROOT/'output/h5-joint-cell-neighbors-20261107'")
s=s.replace('visited=set();trials_total=',"visited={tuple(r['physical_key']) for r in load(BASE/'search/result.json')['rounds']};previously_closed=set(visited);trials_total=")
a=s.index('    if index:\n');b=s.index("    assert model==load(folder/'model.json')",a)
replacement='''    trials=load(folder/'mode-trials.json');assert trials['complete'];records=trials['evaluated'];options={}
    for i,(family,_) in enumerate(lib['identities'][:18]):
        seen={classes[family][modes[i]]};options[i]=[]
        for mi,c in enumerate(classes[family]):
            if c not in seen:options[i].append(mi);seen.add(c)
    expected={((i,mi),) for i,opts in options.items() for mi in opts}
    expected|={((i,mi),(j,mj)) for i in range(6) for mi in options[i] for j in range(6,18) for mj in options[j]}
    assert len(records)==len(expected)==1374 and expected=={tuple(map(tuple,r['changes'])) for r in records}
    assert records==sorted(records,key=lambda r:(round(r['score_mm2'],6),tuple(map(tuple,r['changes']))))
    keys=set();errors=[]
    for row in records:
        chosen=modes.copy();point=np.asarray(incoming).copy()
        for (i,mi),center in zip(row['changes'],row['centers']):
            chosen[i]=mi;bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm'];expected_center=[min(hi,max(lo,float(incoming[2*i+k]))) for k,(lo,hi) in enumerate(bb)];assert center==expected_center;point[2*i:2*i+2]=center
        key=physical_key(lib,classes,chosen);assert list(key)==row['physical_key'] and key not in keys;keys.add(key)
        mm=compile_model(lib,chosen,incoming);assert verify(mm,lib,chosen,incoming) and mm['initial']==point.tolist()
        actual=Reference(mm).score(point);error=abs(actual-row['score_mm2']);assert error<1e-6,(index,actual,row['score_mm2']);errors.append(error)
    skipped=[r['physical_key'] for r in records if tuple(r['physical_key']) in visited]
    assert skipped==trials['skipped_closed_physical_vectors'];selected=next(r for r in records if tuple(r['physical_key']) not in visited);assert selected==load(folder/'selected-mode.json')
    for i,mi in selected['changes']:modes[i]=mi
    model=compile_model(lib,modes,incoming);trials_total+=len(records)
    selection_checks.append({'round':index,'evaluated':len(records),'single_owner_neighbors':78,'bracket_insert_joint_neighbors':1296,'skipped_closed':len(skipped),'selected_changes':selected['changes'],'change_from_base_mm2':selected['score_mm2']-basevalue,'maximum_full_score_difference_mm2':max(errors),'physical_vector_unvisited':True})
    inputs+=[folder/'mode-trials.json',folder/'selected-mode.json']
'''
s=s[:a]+replacement+s[b:]
a=s.index("charges=load(S/'preparation-charges.json');");b=s.index('\nqueue=inputs.copy()',a)
s=s[:a]+"charges=load(S/'preparation-charges.json');assert sum(charges.values())==plan['preparation_seconds_charged']==load(JOINT/'audit/checks.json')['complete_preparation_seconds'];assert charges['complete_source_and_initializer_preparation']==load(BASE/'audit/checks.json')['complete_preparation_seconds'] and charges['complete_joint_neighbor_preparation']==load(ROOT/'output/h5-joint-cell-neighbors-preparation-process-20261107/process.json')['complete_seconds']"+s[b:]
s=s.replace("'unique_physical_vectors':len(visited)","'unique_physical_vectors':len(visited-previously_closed),'prior_closed_vectors_excluded':len(previously_closed)")
s=s.replace("'method':'Replay everydistinctphysicalmode", "'method':'Independently enumerate all 78 single-owner and 1296 joint bracket/insert proposals at every round; replay full scores without delta scoring, verify exact expected centers and physical keys, deterministic ranking and prior-closed-vector exclusions. Replay everydistinctphysicalmode")
compile(s,'audit_h5_joint_cell_response_20261107.py','exec')
with (ROOT/'output/audit_h5_joint_cell_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_hard_cell_model_audit_20261107.py').read_text(encoding='utf-8').replace('h5-hard-cell-model-audit-process-20261107','h5-joint-cell-response-audit-process-20261107').replace("('audit','audit_h5_hard_cell_direct_model_20261107.py',90)","('audit','audit_h5_joint_cell_response_20261107.py',180)")
with (ROOT/'output/run_h5_joint_cell_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
