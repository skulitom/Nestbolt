"""Single-owner and bracket/insert joint compound neighbors, exact pair deltas."""
import numpy as np
import shapely
from h5_hard_cell_direct_model_20261107 import compile_model,Objective
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_mixed_direct_pose_20261107 import owner_shapes


def interaction(left,right):
    return sum(a.intersection(b).area for a,b in zip(left,right))


def rank(record):
    # A declared micrometre-squared score tie, not a geometry tolerance.
    return (round(record['score_mm2'],6),tuple(tuple(v) for v in record['changes']))


def neighbors(library,modes,values):
    model=compile_model(library,modes,values);values=np.asarray(model['initial'])
    classes=family_classes(library);entries=Objective(model).geometry(values,False)
    shapes=[[level[i][1] for level in entries] for i in range(33)]
    baseline=np.zeros((33,33))
    for i,j in model['pairs']:baseline[i,j]=baseline[j,i]=interaction(shapes[i],shapes[j])
    energy=float(np.sum(np.triu(baseline,1)));options=[]
    for i,(family,_) in enumerate(library['identities'][:18]):
        seen={classes[family][modes[i]]}
        for option in library['family_modes'][family]:
            mi=option['mode'];cls=classes[family][mi]
            if cls in seen:continue
            seen.add(cls);bounds=np.asarray(option['center_bounds_mm']);center=np.clip(values[2*i:2*i+2],bounds[:,0],bounds[:,1])
            shape=owner_shapes(library,family,mi,center);interactions=np.zeros(33)
            for kind in range(2):
                others=np.asarray([s[kind] for s in shapes],dtype=object)
                interactions += shapely.area(shapely.intersection(shape[kind],others))
            interactions[i]=0.
            options.append({'owner':i,'mode':mi,'family':family,'center':center.tolist(),'shape':shape,'interactions':interactions,'delta':float(np.sum(interactions-baseline[i]))})
    records=[]
    def row(selected,score):
        changed=modes.copy();centers=[]
        for option in selected:
            changed[option['owner']]=option['mode'];centers.append(option['center'])
        return {'changes':[[o['owner'],o['mode']] for o in selected],'centers':centers,'physical_key':list(physical_key(library,classes,changed)),'score_mm2':float(score)}
    for option in options:records.append(row([option],energy+option['delta']))
    for a in [o for o in options if o['family']=='bracket']:
        for b in [o for o in options if o['family']=='insert']:
            i,j=a['owner'],b['owner']
            correction=interaction(a['shape'],b['shape'])-a['interactions'][j]-b['interactions'][i]+baseline[i,j]
            records.append(row([a,b],energy+a['delta']+b['delta']+correction))
    assert len(records)==1374 and len({tuple(r['physical_key']) for r in records})==len(records)
    return energy,sorted(records,key=rank)


def apply_neighbor(library,modes,values,record):
    changed=modes.copy();point=np.asarray(values).copy()
    for (i,mi),center in zip(record['changes'],record['centers']):
        changed[i]=mi;point[2*i:2*i+2]=center
    model=compile_model(library,changed,point)
    return changed,model,np.asarray(model['initial'])
