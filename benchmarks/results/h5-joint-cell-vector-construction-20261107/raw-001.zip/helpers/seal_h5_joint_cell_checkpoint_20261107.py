"""Archive expanded-neighbor search, numerical controls and complete accounting."""
from pathlib import Path
import json,shutil,collections
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-joint-cell-vector-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-joint-cell-search-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-joint-cell-neighbors-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-hard-cell-continuous-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==30 and front['best_global_round']==0 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D]+[ROOT/'output'/n for n in ['h5-vector-boundary-audit-20261107','h5-vector-boundary-audit-process-20261107','h5-joint-cell-neighbors-preparation-process-20261107','h5-joint-cell-neighbors-audit-process-20261107','h5-joint-cell-response-audit-process-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*joint*cell*20261107.py','*h5*vector*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_joint_cell_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
copies=[(D/'audit/checks.json','neighbor-audit.json'),(D/'checks.json','neighbor-preparation.json'),(ROOT/'output/h5-vector-boundary-audit-20261107/checks.json','vector-gradient-audit.json'),(ROOT/'output/h5-vector-boundary-audit-20261107/timings.json','vector-gradient-timings.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/'round-00-collision-details.json','source-failures.json'),(BASE/'process.json','closed-search-process.json'),(ROOT/'output/h5-joint-cell-main-ci-at-review-20261107.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
response=load(BASE/'round-00/response.json');model=load(BASE/'round-00/model.json');source=load(BASE/'round-00/original-source-checks.json');x=response['best_values'];g=response['best_gradient'];projected=[0 if (x[k]==lo and g[k]>0) or (x[k]==hi and g[k]<0) else g[k] for k,(lo,hi) in enumerate(model['bounds'])];groups=collections.defaultdict(lambda:{'pairs':0,'original_overlap_mm2':0.})
for row in source['pairs']:
    if not row['passed']:
        key='/'.join(sorted(k[0] for k in row['keys']));groups[key]['pairs']+=1;groups[key]['original_overlap_mm2']+=row['intersection_area_mm2']
assert sum(r['pairs'] for r in groups.values())==front['source_pair_failures'] and abs(sum(r['original_overlap_mm2'] for r in groups.values())-front['total_original_overlap_mm2'])<1e-7
write(OUT/'candidate-diagnostic.json',{'best_round':0,'active_bound_coordinates':sum(v==lo or v==hi for v,(lo,hi) in zip(x,model['bounds'])),'maximum_absolute_projected_gradient':max(map(abs,projected)),'pair_groups':dict(groups),'stationarity_or_impossibility_claim':False,'source_optimizer_calls':0})
write(OUT/'next-step.json',{'status':'source_geometry_investigation_required','proposal':'Reconcile historical bracket/cog contact work, then assess original-outline contact candidates for simultaneous translations. The current compound transitions only clamp changed centers to their nearest new bounds.','reason':'Eight bracket/cog pairs contribute 14107.916224 square mm of the best candidate overlap; all 1296 joint changes lose to a single-owner move at each selected round. Faster exact scoring alone did not resolve the layout.','requirements':['No new call until historical scopes are checked and a materially changed source construction is frozen.','Derive and independently check contact geometry and admissible domains from original outlines and the unchanged clearance.','Charge every consumed preparation and preserve all current calls as closed.','Do not use old optimized positions with a reset clock or claim this local failure excludes an allocation.'],'new_source_geometry_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Joint-cell choices and vectorized gradients — 2026-11-07

The expanded search closes after three new physical configurations and **4,122
proposal scores**. Its best candidate, from call 0, still fails **30 source pairs**,
with **18,450.266096 mm²** original overlap. Both later candidates are worse.
All fixed-part clearances and stock checks pass. H2/H5 remain open at **60%
completed milestone weight**; no source-valid full66 layout, native call,
allocation exclusion or qualifying release follows.

## Measured numerical improvement

The new boundary integral retains every clipped line's parent edge, reduces
its endpoint parameters in arrays, and integrates the same translation and
rotation velocities. Nested collections and isolated points are handled
explicitly. Shared boundaries retain the existing half-weight convention;
this does not turn nonsmooth contacts into classical derivatives.

[Correctness controls]({NAME}/vector-gradient-audit.json) cover fourteen
synthetic pairs, a nested collection with intermediate collinear vertices,
406 positive original/clearance boundary terms, four complete objectives and
81 central finite differences. Maximum gradient difference from the two scalar
references is **1.36425e-11**; maximum central-difference error is **6.67284e-7**.
All checks pass. [Ten alternating-order timings per fixed case]({NAME}/vector-gradient-timings.json)
show **1.7243–2.0405×** median whole-objective speedups. These are research-kernel
measurements on four validation cases, not a production performance or packing
claim. Historical optimized points are used only for these controls.

## Expanded compound proposals

At a source-only initial point, the new selector enumerates 78 unique single-owner
changes and **1,296 bracket/insert two-owner changes**. Each changed center is
clamped to its target hard cell; all other positions remain fixed for scoring.
The full pair objective is evaluated by cached single-owner deltas plus the
exact correction for the pair changed twice. Scores are ranked after rounding
to 0.000001 mm², then by owner and mode; this is a declared tie rule.

[Independent preparation replay]({NAME}/neighbor-audit.json) reconstructs the
original and clearance polygons and fully sums all 1,056 terms for every one
of **1,375 full scores**. It uses no delta correction. Maximum score difference
is **4.36558e-10 mm²**; all centers, expected vectors, keys and choices match.
The initial best single score is 78,177.927349 mm² and best joint score is
85,800.290452 mm², versus the 79,154.624600 mm² baseline. Joint proposals do not
provide an initial improvement. The complete new preparation process takes
0.411814 s, bringing consumed source-only preparation to **9.533010 s**.

## Frozen search and replay

The new pipeline selects the best unvisited proposal before every call and
retains the global best separately. It excludes all three physical vectors
from the closed predecessor and each newly called vector. It never consumes
an optimized ancestor point. There are at most three calls, each with a
14-second slice; all 33 centers and fifteen cog angles remain continuous.
Hard domains, source outlines, clearance, objective weights and full66 checks
are unchanged. Every call stops on time without a numerical return.

| Call | Selected move | Failed pairs | Original overlap (mm²) |
|---|---|---:|---:|
| 0 | bracket owner 4 → mode 3 | 30 | 18,450.266096 |
| 1 | bracket owner 2 → mode 9 | 30 | 19,402.083123 |
| 2 | insert owner 17 → mode 2 | 31 | 20,350.616355 |

All selected moves affect one owner. The 1,296 joint alternatives at each round
score worse than its selected single-owner change. Their evaluation is retained;
no actual joint move or packing gain is claimed from adding them.

[Independent response replay]({NAME}/response-audit.json) reconstructs all
4,122 expected proposal vectors, full scores, clamps and selected models. It
verifies **539 retained points and 585 evaluation counters**, all three prior
closed-vector exclusions, complete original source transforms and every
response. Each response checks all 66 originals, 1,380 same-sheet pairs,
264 stock edges, 90 holes and 10,026 hole vertices. [All source failures]({NAME}/source-failures.json)
and both worse candidates remain preserved.

Algorithm/shared totals including preparation are **53.378490/53.439519 s**,
within the unchanged 60/90-second limits. Slice overruns of 0.060660, 0.003205
and 0.053420 s remain recorded. Peak aggregate committed memory is 97,775,616
bytes; [all five search processes close]({NAME}/closed-search-process.json).
These three calls and their predecessor remain closed despite unused time.

[A diagnostic of the retained candidate]({NAME}/candidate-diagnostic.json)
attributes 14,107.916224 mm² to eight bracket/cog pairs, 4,011.017783 mm² to
twenty cog/cog pairs, and 331.332090 mm² to two cog/insert pairs. Twenty-five
coordinates lie on hard bounds. The projected gradient remains nonzero;
neither numerical stationarity nor geometric impossibility is claimed.

[The next investigation]({NAME}/next-step.json) first reconciles historical
bracket/cog contact work, then assesses original-outline contact candidates
for simultaneous translations beyond nearest-bound clamping. No new contact
geometry, complete model or optimizer call is prepared. Consumed work remains
chargeable and optimized candidates cannot reset their clocks.

Four fixed arrangements and 440 whole allocations remain unresolved. Full66
source/native/material checks, production parity and the unchanged H5 matrix
are still required. [Main c3af6112 has five passed jobs and a running Windows
native job at review]({NAME}/main-ci-at-review.json); checkpoint be75186f and
this checkpoint await the ordinary push gate. Production, README, releases
and reserved H2 vectors remain unchanged.

[Raw manifest]({NAME}/raw-manifest.json) and [source bindings]({NAME}/source-bindings.json)
preserve both new evidence and exact prior archive references.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 vectorized gradients and joint cell choices:** [independent numerical/model/response audits]({link}) verify 406 boundary terms, 81 central derivatives and 1,375 independently summed initial neighbor scores. Ten alternating timings on each of four fixed validation cases show 1.7243–2.0405× median research-kernel speedups. The expanded search checks 78 single-owner and 1,296 joint bracket/insert neighbors per round while excluding all three prior closed physical vectors. Three new calls and 4,122 scores close at the declared limit; 539 retained points and 585 evaluation counters replay. All selected changes affect one owner; joint alternatives score worse. Call 0 remains best with 30 failing pairs and 18,450.266096 mm² overlap, including 14,107.916224 mm² in eight bracket/cog pairs; fixed-part and stock checks all pass. Complete preparation is 9.533010 s and algorithm/shared totals are 53.378490/53.439519 s. All slice overruns and worse candidates are preserved; every process closes. No source-valid full66 layout, native call or exclusion follows. Next reconcile historical bracket/cog contacts before assessing source-outline contact translations beyond nearest-bound clamping; no successor geometry or call is prepared. Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Main c3af6112 has five passed jobs and a live Windows native job. Checkpoint be75186f and this checkpoint await the ordinary push gate. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [vectorized gradients and joint cell choices](../benchmarks/results/{NAME}.md).
Exact boundary integration is 1.7243–2.0405× faster on four fixed research controls,
with all numerical checks passing. The expanded single/joint neighborhood checks
4,122 proposals and closes after three new physical configurations. Joint choices
lose to single-owner changes in every round. Call 0 remains best with 30 failing
source pairs and 18,450.266096 mm² overlap; fixed-part and stock checks pass.
Independent replay verifies 539 retained points and 585 evaluation counters.
Preparation-inclusive algorithm/shared totals are 53.378490/53.439519 s.
Every process is closed. Next reconcile historical bracket/cog contacts before
assessing original-outline contact translations beyond nearest-bound clamping.
No successor geometry or call is prepared. Four fixed arrangements and 440
allocations remain; H2/H5 stay open at 60% completed milestone weight.
Main c3af6112 has five passed jobs and a running Windows native check; be75186f
and this checkpoint await the ordinary push gate. Full66 source/native/material
checks, production parity and the unchanged H5 matrix remain required.
No release qualifies.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
