"""Freeze a genuinely expanded two-owner neighborhood, excluding closed vectors."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'output/run_h5_hard_cell_direct_search_20261107.py';s=p.read_text(encoding='utf-8')
s=s.replace('OUT=BASE/\'search\'','OUT=ROOT/\'output/h5-joint-cell-search-20261107\';JOINT=ROOT/\'output/h5-joint-cell-neighbors-20261107\'')
s=s.replace('from h5_hard_cell_direct_model_20261107 import compile_model,Objective,source_rows','from h5_hard_cell_vector_model_20261107 import compile_model,Objective,source_rows\n    from h5_joint_cell_neighbors_20261107 import neighbors,apply_neighbor')
old="visited=set();summaries=[]"
new="visited={tuple(r['physical_key']) for r in load(BASE/'search/result.json')['rounds']};summaries=[]"
assert old in s;s=s.replace(old,new)
a=s.index('        if round_index:\n');b=s.index('        assert verify(mm,lib,modes,incoming);key=',a)
replacement='''        if round_index==0:
            evaluated=load(JOINT/'neighbors.json');neighbor_base=load(JOINT/'checks.json')['baseline_objective_mm2']
        else:neighbor_base,evaluated=neighbors(lib,modes,incoming)
        assert abs(neighbor_base-basevalue)<1e-6
        trialcount+=len(evaluated)
        available=[r for r in evaluated if tuple(r['physical_key']) not in visited]
        write(folder/'mode-trials.json',{'complete':True,'evaluated':evaluated,'skipped_closed_physical_vectors':[r['physical_key'] for r in evaluated if tuple(r['physical_key']) in visited],'selection_policy':'lowest rounded full score over all 78 single and 1296 bracket/insert joint neighbors, excluding every prior and current closed physical vector'})
        if not available:stop='NO_UNVISITED_PHYSICAL_NEIGHBOR';break
        if time.perf_counter()-started>=56:stop='ALGORITHM_TIME_STOP_AFTER_NEIGHBORS';break
        selection=available[0];modes,mm,changed_values=apply_neighbor(lib,modes,incoming,selection)
        assert verify(mm,lib,modes,incoming)
        assert np.array_equal(changed_values,np.asarray(mm['initial']))
        write(folder/'selected-mode.json',selection)
'''
s=s[:a]+replacement+s[b:]
s=s.replace("'optimizer_slice_seconds':[16,12,12]","'optimizer_slice_seconds':[14,14,14]")
start=s.index("charges={'complete_source_geometry_preparation':")
end=s.index(';started=time.perf_counter()-charge',start)
s=s[:start]+"charges={'complete_source_and_initializer_preparation':load(BASE/'audit/checks.json')['complete_preparation_seconds'],'complete_joint_neighbor_preparation':load(ROOT/'output/h5-joint-cell-neighbors-preparation-process-20261107/process.json')['complete_seconds']};charge=sum(charges.values());assert charge==load(JOINT/'audit/checks.json')['complete_preparation_seconds']"+s[end:]
old="write(OUT/'plan.json',{'utc':"
new="files += [ROOT/'output'/n for n in ['h5_vector_boundary_gradient_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_joint_cell_neighbors_20261107.py','h5-vector-boundary-audit-20261107/checks.json','h5-joint-cell-neighbors-preparation-process-20261107/process.json']]+[JOINT/n for n in ['plan.json','neighbors.json','checks.json','audit/checks.json']]+[BASE/'search/result.json'];assert load(ROOT/'output/h5-vector-boundary-audit-20261107/checks.json')['passed'] and load(ROOT/'output/h5-vector-boundary-audit-20261107/checks.json')['all_fixed_cases_faster'] and load(JOINT/'audit/checks.json')['passed'];write(OUT/'plan.json',{'utc':"
assert old in s;s=s.replace(old,new)
a=s.index("'method':'One finite new33-mover/");b=s.index("'});controls=load(EXE.parent",a)
method="One finite expanded compound-neighborhood search with independently checked vectorized boundary integration. At every round choose among all 78 single-owner and 1296 bracket/insert two-owner neighbors by score rounded to 1e-6 square mm then owner/mode. Round zero consumes the prepared source-only neighbor table; later rounds recompute at the best retained candidate. Clamp only changed owners to their new certified hard cells. Exclude all three physical vectors optimized by the closed hard-cell predecessor and every current called vector. No optimized ancestor point is consumed. Three distinct new vectors at most, 14 seconds each, no restart or extension. Proposals need not improve initially; retain the global best separately. Complete preparation 9.533010 seconds is charged, including failed source work. All 33 centers and 15 angles remain continuous; original and clearance objectives retain equal weights. Compile and independently read back each selected model. Reconstruct all 66 originals after every call, regardless of penalty. Stop at validity, three calls, no unvisited neighbor, time, or inconsistency. Local failure and time stops exclude no allocation. Historical search outputs used for performance validation or closed-vector exclusion cannot reset their clocks or initialize a new search."
s=s[:a]+"'method':"+repr(method)+s[b+1:]
assert "'optimizer_slice_seconds':[14,14,14]" in s
compile(s,'run_h5_joint_cell_search_20261107.py','exec')
with (ROOT/'output/run_h5_joint_cell_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'frozen':True,'maximum_new_calls':3,'slices':[14,14,14],'neighbors_per_round':1374,'source_only_preparation_seconds':9.533009699778631})
