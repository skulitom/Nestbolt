"""Vectorized exact clipped-edge integral; the same shared-edge convention.

Every clipped LineString is a subset of a straight original edge. Reducing its
minimum/maximum affine edge parameter gives the same segment integral as the
scalar reference, including intermediate collinear coordinates. Collection
leaves retain their original edge index. Points contribute zero.
"""
import numpy as np
import shapely


def clipped_integral(vertices, geometries, pivot):
    geometries=np.asarray(geometries,dtype=object)
    origins=np.arange(len(geometries))
    while True:
        keep=~shapely.is_empty(geometries)
        geometries=geometries[keep];origins=origins[keep]
        if not len(geometries):return np.zeros(3),0
        if not np.any(shapely.get_type_id(geometries)>=4):break
        geometries,parents=shapely.get_parts(geometries,return_index=True)
        origins=origins[parents]
    keep=shapely.get_type_id(geometries)==1
    geometries=geometries[keep];origins=origins[keep]
    if not len(geometries):return np.zeros(3),0
    coordinates,segments=shapely.get_coordinates(geometries,return_index=True)
    p=vertices[origins]
    edges=vertices[(origins+1)%len(vertices)]-p
    denominators=np.sum(edges*edges,axis=1)
    good=denominators>0
    # Degenerate original edges have zero length and no integral.
    denominator=np.where(good,denominators,1.)
    values=np.sum((coordinates-p[segments])*edges[segments],axis=1)/denominator[segments]
    lo=np.full(len(geometries),np.inf);hi=np.full(len(geometries),-np.inf)
    np.minimum.at(lo,segments,values);np.maximum.at(hi,segments,values)
    lo=np.maximum(0.,lo);hi=np.minimum(1.,hi)
    keep=good&(hi>lo)
    p=p[keep];edges=edges[keep];lo=lo[keep];hi=hi[keep]
    delta=(hi-lo)[:,None]*edges
    normal=np.column_stack((delta[:,1],-delta[:,0]))
    relative=p+((hi+lo)/2)[:,None]*edges-np.asarray(pivot)
    torque=np.sum(-relative[:,1]*normal[:,0]+relative[:,0]*normal[:,1])
    translation=np.sum(normal,axis=0)
    return np.array([translation[0],translation[1],torque]),int(np.sum(keep))


def boundary_gradient(vertices,lines,other,pivot):
    vertices=np.asarray(vertices)
    clipped=shapely.intersection(lines,other)
    shared=shapely.intersection(lines,other.boundary)
    full,count=clipped_integral(vertices,clipped,pivot)
    coincident,_=clipped_integral(vertices,shared,pivot)
    return full-.5*coincident,count,float(np.sum(shapely.length(shared)))
