"""Fixed correctness and timing controls, no optimizer and no candidate selection."""
from pathlib import Path
from hashlib import sha256
import json,time,math,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,LineString,Point,GeometryCollection,MultiLineString
from shapely.affinity import translate,rotate
from shapely.geometry.polygon import orient
from h5_vector_boundary_gradient_20261107 import boundary_gradient,clipped_integral
from h5_direct_pose_model_20261107 import boundary_gradient as reference
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_hard_cell_direct_model_20261107 import Objective as Old,compile_model
from h5_hard_cell_vector_model_20261107 import Objective as New
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-vector-boundary-audit-20261107';BASE=ROOT/'output/h5-hard-cell-direct-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs=[Path(__file__),BASE/'library.json',BASE/'model.json',BASE/'response-audit/checks.json']+[ROOT/'output'/n for n in ['h5_vector_boundary_gradient_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_direct_pose_model_20261107.py','h5_original_overlap_gradient_v2_20261107.py','h5_hard_cell_direct_model_20261107.py']]
for i in range(3):inputs += [BASE/f'search/round-{i:02d}'/n for n in ['model.json','response.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'correctness':'Synthetic smooth, disjoint, contained, shared, disconnected and collection controls; all positive boundary terms on seed and three historical outputs; 81 central differences on a deterministic interior seed perturbation.','performance':'Ten alternating-order whole-objective evaluations per implementation on each of four fixed historical cases. Cases are validation only and cannot initialize a new optimization.','wall_cap_seconds':90,'source_optimizer_calls':0,'retry_permitted':False})
def entry(poly):
    poly=orient(poly,1);v=np.asarray(poly.exterior.coords)[:-1]
    return v,shapely.linestrings(np.stack([v,np.roll(v,-1,axis=0)],axis=1)),poly
def compare(a,b,pivot,label):
    v,lines,a=entry(a);g,n,s=boundary_gradient(v,lines,b,pivot);h,m,t=reference(v,lines,b,pivot);oracle,on,os=moving_boundary_gradient(a,b,pivot)
    assert n==m==on and abs(s-t)<1e-8 and abs(s-os)<1e-8
    error=max(float(np.max(abs(g-h))),float(np.max(abs(g-oracle))))
    assert np.allclose(g,h,rtol=1e-10,atol=1e-7) and np.allclose(g,oracle,rtol=1e-10,atol=1e-7),(label,g,h,oracle)
    return {'case':label,'gradient':g.tolist(),'segments':n,'shared_length_mm':s,'max_absolute_difference':error}
square=Polygon([(0,0),(4,0),(4,4),(0,4)])
concave=Polygon([(0,0),(6,0),(6,6),(4,6),(4,2),(2,2),(2,6),(0,6)])
pairs=[('disjoint',square,translate(square,10,0)),('contained',square,translate(square.buffer(2,join_style=2),.3,.2)),('shared-identical',square,square),('touching-edge',square,translate(square,4,0)),('shared-partial',square,translate(square,2,0)),('smooth',square,rotate(translate(square,2.1,1.3),17)),('disconnected',Polygon([(-1,3),(7,3),(7,5),(-1,5)]),concave)]
synthetic=[]
for label,a,b in pairs:
    for reverse in [False,True]:
        if reverse:a,b=b,a
        synthetic.append(compare(a,b,[1.31,-.77],label+('-reverse' if reverse else '')))
# A nested collection with a multi-coordinate straight segment: its integral is
# translation=(0,-2), rotation=-3 about the origin. Isolated points vanish.
v=np.array([[0.,0.],[4.,0.],[4.,4.],[0.,4.]])
collection=GeometryCollection([Point(0,0),GeometryCollection([MultiLineString([[(.5,0),(1,0),(2.5,0)]])])])
g,n=clipped_integral(v,np.array([collection,Point(4,0),LineString(),GeometryCollection()],dtype=object),[0,0])
assert n==1 and np.allclose(g,[0,-2,-3],atol=1e-12)
write(OUT/'synthetic-controls.json',synthetic)
cases=[('seed',load(BASE/'model.json'),None)]
for i in range(3):cases.append((f'round-{i:02d}',load(BASE/f'search/round-{i:02d}/model.json'),load(BASE/f'search/round-{i:02d}/response.json')['best_values']))
comparisons=[];boundaries=[]
for label,model,point in cases:
    point=np.asarray(model['initial'] if point is None else point)
    a,ag,ad=Old(model).evaluate(point,True);b,bg,bd=New(model).evaluate(point,True)
    assert a==b and np.allclose(ag,bg,rtol=1e-10,atol=1e-7) and ad==bd,(label,a,b,ad,bd)
    comparisons.append({'case':label,'objective':a,'parameters':len(ag),'max_gradient_difference':float(np.max(abs(ag-bg)))})
    for kind,entries in zip(['original','clearance'],Old(model).geometry(point)):
        for i,j in model['pairs']:
            if entries[i][1].intersection(entries[j][1]).area<=0:continue
            for own,other in [(i,j),(j,i)]:boundaries.append(compare(entries[own][1],entries[other][1],entries[own][3],f'{label}/{kind}/{own}/{other}'))
write(OUT/'model-controls.json',comparisons);write(OUT/'boundary-controls.json',boundaries)
model=cases[0][1];bounds=np.asarray(model['bounds']);margin=.03+np.arange(81)*.00037
point=np.clip(np.asarray(model['initial'])+.137*np.sin(np.arange(81)*2**.5+.2),bounds[:,0]+margin,bounds[:,1]-margin)
value,gradient=New(model).evaluate(point);errors=[]
for k in range(81):
    plus=point.copy();minus=point.copy();plus[k]+=1e-4;minus[k]-=1e-4
    numeric=(Old(model).score(plus)-Old(model).score(minus))/2e-4
    error=abs(numeric-gradient[k]);assert error<.02+3e-6*abs(gradient[k]),(k,numeric,gradient[k],error)
    errors.append({'coordinate':k,'analytic':float(gradient[k]),'central':numeric,'absolute_difference':error})
write(OUT/'derivative-controls.json',errors)
timings=[]
for label,model,point in cases:
    point=np.asarray(model['initial'] if point is None else point);old=Old(model);new=New(model);records={'reference':[],'vectorized':[]}
    for repeat in range(10):
        order=[('reference',old),('vectorized',new)]
        if repeat%2:order.reverse()
        for name,objective in order:
            before=time.perf_counter();objective.evaluate(point);records[name].append(time.perf_counter()-before)
    medians={name:float(np.median(values)) for name,values in records.items()}
    timings.append({'case':label,'seconds':records,'median_seconds':medians,'speedup':medians['reference']/medians['vectorized']})
write(OUT/'timings.json',timings)
checks={'passed':True,'seconds':time.perf_counter()-start,'synthetic_controls':len(synthetic),'nested_collection_control':True,'boundary_controls':len(boundaries),'whole_objective_controls':len(comparisons),'central_coordinates':len(errors),'maximum_gradient_difference':max(r['max_absolute_difference'] for r in boundaries),'maximum_central_difference':max(r['absolute_difference'] for r in errors),'timing_repeats_per_case_per_implementation':10,'fixed_case_speedups':{r['case']:r['speedup'] for r in timings},'all_fixed_cases_faster':all(r['speedup']>1 for r in timings),'production_modified':False,'new_optimizer_calls':0,'closed_searches_reused_only_for_validation':True,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
