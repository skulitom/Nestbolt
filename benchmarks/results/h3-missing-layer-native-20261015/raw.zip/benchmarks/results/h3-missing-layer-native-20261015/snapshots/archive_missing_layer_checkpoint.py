from pathlib import Path
from hashlib import sha256
import json
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from h3_reviewed_prerequisites import guards

out = ROOT/'benchmarks/results/h3-missing-layer-native-20261015'
audit = ROOT/'benchmarks/results/h3-reviewed-prerequisites-20261015T204219Z'
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p, value):
    p.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')

results = json.loads((audit/'results.json').read_bytes())
assert results['all_checked'] and results['guards'] == guards()
labels = json.loads((audit/'labels.json').read_bytes())
assert labels['summary']['original']['passed'] == 45
assert labels['summary']['native-repair']['membership_matches'] == 8
assert labels['summary']['native-repair']['physical_cut_holes_match'] == 8
assert labels['summary']['native-repair']['cut_layers_match'] == 7
checks = {'reader_writer_audit': audit.relative_to(ROOT).as_posix(),
          'source_guards_passed': True, 'noop_reads': len(results['rows']),
          'canonical_sheet_checks': sum(len(r.get('canonical_checks', [])) for r in results['rows']),
          'units': sum(r.get('writer_units', 0) for r in results['rows']),
          'labels': labels['summary'], 'held_out_geometry_read': False}
for name in ['workspace-tests', 'release-cli-tests']:
    contents = (out/(name+'.log')).read_text(encoding='utf-8')
    rows = [tuple(map(int, m)) for m in re.findall(r'test result: ok. (\d+) passed; (\d+) failed; (\d+) ignored;', contents)]
    checks[name] = dict(zip(['passed', 'failed', 'ignored'], [sum(r[i] for r in rows) for i in range(3)]))
assert checks['workspace-tests'] == {'passed':295,'failed':0,'ignored':1}
assert checks['release-cli-tests'] == {'passed':26,'failed':0,'ignored':0}
assert '84 passed' in (out/'browser-checks.log').read_text(encoding='utf-8')
assert '4 skipped' in (out/'browser-checks.log').read_text(encoding='utf-8')
assert 'Finished' in (out/'clippy.log').read_text(encoding='utf-8')
checks.update(browser_tests={'passed':84,'skipped':4}, strict_clippy=True, formatting=True)
manifest = json.loads((ROOT/'benchmarks/datasets/shop/manifest.json').read_bytes())
assert all(digest(ROOT/'benchmarks/datasets/shop'/r['path']) == r['sha256'] for r in manifest['corpus_inventory'])
checks['frozen_inventory_files'] = len(manifest['corpus_inventory'])
checks['cli_sha256'] = digest(ROOT/'target/release/nestbolt.exe')
checks['wasm_sha256'] = digest(ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm')
checks['L36_search'] = json.loads((out/'L36-search/checks.json').read_bytes())
write(out/'checks.json', checks)
snapshots = out/'snapshots'
snapshots.mkdir(exist_ok=False)
for path in ['scripts/h2_lightburn_labels.py','scripts/h3_reviewed_prerequisites.py',
             'scripts/h3_writer_audit.py','scripts/h3_geometry_audit.py',
             'scripts/shop_reference_labels.py', 'output/archive_missing_layer_checkpoint.py']:
    shutil.copyfile(ROOT/path, snapshots/Path(path).name)
(snapshots/'product.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/'],cwd=ROOT))
keep_probe = {'plan.json','native-checks.json','previous-comparison.json','checks.json'}
keep_audit = {'plan.json','progress.json','results.json','labels.json'}
raw = [p for p in out.rglob('*') if p.is_file() and not
       (p.parent == out and (p.name in keep_probe or p.suffix == '.png'))]
raw += [p for p in audit.rglob('*') if p.is_file() and not (p.parent == audit and p.name in keep_audit)]
archive = out/'raw.zip'
assert not archive.exists()
records = {p.relative_to(ROOT).as_posix(): {'sha256':digest(p),'size':p.stat().st_size} for p in sorted(raw)}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in raw:
        z.write(path,path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(records)
    for name, record in records.items():
        value=z.read(name)
        assert len(value)==record['size'] and sha256(value).hexdigest()==record['sha256']
write(out/'integrity.json', {'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,
    'crc_passed':True,'members':records})
for path in raw:
    # Exact owned files only, after CRC and SHA verification; no recursive move/delete.
    resolved=path.resolve()
    assert resolved.is_relative_to(out.resolve()) or resolved.is_relative_to(audit.resolve())
    path.unlink()
print(json.dumps({'members':len(records),'bytes':archive.stat().st_size,'sha256':digest(archive),'checks':checks}))
