"""Version the broader source model and its independent controls before use."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'output'
def put(name,text):
    ast.parse(text)
    with (D/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
def change(text):return text.replace('h5_cog_union_distance','h5_cog_physical_union_distance').replace('h5-cog-union-distance','h5-cog-physical-union-distance')
text=change((D/'prepare_h5_cog_union_distance_20261107.py').read_text(encoding='utf-8'))
text=text.replace("inputs=[Path(__file__)","inputs=[ROOT/'output/h5_cog_union_distance_20261107.py']+[ROOT/'output/h5-independent-twelve-cog-integer-20261107'/n for n in ['audit/plan.json','audit/checks.json','mode-rectangles.json','components.json','component-pairs.json']]+[Path(__file__)")
text=text.replace('plus squared violations of268 source-safe orthogonal component separators.','plus squared distance to the union of all four source-safe axis separators for each of268 orthogonal component pairs. Identical cog copies may exchange X order: negative canonical X reflects both relative coordinates, which swaps the endpoints of two identical source shapes.')
text=text.replace('No fixed region assignment or integer/discrete model is consumed.','No fixed region assignment, fixed rectangle separator, cog identity order or integer/discrete model is consumed.')
put('prepare_h5_cog_physical_union_distance_20261107.py',text)
text=change((D/'audit_h5_cog_union_distance_20261107.py').read_text(encoding='utf-8'))
old="""for key,field in [('orth_positive','positive_owner'),('orth_negative','negative_owner'),('orth_axis','axis')]:assert np.array_equal(arrays[key],[r[field] for r in orth])
assert np.array_equal(arrays['orth_upper'],[r['upper']/100 for r in orth]);expected_keys={'initial','bounds','orth_positive','orth_negative','orth_axis','orth_upper'};classes=list(dict.fromkeys(p['class'] for p in pairs))
"""
new="""I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';components=load(I/'components.json');rectangles=load(I/'mode-rectangles.json');source_pairs=load(I/'component-pairs.json');assert meta['source_component_pairs']==source_pairs and meta['rectangle_gap_grid']==23
assert arrays['orth_positive'].shape==arrays['orth_negative'].shape==arrays['orth_axis'].shape==arrays['orth_upper'].shape==(268,4)
for index,pair in enumerate(source_pairs):
    ca,cb=(components[i] for i in pair['components']);oa,ob=(owners[i] for i in pair['owners']);aa=rectangles[oa['identity'][0]][oa['mode']]['rectangles'][ca['piece']]['outward_offsets_grid'];bb=rectangles[ob['identity'][0]][ob['mode']]['rectangles'][cb['piece']]['outward_offsets_grid']
    for direction,(axis,left,right,upper) in enumerate([(0,oa['owner'],ob['owner'],bb[0]-aa[2]-23),(0,ob['owner'],oa['owner'],aa[0]-bb[2]-23),(1,oa['owner'],ob['owner'],bb[1]-aa[3]-23),(1,ob['owner'],oa['owner'],aa[1]-bb[3]-23)]):
        assert arrays['orth_axis'][index,direction]==axis and arrays['orth_positive'][index,direction]==left and arrays['orth_negative'][index,direction]==right and arrays['orth_upper'][index,direction]==upper/100
cogs=owners[16:];assert all(o['identity'][0]=='cog' for o in cogs)
for key in ['mode','rotation_radians','mirrored','translation_from_lower_left','position_bounds_grid']:assert all(o[key]==cogs[0][key] for o in cogs)
expected_keys={'initial','bounds','orth_positive','orth_negative','orth_axis','orth_upper'};classes=list(dict.fromkeys(p['class'] for p in pairs))
"""
assert old in text;text=text.replace(old,new)
text=text.replace("options={'maxiter':3000", "swapped=arrays['initial'].reshape(28,2).copy();swapped[16:]=swapped[16:][::-1];swapped_value,swapped_gradient=obj.evaluate(swapped.reshape(-1));assert abs(swapped_value-energy)<1e-7;expected_gradient=gradient.reshape(28,2).copy();expected_gradient[16:]=expected_gradient[16:][::-1];assert np.max(np.abs(swapped_gradient.reshape(28,2)-expected_gradient))<1e-8\noptions={'maxiter':3000")
text=text.replace("inputs=[Path(__file__)","inputs=[ROOT/'output/h5_cog_union_distance_20261107.py']+[I/n for n in ['audit/plan.json','audit/checks.json','mode-rectangles.json','components.json','component-pairs.json']]+[Path(__file__)")
text=text.replace("'analytic_derivatives_checked':112,","'analytic_derivatives_checked':112,'all_four_source_separator_directions_checked':1072,'identical_cog_order_reversal_value_and_gradient_checked':True,")
text=text.replace('Check112 analytic derivatives','Verify all1072source rectangle directions and identical-cog mode/stock equivalence; reverse all12cog identities and require objective/gradient equivariance, exercising all66 negative-X cog differences. Check112 analytic derivatives')
put('audit_h5_cog_physical_union_distance_20261107.py',text)
text=change((D/'run_h5_cog_union_distance_preparation_20261107.py').read_text(encoding='utf-8'));put('run_h5_cog_physical_union_distance_preparation_20261107.py',text)
text=change((D/'run_h5_cog_union_distance_search_20261107.py').read_text(encoding='utf-8'))
text=text.replace('One distinct continuously bounded distance-to-certified-union optimization call with analytic gradients.','One distinct continuously bounded distance-to-certified-union optimization call with analytic gradients, all four original orthogonal separator directions, and unordered identical cog copies. The earlier fixed-separator model is not repeated.')
text=text.replace("files=[Path(__file__)","files=[ROOT/'output/h5_cog_union_distance_20261107.py',Path(__file__)")
put('run_h5_cog_physical_union_distance_search_20261107.py',text)
