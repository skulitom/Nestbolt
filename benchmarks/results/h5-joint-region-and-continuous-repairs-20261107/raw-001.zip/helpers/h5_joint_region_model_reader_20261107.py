"""Independently read each original-domain, guarded-plane and conflict field."""
from pathlib import Path
import json
from google.protobuf import text_format
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';D=ROOT/'output/h5-joint-region-domains-20261107';B=ROOT/'output/h5-cog-convex-repair-20261107';C=ROOT/'output/h5-cog-convex-choice-search-20261107';MIN=-(2**63)
load=lambda p:json.loads(p.read_bytes())
def verify(proto,mapping):
    real=cp_model.CpModel();assert real.proto.parse_text_format(text_format.MessageToString(proto)) and real.validate()=='';del real
    assert {f.name for f,v in proto.ListFields()}=={'variables','constraints','solution_hint'} and set(mapping)=={'owners','pairs','orthogonal','cog_orders','nogoods','position_units_per_mm','world_origin_mm'} and mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,2100]
    owners=load(P/'owners.json');assert mapping['owners']==owners;domains=load(D/'pairs.json');geometries=load(D/'regions.json');regions=load(P/'regions.json');source={(r['class'],r['kind'],r['source_id']):r for r in regions};usedvars=set();usedcts=set();maxactivity=0;guarded=0
    def var(i,name,domain):
        assert i not in usedvars;usedvars.add(i);v=proto.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'}
    def linear(i,terms,lo,hi,guard=None):
        nonlocal maxactivity,guarded
        assert i not in usedcts;usedcts.add(i);row=proto.constraints[i];terms={i:c for i,c in terms.items() if c}
        assert row.WhichOneof('constraint')=='linear' and {f.name for f,v in row.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
        assert list(row.enforcement_literal)==([] if guard is None else [guard]) and list(row.linear.domain)==[lo,hi] and len(row.linear.vars)==len(terms) and dict(zip(row.linear.vars,row.linear.coeffs))==terms
        assert {f.name for f,v in row.linear.ListFields()}=={'vars','coeffs','domain'}
        activity=sum(abs(c)*max(abs(x) for x in proto.variables[i].domain) for i,c in terms.items());assert activity<2**53;maxactivity=max(maxactivity,activity);guarded+=guard is not None
    def transformed(pair,plane):
        # Obtain each world coefficient from the canonical expression evaluated
        # at zero and its four affected world basis vectors.
        a,b=pair['owners'];indices=[2*a,2*a+1,2*b,2*b+1]
        def value(x):
            delta=[x.get(2*b+k,0)-x.get(2*a+k,0) for k in [0,1]];z=[sum(pair['matrix'][k][j]*delta[j] for j in [0,1])+pair['offset_grid'][k] for k in [0,1]]
            return sum(n*v for n,v in zip(plane['coefficients'],z))
        zero=value({});return {i:value({i:1})-zero for i in indices if value({i:1})!=zero},plane['upper']-zero
    for o in owners:
        for k in [0,1]:var(2*o['owner']+k,f'world_{o["owner"]}_{k}_grid',o['position_bounds_grid'][k])
    assert len(mapping['pairs'])==258;selectors=[]
    for pair,record in zip(domains,mapping['pairs']):
        assert record['pair']==pair['pair'] and set(record)=={'pair','domain_constraints','choices','one_choice'} and len(record['domain_constraints'])==4;box=pair['relative_model_bounds_grid'];dp=[{'coefficients':[-1,0],'upper':-box[0][0]},{'coefficients':[1,0],'upper':box[0][1]},{'coefficients':[0,-1],'upper':-box[1][0]},{'coefficients':[0,1],'upper':box[1][1]}]
        for ci,p in zip(record['domain_constraints'],dp):terms,upper=transformed(pair,p);linear(ci,terms,MIN,upper)
        options=[o for o in pair['options'] if not o['empty']];assert len(options)==len(record['choices']);selected={}
        for option,rec in zip(options,record['choices']):
            assert set(rec)=={'rank','selector','cache','source_plane_indices','constraints'} and rec['rank']==option['rank'] and rec['cache']==option['cache'];sel=rec['selector'];var(sel,f'pair_{pair["pair"]}_rank_{option["rank"]}',[0,1]);selected[option['rank']]=sel
            geometry=geometries[option['cache']];assert rec['source_plane_indices']==geometry['retained_source_plane_indices'] and len(rec['constraints'])==len(rec['source_plane_indices']);original=source[pair['class'],option['kind'],option['source_id']]
            for edge,ci in zip(rec['source_plane_indices'],rec['constraints']):terms,upper=transformed(pair,original['planes'][edge]);linear(ci,terms,MIN,upper,sel)
        linear(record['one_choice'],{s:1 for s in selected.values()},1,1);selectors.append(selected)
    orth=load(P/'orthogonal-separators.json');assert len(mapping['orthogonal'])==len(orth)==268
    for i,(rec,row) in enumerate(zip(mapping['orthogonal'],orth)):
        assert set(rec)=={'source','constraint'} and rec['source']==i;linear(rec['constraint'],{2*row['positive_owner']+row['axis']:1,2*row['negative_owner']+row['axis']:-1},MIN,row['upper'])
    assert len(mapping['cog_orders'])==11
    for rec,a in zip(mapping['cog_orders'],range(16,27)):assert set(rec)=={'owners','constraint'} and rec['owners']==[a,a+1];linear(rec['constraint'],{2*a:1,2*(a+1):-1},MIN,0)
    expected=[{'source':'original-six-region-chain','choices':sorted([[r['pair'],0] for r in load(B/'response-audit/six-region-chain.json')['selected_choices']])}]+[{'source':r['node'],'choices':sorted(r['choices'])} for r in load(C/'audit/certified-choice-nogoods.json')];assert len(mapping['nogoods'])==len(expected)==257
    for rec,wanted in zip(mapping['nogoods'],expected):
        assert set(rec)=={'source','choices','tautology_from_empty_option','constraint'} and rec['source']==wanted['source'] and rec['choices']==wanted['choices'];tautology=any(rank not in selectors[pi] for pi,rank in wanted['choices']);assert rec['tautology_from_empty_option']==tautology
        if tautology:assert rec['constraint'] is None
        else:linear(rec['constraint'],{selectors[pi][rank]:1 for pi,rank in wanted['choices']},MIN,len(wanted['choices'])-1)
    assert usedvars==set(range(len(proto.variables))) and usedcts==set(range(len(proto.constraints)))
    hints={2*o['owner']+k:o['position_grid'][k] for o in owners for k in [0,1]};assert len(proto.solution_hint.vars)==56 and dict(zip(proto.solution_hint.vars,proto.solution_hint.values))==hints and {f.name for f,v in proto.solution_hint.ListFields()}=={'vars','values'}
    hinted=0
    for row in proto.constraints:
        if row.enforcement_literal or not set(row.linear.vars)<=set(hints):continue
        value=sum(c*hints[i] for i,c in zip(row.linear.vars,row.linear.coeffs));assert row.linear.domain[0]<=value<=row.linear.domain[1];hinted+=1
    return {'passed':True,'variables':len(usedvars),'constraints':len(usedcts),'position_variables':56,'region_selectors':len(usedvars)-56,'guarded_source_planes':guarded,'pair_domains':258,'orthogonal_separators':268,'cog_x_orders':11,'certified_nogoods':257,'partial_hints':56,'fully_hinted_rows':hinted,'maximum_absolute_linear_activity':maxactivity,'all_fields_verified':True}
