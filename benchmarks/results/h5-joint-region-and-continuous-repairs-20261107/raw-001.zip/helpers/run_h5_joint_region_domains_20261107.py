from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-joint-region-domains-process-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
stages=[('prepare','prepare_h5_joint_region_domains_20261107.py',25),('audit','audit_h5_joint_region_domains_20261107.py',90)];write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']+[ROOT/'output'/s for _,s,_ in stages]},'stages':stages,'memory_bytes':2**31,'solver_calls':0,'retry_permitted':False});records=[]
for name,script,cap in stages:
    before=time.perf_counter();r=subprocess.run([str(EXE),str(cap*1000),str(2**31),str(OUT/(name+'-job.json')),str(OUT/(name+'-stdout.txt')),str(OUT/(name+'-stderr.txt')),str(OUT/(name+'-stop')),subprocess.list2cmdline([sys.executable,str(ROOT/'output'/script)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap+8)
    (OUT/(name+'-runner-stdout.txt')).write_bytes(r.stdout);(OUT/(name+'-runner-stderr.txt')).write_bytes(r.stderr);job=load(OUT/(name+'-job.json'));passed=r.returncode==0 and job['reason_code']==job['error_code']==0 and job['closed'] and job['active_processes']==0
    rec={'stage':name,'complete_seconds':time.perf_counter()-before,'passed':passed,'exit_code':r.returncode,'job':job};records.append(rec);write(OUT/(name+'.json'),rec);print(rec,flush=True)
    if not passed:break
write(OUT/'process.json',{'closed':True,'complete_seconds':time.perf_counter()-start,'stages':records,'passed':len(records)==2 and all(r['passed'] for r in records),'repeat_permitted':False})
