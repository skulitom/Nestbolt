"""Distance to the full symmetric source-safe union; all rectangle directions."""
from pathlib import Path
import json,numpy as np
from h5_cog_union_distance_20261107 import nearest_regions
ROOT=Path(__file__).resolve().parents[1];PREVIOUS=ROOT/'output/h5-cog-physical-union-distance-20261107'
def pack_source():
    with np.load(PREVIOUS/'source-arrays.npz',allow_pickle=False) as saved:arrays={k:saved[k].copy() for k in saved.files}
    meta=json.loads((PREVIOUS/'mapping.json').read_bytes())
    for group in meta['groups']:
        count=len(group['source_region_indices']);group['source_region_signs']=[1]*count
        if group['class']!='cog_cog':continue
        prefix=f'g{group["group"]}_'
        for key in ['starts','ends','normals']:arrays[prefix+key]=np.concatenate([arrays[prefix+key],-arrays[prefix+key]],axis=0)
        for key in ['valid','upper']:arrays[prefix+key]=np.concatenate([arrays[prefix+key],arrays[prefix+key]],axis=0)
        group['source_region_indices']*=2;group['source_region_signs']+=[-1]*count
    meta['cog_copy_order']='unordered identical selected modes; use the complete union K plus -K and choose the nearest region from both halves for every query'
    return arrays,meta
class Objective:
    def __init__(self,arrays,meta):self.a=arrays;self.meta=meta
    def evaluate(self,flat,details=False):
        x=np.asarray(flat).reshape(28,2);gradient=np.zeros_like(x);energy=0.;records=[]
        for group in self.meta['groups']:
            pre=f'g{group["group"]}_';a=self.a;owners=a[pre+'owners'];qmat=a[pre+'matrix'];points=np.einsum('pkj,pj->pk',qmat,x[owners[:,1]]-x[owners[:,0]])+a[pre+'offset'];closest,d2=nearest_regions(points,a[pre+'starts'],a[pre+'ends'],a[pre+'valid'],a[pre+'normals'],a[pre+'upper']);best=np.argmin(d2,axis=1);residual=points-closest[np.arange(len(points)),best];energy+=float(np.sum(d2[np.arange(len(points)),best]));g=np.einsum('pk,pkj->pj',2*residual,qmat);np.add.at(gradient,owners[:,0],-g);np.add.at(gradient,owners[:,1],g)
            if details:records.append({'group':group,'points':points,'closest':closest,'squared_distances':d2,'selected_regions':best})
        a=self.a;positive=a['orth_positive'];negative=a['orth_negative'];axis=a['orth_axis'];all_violations=np.maximum(x[positive,axis]-x[negative,axis]-a['orth_upper'],0.);choice=np.argmin(all_violations,axis=1);index=np.arange(len(choice));violations=all_violations[index,choice];energy+=float(violations@violations);np.add.at(gradient,(positive[index,choice],axis[index,choice]),2*violations);np.add.at(gradient,(negative[index,choice],axis[index,choice]),-2*violations)
        assert np.isfinite(energy) and np.all(np.isfinite(gradient))
        if details:return energy,gradient.reshape(-1),records,violations
        return energy,gradient.reshape(-1)
