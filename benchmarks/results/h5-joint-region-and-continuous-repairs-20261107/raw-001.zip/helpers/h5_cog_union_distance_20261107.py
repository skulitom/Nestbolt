"""Squared distance to certified convex-region unions with analytic gradients."""
from pathlib import Path
from fractions import Fraction as F
import json,numpy as np
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107'
load=lambda p:json.loads(p.read_bytes())
def pack_source():
    owners=load(P/'owners.json');pairs=load(P/'pair-projections.json');regions=load(P/'regions.json');classes=list(dict.fromkeys(p['class'] for p in pairs));groups=[];arrays={}
    arrays['bounds']=np.asarray([b for o in owners for b in o['position_bounds_grid']],dtype=float)/100
    arrays['initial']=np.asarray([p for o in owners for p in o['position_grid']],dtype=float)/100
    orth=load(P/'orthogonal-separators.json');arrays['orth_positive']=np.asarray([r['positive_owner'] for r in orth],dtype=np.int64);arrays['orth_negative']=np.asarray([r['negative_owner'] for r in orth],dtype=np.int64);arrays['orth_axis']=np.asarray([r['axis'] for r in orth],dtype=np.int64);arrays['orth_upper']=np.asarray([r['upper'] for r in orth],dtype=float)/100
    for gi,cid in enumerate(classes):
        selected=[(i,r) for i,r in enumerate(regions) if r['class']==cid and not r['empty']];group_pairs=[p for p in pairs if p['class']==cid];nv=max(len(r['vertices']) for i,r in selected);np_=max(len(r['planes']) for i,r in selected);starts=np.zeros((len(selected),nv,2));ends=starts.copy();valid=np.zeros((len(selected),nv),dtype=bool);normals=np.zeros((len(selected),np_,2));upper=np.full((len(selected),np_),np.inf)
        for ri,(_,region) in enumerate(selected):
            v=np.asarray([[float(F(x)/100) for x in p] for p in region['vertices']]);count=len(v);starts[ri,:count]=v;ends[ri,:count]=np.roll(v,-1,axis=0);valid[ri,:count]=True
            for pi,plane in enumerate(region['planes']):
                n=np.asarray(plane['coefficients'],dtype=float);length=np.sqrt(n@n);assert length>0;normals[ri,pi]=n/length;upper[ri,pi]=plane['upper']/100/length
        prefix=f'g{gi}_';arrays.update({prefix+'starts':starts,prefix+'ends':ends,prefix+'valid':valid,prefix+'normals':normals,prefix+'upper':upper,prefix+'owners':np.asarray([p['owners'] for p in group_pairs],dtype=np.int64),prefix+'matrix':np.asarray([p['matrix'] for p in group_pairs],dtype=float),prefix+'offset':np.asarray([p['offset_grid'] for p in group_pairs],dtype=float)/100})
        groups.append({'group':gi,'class':cid,'pairs':[p['pair'] for p in group_pairs],'source_region_indices':[i for i,r in selected]})
    return arrays,{'groups':groups,'owners':owners,'position_units':'millimetres from world origin[0,2100]','pair_union_distance_weight':1,'orthogonal_separator_violation_weight':1,'stock_bounds_hard':True}
def nearest_regions(points,starts,ends,valid,normals,upper):
    edge=ends-starts;den=np.sum(edge*edge,axis=-1);delta=points[:,None,None,:]-starts[None,:,:,:]
    t=np.clip(np.sum(delta*edge[None,:,:,:],axis=-1)/np.where(den>0,den,1)[None,:,:],0,1)
    q=starts[None,:,:,:]+t[:,:,:,None]*edge[None,:,:,:];d2=np.sum((points[:,None,None,:]-q)**2,axis=-1);d2=np.where(valid[None,:,:],d2,np.inf);ei=np.argmin(d2,axis=2)
    nearest=q[np.arange(len(points))[:,None],np.arange(len(starts))[None,:],ei]
    distance=d2[np.arange(len(points))[:,None],np.arange(len(starts))[None,:],ei]
    inside=np.all(np.einsum('pd,rkd->prk',points,normals)<=upper[None,:,:],axis=2)
    nearest=np.where(inside[:,:,None],points[:,None,:],nearest);distance=np.where(inside,0.,distance)
    return nearest,distance
class Objective:
    def __init__(self,arrays,meta):self.a=arrays;self.meta=meta
    def evaluate(self,flat,details=False):
        x=np.asarray(flat).reshape(28,2);gradient=np.zeros_like(x);energy=0.;records=[]
        for group in self.meta['groups']:
            pre=f'g{group["group"]}_';a=self.a;owners=a[pre+'owners'];qmat=a[pre+'matrix'];points=np.einsum('pkj,pj->pk',qmat,x[owners[:,1]]-x[owners[:,0]])+a[pre+'offset'];closest,d2=nearest_regions(points,a[pre+'starts'],a[pre+'ends'],a[pre+'valid'],a[pre+'normals'],a[pre+'upper']);best=np.argmin(d2,axis=1);residual=points-closest[np.arange(len(points)),best];energy+=float(np.sum(d2[np.arange(len(points)),best]));g=np.einsum('pk,pkj->pj',2*residual,qmat);np.add.at(gradient,owners[:,0],-g);np.add.at(gradient,owners[:,1],g)
            if details:records.append({'group':group,'points':points,'closest':closest,'squared_distances':d2,'selected_regions':best})
        a=self.a;positive=a['orth_positive'];negative=a['orth_negative'];axis=a['orth_axis'];violations=np.maximum(x[positive,axis]-x[negative,axis]-a['orth_upper'],0.);energy+=float(violations@violations);np.add.at(gradient,(positive,axis),2*violations);np.add.at(gradient,(negative,axis),-2*violations)
        assert np.isfinite(energy) and np.all(np.isfinite(gradient))
        if details:return energy,gradient.reshape(-1),records,violations
        return energy,gradient.reshape(-1)
