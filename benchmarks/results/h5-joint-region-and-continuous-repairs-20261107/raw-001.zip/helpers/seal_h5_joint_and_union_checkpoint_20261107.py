"""Archive all closed joint/continuous calls, controls and original-source failures."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1]
prior=(ROOT/'output/seal_h5_cog_capacity_search_checkpoint_v2_20261107.py').read_text(encoding='utf-8');prefix=prior[:prior.index('copies=[')]
prefix=prefix.replace("NAME='h5-cog-capacity-search-and-initial-model-v2-20261107'","NAME='h5-joint-region-and-continuous-repairs-20261107'")
prefix=prefix.replace("H=ROOT/'output/h5-independent-cog-capacity-20261107';C=ROOT/'output/h5-independent-cog-lazy-20261107';F=ROOT/'output/h5-cog-capacity-search-checkpoint-20261107'","H=ROOT/'output/h5-joint-region-model-20261107';C=ROOT/'output/h5-cog-physical-union-distance-v2-20261107';F=ROOT/'output/h5-joint-and-union-checkpoint-20261107'")
prefix=prefix.replace("front['closed_solver_calls']==1 and front['closed_solver_status']=='UNKNOWN' and not front['pipeline_prepared']","front['closed_joint_solver_calls']==1 and front['closed_joint_status']=='UNKNOWN' and front['closed_continuous_optimizer_calls']==2 and not front['new_mixed_mode_geometry_prepared']")
prefix=prefix.replace("'h5-cog-halfplane-search-and-capacity-20261107'])","'h5-cog-halfplane-search-and-capacity-20261107','h5-cog-capacity-search-and-initial-model-v2-20261107','h5-staged-cog-candidate-and-projections-20261107','h5-cog-convex-repair-and-choice-proofs-20261107'])")
prefix=prefix.replace("['h5-independent-cog-capacity-model-process-20261107','h5-independent-cog-lazy-initial-process-20261107','h5-cog-halfplane-capacity-main-sync-20261107']","['h5-joint-region-domains-20261107','h5-joint-region-domains-process-20261107','h5-joint-region-model-process-20261107','h5-cog-union-distance-20261107','h5-cog-union-distance-preparation-process-20261107','h5-cog-physical-union-distance-20261107','h5-cog-physical-union-distance-preparation-process-20261107','h5-cog-physical-union-distance-v2-preparation-process-20261107','h5-cog-convex-main-sync-20261107']")
prefix=prefix.replace("['*h5*independent*cog*capacity*20261107.py','*h5*independent*cog*lazy*20261107.py','*h5*cog*capacity*search*20261107.py']","['*h5*joint*region*20261107.py','*h5*cog*union*distance*20261107.py','*h5*cog*physical*20261107.py','*h5*joint*union*20261107.py']")
prefix=prefix.replace("for name in ['ccd1.py'","for name in ['seal_h5_cog_capacity_search_checkpoint_v2_20261107.py','ccd1.py'")
prefix=prefix.replace("for name,h in load(F/'source-bindings.json').items():","add('physical-union-correction.json',ROOT/'output/h5-cog-physical-union-correction-20261107.json')\nfor name,h in load(F/'source-bindings.json').items():")
exec(prefix)
U=ROOT/'output/h5-cog-union-distance-20261107';D=ROOT/'output/h5-joint-region-domains-20261107'
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(D/'audit/checks.json','stock-domain-audit.json'),(H/'audit/checks.json','joint-model-audit.json'),(H/'response-audit/checks.json','joint-response-audit.json'),(H/'search/process.json','joint-process.json'),(U/'audit/checks.json','first-distance-controls.json'),(U/'response-audit/checks.json','first-distance-response-audit.json'),(U/'response-audit/collision-details.json','first-distance-source-failures.json'),(C/'audit/checks.json','physical-union-controls.json'),(C/'audit/optimizer-controls.json','physical-optimizer-controls.json'),(C/'response-audit/checks.json','physical-response-audit.json'),(C/'response-audit/collision-details.json','physical-source-failures.json'),(C/'search/process.json','physical-process.json'),(ROOT/'output/h5-cog-physical-union-correction-20261107.json','physical-correction.json'),(ROOT/'output/h5-cog-convex-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Joint region choices and continuous source repairs — 2026-11-07

Three distinct bounded constructions close without a valid full66 layout.
The fully coupled region model returns **UNKNOWN** with no assignment.
The two continuous repairs produce candidates, but independent original-source
replay finds **40 and 38 failing pairs**, respectively. These remain invalid
research results; numerical convergence and lower surrogate penalties do not
satisfy H5. Four fixed arrangements and all 440 allocations remain open.
Completed milestone weight stays **60%**, with H2/H5 incomplete.

## Joint source-region construction

[Exact stock-domain readback]({NAME}/stock-domain-audit.json) verifies all 258
selected-mode relative boxes, 363 cached clipped regions and 1,277 exact
vertices by independent corner images and boundary-line intersections.
All **18,882 source-region options** intersect their stock boxes; none is
discarded. Complete preparation/audit take 0.431228 / 0.590779 s.

[Every joint-model field passes independent readback]({NAME}/joint-model-audit.json):
**18,938 variables, 40,118 constraints**, all 56 original coordinates, 18,882
region selectors, 38,292 guarded source planes, all pair domains, 268 original
orthogonal separators, 11 cog-order constraints and 257 verified choice
conflicts. All 56 partial coordinate hints satisfy the 1,311 fully hinted rows.
Binary/text equality, actual CP-SAT import and six corruption controls pass.
Complete model preparation/audit take **1.616066 / 11.365671 s**.

[The sole joint response]({NAME}/joint-response-audit.json) is **UNKNOWN**:
7,786 branches, zero conflicts and no incumbent. It allocates 15.589553 s
and returns after 15.818898 s; the **0.229345 s solve-slice overrun** is retained.
Presolve consumes most of the slice, with search starting at 11.53 s.
Charged preparation is 36.512010 s; algorithm/shared totals are
**56.301264 / 56.332928 s**, within the overall 60/90-second limits.
[All four processes close]({NAME}/joint-process.json), with 455,811,072 bytes
peak committed memory. No source candidate, native call or exclusion follows.
This model and call are permanently closed.

## Continuous distance to safe regions

A separate construction uses squared distance to the complete certified
safe-region union for each cog interaction and analytic coordinate gradients.
Selected legal modes and stock bounds remain fixed. It consumes the original
necessary candidate and its certified projection preparation; the closed LP,
choice enumeration and joint CP-SAT outputs are not runtime inputs.

[Initial numerical controls]({NAME}/first-distance-controls.json) compare
all **18,882 projections** against exact rational certificates, check 112
analytic derivatives, all packed source fields and a known bounded quadratic
through pinned SciPy 1.17.1 L-BFGS-B. This first objective retains one original
orthogonal separator per component pair.

[Its one call and all 48 improving points replay]({NAME}/first-distance-response-audit.json).
It returns numerical convergence after 45 iterations / 51 evaluations.
The surrogate objective falls from 79,598.294711 to 23,414.927986 mm², but
[full source replay]({NAME}/first-distance-source-failures.json) finds
**39 positive-area intersections and one clearance failure**. Stock checks
pass. Algorithm/shared totals are 31.319446 / 31.396457 s, with preparation
30.234934 s; the call remains closed and receives no H5 credit.

## Broader physical unions and corrected preflight

The next construction allows all four source-safe axis directions for each
orthogonal component pair and removes the ordering restriction on identical
cog copies. It represents the full symmetric cog region union **K ∪ −K**.

[The first broader preflight failure is preserved]({NAME}/physical-correction.json).
Selecting a mirrored half only by the query-X sign made the distance function
discontinuous at the seam; the descent control caught it before any source
optimizer call. The corrected v2 model measures distance to both complete
halves for every query. It reuses and charges the first array preparation,
preserving all failed source, array and process bytes.

[Corrected controls]({NAME}/physical-union-controls.json) check every array,
**24,228 exact projection comparisons**, including 5,346 reflected-region
queries, all **1,072 rectangle directions**, 112 analytic derivatives, and
objective/gradient behavior under reversal of all twelve identical cogs.
[Pinned optimizer controls]({NAME}/physical-optimizer-controls.json) retain the
known bounded quadratic and explicit limits. The complete first/corrected
array preparations are 0.408251 / 0.737396 s; failed/corrected audits are
2.536642 / 6.439704 s. Verification remains separately recorded.

[The corrected physical call]({NAME}/physical-response-audit.json) returns
convergence after **42 iterations / 45 evaluations**, with 43 improving points.
Its best surrogate value is **22,384.710841 mm²**. Independent reconstruction
and [all original-source checks]({NAME}/physical-source-failures.json) still find
**37 intersections and one clearance failure**, with no stock failures.
Both continuous candidates check all **66 originals, 1,632 same-sheet pairs,
264 stock edges, 90 holes and 10,026 hole vertices**.

The corrected optimizer takes 0.534876 s against its 23.950232 s allocation,
with no overrun. Charged preparation is **31.067781 s** and algorithm/shared
totals are **32.724186 / 32.907266 s**. [All five processes close]({NAME}/physical-process.json)
with 96,059,392 bytes peak committed memory. No restart, reseed or extension
is allowed; no native/material or release claim is made.

## Next legal-mode construction

[The next specification]({NAME}/next-step.json) changes the remaining fixed-mode
assumption. It proposes independently audited geometry for all 108 original
mode alternatives, then bounded legal bracket/insert orientation changes.
Only a strictly improving, never previously optimized complete mode vector
may start a new continuous call. At most eight changed-mode calls are proposed,
with the original 60/90-second and 2 GiB limits and a four-second source reserve.
Each returned candidate must undergo full original-source checking.

The warm start remains explicitly invalid. Its **entire consumed 32.907266 s**
must be charged before new all-mode preparation; prior preparation is already
included and must not be counted twice. This mixed-mode geometry and pipeline
have not been prepared or run. Full source/native/material validity,
production integration, UI/CLI/MCP parity and the unchanged full H5 matrix
remain required. H2 keeps its original gate and unopened reserved vectors.

[The preceding checkpoints reached main e3b34ed3 normally]({NAME}/prior-main-push-receipt.json),
after all six prior checks passed and with all 52 remote files preserved.
[Current main CI at review]({NAME}/main-ci-at-review.json) is retained; no run
is cancelled. Production, README and release assets are unchanged.

[Raw evidence]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and [source bindings]({NAME}/source-bindings.json)
preserve all consumed input graphs and failures. Independent archive
verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 joint regions and continuous repairs:** [complete source/model/response audits]({link}) verify all 18,882 stock-clipped options and the 18,938-variable/40,118-constraint joint model. Its sole call closes UNKNOWN without an incumbent; the 0.229345 s solve overrun is retained inside 56.301264/56.332928 s algorithm/shared totals. A separate continuous fixed-separator repair converges numerically but fails 40 original pairs. A broader corrected physical-union model checks all four rectangle directions and unordered identical cogs, passing 24,228 exact projection comparisons and 112 derivative controls; its sole call still fails 38 source pairs. Both candidate replays cover all 66 originals, 1,632 pairs, 264 edges, 90 holes and 10,026 hole vertices. All processes close; no valid layout or exclusion follows. The preflight cog-union seam failure and correction are preserved. The next distinct construction proposes legal orientation changes, charging the complete 32.907266 s warm-start lineage before new preparation; it is not built or run. Four fixed arrangements and 440 allocations remain. H2/H5 stay open at 60%; production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';text=status.read_text(encoding='utf-8');begin=text.index('Latest H5 evidence:');end=text.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [joint regions and continuous repairs](../benchmarks/results/{NAME}.md).
The fully audited joint-region model closes UNKNOWN without a placement.
Two distinct continuous repairs converge numerically, but full original-source
checks still fail 40 and 38 pairs. All stock checks pass; neither candidate is
valid. The broader model now includes all four rectangle directions and the
complete symmetric safe-region union for identical cogs; its preflight seam
failure and correction remain preserved. Every call stays closed.
Legal bracket/insert orientation changes are the next construction, with the
complete 32.907266 s warm-start lineage charged before new preparation.
That mixed-mode model is not yet built. Four fixed arrangements and all 440
allocations remain. H2/H5 stay open at 60%; full source/native/material checks,
production integration/parity and the unchanged H5 matrix remain required.
The preceding checkpoints reached main e3b34ed3 after all six prior checks
passed, preserving all 52 remote files. Current CI is retained; no release.
'''
status.write_text(text[:begin]+intro+text[end:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
