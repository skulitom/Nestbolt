"""Continuous safe unions with all rectangle directions and unordered cog copies."""
from pathlib import Path
import json,numpy as np
from h5_cog_union_distance_20261107 import pack_source as pack_cog_source,nearest_regions
ROOT=Path(__file__).resolve().parents[1];I=ROOT/'output/h5-independent-twelve-cog-integer-20261107'
load=lambda p:json.loads(p.read_bytes())
def pack_source():
    arrays,metadata=pack_cog_source();owners=metadata['owners'];components=load(I/'components.json');rects=load(I/'mode-rectangles.json');pairs=load(I/'component-pairs.json');positive=[];negative=[];axes=[];uppers=[]
    for pair in pairs:
        a,b=(components[i] for i in pair['components']);oa,ob=(owners[i] for i in pair['owners']);ra=rects[oa['identity'][0]][oa['mode']]['rectangles'][a['piece']]['outward_offsets_grid'];rb=rects[ob['identity'][0]][ob['mode']]['rectangles'][b['piece']]['outward_offsets_grid']
        choices=[(0,oa['owner'],ob['owner'],rb[0]-ra[2]-23),(0,ob['owner'],oa['owner'],ra[0]-rb[2]-23),(1,oa['owner'],ob['owner'],rb[1]-ra[3]-23),(1,ob['owner'],oa['owner'],ra[1]-rb[3]-23)]
        axes.append([r[0] for r in choices]);positive.append([r[1] for r in choices]);negative.append([r[2] for r in choices]);uppers.append([r[3]/100 for r in choices])
    arrays['orth_positive']=np.asarray(positive,dtype=np.int64);arrays['orth_negative']=np.asarray(negative,dtype=np.int64);arrays['orth_axis']=np.asarray(axes,dtype=np.int64);arrays['orth_upper']=np.asarray(uppers)
    cogs=[o for o in owners if o['identity'][0]=='cog'];assert len(cogs)==12
    for key in ['mode','rotation_radians','mirrored','translation_from_lower_left','position_bounds_grid']:assert all(o[key]==cogs[0][key] for o in cogs)
    metadata.update({'orthogonal_separator_choice_mode':'minimum of all4source-safe directions per component pair','cog_copy_order':'unordered identical selected modes; reflect negative-X canonical differences by swapping pair endpoints','source_component_pairs':pairs,'rectangle_gap_grid':23})
    return arrays,metadata
class Objective:
    def __init__(self,arrays,meta):self.a=arrays;self.meta=meta
    def evaluate(self,flat,details=False):
        x=np.asarray(flat).reshape(28,2);gradient=np.zeros_like(x);energy=0.;records=[]
        for group in self.meta['groups']:
            pre=f'g{group["group"]}_';a=self.a;owners=a[pre+'owners'];qmat=a[pre+'matrix'];points=np.einsum('pkj,pj->pk',qmat,x[owners[:,1]]-x[owners[:,0]])+a[pre+'offset'];sign=np.ones(len(points))
            if group['class']=='cog_cog':
                assert np.all(a[pre+'offset']==0);sign=np.where(points[:,0]<0,-1.,1.);points=points*sign[:,None]
            closest,d2=nearest_regions(points,a[pre+'starts'],a[pre+'ends'],a[pre+'valid'],a[pre+'normals'],a[pre+'upper']);best=np.argmin(d2,axis=1);residual=points-closest[np.arange(len(points)),best];energy+=float(np.sum(d2[np.arange(len(points)),best]));g=np.einsum('pk,pkj->pj',2*residual*sign[:,None],qmat);np.add.at(gradient,owners[:,0],-g);np.add.at(gradient,owners[:,1],g)
            if details:records.append({'group':group,'points':points,'closest':closest,'squared_distances':d2,'selected_regions':best})
        a=self.a;positive=a['orth_positive'];negative=a['orth_negative'];axis=a['orth_axis'];all_violations=np.maximum(x[positive,axis]-x[negative,axis]-a['orth_upper'],0.);choices=np.argmin(all_violations,axis=1);index=np.arange(len(choices));violations=all_violations[index,choices];energy+=float(violations@violations);np.add.at(gradient,(positive[index,choices],axis[index,choices]),2*violations);np.add.at(gradient,(negative[index,choices],axis[index,choices]),-2*violations)
        assert np.isfinite(energy) and np.all(np.isfinite(gradient))
        if details:return energy,gradient.reshape(-1),records,violations
        return energy,gradient.reshape(-1)
