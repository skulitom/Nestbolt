from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'output';text=(D/'audit_h5_cog_union_distance_response_20261107.py').read_text(encoding='utf-8')
text=text.replace('h5_cog_union_distance_20261107','h5_cog_physical_union_distance_v2_20261107').replace('h5-cog-union-distance-20261107','h5-cog-physical-union-distance-v2-20261107').replace('h5-cog-union-distance-preparation-process-20261107','h5-cog-physical-union-distance-v2-preparation-process-20261107')
text=text.replace("r['incumbents']==48 and r['evaluations']==51 and r['numerical_result']['iterations']==45", "r['incumbents']==43 and r['evaluations']==45 and r['numerical_result']['iterations']==42").replace("saved['evaluation']<=51", "saved['evaluation']<=45")
text=text.replace("'source_region_index':group['group']['source_region_indices'][region],", "'source_region_index':group['group']['source_region_indices'][region],'source_region_sign':group['group']['source_region_signs'][region],")
text=text.replace("source['pair_failures']==40", "source['pair_failures']==38").replace("data.get('inputs',{}).items()", "{**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items()")
text=text.replace('all48 strictly','all43 strictly').replace('one optimizer call,51evaluations,45iterations','one corrected physical-union optimizer call,45evaluations,42iterations').replace('fails40 source pairs','fails38 source pairs')
text=text.replace("'improving_points_verified':48,'function_evaluations':51,'iterations':45", "'improving_points_verified':43,'function_evaluations':45,'iterations':42").replace("'source_pair_failures':40", "'source_pair_failures':38")
ast.parse(text)
with (D/'audit_h5_cog_physical_union_distance_v2_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
