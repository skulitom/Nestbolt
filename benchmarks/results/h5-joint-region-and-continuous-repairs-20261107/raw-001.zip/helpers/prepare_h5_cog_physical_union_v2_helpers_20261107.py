"""Correct the certified union distance at the cog-order seam, preserving v1."""
from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'output'
def put(name,text):
    ast.parse(text)
    with (D/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
base=(D/'h5_cog_union_distance_20261107.py').read_text(encoding='utf-8');objective=base[base.index('class Objective:'):]
header='''"""Distance to the full symmetric source-safe union; all rectangle directions."""
from pathlib import Path
import json,numpy as np
from h5_cog_union_distance_20261107 import nearest_regions
ROOT=Path(__file__).resolve().parents[1];PREVIOUS=ROOT/'output/h5-cog-physical-union-distance-20261107'
def pack_source():
    with np.load(PREVIOUS/'source-arrays.npz',allow_pickle=False) as saved:arrays={k:saved[k].copy() for k in saved.files}
    meta=json.loads((PREVIOUS/'mapping.json').read_bytes())
    for group in meta['groups']:
        count=len(group['source_region_indices']);group['source_region_signs']=[1]*count
        if group['class']!='cog_cog':continue
        prefix=f'g{group["group"]}_'
        for key in ['starts','ends','normals']:arrays[prefix+key]=np.concatenate([arrays[prefix+key],-arrays[prefix+key]],axis=0)
        for key in ['valid','upper']:arrays[prefix+key]=np.concatenate([arrays[prefix+key],arrays[prefix+key]],axis=0)
        group['source_region_indices']*=2;group['source_region_signs']+=[-1]*count
    meta['cog_copy_order']='unordered identical selected modes; use the complete union K plus -K and choose the nearest region from both halves for every query'
    return arrays,meta
'''
objective=objective.replace("all_violations_DOES_NOT_EXIST",'unused')
old="""        a=self.a;positive=a['orth_positive'];negative=a['orth_negative'];axis=a['orth_axis'];violations=np.maximum(x[positive,axis]-x[negative,axis]-a['orth_upper'],0.);energy+=float(violations@violations);np.add.at(gradient,(positive,axis),2*violations);np.add.at(gradient,(negative,axis),-2*violations)
"""
new="""        a=self.a;positive=a['orth_positive'];negative=a['orth_negative'];axis=a['orth_axis'];all_violations=np.maximum(x[positive,axis]-x[negative,axis]-a['orth_upper'],0.);choice=np.argmin(all_violations,axis=1);index=np.arange(len(choice));violations=all_violations[index,choice];energy+=float(violations@violations);np.add.at(gradient,(positive[index,choice],axis[index,choice]),2*violations);np.add.at(gradient,(negative[index,choice],axis[index,choice]),-2*violations)
"""
assert old in objective;objective=objective.replace(old,new);put('h5_cog_physical_union_distance_v2_20261107.py',header+objective)
def names(text):return text.replace('h5_cog_physical_union_distance_20261107','h5_cog_physical_union_distance_v2_20261107').replace('h5-cog-physical-union-distance-20261107','h5-cog-physical-union-distance-v2-20261107').replace('h5-cog-physical-union-distance-preparation-process-20261107','h5-cog-physical-union-distance-v2-preparation-process-20261107')
text=names((D/'prepare_h5_cog_physical_union_distance_20261107.py').read_text(encoding='utf-8'))
text=text.replace("inputs=[ROOT/'output/h5_cog_union_distance_20261107.py']", "inputs=[ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5-cog-physical-union-correction-20261107.json']+[ROOT/'output/h5-cog-physical-union-distance-20261107'/n for n in ['plan.json','source-arrays.npz','mapping.json','checks.json']]")
text=text.replace("write(OUT/'source-preparation-charges.json',charges)","charges['complete_first_physical_array_preparation']=load(ROOT/'output/h5-cog-physical-union-distance-preparation-process-20261107/prepare.json')['complete_seconds'];write(OUT/'source-preparation-charges.json',charges)")
text=text.replace('negative canonical X reflects both relative coordinates, which swaps the endpoints of two identical source shapes.','take distance to the complete symmetric union K plus -K for every cog-pair query. Reflection swaps the endpoints of two identical source shapes. Selecting only the half indicated by query X is incorrect and is not used.')
put('prepare_h5_cog_physical_union_distance_v2_20261107.py',text)
text=names((D/'audit_h5_cog_physical_union_distance_20261107.py').read_text(encoding='utf-8'))
text=text.replace("assert g['pairs']==[p['pair'] for p in pp] and g['source_region_indices']==rr", "signs=[1]*len(rr)\n    if g['class']=='cog_cog':signs+=[-1]*len(rr);rr=rr+rr\n    assert g['pairs']==[p['pair'] for p in pp] and g['source_region_indices']==rr and g['source_region_signs']==signs")
text=text.replace("r=regions[index];n=len(r['vertices']);v=np.array([[float(F(x)/100) for x in p] for p in r['vertices']]);", "r=regions[index];n=len(r['vertices']);sign=signs[ri];v=np.array([[sign*float(F(x)/100) for x in p] for p in r['vertices']]);")
text=text.replace("[x/length,y/length],atol=0", "[sign*x/length,sign*y/length],atol=0")
text=text.replace("obj=Objective(arrays,meta);energy", """def exact_projection(point,region):
    planes=region['planes'];v=[tuple(F(x)/100 for x in p) for p in region['vertices']]
    if all(sum(c*x for c,x in zip(p['coefficients'],point))<=F(p['upper'],100) for p in planes):return tuple(point),F(0)
    choices=[]
    for aa,bb in zip(v,v[1:]+v[:1]):
        edge=[bb[k]-aa[k] for k in [0,1]];den=sum(x*x for x in edge);t=F(0) if den==0 else max(F(0),min(F(1),sum((point[k]-aa[k])*edge[k] for k in [0,1])/den));q=tuple(aa[k]+t*edge[k] for k in [0,1]);choices.append((sum((point[k]-q[k])**2 for k in [0,1]),q))
    distance,q=min(choices);return q,distance
exact_minima={}
obj=Objective(arrays,meta);energy""")
old="""region=regions[region_index];exact=lookup[region['kind'],region['source_id']];q=np.asarray([float(F(v)/100) for v in exact['point_grid']]);d=float(F(exact['distance_squared_grid'])/10000);error="""
new="""region=regions[region_index];sign=g['source_region_signs'][ri]
            if sign==1:
                exact=lookup[region['kind'],region['source_id']];q_exact=tuple(F(v)/100 for v in exact['point_grid']);d_exact=F(exact['distance_squared_grid'])/10000
            else:
                reverse=tuple(-F(v,100) for v in pairs[pi]['candidate_relative_grid']);reverse_q,d_exact=exact_projection(reverse,region);q_exact=tuple(-v for v in reverse_q)
            exact_minima[pi]=min(exact_minima.get(pi,d_exact),d_exact);q=np.asarray([float(v) for v in q_exact]);d=float(d_exact);error="""
assert old in text;text=text.replace(old,new)
text=text.replace("expected=float(sum(F(p['distance_squared_grid']) for p in pairs)/10000);assert abs(energy-expected)<1e-7 and projections==18882", "expected=float(sum(exact_minima.values()));assert abs(energy-expected)<1e-7 and projections==24228")
old="""swapped=arrays['initial'].reshape(28,2).copy();swapped[16:]=swapped[16:][::-1];swapped_value,swapped_gradient=obj.evaluate(swapped.reshape(-1));assert abs(swapped_value-energy)<1e-7;expected_gradient=gradient.reshape(28,2).copy();expected_gradient[16:]=expected_gradient[16:][::-1];assert np.max(np.abs(swapped_gradient.reshape(28,2)-expected_gradient))<1e-8"""
new="""reference=arrays['initial']+.037*np.sin(np.arange(56)*2**.5+.2);reference_value,reference_gradient=obj.evaluate(reference);swapped=reference.reshape(28,2).copy();swapped[16:]=swapped[16:][::-1];swapped_value,swapped_gradient=obj.evaluate(swapped.reshape(-1));assert abs(swapped_value-reference_value)<1e-7;expected_gradient=reference_gradient.reshape(28,2).copy();expected_gradient[16:]=expected_gradient[16:][::-1];assert np.max(np.abs(swapped_gradient.reshape(28,2)-expected_gradient))<1e-8
swapped_initial=arrays['initial'].reshape(28,2).copy();swapped_initial[16:]=swapped_initial[16:][::-1];assert abs(obj.evaluate(swapped_initial.reshape(-1))[0]-energy)<1e-7"""
assert old in text;text=text.replace(old,new)
text=text.replace("str(sum(F(p['distance_squared_grid']) for p in pairs)/10000)","str(sum(exact_minima.values()))")
text=text.replace('all18882 initial','all24228 initial').replace('two deterministic perturbed points','two deterministic perturbed points, and exact rational projections for all5346 reflected-region queries')
text=text.replace("inputs=[ROOT/'output/h5_cog_union_distance_20261107.py']", "inputs=[ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5-cog-physical-union-correction-20261107.json']")
put('audit_h5_cog_physical_union_distance_v2_20261107.py',text)
text=names((D/'run_h5_cog_physical_union_distance_preparation_20261107.py').read_text(encoding='utf-8'));text=text.replace('prepare_h5_cog_physical_union_distance_20261107.py','prepare_h5_cog_physical_union_distance_v2_20261107.py').replace('audit_h5_cog_physical_union_distance_20261107.py','audit_h5_cog_physical_union_distance_v2_20261107.py');put('run_h5_cog_physical_union_distance_v2_preparation_20261107.py',text)
text=names((D/'run_h5_cog_physical_union_distance_search_20261107.py').read_text(encoding='utf-8'));text=text.replace("'source_region_index':group['group']['source_region_indices'][region],", "'source_region_index':group['group']['source_region_indices'][region],'source_region_sign':group['group']['source_region_signs'][region],")
put('run_h5_cog_physical_union_distance_v2_search_20261107.py',text)
preserved=[D/'h5_cog_physical_union_distance_20261107.py',D/'audit_h5_cog_physical_union_distance_20261107.py',D/'h5-cog-physical-union-distance-20261107/source-arrays.npz',D/'h5-cog-physical-union-distance-preparation-process-20261107/process.json',D/'h5-cog-physical-union-distance-preparation-process-20261107/audit-stderr.txt']
record={'preserved_inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in preserved},'failure':'The first broader objective selected a reflected cog half solely by the query-X sign. Its source safe-region cover need not be centrally symmetric at X=0, and nearest distance to a union cannot generally select a half by the query sign. The descent control caught a10.605332790160901mm2 jump under endpoint reversal at two zero-X queries. No source optimizer call ran.','correction':'Use the full union K plus -K for every cog query, with duplicated reflected vertices/normals and a global nearest-region minimum. Keep all four rectangle directions. v2 reuses and charges the complete original broader-array preparation, preserves all failed bytes, and independently checks every added reflected projection with exact rationals. Gradient-equivariance is tested at generic perturbed points, not assumed at nondifferentiable ties.','source_optimizer_calls_before_correction':0,'original_physical_array_preparation_seconds':.40825099986977875,'failed_audit_complete_seconds':2.5366424000822008}
with (D/'h5-cog-physical-union-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
