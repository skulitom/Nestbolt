from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,sys
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint-region-model-20261107';S=BASE/'search';OUT=S/'source-response';P=ROOT/'output/h5-cog-candidate-projections-20261107';D=ROOT/'output/h5-joint-region-domains-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir();values=load(S/'assignment.json');mapping=load(BASE/'mapping.json');assert not load(S/'assignment-check.json')['failed_constraints'];regions=load(P/'regions.json');lookup={(r['class'],r['kind'],r['source_id']):r for r in regions};selected=[]
for pair,mp in zip(load(D/'pairs.json'),mapping['pairs']):
    active=[c for c in mp['choices'] if values[c['selector']]];assert len(active)==1;c=active[0];option=next(o for o in pair['options'] if o['rank']==c['rank']);assert not option['empty'];a,b=pair['owners'];delta=[values[2*b+k]-values[2*a+k] for k in [0,1]];z=[sum(pair['matrix'][k][j]*delta[j] for j in [0,1])+pair['offset_grid'][k] for k in [0,1]]
    assert all(lo<=x<=hi for x,(lo,hi) in zip(z,pair['relative_model_bounds_grid']))
    region=lookup[pair['class'],option['kind'],option['source_id']];assert all(sum(n*x for n,x in zip(p['coefficients'],z))<=p['upper'] for p in region['planes'])
    selected.append({'pair':pair['pair'],'rank':c['rank'],'kind':option['kind'],'source_id':option['source_id'],'canonical_grid':z})
rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json')
for owner in mapping['owners']:
    i=owner['owner'];xy=[values[2*i+k] for k in [0,1]];assert all(lo<=x<=hi for x,(lo,hi) in zip(xy,owner['position_bounds_grid']));world=[xy[0]/100,xy[1]/100+2100]
    rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':owner['rotation_radians'],'mirrored':owner['mirrored'],'translation':[world[k]+owner['translation_from_lower_left'][k] for k in [0,1]]}})
spec=load(FIRST/'plan.json');inventory=load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json');source=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,inventory['full66_identities'])))
assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-regions.json',selected);write(OUT/'original-source-checks.json',source)
files=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',BASE/'mapping.json',S/'assignment.json',S/'assignment-check.json',D/'pairs.json',P/'regions.json',FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'short9-source.json',JOB,ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'method':'Read every selected region directly from its Boolean selector and re-evaluate all original source planes, including box-redundant ones, in canonical coordinates derived from original owner positions. Reconstruct every fixed, short and movable original identity/pose and check all66 originals,1632pairs,264stockedges,90holes and10026holevertices under unchanged source limits.'})
write(OUT/'checks.json',{'source_valid66':source['valid'],'pair_failures':source['pair_failures'],'stock_failures':source['stock_failures'],'originals':66,'same_sheet_pairs':1632,'stock_edges':264,'holes':90,'hole_vertices':10026,'selected_cog_regions_verified':len(selected),'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
