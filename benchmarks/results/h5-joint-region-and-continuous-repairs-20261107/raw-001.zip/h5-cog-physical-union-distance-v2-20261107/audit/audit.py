from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,sys,numpy as np,scipy
from scipy.optimize import minimize,_lbfgsb
from h5_cog_physical_union_distance_v2_20261107 import Objective
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';BASE=ROOT/'output/h5-cog-physical-union-distance-v2-20261107';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');assert scipy.__version__=='1.17.1';data=np.load(BASE/'source-arrays.npz',allow_pickle=False);arrays={k:data[k] for k in data.files};meta=load(BASE/'mapping.json');owners=load(P/'owners.json');pairs=load(P/'pair-projections.json');regions=load(P/'regions.json');ranks=load(P/'all-ranked-projections.json');orth=load(P/'orthogonal-separators.json')
assert meta['owners']==owners and meta['stock_bounds_hard'] and meta['pair_union_distance_weight']==meta['orthogonal_separator_violation_weight']==1
assert np.array_equal(arrays['initial'],[v/100 for o in owners for v in o['position_grid']]) and np.array_equal(arrays['bounds'],[[v/100 for v in b] for o in owners for b in o['position_bounds_grid']])
I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';components=load(I/'components.json');rectangles=load(I/'mode-rectangles.json');source_pairs=load(I/'component-pairs.json');assert meta['source_component_pairs']==source_pairs and meta['rectangle_gap_grid']==23
assert arrays['orth_positive'].shape==arrays['orth_negative'].shape==arrays['orth_axis'].shape==arrays['orth_upper'].shape==(268,4)
for index,pair in enumerate(source_pairs):
    ca,cb=(components[i] for i in pair['components']);oa,ob=(owners[i] for i in pair['owners']);aa=rectangles[oa['identity'][0]][oa['mode']]['rectangles'][ca['piece']]['outward_offsets_grid'];bb=rectangles[ob['identity'][0]][ob['mode']]['rectangles'][cb['piece']]['outward_offsets_grid']
    for direction,(axis,left,right,upper) in enumerate([(0,oa['owner'],ob['owner'],bb[0]-aa[2]-23),(0,ob['owner'],oa['owner'],aa[0]-bb[2]-23),(1,oa['owner'],ob['owner'],bb[1]-aa[3]-23),(1,ob['owner'],oa['owner'],aa[1]-bb[3]-23)]):
        assert arrays['orth_axis'][index,direction]==axis and arrays['orth_positive'][index,direction]==left and arrays['orth_negative'][index,direction]==right and arrays['orth_upper'][index,direction]==upper/100
cogs=owners[16:];assert all(o['identity'][0]=='cog' for o in cogs)
for key in ['mode','rotation_radians','mirrored','translation_from_lower_left','position_bounds_grid']:assert all(o[key]==cogs[0][key] for o in cogs)
expected_keys={'initial','bounds','orth_positive','orth_negative','orth_axis','orth_upper'};classes=list(dict.fromkeys(p['class'] for p in pairs))
assert [g['class'] for g in meta['groups']]==classes
for gi,g in enumerate(meta['groups']):
    assert g['group']==gi;prefix=f'g{gi}_';expected_keys.update(prefix+k for k in ['starts','ends','valid','normals','upper','owners','matrix','offset']);pp=[p for p in pairs if p['class']==g['class']];rr=[i for i,r in enumerate(regions) if r['class']==g['class'] and not r['empty']]
    signs=[1]*len(rr)
    if g['class']=='cog_cog':signs+=[-1]*len(rr);rr=rr+rr
    assert g['pairs']==[p['pair'] for p in pp] and g['source_region_indices']==rr and g['source_region_signs']==signs
    for key,field in [('owners','owners'),('matrix','matrix')]:assert np.array_equal(arrays[prefix+key],[p[field] for p in pp])
    assert np.array_equal(arrays[prefix+'offset'],[[v/100 for v in p['offset_grid']] for p in pp])
    for ri,index in enumerate(rr):
        r=regions[index];n=len(r['vertices']);sign=signs[ri];v=np.array([[sign*float(F(x)/100) for x in p] for p in r['vertices']]);assert np.array_equal(arrays[prefix+'starts'][ri,:n],v) and np.array_equal(arrays[prefix+'ends'][ri,:n],v[list(range(1,n))+[0]])
        assert arrays[prefix+'valid'][ri].tolist()==[True]*n+[False]*(arrays[prefix+'valid'].shape[1]-n) and np.all(arrays[prefix+'starts'][ri,n:]==0) and np.all(arrays[prefix+'ends'][ri,n:]==0)
        for j,plane in enumerate(r['planes']):
            x,y=plane['coefficients'];length=(x*x+y*y)**.5;assert np.allclose(arrays[prefix+'normals'][ri,j],[sign*x/length,sign*y/length],atol=0,rtol=2e-16) and abs(arrays[prefix+'upper'][ri,j]-plane['upper']/100/length)<=1e-12
        assert np.all(arrays[prefix+'normals'][ri,len(r['planes']):]==0) and np.all(np.isposinf(arrays[prefix+'upper'][ri,len(r['planes']):]))
assert set(arrays)==expected_keys
def exact_projection(point,region):
    planes=region['planes'];v=[tuple(F(x)/100 for x in p) for p in region['vertices']]
    if all(sum(c*x for c,x in zip(p['coefficients'],point))<=F(p['upper'],100) for p in planes):return tuple(point),F(0)
    choices=[]
    for aa,bb in zip(v,v[1:]+v[:1]):
        edge=[bb[k]-aa[k] for k in [0,1]];den=sum(x*x for x in edge);t=F(0) if den==0 else max(F(0),min(F(1),sum((point[k]-aa[k])*edge[k] for k in [0,1])/den));q=tuple(aa[k]+t*edge[k] for k in [0,1]);choices.append((sum((point[k]-q[k])**2 for k in [0,1]),q))
    distance,q=min(choices);return q,distance
exact_minima={}
obj=Objective(arrays,meta);energy,gradient,details,violations=obj.evaluate(arrays['initial'],True);assert not np.any(violations);projections=0;max_point_error=max_distance_error=0.
for record in details:
    g=record['group']
    for local,pi in enumerate(g['pairs']):
        lookup={(r['kind'],r['source_id']):r for r in ranks[pi]['ranked']}
        assert np.allclose(record['points'][local],np.asarray(pairs[pi]['candidate_relative_grid'])/100,atol=1e-12,rtol=0)
        for ri,region_index in enumerate(g['source_region_indices']):
            region=regions[region_index];sign=g['source_region_signs'][ri]
            if sign==1:
                exact=lookup[region['kind'],region['source_id']];q_exact=tuple(F(v)/100 for v in exact['point_grid']);d_exact=F(exact['distance_squared_grid'])/10000
            else:
                reverse=tuple(-F(v,100) for v in pairs[pi]['candidate_relative_grid']);reverse_q,d_exact=exact_projection(reverse,region);q_exact=tuple(-v for v in reverse_q)
            exact_minima[pi]=min(exact_minima.get(pi,d_exact),d_exact);q=np.asarray([float(v) for v in q_exact]);d=float(d_exact);error=float(np.max(np.abs(record['closest'][local,ri]-q)));distance_error=abs(record['squared_distances'][local,ri]-d)
            assert error<1e-8 and distance_error<1e-7+1e-12*d;max_point_error=max(max_point_error,error);max_distance_error=max(max_distance_error,distance_error);projections+=1
expected=float(sum(exact_minima.values()));assert abs(energy-expected)<1e-7 and projections==24228
derivatives=[];h=1e-4
for phase in [0,1]:
    point=arrays['initial']+(.037 if phase==0 else .113)*np.sin(np.arange(56)*2**.5+.2+phase);value,g=obj.evaluate(point);errors=[]
    for i in range(56):
        plus=point.copy();minus=point.copy();plus[i]+=h;minus[i]-=h;observed=(obj.evaluate(plus)[0]-obj.evaluate(minus)[0])/(2*h);error=abs(observed-g[i]);assert error<.001+1e-6*abs(g[i]),(phase,i,observed,g[i],error);errors.append(error)
    derivatives.append({'phase':phase,'coordinates_checked':56,'maximum_absolute_error':max(errors),'energy':value})
assert np.max(np.abs(gradient.reshape(28,2).sum(axis=0)))<1e-9 and obj.evaluate(arrays['initial']-1e-6*gradient)[0]<energy
reference=arrays['initial']+.037*np.sin(np.arange(56)*2**.5+.2);reference_value,reference_gradient=obj.evaluate(reference);swapped=reference.reshape(28,2).copy();swapped[16:]=swapped[16:][::-1];swapped_value,swapped_gradient=obj.evaluate(swapped.reshape(-1));assert abs(swapped_value-reference_value)<1e-7;expected_gradient=reference_gradient.reshape(28,2).copy();expected_gradient[16:]=expected_gradient[16:][::-1];assert np.max(np.abs(swapped_gradient.reshape(28,2)-expected_gradient))<1e-8
swapped_initial=arrays['initial'].reshape(28,2).copy();swapped_initial[16:]=swapped_initial[16:][::-1];assert abs(obj.evaluate(swapped_initial.reshape(-1))[0]-energy)<1e-7
options={'maxiter':3000,'maxfun':6000,'maxls':40,'maxcor':10,'ftol':1e-14,'gtol':1e-8}
def quadratic(x):r=x-np.array([1.,-2.]);return float(r@r),2*r
control=minimize(quadratic,np.array([0.,0.]),jac=True,bounds=[[-3,3],[-1,3]],method='L-BFGS-B',options=options);assert control.success and np.max(np.abs(control.x-np.array([1.,-1.])))<1e-8 and abs(control.fun-1)<1e-12
write(OUT/'optimizer-controls.json',{'passed':True,'method':'L-BFGS-B','options':options,'synthetic_calls':1,'source_calls':0,'status':int(control.status),'message':str(control.message),'values':control.x.tolist(),'objective':float(control.fun),'function_evaluations':int(control.nfev),'initial_source_objective':energy,'initial_source_expected_exact_objective':str(sum(exact_minima.values())),'projection_checks':projections,'maximum_projection_point_error_mm':max_point_error,'maximum_projection_distance_error_mm2':max_distance_error,'finite_difference_checks':derivatives})
paths=[Path(sys.executable),Path(_lbfgsb.__file__),Path(scipy.__file__),ROOT/'.cache/shop-venv/Lib/site-packages/scipy/optimize/_lbfgsb_py.py',ROOT/'.cache/shop-venv/Lib/site-packages/scipy/optimize/_minimize.py',ROOT/'.cache/shop-venv/Lib/site-packages/scipy-1.17.1.dist-info/LICENSE.txt']
write(OUT/'tool-provenance.json',{'scipy_version':scipy.__version__,'numpy_version':np.__version__,'python_version':sys.version,'tool_files':{p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in paths},'scipy_license':'BSD-3-Clause','primary_api_source':'installed scipy/optimize/_lbfgsb_py.py, including analytic-jacobian options and callback handling','research_only':True})
inputs=[ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5-cog-physical-union-correction-20261107.json']+[I/n for n in ['audit/plan.json','audit/checks.json','mode-rectangles.json','components.json','component-pairs.json']]+[Path(__file__),ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py']+[BASE/n for n in ['plan.json','source-arrays.npz','mapping.json','checks.json']]+[P/n for n in ['plan.json','audit/plan.json','audit/checks.json','owners.json','regions.json','pair-projections.json','all-ranked-projections.json','orthogonal-separators.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently read every packed source vertex, plane, matrix, offset, stock bound, mode and separator. Compare all24228 initial binary64 projections with independently certified exact rational points/distances. Verify all1072source rectangle directions and identical-cog mode/stock equivalence; reverse all12cog identities and require objective/gradient equivariance, exercising all66 negative-X cog differences. Check112 analytic derivatives by central differences at two deterministic perturbed points, and exact rational projections for all5346 reflected-region queries, translation invariance and a descent direction. Run one known bounded quadratic control with the same pinned L-BFGS-B options; no source optimizer call. Numerical controls do not replace full original-source validation.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all_array_fields_checked':True,'exact_projection_comparisons':projections,'analytic_derivatives_checked':112,'all_four_source_separator_directions_checked':1072,'identical_cog_order_reversal_value_and_gradient_checked':True,'synthetic_optimizer_calls':1,'source_optimizer_calls':0,'initial_objective_mm2':energy,'source_arrays_sha256':digest(BASE/'source-arrays.npz'),'source_valid66':False,'H5_complete':False});print(load(OUT/'checks.json'))
