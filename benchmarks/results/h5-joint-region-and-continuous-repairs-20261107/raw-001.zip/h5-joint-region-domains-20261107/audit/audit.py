"""Independent corner images and complete boundary-intersection certificates."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';BASE=ROOT/'output/h5-joint-region-domains-20261107';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');owners=load(P/'owners.json');original=load(P/'regions.json');source_pairs=load(P/'pair-projections.json');ranks=load(P/'all-ranked-projections.json');pairs=load(BASE/'pairs.json');regions=load(BASE/'regions.json');lookup={(r['class'],r['kind'],r['source_id']):r for r in original};used=set();empty=nonempty=vertices=0
for item in regions:
    assert item['cache']==len(used);used.add(item['cache']);source=lookup[item['class'],item['kind'],item['source_id']];box=item['relative_bounds_grid'];planes=source['planes']+[{'coefficients':[-1,0],'upper':-box[0][0]},{'coefficients':[1,0],'upper':box[0][1]},{'coefficients':[0,-1],'upper':-box[1][0]},{'coefficients':[0,1],'upper':box[1][1]}];points=set()
    for a,b in combinations(planes,2):
        ax,ay=a['coefficients'];bx,by=b['coefficients'];det=ax*by-ay*bx
        if not det:continue
        v=(F(a['upper']*by-ay*b['upper'],det),F(ax*b['upper']-a['upper']*bx,det))
        if all(sum(c*x for c,x in zip(p['coefficients'],v))<=p['upper'] for p in planes):points.add(v)
    actual=set(tuple(map(F,v)) for v in item['vertices']);assert actual==points and len(actual)==len(item['vertices']) and item['empty']==(not points);vertices+=len(points)
    retain=[];redundant=[]
    for pi,plane in enumerate(source['planes'][4:],4):
        maximum=max(sum(c*v for c,v in zip(plane['coefficients'],corner)) for corner in product(*box));(redundant if maximum<=plane['upper'] else retain).append(pi)
    assert retain==item['retained_source_plane_indices'] and redundant==item['box_redundant_plane_indices']
assert len(pairs)==len(source_pairs)==258
for item,source,ranked in zip(pairs,source_pairs,ranks):
    a,b=(owners[i] for i in source['owners']);corners=[]
    for aa in product(*a['position_bounds_grid']):
        for bb in product(*b['position_bounds_grid']):
            delta=[bb[k]-aa[k] for k in [0,1]];corners.append([sum(source['matrix'][k][j]*delta[j] for j in [0,1])+source['offset_grid'][k] for k in [0,1]])
    stock=[[min(p[k] for p in corners),max(p[k] for p in corners)] for k in [0,1]];assert stock==item['relative_stock_bounds_grid']
    for key in ['pair','owners','class','matrix','offset_grid']:assert item[key]==source[key]
    assert len(item['options'])==len(ranked['ranked'])
    for ri,(option,choice) in enumerate(zip(item['options'],ranked['ranked'])):
        assert option['rank']==ri and option['kind']==choice['kind'] and option['source_id']==choice['source_id'];geometry=regions[option['cache']];assert geometry['class']==source['class'] and geometry['kind']==option['kind'] and geometry['source_id']==option['source_id']
        original_region=lookup[geometry['class'],geometry['kind'],geometry['source_id']];p=original_region['planes'];domain=[[-p[0]['upper'],p[1]['upper']],[-p[2]['upper'],p[3]['upper']]];expected=[[max(stock[k][0],domain[k][0]),min(stock[k][1],domain[k][1])] for k in [0,1]]
        assert geometry['relative_bounds_grid']==item['relative_model_bounds_grid']==expected and geometry['empty']==option['empty']
        if option['empty']:empty+=1
        else:nonempty+=1
    assert any(not o['empty'] for o in item['options'])
inputs=[Path(__file__)]+[P/n for n in ['plan.json','audit/plan.json','audit/checks.json','owners.json','regions.json','pair-projections.json','all-ranked-projections.json']]+[BASE/n for n in ['plan.json','pairs.json','regions.json','checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently enumerate all sixteen pairs of selected-mode stock corners to obtain canonical coordinate bounds. Enumerate every boundary-line intersection, retain exactly the feasible points, and require exact equality with clipped region vertices, including all empty cases. A nonempty bounded planar polyhedron has an extreme point, so no feasible intersection can be discarded as empty. Verify every redundant-plane maximum at all box corners and complete pair/rank coverage. No solver or whole-allocation exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'pair_stock_boxes':len(pairs),'clipped_regions':len(regions),'exact_vertices':vertices,'empty_pair_options':empty,'remaining_pair_options':nonempty,'all_original_options_accounted_for':empty+nonempty==18882,'solver_calls':0,'source_valid66':False,'any_allocation_excluded':False};write(OUT/'checks.json',checks);print(checks)
