"""Exact selected-mode stock clipping of every certified pair region."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';OUT=ROOT/'output/h5-joint-region-domains-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clip(poly,n,b):
    points=[]
    for a,z in zip(poly,poly[1:]+poly[:1]):
        av=sum(n[k]*a[k] for k in [0,1])-b;zv=sum(n[k]*z[k] for k in [0,1])-b
        if av<=0:points.append(a)
        if (av<0<zv) or (zv<0<av):
            t=av/(av-zv);points.append(tuple(a[k]+t*(z[k]-a[k]) for k in [0,1]))
    points=sorted(set(points));return points if len(points)<3 else hull(points)
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');assert load(P/'audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5-cog-convex-checkpoint-v2-20261107/next-step.json']+[P/n for n in ['plan.json','audit/plan.json','audit/checks.json','regions.json','owners.json','pair-projections.json','all-ranked-projections.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each selected-mode pair compute the exact interval image of its world-coordinate stock boxes under the signed permutation and offset. Intersect the common certified class domain, including nonnegative cog relative X. Clip every previously nonempty safe region against this tighter box with exact rationals. Exclude only certified empty intersections. Mark a retained source plane redundant only if its exact whole-box maximum satisfies it. All surviving source choices remain available for a distinct jointly coupled selector model. No solver or global allocation exclusion.','prepare_cap_seconds':20,'audit_cap_seconds':90,'solver_calls':0,'retry_permitted':False})
owners=load(P/'owners.json');regions=load(P/'regions.json');pairs=load(P/'pair-projections.json');ranked=load(P/'all-ranked-projections.json');lookup={(r['class'],r['kind'],r['source_id']):r for r in regions};cache=[];indices={};outpairs=[]
for pair,choices in zip(pairs,ranked):
    a,b=(owners[i] for i in pair['owners']);delta=[[b['position_bounds_grid'][k][0]-a['position_bounds_grid'][k][1],b['position_bounds_grid'][k][1]-a['position_bounds_grid'][k][0]] for k in [0,1]]
    stock=[[pair['offset_grid'][k]+sum(min(c*lo,c*hi) for c,(lo,hi) in zip(pair['matrix'][k],delta)),pair['offset_grid'][k]+sum(max(c*lo,c*hi) for c,(lo,hi) in zip(pair['matrix'][k],delta))] for k in [0,1]]
    sample=lookup[pair['class'],choices['ranked'][0]['kind'],choices['ranked'][0]['source_id']];p=sample['planes'];domain=[[-p[0]['upper'],p[1]['upper']],[-p[2]['upper'],p[3]['upper']]];box=[[max(stock[k][0],domain[k][0]),min(stock[k][1],domain[k][1])] for k in [0,1]];assert all(lo<=hi for lo,hi in box)
    options=[]
    for rank,choice in enumerate(choices['ranked']):
        source=lookup[pair['class'],choice['kind'],choice['source_id']];assert source['planes'][:4]==sample['planes'][:4]
        key=json.dumps([pair['class'],box,choice['kind'],choice['source_id']],separators=(',',':'))
        if key not in indices:
            poly=[(F(box[0][0]),F(box[1][0])),(F(box[0][1]),F(box[1][0])),(F(box[0][1]),F(box[1][1])),(F(box[0][0]),F(box[1][1]))]
            for plane in source['planes'][4:]:
                poly=clip(poly,plane['coefficients'],plane['upper'])
                if not poly:break
            retained=[];redundant=[]
            for index,plane in enumerate(source['planes'][4:],4):
                maximum=sum(max(c*lo,c*hi) for c,(lo,hi) in zip(plane['coefficients'],box))
                (redundant if maximum<=plane['upper'] else retained).append(index)
            cid=len(cache);indices[key]=cid;cache.append({'cache':cid,'class':pair['class'],'kind':choice['kind'],'source_id':choice['source_id'],'relative_bounds_grid':box,'vertices':[[str(x) for x in v] for v in poly],'empty':not poly,'retained_source_plane_indices':retained,'box_redundant_plane_indices':redundant})
        options.append({'rank':rank,'kind':choice['kind'],'source_id':choice['source_id'],'cache':indices[key],'empty':cache[indices[key]]['empty']})
    outpairs.append({'pair':pair['pair'],'owners':pair['owners'],'class':pair['class'],'matrix':pair['matrix'],'offset_grid':pair['offset_grid'],'relative_stock_bounds_grid':stock,'relative_model_bounds_grid':box,'options':options});assert any(not r['empty'] for r in options) and time.perf_counter()-start<20
write(OUT/'regions.json',cache);write(OUT/'pairs.json',outpairs)
checks={'passed':True,'seconds':time.perf_counter()-start,'pairs':len(outpairs),'cached_clipped_regions':len(cache),'empty_cached_regions':sum(r['empty'] for r in cache),'exact_vertices':sum(len(r['vertices']) for r in cache),'original_options':sum(len(p['options']) for p in outpairs),'empty_pair_options':sum(o['empty'] for p in outpairs for o in p['options']),'remaining_pair_options':sum(not o['empty'] for p in outpairs for o in p['options']),'remaining_guarded_planes':sum(len(cache[o['cache']]['retained_source_plane_indices']) for p in outpairs for o in p['options'] if not o['empty']),'solver_calls':0,'source_valid66':False,'any_allocation_excluded':False};write(OUT/'checks.json',checks);print(checks)
