from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_joint_region_model_reader_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint-region-model-20261107';S=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');proto=cp_model_pb2.CpModelProto();proto.ParseFromString((BASE/'model.pb').read_bytes());assert proto==text_format.Parse((BASE/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());model=verify(proto,load(BASE/'mapping.json'));assert model['passed']
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((S/'response.pb').read_bytes());parameters=text_format.Parse((S/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters());opened=load(S/'opened.json');result=load(S/'solver-result.json');pipeline=load(S/'result.json');process=load(S/'process.json');job=load(S/'job.json');plan=load(S/'plan.json');charges=load(S/'preparation-charges.json')
assert cp_model_pb2.CpSolverStatus.Name(response.status)==result['status']==pipeline['status']=='UNKNOWN' and not response.solution and result['incumbents']==0 and not list((S/'incumbents').glob('*')) and not result['has_assignment'] and not (S/'assignment.json').exists() and not (S/'source-response').exists()
assert result['solver_calls']==pipeline['solver_calls_opened']==1 and pipeline['source_checker_processes']==0 and not pipeline['source_valid66'] and pipeline['native_calls']==0 and not pipeline['any_allocation_excluded']
assert {f.name for f,v in parameters.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','log_search_progress','log_to_stdout','ignore_subsolvers'}
assert parameters.max_time_in_seconds==result['allocated_solve_seconds']==opened['allocated_solve_seconds'] and parameters.num_search_workers==4 and parameters.random_seed==0 and parameters.log_search_progress and not parameters.log_to_stdout and list(parameters.ignore_subsolvers)==['fj']
assert result['branches']==response.num_branches and result['conflicts']==response.num_conflicts and result['solver_wall_seconds']==response.wall_time and result['solve_slice_overrun_seconds']==max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds']) and response.wall_time<=result['returned_solve_seconds']
assert opened['model_sha256']==digest(BASE/'model.pb')==load(BASE/'audit/checks.json')['model_sha256']
expected={'all_prior_consumed_cost':load(ROOT/'output/h5-cog-convex-checkpoint-v2-20261107/next-step.json')['preparation_before_new_geometry_and_model_seconds'],'complete_stock_domain_preparation':load(ROOT/'output/h5-joint-region-domains-process-20261107/prepare.json')['complete_seconds'],'complete_joint_model_preparation':load(ROOT/'output/h5-joint-region-model-process-20261107/prepare.json')['complete_seconds']};assert charges==expected and sum(charges.values())==plan['preparation_seconds_charged']
assert result['allocated_solve_seconds']+opened['algorithm_seconds_including_preparation_at_open']<=56.01 and result['algorithm_seconds_including_preparation']<=pipeline['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and pipeline['algorithm_overrun_seconds']==0
assert process['exit_code']==job['error_code']==job['reason_code']==job['active_processes']==0 and job['closed'] and process['tree_closed'] and process['closed'] and process['job']==job and job['peak_job_committed_memory']<2**31 and job['complete_ms']<=job['maximum_ms'] and job['assigned_before_resume']
assert load(S/'solver-child-process.json')['exit_code']==0 and not load(S/'solver-child-process.json')['timeout']
inputs=[Path(__file__),ROOT/'output/h5_joint_region_model_reader_20261107.py']+[BASE/n for n in ['plan.json','model.pb','model.pbtxt','mapping.json','audit/plan.json','audit/checks.json','audit/tool-provenance.json']]+[S/n for n in ['plan.json','supervisor-opened.json','preparation-charges.json','opened.json','parameters.pbtxt','response.pb','solver-result.json','result.json','solver-child-process.json','process.json','job.json','solver.log']]
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256']
write(OUT/'source-bindings.json',bindings);write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Re-read every prepared joint-model field and reconcile its sole protobuf response, exact parameters, no-incumbent/no-assignment outcome, all consumed costs, measured solve-slice overrun, overall caps and process closure. UNKNOWN is preserved and excludes no source domain or allocation. The model and call remain permanently closed.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings':len(bindings),'variables':len(proto.variables),'constraints':len(proto.constraints),'closed_solver_calls':1,'status':'UNKNOWN','branches':response.num_branches,'conflicts':response.num_conflicts,'incumbents':0,'allocated_solve_seconds':result['allocated_solve_seconds'],'returned_solve_seconds':result['returned_solve_seconds'],'solve_slice_overrun_seconds':result['solve_slice_overrun_seconds'],'preparation_seconds_charged':sum(charges.values()),'algorithm_seconds_including_preparation':pipeline['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'peak_job_committed_memory':job['peak_job_committed_memory'],'all_descendants_closed':True,'source_valid66':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
