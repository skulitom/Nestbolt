"""One new bounded source-region selector call, never reopened on a limit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint-region-model-20261107';OUT=BASE/'search';PY=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe';SHOP=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def solver_child(started):
    import ortools
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    from h5_source_projection_short_core_reader_20261029 import violations
    checked=load(BASE/'audit/checks.json');assert checked['passed'] and ortools.__version__==checked['ortools_version'] and digest(BASE/'model.pb')==checked['model_sha256']
    for name,value in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/name)==value,name
    for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256'],name
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text(encoding='utf-8')) and model.validate()=='';proto=cp_model_pb2.CpModelProto();proto.ParseFromString((BASE/'model.pb').read_bytes());assert proto==text_format.Parse(str(model.proto),cp_model_pb2.CpModelProto())
    seconds=60-(time.perf_counter()-started)-4
    if seconds<=0:write(OUT/'solver-result.json',{'closed':True,'solver_calls':0,'status':'NO_SOLVE_TIME','has_assignment':False,'algorithm_seconds_including_preparation':time.perf_counter()-started});return
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds;solver.parameters.num_search_workers=4;solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False;solver.parameters.ignore_subsolvers.append('fj')
    with (OUT/'parameters.pbtxt').open('x',encoding='utf-8',newline='\n') as f:f.write(str(solver.parameters))
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':checked['model_sha256'],'allocated_solve_seconds':seconds,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_calls':1,'retry_permitted':False,'algorithm_seconds_including_preparation_at_open':time.perf_counter()-started})
    class Capture(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.count=0
        def on_solution_callback(self):
            write(OUT/'incumbents'/f'{self.count:03d}.json',{'sequence':self.count,'solver_wall_seconds':self.wall_time,'values':[self.value(model.get_int_var_from_proto_index(i)) for i in range(len(model.proto.variables))]});self.count+=1
    capture=Capture()
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda value:(f.write(value+'\n'),f.flush());before=time.perf_counter();status=solver.solve(model,capture);elapsed=time.perf_counter()-before
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString())
    if response.solution:
        values=list(response.solution);read=violations(proto,values);assert not read['failed_constraints'];write(OUT/'assignment.json',values);write(OUT/'assignment-check.json',read)
    write(OUT/'solver-result.json',{'closed':True,'solver_calls':1,'status':solver.status_name(status),'allocated_solve_seconds':seconds,'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'solve_slice_overrun_seconds':max(0.,elapsed-seconds),'branches':response.num_branches,'conflicts':response.num_conflicts,'incumbents':capture.count,'has_assignment':bool(response.solution),'algorithm_seconds_including_preparation':time.perf_counter()-started});print(load(OUT/'solver-result.json'))
def child_process(command,name,started):
    before=time.perf_counter()
    try:r=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-started)));stdout,stderr=r.stdout,r.stderr;record={'exit_code':r.returncode,'timeout':False}
    except subprocess.TimeoutExpired as exc:stdout,stderr=exc.stdout or b'',exc.stderr or b'';record={'exit_code':None,'timeout':True}
    (OUT/(name+'-stdout.txt')).write_bytes(stdout);(OUT/(name+'-stderr.txt')).write_bytes(stderr);record['seconds']=time.perf_counter()-before;record['algorithm_seconds_including_preparation']=time.perf_counter()-started;write(OUT/(name+'-process.json'),record);return record
def pipeline(started):
    s=child_process([str(PY),str(Path(__file__)),'--solver',str(started)],'solver-child',started);source_valid=False;source_calls=0
    if s['exit_code']!=0 or s['timeout'] or not (OUT/'solver-result.json').exists():state='SOLVER_PROCESS_STOP'
    else:
        result=load(OUT/'solver-result.json');state=result['status']
        if result['has_assignment']:
            if time.perf_counter()-started>=60:state='ALGORITHM_TIME_STOP'
            else:
                c=child_process([str(SHOP),str(ROOT/'output/check_h5_joint_region_candidate_20261107.py'),str(started)],'source-child',started);source_calls=1
                if c['exit_code']!=0 or c['timeout'] or not (OUT/'source-response/checks.json').exists():state='SOURCE_PROCESS_STOP'
                else:source_valid=load(OUT/'source-response/checks.json')['source_valid66'];state='SOURCE_VALID_CANDIDATE' if source_valid else 'SOURCE_INVALID_CANDIDATE'
    elapsed=time.perf_counter()-started;write(OUT/'result.json',{'closed':True,'status':state,'solver_calls_opened':int((OUT/'opened.json').exists()),'source_checker_processes':source_calls,'source_valid66':source_valid,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'native_calls':0,'any_allocation_excluded':False,'H5_complete':False})
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(ROOT/'output/h5-joint-region-model-process-20261107/process.json')['passed'];OUT.mkdir();(OUT/'incumbents').mkdir();shutil.copyfile(__file__,OUT/'run.py')
    charges={'all_prior_consumed_cost':load(ROOT/'output/h5-cog-convex-checkpoint-v2-20261107/next-step.json')['preparation_before_new_geometry_and_model_seconds'],'complete_stock_domain_preparation':load(ROOT/'output/h5-joint-region-domains-process-20261107/prepare.json')['complete_seconds'],'complete_joint_model_preparation':load(ROOT/'output/h5-joint-region-model-process-20261107/prepare.json')['complete_seconds']};charge=sum(charges.values());started=time.perf_counter()-charge;write(OUT/'preparation-charges.json',charges)
    first=ROOT/'output/h5-first57-direct-short9-20261104';files=[Path(__file__),ROOT/'output/check_h5_joint_region_candidate_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_source_projection_short_core_reader_20261029.py',ROOT/'output/h5-cog-convex-checkpoint-v2-20261107/next-step.json',ROOT/'output/h5-joint-region-domains-process-20261107/prepare.json',ROOT/'output/h5-joint-region-model-process-20261107/prepare.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json']+[first/n for n in ['plan.json','fixed29.json','short9-source.json']]+[BASE/n for n in ['plan.json','model.pb','model.pbtxt','mapping.json','audit/plan.json','audit/checks.json','audit/tool-provenance.json']]+[ROOT/'output/h5-joint-region-domains-20261107'/n for n in ['pairs.json','audit/plan.json','audit/checks.json']]+[ROOT/'output/h5-cog-candidate-projections-20261107/regions.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'preparation_seconds_charged':charge,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'blas_threads':1,'maximum_solver_calls':1,'retry_permitted':False,'method':'One distinct jointly coupled fixed-mode region model, using all surviving source regions and257 verified choice conflicts. Import and verify the frozen model, perform exactly one bounded call, then close the solver process before full original-source reconstruction/checking. Every runtime cost counts. UNKNOWN/grid-INFEASIBLE/process failure does not exclude the source domain or any allocation.'})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'memory_bytes':2**31,'preparation_seconds_charged':charge,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');command=subprocess.list2cmdline([sys.executable,str(Path(__file__)),'--pipeline',str(started)])
    r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),command,str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'repeat_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed pipeline result; call remains closed.')
if __name__=='__main__':
    if '--solver' in sys.argv:solver_child(float(sys.argv[2]))
    elif '--pipeline' in sys.argv:pipeline(float(sys.argv[2]))
    else:main()
