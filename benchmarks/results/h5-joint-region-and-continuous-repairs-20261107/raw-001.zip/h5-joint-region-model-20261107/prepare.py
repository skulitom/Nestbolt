"""One fresh coupled integer construction over all fixed-mode source choices."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,ortools
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'output/h5-cog-candidate-projections-20261107';D=ROOT/'output/h5-joint-region-domains-20261107';B=ROOT/'output/h5-cog-convex-repair-20261107';C=ROOT/'output/h5-cog-convex-choice-search-20261107';OUT=ROOT/'output/h5-joint-region-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');assert load(D/'audit/checks.json')['passed'] and load(C/'audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/h5-cog-convex-checkpoint-v2-20261107/next-step.json',B/'response-audit/plan.json',B/'response-audit/checks.json',B/'response-audit/six-region-chain.json',C/'audit/plan.json',C/'audit/checks.json',C/'audit/certified-choice-nogoods.json']+[P/n for n in ['plan.json','audit/plan.json','audit/checks.json','owners.json','regions.json','orthogonal-separators.json']]+[D/n for n in ['plan.json','pairs.json','regions.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New model coupling all fixed-mode original coordinates to every retained source-region selector jointly, with exact stock/class bounds, all retained source planes,268 fixed orthogonal separators,11 required cog-X-order constraints, and257 exact conflict clauses. This is not another call to the closed LP or an extension of the closed256-node enumeration. Use0.01mm integer coordinates for construction only, never for continuous exclusion. Only56 coordinate hints are supplied, checked against all fully hinted rows; no source-valid placement is implied.','ortools_version':ortools.__version__,'position_units_per_mm':100,'world_origin_mm':[0,2100],'maximum_solver_calls':1,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'retry_permitted':False,'prepare_cap_seconds':20})
owners=load(P/'owners.json');pairs=load(D/'pairs.json');geometries=load(D/'regions.json');regions=load(P/'regions.json');lookup={(r['class'],r['kind'],r['source_id']):r for r in regions};model=cp_model.CpModel();positions=[]
for o in owners:
    positions.append([model.new_int_var(*o['position_bounds_grid'][k],f'world_{o["owner"]}_{k}_grid') for k in [0,1]])
mapping={'owners':owners,'pairs':[],'orthogonal':[],'cog_orders':[],'nogoods':[],'position_units_per_mm':100,'world_origin_mm':[0,2100]};sel_by_pair=[]
def plane_row(pair,n,upper,guard=None):
    a,b=pair['owners'];coeff=[sum(n[k]*pair['matrix'][k][j] for k in [0,1]) for j in [0,1]];rhs=upper-sum(n[k]*pair['offset_grid'][k] for k in [0,1]);ct=model.add(sum(coeff[j]*(positions[b][j]-positions[a][j]) for j in [0,1])<=rhs)
    if guard is not None:ct.only_enforce_if(guard)
    return ct.index
for pair in pairs:
    box=pair['relative_model_bounds_grid'];domainplanes=[([-1,0],-box[0][0]),([1,0],box[0][1]),([0,-1],-box[1][0]),([0,1],box[1][1])];rec={'pair':pair['pair'],'domain_constraints':[plane_row(pair,n,b) for n,b in domainplanes],'choices':[]};selectors={}
    for option in pair['options']:
        if option['empty']:continue
        rank=option['rank'];sel=model.new_bool_var(f'pair_{pair["pair"]}_rank_{rank}');selectors[rank]=sel;geometry=geometries[option['cache']];source=lookup[pair['class'],option['kind'],option['source_id']];edges=geometry['retained_source_plane_indices'];constraints=[plane_row(pair,source['planes'][e]['coefficients'],source['planes'][e]['upper'],sel) for e in edges]
        rec['choices'].append({'rank':rank,'selector':sel.index,'cache':option['cache'],'source_plane_indices':edges,'constraints':constraints})
    rec['one_choice']=model.add(sum(selectors.values())==1).index;mapping['pairs'].append(rec);sel_by_pair.append(selectors)
for i,row in enumerate(load(P/'orthogonal-separators.json')):mapping['orthogonal'].append({'source':i,'constraint':model.add(positions[row['positive_owner']][row['axis']]-positions[row['negative_owner']][row['axis']]<=row['upper']).index})
for a,b in zip(range(16,27),range(17,28)):mapping['cog_orders'].append({'owners':[a,b],'constraint':model.add(positions[a][0]<=positions[b][0]).index})
root={'source':'original-six-region-chain','choices':[[c['pair'],0] for c in load(B/'response-audit/six-region-chain.json')['selected_choices']]};nogoods=[root]+[{'source':r['node'],'choices':r['choices']} for r in load(C/'audit/certified-choice-nogoods.json')]
for ng in nogoods:
    choices=sorted(ng['choices']);assert len(choices)==len({p for p,r in choices});tautology=any(rank not in sel_by_pair[pi] for pi,rank in choices)
    rec={**ng,'choices':choices,'tautology_from_empty_option':tautology,'constraint':None}
    if not tautology:rec['constraint']=model.add(sum(sel_by_pair[pi][rank] for pi,rank in choices)<=len(choices)-1).index
    mapping['nogoods'].append(rec)
for owner in owners:
    for axis in [0,1]:model.add_hint(positions[owner['owner']][axis],owner['position_grid'][axis])
assert model.validate()=='' and time.perf_counter()-start<20;assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mapping)
checks={'passed':True,'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'position_variables':56,'source_region_selectors':sum(len(s) for s in sel_by_pair),'cog_pair_domains':258,'guarded_source_planes':sum(len(o['constraints']) for p in mapping['pairs'] for o in p['choices']),'orthogonal_separators':268,'cog_x_orders':11,'certified_nogoods':len(mapping['nogoods']),'tautological_nogoods':sum(r['tautology_from_empty_option'] for r in mapping['nogoods']),'partial_coordinate_hints':56,'model_sha256':digest(OUT/'model.pb'),'ortools_version':ortools.__version__,'solver_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
