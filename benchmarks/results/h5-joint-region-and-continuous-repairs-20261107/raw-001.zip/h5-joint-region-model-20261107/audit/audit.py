from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,sys,ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model,cp_model_helper
from h5_joint_region_model_reader_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint-region-model-20261107';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');proto=cp_model_pb2.CpModelProto();proto.ParseFromString((BASE/'model.pb').read_bytes());assert proto==text_format.Parse((BASE/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());mapping=load(BASE/'mapping.json');checked=verify(proto,mapping);rejected=[]
for case in ['wrong_owner_link','wrong_guard','lost_nogood','changed_stock','changed_mode','extra_objective']:
    copy=cp_model_pb2.CpModelProto();copy.CopyFrom(proto);mp=json.loads(json.dumps(mapping))
    if case=='wrong_owner_link':copy.constraints[mp['pairs'][0]['domain_constraints'][0]].linear.coeffs[0]*=-1
    elif case=='wrong_guard':copy.constraints[mp['pairs'][0]['choices'][0]['constraints'][0]].enforcement_literal[0]=mp['pairs'][0]['choices'][1]['selector']
    elif case=='lost_nogood':copy.constraints[mp['nogoods'][-1]['constraint']].linear.domain[-1]+=1
    elif case=='changed_stock':copy.variables[0].domain[0]-=1
    elif case=='changed_mode':mp['owners'][0]['mode']+=1
    else:copy.objective.vars.append(0);copy.objective.coeffs.append(1)
    try:verify(copy,mp)
    except AssertionError:rejected.append(case)
    else:raise AssertionError('Accepted corrupted model: '+case)
paths=[Path(sys.executable),Path(cp_model.__file__),Path(cp_model_helper.__file__),Path(ortools.__file__)]
write(OUT/'tool-provenance.json',{'ortools_version':ortools.__version__,'python_version':sys.version,'tool_files':{p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in paths},'research_only':True,'source_solver_calls':0})
inputs=[Path(__file__),ROOT/'output/h5_joint_region_model_reader_20261107.py']+[BASE/n for n in ['plan.json','model.pb','model.pbtxt','mapping.json','checks.json']]+[ROOT/'output/h5-joint-region-domains-20261107'/n for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Check binary/text equivalence, actual CP-SAT import/validation and every original mode/domain, variable, guard, row, bound, option, exact-choice equation and certified conflict clause independently. Substitute original world basis vectors into canonical source plane expressions. Account for every protobuf/mapping field, all56partialhints and every fully hinted row. Reject six corrupted models. No solver call or source-validity claim.'})
write(OUT/'checks.json',{'passed':True,**checked,'seconds':time.perf_counter()-start,'corrupted_models_rejected':rejected,'model_sha256':digest(BASE/'model.pb'),'ortools_version':ortools.__version__,'solver_calls':0,'source_valid66':False,'H5_complete':False});print(load(OUT/'checks.json'))
