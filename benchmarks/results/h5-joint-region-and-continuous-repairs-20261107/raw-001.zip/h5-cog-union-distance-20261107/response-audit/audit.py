from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,numpy as np
from h5_cog_union_distance_20261107 import Objective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-union-distance-20261107';S=BASE/'search';OUT=BASE/'response-audit';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');archive=np.load(BASE/'source-arrays.npz',allow_pickle=False);arrays={k:archive[k] for k in archive.files};meta=load(BASE/'mapping.json');obj=Objective(arrays,meta);r=load(S/'response.json');result=load(S/'result.json');process=load(S/'process.json');opened=load(S/'opened.json');plan=load(S/'plan.json');job=load(S/'job.json');controls=load(BASE/'audit/optimizer-controls.json');assert load(BASE/'audit/checks.json')['passed'] and opened['options']==controls['options'] and opened['analytic_jacobian'] and opened['method']=='L-BFGS-B'
incumbents=sorted((S/'incumbents').glob('*.json'));assert len(incumbents)==r['incumbents']==48 and r['evaluations']==51 and r['numerical_result']['iterations']==45 and r['numerical_result']['success'] and r['optimizer_calls']==1
last=float('inf');last_evaluation=0
for i,p in enumerate(incumbents):
    saved=load(p);x=np.asarray(saved['values_mm']);value,g=obj.evaluate(x);assert saved['sequence']==i and value==saved['objective_mm2']<last and np.array_equal(g,saved['gradient']) and last_evaluation<saved['evaluation']<=51 and np.all(x>=arrays['bounds'][:,0]) and np.all(x<=arrays['bounds'][:,1]);last=value;last_evaluation=saved['evaluation']
assert r['best_values_mm']==load(incumbents[-1])['values_mm'] and last==r['best_objective_mm2']==result['best_objective_mm2']
energy,g,groups,orth=obj.evaluate(r['best_values_mm'],True);assert energy==r['best_objective_mm2'] and np.array_equal(g,r['best_gradient']) and np.array_equal(orth,r['orthogonal_violations_mm'])
distances=[]
for group in groups:
    for local,pi in enumerate(group['group']['pairs']):
        region=int(group['selected_regions'][local]);distances.append({'pair':pi,'source_region_index':group['group']['source_region_indices'][region],'squared_distance_mm2':float(group['squared_distances'][local,region])})
assert sorted(distances,key=lambda d:d['pair'])==r['pair_distances'] and abs(sum(d['squared_distance_mm2'] for d in distances)+sum(v*v for v in orth)-energy)<1e-7
best=r['best_values_mm'];rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json')
for o in meta['owners']:
    i=o['owner'];world=[best[2*i],best[2*i+1]+2100];rows.append({'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':o['rotation_radians'],'mirrored':o['mirrored'],'translation':[world[k]+o['translation_from_lower_left'][k] for k in [0,1]]}})
assert rows==load(S/'candidate-source66.json');spec=load(FIRST/'plan.json');expected=list(map(tuple,load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json')['full66_identities']));source=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected);assert source==load(S/'original-source-checks.json') and not source['valid'] and source['pair_failures']==40 and source['stock_failures']==0
assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026;write(OUT/'replayed-source-checks.json',source)
bad=[p for p in source['pairs'] if not p['passed']];collision={'pair_failures':len(bad),'positive_area_intersections':sum(p['intersection_area_mm2']>0 for p in bad),'clearance_only_failures':sum(p['intersection_area_mm2']==0 for p in bad),'summed_pairwise_intersection_area_mm2':sum(p['intersection_area_mm2'] for p in bad),'failing_pairs':bad,'scope':'This invalid candidate only; summed areas may double-count and imply no allocation exclusion.'};write(OUT/'collision-details.json',collision)
assert r['returned_optimizer_seconds']<=r['allocated_optimizer_seconds']==opened['allocated_optimizer_seconds'] and r['optimizer_slice_overrun_seconds']==0 and r['algorithm_seconds_including_preparation']<=result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0
assert process['exit_code']==job['error_code']==job['reason_code']==job['active_processes']==0 and job['closed'] and process['job']==job and job['peak_job_committed_memory']<2**31 and process['tree_closed'] and result['source_checker_calls']==1 and result['native_calls']==0
charges=load(S/'preparation-charges.json');assert sum(charges.values())==plan['preparation_seconds_charged'] and charges['complete_new_array_preparation']==load(ROOT/'output/h5-cog-union-distance-preparation-process-20261107/prepare.json')['complete_seconds']
inputs=[Path(__file__),ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'short9-source.json',ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json']+[BASE/n for n in ['plan.json','source-arrays.npz','mapping.json','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json']]+[S/n for n in ['plan.json','supervisor-opened.json','opened.json','preparation-charges.json','response.json','result.json','process.json','job.json','candidate-source66.json','original-source-checks.json']]+incumbents
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in data.get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
for name,record in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==record['sha256']
write(OUT/'source-bindings.json',bindings);write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replay all48 strictly improving objective/gradient records, the best model distances and fixed original modes/stock bounds, then independently reconstruct/recheck all66 actual source contours. Reconcile one optimizer call,51evaluations,45iterations, complete input charges, caps and process closure. Preserve convergence as a numerical event only: the best candidate still fails40 source pairs and excludes no larger domain.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings':len(bindings),'closed_optimizer_calls':1,'optimizer_success':True,'improving_points_verified':48,'function_evaluations':51,'iterations':45,'initial_objective_mm2':controls['initial_source_objective'],'best_objective_mm2':energy,'originals':66,'same_sheet_pairs':1632,'stock_edges':264,'holes':90,'hole_vertices':10026,'source_pair_failures':40,'source_stock_failures':0,'positive_area_intersections':collision['positive_area_intersections'],'clearance_only_failures':collision['clearance_only_failures'],'source_valid66':False,'preparation_seconds_charged':sum(charges.values()),'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'all_descendants_closed':True,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
