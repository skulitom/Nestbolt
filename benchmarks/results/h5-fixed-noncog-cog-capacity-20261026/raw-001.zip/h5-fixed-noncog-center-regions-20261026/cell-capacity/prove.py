"""One bounded exact clique search over conservative cog-center cells."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';COVER=BASE/'cell-cover';OUT=BASE/'cell-capacity'
PAIR=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');started=time.perf_counter();distance=254297;deadline=started+60
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [COVER/'sheet-0.json',COVER/'sheet-1.json',PAIR]},'distance_um':distance,
    'maximum_shared_seconds':60,'maximum_expanded_nodes':200000,'retry_permitted':False,'component_targets':[[0,1,5],[0,0,7],[0,2,2],[1,0,4]],
    'method':'For each conservative closed-cell component, connect two cells exactly when the squared maximum possible point distance between their axis-aligned rectangles is at least254297^2. Each cell diameter is strictly smaller, so at most one cog center lies in it. Any k feasible cog centers imply a k-clique in this necessary graph. Search once for the preregistered component targets using deterministic independent-set coloring and exhaustive include branches. Preserve an exact branch/color certificate on exhaustion or a graph-cell clique on success. A cell clique is not a point or source witness. A graph upper bound applies only to the fixed non-cog arrangement and existing cog sheet counts, never unrestricted feasibility. No external solver or native call.'})
assert load(PAIR)['passed'];results=[];total_nodes=0
class Limit(Exception):pass
for sheet,group,target in [[0,1,5],[0,0,7],[0,2,2],[1,0,4]]:
    if time.perf_counter()>deadline:results.append({'sheet':sheet,'group':group,'target':target,'status':'NOT_STARTED_BUDGET'});continue
    name=f'sheet-{sheet}-group-{group}';folder=OUT/name;folder.mkdir();source=load(COVER/f'sheet-{sheet}.json')['groups'][group];cells=np.array(source['cells_um'],dtype=np.int64);n=len(cells);adj=[]
    for i,a in enumerate(cells):
        dx=np.maximum(abs(a[0]-cells[:,2]),abs(a[2]-cells[:,0]));dy=np.maximum(abs(a[1]-cells[:,3]),abs(a[3]-cells[:,1]));mask=dx*dx+dy*dy>=distance*distance;assert not mask[i]
        bits=int.from_bytes(np.packbits(mask,bitorder='little').tobytes(),'little');adj.append(bits)
    write(folder/'graph.json',{'vertices':n,'distance_um':distance,'adjacency_hex':[hex(x) for x in adj]})
    nodes=[];cache={};expanded=0;begin=time.perf_counter()
    def color(p):
        order=[];colors=[];c=0;remaining=p
        while remaining:
            c+=1;available=remaining
            while available:
                bit=available&-available;v=bit.bit_length()-1;order.append(v);colors.append(c);remaining^=bit;available^=bit;available&=~adj[v]
        return order,colors
    def solve(p,k):
        global total_nodes,expanded
        if time.perf_counter()>deadline or total_nodes>=200000:raise Limit()
        if k==1 and p:return [((p&-p).bit_length()-1)],None
        key=(p,k)
        if key in cache:return None,cache[key]
        total_nodes+=1;expanded+=1;order,colors=color(p);branches=[];remaining=p;cut=0
        for i in range(len(order)-1,-1,-1):
            if colors[i]<k:cut=i+1;break
            v=order[i];answer,child=solve(remaining&adj[v],k-1)
            if answer is not None:return [v]+answer,None
            branches.append({'vertex':v,'child':child});remaining &= ~(1<<v)
        rec={'candidates_hex':hex(p),'required':k,'color_order':order,'colors':colors,'pruned_prefix':cut,'branches':branches};ix=len(nodes);nodes.append(rec);cache[key]=ix;return None,ix
    try:
        witness,root=solve((1<<n)-1,target);status='CELL_CLIQUE_FOUND' if witness is not None else 'TARGET_EXCLUDED'
    except Limit:witness=root=None;status='UNKNOWN_BUDGET'
    write(folder/'certificate.json',{'status':status,'root':root,'nodes':nodes,'cell_clique':witness,'target':target})
    record={'sheet':sheet,'group':group,'vertices':n,'target':target,'status':status,'expanded_nodes':expanded,'certificate_nodes':len(nodes),'search_seconds':time.perf_counter()-begin,
        'cell_clique':witness,'upper_bound':target-1 if status=='TARGET_EXCLUDED' else None}
    if witness is not None:write(folder/'cell-clique.json',{'indices':witness,'grid_indices':[source['grid_indices'][v] for v in witness],'cells_um':[source['cells_um'][v] for v in witness],'point_or_source_witness':False})
    write(folder/'result.json',record);results.append(record);print(record,flush=True)
first=[r for r in results if r['sheet']==0];bound=sum(r['upper_bound'] for r in first) if len(first)==3 and all(r.get('upper_bound') is not None for r in first) else None
write(OUT/'result.json',{'seconds':time.perf_counter()-started,'closed':True,'expanded_nodes':total_nodes,'results':results,'first_sheet_cog_upper_bound':bound,'required_first_sheet_cogs':12,
    'fixed_noncog_arrangement_excluded':bound is not None and bound<12,'unrestricted_exclusion_claimed':False,'source_witness':False,'external_solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
