"""Independent exact geometry, whole-domain cover and branch-certificate reader."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';COVER=BASE/'cell-cover';SEARCH=BASE/'cell-capacity';OUT=BASE/'audit'
GEO=ROOT/'output/h5-allocation-geometry-20261026';MIX=ROOT/'output/h5-mixed-octagon-geometry-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,COVER,SEARCH]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'] and load(MIX/'audit/checks.json')['passed']
originals=load(ROOT/'output/h5-retained64-proxy-regions-20261026/construction/canonical-necessary-poses.json');fixed=load(BASE/'fixed-noncogs.json');assert fixed==[p for p in originals if p['family']!='cog'] and len(fixed)==51
vs=load(GEO/'variants.json');octagon=load(MIX/'octagon.json')['vertices_um'];polys=load(BASE/'forbidden-polygons.json');pi=0;support_checks=0
for pose in fixed:
    for component,b in enumerate(vs[pose['variant']]['coarse_rectangles_um']):
        p=polys[pi];ax,ay=pose['anchor_um'];rect=[b[0]+ax,b[1]+ay,b[2]+ax,b[3]+ay]
        assert p['original_index']==pose['original_index'] and p['family']==pose['family'] and p['sheet']==pose['sheet'] and p['component']==component and p['rectangle_um']==rect
        sums={(x-u,y-v) for x in [rect[0],rect[2]] for y in [rect[1],rect[3]] for u,v in octagon};verts=p['vertices_um'];faces=p['inward_faces'];assert len(verts)==len(faces)==12
        assert all(tuple(v) in sums for v in verts)
        for j,(a,b,c) in enumerate(faces):
            u,v=verts[j],verts[(j+1)%len(verts)];assert a*u[0]+b*u[1]==c and a*v[0]+b*v[1]==c and math.gcd(abs(a),abs(b))==1
            assert all(a*x+b*y>c for k,(x,y) in enumerate(verts) if k not in [j,(j+1)%len(verts)])
            assert all(a*x+b*y>=c for x,y in sums);support_checks+=len(sums)
        pi+=1
assert pi==len(polys)==75
domains=[d for d in load(GEO/'domains.json') if d['variant']==12];assert load(BASE/'domains.json')==domains
removed=remaining=corner_facet_checks=0;sheets=[]
for domain in domains:
    s=domain['sheet'];doc=load(COVER/f'sheet-{s}.json');x0,y0,x1,y1=domain['bounds_um'];step=10000;nx=math.ceil((x1-x0)/step);ny=math.ceil((y1-y0)/step)
    assert doc['domain_um']==domain['bounds_um'] and doc['step_um']==step and doc['columns']==nx and doc['rows']==ny and len(doc['removing_polygon_by_cell'])==nx*ny
    saved={};groups={}
    for g in doc['groups']:
        assert len(g['grid_indices'])==len(g['cells_um'])
        for k,b in zip(g['grid_indices'],g['cells_um']):assert k not in saved;saved[k]=b;groups[k]=g['group']
    for k,remover in enumerate(doc['removing_polygon_by_cell']):
        i,j=k%nx,k//nx;b=[x0+i*step,y0+j*step,min(x1,x0+(i+1)*step),min(y1,y0+(j+1)*step)]
        if remover>=0:
            assert k not in saved and polys[remover]['sheet']==s;removed+=1
            for a,c,d in polys[remover]['inward_faces']:
                assert all(a*x+c*y>d for x in [b[0],b[2]] for y in [b[1],b[3]]);corner_facet_checks+=4
        else:
            assert remover==-1 and saved[k]==b;remaining+=1
            for di in [-1,0,1]:
                for dj in [-1,0,1]:
                    q=(j+dj)*nx+i+di
                    if 0<=i+di<nx and 0<=j+dj<ny and q in groups:assert groups[q]==groups[k]
    assert len(saved)==sum(n==-1 for n in doc['removing_polygon_by_cell']);sheets.append(doc)
distance=load(ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json')['rounded_center_separation_units1000'];assert distance==254297
edge_pairs=cert_nodes=0;bounds={};witnesses=0
for result in load(SEARCH/'result.json')['results']:
    s,g=result['sheet'],result['group'];folder=SEARCH/f'sheet-{s}-group-{g}';cells=sheets[s]['groups'][g]['cells_um'];graph=load(folder/'graph.json');adj=[int(h,16) for h in graph['adjacency_hex']];n=len(cells)
    assert len(adj)==graph['vertices']==n and graph['distance_um']==distance
    for i,a in enumerate(cells):
        assert (a[2]-a[0])**2+(a[3]-a[1])**2<distance**2 and not (adj[i]>>i)&1 and adj[i]>>n==0
        for j in range(i):
            b=cells[j];dx=max(abs(a[x]-b[y]) for x in [0,2] for y in [0,2]);dy=max(abs(a[x]-b[y]) for x in [1,3] for y in [1,3]);edge=dx*dx+dy*dy>=distance**2
            assert bool((adj[i]>>j)&1)==bool((adj[j]>>i)&1)==edge;edge_pairs+=1
    cert=load(folder/'certificate.json');nodes=cert['nodes'];assert cert['status']==result['status'] and cert['target']==result['target']
    for ni,node in enumerate(nodes):
        p=int(node['candidates_hex'],16);k=node['required'];order=node['color_order'];colors=node['colors'];assert k>=1 and len(order)==len(colors) and len(set(order))==len(order)
        assert sum(1<<v for v in order)==p and all(0<=v<n for v in order)
        classes={};previous=0
        for v,c in zip(order,colors):
            assert previous<=c<=previous+1 and c>=1;previous=c;assert not adj[v]&classes.get(c,0);classes[c]=classes.get(c,0)|(1<<v)
        cut=node['pruned_prefix'];assert 0<=cut<=len(order) and (cut==0 or colors[cut-1]<k)
        branches=node['branches'];assert [b['vertex'] for b in branches]==list(reversed(order[cut:]))
        candidate=p
        for branch in branches:
            v=branch['vertex'];child=branch['child'];assert child is not None and 0<=child<ni
            assert nodes[child]['required']==k-1 and int(nodes[child]['candidates_hex'],16)==candidate&adj[v];candidate &= ~(1<<v)
        assert candidate==sum(1<<v for v in order[:cut]);cert_nodes+=1
    if result['status']=='TARGET_EXCLUDED':
        root=nodes[cert['root']];assert int(root['candidates_hex'],16)==(1<<n)-1 and root['required']==result['target'];bounds[f'{s}:{g}']=result['target']-1
    else:
        assert result['status']=='CELL_CLIQUE_FOUND';w=cert['cell_clique'];assert len(set(w))==len(w)==result['target'] and all(adj[a]>>b&1 for a,b in combinations(w,2));witnesses+=1
assert bounds=={'0:0':6,'0:2':1,'1:0':3};run=load(SEARCH/'result.json');assert run['closed'] and run['seconds']<60 and run['expanded_nodes']<=200000
upper=sheets[0]['groups'][1]['cells_um'];region_bounds=[min(p[0] for p in upper),min(p[1] for p in upper),max(p[2] for p in upper),max(p[3] for p in upper)];support=min(p[0]+p[1] for p in upper)
write(OUT/'upper-region-necessary-bounds.json',{'bounds_um':region_bounds,'x_plus_y_at_least_um':support,'cells':len(upper),'mandatory_centers_if_all15_fit':5,
    'reason':'Other first-sheet components hold at most6+1; the short sheet at most3. All15 mandatory cogs therefore require at least5 centers in this upper component, even if cog sheet assignment changes. Fixed51 non-cog poses only.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fixed_noncogs_verified':51,'convex_minkowski_polygons_verified':75,'integer_facets_verified':900,'point_sum_support_checks':support_checks,
    'closed_stock_grid_cells_verified':removed+remaining,'strictly_excluded_cells':removed,'remaining_cells':remaining,'exact_corner_facet_checks':corner_facet_checks,
    'zero_area_boundary_centers_preserved':True,'complete_component_partition':True,'graph_vertex_pairs_verified':edge_pairs,'exhaustive_color_branch_nodes_verified':cert_nodes,
    'necessary_cell_cliques_verified':witnesses,'proved_component_capacities':bounds,'upper_region_needs_at_least5_for_all15':True,'arbitrary_cog_sheet_assignment_covered_by_capacities':True,
    'upper5_excluded':False,'unrestricted_exclusion_claimed':False,'source_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
