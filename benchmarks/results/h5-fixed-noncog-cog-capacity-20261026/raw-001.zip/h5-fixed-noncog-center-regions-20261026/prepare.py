"""Necessary all-angle cog-center regions around the saved complete non-cog poses."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,box,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed-noncog-center-regions-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';MIX=ROOT/'output/h5-mixed-octagon-geometry-20261026'
POSES=ROOT/'output/h5-retained64-proxy-regions-20261026/construction/canonical-necessary-poses.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    ps=sorted(set(points));lo=[];hi=[]
    for p in ps:
        while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
        lo.append(p)
    for p in ps[::-1]:
        while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
        hi.append(p)
    return lo[:-1]+hi[:-1]
assert load(GEO/'audit/checks.json')['passed'] and load(MIX/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
paths=[GEO/n for n in ['variants.json','domains.json','originals.json','audit/checks.json']]+[MIX/n for n in ['octagon.json','audit/checks.json']]+[POSES]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,
    'method':'Keep all51 non-cog original poses in the complete necessary assignment fixed; all15 cog centers and real rotations remain free, with their existing12+3 sheet counts. Translate each non-cog source-contained component rectangle and form its exact integer Minkowski forbidden polygon for the independently proved all-angle source-contained cog octagon. Derive necessary cog stock domains from the audited all-angle support. Save floating GEOS free regions only as a diagnostic, never as an exhaustive certificate: zero-area legal boundary sets may be omitted. An exact integer cell-cover certificate is required for any exclusion claim. No source witness or unrestricted job exclusion is claimed.'})
poses=load(POSES);variants=load(GEO/'variants.json');octagon=load(MIX/'octagon.json')['vertices_um'];domains=[d for d in load(GEO/'domains.json') if d['variant']==12]
assert len(poses)==66 and sum(p['family']=='cog' for p in poses)==15
noncogs=[p for p in poses if p['family']!='cog'];forbidden=[];summary=[]
for pose in noncogs:
    for component,b in enumerate(variants[pose['variant']]['coarse_rectangles_um']):
        ax,ay=pose['anchor_um'];rect=[b[0]+ax,b[1]+ay,b[2]+ax,b[3]+ay]
        sums=sorted({(x-u,y-v) for x in [rect[0],rect[2]] for y in [rect[1],rect[3]] for u,v in octagon});poly=hull(sums);faces=[]
        for a,b in zip(poly,poly[1:]+poly[:1]):
            nx,ny=-(b[1]-a[1]),b[0]-a[0];rhs=nx*a[0]+ny*a[1];g=math.gcd(abs(nx),abs(ny));assert rhs%g==0;faces.append([nx//g,ny//g,rhs//g])
        forbidden.append({'original_index':pose['original_index'],'family':pose['family'],'sheet':pose['sheet'],'component':component,'rectangle_um':rect,'vertices_um':poly,'inward_faces':faces})
for d in domains:
    stock=box(*d['bounds_um']);rows=[p for p in forbidden if p['sheet']==d['sheet']];union=unary_union([Polygon(p['vertices_um']) for p in rows]);free=stock.difference(union)
    write(OUT/f'diagnostic-free-sheet-{d["sheet"]}.json',mapping(free))
    components=[free] if free.geom_type=='Polygon' else list(free.geoms)
    summary.append({'sheet':d['sheet'],'cogs_required':sum(p['family']=='cog' and p['sheet']==d['sheet'] for p in poses),'fixed_noncogs':sum(p['sheet']==d['sheet'] for p in noncogs),'source_components':len(rows),'cog_domain_um':d['bounds_um'],
        'diagnostic_free_area_mm2':free.area/1e6,'diagnostic_component_bounds_mm':[[x/1000 for x in p.bounds] for p in components],
        'diagnostic_component_areas_mm2':[p.area/1e6 for p in components]})
write(OUT/'fixed-noncogs.json',noncogs);write(OUT/'forbidden-polygons.json',forbidden);write(OUT/'domains.json',domains);write(OUT/'diagnostic-summary.json',summary)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'fixed_noncogs':51,'mandatory_cogs':15,'source_component_polygons':len(forbidden),'integer_facets':sum(len(p['inward_faces']) for p in forbidden),'floating_diagnostic_not_exclusion':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'));print(summary)
