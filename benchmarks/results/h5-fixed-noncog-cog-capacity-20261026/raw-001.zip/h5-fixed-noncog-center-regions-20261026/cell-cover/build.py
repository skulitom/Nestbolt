"""Exact closed cell cover of every possible cog center, including boundary sets."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';OUT=BASE/'cell-cover'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();step=10000
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{(BASE/n).relative_to(ROOT).as_posix():digest(BASE/n) for n in ['forbidden-polygons.json','domains.json','fixed-noncogs.json']},
    'step_um':step,'method':'Partition each closed necessary cog stock rectangle into a closed10000um grid, clipped at its top/right edges. Remove a cell only when every point is strictly inside one source-contained forbidden convex polygon, certified by positive integer minimum on every inward facet. Every possible center, including isolated legal boundary points or segments, is covered by a remaining closed cell. Group remaining cells by8-neighbor grid connectivity; no GEOS diagnostic is used. A subsequent exact integer compatibility graph may upper-bound mutually separated centers, but no graph search is opened by this preparation.'})
forbidden=load(BASE/'forbidden-polygons.json');out=[]
for domain in load(BASE/'domains.json'):
    s=domain['sheet'];x0,y0,x1,y1=domain['bounds_um'];nx=math.ceil((x1-x0)/step);ny=math.ceil((y1-y0)/step)
    cells=np.array([[x0+i*step,y0+j*step,min(x1,x0+(i+1)*step),min(y1,y0+(j+1)*step)] for j in range(ny) for i in range(nx)],dtype=np.int64)
    removers=np.full(len(cells),-1,dtype=np.int64)
    for pi,p in enumerate(forbidden):
        if p['sheet']!=s:continue
        ix=np.flatnonzero(removers<0)
        if not len(ix):break
        available=cells[ix];inside=np.ones(len(ix),dtype=bool)
        for a,b,c in p['inward_faces']:
            minimum=a*available[:,0 if a>=0 else 2]+b*available[:,1 if b>=0 else 3]-c
            inside &= minimum>0
        removers[ix[inside]]=pi
    remaining=set(np.flatnonzero(removers<0).tolist());groups=[]
    while remaining:
        initial=min(remaining);remaining.remove(initial);todo=[initial];group=[]
        while todo:
            k=todo.pop();group.append(k);i,j=k%nx,k//nx
            for di in [-1,0,1]:
                for dj in [-1,0,1]:
                    if not 0<=i+di<nx or not 0<=j+dj<ny:continue
                    q=(j+dj)*nx+i+di
                    if q in remaining:remaining.remove(q);todo.append(q)
        groups.append(sorted(group))
    records=[]
    for gi,group in enumerate(groups):
        bounds=[int(cells[group,0].min()),int(cells[group,1].min()),int(cells[group,2].max()),int(cells[group,3].max())]
        records.append({'group':gi,'grid_indices':group,'bounds_um':bounds,'cells_um':cells[group].tolist()})
    write(OUT/f'sheet-{s}.json',{'sheet':s,'domain_um':[x0,y0,x1,y1],'step_um':step,'columns':nx,'rows':ny,'removing_polygon_by_cell':removers.tolist(),'groups':records})
    out.append({'sheet':s,'total_cells':len(cells),'excluded_cells':int(sum(removers>=0)),'remaining_cells':int(sum(removers<0)),'groups':[{'count':len(g['grid_indices']),'bounds_um':g['bounds_um']} for g in records]})
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'sheets':out,'complete_closed_domain_cover':True,'boundary_centers_retained':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
