"""One bounded exact search after rational upper-region clipping."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time,math
from fractions import Fraction as F
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';COVER=BASE/'cell-cover';OUT=BASE/'refined-upper-capacity'
PAIR=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');started=time.perf_counter();distance=254297;deadline=started+60
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'upper-refinement/cells.json',BASE/'upper-refinement/boxes.json',BASE/'upper-refinement/plan.json',PAIR]},'distance_um':distance,
    'maximum_shared_seconds':60,'maximum_expanded_nodes':200000,'retry_permitted':False,'component_targets':[[0,1,5]],
    'method':'A materially refined finite geometry, not a retry of the coarse cell graph. Each exact rational surviving patch is enclosed by the convex hull of floor/ceil corners of its vertices, adding less than1um coordinate relaxation. Combine patches sharing an integer box. Connect two patch groups only when some pair of enclosing integer hull vertices are separated by at least254297um. Any5 actual centers imply a5-clique. Preserve a full branch/color certificate or a necessary cell clique; neither is a source placement or unrestricted exclusion. One60-second/200000-node search, no retry.'})
assert load(PAIR)['passed'];results=[];total_nodes=0
class Limit(Exception):pass
for sheet,group,target in [[0,1,5]]:
    if time.perf_counter()>deadline:results.append({'sheet':sheet,'group':group,'target':target,'status':'NOT_STARTED_BUDGET'});continue
    name=f'sheet-{sheet}-group-{group}';folder=OUT/name;folder.mkdir();cells=load(BASE/'upper-refinement/boxes.json');n=len(cells);adj=[];points=[set() for _ in cells]
    for row in load(BASE/'upper-refinement/cells.json'):
        for patch in row['pieces']:
            if patch['empty_integer_bounds']:continue
            for x,y in patch['polygon_rational']:
                x,y=F(*x),F(*y)
                for u in [math.floor(x),math.ceil(x)]:
                    for v in [math.floor(y),math.ceil(y)]:points[patch['box_index']].add((u,v))
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def hull(ps):
        ps=sorted(ps);lo=[];hi=[]
        for q in ps:
            while len(lo)>1 and cross(lo[-2],lo[-1],q)<=0:lo.pop()
            lo.append(q)
        for q in ps[::-1]:
            while len(hi)>1 and cross(hi[-2],hi[-1],q)<=0:hi.pop()
            hi.append(q)
        return lo[:-1]+hi[:-1] if len(ps)>1 else ps
    hulls=[hull(p) for p in points];assert all(hulls);maximum=max(map(len,hulls));padded=np.array([h+[h[0]]*(maximum-len(h)) for h in hulls],dtype=np.int64)
    write(folder/'enclosing-integer-hulls.json',hulls)
    for i,a in enumerate(hulls):
        farthest=np.zeros(n,dtype=np.int64)
        for x,y in a:
            dx=x-padded[:,:,0];dy=y-padded[:,:,1];farthest=np.maximum(farthest,(dx*dx+dy*dy).max(axis=1))
        mask=farthest>=distance*distance;assert not mask[i]
        adj.append(int.from_bytes(np.packbits(mask,bitorder='little').tobytes(),'little'))
    write(folder/'graph.json',{'vertices':n,'distance_um':distance,'adjacency_hex':[hex(x) for x in adj]})
    nodes=[];cache={};expanded=0;begin=time.perf_counter()
    def color(p):
        order=[];colors=[];c=0;remaining=p
        while remaining:
            c+=1;available=remaining
            while available:
                bit=available&-available;v=bit.bit_length()-1;order.append(v);colors.append(c);remaining^=bit;available^=bit;available&=~adj[v]
        return order,colors
    def solve(p,k):
        global total_nodes,expanded
        if time.perf_counter()>deadline or total_nodes>=200000:raise Limit()
        if k==1 and p:return [((p&-p).bit_length()-1)],None
        key=(p,k)
        if key in cache:return None,cache[key]
        total_nodes+=1;expanded+=1;order,colors=color(p);branches=[];remaining=p;cut=0
        for i in range(len(order)-1,-1,-1):
            if colors[i]<k:cut=i+1;break
            v=order[i];answer,child=solve(remaining&adj[v],k-1)
            if answer is not None:return [v]+answer,None
            branches.append({'vertex':v,'child':child});remaining &= ~(1<<v)
        rec={'candidates_hex':hex(p),'required':k,'color_order':order,'colors':colors,'pruned_prefix':cut,'branches':branches};ix=len(nodes);nodes.append(rec);cache[key]=ix;return None,ix
    try:
        witness,root=solve((1<<n)-1,target);status='CELL_CLIQUE_FOUND' if witness is not None else 'TARGET_EXCLUDED'
    except Limit:witness=root=None;status='UNKNOWN_BUDGET'
    write(folder/'certificate.json',{'status':status,'root':root,'nodes':nodes,'cell_clique':witness,'target':target})
    record={'sheet':sheet,'group':group,'vertices':n,'target':target,'status':status,'expanded_nodes':expanded,'certificate_nodes':len(nodes),'search_seconds':time.perf_counter()-begin,
        'cell_clique':witness,'upper_bound':target-1 if status=='TARGET_EXCLUDED' else None}
    if witness is not None:write(folder/'cell-clique.json',{'indices':witness,'boxes_um':[cells[v] for v in witness],'point_or_source_witness':False})
    write(folder/'result.json',record);results.append(record);print(record,flush=True)
first=[r for r in results if r['sheet']==0];bound=sum(r['upper_bound'] for r in first) if len(first)==3 and all(r.get('upper_bound') is not None for r in first) else None
write(OUT/'result.json',{'seconds':time.perf_counter()-started,'closed':True,'expanded_nodes':total_nodes,'results':results,'all_first_sheet_components_not_combined_here':True,'first_sheet_cog_upper_bound':None,'required_first_sheet_cogs':12,
    'fixed_noncog_arrangement_excluded':False,'unrestricted_exclusion_claimed':False,'source_witness':False,'external_solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
