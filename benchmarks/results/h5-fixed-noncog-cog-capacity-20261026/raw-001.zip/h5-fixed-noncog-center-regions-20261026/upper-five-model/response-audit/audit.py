"""Bind the closed necessary-model result and combine only audited local capacities."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';MODEL=BASE/'upper-five-model';SEARCH=MODEL/'search';OUT=MODEL/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
geometry=load(BASE/'audit/checks.json');audit=load(MODEL/'model-audit/checks.json');assert geometry['passed'] and audit['passed']
assert geometry['proved_component_capacities']=={'0:0':6,'0:2':1,'1:0':3} and audit['mandatory_centers']==5
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json');budget=load(SEARCH/'budget.json')
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and result['closed'] and result['solver_calls']==1 and opened['maximum_calls']==1 and budget['maximum_calls']==1
assert digest(SEARCH/'model.pb')==digest(MODEL/'model.pb')==audit['model_sha256']==opened['model_sha256']
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and result['status']=='INFEASIBLE' and not response.solution and not result['has_solution'] and not (SEARCH/'assignment.json').exists()
assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters());assert params.max_time_in_seconds==60 and params.num_search_workers==4 and list(params.ignore_subsolvers)==['fj']
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert 'status: INFEASIBLE' in log and '1 ignored subsolver: [fj]' in log and 'Starting search at' in log
printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1));assert abs(printed-Decimal(str(response.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
assert response.wall_time<=60 and result['returned_solve_seconds']<60
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':'INFEASIBLE','closed':True,'solver_calls':1,'branches':response.num_branches,'conflicts':response.num_conflicts,
    'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'all_budgets_satisfied':True,'fj_excluded':True,
    'model_sha256':digest(MODEL/'model.pb'),'audited_first_sheet_component_bounds':[6,4,1],'audited_short_sheet_bound':3,'total_cog_upper_bound_with_fixed_noncogs':14,'mandatory_cogs':15,
    'fixed51_noncog_arrangement_excluded':True,'at_least_one_noncog_pose_or_orientation_must_change':True,'all_cog_real_rotations_and_sheet_assignments_covered':True,
    'coarse_grid_boundary_centers_preserved':True,'unverified_refined_graph_not_used_in_proof':True,'solver_infeasibility_response_not_external_formal_unsat_proof':True,
    'unrestricted_job_exclusion_claimed':False,'source_layout_found':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
