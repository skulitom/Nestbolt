"""Necessary five-center model justified by audited whole-domain capacities."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';OUT=BASE/'upper-five-model'
PAIR=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
paths=[BASE/n for n in ['forbidden-polygons.json','audit/checks.json','audit/upper-region-necessary-bounds.json']]+[PAIR]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'ignore_subsolvers':['fj'],
    'method':'The independently audited domain cover proves that the lower first-sheet component holds at most6 cog centers, the small component at most1 and the short sheet at most3. Thus all15 mandatory cogs require5 in the upper component for these fixed51 non-cog poses, regardless of cog sheet assignment. Use its conservative bounding box and minimum x+y support, with each of5 free integer centers outside every relevant source-contained forbidden polygon. Order centers byX only, using indistinguishability. For each of10 center pairs require the relative displacement outside a64-vertex convex integer polygon strictly contained in the disk of the proved minimum center distance254297um. This is a necessary distance condition, not actual cog geometry. No fixed cogs, angles, hints or objective. The coarse/refined cell cliques are not supplied as point hints. Audit every serialized constraint before one60-second solve inside90 shared seconds. INFEASIBLE can exclude only the fixed non-cog arrangement; a positive assignment requires further exact/source readback.'})
region=load(BASE/'audit/upper-region-necessary-bounds.json');bounds=region['bounds_um'];support=region['x_plus_y_at_least_um'];d=load(PAIR)['rounded_center_separation_units1000'];assert d==254297
vertices=[(round((d-2)*math.cos(2*math.pi*k/64)),round((d-2)*math.sin(2*math.pi*k/64))) for k in range(64)];assert all(x*x+y*y<d*d for x,y in vertices)
def faces_of(poly):
    faces=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        nx,ny=-(b[1]-a[1]),b[0]-a[0];rhs=nx*a[0]+ny*a[1];g=math.gcd(abs(nx),abs(ny));assert rhs%g==0;faces.append([nx//g,ny//g,rhs//g])
    return faces
pair_faces=faces_of(vertices);write(OUT/'pair-separation-polygon.json',{'minimum_distance_um':d,'vertices_um':vertices,'inward_faces':pair_faces})
source=load(BASE/'forbidden-polygons.json');relevant=[];skipped=[]
for pi,p in enumerate(source):
    if p['sheet']!=0:continue
    outside=[j for j,(a,b,c) in enumerate(p['inward_faces']) if max(a*x+b*y for x in [bounds[0],bounds[2]] for y in [bounds[1],bounds[3]])<=c]
    if outside:skipped.append({'polygon':pi,'separating_facet':outside[0]})
    else:relevant.append(pi)
model=cp_model.CpModel();coords=[];supports=[]
for i in range(5):
    x=model.new_int_var(bounds[0],bounds[2],f'x_{i}');y=model.new_int_var(bounds[1],bounds[3],f'y_{i}');coords.append([x,y]);supports.append(model.add(x+y>=support).index)
orders=[model.add(coords[i][0]<=coords[i+1][0]).index for i in range(4)];clauses=[]
def add_clause(kind,originals,polygon,faces):
    zs=[];cts=[];a=coords[originals[0]]
    for fi,(nx,ny,rhs) in enumerate(faces):
        z=model.new_bool_var(f'{kind}_{"_".join(map(str,originals))}_{polygon}_{fi}');zs.append(z)
        expr=nx*a[0]+ny*a[1]
        if kind=='pair':b=coords[originals[1]];expr=nx*(b[0]-a[0])+ny*(b[1]-a[1])
        cts.append(model.add(expr<=rhs).only_enforce_if(z).index)
    oc=model.add_bool_or(zs).index;clauses.append({'kind':kind,'centers':originals,'polygon':polygon,'facet_variables':[z.index for z in zs],'facet_constraints':cts,'or_constraint':oc})
for i in range(5):
    for pi in relevant:add_clause('source',[i],pi,source[pi]['inward_faces'])
for i in range(5):
    for j in range(i+1,5):add_clause('pair',[i,j],0,pair_faces)
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'coordinates':[[v.index for v in r] for r in coords],'support_constraints':supports,'x_order_constraints':orders,'relevant_source_polygons':relevant,'skipped_source_polygons':skipped,'clauses':clauses})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_upper_centers':5,'source_polygons_relevant':len(relevant),'source_polygons_skipped_by_exact_bound':len(skipped),'source_clauses':5*len(relevant),'pair_clauses':10,'pair_polygon_facets':64,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
