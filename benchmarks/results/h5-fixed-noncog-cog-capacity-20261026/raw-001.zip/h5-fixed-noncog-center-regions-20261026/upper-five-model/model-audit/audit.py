"""Read all five-center variables, clauses and source necessity inputs independently."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';MODEL=BASE/'upper-five-model';OUT=MODEL/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
checks=load(BASE/'audit/checks.json');assert checks['passed'] and checks['proved_component_capacities']=={'0:0':6,'0:2':1,'1:0':3} and checks['upper_region_needs_at_least5_for_all15']
region=load(BASE/'audit/upper-region-necessary-bounds.json');b=region['bounds_um'];p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');pair=load(MODEL/'pair-separation-polygon.json');d=pair['minimum_distance_um'];assert d==254297
assert not p.HasField('objective') and not p.HasField('floating_point_objective') and not p.solution_hint.vars
verts=pair['vertices_um'];faces=pair['inward_faces'];assert len(verts)==len(faces)==64 and all(x*x+y*y<d*d for x,y in verts)
for j,(a,c,rhs) in enumerate(faces):
    u,v=verts[j],verts[(j+1)%64];assert a*u[0]+c*u[1]==rhs and a*v[0]+c*v[1]==rhs and math.gcd(abs(a),abs(c))==1
    assert all(a*x+c*y>rhs for k,(x,y) in enumerate(verts) if k not in [j,(j+1)%64])
source=load(BASE/'forbidden-polygons.json');relevant=[];skip=[]
for pi,poly in enumerate(source):
    if poly['sheet']!=0:continue
    candidates=[j for j,(a,c,rhs) in enumerate(poly['inward_faces']) if all(a*x+c*y<=rhs for x in [b[0],b[2]] for y in [b[1],b[3]])]
    if candidates:skip.append({'polygon':pi,'separating_facet':candidates[0]})
    else:relevant.append(pi)
assert mp['relevant_source_polygons']==relevant and mp['skipped_source_polygons']==skip
vi=ci=0;LOW=-9223372036854775808;HIGH=9223372036854775807
def linear(index,coeff,domain,when=[]):
    global ci
    assert index==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==when
    assert dict(zip(ct.linear.vars,ct.linear.coeffs))=={k:v for k,v in coeff.items() if v} and list(ct.linear.domain)==domain;ci+=1
for i in range(5):
    assert mp['coordinates'][i]==[2*i,2*i+1]
    for axis in [0,1]:
        v=p.variables[vi];assert v.name==f'{"xy"[axis]}_{i}' and list(v.domain)==[b[axis],b[axis+2]];vi+=1
    linear(mp['support_constraints'][i],{2*i:1,2*i+1:1},[region['x_plus_y_at_least_um'],HIGH])
for i in range(4):linear(mp['x_order_constraints'][i],{2*i:1,2*i+2:-1},[LOW,0])
expected=[('source',[i],pi,source[pi]['inward_faces']) for i in range(5) for pi in relevant]+[('pair',[i,j],0,faces) for i,j in combinations(range(5),2)]
assert len(mp['clauses'])==len(expected)
for saved,(kind,ids,polygon,fs) in zip(mp['clauses'],expected):
    variables=[];cts=[]
    for fi,(a,c,rhs) in enumerate(fs):
        v=p.variables[vi];assert v.name==f'{kind}_{"_".join(map(str,ids))}_{polygon}_{fi}' and list(v.domain)==[0,1]
        x,y=mp['coordinates'][ids[0]];coeff={x:a,y:c}
        if kind=='pair':u,w=mp['coordinates'][ids[1]];coeff={u:a,w:c,x:-a,y:-c}
        variables.append(vi);cts.append(ci);linear(ci,coeff,[LOW,rhs],[vi]);vi+=1
    ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='bool_or' and not ct.enforcement_literal and list(ct.bool_or.literals)==variables
    assert saved=={'kind':kind,'centers':ids,'polygon':polygon,'facet_variables':variables,'facet_constraints':cts,'or_constraint':ci};ci+=1
assert vi==len(p.variables) and ci==len(p.constraints)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'mandatory_centers':5,'minimum_cog_center_distance_um':d,'strictly_inscribed_pair_vertices_verified':64,
    'source_clauses_verified':5*len(relevant),'pair_clauses_verified':10,'source_polygons_skipped_only_with_exact_domain_separation':len(skip),'free_coordinates_and_x_only_copy_order':True,
    'no_hints_or_objective':True,'fixed51_noncog_scope_only':True,'all_real_cog_angles_and_sheet_allocations_covered_by_necessity':True,'model_sha256':digest(MODEL/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
