"""Clip the unresolved upper center cells by exact rational source inequalities."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from h5_exact_convex_clip import subtract,encode
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-noncog-center-regions-20261026';OUT=BASE/'upper-refinement'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'refine.py');start=time.perf_counter()
paths=[BASE/n for n in ['forbidden-polygons.json','cell-cover/sheet-0.json','cell-capacity/sheet-0-group-1/cell-clique.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
    'method':'The upper first-sheet component had a5-cell clique in the10mm conservative cover, not a point witness. Clip every one of its914 cells against all same-sheet convex source forbidden polygons using exact rational halfplanes, preserving legal boundary points and segments. Subtract strict interiors only. Every surviving convex patch is enclosed by its integer-center bounding box, ceil(min) and floor(max); patches with an empty integer bound cannot contain a rounded cog center. No floating free-region diagnostic is used. Save every surviving patch, empty integer box and source cell index for independent coverage verification. This changes the graph geometry, not search budget or seed. No graph search here.'})
source=load(BASE/'cell-cover/sheet-0.json')['groups'][1];polys=load(BASE/'forbidden-polygons.json');rows=[];boxes=[];bbox_to_id={}
for cell_index,b in enumerate(source['cells_um']):
    pieces=[[(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3])]]
    for pi,p in enumerate(polys):
        if p['sheet']!=0:continue
        pb=[min(q[0] for q in p['vertices_um']),min(q[1] for q in p['vertices_um']),max(q[0] for q in p['vertices_um']),max(q[1] for q in p['vertices_um'])]
        if b[2]<pb[0] or b[0]>pb[2] or b[3]<pb[1] or b[1]>pb[3]:continue
        pieces=[q for piece in pieces for q in subtract(piece,p['inward_faces'])]
        if not pieces:break
    saved=[]
    for piece in pieces:
        bb=[math.ceil(min(p[0] for p in piece)),math.ceil(min(p[1] for p in piece)),math.floor(max(p[0] for p in piece)),math.floor(max(p[1] for p in piece))];empty=bb[0]>bb[2] or bb[1]>bb[3];index=None
        if not empty:
            key=tuple(bb)
            if key not in bbox_to_id:bbox_to_id[key]=len(boxes);boxes.append(bb)
            index=bbox_to_id[key]
        saved.append({'polygon_rational':encode(piece),'integer_bounds_um':bb,'empty_integer_bounds':empty,'box_index':index})
    rows.append({'source_cell_index':cell_index,'grid_index':source['grid_indices'][cell_index],'pieces':saved})
write(OUT/'cells.json',rows);write(OUT/'boxes.json',boxes)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'source_cells':len(rows),'rational_pieces':sum(len(r['pieces']) for r in rows),'remaining_integer_boxes':len(boxes),'cells_completely_excluded':sum(not r['pieces'] for r in rows),'integer_empty_pieces':sum(p['empty_integer_bounds'] for r in rows for p in r['pieces']),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
