"""Rational convex clipping, including point and segment boundary pieces."""
from fractions import Fraction as F
def clean(points):
    out=[]
    for p in points:
        if not out or out[-1]!=p:out.append(p)
    if len(out)>1 and out[0]==out[-1]:out.pop()
    return out
def clip(poly,a,b,c):
    if not poly:return []
    out=[];previous=poly[-1];ev=a*previous[0]+b*previous[1]-c
    for p in poly:
        ep=a*p[0]+b*p[1]-c
        if (ev<=0)!=(ep<=0):
            t=F(ev,ev-ep);out.append((previous[0]+t*(p[0]-previous[0]),previous[1]+t*(p[1]-previous[1])))
        if ep<=0:out.append(p)
        previous,ev=p,ep
    return clean(out)
def subtract(poly,faces):
    if any(all(a*x+b*y<=c for x,y in poly) for a,b,c in faces):return [poly]
    if all(all(a*x+b*y>c for x,y in poly) for a,b,c in faces):return []
    outside=[];inside=poly
    for a,b,c in faces:
        q=clip(inside,a,b,c)
        if q:outside.append(q)
        inside=clip(inside,-a,-b,-c)
        if not inside:break
    return outside
def encode(poly):return [[[F(x).numerator,F(x).denominator],[F(y).numerator,F(y).denominator]] for x,y in poly]
def decode(poly):return [(F(*x),F(*y)) for x,y in poly]
