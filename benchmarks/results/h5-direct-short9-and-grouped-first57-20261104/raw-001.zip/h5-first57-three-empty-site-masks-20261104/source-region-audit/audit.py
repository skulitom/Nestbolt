"""Certify every rounded placement region against original source modes and all occupied cog sites."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-three-empty-site-masks-20261104';OUT=BASE/'source-region-audit';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';SLOTS=ROOT/'output/h5-first57-direct-short9-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(points,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in points]
def rational(points):return [tuple(map(F,p)) for p in points]
def support(region,a,cog,n):
    nx,ny=map(F,n);gap=min(x*nx+y*ny for x,y in region)+min(x*nx+y*ny for x,y in a)-max(x*nx+y*ny for x,y in cog);norm=nx*nx+ny*ny
    return gap>0 and gap*gap>=F('.225')**2*norm, float(gap)/math.sqrt(float(norm))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
assert load(SLOTS/'audit/checks.json')['passed']
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json');sites=load(SLOTS/'source-cog-sites.json');library=load(FIRST/'geometry-library.json')
assert [r['identity'] for r in instances]==inventory['moving16_orthogonal_identities'] and sum(r['mode_count'] for r in instances)==96
assert modes=={k:v for k,v in load(FIRST/'family-modes.json').items() if k!='cog'}
for family in ['bracket','insert','cog']:
    shapes=[Polygon(p) for p in canonical[family]];source=Polygon(parts[family]['geometry'][0]['outer'])
    assert unary_union(shapes).symmetric_difference(source).area<1e-7 and abs(sum(p.area for p in shapes)-source.area)<1e-7
cogs=[]
for site in sites:
    t=site['transform'];outer=transform(parts['cog']['geometry'][0]['outer'],t);full_hull=hull(rational(outer));pieces=[transform(p,t) for p in canonical['cog']]
    assert unary_union([Polygon(p) for p in pieces]).symmetric_difference(Polygon(outer)).area<1e-7
    cogs.append({'outer':outer,'hull':full_hull,'pieces':pieces,'rational_pieces':[rational(p) for p in pieces]})
mode_data={};full_nf={};piece_nf={}
for family,items in modes.items():
    for mode in items:
        key=(family,mode['mode']);t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':mode['translation_from_lower_left']};pieces=[transform(p,t) for p in canonical[family]]
        outline=transform(parts[family]['geometry'][0]['outer'],t);assert unary_union([Polygon(p) for p in pieces]).symmetric_difference(Polygon(outline)).area<1e-7
        assert Polygon(outline).hausdorff_distance(Polygon(library[mode['normalized_geometry']]['outer']))<1e-9
        mode_data[key]={'mode':mode,'pieces':pieces,'rational_pieces':[rational(p) for p in pieces]}
        for site,cg in enumerate(cogs):
            for pi,p in enumerate(pieces):full_nf[key,site,pi]=MultiPoint((np.asarray(cg['outer'])[:,None,:]-np.asarray(p)[None,:,:]).reshape(-1,2)).convex_hull
proofs=[];summary=[];minimum=math.inf;fallback=0;disabled=[];mask_pairs=set()
for gid in range(10):
    data=load(BASE/'geometries'/f'{gid:02d}.json');assert data['geometry']==gid
    eligible=[(k,v) for k,v in mode_data.items() if v['mode']['normalized_geometry']==gid];assert eligible
    b=eligible[0][1]['mode']['lower_left_bounds'];assert data['domain']==[b[0][0],b[1][0],b[0][1],b[1][1]]
    coverage=[]
    for mask in data['masks']:
        assert mask['mask'].bit_count()<=3 and mask['required_empty_sites']==[i for i in range(15) if mask['mask']&(1<<i)]
        coverage+=mask['regions']
    assert sorted(coverage)==list(range(len(data['regions'])))
    checked=0
    for index,region in enumerate(data['regions']):
        assert region['region']==index and region['required_empty_mask'].bit_count()<=3
        empty=set(region['required_empty_sites']);assert empty=={i for i in range(15) if region['required_empty_mask']&(1<<i)}
        compatible=[pair for pair in combinations(range(15),3) if empty<=set(pair)];assert compatible;mask_pairs.update(compatible)
        rounded=hull([tuple(F(round(v,9)) for v in p) for p in region['vertices']])
        if len(rounded)<3:disabled.append([gid,index]);continue
        shape=Polygon([(float(x),float(y)) for x,y in rounded]);assert shape.is_valid and shape.area>0
        for key,moving in eligible:
            for si,cg in enumerate(cogs):
                if si in empty:continue
                for pi,source in enumerate(moving['rational_pieces']):
                    seg=list(shapely.shortest_line(full_nf[key,si,pi],shape).coords);accepted=False
                    if len(seg)==2:
                        dx,dy=seg[1][0]-seg[0][0],seg[1][1]-seg[0][1];length=math.hypot(dx,dy)
                        if length>0:
                            n=[dx/length,dy/length];accepted,gap=support(rounded,source,cg['hull'],n)
                    if accepted:
                        proofs.append([gid,index,key[0],key[1],si,pi,-1,*n]);minimum=min(minimum,gap);checked+=1
                    else:
                        fallback+=1
                        for ci,cp in enumerate(cg['rational_pieces']):
                            cache=(key,si,pi,ci)
                            if cache not in piece_nf:piece_nf[cache]=MultiPoint((np.asarray(cg['pieces'][ci])[:,None,:]-np.asarray(moving['pieces'][pi])[None,:,:]).reshape(-1,2)).convex_hull
                            seg=list(shapely.shortest_line(piece_nf[cache],shape).coords);assert len(seg)==2,(gid,index,key,si,pi,ci)
                            dx,dy=seg[1][0]-seg[0][0],seg[1][1]-seg[0][1];length=math.hypot(dx,dy);assert length>0
                            n=[dx/length,dy/length];valid,gap=support(rounded,source,cp,n);assert valid,(gid,index,key,si,pi,ci,gap)
                            proofs.append([gid,index,key[0],key[1],si,pi,ci,*n]);minimum=min(minimum,gap);checked+=1
    summary.append({'geometry':gid,'regions':len(data['regions']),'source_support_proofs':checked})
assert mask_pairs==set(combinations(range(15),3))
write(OUT/'source-support-certificates.json',proofs);write(OUT/'geometry-summary.json',summary);write(OUT/'disabled-rounded-regions.json',disabled)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PIECES,FIRST/'family-modes.json',FIRST/'geometry-library.json',SLOTS/'source-cog-sites.json',SLOTS/'audit/plan.json',SLOTS/'audit/checks.json']+[BASE/n for n in ['plan.json','checks.json','family-modes.json','instances.json','inventory.json']]+[BASE/'geometries'/f'{gid:02d}.json' for gid in range(10)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently transform original convex source pieces for all12 orthogonal source modes and all15 cog poses. For each rounded convex placement region, certify separation from every cog site not declared empty by its mask. Prefer one exact rational support proof against the entire original cog hull; when that fails, certify all21 original cog convex pieces. Preserve source-transform aliases separately. Every proof uses exact rational arithmetic on the transformed source vertices and rounded region vertices. Check original source partition coverage and all455 empty-site options. Regions collapsing after rounding are explicitly disabled before modeling; no global coverage claim.'})
result={'passed':True,'seconds':time.perf_counter()-started,'orthogonal_source_modes_verified':len(mode_data),'original_cog_sites_verified':15,'rounded_regions_reviewed':sum(s['regions'] for s in summary),'disabled_degenerate_regions':len(disabled),'exact_original_source_support_proofs':len(proofs),'full_cog_hull_fallbacks_to_piece_proofs':fallback,'minimum_certified_source_gap_mm':minimum,'all455_empty_site_triples_represented':True,'all_mode_aliases_separately_verified':True,'global_coverage_claimed':False,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
