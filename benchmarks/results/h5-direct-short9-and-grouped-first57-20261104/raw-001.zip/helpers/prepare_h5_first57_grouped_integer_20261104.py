"""Integer source regions and pair-cover groups of rigid source rectangles."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-grouped-integer-20261104'
REG=ROOT/'output/h5-first57-three-empty-site-masks-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(REG/'source-region-audit/checks.json')['passed'] and load(PRE/'audit/checks.json')['passed']
assert load(REG/'source-region-audit/disabled-rounded-regions.json')==[]
assert load(PRIOR/'audit-v3/checks.json')['passed']
OUT.mkdir();started=time.perf_counter()
origin=[F(0),F(2100)];envelope=[F(1500),F(900)];grid=100;scale=100000;eps=F('1e-7')
modes=load(REG/'family-modes.json')
converted={f:[{**m,'integer_lower_left_bounds':[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(m['lower_left_bounds'])]} for m in opts] for f,opts in modes.items()}
templates=[];planes=0;max_error=F(0);max_activity=0
for gid in range(10):
    regions=[]
    for source in load(REG/'geometries'/f'{gid:02d}.json')['regions']:
        poly=hull([tuple(F(round(x,9)) for x in p) for p in source['vertices']]);assert len(poly)>=3
        r={k:source[k] for k in ['region','required_empty_mask','required_empty_sites']}
        r['hull_vertices']=[[str(x),str(y)] for x,y in poly];r['planes']=[]
        for edge,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));n=[dy/den,-dx/den];raw=[round(v*scale) for v in n]
            error=sum(abs(v-F(c,scale))*limit for v,c,limit in zip(n,raw,envelope))
            rhs=sum(v*(x-o) for v,x,o in zip(n,a,origin));div=math.gcd(*map(abs,raw));assert div>0
            co=[v//div for v in raw];upper=math.floor((rhs-error-eps)*scale*grid)//div
            activity=sum(abs(v)*int(limit*grid) for v,limit in zip(co,envelope))
            assert activity<2**53 and abs(upper)<2**53
            r['planes'].append({'edge':edge,'coefficients':co,'upper':upper,'unreduced_coefficients':raw,'divisor':div,
                'exact_infinity_normal':list(map(str,n)),'rounding_error_bound_mm':str(error)})
            max_error=max(max_error,error);max_activity=max(max_activity,activity);planes+=1
        regions.append(r)
    templates.append({'geometry':gid,'regions':regions})
old_rect=load(PRIOR/'mode-rectangles.json')
rectangles={f:[{**m,'rectangles':[{**r,'outward_offsets_grid':[math.floor(F(v)*grid) if k<2 else math.ceil(F(v)*grid) for k,v in enumerate(r['exact_affine_bounds_mm'])]} for r in m['rectangles']]} for m in opts] for f,opts in old_rect.items()}
instances=load(REG/'instances.json')
components=[]
for owner,instance in enumerate(instances):
    for piece in range(2 if instance['identity'][0]=='bracket' else 1):
        components.append({'component':len(components),'owner':owner,'identity':instance['identity'],'piece':piece})
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']]
brackets=[i for i,r in enumerate(instances) if r['identity'][0]=='bracket'];assert len(brackets)==8
labels={owner:i+1 for i,owner in enumerate(brackets)}
groups=[]
for row in range(16):
    chosen=[c['component'] for c in components if c['identity'][0]=='insert' or c['piece']==((row&labels[c['owner']]).bit_count()%2)]
    assert len(chosen)==16 and len({components[i]['owner'] for i in chosen})==16
    groups.append({'row':row,'components':chosen})
coverage=[{'components':p['components'],'groups':[g['row'] for g in groups if set(p['components'])<=set(g['components'])]} for p in pairs]
assert len(components)==24 and len(pairs)==268 and min(len(p['groups']) for p in coverage)==4
for name,value in [('family-modes.json',converted),('unary-templates.json',templates),('mode-rectangles.json',rectangles),
    ('components.json',components),('component-pairs.json',pairs),('pair-cover-groups.json',groups),('pair-cover-certificates.json',coverage)]:
    write(OUT/name,value)
for name in ['inventory.json','instances.json']:shutil.copyfile(REG/name,OUT/name)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py']+[REG/n for n in ['plan.json','checks.json','family-modes.json','instances.json','inventory.json','source-region-audit/plan.json','source-region-audit/checks.json','source-region-audit/disabled-rounded-regions.json']]+[REG/'geometries'/f'{i:02d}.json' for i in range(10)]+[PRE/'audit/plan.json',PRE/'audit/checks.json']+[PRIOR/n for n in ['plan.json','mode-rectangles.json','audit-v3/plan.json','audit-v3/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Preserve all455 choices of three empty cog sites and sixteen orthogonal originals. Convert certified rounded source hulls to inward local integer planes on a0.01mm grid. Outward-round source component rectangles. Sixteen binary pair-cover rows each select exactly one component per original; every different-owner component pair appears in at least four rows. Future global NoOverlap2D constraints on these groups, with0.23mm extension at each right/top edge, enforce every required pair without artificial same-owner spacing. Model will share each geometry/mask selector across its region choices to avoid repeated site implications. Independently verify source implications and full group coverage before any model.',
    'world_origin_mm':[0,2100],'grid_units_per_mm':grid,'normal_scale':scale,'local_domain_envelope_mm':[1500,900],'plane_inset_mm':str(eps),
    'rectangle_gap_grid':23,'required_empty_sites':3,'site_selections':455,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':time.perf_counter()-started,'cached_regions':3941,'integer_planes':planes,'instance_source_modes':96,
    'rigid_components':24,'different_owner_component_pairs':268,'pair_cover_groups':16,'components_per_group':16,'minimum_pair_coverage':4,
    'maximum_normal_error_mm':float(max_error),'maximum_integer_activity':max_activity,'independent_audit_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
