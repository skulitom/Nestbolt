"""Seal a direct short9 construction and the sole grouped first57 call."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-direct-short9-and-grouped-first57-20261104';OUT=ROOT/'benchmarks/results'/NAME
PRE=ROOT/'output/h5-first57-direct-short9-20261104';REG=ROOT/'output/h5-first57-three-empty-site-masks-20261104';BASE=ROOT/'output/h5-first57-grouped-integer-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104','h5-independent-cog-rows-and-expanded-domains-20261104','h5-expanded-joint-and-staged-row-constructions-20261104','h5-row-reductions-and-three-cog-allocation-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
assert load(PRE/'audit/checks.json')['passed'] and load(REG/'source-region-audit/checks.json')['passed']
for folder in ['geometry-audit','model-audit','response-audit']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json')
assert response['closed_solver_calls']==1 and response['solver_status']=='UNKNOWN' and response['assignments']==0
assert response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for name in ['h5-first57-direct-short9-20261104','h5-first57-direct-short9-process-20261104','h5-first57-three-empty-site-masks-20261104','h5-first57-three-empty-masks-process-20261104','h5-first57-grouped-integer-20261104','h5-first57-grouped-integer-process-20261104','h5-first57-grouped-model-process-20261104']:
    folder=ROOT/'output'/name
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_first57*20261104.py','h5_grouped_model_assignment_reader_20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,'h5-first57-grouped-checkpoint-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(PRE/'audit/checks.json','direct-short9-audit.json'),(PRE/'inventory.json','inventory.json'),(PRE/'short9-source.json','short9-source.json'),
    (PRE/'module-spec.json','short9-module-spec.json'),(REG/'source-region-audit/checks.json','source-region-audit.json'),
    (BASE/'geometry-audit/checks.json','integer-and-pair-cover-audit.json'),(BASE/'pair-cover-groups.json','pair-cover-groups.json'),
    (BASE/'model/checks.json','model.json'),(BASE/'model-audit/checks.json','model-audit.json'),
    (BASE/'model/final-preparation-charges.json','preparation-charges.json'),(BASE/'response-audit/checks.json','response-audit.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_call_must_not_be_repeated':True,'closed_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],
    'direct_short9_is_source_valid':True,'next_method':'Prepare a necessary continuous-source rectangle cover for orthogonal mover anchors against the fifteen fixed cog sites. Use exact rectangles contained inside original cog source pieces and exact shrunken source bodies for each bracket/insert mode. Track blocked cog-site masks over all open coordinate intervals and boundary points. Such an outward necessary domain can support fresh capacity proofs across the455 three-empty-site choices; the current conservative positive regions cannot. Independently prove original-source containment, exhaustive coverage and any resulting capacity bound before removing a site choice. Reuse the fast direct short9, keep all16 first-sheet movers mandatory, and retain every preparation cost. Do not reseed or extend the closed grouped model.',
    'necessary_cover_prepared':False,'new_first57_site_choices':455,'new_first57_site_choices_excluded':0,
    'older_fixed13_cog_frontier':{'site_choices':2,'count_distributions':3},'remaining_allocation_candidates':440,
    'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'direct_short9_valid':True,'direct_short9_complete_process_seconds':load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds'],
    'new_source_regions':3941,'source_support_proofs':158834,'closed_solver_calls':1,'solver_status':'UNKNOWN','assignments':0,
    'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,
    'new_first57_site_choices':455,'remaining_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-first57-grouped-checkpoint-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 direct short9 and grouped first57:** [independent audits]({link}) verify a new explicit 4-bracket/2-insert/3-cog short sheet in a complete 0.296828 s preparation process. Its complementary first57 retains all16 orthogonal movers and all455 choices of twelve cog sites. Fresh geometry has3,941 regions and158,834 exact source supports. Sixteen global rectangle groups cover all268 different-owner component pairs. Every field of the35,735-variable/143,671-constraint model passes audit. Its sole call closes UNKNOWN with no assignment; the0.149519 s solve-slice overrun is preserved, while complete algorithm/shared totals56.166951/56.264559 s remain within60/90 s. No site choice or allocation is excluded. Fresh necessary-source capacity bounds are the next method to assess. Full66 validation and H2/H5 remain open at60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [row reductions and three-cog allocation](../benchmarks/results/h5-row-reductions-and-three-cog-allocation-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [direct short9 and grouped first57](../benchmarks/results/{NAME}.md).',1)
a='The fixed-cog construction retains 2 site choices and 3 count distributions.\nExpanded-row reductions are audited but do not justify another call. The new\n4/4/3 short-sheet call closes UNKNOWN; an exact proof limits the older fixed\nfour-bracket/three-cog core to two inserts. A new construction must move the core.\nThe short sheet now passes independent original-source checks for five brackets,\nfour inserts and two cogs. Its matching 55-part first sheet remains to construct.'
b='The earlier fixed13-cog construction retains 2 site choices and 3 distributions.\nA new direct4/2/3 short sheet passes source checks in0.297 s. Its grouped first57\nmodel retains all455 twelve-cog selections but closes UNKNOWN without a placement.\nFresh necessary-source capacity bounds remain to prepare before further search.\nBoth the valid5/4/2 short sheet and new direct4/2/3 short sheet are preserved;\nthe matching first55 and first57 constructions remain unresolved.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
