from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
s=(OUT/'run_h5_integer_mode_regions_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-short11-integer-mode-regions-20261029','h5-first57-grouped-integer-20261104')
s=s.replace('h5_source_projection_short_core_reader_20261029','h5_grouped_model_assignment_reader_20261104')
s=s.replace('check_h5_integer_mode_candidate_20261029.py','check_h5_first57_grouped_candidate_20261104.py')
s=s.replace("load(MODEL / 'checks.json')['preparation_seconds_charged']","load(MODEL/'final-preparation-charges.json')['preparation_seconds_charged']")
s=s.replace("BASE / 'plan.json', MODEL / 'plan.json'","BASE / 'plan.json', MODEL/'final-preparation-charges.json', MODEL / 'plan.json'")
s=s.replace('remaining = 60-(time.perf_counter()-started)-3','remaining = 60-(time.perf_counter()-started)-4')
s=s.replace("'source_validation_reserve_seconds': 3","'source_validation_reserve_seconds': 4")
s=s.replace("assert not checked['failed_constraints']","assert not checked['failed_constraints'] and not checked['variable_failures']")
s=s.replace("['source_valid11']","['source_valid66']")
s=s.replace("'source_checker_calls': source_checks, 'source_valid11': source_valid, 'source_valid66': False,","'source_checker_calls': source_checks, 'source_valid66': source_valid,")
with (OUT/'run_h5_first57_grouped_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
