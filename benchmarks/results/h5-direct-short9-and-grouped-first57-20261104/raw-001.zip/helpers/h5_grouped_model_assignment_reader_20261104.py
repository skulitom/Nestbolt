"""Independent integer reader for linear, interval and global rectangle constraints."""
from itertools import combinations
def violations(model,values):
    assert len(values)==len(model.variables)
    variable_failures=[i for i,(v,x) in enumerate(zip(model.variables,values)) if not any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))]
    failed=[];active=inactive=pair_checks=0
    def expression(e):return e.offset+sum(c*values[i] for i,c in zip(e.vars,e.coeffs))
    def enabled(c):return all(values[i]==1 if i>=0 else values[-i-1]==0 for i in c.enforcement_literal)
    for i,c in enumerate(model.constraints):
        if not enabled(c):inactive+=1;continue
        active+=1;kind=c.WhichOneof('constraint')
        if kind=='linear':
            value=sum(k*values[v] for v,k in zip(c.linear.vars,c.linear.coeffs))
            good=any(a<=value<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='interval':
            start,size,end=map(expression,[c.interval.start,c.interval.size,c.interval.end])
            good=size>=0 and start+size==end
        elif kind=='no_overlap_2d':
            rectangles=[]
            for x,y in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                xc,yc=model.constraints[x],model.constraints[y]
                assert xc.WhichOneof('constraint')==yc.WhichOneof('constraint')=='interval'
                if enabled(xc) and enabled(yc):
                    rectangles.append((expression(xc.interval.start),expression(yc.interval.start),expression(xc.interval.end),expression(yc.interval.end)))
            good=True
            for a,b in combinations(rectangles,2):
                pair_checks+=1
                if a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]:continue
                good=False
        else:raise AssertionError('Unexpected constraint: '+str(kind))
        if not good:failed.append(i)
    return {'variable_failures':variable_failures,'failed_constraints':failed,'active_constraints':active,'inactive_constraints':inactive,'global_rectangle_pair_checks':pair_checks}
