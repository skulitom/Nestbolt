from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
s=(OUT/'run_h5_first57_direct_short9_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-direct-short9-process-20261104','h5-first57-grouped-integer-process-20261104')
s=s.replace('prepare_h5_first57_direct_short9_20261104.py','prepare_h5_first57_grouped_integer_20261104.py')
s=s.replace("'maximum_process_seconds':10","'maximum_process_seconds':20").replace('timeout=10','timeout=20').replace('elapsed-10','elapsed-20')
with (OUT/'run_h5_first57_grouped_integer_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
