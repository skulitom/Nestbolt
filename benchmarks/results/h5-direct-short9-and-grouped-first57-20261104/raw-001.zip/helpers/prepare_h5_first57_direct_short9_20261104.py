"""Direct source modules for short9; re-inventory the complementary first57."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from copy import deepcopy
from collections import Counter
import json,math,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-direct-short9-20261104'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter()
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(FIRST/'plan.json');stock=spec['source_stocks']['sheet-1']
g=.23;width=330+2*g;height=310+2*g;origin=[stock[0]+.025,stock[1]+.025]
rows=[];modules=[]
for n,brackets in enumerate([[7,8],[10,11]]):
    x=origin[0]+n*(width+g);y=origin[1]
    # Turned bracket A: left stem and top arm. Bracket B: right stem and bottom arm.
    local=[{'part_id':'bracket','copy_index':brackets[0],'sheet_id':'sheet-1','transform':{'rotation_radians':math.radians(270),'mirrored':False,'translation':[x,y+10+2*g+300]}},
           {'part_id':'bracket','copy_index':brackets[1],'sheet_id':'sheet-1','transform':{'rotation_radians':math.radians(90),'mirrored':False,'translation':[x+80+2*g+250,y]}},
           {'part_id':'insert','copy_index':4+n,'sheet_id':'sheet-1','transform':{'rotation_radians':0.,'mirrored':False,'translation':[x+75+g,y+100+g]}}]
    rows.extend(local);modules.append({'index':n,'origin':[x,y],'bounds':[x,y,x+width,y+height],'identities':[[r['part_id'],r['copy_index']] for r in local]})
angle=math.radians(7);c,s=math.cos(angle),math.sin(angle)
vertices=[(x*c-y*s,x*s+y*c) for x,y in parts['cog']['geometry'][0]['outer']]
offset=[-min(p[k] for p in vertices) for k in [0,1]]
pitch=258.86;left=origin[0]+2*(width+g)
for n,copy in enumerate([0,13,14]):
    rows.append({'part_id':'cog','copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':angle,'mirrored':False,'translation':[left+n*pitch+offset[0],origin[1]+offset[1]]}})
short_ids=[[r['part_id'],r['copy_index']] for r in rows]
short_check=audit(job,rows,{'sheet-1':stock},spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,short_ids)))
write(OUT/'short9-source.json',rows);write(OUT/'short9-source-checks.json',short_check);assert short_check['valid']
fixed=load(FIRST/'fixed29.json');fixed_ids=[[r['part_id'],r['copy_index']] for r in fixed]
universe=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])]
first_ids=[r for r in universe if r not in short_ids]
cog_ids=[r for r in first_ids if r[0]=='cog'];orthogonal=[r for r in first_ids if r not in fixed_ids+cog_ids]
assert len(first_ids)==57 and len(cog_ids)==12 and len(orthogonal)==16 and len(fixed_ids)==29
assert Counter(r[0] for r in orthogonal)=={'bracket':8,'insert':8}
assert len({tuple(r) for r in short_ids+fixed_ids+cog_ids+orthogonal})==66
inventory={'full66_identities':universe,'short9_identities':short_ids,'first57_identities':first_ids,
    'fixed29_identities':fixed_ids,'required_cog12_identities':cog_ids,'moving16_orthogonal_identities':orthogonal,
    'short_counts':[4,2,3],'first_counts':[18,8,19,12],'all66_originals_accounted_once':True}
sites=load(SLOTS/'source-cog-sites.json')
# A reference control contains all15 cog sites, independently of the sheet split.
# This certifies every possible 12-site subset; it is not combined with short9.
control=deepcopy(sites)
for i,r in enumerate(control):r['copy_index']=i
reference=audit(job,fixed+control,{'sheet-0':spec['source_stocks']['sheet-0']},spec['required_pair_gap_mm'],spec['stock_guard_mm'],
    list(map(tuple,fixed_ids))+[('cog',i) for i in range(15)])
write(OUT/'all15-reference44-source.json',fixed+control);write(OUT/'all15-reference44-checks.json',reference);assert reference['valid']
write(OUT/'inventory.json',inventory);write(OUT/'module-spec.json',{'gap_mm':g,'module_width_mm':width,'module_height_mm':height,'origin_mm':origin,'modules':modules,'cog_row_left_mm':left,'cog_pitch_mm':pitch,'cog_rotation_radians':angle,'cog_translation_from_lower_left':offset})
for name in ['fixed29.json','family-modes.json','geometry-library.json']:shutil.copyfile(FIRST/name,OUT/name)
shutil.copyfile(SLOTS/'source-cog-sites.json',OUT/'source-cog-sites.json')
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[FIRST/n for n in ['plan.json','checks.json','fixed29.json','family-modes.json','geometry-library.json','audit/plan.json','audit/checks.json']]+[SLOTS/n for n in ['plan.json','checks.json','source-cog-sites.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Construct short9 directly from two explicit turned-bracket/insert modules and three original cogs in a straight row at7 degrees and258.86mm pitch. No historical short placement, optimizer output or repair is read. All source transforms and holes are preserved. Re-inventory the complementary first57 with fixed29, twelve cogs chosen from fifteen mutually source-valid reference sites, and sixteen independently movable orthogonal originals. Fresh placement-region masks may require up to three empty cog sites (all455 triples); no prior two-empty-site capacity or negative result transfers. Independent source/preparation/model audits and full charged60/90-second limits remain mandatory.',
    'source_stocks':spec['source_stocks'],'construction_stock':spec['construction_stock'],'required_pair_gap_mm':spec['required_pair_gap_mm'],'stock_guard_mm':spec['stock_guard_mm'],
    'candidate_cog_sites':15,'required_cogs':12,'empty_sites':3,'site_selections':455,
    'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'solver_calls':0,'native_calls':0})
checks={'passed':True,'seconds_including_source_controls':time.perf_counter()-started,'direct_short9_source_valid':True,
    'short_pairs':short_check['same_sheet_pairs'],'short_stock_edges':short_check['stock_edges'],'short_cutouts':short_check['cutouts'],'short_hole_vertices':short_check['hole_vertices'],
    'short_minimum_gap_mm':short_check['minimum_pair_gap_mm'],'short_minimum_stock_mm':short_check['minimum_extra_stock_mm'],
    'reference44_source_valid':True,'reference_pairs':reference['same_sheet_pairs'],'reference_stock_edges':reference['stock_edges'],
    'reference_cutouts':reference['cutouts'],'reference_hole_vertices':reference['hole_vertices'],
    'required_first_originals':57,'moving_orthogonal_originals':16,'source_mode_options':96,'required_cogs':12,'candidate_sites':15,'site_selections':455,
    'all66_originals_accounted_once':True,'old_short_optimization_results_used':False,'independent_audit_pending':True,'source_valid66':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
