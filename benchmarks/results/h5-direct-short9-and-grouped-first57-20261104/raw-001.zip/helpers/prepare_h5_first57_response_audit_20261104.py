from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
s=(OUT/'audit_h5_short443_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-short443-integer-regions-20261104','h5-first57-grouped-integer-20261104')
s=s.replace("BASE/'audit/plan.json'","ROOT/'output/h5-first57-direct-short9-20261104/audit/plan.json'")
s=s.replace("BASE/'final-preparation.json'","MODEL/'final-preparation-charges.json'")
s=s.replace("ROOT/'output/h5-short443-preparation-process-20261104/opened.json',ROOT/'output/h5-short443-model-process-20261104/opened.json'",
    "ROOT/'output/h5-first57-direct-short9-process-20261104/opened.json',ROOT/'output/h5-first57-three-empty-masks-process-20261104/opened.json',ROOT/'output/h5-first57-grouped-integer-process-20261104/opened.json',ROOT/'output/h5-first57-grouped-model-process-20261104/opened.json'")
s=s.replace("for folder in ['audit','geometry-audit','model-audit']","for folder in ['geometry-audit','model-audit']")
a=s.index("assert charges['prior_source_mode_and_template_preparation_seconds']")
b=s.index("charge=sum(charges.values())",a)
s=s[:a]+"""expected={
    'fixed_source_mode_geometry_preparation_seconds':load(ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight/checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight/checks.json')['seconds']}
for folder,key in [
    ('h5-first57-direct-short9-process-20261104','direct_short9_and_inventory_complete_process_seconds'),
    ('h5-first57-three-empty-masks-process-20261104','three_empty_site_mask_complete_process_seconds'),
    ('h5-first57-grouped-integer-process-20261104','integer_and_pair_cover_complete_process_seconds'),
    ('h5-first57-grouped-model-process-20261104','model_complete_process_seconds')]:
    p=load(ROOT/'output'/folder/'process.json')
    assert p['exit_code']==0 and not p['timeout'] and p['closed']
    expected[key]=p['complete_process_seconds']
assert charges==expected
"""+s[b:]
s=s.replace("ledger['internal_model_build_seconds_replaced_by_complete_process']==load(MODEL/'preparation-charges.json')['cp_model_build_internal_seconds']<charges['cp_model_complete_process_seconds']",
    "ledger['internal_model_seconds_replaced']==load(MODEL/'preparation-charges.json')['model_internal_seconds_pending_complete_process_charge']<charges['model_complete_process_seconds']")
s=s.replace("data['algorithm_seconds']==25 and data['shared_seconds']==35 and data['source_validation_reserve_seconds']==3","data['algorithm_seconds']==60 and data['shared_seconds']==90 and data['source_validation_reserve_seconds']==4")
# BASE defines the same call cap but only MODEL defines the validation reserve.
s=s.replace("[load(BASE/'plan.json'),ledger,opened,budget]","[load(MODEL/'plan.json'),ledger,opened,budget]")
s=s.replace('7071','35735').replace('23988','143671')
s=s.replace('25-charge-3','60-charge-4').replace("preparation']-25","preparation']-60").replace("preparation']-35","preparation']-90")
s=s.replace("['source_valid11','source_valid66','any_allocation_excluded','H5_complete']","['source_valid66','any_allocation_excluded','H5_complete']")
a=s.index("failure=load(BASE/'audit-preflight-failure.json')")
b=s.index("write(OUT/'source-bindings.json'",a)
s=s[:a]+s[b:]
s=s.replace(",BASE/'audit-preflight-failure.json',ROOT/failure['script']","")
s=s.replace("'source_valid11':False,","")
with (OUT/'audit_h5_first57_grouped_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
