"""Read every grouped-packing protobuf variable, constraint and source mapping."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-grouped-integer-20261104';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,BASE/'geometry-audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'geometry-audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes())
assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'}
mapping=load(MODEL/'mapping.json');modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json')
templates=load(BASE/'unary-templates.json');rectangles=load(BASE/'mode-rectangles.json');raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,2100] and mapping['rectangle_gap_grid']==23
assert len(mapping['owners'])==len(instances)==16
used_v=set();used_c=set()
def variable(i,name,domain):
    assert i not in used_v;used_v.add(i);v=p.variables[i]
    assert {f.name for f,x in v.ListFields()}=={'name','domain'} and v.name==name and list(v.domain)==domain
def linear(i,co,lo,hi,guard=None):
    assert i not in used_c;used_c.add(i);c=p.constraints[i]
    assert {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert list(c.enforcement_literal)==([] if guard is None else [guard])
    expected={k:v for k,v in co.items() if v}
    assert len(c.linear.vars)==len(expected) and dict(zip(c.linear.vars,c.linear.coeffs))==expected
    assert list(c.linear.domain)==[lo,hi]
def expr(actual,index,offset=0):
    assert list(actual.vars)==[index] and list(actual.coeffs)==[1] and actual.offset==offset
mode_count=region_count=mask_count=plane_count=site_links=0
for i,(o,instance) in enumerate(zip(mapping['owners'],instances)):
    assert o['owner']==i and o['identity']==instance['identity'] and o['positions']==[2*i,2*i+1]
    fm=modes[o['identity'][0]]
    for axis in [0,1]:
        variable(o['positions'][axis],f'owner_{i}_axis_{axis}',[min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm)])
    assert len(o['modes'])==len(fm)
    for actual,source in zip(o['modes'],fm):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source
        selector=actual['selector'];variable(selector,f'mode_{i}_{source["mode"]}',[0,1])
        assert len(actual['stock_constraints'])==2
        for axis,(lo,hi) in enumerate(source['integer_lower_left_bounds']):linear(actual['stock_constraints'][axis],{o['positions'][axis]:1},lo,hi,selector)
        mode_count+=1
    linear(o['one_mode_constraint'],{m['selector']:1 for m in o['modes']},1,1)
empty=mapping['empty_site_selectors'];assert len(empty)==15
for i,v in enumerate(empty):variable(v,f'empty_site_{i}',[0,1])
linear(mapping['exactly_three_empty_constraint'],{v:1 for v in empty},3,3)
for o in mapping['owners']:
    i=o['owner'];gids=sorted({m['normalized_geometry'] for m in o['modes']})
    expected_masks=[(gid,mask) for gid in gids for mask in sorted({r['required_empty_mask'] for r in templates[gid]['regions']})]
    assert [(g['geometry'],g['mask']) for g in o['mask_groups']]==expected_masks
    expected_regions=[(gid,r['region']) for gid,mask in expected_masks for r in templates[gid]['regions'] if r['required_empty_mask']==mask]
    assert [(r['geometry'],r['region']) for r in o['regions']]==expected_regions
    for g in o['mask_groups']:
        gid,mask,selector=g['geometry'],g['mask'],g['selector'];variable(selector,f'mask_{i}_{gid}_{mask}',[0,1])
        sites=[s for s in range(15) if mask&(1<<s)]
        assert g['required_empty_sites']==sites and len(g['site_implications'])==len(sites)
        for ct,site in zip(g['site_implications'],sites):linear(ct,{selector:1,empty[site]:-1},MIN,0);site_links+=1
        selected=[r for r in o['regions'] if r['geometry']==gid and r['mask']==mask]
        assert g['region_selectors']==[r['selector'] for r in selected] and selected
        for r in selected:
            source=templates[gid]['regions'][r['region']]
            assert source['region']==r['region'] and source['required_empty_mask']==mask and r['mask_selector']==selector
            rs=r['selector'];variable(rs,f'region_{i}_{gid}_{r["region"]}',[0,1])
            assert len(r['plane_constraints'])==len(source['planes'])
            for ct,plane in zip(r['plane_constraints'],source['planes']):
                linear(ct,{o['positions'][k]:v for k,v in enumerate(plane['coefficients'])},MIN,plane['upper'],rs);plane_count+=1
            region_count+=1
        linear(g['one_region_when_mask_constraint'],{selector:-1,**{r['selector']:1 for r in selected}},0,0);mask_count+=1
    assert [g['geometry'] for g in o['geometry_marginals']]==gids
    for g in o['geometry_marginals']:
        gid=g['geometry'];ms=[m['selector'] for m in o['modes'] if m['normalized_geometry']==gid];gs=[q['selector'] for q in o['mask_groups'] if q['geometry']==gid]
        assert g['mode_selectors']==ms and g['mask_selectors']==gs
        linear(g['constraint'],{**{m:-1 for m in ms},**{q:1 for q in gs}},0,0)
assert len(mapping['components'])==len(raw_components)==24
links=0
for actual,raw in zip(mapping['components'],raw_components):
    for k,v in raw.items():assert actual[k]==v
    owner=mapping['owners'][raw['owner']];family=owner['identity'][0];piece=raw['piece'];coords=actual['coordinates']
    assert len(coords)==4
    for k,v in enumerate(coords):
        axis=k%2
        lo=min(m['integer_lower_left_bounds'][axis][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        hi=max(m['integer_lower_left_bounds'][axis][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        variable(v,f'component_{raw["component"]}_edge_{k}',[lo,hi])
    assert len(actual['mode_links'])==len(owner['modes'])
    for link,m in zip(actual['mode_links'],owner['modes']):
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid']
        assert link['mode']==m['mode'] and link['selector']==m['selector'] and link['offsets']==offsets and len(link['constraints'])==4
        for k,(ct,value) in enumerate(zip(link['constraints'],offsets)):linear(ct,{coords[k]:1,owner['positions'][k%2]:-1},value,value,m['selector']);links+=1
    assert len(actual['sizes'])==len(actual['size_links'])==len(actual['interval_constraints'])==2
    for axis in [0,1]:
        possible=[rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis+2]-rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis]+23 for m in owner['modes']]
        size=actual['sizes'][axis];variable(size,f'component_{raw["component"]}_size_{axis}',[min(possible),max(possible)])
        linear(actual['size_links'][axis],{size:1,coords[axis+2]:-1,coords[axis]:1},23,23)
        index=actual['interval_constraints'][axis];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
        assert {f.name for f,v in ct.ListFields()}=={'name','interval'} and ct.name==f'component_{raw["component"]}_interval_{axis}'
        expr(ct.interval.start,coords[axis]);expr(ct.interval.size,size);expr(ct.interval.end,coords[axis+2],23)
assert len(mapping['packing_groups'])==len(groups)==16
for actual,source in zip(mapping['packing_groups'],groups):
    assert {k:v for k,v in actual.items() if k!='constraint'}==source
    index=actual['constraint'];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
    assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'}
    assert list(ct.no_overlap_2d.x_intervals)==[mapping['components'][i]['interval_constraints'][0] for i in source['components']]
    assert list(ct.no_overlap_2d.y_intervals)==[mapping['components'][i]['interval_constraints'][1] for i in source['components']]
expected_symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in mapping['owners'] if o['identity'][0]==family),key=lambda o:o['identity'][1])
    expected_symmetry.extend((family,a['owner'],b['owner']) for a,b in zip(peers,peers[1:]))
assert [(s['family'],*s['owners']) for s in mapping['symmetry_constraints']]==expected_symmetry
for s in mapping['symmetry_constraints']:
    a,b=s['owners'];linear(s['constraint'],{2*a:1,2*b:-1},MIN,0)
assert used_v==set(range(len(p.variables))) and used_c==set(range(len(p.constraints)))
assert len(p.variables)==35735 and len(p.constraints)==143671 and mode_count==96 and region_count==31528 and mask_count==3920 and plane_count==129256 and site_links==9440 and links==640
ledger=load(MODEL/'final-preparation-charges.json')
for name,h in ledger['inputs'].items():assert digest(ROOT/name)==h
old=load(MODEL/'preparation-charges.json');internal=old.pop('model_internal_seconds_pending_complete_process_charge')
process=load(ROOT/'output/h5-first57-grouped-model-process-20261104/process.json');assert process['exit_code']==0 and not process['timeout']
old['model_complete_process_seconds']=process['complete_process_seconds']
assert ledger['charges']==old and ledger['internal_model_seconds_replaced']==internal and ledger['preparation_seconds_charged']==sum(old.values())
assert ledger['algorithm_seconds']==60 and ledger['shared_seconds']==90 and ledger['source_validation_reserve_seconds']==4 and ledger['maximum_calls']==1 and not ledger['retry_permitted']
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','pair-cover-groups.json','pair-cover-certificates.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json','final-preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'all_model_fields_exhaustively_verified':True,'variables_verified':len(used_v),'constraints_verified':len(used_c),
    'source_mode_selectors_verified':mode_count,'mask_selectors_verified':mask_count,'region_selectors_verified':region_count,'guarded_planes_verified':plane_count,'empty_site_implications_verified':site_links,
    'rigid_coordinate_mode_links_verified':links,'interval_constraints_verified':48,'size_equalities_verified':48,'global_no_overlap_groups_verified':16,
    'pair_cover_source_proof_bound':True,'all455_site_triples_retained':True,'preparation_seconds_charged':ledger['preparation_seconds_charged'],
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
