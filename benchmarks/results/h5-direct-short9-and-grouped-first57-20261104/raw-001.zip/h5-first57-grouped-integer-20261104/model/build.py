"""One new first57 construction: shared mask implications and global pair-cover packing."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-grouped-integer-20261104';OUT=BASE/'model'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';REG=ROOT/'output/h5-first57-three-empty-site-masks-20261104'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'
RID=ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');unary=load(BASE/'unary-templates.json')
rectangles=load(BASE/'mode-rectangles.json');raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
model=cp_model.CpModel()
def var(i):return model.get_int_var_from_proto_index(i)
def linear(co,lo,hi,guard=None):
    ct=model.add_linear_constraint(sum(v*var(i) for i,v in co.items() if v),lo,hi)
    if guard is not None:ct.only_enforce_if(var(guard))
    return ct.index
owners=[]
for index,instance in enumerate(instances):
    fm=modes[instance['identity'][0]];xy=[]
    for axis in [0,1]:xy.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm),f'owner_{index}_axis_{axis}').index)
    owners.append({'owner':index,'identity':instance['identity'],'positions':xy,'modes':[],'regions':[],'mask_groups':[],'geometry_marginals':[]})
for owner in owners:
    for m in modes[owner['identity'][0]]:
        selector=model.new_bool_var(f'mode_{owner["owner"]}_{m["mode"]}').index
        saved={**m,'selector':selector,'stock_constraints':[linear({owner['positions'][k]:1},a,b,selector) for k,(a,b) in enumerate(m['integer_lower_left_bounds'])]}
        owner['modes'].append(saved)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
empty=[model.new_bool_var(f'empty_site_{i}').index for i in range(15)]
exact_three=linear({i:1 for i in empty},3,3);plane_count=site_links=0
for owner in owners:
    i=owner['owner'];geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    for gid in geometries:
        masks=sorted({r['required_empty_mask'] for r in unary[gid]['regions']})
        for mask in masks:
            selector=model.new_bool_var(f'mask_{i}_{gid}_{mask}').index
            sites=[s for s in range(15) if mask&(1<<s)]
            saved={'geometry':gid,'mask':mask,'selector':selector,'required_empty_sites':sites,
                'site_implications':[linear({selector:1,empty[s]:-1},cp_model.INT_MIN,0) for s in sites],'region_selectors':[]}
            site_links+=len(sites)
            for r in unary[gid]['regions']:
                if r['required_empty_mask']!=mask:continue
                rs=model.new_bool_var(f'region_{i}_{gid}_{r["region"]}').index;ct=[]
                for p in r['planes']:
                    ct.append(linear({owner['positions'][k]:v for k,v in enumerate(p['coefficients'])},cp_model.INT_MIN,p['upper'],rs));plane_count+=1
                owner['regions'].append({'geometry':gid,'region':r['region'],'mask':mask,'mask_selector':selector,'selector':rs,'plane_constraints':ct})
                saved['region_selectors'].append(rs)
            saved['one_region_when_mask_constraint']=linear({selector:-1,**{r:1 for r in saved['region_selectors']}},0,0)
            owner['mask_groups'].append(saved)
        ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid]
        gs=[g['selector'] for g in owner['mask_groups'] if g['geometry']==gid]
        owner['geometry_marginals'].append({'geometry':gid,'mode_selectors':ms,'mask_selectors':gs,'constraint':linear({**{m:-1 for m in ms},**{g:1 for g in gs}},0,0)})
    # The one-mode equation, geometry marginals and mask/region equalities imply
    # exactly one region globally; no redundant all-region equation is needed.
components=[];intervals_x=[];intervals_y=[];gap=23;coordinate_links=0
for raw in raw_components:
    owner=owners[raw['owner']];family=owner['identity'][0];piece=raw['piece'];coords=[]
    for k in range(4):
        axis=k%2;fm=owner['modes']
        lo=min(m['integer_lower_left_bounds'][axis][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in fm)
        hi=max(m['integer_lower_left_bounds'][axis][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in fm)
        coords.append(model.new_int_var(lo,hi,f'component_{raw["component"]}_edge_{k}').index)
    saved={**raw,'coordinates':coords,'mode_links':[],'sizes':[],'size_links':[],'interval_constraints':[]}
    for m in owner['modes']:
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid']
        links=[linear({coords[k]:1,owner['positions'][k%2]:-1},value,value,m['selector']) for k,value in enumerate(offsets)]
        saved['mode_links'].append({'mode':m['mode'],'selector':m['selector'],'offsets':offsets,'constraints':links});coordinate_links+=4
    for axis in [0,1]:
        possible=[rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis+2]-rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis]+gap for m in owner['modes']]
        size=model.new_int_var(min(possible),max(possible),f'component_{raw["component"]}_size_{axis}').index
        saved['sizes'].append(size);saved['size_links'].append(linear({size:1,coords[axis+2]:-1,coords[axis]:1},gap,gap))
        interval=model.new_interval_var(var(coords[axis]),var(size),var(coords[axis+2])+gap,f'component_{raw["component"]}_interval_{axis}')
        saved['interval_constraints'].append(interval.index)
        (intervals_x if axis==0 else intervals_y).append(interval)
    components.append(saved)
packing=[]
for g in groups:
    ct=model.add_no_overlap_2d([intervals_x[i] for i in g['components']],[intervals_y[i] for i in g['components']])
    packing.append({**g,'constraint':ct.index})
symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):symmetry.append({'family':family,'owners':[a['owner'],b['owner']],'constraint':linear({a['positions'][0]:1,b['positions'][0]:-1},cp_model.INT_MIN,0)})
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert not validation,validation
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'empty_site_selectors':empty,'exactly_three_empty_constraint':exact_three,'components':components,'packing_groups':packing,'symmetry_constraints':symmetry,
    'position_units_per_mm':100,'world_origin_mm':[0,2100],'rectangle_gap_grid':gap}
write(OUT/'mapping.json',mapping);elapsed=time.perf_counter()-started
charges={'fixed_source_mode_geometry_preparation_seconds':load(FIRST/'checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(SLOTS/'checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(RID/'checks.json')['seconds'],
    'direct_short9_and_inventory_complete_process_seconds':load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds'],
    'three_empty_site_mask_complete_process_seconds':load(ROOT/'output/h5-first57-three-empty-masks-process-20261104/process.json')['complete_process_seconds'],
    'integer_and_pair_cover_complete_process_seconds':load(ROOT/'output/h5-first57-grouped-integer-process-20261104/process.json')['complete_process_seconds'],
    'model_internal_seconds_pending_complete_process_charge':elapsed}
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),FIRST/'checks.json',SLOTS/'checks.json',RID/'checks.json']+[ROOT/'output'/n/'process.json' for n in ['h5-first57-direct-short9-process-20261104','h5-first57-three-empty-masks-process-20261104','h5-first57-grouped-integer-process-20261104']]+[BASE/n for n in ['plan.json','checks.json','geometry-audit/plan.json','geometry-audit/checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','pair-cover-groups.json','pair-cover-certificates.json']]+[PRE/'plan.json',PRE/'audit/plan.json',PRE/'audit/checks.json',REG/'source-region-audit/plan.json',REG/'source-region-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Direct short9 and complementary first57. Select exactly three empty cog sites among all455 triples. All16 orthogonal originals remain independently movable with96 source modes. Hierarchical geometry/mask/region equations imply one source-safe region per owner and share empty-site implications across all regions of a mask. Each original source component has four rigid coordinates and two interval sizes. Sixteen global NoOverlap2D groups cover all268 different-owner component pairs, with0.23mm separation; no group contains two components of one owner. Same-family X order removes only interchangeable-copy symmetry. No hints, objective or capacity pruning. Audit every model field and final complete-process ledger before one bounded call.',
    'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'provisional_preparation_seconds':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'owners':16,'source_mode_selectors':96,'empty_site_selectors':15,'required_empty_sites':3,'source_region_selectors':sum(len(o['regions']) for o in owners),
    'mask_selectors':sum(len(o['mask_groups']) for o in owners),'empty_site_implications':site_links,'guarded_region_planes':plane_count,
    'rigid_components':24,'coordinate_mode_links':coordinate_links,'interval_constraints':48,'interval_size_constraints':48,
    'global_no_overlap_2d_constraints':16,'same_family_symmetry_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),
    'final_complete_process_ledger_pending':True,'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
