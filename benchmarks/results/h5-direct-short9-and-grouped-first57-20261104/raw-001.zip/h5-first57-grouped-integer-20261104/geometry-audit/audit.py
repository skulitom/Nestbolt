"""Audit all source-plane implications, rigid rectangles and exhaustive pair coverage."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-grouped-integer-20261104';OUT=BASE/'geometry-audit'
REG=ROOT/'output/h5-first57-three-empty-site-masks-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
spec=load(BASE/'plan.json');assert spec['world_origin_mm']==[0,2100] and spec['local_domain_envelope_mm']==[1500,900]
assert spec['grid_units_per_mm']==100 and spec['normal_scale']==100000 and spec['rectangle_gap_grid']==23 and spec['required_empty_sites']==3
assert load(REG/'source-region-audit/checks.json')['passed'] and load(REG/'source-region-audit/disabled-rounded-regions.json')==[]
assert load(PRE/'audit/checks.json')['passed']
origin=[F(0),F(2100)];limit=[F(1500),F(900)];grid=100;scale=100000
modes=load(BASE/'family-modes.json');original=load(REG/'family-modes.json')
for family,items in modes.items():
    assert len(items)==len(original[family])
    for m,source in zip(items,original[family]):
        assert {k:v for k,v in m.items() if k!='integer_lower_left_bounds'}==source
        for k,(a,b) in enumerate(source['lower_left_bounds']):
            lo,hi=m['integer_lower_left_bounds'][k]
            assert [lo,hi]==[math.ceil((F(a)-origin[k])*grid),math.floor((F(b)-origin[k])*grid)]
            assert -limit[k]*grid<=lo<=hi<=limit[k]*grid
templates=load(BASE/'unary-templates.json');assert len(templates)==10;planes=0;insets=[];max_activity=0
for gid,template in enumerate(templates):
    raw=load(REG/'geometries'/f'{gid:02d}.json')['regions']
    assert template['geometry']==gid and len(template['regions'])==len(raw)
    for r,source in zip(template['regions'],raw):
        for k in ['region','required_empty_mask','required_empty_sites']:assert r[k]==source[k]
        assert r['required_empty_mask'].bit_count()<=3 and r['required_empty_sites']==[k for k in range(15) if r['required_empty_mask']&(1<<k)]
        points=[tuple(F(round(v,9)) for v in p) for p in source['vertices']]
        poly=[tuple(map(F,p)) for p in r['hull_vertices']]
        assert len(poly)>=3 and set(poly)<=set(points)
        assert all(cross(a,b,c)>0 for a,b,c in zip(poly,poly[1:]+poly[:1],poly[2:]+poly[:2]))
        assert all(cross(a,b,p)>=0 for a,b in zip(poly,poly[1:]+poly[:1]) for p in points)
        assert len(r['planes'])==len(poly)
        for edge,(a,b,p) in enumerate(zip(poly,poly[1:]+poly[:1],r['planes'])):
            dx,dy=b[0]-a[0],b[1]-a[1];n=[dy/max(abs(dx),abs(dy)),-dx/max(abs(dx),abs(dy))]
            assert p['edge']==edge and list(map(F,p['exact_infinity_normal']))==n
            raw=[round(v*scale) for v in n];div=math.gcd(*map(abs,raw))
            assert p['unreduced_coefficients']==raw and p['divisor']==div>0 and p['coefficients']==[v//div for v in raw]
            err=sum(abs(v-F(c,scale))*b for v,c,b in zip(n,raw,limit));assert F(p['rounding_error_bound_mm'])==err
            rhs=sum(v*(x-o) for v,x,o in zip(n,a,origin))
            assert p['upper']==math.floor((rhs-err-F('1e-7'))*scale*grid)//div
            inset=rhs-F(p['upper']*div,scale*grid)-err;assert inset>=F('1e-7');insets.append(inset)
            activity=sum(abs(c)*int(v*grid) for c,v in zip(p['coefficients'],limit))
            assert activity<2**53 and abs(p['upper'])<2**53;max_activity=max(max_activity,activity);planes+=1
canonical=load(PIECES);rectangles=load(BASE/'mode-rectangles.json');rectangle_count=0;max_padding=F(0)
for family,items in rectangles.items():
    assert len(items)==len(modes[family]) and len(canonical[family])=={'bracket':2,'insert':1}[family]
    for record,m in zip(items,modes[family]):
        assert record['mode']==m['mode'] and record['geometry']==m['normalized_geometry']
        c,s=F(math.cos(m['rotation_radians'])),F(math.sin(m['rotation_radians']));sign=-1 if m['mirrored'] else 1;tx,ty=map(F,m['translation_from_lower_left'])
        assert len(record['rectangles'])==len(canonical[family])
        for pi,(r,piece) in enumerate(zip(record['rectangles'],canonical[family])):
            pts=[(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in piece]
            bounds=[min(x for x,y in pts),min(y for x,y in pts),max(x for x,y in pts),max(y for x,y in pts)]
            assert r['piece']==pi and list(map(F,r['exact_affine_bounds_mm']))==bounds
            expected=[math.floor(v*grid) if k<2 else math.ceil(v*grid) for k,v in enumerate(bounds)]
            assert r['outward_offsets_grid']==expected
            for k,(b,tick) in enumerate(zip(bounds,expected)):
                padding=b-F(tick,grid) if k<2 else F(tick,grid)-b
                assert 0<=padding<F('.01');max_padding=max(max_padding,padding)
            rectangle_count+=1
instances=load(BASE/'instances.json');assert instances==load(REG/'instances.json') and len(instances)==16
assert load(BASE/'inventory.json')==load(REG/'inventory.json')
components=load(BASE/'components.json');pairs=load(BASE/'component-pairs.json')
expected_components=[]
for owner,r in enumerate(instances):
    for piece in range(len(canonical[r['identity'][0]])):
        expected_components.append({'component':len(expected_components),'owner':owner,'identity':r['identity'],'piece':piece})
assert components==expected_components and len(components)==24
expected_pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']]
assert pairs==expected_pairs and len(pairs)==268
groups=load(BASE/'pair-cover-groups.json');assert len(groups)==16
for index,g in enumerate(groups):
    assert g['row']==index and len(g['components'])==len(set(g['components']))==16
    assert {components[i]['owner'] for i in g['components']}==set(range(16))
    assert all(0<=i<24 for i in g['components'])
expected_coverage=[{'components':p['components'],'groups':[g['row'] for g in groups if set(p['components'])<=set(g['components'])]} for p in pairs]
assert expected_coverage==load(BASE/'pair-cover-certificates.json') and min(len(p['groups']) for p in expected_coverage)==4
assert F(spec['rectangle_gap_grid'],grid)>F(load(PRE/'plan.json')['required_pair_gap_mm'])
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),PIECES]+[BASE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','pair-cover-groups.json','pair-cover-certificates.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'pair_cover_implication':'For each different-owner component pair, at least one group includes both, so nonoverlap in all groups enforces every pair. Every group contains exactly one component per owner, so it adds no same-owner spacing. Extending both X and Y intervals by23grid units at the positive end makes disjointness in either axis imply0.23mm separation of the original outward boxes. Group predicates are precisely conjunctions of their pairwise predicates; coverage proves equivalence to the full different-owner pair requirement.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_source_bindings':len(bindings),'cached_regions_verified':sum(len(t['regions']) for t in templates),
    'integer_plane_implications_verified':planes,'minimum_certified_inset_mm':float(min(insets)),'maximum_integer_activity':max_activity,
    'source_component_mode_rectangles_verified':rectangle_count,'maximum_outward_padding_mm':float(max_padding),
    'original_orthogonal_owners':16,'rigid_components':24,'different_owner_component_pairs_verified':268,'pair_cover_groups':16,'minimum_pair_coverage':4,
    'no_same_owner_pairs_in_any_group':True,'all_source_masks_preserved':True,'all455_site_triples_preserved':True,
    'source_valid66':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
