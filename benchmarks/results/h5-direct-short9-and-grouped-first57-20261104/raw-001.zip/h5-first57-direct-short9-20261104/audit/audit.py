"""Independently replay the direct source construction and complementary inventory."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-direct-short9-20261104';OUT=BASE/'audit'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(BASE/'plan.json');inventory=load(BASE/'inventory.json')
rows=load(BASE/'short9-source.json');fixed=load(BASE/'fixed29.json');module=load(BASE/'module-spec.json')
assert len(rows)==9 and len(fixed)==29 and fixed==load(FIRST/'fixed29.json')
assert Counter(r['part_id'] for r in rows)=={'bracket':4,'insert':2,'cog':3}
assert module['gap_mm']==.23 and module['module_width_mm']==330.46 and module['module_height_mm']==310.46
# Derive local placement from original L/rectangle dimensions rather than a saved witness.
assert parts['bracket']['geometry'][0]['outer']==[[0,0],[300,0],[300,75],[100,75],[100,250],[0,250]]
assert parts['insert']['geometry'][0]['outer']==[[0,0],[180,0],[180,110],[0,110]]
for n in [0,1]:
    a,b,i=rows[3*n:3*n+3];x,y=module['modules'][n]['origin']
    assert abs(x-(6.525+n*330.69))<1e-10 and y==6.525
    expected=[(a,270,(x,y+310.46)),(b,90,(x+330.46,y)),(i,0,(x+75.23,y+100.23))]
    for r,angle,translation in expected:
        assert r['transform']['rotation_radians']==math.radians(angle) and not r['transform']['mirrored']
        assert max(abs(v-w) for v,w in zip(r['transform']['translation'],translation))<1e-10
    assert [a['copy_index'],b['copy_index'],i['copy_index']]==[[7,8,4],[10,11,5]][n]
for n,r in enumerate(rows[6:]):
    t=r['transform'];assert r['part_id']=='cog' and r['copy_index']==[0,13,14][n] and not t['mirrored'] and t['rotation_radians']==math.radians(7)
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])
    vertices=[(x*c-y*s+t['translation'][0],x*s+y*c+t['translation'][1]) for x,y in parts['cog']['geometry'][0]['outer']]
    assert abs(min(x for x,y in vertices)-(667.905+n*258.86))<1e-9 and abs(min(y for x,y in vertices)-6.525)<1e-9
universe={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
short={tuple(x) for x in inventory['short9_identities']};first={tuple(x) for x in inventory['first57_identities']}
fixed_ids={tuple(x) for x in inventory['fixed29_identities']};cogs={tuple(x) for x in inventory['required_cog12_identities']};orth={tuple(x) for x in inventory['moving16_orthogonal_identities']}
assert len(universe)==66 and len(short)==9 and len(first)==57 and not short&first and short|first==universe
assert len(fixed_ids)==29 and len(cogs)==12 and len(orth)==16 and fixed_ids|cogs|orth==first
assert not fixed_ids&cogs and not fixed_ids&orth and not cogs&orth
assert short=={(r['part_id'],r['copy_index']) for r in rows} and fixed_ids=={(r['part_id'],r['copy_index']) for r in fixed}
assert Counter(f for f,i in orth)=={'bracket':8,'insert':8} and cogs=={('cog',i) for i in range(1,13)}
short_check=audit(job,rows,{'sheet-1':spec['source_stocks']['sheet-1']},spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(short))
assert short_check==load(BASE/'short9-source-checks.json') and short_check['valid']
reference=load(BASE/'all15-reference44-source.json')
assert reference[:29]==fixed and len(reference)==44 and len({(r['part_id'],r['copy_index']) for r in reference})==44
sites=load(BASE/'source-cog-sites.json');assert sites==load(SLOTS/'source-cog-sites.json')
assert [r['transform'] for r in reference[29:]]==[r['transform'] for r in sites]
ref_check=audit(job,reference,{'sheet-0':spec['source_stocks']['sheet-0']},spec['required_pair_gap_mm'],spec['stock_guard_mm'],
    list(fixed_ids)+[('cog',i) for i in range(15)])
assert ref_check==load(BASE/'all15-reference44-checks.json') and ref_check['valid']
assert len(list(combinations(range(15),3)))==455 and spec['site_selections']==455
for name in ['family-modes.json','geometry-library.json']:assert load(BASE/name)==load(FIRST/name)
assert load(FIRST/'audit/checks.json')['passed'] and load(SLOTS/'audit/checks.json')['passed']
process=load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout']
write(OUT/'short9-independent-readback.json',short_check);write(OUT/'reference44-independent-readback.json',ref_check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,ROOT/'output/h5-first57-direct-short9-process-20261104/opened.json',
    ROOT/'output/h5-first57-direct-short9-process-20261104/process.json']+[BASE/n for n in ['plan.json','checks.json','inventory.json','module-spec.json','short9-source.json','short9-source-checks.json','fixed29.json','source-cog-sites.json','all15-reference44-source.json','all15-reference44-checks.json','family-modes.json','geometry-library.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'direct_formula_short9_verified':True,'all66_inventory_verified':True,
    'short9_pairs':36,'short9_stock_edges':36,'short9_cutouts':17,'short9_hole_vertices':2308,
    'short9_minimum_gap_mm':short_check['minimum_pair_gap_mm'],'short9_minimum_stock_mm':short_check['minimum_extra_stock_mm'],
    'reference44_pairs':946,'reference44_stock_edges':176,'reference44_cutouts':44,'reference44_hole_vertices':4414,
    'all455_twelve_site_subsets_safe_against_fixed29':True,'reference44_not_combined_with_short9':True,
    'first57_required_originals':57,'orthogonal_movers':16,'source_modes':96,'complete_preparation_process_seconds':process['complete_process_seconds'],
    'prior_fixed_mode_site_preparation_charges_still_required':True,'source_valid66':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
