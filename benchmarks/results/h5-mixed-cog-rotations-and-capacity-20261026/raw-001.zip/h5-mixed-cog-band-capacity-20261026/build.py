"""Exact lower area demand in horizontal bands for a necessary strip model."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from bisect import bisect_right
from functools import lru_cache
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-mixed-cog-angle-screen-20261026';OUT=ROOT/'output/h5-mixed-cog-band-capacity-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def ratio(x):return [x.numerator,x.denominator]
OUT.mkdir();(OUT/'profiles').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240;spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');assert load(SOURCE/'audit/checks.json')['passed'];stock=[F(*v) for v in spec['stock_bounds_rational']];bands=[];lo=stock[1]
while lo<stock[3]:hi=min(stock[3],lo+5);bands.append([lo,hi]);lo=hi
counts={'bracket':4,'insert':1,'cog':4};paths=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',ROOT/'output/h5-balanced-union-search-20261026/audit/checks.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'profiles':list(range(12)),'required_original_counts':counts,'coordinate_units_per_mm':1000,'area_units_per_mm2':1000,'vertical_cell_width_units':1000,'bands_mm':[[ratio(a),ratio(b)] for a,b in bands],'stock_width_mm':ratio(stock[2]-stock[0]),'stock_bounds_rational':spec['stock_bounds_rational'],'construction_limit_seconds':240,'solver_cap_seconds':20,'shared_solver_seconds':30,'workers':4,'seed':0,'method':'Necessary horizontal-band area model for four original brackets, one insert and four cogs in the same short second sheet. Brackets may choose all eight current quarter-turn/mirror profiles, inserts both axis-aligned orientations, cogs independently choose the reconstructed56.25degree or65.25degree source angles. Cover every integer vertical anchor in exact disjoint1mm cells; horizontal coordinates and all collisions are relaxed. For each cell and each5mm stock band, compute the exact minimum filled-outer area over every continuous shift in that cell, using rational piecewise-linear slice widths, all band/vertex breakpoints and all quadratic stationary points. Floor each demand to1000units/mm2 and floor each stock-band capacity; aggregating indistinguishable family counts is necessary for every actual source layout. No independence assumption across bands is used for a positive claim; per-band minima intentionally relax shared shifts. This is a new capacity formulation, not a retry of any closed coordinate call. Independently audit before one separately bounded call. A positive is only a necessary allocation; negative scope retains the two declared cog angles and target stock, not unrestricted rotations or full H5.'})
rows=[];coefficients=0
for p in profiles:
    assert time.perf_counter()<deadline
    pts=[tuple(F(v) for v in xy) for xy in p['geometry']['coordinates'][0]]
    signed=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(pts,pts[1:]))
    if signed<0:pts.reverse()
    edges=[]
    for a,b in zip(pts,pts[1:]):
        if a[1]==b[1]:continue
        sign=1 if b[1]>a[1] else -1;m=(b[0]-a[0])/(b[1]-a[1]);c=a[0]-m*a[1];edges.append((min(a[1],b[1]),max(a[1],b[1]),sign*m,sign*c))
    knots=sorted({v[1] for v in pts});segments=[];area=F(0)
    for a,b in zip(knots,knots[1:]):
        mid=(a+b)/2;m=sum(e[2] for e in edges if e[0]<mid<e[1]);c=sum(e[3] for e in edges if e[0]<mid<e[1]);assert m*a+c>=0 and m*b+c>=0;segments.append((m,c,area));area+=m*(b*b-a*a)/2+c*(b-a)
    assert area==abs(signed)/2
    @lru_cache(None)
    def below(y):
        if y<=knots[0]:return F(0)
        if y>=knots[-1]:return area
        i=bisect_right(knots,y)-1;m,c,base=segments[i];a=knots[i];return base+m*(y*y-a*a)/2+c*(y-a)
    def slope(y):
        if y<=knots[0] or y>=knots[-1]:return F(0),F(0)
        return segments[bisect_right(knots,y)-1][:2]
    b=p['bounds'];pad=F(.0125)+F(.000001);ylo=math.ceil((stock[1]+pad-F(b[1]))*1000);yhi=math.floor((stock[3]-pad-F(b[3]))*1000);cells=[]
    for bottom in range(ylo,yhi+1,1000):
        top=min(yhi,bottom+999);t0,t1=F(bottom,1000),F(top,1000);demands=[]
        for a,b in bands:
            points=sorted({t0,t1}|{v for bound in [a,b] for k in knots if t0<(v:=bound-k)<t1});candidates=list(points)
            for u,v in zip(points,points[1:]):
                mid=(u+v)/2;ma,ca=slope(a-mid);mb,cb=slope(b-mid);A=mb-ma;B=ma*a+ca-mb*b-cb
                if A:
                    root=-B/A
                    if u<root<v:candidates.append(root)
            value=min(below(b-t)-below(a-t) for t in candidates);assert value>=0;demands.append(math.floor(value*1000));coefficients+=1
        cells.append({'index':len(cells),'y_bounds_units1000':[bottom,top],'band_lower_area_units':demands})
    write(OUT/'profiles'/f"{p['index']:03d}.json",{'profile':p['index'],'family':p['family'],'y_bounds_units1000':[ylo,yhi],'filled_outer_area_mm2':ratio(area),'cells':cells});rows.append({'profile':p['index'],'family':p['family'],'cells':len(cells)});print({'profile':p['index'],'cells':len(cells),'seconds':time.perf_counter()-start},flush=True)
caps=[math.floor((stock[2]-stock[0])*(b-a)*1000) for a,b in bands];write(OUT/'band-capacities.json',caps);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'profiles':len(rows),'vertical_cells':sum(r['cells'] for r in rows),'bands':len(bands),'exact_lower_area_coefficients':coefficients,'profile_summary':rows,'all_profiles_complete':len(rows)==12,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
