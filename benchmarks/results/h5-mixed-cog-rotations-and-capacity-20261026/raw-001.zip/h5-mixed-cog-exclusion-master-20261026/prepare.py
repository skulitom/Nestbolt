"""Add only the newly rejected two-phase group count to the new mixed-angle master."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-mixed-cog-band-model-20261026';SOURCE=ROOT/'output/h5-mixed-cog-group-strip-source-20261026';PROBE=ROOT/'output/h5-mixed-cog-group-shared-probe-20261026';OUT=ROOT/'output/h5-mixed-cog-exclusion-master-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'audit/checks.json')['passed'] and load(PROBE/'response-audit/checks.json')['passed'] and load(PROBE/'search/000/result.json')['status']=='INFEASIBLE'
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'model.pb').read_bytes());assert len(m.variables)==709 and len(m.constraints)==67
mapping=load(PARENT/'mapping.json');groups=[([0,4],1),([2,6],1),([3,5],2),([10],1),([11],2)]
paths=[PARENT/'model.pb',PARENT/'mapping.json',PARENT/'audit/checks.json',SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',PROBE/'models/000.pb',PROBE/'models/000-mapping.json',PROBE/'model-audit/checks.json',PROBE/'response-audit/checks.json',PROBE/'search/000/model.pb',PROBE/'search/000/response.pb',PROBE/'search/000/result.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'excluded_group_counts':[{'profiles':g,'count':n} for g,n in groups],'method':'Preserve the full709-variable/67-constraint two-phase master, including at least one profile11 cog. Add five exact reified count equalities and a not-all clause for counts (p0+p4,p2+p6,p3+p5,p10,p11)=(1,1,2,1,2). Family totals imply two cogs9 and no other bracket/insert profiles. Identical bracket copies relabel into0/4,2/6,3/5,3/5; only identical3/5 slots are profile-ordered. Identical cog copies relabel into9/9/11/11; x ordering is permitted only within each phase pair. Every matching source witness would satisfy the independently rejected74-mode full-coordinate model. No old fixed-angle cut transfers. Independent source projection, complete parent restoration, truth-table and actual-import audit before one new20second necessary call within30shared seconds.'})
rows=[]
for group,count in groups:
    flag=len(m.variables);name='-'.join(map(str,group));m.variables.add(name=f'excluded-mixed-group{name}-count{count}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for lit,domain in [(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]:
        c=m.constraints.add();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(domain)
    rows.append({'profiles':group,'count':count,'flag':flag,'cell_variables':ids})
m.constraints.add().bool_or.literals.extend(-r['flag']-1 for r in rows)
shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');write(OUT/'exclusion.json',rows);(OUT/'model.pb').write_bytes(m.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
