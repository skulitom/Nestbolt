"""Verify exact mixed-angle source projection without transferring any old-angle cut."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,permutations,combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-cog-exclusion-master-20261026';PARENT=ROOT/'output/h5-mixed-cog-band-model-20261026';SOURCE=ROOT/'output/h5-mixed-cog-group-strip-source-20261026';PROBE=ROOT/'output/h5-mixed-cog-group-shared-probe-20261026';DATA=ROOT/'output/h5-mixed-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify actual full-coordinate model/INFEASIBLE response, exact source profiles, every stock domain and74 orientation modes across36 pairs. Enumerate384 bracket mirror/identity assignments times24 cog identity permutations, relabelling cogs into the two phase pairs; only identical-phase copies may be x-ordered. Reconstruct five exact aggregate count reifications and OR, enumerate40000 count/flag truth cases, restore the entire709/67 mixed-angle parent byte fields and check real solver import/export. No earlier single-angle exclusion is copied and no solve occurs.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for p in [PARENT/'audit/checks.json',SOURCE/'audit/checks.json',PROBE/'model-audit/checks.json',PROBE/'response-audit/checks.json']:assert load(p)['passed']
s=load(SOURCE/'plan.json');allowed=[[0,4],[2,6],[3,5],[3,5],[10],[9],[9],[11],[11]];assert s['allowed_profiles']==allowed
assert load(SOURCE/'profiles.json')==load(ROOT/'output/h5-mixed-cog-angle-screen-20261026/profiles.json')
assert [p['item'] for p in s['parts']]==[21,22,25,26,37,53,63,64,65]
assert all(p['family']=='bracket' for p in s['parts'][:4]) and len({p['copy'] for p in s['parts'][:4]})==4
assert all(p['family']=='cog' for p in s['parts'][5:]) and len({p['copy'] for p in s['parts'][5:]})==4
closed=proto(PROBE/'search/000/model.pb');assert closed==proto(PROBE/'models/000.pb');response=cp_model_pb2.CpSolverResponse();response.ParseFromString((PROBE/'search/000/response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
for i,options in enumerate(allowed):
    for axis in range(2):assert list(closed.variables[2*i+axis].domain)==[min(s['anchor_bounds_units1000'][str(p)][axis] for p in options),max(s['anchor_bounds_units1000'][str(p)][axis+2] for p in options)]
    for p in options:assert s['anchor_bounds_units1000'][str(p)][1::2]==load(DATA/'profiles'/f'{p:03d}.json')['y_bounds_units1000']
maps=load(PROBE/'models/000-mapping.json');assert len(maps)==74 and {(tuple(r['parts']),tuple(r['profiles'])) for r in maps}=={((a,b),(pa,pb)) for a,b in combinations(range(9),2) for pa,pb in product(allowed[a],allowed[b])}
checked=0;cog_patterns=set()
for selected in product(*allowed[:4]):
    for perm in permutations(range(4)):
        assigned=[selected[i] for i in perm];remaining=list(range(4));back=[]
        for group in [[0,4],[2,6]]:
            ids=[i for i in remaining if assigned[i] in group];assert len(ids)==1;back.extend(ids);remaining.remove(ids[0])
        back.extend(sorted(remaining,key=lambda i:assigned[i]));result=[assigned[i] for i in back];assert all(result[i] in allowed[i] for i in range(4)) and result[2]<=result[3]
        for cp in permutations(range(4)):
            phase=[(9,9,11,11)[i] for i in cp];order=[i for p in [9,11] for i,v in enumerate(phase) if v==p]
            assert sorted(order)==list(range(4)) and [phase[i] for i in order]==[9,9,11,11];cog_patterns.add(tuple(phase));checked+=1
assert checked==9216 and len(cog_patterns)==6
m=proto(BASE/'model.pb');old=proto(PARENT/'model.pb');assert len(m.variables)==714 and len(m.constraints)==78
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[709:];del restored.constraints[67:];assert restored==old
mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json') and {r['profile'] for r in mapping if r['family']=='cog'}=={9,11}
groups=[([0,4],1),([2,6],1),([3,5],2),([10],1),([11],2)];rows=[]
for j,(group,count) in enumerate(groups):
    flag=709+j;name='-'.join(map(str,group));assert m.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f'excluded-mixed-group{name}-count{count}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for k,(lit,dom) in enumerate([(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]):
        c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(dom);assert c==m.constraints[67+2*j+k]
    rows.append({'profiles':group,'count':count,'flag':flag,'cell_variables':ids})
assert rows==load(BASE/'exclusion.json');c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-710,-711,-712,-713,-714]);assert c==m.constraints[77];cases=0
for totals in product(range(5),range(5),range(5),range(2),range(5)):
    exists=False
    for bits in product([0,1],repeat=5):
        valid=not all(bits)
        for j,(value,bit) in enumerate(zip(totals,bits)):
            dom=list(m.constraints[67+2*j+(0 if bit else 1)].linear.domain);valid &= any(lo<=value<=hi for lo,hi in zip(dom[::2],dom[1::2]))
        exists |= valid;cases+=1
    assert exists==(totals!=(1,1,2,1,2))
assert cases==40000
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'implication.json',{'statement':'The excluded aggregate counts consume all4 brackets and the sole insert10. Total cog count4 and p11=2 force p9=2. Identical copies relabel to the source slots, with only same-choice slots sortable. All full stock domains and every physical orientation pair are retained by the independently audited source model. Thus any matching source/grid layout would contradict its closed negative response. No other phase count or bracket family is excluded, and no fixed-angle cut is transferred.','scope':'The same two allowed angles, guarded source geometry and integer grid only; not unrestricted original packing.','all_original_identities_retained':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':714,'constraints':78,'exact_parent_restoration_verified':True,'joint_bracket_cog_identity_permutations_checked':checked,'distinct_cog_phase_assignments':6,'source_modes_checked':74,'source_physical_pairs_checked':36,'count_flag_cases_checked':cases,'actual_import_export_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
