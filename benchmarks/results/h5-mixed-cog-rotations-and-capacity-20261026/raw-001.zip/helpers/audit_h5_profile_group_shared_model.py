"""Independent reconstruction of all source modes and shared plane clauses."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-profile-group-shared-probe-20261026';SOURCE=ROOT/'output/h5-profile-group-strip-source-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct all coordinate/profile variables and stock/count constraints. Only identical3/5-copy order and cog x order are allowed. For every one of74 modes, evaluate each source halfplane at four difference-box corners, account for every face, and independently reconstruct each shared plane by serialized complete linear fields. Rebuild every mode OR including its exact inactive-profile escape literals. Coordinate equivalence follows by setting shared literals from plane truth; all true shared flags imply the same original source planes. Require exact full proto fields and solver import/export; no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];bounds=s['anchor_bounds_units1000'];m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};vi=ci=0
def var(name,dom):
    global vi
    assert m.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=dom);vi+=1
def linear(terms,lo,hi,enforce=()):
    global ci
    c=cp_model_pb2.ConstraintProto();ids=sorted(v for v,k in terms.items() if k);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce);assert c==m.constraints[ci],ci;ci+=1
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in options),max(bounds[str(p)][axis+2] for p in options)])
flags={}
for i in range(4):
    flags[i]={}
    for p in allowed[i]:flags[i][p]=vi;var(f'p{i}-profile{p}',[0,1])
assert {str(i):{str(p):v for p,v in choices.items()} for i,choices in flags.items()}==load(BASE/'profile-flags.json')
for i in range(4):
    linear(dict.fromkeys(flags[i].values(),1),1,1)
    for p,v in flags[i].items():
        b=bounds[str(p)]
        for axis in range(2):linear({2*i+axis:1},b[axis],b[axis+2],[v])
assert allowed[2]==allowed[3]==[3,5];linear({flags[2][3]:3,flags[2][5]:5,flags[3][3]:-3,flags[3][5]:-5},-2**63,0)
for i in range(5,8):linear({2*i:1,2*(i+1):-1},-2**63,0)
assert vi==26 and ci==24;assert len({p['copy'] for p in s['parts'][:4]})==4 and len({p['copy'] for p in s['parts'][5:]})==4 and all(p['family']=='bracket' for p in s['parts'][:4]) and all(p['family']=='cog' for p in s['parts'][5:]);data={(c['profile_a'],c['profile_b']):load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in s['mutual_cases']};unique={};rows=[];clauses=[];maps=[];taut=uses=0
for a,b in combinations(range(9),2):
    for pa,pb in product(allowed[a],allowed[b]):
        aa,bb=bounds[str(pa)],bounds[str(pb)];d=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];corners=list(product([d[0],d[2]],[d[1],d[3]]));active=([flags[a][pa]] if a<4 else [])+([flags[b][pb]] if b<4 else []);fs=[]
        for face in data[pa,pb]['faces']:
            hs=face['outside_halfplanes'];values=[[h['a']*x+h['b']*y for x,y in corners] for h in hs]
            if any(min(v)>=h['bound'] for h,v in zip(hs,values)):fs.append({'face':face['index'],'tautological':True});taut+=1;continue
            live=[j for j,(h,v) in enumerate(zip(hs,values)) if max(v)>=h['bound']];efs=[]
            for j in live:
                h=hs[j];terms={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};ids=sorted(v for v,k in terms.items() if k);p=cp_model_pb2.LinearConstraintProto(vars=ids,coeffs=[terms[v] for v in ids],domain=[h['bound'],2**63-1]);key=p.SerializeToString()
                if key not in unique:
                    v=vi;unique[key]=v;var(f'pair-plane-{v}',[0,1]);linear(terms,h['bound'],2**63-1,[v]);rows.append({'flag':v,'parts':[a,b],'a':h['a'],'b':h['b'],'bound':h['bound']})
                efs.append(unique[key]);uses+=1
            clauses.append([-v-1 for v in active]+efs);fs.append({'face':face['index'],'live_edges':live,'shared_flags':efs})
        maps.append({'parts':[a,b],'profiles':[pa,pb],'active':active,'difference_bounds':d,'faces':fs})
for lits in clauses:
    c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend(lits);assert c==m.constraints[ci];ci+=1
assert len(maps)==74 and maps==load(BASE/'models/000-mapping.json') and rows==load(BASE/'shared-planes.json');r=load(BASE/'inventory.json')[0];assert vi==len(m.variables)==r['variables'] and ci==len(m.constraints)==r['constraints'] and r['shared_planes']==len(unique) and r['edge_uses']==uses and r['face_clauses']==len(clauses) and r['tautological_faces']==taut and r['parts']==list(range(9)) and r['originals']==[p['item'] for p in s['parts']] and r['solver_seconds']==45 and digest(BASE/'models/000.pb')==r['model_sha256']
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'physical_modes_checked':74,'source_edge_uses_verified':uses,'shared_planes_verified':len(unique),'all_source_faces_and_mode_clauses_verified':True,'sharing_preserves_source_coordinate_feasibility':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
