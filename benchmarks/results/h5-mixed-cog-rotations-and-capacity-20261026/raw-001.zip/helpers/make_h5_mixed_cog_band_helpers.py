"""Fresh two-phase band model requiring at least one cog at the added angle."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
paths=[('h5-aligned-cog-profiles-20261026','h5-mixed-cog-angle-screen-20261026'),('h5-aligned-cog-band-capacity-20261026','h5-mixed-cog-band-capacity-20261026'),('h5-aligned-cog-band-model-20261026','h5-mixed-cog-band-model-20261026'),('h5-aligned-cog-band-search-20261026','h5-mixed-cog-band-search-20261026')]
def make(src,dst,extra):
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for a,b in paths:s=s.replace(a,b)
    for a,b in extra:
        assert a in s,(src,a);s=s.replace(a,b)
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
make('build_h5_aligned_cog_band_capacity.py','build_h5_mixed_cog_band_capacity.py',[
 ('list(range(11))','list(range(12))'),('len(rows)==11','len(rows)==12'),
 ('h5-shared-bracket-strip-probe-20261026/response-audit/checks.json','h5-balanced-union-search-20261026/audit/checks.json'),
 ('cogs the independently reconstructed56.25degree source angle','cogs independently choose the reconstructed56.25degree or65.25degree source angles'),
 ('negative scope retains the fixed cog angle and target stock','negative scope retains the two declared cog angles and target stock')])
make('audit_h5_aligned_cog_band_capacity.py','audit_h5_mixed_cog_band_capacity.py',[
 ('all11 approved original profiles','all12 approved original profiles'),('42525','44667'),('675','709'),
 ("'original_profiles_reconstructed':11","'original_profiles_reconstructed':12"),
 ('Current fixed cog orientation','Two declared cog orientations'),
 ('Only the new56.25degree cog profile is included; old-angle source exclusions do not transfer.','Both56.25degree and65.25degree cog profiles are included; all fixed-angle conditional exclusions are omitted.')])
make('prepare_h5_aligned_cog_band_model.py','prepare_h5_mixed_cog_band_model.py',[
 ('No coordinates, collisions, objective, hints or omitted originals.','Require at least one cog in new profile11, while all four cogs choose9/11. No prior conditional exclusion is copied. No coordinates, collisions, objective, hints or omitted originals.'),
 ('negative retains the recorded fixed-angle source scope.','negative retains only the recorded two-phase scope with at least one new-angle cog.'),
 ("write(OUT/'mapping.json',mapping);","constraint([(r['variable'],1) for r in mapping if r['profile']==11],1,4)\nwrite(OUT/'mapping.json',mapping);")])
make('audit_h5_aligned_cog_band_model.py','audit_h5_mixed_cog_band_model.py',[
 ('675','709'),('range(11)','range(12)'),('len(model.constraints)==66','len(model.constraints)==67'),("'constraints':66","'constraints':67"),
 ('require whole-proto equality','add the complete profile11 sum constrained to1..4 (at least one new-phase cog), require whole-proto equality'),
 ('model=cp_model_pb2.CpModelProto();',"c=expected.constraints.add();ids=[r['variable'] for r in mapping if r['profile']==11];c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,4]);assert len(ids)==34\nmodel=cp_model_pb2.CpModelProto();"),
 ("'verified_band_inequalities':63","'verified_band_inequalities':63,'new_phase_count_constraint_verified':True")])
make('run_h5_aligned_cog_band_model.py','run_h5_mixed_cog_band_model.py',[
 ('675-variable','709-variable'),('new56.25degree guarded-source geometry','two-phase56.25/65.25degree guarded-source geometry, with at least one new-phase cog and no transferred fixed-angle exclusions')])
make('audit_h5_aligned_cog_band_response.py','audit_h5_mixed_cog_band_response.py',[
 ('len(s)==675','len(s)==709'),('all66 linear constraints','all67 linear constraints including at least one new-phase cog'),('current cog angle','two declared cog angles with at least one new-phase cog'),
 ("write(OUT/'verified-allocation.json',allocation);","assert sum(r['count'] for r in allocation if r['profile']==11)>=1;write(OUT/'profile-totals.json',{i:sum(r['count'] for r in allocation if r['profile']==i) for i in range(12)});write(OUT/'verified-allocation.json',allocation);")])
