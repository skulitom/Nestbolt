"""Test the newly selected three/one cog-phase family with balanced bracket types."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('build_h5_mixed_cog_group_strip.py','build_h5_three_one_cog_strip.py'),('audit_h5_mixed_cog_group_geometry.py','audit_h5_three_one_cog_geometry.py'),('prepare_h5_mixed_cog_group_shared_model.py','prepare_h5_three_one_cog_shared_model.py'),('audit_h5_mixed_cog_group_shared_model.py','audit_h5_three_one_cog_shared_model.py'),('run_h5_mixed_cog_group_probe.py','run_h5_three_one_cog_probe.py'),('audit_h5_mixed_cog_group_response.py','audit_h5_three_one_cog_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-mixed-cog-group-strip-source-20261026','h5-three-one-cog-strip-source-20261026').replace('h5-mixed-cog-group-shared-probe-20261026','h5-three-one-cog-shared-probe-20261026')
    s=s.replace('[[0,4],[2,6],[3,5],[3,5],[10],[9],[9],[11],[11]]','[[0,4],[2,6],[1,7],[3,5],[8],[9],[9],[9],[11]]')
    if src.startswith('build'):
        s=s.replace('len(keys)==39','len(keys)==52').replace("'pair_cases':39","'pair_cases':52")
        old="ROOT/'output/h5-profile-group-strip-source-20261026']:";assert old in s
        s=s.replace(old,"ROOT/'output/h5-profile-group-strip-source-20261026',ROOT/'output/h5-balanced-group-strip-source-20261026',ROOT/'output/h5-mixed-cog-group-strip-source-20261026']:")
        s=s.replace('h5-mixed-cog-band-search-20261026','h5-mixed-cog-exclusion-search-20261026')
        old='(totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10],totals[9],totals[11])==(1,1,2,1,2,2)';new='(totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5],totals[8],totals[9],totals[11])==(1,1,1,1,1,3,1)';assert old in s;s=s.replace(old,new)
        old="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[3,5],'count':2},{'profiles':[10],'count':1},{'profiles':[9],'count':2},{'profiles':[11],'count':2}]";new="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[1,7],'count':1},{'profiles':[3,5],'count':1},{'profiles':[8],'count':1},{'profiles':[9],'count':3},{'profiles':[11],'count':1}]";assert old in s;s=s.replace(old,new)
        s=s.replace('one bracket from0/4, one from2/6 and two from3/5. Insert10, two56.25degree cogs9 and two65.25degree cogs11 remain.','one bracket each from0/4,2/6,1/7,3/5. Insert8, three56.25degree cogs9 and one65.25degree cog11 remain.').replace('all39 cases','all52 cases').replace('two/two cog-angle counts','three/one cog-angle counts')
    elif 'geometry' in src:
        s=s.replace('len(needed)==39','len(needed)==52').replace("'h5-mixed-cog-band-search']","'h5-mixed-cog-group-strip','h5-mixed-cog-exclusion-search']")
    elif src.startswith('prepare'):
        old="linear({**{flags[2][p]:p for p in allowed[2]},**{flags[3][p]:-p for p in allowed[3]}},-2**63,0)\n";assert old in s;s=s.replace(old,'')
        s=s.replace('for i in [5,7]:linear','for i in [5,6]:linear').replace('len(m.constraints)==23','len(m.constraints)==22')
        s=s.replace('Only the two identical3/5-slot bracket copies are profile-ordered; cogs are x-ordered only within identical phase pairs5/6 and7/8.','Distinct bracket type slots are unordered; x-order only the three identical profile9 cog copies5/6/7, with no order relative to the profile11 cog8.')
    elif 'shared_model' in src:
        old="assert allowed[2]==allowed[3]==[3,5];linear({flags[2][3]:3,flags[2][5]:5,flags[3][3]:-3,flags[3][5]:-5},-2**63,0)\n";assert old in s;s=s.replace(old,'')
        s=s.replace('for i in [5,7]:linear','for i in [5,6]:linear').replace('vi==26 and ci==23','vi==26 and ci==22')
        s=s.replace('Only identical3/5-copy order and separate same-phase cog-pair x orders are allowed; never order across different phases.','Distinct bracket type slots are unordered. Only the three identical profile9 cog copies are x-ordered; never order relative to profile11.')
    elif 'response' in src:
        old='selected.extend([10,9,9,11,11]);assert selected[2]<=selected[3] and sol[10:14:2]==sorted(sol[10:14:2]) and sol[14:18:2]==sorted(sol[14:18:2])';new='selected.extend([8,9,9,9,11]);assert all(selected[i] in s["allowed_profiles"][i] for i in range(9)) and sol[10:16:2]==sorted(sol[10:16:2])';assert old in s;s=s.replace(old,new).replace('two/two cog-angle counts','three/one cog-angle counts')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
