"""Read back one changed-composition necessary allocation call."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-aligned-cog-band-search-20261026';MODEL=ROOT/'output/h5-aligned-cog-band-model-20261026';DATA=ROOT/'output/h5-aligned-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for folder in [BASE,MODEL] for p in folder.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify the sole closed necessary allocation call, exact actual model/parameters/response and shared timing. Preserve its changed mandatory composition and all66-original identity obligations. On a positive, independently evaluate every variable, all66 linear constraints, original family counts, all63 band sums and the exact saved allocation. A necessary allocation is not a coordinate or full-job witness. A negative is scoped to this composition and current cog angle.'})
for path in [BASE/'plan.json',MODEL/'plan.json',MODEL/'audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(MODEL/'audit/checks.json')['passed'];proc=load(BASE/'process.json');budget=load(BASE/'budget.json');opened=load(BASE/'opened.json');result=load(BASE/'result.json');assert not proc['timeout'] and proc['exit_code']==0 and proc['seconds']<=30 and budget=={**budget,'shared_seconds':30,'solver_cap_seconds':20,'workers':4,'seed':0,'shutdown_reserve_seconds':5,'maximum_solver_calls':1};assert result['solver_calls']==opened['maximum_solver_calls']==1
model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((MODEL/'model.pb').read_bytes());assert model==expected and digest(BASE/'model.pb')==opened['model_sha256'];params=text_format.Parse((BASE/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=min(20,opened['remaining_shared_seconds']),num_search_workers=4,random_seed=0,cp_model_presolve=True,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(BASE/'parameters.pbtxt')==opened['parameters_sha256'] and params.max_time_in_seconds==opened['solver_seconds_limit'];response=cp_model_pb2.CpSolverResponse();response.ParseFromString((BASE/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==result['status'] and abs(response.wall_time-result['seconds'])<.1 and result['seconds']<proc['seconds'] and result['solver_soft_overrun_seconds']==max(0,result['seconds']-params.max_time_in_seconds)
positive=result['status'] in ['OPTIMAL','FEASIBLE'];assert positive==result['has_necessary_allocation'];mapping=load(MODEL/'mapping.json');counts=load(DATA/'plan.json')['required_original_counts'];checked=0
if positive:
    s=list(response.solution);assert len(s)==675
    for v,n in zip(model.variables,s):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
    for c in model.constraints:
        assert c.WhichOneof('constraint')=='linear' and not c.enforcement_literal;n=sum(s[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]));checked+=1
    allocation=[{**r,'count':s[r['variable']]} for r in mapping if s[r['variable']]];assert allocation==load(BASE/'allocation.json');assert all(sum(r['count'] for r in allocation if r['family']==f)==n for f,n in counts.items());bands=[sum(r['count']*r['demands'][j] for r in allocation) for j in range(63)];caps=load(DATA/'band-capacities.json');assert all(a<=b for a,b in zip(bands,caps));write(OUT/'verified-allocation.json',allocation);write(OUT/'band-loads.json',{'demand_units':bands,'capacity_units':caps,'family_counts':counts})
else:assert result['status'] in ['INFEASIBLE','UNKNOWN'] and not response.solution and not (BASE/'allocation.json').exists()
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'terminal_status':result['status'],'necessary_allocation':positive,'required_family_counts':counts,'solver_calls':1,'actual_solver_seconds':result['seconds'],'actual_shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':result['solver_soft_overrun_seconds'],'returned_constraints_checked':checked,'all66_original_obligations_preserved':True,'all_calls_closed':True,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
