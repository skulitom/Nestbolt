from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_profile_exclusion_master.py','run_h5_mixed_cog_exclusion_master.py'),('audit_h5_profile_exclusion_response.py','audit_h5_mixed_cog_exclusion_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-profile-exclusion-master-20261026','h5-mixed-cog-exclusion-master-20261026').replace('h5-profile-exclusion-search-20261026','h5-mixed-cog-exclusion-search-20261026').replace('h5-aligned-cog-band-capacity-20261026','h5-mixed-cog-band-capacity-20261026').replace('679-variable/75-constraint','714-variable/78-constraint').replace('all679 variable domains and75 constraints','all714 variable domains and78 constraints').replace('len(sol)==679','len(sol)==714').replace('new56.25degree guarded-source geometry','two-phase56.25/65.25degree guarded-source geometry with at least one new-phase cog')
    if src.startswith('audit'):
        s=s.replace('range(11)','range(12)');old="assert tuple(totals[i] for i in [4,5,6,10])!=(1,2,1,1);";assert old in s
        s=s.replace(old,"assert totals[11]>=1 and (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10],totals[11])!=(1,1,2,1,2);")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
