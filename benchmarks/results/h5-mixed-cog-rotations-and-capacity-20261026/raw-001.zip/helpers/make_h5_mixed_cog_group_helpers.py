"""Prepare the newly allocated two/two cog-phase family with all bracket mirrors."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
pairs=[('build_h5_profile_group_strip.py','build_h5_mixed_cog_group_strip.py'),('audit_h5_profile_group_geometry.py','audit_h5_mixed_cog_group_geometry.py'),('prepare_h5_profile_group_shared_model.py','prepare_h5_mixed_cog_group_shared_model.py'),('audit_h5_profile_group_shared_model.py','audit_h5_mixed_cog_group_shared_model.py'),('run_h5_profile_group_probe.py','run_h5_mixed_cog_group_probe.py'),('audit_h5_profile_group_response.py','audit_h5_mixed_cog_group_response.py')]
for src,dst in pairs:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-profile-group-strip-source-20261026','h5-mixed-cog-group-strip-source-20261026').replace('h5-profile-group-shared-probe-20261026','h5-mixed-cog-group-shared-probe-20261026')
    s=s.replace('[[0,4],[2,6],[3,5],[3,5],[10],[9],[9],[9],[9]]','[[0,4],[2,6],[3,5],[3,5],[10],[9],[9],[11],[11]]')
    if src.startswith('build'):
        s=s.replace("PROFILES=ROOT/'output/h5-aligned-cog-profiles-20261026'","PROFILES=ROOT/'output/h5-mixed-cog-angle-screen-20261026'")
        s=s.replace("spec=load(PROFILES/'plan.json')","spec=load(ROOT/'output/h5-aligned-cog-profiles-20261026/plan.json')")
        s=s.replace('len(keys)==30','len(keys)==39').replace("'pair_cases':30","'pair_cases':39")
        old="ROOT/'output/h5-aligned-alternate-strip-source-20261026']:";assert old in s;s=s.replace(old,"ROOT/'output/h5-aligned-alternate-strip-source-20261026',ROOT/'output/h5-profile-group-strip-source-20261026']:")
        old="inputs.append(ROOT/'output/h5-aligned-alternate-strip-probe-20261026/response-audit/checks.json');assert load(inputs[-1])['passed'];"
        new="inputs.append(ROOT/'output/h5-mixed-cog-band-search-20261026/audit/checks.json');assert load(inputs[-1])['passed'];inputs.extend([ROOT/'output/h5-aligned-cog-profiles-20261026/plan.json',ROOT/'output/h5-mixed-cog-band-search-20261026/allocation.json']);allocation=load(inputs[-1]);totals={p:sum(r['count'] for r in allocation if r['profile']==p) for p in range(12)};assert (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10],totals[9],totals[11])==(1,1,2,1,2,2);"
        assert old in s;s=s.replace(old,new)
        s=s.replace("{'profiles':[10],'count':1}]","{'profiles':[10],'count':1},{'profiles':[9],'count':2},{'profiles':[11],'count':2}]")
        s=s.replace('Insert10 and four aligned cogs9 remain.','Insert10, two56.25degree cogs9 and two65.25degree cogs11 remain.').replace('all30 cases','all39 cases').replace('fixed cog angle','declared two/two cog-angle counts')
    elif 'geometry' in src:
        s=s.replace("'h5-aligned-cog-capacity-and-cover-limit-20261026']","'h5-aligned-cog-capacity-and-cover-limit-20261026','h5-aligned-profile-family-exclusions-20261026']")
        s=s.replace("['h5-aligned-alternate-strip']","['h5-aligned-alternate-strip','h5-mixed-cog-angle-screen','h5-mixed-cog-band-search']").replace('len(needed)==30','len(needed)==39')
    elif src.startswith('prepare'):
        old='for i in range(5,8):linear({2*i:1,2*(i+1):-1},-2**63,0)';assert old in s;s=s.replace(old,'for i in [5,7]:linear({2*i:1,2*(i+1):-1},-2**63,0)')
        s=s.replace('len(m.constraints)==24','len(m.constraints)==23').replace('the four cog copies are x-ordered.','cogs are x-ordered only within identical phase pairs5/6 and7/8.')
    elif 'shared_model' in src:
        old='for i in range(5,8):linear({2*i:1,2*(i+1):-1},-2**63,0)';assert old in s;s=s.replace(old,'for i in [5,7]:linear({2*i:1,2*(i+1):-1},-2**63,0)')
        s=s.replace('vi==26 and ci==24','vi==26 and ci==23').replace('Only identical3/5-copy order and cog x order are allowed.','Only identical3/5-copy order and separate same-phase cog-pair x orders are allowed; never order across different phases.')
    elif 'response' in src:
        old='selected.extend([10]+[9]*4);assert selected[2]<=selected[3] and sol[10:18:2]==sorted(sol[10:18:2])';new='selected.extend([10,9,9,11,11]);assert selected[2]<=selected[3] and sol[10:14:2]==sorted(sol[10:14:2]) and sol[14:18:2]==sorted(sol[14:18:2])';assert old in s;s=s.replace(old,new).replace('current cog angle','declared two/two cog-angle counts')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
