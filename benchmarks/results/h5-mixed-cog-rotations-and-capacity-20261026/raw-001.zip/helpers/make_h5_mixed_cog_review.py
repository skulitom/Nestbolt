from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_profile_family_checkpoint.py').read_text(encoding='utf-8').replace('h5-profile-family-checkpoint-review-20261026','h5-mixed-cog-checkpoint-review-20261026')
old="head=='88e1dc19c23eb9c5aa01b57d9537d66d87a841fb'";assert old in s;s=s.replace(old,"head=='1299e16bd461f17ef73af2bf33160c2200632a59'")
compile(s,'review_h5_mixed_cog_checkpoint.py','exec')
with (ROOT/'output/review_h5_mixed_cog_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
