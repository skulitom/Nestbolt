"""Screen original cog pairs at two tooth phases; no packing solver or full-layout claim."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
from shapely.geometry import Polygon,LineString,shape,mapping
from shapely.affinity import translate
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-aligned-cog-profiles-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-mixed-cog-angle-screen-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'pairs').mkdir();shutil.copyfile(__file__,OUT/'screen.py');start=time.perf_counter();deadline=start+240
profiles=load(PARENT/'profiles.json');job=load(JOB);g=next(p for p in job['parts'] if p['id']=='cog');old=profiles[9];cx,cy=old['original_center'];assert g['rotations']['kind']=='free' and not g['allow_mirror']
pts=g['geometry'][0]['outer'];assert len(pts)==80
rad=[math.hypot(x-cx,y-cy) for x,y in pts];angles=[math.atan2(y-cy,x-cx)%math.tau for x,y in pts]
assert all(abs(rad[i]-(109.2 if i%4 in [0,3] else 140.))<1e-6 for i in range(80))
pitch=[(angles[(i+4)%80]-angles[i])%math.tau for i in range(0,80,4)]
assert max(abs(p-math.tau/20) for p in pitch)<1e-8
theta=old['rotation_radians']+math.pi/20;co,si=math.cos(theta),math.sin(theta);rotated=[((x-cx)*co-(y-cy)*si,(x-cx)*si+(y-cy)*co) for x,y in pts];poly=Polygon(rotated);assert poly.is_valid
profiles.append({**old,'index':11,'rotation_radians':theta,'rotation_hex':theta.hex(),'vertices':rotated,'bounds':list(poly.bounds),'geometry':mapping(poly)})
spec=load(PARENT/'plan.json');stock=[F(*v) for v in spec['stock_bounds_rational']];pad=F(.0125)+F(.000001);bounds={}
for pi in [9,11]:
    b=profiles[pi]['bounds'];bounds[pi]=[math.ceil((stock[0]+pad-F(b[0]))*1000),math.ceil((stock[1]+pad-F(b[1]))*1000),math.floor((stock[2]-pad-F(b[2]))*1000),math.floor((stock[3]-pad-F(b[3]))*1000)]
paths=[JOB,PARENT/'profiles.json',PARENT/'plan.json',PARENT/'audit/checks.json',ROOT/'output/h5-balanced-union-search-20261026/audit/checks.json',ROOT/'benchmarks/results/h5-aligned-profile-family-exclusions-20261026/checks.json']
assert load(paths[-2])['status']=='INFEASIBLE' and load(paths[-1])['passed']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'cog_profiles':[9,11],'angles_degrees':[math.degrees(old['rotation_radians']),math.degrees(theta)],'tooth_count':20,'half_tooth_radians':math.pi/20,'maximum_pitch_error_radians':max(abs(p-math.tau/20) for p in pitch),'stock_bounds_rational':spec['stock_bounds_rational'],'anchor_bounds_units1000':bounds,'construction_limit_seconds':240,'solver_calls':0,'method':'Check the actual four-vertex tooth pattern and20 tooth pitches. Append an exact full-original cog rotation9degrees beyond the aligned56.25degree profile; retain every parent profile unchanged. For all four ordered9/11 pair choices construct full original Minkowski forbidden geometry plus circumscribed128-gon clearance .2126mm. Within the exact relative stock-y interval inspect all guarded-boundary vertex heights and endpoints; horizontal slices give the rightmost forbidden x. This numeric boundary screen selects a candidate, not a global packing proof. Round candidate dy to a legal micrometre-grid value, recompute the rightmost boundary, round dx outward, and check the original filled outer polygons at the resulting two-part stock placement. Holes are preserved in the unchanged job and required at any full-layout audit. No fixed-angle exclusion transfers and no solver/native/full-target claim.'})
write(OUT/'profiles.json',profiles);summaries=[]
def rings(geom):
    for p in [geom] if geom.geom_type=='Polygon' else geom.geoms:
        yield p.exterior
        yield from p.interiors
def right_edge(guarded,y):
    cut=guarded.intersection(LineString([(-1000,y),(1000,y)]));assert not cut.is_empty;return cut.bounds[2]
for pa,pb in product([9,11],repeat=2):
    assert time.perf_counter()<deadline
    a,b=shape(profiles[pa]['geometry']),shape(profiles[pb]['geometry']);aa,bb=bounds[pa],bounds[pb];dylo,dyhi=bb[1]-aa[3],bb[3]-aa[1]
    raw=raw_obstacle(a,b);guarded=expand(raw,.2125,.0001);assert guarded.covers(raw)
    ys=sorted({dylo/1000,dyhi/1000,0.}|{y for r in rings(guarded) for x,y in r.coords if dylo/1000<=y<=dyhi/1000});rows=[]
    for dy in ys:
        dx=right_edge(guarded,dy);rows.append({'dy_mm':dy,'rightmost_forbidden_dx_mm':dx,'pair_span_x_mm':dx+b.bounds[2]-a.bounds[0]})
    chosen=min(rows,key=lambda r:r['pair_span_x_mm']);dyunits=max(dylo,min(dyhi,round(chosen['dy_mm']*1000)));dxunits=math.ceil((right_edge(guarded,dyunits/1000)+.000002)*1000)
    ax=aa[0];ay=max(aa[1],bb[1]-dyunits);bx=ax+dxunits;by=ay+dyunits
    assert aa[0]<=ax<=aa[2] and aa[1]<=ay<=aa[3] and bb[0]<=bx<=bb[2] and bb[1]<=by<=bb[3]
    ap,bp=translate(a,ax/1000,ay/1000),translate(b,bx/1000,by/1000);gap=ap.distance(bp);required=(job['clearance']+3000*32*2**-23)/math.cos(.05);assert gap>required and not ap.intersects(bp)
    fullstock=[float(v) for v in stock]
    for p in [ap,bp]:
        q=p.bounds;assert min(q[0]-fullstock[0],q[1]-fullstock[1],fullstock[2]-q[2],fullstock[3]-q[3])>3000*32*2**-23
    name=f'{pa:03d}-{pb:03d}';write(OUT/'pairs'/f'{name}.json',{'profiles':[pa,pb],'raw_forbidden':mapping(raw),'guarded_forbidden':mapping(guarded),'relative_y_bounds_units1000':[dylo,dyhi],'boundary_samples':rows,'chosen_sample':chosen,'grid_anchors_units1000':[[ax,ay],[bx,by]],'grid_relative_units1000':[dxunits,dyunits],'original_pair_gap_mm':gap,'required_native_pair_gap_mm':required,'grid_pair_span_x_mm':bp.bounds[2]-ap.bounds[0]})
    summaries.append({'profiles':[pa,pb],'boundary_samples':len(rows),'minimum_screened_dx_mm':chosen['rightmost_forbidden_dx_mm'],'minimum_screened_span_x_mm':chosen['pair_span_x_mm'],'grid_dx_mm':dxunits/1000,'grid_dy_mm':dyunits/1000,'grid_span_x_mm':bp.bounds[2]-ap.bounds[0],'original_gap_mm':gap})
write(OUT/'pair-summary.json',summaries);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'original_outer_vertices':80,'original_hole_vertices':len(g['geometry'][0]['holes'][0]),'tooth_count':20,'half_tooth_degrees':9.,'profiles':len(profiles),'parent_profiles_unchanged':11,'new_angle_degrees':math.degrees(theta),'new_width_mm':poly.bounds[2]-poly.bounds[0],'new_height_mm':poly.bounds[3]-poly.bounds[1],'ordered_pair_cases':4,'best_same_phase_span_x_mm':min(r['grid_span_x_mm'] for r in summaries if r['profiles'][0]==r['profiles'][1]),'best_mixed_phase_span_x_mm':min(r['grid_span_x_mm'] for r in summaries if r['profiles'][0]!=r['profiles'][1]),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'));print(summaries)
