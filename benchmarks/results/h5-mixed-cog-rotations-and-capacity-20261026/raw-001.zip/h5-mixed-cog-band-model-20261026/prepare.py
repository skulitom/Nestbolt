"""Build the small necessary aggregate band-area model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-mixed-cog-band-capacity-20261026';OUT=ROOT/'output/h5-mixed-cog-band-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in SOURCE.rglob('*') if p.is_file()},'method':'One integer count for each audited profile/vertical cell, bounded by its mandatory family count. Three exact family sums require four brackets,one insert,four cogs. Sixty-three necessary band inequalities use every exact independently verified lower area coefficient and stock capacity. Require at least one cog in new profile11, while all four cogs choose9/11. No prior conditional exclusion is copied. No coordinates, collisions, objective, hints or omitted originals. Independent full reconstruction and actual solver import before one separately bounded20second call within30shared seconds. Positive is only a necessary allocation; negative retains only the recorded two-phase scope with at least one new-angle cog.'});model=cp_model_pb2.CpModelProto();mapping=[]
for pi in spec['profiles']:
    p=load(SOURCE/'profiles'/f'{pi:03d}.json')
    for cell in p['cells']:
        index=len(model.variables);model.variables.add(name=f'p{pi}-cell{cell["index"]}',domain=[0,spec['required_original_counts'][p['family']]]);mapping.append({'variable':index,'profile':pi,'family':p['family'],'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
def constraint(terms,low,high):
    c=model.constraints.add();c.linear.vars.extend(v for v,k in terms);c.linear.coeffs.extend(k for v,k in terms);c.linear.domain.extend([low,high])
for family,count in spec['required_original_counts'].items():constraint([(r['variable'],1) for r in mapping if r['family']==family],count,count)
for band,capacity in enumerate(load(SOURCE/'band-capacities.json')):constraint([(r['variable'],r['demands'][band]) for r in mapping if r['demands'][band]],-2**63,capacity)
constraint([(r['variable'],1) for r in mapping if r['profile']==11],1,4)
write(OUT/'mapping.json',mapping);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'family_counts':spec['required_original_counts'],'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'))
