"""Read the selected source poses as a complete original-identity partial with all cutouts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import copy,json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];SELECT=ROOT/'output/h5-fixed36-source-selection-20261026';POOL=ROOT/'output/h5-fixed36-source-cog-pool-20261026';INV=ROOT/'output/h5-fixed36-cog-neighborhood-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=SELECT/'original-readback'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();inputs=[SELECT/'response-audit/checks.json',SELECT/'response-audit/selected-candidate-indices.json',POOL/'candidates.json',POOL/'audit-segment-circles/checks.json',INV/'next-neighborhood.json',INV/'checks.json',SRC/'items.json',SRC/'geometry.json',JOB];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Assign selected identical cog poses to required original cog copy IDs in order. Preserve the36 fixed first non-cogs and15 fixed short non-cogs exactly. Reconstruct every original outer/cutout vertex directly and check all same-sheet filled-outer pairs and guarded stock edges. Preserve missing original cog IDs explicitly. No native call on a partial; no reinterpretation of the finite12 optimum as unrestricted impossibility.'})
assert load(SELECT/'response-audit/checks.json')['passed'] and load(POOL/'audit-segment-circles/checks.json')['passed'];indices=load(SELECT/'response-audit/selected-candidate-indices.json');pool=load(POOL/'candidates.json');spec=load(INV/'next-neighborhood.json');items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};placements=copy.deepcopy(spec['fixed_first_placements']+spec['fixed_short_placements'])
for original,index in zip(spec['mandatory_moving_first_cogs'],indices):
    p=copy.deepcopy(pool[index]['placement']);p['copy_index']=items[original]['copy'];placements.append(p)
missing=spec['mandatory_moving_first_cogs'][len(indices):];placed=[ids[p['part_id'],p['copy_index']] for p in placements];assert len(set(placed))==len(placed) and sorted(placed+missing)==list(range(66));job=load(JOB);families={p['id']:p for p in job['parts']};stocks=[[float(F(*v)) for v in row] for row in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};holes=vertices=0;edges=[]
for p in placements:
    original=ids[p['part_id'],p['copy_index']];f=families[p['part_id']];g=f['geometry'][0];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];assert not t['mirrored'] or f['allow_mirror'];assert f['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in f['rotations']['degrees'])
    def ring(vs):return [(mi*x*co-y*si+tx,mi*x*si+y*co+ty) for x,y in vs]
    outer=ring(g['outer']);inside=[ring(h) for h in g.get('holes',[])];full=Polygon(outer,inside);filled=Polygon(outer);source=Polygon(g['outer'],g.get('holes',[]));assert full.is_valid and filled.is_valid and abs(full.area-source.area)<1e-7 and len(full.interiors)==len(inside)
    for a,b in zip(full.interiors,inside):assert list(a.coords)[:-1]==b
    holes+=len(inside);vertices+=sum(len(h) for h in inside);sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;polys[original]=(sheet,filled);edges.append({'original':original,'extra_margins_mm':extra})
pairs=[]
for i,j in combinations(sorted(polys),2):
    sa,a=polys[i];sb,b=polys[j]
    if sa==sb:
        d=a.distance(b);assert a.disjoint(b) and d>gap;pairs.append({'originals':[i,j],'distance_mm':d})
write(OUT/'placements.json',placements);write(OUT/'missing-originals.json',missing);write(OUT/'pairs.json',pairs);write(OUT/'stock-edges.json',edges);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':len(placements),'first_original_cogs':len(indices),'fixed_first_noncogs':36,'fixed_short_noncogs':15,'missing_original_cogs':missing,'same_sheet_original_pair_checks':len(pairs),'stock_edge_checks':4*len(edges),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(r['distance_mm'] for r in pairs),'required_native_pair_gap_mm':gap,'minimum_extra_stock_mm':min(min(r['extra_margins_mm']) for r in edges),'all66_identities_accounted_once':True,'all_fixed_non_cog_poses_preserved':True,'part_in_hole_used':False,'finite_pool_optimum_only':True,'native_calls':0,'full66_target_witness':len(placements)==66,'H5_complete':False});print(load(OUT/'checks.json'))
