"""Audit the single finite source selection and every returned Boolean/linear constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed36-source-selection-20261026';RUN=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def model(p):
    v=pb.CpModelProto();v.ParseFromString(p.read_bytes());return v
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify one declared closed call, actual model/parameters and terminal timings. Independently evaluate every returned variable, active at-most-one, conditional bool-and and cardinality row, the count objective and complete seed. Save selected original source pose indices. A count below15 is an incomplete original66 job, regardless of finite optimum; no continuous exclusion follows.'})
for p in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=30 and budget['shared_seconds']==30 and budget['deadline_perf_counter']==budget['start_perf_counter']+30 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==20
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert census['solver_calls']==len(census['results'])==len(list(RUN.rglob('opened.json')))==1 and not census['pending_pairs'] and r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1 and r['parts']==list(range(15))
m=model(folder/'model.pb');assert m==model(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==20
response=pb.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert pb.CpSolverStatus.Name(response.status)==r['status'] and abs(response.wall_time-r['seconds'])<.2 and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-20) and r['seconds']<=r['stage_seconds'];sol=list(response.solution);active=0;positive=r['status'] in ['FEASIBLE','OPTIMAL'];selected=[]
if positive:
    assert len(sol)==len(m.variables) and sol[:30]==r['original_coordinates_units1000'] and all(v in [0,1] for v in sol) and 12<=sum(sol)<=15
    def truth(i):return bool(sol[i]) if i>=0 else not bool(sol[-i-1])
    for v,n in zip(m.variables,sol):assert any(a<=n<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    for c in m.constraints:
        if not all(truth(i) for i in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':value=sum(sol[i]*coef for i,coef in zip(c.linear.vars,c.linear.coeffs));assert any(a<=value<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='at_most_one':assert sum(truth(i) for i in c.at_most_one.literals)<=1
        else:assert kind=='bool_and' and all(truth(i) for i in c.bool_and.literals)
        active+=1
    selected=[i for i,v in enumerate(sol) if v];assert response.objective_value==len(selected) and len(selected)<=response.best_objective_bound<=15
    if r['status']=='OPTIMAL':assert response.best_objective_bound==len(selected)
    write(OUT/'selected-candidate-indices.json',selected)
else:assert r['status']=='UNKNOWN' and not sol
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'positive_variables_verified':len(sol),'positive_active_constraints_verified':active,'selected_original_cogs':len(selected),'solver_objective':response.objective_value,'finite_pool_best_bound':response.best_objective_bound,'finite_pool_optimal':r['status']=='OPTIMAL','all15_cogs_required_for_target':True,'original_layout_readback_pending':positive,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
