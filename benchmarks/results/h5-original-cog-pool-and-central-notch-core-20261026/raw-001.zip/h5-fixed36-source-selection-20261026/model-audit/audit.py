"""Independently reconstruct all finite source selection protobuf fields and actual import."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed36-source-selection-20261026';POOL=ROOT/'output/h5-fixed36-source-cog-pool-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rows(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return [json.loads(line) for line in f]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for p in [BASE/'plan.json',POOL/'audit-segment-circles/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(POOL/'audit-segment-circles/checks.json')['passed'];n=len(load(POOL/'candidates.json'));seeds=set(load(POOL/'seed-indices.json'));cliques=rows(POOL/'cliques.jsonl.gz');adj=[0]*n;expected=pb.CpModelProto();forward={}
for i in range(n):v=expected.variables.add();v.name=f'original-cog-pose{i}';v.domain.extend([0,1])
for row in cliques:
    if len(row)>2:expected.constraints.add().at_most_one.literals.extend(row)
    else:i,j=row;forward.setdefault(i,set()).add(j)
    mask=sum(1<<i for i in row)
    for i in row:adj[i]|=mask^(1<<i)
for i in sorted(forward):
    c=expected.constraints.add();c.enforcement_literal.append(i);c.bool_and.literals.extend(-j-1 for j in sorted(forward[i]))
c=expected.constraints.add();c.linear.vars.extend(range(n));c.linear.coeffs.extend([1]*n);c.linear.domain.extend([12,15]);expected.objective.vars.extend(range(n));expected.objective.coeffs.extend([-1]*n);expected.objective.scaling_factor=-1;expected.solution_hint.vars.extend(range(n));expected.solution_hint.values.extend(int(i in seeds) for i in range(n))
original=[0]*n;edges=rows(POOL/'conflicts.jsonl.gz')
for i,j in edges:original[i]|=1<<j;original[j]|=1<<i
assert adj==original;sm=sum(1<<i for i in seeds);assert len(seeds)==12 and all(not(adj[i]&sm) for i in seeds)
actual=pb.CpModelProto();actual.ParseFromString((BASE/'models/000.pb').read_bytes());assert actual==expected;model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'roundtrip.pb'));actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==expected
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':n,'constraints':len(expected.constraints),'complete_original_conflict_edges':len(edges),'seed_count':12,'maximum_selected_cogs':15,'all15_required_for_target':True,'all_protobuf_fields_reconstructed':True,'all_residual_edges_preserved':True,'complete_original_seed_hint_verified':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
