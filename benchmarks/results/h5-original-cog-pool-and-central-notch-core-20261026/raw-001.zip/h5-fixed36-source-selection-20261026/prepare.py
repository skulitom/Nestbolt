"""One finite source-pose selection; all15 cogs remain required for target acceptance."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];POOL=ROOT/'output/h5-fixed36-source-cog-pool-20261026';INV=ROOT/'output/h5-fixed36-cog-neighborhood-20261026';OUT=ROOT/'output/h5-fixed36-source-selection-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(POOL/'audit-segment-circles/checks.json')['passed'];OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();pool=load(POOL/'candidates.json');seeds=load(POOL/'seed-indices.json');n=len(pool)
with gzip.open(POOL/'cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[json.loads(line) for line in f]
inputs=[POOL/p for p in ['plan.json','candidates.json','seed-indices.json','cliques.jsonl.gz','conflicts.jsonl.gz','result.json','audit-segment-circles/checks.json','audit-segment-circles/plan.json','audit-segment-circles/circle-certificates.json']]+[INV/'next-neighborhood.json',INV/'checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'required_cog_count_for_target':15,'fixed_first_noncogs':36,'fixed_short_noncogs':15,'method':'New finite original-source contact selection for the changed36-fixed neighborhood. Every candidate satisfies original native-guard pair and stock requirements. All compressed cliques and all residual conflict edges remain. Combine residual forward edges into equivalent conditional bool-and implications without dropping any pair. Maximize selected original cogs from the preserved12-pose seed to at most15. Counts below15 are diagnostic partials and do not satisfy the original target; the full66 obligation remains explicit. A finite optimum is not a continuous/all-angle exclusion. Independently audit full protobuf and actual import/export before this sole20solver/30shared call. No retries, no native validation on partials.'})
m=pb.CpModelProto()
for i in range(n):m.variables.add(name=f'original-cog-pose{i}',domain=[0,1])
large=[];forward={}
for row in cliques:
    if len(row)>2:large.append(row);m.constraints.add(at_most_one=pb.BoolArgumentProto(literals=row))
    else:a,b=row;forward.setdefault(a,set()).add(b)
for i,js in sorted(forward.items()):m.constraints.add(enforcement_literal=[i],bool_and=pb.BoolArgumentProto(literals=[-j-1 for j in sorted(js)]))
m.constraints.add(linear=pb.LinearConstraintProto(vars=list(range(n)),coeffs=[1]*n,domain=[12,15]));m.objective.vars.extend(range(n));m.objective.coeffs.extend([-1]*n);m.objective.scaling_factor=-1;m.solution_hint.vars.extend(range(n));m.solution_hint.values.extend(int(i in seeds) for i in range(n))
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'inventory.json',[{'index':0,'parts':list(range(15)),'variables':n,'constraints':len(m.constraints),'model_sha256':digest(p),'solver_seconds':20,'original_coordinates_field_is_pose_selection_bits_only':True}]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variables':n,'constraints':len(m.constraints),'larger_cliques':len(large),'combined_forward_implications':len(forward),'represented_residual_edges':sum(len(js) for js in forward.values()),'solver_calls':0});print(load(OUT/'prepared.json'))
