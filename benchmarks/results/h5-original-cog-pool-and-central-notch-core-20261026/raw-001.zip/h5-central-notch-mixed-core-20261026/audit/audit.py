"""Independent direct-vertex readback and complete identity inventory for the changed core."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json, math, shutil, time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-central-notch-mixed-core-20261026'
CORE=ROOT/'output/h5-central-notch-frame-core-20261026'
SHORT=ROOT/'output/h5-nine-insert-short-sheet-20261026'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PROFILES=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
inputs=[BASE/n for n in ['checks.json','placements.json','added-first-placements.json','anchors.json','mandatory-remaining-originals.json','pairs.json','stock-edges.json']]+[CORE/'frame-placements.json',CORE/'partial33-placements.json',CORE/'notch-container.json',SHORT/'short-sheet-placements.json',SHORT/'audit/checks.json',SRC/'items.json',SRC/'geometry.json',JOB,PROFILES]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct each transformed original outer and every cutout using direct vertex arithmetic. Rebuild the sixteen turned and two unturned frame anchors from the stated pattern. Check six mixed-core anchors, permissions, areas, every same-sheet filled-outer pair and every guarded stock edge. Verify unchanged short15 transforms and a disjoint complete66 original identity partition. No affine helper or builder-computed polygon is reused. The finite four-bracket notch negative and prior fixed36 pool optimum are not inherited.'})
assert digest(JOB)=='2aede6286cf59186781a67a2c355f305aad2d50e735bbfa6cad5ea7dd2ffc6bb'
assert load(BASE/'checks.json')['passed'] and load(SHORT/'audit/checks.json')['passed']
items=load(SRC/'items.json');ids={(x['family'],x['copy']):i for i,x in enumerate(items)}
placements=load(BASE/'placements.json');byid={ids[p['part_id'],p['copy_index']]:p for p in placements}
assert len(placements)==len(byid)==39
assert placements[:33]==load(CORE/'partial33-placements.json')
short=[p for p in placements if p['sheet_id']=='sheet-1'];first=[p for p in placements if p['sheet_id']=='sheet-0']
assert short==load(SHORT/'short-sheet-placements.json') and len(short)==15 and len(first)==24
frames=load(CORE/'frame-placements.json');assert placements[:18]==frames
for i in range(18):
    p=byid[i];t=p['transform'];assert p['sheet_id']=='sheet-0' and not t['mirrored']
    if i<16:
        row,col=divmod(i,4);x=6.525+col*350.225;y=6.525+row*450.225
        assert t['rotation_radians']==math.pi/2 and max(abs(a-b) for a,b in zip(t['translation'],[x+350,y]))<1e-10
    else:
        x=6.525 if i==16 else 1043.475;y=1807.425
        assert t['rotation_radians']==0 and max(abs(a-b) for a,b in zip(t['translation'],[x,y]))<1e-10
expected=[(18,7,456.75,1807.65),(19,5,537.2,1820.125),(38,10,531.975,1907.875),(39,8,787.425,1807.65),(40,8,897.65,1807.65),(41,10,787.425,1987.875)]
profiles={p['index']:p for p in load(PROFILES)}
assert [ids[p['part_id'],p['copy_index']] for p in load(BASE/'added-first-placements.json')]==[r[0] for r in expected]
for saved,(i,profile,x,y) in zip(load(BASE/'anchors.json'),expected):
    assert saved['original']==i and saved['profile']==profile and max(abs(a-b) for a,b in zip(saved['lower_left_mm'],[x,y]))<1e-10
    t=byid[i]['transform'];p=profiles[profile]
    assert t['rotation_radians']==p['rotation_radians'] and t['mirrored']==p['mirrored']
    assert max(abs(a-b) for a,b in zip(t['translation'],[x-p['rotated_original_min'][0],y-p['rotated_original_min'][1]]))<1e-10
remaining=load(BASE/'mandatory-remaining-originals.json')
assert remaining==[20,23,24,27]+list(range(42,50))+list(range(51,66))
assert sorted(list(byid)+remaining)==list(range(66)) and not set(byid)&set(remaining)
job=load(JOB);families={p['id']:p for p in job['parts']}
stocks=[[float(F(*v)) for v in b] for b in load(SRC/'geometry.json')['stock_bounds_rational']]
guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05)
shapes={};edges=[];holes=vertices=0
for i,p in sorted(byid.items()):
    f=families[p['part_id']];g=f['geometry'][0];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    assert not t['mirrored'] or f['allow_mirror']
    assert f['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in f['rotations']['degrees'])
    def ring(vs):return [(mi*x*co-y*si+tx,mi*x*si+y*co+ty) for x,y in vs]
    outer=ring(g['outer']);inside=[ring(h) for h in g.get('holes',[])];filled=Polygon(outer);full=Polygon(outer,inside);source=Polygon(g['outer'],g.get('holes',[]))
    assert filled.is_valid and full.is_valid and abs(source.area-full.area)<1e-7 and len(full.interiors)==len(inside)
    for actual,wanted in zip(full.interiors,inside):assert list(actual.coords)[:-1]==wanted
    holes+=len(inside);vertices+=sum(map(len,inside));sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet]
    extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard
    shapes[i]=(sheet,filled);edges.append({'original':i,'extra_margins_mm':extra})
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:
        d=a.distance(b);assert a.disjoint(b) and d>gap;pairs.append({'originals':[i,j],'distance_mm':d})
saved_pairs=load(BASE/'pairs.json');assert len(pairs)==len(saved_pairs)==381
for a,b in zip(pairs,saved_pairs):assert a['originals']==b['originals'] and abs(a['distance_mm']-b['distance_mm'])<1e-9
saved_edges={r['original']:r for r in load(BASE/'stock-edges.json')}
for a in edges:assert max(abs(x-y) for x,y in zip(a['extra_margins_mm'],saved_edges[a['original']]['extra_margins_mm']))<1e-9
write(OUT/'pairs.json',pairs);write(OUT/'stock-edges.json',edges)
write(OUT/'next-neighborhood.json',{'fixed_first_originals':[ids[p['part_id'],p['copy_index']] for p in first],'fixed_first_placements':first,'fixed_short_originals':[ids[p['part_id'],p['copy_index']] for p in short],'fixed_short_placements':short,'mandatory_moving_first_originals':remaining,'mandatory_moving_family_counts':dict(Counter(items[i]['family'] for i in remaining)),'all66_originals_accounted_once':True,'part_in_hole':False,'old_domains_or_pool_limits_transferred':False,'old64_partial_preserved':True,'next_action':'Construct a fresh joint original-geometry candidate space for all four brackets, eight inserts and fifteen cogs around these24 first-sheet fixed originals. Old36-fixed domains, seeds and the finite12-cog optimum do not restrict this changed core. Every moving original stays mandatory. Any source-positive needs independent full66 readback, native/material validation, production60-second integration and the entire H5 matrix. The closed four-bracket notch and source-pool selection calls may not be repeated, reseeded or extended.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_verified':39,'fixed_first_originals':24,'fixed_short_originals':15,'mandatory_moving_originals':27,'mandatory_moving_family_counts':dict(Counter(items[i]['family'] for i in remaining)),'all66_originals_accounted_once':True,'original_pair_checks':len(pairs),'stock_edge_checks':4*len(edges),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'required_native_pair_gap_mm':gap,'minimum_extra_stock_mm':min(min(p['extra_margins_mm']) for p in edges),'all_short_transforms_preserved':True,'all18_frame_patterns_rebuilt':True,'six_mixed_anchors_rebuilt':True,'old_constraints_inherited':False,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False})
print(load(OUT/'checks.json'))
