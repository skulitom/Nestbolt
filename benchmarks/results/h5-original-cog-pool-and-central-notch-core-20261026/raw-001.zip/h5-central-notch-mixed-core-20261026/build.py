"""Fill the central opening with two brackets and four inserts; retain all other originals."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];CORE=ROOT/'output/h5-central-notch-frame-core-20261026';PROFILES=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-central-notch-mixed-core-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[CORE/n for n in ['partial33-placements.json','notch-container.json','checks.json']]+[PROFILES,JOB,SRC/'items.json',SRC/'geometry.json',ROOT/'output/h5-notch-four-brackets-20261026/response-audit/checks.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'After the four-bracket axis-gap construction closes negative, place original brackets18/19 with insert38 between their separate filled outers. Beside that group place vertical inserts39/40 and horizontal insert41 above them. Preserve all18 frames of the changed central-notch core and all15 short originals. This39-original subassembly is not an improvement over the retained64-original partial. It supplies a distinct first-sheet construction with all remaining four brackets, eight inserts and fifteen cogs explicit mandatory movers. No old fixed36 source-pool limit or domain restriction transfers.'})
assert load(CORE/'checks.json')['passed'] and load(ROOT/'output/h5-notch-four-brackets-20261026/response-audit/checks.json')['passed'];items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};profiles={p['index']:p for p in load(PROFILES)};container=load(CORE/'notch-container.json');x,y=container['lower_left_mm'];anchors=[(18,7,x,y),(19,5,x+80.45,y+12.475),(38,10,x+75.225,y+100.225),(39,8,x+330.675,y),(40,8,x+440.9,y),(41,10,x+330.675,y+180.225)];placements=load(CORE/'partial33-placements.json');added=[]
for original,profile,a,b in anchors:
    p=profiles[profile];t={'rotation_radians':p['rotation_radians'],'mirrored':p['mirrored'],'translation':[a-p['rotated_original_min'][0],b-p['rotated_original_min'][1]]};v={'part_id':items[original]['family'],'copy_index':items[original]['copy'],'sheet_id':'sheet-0','transform':t};placements.append(v);added.append(v)
job=load(JOB);families={p['id']:p for p in job['parts']};stock=[[float(F(*v)) for v in b] for b in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);shapes={};holes=verts=0;edges=[]
for p in placements:
    original=ids[p['part_id'],p['copy_index']];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;g=families[p['part_id']]['geometry'][0];a=[mi*co,-si,mi*si,co,*t['translation']];filled=affine_transform(Polygon(g['outer']),a);full=affine_transform(Polygon(g['outer'],g.get('holes',[])),a);assert filled.is_valid and full.is_valid;holes+=len(full.interiors);verts+=sum(len(h) for h in g.get('holes',[]));sheet=int(p['sheet_id'].split('-')[1]);bb=filled.bounds;st=stock[sheet];extra=[bb[0]-st[0],bb[1]-st[1],st[2]-bb[2],st[3]-bb[3]];assert min(extra)>guard;shapes[original]=(sheet,filled);edges.append({'original':original,'extra_margins_mm':extra})
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>gap;pairs.append({'originals':[i,j],'distance_mm':d})
remaining=sorted(set(range(66))-set(shapes));assert len(shapes)==len(placements)==39 and len(remaining)==27 and Counter(items[i]['family'] for i in remaining)=={'bracket':4,'insert':8,'cog':15};write(OUT/'placements.json',placements);write(OUT/'added-first-placements.json',added);write(OUT/'anchors.json',[{'original':i,'profile':p,'lower_left_mm':[a,b]} for i,p,a,b in anchors]);write(OUT/'pairs.json',pairs);write(OUT/'stock-edges.json',edges);write(OUT/'mandatory-remaining-originals.json',remaining)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':39,'fixed_first_noncogs':24,'fixed_short_noncogs':15,'mandatory_remaining_counts':dict(Counter(items[i]['family'] for i in remaining)),'same_sheet_pairs':len(pairs),'stock_edge_checks':156,'cutouts_preserved':holes,'cutout_vertices_preserved':verts,'minimum_pair_gap_mm':min(r['distance_mm'] for r in pairs),'all66_identities_accounted_once':True,'part_in_hole_used':False,'not_a_partial_count_improvement':True,'old_domain_or_pool_limits_transferred':False,'independent_readback_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
