"""Visual inspection of the changed fixed artwork and twelve preserved cog seeds."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed36-space-inspection-20261026';OUT.mkdir();load=lambda p:json.loads(p.read_bytes());fixed=load(ROOT/'output/h5-fixed36-cog-space-20261026/fixed-originals-and-obstacles.json');spec=load(ROOT/'output/h5-fixed36-cog-neighborhood-20261026/next-neighborhood.json');domains=load(ROOT/'output/h5-fixed36-combined-domains-20261026/merged-domain-rectangles.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');source=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];fig,axes=plt.subplots(1,2,figsize=(15,7),layout='constrained')
for ax in axes:
    for r in fixed:
        coords=r['filled_outer']['coordinates'][0];ax.add_patch(Patch(coords,closed=True,facecolor='#b9c4cf',edgecolor='#455568',linewidth=.6))
        if r['family']=='bracket':ax.text(sum(p[0] for p in coords[:-1])/len(coords[:-1]),sum(p[1] for p in coords[:-1])/len(coords[:-1]),str(r['item']),fontsize=9)
    ax.set(xlim=(0,1500),ylim=(1950,3010),xlabel='mm',ylabel='mm');ax.set_aspect('equal');ax.grid(alpha=.15)
for r in domains:
    a,b,c,d=[v/1000 for v in r['bounds_units1000']];axes[0].add_patch(Patch([(a,b),(c,b),(c,d),(a,d)],closed=True,facecolor='#64c8a0',edgecolor='none',alpha=.5))
for row in spec['prior_original_cog_poses_for_diagnostics_only']:
    t=row['placement']['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];points=[(x*co-y*si+tx,x*si+y*co+ty) for x,y in source];axes[1].add_patch(Patch(points,closed=True,facecolor='#73a5df',edgecolor='#275783',linewidth=.7));cx=139.723742*co-139.723742*si+tx;cy=139.723742*si+139.723742*co+ty;axes[1].text(cx,cy,str(row['item']),ha='center',va='center',fontsize=9)
axes[0].set_title('All-angle necessary center regions (green)');axes[1].set_title('Twelve prior original cog poses; three still required');fig.suptitle('First-sheet bottom region after moving nine inserts to the short sheet');fig.savefig(OUT/'inspection.png',dpi=130);plt.close(fig);print(OUT/'inspection.png')
