from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_fourteen_cog_necessary_model.py').read_text(encoding='utf-8').replace('h5-fourteen-cog-necessary-model-20261026','h5-notch-four-brackets-20261026').replace('One mandatory fourteen-cog necessary decision','One four-bracket guarded-notch construction')
with (ROOT/'output/run_h5_notch_four_brackets.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
