"""Use distance to finite source edges, preserving the over-restrictive line test failure."""
from pathlib import Path
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed36-source-cog-pool-20261026';OLD=BASE/'audit-repaired';assert not (OLD/'checks.json').exists()
with (OLD/'failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'exit_code':1,'failed_assertion':'Inner circle must lie in every infinite edge halfplane','checks_json_emitted':False,'solver_calls':0,'diagnosis':'The gear inner disk is inside the polygon but not its convex kernel. Extensions of sloped tooth edges approach the center to30.22mm even though their finite segments stay beyond109.115mm. The attempted infinite-line condition was unnecessarily strong and correctly emitted no pass.','repair':'Certify center winding and exact distance to each finite source edge segment, including endpoint projections. A connected disk containing an interior point and disjoint from every boundary edge lies within the polygon. Keep the same inner radius, outer radius, pair thresholds and120-second audit cap in a new audit-segment-circles folder.'},f,indent=2);f.write('\n')
s=(ROOT/'output/audit_h5_fixed36_source_cog_pool_repaired.py').read_text(encoding='utf-8').replace("OUT=BASE/'audit-repaired'", "OUT=BASE/'audit-segment-circles'")
a="    for a,b in zip(vertices,vertices[1:]+vertices[:1]):\n        dx,dy=b[0]-a[0],b[1]-a[1];ux,uy=center[0]-a[0],center[1]-a[1];cross=dx*uy-dy*ux;assert cross>0 and cross*cross>inner*inner*(dx*dx+dy*dy);assert ux*ux+uy*uy<outer*outer;circle_edges+=1;circle_vertices+=1"
b="""    winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];ux,uy=center[0]-a[0],center[1]-a[1];cross=dx*uy-dy*ux;length=dx*dx+dy*dy;dot=ux*dx+uy*dy;assert length>0
        if dot<=0:assert ux*ux+uy*uy>inner*inner
        elif dot>=length:assert (center[0]-b[0])**2+(center[1]-b[1])**2>inner*inner
        else:assert cross*cross>inner*inner*length
        if a[1]<=center[1]<b[1] and cross>0:winding+=1
        if b[1]<=center[1]<a[1] and cross<0:winding-=1
        assert ux*ux+uy*uy<outer*outer;circle_edges+=1;circle_vertices+=1
    assert winding==1"""
assert a in s;s=s.replace(a,b).replace('Exact positive edge cross products put each whole inner disk in the intersection of its interior halfplanes, hence in its kernel.','Exact nonzero winding places each center inside the original polygon. Exact distances to every finite edge segment, including endpoint projections, exceed the inner radius. The connected inner disk is therefore disjoint from the whole boundary and remains inside the polygon.').replace('gs=np.asarray(gs,dtype=object);centers=np.asarray(centers,dtype=np.int64);expected=[]', 'gs=np.asarray(gs,dtype=object);centers=np.asarray(centers,dtype=np.int64);assert int(np.abs(centers).max())<10**8;expected=[]')
with (ROOT/'output/audit_h5_fixed36_source_cog_pool_segment_circles.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Preserved line-test failure; prepared exact finite-segment disk containment audit.')
