"""Rebuild all geometry-derived restrictions for36 unchanged fixed owners and15 cogs."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
s=(ROOT/'output/screen_h5_fixed40_cog_space.py').read_text(encoding='utf-8').replace('h5-fixed40-cog-space-20261026','h5-fixed36-cog-space-20261026').replace('h5-five-insert-short-sheet-repaired-20261026','h5-nine-insert-short-sheet-20261026').replace('partial64-placements.json','partial63-placements.json').replace('len(first)==40','len(first)==36').replace("'fixed_originals':40","'fixed_originals':36").replace("'mandatory_first_sheet_cogs':14","'mandatory_first_sheet_cogs':15").replace('all40 fixed','all36 fixed').replace('40 non-cog','36 non-cog').replace('all14','all15').replace('the2 remaining cogs','the3 remaining cogs').replace('for14 first-sheet','for15 first-sheet')
with (ROOT/'output/screen_h5_fixed36_cog_space.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['build_h5_fixed40_support_domains','audit_h5_fixed40_support_domains','refine_h5_fixed40_support_domains','audit_h5_fixed40_combined_domains']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8').replace('h5-fixed40-','h5-fixed36-')
    for a,b in [('==40','==36'),("':40","':36"),('all40','all36'),('the40','the36'),('40 fixed','36 fixed')]:s=s.replace(a,b)
    if name=='audit_h5_fixed40_support_domains':s=rep(s,'len(expected)==len(rects)==52','len(expected)==len(rects)==48')
    if name=='audit_h5_fixed40_combined_domains':
        s=rep(s,"load=lambda", "PAIRPROOF=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit'\nload=lambda")
        s=rep(s,"GEOM/'original-cog-proof.json'];write", "GEOM/'original-cog-proof.json',PAIRPROOF/'checks.json',PAIRPROOF/'necessity-proof.json'];write")
        s=rep(s,'D=247441;assert 3*3>2;', "assert load(PAIRPROOF/'checks.json')['passed'] and load(PAIRPROOF/'checks.json')['original_all_angle_center_separation_units1000']==254300\nD=254297;assert 3*3>2;")
        s=s.replace('247441','254297').replace('247444','254300').replace('options=[14]','options=[15]').replace('all14_moving_cogs','all15_moving_cogs').replace('fourteen-cog','fifteen-cog')
    with (ROOT/'output'/f"{name.replace('fixed40','fixed36')}.py").open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent36-owner domain reconstruction and15-cog capacities.')
