"""Diagnostic all-angle disk-center map against the 36 non-cog originals; all15 first-sheet cogs are mandatory."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-nine-insert-short-sheet-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-fixed36-cog-space-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'screen.py');start=time.perf_counter()
inputs=[BASE/n for n in ['partial63-placements.json','mandatory-first-additions.json','audit/checks.json']]+[SRC/'items.json',SRC/'geometry.json',GEOM/'original-cog-proof.json',GEOM/'audit/checks.json',JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_seconds_limit':120,'moving_cog_disk_radius_mm':109.10,'buffer_quadrant_segments':32,'stock_support_radius_mm':139.270,'stock_relaxation_mm':.020,'method':'Construct a diagnostic continuous center map for a109.10mm disk inside every original cog against all36 fixed non-cog original filled outers, releasing all12 existing first-sheet cogs and retaining the3 remaining cogs as mandatory, for15 first-sheet cogs. Round polygon buffers and zero pair clearance deliberately weaken collision obstacles. Stock uses all-angle hull support and0.020mm outward relaxation. Preserve all components and full obstacle owners, plus component bounding-box distances. This floating-geometry map is a screening result, not by itself an independent exact exclusion. No source-angle or solver search, no native call.'})
assert load(BASE/'audit/checks.json')['passed'] and load(GEOM/'audit/checks.json')['passed']
job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(r['family'],r['copy']):i for i,r in enumerate(items)};first=[p for p in load(BASE/'partial63-placements.json') if p['sheet_id']=='sheet-0' and p['part_id']!='cog'];assert len(first)==36;fixed=[];obstacles=[]
for p in first:
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=Polygon([(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in families[p['part_id']]['geometry'][0]['outer']]);assert g.is_valid
    obstacle=g.buffer(109.10,quad_segs=32,join_style='round');assert obstacle.is_valid;obstacles.append(obstacle);fixed.append({'item':ids[p['part_id'],p['copy_index']],'family':p['part_id'],'placement':p,'filled_outer':mapping(g),'disk_obstacle':mapping(obstacle)});assert time.perf_counter()-start<120
stock=[float(F(*v)) for v in load(SRC/'geometry.json')['stock_bounds_rational'][0]];h=139.270;bounds=[stock[0]-.020+h,stock[1]-.020+h,stock[2]+.020-h,stock[3]+.020-h];center_stock=box(*bounds);forbidden=unary_union(obstacles);free=center_stock.difference(forbidden)
components=[]
def collect(g):
    if g.is_empty:return
    if g.geom_type=='Polygon':components.append(g)
    else:
        for child in g.geoms:collect(child)
collect(free);rows=[]
for i,g in enumerate(components):
    b=g.bounds;rows.append({'index':i,'area_mm2':g.area,'bounds':list(b),'bounding_diagonal_mm':math.hypot(b[2]-b[0],b[3]-b[1]),'representative_point':list(g.representative_point().coords)[0],'geometry':mapping(g)})
pairs=[]
for a,b in combinations(rows,2):
    aa,bb=a['bounds'],b['bounds'];dx=max(abs(aa[0]-bb[2]),abs(aa[2]-bb[0]));dy=max(abs(aa[1]-bb[3]),abs(aa[3]-bb[1]));pairs.append({'components':[a['index'],b['index']],'maximum_box_distance_mm':math.hypot(dx,dy)})
write(OUT/'fixed-originals-and-obstacles.json',fixed);write(OUT/'center-stock.json',{'bounds':bounds,'geometry':mapping(center_stock)});write(OUT/'free-center-region.json',mapping(free));write(OUT/'components.json',rows);write(OUT/'component-pair-bounds.json',pairs)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'fixed_originals':36,'mandatory_first_sheet_cogs':15,'free_components':len(rows),'free_area_mm2':free.area,'component_summaries':[{k:v for k,v in r.items() if k!='geometry'} for r in rows],'maximum_component_pair_box_distance_mm':max((r['maximum_box_distance_mm'] for r in pairs),default=None),'screen_only':True,'formal_infeasibility_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
