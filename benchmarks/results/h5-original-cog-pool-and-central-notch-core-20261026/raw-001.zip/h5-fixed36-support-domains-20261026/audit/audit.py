"""Independent exact source rectangles, support union and full-domain coverage."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from h5_rational_geometry_helpers import point_bounds,contains,sub,mul
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed36-support-domains-20261026';SCREEN=ROOT/'output/h5-fixed36-cog-space-20261026';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[ROOT/'output/h5_rational_geometry_helpers.py'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Independently regenerate every orthogonal source grid rectangle. Verify each inset world rectangle corner strictly inside all four true transformed source edges using exact rational sine/cosine intervals. Check global original support constants and every interval-union condition, reconstruct all forbidden boxes and clipping. Enumerate every complete grid cell and compare exact allowed/excluded assignments, covering all boundaries. No GEOS geometry is used for proof.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEOM/'audit/checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed'];cog=load(GEOM/'original-cog-proof.json');assert cog['original_inscribed_radius_units1000']==109115 and cog['all_angle_stock_support_radius_units1000']==139270;R,h,r,beta=140001,139270,109115,15000;assert beta*beta>=R*R-h*h
for x,y in cog['centered_vertices_rational']:assert F(*x)**2+F(*y)**2<=F(R,1000)**2
families={p['id']:p for p in load(JOB)['parts']};fixed=load(SCREEN/'fixed-originals-and-obstacles.json');rects=load(BASE/'fixed-source-rectangles.json');expected=[];corners_checked=0;edge_checks=0;min_cross=None
for owner in fixed:
    vs=[tuple(map(F,v)) for v in families[owner['family']]['geometry'][0]['outer']];assert all(a[0]==b[0] or a[1]==b[1] for a,b in zip(vs,vs[1:]+vs[:1]));xs=sorted({p[0] for p in vs});ys=sorted({p[1] for p in vs})
    for a,b in zip(xs,xs[1:]):
        for d,e in zip(ys,ys[1:]):
            if contains(vs,((a+b)/2,(d+e)/2)):expected.append((owner,[a,d,b,e]))
assert len(expected)==len(rects)==48
for row,(owner,source) in zip(rects,expected):
    assert row['item']==owner['item'] and row['placement']==owner['placement'] and list(map(F,row['source_rectangle']))==source;a,b,c,d=source;vs=[(a,b),(c,b),(c,d),(a,d)];assert row['source_corners']==[list(v) for v in vs];transformed=[point_bounds(v,owner['placement']['transform']) for v in vs];mi=-1 if owner['placement']['transform']['mirrored'] else 1;world=row['world_inner_rectangle_units1000'];assert world[0]<world[2] and world[1]<world[3]
    for x,y in product([F(world[0],1000),F(world[2],1000)],[F(world[1],1000),F(world[3],1000)]):
        for aa,bb in zip(transformed,transformed[1:]+transformed[:1]):
            cross=sub(mul(sub(bb[0],aa[0]),sub((y,y),aa[1])),mul(sub(bb[1],aa[1]),sub((x,x),aa[0])));lower=cross[0] if mi==1 else -cross[1];assert lower>0;edge_checks+=1;min_cross=lower if min_cross is None else min(min_cross,lower)
        corners_checked+=1
    assert min(world[2]-world[0],world[3]-world[1])+r>R and min(world[2]-world[0],world[3]-world[1])>2*beta
grid=load(BASE/'grid.json');root=grid['root_bounds_units1000'];expectedboxes=[]
for row in rects:
    a,b,c,d=row['world_inner_rectangle_units1000']
    for direction,bb in [('horizontal-support',[a+beta+1,b-h+1,c-beta-1,d+h-1]),('vertical-support',[a-h+1,b+beta+1,c+h-1,d-beta-1])]:
        clipped=[max(root[0],bb[0]),max(root[1],bb[1]),min(root[2],bb[2]),min(root[3],bb[3])]
        if clipped[0]<clipped[2] and clipped[1]<clipped[3]:expectedboxes.append({'index':len(expectedboxes),'fixed_rectangle':row['index'],'direction':direction,'unclipped_bounds_units1000':bb,'bounds_units1000':clipped})
assert expectedboxes==load(BASE/'forbidden-support-rectangles.json');xs=sorted({root[0],root[2]}|{r['bounds_units1000'][i] for r in expectedboxes for i in [0,2]});ys=sorted({root[1],root[3]}|{r['bounds_units1000'][i] for r in expectedboxes for i in [1,3]});assert xs==grid['x_breaks_units1000'] and ys==grid['y_breaks_units1000'];allowed=[];excluded=[]
for i,j in product(range(len(xs)-1),range(len(ys)-1)):
    cell=[xs[i],ys[j],xs[i+1],ys[j+1]];cover=[r['index'] for r in expectedboxes if all(r['bounds_units1000'][k]<=cell[k] for k in [0,1]) and all(cell[k]<=r['bounds_units1000'][k] for k in [2,3])]
    row={'grid':[i,j],'bounds_units1000':cell}
    if cover:excluded.append({**row,'forbidden_box':cover[0]})
    else:allowed.append({'index':len(allowed),**row})
assert allowed==load(BASE/'allowed-closed-cells.json') and excluded==load(BASE/'excluded-cells.json') and len(allowed)+len(excluded)==(len(xs)-1)*(len(ys)-1)
write(OUT/'necessity-proof.json',{'all36_originals_retained':True,'world_rectangles_exactly_inside_originals':True,'statement':'The fixed outer polygons are orthogonal in source coordinates; their complete vertex-coordinate grid makes each included source rectangle a filled subset. Every world inset corner is strictly inside every true transformed source edge by exact rational interval cross products, hence each whole convex world rectangle is contained. For a rectangle of width/height exceeding R-r, the original cog inner disk collision interval overlaps both support-tip collision intervals. With the center at least beta from the transverse sides, a support vertex with longitudinal projection >=h and absolute transverse projection <=beta lies in the rectangle. The union forbids longitudinal center coordinates strictly from low-h to high+h. Shrinking each strict box by1micrometre yields a closed, entirely forbidden rectangle. Cartesian edge partition and closed-cell retention cover every continuous feasible source center, including boundary cases; only cells wholly inside one proved forbidden box are removed. Flooring a feasible source center to1micrometre stays inside its retained integer-bound cell. No full source layout is claimed.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':36,'source_rectangles_verified':len(rects),'exact_world_corners_verified':corners_checked,'exact_interval_edge_tests':edge_checks,'forbidden_support_boxes_verified':len(expectedboxes),'grid_cells_verified':(len(xs)-1)*(len(ys)-1),'allowed_closed_cells':len(allowed),'excluded_cells':len(excluded),'continuous_boundary_coverage_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
