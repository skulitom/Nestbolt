"""Positive-construction decision: four orthogonal original brackets in the guarded opening."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];CORE=ROOT/'output/h5-central-notch-frame-core-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-notch-four-brackets-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(CORE/'checks.json')['passed'];OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();container=load(CORE/'notch-container.json');W,H,G=586500,349550,225;part=next(p for p in load(JOB)['parts'] if p['id']=='bracket');assert part['geometry'][0]['outer']==[[0,0],[300,0],[300,75],[100,75],[100,250],[0,250]]
inputs=[CORE/'plan.json',CORE/'notch-container.json',CORE/'checks.json',JOB];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Four mandatory brackets in the586.5x349.55mm guarded central opening. Exact integer quarter-turn/reflection profiles cover each L with two disjoint axis rectangles. Every pair of components from different originals must have at least0.225mm separation on one axis. Anchors use a1micrometre grid. This is a sufficient positive construction restriction, not a necessary all-angle exclusion; negative/unknown results only close this one subproblem. A positive must pass actual original float transforms, stock, pair and hole preservation readback with the frame core. All remaining job originals stay mandatory.'})
profiles=[]
for mirror in [False,True]:
    for quarter in range(4):
        co,si=[1,0,-1,0][quarter],[0,1,0,-1][quarter];mi=-1 if mirror else 1
        def transform(x,y):return mi*x*co-y*si,mi*x*si+y*co
        rectangles=[]
        for a,b,c,d in [[0,0,100000,250000],[100000,0,300000,75000]]:
            ps=[transform(x,y) for x in [a,c] for y in [b,d]];rectangles.append([min(x for x,y in ps),min(y for x,y in ps),max(x for x,y in ps),max(y for x,y in ps)])
        ox=min(r[0] for r in rectangles);oy=min(r[1] for r in rectangles);rectangles=[[a-ox,b-oy,c-ox,d-oy] for a,b,c,d in rectangles];profiles.append({'index':len(profiles),'quarter':quarter,'mirrored':mirror,'rotated_min_units':[ox,oy],'table':[len(profiles),max(r[2] for r in rectangles),max(r[3] for r in rectangles),*sum(rectangles,[])]})
m=pb.CpModelProto();mapping={'parts':[],'pair_rows':[]}
def var(name,lo,hi):i=len(m.variables);m.variables.add(name=name,domain=[lo,hi]);return i
def row(terms,lo,hi,en=()):
    terms={i:c for i,c in terms.items() if c};vs=sorted(terms);m.constraints.add(enforcement_literal=en,linear=pb.LinearConstraintProto(vars=vs,coeffs=[terms[i] for i in vs],domain=[lo,hi]))
for i in range(4):mapping['parts'].append({'original':container['proposed_bracket_originals'][i],'x':var(f'b{i}-x',0,W),'y':var(f'b{i}-y',0,H)})
for i,p in enumerate(mapping['parts']):
    vs=[var(f'b{i}-profile-column{j}',min(r['table'][j] for r in profiles),max(r['table'][j] for r in profiles)) for j in range(11)];p['profile_fields']=vs;table=m.constraints.add().table
    for v in vs:table.exprs.add(vars=[v],coeffs=[1])
    table.values.extend(v for r in profiles for v in r['table']);row({p['x']:1,vs[1]:1},0,W);row({p['y']:1,vs[2]:1},0,H)
for i,j in combinations(range(4),2):
    a,b=mapping['parts'][i],mapping['parts'][j]
    for ca in range(2):
        for cb in range(2):
            aa=a['profile_fields'][3+4*ca:7+4*ca];bb=b['profile_fields'][3+4*cb:7+4*cb];flags=[]
            choices=[{a['x']:1,b['x']:-1,aa[2]:1,bb[0]:-1},{b['x']:1,a['x']:-1,bb[2]:1,aa[0]:-1},{a['y']:1,b['y']:-1,aa[3]:1,bb[1]:-1},{b['y']:1,a['y']:-1,bb[3]:1,aa[1]:-1}]
            for k,terms in enumerate(choices):f=var(f'sep-{i}-{j}-{ca}-{cb}-{k}',0,1);flags.append(f);row(terms,-2**63,-G,[f])
            m.constraints.add(bool_or=pb.BoolArgumentProto(literals=flags));mapping['pair_rows'].append({'parts':[i,j],'components':[ca,cb],'flags':flags})
for i in range(3):row({mapping['parts'][i]['x']:1,mapping['parts'][i+1]['x']:-1},-2**63,0)
assert len(m.variables)==148 and len(m.constraints)==135;p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'profiles.json',profiles);write(OUT/'mapping.json',mapping);write(OUT/'inventory.json',[{'index':0,'parts':list(range(4)),'variables':148,'constraints':135,'model_sha256':digest(p),'solver_seconds':20}]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variables':148,'constraints':135,'solver_calls':0});print(load(OUT/'prepared.json'))
