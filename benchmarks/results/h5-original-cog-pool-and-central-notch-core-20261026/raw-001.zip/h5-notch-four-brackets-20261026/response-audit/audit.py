"""Verify the closed negative construction call without turning it into an unrestricted bound."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-notch-four-brackets-20261026';RUN=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for p in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=30 and budget['shared_seconds']==30 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==20 and budget['deadline_perf_counter']==budget['start_perf_counter']+30;assert census['solver_calls']==len(census['results'])==len(list(RUN.rglob('opened.json')))==1 and not census['pending_pairs'] and r==census['results'][0] and r['parts']==list(range(4))
m=pb.CpModelProto();m.ParseFromString((folder/'model.pb').read_bytes());expected=pb.CpModelProto();expected.ParseFromString((BASE/'models/000.pb').read_bytes());assert m==expected and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256']
response=pb.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert pb.CpSolverStatus.Name(response.status)==r['status']=='INFEASIBLE' and not response.solution and r['original_coordinates_units1000'] is None and abs(response.wall_time-r['seconds'])<.2 and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-20)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'one_micrometre_grid_and_axis_gap_construction_only':True,'unrestricted_notch_infeasibility_claimed':False,'global_first_sheet_exclusion_claimed':False,'H5_complete':False});print(load(OUT/'checks.json'))
