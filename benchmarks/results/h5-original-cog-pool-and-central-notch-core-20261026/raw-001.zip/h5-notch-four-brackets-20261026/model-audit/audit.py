"""Independently reconstruct the orthogonal source rectangles and complete notch model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-notch-four-brackets-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='bracket');assert part['allow_mirror'] and set(part['rotations']['degrees'])=={0,90,180,270};assert part['geometry'][0]['outer']==[[0,0],[300,0],[300,75],[100,75],[100,250],[0,250]];profiles=[]
for mirror in [False,True]:
    for quarter in range(4):
        components=[]
        for source in [[(0,0),(100000,0),(100000,250000),(0,250000)],[(100000,0),(300000,0),(300000,75000),(100000,75000)]]:
            vertices=[]
            for x,y in source:
                if mirror:x=-x
                for _ in range(quarter):x,y=-y,x
                vertices.append((x,y))
            components.append([min(v[0] for v in vertices),min(v[1] for v in vertices),max(v[0] for v in vertices),max(v[1] for v in vertices)])
        ox=min(v[0] for v in components);oy=min(v[1] for v in components);rs=[[a-ox,b-oy,c-ox,d-oy] for a,b,c,d in components];assert sum((c-a)*(d-b) for a,b,c,d in rs)==40000*10**6;profiles.append({'index':len(profiles),'quarter':quarter,'mirrored':mirror,'rotated_min_units':[ox,oy],'table':[len(profiles),max(v[2] for v in rs),max(v[3] for v in rs),*sum(rs,[])]})
assert profiles==load(BASE/'profiles.json');m=pb.CpModelProto();mapping={'parts':[],'pair_rows':[]};originals=load(ROOT/'output/h5-central-notch-frame-core-20261026/notch-container.json')['proposed_bracket_originals']
def variable(name,domain):i=len(m.variables);v=m.variables.add();v.name=name;v.domain.extend(domain);return i
def linear(terms,domain,en=()):
    terms={v:c for v,c in terms.items() if c};c=m.constraints.add();c.enforcement_literal.extend(en);c.linear.vars.extend(sorted(terms));c.linear.coeffs.extend(terms[v] for v in sorted(terms));c.linear.domain.extend(domain)
for i in range(4):mapping['parts'].append({'original':originals[i],'x':variable(f'b{i}-x',[0,586500]),'y':variable(f'b{i}-y',[0,349550])})
for i,p in enumerate(mapping['parts']):
    vs=[variable(f'b{i}-profile-column{j}',[min(r['table'][j] for r in profiles),max(r['table'][j] for r in profiles)]) for j in range(11)];p['profile_fields']=vs;c=m.constraints.add()
    for v in vs:e=c.table.exprs.add();e.vars.append(v);e.coeffs.append(1)
    c.table.values.extend(sum([r['table'] for r in profiles],[]));linear({p['x']:1,vs[1]:1},[0,586500]);linear({p['y']:1,vs[2]:1},[0,349550])
for i,j in combinations(range(4),2):
    a,b=mapping['parts'][i],mapping['parts'][j]
    for ca in range(2):
        for cb in range(2):
            aa=a['profile_fields'][3+4*ca:7+4*ca];bb=b['profile_fields'][3+4*cb:7+4*cb];terms=[{a['x']:1,b['x']:-1,aa[2]:1,bb[0]:-1},{b['x']:1,a['x']:-1,bb[2]:1,aa[0]:-1},{a['y']:1,b['y']:-1,aa[3]:1,bb[1]:-1},{b['y']:1,a['y']:-1,bb[3]:1,aa[1]:-1}];flags=[]
            for k,term in enumerate(terms):v=variable(f'sep-{i}-{j}-{ca}-{cb}-{k}',[0,1]);flags.append(v);linear(term,[-2**63,-225],[v])
            m.constraints.add().bool_or.literals.extend(flags);mapping['pair_rows'].append({'parts':[i,j],'components':[ca,cb],'flags':flags})
for i in range(3):linear({mapping['parts'][i]['x']:1,mapping['parts'][i+1]['x']:-1},[-2**63,0])
actual=pb.CpModelProto();actual.ParseFromString((BASE/'models/000.pb').read_bytes());assert actual==m and mapping==load(BASE/'mapping.json') and len(m.variables)==148 and len(m.constraints)==135 and not m.HasField('objective') and not m.HasField('solution_hint');real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_bracket_profiles_verified':8,'exact_source_components_per_profile':2,'variables':148,'constraints':135,'component_pairs_with_four_separations':24,'all_protobuf_fields_reconstructed':True,'actual_import_export_verified':True,'positive_construction_only':True,'negative_not_an_unrestricted_exclusion':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
