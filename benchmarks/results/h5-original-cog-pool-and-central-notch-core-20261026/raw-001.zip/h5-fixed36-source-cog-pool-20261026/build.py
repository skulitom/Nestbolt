"""Finite original-cog contacts in the newly rebuilt36-owner neighborhood."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import deque
import gzip,heapq,itertools,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,mapping
from shapely.affinity import affine_transform
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from build_h5_cog_free_regions import proposals,identity
ROOT=Path(__file__).resolve().parents[1];INV=ROOT/'output/h5-fixed36-cog-neighborhood-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-fixed36-source-cog-pool-20261026';POOLS=[ROOT/'output'/n/'candidates.json' for n in ['h5-dense-cog-completion-20261023','h5-expanded-frame-joint-20261023']]
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lines(p,rows):
    with gzip.open(p,'xt',encoding='utf-8',newline='\n') as f:
        for r in rows:f.write(json.dumps(r,separators=(',',':'))+'\n')
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();spec=load(INV/'next-neighborhood.json');assert load(INV/'checks.json')['passed'];job=load(JOB);families={p['id']:p for p in job['parts']};source={k:Polygon(p['geometry'][0]['outer']) for k,p in families.items()};guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
angles=sorted({r['placement']['transform']['rotation_radians'] for r in spec['prior_original_cog_poses_for_diagnostics_only']}|{math.radians(x) for x in [0,4.5,6.25,7.75,9,11.25,13.5]})
inputs=[INV/'next-neighborhood.json',INV/'checks.json',JOB,ROOT/'output/h5-fixed36-combined-domains-20261026/audit/checks.json',Path(gap.__file__),ROOT/'output/build_h5_cog_free_regions.py']+POOLS
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'generation_limit_seconds':120,'maximum_new_contacts':1800,'maximum_candidates':12000,'compression_seconds':15,'coordinate_angles_radians':angles,'required_original_pair_gap_mm':required,'required_stock_extra_mm':guard,'proposal_padding_mm':.0126,'solver_call_not_opened':True,'method':'Changed36-fixed/15-short neighborhood, with all15 first cogs required. Preserve and directly recheck every compatible original cog pose from both historical pools, plus all12 known seed poses. Use eight declared exact source angles and full original Minkowski free-translation regions against the36 fixed outers; round-robin boundary vertices, edge midpoints and representative points, retaining all rejected/pending events at the1800-new/120-second cap. No source pose is rounded or merged by proximity. Recompute every guarded source-cog pair conflict and preserve every edge after bounded clique compression. The finite pool does not prove unrestricted infeasibility. No native call on partial layouts.'})
def shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;return affine_transform(source[p['part_id']],[mi*c,-s,mi*s,c,*t['translation']])
fixed=[shape(p) for p in spec['fixed_first_placements']];stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];bounds=[m['left']+edge+guard,m['bottom']+edge+guard,stock['width']-m['right']-edge-guard,stock['height']-m['top']-edge-guard];pool=[];geometry=[];keys={};events=[];seen=set();seeds=[]
def consider(p,origin):
    p={'part_id':'cog','sheet_id':'sheet-0','transform':p['transform']};key=identity(p)
    if key in keys:return keys[key],'duplicate'
    if key in seen:return None,'previously rejected'
    seen.add(key);g=shape(p);bb=g.bounds
    if not (bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3]):return None,'stock'
    blockers=[i for i,f in enumerate(fixed) if g.distance(f)<=required]
    if blockers:return None,{'fixed_blockers':blockers}
    i=len(pool);keys[key]=i;pool.append({'index':i,'placement':p,'source':origin});geometry.append(g);return i,'added'
for row in spec['prior_original_cog_poses_for_diagnostics_only']:
    i,status=consider(row['placement'],{'kind':'original seed','item':row['item']});assert i is not None;seeds.append(i)
for path in POOLS:
    for row in load(path):
        p=row['placement']
        if p['part_id']!='cog' or p['sheet_id']!='sheet-0':continue
        i,status=consider(p,{'kind':'historical original pose','path':path.relative_to(ROOT).as_posix(),'index':row['index']});events.append({'source':path.parent.name,'index':row['index'],'candidate':i,'result':status})
    assert time.perf_counter()-start<120
old_count=len(pool);queries=[];gap.EPS=.0126
for angle in angles:
    if time.perf_counter()-start>=120:break
    moving=shape({'part_id':'cog','transform':{'rotation_radians':angle,'mirrored':False,'translation':[0.,0.]}});began=time.perf_counter();region=gap.regions(moving,fixed,stock,edge,required);query={'index':len(queries),'angle':angle,'seconds':time.perf_counter()-began,'geometry':mapping(region),'proposals':proposals(region)};write(OUT/'regions'/f"{query['index']:03d}.json",query);queries.append(query);print({'angle':angle,'seconds':query['seconds'],'proposals':len(query['proposals'])},flush=True)
queue=deque((q['index'],0) for q in queries if q['proposals']);new=0;new_events=[]
while queue and new<1800 and time.perf_counter()-start<120:
    qi,pi=queue.popleft();q=queries[qi];p={'transform':{'rotation_radians':q['angle'],'mirrored':False,'translation':q['proposals'][pi]['point']}};i,status=consider(p,{'kind':'new contact','query':qi,'proposal':pi});new_events.append({'query':qi,'proposal':pi,'candidate':i,'result':status});new+=status=='added'
    if pi+1<len(q['proposals']):queue.append((qi,pi+1))
assert len(pool)<=12000;write(OUT/'candidates.json',pool);write(OUT/'seed-indices.json',seeds);write(OUT/'old-events.json',events);write(OUT/'contact-events.json',new_events);write(OUT/'pending.json',{'unbuilt_angles':angles[len(queries):],'proposal_lists':list(queue)});generation=time.perf_counter()-start
gs=np.asarray(geometry,dtype=object);ij=STRtree(gs).query(gs,predicate='dwithin',distance=required);a,b=ij;take=a<b;a,b=a[take],b[take];take=shapely.distance(gs[a],gs[b])<=required;a,b=a[take],b[take];edges=sorted((int(i),int(j)) for i,j in zip(a,b));adj=[0]*len(pool)
for i,j in edges:adj[i]|=1<<j;adj[j]|=1<<i
seedmask=sum(1<<i for i in seeds);assert len(seeds)==12 and all(not(adj[i]&seedmask) for i in seeds)
remain=adj.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(adj) if a];heapq.heapify(heap);cliques=[];began=time.perf_counter()
while heap and time.perf_counter()-began<15:
    degree,i=heapq.heappop(heap)
    if -degree!=remain[i].bit_count() or not remain[i]:continue
    choices=remain[i];row=[i];mask=1<<i
    while choices:
        js=list(itertools.islice(bits(choices),16));j=max(js,key=lambda j:((adj[j]&choices).bit_count(),-j));row.append(j);mask|=1<<j;choices&=adj[j]
    assert all(not((mask^(1<<j))&~adj[j]) for j in row);cliques.append(sorted(row))
    for j in row:
        remain[j]&=~mask
        if remain[j]:heapq.heappush(heap,(-remain[j].bit_count(),j))
large=len(cliques);residual=0
for i,mask in enumerate(remain):
    for j in bits(mask&~((1<<(i+1))-1)):cliques.append([i,j]);residual+=1
lines(OUT/'conflicts.jsonl.gz',edges);lines(OUT/'cliques.jsonl.gz',sorted(set(map(tuple,cliques))))
write(OUT/'result.json',{'generation_seconds':generation,'total_seconds':time.perf_counter()-start,'historical_and_seed_candidates':old_count,'new_contacts':new,'candidates':len(pool),'queries':len(queries),'pending_queries':len(angles)-len(queries),'pending_proposal_lists':len(queue),'guarded_conflicts':len(edges),'compressed_cliques':large,'residual_edges':residual,'all12_seed_poses_retained':True,'mandatory_first_cogs':15,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
