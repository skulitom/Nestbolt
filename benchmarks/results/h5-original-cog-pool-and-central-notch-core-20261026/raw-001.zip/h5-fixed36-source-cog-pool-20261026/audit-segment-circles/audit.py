"""Direct original-vertex and complete finite conflict-graph readback."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,math,shutil,time
from fractions import Fraction as F
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed36-source-cog-pool-20261026';INV=ROOT/'output/h5-fixed36-cog-neighborhood-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit-segment-circles'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rows(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return [json.loads(l) for l in f]
def identity(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(x).hex() for x in t['translation']))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Transform each saved source outer directly, without builder affinity. Verify every candidate provenance, original stock/guard and every fixed-original clearance. Certify an inner109.1mm disk and outer140.01mm disk for every saved direct-vertex polygon using exact scaled integers. Every unordered pair is decided by exact integer center distances when the two inner disks overlap or the two outer disks have more than required clearance; only unresolved pairs call original polygon distance. Independently reconstruct every conflict, without the builder spatial index. Reconstruct every clique edge and require exact equality with the full conflict graph. Recheck all12 seed transforms and original66 identity partition. No all-angle or continuous finite-pool completeness claim.'})
plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);families={p['id']:p for p in job['parts']};spec=load(INV/'next-neighborhood.json');pool=load(BASE/'candidates.json');guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);assert required==plan['required_original_pair_gap_mm'] and guard==plan['required_stock_extra_mm'] and len(spec['mandatory_moving_first_cogs'])==15 and sorted(spec['fixed_first_originals']+spec['mandatory_moving_first_cogs']+spec['fixed_short_originals'])==list(range(66))
def shape(p):
    t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];return Polygon([(mi*x*co-y*si+tx,mi*x*si+y*co+ty) for x,y in families[p['part_id']]['geometry'][0]['outer']])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];bounds=[m['left']+e+guard,m['bottom']+e+guard,st['width']-m['right']-e-guard,st['height']-m['top']-e-guard];old={};queries={};gs=[];keys={};fixed_tests=0;minimum=None
for i,row in enumerate(pool):
    assert row['index']==i;p=row['placement'];assert p['part_id']=='cog' and p['sheet_id']=='sheet-0' and not p['transform']['mirrored'];k=identity(p);assert k not in keys;keys[k]=i;origin=row['source']
    if origin['kind']=='original seed':expected=next(r['placement'] for r in spec['prior_original_cog_poses_for_diagnostics_only'] if r['item']==origin['item'])
    elif origin['kind']=='historical original pose':
        path=origin['path']
        if path not in old:old[path]=load(ROOT/path)
        source=old[path][origin['index']];assert source['index']==origin['index'];expected=source['placement']
    else:
        assert origin['kind']=='new contact';q=origin['query']
        if q not in queries:queries[q]=load(BASE/'regions'/f'{q:03d}.json')
        v=queries[q];assert v['angle'] in plan['coordinate_angles_radians'];expected={'part_id':'cog','sheet_id':'sheet-0','transform':{'rotation_radians':v['angle'],'mirrored':False,'translation':v['proposals'][origin['proposal']]['point']}}
    assert identity(expected)==k;g=shape(p);assert g.is_valid;bb=g.bounds;assert bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3];dist=shapely.distance(g,fixed);assert bool(np.all(dist>required));fixed_tests+=len(dist);d=float(dist.min());minimum=d if minimum is None else min(minimum,d);gs.append(g)
n=len(gs);centers=[];circle_edges=0;circle_vertices=0
for row,g in zip(pool,gs):
    t=row['placement']['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);cx=139.723742*co-139.723742*si+t['translation'][0];cy=139.723742*si+139.723742*co+t['translation'][1];q=[round(cx*1000),round(cy*1000)];centers.append(q);ratios=[[float(x).as_integer_ratio(),float(y).as_integer_ratio()] for x,y in list(g.exterior.coords)[:-1]];scale=math.lcm(1000,*(v[1] for pt in ratios for v in pt));vertices=[(a*(scale//b),c*(scale//d)) for (a,b),(c,d) in ratios];center=[v*(scale//1000) for v in q];inner=109100*(scale//1000);outer=140010*(scale//1000)
    winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];ux,uy=center[0]-a[0],center[1]-a[1];cross=dx*uy-dy*ux;length=dx*dx+dy*dy;dot=ux*dx+uy*dy;assert length>0
        if dot<=0:assert ux*ux+uy*uy>inner*inner
        elif dot>=length:assert (center[0]-b[0])**2+(center[1]-b[1])**2>inner*inner
        else:assert cross*cross>inner*inner*length
        if a[1]<=center[1]<b[1] and cross>0:winding+=1
        if b[1]<=center[1]<a[1] and cross<0:winding-=1
        assert ux*ux+uy*uy<outer*outer;circle_edges+=1;circle_vertices+=1
    assert winding==1
gs=np.asarray(gs,dtype=object);centers=np.asarray(centers,dtype=np.int64);assert int(np.abs(centers).max())<10**8;expected=[];pairs=0;inner_pruned=outer_pruned=exact_distances=0;near2=(2*109100)**2;far2=(2*140010+math.ceil(required*1000)+1)**2
for i in range(n):
    delta=centers[i+1:]-centers[i];square=np.sum(delta*delta,axis=1);near=square<near2;far=square>far2;middle=np.flatnonzero(~(near|far));blocked=near.copy();blocked[middle]=shapely.distance(gs[i],gs[i+1+middle])<=required;pairs+=len(square);inner_pruned+=int(near.sum());outer_pruned+=int(far.sum());exact_distances+=len(middle);expected.extend([i,i+1+int(j)] for j in np.flatnonzero(blocked))
    assert time.perf_counter()-start<120,'Repaired audit cap reached; no pass'
assert inner_pruned+outer_pruned+exact_distances==pairs
write(OUT/'circle-certificates.json',{'centers_units1000':centers.tolist(),'inner_radius_units1000':109100,'outer_radius_units1000':140010,'inner_collision_threshold_squared_units':near2,'outer_safe_threshold_squared_units':far2,'statement':'Every direct-vertex cog is a valid simple counterclockwise polygon. Exact nonzero winding places each center inside the original polygon. Exact distances to every finite edge segment, including endpoint projections, exceed the inner radius. The connected inner disk is therefore disjoint from the whole boundary and remains inside the polygon. Every outer vertex lies strictly in the outer disk, so the entire polygon lies in that convex disk. Exact integer center distance therefore proves every pruned near pair intersects and every pruned far pair exceeds the required clearance. Unresolved pairs retain the original direct polygon distance test.'})
saved=rows(BASE/'conflicts.jsonl.gz');assert saved==expected;adj=[0]*n
for i,j in saved:assert 0<=i<j<n;adj[i]|=1<<j;adj[j]|=1<<i
covered=[0]*n;cliques=rows(BASE/'cliques.jsonl.gz');clique_members=0
for row in cliques:
    assert row==sorted(set(row)) and len(row)>=2 and 0<=row[0]<row[-1]<n;mask=sum(1<<j for j in row)
    for j in row:assert not((mask^(1<<j))&~adj[j]);covered[j]|=mask^(1<<j);clique_members+=1
assert covered==adj;seeds=load(BASE/'seed-indices.json');assert len(seeds)==len(set(seeds))==12 and [identity(pool[i]['placement']) for i in seeds]==[identity(r['placement']) for r in spec['prior_original_cog_poses_for_diagnostics_only']];sm=sum(1<<i for i in seeds);assert all(not(adj[i]&sm) for i in seeds)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_cog_candidates_verified':n,'candidate_fixed_original_pairs_verified':fixed_tests,'candidate_stock_edges_verified':4*n,'exact_inner_disk_edge_checks':circle_edges,'exact_outer_disk_vertex_checks':circle_vertices,'inner_disk_pruned_pairs':inner_pruned,'outer_disk_pruned_pairs':outer_pruned,'unresolved_original_polygon_distances':exact_distances,'all_unordered_candidate_pairs_verified':pairs,'complete_original_conflicts_verified':len(saved),'cliques_verified':len(cliques),'clique_members_verified':clique_members,'all_conflict_edges_preserved':True,'minimum_candidate_fixed_gap_mm':minimum,'required_gap_mm':required,'all12_seeds_preserved':True,'all15_cogs_required_for_target':True,'all66_original_identities_accounted_once':True,'finite_pool_only':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
