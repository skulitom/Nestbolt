"""Direct original-vertex and complete finite conflict-graph readback."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed36-source-cog-pool-20261026';INV=ROOT/'output/h5-fixed36-cog-neighborhood-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rows(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return [json.loads(l) for l in f]
def identity(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(x).hex() for x in t['translation']))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Transform each saved source outer directly, without builder affinity. Verify every candidate provenance, original stock/guard and every fixed-original clearance. Enumerate every unordered candidate pair in chunks and reconstruct every conflicting pair from original polygon distance, independently of the spatial-index construction. Reconstruct every clique edge and require exact equality with the full conflict graph. Recheck all12 seed transforms and original66 identity partition. No all-angle or continuous finite-pool completeness claim.'})
plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);families={p['id']:p for p in job['parts']};spec=load(INV/'next-neighborhood.json');pool=load(BASE/'candidates.json');guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);assert required==plan['required_original_pair_gap_mm'] and guard==plan['required_stock_extra_mm'] and len(spec['mandatory_moving_first_cogs'])==15 and sorted(spec['fixed_first_originals']+spec['mandatory_moving_first_cogs']+spec['fixed_short_originals'])==list(range(66))
def shape(p):
    t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];return Polygon([(mi*x*co-y*si+tx,mi*x*si+y*co+ty) for x,y in families[p['part_id']]['geometry'][0]['outer']])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];bounds=[m['left']+e+guard,m['bottom']+e+guard,st['width']-m['right']-e-guard,st['height']-m['top']-e-guard];old={};queries={};gs=[];keys={};fixed_tests=0;minimum=None
for i,row in enumerate(pool):
    assert row['index']==i;p=row['placement'];assert p['part_id']=='cog' and p['sheet_id']=='sheet-0' and not p['transform']['mirrored'];k=identity(p);assert k not in keys;keys[k]=i;origin=row['source']
    if origin['kind']=='original seed':expected=next(r['placement'] for r in spec['prior_original_cog_poses_for_diagnostics_only'] if r['item']==origin['item'])
    elif origin['kind']=='historical original pose':
        path=origin['path']
        if path not in old:old[path]=load(ROOT/path)
        source=old[path][origin['index']];assert source['index']==origin['index'];expected=source['placement']
    else:
        assert origin['kind']=='new contact';q=origin['query']
        if q not in queries:queries[q]=load(BASE/'regions'/f'{q:03d}.json')
        v=queries[q];assert v['angle'] in plan['coordinate_angles_radians'];expected={'part_id':'cog','sheet_id':'sheet-0','transform':{'rotation_radians':v['angle'],'mirrored':False,'translation':v['proposals'][origin['proposal']]['point']}}
    assert identity(expected)==k;g=shape(p);assert g.is_valid;bb=g.bounds;assert bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3];dist=shapely.distance(g,fixed);assert bool(np.all(dist>required));fixed_tests+=len(dist);d=float(dist.min());minimum=d if minimum is None else min(minimum,d);gs.append(g)
gs=np.asarray(gs,dtype=object);n=len(gs);expected=[];pairs=0
for i in range(n):
    distances=shapely.distance(gs[i],gs[i+1:]);pairs+=len(distances);expected.extend([i,i+1+int(j)] for j in np.flatnonzero(distances<=required))
    assert time.perf_counter()-start<120,'Audit cap reached; no pass'
saved=rows(BASE/'conflicts.jsonl.gz');assert saved==expected;adj=[0]*n
for i,j in saved:assert 0<=i<j<n;adj[i]|=1<<j;adj[j]|=1<<i
covered=[0]*n;cliques=rows(BASE/'cliques.jsonl.gz');clique_members=0
for row in cliques:
    assert row==sorted(set(row)) and len(row)>=2 and 0<=row[0]<row[-1]<n;mask=sum(1<<j for j in row)
    for j in row:assert not((mask^(1<<j))&~adj[j]);covered[j]|=mask^(1<<j);clique_members+=1
assert covered==adj;seeds=load(BASE/'seed-indices.json');assert len(seeds)==len(set(seeds))==12 and [identity(pool[i]['placement']) for i in seeds]==[identity(r['placement']) for r in spec['prior_original_cog_poses_for_diagnostics_only']];sm=sum(1<<i for i in seeds);assert all(not(adj[i]&sm) for i in seeds)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_cog_candidates_verified':n,'candidate_fixed_original_pairs_verified':fixed_tests,'candidate_stock_edges_verified':4*n,'all_unordered_candidate_pairs_verified':pairs,'complete_original_conflicts_verified':len(saved),'cliques_verified':len(cliques),'clique_members_verified':clique_members,'all_conflict_edges_preserved':True,'minimum_candidate_fixed_gap_mm':minimum,'required_gap_mm':required,'all12_seeds_preserved':True,'all15_cogs_required_for_target':True,'all66_original_identities_accounted_once':True,'finite_pool_only':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
