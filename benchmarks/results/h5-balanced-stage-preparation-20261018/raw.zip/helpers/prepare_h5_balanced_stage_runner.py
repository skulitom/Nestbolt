from pathlib import Path
root=Path(__file__).resolve().parents[1]
text=(root/'scripts/h5_return_reuse_stage_diagnosis.py').read_text(encoding='utf-8')
text=text.replace('h5_return_reuse_pilot','h5_balanced_group_pilot')
text=text.replace('h5-return-reuse-stage-diagnosis-20261018','h5-balanced-stage-20261018')
text=text.replace('h5-return-reuse-pilot-20261018','h5-balanced-group-pilot-20261018')
text=text.replace('h5_return_reuse_stage_diagnosis.py','h5_balanced_stage.py')
start=text.index('"""');end=text.index('"""',start+3)+3
text='''"""Observe retained proposal identities, repair stages and immediate effects of the rejected balanced-pair candidate.

Four diagnostic-only searches: both mechanical development jobs, both kerfs,
seed 0, 60 seconds, serial physical CCD0 CPU 8. Instrumentation preserves the
original algorithm and limits but can perturb wall deadlines. No quality or
speed comparison, no changed candidate integration, and no held-out inputs.
"""'''+text[end:]
text=text.replace("'source_change':'Read-only observations of fresh/resumed source losses, original item inventory, weighted losses, repair duration/budget and receiver/source/final acceptance stages; one stderr trace per invocation. Prior frame observations remain.',", "'source_change':'Read-only retained proposal item identities, receiver/source losses, immediate material and last-sheet extent, final rejection stage. One stderr trace per invocation.',")
start=text.index('def check_frame_attempt(');end=text.index('def run(out):',start)
reader='''def neutral(proposal):
    return sorted(proposal['incoming_ids']) == sorted(proposal['returned_ids'])


def check_traces(traces, stats=None):
    assert isinstance(traces,list) and traces
    attempts=[];proposals=[]
    def positive(value):
        assert type(value) in [int,float] and math.isfinite(value) and value>0
    def loss(value):
        assert value is None or (type(value) in [int,float] and math.isfinite(value) and value>=0)
    outcomes={'accepted','receiver_repair_failed','source_repair_failed','expired_after_repairs',
              'independent_geometry_failed','material_guard_failed','expired_before_acceptance',
              'forbidden_incoming_orientation'}
    for t in traces:
        assert type(t['disabled_or_expired']) is bool and type(t['baseline_invalid']) is bool
        ps=t['proposals'];seen=set()
        if t['disabled_or_expired'] or t['baseline_invalid']:
            assert not ps and not t['attempts']
            assert t['before_material'] is None and t['before_last_extent'] is None
            continue
        positive(t['before_material']);positive(t['before_last_extent'])
        for p in ps:
            assert type(p['paired']) is bool and type(p['target']) is int and p['target']>=0
            for key in ['incoming_ids','returned_ids']:
                assert isinstance(p[key],list) and p[key] and all(type(i) is int and i>=0 for i in p[key])
            assert len(p['incoming_ids'])==(2 if p['paired'] else 1)
            assert 1<=len(p['returned_ids'])<=p['blockers']<=3 and type(p['blockers']) is int
            positive(p['incoming_area']);positive(p['returned_area'])
            if p['paired']:
                assert p['incoming_ids'][0]==p['incoming_ids'][1]
                assert len(p['returned_ids'])==p['blockers']
                assert p['returned_area']<=p['incoming_area']
            elif len(p['returned_ids'])==1:
                assert p['returned_area']<p['incoming_area']
        proposals.extend(ps)
        for a in t['attempts']:
            i=a['proposal_index']
            assert type(i) is int and 0<=i<len(ps) and i not in seen
            seen.add(i);p=ps[i]
            assert a['outcome'] in outcomes
            for key in ['receiver_initial_loss','receiver_loss','source_initial_loss','source_loss']:loss(a[key])
            for key in ['after_material','after_last_extent']:
                if a[key] is not None:positive(a[key])
            outcome=a['outcome']
            if outcome=='forbidden_incoming_orientation':
                assert p['paired'] and all(a[k] is None for k in ['receiver_initial_loss','receiver_loss','source_initial_loss','source_loss','after_material','after_last_extent'])
            elif outcome=='receiver_repair_failed':
                assert a['receiver_initial_loss'] is not None and a['receiver_loss']>0
                assert all(a[k] is None for k in ['source_initial_loss','source_loss','after_material','after_last_extent'])
            else:
                assert a['receiver_initial_loss'] is not None and a['receiver_loss']==0
                assert a['source_initial_loss'] is not None and a['source_loss'] is not None
                if outcome=='source_repair_failed':assert a['source_loss']>0
                else:assert a['source_loss']==0
                if outcome in ['source_repair_failed','expired_after_repairs']:
                    assert a['after_material'] is None and a['after_last_extent'] is None
                elif outcome=='independent_geometry_failed':
                    assert a['after_material'] is None and a['after_last_extent'] is not None
                else:
                    assert a['after_material'] is not None and a['after_last_extent'] is not None
                if outcome=='accepted':assert a['after_material']<=t['before_material']
            attempts.append({**a,'proposal':p,'neutral_inventory':neutral(p),
                'before_material':t['before_material'],'before_last_extent':t['before_last_extent']})
    counts=Counter(a['outcome'] for a in attempts)
    paired=[a for a in attempts if a['proposal']['paired']]
    if stats is not None:
        assert len(attempts)==stats.get('directed_exchange_attempts',0)
        assert counts['accepted']==stats.get('directed_exchanges',0)
        assert len(paired)==stats.get('paired_exchange_attempts',0)
        assert sum(a['outcome']=='accepted' for a in paired)==stats.get('paired_exchanges',0)
    return {'invocations':len(traces),'attempts':len(attempts),'outcomes':dict(counts),
        'paired_attempts':len(paired),'paired_accepted':sum(a['outcome']=='accepted' for a in paired),
        'neutral_attempts':sum(a['neutral_inventory'] for a in attempts),
        'neutral_accepted':sum(a['neutral_inventory'] and a['outcome']=='accepted' for a in attempts),
        'retained_proposals':len(proposals),'retained_neutral_proposals':sum(neutral(p) for p in proposals),
        'attempt_rows':attempts,'traces':traces}


def read_trace(archive, record):
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        case=json.loads(z.read('case.json'))
        for name,expected in case['artifacts'].items():assert prior.sha256(z.read(name)).hexdigest()==expected
        traces=[json.loads(line.removeprefix('BALANCED_DIAG '))
            for line in z.read('search-stderr.log').decode('utf-8').splitlines() if line.startswith('BALANCED_DIAG ')]
    return check_traces(traces,record.get('stats') if record['status']=='valid' else None)


'''
text=text[:start]+reader+text[end:]
(root/'scripts/h5_balanced_stage.py').write_text(text,encoding='utf-8',newline='\n')
print('Balanced-pair trace reader and guarded four-case runner prepared')
