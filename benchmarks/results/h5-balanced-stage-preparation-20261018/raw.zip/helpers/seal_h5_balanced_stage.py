from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-balanced-stage-20261018'
out=root/'benchmarks/results/h5-balanced-stage-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_balanced_stage as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert digest(probe/'workspace'/plan['changed_file'])==build['source_sha256']
assert '97 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert runner.prior.source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==4
assert len(reader['malformed_records_rejected'])==8 and reader['identity_multiset_checks']==4
assert reader['reader_sha256']==digest(root/'scripts/h5_balanced_stage.py')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_balanced_stage.py','build_h5_balanced_stage.py',
             'prepare_h5_balanced_stage_runner.py','check_h5_balanced_stage_reader.py','seal_h5_balanced_stage.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_balanced_stage.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':97,'strict_lint_passed':True,'observer_build_passed':True,
    'authored_test_traces':4,'malformed_records_rejected':8,'identity_multiset_checks':4,
    'production_and_rejected_candidate_unchanged':True,'measured_search_started':False,'quality_claim':False,'H5_complete':False})
doc='''# Balanced-pair identity and stage observations — preparation, 2026-10-18

The rejected pair candidate accepted 13 of 25 paired attempts in its
[72-outcome pilot](h5-balanced-group-pilot-20261018.md), but five material pairs
failed. The source permits returning the same part types and quantities as
the incoming pair. Such exchanges preserve per-sheet inventory; whether any
occurred in the measured pilot is unknown because its logs lack identities.
An inventory-preserving exchange can still rearrange poses, so it is not
assumed to be ineffective.

This separate observer records original item identities for every retained
proposal, links attempted repairs to those proposals, and records receiver
and source losses, immediate validated material and last-sheet occupied
extent. It changes no proposal, budget, repair or acceptance policy. Reversing
the inserted observations restores the original pre-formatting source text;
all other 149 files, the rejected candidate and production remain unchanged.
Logging can alter wall deadlines: these observations cannot explain the exact
trajectory of an earlier run or establish a quality or speed improvement.

All 97 optimized core tests, strict lint and the observer build pass. Four
existing authored tests exercise accepted 2-for-3 exchanges, failed source
repair, disabled/expired calls and strict material rejection. The reader
rejects eight malformed records and checks multiset equality with four small
examples. Trace counts must match all four saved solver counters.

The committed plan opens four serial observations: two mechanical development
jobs, kerfs 0.2 and 1.5 mm, seed zero, 60 seconds, physical CCD0 CPU 8. Every
output still needs public independent validation and export; original ZIPs
and all traces are retained. No reserved files, changed limit or H5 credit.
H2/H5 remain open; completed weight stays 60%.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-balanced-stage-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:
    f.write('''

## 2026-10-18 — Qualify balanced-pair identity and stage observations

[The diagnostic copy](benchmarks/results/h5-balanced-stage-preparation-20261018.md)
passes 97 optimized core tests, strict lint, build, four real authored traces,
eight malformed-record checks and four multiset checks. Observations identify
retained/attempted exchanges of the same versus different original part types,
repair losses, immediate material and last-sheet extent. Identical inventories
are not assumed to imply identical poses or ineffective rearrangement.

Four committed serial, seed-zero 60-second mechanical observations follow.
All algorithms, deadlines and acceptance limits remain; trace overhead can
perturb wall timing. This is not a replay or quality rerun of the failed pilot.
Production and its failed comparisons remain unchanged. H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed_members':len(inventory),'bytes':raw.stat().st_size}))
