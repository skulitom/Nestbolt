"""Recover the interrupted audit's diagnostics without changing its saved attempt."""
import traceback
import audit_h5_occupied_area_relaxation as audit

audit.OUT=audit.BASE/'audit-recovered'
try:
    audit.main()
except Exception:
    with (audit.OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:
        f.write(traceback.format_exc())
    raise
