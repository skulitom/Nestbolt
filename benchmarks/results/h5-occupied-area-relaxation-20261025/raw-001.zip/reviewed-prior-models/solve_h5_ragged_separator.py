"""Bounded exact-count model of ragged cog groups with verified pocket fillers."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil,traceback,sys
import ortools
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-ragged-pockets-20261018';OUT=ROOT/'output/h5-ragged-separator-cpsat-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');patterns={**load(ROOT/'output/h5-cog-lattices-20261018/all-patterns.json'),**load(SRC/'components.json')};job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=.22;scale=1000
    recipes=load(SRC/'selected-recipes.json');width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
    capW=math.floor((width+g)*scale);capH=[math.floor((h+g)*scale) for h in heights];kept=[];rejected=[]
    for r in recipes:
        area=sum(math.ceil((patterns[n]['width']+g)*scale)*math.ceil((patterns[n]['height']+g)*scale)*qty for n,qty in r['recipe'].items())
        row={**r,'grid_rectangle_area':area,'grid_available_area':capW*sum(capH)}
        (kept if area<=capW*sum(capH) else rejected).append(row)
    assert kept;recipes=kept
    common={n:min(r['recipe'].get(n,0) for r in recipes) for n in set().union(*(r['recipe'] for r in recipes))};common={n:qty for n,qty in common.items() if qty}
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'input_hashes':{str(SRC.relative_to(ROOT)/n):digest(SRC/n) for n in ['components.json','selected-recipes.json','job.json','conditional-target.json']},
          'method':'Choose exactly one complete original-inventory recipe containing a verified ragged cog group and its pocket fillers. Reject only recipes whose outward-rounded total rectangle area exceeds inward-rounded original capacity; retain that finite-model rejection. Factor identical pattern quantities common to all eligible recipes, then make each remaining item conditional on its recipe. Every rectangle may translate on a 0.001 mm grid, choose either original target sheet and rotate by a quarter-turn when it fits. All frame positions are free. Exact-one choices, linked optional intervals and per-sheet NoOverlap2D require complete inventory, with no partial objective. Sort identical-copy sheet/y/x keys only to remove interchangeable-copy symmetry.',
          'recipes':recipes,'area_rejected_recipes':rejected,'common_inventory':common,'scale_per_mm':scale,'block_gap_mm':g,'width_mm':width,'height_limits_mm':heights,'seconds_limit':120,'seed':0,'workers':8,'python':sys.version,'ortools':ortools.__version__,
          'scope':'New finite offline model, not a quality run or budget change. Feasible rectangles must be expanded to all 66 original parts and independently validated. UNKNOWN or finite-model infeasibility does not prove unrestricted geometry impossible.'}
    plan['separator_normalization']='For a selected horizontal ragged component, its padded width plus every coexisting rectangle orientation width exceeds the first-sheet width. Hence all other rectangles lie wholly above or below its padded vertical interval. Translate below rectangles upward by the component padded height, leave above rectangles fixed, and put the component at y=0,x=0. All original relative orders, bounds, integer-grid positions and nonoverlap remain feasible. This removes placement symmetry only for this proven full-width case; quarter-turned components remain unconstrained. Same 120-second limit, seed, workers and exact inventory as the preserved prior model.'
    plan['baseline_model_sha256']=digest(ROOT/'output/h5-ragged-pocket-cpsat-20261018/model.pbtxt')
    write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    used={n:patterns[n] for n in sorted(set().union(*(r['recipe'] for r in recipes)))};write(OUT/'patterns.json',used)
    for r in recipes:
        assert Counter(m['part_id'] for n,qty in r['recipe'].items() for _ in range(qty) for m in patterns[n]['members'])==Counter({p['id']:p['quantity'] for p in job['parts']})
    model=cp_model.CpModel();options=[model.new_bool_var(f'inventory-{i}') for i in range(len(recipes))];model.add_exactly_one(options)
    items=[{'pattern':n,'group':None} for n,qty in sorted(common.items()) for _ in range(qty)]
    for oi,r in enumerate(recipes):items += [{'pattern':n,'group':oi} for n,qty in sorted(r['recipe'].items()) for _ in range(qty-common.get(n,0))]
    W=math.floor((width+g)*scale);Hs=[math.floor((h+g)*scale) for h in heights];big=(max(Hs)+1)*(W+1);intervals=[[],[]];placements=[];keys=defaultdict(list);metadata=[]
    for i,item in enumerate(items):
        p=used[item['pattern']];lits=[];row=[];key=model.new_int_var(0,2*big,f'key-{i}');keys[(item['group'],item['pattern'])].append(key)
        for sheet in [0,1]:
            for rot in [False,True]:
                w,h=(p['height'],p['width']) if rot else (p['width'],p['height']);wi=math.ceil((w+g)*scale);hi=math.ceil((h+g)*scale)
                if wi>W or hi>Hs[sheet]:continue
                name=f'{i}-s{sheet}-r{int(rot)}';present=model.new_bool_var('present-'+name);x=model.new_int_var(0,W-wi,'x-'+name);y=model.new_int_var(0,Hs[sheet]-hi,'y-'+name)
                ix=model.new_optional_fixed_size_interval_var(x,wi,present,'ix-'+name);iy=model.new_optional_fixed_size_interval_var(y,hi,present,'iy-'+name);intervals[sheet].append((ix,iy));lits.append(present)
                model.add(key==sheet*big+y*(W+1)+x).only_enforce_if(present)
                if item['group'] is not None and item['pattern'].startswith('rows-') and sheet==0 and not rot:
                    coexisting=[n for n,qty in recipes[item['group']]['recipe'].items() if qty and n!=item['pattern']]
                    for other in coexisting:
                        q=used[other];minimum_width=min(math.ceil((q['width']+g)*scale),math.ceil((q['height']+g)*scale));assert wi+minimum_width>W,(item,other)
                    model.add(x==0).only_enforce_if(present).with_name(f'separator-origin-x-{i}')
                    model.add(y==0).only_enforce_if(present).with_name(f'separator-origin-y-{i}')
                row.append({'item':i,'pattern':item['pattern'],'group':item['group'],'sheet':sheet,'rotated':rot,'width_units':wi,'height_units':hi,'present_var':present.index,'x_var':x.index,'y_var':y.index})
                placements.append((row[-1],present,x,y))
        if item['group'] is None:model.add_exactly_one(lits)
        else:
            model.add(sum(lits)==options[item['group']]);model.add(key==0).only_enforce_if(options[item['group']].Not())
        metadata.append({'item':i,**item,'key_var':key.index,'choices':row})
    for group in keys.values():
        for a,b in zip(group,group[1:]):model.add(a<=b)
    for rows in intervals:model.add_no_overlap_2d([p[0] for p in rows],[p[1] for p in rows])
    write(OUT/'mapping.json',{'W':W,'Hs':Hs,'key_stride':big,'inventory_variables':[o.index for o in options],'items':metadata})
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'));solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda msg:(log.write(msg+'\n'),log.flush());t0=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-t0
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE];result={'status':solver.status_name(status),'seconds':elapsed,'feasible':feasible,'response_stats':solver.response_stats(),'model_sha256':digest(OUT/'model.pbtxt')}
    if feasible:
        selected=[{**r,'x':solver.value(x)/scale,'y':solver.value(y)/scale} for r,p,x,y in placements if solver.boolean_value(p)];write(OUT/'selection.json',selected)
        counts=Counter();actual=[];base=[m['left']+e+1e-4,m['bottom']+e+1e-4]
        for b in selected:
            p=used[b['pattern']]
            for member in p['members']:
                t=json.loads(json.dumps(member['transform']));x,y=t['translation']
                if b['rotated']:t['rotation_radians']+=math.pi/2;x,y=p['height']-y,x
                t['translation']=[base[0]+b['x']+x,base[1]+b['y']+y];family=member['part_id'];actual.append({'part_id':family,'copy_index':counts[family],'sheet_id':f"sheet-{b['sheet']}",'transform':t});counts[family]+=1
        write(OUT/'layout.json',{'version':1,'units':'mm','sheets':load(OUT/'original.json')['sheets'],'placements':actual});result['counts']=dict(counts);result['recipe_index']=next(i for i,o in enumerate(options) if solver.boolean_value(o))
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
