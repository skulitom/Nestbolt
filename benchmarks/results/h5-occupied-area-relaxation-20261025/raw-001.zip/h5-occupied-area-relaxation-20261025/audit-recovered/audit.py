"""Check continuous outer-cover construction and every known compatible original pose."""
from collections import Counter
from datetime import datetime,timezone
from itertools import product
import math,shutil,time
import numpy as np
import shapely
from shapely.geometry import MultiPoint,Point,box,shape as from_geojson
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from diagnose_h5_concave_gaps import convex_pieces
from build_h5_occupied_area_relaxation import ROOT,SRC,PRIOR,OUT as BASE,load,write,digest
OUT=BASE/'audit'
def coords(g):return list(g.exterior.coords)[:-1] if g.geom_type=='Polygon' else list(g.coords)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');eps=plan['outward_numerical_padding_mm'];step=plan['grid_step_mm'];mp=load(PRIOR/'mapping.json');pool=load(PRIOR/'candidates.json');groups=mp['core_groups'];job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',BASE/'cache-checks.json',BASE/'pending.json']},'method':'Match sources to committed evidence. Independently reconstruct each cached zero-clearance Minkowski obstacle from convex-piece Cartesian vertex differences; verify decomposition coverage. Reconstruct every translated forbidden union and expanded stock domain; verify shrunken exclusions are subsets and inward-separated. Re-enumerate every intersecting grid cell and check its entire clipped translation region is covered by its convex outer hull. Independently reconstruct every convex Minkowski sum with moving-part pieces, swept union, physical clipping and complete family/core aggregate. Check every known compatible original polygon and every matching original translation against the continuous covers, including all four64/63-part baseline mappings. The necessary area comparison is interpreted only after these checks. No generation or solver call.'})
    manifest=ROOT/'benchmarks/results/h5-small-pair-joint-20261025/raw-manifest.json';data=load(manifest);hashes={r['path']:r['sha256'] for r in data['files']+data['aliases']};provenance=[]
    for name,h in plan['inputs'].items():
        p=ROOT/name;assert digest(p)==h
        key=PRIOR.name+'/'+p.relative_to(PRIOR).as_posix() if p.is_relative_to(PRIOR) else 'helpers/'+p.name if p.suffix=='.py' else 'source-inputs/'+p.relative_to(ROOT).as_posix();assert hashes[key]==h;provenance.append({'source':name,'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key,'sha256':h})
    specs=[{'family':f,'degrees':a,'mirrored':mir} for f in ['bracket','insert'] for mir in ([False,True] if parts[f]['allow_mirror'] else [False]) for a in parts[f]['rotations']['degrees']];assert specs==plan['specifications'] and len(specs)==12
    fixedids=sorted({i for g in groups for i in g['fixed_candidates']});fixed={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixedids};cache={};cached_sums=0;max_error=0.
    for r in load(BASE/'cache-checks.json'):
        stored=load(BASE/'obstacles'/f"{r['index']:03d}.json");assert all(stored[k]==v for k,v in r.items());i=r['first_fixed_candidate'];p=pool[i]['placement'];fg=shape(parts[p['part_id']],r['fixed_zero_transform']);mg=shape(parts[r['moving_family']],r['moving_zero_transform']);fp=convex_pieces(fg);moving=convex_pieces(mg);assert unary_union(fp).equals(fg) and unary_union(moving).equals(mg);sums=[]
        for a,b in product(fp,moving):sums.append(MultiPoint([(x-u,y-v) for (x,y),(u,v) in product(coords(a),coords(b))]).convex_hull);cached_sums+=1
        expected=unary_union(sums);actual=from_geojson(stored['raw_geometry']);error=expected.symmetric_difference(actual).area;assert error<1e-6 and expected.hausdorff_distance(actual)<1e-8;max_error=max(max_error,error);assert r['hausdorff_error_mm']<1e-7 and r['area_error_mm2']<1e-4;cache[r['index']]=actual
    physical={};stocks={};minerosion=math.inf;original_fixed_area=0
    for g in groups:
        assert Counter(pool[i]['placement']['part_id'] for i in g['fixed_candidates'])==Counter(frame=18,cog=15)
        for sheet in ['sheet-0','sheet-1']:
            row=load(BASE/'cores'/f"{g['index']}-{sheet}.json");ids=[i for i in g['fixed_candidates'] if pool[i]['placement']['sheet_id']==sheet];assert row['fixed_candidates']==ids;union=unary_union([fixed[i] for i in ids]);assert union.equals(from_geojson(row['fixed_union']));excluded=from_geojson(row['physical_exclusion']);assert excluded.difference(union).is_empty;dist=excluded.distance(union.boundary);assert dist>=eps-1e-7;minerosion=min(minerosion,dist);height=stock['height'] if sheet=='sheet-0' else target['required_used_height_mm'];expanded=box(m['left']+edge-eps,m['bottom']+edge-eps,stock['width']-m['right']-edge+eps,height-m['top']-edge+eps);assert expanded.equals(from_geojson(row['expanded_stock']));key=(g['index'],sheet);stocks[key]=expanded;physical[key]=expanded.difference(excluded);assert physical[key].equals(from_geojson(row['physical_outer_free_region']))
    queries=[];cover_by_query={};translation_by_query={};cells_checked=sums_checked=0
    for spec in plan['queries'][:result['completed_queries']]:
        q=load(BASE/'queries'/f"{spec['index']:03d}.json");assert all(q[k]==v for k,v in spec.items());o=specs[q['specification']];t={'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]};assert q['family']==o['family'] and q['moving_transform']==t;moving=shape(parts[o['family']],t);pieces=convex_pieces(moving);assert unary_union(pieces).equals(moving);a,b,c,d=moving.bounds;key=(q['core_group'],q['sheet_id']);sa,sb,sc,sd=stocks[key].bounds;domain=box(sa-a,sb-b,sc-c,sd-d);assert list(domain.bounds)==q['domain_bounds'];refs=q['obstacles'];assert [r['fixed_candidate'] for r in refs]==[i for i in groups[q['core_group']]['fixed_candidates'] if pool[i]['placement']['sheet_id']==q['sheet_id']];forbidden=unary_union([translate(cache[r['cache']],*pool[r['fixed_candidate']]['placement']['transform']['translation']) for r in refs]);assert forbidden.equals(from_geojson(q['raw_forbidden']));eroded=from_geojson(q['shrunken_forbidden']);assert eroded.difference(forbidden).is_empty;dist=eroded.distance(forbidden.boundary);assert dist>=eps-1e-7;minerosion=min(minerosion,dist);region=domain.difference(eroded);assert region.equals(from_geojson(q['translation_region']));hulls=[];sums=[];expected_cells=[]
        if not region.is_empty:
            a,b,c,d=region.bounds
            for i in range(math.floor(a/step),math.floor(c/step)+1):
                for j in range(math.floor(b/step),math.floor(d/step)+1):
                    clip=region.intersection(box(i*step,j*step,(i+1)*step,(j+1)*step))
                    if clip.is_empty:continue
                    expected_cells.append([i,j]);row=q['cell_hulls'][len(expected_cells)-1];assert row['cell']==[i,j];h=from_geojson(row['hull']);assert h.is_valid and h.equals(h.convex_hull) and h.covers(clip);expanded=MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(coords(clip.convex_hull),[(-eps,-eps),(-eps,eps),(eps,eps),(eps,-eps)])]).convex_hull;assert h.equals(expanded);hulls.append(h);cells_checked+=1
                    for piece in pieces:sums.append(MultiPoint([(x+u,y+v) for (x,y),(u,v) in product(coords(h),coords(piece))]).convex_hull);sums_checked+=1
        assert len(expected_cells)==len(q['cell_hulls']) and len(sums)==q['minkowski_sums'];cover=unary_union(hulls);sweep=unary_union(sums);assert region.difference(cover).is_empty and cover.equals(from_geojson(q['translation_outer_cover'])) and sweep.equals(from_geojson(q['swept_outer_cover']));occupied=sweep.intersection(physical[key]);assert occupied.equals(from_geojson(q['occupied_outer_cover'])) and abs(occupied.area-q['occupied_outer_area_mm2'])<1e-6;cover_by_query[q['index']]=occupied;translation_by_query[q['index']]=region;queries.append(q)
    assert load(BASE/'pending.json')==plan['queries'][len(queries):];aggregates=[];familycovers={}
    for reported in result['aggregates']:
        gi=reported['core_group'];record=load(BASE/'cores'/f'{gi}-aggregate.json');qs=[q for q in queries if q['core_group']==gi];assert len(qs)==24;areas=Counter();combined=0
        for sheet in ['sheet-0','sheet-1']:
            saved=next(r for r in record['covers'] if r['sheet_id']==sheet);families={}
            for f in ['bracket','insert']:
                g=unary_union([cover_by_query[q['index']] for q in qs if q['sheet_id']==sheet and q['family']==f]);assert g.equals(from_geojson(saved['families'][f]));families[f]=g;familycovers[gi,sheet,f]=g;areas[f]+=g.area
            both=unary_union(list(families.values()));assert both.equals(from_geojson(saved['combined']));combined+=both.area
        assert all(abs(areas[f]-record['family_area_upper_mm2'][f])<1e-6 for f in areas) and abs(combined-record['combined_area_upper_mm2'])<1e-6;assert reported=={k:v for k,v in record.items() if k!='covers'};aggregates.append(reported)
    ids=mp['candidates'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);families=np.asarray([pool[i]['placement']['part_id'] for i in ids]);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);angles=np.asarray([pool[i]['placement']['transform']['rotation_radians'] for i in ids]);mirrors=np.asarray([pool[i]['placement']['transform']['mirrored'] for i in ids]);translations=np.asarray([pool[i]['placement']['transform']['translation'] for i in ids]);memberships=translationchecks=0;complete={r['core_group'] for r in aggregates}
    for (gi,sheet,f),cover in familycovers.items():
        ix=np.asarray([j for j in range(len(ids)) if gi in mp['compatible_groups'][j] and sheets[j]==sheet and families[j]==f],dtype=int);shapely.prepare(cover);covered=shapely.covers(cover,gs[ix]);assert bool(np.all(covered)),(gi,sheet,f,[ids[int(j)] for j in ix[~covered]][:10]);memberships+=len(ix)
    for q in queries:
        if q['core_group'] not in complete:continue
        o=specs[q['specification']];angle=math.radians(o['degrees']);ix=np.asarray([j for j in range(len(ids)) if q['core_group'] in mp['compatible_groups'][j] and sheets[j]==q['sheet_id'] and families[j]==q['family'] and mirrors[j]==o['mirrored'] and abs(math.remainder(float(angles[j])-angle,math.tau))<1e-9],dtype=int);region=translation_by_query[q['index']];points=shapely.points(translations[ix]);shapely.prepare(region);assert bool(np.all(shapely.covers(region,points))),(q['index'],'uncovered known translation');translationchecks+=len(ix)
    expected_memberships=sum(sum(g in complete for g in groups_) for groups_ in mp['compatible_groups']);assert memberships==translationchecks==expected_memberships;local={i:j for j,i in enumerate(ids)};seedcounts=[]
    for seed in mp['mapped_seeds']:
        gi=seed['core_group'];assert gi in complete;chosen=seed['selected_variable_candidates'];assert all(shapely.covers(familycovers[gi,pool[i]['placement']['sheet_id'],pool[i]['placement']['part_id']],gs[local[i]]) for i in chosen);seedcounts.append(len(chosen)+33)
    assert seedcounts==[64,64,63,63];excluded=[r['core_group'] for r in aggregates if r['combined_slack_mm2']<0 or min(r['family_slack_mm2'].values())<0];write(OUT/'provenance.json',{'passed':True,'source_members_matching_committed_evidence':provenance})
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_members_verified':len(provenance),'all_permitted_orientation_reflection_classes':len(specs),'cached_zero_clearance_obstacles_reconstructed':len(cache),'cached_convex_piece_vertex_sums':cached_sums,'maximum_cache_area_error_mm2':max_error,'minimum_forbidden_erosion_distance_mm':minerosion,'queries_reconstructed':len(queries),'all_translation_regions_covered':True,'grid_hulls_independently_checked':cells_checked,'convex_occupied_point_sums_reconstructed':sums_checked,'complete_core_aggregates':len(aggregates),'known_variable_poses':len(ids),'known_compatible_original_polygon_cover_checks':memberships,'known_original_translation_region_checks':translationchecks,'four_baseline_counts':seedcounts,'conditionally_excluded_core_groups':excluded,'all_seven_area_bounds_exceed_inventory':len(aggregates)==7 and not excluded,'minimum_combined_area_slack_mm2':min(r['combined_slack_mm2'] for r in aggregates),'interpretation':'The audited generous occupied-area bounds exclude none of the seven fixed cores. They prove neither that the full inventory fits nor that any core must move. Finite-pose search limits remain unresolved.','solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
