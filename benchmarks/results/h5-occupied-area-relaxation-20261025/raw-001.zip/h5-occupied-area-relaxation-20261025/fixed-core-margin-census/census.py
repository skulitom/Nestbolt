"""Measure fixed cores before choosing a coordinate-model domain."""
from itertools import combinations
import math,shutil
from audit_h5_cog_lattices import shape
from build_h5_occupied_area_relaxation import ROOT,SRC,PRIOR,OUT as BASE,load,write,digest
OUT=BASE/'fixed-core-margin-census'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'census.py')
    paths=[SRC/'job.json',SRC/'conditional-target.json',PRIOR/'mapping.json',PRIOR/'candidates.json',ROOT/'crates/core/src/construct.rs',ROOT/'crates/core/src/sheets.rs']
    write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'scope':'Read-only original-polygon clearance census of every saved fixed core. Reproduce source guard and compensated sheet-search separation; measure boundary and pair margins. A sufficient-distance screen is not native acceptance. No pose or solver generation.'})
    job=load(paths[0]);target=load(paths[1]);mp=load(paths[2]);pool=load(paths[3]);parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance']
    assert job['units']=='mm'
    magnitude=max(1.,*(abs(x) for p in parts.values() for g in p['geometry'] for pt in g['outer'] for x in pt),*(d for s in job['stocks'] for d in [s['width'],s['height']]))
    guard=max(magnitude*32*2**-23,.00002);separation=(job['clearance']+guard)/math.cos(.05);rows=[]
    for core in mp['core_groups']:
        ps=[pool[i]['placement'] for i in core['fixed_candidates']];gs=[shape(parts[p['part_id']],p['transform']) for p in ps];pairs=[];edges=[]
        for j,g in enumerate(gs):
            height=st['height'] if ps[j]['sheet_id']=='sheet-0' else target['required_used_height_mm'];a,b,c,d=g.bounds
            for side,v in [('left',a-m['left']-edge),('bottom',b-m['bottom']-edge),('right',st['width']-m['right']-edge-c),('top',height-m['top']-edge-d)]:edges.append({'candidate':core['fixed_candidates'][j],'side':side,'slack_mm':v})
        for a,b in combinations(range(len(ps)),2):
            if ps[a]['sheet_id']==ps[b]['sheet_id']:pairs.append({'a':core['fixed_candidates'][a],'b':core['fixed_candidates'][b],'distance_mm':gs[a].distance(gs[b])})
        lowpair=min(pairs,key=lambda r:r['distance_mm']);lowedge=min(edges,key=lambda r:r['slack_mm']);row={'core_group':core['index'],'pairs_checked':len(pairs),'minimum_pair':lowpair,'minimum_stock_slack':lowedge,'below_guarded_pair_screen':[r for r in pairs if r['distance_mm']<separation],'below_guarded_stock_screen':[r for r in edges if r['slack_mm']<guard]};row['passes_sufficient_distance_screen']=not row['below_guarded_pair_screen'] and not row['below_guarded_stock_screen'];rows.append(row)
    write(OUT/'checks.json',{'passed':True,'source_magnitude_mm':magnitude,'conversion_guard_mm':guard,'compensated_sheet_separation_mm':separation,'cores':rows,'passing_sufficient_distance_screen':[r['core_group'] for r in rows if r['passes_sufficient_distance_screen']],'native_margin_qualified':False,'note':'Distances are measured in original f64 geometry. Actual native transformed collision checks are still required; no layout is qualified by this screen.'})
    print({'guard_mm':guard,'separation_mm':separation,'cores':[{'core':r['core_group'],'pair_mm':r['minimum_pair']['distance_mm'],'stock_slack_mm':r['minimum_stock_slack']['slack_mm'],'passes_screen':r['passes_sufficient_distance_screen']} for r in rows]},flush=True)
if __name__=='__main__':main()
