import{n}from"./engine-Cz7GqMN5.js";window.nestJob=n;window.benchReady=!0;
