from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-optional-bracket-trees-20261106';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-optional-bracket-trees-20261106'
PROCESS=ROOT/'output/h5-first57-optional-bracket-trees-process-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
audit=load(BASE/'audit/checks.json')
assert audit['passed'] and audit['new_fixed29_choices_excluded']==5 and audit['remaining_fixed29_choices']==63
assert audit['tree_records_verified']==10967 and audit['necessary_graph_witnesses']==61
assert audit['budget_limited_cases']==[[9,10,14]]
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106','h5-deferred-conflict-tree-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [BASE,PROCESS]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5_optional_bracket_trees*20261106.py'):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-optional-bracket-trees-report-20261106.md','prepare_h5_local_conflict_covers_20261104.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(BASE/'audit/checks.json','tree-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/necessary-graph-witnesses.json','necessary-graph-witnesses.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'complete_preparation_seconds':process['complete_process_seconds'],'processes':[process],
    'independent_audit_seconds':audit['seconds'],'per_case_seconds_cap':0.45,'expanded_node_cap':5000,
    'node_limited_case':[9,10,14],'closed_node_limited_case_must_not_be_extended':True,
    'placement_solver_calls':0,'native_calls':0})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'current_tree_process_closed':True,
    'remaining_fixed29_choices':63,'total_fixed29_choices_excluded':392,
    'bracket_graph_witnesses':61,'node_limited_bracket_case':[9,10,14],'earlier_joint_graph_case':[4,9,14],
    'next_method':'Build complete continuous insert covers for the remaining 63 cases and independently check their source/mode mapping. Then assess a new joint necessary graph requiring eight brackets and eight inserts. At each node independently certified family-specific clique covers bound the remaining count. Branch over every member of one conflict clique plus skipping it, preserving all candidates of both families compatible with a selected cell. Add source-certified mandatory-clique support propagation only when every clique is necessarily occupied. Freeze fresh time/node caps and independently replay all leaves/branches. Only a completely closed joint tree can exclude an arrangement; open graph witnesses are not source placements. Preserve all consumed preparation for any later construction ledger; do not extend the closed bracket-only tree or any earlier placement call.',
    'survivors':'output/h5-first57-optional-bracket-trees-20261106/audit/remaining-fixed29-choices.json',
    'bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104',
    'insert_necessary_cover':'output/h5-first57-necessary-mask-cover-20261104',
    'new_joint_model_prepared':False,'whole_allocation_candidates':440,
    'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded':5,'remaining_fixed29_choices':63,'total_fixed29_choices_excluded':392,'original_fixed29_choices':455,
    'tree_records_verified':10967,'branch_cliques_verified':2380,'closed_count_leaves_verified':6858,
    'closed_cover_pair_checks':3086774,'branch_clique_pair_checks':27075,'strict_source_inner_pair_evaluations':855133,
    'necessary_graph_witnesses':61,'node_limited_cases':[[9,10,14]],'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-optional-bracket-trees-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 optional bracket trees:** [independent complete-cover replay]({link}) verifies 10,967 tree records, 2,380 branching cliques and 6,858 closed count leaves across all 67 broader bracket cases. Complete trees exclude [1,11,12], [2,11,12], [3,11,12], [8,9,14] and [8,11,12], leaving 63 fixed29/cog choices (392 of 455 excluded). Sixty-one cases retain necessary bracket-graph witnesses; [9,10,14] reaches the frozen 5,000-node limit with 32 open leaves. Neither outcome is a source placement or an exclusion, and the limited process stays closed. Complete preparation/audit take 6.176453/2.258178 s, with no time overrun, placement solver or native call. A new joint bracket/insert necessary graph is next, with complete covers, fresh limits and independent replay. All consumed preparation must be charged before any later construction claim. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%; the next push still waits for the prior main run to finish successfully.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [complete deferred proof trees](../benchmarks/results/h5-deferred-conflict-tree-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [optional bracket trees](../benchmarks/results/{NAME}.md).',1)
a='proofs exclude another 15. Complete proof trees exclude four more, leaving\n68 choices (387 of 455 excluded). Case [4,9,14] has an unresolved necessary-graph\nwitness; 67 have larger bracket-clique bounds for a new optional-clique proof.\nAll prior calls and bounded processes stay closed.'
b='proofs exclude another 15. Mandatory proof trees exclude four more, and optional\nbracket trees exclude five, leaving 63 choices (392 of 455 excluded). Sixty-one\nbracket-graph witnesses, one node-limited case and the earlier joint witness\nremain unresolved. Fresh complete joint bracket/insert proofs are next.\nAll prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
