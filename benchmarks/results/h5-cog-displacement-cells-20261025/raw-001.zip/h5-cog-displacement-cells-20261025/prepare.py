"""Prepare bounded allowed displacement cells for complete guarded cog separation."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time,traceback
from shapely.geometry import shape,mapping,MultiPoint,box
from shapely.ops import unary_union
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
PREV=ROOT/'output/h5-original-core-search-20261025'
OUT=ROOT/'output/h5-cog-displacement-cells-20261025'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clip(poly,a,b,c):
    if not poly:return []
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        vp=a*p[0]+b*p[1]-c;vq=a*q[0]+b*q[1]-c
        if vp<=0:out.append(p)
        if (vp<0<vq) or (vq<0<vp):
            t=vp/(vp-vq);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return list(dict.fromkeys(out))
def encoded(points):return [[[v.numerator,v.denominator] for v in p] for p in points]
def dyadic_corners(points):
    values=[];scale=2**30
    for x,y in points:
        ix=math.floor(x/1000*scale);iy=math.floor(y/1000*scale)
        values.extend([(a/scale,b/scale) for a,b in product([ix,ix+1],[iy,iy+1])])
    return values
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+120
    paths=[SOURCE/'mutual/081.json',SOURCE/'queries/018.json',SOURCE/'queries/019.json',SOURCE/'audit/checks.json',PREV/'atlas.json',PREV/'audit/checks.json',
        PREV/'remaining-second-sheet-pairs/audit/verified-pair-witnesses.json',ROOT/'output/build_h5_strong_pair_domains.py',ROOT/'output/build_h5_full_original_joint_domains.py']
    assert load(paths[3])['passed'] and load(paths[5])['passed']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':120,'maximum_raw_faces':200000,'per_geometry_merge_attempt_limit':10000,
        'coordinate_units_per_mm':1000,'normal_scale':10000000,'allowed_face_inset_mm':.000001,'outward_forbidden_vertex_box_grid_mm':'2^-30',
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'For each complete same-sheet anchor difference box, reconstruct exactly the real convex failure region of each of the61 full guarded original source clauses. On integer coordinates, failure of outside projection>=bound is projection<=bound-1. Clip the complete difference rectangle by all those integer halfplanes using rational arithmetic. Enclose every resulting rational vertex in an outward exact dyadic box, then form its convex hull; their union conservatively covers every source-clause failure region. Decompose the bounded complement into convex allowed cells, retain all raw faces, inset each by1e-6mm and derive inward exact-error-rounded inequalities. Empty insets/grid boxes are explicitly retained as discards. Independent proof that every retained cell avoids every complete rational failure region is required before any model uses these cells. No original shape, clearance, stock/material limit or count is changed. This is a constructive subset; finite boundary losses do not establish unrestricted impossibility. No solver call.'})
    mutual=load(paths[0]);atlas=load(paths[4]);summaries=[]
    for qi in [18,19]:
        assert time.perf_counter()<deadline
        ds=load(SOURCE/'queries'/f'{qi:03d}.json')['domains']
        b=[min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)]
        r=[b[0]-b[2],b[1]-b[3],b[2]-b[0],b[3]-b[1]];assert atlas['same_sheet_difference_bounds'][str(qi)]==r
        rectangle=[(F(r[0]),F(r[1])),(F(r[2]),F(r[1])),(F(r[2]),F(r[3])),(F(r[0]),F(r[3]))]
        forbidden=[];enclosures=[]
        for face in mutual['faces']:
            poly=rectangle.copy()
            for h in face['outside_halfplanes']:poly=clip(poly,h['a'],h['b'],h['bound']-1)
            row={'source_face':face['index'],'vertices_units_rational':encoded(poly),'empty':not poly}
            if poly:
                enclosure=MultiPoint(dyadic_corners(poly)).convex_hull;assert enclosure.geom_type=='Polygon';enclosures.append(enclosure);row['outward_enclosure_mm']=mapping(enclosure)
            forbidden.append(row)
        obstacles=unary_union(enclosures)
        rect=MultiPoint(dyadic_corners(rectangle)).convex_hull
        free=rect.difference(obstacles);assert free.is_valid and not free.is_empty
        faces,merge=convex_faces(free,deadline);assert len(faces)<200000
        raw_union=unary_union(faces);missing=free.difference(raw_union);domains=[];discarded=[]
        for i,raw in enumerate(faces):
            inset=raw.buffer(-.000001,join_style='mitre');row={'index':i,'raw_face':mapping(raw)}
            if inset.is_empty:row['reason']='empty conservative inset';discarded.append(row);continue
            assert inset.geom_type=='Polygon' and inset.equals(inset.convex_hull) and free.covers(inset)
            row['inset_face']=mapping(inset);a,c,d,e=map(F,inset.bounds)
            bounds=[max(r[0],math.ceil(a*1000)),max(r[1],math.ceil(c*1000)),min(r[2],math.floor(d*1000)),min(r[3],math.floor(e*1000))]
            row['coordinate_bounds']=bounds
            if bounds[0]>bounds[2] or bounds[1]>bounds[3]:row['reason']='empty inward integer box';discarded.append(row);continue
            row['halfplanes']=inequalities(inset,True);domains.append(row)
        write(OUT/f'query-{qi}.json',{'query':qi,'sheet':qi-18,'profile':9,'anchor_union_bounds_units1000':b,'difference_bounds_units1000':r,
            'source_failure_polygons':forbidden,'outward_forbidden_union':mapping(obstacles),'outward_difference_rectangle':mapping(rect),'free_region':mapping(free),
            'raw_faces':len(faces),'raw_uncovered_region':mapping(missing),'raw_uncovered_area_mm2':missing.area,'raw_whole_free_region_covered':raw_union.covers(free),
            'merge':merge,'domains':domains,'discarded_faces':discarded})
        row={'query':qi,'raw_faces':len(faces),'allowed_cells':len(domains),'discarded_faces':len(discarded),'inward_halfplanes':sum(len(d['halfplanes']) for d in domains),
            'source_failure_regions':len(forbidden),'nonempty_source_failure_regions':len(enclosures),'raw_uncovered_area_mm2':missing.area,'raw_whole_free_region_covered':raw_union.covers(free),**merge}
        summaries.append(row);print(row,flush=True)
    write(OUT/'summary.json',summaries)
    witnesses=[]
    q19=load(OUT/'query-19.json')
    for w in load(paths[6]):
        a,b=w['positions'];x=b['x_units']-a['x_units'];y=b['y_units']-a['y_units'];matches=[]
        for d in q19['domains']:
            r=d['coordinate_bounds']
            if r[0]<=x<=r[2] and r[1]<=y<=r[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']):matches.append(d['index'])
        witnesses.append({'case':w['case'],'domain_rows':w['domain_rows'],'difference_units1000':[x,y],'matching_allowed_cell_indices':matches})
    write(OUT/'previous-witness-membership.json',witnesses)
    result={'seconds':time.perf_counter()-start,'completed_queries':2,'allowed_cells':sum(r['allowed_cells'] for r in summaries),'inward_halfplanes':sum(r['inward_halfplanes'] for r in summaries),
        'same_sheet_pair_choice_upper_bound':15*sum(r['allowed_cells'] for r in summaries),'previous_two_cog_witnesses_retained':sum(bool(w['matching_allowed_cell_indices']) for w in witnesses),
        'previous_two_cog_witnesses_checked':len(witnesses),'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert result['seconds']<120;write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
