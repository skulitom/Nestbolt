"""Independent exact rational proof of each selected allowed displacement cell."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time,traceback
import numpy as np
from shapely.geometry import shape,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from audit_h5_full_original_joint_domains import check_planes
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-displacement-cells-20261025';REF=BASE/'coarse-refinement';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def intersect(vertices,a,b,limit):
    if not vertices:return []
    output=[];previous=vertices[-1];pv=a*previous[0]+b*previous[1]-limit
    for current in vertices:
        cv=a*current[0]+b*current[1]-limit
        if (pv<=0)!=(cv<=0):
            ratio=pv/(pv-cv);output.append(tuple(previous[k]+ratio*(current[k]-previous[k]) for k in [0,1]))
        if cv<=0:output.append(current)
        previous=current;pv=cv
    return list(dict.fromkeys(output))
def decode(points):return [tuple(F(*v) for v in p) for p in points]
def normal(points,edge):
    p,q=points[edge],points[(edge+1)%len(points)];return q[1]-p[1],p[0]-q[0]
def projections(points,n):return [n[0]*p[0]+n[1]*p[1] for p in points]
def exact_gap(cell,bad,axis):
    if axis['kind']=='x':n=(F(1),F(0))
    elif axis['kind']=='y':n=(F(0),F(1))
    else:n=normal(cell if axis['kind']=='cell' else bad,axis['edge'])
    a,b=projections(cell,n),projections(bad,n)
    forward=min(b)-max(a);reverse=min(a)-max(b)
    return (forward,1) if forward>=reverse else (reverse,-1)
def separator(cell,bad):
    for kind in ['x','y']:
        axis={'kind':kind};gap,sign=exact_gap(cell,bad,axis)
        if gap>0:return {**axis,'sign':sign,'gap':[gap.numerator,gap.denominator]}
    ca=np.array([[float(v) for v in p] for p in cell]);ba=np.array([[float(v) for v in p] for p in bad]);axes=[];labels=[]
    for kind,points in [('cell',cell),('failure',bad)]:
        for i in range(len(points)):
            n=normal(points,i)
            if n==(0,0):continue
            x,y=map(float,n);scale=math.hypot(x,y);axes.append([x/scale,y/scale]);labels.append({'kind':kind,'edge':i})
    vectors=np.array(axes);ap=ca@vectors.T;bp=ba@vectors.T
    gaps=np.maximum(bp.min(axis=0)-ap.max(axis=0),ap.min(axis=0)-bp.max(axis=0))
    for index in np.argsort(gaps)[::-1]:
        axis=labels[int(index)];gap,sign=exact_gap(cell,bad,axis)
        if gap>0:return {**axis,'sign':sign,'gap':[gap.numerator,gap.denominator]}
    raise AssertionError('No exact strict separating axis for a retained cell')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    paths=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'Reconstruct every bounded source-clause failure polygon independently with exact rational halfplane clipping. Verify complete vertex sets and outward enclosures. Rebuild selected raw free regions, every inset/grid box and every sufficient inward coefficient-error bound. For every retained cell and every nonempty source failure polygon, certify a strict separating axis using exact rational projections of all vertices; floating axes only nominate a certificate that must pass exact arithmetic. Read certificates back and recheck them. On integer coordinates every failed original outside clause would lie in one of these complete failure polygons (projection<=bound-1), so disjointness proves every retained cell satisfies all full guarded original clauses. Preserve all unselected candidates and declared constructive losses. No solver call.'})
    for p in [BASE/'plan.json',BASE/'refinement/plan.json',REF/'plan.json']:
        for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-original-core-search-20261025/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in [SOURCE/'mutual/081.json',SOURCE/'queries/018.json',SOURCE/'queries/019.json']:assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    mutual=load(SOURCE/'mutual/081.json');rows=[];proofs=[];byquery={};cellpoints={};badpoints={};inside_count=0
    candidates=load(REF/'candidates.json');eligible=[r for r in candidates if r['complete_failure_union_covered'] and r['raw_whole_region_covered'] and r['allowed_cells']+4<=352]
    selected=min(eligible,key=lambda r:r['tolerance_mm']);assert selected==load(REF/'selection.json') and selected['candidate']==1
    assert (REF/'selected-query-18.json').read_bytes()==(REF/'candidate-1.json').read_bytes() and (REF/'selected-query-19.json').read_bytes()==(BASE/'query-19.json').read_bytes()
    for qi in [18,19]:
        original=load(BASE/f'query-{qi}.json');data=load(REF/f'selected-query-{qi}.json');byquery[qi]=data
        ds=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];b=[min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)]
        r=[b[0]-b[2],b[1]-b[3],b[2]-b[0],b[3]-b[1]];assert r==original['difference_bounds_units1000']==data['difference_bounds_units1000']
        rectangle=[(F(r[0]),F(r[1])),(F(r[2]),F(r[1])),(F(r[2]),F(r[3])),(F(r[0]),F(r[3]))]
        assert len(original['source_failure_polygons'])==len(mutual['faces'])==61
        forbidden=[]
        for row,face in zip(original['source_failure_polygons'],mutual['faces']):
            assert row['source_face']==face['index'];poly=rectangle.copy()
            for h in face['outside_halfplanes']:poly=intersect(poly,h['a'],h['b'],h['bound']-1)
            stored=decode(row['vertices_units_rational']);assert set(poly)==set(stored) and (not poly)==row['empty']
            badpoints[qi,face['index']]=poly
            if not poly:continue
            enclosure=orient(shape(row['outward_enclosure_mm']),sign=1);ep=[tuple(F(v)*1000 for v in p) for p in list(enclosure.exterior.coords)[:-1]]
            for i in range(len(ep)):
                n=normal(ep,i);limit=n[0]*ep[i][0]+n[1]*ep[i][1]
                assert all(n[0]*x+n[1]*y<=limit for x,y in poly)
            forbidden.append(enclosure)
        assert unary_union(forbidden).equals(shape(original['outward_forbidden_union']))
        if qi==18:
            source=shape(original['outward_forbidden_union']);simplified=source.simplify(data['tolerance_mm'],preserve_topology=True);expanded=simplified.buffer(data['outward_padding_mm'],join_style='mitre')
            assert data['tolerance_mm']==.005 and data['outward_padding_mm']==.01 and expanded.covers(source)
            assert expanded.equals_exact(shape(data['outward_forbidden_union']),0)
            free=shape(original['outward_difference_rectangle']).difference(expanded)
        else:free=shape(original['outward_difference_rectangle']).difference(shape(original['outward_forbidden_union']))
        assert free.equals_exact(shape(data['free_region']),0)
        allfaces=data['domains']+data['discarded_faces'];assert sorted(d['index'] for d in allfaces)==list(range(data['raw_faces']))
        assert unary_union([shape(d['raw_face']) for d in allfaces]).covers(free) and data.get('raw_whole_region_covered',data.get('raw_whole_free_region_covered'))
        assert not data['discarded_faces']
        for d in data['domains']:
            assert time.perf_counter()-start<120
            raw=shape(d['raw_face']);inset=raw.buffer(-.000001,join_style='mitre');assert inset.equals_exact(shape(d['inset_face']),0) and free.covers(inset) and inset.equals(inset.convex_hull)
            a,c,e,f=map(F,inset.bounds);expected=[max(r[0],math.ceil(a*1000)),max(r[1],math.ceil(c*1000)),min(r[2],math.floor(e*1000)),min(r[3],math.floor(f*1000))]
            assert d['coordinate_bounds']==expected;inside_count+=check_planes(inset,d['halfplanes'],True)
            points=[tuple(F(v)*1000 for v in p) for p in list(orient(inset,sign=1).exterior.coords)[:-1]];cellpoints[qi,d['index']]=points
            for i in range(len(points)):
                n=normal(points,i);limit=n[0]*points[i][0]+n[1]*points[i][1];assert all(n[0]*x+n[1]*y<=limit for x,y in points)
            for face in mutual['faces']:
                bad=badpoints[qi,face['index']]
                if not bad:continue
                certificate=separator(points,bad);proofs.append({'query':qi,'cell':d['index'],'source_face':face['index'],**certificate})
        rows.append({'query':qi,'retained_cells':len(data['domains']),'nonempty_failure_regions':len(forbidden),'cell_failure_pairs_proved':sum(p['query']==qi for p in proofs)})
    write(OUT/'separation-certificates.json',proofs)
    for p in load(OUT/'separation-certificates.json'):
        gap,sign=exact_gap(cellpoints[p['query'],p['cell']],badpoints[p['query'],p['source_face']],p)
        assert gap>0 and sign==p['sign'] and [gap.numerator,gap.denominator]==p['gap']
    witnesses=load(ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs/audit/verified-pair-witnesses.json');matches=[]
    for w in witnesses:
        a,b=w['positions'];x=b['x_units']-a['x_units'];y=b['y_units']-a['y_units'];ids=[]
        for d in byquery[19]['domains']:
            r=d['coordinate_bounds']
            if r[0]<=x<=r[2] and r[1]<=y<=r[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']):ids.append(d['index'])
        assert ids;matches.append({'case':w['case'],'difference_units1000':[x,y],'cell_indices':ids})
    write(OUT/'query-checks.json',rows);write(OUT/'retained-witnesses.json',matches)
    checks={'passed':True,'seconds':time.perf_counter()-start,'independently_rebuilt_source_failure_regions':122,'retained_first_sheet_cells':229,'retained_second_sheet_cells':4,
        'retained_cells':233,'exact_inward_halfplanes_verified':inside_count,'exact_whole_cell_failure_region_separations':len(proofs),'certificates_read_back':len(proofs),
        'all_full_guarded_original_clauses_implied_for_integer_differences':True,'previous_second_sheet_witnesses_retained':5,
        'first_sheet_simplification_tolerance_mm':.005,'first_sheet_outward_failure_padding_mm':.01,'constructive_restriction_not_unrestricted_exhaustion':True,
        'explicit_selected_query_difference_bounds_required':True,'potential_cell_flags_across15_pairs':3495,'solver_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert checks['seconds']<120;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
