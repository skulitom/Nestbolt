"""Bounded outward simplification of q18 failure union; q19 stays exact."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time,traceback
from shapely.geometry import shape,mapping
from shapely.ops import unary_union
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-displacement-cells-20261025';OUT=BASE/'coarse-refinement'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'refine.py');start=time.perf_counter();deadline=start+120
    inputs=[BASE/'plan.json',BASE/'query-18.json',BASE/'query-19.json',BASE/'result.json',BASE/'refinement/result.json',ROOT/'output/build_h5_strong_pair_domains.py',ROOT/'output/build_h5_full_original_joint_domains.py']
    tolerances=[.001,.005,.01,.025,.05]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':120,'simplification_tolerances_mm':tolerances,'outward_padding_multiple':2,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'The exact source-clause complement created1245 first-sheet cells, so the previous four sub-micrometre candidates still required at least1158 cells; measure five distinct, explicitly declared conservative representations. Simplify only the first-sheet whole forbidden union with preserved topology, then pad it outward by twice the simplification tolerance using mitred joins. Require the entire original outward failure union to remain covered before retaining the candidate. Decompose the resulting free complement, retaining all raw and discarded inset/grid faces and raw coverage losses. Prefer the smallest tolerance among fully covered candidates with at most352 total cells including the four unchanged second-sheet cells; if none qualifies, retain the smallest representation only as diagnostic data; this is a representation-size decision, not benchmark acceptance. The second-sheet four-cell representation and all five original witnesses stay unchanged. Every final retained cell still needs an independent exact separation proof against every rational source failure polygon before any solver use. Added exclusion is a documented constructive restriction, never a weaker guard or a global impossibility claim.'})
    original=load(inputs[1]);obstacle=shape(original['outward_forbidden_union']);rect=shape(original['outward_difference_rectangle']);r=original['difference_bounds_units1000'];records=[]
    for index,tol in enumerate(tolerances):
        assert time.perf_counter()<deadline
        simpler=obstacle.simplify(tol,preserve_topology=True);expanded=simpler.buffer(2*tol,join_style='mitre')
        covers=expanded.covers(obstacle)
        if not covers:
            write(OUT/f'candidate-{index}.json',{'tolerance_mm':tol,'complete_failure_union_covered':False,'uncovered':mapping(obstacle.difference(expanded))});records.append({'candidate':index,'tolerance_mm':tol,'complete_failure_union_covered':False});continue
        free=rect.difference(expanded);faces,merge=convex_faces(free,deadline);domains=[];discarded=[]
        for i,raw in enumerate(faces):
            row={'index':i,'raw_face':mapping(raw)};inset=raw.buffer(-.000001,join_style='mitre')
            if inset.is_empty:row['reason']='empty conservative inset';discarded.append(row);continue
            assert inset.geom_type=='Polygon' and inset.equals(inset.convex_hull) and free.covers(inset)
            row['inset_face']=mapping(inset);a,b,c,d=map(F,inset.bounds)
            bounds=[max(r[0],math.ceil(a*1000)),max(r[1],math.ceil(b*1000)),min(r[2],math.floor(c*1000)),min(r[3],math.floor(d*1000))];row['coordinate_bounds']=bounds
            if bounds[0]>bounds[2] or bounds[1]>bounds[3]:row['reason']='empty inward integer box';discarded.append(row);continue
            row['halfplanes']=inequalities(inset,True);domains.append(row)
        raw_union=unary_union(faces);missing=free.difference(raw_union)
        row={'candidate':index,'tolerance_mm':tol,'outward_padding_mm':2*tol,'complete_failure_union_covered':True,'raw_faces':len(faces),'allowed_cells':len(domains),
            'discarded_faces':len(discarded),'inward_halfplanes':sum(len(d['halfplanes']) for d in domains),'raw_uncovered_area_mm2':missing.area,'raw_whole_region_covered':raw_union.covers(free),**merge}
        write(OUT/f'candidate-{index}.json',{**row,'query':18,'sheet':0,'profile':9,'difference_bounds_units1000':r,'simplified_failure_union':mapping(simpler),
            'outward_forbidden_union':mapping(expanded),'free_region':mapping(free),'raw_uncovered_region':mapping(missing),'domains':domains,'discarded_faces':discarded})
        records.append(row);print(row,flush=True)
    valid=[r for r in records if r['complete_failure_union_covered'] and r['raw_whole_region_covered']]
    eligible=[r for r in valid if r['allowed_cells']+4<=352];chosen=min(eligible,key=lambda r:r['tolerance_mm']) if eligible else min(valid,key=lambda r:(r['allowed_cells'],r['inward_halfplanes'],r['tolerance_mm']));shutil.copyfile(OUT/f"candidate-{chosen['candidate']}.json",OUT/'selected-query-18.json');shutil.copyfile(BASE/'query-19.json',OUT/'selected-query-19.json')
    write(OUT/'candidates.json',records);write(OUT/'selection.json',chosen)
    q19=load(BASE/'query-19.json');result={'seconds':time.perf_counter()-start,'candidates_examined':len(records),'complete_covered_candidates':len(valid),'selected_candidate':chosen['candidate'],'smaller_than_original_core_direction_count':bool(eligible),
        'selected_first_sheet_cells':chosen['allowed_cells'],'selected_second_sheet_cells':len(q19['domains']),'selected_total_cells':chosen['allowed_cells']+len(q19['domains']),
        'possible_cell_flags_across15_pairs':15*(chosen['allowed_cells']+len(q19['domains'])),'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert result['seconds']<120;write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
