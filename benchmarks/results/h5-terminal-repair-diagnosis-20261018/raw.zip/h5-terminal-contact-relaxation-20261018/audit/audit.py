"""Audit saved free-region queries and the rejected collective LP without running either search again."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,itertools,json,math,shutil,subprocess,sys,traceback
import numpy as np
from shapely.geometry import Polygon,shape
ROOT=Path(__file__).resolve().parents[1];OBS=ROOT/'output/h5-terminal-repair-observer-20261018'
FREE=ROOT/'output/h5-terminal-cog-regions-20261018';RELAX=ROOT/'output/h5-terminal-contact-relaxation-20261018';OUT=RELAX/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');fixture=load(OBS/'fixture.json');job=fixture['job'];base=load(OBS/'audit/best/layout.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    try:
        queries=load(FREE/'attempts.json');freecheck=load(FREE/'checks.json');relaxcheck=load(RELAX/'checks.json')
        assert len(queries)==freecheck['queries']==380 and not freecheck['expired'] and freecheck['accepted_moves']==0
        assert load(FREE/'initial-layout.json')==load(FREE/'final-layout.json')==base
        bycopy=Counter()
        for i,q in enumerate(queries):
            folder=FREE/f'query-{i:04}';assert q==load(folder/'query.json') and q['query']==i
            region=shape(load(folder/'free-region.json'));assert region.is_empty and region.area==q['free_area_mm2']==0 and q['regions']==q['positions']==0 and not q['accepted'];bycopy[q['copy_index']]+=1
        assert len(bycopy)==10 and set(bycopy.values())=={38}
        assert load(RELAX/'initial-layout.json')==load(RELAX/'final-layout.json')==base
        assert relaxcheck['reason']=='local_stall' and relaxcheck['iterations']==1 and relaxcheck['accepted_iterations']==0
        plan=load(RELAX/'plan.json');event=load(RELAX/'iteration-00/result.json');solution=load(RELAX/'iteration-00/solution.json');constraints=load(RELAX/'iteration-00/constraints.json')
        shifts=np.asarray(solution['shifts']);slacks=np.asarray(solution['slacks']);assert len(shifts)==66 and len(slacks)==len(constraints) and min(slacks)>=-1e-9 and np.max(np.abs(shifts))<=plan['coordinate_step_mm']+1e-7
        assert all(np.max(np.abs(shifts[i]))==0 for i,p in enumerate(base['placements']) if p['part_id']=='frame')
        residuals=[]
        for k,c in enumerate(constraints):
            normal=np.asarray(c['normal']);assert abs(np.linalg.norm(normal)-1.)<1e-9
            residual=float(normal@(shifts[c['a']]-shifts[c['b']])-slacks[k]-c['rhs']);residuals.append(residual);assert residual<=1e-6
        objective=float(np.sum(slacks)+plan['movement_cost']*np.sum(np.abs(shifts)));assert abs(objective-solution['objective'])<1e-6
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
        source=ROOT/'output/h5-pattern-joint-probe-20261018/inputs'/load(OBS/'plan.json')['case'];results=[]
        for trial in event['trials']:
            fraction=trial['fraction'];folder=OUT/f'fraction-{fraction:g}';folder.mkdir();layout=copy.deepcopy(base);geoms=[];outside=[];rows=[];conflicts=[]
            for i,p in enumerate(layout['placements']):
                before=base['placements'][i];p['transform']['translation']=[float(x+d*fraction) for x,d in zip(before['transform']['translation'],shifts[i])]
                assert all(p[k]==before[k] for k in ['part_id','copy_index','sheet_id']) and p['transform']['rotation_radians']==before['transform']['rotation_radians'] and p['transform']['mirrored']==before['transform']['mirrored']
                t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);vertices=[]
                for x,y in parts[p['part_id']]['geometry'][0]['outer']:
                    if t['mirrored']:x=-x
                    vertices.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
                geom=Polygon(vertices);assert geom.is_valid;geoms.append(geom);a,b,c,d=geom.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else fixture['target_used_height_mm']
                if a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7:outside.append(i)
            assert Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in job['parts']}) and len({(p['part_id'],p['copy_index']) for p in layout['placements']})==66
            for i,j in itertools.combinations(range(66),2):
                if layout['placements'][i]['sheet_id']!=layout['placements'][j]['sheet_id']:continue
                a,b=geoms[i],geoms[j];ov=a.intersection(b).area;dist=a.distance(b);row={'a':i,'b':j,'overlap_mm2':ov,'distance_mm':dist};rows.append(row)
                if ov>1e-7 or dist<job['clearance']-1e-7:conflicts.append(row)
            record={'fraction':fraction,'pairs_checked':len(rows),'physical_pair_conflicts':len(conflicts),'outside_indices':outside,'filled_overlap_mm2':sum(r['overlap_mm2'] for r in rows),'original_target_valid':not outside and not conflicts,'recorded_conservative_penetration_mm':trial['penetration_mm']}
            assert not record['original_target_valid'] and trial['penetration_mm']>event['before_penetration_mm']
            if fraction==1.:assert not outside
            write(folder/'layout.json',layout);write(folder/'checks.json',record);write(folder/'conflicts.json',conflicts)
            with gzip.open(folder/'all-physical-pairs.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
                for row in rows:f.write(json.dumps(row)+'\n')
            if fraction==1.:
                command=[str(cli),'validate','--library',str(source/'library.json'),'--request',str(source/'request.json'),'--layout',str(folder/'layout.json')]
                cp=subprocess.run(command,capture_output=True,timeout=60);(folder/'public.json').write_bytes(cp.stdout);(folder/'public.stderr').write_bytes(cp.stderr);write(folder/'public-command.json',{'command':command,'exit_code':cp.returncode});report=json.loads(cp.stdout);assert cp.returncode==1 and report['valid']==False
            results.append(record)
        checks={'complete':True,'production_digest':source_digest(),'empty_free_regions_verified':380,'distinct_cogs':len(bycopy),'queries_per_cog':38,
            'original_final_layouts_unchanged':True,'all_LP_constraints_verified':True,'LP_max_residual_mm':max(residuals),'LP_objective_reproduced':objective,
            'LP_sum_slacks_mm':float(np.sum(slacks)),'collective_trial_pairs_checked':sum(r['pairs_checked'] for r in results),'trials':results,'accepted_layouts':0,'new_native_searches':0,'H5_complete':False}
        write(OUT/'checks.json',checks);print(json.dumps(checks),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
