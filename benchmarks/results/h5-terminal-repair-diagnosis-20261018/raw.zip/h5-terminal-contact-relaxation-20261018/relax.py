"""Offline collective contact linearization of a rejected state; not native search or a quality run."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import copy,importlib.util,itertools,json,math,shutil,time,traceback
import numpy as np
from scipy.optimize import linprog
from shapely.geometry import Polygon,Point
from shapely.affinity import translate
from shapely.ops import nearest_points
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-terminal-repair-observer-20261018'
OUT=ROOT/'output/h5-terminal-contact-relaxation-20261018'
SECONDS=120.;ITERATIONS=40;STEP=60.;TOL=1e-7;MOVE_COST=1e-4
spec=importlib.util.spec_from_file_location('gap',ROOT/'output/diagnose_h5_concave_gaps.py');gap=importlib.util.module_from_spec(spec);spec.loader.exec_module(gap)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'relax.py');fixture=load(PRIOR/'fixture.json');job=fixture['job'];layout=load(PRIOR/'audit/best/layout.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'source_layout_sha256':digest(PRIOR/'audit/best/layout.json'),
        'method':'Keep all rotations, reflections, copies and sheet assignments exact. Keep frames fixed; jointly translate every other part, including currently noncolliding neighbours. Derive local separating half-planes from closest boundaries of conservative filled-outer Minkowski obstacles. Minimize sum of nonnegative separation slacks plus 0.0001 times absolute movement, within original sheet bounds and 60 mm coordinate trust steps. Re-evaluate all affected nonlinear obstacle contacts at fractions 1, 1/2, 1/4, 1/8, 1/16, accept only decreasing penetration sum. Retain every LP, trial, failure and final actual-geometry check. No infeasibility claim follows from stopping.',
        'geometry_seconds_cap':SECONDS,'iterations_cap':ITERATIONS,'coordinate_step_mm':STEP,'movement_cost':MOVE_COST,
        'construction_margin_mm':gap.EPS,'acceptance_tolerance_mm':TOL,'native_calls':0,'quality_runs':0,'completion_claim':False})
    write(OUT/'job.json',job);write(OUT/'initial-layout.json',layout);start=time.perf_counter();history=[]
    try:
        parts={p['id']:p for p in job['parts']};n=len(layout['placements']);stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];height=fixture['target_used_height_mm']
        gs=[gap.pose(Polygon(parts[p['part_id']]['geometry'][0]['outer']),p['transform']) for p in layout['placements']]
        origins=np.asarray([g.bounds[:2] for g in gs]);shapes=[translate(g,-x,-y) for g,(x,y) in zip(gs,origins)]
        movable=[i for i,p in enumerate(layout['placements']) if p['part_id']!='frame'];vi={i:k for k,i in enumerate(movable)};nv=2*len(movable)
        limits=[]
        for i,g in enumerate(shapes):
            h=stock['height'] if layout['placements'][i]['sheet_id']=='sheet-0' else height
            limits.append((m['left']+edge,m['bottom']+edge,stock['width']-m['right']-edge-g.bounds[2],h-m['top']-edge-g.bounds[3]))
        pairs=[(i,j) for i,j in itertools.combinations(range(n),2) if layout['placements'][i]['sheet_id']==layout['placements'][j]['sheet_id'] and (i in vi or j in vi)]
        obstacle_cache={};pair_obstacles={}
        def obstacle(i,j):
            if (i,j) not in pair_obstacles:
                key=(shapes[i].wkb,shapes[j].wkb)
                if key not in obstacle_cache:obstacle_cache[key]=gap.obstacle(shapes[i],shapes[j],job['clearance'])
                pair_obstacles[(i,j)]=obstacle_cache[key]
            return pair_obstacles[(i,j)]
        def contacts(pos,with_normals=False):
            out=[];merit=0.
            for i,j in pairs:
                a,b=pos[i],pos[j];wi,hi=shapes[i].bounds[2:];wj,hj=shapes[j].bounds[2:]
                if max(b[0]-a[0]-wi,a[0]-b[0]-wj,b[1]-a[1]-hi,a[1]-b[1]-hj)>2*math.sqrt(2)*STEP+job['clearance']:continue
                region=obstacle(i,j);p=Point(*(b-a));q=nearest_points(region.boundary,p)[0];v=np.array([q.x-p.x,q.y-p.y]);d=float(np.linalg.norm(v));inside=region.contains(p)
                merit+=d if inside else 0.
                if with_normals:
                    if d<1e-9:
                        # Resolve a zero-distance boundary normal with symmetric probes.
                        candidates=[]
                        for poly in gap.polygons(region):
                            coords=list(poly.exterior.coords)
                            for u,w in zip(coords,coords[1:]):
                                e=np.asarray(w)-u;l=float(np.linalg.norm(e))
                                if l<1e-12:continue
                                t=np.clip(np.dot(np.array([p.x,p.y])-u,e)/(l*l),0.,1.);r=np.asarray(u)+t*e
                                candidates.append((float(np.linalg.norm(r-[p.x,p.y])),e/l))
                        _,e=min(candidates,key=lambda x:x[0]);normal=np.array([e[1],-e[0]])
                        if region.contains(Point(*(np.array([p.x,p.y])+1e-5*normal))):normal=-normal
                    else:normal=v/d if inside else -v/d
                    out.append((i,j,normal,np.array([q.x,q.y]),d if inside else -d))
            for i in movable:
                l,b,r,t=limits[i];x,y=pos[i];merit+=max(l-x,0.)+max(x-r,0.)+max(b-y,0.)+max(y-t,0.)
            return merit,out
        def physical(pos):
            geoms=[translate(g,*(pos[i]-origins[i])) for i,g in enumerate(gs)];bad=[];area=0.;pair_count=0;outside=[]
            for i,j in itertools.combinations(range(n),2):
                if layout['placements'][i]['sheet_id']!=layout['placements'][j]['sheet_id']:continue
                pair_count+=1;ov=geoms[i].intersection(geoms[j]).area;dist=geoms[i].distance(geoms[j]);area+=ov
                if ov>1e-7 or dist<job['clearance']-TOL:bad.append({'a':i,'b':j,'overlap_mm2':ov,'distance_mm':dist})
            for i,(x,y) in enumerate(pos):
                l,b,r,t=limits[i]
                if x<l-TOL or y<b-TOL or x>r+TOL or y>t+TOL:outside.append(i)
            return {'pairs_checked':pair_count,'pair_conflicts':bad,'outside_indices':outside,'overlap_mm2':area,'valid':not bad and not outside}
        current=origins.copy();initial=physical(current);write(OUT/'initial-checks.json',initial);reason='iteration_limit'
        for iteration in range(ITERATIONS):
            if time.perf_counter()-start>=SECONDS:reason='geometry_time_limit';break
            merit,cs=contacts(current,True)
            if time.perf_counter()-start>=SECONDS:reason='geometry_time_limit';break
            if merit<1e-8:reason='zero_conservative_penetration';break
            ns=len(cs);dimension=2*nv+ns;rows=[];rhs=[];bounds=[]
            for i in movable:
                l,b,r,t=limits[i];x,y=current[i];bounds.extend([(max(-STEP,l-x),min(STEP,r-x)),(max(-STEP,b-y),min(STEP,t-y))])
            bounds += [(0.,None)]*(nv+ns)
            for k in range(nv):
                for sign in (-1.,1.):
                    row=np.zeros(dimension);row[k]=sign;row[nv+k]=-1.;rows.append(row);rhs.append(0.)
            saved_constraints=[]
            for k,(i,j,normal,q,penetration) in enumerate(cs):
                row=np.zeros(dimension)
                if i in vi:row[2*vi[i]:2*vi[i]+2]=normal
                if j in vi:row[2*vi[j]:2*vi[j]+2]=-normal
                row[2*nv+k]=-1.;value=float(normal@(current[j]-current[i]-q));rows.append(row);rhs.append(value)
                saved_constraints.append({'a':i,'b':j,'normal':normal.tolist(),'boundary':q.tolist(),'rhs':value,'penetration_mm':penetration})
            objective=np.r_[np.zeros(nv),np.full(nv,MOVE_COST),np.ones(ns)]
            solution=linprog(objective,A_ub=np.asarray(rows),b_ub=np.asarray(rhs),bounds=bounds,method='highs',options={'time_limit':min(10.,max(.01,SECONDS-(time.perf_counter()-start)))})
            folder=OUT/f'iteration-{iteration:02}';folder.mkdir();write(folder/'constraints.json',saved_constraints)
            event={'iteration':iteration,'before_penetration_mm':merit,'lp_success':bool(solution.success),'lp_status':int(solution.status),'lp_message':solution.message,'elapsed_seconds':time.perf_counter()-start,'trials':[],'accepted':False}
            if not solution.success:
                write(folder/'result.json',event);history.append(event);reason='linear_program_failure';break
            step=np.zeros((n,2));step[movable]=solution.x[:nv].reshape(len(movable),2)
            write(folder/'solution.json',{'shifts':step.tolist(),'slacks':solution.x[2*nv:].tolist(),'objective':float(solution.fun)})
            chosen=None
            for fraction in [1.,.5,.25,.125,.0625]:
                trial=current+fraction*step;score,_=contacts(trial);event['trials'].append({'fraction':fraction,'penetration_mm':score})
                if score<merit-1e-6 and (chosen is None or score<chosen[0]):chosen=(score,fraction,trial)
                if time.perf_counter()-start>=SECONDS:break
            if chosen is not None:
                current=chosen[2];event.update({'accepted':True,'fraction':chosen[1],'after_penetration_mm':chosen[0],'physical':physical(current)});write(folder/'origins.json',current.tolist())
            write(folder/'result.json',event);history.append(event)
            print(json.dumps({'iteration':iteration,'penetration_mm':event.get('after_penetration_mm',merit),'accepted':event['accepted'],'seconds':time.perf_counter()-start}),flush=True)
            if chosen is None:reason='local_stall';break
        final=physical(current);result=copy.deepcopy(layout)
        for i,p in enumerate(result['placements']):p['transform']['translation']=[float(x+d) for x,d in zip(p['transform']['translation'],current[i]-origins[i])]
        assert all(result['placements'][i]==layout['placements'][i] for i in range(n) if i not in vi)
        assert Counter(p['part_id'] for p in result['placements'])==Counter({p['id']:p['quantity'] for p in job['parts']})
        write(OUT/'final-layout.json',result);write(OUT/'final-checks.json',final);write(OUT/'history.json',history)
        write(OUT/'checks.json',{'complete':True,'reason':reason,'geometry_seconds':time.perf_counter()-start,'iterations':len(history),'accepted_iterations':sum(e['accepted'] for e in history),
            'initial_overlap_mm2':initial['overlap_mm2'],'final_overlap_mm2':final['overlap_mm2'],'final_pair_conflicts':len(final['pair_conflicts']),'final_outside_count':len(final['outside_indices']),
            'complete_target_layout':final['valid'],'maximum_coordinate_translation_mm':float(np.max(np.abs(current-origins))),'all_frames_fixed':True,'quantities_rotations_reflections_and_sheet_assignments_unchanged':True,'native_calls':0,'quality_runs':0})
        print((OUT/'checks.json').read_text(encoding='utf-8'),flush=True)
    except Exception as e:
        write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'history':history});raise
if __name__=='__main__':main()
