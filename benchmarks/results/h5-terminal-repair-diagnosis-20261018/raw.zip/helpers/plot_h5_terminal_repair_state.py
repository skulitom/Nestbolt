"""Draw original filled outlines for the initial proposal and the unaccepted terminal best state."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch,Rectangle,Patch as LegendPatch
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-terminal-repair-observer-20261018'
fixture=json.loads((OUT/'fixture.json').read_bytes());job=fixture['job'];parts={p['id']:p for p in job['parts']}
colors={'frame':'#b8d5e8','bracket':'#c3acd7','insert':'#a7cfb3','cog':'#edb35e'}
fig,axes=plt.subplots(2,2,figsize=(11,12),gridspec_kw={'height_ratios':[3000,326]},layout='constrained')
for col,phase in enumerate(['initial','best']):
    layout=json.loads((OUT/'audit'/phase/'layout.json').read_bytes());checks=json.loads((OUT/'audit'/phase/'checks.json').read_bytes())
    conflicted={(part,copy) for p in checks['physical_conflicts'] for part,copy in zip(p['parts'],p['copies'])}
    conflicted|={(p['part'],p['copy']) for p in checks['bounds_violations']}
    for row,sheet in enumerate(['sheet-0','sheet-1']):
        ax=axes[row,col];height=job['stocks'][0]['height'] if row==0 else fixture['target_used_height_mm'];width=job['stocks'][0]['width']
        ax.add_patch(Rectangle((0,0),width,height,facecolor='#fafafa',edgecolor='#34495e',linewidth=1.4))
        for p in layout['placements']:
            if p['sheet_id']!=sheet:continue
            t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);verts=[]
            for x,y in parts[p['part_id']]['geometry'][0]['outer']:
                if t['mirrored']:x=-x
                verts.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
            hot=(p['part_id'],p['copy_index']) in conflicted
            ax.add_patch(Patch(verts,closed=True,facecolor=colors[p['part_id']],edgecolor='#bd2424' if hot else '#64717a',linewidth=1.1 if hot else .45,alpha=.80))
            if p['part_id']=='cog' or hot:
                xs,ys=zip(*verts);label=p['part_id'][0].upper()+str(p['copy_index']+1)
                ax.text((min(xs)+max(xs))/2,(min(ys)+max(ys))/2,label,ha='center',va='center',fontsize=7,color='#822020' if hot else '#453b25')
        ax.set_xlim(-25,width+25);ax.set_ylim(-12,height+(65 if row==0 else 15));ax.set_aspect('equal');ax.tick_params(labelsize=7)
        ax.set_ylabel('mm' if col==0 else '');ax.set_xlabel('mm' if row==1 else '')
        if row==0:
            title='Restored starting proposal' if phase=='initial' else 'Best saved state — still rejected'
            ax.set_title(f'{title}\nFilled overlap: {checks["filled_overlap_mm2"]:,.0f} mm²',fontsize=11)
        else:ax.set_title('Second sheet: original 325.927 mm target',fontsize=9)
fig.suptitle('Repair reduces overlap but leaves the cog region unresolved\nLarge plates · 0.2 mm kerf · seed 0 · unchanged 12-work-second allowance',fontsize=13)
handles=[LegendPatch(facecolor=v,edgecolor='#64717a',label=k.title()) for k,v in colors.items()]
handles.append(LegendPatch(facecolor='none',edgecolor='#bd2424',label='Overlap or outside stock'))
fig.legend(handles=handles,loc='outside lower center',ncol=5,fontsize=9)
fig.savefig(OUT/'terminal-layouts.png',dpi=160)
print(str(OUT/'terminal-layouts.png'))
