"""Exact filled-outer free-region queries for residual cogs, with all neighbours fixed per query."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import copy,importlib.util,itertools,json,math,shutil,subprocess,time,traceback
from shapely.geometry import Polygon,box,mapping
from shapely.affinity import affine_transform,translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-terminal-repair-observer-20261018'
OUT=ROOT/'output/h5-terminal-cog-regions-20261018';SECONDS=120.;MAX_MOVES=8;TOL=1e-7
spec=importlib.util.spec_from_file_location('gap',ROOT/'output/diagnose_h5_concave_gaps.py');gap=importlib.util.module_from_spec(spec);spec.loader.exec_module(gap)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'query.py');fixture=load(PRIOR/'fixture.json');job=fixture['job'];layout=load(PRIOR/'audit/best/layout.json')
    parts={p['id']:p for p in job['parts']};original={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];height=fixture['target_used_height_mm']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'source_layout_sha256':digest(PRIOR/'audit/best/layout.json'),
        'method':'Rank cogs outside stock first, then by actual residual overlap. Remove one cog and calculate conservative Minkowski free regions against all other actual filled outer contours on both original target sheets. Try its current free angle, then integer angles 0 through 17 degrees (a finite phase sample for this 20-tooth family, not exhaustive free rotation). The obstacle helper uses exact covering convex pieces and a mitred clearance envelope plus 0.0001 mm construction margin. Accept only a position clear of every fixed neighbour and inside the original target stock. A move must strictly reduce the whole physical violation count; original quantities remain. Recompute after accepted moves. Keep all attempted regions, any expiry and unchanged failed state.',
        'geometry_seconds_cap':SECONDS,'accepted_move_cap':MAX_MOVES,'acceptance_tolerance_mm':TOL,'native_or_quality_runs':0,
        'runtime_budget_unchanged':True,'geometric_infeasibility_claim':False})
    write(OUT/'initial-layout.json',layout);write(OUT/'job.json',job);start=time.perf_counter();templates={};obstacles={};attempts=[];moves=[];expired=False
    def geom(p):return gap.pose(original[p['part_id']],p['transform'])
    def local(p):
        t=p['transform'];key=(p['part_id'],t['rotation_radians'],t['mirrored'])
        if key not in templates:
            g=gap.pose(original[p['part_id']],{**t,'translation':[0.,0.]});a,b,_,_=g.bounds;templates[key]=(translate(g,-a,-b),a,b)
        return key,templates[key]
    def inspect(value):
        gs=[geom(p) for p in value['placements']];bad=Counter();area=0.;outside=[];pairs=0;conflicts=0
        for i,(p,g) in enumerate(zip(value['placements'],gs)):
            a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else height
            if a<m['left']+edge-TOL or b<m['bottom']+edge-TOL or c>stock['width']-m['right']-edge+TOL or d>h-m['top']-edge+TOL:outside.append(i);bad[i]+=1
        for i,j in itertools.combinations(range(len(gs)),2):
            if value['placements'][i]['sheet_id']!=value['placements'][j]['sheet_id']:continue
            pairs+=1;overlap=gs[i].intersection(gs[j]).area;distance=gs[i].distance(gs[j]);area+=overlap
            if overlap>1e-7 or distance<job['clearance']-TOL:bad[i]+=1;bad[j]+=1;conflicts+=1
        return {'geoms':gs,'bad':bad,'outside':outside,'pair_conflicts':conflicts,'overlap_mm2':area,'pairs':pairs,'violations':conflicts+len(outside)}
    initial=inspect(layout)
    try:
        while len(moves)<MAX_MOVES and time.perf_counter()-start<SECONDS:
            state=inspect(layout)
            if state['violations']==0:break
            order=sorted((i for i in state['bad'] if layout['placements'][i]['part_id']=='cog'),key=lambda i:(i not in state['outside'],-state['bad'][i],i))
            accepted=False
            for i in order:
                p=layout['placements'][i];angles=[p['transform']['rotation_radians']]+[math.radians(a) for a in range(18)]
                for angle in dict.fromkeys(angles):
                    moving={**p,'transform':{**p['transform'],'rotation_radians':angle,'translation':[0.,0.]}};mk,(shape,mx,my)=local(moving)
                    for sheet,h in [('sheet-0',stock['height']),('sheet-1',height)]:
                        if time.perf_counter()-start>=SECONDS:expired=True;break
                        folder=OUT/f'query-{len(attempts):04}';folder.mkdir()
                        x0,y0,x1,y1=shape.bounds
                        domain=box(m['left']+edge+gap.EPS-x0,m['bottom']+edge+gap.EPS-y0,stock['width']-m['right']-edge-gap.EPS-x1,h-m['top']-edge-gap.EPS-y1)
                        forbidden=[]
                        for j,q in enumerate(layout['placements']):
                            if j==i or q['sheet_id']!=sheet:continue
                            fk,(fixed,fx,fy)=local(q);key=(fk,mk)
                            if key not in obstacles:obstacles[key]=gap.obstacle(fixed,shape,job['clearance'])
                            tx,ty=q['transform']['translation'];forbidden.append(translate(obstacles[key],tx+fx,ty+fy))
                        free=domain.difference(unary_union(forbidden));polys=gap.polygons(free)
                        write(folder/'free-region.json',mapping(free));positions=[]
                        for poly in polys:
                            if poly.area<=0:continue
                            positions.extend(list(poly.exterior.coords)[:-1]);point=poly.representative_point();positions.append((point.x,point.y))
                        record={'query':len(attempts),'copy_index':p['copy_index'],'placement_index':i,'angle_radians':angle,'destination':sheet,
                            'regions':len(polys),'free_area_mm2':free.area,'positions':len(positions),'seconds':time.perf_counter()-start,'accepted':False}
                        for x,y in sorted(set(positions),key=lambda p:(p[1],p[0])):
                            transform={**moving['transform'],'translation':[x-mx,y-my]};g=gap.pose(original['cog'],transform)
                            neighbours=[state['geoms'][j] for j,q in enumerate(layout['placements']) if j!=i and q['sheet_id']==sheet]
                            a,b,c,d=g.bounds
                            if not (a>=m['left']+edge-TOL and b>=m['bottom']+edge-TOL and c<=stock['width']-m['right']-edge+TOL and d<=h-m['top']-edge+TOL):continue
                            if any(not g.disjoint(q) or g.distance(q)<job['clearance']-TOL for q in neighbours):continue
                            candidate=copy.deepcopy(layout);candidate['placements'][i]={**p,'sheet_id':sheet,'transform':transform};after=inspect(candidate)
                            assert after['violations']<state['violations']
                            write(folder/'accepted-layout.json',candidate);record['accepted']=True
                            moves.append({'copy':p['copy_index'],'from':p,'to':candidate['placements'][i],'before_violations':state['violations'],
                                'after_violations':after['violations'],'before_overlap_mm2':state['overlap_mm2'],'after_overlap_mm2':after['overlap_mm2'],'query':len(attempts)})
                            layout=candidate;accepted=True;break
                        attempts.append(record);write(folder/'query.json',record)
                        if accepted:print(json.dumps({'moved_cog':p['copy_index'],'remaining_violations':moves[-1]['after_violations'],'seconds':time.perf_counter()-start}),flush=True)
                        if accepted:break
                    if expired or accepted:break
                if expired or accepted:break
            if expired or not accepted:break
        final=inspect(layout);write(OUT/'final-layout.json',layout);write(OUT/'moves.json',moves);write(OUT/'attempts.json',attempts)
        write(OUT/'checks.json',{'complete':True,'expired':expired or time.perf_counter()-start>=SECONDS,'seconds':time.perf_counter()-start,
            'queries':len(attempts),'accepted_moves':len(moves),'initial_violations':initial['violations'],'final_violations':final['violations'],
            'initial_overlap_mm2':initial['overlap_mm2'],'final_overlap_mm2':final['overlap_mm2'],'final_outside_count':len(final['outside']),
            'final_independent_pairs':final['pairs'],'all_original_quantities_unchanged':Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in job['parts']}),
            'complete_target_layout':final['violations']==0,'native_calls':0})
        print((OUT/'checks.json').read_text(encoding='utf-8'),flush=True)
    except Exception as e:
        write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed_queries':attempts,'accepted_moves':moves});raise
if __name__=='__main__':main()
