"""Independently inspect the retained failed best state; never promote it to an accepted solver output."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,itertools,json,math,shutil,struct,subprocess,sys,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-terminal-repair-observer-20261018';AUDIT=OUT/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def f32_sum(values):
    value=0.
    for x in values:value=struct.unpack('<f',struct.pack('<f',value+x))[0]
    return value
def polygon(part,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);out=[]
    for x,y in part['geometry'][0]['outer']:
        if t['mirrored']:x=-x
        out.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
    return Polygon(out)
def main():
    AUDIT.mkdir();shutil.copyfile(__file__,AUDIT/'audit.py');records=[]
    try:
        plan=load(OUT/'plan.json');assert load(OUT/'run/checks.json')['original_failure_reproduced_exactly']
        assert source_digest()==plan['production_digest'];fixture=load(OUT/'fixture.json');job=fixture['job'];parts={p['id']:p for p in job['parts']}
        source=Path(plan['parent_source']);work=OUT/'candidate'
        for row in plan['source_files']:
            assert digest(source/row['path'])==row['sha256']
            if row['path'] not in plan['changed_files']:assert digest(work/row['path'])==row['sha256']
        for rel,h in plan['changed_files'].items():
            assert digest(work/rel)==h;before=(source/rel).read_text(encoding='utf-8');current=(work/rel).read_text(encoding='utf-8')
            if rel.endswith('exchange.rs'):
                body=current.split('// BEGIN fixed-input terminal observation;',1)[0].removesuffix('\n')
                assert body.replace(plan['first_hook'],'',1).replace(plan['second_hook'],'',1)==before
            else:assert current.startswith(before)
        initial=load(OUT/'run/initial.json');best=load(OUT/'run/best.json');stable={};roundtrips=[]
        for p in initial['items']:
            if p['blocker']:continue
            shape=polygon(parts[p['part_id']],p['public_transform']);matches=[]
            for i,original in enumerate(fixture['proposal']['placements']):
                if original['part_id']==p['part_id'] and original['sheet_id']==f"sheet-{p['raw_sheet_index']}":
                    error=shape.hausdorff_distance(polygon(parts[p['part_id']],original['transform']))
                    if error<.011444091796875:matches.append((i,original,error))
            assert len(matches)==1
            i,original,error=matches[0];stable[p['stable_index']]={'part_id':p['part_id'],'copy_index':original['copy_index'],'proposal_index':i}
            roundtrips.append({'stable_index':p['stable_index'],'error_mm':error})
        assert len(stable)==len(fixture['proposal']['placements'])==66 and len({x['proposal_index'] for x in stable.values()})==66
        write(AUDIT/'stable-copies.json',{'mapping':stable,'initial_roundtrip':roundtrips})
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
        assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
        publicsrc=ROOT/'output/h5-pattern-joint-probe-20261018/inputs'/plan['case']
        for phase,state in [('initial',initial),('best',best)]:
            folder=AUDIT/phase;folder.mkdir();layout=copy.deepcopy(fixture['proposal']);layout['placements']=[];placements=[]
            loss=state['loss_details'];assert f32_sum([p['loss'] for p in loss['pairs']]+[p['static_loss'] for p in loss['items']])==loss['total_loss']
            for p in state['items']:
                if p['blocker']:continue
                identity=stable[p['stable_index']];assert identity['part_id']==p['part_id']
                public={'part_id':p['part_id'],'copy_index':identity['copy_index'],'sheet_id':f"sheet-{p['raw_sheet_index']}",'transform':p['public_transform']}
                layout['placements'].append(public);placements.append((p,public,polygon(parts[p['part_id']],p['public_transform'])))
            assert Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in job['parts']})
            assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==66
            write(folder/'layout.json',layout)
            command=[str(cli),'validate','--library',str(publicsrc/'library.json'),'--request',str(publicsrc/'request.json'),'--layout',str(folder/'layout.json')]
            cp=subprocess.run(command,capture_output=True,timeout=60);(folder/'public.json').write_bytes(cp.stdout);(folder/'public.stderr').write_bytes(cp.stderr)
            write(folder/'public-command.json',{'command':command,'exit_code':cp.returncode});public=json.loads(cp.stdout)
            physical_pairs=[];pair_count=0;conflicts=[]
            for (a,pa,ga),(b,pb,gb) in itertools.combinations(placements,2):
                if pa['sheet_id']!=pb['sheet_id']:continue
                pair_count+=1;distance=ga.distance(gb);area=ga.intersection(gb).area
                row={'a':a['stable_index'],'b':b['stable_index'],'parts':[pa['part_id'],pb['part_id']],
                    'copies':[pa['copy_index'],pb['copy_index']],'sheet':pa['sheet_id'],'distance_mm':distance,'filled_overlap_mm2':area}
                physical_pairs.append(row)
                if area>1e-7 or distance<job['clearance']-1e-7:conflicts.append(row)
            stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];bounds=[];tops=[0.,0.];groups=Counter()
            for p,public_p,g in placements:
                a,b,c,d=g.bounds;i=p['raw_sheet_index'];groups[str(i)]+=1
                assert g.is_valid
                if i in [0,1]:tops[i]=max(tops[i],d)
                actual_height=stock['height'];target_height=stock['height'] if i==0 else fixture['target_used_height_mm']
                actual_bad=(i not in [0,1] or a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>actual_height-m['top']-edge+1e-7)
                target_bad=actual_bad or d>target_height-m['top']-edge+1e-7
                if actual_bad or target_bad:bounds.append({'stable_index':p['stable_index'],'part':p['part_id'],'copy':public_p['copy_index'],'sheet':i,
                    'physical_bounds':list(g.bounds),'outside_original_stock':actual_bad,'outside_target_crop':target_bad,'target_top_mm':target_height-m['top']-edge})
            native_polys=[Polygon(p['joint_vertices']) for p in state['items']];reported={(p['a'],p['b']):p['loss'] for p in loss['pairs']};native_pairs=[]
            for a,b in itertools.combinations(range(len(native_polys)),2):
                area=native_polys[a].intersection(native_polys[b]).area;distance=native_polys[a].distance(native_polys[b]);score=reported.get((a,b),0.)
                if area>1e-7 or score>0:native_pairs.append({'a':state['items'][a]['stable_index'],'b':state['items'][b]['stable_index'],
                    'parts':[state['items'][a]['part_id'],state['items'][b]['part_id']],'includes_blocker':state['items'][a]['blocker'] or state['items'][b]['blocker'],
                    'loss':score,'native_overlap_mm2':area,'native_distance_mm':distance,'reported_but_disjoint':score>0 and distance>1e-7,'overlap_not_reported':area>1e-7 and score==0})
            container=Polygon(state['container_vertices']);zones=[Polygon(p['vertices']) for p in state['zones']];statics=[]
            for i,(p,g) in enumerate(zip(state['items'],native_polys)):
                outside=g.difference(container).area;zone=sum(g.intersection(z).area for z in zones);score=loss['items'][i]['static_loss']
                if outside>1e-7 or zone>1e-7 or score>0:statics.append({'stable_index':p['stable_index'],'part':p['part_id'],'blocker':p['blocker'],'outside_container_mm2':outside,'wall_overlap_mm2':zone,'static_loss':score})
            with gzip.open(folder/'all-physical-pairs.jsonl.gz','xt',encoding='utf-8',newline='\n') as f:
                for row in physical_pairs:f.write(json.dumps(row,separators=(',',':'))+'\n')
            material=stock['width']*(stock['height']+tops[1]+m['top']+edge)
            physical_valid=not conflicts and not any(p['outside_original_stock'] for p in bounds)
            target_valid=physical_valid and not bounds and material<=fixture['target_material_mm2']+1e-7
            record={'phase':phase,'public_valid':public['valid'],'public_exit':cp.returncode,'public_violation_count':public['violation_count'],
                'public_codes':dict(Counter(v['code'] for v in public['violations'])),'physical_filled_outer_valid':physical_valid,
                'original_target_satisfied':target_valid,'material_from_actual_extent_mm2':material,'target_material_mm2':fixture['target_material_mm2'],
                'source_used_height_mm':tops[1]+m['top']+edge,'target_used_height_mm':fixture['target_used_height_mm'],
                'physical_pairs_checked':pair_count,'filled_overlap_mm2':sum(p['filled_overlap_mm2'] for p in physical_pairs),
                'physical_conflicts':conflicts,'bounds_violations':bounds,'parts_per_sheet':dict(groups),
                'native_total_loss':loss['total_loss'],'native_positive_pairs':native_pairs,'native_statics':statics,
                'accepted_by_solver':False,'stable_inventory_complete':True}
            write(folder/'checks.json',record);records.append(record)
            print(json.dumps({k:record[k] for k in ['phase','public_valid','physical_filled_outer_valid','original_target_satisfied','filled_overlap_mm2','native_total_loss','parts_per_sheet']}),flush=True)
        first={p['stable_index']:p for p in initial['items'] if not p['blocker']};moves=[]
        for p in best['items']:
            if p['blocker']:continue
            a=first[p['stable_index']];t=a['public_transform'];u=p['public_transform'];delta=[u['translation'][j]-t['translation'][j] for j in range(2)]
            turn=math.remainder(u['rotation_radians']-t['rotation_radians'],math.tau)
            if a['raw_sheet_index']!=p['raw_sheet_index'] or math.hypot(*delta)>1e-7 or abs(turn)>1e-7 or t['mirrored']!=u['mirrored']:
                moves.append({'stable_index':p['stable_index'],**stable[p['stable_index']], 'from_sheet':a['raw_sheet_index'],'to_sheet':p['raw_sheet_index'],
                    'translation_delta_mm':delta,'rotation_change_radians':turn,'reflection_changed':t['mirrored']!=u['mirrored']})
        write(AUDIT/'moves.json',moves)
        write(AUDIT/'checks.json',{'complete':True,'states':[{k:r[k] for k in ['phase','public_valid','physical_filled_outer_valid','original_target_satisfied','filled_overlap_mm2','native_total_loss','physical_pairs_checked','parts_per_sheet']} for r in records],
            'moved_copies':len(moves),'changed_sheets':sum(m['from_sheet']!=m['to_sheet'] for m in moves),'original_counts_and_identity_preserved':True,
            'production_digest':source_digest(),'all_runtime_and_prior_tests_unchanged':True,'native_work_and_failure_reproduced_exactly':True,
            'accepted_layouts':0,'H5_complete':False})
    except Exception as e:
        write(AUDIT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'completed_states':[r['phase'] for r in records]});raise
if __name__=='__main__':main()
