"""Observe the unchanged helper's initial and best terminal snapshots in one fixed adjusted-input replay."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-native-collision-observer-20261018/candidate'
OUT=ROOT/'output/h5-terminal-repair-observer-20261018';WORK=OUT/'candidate';TARGET=ROOT/'output/h5-terminal-repair-target-20261018'
EX='crates/core/src/sheets/vstrip/exchange.rs';SEP='crates/core/src/separate.rs'
CASE='m-mechanical-large-plates-k0.2-s0-candidate';PRIOR=ROOT/'output/h5-spaced-joint-repair-20261018'/CASE
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not OUT.exists() and not TARGET.exists();OUT.mkdir();shutil.copytree(OLD,WORK)
original=(OLD/EX).read_text(encoding='utf-8');old_sep=(OLD/SEP).read_text(encoding='utf-8')
needle='        let (snapshot, tracker) = repair.separate(&self.deadline(self.last_step(until)));'
assert original.count(needle)==1
before='''        #[cfg(test)]
        record_joint_terminal_snapshot(strip, shape, &repair.layout, &repair.tracker, "initial", until);
'''
after='''
        #[cfg(test)]
        record_joint_terminal_snapshot(strip, shape, &JLayout::from_snapshot(&snapshot), &tracker, "best", until);'''
function=r'''
// BEGIN fixed-input terminal observation; compiled only for diagnostics.
#[cfg(test)]
fn record_joint_terminal_snapshot(
    strip:&Strip, shape:Shape, layout:&JLayout, tracker:&crate::separate::Tracker,
    phase:&str, until:f64,
) {
    let Some(directory)=std::env::var_os("NESTBOLT_JOINT_TERMINAL_DIRECTORY") else {return;};
    let at=strip.clock.now();let counts=strip.clock.counts();
    let details=crate::separate::saved_terminal_loss_details(tracker,layout);
    let mut items=vec![];
    for (index,p) in layout.placed_items().values().enumerate() {
        let raw_sheet=strip.sheet_of(p.shape());let dt=p.d_transf();let blocker=strip.is_blocker(p);
        let public_transform=if blocker {None} else {Some(strip.model.external(p.item().idx(),&shift(dt,-strip.start(raw_sheet))))};
        let part_id=if blocker {None} else {Some(strip.model.job.parts[strip.model.part[p.item().idx()]].id.clone())};
        items.push(serde_json::json!({"index":index,"stable_index":details["items"][index]["stable_index"],
            "item_index":p.item().idx(),"part_id":part_id,"blocker":blocker,"raw_sheet_index":raw_sheet,
            "native_transform":{"rotation":f64::from(dt.rotation()),"reflected":dt.reflected,
                "translation":[f64::from(dt.translation().0),f64::from(dt.translation().1)]},
            "public_transform":public_transform,
            "joint_vertices":p.shape().vertices().iter().map(|v|[f64::from(v.0),f64::from(v.1)]).collect::<Vec<_>>(),
            "local_physical_vertices":p.shape().vertices().iter().map(|v|
                strip.model.inverse.apply([f64::from(v.0)-f64::from(strip.start(raw_sheet)),f64::from(v.1)])).collect::<Vec<_>>() }));
    }
    let zones:Vec<_>=layout.container().quality_zones().iter().enumerate().flat_map(|(quality,zone)|{
        zone.iter().flat_map(move |z|z.shapes_cd().iter().map(move |s|serde_json::json!({"quality":quality,
            "vertices":s.vertices().iter().map(|v|[f64::from(v.0),f64::from(v.1)]).collect::<Vec<_>>()})))
    }).collect();
    let record=serde_json::json!({"phase":phase,"at":at,"until":until,"work":counts,
        "hard_limit_hit":strip.clock.hit_hard_limit(),"sheet_count":shape.sheets,"last_internal":f64::from(shape.last),
        "full_internal":f64::from(strip.model.full_width),"pitch":f64::from(strip.pitch()),
        "strip_height":f64::from(strip.height()),"loss_details":details,"items":items,"zones":zones,
        "container_vertices":layout.container().outer_cd().vertices().iter().map(|v|[f64::from(v.0),f64::from(v.1)]).collect::<Vec<_>>(),
        "model_inverse":{"m":strip.model.inverse.m,"t":strip.model.inverse.t},"native_observation_only":true});
    use std::io::Write;
    let path=std::path::Path::new(&directory).join(format!("{phase}.json"));
    let mut file=std::fs::OpenOptions::new().write(true).create_new(true).open(path).unwrap();
    file.write_all(&serde_json::to_vec_pretty(&record).unwrap()).unwrap();file.write_all(b"\n").unwrap();
    assert_eq!(serde_json::to_value(counts).unwrap(),serde_json::to_value(strip.clock.counts()).unwrap());
}
// END fixed-input terminal observation.
'''
separate=r'''
// BEGIN stable item identity for the fixed-input terminal diagnostic.
#[cfg(test)]
pub(crate) fn saved_terminal_loss_details(tracker:&Tracker,layout:&Layout)->serde_json::Value {
    let mut result=saved_geometry_loss_details(tracker,layout);
    for (i,key) in layout.placed_items().keys().enumerate() {
        result["items"][i]["stable_index"]=serde_json::json!(tracker.index[key]);
    }
    result
}
// END stable item identity diagnostic.
'''
(WORK/EX).write_text(original.replace(needle,before+needle+after)+function,encoding='utf-8',newline='\n')
(WORK/SEP).write_text(old_sep+separate,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=WORK,check=True)
current=(WORK/EX).read_text(encoding='utf-8')
# Formatting can wrap the two observer calls. Remove their exact formatted blocks
# and require the entire old source, including every prior test, byte-for-byte.
start=current.index('        #[cfg(test)]\n        record_joint_terminal_snapshot(')
end=current.index(needle,start)
first_hook=current[start:end]
second_start=current.index('        #[cfg(test)]\n        record_joint_terminal_snapshot(',end)
second_end=current.index('        if self.clock.now() >= self.last_step(until) {',second_start)
second_hook=current[second_start:second_end]
body=current.split('// BEGIN fixed-input terminal observation;',1)[0].removesuffix('\n')
assert body.replace(first_hook,'',1).replace(second_hook,'',1)==original
assert (WORK/SEP).read_text(encoding='utf-8').startswith(old_sep)
files=[{'path':p.relative_to(OLD).as_posix(),'sha256':digest(p)} for p in sorted(OLD.rglob('*')) if p.is_file()]
for row in files:
    if row['path'] not in [EX,SEP]:assert digest(WORK/row['path'])==row['sha256']
for rel in [EX,SEP]:
    (OUT/(Path(rel).stem+'.patch')).write_text(''.join(difflib.unified_diff((OLD/rel).read_text(encoding='utf-8').splitlines(True),(WORK/rel).read_text(encoding='utf-8').splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)),encoding='utf-8',newline='\n')
shutil.copyfile(PRIOR/'fixture.json',OUT/'fixture.json')
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'case':CASE,'parent_source':str(OLD),
    'source_files':files,'changed_files':{r:digest(WORK/r) for r in [EX,SEP]},'first_hook':first_hook,'second_hook':second_hook,
    'prior_result':str(PRIOR/'result.json'),'prior_result_sha256':digest(PRIOR/'result.json'),
    'fixture_sha256':digest(OUT/'fixture.json'),'production_digest':source_digest(),'target':str(TARGET),
    'seed':0,'work_allowance':12.,'native_cpu':[8],'hard_seconds':60,'instrumented_replays':1,
    'test':'sheets::vstrip::exchange::tests::saved_partial_joint_repair_diagnostic','prior_tests_unchanged':173,
    'runtime_source_unchanged':True,'all_existing_helper_decisions_exact':True,'no_extra_charged_work':True,
    'scope':'One observational replay of the closest fixed changed input. Capture the saved best state before the same expiry return; compare final counts, stats and work exactly with the prior failure. Never accept an expired output; no quality claim.'})
shutil.copyfile(__file__,OUT/'prepare.py');print(json.dumps({'prepared':True,'old_tests_exact':173,'new_tests':0,'replays':1}))
