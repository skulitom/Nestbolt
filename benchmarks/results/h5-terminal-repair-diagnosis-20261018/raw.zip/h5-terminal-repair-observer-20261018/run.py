"""Replay one fixed failed input once to preserve its terminal best state and verify unchanged decisions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,psutil,shutil,subprocess,time,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-terminal-repair-observer-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(OUT/'plan.json');binary=OUT/'terminal-tests.exe';build=load(OUT/'build.json')
assert build['exit_code']==0 and digest(binary)==build['binary_sha256']
assert digest(OUT/'fixture.json')==plan['fixture_sha256'] and digest(Path(plan['prior_result']))==plan['prior_result_sha256']
for rel,h in plan['changed_files'].items():assert digest(OUT/'candidate'/rel)==h
dest=OUT/'run';dest.mkdir();shutil.copyfile(__file__,OUT/'run.py')
psutil.Process().cpu_affinity([8]);assert psutil.Process().cpu_affinity()==[8]
env=os.environ.copy();assert not env.get('NESTBOLT_SIMPLIFY')
env['NESTBOLT_JOINT_FIXTURE']=str(OUT/'fixture.json');env['NESTBOLT_JOINT_OUTPUT']=str(dest/'result.json');env['NESTBOLT_JOINT_TERMINAL_DIRECTORY']=str(dest)
command=[str(binary),'--exact',plan['test'],'--ignored','--nocapture','--test-threads=1']
write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'command':command,'cpu':[8],'fixture_sha256':digest(OUT/'fixture.json'),'binary_sha256':digest(binary)})
try:
    t=time.perf_counter()
    with (dest/'test.log').open('xb') as log:cp=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100)
    wall=time.perf_counter()-t;write(dest/'exit.json',{'exit_code':cp.returncode,'wall_seconds':wall})
    assert cp.returncode==0
    result=load(dest/'result.json');old=load(Path(plan['prior_result']));initial=load(dest/'initial.json');best=load(dest/'best.json')
    for key in ['success','stats','work','started','until','finished','native_loss_observations']:
        assert result[key]==old[key],key
    assert not result['success'] and result['after'] is None and result['stats']['joint_repair_expired']==1
    assert initial['work']['evaluations']==0 and best['work']==result['work'] and not best['hard_limit_hit']
    first={i['stable_index']:i['item_index'] for i in initial['items']};last={i['stable_index']:i['item_index'] for i in best['items']}
    assert first==last and len(first)==len(initial['items'])==len(best['items'])
    record={'completed':True,'original_failure_reproduced_exactly':True,'same_work_counts_stats_and_expiry':True,
        'initial_loss':initial['loss_details']['total_loss'],'best_loss':best['loss_details']['total_loss'],
        'best_at':best['at'],'until':best['until'],'wall_seconds':wall,'stable_identity_and_inventory_preserved':True,
        'instrumented_replays':1,'quality_runs':0,'accepted_layouts':0}
    write(dest/'checks.json',record);print(json.dumps(record),flush=True)
except Exception as e:
    write(dest/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
