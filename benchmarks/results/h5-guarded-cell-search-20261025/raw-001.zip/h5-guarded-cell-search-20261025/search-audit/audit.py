"""Read back the closed original-core search without rerunning any solver."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, time, shutil
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-guarded-cell-search-20261025'
RUN = BASE / 'shared-search'
OUT = BASE / 'search-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

def main():
    OUT.mkdir(); shutil.copyfile(__file__, OUT/'audit.py'); start = time.perf_counter()
    result = load(RUN/'result.json'); budget = load(RUN/'budget.json')
    model = load(RUN/'solve/model-audit.json'); solved = load(RUN/'solve/result.json')
    opened = load(RUN/'solve/opened.json')
    write(OUT/'plan.json', {'utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in RUN.rglob('*') if p.is_file()},
        'method': 'The recorded remaining time already subtracts the two-second shutdown reserve; compare the actual cap directly to that recorded value. Read back the terminal one-call UNKNOWN, every recorded input hash, model and actual parameters. Check the declared master45-second cap, two-second shutdown reserve and shared60-second pipeline separately. Preserve measured soft-limit overshoot. UNKNOWN with no incumbent supports neither feasibility nor impossibility. No solver calls or continuation.'})
    for plan in [load(RUN/'plan.json'), load(RUN/'solve/plan.json')]:
        for name, expected in plan['inputs'].items(): assert digest(ROOT/name) == expected
    assert model['hints'] == 16 and model['new_exact_second_sheet_pair_clauses'] == 150
    assert model['passed'] and digest(RUN/'solve/model.pb') == model['model_sha256']
    assert digest(RUN/'solve/parameters.pbtxt') == model['parameters_sha256']
    params = text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(), sat_parameters_pb2.SatParameters())
    assert budget['shared_seconds'] == 60 and budget['master_solver_cap_seconds'] == 45
    assert budget['solver_shutdown_reserve_seconds'] == 2
    assert budget['deadline_perf_counter'] == budget['start_perf_counter'] + 60
    assert params.max_time_in_seconds == opened['seconds_limit'] == min(45, model['remaining_shared_budget_at_parameter_set'])
    assert params.num_search_workers == 8 and params.random_seed == 0
    assert params.cp_model_presolve and params.cp_model_probing_level == 0 and params.symmetry_level == 0
    assert result['master_solver_calls'] == 1 and result['anchor_solver_calls'] == 0
    assert result['status'] == 'MASTER_UNKNOWN' and solved['status'] == 'UNKNOWN'
    assert not solved['has_necessary_domain_candidate'] and solved['solver_calls'] == 1
    assert len(result['stages']) == 1 and result['stages'][0]['stage'] == 'master'
    assert result['stages'][0]['exit_code'] == 0
    assert result['elapsed_seconds'] >= result['stages'][0]['seconds']
    assert model['construction_seconds'] + model['audit_seconds'] + solved['seconds'] <= result['stages'][0]['seconds']
    assert not (RUN/'solve/selection.json').exists() and not (RUN/'solve/necessary-cog-positions.json').exists()
    assert not (RUN/'anchor-solve').exists()
    checks = {'passed': True, 'seconds': time.perf_counter()-start, 'terminal_status': 'UNKNOWN', 'incumbent': False,
        'master_solver_calls': 1, 'anchor_solver_calls': 0,
        'declared_shared_seconds': 60, 'actual_shared_seconds': result['elapsed_seconds'],
        'shared_budget_honored': result['elapsed_seconds'] <= 60,
        'shared_overrun_seconds': max(0, result['elapsed_seconds']-60),
        'declared_solver_seconds': params.max_time_in_seconds, 'actual_solver_seconds': solved['seconds'],
        'solver_soft_limit_overshoot_seconds': max(0, solved['seconds']-params.max_time_in_seconds),
        'source_model_and_parameters_verified': True, 'completed_call_closed_no_retry': True,
        'no_feasibility_or_impossibility_claim': True, 'full_target_witness': False,
        'native_full_job_qualified': False, 'H5_complete': False}
    write(OUT/'checks.json', checks); print(checks, flush=True)

if __name__ == '__main__': main()
