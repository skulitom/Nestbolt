"""One shared60-second master/audit/coordinate pipeline; completed calls stay closed."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-cell-search-20261025';EVIDENCE=ROOT/'output/h5-original-core-search-20261025';REGIONAL=ROOT/'output/h5-cog-region-capacities-20261025';OUT=BASE/'shared-search'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();deadline=start+60
    assert load(EVIDENCE/'audit/checks.json')['passed'] and load(ROOT/'output/h5-cog-displacement-cells-20261025'/'audit/checks.json')['passed']
    write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'start_perf_counter':start,'deadline_perf_counter':deadline,
        'master_solver_cap_seconds':45,'solver_shutdown_reserve_seconds':2,'maximum_master_solver_calls':1,'maximum_anchor_solver_calls':1,'random_seed':0,'workers':8,'previous_calls_remain_closed':True})
    solver=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe';geometry=ROOT/'.cache/shop-venv/Scripts/python.exe'
    stages=[('master',solver,'solve_h5_guarded_cell_master.py'),('selection',geometry,'audit_h5_guarded_cell_selection.py'),('anchors',solver,'solve_h5_guarded_cell_anchors.py')]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'budget':'budget.json','inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [REGIONAL/'capacities.json',REGIONAL/'audit/checks.json',EVIDENCE/'atlas.json',EVIDENCE/'audit/checks.json',EVIDENCE/'added-pairs.json',ROOT/'output/h5-cog-displacement-cells-20261025'/'audit/checks.json',ROOT/'output/h5-cog-displacement-cells-20261025'/'coarse-refinement/selected-query-18.json',ROOT/'output/h5-cog-displacement-cells-20261025'/'coarse-refinement/selected-query-19.json']+[ROOT/'output'/n for _,_,n in stages]},
        'method':'New master replaces necessary core separation with full guarded displacement cells and includes all ten exact second-sheet pair exclusions and advisory hints from a verified original two-cog witness, with no fixed placements or omitted originals. One shared60-second pipeline. Build and independently audit the strengthened master with simultaneous full-domain cog anchors and all independently proved guarded displacement cells with exact sheet activation and chosen-cell constraints and all new guarded domain-pair exclusions, make at most one master call capped at45 seconds with2 seconds shutdown reserve, then independently check any selected domains and all capacities. Only an assignment passing those checks may build and independently audit a full original-coordinate model and make at most one coordinate call. Stop on negative/unknown/cap/invalid selection. Never retry, extend or resume a completed call. Every stage output and terminal result remains recorded.'})
    records=[];status='NOT_STARTED'
    for name,exe,script in stages:
        remaining=deadline-time.perf_counter()
        if remaining<=0:status='SHARED_BUDGET_EXHAUSTED';break
        began=time.perf_counter()
        try:
            run=subprocess.run([str(exe),str(ROOT/'output'/script)],cwd=ROOT,capture_output=True,timeout=max(0.01,remaining))
            (OUT/(name+'-stdout.txt')).write_bytes(run.stdout);(OUT/(name+'-stderr.txt')).write_bytes(run.stderr)
            records.append({'stage':name,'seconds':time.perf_counter()-began,'exit_code':run.returncode});write(OUT/(name+'-process.json'),records[-1]);print(run.stdout.decode(errors='replace'),flush=True)
            if run.returncode:status='STAGE_FAILED';break
        except subprocess.TimeoutExpired as e:
            (OUT/(name+'-stdout.txt')).write_bytes(e.stdout or b'');(OUT/(name+'-stderr.txt')).write_bytes(e.stderr or b'');status='SHARED_BUDGET_PROCESS_TIMEOUT';break
        if name=='master':
            r=load(OUT/'solve/result.json')
            if not r['has_necessary_domain_candidate']:status='MASTER_'+r['status'];break
        if name=='selection' and load(OUT/'selection-audit/checks.json')['selected_combination_geometrically_excluded']:status='SELECTED_DOMAIN_CONFLICT';break
        if name=='anchors':status='ANCHORS_'+load(OUT/'anchor-solve/result.json')['status']
    result={'status':status,'elapsed_seconds':time.perf_counter()-start,'shared_budget_seconds':60,'stages':records,
        'master_solver_calls':int((OUT/'solve/opened.json').exists()),'anchor_solver_calls':int((OUT/'anchor-solve/opened.json').exists()),
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
