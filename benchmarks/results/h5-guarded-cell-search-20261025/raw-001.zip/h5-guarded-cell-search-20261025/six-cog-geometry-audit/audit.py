"""Reconstruct all63 currently placed originals; retain explicit missing originals."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json,math,shutil,time,copy
from shapely.geometry import Polygon,shape,mapping
from shapely.affinity import affine_transform,translate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-cell-search-20261025';RUN=BASE/'first-sheet-four-cog-diagnostic';OUT=BASE/'six-cog-geometry-audit';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025';FIXED=ROOT/'output/h5-guarded-source-adjustment-20261025/audit/adjusted-fixed-originals.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();sourcepath=ROOT/load(SRC/'plan.json')['hint_source']
    paths=[RUN/'audit/checks.json',RUN/'audit/six-cog-positions.json',SOURCE/'plan.json',SOURCE/'profiles.json',FIXED,JOB,SRC/'geometry.json',SRC/'items.json',sourcepath]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'Reconstruct the six proved cog placements and all57 unchanged fixed originals from the actual job polygons, transforms and copy identities. Check every same-sheet pair and all stock edges against the original native guards. Preserve all63 placed identities and explicitly record the three absent originals28,29,50. This is a valid partial construction for further work, not a full66 target or native acceptance. Do not call the native validator on it.'})
    assert load(paths[0])['passed'];six=load(paths[1]);spec=load(paths[2]);profiles=load(paths[3]);fixed=load(FIXED);job=load(JOB);items=load(SRC/'items.json');families={p['id']:p for p in job['parts']};fixedby={p['item']:p for p in fixed};moving={p['item']:p for p in six}
    assert len(fixedby)==57 and len(moving)==6 and set(fixedby).isdisjoint(moving);placed=sorted(set(fixedby)|set(moving));missing=sorted(set(range(66))-set(placed));assert missing==[28,29,50]
    stocks=[[float(F(*v)) for v in s] for s in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05)
    layout=copy.deepcopy(load(sourcepath));layout['placements']=[];records=[];polys={};maxerror=0
    for i in placed:
        item=items[i];family=item['family']
        if i in fixedby:
            f=fixedby[i];t=copy.deepcopy(f['transform']);sheet=f['sheet'];expected=shape(f['geometry'])
        else:
            p=moving[i];profile=profiles[p['profile']];assert family=='cog' and not profile['mirrored'];angle=profile['rotation_radians'];c,s=math.cos(angle),math.sin(angle);cx,cy=profile['original_center'];x,y=p['x_units']/1000,p['y_units']/1000
            t={'rotation_radians':angle,'translation':[x-c*cx+s*cy,y-s*cx-c*cy],'mirrored':False};sheet=p['sheet'];expected=translate(shape(profile['geometry']),x,y)
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;poly=affine_transform(Polygon(families[family]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,*t['translation']]);assert poly.is_valid
        error=poly.hausdorff_distance(expected);assert error<1e-7;maxerror=max(maxerror,error);polys[i]=poly
        records.append({'item':i,'family':family,'copy':item['copy'],'sheet':sheet,'transform':t,'geometry':mapping(poly),'from_original_fixed57':i in fixedby})
        layout['placements'].append({'part_id':family,'copy_index':item['copy'],'sheet_id':f'sheet-{sheet}','transform':t})
    pairs=[];stock=[]
    for a,b in combinations(records,2):
        if a['sheet']!=b['sheet']:continue
        pa,pb=polys[a['item']],polys[b['item']];distance=pa.distance(pb);area=pa.intersection(pb).area;assert area==0 and distance>=gap
        pairs.append({'items':[a['item'],b['item']],'sheet':a['sheet'],'gap_mm':distance,'intersection_area_mm2':area})
    for p in records:
        b=polys[p['item']].bounds;s=stocks[p['sheet']];margins=[b[0]-s[0],b[1]-s[1],s[2]-b[2],s[3]-b[3]];assert min(margins)>=guard;stock.append({'item':p['item'],'extra_stock_margins_mm':margins})
    assert Counter(p['family'] for p in records)+Counter(items[i]['family'] for i in missing)==Counter(spec['required_original_counts'])
    assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==63
    write(OUT/'placed63-originals.json',records);write(OUT/'partial63-layout.json',layout);write(OUT/'all-pair-checks.json',pairs);write(OUT/'stock-checks.json',stock);write(OUT/'missing-originals.json',[items[i] for i in missing])
    checks={'passed':True,'seconds':time.perf_counter()-start,'placed_originals':63,'missing_original_items':missing,'required_originals':66,'same_sheet_original_pairs_checked':len(pairs),'stock_edges_checked':4*len(stock),
        'native_required_gap_mm':gap,'minimum_original_gap_mm':min(p['gap_mm'] for p in pairs),'native_stock_guard_mm':guard,'minimum_extra_stock_margin_mm':min(v for p in stock for v in p['extra_stock_margins_mm']),
        'maximum_original_reconstruction_error_mm':maxerror,'all63_original_identities_shapes_and_permitted_transforms_preserved':True,'three_other_originals_still_required':True,'native_calls':0,
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
