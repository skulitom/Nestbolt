"""Bounded deterministic original-domain samples for the three remaining originals."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,shutil,time,traceback
import numpy as np
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-cell-search-20261025';OUT=BASE/'remaining-three-candidates';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+60
    spec=load(SOURCE/'plan.json');six=load(BASE/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json');lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']}
    assert load(BASE/'six-cog-geometry-audit/checks.json')['passed'];assert [p['index'] for p in spec['parts'][:3]]==[28,29,50]
    paths=[SOURCE/'plan.json',SOURCE/'audit/checks.json',BASE/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json',BASE/'six-cog-geometry-audit/checks.json']
    paths += [SOURCE/'queries'/f'{q:03d}.json' for q in range(18)]+[SOURCE/'mutual'/f'{lookup[p,9]:03d}.json' for p in range(9)]
    fractions=[F(1,1000),F(1,100),F(1,10),F(1,2),F(1)]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':60,'maximum_generated_grid_points':300000,'solver_calls':0,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'queries':list(range(18)),'interpolation_fractions':[[v.numerator,v.denominator] for v in fractions],
        'method':'Keep the independently checked63 original placements fixed only for a constructive completion attempt. For every allowed source inward domain of both remaining original brackets and the insert, form the exact rational mean of stored convex vertices and interpolate each vertex toward that mean by1/1000,1/100,1/10,1/2,1. Test all floor/ceil micrometre neighbours, plus floor/ceil neighbours of the integer bounding-box midpoint. Retain a grid point only if every complete source inward inequality and box holds. Deduplicate identical query/coordinate points retaining the first valid domain witness. Filter every point against every fixed cog on that sheet using every full guarded original integer outside clause, without changing clearance. Preserve all valid generated grid points, accepted indices, counts, caps and pending queries. This finite sampling can construct a full original witness but a negative cannot exclude unsampled continuous placements. No missing original is waived and no native/quality acceptance occurs here.'})
    summaries=[];pending=[];generated=0
    for qi in range(18):
        if time.perf_counter()>=deadline or generated>=300000:pending=list(range(qi,18));break
        q=spec['queries'][qi];domains=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];points={};tried=0
        for row,d in enumerate(domains):
            if time.perf_counter()>=deadline or generated+tried>=300000:break
            vertices=[tuple(F(v)*1000 for v in p) for p in list(shape(d['inset_face']).exterior.coords)[:-1]];mean=tuple(sum(p[k] for p in vertices)/len(vertices) for k in [0,1]);b=d['coordinate_bounds']
            rational=[tuple(p[k]+f*(mean[k]-p[k]) for k in [0,1]) for p in vertices for f in fractions]+[(F(b[0]+b[2],2),F(b[1]+b[3],2))]
            grid=sorted({(x,y) for a,c in rational for x,y in product([math.floor(a),math.ceil(a)],[math.floor(c),math.ceil(c)])});tried+=len(grid)
            for x,y in grid:
                if b[0]<=x<=b[2] and b[1]<=y<=b[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']):points.setdefault((x,y),row)
        completed_domains=(row+1 if domains else 0)
        if time.perf_counter()>=deadline or generated+tried>=300000:
            write(OUT/'capped-query.json',{'query':qi,'visited_domain_rows':completed_domains,'generated_grid_points':tried});pending=list(range(qi,18));break
        generated+=tried;records=[{'x_units':x,'y_units':y,'domain_row':r,'domain_index':domains[r]['index']} for (x,y),r in sorted(points.items())]
        accepted=np.ones(len(records),dtype=bool);xy=np.array([[p['x_units'],p['y_units']] for p in records],dtype=np.int64).reshape(-1,2);mutual=load(SOURCE/'mutual'/f'{lookup[q["profile"],9]:03d}.json');filter_records=[]
        for cog in six:
            if cog['sheet']!=q['sheet']:continue
            before=int(np.count_nonzero(accepted));dx=cog['x_units']-xy[:,0];dy=cog['y_units']-xy[:,1]
            for face in mutual['faces']:
                separated=np.zeros(len(records),dtype=bool)
                for h in face['outside_halfplanes']:
                    assert abs(h['a'])*1500000+abs(h['b'])*3000000<2**62
                    separated |= h['a']*dx+h['b']*dy>=h['bound']
                accepted &= separated
            filter_records.append({'cog_part':cog['part'],'before':before,'after':int(np.count_nonzero(accepted)),'guarded_clauses':len(mutual['faces'])})
        ids=np.flatnonzero(accepted).tolist();write(OUT/'queries'/f'{qi:03d}.json',{'query':qi,'profile':q['profile'],'sheet':q['sheet'],'generated_grid_points':tried,'unique_source_valid_points':records,'accepted_indices':ids,'fixed_cog_filters':filter_records})
        summary={'query':qi,'profile':q['profile'],'sheet':q['sheet'],'source_domains':len(domains),'generated_grid_points':tried,'unique_source_valid_points':len(records),'fixed_cog_safe_points':len(ids)};summaries.append(summary);print(summary,flush=True)
    write(OUT/'summary.json',summaries);write(OUT/'pending-queries.json',pending)
    result={'seconds':time.perf_counter()-start,'planned_queries':18,'complete_queries':len(summaries),'pending_queries':len(pending),'generated_grid_points':generated,
        'safe_bracket_points':sum(r['fixed_cog_safe_points'] for r in summaries if r['query']<16),'safe_insert_points':sum(r['fixed_cog_safe_points'] for r in summaries if r['query']>=16),
        'independent_audit_pending':True,'finite_sample_only':True,'solver_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
