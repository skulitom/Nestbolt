"""Regenerate finite samples and independently certify every accept/reject decision."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time,traceback
import numpy as np
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-cell-search-20261025';RUN=BASE/'remaining-three-candidates';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=RUN/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(RUN/'plan.json');result=load(RUN/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in RUN.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Regenerate the complete declared rational vertex-to-mean samples and floor/ceil neighbours independently, including first valid domain witnesses and exact source inward conditions. Match every recorded unique source-valid point. For every rejected point produce a fixed-cog/source-face certificate, then verify all failed-clause inequalities with arbitrary-precision Python integers. NumPy only nominates those certificates. Check each accepted point against every complete original guarded clause with Python integers. Thus every generated accepted/rejected point is accounted for, but unsampled points and other cog placements are not excluded. No solver or native call.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    assert result['complete_queries']==18 and result['pending_queries']==0 and result['seconds']<60 and not load(RUN/'pending-queries.json')
    spec=load(SOURCE/'plan.json');six=load(BASE/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json');lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']}
    fractions=[F(*f) for f in plan['interpolation_fractions']];generated=unique=negative=positive=positive_clauses=negative_inequalities=0;summaries=[]
    for qi in range(18):
        assert time.perf_counter()-start<120
        data=load(RUN/'queries'/f'{qi:03d}.json');q=spec['queries'][qi];domains=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];expected={};tried=0
        for row,d in enumerate(domains):
            vertices=[tuple(F(v)*1000 for v in p) for p in list(shape(d['inset_face']).exterior.coords)[:-1]];center=[sum(p[k] for p in vertices)/len(vertices) for k in [0,1]];b=d['coordinate_bounds']
            real=[((1-f)*v[0]+f*center[0],(1-f)*v[1]+f*center[1]) for v in vertices for f in fractions];real.append((F(b[0]+b[2],2),F(b[1]+b[3],2)))
            grid={(x,y) for px,py in real for x in [math.floor(px),math.ceil(px)] for y in [math.floor(py),math.ceil(py)]};tried+=len(grid)
            for x,y in sorted(grid):
                if not (b[0]<=x<=b[2] and b[1]<=y<=b[3]):continue
                if all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']):expected.setdefault((x,y),row)
        wanted=[{'x_units':x,'y_units':y,'domain_row':r,'domain_index':domains[r]['index']} for (x,y),r in sorted(expected.items())]
        assert wanted==data['unique_source_valid_points'] and tried==data['generated_grid_points'];generated+=tried;unique+=len(wanted)
        accepted=data['accepted_indices'];assert accepted==sorted(set(accepted)) and all(0<=i<len(wanted) for i in accepted)
        mutual=load(SOURCE/'mutual'/f'{lookup[q["profile"],9]:03d}.json');cogs=[p for p in six if p['sheet']==q['sheet']];rejected=set(range(len(wanted)))-set(accepted);certs=[]
        xy=np.array([[p['x_units'],p['y_units']] for p in wanted],dtype=np.int64).reshape(-1,2)
        for cog in cogs:
            for face in mutual['faces']:
                if not rejected:break
                ids=np.array(sorted(rejected),dtype=np.int64);dx=cog['x_units']-xy[ids,0];dy=cog['y_units']-xy[ids,1];failed=np.ones(len(ids),dtype=bool)
                for h in face['outside_halfplanes']:failed &= h['a']*dx+h['b']*dy<h['bound']
                for index in ids[failed].tolist():
                    p=wanted[index];x=cog['x_units']-p['x_units'];y=cog['y_units']-p['y_units']
                    for h in face['outside_halfplanes']:assert int(h['a'])*x+int(h['b'])*y<int(h['bound']);negative_inequalities+=1
                    certs.append([index,cog['part'],face['index']]);rejected.remove(index)
        assert not rejected and len(certs)+len(accepted)==len(wanted)
        for index in accepted:
            p=wanted[index]
            for cog in cogs:
                dx=cog['x_units']-p['x_units'];dy=cog['y_units']-p['y_units']
                for face in mutual['faces']:
                    assert any(int(h['a'])*dx+int(h['b'])*dy>=int(h['bound']) for h in face['outside_halfplanes']);positive_clauses+=1
        write(OUT/f'query-{qi:03d}-rejection-certificates.json',{'query':qi,'columns':['point_index','fixed_cog_part','failed_source_face'],'certificates':certs})
        negative+=len(certs);positive+=len(accepted);summaries.append({'query':qi,'generated_grid_points':tried,'unique_source_valid_points':len(wanted),'certified_rejected_points':len(certs),'verified_accepted_points':len(accepted)})
    assert generated==result['generated_grid_points']==162863 and negative+positive==unique and positive==8
    assert sum(r['verified_accepted_points'] for r in summaries[:16])==0 and sum(r['verified_accepted_points'] for r in summaries[16:])==8
    write(OUT/'query-checks.json',summaries)
    checks={'passed':True,'seconds':time.perf_counter()-start,'all18_queries_regenerated':True,'generated_grid_points':generated,'unique_source_valid_points':unique,
        'rejected_points_with_exact_failure_certificates':negative,'arbitrary_precision_failed_inequalities_checked':negative_inequalities,'accepted_points':positive,
        'accepted_full_guarded_clause_checks':positive_clauses,'accepted_bracket_points':0,'accepted_insert_points':8,'fixed_six_cogs_cannot_be_completed_by_this_sample':True,
        'no_continuous_or_other_cog_placement_impossibility_claim':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert checks['seconds']<120;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
