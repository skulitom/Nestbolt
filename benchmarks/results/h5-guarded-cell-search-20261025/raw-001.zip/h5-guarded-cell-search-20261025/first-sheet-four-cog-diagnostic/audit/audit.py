"""Read back the four-cog result and combine it with the proved second-sheet pair."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from audit_h5_four_cog_model import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';CELL=ROOT/'output/h5-cog-displacement-cells-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    witness_path=ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs/audit/verified-pair-witnesses.json'
    inputs=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[witness_path,SOURCE/'mutual/081.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Reconstruct the entire four-cog model from source, verify actual parameters and the single closed call, then verify every selected inward domain, cell, bound, capacity and full guarded original outside clause. Combine the four first-sheet witnesses with the first previously proved two-cog second-sheet witness, assigning interchangeable copies3..8 in existing choice order. Check all seven same-sheet original-cog pairs against all61 source guarded clauses. This remains a six-cog subproblem witness with three other moving originals still mandatory; native/full66 acceptance is not claimed.'})
    plan=load(BASE/'plan.json')
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    model=load(BASE/'model-audit.json');result=load(BASE/'result.json');opened=load(BASE/'opened.json')
    assert model['passed'] and result['status']=='OPTIMAL' and result['four_cog_candidate'] and result['solver_calls']==1 and result['total_seconds']<60
    assert digest(BASE/'model.pb')==model['model_sha256'] and digest(BASE/'parameters.pbtxt')==model['parameters_sha256']
    params=text_format.Parse((BASE/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
    assert params.max_time_in_seconds==opened['seconds_limit']==min(45,model['remaining_after_shutdown_reserve_seconds']) and params.num_search_workers==8 and params.random_seed==0
    assert result['solver_seconds']<params.max_time_in_seconds and model['construction_seconds']+model['audit_seconds']+result['solver_seconds']<=result['total_seconds']
    ds=load(SOURCE/'queries/018.json')['domains'];cells=load(CELL/'coarse-refinement/selected-query-18.json');regional=load(ROOT/'output/h5-cog-region-capacities-20261025/capacities.json');cert=load(ROOT/'output/h5-original-domain-conflicts-20261025/three-cog-certificate/certificate.json')
    box=[min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)]
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((BASE/'model.pb').read_bytes());mapping,stats=verify(actual,ds,cells,box,regional,cert);assert mapping==load(BASE/'mapping.json')
    first=load(BASE/'positions.json');chosen=load(BASE/'chosen-cells.json');assert [p['cog'] for p in first]==list(range(4)) and [r['cogs'] for r in chosen]==[list(p) for p in combinations(range(4),2)]
    assert [p['domain_row'] for p in first]==sorted(p['domain_row'] for p in first)
    planes=cellplanes=0
    for p in first:
        assert p['query']==18 and p['profile']==9 and p['sheet']==0;d=ds[p['domain_row']];assert d['index']==p['domain_index'];x,y=p['x_units'],p['y_units'];assert isinstance(x,int) and isinstance(y,int)
        for b in [d['coordinate_bounds'],box]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];planes+=1
    for r in chosen:
        assert len(r['cell_indices'])==1;d=next(d for d in cells['domains'] if d['index']==r['cell_indices'][0]);a,b=[first[i] for i in r['cogs']];x,y=b['x_units']-a['x_units'],b['y_units']-a['y_units']
        for box in [d['coordinate_bounds'],cells['difference_bounds_units1000']]:assert box[0]<=x<=box[2] and box[1]<=y<=box[3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];cellplanes+=1
    for g in regional['constraints']:
        if g['query']==18:assert sum(p['domain_row'] in g['domain_rows'] for p in first)<=g['capacity']
    assert not all(any(p['domain_row'] in g['domain_rows'] for p in first) for g in cert['groups'])
    spec=load(SOURCE/'plan.json');pair=load(witness_path)[0];six=[]
    for part,p in zip(range(3,9),first+pair['positions']):
        item=spec['parts'][part];assert item['family']=='cog' and item['profiles']==[9] and item['queries']==[18,19]
        q=p['query'];domains=load(SOURCE/'queries'/f'{q:03d}.json')['domains'];d=domains[p['domain_row']];assert d['index']==p['domain_index']
        x,y=p['x_units'],p['y_units'];b=d['coordinate_bounds'];assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
        assert all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes'])
        six.append({'part':part,'item':item['index'],'family':'cog','copy':item['copy'],'query':q,'profile':9,'sheet':q-18,'domain_row':p['domain_row'],'domain_index':p['domain_index'],
            'choice_index':p['domain_row']+(len(ds) if q==19 else 0),'x_units':x,'y_units':y})
    assert [p['choice_index'] for p in six]==sorted(p['choice_index'] for p in six)
    mutual=load(SOURCE/'mutual/081.json');pairchecks=[]
    for a,b in combinations(six,2):
        if a['sheet']!=b['sheet']:continue
        dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units']
        assert all(any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']) for f in mutual['faces'])
        pairchecks.append({'parts':[a['part'],b['part']],'sheet':a['sheet'],'difference_units1000':[dx,dy],'full_guarded_clauses_checked':len(mutual['faces'])})
    assert len(pairchecks)==7;write(OUT/'six-cog-positions.json',six);write(OUT/'six-cog-pair-checks.json',pairchecks)
    checks={'passed':True,'seconds':time.perf_counter()-start,'single_closed_call_status':'OPTIMAL','single_call_within_solver_and_shared_budgets':True,'four_cog_model_reconstructed':True,
        'first_sheet_inward_halfplanes_checked':planes,'selected_cell_halfplanes_checked':cellplanes,'combined_original_cog_anchors':6,'same_sheet_cog_pairs':7,'full_guarded_clauses_checked':7*len(mutual['faces']),
        'all_six_original_copies_and_permitted_angles_preserved':True,'other_three_moving_originals_still_required':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
