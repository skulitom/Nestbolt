"""One bounded four-cog capacity/witness diagnostic, not a full-layout search."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from audit_h5_four_cog_model import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-cell-search-20261025';OUT=BASE/'first-sheet-four-cog-diagnostic';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';CELL=ROOT/'output/h5-cog-displacement-cells-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');started=time.perf_counter();deadline=started+60
    paths=[SOURCE/'queries/018.json',SOURCE/'plan.json',CELL/'coarse-refinement/selected-query-18.json',CELL/'audit/checks.json',
        ROOT/'output/h5-cog-region-capacities-20261025/capacities.json',ROOT/'output/h5-cog-region-capacities-20261025/audit/checks.json',
        ROOT/'output/h5-original-domain-conflicts-20261025/three-cog-certificate/certificate.json',ROOT/'output/h5-original-domain-conflicts-20261025/three-cog-certificate/audit/checks.json',
        ROOT/'output/h5-convex-domain-conflicts-20261025/second-sheet-pair-proofs/audit/capacity-certificate.json',BASE/'search-audit/checks.json',ROOT/'output/audit_h5_four_cog_model.py']
    assert all(load(paths[i])['passed'] for i in [3,5,7,9]);assert load(paths[8])['maximum_cog_occupancy']==2
    domains=load(paths[0])['domains'];cells=load(paths[2]);regional=load(paths[4]);cert=load(paths[6]);box=[min(d['coordinate_bounds'][k] for d in domains) if k<2 else max(d['coordinate_bounds'][k] for d in domains) for k in range(4)]
    assert len(domains)==735 and len(cells['domains'])==229
    params={'max_time_in_seconds':45,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'solver_cap_seconds':45,'shutdown_reserve_seconds':2,'maximum_solver_calls':1,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'parameters':params,
        'method':'The second sheet holds at most two moving cogs, so any full six-cog placement requires at least four on the first sheet. Independently examine four mandatory identical first-sheet cogs, retaining all735 original inward domains per cog, complete chosen-domain integer boxes and halfplanes, the applicable regional capacities and global three-region exclusion, and every proved guarded relative-position cell for all six pairings. Other five moving originals are absent only from this subproblem and remain mandatory for H5. A positive can supply a four-cog witness for later full construction, never partial acceptance; a negative is conditional on the finite source/grid/cells including the extra0.01mm conservative failure padding. Audit every model field before at most one45-second/eight-worker/seed-zero call within60 seconds total. No hints, objective, old-call continuation, seed change or retries.'})
    buildstart=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[v]*a for v,a in terms),lo,hi)
        if en:c.only_enforce_if([vs[v] for v in en])
    points=[];pairmap=[];regionmap=[]
    for i in range(4):
        x=var(f'cog{i}-x',box[0],box[2]);y=var(f'cog{i}-y',box[1],box[3]);choice=var(f'cog{i}-choice',0,len(domains)-1);flags=[]
        for j,d in enumerate(domains):
            flag=var(f'cog{i}-domain{j}',0,1);flags.append(flag);b=d['coordinate_bounds'];linear([(x,1)],b[0],b[2],[flag]);linear([(y,1)],b[1],b[3],[flag])
            for h in d['halfplanes']:linear([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['bound'],[flag])
        model.add_exactly_one([vs[f] for f in flags]);linear([(choice,1)]+[(f,-j) for j,f in enumerate(flags)],0,0);points.append({'index':i,'x':x,'y':y,'choice':choice,'domains':flags})
    for a,b in zip(points,points[1:]):linear([(a['choice'],1),(b['choice'],-1)],cp_model.INT_MIN,0)
    for group in regional['constraints']:
        if group['query']==18:linear([(p['domains'][j],1) for p in points for j in group['domain_rows']],cp_model.INT_MIN,group['capacity'])
    for g in cert['groups']:
        flag=var(f"region-{g['name']}",0,1);selectors=[p['domains'][j] for p in points for j in g['domain_rows']]
        linear([(v,1) for v in selectors]+[(flag,-1)],0,cp_model.INT_MAX);linear([(v,1) for v in selectors]+[(flag,-4)],cp_model.INT_MIN,0);regionmap.append({'name':g['name'],'flag':flag})
    model.add_bool_or([vs[r['flag']].Not() for r in regionmap])
    for a,b in combinations(points,2):
        flags=[]
        for d in cells['domains']:
            flag=var(f"pair{a['index']}-{b['index']}-cell{d['index']}",0,1);flags.append({'index':d['index'],'flag':flag});r=d['coordinate_bounds']
            linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[flag]);linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[flag])
            for h in d['halfplanes']:linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],cp_model.INT_MIN,h['bound'],[flag])
        model.add_exactly_one([vs[f['flag']] for f in flags]);pairmap.append({'cogs':[a['index'],b['index']],'cells':flags})
    mapping={'cogs':points,'pairs':pairmap,'regions':regionmap};write(OUT/'mapping.json',mapping);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'));buildtime=time.perf_counter()-buildstart
    auditstart=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());expected,stats=verify(actual,domains,cells,box,regional,cert);assert mapping==expected
    remaining=deadline-time.perf_counter()-2;assert remaining>0;params['max_time_in_seconds']=min(45,remaining);solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':buildtime,'audit_seconds':time.perf_counter()-auditstart,**stats,'remaining_after_shutdown_reserve_seconds':remaining,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt')})
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds']});print(load(OUT/'model-audit.json'),flush=True)
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if positive:
        positions=[]
        for p in points:
            selected=[j for j,f in enumerate(p['domains']) if solver.value(vs[f])];assert len(selected)==1
            positions.append({'cog':p['index'],'query':18,'profile':9,'sheet':0,'domain_row':selected[0],'domain_index':domains[selected[0]]['index'],'x_units':solver.value(vs[p['x']]),'y_units':solver.value(vs[p['y']])})
        write(OUT/'positions.json',positions);write(OUT/'chosen-cells.json',[{'cogs':p['cogs'],'cell_indices':[f['index'] for f in p['cells'] if solver.value(vs[f['flag']])]} for p in pairmap])
    result={'status':solver.status_name(code),'solver_seconds':elapsed,'total_seconds':time.perf_counter()-started,'declared_shared_seconds':60,'solver_calls':1,'four_cog_candidate':positive,'response_stats':solver.response_stats(),
        'partial_subproblem_only':True,'other_five_moving_originals_still_required':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
