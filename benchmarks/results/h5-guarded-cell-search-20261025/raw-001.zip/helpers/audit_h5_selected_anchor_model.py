"""Independent exact bounds reduction and full original-coordinate model oracle."""
from collections import Counter
from itertools import combinations
from ortools.sat import cp_model_pb2

def verify(actual,spec,selected,queries,mutual):
    vi=ci=planes=always=impossible=possible=pieces=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name);vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        d=Counter()
        for v,c in terms:d[v]+=c
        ids=sorted(i for i,c in d.items() if c);p=cp_model_pb2.ConstraintProto();p.enforcement_literal.extend(en);p.linear.vars.extend(ids);p.linear.coeffs.extend(d[i] for i in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(ids):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend(ids);assert actual.constraints[ci]==p,(ci,ids);ci+=1
    parts=[]
    for p in selected:
        face=queries[p['query']]['domains'][p['domain_row']];q=spec['queries'][p['query']];f=face['coordinate_bounds'];s=q['anchor_bounds_units1000']
        b=[max(f[0],s[0]),max(f[1],s[1]),min(f[2],s[2]),min(f[3],s[3])];assert b[0]<=b[2] and b[1]<=b[3]
        x=var(f"part{p['part']}-x",b[0],b[2]);y=var(f"part{p['part']}-y",b[1],b[3]);assert face['index']==p['domain_index'] and q['profile']==p['profile'] and q['sheet']==p['sheet']
        for h in face['halfplanes']:assert h['sense']=='le';linear([(x,h['a']),(y,h['b'])],-2**63,h['bound']);planes+=1
        parts.append({**p,'x':x,'y':y,'coordinate_bounds':b})
    lookup={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']};pairs=[]
    for a,b in combinations(parts,2):
        if a['sheet']!=b['sheet']:continue
        case=lookup[(a['profile'],b['profile'])];ba,bb=a['coordinate_bounds'],b['coordinate_bounds'];r=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];records=[]
        for f in mutual[case]['faces']:
            edges=[]
            for n,h in enumerate(f['outside_halfplanes']):
                low=min(h['a']*r[0],h['a']*r[2])+min(h['b']*r[1],h['b']*r[3]);high=max(h['a']*r[0],h['a']*r[2])+max(h['b']*r[1],h['b']*r[3])
                edges.append({'edge':n,'minimum_projection':low,'maximum_projection':high,'always':low>=h['bound'],'possible':high>=h['bound']})
            dirs=[]
            if any(e['always'] for e in edges):always+=1
            else:
                pieces+=1
                for e in edges:
                    if not e['possible']:impossible+=1;continue
                    h=f['outside_halfplanes'][e['edge']];d=var(f"pair{a['part']}-{b['part']}-face{f['index']}-edge{e['edge']}",0,1);dirs.append(d);possible+=1
                    linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[d])
                boolean(dirs)
            records.append({'face':f['index'],'edges':edges,'always_separated':any(e['always'] for e in edges),'directions':dirs})
        pairs.append({'parts':[a['part'],b['part']],'case':case,'difference_bounds':r,'faces':records})
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'pairs':pairs},{'variables':vi,'constraints':ci,'mandatory_moving_originals':9,'fixed_originals':57,'required_originals':66,
        'inward_domain_halfplanes':planes,'same_sheet_physical_pairs':len(pairs),'full_original_forbidden_faces':sum(len(p['faces']) for p in pairs),
        'whole_box_always_separated_faces':always,'remaining_forbidden_piece_disjunctions':pieces,'proved_impossible_directions_omitted':impossible,
        'possible_separating_directions':possible,'hints':0,'objectives':0,'optional_originals':0,'all_filtering_by_exact_integer_bounds':True}
