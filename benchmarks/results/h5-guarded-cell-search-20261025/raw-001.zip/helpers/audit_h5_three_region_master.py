"""Independent complete-master audit plus certified global region occupancy clause."""
from collections import Counter
from ortools.sat import cp_model_pb2
from audit_h5_domain_selection_model import verify as verify_base

def verify(actual,spec,queries,census,groups,aux,orders,certificate):
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.variables[-3:];del prefix.constraints[-7:]
    mapping,stats=verify_base(prefix,spec,queries,census,groups,aux,orders);vi=len(prefix.variables);ci=len(prefix.constraints)
    def linear(terms,lo,hi):
        nonlocal ci
        d=Counter()
        for v,c in terms:d[v]+=c
        ids=sorted(v for v,c in d.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(d[v] for v in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    cogs=[p for p in mapping['parts'] if p['family']=='cog'];assert [p['part'] for p in cogs]==certificate['applicable_moving_cog_parts'] and len(cogs)==6
    occupancies=[]
    for g in certificate['groups']:
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=f"region-{g['name']}-occupied",domain=[0,1]);flag=vi;vi+=1
        wanted=[];b=g['coordinate_box_units1000']
        for i,face in enumerate(queries[g['query']]['domains']):
            d=face['coordinate_bounds']
            if b[0]<=d[0]<=d[2]<=b[2] and b[1]<=d[1]<=d[3]<=b[3]:wanted.append(i)
        assert wanted==g['domain_rows'];selectors=[]
        for p in cogs:
            q=next(m for m in p['modes'] if m['query']==g['query']);selectors.extend(q['domains'][i] for i in wanted)
        linear([(v,1) for v in selectors]+[(flag,-1)],0,2**63-1)
        linear([(v,1) for v in selectors]+[(flag,-6)],-2**63,0)
        for count in range(7):assert [f for f in [0,1] if count-f>=0 and count-6*f<=0]==[int(count>0)]
        occupancies.append({'name':g['name'],'occupied':flag,'selectors':selectors})
    clause=cp_model_pb2.ConstraintProto();clause.bool_or.literals.extend(-r['occupied']-1 for r in occupancies);assert actual.constraints[ci]==clause;ci+=1
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    mapping['region_occupancies']=occupancies
    return mapping,{**stats,'variables':vi,'constraints':ci,'certified_global_region_exclusions':1,'occupancy_flags':3,
        'occupancy_selectors':sum(len(g['selectors']) for g in occupancies),'certified_region_group_sizes':[len(g['domain_rows']) for g in certificate['groups']],
        'global_excluded_domain_triples':696,'all_six_cogs_in_every_occupancy_group':True,'exact_zero_or_positive_occupancy_truth_tables_checked':True}
