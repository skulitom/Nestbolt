"""Reconstruct the refined master plus all certified second-sheet constraints."""
from itertools import combinations
from ortools.sat import cp_model_pb2
from audit_h5_three_region_master import verify as verify_previous
def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity):
    cogs=[p['part'] for p in spec['parts'] if p['family']=='cog'];assert cogs==capacity['applicable_parts'] and len(cogs)==6
    count=len(list(combinations(cogs,2)))*len(pairs['domain_row_pairs'])+1
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.constraints[-count:]
    mapping,stats=verify_previous(prefix,spec,queries,census,groups,aux,orders,certificate);ci=len(prefix.constraints)
    assert pairs['query']==capacity['query']==19 and capacity['maximum_cog_occupancy']==2
    for i,j in combinations(cogs,2):
        a=next(q for q in mapping['parts'][i]['modes'] if q['query']==19);b=next(q for q in mapping['parts'][j]['modes'] if q['query']==19)
        for ra,rb in pairs['domain_row_pairs']:
            c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-a['domains'][ra]-1,-b['domains'][rb]-1]);assert c==actual.constraints[ci];ci+=1
    ids=sorted(next(q for q in mapping['parts'][i]['modes'] if q['query']==19)['active'] for i in cogs)
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*6);c.linear.domain.extend([-2**63,2]);assert c==actual.constraints[ci];ci+=1
    assert ci==len(actual.constraints) and len(actual.variables)==len(prefix.variables)
    return mapping,{**stats,'constraints':ci,'second_sheet_exact_pair_constraints':count-1,'second_sheet_global_cog_capacity':2,'all_six_cogs_counted_in_capacity':True}
