"""Independent oracle for the complete necessary domain-compatibility model."""
from collections import Counter
from ortools.sat import cp_model_pb2

def verify(actual,spec,queries,census,groups,aux,orders):
    vi=ci=ndom=nquery=ngroups=nlits=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name);vi+=1;return vi-1
    def linear(terms,lo,hi):
        nonlocal ci
        d=Counter()
        for i,c in terms:d[i]+=c
        ids=sorted(i for i,c in d.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(d[i] for i in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(kind,lits):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();getattr(p,kind).literals.extend(lits);assert actual.constraints[ci]==p,(ci,kind);ci+=1
    parts=[]
    for pi,item in enumerate(spec['parts']):
        sheet=var(f'part{pi}-sheet',0,1);modes=[];allvars=[]
        for qi in item['queries']:
            active=var(f'part{pi}-query{qi}-active',0,1);ds=[];nquery+=1
            for face in queries[qi]['domains']:
                v=var(f"part{pi}-query{qi}-face{face['index']}",0,1);ds.append(v);allvars.append(v);ndom+=1
            linear([(d,1) for d in ds]+[(active,-1)],0,0);modes.append({'query':qi,'active':active,'domains':ds})
        boolean('exactly_one',[m['active'] for m in modes]);linear([(sheet,1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in modes],0,0)
        choice=var(f'part{pi}-choice-index',0,len(allvars)-1);linear([(choice,1)]+[(v,-i) for i,v in enumerate(allvars)],0,0)
        parts.append({'part':pi,'item':item['index'],'family':item['family'],'sheet':sheet,'choice':choice,'modes':modes})
    assert [p['item'] for p in parts]==[28,29,50,54,57,58,62,64,65]
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    assert orders==[[0,1],[3,4],[4,5],[5,6],[6,7],[7,8]]
    for i,j in orders:
        assert all(spec['parts'][i][k]==spec['parts'][j][k] for k in ['family','queries','profiles','allowed_modes'])
        linear([(parts[i]['choice'],1),(parts[j]['choice'],-1)],-2**63,0)
    details=[]
    for pair in census['physical_pair_case_uses']:
        i,j=pair['parts'];a,b=parts[i],parts[j]
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b'])
            for group in row['groups']:
                if not group['conflicts_per_a_row']:continue
                da=[qa['domains'][k] for k in group['rows_a']];bits=bin(int(group['forbidden_b_hex'],16))[2:].zfill(8*(len(group['forbidden_b_hex'])//2))[:case['rows_b']]
                forbidden=[qb['domains'][k] for k,v in enumerate(bits) if v=='1'];assert len(forbidden)==group['conflicts_per_a_row']
                if len(da)==1:flag=da[0]
                else:
                    flag=var(f"pair{i}-{j}-case{caseid}-group{group['group']}",0,1);linear([(v,1) for v in da]+[(flag,-1)],0,0)
                if len(forbidden)==len(qb['domains']):boolean('bool_or',[-flag-1,-qb['active']-1]);nlits+=2
                else:boolean('at_most_one',[flag]+forbidden);nlits+=1+len(forbidden)
                ngroups+=1;details.append({'parts':[i,j],'case':caseid,'group':group['group'],'flag':flag})
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'groups':details},{'variables':vi,'constraints':ci,'mandatory_moving_originals':9,'fixed_originals':57,'required_originals':66,
        'query_options':nquery,'domain_options':ndom,'physical_pair_case_uses':394,'physical_pair_groups':ngroups,'conflict_group_literals':nlits,
        'copy_index_order_constraints':6,'original_area_constraints':2,'hints':0,'objectives':0,'optional_originals':0,
        'whole_original_domain_exclusions_only':True,'negative_scope':'Recorded original-source angles and inward convex domains; not unrestricted packing impossibility.'}
