"""Reconstruct the four-cog first-sheet subproblem without trusting the builder."""
from collections import Counter
from itertools import combinations
from ortools.sat import cp_model_pb2
def verify(actual,domains,cells,box,regional,global_certificate):
    vi=ci=0;points=[];pairmap=[];regionmap=[]
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        values=Counter()
        for v,c in terms:values[v]+=c
        ids=sorted(v for v,c in values.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(values[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en)
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(field,ids):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();getattr(p,field).literals.extend(ids);assert actual.constraints[ci]==p;ci+=1
    for i in range(4):
        x=var(f'cog{i}-x',box[0],box[2]);y=var(f'cog{i}-y',box[1],box[3]);choice=var(f'cog{i}-choice',0,len(domains)-1);flags=[]
        for j,d in enumerate(domains):
            flag=var(f'cog{i}-domain{j}',0,1);flags.append(flag);b=d['coordinate_bounds']
            linear([(x,1)],b[0],b[2],[flag]);linear([(y,1)],b[1],b[3],[flag])
            for h in d['halfplanes']:linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[flag])
        boolean('exactly_one',flags);linear([(choice,1)]+[(f,-j) for j,f in enumerate(flags)],0,0);points.append({'index':i,'x':x,'y':y,'choice':choice,'domains':flags})
    for a,b in zip(points,points[1:]):linear([(a['choice'],1),(b['choice'],-1)],-2**63,0)
    for group in regional['constraints']:
        if group['query']!=18:continue
        linear([(p['domains'][j],1) for p in points for j in group['domain_rows']],-2**63,group['capacity'])
    for g in global_certificate['groups']:
        assert g['query']==18;flag=var(f"region-{g['name']}",0,1);selectors=[p['domains'][j] for p in points for j in g['domain_rows']]
        linear([(v,1) for v in selectors]+[(flag,-1)],0,2**63-1);linear([(v,1) for v in selectors]+[(flag,-4)],-2**63,0);regionmap.append({'name':g['name'],'flag':flag})
    boolean('bool_or',[-r['flag']-1 for r in regionmap])
    for a,b in combinations(points,2):
        flags=[]
        for d in cells['domains']:
            flag=var(f"pair{a['index']}-{b['index']}-cell{d['index']}",0,1);flags.append({'index':d['index'],'flag':flag});r=d['coordinate_bounds']
            linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[flag]);linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[flag])
            for h in d['halfplanes']:linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],-2**63,h['bound'],[flag])
        boolean('exactly_one',[f['flag'] for f in flags]);pairmap.append({'cogs':[a['index'],b['index']],'cells':flags})
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    rest=cp_model_pb2.CpModelProto();rest.CopyFrom(actual);rest.ClearField('variables');rest.ClearField('constraints');assert not rest.ListFields()
    return {'cogs':points,'pairs':pairmap,'regions':regionmap},{'variables':vi,'constraints':ci,'mandatory_modeled_cogs':4,'all735_first_sheet_domains_per_cog':len(domains)==735,
        'full_guarded_cell_flags':6*len(cells['domains']),'all_six_modeled_pairs_require_one_cell':True,'source_fixed_originals':57,'other_mandatory_moving_originals_not_modeled':5,
        'H5_required_originals':66,'partial_diagnostic_only':True,'hints':0,'objectives':0}
