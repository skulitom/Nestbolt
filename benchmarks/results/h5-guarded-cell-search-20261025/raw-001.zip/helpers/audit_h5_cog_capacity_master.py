"""Audit every inherited constraint and all certified regional occupancy sums."""
from ortools.sat import cp_model_pb2
from audit_h5_second_sheet_master import verify as verify_previous
def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional):
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.constraints[-len(regional['constraints']):]
    mapping,stats=verify_previous(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity);ci=len(prefix.constraints);nlits=0
    assert regional['applicable_cog_parts']==capacity['applicable_parts']
    for group in regional['constraints']:
        selectors=[]
        for i in regional['applicable_cog_parts']:
            m=next(q for q in mapping['parts'][i]['modes'] if q['query']==group['query']);selectors.extend(m['domains'][k] for k in group['domain_rows'])
        assert len(selectors)==len(set(selectors))
        c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(sorted(selectors));c.linear.coeffs.extend([1]*len(selectors));c.linear.domain.extend([-2**63,group['capacity']])
        assert actual.constraints[ci]==c;ci+=1;nlits+=len(selectors)
    assert ci==len(actual.constraints) and len(actual.variables)==len(prefix.variables)
    return mapping,{**stats,'constraints':ci,'certified_regional_capacity_constraints':len(regional['constraints']),'regional_capacity_selector_uses':nlits,'all_six_cogs_counted_in_every_region':True}
