"""Prepare the guarded-cell full-original pipeline without running its solver."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'output'
OLD='output/h5-second-sheet-guided-search-20261025/shared-search';NEW='output/h5-guarded-cell-search-20261025/shared-search'
CELL="ROOT/'output/h5-cog-displacement-cells-20261025'"
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'solve_h5_second_sheet_guided_master.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('from audit_h5_second_sheet_guided_master import verify','from audit_h5_guarded_cell_master import verify')
s=s.replace("    pair_exclusions=load(PROOF/", "    cellpath="+CELL+";assert load(cellpath/'audit/checks.json')['passed'];cells={q:load(cellpath/'coarse-refinement'/f'selected-query-{q}.json') for q in [18,19]};cell_witness=load(cellpath/'audit/retained-witnesses.json')[0]\n    pair_exclusions=load(PROOF/")
s=s.replace("ROOT/'output/audit_h5_second_sheet_guided_master.py',", "ROOT/'output/audit_h5_guarded_cell_master.py',cellpath/'audit/checks.json',cellpath/'audit/retained-witnesses.json',cellpath/'coarse-refinement/selected-query-18.json',cellpath/'coarse-refinement/selected-query-19.json',")
a=s.index('    for a,b in combinations(cog_positions,2):');b=s.index("    for i,j in combinations(regional['applicable_cog_parts'],2):",a)
s=s[:a]+'''    cell_pairs=[]
    for a,b in combinations(cog_positions,2):
        i,j=a['part'],b['part'];sa,sb=parts[i]['sheet'],parts[j]['sheet'];modes=[]
        for q in [18,19]:
            active=var(f'cog-pair{i}-{j}-query{q}-active',0,1);la=vs[sa].Not() if q==18 else vs[sa];lb=vs[sb].Not() if q==18 else vs[sb]
            model.add_bool_or([vs[active].Not(),la]);model.add_bool_or([vs[active].Not(),lb]);model.add_bool_or([vs[active],la.Not(),lb.Not()])
            flags=[]
            for d in cells[q]['domains']:
                flag=var(f"cog-pair{i}-{j}-query{q}-cell{d['index']}",0,1);flags.append({'index':d['index'],'flag':flag});r=d['coordinate_bounds']
                model.add_linear_constraint(vs[b['x']]-vs[a['x']],r[0],r[2]).only_enforce_if(vs[flag])
                model.add_linear_constraint(vs[b['y']]-vs[a['y']],r[1],r[3]).only_enforce_if(vs[flag])
                for h in d['halfplanes']:
                    model.add_linear_constraint((vs[b['x']]-vs[a['x']])*h['a']+(vs[b['y']]-vs[a['y']])*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[flag])
            linear([(f['flag'],1) for f in flags]+[(active,-1)],0,0);modes.append({'query':q,'active':active,'cells':flags})
        cell_pairs.append({'parts':[i,j],'sheet_modes':modes})
'''+s[b:]
needle="    mapping={'parts':parts"
extra="""    hinted_pair=next(p for p in cell_pairs if p['parts']==[7,8]);hinted_mode=next(m for m in hinted_pair['sheet_modes'] if m['query']==19);hinted_cell=next(c for c in hinted_mode['cells'] if c['index']==cell_witness['cell_indices'][0])
    model.add_hint(vs[hinted_mode['active']],1);model.add_hint(vs[hinted_cell['flag']],1)
"""
s=s.replace(needle,extra+needle)
s=s.replace("'simultaneous_cog_coordinates':cog_positions}","'simultaneous_cog_coordinates':cog_positions,'guarded_displacement_cell_pairs':cell_pairs}")
s=s.replace('regional,atlas,mutual,added,new_pairs,witness);','regional,atlas,added,new_pairs,witness,cells,cell_witness);')
start=s.index("        'method':'");end=s.index("'})",start)
s=s[:start]+"        'method':'Keep all66 original identities, all domains, area and occupancy constraints, and all140 added guarded/exact pair exclusions. Replace the necessary raw-core cog disjunctions with independently proved full guarded allowed displacement cells:229 on sheet0 and4 on sheet1. Each same-sheet pair activates exactly one cell; different-sheet pairs activate none. Enforce every selected cell integer box and inward halfplane on anchorB-anchorA, together with explicit query anchor bounds. First-sheet outward failure padding0.01mm is a stricter constructive restriction and limits negative scope. Independently reconstruct every model field, Boolean truth table and16 advisory hints before one45-second/eight-worker/seed-zero call inside the shared60-second pipeline, reserving2 seconds for shutdown. Hints fix no placements. All other original pair coordinates and66-part/native/H5 validation remain required. No continuation, retry or seed change of any closed call."+s[end:]
needle="        write(OUT/'necessary-cog-positions.json'"
start=s.index(needle);end=s.index('\n',start)
extra="""
        chosen_cells=[]
        for pair in cell_pairs:
            active=[m for m in pair['sheet_modes'] if solver.value(vs[m['active']])]
            chosen=[]
            for m in active:
                chosen.extend({'query':m['query'],'cell_index':c['index']} for c in m['cells'] if solver.value(vs[c['flag']]))
            chosen_cells.append({'parts':pair['parts'],'chosen_cells':chosen})
        write(OUT/'guarded-cog-cell-selection.json',chosen_cells)
"""
s=s[:end]+extra+s[end:]
s=s.replace('A feasible assignment has necessary original-core cog anchors only','A feasible assignment has full guarded original-cog anchors')
save('solve_h5_guarded_cell_master.py',s)
s=(R/'audit_h5_second_sheet_guided_selection.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace("mutual=load(ROOT/'output/h5-full-cog-coordinates-20261025/original-core-relaxation'/'pieces.json')","mutual=load(SOURCE/'mutual/081.json')")
s=s.replace('necessary-original-core-check.json','full-guarded-cog-check.json').replace('complete_necessary_core_piece_checks','complete_full_guarded_piece_checks')
s=s.replace("    write(OUT/'plan.json',","    inputs.extend([SOURCE/'mutual/081.json',NEW/'solve/guarded-cog-cell-selection.json',"+CELL+"/'audit/checks.json',"+CELL+"/'coarse-refinement/selected-query-18.json',"+CELL+"/'coarse-refinement/selected-query-19.json'])\n    write(OUT/'plan.json',")
needle="    write(OUT/'full-guarded-cog-check.json'"
extra="""    chosen=load(NEW/'solve/guarded-cog-cell-selection.json');assert [r['parts'] for r in chosen]==[list(p) for p in combinations(range(3,9),2)];cell_checks=0
    for row in chosen:
        i,j=row['parts'];a=next(p for p in positions if p['part']==i);b=next(p for p in positions if p['part']==j)
        if parts[i]['sheet']!=parts[j]['sheet']:assert not row['chosen_cells'];continue
        assert len(row['chosen_cells'])==1;selected_cell=row['chosen_cells'][0];q=18+parts[i]['sheet'];assert selected_cell['query']==q
        data=load(ROOT/'output/h5-cog-displacement-cells-20261025/coarse-refinement'/f'selected-query-{q}.json');d=next(d for d in data['domains'] if d['index']==selected_cell['cell_index'])
        x,y=b['x_units']-a['x_units'],b['y_units']-a['y_units']
        for r in [d['coordinate_bounds'],data['difference_bounds_units1000']]:assert r[0]<=x<=r[2] and r[1]<=y<=r[3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];cell_checks+=1
    write(OUT/'guarded-cog-cells-check.json',{'passed':True,'all15_pair_activations_verified':True,'chosen_cell_halfplanes_checked':cell_checks})
"""
assert needle in s;s=s.replace(needle,extra+needle);save('audit_h5_guarded_cell_selection.py',s)
s=(R/'solve_h5_second_sheet_guided_anchors.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('necessary-original-core-check.json','full-guarded-cog-check.json')
s=s.replace("inputs=[BASE/'selection-audit/new-exact-pairs-check.json'","inputs=[BASE/'selection-audit/guarded-cog-cells-check.json',BASE/'selection-audit/new-exact-pairs-check.json'")
save('solve_h5_guarded_cell_anchors.py',s)
s=(R/'run_h5_second_sheet_guided_search.py').read_text(encoding='utf-8').replace('h5-second-sheet-guided-search-20261025','h5-guarded-cell-search-20261025')
for name in ['solve_h5_second_sheet_guided_master','audit_h5_second_sheet_guided_selection','solve_h5_second_sheet_guided_anchors']:s=s.replace(name,name.replace('second_sheet_guided','guarded_cell'))
s=s.replace("assert load(EVIDENCE/'audit/checks.json')['passed']","assert load(EVIDENCE/'audit/checks.json')['passed'] and load("+CELL+"/'audit/checks.json')['passed']")
s=s.replace("EVIDENCE/'added-pairs.json']","EVIDENCE/'added-pairs.json',"+CELL+"/'audit/checks.json',"+CELL+"/'coarse-refinement/selected-query-18.json',"+CELL+"/'coarse-refinement/selected-query-19.json']")
s=s.replace('every necessarily rounded original-cog core piece','all independently proved guarded displacement cells with exact sheet activation and chosen-cell constraints')
s=s.replace('New master includes all ten exact','New master replaces necessary core separation with full guarded displacement cells and includes all ten exact')
save('run_h5_guarded_cell_search.py',s)
print('Prepared guarded-cell staged search; no solver call yet.')
