"""Exact mapping of all newly certified nonduplicate guarded cog-pair clauses."""
from itertools import combinations
from ortools.sat import cp_model_pb2
from audit_h5_cog_capacity_master import verify as verify_previous
def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,added):
    cogs=regional['applicable_cog_parts'];assert len(cogs)==6 and len(added['pairs'])==130
    count=len(added['pairs'])*15;prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.constraints[-count:]
    mapping,stats=verify_previous(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional);ci=len(prefix.constraints)
    for i,j in combinations(cogs,2):
        for row in added['pairs']:
            a=next(m for m in mapping['parts'][i]['modes'] if m['query']==row['query']);b=next(m for m in mapping['parts'][j]['modes'] if m['query']==row['query']);ia,ib=row['domain_rows']
            p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend([-a['domains'][ia]-1,-b['domains'][ib]-1]);assert actual.constraints[ci]==p;ci+=1
    assert ci==len(actual.constraints) and len(actual.variables)==len(prefix.variables)
    return mapping,{**stats,'constraints':ci,'new_nonduplicate_guarded_cog_pair_clauses':count,'new_pair_clauses_cover_all15_cog_pairings':True}
