"""Independent complete protobuf reconstruction of fourteen mandatory cog centers."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed40-strong-coordinate-model-20261026';DOM=ROOT/'output/h5-fixed40-strong-domains-20261026';OUT=BASE/'model-audit'
UNION=ROOT/'output/h5-fixed40-strong-union-capacities-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reconstruct every variable, bound, profile-domain equality, occupancy sum/capacity, conflict and squared-distance constraint from independent domain certificates. Verify all66 identities, identical-cog relabelling, no hints/objective, arithmetic bounds and actual import/export.'})
spec=load(BASE/'plan.json')
for n,h in spec['inputs'].items():assert digest(ROOT/n)==h,n
assert load(DOM/'audit/checks.json')['passed'];assert sorted(spec['fixed_first_originals']+spec['mandatory_moving_first_cogs']+spec['fixed_short_originals'])==list(range(66)) and len(spec['mandatory_moving_first_cogs'])==14
ds=load(DOM/'merged-domain-rectangles.json');caps=load(DOM/'audit/cell-capacities.json');conflicts=load(DOM/'audit/incompatible-cell-pairs.json');xb=[min(d['bounds_units1000'][0] for d in ds),max(d['bounds_units1000'][2] for d in ds)];yb=[min(d['bounds_units1000'][1] for d in ds),max(d['bounds_units1000'][3] for d in ds)];assert load(BASE/'coordinate-bounds.json')=={'x':xb,'y':yb};m=pb.CpModelProto();mapping={'points':[],'occupancies':[],'pairs':[]}
def variable(name,domain):
    i=len(m.variables);m.variables.add(name=name,domain=domain);return i
def row(terms,domain,en=()):
    items=sorted(terms.items());c=m.constraints.add();c.enforcement_literal.extend(en);c.linear.vars.extend(i for i,v in items);c.linear.coeffs.extend(v for i,v in items);c.linear.domain.extend(domain)
for i,original in enumerate(spec['mandatory_moving_first_cogs']):mapping['points'].append({'part':i,'original':original,'x':variable(f'p{i}-x',xb),'y':variable(f'p{i}-y',yb),'domains':[]})
for point in mapping['points']:
    for d in ds:
        j=d['index'];flag=variable(f"p{point['part']}-domain{j}",[0,1]);point['domains'].append(flag);bb=d['bounds_units1000'];row({point['x']:1},[bb[0],bb[2]],[flag]);row({point['y']:1},[bb[1],bb[3]],[flag])
    row(dict.fromkeys(point['domains'],1),[1,1])
for j,cap in enumerate(caps):
    assert cap['domain']==j;v=variable(f'domain{j}-occupancy',[0,cap['capacity']]);mapping['occupancies'].append(v);row({**{p['domains'][j]:1 for p in mapping['points']},v:-1},[0,0])
for a,b in conflicts:
    assert caps[a]['capacity']==caps[b]['capacity']==1
    row({mapping['occupancies'][a]:1,mapping['occupancies'][b]:1},[0,1])
assert load(UNION/'audit/checks.json')['passed']
for r in load(UNION/'union-capacities.json'):row({mapping['occupancies'][i]:1 for i in r['domains']},[0,r['capacity']])
for i,j in combinations(range(14),2):
    p,q=mapping['points'][i],mapping['points'][j];mx,my=xb[1]-xb[0],yb[1]-yb[0];dx=variable(f'dx-{i}-{j}',[0,mx]);dy=variable(f'dy-{i}-{j}',[-my,my]);xx=variable(f'dx2-{i}-{j}',[0,mx*mx]);yy=variable(f'dy2-{i}-{j}',[0,my*my]);row({q['x']:1,p['x']:-1,dx:-1},[0,0]);row({q['y']:1,p['y']:-1,dy:-1},[0,0])
    for v,square in [(dx,xx),(dy,yy)]:
        c=m.constraints.add();c.int_prod.target.vars.append(square);c.int_prod.target.coeffs.append(1)
        for _ in range(2):e=c.int_prod.exprs.add();e.vars.append(v);e.coeffs.append(1)
    row({xx:1,yy:1},[254297**2,2**63-1]);mapping['pairs'].append({'parts':[i,j],'dx':dx,'dy':dy,'dx2':xx,'dy2':yy});assert mx*mx+my*my<2**60
M=len(ds); C=len(conflicts); V=392+15*M; K=29*M+C+469+len(load(UNION/'union-capacities.json'))
assert m==proto(BASE/'models/000.pb') and mapping==load(BASE/'mapping.json') and len(m.variables)==V and len(m.constraints)==K and not m.HasField('objective') and not m.HasField('solution_hint')
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'all14_original_cogs_required':True,'all66_identities_accounted_once':True,'statement':'Each source-feasible cog center floors into a certified retained domain. Identical cog copies can be relabelled by increasing X without changing any fixed first/short obligation or allowed orientation. Every one of91 source pair distances remains at least254297 units after conservative rounding. Auxiliary differences and exact integer products represent that necessary squared norm without approximation. Domain occupancies are exact sums of selected flags; certified individual/whole-union capacities and incompatible pairs hold for every domain choice. A negative excludes the40-fixed/fixed-short12 neighborhood at all real cog angles and continuous centers. A positive is only necessary and must still be realized by original cog angles/geometry. No first-sheet cog is omitted and no old seed is locked.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':V,'constraints':K,'mandatory_original_cogs':14,'domain_choices_verified':14*M,'occupancy_counts_verified':M,'incompatible_cell_constraints_verified':C,'exact_squared_pair_constraints_verified':91,'union_capacity_constraints_verified':len(load(UNION/'union-capacities.json')),'integer_products_verified':182,'all66_identities_accounted_once':True,'no_objective_or_hints':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
