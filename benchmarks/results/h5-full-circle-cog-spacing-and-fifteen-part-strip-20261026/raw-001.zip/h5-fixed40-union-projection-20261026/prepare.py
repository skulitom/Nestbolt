"""A distinct occupancy-only projection of the complete all-angle domain cover."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];DOM=ROOT/'output/h5-fixed40-combined-domains-20261026';INV=ROOT/'output/h5-fixed40-cog-neighborhood-20261026';PRIOR=ROOT/'output/h5-fixed40-capacity-projection-20261026';UNION=ROOT/'output/h5-fixed40-union-capacities-20261026';OUT=ROOT/'output/h5-fixed40-union-projection-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[DOM/'merged-domain-rectangles.json',DOM/'audit/cell-capacities.json',DOM/'audit/incompatible-cell-pairs.json',DOM/'audit/checks.json',DOM/'audit/necessity-proof.json',INV/'next-neighborhood.json',INV/'checks.json',PRIOR/'response-audit/checks.json',UNION/'union-capacities.json',UNION/'audit/checks.json',UNION/'audit/necessity-proof.json']
assert load(PRIOR/'response-audit/checks.json')['status']=='OPTIMAL' and load(UNION/'audit/checks.json')['passed'] and load(DOM/'audit/checks.json')['passed']
caps=load(DOM/'audit/cell-capacities.json');pairs=load(DOM/'audit/incompatible-cell-pairs.json');assert all(caps[a]['capacity']==caps[b]['capacity']==1 for a,b in pairs)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'New union-capacity projection after the plain occupancy call closed positive with630 violations of independently valid union capacities. Each certified merged domain has an integer occupancy at its independently proved capacity. Every incompatible pair has separately unit-capacity endpoints and sum at most one. Total occupancy equals14. Add all2791 independently audited domain-union capacity constraints. Retain all66 original obligations and drop coordinates and squared distances. Infeasibility excludes the fixed40/short12 neighborhood. A positive is only a possible multiset of14 domains, not cog centers or source feasibility. No hint/objective, one separately declared20/30-second call; no retry of the closed coordinate or plain occupancy formulations.'})
m=pb.CpModelProto()
for r in caps:m.variables.add(name=f"domain{r['domain']}-occupancy",domain=[0,r['capacity']])
for a,b in pairs:m.constraints.add(linear=pb.LinearConstraintProto(vars=[a,b],coeffs=[1,1],domain=[0,1]))
for r in load(UNION/'union-capacities.json'):m.constraints.add(linear=pb.LinearConstraintProto(vars=r['domains'],coeffs=[1]*len(r['domains']),domain=[0,r['capacity']]))
m.constraints.add(linear=pb.LinearConstraintProto(vars=list(range(len(caps))),coeffs=[1]*len(caps),domain=[14,14]))
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
write(OUT/'inventory.json',[{'index':0,'parts':list(range(14)),'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'solver_seconds':20,'original_coordinates_field_is_projection_variables_only':True}])
write(OUT/'prepared.json',{'variables':len(m.variables),'constraints':len(m.constraints),'seconds':time.perf_counter()-start,'solver_calls':0});print(load(OUT/'prepared.json'))
