"""Independent complete model reconstruction and necessary-mapping proof."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed40-union-projection-20261026';DOM=ROOT/'output/h5-fixed40-combined-domains-20261026';INV=ROOT/'output/h5-fixed40-cog-neighborhood-20261026';UNION=ROOT/'output/h5-fixed40-union-capacities-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
caps=load(DOM/'audit/cell-capacities.json');pairs=load(DOM/'audit/incompatible-cell-pairs.json');assert load(DOM/'audit/checks.json')['passed'];inv=load(INV/'next-neighborhood.json');assert len(inv['mandatory_moving_first_cogs'])==14 and len(inv['fixed_first_originals'])==40 and len(inv['fixed_short_originals'])==12 and sorted(inv['mandatory_moving_first_cogs']+inv['fixed_first_originals']+inv['fixed_short_originals'])==list(range(66))
m=pb.CpModelProto()
for i,r in enumerate(caps):
    assert r['domain']==i;v=m.variables.add();v.name=f'domain{i}-occupancy';v.domain.extend([0,r['capacity']])
for a,b in pairs:
    assert a<b and caps[a]['capacity']==caps[b]['capacity']==1;c=m.constraints.add();c.linear.vars.extend([a,b]);c.linear.coeffs.extend([1,1]);c.linear.domain.extend([0,1])
assert load(UNION/'audit/checks.json')['passed']
for r in load(UNION/'union-capacities.json'):
    c=m.constraints.add();c.linear.vars.extend(r['domains']);c.linear.coeffs.extend([1]*len(r['domains']));c.linear.domain.extend([0,r['capacity']])
c=m.constraints.add();c.linear.vars.extend(range(len(caps)));c.linear.coeffs.extend([1]*len(caps));c.linear.domain.extend([14,14]);actual=pb.CpModelProto();actual.ParseFromString((BASE/'models/000.pb').read_bytes());assert actual==m and not m.HasField('objective') and not m.HasField('solution_hint')
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'necessity-proof.json',{'statement':'Every feasible original center belongs to at least one retained closed domain. Assign it to any one such domain, even at overlaps/boundaries, and count assignments. Each count obeys its geometric capacity. Every conflict has separately unit-capacity endpoints and maximum cross-domain point distance smaller than the necessary cog separation, so their counts sum to at most one. Each union sum also obeys its independently audited bounding-box separation capacity. Fourteen originals therefore induce a satisfying assignment to this strengthened projection. Conversely a positive count vector need not have center coordinates or realizable original angles. All40 fixed first and12 short originals remain exact obligations.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'mandatory_cogs':14,'all66_originals_accounted_once':True,'conflict_endpoint_capacity1_verified':len(pairs),'union_capacity_rows_verified':len(load(UNION/'union-capacities.json')),'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
