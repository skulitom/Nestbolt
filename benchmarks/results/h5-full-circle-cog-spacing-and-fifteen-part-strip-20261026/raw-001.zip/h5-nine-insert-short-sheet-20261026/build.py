"""Use two inter-part bracket gaps and a three-insert stack on the short sheet."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-five-insert-short-sheet-repaired-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PROFILES=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json';OUT=ROOT/'output/h5-nine-insert-short-sheet-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(g,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;return affine_transform(g,[mi*c,-s,mi*s,c,*t['translation']])
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[OLD/n for n in ['first-sheet-placements.json','partial64-placements.json','audit/checks.json']]+[SRC/'items.json',SRC/'geometry.json',JOB,PROFILES,ROOT/'output/h5-fixed40-linear-distance-model-20261026/response-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New allocation: all three short-sheet bracket pairs now enclose an insert between separate filled outers. Replace short cog65 with four more inserts30/31/33/50 from the first sheet. To the right of the three bracket/insert groups, fit four vertical inserts side by side and two horizontal inserts above them. The short sheet contains six brackets and nine inserts. Its extra inserted area exceeds the removed cog area by29137.28106202mm2. All48 remaining first placements stay unchanged. The63-part partial requires first cogs63/64/65; this changes the neighborhood to36 fixed non-cogs and15 mandatory moving cogs. All prior40-fixed calls remain closed UNKNOWN or projection-positive; no exclusion is transferred.'})
assert load(OLD/'audit/checks.json')['passed'] and load(ROOT/'output/h5-fixed40-linear-distance-model-20261026/response-audit/checks.json')['status']=='UNKNOWN';job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};profiles={p['index']:p for p in load(PROFILES)};short=[];anchors=[]
def placed(item,profile,x,y):
    p=profiles[profile];t={'rotation_radians':p['rotation_radians'],'mirrored':p['mirrored'],'translation':[x-p['rotated_original_min'][0],y-p['rotated_original_min'][1]]};short.append({'part_id':items[item]['family'],'copy_index':items[item]['copy'],'sheet_id':'sheet-1','transform':t});anchors.append({'item':item,'profile':profile,'lower_left':[x,y]})
left=6.525
for brs,insert in zip([[21,22],[25,26],[28,29]],[32,34,35]):
    placed(brs[0],7,left,6.525);placed(brs[1],5,left+80.45,19.0);placed(insert,10,left+75.225,106.75);left+=330.675
for k,insert in enumerate([30,31,33,36]):placed(insert,8,left+k*110.225,6.525)
for k,insert in enumerate([37,50]):placed(insert,10,left+k*180.225,186.75)
first=[p for p in load(OLD/'first-sheet-placements.json') if ids[p['part_id'],p['copy_index']] not in [30,31,33,50]];assert len(first)==48 and len(short)==15 and Counter(p['part_id'] for p in short)=={'bracket':6,'insert':9};allp=first+short;placedids=[ids[p['part_id'],p['copy_index']] for p in allp];assert len(set(placedids))==63 and sorted(placedids+[63,64,65])==list(range(66));stocks=[[float(F(*v)) for v in row] for row in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};holes=vertices=0;pairs=[];edges=[]
for p in allp:
    i=ids[p['part_id'],p['copy_index']];f=families[p['part_id']];t=p['transform'];assert not t['mirrored'] or f['allow_mirror'];assert f['rotations']['kind']=='free' or any(abs(math.degrees(t['rotation_radians'])%360-d)<1e-8 for d in f['rotations']['degrees']);g=f['geometry'][0];filled=transform(Polygon(g['outer']),t);full=transform(Polygon(g['outer'],g.get('holes',[])),t);assert filled.is_valid and full.is_valid and len(full.interiors)==len(g.get('holes',[]));holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]));sheet=int(p['sheet_id'].split('-')[1]);polys[i]=(sheet,filled);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;edges.append({'item':i,'extra_margins_mm':extra})
for a,b in combinations(sorted(polys),2):
    sa,pa=polys[a];sb,pb=polys[b]
    if sa==sb:
        d=pa.distance(pb);assert pa.intersection(pb).area==0 and d>gap;pairs.append({'items':[a,b],'sheet_id':f'sheet-{sa}','distance_mm':d})
write(OUT/'first-sheet-placements.json',first);write(OUT/'short-sheet-placements.json',short);write(OUT/'short-sheet-anchors.json',anchors);write(OUT/'partial63-placements.json',allp);write(OUT/'placed-identities.json',placedids);write(OUT/'mandatory-first-additions.json',[63,64,65]);write(OUT/'original-pair-checks.json',pairs);write(OUT/'original-stock-checks.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':63,'first_sheet_originals':48,'short_sheet_originals':15,'short_counts':dict(Counter(p['part_id'] for p in short)),'moved_first_inserts':[30,31,33,50],'first48_transforms_unchanged':True,'three_inserts_between_separate_bracket_filled_outers':True,'part_in_hole_used':False,'mandatory_first_additions':[63,64,65],'all66_identities_accounted_once':True,'original_pair_checks':len(pairs),'stock_edge_checks':4*len(edges),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_original_pair_gap_mm':min(r['distance_mm'] for r in pairs),'required_native_pair_gap_mm':gap,'minimum_extra_stock_margin_mm':min(min(r['extra_margins_mm']) for r in edges),'short_highest_outer_y_mm':max(g.bounds[3] for s,g in polys.values() if s==1),'short_rightmost_outer_x_mm':max(g.bounds[2] for s,g in polys.values() if s==1),'old_fixed40_exclusion_not_applied':True,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
