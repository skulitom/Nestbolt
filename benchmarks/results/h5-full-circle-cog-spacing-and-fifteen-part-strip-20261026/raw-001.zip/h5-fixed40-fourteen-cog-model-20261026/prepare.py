"""Complete fourteen-cog necessary decision over certified continuous-cover domains."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];DOM=ROOT/'output/h5-fixed40-combined-domains-20261026';INV=ROOT/'output/h5-fixed40-cog-neighborhood-20261026';OUT=ROOT/'output/h5-fixed40-fourteen-cog-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(DOM/'audit/checks.json')['passed'];domains=load(DOM/'merged-domain-rectangles.json');caps=load(DOM/'audit/cell-capacities.json');conflicts=load(DOM/'audit/incompatible-cell-pairs.json');spec=load(INV/'next-neighborhood.json');assert spec['moving_count']==14 and len(domains)>0; M=len(domains); C=len(conflicts); V=392+15*M; K=29*M+C+469; assert all(caps[a]['capacity']==caps[b]['capacity']==1 for a,b in conflicts)
inputs=[p for p in (DOM/'audit').rglob('*') if p.is_file()]+[DOM/'merged-domain-rectangles.json',DOM/'result.json',INV/'next-neighborhood.json',INV/'checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'fixed_first_originals':spec['fixed_first_originals'],'mandatory_moving_first_cogs':spec['mandatory_moving_first_cogs'],'fixed_short_originals':spec['fixed_short_originals'],'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'rounded_cog_separation_units1000':247441,'method':'All14 first-sheet cog originals remain mandatory. Each chooses one of the independently audited necessary center rectangles. Domain occupancy counts equal all matching point flags and obey independently recomputed geometric capacities and incompatible-cell pair capacities, whose endpoints must each have capacity one. Ordered identical centers have x_i<=x_j; every one of91 pairs retains exact squared Euclidean separation >=247441^2 using integer multiplication. Coordinate domains and squares are bounded from the complete rectangle union. No angles are fixed, no seed poses are locked, no objective/hint is used. This is a new40-fixed necessary all-angle formulation, not a retry of an older call. Fully reconstruct/import before one20solver/30shared call.'})
m=pb.CpModelProto();mapping={'points':[],'occupancies':[],'pairs':[]}
def var(name,lo,hi):
    i=len(m.variables);m.variables.add(name=name,domain=[lo,hi]);return i
def linear(terms,lo,hi,en=()):
    vs=sorted(terms);m.constraints.add().CopyFrom(pb.ConstraintProto(enforcement_literal=en,linear=pb.LinearConstraintProto(vars=vs,coeffs=[terms[v] for v in vs],domain=[lo,hi])))
xb=[min(d['bounds_units1000'][0] for d in domains),max(d['bounds_units1000'][2] for d in domains)];yb=[min(d['bounds_units1000'][1] for d in domains),max(d['bounds_units1000'][3] for d in domains)]
for i in range(14):mapping['points'].append({'part':i,'original':spec['mandatory_moving_first_cogs'][i],'x':var(f'p{i}-x',*xb),'y':var(f'p{i}-y',*yb),'domains':[]})
for p in mapping['points']:
    for d in domains:
        f=var(f"p{p['part']}-domain{d['index']}",0,1);p['domains'].append(f);a,b,c,e=d['bounds_units1000'];linear({p['x']:1},a,c,[f]);linear({p['y']:1},b,e,[f])
    linear({f:1 for f in p['domains']},1,1)
for cap in caps:
    j=cap['domain'];v=var(f'domain{j}-occupancy',0,cap['capacity']);mapping['occupancies'].append(v);linear({**{p['domains'][j]:1 for p in mapping['points']},v:-1},0,0)
for a,b in conflicts:linear({mapping['occupancies'][a]:1,mapping['occupancies'][b]:1},0,1)
for i,j in combinations(range(14),2):
    a,b=mapping['points'][i],mapping['points'][j];dx=var(f'dx-{i}-{j}',0,xb[1]-xb[0]);dy=var(f'dy-{i}-{j}',yb[0]-yb[1],yb[1]-yb[0]);xx=var(f'dx2-{i}-{j}',0,(xb[1]-xb[0])**2);yy=var(f'dy2-{i}-{j}',0,(yb[1]-yb[0])**2);linear({b['x']:1,a['x']:-1,dx:-1},0,0);linear({b['y']:1,a['y']:-1,dy:-1},0,0)
    for v,square in [(dx,xx),(dy,yy)]:m.constraints.add().CopyFrom(pb.ConstraintProto(int_prod=pb.LinearArgumentProto(target=pb.LinearExpressionProto(vars=[square],coeffs=[1]),exprs=[pb.LinearExpressionProto(vars=[v],coeffs=[1]),pb.LinearExpressionProto(vars=[v],coeffs=[1])])))
    linear({xx:1,yy:1},247441**2,2**63-1);mapping['pairs'].append({'parts':[i,j],'dx':dx,'dy':dy,'dx2':xx,'dy2':yy})
assert len(m.variables)==V and len(m.constraints)==K;p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'mapping.json',mapping);write(OUT/'coordinate-bounds.json',{'x':xb,'y':yb});write(OUT/'inventory.json',[{'index':0,'parts':list(range(14)),'variables':V,'constraints':K,'model_sha256':digest(p),'solver_seconds':20,'domain_choices':14*M,'occupancy_variables':M,'cell_capacity_constraints':M,'incompatible_cell_constraints':C,'original_pairs':91,'integer_square_constraints':182,'source_angles':'all real','all66_originals_required':True}]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variables':V,'constraints':K,'solver_calls':0});print(load(OUT/'prepared.json'))
