"""Independent exact bounding-box capacity proofs for all proposed domain unions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed40-union-capacities-20261026';DOM=ROOT/'output/h5-fixed40-combined-domains-20261026';OUT=BASE/'audit';D=247441
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(DOM/'audit/checks.json')['passed'];ds=load(DOM/'merged-domain-rectangles.json');rows=load(BASE/'union-capacities.json');seen=set();corners=0
for r in rows:
    members=r['domains'];assert members==sorted(set(members)) and len(members)>=2 and tuple(members) not in seen;seen.add(tuple(members));bb=r['bounds_units1000'];axis=r['transverse_axis'];assert axis in [0,1]
    assert bb==[min(ds[i]['bounds_units1000'][a] for i in members) for a in [0,1]]+[max(ds[i]['bounds_units1000'][a] for i in members) for a in [2,3]]
    for i in members:
        b=ds[i]['bounds_units1000'];assert bb[0]<=b[0]<=b[2]<=bb[2] and bb[1]<=b[1]<=b[3]<=bb[3];corners+=4
    t=bb[axis+2]-bb[axis];span=bb[3-axis]-bb[1-axis];q=r['longitudinal_spacing_units'];assert 0<=t<D and (q-1)**2<D*D-t*t<=q*q and r['capacity']==span//q+1
write(OUT/'necessity-proof.json',{'statement':'Assign each actual center to a single retained domain. Every center assigned to a listed union lies within its certified bounding box. Its pairwise transverse difference is at most t<D; Euclidean separation at least D therefore implies absolute longitudinal difference at least sqrt(D²-t²), and integer differences are at least q=ceil(sqrt(D²-t²)). Ordering all such longitudinal coordinates shows N<=floor(span/q)+1. Hence sum of all listed domain occupancies obeys the cap, with no assumption that individual capacities equal one. Only valid cuts are required: completeness of this cut list is not needed for a negative conclusion.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'union_capacity_rows_verified':len(rows),'contained_domain_corners_verified':corners,'all_rounding_and_span_bounds_exact':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
