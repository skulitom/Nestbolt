"""Complete axis-band domain unions with independent whole-union separation capacities."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];DOM=ROOT/'output/h5-fixed40-combined-domains-20261026';PRIOR=ROOT/'output/h5-fixed40-capacity-projection-20261026';OUT=ROOT/'output/h5-fixed40-union-capacities-20261026';D=247441
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[DOM/'merged-domain-rectangles.json',DOM/'audit/checks.json',DOM/'audit/cell-capacities.json',PRIOR/'response-audit/checks.json',PRIOR/'response-audit/domain-occupancies.json'];assert load(PRIOR/'response-audit/checks.json')['status']=='OPTIMAL'
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_seconds':120,'method':'The occupancy projection placed11 counts across three overlapping-height large cells, exposing missing union capacities. For each axis and each pair of domain minimum/maximum edges less than247441 apart, include every entire domain within that band. Bound their union by its full bounding rectangle. If transverse span t<D, all cog pairs require integer longitudinal separation q=ceil(sqrt(D^2-t^2)), so at most floor(longitudinal_span/q)+1 centers lie in the whole union. Keep all useful distinct domain subsets at their tightest independently derived cap. This is valid for summed occupancy even when individual cells have capacity above1; it does not infer sum<=1 from mere incompatibility. No solver call.'})
ds=load(DOM/'merged-domain-rectangles.json');caps=load(DOM/'audit/cell-capacities.json');rows={};bands=0
for axis in [0,1]:
    lows=sorted({r['bounds_units1000'][axis] for r in ds});highs=sorted({r['bounds_units1000'][axis+2] for r in ds})
    for lo in lows:
        for hi in highs:
            if not 0<hi-lo<D:continue
            bands+=1;members=tuple(r['index'] for r in ds if lo<=r['bounds_units1000'][axis] and r['bounds_units1000'][axis+2]<=hi)
            if len(members)<2:continue
            bounds=[min(ds[i]['bounds_units1000'][a] for i in members) for a in [0,1]]+[max(ds[i]['bounds_units1000'][a] for i in members) for a in [2,3]];t=bounds[axis+2]-bounds[axis];span=bounds[3-axis]-bounds[1-axis];square=D*D-t*t;q=math.isqrt(square);q+=q*q<square;cap=span//q+1
            if cap>=min(14,sum(caps[i]['capacity'] for i in members)):continue
            row={'domains':list(members),'bounds_units1000':bounds,'transverse_axis':axis,'longitudinal_spacing_units':q,'capacity':cap}
            if members not in rows or cap<rows[members]['capacity']:rows[members]=row
        assert time.perf_counter()-start<120
result=sorted(rows.values(),key=lambda r:(len(r['domains']),r['domains']));old={r['domain']:r['count'] for r in load(PRIOR/'response-audit/domain-occupancies.json')};violations=[{'row':i,'occupancy':sum(old.get(j,0) for j in r['domains']),'capacity':r['capacity']} for i,r in enumerate(result) if sum(old.get(j,0) for j in r['domains'])>r['capacity']];assert violations
write(OUT/'union-capacities.json',result);write(OUT/'prior-projection-violations.json',violations);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'bands_examined':bands,'distinct_useful_union_capacities':len(result),'prior_positive_violations':len(violations),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
