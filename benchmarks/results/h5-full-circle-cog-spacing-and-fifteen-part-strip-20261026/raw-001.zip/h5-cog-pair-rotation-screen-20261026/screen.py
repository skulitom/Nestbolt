"""Diagnostic full-circle cog-pair bound from conservative eroded horizontal sections."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,LineString
from shapely.affinity import rotate
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-rotation-independent-geometry-20261026/original-cog-proof.json';OUT=ROOT/'output/h5-cog-pair-rotation-screen-20261026'
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'screen.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{SRC.relative_to(ROOT).as_posix():sha256(SRC.read_bytes()).hexdigest()},'limit_seconds':60,'phase_step_degrees':.5,'all360_degrees_examined':True,'horizontal_levels_mm':[-40,40,.5],'erosion_mm':.62,'method':'Screen720 rotation cells with midpoint phases and0.62mm erosion, greater than140.001mm times the half-cell angular width. For each horizontal level retain only the eroded connected section containing X0. Such intervals overlap for center separation d less than rightA-leftB. Evaluate every720x720 phase-cell pair and its best witness Y. Floating GEOS/math screen only; no formal universal bound claimed before independent exact certificates.'})
p=json.loads(SRC.read_bytes());g=Polygon([(a/b,c/d) for (a,b),(c,d) in p['centered_vertices_rational']]);ys=np.arange(-40,40.001,.5);left=[];right=[]
for k in range(720):
    shape=rotate(g,(k+.5)*.5,origin=(0,0)).buffer(-.62);ls=[];rs=[]
    for y in ys:
        section=shape.intersection(LineString([(-150,float(y)),(150,float(y))]));parts=[section] if section.geom_type=='LineString' else list(section.geoms);s=next(t for t in parts if t.bounds[0]<=0<=t.bounds[2]);ls.append(s.bounds[0]);rs.append(s.bounds[2])
    left.append(ls);right.append(rs);assert time.perf_counter()-start<60
left=np.asarray(left);right=np.asarray(right);best=np.full((720,720),-1.);witness=np.zeros((720,720),dtype=np.int16)
for j,y in enumerate(ys):
    candidate=right[:,j,None]-left[None,:,j];mask=candidate>best;best[mask]=candidate[mask];witness[mask]=j
i,k=np.unravel_index(np.argmin(best),best.shape);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'phase_cells':720,'phase_pairs':720**2,'horizontal_levels':len(ys),'minimum_pair_section_reach_mm':float(best[i,k]),'worst_phase_midpoints_degrees':[(i+.5)*.5,(k+.5)*.5],'worst_witness_y_mm':float(ys[witness[i,k]]),'screen_only':True,'formal_universal_bound_claimed':False,'solver_calls':0,'H5_complete':False});print(json.loads((OUT/'result.json').read_bytes()))
