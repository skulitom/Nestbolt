"""Audit a declared, closed occupancy projection without interpreting counts as coordinates."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,sys,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output'/sys.argv[1];RUN=BASE/'search';OUT=BASE/'response-audit'
assert BASE.parent==ROOT/'output' and BASE.is_dir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def model(p):
    v=pb.CpModelProto();v.ParseFromString(p.read_bytes());return v
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'base':BASE.relative_to(ROOT).as_posix(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for p in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=30 and budget['shared_seconds']==30 and budget['deadline_perf_counter']==budget['start_perf_counter']+30 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==20
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert census['solver_calls']==len(census['results'])==len(list(RUN.rglob('opened.json')))==1 and not census['pending_pairs'] and r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1
m=model(folder/'model.pb');assert m==model(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==20
response=pb.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert pb.CpSolverStatus.Name(response.status)==r['status'] and abs(response.wall_time-r['seconds'])<.2 and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-20) and r['seconds']<=r['stage_seconds'];sol=list(response.solution);active=0;positive=r['status'] in ['FEASIBLE','OPTIMAL']
if positive:
    assert len(sol)==len(m.variables) and sol[:28]==r['original_coordinates_units1000'] and sum(sol)==14
    for v,n in zip(m.variables,sol):assert any(a<=n<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    for c in m.constraints:
        assert not c.enforcement_literal and c.WhichOneof('constraint')=='linear';n=sum(sol[i]*coef for i,coef in zip(c.linear.vars,c.linear.coeffs));assert any(a<=n<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]));active+=1
    write(OUT/'domain-occupancies.json',[{'domain':i,'count':n} for i,n in enumerate(sol) if n])
else:assert r['status'] in ['INFEASIBLE','UNKNOWN'] and not sol
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'positive_variables_verified':len(sol),'positive_constraints_verified':active,'counts_are_not_coordinates':True,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
