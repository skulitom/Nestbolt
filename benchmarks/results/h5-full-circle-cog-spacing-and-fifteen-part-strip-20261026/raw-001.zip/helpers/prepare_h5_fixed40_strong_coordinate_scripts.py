"""One fresh full coordinate model at the independently certified254.3mm cog spacing."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for name in ['prepare_h5_fixed40_union_coordinate_model','audit_h5_fixed40_union_coordinate_model','run_h5_fixed40_union_coordinate_model','audit_h5_fixed40_union_coordinate_response']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8').replace('h5-fixed40-union-coordinate-model-20261026','h5-fixed40-strong-coordinate-model-20261026').replace('h5-fixed40-combined-domains-20261026','h5-fixed40-strong-domains-20261026').replace('h5-fixed40-union-capacities-20261026','h5-fixed40-strong-union-capacities-20261026').replace('247441','254297').replace('247444','254300').replace('2791','2846').replace('630 violations','639 violations')
    if name.startswith('prepare'):
        a="ROOT/'output/h5-fixed40-union-projection-20261026/response-audit/checks.json']";b="ROOT/'output/h5-fixed40-union-projection-20261026/response-audit/checks.json',ROOT/'output/h5-fixed40-union-coordinate-model-20261026/response-audit/checks.json',ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json']";assert a in s;s=s.replace(a,b)
        s=s.replace('This distinct full coordinate formulation adds2846','A new exact full-circle capsule proof increases source pair separation from247.444mm to254.3mm. This distinct full coordinate formulation uses its rounded254297-unit pair distances and adds2846')
    with (ROOT/'output'/f"{name.replace('union_coordinate','strong_coordinate')}.py").open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared one fresh stronger-distance coordinate model and independent audits.')
