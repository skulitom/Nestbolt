"""Add certified whole-union occupancy cuts to a fresh complete coordinate formulation."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
for name in ['prepare_h5_fixed40_fourteen_cog_model','audit_h5_fixed40_fourteen_cog_model','run_h5_fixed40_fourteen_cog_model','audit_h5_fixed40_fourteen_cog_response']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8').replace('h5-fixed40-fourteen-cog-model-20261026','h5-fixed40-union-coordinate-model-20261026')
    if name.startswith(('prepare','audit')) and not name.endswith('response'):
        s=rep(s,"load=lambda", "UNION=ROOT/'output/h5-fixed40-union-capacities-20261026'\nload=lambda")
        s=rep(s,'K=29*M+C+469','K=29*M+C+469+len(load(UNION/\'union-capacities.json\'))')
        if name.startswith('prepare'):
            s=rep(s,"INV/'checks.json']", "INV/'checks.json',UNION/'union-capacities.json',UNION/'audit/checks.json',UNION/'audit/necessity-proof.json',ROOT/'output/h5-fixed40-fourteen-cog-model-20261026/response-audit/checks.json',ROOT/'output/h5-fixed40-union-projection-20261026/response-audit/checks.json']")
            s=rep(s,'for i,j in combinations(range(14),2):', "assert load(UNION/'audit/checks.json')['passed']\nfor r in load(UNION/'union-capacities.json'):linear({mapping['occupancies'][i]:1 for i in r['domains']},0,r['capacity'])\nfor i,j in combinations(range(14),2):")
            s=s.replace('This is a new40-fixed necessary all-angle formulation, not a retry of an older call.','This distinct full coordinate formulation adds2791 newly certified whole-union occupancy capacities, eliminating the documented630 violations of the former count projection. The earlier coordinate and both occupancy calls are closed. No old call is extended or reseeded.')
            s=rep(s,"'integer_square_constraints':182", "'union_capacity_constraints':len(load(UNION/'union-capacities.json')),'integer_square_constraints':182")
        else:
            s=rep(s,'for i,j in combinations(range(14),2):', "assert load(UNION/'audit/checks.json')['passed']\nfor r in load(UNION/'union-capacities.json'):row({mapping['occupancies'][i]:1 for i in r['domains']},[0,r['capacity']])\nfor i,j in combinations(range(14),2):")
            s=s.replace('certified capacities and incompatible pairs hold for every domain choice.','certified individual/whole-union capacities and incompatible pairs hold for every domain choice.')
            s=rep(s,"'integer_products_verified':182", "'union_capacity_constraints_verified':len(load(UNION/'union-capacities.json')),'integer_products_verified':182")
    p=ROOT/'output'/f"{name.replace('fourteen_cog','union_coordinate')}.py"
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared fresh complete coordinate-plus-union formulation, one20/30-second call.')
