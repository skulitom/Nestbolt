"""Create a separately bounded mandatory fourteen-cog decision for the new owner set."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
for name in ['prepare_h5_fourteen_cog_necessary_model','audit_h5_fourteen_cog_necessary_model','run_h5_fourteen_cog_necessary_model','audit_h5_fourteen_cog_necessary_response']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8')
    s=s.replace('h5-fourteen-cog-necessary-model-20261026','h5-fixed40-fourteen-cog-model-20261026').replace('h5-fixed43-combined-domains-20261026','h5-fixed40-combined-domains-20261026').replace('h5-cog-space-screen-audit-20261026','h5-fixed40-cog-neighborhood-20261026')
    s=s.replace('new43-fixed','new40-fixed').replace('fixed43/short9','fixed40/short12').replace('the43-fixed/fixed-short9','the40-fixed/fixed-short12')
    if name.startswith('prepare'):
        s=replace(s,"and len(domains)==135", "and len(domains)>0; M=len(domains); C=len(conflicts); V=392+15*M; K=29*M+C+469; assert all(caps[a]['capacity']==caps[b]['capacity']==1 for a,b in conflicts)")
        s=s.replace('one of135 independently','one of the independently').replace('obey135 geometric capacities plus2409 incompatible-cell pair capacities','obey independently recomputed geometric capacities and incompatible-cell pair capacities, whose endpoints must each have capacity one')
        for a,b in [('==2417','==V'),('==6793','==K'),("':2417","':V"),("':6793","':K"),("':1890","':14*M"),("':135","':M"),("':2409","':C")]:s=s.replace(a,b)
    elif name=='audit_h5_fourteen_cog_necessary_model':
        s=replace(s,"for a,b in conflicts:row", "for a,b in conflicts:\n    assert caps[a]['capacity']==caps[b]['capacity']==1\n    row")
        s=replace(s,"assert m==proto", "M=len(ds); C=len(conflicts); V=392+15*M; K=29*M+C+469\nassert m==proto")
        for a,b in [('==2417','==V'),('==6793','==K'),("':2417","':V"),("':6793","':K"),("':1890","':14*M"),("':135","':M"),("':2409","':C")]:s=s.replace(a,b)
    path=ROOT/'output'/f"{name.replace('fourteen_cog_necessary','fixed40_fourteen_cog')}.py"
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared one fresh 20-second solver / 30-second shared call and audits.')
