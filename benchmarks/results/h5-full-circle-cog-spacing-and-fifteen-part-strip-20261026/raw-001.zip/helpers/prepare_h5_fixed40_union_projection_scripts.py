"""Build a new projection with exact capacity bounds across unions of nearby cells."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
for name in ['prepare_h5_fixed40_capacity_projection','audit_h5_fixed40_capacity_projection','run_h5_fixed40_capacity_projection']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8').replace('h5-fixed40-capacity-projection-20261026','h5-fixed40-union-projection-20261026')
    if name.startswith('prepare'):
        s=rep(s,"PRIOR=ROOT/'output/h5-fixed40-fourteen-cog-model-20261026'", "PRIOR=ROOT/'output/h5-fixed40-capacity-projection-20261026';UNION=ROOT/'output/h5-fixed40-union-capacities-20261026'")
        s=rep(s,"PRIOR/'response-audit/checks.json']", "PRIOR/'response-audit/checks.json',UNION/'union-capacities.json',UNION/'audit/checks.json',UNION/'audit/necessity-proof.json']")
        s=rep(s,"['status']=='UNKNOWN'", "['status']=='OPTIMAL' and load(UNION/'audit/checks.json')['passed']")
        s=rep(s,"m.constraints.add(linear=pb.LinearConstraintProto(vars=list(range(len(caps)))", "for r in load(UNION/'union-capacities.json'):m.constraints.add(linear=pb.LinearConstraintProto(vars=r['domains'],coeffs=[1]*len(r['domains']),domain=[0,r['capacity']]))\nm.constraints.add(linear=pb.LinearConstraintProto(vars=list(range(len(caps)))")
        s=s.replace('Distinct occupancy-only necessary projection after the complete coordinate call closed UNKNOWN.','New union-capacity projection after the plain occupancy call closed positive with630 violations of independently valid union capacities.').replace('Drop coordinates and squared pair distances entirely, retaining all66 original obligations.','Add all2791 independently audited domain-union capacity constraints. Retain all66 original obligations and drop coordinates and squared distances.').replace('no retry of the closed coordinate formulation','no retry of the closed coordinate or plain occupancy formulations')
    elif name.startswith('audit'):
        s=rep(s,"OUT=BASE/'model-audit'", "UNION=ROOT/'output/h5-fixed40-union-capacities-20261026';OUT=BASE/'model-audit'")
        s=rep(s,"c=m.constraints.add();c.linear.vars.extend(range(len(caps)))", "assert load(UNION/'audit/checks.json')['passed']\nfor r in load(UNION/'union-capacities.json'):\n    c=m.constraints.add();c.linear.vars.extend(r['domains']);c.linear.coeffs.extend([1]*len(r['domains']));c.linear.domain.extend([0,r['capacity']])\nc=m.constraints.add();c.linear.vars.extend(range(len(caps)))")
        s=s.replace('Fourteen originals therefore induce a satisfying assignment to this projection.','Each union sum also obeys its independently audited bounding-box separation capacity. Fourteen originals therefore induce a satisfying assignment to this strengthened projection.')
        s=rep(s,"'actual_import_export_verified':True", "'union_capacity_rows_verified':len(load(UNION/'union-capacities.json')),'actual_import_export_verified':True")
    p=ROOT/'output'/f"{name.replace('capacity_projection','union_projection')}.py"
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared fresh union-capacity projection, one20/30-second call.')
