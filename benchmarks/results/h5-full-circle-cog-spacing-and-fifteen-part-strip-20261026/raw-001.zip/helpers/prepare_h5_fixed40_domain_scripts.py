"""Derive fresh, dimension-independent domain checks for the changed 40-owner set."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
for name in ['build_h5_fixed43_support_domains','audit_h5_fixed43_support_domains','refine_h5_fixed43_support_domains','audit_h5_fixed43_combined_domains']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8')
    for a,b in [('h5-fixed43-','h5-fixed40-'),('h5-released-twelve-cog-space-20261026','h5-fixed40-cog-space-20261026'),('h5-cog-space-screen-audit-20261026','h5-fixed40-cog-neighborhood-20261026')]:
        if a in s:s=s.replace(a,b)
    for a,b in [('==43','==40'),("':43","':40"),('all43','all40'),('the43','the40'),('43 fixed','40 fixed')]:s=s.replace(a,b)
    if name=='audit_h5_fixed43_support_domains':
        s=replace(s,'len(expected)==len(rects)==55','len(expected)==len(rects)==52')
        s=replace(s,'len(allowed)+len(excluded)==3612','len(allowed)+len(excluded)==(len(xs)-1)*(len(ys)-1)')
        s=replace(s,"'source_rectangles_verified':55","'source_rectangles_verified':len(rects)")
        s=replace(s,"'grid_cells_verified':3612","'grid_cells_verified':(len(xs)-1)*(len(ys)-1)")
    if name=='audit_h5_fixed43_combined_domains':
        s=replace(s,"seed_checks=[];center=", "# Count conflicts require unit capacity independently at both endpoints.\nassert all(caps[a]['capacity']==caps[b]['capacity']==1 for a,b in conflicts)\nseed_checks=[];center=")
        s=replace(s,"'continuous_boundary_coverage_verified':True", "'all_conflict_endpoints_separately_capacity1':True,'continuous_boundary_coverage_verified':True")
    path=ROOT/'output'/f"{name.replace('fixed43','fixed40')}.py"
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared four fresh fixed40 domain scripts; no solver call.')
