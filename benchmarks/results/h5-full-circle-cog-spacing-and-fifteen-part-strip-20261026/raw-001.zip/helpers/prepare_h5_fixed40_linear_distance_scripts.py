"""Use a certified inscribed32-gon to expose pair separation as linear disjunctions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math
ROOT=Path(__file__).resolve().parents[1];GEOM=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';GEOM.mkdir();D=254297
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
vertices=[[math.trunc((D-1)*math.cos(2*math.pi*i/32)),math.trunc((D-1)*math.sin(2*math.pi*i/32))] for i in range(32)];facets=[]
for a,b in zip(vertices,vertices[1:]+vertices[:1]):
    n=[b[1]-a[1],a[0]-b[0]];rhs=n[0]*a[0]+n[1]*a[1];assert rhs>0 and all(n[0]*v[0]+n[1]*v[1]<=rhs for v in vertices);facets.append({'normal':n,'rhs':rhs})
assert all(x*x+y*y<D*D for x,y in vertices)
write(GEOM/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{'output/h5-fixed40-strong-coordinate-model-20261026/response-audit/checks.json':sha256((ROOT/'output/h5-fixed40-strong-coordinate-model-20261026/response-audit/checks.json').read_bytes()).hexdigest()},'method':'New linear necessary formulation after the squared-distance model closed UNKNOWN. A32-vertex integer polygon lies strictly inside the254297-unit forbidden center-distance disk. Every valid cog pair must be outside at least one polygon edge. This is encoded with a chosen linear facet for each pair, replacing nonlinear square products. All center domains and certified union capacities remain complete. New20solver/30shared call, no retry.'})
write(GEOM/'vertices.json',vertices);write(GEOM/'facets.json',facets)
for mode,name in [('prepare','prepare_h5_fixed40_strong_coordinate_model'),('audit','audit_h5_fixed40_strong_coordinate_model')]:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8').replace('h5-fixed40-strong-coordinate-model-20261026','h5-fixed40-linear-distance-model-20261026')
    s=rep(s,"load=lambda", "FACETS=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026'\nload=lambda")
    if mode=='prepare':
        s=rep(s,'V=392+15*M; K=29*M+C+469+', 'V=28+15*M+91*32; K=29*M+C+3030+')
        s=rep(s,"ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json']", "ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json',FACETS/'plan.json',FACETS/'vertices.json',FACETS/'facets.json',ROOT/'output/h5-fixed40-strong-coordinate-model-20261026/response-audit/checks.json']")
        begin=s.index('for i,j in combinations(range(14),2):');end=s.index('assert len(m.variables)',begin)
        s=s[:begin]+'''facets=load(FACETS/'facets.json')
for i in range(13):linear({mapping['points'][i+1]['x']:1,mapping['points'][i]['x']:-1},0,2**63-1)
for i,j in combinations(range(14),2):
    a,b=mapping['points'][i],mapping['points'][j];flags=[]
    for k,facet in enumerate(facets):
        nx,ny=facet['normal'];flag=var(f'pair-{i}-{j}-facet{k}',0,1);flags.append(flag);linear({b['x']:nx,a['x']:-nx,b['y']:ny,a['y']:-ny},facet['rhs'],2**63-1,[flag])
    linear({f:1 for f in flags},1,1);mapping['pairs'].append({'parts':[i,j],'facets':flags})
''' +s[end:]
        s=s.replace('every one of91 pairs retains exact squared Euclidean separation >=254297^2 using integer multiplication','every one of91 pairs chooses one of32 outward integer polygon facets; the entire polygon is certified strictly inside the forbidden254297-unit disk').replace('Coordinate domains and squares are bounded','Coordinate domains are bounded').replace("'integer_square_constraints':182","'linear_pair_facet_constraints':91*32")
    else:
        s=rep(s,'V=392+15*M; K=29*M+C+469+', 'V=28+15*M+91*32; K=29*M+C+3030+')
        begin=s.index('for i,j in combinations(range(14),2):');end=s.index('M=len(ds);',begin)
        s=s[:begin]+'''vertices=load(FACETS/'vertices.json');facets=load(FACETS/'facets.json');assert len(vertices)==len(facets)==32 and len(set(map(tuple,vertices)))==32
for k,(a,b) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
    nx,ny=b[1]-a[1],a[0]-b[0];rhs=nx*a[0]+ny*a[1];assert facets[k]=={'normal':[nx,ny],'rhs':rhs} and rhs>0 and all(nx*x+ny*y<=rhs for x,y in vertices)
    assert a[0]**2+a[1]**2<254297**2
    c=vertices[(k+2)%32];assert (b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])>0
for i in range(13):row({mapping['points'][i+1]['x']:1,mapping['points'][i]['x']:-1},[0,2**63-1])
for i,j in combinations(range(14),2):
    p,q=mapping['points'][i],mapping['points'][j];flags=[]
    for k,f in enumerate(facets):
        nx,ny=f['normal'];v=variable(f'pair-{i}-{j}-facet{k}',[0,1]);flags.append(v);row({q['x']:nx,p['x']:-nx,q['y']:ny,p['y']:-ny},[f['rhs'],2**63-1],[v])
    row(dict.fromkeys(flags,1),[1,1]);mapping['pairs'].append({'parts':[i,j],'facets':flags})
''' +s[end:]
        s=s.replace('Auxiliary differences and exact integer products represent that necessary squared norm without approximation.','Every integer vertex of the strict convex32-gon has norm less than254297. Convexity of the disk puts the entire polygon inside the forbidden distance disk; its exact supporting edges reconstruct the polygon. Therefore every valid pair lies outside at least one facet. Selecting one such facet is a necessary linear relaxation, with no assumption that every positive polygon-separated vector reaches the full Euclidean distance.').replace("'exact_squared_pair_constraints_verified':91", "'linear_separated_original_pairs_verified':91").replace("'integer_products_verified':182", "'integer_polygon_facets_verified':32,'linear_pair_rows_verified':91*32")
    p=ROOT/'output'/f"{name.replace('strong_coordinate','linear_distance')}.py"
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_fixed40_strong_coordinate_model.py').read_text().replace('h5-fixed40-strong-coordinate-model-20261026','h5-fixed40-linear-distance-model-20261026')
with (ROOT/'output/run_h5_fixed40_linear_distance_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_fixed40_strong_coordinate_response.py').read_text().replace('h5-fixed40-strong-coordinate-model-20261026','h5-fixed40-linear-distance-model-20261026')
s=rep(s,'assert distance2>=254297**2;', "assert any(f['normal'][0]*(u-x)+f['normal'][1]*(v-y)>=f['rhs'] for f in load(ROOT/'output/h5-fixed40-linear-distance-geometry-20261026/facets.json'));")
s=s.replace("'squared_distance_units':distance2", "'squared_distance_units':distance2,'full254297_distance_passed':distance2>=254297**2")
with (ROOT/'output/audit_h5_fixed40_linear_distance_response.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a new linear32-facet pair model; every facet polygon is independently audited.')
