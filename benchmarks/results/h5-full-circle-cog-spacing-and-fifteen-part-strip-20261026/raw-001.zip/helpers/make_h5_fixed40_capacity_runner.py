from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_fourteen_cog_necessary_model.py').read_text().replace('h5-fourteen-cog-necessary-model-20261026','h5-fixed40-capacity-projection-20261026').replace('One mandatory fourteen-cog necessary decision','One necessary14 occupancy projection')
with (ROOT/'output/run_h5_fixed40_capacity_projection.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
