"""Reuse immutable covered rectangles, recomputing every capacity at the new certified separation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-fixed40-combined-domains-20261026';NEW=ROOT/'output/h5-fixed40-strong-domains-20261026';PROOF=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
assert load(PROOF/'checks.json')['passed'] and load(OLD/'audit/checks.json')['passed'];NEW.mkdir();shutil.copyfile(__file__,NEW/'prepare.py')
paths=[OLD/'merged-domain-rectangles.json',OLD/'result.json',OLD/'audit/checks.json',PROOF/'checks.json',PROOF/'necessity-proof.json'];write(NEW/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'The40 fixed original transforms and complete geometric domain cover are unchanged. Copy only the185 exact domain rectangles and geometric construction summary byte-for-byte. Re-audit the full original tree/rectangles and newly compute capacities/conflicts from254300 source separation minus3micrometres for flooring. No old capacity or conflict row is inherited.'})
for n in ['merged-domain-rectangles.json','result.json']:shutil.copyfile(OLD/n,NEW/n)
s=(ROOT/'output/audit_h5_fixed40_combined_domains.py').read_text(encoding='utf-8')
s=rep(s,"OUT=BASE/'audit'", "STRONG=ROOT/'output/h5-fixed40-strong-domains-20261026';NEWPROOF=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit';OUT=STRONG/'audit'")
s=rep(s,"paths=[p for p in BASE.rglob", "paths=[STRONG/'plan.json',STRONG/'merged-domain-rectangles.json',NEWPROOF/'checks.json',NEWPROOF/'necessity-proof.json']+[p for p in BASE.rglob")
s=rep(s,'D=247441;assert 3*3>2;', "assert load(NEWPROOF/'checks.json')['passed'] and load(NEWPROOF/'checks.json')['original_all_angle_center_separation_units1000']==254300;assert digest(STRONG/'merged-domain-rectangles.json')==digest(BASE/'merged-domain-rectangles.json')\nD=254297;assert 3*3>2;")
s=s.replace('247444','254300').replace('247441','254297')
with (ROOT/'output/audit_h5_fixed40_strong_domains.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['build_h5_fixed40_union_capacities','audit_h5_fixed40_union_capacities']:
    s=(ROOT/'output'/f'{name}.py').read_text(encoding='utf-8').replace('h5-fixed40-combined-domains-20261026','h5-fixed40-strong-domains-20261026').replace('h5-fixed40-union-capacities-20261026','h5-fixed40-strong-union-capacities-20261026').replace('247441','254297')
    with (ROOT/'output'/f"{name.replace('union_capacities','strong_union_capacities')}.py").open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent254.3mm capacity derivations; geometric cover preserved exactly.')
