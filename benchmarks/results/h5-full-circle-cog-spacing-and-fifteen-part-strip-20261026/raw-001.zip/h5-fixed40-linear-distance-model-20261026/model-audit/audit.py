"""Independent complete protobuf reconstruction of fourteen mandatory cog centers."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed40-linear-distance-model-20261026';DOM=ROOT/'output/h5-fixed40-strong-domains-20261026';OUT=BASE/'model-audit'
UNION=ROOT/'output/h5-fixed40-strong-union-capacities-20261026'
FACETS=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reconstruct every variable, bound, profile-domain equality, occupancy sum/capacity, conflict and squared-distance constraint from independent domain certificates. Verify all66 identities, identical-cog relabelling, no hints/objective, arithmetic bounds and actual import/export.'})
spec=load(BASE/'plan.json')
for n,h in spec['inputs'].items():assert digest(ROOT/n)==h,n
assert load(DOM/'audit/checks.json')['passed'];assert sorted(spec['fixed_first_originals']+spec['mandatory_moving_first_cogs']+spec['fixed_short_originals'])==list(range(66)) and len(spec['mandatory_moving_first_cogs'])==14
ds=load(DOM/'merged-domain-rectangles.json');caps=load(DOM/'audit/cell-capacities.json');conflicts=load(DOM/'audit/incompatible-cell-pairs.json');xb=[min(d['bounds_units1000'][0] for d in ds),max(d['bounds_units1000'][2] for d in ds)];yb=[min(d['bounds_units1000'][1] for d in ds),max(d['bounds_units1000'][3] for d in ds)];assert load(BASE/'coordinate-bounds.json')=={'x':xb,'y':yb};m=pb.CpModelProto();mapping={'points':[],'occupancies':[],'pairs':[]}
def variable(name,domain):
    i=len(m.variables);m.variables.add(name=name,domain=domain);return i
def row(terms,domain,en=()):
    items=sorted(terms.items());c=m.constraints.add();c.enforcement_literal.extend(en);c.linear.vars.extend(i for i,v in items);c.linear.coeffs.extend(v for i,v in items);c.linear.domain.extend(domain)
for i,original in enumerate(spec['mandatory_moving_first_cogs']):mapping['points'].append({'part':i,'original':original,'x':variable(f'p{i}-x',xb),'y':variable(f'p{i}-y',yb),'domains':[]})
for point in mapping['points']:
    for d in ds:
        j=d['index'];flag=variable(f"p{point['part']}-domain{j}",[0,1]);point['domains'].append(flag);bb=d['bounds_units1000'];row({point['x']:1},[bb[0],bb[2]],[flag]);row({point['y']:1},[bb[1],bb[3]],[flag])
    row(dict.fromkeys(point['domains'],1),[1,1])
for j,cap in enumerate(caps):
    assert cap['domain']==j;v=variable(f'domain{j}-occupancy',[0,cap['capacity']]);mapping['occupancies'].append(v);row({**{p['domains'][j]:1 for p in mapping['points']},v:-1},[0,0])
for a,b in conflicts:
    assert caps[a]['capacity']==caps[b]['capacity']==1
    row({mapping['occupancies'][a]:1,mapping['occupancies'][b]:1},[0,1])
assert load(UNION/'audit/checks.json')['passed']
for r in load(UNION/'union-capacities.json'):row({mapping['occupancies'][i]:1 for i in r['domains']},[0,r['capacity']])
vertices=load(FACETS/'vertices.json');facets=load(FACETS/'facets.json');assert len(vertices)==len(facets)==32 and len(set(map(tuple,vertices)))==32
for k,(a,b) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
    nx,ny=b[1]-a[1],a[0]-b[0];rhs=nx*a[0]+ny*a[1];assert facets[k]=={'normal':[nx,ny],'rhs':rhs} and rhs>0 and all(nx*x+ny*y<=rhs for x,y in vertices)
    assert a[0]**2+a[1]**2<254297**2
    c=vertices[(k+2)%32];assert (b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])>0
for i in range(13):row({mapping['points'][i+1]['x']:1,mapping['points'][i]['x']:-1},[0,2**63-1])
for i,j in combinations(range(14),2):
    p,q=mapping['points'][i],mapping['points'][j];flags=[]
    for k,f in enumerate(facets):
        nx,ny=f['normal'];v=variable(f'pair-{i}-{j}-facet{k}',[0,1]);flags.append(v);row({q['x']:nx,p['x']:-nx,q['y']:ny,p['y']:-ny},[f['rhs'],2**63-1],[v])
    row(dict.fromkeys(flags,1),[1,1]);mapping['pairs'].append({'parts':[i,j],'facets':flags})
M=len(ds); C=len(conflicts); V=28+15*M+91*32; K=29*M+C+3030+len(load(UNION/'union-capacities.json'))
assert m==proto(BASE/'models/000.pb') and mapping==load(BASE/'mapping.json') and len(m.variables)==V and len(m.constraints)==K and not m.HasField('objective') and not m.HasField('solution_hint')
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'all14_original_cogs_required':True,'all66_identities_accounted_once':True,'statement':'Each source-feasible cog center floors into a certified retained domain. Identical cog copies can be relabelled by increasing X without changing any fixed first/short obligation or allowed orientation. Every one of91 source pair distances remains at least254297 units after conservative rounding. Every integer vertex of the strict convex32-gon has norm less than254297. Convexity of the disk puts the entire polygon inside the forbidden distance disk; its exact supporting edges reconstruct the polygon. Therefore every valid pair lies outside at least one facet. Selecting one such facet is a necessary linear relaxation, with no assumption that every positive polygon-separated vector reaches the full Euclidean distance. Domain occupancies are exact sums of selected flags; certified individual/whole-union capacities and incompatible pairs hold for every domain choice. A negative excludes the40-fixed/fixed-short12 neighborhood at all real cog angles and continuous centers. A positive is only necessary and must still be realized by original cog angles/geometry. No first-sheet cog is omitted and no old seed is locked.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':V,'constraints':K,'mandatory_original_cogs':14,'domain_choices_verified':14*M,'occupancy_counts_verified':M,'incompatible_cell_constraints_verified':C,'linear_separated_original_pairs_verified':91,'union_capacity_constraints_verified':len(load(UNION/'union-capacities.json')),'integer_polygon_facets_verified':32,'linear_pair_rows_verified':91*32,'all66_identities_accounted_once':True,'no_objective_or_hints':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
