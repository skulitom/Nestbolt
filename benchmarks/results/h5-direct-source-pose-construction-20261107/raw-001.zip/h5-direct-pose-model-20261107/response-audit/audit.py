from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import math,json,time,shutil
import numpy as np
from h5_direct_pose_model_20261107 import Objective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-pose-model-20261107';S=BASE/'search';OUT=BASE/'response-audit';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');model=load(BASE/'model.json');obj=Objective(model);r=load(S/'response.json');result=load(S/'result.json');process=load(S/'process.json');opened=load(S/'opened.json');plan=load(S/'plan.json');job=load(S/'job.json');bounds=np.asarray(model['bounds']);controls=load(BASE/'audit/optimizer-controls.json')
assert load(BASE/'audit/checks.json')['passed'] and opened['options']==controls['options'] and opened['method']=='L-BFGS-B' and opened['parameters']==68 and opened['analytic_jacobian'] and opened['model_sha256']==digest(BASE/'model.json')
records=sorted((S/'incumbents').glob('*.json'));assert len(records)==r['incumbents']==51 and r['evaluations']==64 and r['status']=='TIME_STOP' and r['numerical_result'] is None and r['optimizer_calls']==1
last=math.inf;last_eval=0
for i,p in enumerate(records):
    saved=load(p);x=np.asarray(saved['values']);energy,g=obj.evaluate(x);assert energy==saved['objective_mm2']<last and np.array_equal(g,saved['gradient']) and np.all(x>=bounds[:,0]) and np.all(x<=bounds[:,1]);assert saved['sequence']==i and last_eval<saved['evaluation']<=64;last=energy;last_eval=saved['evaluation']
assert r['best_values']==load(records[-1])['values'] and r['best_objective_mm2']==last==result['best_objective_mm2'];energy,g,details=obj.evaluate(r['best_values'],True);assert np.array_equal(g,r['best_gradient']) and details==r['best_details'] and energy==r['best_objective_mm2']
for kind in ['original','clearance']:assert abs(sum(t['area_mm2'] for t in details['positive_terms'] if t['kind']==kind)-details[kind+'_overlap_area_mm2'])<1e-7
rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json');values=r['best_values'];pose_changes=[]
for o in model['owners']:
    i=o['owner'];angle=values[o['angle_coordinate']]/140 if o['angle_coordinate'] is not None else o['rotation_radians'];xy=[values[2*i],values[2*i+1]]
    if o['angle_coordinate'] is not None:
        c,s=math.cos(angle),math.sin(angle);px,py=o['source_center'];xy=[xy[0]-(px*c-py*s),xy[1]-(px*s+py*c)];pose_changes.append({'identity':o['identity'],'initial_degrees':math.degrees(o['rotation_radians']),'final_degrees':math.degrees(angle),'legal_free_rotation':True})
    rows.append({'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':o['mirrored'],'translation':xy}})
assert rows==load(S/'candidate-source66.json');spec=load(FIRST/'plan.json');expected=list(map(tuple,load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json')['full66_identities']));source=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert source==load(S/'original-source-checks.json') and not source['valid'] and source['pair_failures']==32 and source['stock_failures']==0 and source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026;assert abs(sum(t['intersection_area_mm2'] for t in source['pairs'])-details['original_overlap_area_mm2'])<1e-7
write(OUT/'replayed-source-checks.json',source);write(OUT/'cog-angle-changes.json',pose_changes);bad=[p for p in source['pairs'] if not p['passed']];write(OUT/'collision-details.json',{'pair_failures':len(bad),'positive_area_intersections':sum(p['intersection_area_mm2']>0 for p in bad),'clearance_only_failures':sum(p['intersection_area_mm2']==0 for p in bad),'summed_pairwise_intersection_area_mm2':sum(p['intersection_area_mm2'] for p in bad),'failing_pairs':bad,'scope':'This invalid candidate only;summedareas can doublecount.No allocation exclusion.'})
assert r['allocated_optimizer_seconds']==opened['allocated_optimizer_seconds'] and r['optimizer_slice_overrun_seconds']==max(0,r['returned_optimizer_seconds']-r['allocated_optimizer_seconds'])>0
assert r['algorithm_seconds_including_preparation']<=result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0
assert process['exit_code']==job['error_code']==job['reason_code']==job['active_processes']==0 and job['closed'] and process['job']==job and job['peak_job_committed_memory']<2**31 and process['tree_closed'] and result['source_checker_calls']==1 and result['native_calls']==0
charges=load(S/'preparation-charges.json');assert sum(charges.values())==plan['preparation_seconds_charged'];assert charges['complete_consumed_source_candidate']==load(ROOT/'output/h5-target-cog-model-20261107/search/process.json')['seconds_including_preparation'];assert charges['complete_new_geometry_and_model_preparation']==load(ROOT/'output/h5-direct-pose-preparation-process-20261107/prepare.json')['complete_seconds']
inputs=[Path(__file__),ROOT/'output/h5_direct_pose_model_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json',ROOT/'output/h5-direct-pose-preparation-process-20261107/prepare.json']+[BASE/n for n in ['plan.json','model.json','initial-objective.json','seed-source-checks.json','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json']]+[FIRST/n for n in ['plan.json','fixed29.json','short9-source.json']]+[S/n for n in ['plan.json','supervisor-opened.json','opened.json','preparation-charges.json','response.json','result.json','process.json','job.json','candidate-source66.json','original-source-checks.json']]+records
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    d=load(p)
    if not isinstance(d,dict):continue
    for name,h in {**d.get('inputs',{}),**d.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
for name,record in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==record['sha256']
write(OUT/'source-bindings.json',bindings);write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replay all51strictly improving68parameter objective/gradient records and64evaluation counters;reconstruct all12actualcontinuouscogrotations and all66originalcontours;independently check every originalsourcepair/stock/identity/hole. Reconcile exact charges,time-stop withpreserved.0760655secondsolve-slice overrun,and56.2734/56.3403algorithm/sharedtotals. All descendants close. No optimizerresult beyondtime-stop is fabricated,no invalid sourcecandidate reachesnative,andtheclosedcallcannot be extended/reseeded.'})
initial=load(BASE/'initial-objective.json');checks={'passed':True,'seconds':time.perf_counter()-started,'source_bindings':len(bindings),'closed_optimizer_calls':1,'optimizer_status':'TIME_STOP','numerical_return_present':False,'improving_points_verified':51,'function_evaluations':64,'initial_objective_mm2':initial['energy_mm2'],'best_objective_mm2':energy,'initial_original_overlap_mm2':initial['original_overlap_area_mm2'],'best_original_overlap_mm2':details['original_overlap_area_mm2'],'continuous_cog_angles_verified':12,'originals':66,'same_sheet_pairs':1632,'stock_edges':264,'holes':90,'hole_vertices':10026,'source_pair_failures':32,'source_stock_failures':0,'source_valid66':False,'preparation_seconds_charged':sum(charges.values()),'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'optimizer_slice_overrun_seconds':r['optimizer_slice_overrun_seconds'],'all_descendants_closed':True,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
