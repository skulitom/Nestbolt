from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from hashlib import sha256
from datetime import datetime,timezone
import math,json,time,copy,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_direct_pose_model_20261107 import Objective,source_pose,source_rows,boundary_gradient,transformed
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-pose-model-20261107';OUT=BASE/'audit';B=ROOT/'output/h5-target-cog-model-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');model=load(BASE/'model.json');job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(FIRST/'plan.json');fixed=load(FIRST/'fixed29.json');short=load(FIRST/'short9-source.json');old=load(B/'mapping.json')['owners'];oldrows=load(B/'search/candidate-source66.json');byid={(r['part_id'],r['copy_index']):r for r in oldrows};proofs=load(BASE/'clearance-supports.json');bounds=np.asarray(model['bounds']);initial=np.asarray(model['initial']);assert len(initial)==68 and bounds.shape==(68,2) and np.all(initial>=bounds[:,0]) and np.all(initial<=bounds[:,1])
def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def canonical(v):
    p=[tuple(map(F,x)) for x in v]
    if sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))<0:p.reverse()
    return p
def winding(point,v):
    count=0
    for a,b in zip(v,v[1:]+v[:1]):
        if a[1]<=point[1]<b[1] and orient(a,b,point)>0:count+=1
        elif b[1]<=point[1]<a[1] and orient(a,b,point)<0:count-=1
    return count
minimum=math.inf;count=0
for family,data in model['families'].items():
    assert data['original']==parts[family]['geometry'][0]['outer'];source=canonical(data['original']);expanded=canonical(data['clearance']);poly=Polygon(data['clearance']);assert poly.is_valid and not poly.interiors and winding(source[0],expanded)!=0
    assert len(proofs[family])==len(source)*len(expanded);seen=set()
    for p in proofs[family]:
        ai,bi=p['source_edge'],p['expanded_edge'];assert (ai,bi) not in seen;seen.add((ai,bi));a,b=source[ai],source[(ai+1)%len(source)];c,d=expanded[bi],expanded[(bi+1)%len(expanded)];nx,ny=map(F,p['normal']);norm=nx*nx+ny*ny;gap=min(nx*x+ny*y for x,y in [c,d])-max(nx*x+ny*y for x,y in [a,b]);assert norm>0 and gap>0 and gap*gap>=F('.114')**2*norm;minimum=min(minimum,float(gap)/math.sqrt(float(norm)));count+=1
assert count==9344 and set(model['families'])=={'bracket','insert','cog'}
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F('.025'),stock[1]+F('.025'),stock[2]-F('.025'),stock[3]-F('.025')];assert model['safe_original_stock_mm']==list(map(float,safe)) and model['objective_weights']=={'original_area':1,'clearance_area':1} and model['certified_local_disc_radius_mm']=='.114' and model['circumscribed_cog_radius_mm']=='140.000002'
center=[(min(F(p[k]) for p in parts['cog']['geometry'][0]['outer'])+max(F(p[k]) for p in parts['cog']['geometry'][0]['outer']))/2 for k in [0,1]];radius=F('140.000002');r2=max(sum((F(p[k])-center[k])**2 for k in [0,1]) for p in parts['cog']['geometry'][0]['outer']);assert r2<radius*radius
expected_bounds=[];expected_values=[];angle_bounds=[];angle_values=[];expected_owners=[];expected_clamps=[];angles=0
for i,old_owner in enumerate(old):
    identity=old_owner['identity'];t=byid[tuple(identity)]['transform'];owner={'owner':i,'identity':identity,'rotation_radians':t['rotation_radians'],'mirrored':t['mirrored'],'angle_coordinate':None,'angle_scale_mm':None,'source_center':None};xy=t['translation'].copy()
    if identity[0]=='cog':
        assert parts['cog']['rotations']['kind']=='free' and not t['mirrored'];owner.update({'angle_coordinate':56+angles,'angle_scale_mm':140,'source_center':list(map(float,center))});c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);px,py=map(float,center);xy=[xy[0]+px*c-py*s,xy[1]+px*s+py*c];bb=[[float(safe[k]+radius),float(safe[k+2]-radius)] for k in [0,1]];angle_values.append(140*t['rotation_radians']);angle_bounds.append([140*(t['rotation_radians']-math.pi),140*(t['rotation_radians']+math.pi)]);angles+=1
    else:
        c,s=map(F,[math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])]);sign=-1 if t['mirrored'] else 1;vertices=[(sign*F(x)*c-F(y)*s,sign*F(x)*s+F(y)*c) for x,y in parts[identity[0]]['geometry'][0]['outer']];bb=[[v/100+[0,2100][k]+old_owner['translation_from_lower_left'][k] for v in b] for k,b in enumerate(old_owner['position_bounds_grid'])]
        for k in [0,1]:assert F(bb[k][0])+min(p[k] for p in vertices)>safe[k]-F('1e-10') and F(bb[k][1])+max(p[k] for p in vertices)<safe[k+2]+F('1e-10')
    clipped=[min(max(v,b[0]),b[1]) for v,b in zip(xy,bb)];expected_clamps.append({'owner':i,'before':xy,'after':clipped,'changed':xy!=clipped});expected_values+=clipped;expected_bounds+=bb;expected_owners.append(owner)
expected_values+=angle_values;expected_bounds+=angle_bounds
assert model['owners']==expected_owners and model['initial']==expected_values and model['bounds']==expected_bounds and angles==12 and load(BASE/'seed-domain-clamps.json')==expected_clamps
assert model['pairs']==list(map(list,combinations(range(28),2))) and len(model['pairs'])==378 and model['fixed_source_rows']==fixed+short
def independent_rows(values):
    result=list(fixed+short)
    for owner in model['owners']:
        i=owner['owner'];theta=values[owner['angle_coordinate']]/140 if owner['angle_coordinate'] is not None else owner['rotation_radians'];xy=[float(values[2*i]),float(values[2*i+1])]
        if owner['angle_coordinate'] is not None:
            c,s=math.cos(theta),math.sin(theta);px,py=map(float,center);xy=[xy[0]-(px*c-py*s),xy[1]-(px*s+py*c)]
        result.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':owner['mirrored'],'translation':xy}})
    return result
rows=independent_rows(initial);assert rows==source_rows(model,initial)==load(BASE/'seed-source66.json');identities=list(map(tuple,load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json')['full66_identities']));source=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],identities);assert source==load(BASE/'seed-source-checks.json') and source['pair_failures']==39 and source['stock_failures']==0;write(OUT/'seed-source-checks.json',source)
fixed_check=audit(job,fixed+short,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm']);assert fixed_check['valid'];core_top=-math.inf
for row in fixed:
    pose=row['transform'];c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);sign=-1 if pose['mirrored'] else 1
    core_top=max(core_top,max(sign*x*s+y*c+pose['translation'][1] for x,y in parts[row['part_id']]['geometry'][0]['outer']))
assert float(safe[1])-core_top>spec['required_pair_gap_mm'];write(OUT/'stock-domain-proof.json',{'exact_cog_squared_radius':str(r2),'exact_radius_bound':str(radius),'safe_stock':list(map(float,safe)),'fixed_core_top_mm':core_top,'minimum_core_gap_mm':float(safe[1])-core_top,'all_angle_containment':'Every original vertex has norm strictly below radius; each edge is a convex combination of its endpoints. Rigid rotations preserve this norm. The center box therefore contains every original outline at every permitted angle. The2e-6mm reserve exceeds numeric transform readback tolerance; all candidates still require original-source validation.','fixed38_source_valid':True})
stock_controls=[]
for i,owner in enumerate(model['owners']):
    phases=[None] if owner['angle_coordinate'] is None else [-math.pi/3,0,math.pi/4]
    for phase in phases:
        for corner in product(*bounds[2*i:2*i+2]):
            x=initial.copy();x[2*i:2*i+2]=corner
            if phase is not None:x[owner['angle_coordinate']]=140*phase
            r=independent_rows(x)[38+i];check=audit(job,fixed+short+[r],spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm']);assert check['valid'];stock_controls.append({'owner':i,'phase':phase,'corner':list(corner),'minimum_gap_mm':check['minimum_pair_gap_mm'],'minimum_stock_mm':check['minimum_extra_stock_mm']})
assert len(stock_controls)==208;write(OUT/'stock-corner-controls.json',stock_controls)
obj=Objective(model);energy,gradient,details=obj.evaluate(initial,True);saved=load(BASE/'initial-objective.json');assert energy==saved['energy_mm2'] and gradient.tolist()==saved['gradient'] and details=={k:v for k,v in saved.items() if k not in ['energy_mm2','gradient']};assert abs(details['original_overlap_area_mm2']-sum(p['intersection_area_mm2'] for p in source['pairs']))<1e-7
# Independent scalar reference for the batched boundary kernel and pivot/scale.
reference=np.zeros(68);comparisons=0;maximum_kernel_error=0.
for shapes in obj.geometry(initial):
    for i,j in model['pairs']:
        if shapes[i][1].intersection(shapes[j][1]).area<=0:continue
        for own,other in [(i,j),(j,i)]:
            v,p,lines,pivot=shapes[own];g,n,shared=moving_boundary_gradient(p,shapes[other][1],pivot);fast,n2,shared2=boundary_gradient(v,lines,shapes[other][1],pivot);err=float(np.max(np.abs(g-fast)));assert err<1e-7 and abs(shared-shared2)<1e-8;maximum_kernel_error=max(maximum_kernel_error,err);reference[2*own:2*own+2]+=g[:2];o=model['owners'][own]
            if o['angle_coordinate'] is not None:reference[o['angle_coordinate']]+=g[2]/140
            comparisons+=1
assert np.max(np.abs(reference-gradient))<1e-7
pair_array=np.asarray(model['pairs']);
def independent_energy(values):
    current=independent_rows(values)[38:];total=0.
    for kind in ['original','clearance']:
        shapes=[]
        for row in current:
            t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation'];shapes.append(Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in model['families'][row['part_id']][kind]]))
        shapes=np.asarray(shapes,dtype=object);total+=float(np.sum(shapely.area(shapely.intersection(shapes[pair_array[:,0]],shapes[pair_array[:,1]]))))
    return total
derivatives=[];directions=[]
for phase in [0,1]:
    point=initial.copy() if phase==0 else np.clip(initial+.037*np.sin(np.arange(68)*2**.5+.2),bounds[:,0],bounds[:,1]);value,g,meta=obj.evaluate(point,True);assert abs(independent_energy(point)-value)<1e-7;errors=[]
    for i in range(68):
        plus=point.copy();minus=point.copy();plus[i]+=1e-4;minus[i]-=1e-4;observed=(independent_energy(plus)-independent_energy(minus))/2e-4;err=abs(observed-g[i]);assert err<.005+2e-6*abs(g[i]),(phase,i,observed,g[i],err);errors.append(float(err))
    derivatives.append({'phase':phase,'coordinates':68,'maximum_error':max(errors),'energy_mm2':value,'shared_boundary_length_mm':meta['coincident_boundary_length_mm'],'symmetric_convention_at_shared_edges':True})
    for step in [1e-7,1e-6,1e-5]:
        candidate=np.clip(point-step*g,bounds[:,0],bounds[:,1]);observed=independent_energy(candidate);assert observed<value,(phase,step,value,observed);directions.append({'phase':phase,'projected_gradient_step':step,'before':value,'after':observed,'strictly_decreases':True})
write(OUT/'derivative-controls.json',derivatives);write(OUT/'one-sided-descent-controls.json',directions)
clearance_controls=[]
base_original=Polygon([(0,0),(180,0),(180,110),(0,110)]);base_clearance=Polygon([(-.115,-.115),(180.115,-.115),(180.115,110.115),(-.115,110.115)])
for gap in [-.1,0,.1,.24]:
    other_original=shapely.affinity.translate(base_original,xoff=180+gap) if hasattr(shapely,'affinity') else None
    from shapely.affinity import translate
    other_original=translate(base_original,xoff=180+gap);other_clearance=translate(base_clearance,xoff=180+gap);original_area=base_original.intersection(other_original).area;clearance_area=base_clearance.intersection(other_clearance).area;g,_,_=moving_boundary_gradient(other_clearance,base_clearance,[180+gap,0]);after=base_clearance.intersection(translate(other_clearance,xoff=1e-4)).area
    assert abs(clearance_area-max(0,.23-gap)*110.23)<1e-8
    if gap<.23:assert after<clearance_area and g[0]<0
    else:assert clearance_area==original_area==0 and gap>spec['required_pair_gap_mm']
    if gap>=0:assert original_area==0
    clearance_controls.append({'original_gap_mm':gap,'original_area_mm2':original_area,'clearance_area_mm2':clearance_area,'separating_gradient_x':float(g[0]),'separating_step_lowers_positive_penalty':after<clearance_area,'zero_clearance_penalty_implies_source_gap_control':gap>.23})
write(OUT/'clearance-contact-controls.json',clearance_controls)
controls=load(ROOT/'output/h5-mixed-mode-union-20261107/audit/optimizer-controls.json');provenance=load(ROOT/'output/h5-mixed-mode-union-20261107/audit/tool-provenance.json');assert controls['passed']
for name,record in provenance['tool_files'].items():assert digest(ROOT/name)==record['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',provenance)
process=load(ROOT/'output/h5-direct-pose-preparation-process-20261107/prepare.json');assert process['passed'] and process['job']['active_processes']==0 and process['job']['closed'] and process['complete_seconds']<7
inputs=[Path(__file__),ROOT/'output/h5_direct_pose_model_20261107.py',ROOT/'output/h5_original_overlap_gradient_v2_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,ROOT/'output/h5-direct-pose-preparation-process-20261107/prepare.json']+[BASE/n for n in ['plan.json','model.json','checks.json','clearance-supports.json','seed-domain-clamps.json','seed-source66.json','seed-source-checks.json','initial-objective.json']]+[B/n for n in ['mapping.json','search/candidate-source66.json']]+[FIRST/n for n in ['plan.json','fixed29.json','short9-source.json']]+[ROOT/'output/h5-mixed-mode-union-20261107/audit'/n for n in ['optimizer-controls.json','tool-provenance.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exact winding and9344 all-edge support readback proves clearance-contour containment. Reconstruct all68 parameter domains,originalposes,12angle pivots/scales,378pairs and4necessary domain clamps. Prove all-angle stockcontainment fromexact source radii and fixedcore gap;208native-original-source corner controls. Reconstruct all66source seed and objective,compare batched boundary gradients to separately implemented scalar sourcekernel,136independentcentral controls,6projectedone-sideddescent controls and4gap/contact controls. Recheck pinned tools,complete charged preparation and processclosure. Numerical derivative controls are local,nonsmooth convention explicit;nooptimizer/noall-layout claim.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'exact_clearance_supports':count,'minimum_certified_local_clearance_mm':minimum,'moving_originals':28,'moving_pairs':378,'parameters':68,'continuous_cog_angles':12,'stock_corner_source_controls':len(stock_controls),'batched_scalar_gradient_comparisons':comparisons,'maximum_kernel_gradient_error':maximum_kernel_error,'independent_central_controls':136,'projected_one_sided_descent_controls':len(directions),'clearance_contact_controls':len(clearance_controls),'source_seed_pair_failures':source['pair_failures'],'source_seed_stock_failures':source['stock_failures'],'initial_objective_mm2':energy,'model_sha256':digest(BASE/'model.json'),'complete_model_preparation_seconds':process['complete_seconds'],'complete_preparation_before_search_seconds':load(BASE/'plan.json')['complete_consumed_candidate_charge_seconds']+process['complete_seconds'],'source_valid66':False,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
