"""One bounded original-outline continuous pose call; no restart."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-pose-model-20261107';OUT=BASE/'search';PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def child(started):
    import numpy as np,scipy
    from scipy.optimize import minimize
    from h5_direct_pose_model_20261107 import Objective,source_rows
    assert scipy.__version__=='1.17.1';plan=load(OUT/'plan.json');checked=load(BASE/'audit/checks.json');assert checked['passed']
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256']
    assert digest(BASE/'model.json')==checked['model_sha256'];model=load(BASE/'model.json');objective=Objective(model);options=load(BASE/'audit/optimizer-controls.json')['options'];bounds=np.asarray(model['bounds']);initial=np.asarray(model['initial']);remaining=60-(time.perf_counter()-started)-4
    if remaining<=0:write(OUT/'result.json',{'closed':True,'optimizer_calls':0,'status':'NO_SOLVE_TIME','source_valid66':False,'algorithm_seconds_including_preparation':time.perf_counter()-started});return
    state={'evaluations':0,'best':float('inf'),'values':None,'incumbents':0};deadline=time.perf_counter()+remaining
    class Deadline(Exception):pass
    def function(x):
        if time.perf_counter()>=deadline:raise Deadline()
        value,g=objective.evaluate(x);state['evaluations']+=1
        if value<state['best']:
            state['best']=value;state['values']=x.copy();write(OUT/'incumbents'/f'{state["incumbents"]:05d}.json',{'sequence':state['incumbents'],'evaluation':state['evaluations'],'objective_mm2':value,'values':x.tolist(),'gradient':g.tolist(),'algorithm_seconds_including_preparation':time.perf_counter()-started});state['incumbents']+=1
        return value,g
    def callback(x):
        if state['best']<=1e-16:raise StopIteration()
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'method':'L-BFGS-B','analytic_jacobian':True,'nonsmooth_shared_boundary_convention':'symmetric half-weight;local directional controls passed;no classical/global convergence claim','options':options,'parameters':68,'allocated_optimizer_seconds':remaining,'maximum_calls':1,'retry_permitted':False,'model_sha256':checked['model_sha256'],'algorithm_seconds_including_preparation_at_open':time.perf_counter()-started})
    before=time.perf_counter();result=None
    try:
        result=minimize(function,initial.copy(),jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options);status='RETURNED';numerical={'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'gradient_evaluations':int(result.njev),'objective_mm2':float(result.fun),'values':result.x.tolist(),'gradient':result.jac.tolist()}
    except Deadline:status='TIME_STOP';numerical=None
    elapsed=time.perf_counter()-before;assert state['values'] is not None;best=state['values'];value,g,details=objective.evaluate(best,True);assert value==state['best'] and np.all(best>=bounds[:,0]) and np.all(best<=bounds[:,1])
    write(OUT/'response.json',{'closed':True,'optimizer_calls':1,'status':status,'numerical_result':numerical,'allocated_optimizer_seconds':remaining,'returned_optimizer_seconds':elapsed,'optimizer_slice_overrun_seconds':max(0.,elapsed-remaining),'evaluations':state['evaluations'],'incumbents':state['incumbents'],'best_objective_mm2':value,'best_values':best.tolist(),'best_gradient':g.tolist(),'best_details':details,'algorithm_seconds_including_preparation':time.perf_counter()-started})
    from h5_legacy64_source_readback import audit
    first=ROOT/'output/h5-first57-direct-short9-20261104';spec=load(first/'plan.json');rows=source_rows(model,best);write(OUT/'candidate-source66.json',rows);before=time.perf_counter();source=audit(load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json')['full66_identities'])));source_seconds=time.perf_counter()-before
    assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026;write(OUT/'original-source-checks.json',source);elapsed_all=time.perf_counter()-started
    write(OUT/'result.json',{'closed':True,'optimizer_calls':1,'status':'SOURCE_VALID_CANDIDATE' if source['valid'] else 'SOURCE_INVALID_CANDIDATE','optimizer_status':status,'best_objective_mm2':value,'original_overlap_area_mm2':details['original_overlap_area_mm2'],'clearance_overlap_area_mm2':details['clearance_overlap_area_mm2'],'source_checker_calls':1,'source_checker_seconds':source_seconds,'source_valid66':source['valid'],'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'algorithm_seconds_including_preparation':elapsed_all,'algorithm_overrun_seconds':max(0.,elapsed_all-60),'native_calls':0,'any_allocation_excluded':False,'H5_complete':False});print(load(OUT/'result.json'))
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'incumbents').mkdir();shutil.copyfile(__file__,OUT/'run.py');charges={'complete_consumed_source_candidate':load(BASE/'plan.json')['complete_consumed_candidate_charge_seconds'],'complete_new_geometry_and_model_preparation':load(ROOT/'output/h5-direct-pose-preparation-process-20261107/prepare.json')['complete_seconds']};charge=sum(charges.values());started=time.perf_counter()-charge;write(OUT/'preparation-charges.json',charges)
    first=ROOT/'output/h5-first57-direct-short9-20261104';files=[Path(__file__),ROOT/'output/h5_direct_pose_model_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-direct-pose-preparation-process-20261107/prepare.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json']+[BASE/n for n in ['plan.json','model.json','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json']]+[first/n for n in ['plan.json','fixed29.json','short9-source.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'preparation_seconds_charged':charge,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_optimizer_calls':1,'restarts':0,'retry_permitted':False,'blas_threads':1,'method':'One genuinely new68-parameter original-pose model with all12continuous legalcogangles. Equal-weight original-filled and source-certified clearance-contour intersection areas,hardstock domains,all378moving pairs. Frozen full2pi angleintervals and originalselected bracket/insert poses. Stop on first return,time orzeroobjective;preserve every improving point. No restart,reseed or extension. Check all66originals after best candidate regardless of heuristic residual. Numericconvergence orlocalfailure proves neither validity norinfeasibility. All consumed candidate and newgeometry/proofs/modelpreparation charged;verification-only gradient diagnostics not loaded.'})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'memory_bytes':2**31,'preparation_seconds_charged':charge,'retry_permitted':False});env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'repeat_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result;the call remains closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
