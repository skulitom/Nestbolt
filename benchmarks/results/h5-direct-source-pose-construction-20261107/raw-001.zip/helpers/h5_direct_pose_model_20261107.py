"""Continuous original poses with filled-outline and certified-clearance areas."""
import math
import numpy as np
import shapely
from shapely.geometry import Polygon,LineString

def line_parts(g):
    if g.is_empty:return []
    if g.geom_type=='LineString':return [g]
    if hasattr(g,'geoms'):return [p for child in g.geoms for p in line_parts(child)]
    return []

def boundary_gradient(vertices,lines,other,pivot):
    """Batch clipping; half weight coincident edges, and report their length."""
    intersections=shapely.intersection(lines,other);shared=shapely.intersection(lines,other.boundary);gradient=np.zeros(3);count=0;shared_length=float(np.sum(shapely.length(shared)))
    for i,p in enumerate(vertices):
        edge=vertices[(i+1)%len(vertices)]-p;den=float(edge@edge)
        if not den:continue
        for geometry,weight in [(intersections[i],1.),(shared[i],-.5)]:
            for segment in line_parts(geometry):
                ts=[float((np.asarray(v)-p)@edge/den) for v in segment.coords];lo=max(0.,min(ts));hi=min(1.,max(ts))
                if hi<=lo:continue
                d=weight*(hi-lo)*edge;n=np.array([d[1],-d[0]]);mid=p+(hi+lo)/2*edge-np.asarray(pivot);gradient[:2]+=n;gradient[2]+=float(np.array([-mid[1],mid[0]])@n);count+=weight==1.
    return gradient,count,shared_length

def source_pose(owner,values):
    i=owner['owner'];angle=float(values[owner['angle_coordinate']])/owner['angle_scale_mm'] if owner['angle_coordinate'] is not None else owner['rotation_radians'];xy=[float(values[2*i]),float(values[2*i+1])]
    if owner['angle_coordinate'] is not None:
        c,s=math.cos(angle),math.sin(angle);px,py=owner['source_center'];translation=[xy[0]-(px*c-py*s),xy[1]-(px*s+py*c)]
    else:translation=xy
    return {'rotation_radians':angle,'mirrored':owner['mirrored'],'translation':translation}

def source_rows(model,values):
    return list(model['fixed_source_rows'])+[{'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':source_pose(o,values)} for o in model['owners']]

def transformed(points,pose):
    c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);m=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];v=np.array([[m*x*c-y*s+tx,m*x*s+y*c+ty] for x,y in points])
    if np.sum(v[:,0]*np.roll(v[:,1],-1)-v[:,1]*np.roll(v[:,0],-1))<0:v=v[::-1]
    return v

class Objective:
    def __init__(self,model):self.model=model
    def geometry(self,values):
        all_shapes=[]
        for kind in ['original','clearance']:
            entries=[]
            for o in self.model['owners']:
                points=self.model['families'][o['identity'][0]][kind];pose=source_pose(o,values);v=transformed(points,pose);polygon=Polygon(v);pivot=[float(values[2*o['owner']]),float(values[2*o['owner']+1])];entries.append((v,polygon,shapely.linestrings(np.stack([v,np.roll(v,-1,axis=0)],axis=1)),pivot))
            all_shapes.append(entries)
        return all_shapes
    def evaluate(self,values,details=False):
        gradient=np.zeros(68);total=0.;records=[];shared=0.;segments=0;levels=[];owners=self.model['owners']
        for kind,shapes in zip(['original','clearance'],self.geometry(values)):
            level=0.
            for i,j in self.model['pairs']:
                a,b=shapes[i][1],shapes[j][1];overlap=a.intersection(b).area;level+=overlap
                if overlap<=0:continue
                row={'kind':kind,'owners':[i,j],'area_mm2':overlap}
                for own,other in [(i,j),(j,i)]:
                    v,poly,lines,pivot=shapes[own];g,n,coincident=boundary_gradient(v,lines,shapes[other][1],pivot);gradient[2*own:2*own+2]+=g[:2];o=owners[own]
                    if o['angle_coordinate'] is not None:gradient[o['angle_coordinate']]+=g[2]/o['angle_scale_mm']
                    shared+=coincident;segments+=n
                if details:records.append(row)
            total+=level;levels.append(level)
        assert np.isfinite(total) and np.all(np.isfinite(gradient))
        if details:return total,gradient,{'original_overlap_area_mm2':levels[0],'clearance_overlap_area_mm2':levels[1],'positive_terms':records,'clipped_segments':segments,'coincident_boundary_length_mm':shared}
        return total,gradient
