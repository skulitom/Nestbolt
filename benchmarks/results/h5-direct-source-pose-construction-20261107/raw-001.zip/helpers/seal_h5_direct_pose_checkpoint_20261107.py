"""Preserve direct source pose construction and explicit consumed-budget closure."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-direct-source-pose-construction-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-direct-pose-model-20261107';F=ROOT/'output/h5-direct-pose-checkpoint-20261107';D=BASE","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-target-cog-repair-and-source-gradients-20261107'","front['source_pair_failures']==39":"front['source_pair_failures']==32","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F]+[ROOT/'output'/n for n in ['h5-direct-pose-preparation-process-20261107','h5-direct-pose-audit-process-20261107','h5-direct-pose-response-audit-process-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*direct*pose*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_direct_pose_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(BASE/'audit/checks.json','source-and-model-audit.json'),(BASE/'audit/stock-domain-proof.json','stock-domain-proof.json'),(BASE/'audit/stock-corner-controls.json','stock-corner-controls.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/one-sided-descent-controls.json','directional-controls.json'),(BASE/'audit/clearance-contact-controls.json','clearance-controls.json'),(BASE/'seed-domain-clamps.json','seed-domain-clamps.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/collision-details.json','source-failures.json'),(BASE/'response-audit/cog-angle-changes.json','cog-angle-changes.json'),(BASE/'search/process.json','closed-search-process.json'),(ROOT/'output/h5-direct-pose-preparation-process-20261107/process.json','preparation-process.json'),(ROOT/'output/h5-direct-pose-audit-process-20261107/process.json','model-audit-process.json'),(ROOT/'output/h5-direct-pose-response-audit-process-20261107/process.json','response-audit-process.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Direct original-source pose construction — 2026-11-07

The new continuous-pose model reduces actual summed overlap from
**41,109.022811 to 27,392.624149 mm²** and failing pairs from **39 to 32**.
It stops at its frozen time limit. The best layout remains invalid: **29
overlaps and three insufficient-clearance pairs**, with no stock failures.
No native or LightBurn call follows. H2/H5 remain open at **60% completed
milestone weight**; four fixed arrangements and 440 whole allocations remain.
Neither a valid layout nor an allocation exclusion has been established.

## Fresh source geometry and all-angle domains

The model uses **56 independent translation coordinates and 12 continuous
cog-angle coordinates**, retaining each bracket/insert's selected legal pose.
Every angle spans one complete 2π interval. Cog angle coordinates are scaled
by140 mm, with an explicit source-center pivot and independently checked
translation reconstruction. All **378 pairs of moving originals** remain.

The objective equally weights two areas: actual filled-original intersections
and intersections of clearance contours derived from those originals. Both
terms have units mm². Filled outers enforce noPIH; all original contours and
holes remain unchanged in source output. The clearance term remains positive
at original contact or a short gap, where original intersection area can be zero.

Fresh local clearance contours are unions of original convex pieces expanded
by a0.115 mm square. [Independent exact winding and support readback]({NAME}/source-and-model-audit.json)
checks **9,344 source-edge/expanded-edge pairs**. Every expanded contour
contains a disc expansion of radius0.114 mm about its filled original.
The minimum certified local boundary gap is **0.114999999975 mm**. Disjoint
clearance interiors therefore provide at least0.228 mm original separation
under rigid geometry, above the unchanged0.2117086725 mm source checker
threshold. Numerical output still requires independent source validation.

[The stock-domain proof]({NAME}/stock-domain-proof.json) derives a conservative
all-angle cog radius of **140.000002 mm** directly from exact original vertices.
Its center box fits the entire original at every angle. Selected bracket and
insert domains retain their source bounds. The fixed29 core and short9 sheet
are independently source-valid, and the moving box clears the fixed core.
[208 original-source corner controls]({NAME}/stock-corner-controls.json)
exercise every owner and several cog angles; all pass.

[Four seed positions are clamped]({NAME}/seed-domain-clamps.json) only as needed
for the new all-angle domains. The reconstructed seed retains all66 originals
and still fails39 pairs. Its original summed overlap is41,109.022811 mm²;
the source changes are explicitly preserved and are not claimed as a repair.

[Complete geometry/model preparation]({NAME}/preparation-process.json) takes
**1.020532 s**, including source-buffer construction, exact support selection,
source checks, initial scoring and serialization. The complete consumed
preparation charge is **46.995655 s**, including the earlier candidate lineage.

## Independent model and derivative checks

The audit reconstructs every owner, parameter, bounds interval, source pose,
pair and clamp. All full66 original seed checks are replayed. The batched
boundary-gradient implementation is compared with the separately implemented
scalar source kernel in **156 cases**, with zero discrepancy. Shared edges
retain the explicit symmetric half-weight convention; no unique classical
derivative is claimed at a nonsmooth configuration.

[136 independent central differences]({NAME}/derivative-controls.json),
[six projected one-sided descent controls]({NAME}/directional-controls.json)
and [four overlap/contact/short-gap/separated controls]({NAME}/clearance-controls.json)
pass. These are local controls, not a global convergence guarantee. Pinned
SciPy1.17.1 tool hashes and optimizer controls pass. [The complete independent
source/model audit]({NAME}/model-audit-process.json) takes **6.330012 s** and
closes all descendants normally.

## One closed continuous-pose call

The frozen call allows no restart, reseed or extension. It allocates
**8.269466 s** to L-BFGS-B, reserving four seconds for full original validation
within the preparation-inclusive60/90-second and2GiB limits.

[Independent response replay]({NAME}/response-audit.json) verifies all **51
strictly improving points and64 evaluations**, including68 parameters and
their gradients. The optimizer stops on time; it does **not** return a
numerical convergence result. The best combined penalty falls from
**83,533.582835 to55,803.019516 mm²**. [All12 legal cog rotations]({NAME}/cog-angle-changes.json)
are independently reconstructed from the scaled coordinates.

Full source replay checks **66 originals,1,632 same-sheet pairs,264 stock
edges,90 holes and10,026 hole vertices**. [The failing source pairs]({NAME}/source-failures.json)
include29 positive-area intersections and three clearance-only failures.
Every stock edge passes. Summed pairwise areas can double-count; they are
not a union-area or material measure. This remains an invalid candidate.

The optimizer's returned slice is **8.345532 s**, exceeding its allocated slice
by **0.076065 s**. This overrun is preserved. Complete algorithm/shared totals
are **56.273396 /56.340300 s**, within their original limits, with no overall
algorithm overrun. [All five processes close]({NAME}/closed-search-process.json),
with **92,430,336 bytes** peak committed memory. The separate complete
[response audit]({NAME}/response-audit-process.json) takes **9.805810 s**.

## Explicit budget closure and next work

The consumed candidate lineage now leaves only **3.659700 s**, less than the
required four-second source reserve even before new preparation. It cannot
support another optimization. Continuing this candidate under a reset clock,
or changing only its seed, would violate the closed-call/resource rules.

[The next task]({NAME}/next-step.json) assesses a genuinely broader physical
model: legal discrete bracket/insert orientations alongside continuous cog
rotations. Those16 originals remain fixed in this closed model. Any new
construction must first establish deterministic original-source initialization,
all legal modes and domains, complete independent readback and a new fully
charged bounded pipeline. Historical candidate transforms, mode choices,
buffers, gradients or initialization must not be hidden in constants or
treated as free data. Pure verified code may be reused. No broader model,
initializer or optimizer call has been prepared or opened.

H2's original gate remains open under the earlier user decision. Full66 source,
native, material, unchanged H5 matrix and production UI/CLI/MCP parity remain
required. [Main9118d6cb CI]({NAME}/main-ci-at-review.json) has five successful
jobs and a live Windows native job at review. The preceding0ae08d60 checkpoint
and this checkpoint await the ordinary fast-forward push gate. No live CI run
is cancelled, and no production, README or release change is made.

[Raw evidence]({NAME}/raw-manifest.json) preserves {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and [source bindings]({NAME}/source-bindings.json)
retain the complete consumed lineage. Independent archive readback is required
before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 direct original-source pose construction:** [independent geometry/model/response audits]({link}) verify 9,344 exact clearance supports, 68 continuous pose parameters, all 378 moving pairs and 208 source stock-corner controls. Controls cover 156 scalar/batched gradient comparisons, 136 central differences, six projected descent steps and four clearance cases. One bounded call stops on time after 64 evaluations and 51 improving points. Actual original overlap falls from 41,109.022811 to 27,392.624149 mm², but all66 source replay still finds 29 overlaps and three clearance failures, with all stock edges passing. Complete preparation is 46.995655 s; algorithm/shared totals are 56.273396/56.340300 s and all processes close. The 0.076065 s optimizer-slice overrun remains recorded inside the overall limits. Only 3.659700 s remains in the consumed lineage, below the four-second source reserve, so no continuation or reset clock is allowed. Next assess a genuinely broader legal bracket/insert mode model with independently prepared source initialization and complete accounting; it is not yet built or run. Four fixed arrangements and 440 allocations remain, H2/H5 stay open at 60%, and all closed calls stay closed. Five main CI jobs pass; Windows native CI is live at review. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
path=ROOT/'docs/STATUS.md';s=path.read_text(encoding='utf-8');begin=s.index('Latest H5 evidence:');end=s.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [direct original-source pose construction](../benchmarks/results/{NAME}.md).
Fresh clearance geometry and a68-parameter continuous-pose model pass exact
source, all-angle stock, derivative and directional controls. One bounded
call reduces actual overlap and failing pairs39 to32, but its candidate still
has29 overlaps and three clearance failures. All stock checks pass. The call
stops on time after64 evaluations; no numerical convergence is invented.
Complete algorithm/shared totals are56.273396/56.340300 s including preparation.
The0.076065 s optimizer-slice overrun is preserved; overall limits pass.
The consumed lineage leaves less than the required four-second source reserve,
so it cannot continue. Next assess legal bracket/insert orientation choices
in a genuinely broader model with independent original-source initialization
and full accounting. No new initializer, model or call is prepared.
Four fixed arrangements and440 allocations remain; H2/H5 stay open at60%.
Full source/native/material validation, production parity and the unchanged
H5 matrix remain required. Main9118d6cb has five passed CI jobs and a live
Windows native job. Checkpoint0ae08d60 and this checkpoint await the ordinary
push gate. No release qualifies.
'''
path.write_text(s[:begin]+intro+s[end:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
