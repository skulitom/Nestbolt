"""Pure exact containment/support helpers for local clearance contours."""
from fractions import Fraction as F
import math
import shapely
from shapely.geometry import LineString,Polygon,MultiPoint
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import area,cross

def ccw(v):
    points=[tuple(map(F,p)) for p in v]
    return list(reversed(points)) if area(points)<0 else points

def inside_exact(point,vertices):
    winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        if a[1]<=point[1]<b[1] and cross(a,b,point)>0:winding+=1
        if b[1]<=point[1]<a[1] and cross(a,b,point)<0:winding-=1
    return winding!=0

def clearance_outline(pieces,radius):
    r=F(radius);square=[(-r,-r),(r,-r),(r,r),(-r,r)];polys=[]
    for piece in pieces:
        polys.append(MultiPoint([(float(F(p[0])+q[0]),float(F(p[1])+q[1])) for p in piece for q in square]).convex_hull)
    shape=unary_union(polys);assert shape.geom_type=='Polygon' and shape.is_valid and len(shape.interiors)==0
    return [[float(x),float(y)] for x,y in ccw(list(shape.exterior.coords)[:-1])]

def certify_clearance(original,expanded,required):
    source=ccw(original);outer=ccw(expanded);assert inside_exact(source[0],outer);proofs=[];minimum=math.inf
    for ai,(a,b) in enumerate(zip(source,source[1:]+source[:1])):
        line=LineString([list(map(float,a)),list(map(float,b))])
        for bi,(c,d) in enumerate(zip(outer,outer[1:]+outer[:1])):
            other=LineString([list(map(float,c)),list(map(float,d))]);nearest=list(shapely.shortest_line(line,other).coords);assert len(nearest)==2
            n=[nearest[1][k]-nearest[0][k] for k in [0,1]];nx,ny=map(F,n);norm=nx*nx+ny*ny;gap=min(p[0]*nx+p[1]*ny for p in [c,d])-max(p[0]*nx+p[1]*ny for p in [a,b]);assert gap>0 and gap*gap>=F(required)**2*norm
            lower=float(gap)/math.sqrt(float(norm));minimum=min(minimum,lower);proofs.append({'source_edge':ai,'expanded_edge':bi,'normal':n})
    return proofs,minimum
