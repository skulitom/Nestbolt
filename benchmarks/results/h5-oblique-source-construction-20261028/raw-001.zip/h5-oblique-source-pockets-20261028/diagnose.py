"""Constructive source-anchor pockets around the independently verified oblique packet."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, math, shutil, time
import numpy as np
from shapely.geometry import Polygon, box, mapping
from shapely.affinity import affine_transform, translate
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as geom

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-oblique-source-pockets-20261028'
BASE=ROOT/'output/h5-oblique64-source-20261028'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py');start=time.perf_counter();deadline=start+120
assert load(BASE/'audit/checks.json')['passed']
job=load(JOB);parts={r['id']:r for r in job['parts']};rows=load(BASE/'source64.json')
required=.21170867250963943;geom.EPS=.0126
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,BASE/'source64.json',BASE/'audit/checks.json',Path(geom.__file__)]},
 'maximum_preparation_seconds':120,'maximum_runs':1,'retry_permitted':False,'required_gap_mm':required,'construction_extra_mm':geom.EPS,
 'method':'Build source-polygon Minkowski forbidden regions for all eight bracket modes and two insert outer classes, first with all64 existing source placements fixed, then with the two first-sheet brackets and five top inserts removed. All15 phase7 cogs,29 first-sheet core and13 short core placements remain fixed. The latter57-original construction has4 brackets and5 inserts mandatory. Reuse exact local-source configuration obstacles under translations. Positive-area anchor pockets are sufficient construction domains; the mitred clearance overestimate and positive margin mean an empty pocket is not an actual-source impossibility proof. No optimizer, quantity change, native call or existing closed-search retry.'})
def local(row):
    t=row['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1
    return affine_transform(Polygon(parts[row['part_id']]['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0])
fixed64=[r for r in rows if r['sheet_id']=='sheet-0']
fixed57=[r for r in fixed64 if not (r['part_id']=='bracket' or (r['part_id']=='insert' and r['copy_index']>=16))]
assert len(fixed64)==51 and len(fixed57)==44
cache={};modes=[];records=[]
for family,angles,mirrors in [('bracket',[q*math.pi/2 for q in range(4)],[False,True]),('insert',[0.,math.pi/2],[False])]:
    for mirrored in mirrors:
        for angle in angles:
            assert time.perf_counter()<deadline
            mi=len(modes);dummy={'part_id':family,'transform':{'rotation_radians':angle,'mirrored':mirrored,'translation':[0,0]}}
            g=local(dummy);b=g.bounds;off=[-b[0],-b[1]];g=translate(g,*off);w,h=g.bounds[2:]
            mode={'index':mi,'family':family,'angle':angle,'mirrored':mirrored,'source_translation_offset':off,'geometry':mapping(g)};modes.append(mode)
            legal=box(6.5+geom.EPS,6.5+geom.EPS,1493.5-geom.EPS-w,2993.5-geom.EPS-h)
            for label,fixed in [('fixed64',fixed64),('fixed57',fixed57)]:
                if label=='fixed64' and family=='insert':continue
                obstacles=[]
                for r in fixed:
                    t=r['transform'];key=(r['part_id'],t['rotation_radians'],t['mirrored'],mi)
                    if key not in cache:cache[key]=geom.obstacle(local(r),g,required)
                    obstacles.append(translate(cache[key],*t['translation']))
                free=legal.difference(unary_union(obstacles));assert free.is_valid
                write(OUT/f'{label}-mode{mi:02d}.json',mapping(free))
                components=geom.polygons(free)
                records.append({'fixed':label,'mode':mi,'family':family,'area_mm2':free.area,'components':len(components),'bounds':None if free.is_empty else list(free.bounds),'representatives':[list(p.representative_point().coords)[0] for p in components]})
write(OUT/'modes.json',modes);write(OUT/'pockets.json',records)
write(OUT/'fixed57.json',[r for r in rows if r['sheet_id']=='sheet-1']+fixed57)
write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-start,'fixed64_bracket_positive_modes':sum(r['fixed']=='fixed64' and r['area_mm2']>0 for r in records),'fixed57_bracket_positive_modes':sum(r['fixed']=='fixed57' and r['family']=='bracket' and r['area_mm2']>0 for r in records),'fixed57_insert_positive_modes':sum(r['fixed']=='fixed57' and r['family']=='insert' and r['area_mm2']>0 for r in records),'local_source_obstacles':len(cache),'full66_witness':False,'infeasibility_claimed':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'result.json'));print(records)
