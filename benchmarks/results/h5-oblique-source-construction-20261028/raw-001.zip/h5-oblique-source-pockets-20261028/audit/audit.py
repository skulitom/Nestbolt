"""Check translated-cache pockets against direct world-source configuration construction."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,shape
from shapely.affinity import translate
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-oblique-source-pockets-20261028';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};all64=load(ROOT/'output/h5-oblique64-source-20261028/source64.json');all57=load(BASE/'fixed57.json');modes=load(BASE/'modes.json');required=plan['required_gap_mm'];geom.EPS=plan['construction_extra_mm']
def world(family,t):
    a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']])
fixed={name:[world(r['part_id'],r['transform']) for r in rows if r['sheet_id']=='sheet-0'] for name,rows in [('fixed64',all64),('fixed57',all57)]};checks=[];samples=0
assert len(all57)==57 and all(r in all64 for r in all57)
for row in load(BASE/'pockets.json'):
    i=row['mode'];mode=modes[i];g=world(mode['family'],{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],'translation':mode['source_translation_offset']});assert g.equals_exact(shape(mode['geometry']),1e-9)
    saved=shape(load(BASE/f"{row['fixed']}-mode{i:02d}.json"));fresh=geom.regions(g,fixed[row['fixed']],job['stocks'][0],job['edge_clearance'],required)
    delta=fresh.symmetric_difference(saved).area;assert delta<1e-6 and abs(saved.area-row['area_mm2'])<1e-8
    for xy in row['representatives']:
        placed=translate(g,*xy);b=placed.bounds;assert min(b[0]-6.5,b[1]-6.5,1493.5-b[2],2993.5-b[3])>3000*32*2**-23
        assert all(placed.distance(f)>required for f in fixed[row['fixed']]);samples+=1
    checks.append({'fixed':row['fixed'],'mode':i,'source_world_rebuild_difference_area_mm2':delta,'positive_area':saved.area>0})
write(OUT/'regions.json',checks)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'world_source_region_rebuilds':len(checks),'positive_representatives_source_checked':samples,'maximum_rebuild_area_difference_mm2':max(r['source_world_rebuild_difference_area_mm2'] for r in checks),'fixed57_is_exact_subset_of_valid64':True,'zero_fixed64_construction_pockets':True,'conservative_buffer_empty_regions_do_not_prove_source_impossibility':True,'external_solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
