"""One materially new17-mover source neighborhood from the audited phase7 layout."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon,mapping,box
from shapely.affinity import affine_transform,translate
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-oblique-joint-source-20261028';BASE=ROOT/'output/h5-oblique64-source-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'free').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+120
assert load(BASE/'audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};fixed=load(BASE/'fixed49-noncogs.json');source=load(BASE/'source64.json');required=.21170867250963943;geom.EPS=.0126
inputs=[JOB,BASE/'source64.json',BASE/'fixed49-noncogs.json',BASE/'audit/checks.json',ROOT/'output/h5-oblique-source-pockets-20261028/result.json',Path(geom.__file__)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'preparation_seconds':120,'search_seconds':60,'shared_search_seconds':90,'maximum_positional_stages':4,'per_stage_maximum_iterations':300,'per_stage_maximum_function_evaluations':700,'finite_cog_phases_degrees':[7.0],'allowed_bracket_modes':8,'required_pair_gap_mm':required,'stock_guard_mm':3000*32*2**-23,'construction_eps_mm':geom.EPS,
 'method':'Keep all49 independently source-valid noncogs from the new oblique64 layout fixed. All15 phase7 cogs may slide simultaneously, plus mandatory brackets10/11 with all8 allowed original modes. Initialize cogs at their audited source64 poses and the two missing brackets at the bottom corners of the cog region, with vertical outer stems and100mm bottom feet. All17 are mandatory; no source/copy/quantity change. The configuration differs from prior closed0/4.5/9/13.5-degree24/53-mover searches and corrected49 necessity models. One60-second deterministic L-BFGS/mode-descent run, maximum4 positional stages, one initial state and no random restart; preparation and diagnostics are not an H5 quality run. Audit source obstacles, fixed-free region samples and finite-difference objective gradients before the run. Independently read all66 original rings afterward. No native call without a complete source-valid66 witness.'})
def poly(family,a,mir):
    c,s=math.cos(a),math.sin(a);m=-1 if mir else 1
    return affine_transform(Polygon(parts[family]['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0])
def world(r):return translate(poly(r['part_id'],r['transform']['rotation_radians'],r['transform']['mirrored']),*r['transform']['translation'])
modes=[];shapes=[]
for family,angles,mirrors in [('cog',[math.radians(7)],[False]),('bracket',[q*math.pi/2 for q in range(4)],[False,True])]:
    for mir in mirrors:
        for a in angles:
            g=poly(family,a,mir);c,s=math.cos(a),math.sin(a)
            offset=[-139.723742*c+139.723742*s,-139.723742*s-139.723742*c] if family=='cog' else [-g.bounds[0],-g.bounds[1]]
            g=translate(g,*offset);modes.append({'index':len(modes),'family':family,'angle':a,'mirrored':mir,'source_translation_offset':offset,'geometry':mapping(g)});shapes.append(g)
fixed_first=[world(r) for r in fixed if r['sheet_id']=='sheet-0']
assert len(fixed_first)==36 and len(fixed)==49
for i,g in enumerate(shapes):
    assert time.perf_counter()<deadline
    free=geom.regions(g,fixed_first,job['stocks'][0],job['edge_clearance'],required);assert not free.is_empty and free.is_valid
    write(OUT/'free'/f'{i:02d}.json',mapping(free))
for i,g in enumerate(shapes):
    for j in range(i,len(shapes)):
        assert time.perf_counter()<deadline
        obstacle=geom.obstacle(g,shapes[j],required);assert not obstacle.is_empty and obstacle.is_valid
        write(OUT/'obstacles'/f'{i:02d}-{j:02d}.json',mapping(obstacle))
moving=[]
for r in source:
    if r['part_id']!='cog':continue
    off=modes[0]['source_translation_offset'];xy=[r['transform']['translation'][k]-off[k] for k in range(2)]
    moving.append({'original':51+r['copy_index'],'family':'cog','copy_index':r['copy_index'],'allowed_modes':[0],'initial_mode':0,'initial_anchor':xy})
for copy,mi,xy in [(10,8,[6.525,2107.875]),(11,2,[1243.475,2107.875])]:
    moving.append({'original':18+copy,'family':'bracket','copy_index':copy,'allowed_modes':list(range(1,9)),'initial_mode':mi,'initial_anchor':xy})
assert len(moving)==17 and len(modes)==9
write(OUT/'modes.json',modes);write(OUT/'fixed49.json',fixed);write(OUT/'moving.json',moving)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'modes':9,'free_regions':9,'unordered_configuration_obstacles':45,'moving_originals':17,'position_variables':34,'fixed_first_originals':36,'fixed_short_originals':13,'all66_originals_accounted':True,'optimizer_opened':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
