"""One bounded deterministic continuous/mode descent from the declared initial layout."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-oblique-joint-source-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class BudgetStop(Exception):pass
def child():
    import numpy as np
    import scipy
    from scipy.optimize import minimize
    from h5_oblique_sliding_objective import SlidingObjective
    assert load(BASE/'preflight/checks.json')['passed'];plan=load(BASE/'plan.json');obj=SlidingObjective(BASE);modes=[r['initial_mode'] for r in obj.moving];x=np.asarray([r['initial_anchor'] for r in obj.moving],dtype=float).reshape(-1);best=None;calls=0;improvements=[];stages=[];trials=[];changes=[];start=time.perf_counter();deadline=start+60
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'search_seconds':60,'maximum_positional_stages':4,'maxiter_per_stage':300,'maxfun_per_stage':700,'initial_configurations':1,'random_restarts':0,'scipy_version':scipy.__version__,'numpy_version':np.__version__,'native_calls':0})
    def evaluate(z,mi,kind):
        nonlocal calls,best
        if time.perf_counter()>=deadline:raise BudgetStop()
        value,gradient,diag=obj.evaluate(z,mi);calls+=1
        if best is None or value<best['value']:
            best={'value':float(value),'anchors':np.asarray(z).reshape(-1,2).tolist(),'modes':list(mi),'evaluation':calls,'seconds':time.perf_counter()-start,'diagnostics':diag};improvements.append({'evaluation':calls,'seconds':best['seconds'],'value':float(value),'kind':kind,**diag})
        return value,gradient,diag
    status='STAGE_LIMIT';message=None
    try:
        value,_,diag=evaluate(x,modes,'initial')
        for stage in range(4):
            before=time.perf_counter();before_value=value;stage_modes=list(modes)
            def fun(z):v,g,_=evaluate(z,stage_modes,f'position-{stage}');return v,g
            result=minimize(fun,x,jac=True,method='L-BFGS-B',options={'maxiter':300,'maxfun':700,'maxls':20,'ftol':1e-12,'gtol':1e-6});x=np.asarray(result.x);value,_,diag=evaluate(x,modes,f'position-{stage}-returned');stages.append({'stage':stage,'seconds':time.perf_counter()-before,'start_value':before_value,'returned_value':float(value),'scipy_success':bool(result.success),'scipy_status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'modes':list(modes)})
            if value<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            accepted=0
            for i,item in enumerate(obj.moving):
                original_mode=modes[i];chosen=original_mode;chosen_value=value
                for alternative in item['allowed_modes']:
                    if alternative==original_mode:continue
                    trial=list(modes);trial[i]=alternative;v,_,d=evaluate(x,trial,f'mode-{stage}-{i}');trials.append({'stage':stage,'original':item['original'],'from_mode':original_mode,'alternative_mode':alternative,'value':float(v),'accepted_as_best_in_sweep':v<chosen_value-1e-8})
                    if v<chosen_value-1e-8:chosen,chosen_value=alternative,v
                if chosen!=original_mode:changes.append({'stage':stage,'original':item['original'],'from_mode':original_mode,'to_mode':chosen,'before_value':float(value),'after_value':float(chosen_value)});modes[i]=chosen;value=chosen_value;accepted+=1
            if value<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            if accepted==0 and result.success:status='LOCAL_STATIONARY';break
    except BudgetStop:status='TIME_LIMIT';message='Declared60-second objective-evaluation deadline reached; no restart.'
    assert best is not None;write(OUT/'best.json',best);write(OUT/'best-moving-placements.json',obj.placements(best['anchors'],best['modes']));write(OUT/'improvements.json',improvements);write(OUT/'position-stages.json',stages);write(OUT/'mode-trials.json',trials);write(OUT/'accepted-mode-changes.json',changes)
    write(OUT/'result.json',{'status':status,'message':message,'search_seconds':time.perf_counter()-start,'objective_evaluations':calls,'positional_stages_returned':len(stages),'mode_trials':len(trials),'accepted_mode_changes':len(changes),'best_value':best['value'],'best_diagnostics':best['diagnostics'],'closed':True,'initial_configurations':1,'random_restarts':0,'all17_movers_mandatory':True,'source_readback_required':True,'source_feasible_claimed':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents};inputs['output/h5_oblique_sliding_objective.py']=digest(ROOT/'output/h5_oblique_sliding_objective.py');write(OUT/'plan.json',{'inputs':inputs,'search_seconds':60,'shared_seconds':90,'maximum_runs':1,'retry_permitted':False,'maximum_positional_stages':4,'initial_configurations':1,'random_restarts':0});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:(OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed response; run closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
