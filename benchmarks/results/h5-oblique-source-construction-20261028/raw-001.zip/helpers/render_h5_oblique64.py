"""Plot the independently valid partial64 from original source rings."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Patch
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-oblique64-source-20261028';OUT=BASE/'source64.png'
assert not OUT.exists()
load=lambda p:json.loads(p.read_bytes());assert load(BASE/'audit/checks.json')['passed']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};rows=load(BASE/'source64.json')
colors={'frame':'#a8c5e6','insert':'#c6afe3','cog':'#a7cfb5','bracket':'#edbb86'}
fig=plt.figure(figsize=(13,11),facecolor='white');gs=fig.add_gridspec(3,2,width_ratios=[1,1.9],height_ratios=[1.2,1,.7],wspace=.2,hspace=.34)
axes=[(fig.add_subplot(gs[:,0]),'sheet-0',[0,1500,0,3000],'First sheet: 51 parts'),(fig.add_subplot(gs[:2,1]),'sheet-0',[0,1500,2050,3000],'Upper region: all 15 cogs, 5 inserts, 2 brackets'),(fig.add_subplot(gs[2,1]),'sheet-1',[0,1500,0,325.9269023299994],'Short sheet: 8 brackets and 5 inserts')]
for ax,sheet,limits,title in axes:
    top=3000 if sheet=='sheet-0' else 325.9269023299994
    ax.add_patch(Rectangle((0,0),1500,top,facecolor='#fafafa',edgecolor='#222222',lw=1))
    ax.add_patch(Rectangle((6.5,6.5),1487,top-13,facecolor='none',edgecolor='#999999',lw=.6,linestyle='--'))
    for row in rows:
        if row['sheet_id']!=sheet:continue
        t=row['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        def ring(r):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in r]
        geo=parts[row['part_id']]['geometry'][0];xy=ring(geo['outer'])
        ax.add_patch(Polygon(xy,closed=True,facecolor=colors[row['part_id']],edgecolor='#44515c',lw=.5))
        for h in geo.get('holes',[]):ax.add_patch(Polygon(ring(h),closed=True,facecolor='none',edgecolor='#6f7982',lw=.3))
    ax.set(xlim=limits[:2],ylim=limits[2:],aspect='equal',title=title,xlabel='mm',ylabel='mm');ax.tick_params(labelsize=8);ax.spines[['top','right']].set_visible(False)
fig.suptitle('Verified 64-part construction — two mandatory brackets remain unplaced',fontsize=15,y=.985)
fig.legend(handles=[Patch(facecolor=v,edgecolor='#44515c',label=k.title()) for k,v in colors.items()],loc='lower center',ncol=4,bbox_to_anchor=(.5,.035),frameon=False)
fig.text(.5,.014,'Original outlines; holes remain reserved. Minimum pair gap 0.214827 mm. This is not a complete H5 layout.',ha='center',fontsize=10)
fig.savefig(OUT,dpi=160,bbox_inches='tight');plt.close(fig)
print(OUT)
