"""Seal the constructive source64, unsuccessful joint66 and their independent audits."""
from pathlib import Path
from datetime import datetime,timezone
import json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-oblique-source-construction-20261028';OUT=ROOT/'benchmarks/results'/NAME
SCAN=ROOT/'output/h5-cog-oblique-contacts-20261028';SOURCE=ROOT/'output/h5-oblique64-source-20261028';POCKET=ROOT/'output/h5-oblique-source-pockets-20261028';JOINT=ROOT/'output/h5-oblique-joint-source-20261028';PUB=ROOT/'output/h5-oblique-publication-20261028'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='f4f6f1fe473ae3c5da129c63441e6306980294b6'
assert not git('diff','HEAD','--name-only')
prior=load(ROOT/'benchmarks/results/h5-cog-corner-support-20261026/publication-review.json')
production=source_digest();assert production==prior['production_digest']
readmes={p:digest(ROOT/p) for p in prior['current_readmes']};assert readmes==prior['current_readmes']
review=[load(PUB/f'review-{i}.json') for i in range(5)]
upstream={'sparrow_head':review[0]['sha'],'studio_head':review[1]['sha'],'sparrow_release':review[2]['tag_name'],'studio_latest_release':[r['tag_name'] for r in review[3]]}
assert all(upstream[k]==prior[k] for k in upstream)
assert review[4]['head_sha']==head and review[4]['id']==40668367016 and review[4]['status']=='in_progress'
jobs=load(PUB/'ci-jobs-in-progress.json')['jobs'];assert len(jobs)==6 and sum(j['conclusion']=='success' for j in jobs)==5 and sum(j['status']=='in_progress' for j in jobs)==1
checks=[load(p) for p in [SOURCE/'audit/checks.json',POCKET/'audit/checks.json',JOINT/'preflight/checks.json',JOINT/'result-audit/checks.json']]
assert all(r['passed'] for r in checks) and checks[0]['source64_summary']['valid'] and not checks[3]['source_valid']
assert checks[3]['source_summary']['pair_failures']==33 and checks[3]['source_summary']['stock_failures']==2
OUT.mkdir();members={};queue=[];bindings={}
for folder in [SCAN,SOURCE,POCKET,JOINT,PUB,ROOT/'output/h5-reconciled-main-sync-20261028']:
    for p in folder.rglob('*'):
        if not p.is_file():continue
        members[folder.name+'/'+p.relative_to(folder).as_posix()]=p
        if p.name=='plan.json':queue.append(p)
seen=set()
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;members['source-inputs/'+n]=q
        if q.name=='plan.json':queue.append(q)
for name in ['scan_h5_cog_oblique_contacts.py','construct_h5_oblique64_source.py','audit_h5_oblique64_source.py','diagnose_h5_oblique_pockets.py','audit_h5_oblique_pockets.py','prepare_h5_oblique_joint_source.py','h5_oblique_sliding_objective.py','audit_h5_oblique_joint_preflight.py','run_h5_oblique_joint_source.py','audit_h5_oblique_joint_result.py','h5_legacy64_source_readback.py','diagnose_h5_concave_gaps.py','render_h5_oblique64.py','pack_h5_evidence_archive.py','ccd1.py']:
    members['helpers/'+name]=ROOT/'output'/name
members['helpers/seal_h5_oblique_checkpoint_20261028.py']=Path(__file__)
archive,manifest=pack(ROOT,OUT,NAME,members)
write(OUT/'source-bindings.json',bindings)
for p,n in [(SCAN/'result.json','contact-result.json'),(SOURCE/'source64.json','source64.json'),(SOURCE/'source64.png','source64.png'),(SOURCE/'audit/checks.json','source64-checks.json'),(POCKET/'pockets.json','anchor-pockets.json'),(POCKET/'audit/checks.json','pocket-checks.json'),(JOINT/'preflight/checks.json','joint-preflight-checks.json'),(JOINT/'search/result.json','joint-result.json'),(JOINT/'result-audit/checks.json','joint-source-checks.json'),(ROOT/'output/h5-reconciled-main-sync-20261028/receipt.json','prior-main-push.json'),(PUB/'ci-jobs-in-progress.json','prior-main-ci-snapshot.json')]:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'production_digest':production,'current_readmes':readmes,**upstream,'upstream_heads_and_releases_unchanged':True,'main_CI_run':40668367016,'main_CI_five_pass_one_running':True,'no_main_push_until_all6_pass':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':4,'verified_contacts':3888,'direct_contact_gap_checks':7776,'source64_valid':True,'mandatory_unplaced_brackets':2,'joint_source66_valid':False,'joint_source_pair_failures':33,'joint_source_stock_failures':2,'existing_searches_not_repeated':True,'all_new_searches_closed':True,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
write(OUT/'next-step.json',{'action':'Preserve main f4f6f1fe CI40668367016 until all six jobs pass; five passed and Windows checks were still running at this checkpoint. This evidence-only checkpoint can be committed locally, but do not push another main head over that live run. Recheck remote main and reconcile any new upstream changes before a normal fast-forward push. The original-source64 (all15 cogs,21 inserts,18 frames,10 brackets) is independently valid; bracket copies10/11 remain mandatory. The sole phase7/17-mover joint call stopped at a local minimum with33 actual source-pair failures and2 stock failures; it is closed, with no retry, reseed or extension. Conservative empty fixed64 anchor pockets do not prove actual-source impossibility. Do not transfer old fixed49/51 position-dependent exclusions. Seek a materially different construction or source-supported structural decomposition that changes the restrictive noncog arrangement or cog row structure; keep all66 originals, required clearances, PIH off and material target unchanged. Only a complete independently source-valid66 layout may go to the native validator; only then consider production integration and the full quality matrix. H2 remains open under the explicit retained-gate decision;22 reserved vectors remain unopened; no new release qualifies.','completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Original-source oblique cog construction — 2026-10-28

The new construction independently validates **64 of 66 original parts**, including
all15 cogs and all21 inserts. Bracket copies10/11 remain mandatory and unplaced.
It does not satisfy H5. A subsequent joint66 construction stops at a local minimum
and fails independent source readback; that failure is preserved in full.

![Verified partial construction; two brackets remain unplaced]({NAME}/source64.png)

## Finite source-contact scan

The declared36 phases (0° through17.5° by0.5°), all1,296 ordered pairs, and
directions0°/72°/108° yield3,888 contact cases and93,312 distance evaluations.
The original80-vertex outline has the origin in its star kernel. Every ray's
outward contact is bracketed on240–281mm with20 bisections; no tooth symmetry is
assumed to skip cases. The independent reader checks all80 exact kernel edges,
all7,776 bracket-end distances and all666 complete ranked phase pairs.
The best complete pair is7°/7°, with258.86mm conservative neighbor pitch.
The scan completes in2.786448 seconds,3.730314 shared seconds, within60/90 limits.
This finite construction does not exclude any unsampled phase or prove optimality.

## Valid source64

The15 original cogs form five columns and three alternating-offset rows:
79.992139mm row offset and246.190490mm row height. Their actual packet is
1,395.380539×772.329379mm. All42 prior core originals are unchanged. Five remaining
horizontal inserts and two top-corner brackets complete the64-part construction.
First-sheet counts are18 frames,16 inserts,15 cogs and2 brackets; the short sheet
retains8 brackets and5 inserts. The target stock bounds and PIH-off reservation
of filled outer outlines are unchanged.

Independent readback checks1,353 same-sheet source pairs,256 stock edges,
84 cutouts and9,294 hole vertices. There are **zero pair or stock failures**:
minimum pair gap0.2148269833mm exceeds the required0.2117086725mm, and the
minimum extra stock0.025mm exceeds the0.0114440918mm native guard. This check
uses original rings directly, independently of the contact scan and optimizer.

## Anchor pockets and the unsuccessful joint66

Source configuration obstacles give no positive-area bracket construction pocket
with the64 poses fixed. Removing the two top brackets and five top inserts yields
two bracket modes with pockets and two insert modes. All18 cached region results
are rebuilt from world-space original polygons; maximum difference area is
2.65e-11mm². All five positive representative poses pass direct source checks.
The clearance buffer and positive construction margin are conservative, so empty
regions are **not** an original-source impossibility proof.

One materially new neighborhood retains the49 valid noncog poses, frees all15
phase7 cog centers and both missing brackets, and permits all eight bracket modes.
The initial cogs are exactly the verified64 poses. Preflight checks all9 source
modes,729 source-obstacle samples,9 free-region representatives and34 objective
gradient components (maximum error4.57e-6). All66 source identities are accounted
for; the initial complete candidate has3 source-pair failures and no stock failure.

The single call returns `LOCAL_STATIONARY` after128 objective evaluations,
two positional stages and one mode change:0.046184 search/2.960379 shared seconds,
within the60/90 ceilings. It is closed without retry or restart. Independent
readback of its best penalty result checks all66 originals,1,456 source pairs,
264 stock edges,90 holes and10,026 hole vertices. It finds **33 pair failures and
2 stock failures**. Lower penalty is not source validity. This result proves
neither unrestricted infeasibility nor a fixed-arrangement exclusion. No native
validator, production change or full-quality rerun follows it.

## Publication and remaining work

The reconciled previous checkpoint is on main at `f4f6f1fe`; its14 upstream
layered-kit example files are preserved. At this checkpoint,
[its own CI](https://github.com/skulitom/Nestbolt/actions/runs/40668367016)
has five successful jobs and the Windows checks still running. Preserve that run
and wait for all six successes before the next normal main push. Production,
README files, Sparrow/Studio heads and releases are unchanged.

H2/H5 remain open at **60% completed milestone weight**. The22 reserved H2 vectors
remain unopened. This work provides a valid partial construction and a rejected
complete candidate, with no H5 credit or new release. Next seek a different cog
row structure or a change to the surrounding noncog arrangement; preserve all66
quantities, clearances and the original material target.

[Source64 checks]({NAME}/source64-checks.json),
[pocket checks]({NAME}/pocket-checks.json),
[joint preflight]({NAME}/joint-preflight-checks.json),
[joint source failure]({NAME}/joint-source-checks.json),
[publication review]({NAME}/publication-review.json),
[next step]({NAME}/next-step.json),
[byte-verified complete archive]({NAME}/raw-manifest.json).
The archive holds{archive['archive_members']} canonical files plus{archive['verified_aliases']}
exact-byte aliases ({archive['archive_bytes']:,} compressed bytes), including plans,
source inputs, scripts, all contacts, successful/failed readbacks and the prior
main-push receipt.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 oblique original-source construction, 2026-10-28:** [the evidence]({link})
independently verifies3,888 contact cases and a new source-valid64 layout with
all15 cogs and21 inserts. All1,353 source pairs and256 stock edges pass; minimum
gap0.2148269833mm and extra stock0.025mm exceed the unchanged guards. Two bracket
copies remain mandatory. Eighteen conservative anchor-pocket regions are rebuilt
from original world polygons; empty pockets are not source-impossibility proofs.
A new17-mover phase7 joint call closes at a local minimum after128 evaluations
in0.046184 search/2.960379 shared seconds. Its complete66 candidate fails33 source
pairs and2 stock edges, preserved with all90 holes/10,026 hole vertices. Four
independent audits pass, but there is no complete valid66 or native/H5 pass.
All searches stay closed; next change the structural arrangement, not the guard.
Mainf4f6f1fe preserves the layered-kit example and has five passing CI jobs, with
Windows still running; defer the next main push until all six pass. Production,
READMEs and upstream releases are unchanged. H2/H5 remain open at60%; all22
reserved vectors stay unopened and no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'completion_percent':60})
