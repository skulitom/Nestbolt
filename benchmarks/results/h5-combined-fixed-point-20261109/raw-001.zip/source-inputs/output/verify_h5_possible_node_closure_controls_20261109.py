"""Exhaustive finite oracle for query-signature closures and active restrictions."""
from pathlib import Path
from hashlib import sha256
import json, time
from h5_possible_node_closure_20261109 import intersection_closure, allowed_columns, column_closure, query_signature, column_signature

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/h5-possible-node-closure-controls-20261109'
OUT.mkdir()
started = time.perf_counter()
checked = restrictions = replay = 0
for matrix in range(512):
    rows = [(matrix >> (3 * qi)) & 7 for qi in range(3)]
    columns = allowed_columns(rows, [0, 1, 2])
    for source in range(8):
        signature = query_signature(rows, source)
        expected = 0
        # Independent finite oracle: union every set giving this exact signature.
        for candidate in range(8):
            if query_signature(rows, candidate) == signature:
                expected |= candidate
        possible = intersection_closure(rows, 7, signature)
        assert possible == column_closure(columns, signature) == expected
        assert source & ~possible == 0
        assert query_signature(rows, possible) == column_signature(columns, possible, 3) == signature
        checked += 1
        for active in range(8):
            conservative = query_signature(rows, possible & active)
            exact = query_signature(rows, source & active)
            assert source & active & ~(possible & active) == 0
            assert conservative & ~exact == 0
            assert signature & ~conservative == 0
            restrictions += 1
        replay += 1
# Keep noncompact original graph positions and multiple machine words explicit.
positions = [0, 7, 64, 129]
universe = sum(1 << p for p in positions)
for pattern in range(256):
    rows = [sum(1 << p for j, p in enumerate(positions) if pattern & (1 << ((j + qi) % 8))) for qi in range(8)]
    columns = allowed_columns(rows, positions)
    for subset in range(16):
        source = sum(1 << p for j, p in enumerate(positions) if subset & (1 << j))
        signature = query_signature(rows, source)
        possible = intersection_closure(rows, universe, signature)
        assert possible == column_closure(columns, signature)
        assert source & ~possible == 0
        assert query_signature(rows, possible) == column_signature(columns, possible, 8) == signature
        replay += 1
result = {'passed': True, 'exhaustive_three_node_three_query_cases': checked, 'active_mask_restrictions': restrictions, 'signature_replays': replay, 'possible_sets_are_upper_covers': True, 'optimizer_calls': 0, 'seconds': time.perf_counter() - started}
with (OUT / 'checks.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(result, f, indent=2); f.write('\n')
with (OUT / 'source-bindings.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump({p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), ROOT / 'output/h5_possible_node_closure_20261109.py']}, f, indent=2); f.write('\n')
print(result)
