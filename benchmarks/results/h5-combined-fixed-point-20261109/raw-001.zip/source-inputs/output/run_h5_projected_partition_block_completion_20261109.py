"""Complete untouched original slabs plus all proper replacement children once."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-projected-partition-20261109';OUT=ROOT/'output/h5-projected-partition-block-completion-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(BASE/'plan.json');replacement=load(ROOT/'output/h5-projected-partition-replacement-20261109/plan.json')
block_replacement=load(ROOT/'output/h5-projected-partition-block-replacement-20261109/plan.json')
for failed_slab in [2,3]:
    failed=load(ROOT/f'output/h5-fixed29-projected-atoms-09-{failed_slab}-process-20261109/process.json');assert failed['closed'] and not failed['passed'] and failed['job']['active_processes']==0
OUT.mkdir();pieces=[]
for spec in plan['slabs']:
    index,slab=spec['refinement_index'],spec['slab_index']
    if index==9 and slab in [2,3]:
        selected=replacement if slab==2 else block_replacement
        for child in selected['replacement_slabs']:
            ci=child['child_index'];prefix='h5-fixed29-projected-atoms' if slab==2 else 'h5-fixed29-block-atoms'
            pieces.append({'refinement_index':index,'slab_index':slab,'child_index':ci,'closed_x_bounds_um':child['closed_x_bounds_um'],'folder':f'output/h5-fixed29-projected-partition-20261109/choice-09-slab-{slab}-child-{ci}','process_label':f'{prefix}-09-{slab}-child-{ci}','already_consumed':slab==2 or ci==0})
    else:
        prior=index==1 or slab<2;prefix='h5-fixed29-projected-atoms' if prior else 'h5-fixed29-block-atoms'
        pieces.append({'refinement_index':index,'slab_index':slab,'child_index':None,'closed_x_bounds_um':spec['closed_x_bounds_um'],'folder':f'output/h5-fixed29-projected-partition-20261109/choice-{index:02d}-slab-{slab}','process_label':f'{prefix}-{index:02d}-{slab}','already_consumed':prior})
assert len(pieces)==38
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'plan.json',ROOT/'output/h5-projected-partition-replacement-20261109/plan.json',ROOT/'output/h5-fixed29-projected-atoms-09-2-process-20261109/process.json',ROOT/'output/h5-fixed29-projected-atoms-09-3-process-20261109/process.json',ROOT/'output/h5-projected-partition-block-replacement-20261109/plan.json']},'method':'Administrative completion of the exact original full domain. Reuse all previously completed pieces without rerunning, prove every proper replacement child, then open only previously untouched frozen original slabs. Both original failed parents and stopped runner remain closed. Each numerical worker retains60s/2GiB controls.','proof_slabs':pieces,'optimizer_calls':0,'retry_permitted':False})
write(OUT/'proof-slabs.json',pieces);write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'administrative_runner':True,'original_both_failed_parents_preserved':True})
for spec in pieces:
    for audit in [False,True]:
        label=spec['process_label']+('-audit' if audit else '');folder=ROOT/'output'/(label+'-process-20261109')
        if spec['already_consumed']:
            result=load(folder/'process.json');assert result['passed'] and result['closed'] and result['job']['active_processes']==0
        else:
            assert not folder.exists(),str(folder)
            wrapper=ROOT/'output'/('run_'+label.replace('-','_')+'_stage_20261109.py')
            r=subprocess.run([sys.executable,str(wrapper)],cwd=ROOT,capture_output=True)
            (OUT/(label+'-stdout.txt')).write_bytes(r.stdout);(OUT/(label+'-stderr.txt')).write_bytes(r.stderr)
            assert (folder/'process.json').is_file(),(r.returncode,r.stderr)
            result=load(folder/'process.json');assert r.returncode==0 and result['passed'] and result['closed'] and result['job']['active_processes']==0,(label,result)
        entry={'utc':datetime.now(timezone.utc).isoformat(),'case':spec['refinement_index'],'slab':spec['slab_index'],'child':spec['child_index'],'audit':audit,'complete_seconds':result['complete_seconds'],'passed':True,'reused':spec['already_consumed']}
        with (OUT/'progress.jsonl').open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(entry)+'\n')
        if not spec['already_consumed']:print(entry,flush=True)
write(OUT/'checks.json',{'passed':True,'all38_proof_slabs_complete':True,'all76_successful_processes_closed':True,'both_failed_parents_preserved':True,'no_consumed_process_repeated':True,'optimizer_calls':0})
print(load(OUT/'checks.json'),flush=True)
