"""Independent complementary-loss accumulation across every original audited slab."""
from pathlib import Path
from hashlib import sha256
import json,time,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-closure-plan-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
batch=int(sys.argv[1]);SOURCE=BASE/f'query-batch-{batch:02d}';OUT=SOURCE/'audit';OUT.mkdir();began=time.perf_counter();bindings=load(SOURCE/'plan.json')['inputs']
for name,h in bindings.items():assert digest(ROOT/name)==h
for p in [Path(__file__),SOURCE/'query-results.json',SOURCE/'checks.json']:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently accumulate uncovered-area losses per query by walking set bits, then subtract from the complete physical union area. Read each original slab separately rather than producer coalesced signatures. Bracket and insert losses use their own masks; joint loss uses their intersection. Reconstruct every source mapping target and compare every integer result. This checks all required representatives in the frozen batch, not a sample.'})
spec=load(BASE/'plan.json')['query_batches'][batch];index=spec['refinement_index'];data=load(PRE/f'choice-{index:02d}.json');representatives=data['required_representatives'];selected=spec['representative_positions'];query_indices=[representatives.index(p) for p in selected]
slots={qi:i for i,qi in enumerate(query_indices)};batch_mask=sum(1<<qi for qi in query_indices);losses=[[0,0,0] for _ in selected];total=0;signature_entries=0
pieces=[p for p in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json') if p['refinement_index']==index]
assert len(pieces)==(16 if index==1 else 22)
assert load(ROOT/'output/h5-complete-closure-all-batches-20261109/checks.json')['passed']
closure_maps=[{},{}]
for closure_spec in load(BASE/'plan.json')['closure_batches']:
    if closure_spec['refinement_index']!=index:continue
    closure_folder=BASE/f"closure-batch-{closure_spec['batch_index']:02d}"
    assert load(closure_folder/'audit/checks.json')['passed']
    for old,possible,new in load(closure_folder/'closures.json'):
        key=int(old,16);assert key not in closure_maps[closure_spec['family']]
        closure_maps[closure_spec['family']][key]=int(new,16)

for piece in pieces:
    folder=ROOT/piece['folder'];assert load(folder/'audit/checks.json')['passed']
    for ub,ui,area in load(folder/'atoms.json'):
        b=closure_maps[0][int(ub,16)];i=closure_maps[1][int(ui,16)];total+=area;signature_entries+=1
        for family,mask in enumerate([b,i,b&i]):
            remaining=mask&batch_mask
            while remaining:
                qi=remaining.bit_length()-1;losses[slots[qi]][family]+=area;remaining^=1<<qi
saved=load(SOURCE/'query-results.json');assert len(saved)==len(selected)
required=[279993000000,158392000000,438385000000];results=[];mapping=dict(data['pivot_to_representative']);active=load(ROOT/f'benchmarks/results/h5-complete-reference-capacity-20261109/choice-{index:02d}-frontier.json')['remaining_current_positions']
for position,qi,loss,row in zip(selected,query_indices,losses,saved):
    areas=[total-value for value in loss];failures=[k for k,(value,need) in enumerate(zip(areas,required)) if value<need]
    forbidden=int(data['representative_active_forbidden_rows_hex'][qi],16);allowed=sum(not forbidden>>p&1 for p in active)
    excluded=sorted(p for p in data['active_bracket_pivots'] if p in set(active) and mapping[p]==position) if failures else []
    expected={'refinement_index':index,'representative_current_position':position,'representative_query_index':qi,'allowed_current_nodes':allowed,'family_and_joint_area_upper_um2':areas,'failing_area_indices':failures,'provisional_reference_query_excluded':bool(failures),'dominated_active_bracket_positions_excluded':excluded}
    assert row==expected;results.append({**expected,'reference_query_excluded':bool(failures)})
process=load(ROOT/f'output/h5-restricted-closure-query-batch-{batch:02d}-process-20261109/process.json');assert process['passed'] and process['closed']
write(OUT/'query-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'batch_index':batch,'refinement_index':index,'representative_queries_verified':len(results),'conservative_area_bounds_verified':3*len(results),'original_slab_signature_entries_checked':signature_entries,'excluded_queries':sum(r['reference_query_excluded'] for r in results),'excluded_active_bracket_positions':sum(len(r['dominated_active_bracket_positions_excluded']) for r in results),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
