"""Independently reconcile every source signature and complete frozen batch."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json, time

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-complete-closure-plan-20261109'
OUT = BASE / 'audit'
load = lambda p: json.loads(p.read_bytes())
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

OUT.mkdir()
started = time.perf_counter()
plan = load(BASE / 'plan.json')
for name, digest in plan['inputs'].items():
    assert sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
manifest = load(ROOT / 'output/h5-projected-partition-block-completion-20261109/proof-slabs.json')
covered = count = physical = 0
for case in [1, 9]:
    actual = defaultdict(int)
    for item in reversed(manifest):
        if item['refinement_index'] != case:
            continue
        for b, i, area in load(ROOT / item['folder'] / 'atoms.json'):
            actual[(int(b, 16), int(i, 16))] += area
            physical += 1
    records = load(BASE / f'choice-{case:02d}-atoms.json')
    assert len(records) == len(actual)
    assert {(int(b, 16), int(i, 16)): a for b, i, a in records} == actual
    data = load(ROOT / f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json')
    current = load(ROOT / f'benchmarks/results/h5-complete-reference-capacity-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions']
    assert len(current) == (3801 if case == 1 else 4781)
    assert len(current) == len(set(current)) and set(current) < set(data['active_current_positions'])
    assert sum(actual.values()) == (497091028543 if case == 1 else 484740614909)
    for family in range(2):
        values = load(BASE / f'choice-{case:02d}-family-{family}-signatures.json')
        assert [int(v, 16) for v in values] == sorted({pair[family] for pair in actual})
        bounds = []
        for task in plan['closure_batches']:
            if task['refinement_index'] == case and task['family'] == family:
                assert task['first'] < task['stop'] <= len(values)
                bounds.extend(range(task['first'], task['stop']))
        assert bounds == list(range(len(values)))
        covered += len(bounds)
    reps = []
    for task in plan['query_batches']:
        if task['refinement_index'] == case:
            reps.extend(task['representative_positions'])
    assert reps == data['required_representatives']
    count += len(reps)
assert [t['batch_index'] for t in plan['closure_batches']] == list(range(88))
result = {'passed': True, 'seconds': time.perf_counter() - started, 'physical_entries': physical, 'unique_family_signatures': covered, 'all_representatives': count, 'closure_batches': 88, 'query_batches': 50, 'source_bindings': len(plan['inputs']), 'optimizer_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', result)
write(OUT / 'source-bindings.json', {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), BASE / 'plan.json', BASE / 'case-summary.json']})
print(result)
