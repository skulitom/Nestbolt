"""Check each node by allowed-query columns and independently replay both masks."""
from pathlib import Path
from hashlib import sha256
import json, sys, time
from h5_possible_node_closure_20261109 import allowed_columns, column_closure, column_signature

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-complete-closure-plan-20261109'
load = lambda p: json.loads(p.read_bytes())
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

batch = int(sys.argv[1])
folder = BASE / f'closure-batch-{batch:02d}'
OUT = folder / 'audit'
OUT.mkdir()
started = time.perf_counter()
plan = load(folder / 'plan.json')
for name, digest in plan['inputs'].items():
    assert sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
task = load(BASE / 'plan.json')['closure_batches'][batch]
assert task == plan['batch']
case, family = task['refinement_index'], task['family']
data = load(ROOT / f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json')
positions = sorted(r['current_position'] for r in data['node_regions'] if r['family'] == family)
universe = sum(1 << p for p in positions)
rows = [int(v, 16) & universe for v in data['representative_active_forbidden_rows_hex']]
columns = allowed_columns(rows, positions)
active = set(load(ROOT / f'benchmarks/results/h5-complete-reference-capacity-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions'])
active_columns = [(p, v) for p, v in columns if p in active]
expected = load(BASE / f'choice-{case:02d}-family-{family}-signatures.json')[task['first']:task['stop']]
records = load(folder / 'closures.json')
assert [row[0] for row in records] == expected
changed = 0
for old_text, possible_text, restricted_text in records:
    old = int(old_text, 16)
    possible = column_closure(columns, old)
    assert hex(possible) == possible_text
    assert column_signature(columns, possible, len(rows)) == old
    restricted = column_signature(active_columns, possible, len(rows))
    assert hex(restricted) == restricted_text and old & ~restricted == 0
    changed += restricted != old
result = {'passed': True, 'seconds': time.perf_counter() - started, 'batch_index': batch, 'family_signatures': len(records), 'tightened_signatures': changed, 'per_node_memberships_verified': len(records) * len(positions), 'original_and_restricted_signature_replays': 2 * len(records), 'optimizer_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', result)
write(OUT / 'source-bindings.json', {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), ROOT / 'output/h5_possible_node_closure_20261109.py', folder / 'plan.json', folder / 'closures.json']})
print(result)
