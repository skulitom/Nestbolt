"""Exhaust all node and query subsets, both compact and cross-word source indices."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_block_projected_coverage_atoms_20261109 import forbidden_projection,allowed_projection
from h5_projected_coverage_atoms_20261109 import vertical_atoms,horizontal_atoms
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-block-query-projection-controls-20261109'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter()
new=ROOT/'output/h5_block_projected_coverage_atoms_20261109.py';old=ROOT/'output/h5_projected_coverage_atoms_20261109.py'
assert new.read_text().split('def vertical_atoms',1)[1]==old.read_text().split('def vertical_atoms',1)[1]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),new,old,ROOT/'output/h5-projected-coverage-atom-controls-20261109/checks.json',ROOT/'output/h5-projected-coverage-atom-controls-20261109/plan.json']},'method':'Prove the unchanged geometric sweep source byte-for-byte. For both node sets0..7 and0,1,7,8,63,64,129,511, exhaust all256covering-node subsets against all256forbidden-query subsets. Direct boolean membership independently enumerates both family query signatures. Compare eight-node intersection tables and independently constructed four-node union tables. Also replay geometric overlapping-cover cases under both new projectors against the already controlled geometric sweeps.','process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
checks=0;geometric=0
for nodes in [list(range(8)),[0,1,7,8,63,64,129,511]]:
    forbidden=[sum(1<<n for k,n in enumerate(nodes) if q>>k&1) for q in range(256)]
    data={'current_nodes':max(nodes)+1,'representative_active_forbidden_rows_hex':[hex(v) for v in forbidden],'node_regions':[{'current_position':n,'family':k%2} for k,n in enumerate(nodes)]}
    producer=forbidden_projection(data);audit=allowed_projection(data)
    for selection in range(256):
        mask=sum(1<<n for k,n in enumerate(nodes) if selection>>k&1);expected=[]
        for family in range(2):
            uncovered=0
            for query in range(256):
                if not any(k%2==family and selection>>k&1 and not query>>k&1 for k in range(8)):uncovered|=1<<query
            expected.append(uncovered)
        assert producer(mask)==audit(mask)==tuple(expected);checks+=256
    rectangles=[(n,(k%3,k%2,4+k%3,4+k%2)) for k,n in enumerate(nodes)]+[(-1,(1,1,3,3))]
    assert vertical_atoms(rectangles,max(nodes)+1,0,6,producer)==horizontal_atoms(rectangles,max(nodes)+1,0,6,audit);geometric+=1
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'complete_node_query_membership_cases':checks,'complete_cover_signatures':512,'geometric_cross_checks':geometric,'unchanged_sweep_source_verified':True,'arbitrary_node_word_boundaries_verified':True,'optimizer_calls':0})
print(json.loads((OUT/'checks.json').read_bytes()))
