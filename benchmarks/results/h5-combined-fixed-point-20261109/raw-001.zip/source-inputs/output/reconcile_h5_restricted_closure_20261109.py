"""Reconcile complete closure coverage, every conditional result, and closed jobs."""
from pathlib import Path
from hashlib import sha256
import json, time
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-complete-closure-plan-20261109'
OUT = BASE / 'reconciliation'
PRIOR = ROOT / 'benchmarks/results/h5-complete-reference-capacity-20261109'
load = lambda p: json.loads(p.read_bytes())
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
OUT.mkdir()
started = time.perf_counter()
bindings = {}
def bind(p):
    key = p.relative_to(ROOT).as_posix()
    value = sha256(p.read_bytes()).hexdigest()
    assert key not in bindings or bindings[key] == value, key
    bindings[key] = value
def verify(mapping):
    for name, expected in mapping.items():
        if name not in bindings:
            bind(ROOT / name)
        assert bindings[name] == expected, name
plan = load(BASE / 'plan.json')
assert load(BASE / 'audit/checks.json')['passed']
verify(plan['inputs'])
verify(load(BASE / 'audit/source-bindings.json'))
verify(load(ROOT / 'output/h5-possible-node-closure-controls-20261109/source-bindings.json'))
for folder in ['h5-complete-closure-all-batches-20261109', 'h5-restricted-closure-query-all-batches-20261109']:
    p = ROOT / 'output' / folder / 'checks.json'
    assert load(p)['passed']; bind(p)
processes = []
cost = plan['inherited_numeric_preparation_seconds']
assert cost == 984.3041554994415
def process(label, charge):
    global cost
    folder = ROOT / 'output' / (label + '-process-20261109')
    v = load(folder / 'process.json')
    assert v['passed'] and v['closed'] and v['job']['closed'] and v['job']['active_processes'] == 0
    assert v['job']['job_committed_memory_limit'] == 2**31
    bind(folder / 'process.json'); bind(folder / 'opened.json')
    verify(load(folder / 'opened.json')['inputs'])
    if charge:
        cost += v['complete_seconds']
    processes.append({'stage': label, 'complete_seconds': v['complete_seconds'], 'passed': True, 'closed': True, 'active_processes': 0, 'newly_charged_here': charge})
for label, charge in [('h5-possible-node-closure-controls', True), ('h5-complete-closure-plan', True), ('h5-complete-closure-plan-audit', False)]:
    process(label, charge)
old_queries = {(r['refinement_index'], r['representative_query_index']): r for r in load(PRIOR / 'all3138-query-results.json')}
bind(PRIOR / 'all3138-query-results.json')
cases = []
all_results = []
memberships = replays = signatures = 0
for case in [1, 9]:
    source = ROOT / f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json'
    front = PRIOR / f'choice-{case:02d}-frontier.json'
    data = load(source); bind(source); bind(front)
    active = load(front)['remaining_current_positions']
    active_set = set(active)
    assert active_set < set(data['active_current_positions'])
    active_mask = sum(1 << p for p in active)
    graph = ROOT / data['graph']
    nodes = load(graph / 'nodes.json')
    raw = (graph / 'conflicts.bin').read_bytes()
    width = (len(nodes) + 7) // 8
    bind(graph / 'nodes.json'); bind(graph / 'conflicts.bin')
    closures = [{}, {}]
    for spec in plan['closure_batches']:
        if spec['refinement_index'] != case:
            continue
        bi = spec['batch_index']; folder = BASE / f'closure-batch-{bi:02d}'
        verify(load(folder / 'plan.json')['inputs'])
        verify(load(folder / 'audit/source-bindings.json'))
        audit = load(folder / 'audit/checks.json'); assert audit['passed']; bind(folder / 'audit/checks.json')
        rows = load(folder / 'closures.json')
        expected = load(BASE / f"choice-{case:02d}-family-{spec['family']}-signatures.json")[spec['first']:spec['stop']]
        assert [r[0] for r in rows] == expected
        for old, possible, new in rows:
            key = int(old, 16)
            assert key not in closures[spec['family']]
            closures[spec['family']][key] = (int(possible, 16), int(new, 16))
            assert key & ~int(new, 16) == 0
        signatures += len(rows)
        memberships += audit['per_node_memberships_verified']
        replays += audit['original_and_restricted_signature_replays']
        process(f'h5-possible-node-closure-{bi:02d}', True)
        process(f'h5-possible-node-closure-{bi:02d}-audit', False)
    results = []
    for spec in plan['query_batches']:
        if spec['refinement_index'] != case:
            continue
        bi = spec['batch_index']; folder = BASE / f'query-batch-{bi:02d}'
        verify(load(folder / 'audit/plan.json')['inputs'])
        audit = load(folder / 'audit/checks.json'); assert audit['passed']; bind(folder / 'audit/checks.json')
        rows = load(folder / 'audit/query-results.json'); bind(folder / 'audit/query-results.json')
        assert [r['representative_current_position'] for r in rows] == spec['representative_positions']
        for row in rows:
            old = old_queries[(case, row['representative_query_index'])]
            assert all(a <= b for a, b in zip(row['family_and_joint_area_upper_um2'], old['family_and_joint_area_upper_um2']))
        results.extend(rows)
        process(f'h5-restricted-closure-query-batch-{bi:02d}', True)
        process(f'h5-restricted-closure-query-batch-{bi:02d}-audit', False)
    assert [r['representative_current_position'] for r in results] == data['required_representatives']
    by_rep = {r['representative_current_position']: r for r in results}
    exclusions = []
    targets = []
    for p, rep in data['pivot_to_representative']:
        if p not in active_set:
            continue
        qi = data['required_representatives'].index(rep)
        rep_row = int(data['representative_active_forbidden_rows_hex'][qi], 16) & active_mask
        pivot_row = (int.from_bytes(raw[p * width:(p + 1) * width], 'little') | (1 << p)) & active_mask
        assert rep_row & ~pivot_row == 0
        targets.append(p)
        if by_rep[rep]['reference_query_excluded']:
            exclusions.append({'current_position': p, 'representative_current_position': rep, 'failing_area_indices': by_rep[rep]['failing_area_indices']})
    excluded = {r['current_position'] for r in exclusions}
    assert sorted(excluded) == sorted(p for row in results for p in row['dominated_active_bracket_positions_excluded'])
    remaining = [p for p in active if p not in excluded]
    # These global bounds are conservative closure areas after only this round's removals.
    remaining_mask = sum(1 << p for p in remaining)
    global_bounds = [0, 0, 0]
    for b, i, area in load(BASE / f'choice-{case:02d}-atoms.json'):
        cb = bool(closures[0][int(b, 16)][0] & remaining_mask)
        ci = bool(closures[1][int(i, 16)][0] & remaining_mask)
        for family, covered in enumerate([cb, ci, cb or ci]):
            if covered:
                global_bounds[family] += area
    counts = [sum(nodes[p]['family'] == f for p in remaining) for f in range(2)]
    lower = [319992000000, 158392000000, 478384000000]
    scope_excluded = any(n < 8 for n in counts) or any(a < b for a, b in zip(global_bounds, lower))
    result = {'refinement_index': case, 'empty_sites': data['empty_sites'], 'active_nodes_before': len(active), 'complete_query_rows': len(results), 'current_bracket_mapping_targets': len(targets), 'excluded_queries_including_already_removed_targets': sum(r['reference_query_excluded'] for r in results), 'new_bracket_cells_excluded': len(excluded), 'remaining_current_nodes': len(remaining), 'remaining_family_counts': counts, 'conservative_global_closure_area_upper_um2': global_bounds, 'whole_scope_excluded': scope_excluded}
    cases.append(result); all_results.extend(results)
    write(OUT / f'choice-{case:02d}-exclusions.json', exclusions)
    write(OUT / f'choice-{case:02d}-frontier.json', {**result, 'graph': data['graph'], 'remaining_current_positions': remaining, 'seed_exclusions_only': True, 'additional_root_clique_propagation_performed': False, 'current_graph_positions_not_recompacted': True})
assert signatures == 87484 and len(all_results) == 3138 and len(processes) == 279
assert sum(r['current_bracket_mapping_targets'] for r in cases) == 5070
bind(Path(__file__))
write(OUT / 'plan.json', {'inputs': bindings, 'method': 'Complete single-round reconciliation. Verify all closure proofs and process pins; require every original query and all 5070 current bracket mapping targets. Compare every new conditional upper bound to its original bound, replay raw graph-row subset transfer, and remove only independently audited deficit seeds. Compute conservative global closure areas. No additional clique propagation or second round is implied.', 'optimizer_calls': 0})
write(OUT / 'case-results.json', cases)
write(OUT / 'query-results.json', all_results)
write(OUT / 'process-summary.json', processes)
checks = {'passed': True, 'seconds': time.perf_counter() - started, 'complete_scopes': 2, 'unique_family_signatures_verified': signatures, 'node_memberships_verified': memberships, 'signature_replays': replays, 'complete_query_rows': 3138, 'conservative_conditional_area_bounds': 9414, 'current_bracket_mapping_targets': 5070, 'new_bracket_cells_excluded': sum(r['new_bracket_cells_excluded'] for r in cases), 'remaining_current_nodes': sum(r['remaining_current_nodes'] for r in cases), 'remaining_fixed29_cases': sum(not r['whole_scope_excluded'] for r in cases), 'all279_prior_new_processes_closed': True, 'complete_preparation_seconds_before_this_reconciliation': cost, 'inherited_preparation_seconds': 984.3041554994415, 'common_line_holes_reserved': True, 'ordinary_part_in_hole_exclusions': 0, 'whole_allocations_remaining': 440, 'optimizer_allowed_from_current_lineage': False, 'optimizer_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks); print(cases)
