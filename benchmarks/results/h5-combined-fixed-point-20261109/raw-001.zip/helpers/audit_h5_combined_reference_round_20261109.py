"""Independently project changed covers, recompute all losses, and replay counts."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import allowed_projection
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-combined-reference-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
iteration=int(sys.argv[1]);SOURCE=BASE/f'round-{iteration:02d}';OUT=SOURCE/'audit';process_file=ROOT/f'output/h5-combined-reference-round-{iteration:02d}-process-20261109/process.json';process=load(process_file)
assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings=dict(load(SOURCE/'plan.json')['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
for name,h in load(ROOT/'output/h5-combined-query-controls-20261109/source-bindings.json').items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h;bindings[name]=h
plan=load(BASE/'plan.json');summaries=load(SOURCE/'case-results.json');results=[];signature_count=physical_count=query_count=0
for case,summary in zip([1,9],summaries):
    data=load(BASE/f'choice-{case:02d}-queries.json');saved=load(SOURCE/f'choice-{case:02d}-frontier.json')
    if iteration==0:prior=data['baseline_active_positions'];active=data['initial_active_positions'];old_signatures=None
    else:
        previous=BASE/f'round-{iteration-1:02d}';previous_front=load(previous/f'choice-{case:02d}-frontier.json');prior=previous_front['input_active_positions'];active=previous_front['remaining_current_positions'];old_signatures=load(previous/f'choice-{case:02d}-signatures.json');assert load(previous/'audit/checks.json')['passed']
    assert saved['input_active_positions']==active
    prior_mask=sum(1<<p for p in prior);active_mask=sum(1<<p for p in active);assert active_mask&~prior_mask==0;removed_mask=prior_mask^active_mask
    project=allowed_projection(data);current_signatures=load(SOURCE/f'choice-{case:02d}-signatures.json');maps=[{},{}]
    changed=[0,0];reprojected=[0,0]
    for family in range(2):
        records=load(BASE/f'choice-{case:02d}-family-{family}-covers.json');assert len(current_signatures[family])==len(records)
        for index,(key,possible_text,baseline) in enumerate(records):
            possible=int(possible_text,16);old=int(baseline if old_signatures is None else old_signatures[family][index][1],16)
            if possible&removed_mask:current=project(possible&active_mask)[family];reprojected[family]+=1
            else:current=old
            assert current_signatures[family][index]==[key,hex(current)] and old&~current==0
            maps[family][int(key,16)]=current;changed[family]+=current!=old;signature_count+=1
    total=0;weighted=[[],[],[]]
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index']!=case:continue
        for b,i,area in load(ROOT/piece['folder']/'atoms.json'):
            b=maps[0][int(b,16)];i=maps[1][int(i,16)]
            for f,mask in enumerate([b,i,b&i]):weighted[f].append((mask,area))
            total+=area;physical_count+=1
    losses=[weighted_query_sums(values,len(data['query_positions'])) for values in weighted];rows_saved=load(SOURCE/f'choice-{case:02d}-queries.json');assert len(rows_saved)==len(data['query_positions'])
    active_set=set(active);seed_set=set();targets_checked=set()
    for qi,row in enumerate(rows_saved):
        areas=[total-losses[f][qi] for f in range(3)];family=data['query_families'][qi];fails=[f for f,(a,b) in enumerate(zip(areas,data['required_by_reference_family_um2'][family])) if a<b]
        targets=[p for p in data['query_targets'][qi] if p in active_set];targets_checked.update(targets);rejected=targets if fails else []
        expected={'query_index':qi,'reference_family':family,'reference_current_position':data['query_positions'][qi],'family_and_joint_area_upper_um2':areas,'failing_area_indices':fails,'excluded_current_targets':rejected}
        assert row==expected;seed_set.update(rejected);query_count+=1
    assert targets_checked==active_set and saved['conditional_removed_positions']==sorted(seed_set)
    graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8;cliques=[[int(v,16) for v in family] for family in data['root_clique_masks_hex']]
    current=active_mask&~sum(1<<p for p in seed_set);rounds=saved['clique_rounds'];assert 1<=len(rounds)<=plan['maximum_clique_passes_per_round']
    for step,record in enumerate(rounds):
        expected=[]
        for p in active:
            if not current&(1<<p):continue
            forbidden=int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p);allowed=current&~forbidden
            upper=[sum((group&allowed)!=0 for group in family) for family in cliques];required=[8-(nodes[p]['family']==0),8-(nodes[p]['family']==1)]
            if upper[0]<required[0] or upper[1]<required[1]:expected.append({'current_position':p,'upper':upper,'required':required})
        assert record=={'pass_index':step,'removed':expected}
        if not expected:assert step==len(rounds)-1
        current&=~sum(1<<r['current_position'] for r in expected)
    retained=[p for p in active if current&(1<<p)];assert retained==saved['remaining_current_positions']
    counts=[sum(bool(group&current) for group in family) for family in cliques]
    assert summary['changed_signatures_by_family']==changed and summary['reprojected_records_by_family']==reprojected
    assert summary['input_nodes']==len(active) and summary['remaining_nodes']==len(retained) and summary['conditional_seed_exclusions']==len(seed_set)
    assert summary['clique_exclusions']==sum(len(r['removed']) for r in rounds) and summary['conditional_seeds_by_family']==[sum(nodes[p]['family']==f for p in seed_set) for f in range(2)]
    assert summary['global_clique_upper_counts']==counts and summary['scope_excluded']==any(n<8 for n in counts) and summary['fixed_point']==(active==retained)
    results.append(summary)
assert signature_count==87484 and physical_count==151597 and query_count==6650
cost=plan['inherited_numeric_preparation_seconds'];processes=[]
for label,charge in [('h5-combined-reference-plan',True)]+[(f'h5-combined-reference-round-{i:02d}',True) for i in range(iteration+1)]:
    folder=ROOT/'output'/(label+'-process-20261109');v=load(folder/'process.json');assert v['passed'] and v['closed'] and v['job']['active_processes']==0
    cost+=v['complete_seconds'];processes.append({'stage':label,'complete_seconds':v['complete_seconds'],'charged':charge})
    for p in [folder/'process.json',folder/'opened.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
for p in [Path(__file__),ROOT/'output/h5_weighted_query_masks_20261109.py',SOURCE/'plan.json']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Independent allowed-union projection of every changed possible-node intersection and exact unchanged-set carry-forward. Full weighted loss vectors recomputed from every original physical proof piece. Check all19950 bounds, all6650reference identities, every surviving target and all simultaneous clique implications. Producer terminal success required.'})
checks={'passed':True,'seconds':time.perf_counter()-began,'round_index':iteration,'complete_cases':2,'complete_queries':query_count,'conditional_area_bounds':3*query_count,'possible_node_records':signature_count,'original_physical_entries':physical_count,'conditional_seed_exclusions':sum(r['conditional_seed_exclusions'] for r in results),'clique_exclusions':sum(r['clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'joint_fixed_point':all(r['fixed_point'] for r in results),'all_scopes_excluded':all(r['scope_excluded'] for r in results),'remaining_fixed29_cases':sum(not r['scope_excluded'] for r in results),'complete_preparation_seconds_if_consumed':cost,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False}
write(OUT/'case-results.json',results);write(OUT/'checks.json',checks);print(checks);print(results)
