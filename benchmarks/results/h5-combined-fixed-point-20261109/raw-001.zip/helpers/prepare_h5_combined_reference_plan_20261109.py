"""Freeze complete combined reference families and a bounded monotone proof loop."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-combined-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-complete-insert-capacity-20261109'
OLD=ROOT/'output/h5-complete-closure-plan-20261109';INSERT=ROOT/'output/h5-complete-insert-reference-20261109';BRACKET=ROOT/'output/h5-incremental-closure-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PARENT/'archive-checks.json')['passed'] and load(ROOT/'output/h5-combined-query-controls-20261109/checks.json')['passed']
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),PARENT/'archive-checks.json',PARENT/'checks.json',ROOT/'output/h5-combined-query-controls-20261109/checks.json',ROOT/'output/h5-combined-query-controls-20261109/source-bindings.json',ROOT/'output/h5-combined-query-controls-process-20261109/process.json',OLD/'plan.json',OLD/'checkpoint-audit/checks.json',INSERT/'plan.json',INSERT/'preflight-audit/checks.json',INSERT/'preflight-audit/plan.json',BRACKET/'audit-v2/checks.json',BRACKET/'audit-v2/plan.json',BRACKET/'producer/query-results.json',ROOT/'output/h5-fixed29-conditional-frontier-20261108/audit/checks.json',ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json']
geometries=load(ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json');summaries=[]
bracket_results=load(BRACKET/'producer/query-results.json')
for case in [1,9]:
    original=ROOT/f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json';bdata=load(original);idata=load(INSERT/f'choice-{case:02d}-queries.json')
    graph=ROOT/bdata['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    initial=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];baseline=idata['active_current_positions'];assert set(initial)<set(baseline)
    baseline_mask=sum(1<<p for p in baseline);initial_set=set(initial)
    bpos=bdata['required_representatives'];ipos=idata['insert_reference_positions'];positions=bpos+ipos;rows=[];witnesses=ROOT/f'output/h5-fixed29-conditional-frontier-20261108/choice-{case:02d}-frontier.json';components=load(witnesses)['source_self_collision_components']
    for p in positions:
        l,b,r,t=nodes[p]['bounds_um'];component=geometries[nodes[p]['geometry']]['inner_rectangles_um'][components[p]]
        assert r-l<component[2]-component[0] and t-b<component[3]-component[1]
        rows.append((int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p))&baseline_mask)
    assert rows[:len(bpos)]==[int(v,16)&baseline_mask for v in bdata['representative_active_forbidden_rows_hex']]
    assert rows[len(bpos):]==[int(v,16) for v in idata['representative_active_forbidden_rows_hex']]
    targets={p:[] for p in bpos}
    for p,rep in bdata['pivot_to_representative']:
        if p in initial_set:targets[rep].append(p)
    query_targets=[targets[p] for p in bpos]+[[p] if p in initial_set else [] for p in ipos]
    bresults=[r for r in bracket_results if r['refinement_index']==case];iresults=load(INSERT/f'choice-{case:02d}-areas/query-results.json')
    assert [r['representative_current_position'] for r in bresults]==bpos and [r['insert_current_position'] for r in iresults]==ipos
    values=[r['family_and_joint_area_upper_um2'] for r in bresults+iresults]
    bsign=load(BRACKET/f'producer/choice-{case:02d}-signatures.json');bsign=[{key:int(value,16) for key,value in family} for family in bsign]
    isign=[{},{}]
    for spec in load(INSERT/'plan.json')['projection_batches']:
        if spec['refinement_index']!=case:continue
        folder=INSERT/f"projection-batch-{spec['batch_index']:02d}";assert load(folder/'audit/checks.json')['passed'];inputs.extend([folder/'projected-signatures.json',folder/'audit/plan.json',folder/'audit/checks.json'])
        for key,value in load(folder/'projected-signatures.json'):isign[spec['family']][key]=int(value,16)
    covers=[[],[]]
    for spec in load(OLD/'plan.json')['closure_batches']:
        if spec['refinement_index']!=case:continue
        family=spec['family'];folder=OLD/f"closure-batch-{spec['batch_index']:02d}";inputs.extend([folder/'closures.json',folder/'audit/checks.json',folder/'audit/source-bindings.json'])
        for key,possible,prior in load(folder/'closures.json'):covers[family].append([key,possible,hex(bsign[family][key]|(isign[family][key]<<len(bpos)))])
    groups=load(graph/'root-covers.json');cliques=[]
    for family,family_groups in enumerate(groups):
        seen=set();masks=[]
        for group in family_groups:
            assert len(set(group))==len(group) and all(nodes[p]['family']==family for p in group)
            mask=sum(1<<p for p in group)
            for p in group:assert ((int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p))&mask)==mask
            seen.update(group);masks.append(hex(mask))
        assert seen=={p for p,node in enumerate(nodes) if node['family']==family};cliques.append(masks)
    record={'refinement_index':case,'empty_sites':bdata['empty_sites'],'graph':bdata['graph'],'current_nodes':len(nodes),'baseline_active_positions':baseline,'initial_active_positions':initial,'bracket_query_count':len(bpos),'insert_query_count':len(ipos),'query_positions':positions,'query_families':[0]*len(bpos)+[1]*len(ipos),'query_targets':query_targets,'baseline_area_upper_um2':values,'representative_active_forbidden_rows_hex':list(map(hex,rows)),'node_regions':[{'current_position':r['current_position'],'family':r['family']} for r in bdata['node_regions']],'root_clique_masks_hex':cliques,'required_by_reference_family_um2':[[279993000000,158392000000,438385000000],[319992000000,138593000000,458585000000]]}
    write(OUT/f'choice-{case:02d}-queries.json',record)
    for family in range(2):write(OUT/f'choice-{case:02d}-family-{family}-covers.json',covers[family])
    inputs.extend([original,INSERT/f'choice-{case:02d}-queries.json',INSERT/f'choice-{case:02d}-areas/query-results.json',BRACKET/f'producer/choice-{case:02d}-signatures.json',PARENT/f'choice-{case:02d}-frontier.json',witnesses,graph/'nodes.json',graph/'conflicts.bin',graph/'root-covers.json',OLD/f'choice-{case:02d}-atoms.json'])
    summaries.append({'refinement_index':case,'baseline_nodes':len(baseline),'initial_nodes':len(initial),'bracket_queries':len(bpos),'insert_queries':len(ipos),'total_queries':len(positions),'current_targets':sum(map(len,query_targets)),'possible_node_records':sum(map(len,covers))})
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):inputs.extend([ROOT/piece['folder']/'atoms.json',ROOT/piece['folder']/'audit/checks.json'])
cost=load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed']+load(ROOT/'output/h5-combined-query-controls-process-20261109/process.json')['complete_seconds']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Complete combined bracket-representative and direct-insert reference families. Both audited baseline area vectors and projected signatures share the8569-node baseline. Current inputs apply18insert removals. Every round reprojects changed possible-node intersections under reduced masks; exact carry-forward is allowed only for unchanged intersections. Producer subtracts newly uncovered weighted deltas; independent auditor recomputes every area from original physical pieces via controlled binary counters. Apply each reference family own companion thresholds, original certified bracket mapping and direct insert targets, then simultaneous necessary root-clique implications. Continue only after full independent audit and a changed mask, stopping at genuine joint fixed point, complete scope exclusion, or declared8-round cap. No optimizer/source-atlas/P-construction repeat.','maximum_combined_rounds':8,'maximum_clique_passes_per_round':8,'producer_cap_seconds':60,'auditor_cap_seconds':60,'memory_bytes':2**31,'inherited_numeric_preparation_seconds':cost,'optimizer_calls':0,'retry_permitted':False,'common_line_holes_reserved':True})
write(OUT/'case-summary.json',summaries);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'complete_cases':2,'combined_queries':sum(r['total_queries'] for r in summaries),'initial_current_targets':sum(r['current_targets'] for r in summaries),'possible_node_records':sum(r['possible_node_records'] for r in summaries),'independent_audit_pending':True,'optimizer_calls':0})
print(summaries)
