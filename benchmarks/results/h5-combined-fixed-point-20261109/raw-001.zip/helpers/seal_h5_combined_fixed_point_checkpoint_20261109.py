"""Preserve the complete joint fixed point and its independently checked inputs."""
from pathlib import Path
import json, shutil, subprocess
ROOT=Path(__file__).resolve().parents[1]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8')
prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-combined-fixed-point-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-combined-reference-20261109';F=BASE/'round-00/audit';D=BASE/'preflight-audit'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-complete-insert-capacity-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['joint_fixed_point'] and front['remaining_nodes']==8551 and front['complete_queries']==6650 and front['conditional_seed_exclusions']==front['clique_exclusions']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-combined-query-controls-20261109']+[ROOT/'output'/(label+'-process-20261109') for label in ['h5-combined-query-controls','h5-combined-reference-plan','h5-combined-reference-plan-audit','h5-combined-reference-round-00','h5-combined-reference-round-00-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*combined*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_combined_fixed_point_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json').items()":"load(F/'plan.json')['inputs'].items()",
}
for before,after in changes.items():
    assert before in prefix,before
    prefix=prefix.replace(before,after)
exec(prefix)
labels=[('h5-combined-query-controls',True),('h5-combined-reference-plan',True),('h5-combined-reference-plan-audit',False),('h5-combined-reference-round-00',True),('h5-combined-reference-round-00-audit',False)]
processes=[];cost=load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed']
for label,charge in labels:
    p=load(ROOT/'output'/(label+'-process-20261109')/'process.json')
    assert p['passed'] and p['closed'] and p['job']['closed'] and p['job']['active_processes']==0 and p['job']['job_committed_memory_limit']==2**31
    if charge:cost+=p['complete_seconds']
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':charge})
assert abs(cost-front['complete_preparation_seconds_if_consumed'])<1e-8
inherited=load(PARENT/'process-summary.json')+load(PARENT/'inherited-process-summary.json')
assert len(inherited)==591 and all(p['closed'] and p['active_processes']==0 for p in inherited)
write(OUT/'process-summary.json',processes);write(OUT/'inherited-process-summary.json',inherited)
copies=[(F/'checks.json','complete-audit.json'),(F/'case-results.json','case-results.json'),(BASE/'plan.json','complete-plan.json'),(D/'checks.json','source-preflight-audit.json'),(ROOT/'output/h5-combined-query-controls-20261109/checks.json','combined-width-controls.json')]
for case in [1,9]:
    copies.extend([(F.parent/f'choice-{case:02d}-frontier.json',f'choice-{case:02d}-frontier.json'),(F.parent/f'choice-{case:02d}-queries.json',f'choice-{case:02d}-queries.json')])
    current=load(F.parent/f'choice-{case:02d}-frontier.json')
    previous=load(PARENT/f'choice-{case:02d}-frontier.json')
    assert current['input_active_positions']==current['remaining_current_positions']==previous['remaining_current_positions']
for source,name in copies:shutil.copyfile(source,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42547117998','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True))
assert ci['headSha']=='2ae15d964798b097284abaefe7e0d143a0de1905'
write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'new_processes_closed':5,'inherited_processes_closed':591,'all596_processes_closed':True,'completion_percent':60,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'additional_rounds_opened':0,'identical_frontier_to_parent':True})
proposal='The complete single-reference area and root-clique rules are at a joint fixed point. Do not repeat them on unchanged masks. Assess two-reference capacity bounds: remaining family coverage must lie in the intersection of the two conservative single-reference covers; the joint cover is the union of the resulting family intersections. Subtract both selected part areas from the required totals. Bracket reference implications must retain the original certified mapping, and both targets must be distinct. Independently preflight all identities and a declared finite pair scope before using any new incompatibility. A failed pair bound can prove only that those target cells cannot coexist; it does not by itself remove a cell or an arrangement. No pair-bound controls, numerical model or call is prepared. Preserve complete consumed preparation; no optimizer or timed H5 acceptance from this lineage.'
write(OUT/'next-step.json',{'status':'complete_joint_fixed_point_both_cases_open','proposal':proposal,'pair_capacity_stage_prepared':False,'authoritative_current_masks':'output/h5-combined-reference-20261109/round-00/choice-{01,09}-frontier.json remaining_current_positions','consumed_preparation_seconds':cost,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'H5_complete':False})
passed=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Combined conditional fixed point — 2026-11-09

**The complete bracket and insert bounds reach a joint fixed point: no further cells are excluded.**
Both fixed29 choices `[0,5,10]` and `[5,10,11]` remain open with 8,551 cells.
H2/H5 remain open at **60% completed milestone weight**.

## Full scope and independent verification

The [preceding insert proof](h5-complete-insert-capacity-20261109.md) removed 18
cells after the bracket-only fixed point. This stage combines all 3,138 bracket
representative queries and 3,512 direct insert queries under the changed masks.
It preserves original graph array positions and the certified bracket mapping.
The [source audit]({NAME}/source-preflight-audit.json) verifies all 6,650 rows,
8,551 current targets, 8,721 source self witnesses, 1,848,482 directed clique
edges and 87,484 possible-node records. The two baseline families share the
same prior 8,569-cell masks.

[Width controls]({NAME}/combined-width-controls.json) compare 425,600 scalar
answers across 128 cases, both family boundaries, the maximum query index
3,833 and large integer carries. Each bracket reference leaves seven brackets
and eight inserts; each insert leaves eight brackets and seven inserts.
Their different area requirements are applied to every query.

The producer restricts each certified possible-node set to the current mask,
carrying a signature only when that intersection is exactly unchanged.
It tightens 104 insert-family signatures in case09 and applies 2,121 weighted
updates. The independent auditor uses allowed-node union projection and
recomputes all **19,950 area bounds from all 151,597 original physical records**,
instead of using the producer's incremental losses. Every query, mapped target
and simultaneous root-clique implication matches.

| Omitted sites | Complete queries | Remaining cells | New exclusions |
|---|---:|---:|---:|
| [0,5,10] | 2,816 | 3,793 | 0 |
| [5,10,11] | 3,834 | 4,758 | 0 |

[The complete audit]({NAME}/complete-audit.json) confirms both masks are unchanged.
The loop stops after its first audited round; none of the other seven permitted
rounds opens. The fixed point applies to these conditional and clique rules,
not to all possible proofs. The previous exact global envelope bounds remain
applicable because both masks are identical. The 453/455 prior whole-choice
exclusions stand, including 428 at zero clearance.

## Limits and next work

[All five new numerical processes]({NAME}/process-summary.json) pass and close
with zero descendants. The [591 inherited processes]({NAME}/inherited-process-summary.json)
are terminal, including four preserved failures. New workers retain CCD1
logical processors 16–31, one BLAS/OMP/MKL thread and a 2 GiB Windows Job cap.
The controls use 20 s, the two preflight stages 30 s each, and the producer
and complete auditor 60 s each. Consumed preparation is **{cost:.6f} s**;
the independent audits are external verification. No optimizer, timer reset
or timed H5 pass follows.

[Next]({NAME}/next-step.json), assess conservative two-reference capacities.
Two selected cells restrict the remaining geometry simultaneously; a failed
pair bound could add a certified incompatibility. Its controls and finite
query scope must be independently checked before use. No such stage is prepared.

Common-line occupied outer envelopes reserve holes; all 90 cutting holes
remain preserved. No ordinary part-in-hole or whole-allocation exclusion is
claimed. All 440 whole-job allocations, full66 source/native/material checks,
production integration and the H5 matrix remain open. Valid64 stays best.
The eight older first32 and 680 five-column cores remain closed.

Product, README and releases are unchanged. Earlier checkpoints `3642e620`
and `335be569` are committed. Main remains `2ae15d96`; [CI at review]({NAME}/main-ci-at-review.json)
has {passed} passed / {live} live jobs. These checkpoints await the ordinary push gate.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete chain.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 combined conditional fixed point:** [complete source and independent area audit]({{link}}) covers all 6,650 bracket/insert queries, 8,551 current targets, 87,484 possible-node records, 151,597 original physical entries and 19,950 bounds. The changed masks tighten 104 signatures and yield no new conditional or clique exclusion. Both choices reach a joint fixed point; no extra round opens. All five new processes pass and close; 591 inherited processes remain terminal with four preserved failures. Consumed preparation {cost:.6f} s cannot reset or open an optimizer. Next assess independently controlled two-reference capacity bounds; no such stage is prepared. All 440 allocations/full66/H5 remain open, valid64 stays best, H2/H5 remain open at 60%, common-line holes stay reserved, and product/README/releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md'
    append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [combined conditional fixed point](../benchmarks/results/{NAME}.md).
All 6,650 bracket/insert queries and 19,950 conservative area bounds pass
independent verification from every original physical proof piece. The 18
prior insert removals tighten 104 signatures but produce no further seed or
clique exclusion. Both choices reach a joint fixed point, retaining 8,551
cells. No extra round opens. The 453/455 prior exclusions stand, including
428 at zero clearance. Common-line holes remain reserved; no ordinary
part-in-hole or whole-allocation exclusion is claimed. All five new and 591
inherited processes are terminal, with the four inherited failures preserved.
Consumed preparation is {cost:.6f} s; no optimizer or timer reset is permitted.
Next assess two-reference capacity bounds; no such stage is prepared.
All 440 allocations and full66/H5 validation remain open; valid64 stays best.
H2/H5 remain open at 60%. Separate eight older first32 and 680 five-column
cores stay closed. Product, README and releases are unchanged. Checkpoints
3642e620 and 335be569 are committed; main 2ae15d96 has {passed} passed/{live}
live CI jobs at review. The evidence checkpoints await ordinary push.
'''
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content[:start]+intro+content[end:])
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text\n')
print({'passed':True,'archive':archive,'bindings':len(bindings),'historical_references':len(external),'consumed_preparation_seconds':cost,'joint_fixed_point':True,'remaining_nodes':8551})
