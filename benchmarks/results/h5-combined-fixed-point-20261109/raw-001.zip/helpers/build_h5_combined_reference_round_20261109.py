"""Complete coupled reference restriction by delta loss and necessary clique counts."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import forbidden_projection
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-combined-reference-20261109';OLD=ROOT/'output/h5-complete-closure-plan-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
iteration=int(sys.argv[1]);plan=load(BASE/'plan.json');assert 0<=iteration<plan['maximum_combined_rounds'] and load(BASE/'preflight-audit/checks.json')['passed']
if iteration:
    previous=BASE/f'round-{iteration-1:02d}';check=load(previous/'audit/checks.json')
    p=load(ROOT/f'output/h5-combined-reference-round-{iteration-1:02d}-audit-process-20261109/process.json')
    assert check['passed'] and not check['joint_fixed_point'] and not check['all_scopes_excluded'] and p['passed'] and p['closed'] and p['job']['active_processes']==0
OUT=BASE/f'round-{iteration:02d}';OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),ROOT/'output/h5_block_projected_coverage_atoms_20261109.py',BASE/'plan.json',BASE/'preflight-audit/plan.json',BASE/'preflight-audit/checks.json'];cases=[]
for case in [1,9]:
    source=BASE/f'choice-{case:02d}-queries.json';data=load(source);graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    inputs.extend([source,graph/'nodes.json',graph/'conflicts.bin',OLD/f'choice-{case:02d}-atoms.json'])
    if iteration==0:
        prior=data['baseline_active_positions'];active=data['initial_active_positions'];prior_areas=data['baseline_area_upper_um2'];prior_signatures=None
    else:
        old_front=load(previous/f'choice-{case:02d}-frontier.json');prior=old_front['input_active_positions'];active=old_front['remaining_current_positions']
        prior_areas=[r['family_and_joint_area_upper_um2'] for r in load(previous/f'choice-{case:02d}-queries.json')];prior_signatures=load(previous/f'choice-{case:02d}-signatures.json')
        inputs.extend([previous/'audit/checks.json',previous/f'choice-{case:02d}-frontier.json',previous/f'choice-{case:02d}-queries.json',previous/f'choice-{case:02d}-signatures.json'])
    prior_mask=sum(1<<p for p in prior);active_mask=sum(1<<p for p in active);assert active_mask&~prior_mask==0
    project=forbidden_projection(data);maps=[{},{}];signatures=[[],[]];changed=[0,0];reprojected=[0,0]
    for family in range(2):
        p=BASE/f'choice-{case:02d}-family-{family}-covers.json';inputs.append(p)
        covers=load(p)
        if prior_signatures is not None:assert [r[0] for r in prior_signatures[family]]==[r[0] for r in covers]
        for index,(key,possible_text,baseline_text) in enumerate(covers):
            possible=int(possible_text,16);old=int(baseline_text if prior_signatures is None else prior_signatures[family][index][1],16)
            if possible&prior_mask!=possible&active_mask:
                current=project(possible&active_mask)[family];reprojected[family]+=1
            else:current=old
            assert old&~current==0;changed[family]+=current!=old
            maps[family][int(key,16)]=(old,current);signatures[family].append([key,hex(current)])
    areas=[row[:] for row in prior_areas];updates=0
    for b,i,weight in load(OLD/f'choice-{case:02d}-atoms.json'):
        b0,b1=maps[0][int(b,16)];i0,i1=maps[1][int(i,16)]
        for family,loss in enumerate([b1&~b0,i1&~i0,(b1&i1)&~(b0&i0)]):
            while loss:
                bit=loss&-loss;areas[bit.bit_length()-1][family]-=weight;loss^=bit;updates+=1
    active_set=set(active);results=[];seeds=[]
    for qi,(position,reference_family,targets,values) in enumerate(zip(data['query_positions'],data['query_families'],data['query_targets'],areas)):
        assert all(0<=a<=b for a,b in zip(values,prior_areas[qi]))
        failures=[f for f,(a,b) in enumerate(zip(values,data['required_by_reference_family_um2'][reference_family])) if a<b]
        rejected=[p for p in targets if p in active_set] if failures else [];seeds.extend(rejected)
        results.append({'query_index':qi,'reference_family':reference_family,'reference_current_position':position,'family_and_joint_area_upper_um2':values,'failing_area_indices':failures,'excluded_current_targets':rejected})
    assert len(seeds)==len(set(seeds));current=active_mask&~sum(1<<p for p in seeds);clique_rounds=[]
    rows=[int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p) for p in range(len(nodes))];cliques=[[int(v,16) for v in family] for family in data['root_clique_masks_hex']]
    for step in range(plan['maximum_clique_passes_per_round']):
        removed=[]
        for p in active:
            if not current&(1<<p):continue
            allowed=current&~rows[p];upper=[sum(bool(group&allowed) for group in family) for family in cliques];required=[8-int(nodes[p]['family']==f) for f in range(2)]
            if any(a<b for a,b in zip(upper,required)):removed.append({'current_position':p,'upper':upper,'required':required})
        clique_rounds.append({'pass_index':step,'removed':removed})
        if not removed:break
        current&=~sum(1<<r['current_position'] for r in removed)
    remaining=[p for p in active if current&(1<<p)];global_counts=[sum(bool(group&current) for group in family) for family in cliques]
    summary={'refinement_index':case,'input_nodes':len(active),'remaining_nodes':len(remaining),'complete_queries':len(results),'conditional_seed_exclusions':len(seeds),'conditional_seeds_by_family':[sum(nodes[p]['family']==f for p in seeds) for f in range(2)],'clique_exclusions':sum(len(r['removed']) for r in clique_rounds),'changed_signatures_by_family':changed,'reprojected_records_by_family':reprojected,'delta_weighted_query_updates':updates,'global_clique_upper_counts':global_counts,'scope_excluded':any(n<8 for n in global_counts),'fixed_point':remaining==active}
    write(OUT/f'choice-{case:02d}-queries.json',results);write(OUT/f'choice-{case:02d}-signatures.json',signatures)
    write(OUT/f'choice-{case:02d}-frontier.json',{**summary,'input_active_positions':active,'remaining_current_positions':remaining,'conditional_removed_positions':sorted(seeds),'clique_rounds':clique_rounds})
    cases.append(summary);print(summary,flush=True)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'round_index':iteration,'method':plan['method']})
write(OUT/'case-results.json',cases);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'round_index':iteration,'complete_queries':sum(r['complete_queries'] for r in cases),'conditional_seed_exclusions':sum(r['conditional_seed_exclusions'] for r in cases),'clique_exclusions':sum(r['clique_exclusions'] for r in cases),'remaining_nodes':sum(r['remaining_nodes'] for r in cases),'provisional_joint_fixed_point':all(r['fixed_point'] for r in cases),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
