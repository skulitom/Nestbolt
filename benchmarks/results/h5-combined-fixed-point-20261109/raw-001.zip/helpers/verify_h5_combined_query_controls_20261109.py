"""Verify weighted sums across combined bracket/insert query boundaries."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-combined-query-controls-20261109';OUT.mkdir();began=time.perf_counter()
cases=0;scalars=0
for brackets,inserts in [(1133,1683),(2005,1829)]:
    total=brackets+inserts;positions=[0,7,63,64,129,511,brackets-1,brackets,brackets+1,total-1]
    for seed in range(64):
        records=[]
        for j in range(16):
            mask=sum(1<<p for k,p in enumerate(positions) if ((seed*(j+3)+29*j)>>(k%8))&1)
            records.append((mask,(1<<(j+32))-1+seed*1009))
        expected=[sum(weight for mask,weight in records if mask&(1<<q)) for q in range(total)]
        actual=weighted_query_sums(records,total);assert actual==expected
        low=(1<<brackets)-1
        assert actual==weighted_query_sums([(m&low,w) for m,w in records],brackets)+weighted_query_sums([(m>>brackets,w) for m,w in records],inserts)
        cases+=1;scalars+=total
result={'passed':True,'combined_width_cases':cases,'scalar_queries_verified':scalars,'maximum_query_index':3833,'both_family_boundaries_checked':[1133,2005],'large_weight_carries_checked':True,'seconds':time.perf_counter()-began,'optimizer_calls':0}
for name,value in [('checks.json',result),('source-bindings.json',{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'output/h5_weighted_query_masks_20261109.py']})]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(result)
