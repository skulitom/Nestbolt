"""Independently verify combined queries, all target implications and source pins."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-combined-reference-20261109';OUT=BASE/'preflight-audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process=load(ROOT/'output/h5-combined-reference-plan-process-20261109/process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings=dict(load(BASE/'plan.json')['inputs']);seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
verify(bindings.copy())
for p in [ROOT/'output/h5-incremental-closure-20261109/audit-v2/plan.json',ROOT/'output/h5-complete-insert-reference-20261109/reconciliation/plan.json']:
    verify(load(p)['inputs'])
geometry=load(ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json');counts={'queries':0,'targets':0,'source_self_witnesses':0,'directed_clique_edges':0,'possible_node_records':0}
for case in [1,9]:
    p=BASE/f'choice-{case:02d}-queries.json';data=load(p);bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
    old=load(ROOT/f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json');insert=load(ROOT/f'output/h5-complete-insert-reference-20261109/choice-{case:02d}-queries.json')
    graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    active=load(ROOT/f'benchmarks/results/h5-complete-insert-capacity-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions'];assert data['initial_active_positions']==active
    baseline=insert['active_current_positions'];assert data['baseline_active_positions']==baseline and set(active)<set(baseline)
    baseline_mask=sum(1<<p for p in baseline);active_mask=sum(1<<p for p in active)
    bpos=old['required_representatives'];ipos=insert['insert_reference_positions'];assert data['query_positions']==bpos+ipos and data['query_families']==[0]*len(bpos)+[1]*len(ipos)
    assert data['required_by_reference_family_um2']==[[279993000000,158392000000,438385000000],[319992000000,138593000000,458585000000]]
    assert data['node_regions']==[{'current_position':r['current_position'],'family':r['family']} for r in old['node_regions']]
    witness=load(ROOT/f'output/h5-fixed29-conditional-frontier-20261108/choice-{case:02d}-frontier.json')['source_self_collision_components']
    for node in sorted(set(active)|set(bpos)|set(ipos)):
        l,b,r,t=nodes[node]['bounds_um'];c=geometry[nodes[node]['geometry']]['inner_rectangles_um'][witness[node]]
        assert r-l<c[2]-c[0] and t-b<c[3]-c[1];counts['source_self_witnesses']+=1
    raw_rows=[]
    for position in bpos+ipos:
        forbidden=sum(1<<q for q in baseline if q==position or raw[position*width+q//8]&(1<<(q%8)))
        raw_rows.append(forbidden)
    assert list(map(hex,raw_rows))==data['representative_active_forbidden_rows_hex']
    expected_targets=[[] for _ in bpos];slots={p:i for i,p in enumerate(bpos)};active_set=set(active)
    for target,rep in old['pivot_to_representative']:
        if target not in active_set:continue
        own=(int.from_bytes(raw[target*width:(target+1)*width],'little')|(1<<target))&active_mask
        assert raw_rows[slots[rep]]&active_mask&~own==0
        expected_targets[slots[rep]].append(target)
    expected_targets.extend([[p] if p in active_set else [] for p in ipos]);assert data['query_targets']==expected_targets
    flattened=[p for row in expected_targets for p in row];assert len(flattened)==len(set(flattened)) and set(flattened)==active_set
    bresults=[r for r in load(ROOT/'output/h5-incremental-closure-20261109/producer/query-results.json') if r['refinement_index']==case]
    iresults=load(ROOT/f'output/h5-complete-insert-reference-20261109/choice-{case:02d}-areas/query-results.json')
    assert data['baseline_area_upper_um2']==[r['family_and_joint_area_upper_um2'] for r in bresults+iresults]
    assert [r['representative_current_position'] for r in bresults]==bpos and [r['insert_current_position'] for r in iresults]==ipos
    for family,groups in enumerate(load(graph/'root-covers.json')):
        masks=[];covered=set()
        for group in groups:
            assert all(nodes[p]['family']==family for p in group)
            for p in group:
                for q in group:
                    assert p==q or raw[p*width+q//8]&(1<<(q%8));counts['directed_clique_edges']+=p!=q
            masks.append(hex(sum(1<<p for p in group)));covered.update(group)
        assert data['root_clique_masks_hex'][family]==masks and covered=={p for p,node in enumerate(nodes) if node['family']==family}
    bsign=load(ROOT/f'output/h5-incremental-closure-20261109/producer/choice-{case:02d}-signatures.json');bsign=[dict(rows) for rows in bsign];isign=[{},{}]
    insert_base=ROOT/'output/h5-complete-insert-reference-20261109'
    for spec in load(insert_base/'plan.json')['projection_batches']:
        if spec['refinement_index']==case:isign[spec['family']].update(load(insert_base/f"projection-batch-{spec['batch_index']:02d}/projected-signatures.json"))
    expected=[[],[]];old_base=ROOT/'output/h5-complete-closure-plan-20261109'
    for spec in load(old_base/'plan.json')['closure_batches']:
        if spec['refinement_index']!=case:continue
        family=spec['family'];folder=old_base/f"closure-batch-{spec['batch_index']:02d}";verify(load(folder/'audit/source-bindings.json'))
        for key,possible,prior in load(folder/'closures.json'):expected[family].append([key,possible,hex(int(bsign[family][key],16)+(int(isign[family][key],16)*(2**len(bpos))))])
    for family in range(2):
        p=BASE/f'choice-{case:02d}-family-{family}-covers.json';saved=load(p);assert saved==expected[family] and len({r[0] for r in saved})==len(saved)
        bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest();counts['possible_node_records']+=len(saved)
    counts['queries']+=len(bpos)+len(ipos);counts['targets']+=len(active)
assert counts['queries']==6650 and counts['targets']==8551 and counts['possible_node_records']==87484
for p in [Path(__file__),BASE/'plan.json',BASE/'case-summary.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently reconstruct every combined forbidden row from raw bytes, every source self witness and bracket-target row-subset implication, every direct insert target, complete root-clique edge proofs, both family baseline vectors and concatenated baseline masks for every certified P record. Verify the full prior scalar/weighted evidence bindings. No sampled reference set.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,**counts,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
