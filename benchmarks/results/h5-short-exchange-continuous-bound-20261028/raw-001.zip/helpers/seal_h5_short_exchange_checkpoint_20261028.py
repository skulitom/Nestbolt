"""Publish verified empty finite regions and the exact all-angle fixed-layout bound."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-short-two-cog-exchange-20261028';PUB=BASE/'publication'
NAME='h5-short-exchange-continuous-bound-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)

def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()

head=git('rev-parse','HEAD');assert head=='85e63ab2e745a84a3010e5fbed929170132def12' and not git('diff','HEAD','--name-only')
prepared=load(BASE/'prepared.json');checked=load(BASE/'preflight-v2/checks.json');closed=load(BASE/'finite-construction-closure.json');bound=load(BASE/'all-angle-bound/audit/checks.json')
assert prepared['passed'] and prepared['preparation_closed'] and prepared['seconds']<120
assert checked['passed'] and checked['empty_cog_free_domains_verified']==216 and checked['complete_free_domains_verified']==228
assert closed['closed'] and closed['construction_calls']==0 and not closed['retry_permitted']
assert bound['passed'] and bound['all6_fixed11_cases_excluded_for_any_cog_angle'] and bound['continuous_coverage_nodes']==90 and bound['covered_leaves']==48
assert not (BASE/'preflight/checks.json').exists() and load(BASE/'preflight/retained-incomplete-audit.json')['original_exit_code_unavailable']
prior=load(ROOT/'benchmarks/results/h5-fixed-cog-rows-and-short-exchange-20261028/publication-review.json')
production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];assert main=='83f3f51f7767d6ddd1e2eb34968d1502bb0ae3d8'
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert ci['head_sha']==main and ci['status']=='completed' and ci['conclusion']=='success' and len(jobs)==6 and all(j['conclusion']=='success' and j['status']=='completed' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}

def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)

for p in BASE.rglob('*'):
    if p.is_file():add(BASE.name+'/'+p.relative_to(BASE).as_posix(),p)
helpers=['prepare_h5_short_two_cog_exchange_20261028.py','audit_h5_short_two_cog_exchange_20261028.py','audit_h5_short_two_cog_exchange_v2_20261028.py','h5_vector_source_minkowski_20261028.py','prove_h5_short_exchange_all_angle_20261028.py','audit_h5_short_exchange_all_angle_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_short_exchange_archive_20261028.py',Path(__file__).name]
for name in helpers:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[('prepared.json','geometry-prepared.json'),('preflight/retained-incomplete-audit.json','retained-incomplete-audit.json'),('preflight-v2/checks.json','geometry-audit.json'),('preflight-v2/source-sample-checks.json','source-sample-checks.json'),('finite-construction-closure.json','finite-construction-closure.json'),('all-angle-bound/plan.json','bound-plan.json'),('all-angle-bound/moving-core.json','moving-core.json'),('all-angle-bound/result.json','bound-result.json'),('all-angle-bound/audit/checks.json','bound-audit.json'),('all-angle-bound/audit/case-checks.json','bound-cases.json'),('all-angle-bound/audit/necessity-proof.json','necessity-proof.json')]
for a,b in copies:shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40783629977,'main_all6_pass':True,'normal_push_ready_after_commit':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Prepare a separate fixed-10 inventory by releasing one additional original from each of the six fixed-11 cases. Deduplicate identical geometry while preserving every original identity allocation. Use source-contained all-angle cog cores as a necessary preflight before selecting a new bounded source construction; a core-domain witness is only an unexcluded relaxation, never a feasible original placement. Do not reopen the closed fixed-11 construction or change its bounds. Keep all 66 original identities mandatory, with unchanged first/short stock and common-line PIH off. Native validation still requires a complete source-valid 66.', 'geometry_prepared':False,'new_search_opened':False,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'complete_source_obstacles':262,'complete_free_domains':228,'empty_finite_cog_domains':216,'all_angle_fixed11_cases_excluded':6,'continuous_coverage_nodes':90,'covered_leaves':48,'construction_calls':0,'solver_calls':0,'native_calls':0,'new_source_valid13':False,'new_source_valid66':False,'full_allocation_or_global_job_excluded':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
