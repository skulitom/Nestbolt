"""Independently audit all66 proxy parts and diagnose one original-outline lift."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction
from collections import Counter
from itertools import combinations
import copy,json,math,shutil,time,traceback
from shapely.geometry import Polygon,Point
from shapely.affinity import affine_transform

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pair-core-relocation-regions-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'solution-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source']
    jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
    diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    inputs=[BASE/n for n in ['audit/checks.json','solve/positions.json','solve/result.json','solve/model-audit.json']]
    inputs += [SRC/n for n in ['geometry.json','propagation.json','hint-poses.json','items.json','audit/source-inner-rectangles.json']]
    inputs += [sourcepath,jobpath,diskpath]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'audit_limit_seconds':120,'method':'Independently reconstruct every fixed and movable inner rectangle, exact selected-cell membership, original copy counts, all same-sheet rectangle pairs and full original-area charges. Then create one explicit original-outline lift: preserve62 source transforms, use selected bracket orientations at grid lower-corner anchors, and restore both cogs at grid center anchors with their own source angles. Reassign only copy labels to the audited66-item inventory. Diagnose every original polygon pair and stock boundary. This one lift does not exhaust floor-anchor phases or cog angles. Also use the certified all-angle cog disk and the sqrt(2)*0.01 mm floor-center uncertainty to detect robust necessary collisions with fixed original polygons or other moved cogs. Do not call native packing on an already invalid original layout. No acceptance claim.'})
    start=time.perf_counter();assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'solve/model-audit.json')['passed']
    assert load(BASE/'solve/result.json')['has_full_proxy_solution']
    solution=load(BASE/'solve/positions.json');case=load(BASE/'cases'/f"{solution['case']:03d}.json")
    survivors=load(BASE/'audit/surviving-neighborhoods.json');survivor=next(s for s in survivors if s['case']==solution['case'])
    allocation=survivor['surviving_allocations'][solution['allocation']];owners=solution['released_items']
    assert owners==case['case']['released_items']
    g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json')
    hints=load(SRC/'hint-poses.json');source=load(sourcepath);job=load(jobpath);parts={p['id']:p for p in job['parts']}
    disk=load(diskpath);center=[float(Fraction(*v)) for v in disk['center']];radius=disk['radius_units']/10000
    remaining=[h for h in hints if h['item'] not in owners];assert len(remaining)==62
    additional=[i for i in items if i['source_index'] is None];assert len(additional)==2 and all(i['family']=='bracket' for i in additional)
    ids=[i['index'] for i in additional]+owners
    records=[{'item':h['item'],'family':h['family'],'sheet':h['sheet'],'x_units':h['x_units'],'y_units':h['y_units'],
              'mode':h['mode'],'class':h['representative_class'],'fixed':True} for h in remaining]
    for pi,p in enumerate(solution['movable_parts']):
        assert p['part']==pi and p['case']==solution['case']
        row=case['queries'][p['query']];q=row['query'];cell=row['free_integer_cells'][p['cell']]
        assert q['role']==p['role'] and q['family']==p['family'] and q['sheet']==p['sheet'] and q['mode']==p['mode'] and q['class']==p['class']
        assert cell[0]<=p['x_units']<=cell[2] and cell[1]<=p['y_units']<=cell[3]
        records.append({'item':ids[pi],'family':p['family'],'sheet':p['sheet'],'x_units':p['x_units'],'y_units':p['y_units'],
                        'mode':p['mode'],'class':p['class'],'fixed':False})
    assert len(records)==len({r['item'] for r in records})==66 and {r['item'] for r in records}==set(range(66))
    assert Counter(r['family'] for r in records)=={'frame':18,'bracket':12,'insert':21,'cog':15}
    moved=solution['movable_parts'];assert [moved[2]['sheet'],moved[3]['sheet']]==allocation['restored_sheets']
    assert [sum(p['sheet']==s for p in moved[:2]) for s in [0,1]]==allocation['brackets_per_sheet']
    rectangles=[]
    for r in records:
        offsets=aux['cog_inner_components'] if r['family']=='cog' else aux['inner_non_cog_components'][r['class']]['components']
        bounds=g['cog_center_bounds'][r['sheet']] if r['family']=='cog' else next(m['coordinate_bounds'] for m in g['modes'] if m['index']==r['mode'])
        assert bounds[0]<=r['x_units']<=bounds[2] and bounds[1]<=r['y_units']<=bounds[3]
        for arm,b in enumerate(offsets):rectangles.append({'item':r['item'],'sheet':r['sheet'],'arm':arm,'bounds':[b[k]+r['x_units' if k%2==0 else 'y_units'] for k in range(4)]})
    fixed_expected=[r for r in load(SRC/'audit/source-inner-rectangles.json') if r['item'] not in owners]
    assert [r for r in rectangles if r['item'] not in ids]==fixed_expected
    pair_count=0
    for a,b in combinations(rectangles,2):
        if a['sheet']!=b['sheet']:continue
        x,y=a['bounds'],b['bounds'];assert x[2]<=y[0] or y[2]<=x[0] or x[3]<=y[1] or y[3]<=x[1],(a,b)
        pair_count+=1
    areas=[sum(aux['part_areas'][r['family']]['lower_units'] for r in records if r['sheet']==s) for s in [0,1]]
    assert all(areas[s]<=aux['sheet_capacities'][s]['upper_area_units'] for s in [0,1])
    write(OUT/'proxy-parts.json',records);write(OUT/'proxy-inner-rectangles.json',rectangles)
    layout=copy.deepcopy(source);layout['placements']=[];shapes={};stockbounds=[[float(Fraction(*v)) for v in b] for b in g['stock_bounds_rational']]
    for r in sorted(records,key=lambda r:r['item']):
        item=items[r['item']]
        if r['fixed']:p=copy.deepcopy(source['placements'][item['source_index']])
        else:
            x,y=r['x_units']/100,r['y_units']/100
            if r['family']=='cog':
                old=source['placements'][item['source_index']];angle=old['transform']['rotation_radians'];mirror=False
                c,s=math.cos(angle),math.sin(angle);tx=x-c*center[0]+s*center[1];ty=y-s*center[0]-c*center[1]
            else:
                cl=g['classes'][r['class']];angle=cl['quarter_turn']*math.pi/2;mirror=cl['mirrored'];c,s=math.cos(angle),math.sin(angle);mi=-1 if mirror else 1
                pts=[(mi*a*c-b*s,mi*a*s+b*c) for a,b in parts[r['family']]['geometry'][0]['outer']]
                tx=x-min(a for a,b in pts);ty=y-min(b for a,b in pts)
            p={'part_id':r['family'],'sheet_id':f"sheet-{r['sheet']}",'transform':{'rotation_radians':angle,'translation':[tx,ty],'mirrored':mirror}}
        p['copy_index']=item['copy'];layout['placements'].append(p);t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        shapes[r['item']]=affine_transform(Polygon(parts[r['family']]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,tx,ty])
    write(OUT/'original-outline-trial.json',layout)
    collisions=[];stockfail=[];original_pairs=0
    byid={r['item']:r for r in records}
    for i,j in combinations(sorted(shapes),2):
        if byid[i]['sheet']!=byid[j]['sheet']:continue
        a,b=shapes[i],shapes[j];distance=a.distance(b);original_pairs+=1
        if distance<job['clearance']-1e-7:
            collisions.append({'items':[i,j],'families':[byid[i]['family'],byid[j]['family']],
                               'distance_mm':distance,'intersection_area_mm2':a.intersection(b).area,
                               'involves_moved_part':not(byid[i]['fixed'] and byid[j]['fixed'])})
    for i,shape in shapes.items():
        b=shape.bounds;stock=stockbounds[byid[i]['sheet']]
        failures=[max(0,stock[0]-b[0]),max(0,stock[1]-b[1]),max(0,b[2]-stock[2]),max(0,b[3]-stock[3])]
        if max(failures)>1e-7:stockfail.append({'item':i,'family':byid[i]['family'],'sheet':byid[i]['sheet'],'bounds':list(b),'stock_bounds':stock,'violations_mm':failures})
    # Distance is 1-Lipschitz in center displacement. Even the largest possible
    # floor-anchor shift cannot repair a distance deficit exceeding sqrt(2)/100.
    robust=[];uncertainty=math.sqrt(2)/100
    for r in records:
        if r['fixed'] or r['family']!='cog':continue
        anchor=Point(r['x_units']/100,r['y_units']/100)
        for other in records:
            if not other['fixed'] or other['sheet']!=r['sheet']:continue
            d=anchor.distance(shapes[other['item']]);deficit=radius-uncertainty-d
            if deficit>1e-7:robust.append({'kind':'moved_cog_vs_fixed_original','items':[r['item'],other['item']],
                         'fixed_family':other['family'],'anchor_distance_to_original_mm':d,'disk_radius_mm':radius,
                         'maximum_center_floor_displacement_mm':uncertainty,'strict_overlap_margin_after_uncertainty_mm':deficit})
    movedcogs=[r for r in records if not r['fixed'] and r['family']=='cog']
    for a,b in combinations(movedcogs,2):
        if a['sheet']!=b['sheet']:continue
        distance=math.hypot(a['x_units']-b['x_units'],a['y_units']-b['y_units'])/100;deficit=2*radius-2*uncertainty-distance
        if deficit>1e-7:robust.append({'kind':'two_moved_cog_disks','items':[a['item'],b['item']],'strict_overlap_margin_after_uncertainty_mm':deficit})
    write(OUT/'original-pair-failures.json',collisions);write(OUT/'original-stock-failures.json',stockfail);write(OUT/'angle-independent-cog-conflicts.json',robust)
    assert time.perf_counter()-start<120
    checks={'passed':True,'seconds':time.perf_counter()-start,'case':solution['case'],'released_items':owners,
            'proxy_original_parts':66,'fixed_source_transforms_preserved':62,'mandatory_movable_parts':4,
            'exact_proxy_inner_rectangles':len(rectangles),'exact_same_sheet_proxy_component_pairs':pair_count,
            'original_area_units_per_sheet':areas,'selected_complete_cell_memberships':4,
            'all_original_copy_indices_unique_and_complete':True,'full_proxy_solution_verified':True,
            'original_outline_trial_pairs':original_pairs,'original_outline_trial_pair_failures':len(collisions),
            'original_outline_trial_stock_failures':len(stockfail),'robust_angle_independent_cog_conflicts':len(robust),
            'original_outline_trial_valid':not collisions and not stockfail,'native_packing_calls':0,
            'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False,
            'interpretation':'All66 inner-proxy parts are independently verified. The explicit original-outline trial is a separate diagnostic, not an accepted cutting layout. Robust cog conflicts, when present, reject this selected integer-center anchor even allowing every cog angle and its full floor-anchor uncertainty; they do not reject other anchors in the free cells or other neighborhoods.'}
    write(OUT/'checks.json',checks);print(checks,flush=True);print({'robust_conflicts':robust},flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
