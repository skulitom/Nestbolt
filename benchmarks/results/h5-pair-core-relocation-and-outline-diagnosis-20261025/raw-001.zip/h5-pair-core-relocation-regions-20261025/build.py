"""Complete, bounded two-core-release census with exact necessary occupied areas."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from itertools import combinations, product
from collections import Counter
import json, shutil, time, traceback
from build_h5_proxy_bracket_completion import forbidden, free_cells
from build_h5_core_relocation_regions import union_area

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
BASE=ROOT/'output/h5-pair-core-relocation-regions-20261025'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
ROLES=['bracket','restored0','restored1']
SUBSETS=[list(s) for k in [1,2,3] for s in combinations(ROLES,k)]

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    BASE.mkdir(); (BASE/'cases').mkdir(); shutil.copyfile(__file__,BASE/'build.py')
    g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json')
    hints=load(SRC/'hint-poses.json');fixed=load(SRC/'audit/source-inner-rectangles.json')
    cores=[i for i in items if i['family'] in ['frame','cog']]
    cases=[{'index':ci,'released_items':[a['index'],b['index']],
            'families':[a['family'],b['family']],'source_indices':[a['source_index'],b['source_index']]}
           for ci,(a,b) in enumerate(combinations(cores,2))]
    assert len(cases)==528
    inputs=[SRC/n for n in ['plan.json','geometry.json','propagation.json','items.json','hint-poses.json',
                           'audit/checks.json','audit/source-inner-rectangles.json']]
    inputs += [ROOT/'benchmarks/results/h5-single-core-relocation-exclusion-20261025'/n
               for n in ['checks.json','raw-manifest.json']]
    inputs += [ROOT/'output'/n for n in ['build_h5_proxy_bracket_completion.py','build_h5_core_relocation_regions.py']]
    write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'construction_limit_seconds':120,'maximum_total_free_cells':500000,
          'cases':cases,'queries_planned':9984,'roles':ROLES,'role_subsets':SUBSETS,
          'required_original_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},
          'fixed_original_parts_per_case':62,'restored_original_parts_per_case':2,'additional_mandatory_brackets':2,
          'method':'Enumerate all 528 unordered pairs of the 33 original frame/cog parts. Temporarily remove all components of both parts, keep the other 62 poses fixed, and construct every inclusive integer free-anchor cell for both restored originals and both extra brackets. Sweep each component over every cell to obtain outward occupied covers. Test exact continuous union areas for all seven nonempty role subsets on each sheet, for every allowed sheet/count allocation, plus full original-area capacity. All parts mandatory. Existing finite source orientation inventory, material bounds and floor-safe inner proxies retained. Positive clearance is dropped only in this necessary diagnostic. Preserve incomplete cases and all pending work if time/cell bounds are reached. No solver call, full target witness, acceptance or unrestricted infeasibility claim.'})
    start=time.perf_counter();totalcells=queries_done=0;summary=[];pending=[];stop_reason=None
    brmodes=[m for m in g['modes'] if m['family']=='bracket']
    for case in cases:
        if time.perf_counter()-start>=120 or totalcells>=500000:
            pending=list(range(case['index'],len(cases)));stop_reason='time' if time.perf_counter()-start>=120 else 'cell_cap';break
        owners=case['released_items'];remaining=[h for h in hints if h['item'] not in owners]
        assert len(remaining)==62
        counts=Counter(h['family'] for h in remaining);counts.update(case['families']);counts['bracket']+=2
        assert counts=={'frame':18,'bracket':12,'insert':21,'cog':15}
        work=[]
        for role,part in [('bracket',None)]+[(f'restored{k}',items[i]) for k,i in enumerate(owners)]:
            modes=(brmodes if part is None else
                   [{'index':s,'class':None,'sheet':s,'coordinate_bounds':b} for s,b in enumerate(g['cog_center_bounds'])]
                   if part['family']=='cog' else [m for m in g['modes'] if m['index'] in part['allowed_modes']])
            for m in modes:
                work.append({'index':len(work),'role':role,'family':'bracket' if part is None else part['family'],
                             'mode':m['index'],'class':m['class'],'sheet':m['sheet'],'domain':m['coordinate_bounds'],
                             'components':aux['cog_inner_components'] if m['class'] is None else
                                          aux['inner_non_cog_components'][m['class']]['components']})
        queries=[];covers={s:{r:[] for r in ROLES} for s in [0,1]}
        for q in work:
            if time.perf_counter()-start>=120 or totalcells>=500000:
                stop_reason='time' if time.perf_counter()-start>=120 else 'cell_cap';break
            boxes=[r['bounds'] for r in fixed if r['sheet']==q['sheet'] and r['item'] not in owners]
            obstacles=forbidden(boxes,q['components'],q['domain']);cells=free_cells(q['domain'],obstacles)
            occupied=sorted(set((c[0]+r[0],c[1]+r[1],c[2]+r[2],c[3]+r[3]) for c in cells for r in q['components']))
            queries.append({'query':q,'fixed_inner_components':len(boxes),'forbidden_integer_rectangles':obstacles,
                            'free_integer_cells':cells,'free_integer_anchor_count':sum((r[2]-r[0]+1)*(r[3]-r[1]+1) for r in cells),
                            'outward_occupied_cover_rectangles':occupied})
            covers[q['sheet']][q['role']].extend(occupied);totalcells+=len(cells);queries_done+=1
        if stop_reason:
            write(BASE/'cases'/f"{case['index']:03d}.json",{'case':case,'complete':False,'queries':queries,
                  'pending_queries':work[len(queries):],'stop_reason':stop_reason})
            pending=list(range(case['index'],len(cases)));break
        proxy_areas={}
        for role in ROLES:
            options={sum((r[2]-r[0])*(r[3]-r[1]) for r in q['components']) for q in work if q['role']==role}
            assert len(options)==1;proxy_areas[role]=next(iter(options))
        # The union measure is an upper bound even when continuous interpolation
        # includes positions unavailable on the exact integer grid.
        areas={s:{'|'.join(sub):union_area([r for role in sub for r in covers[s][role]]) for sub in SUBSETS} for s in [0,1]}
        basearea=[sum(aux['part_areas'][h['family']]['lower_units'] for h in remaining if h['sheet']==s) for s in [0,1]]
        allowed=[sorted({q['sheet'] for q in work if q['role']==f'restored{k}'}) for k in [0,1]]
        allocations=[]
        for restored_sheets in product(*allowed):
            for second in [0,1,2]:
                bracket_counts=[2-second,second];failures=[]
                for s in [0,1]:
                    n={'bracket':bracket_counts[s],**{f'restored{k}':int(restored_sheets[k]==s) for k in [0,1]}}
                    charge=basearea[s]+n['bracket']*aux['part_areas']['bracket']['lower_units']+sum(n[f'restored{k}']*aux['part_areas'][case['families'][k]]['lower_units'] for k in [0,1])
                    cap=aux['sheet_capacities'][s]['upper_area_units']
                    if charge>cap:failures.append({'sheet':s,'condition':'original_area_capacity','required':charge,'upper':cap})
                    for sub in SUBSETS:
                        key='|'.join(sub);need=sum(n[role]*proxy_areas[role] for role in sub)
                        if need>areas[s][key]:failures.append({'sheet':s,'condition':key+'_occupied_cover','required':need,'upper':areas[s][key]})
                allocations.append({'restored_sheets':list(restored_sheets),'brackets_per_sheet':bracket_counts,
                                    'passes_necessary_bounds':not failures,'failures':failures})
        survivors=[a for a in allocations if a['passes_necessary_bounds']]
        write(BASE/'cases'/f"{case['index']:03d}.json",{'case':case,'complete':True,'queries':queries,
              'base_original_area_units':basearea,'proxy_required_area_units_squared':proxy_areas,
              'outward_occupied_cover_area_units_squared':areas,'allocations':allocations,
              'excluded_by_necessary_bounds':not survivors,'surviving_allocations':len(survivors)})
        summary.append({'case':case['index'],'released_items':owners,'families':case['families'],
                        'excluded':not survivors,'surviving_allocations':len(survivors)})
        if len(summary)%100==0:print({'completed_cases':len(summary),'seconds':time.perf_counter()-start,'free_cells':totalcells},flush=True)
    write(BASE/'pending.json',pending)
    result={'seconds':time.perf_counter()-start,'cases_planned':528,'cases_completed':len(summary),
            'queries_planned':9984,'queries_completed':queries_done,'total_free_cells':totalcells,
            'pending_cases':len(pending),'stop_reason':stop_reason,'cell_cap_reached':totalcells>=500000,
            'excluded_cases':sum(r['excluded'] for r in summary),'surviving_cases':sum(not r['excluded'] for r in summary),
            'surviving_allocations':sum(r['surviving_allocations'] for r in summary),'cases':summary,
            'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    if not pending:assert queries_done==9984
    write(BASE/'result.json',result);print({k:v for k,v in result.items() if k!='cases'},flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if BASE.exists():(BASE/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
