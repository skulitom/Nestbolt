"""Independent complete integer-grid and occupied-union audit for 528 pair releases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from collections import Counter, defaultdict
from itertools import combinations, product
import json, shutil, time, traceback
import numpy as np
from audit_h5_core_relocation_regions import coverage, area

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
BASE=ROOT/'output/h5-pair-core-relocation-regions-20261025'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    inputs=[BASE/'plan.json',BASE/'result.json',BASE/'pending.json']
    inputs += [SRC/n for n in ['geometry.json','propagation.json','items.json','hint-poses.json',
                              'audit/checks.json','audit/source-inner-rectangles.json']]
    inputs.append(ROOT/'output/audit_h5_core_relocation_regions.py')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'audit_limit_seconds':120,
          'case_hashes':{p.name:digest(p) for p in sorted((BASE/'cases').glob('*.json'))},
          'method':'Independently reconstruct the exhaustive 528 original core pairs, all role/mode domains, all integer collision obstacles, and each free-cell complement by two-dimensional difference arrays. Independently reconstruct occupied covers and measure their continuous union with two-dimensional arrays, separately from the construction sweep. Check all seven role-subset inequalities and full original-area charges for every sheet allocation. Verify both original released poses are covered in every case. No solver call or inference beyond these conditional neighborhoods.'})
    start=time.perf_counter()
    assert result['cases_completed']==result['cases_planned']==528 and result['queries_completed']==result['queries_planned']==9984
    assert not result['stop_reason'] and not result['cell_cap_reached'] and not load(BASE/'pending.json')
    g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json')
    hints=load(SRC/'hint-poses.json');hintmap={h['item']:h for h in hints}
    fixed=load(SRC/'audit/source-inner-rectangles.json');assert load(SRC/'audit/checks.json')['passed']
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=ROOT/'benchmarks/results/h5-single-core-relocation-exclusion-20261025/raw-manifest.json'
    mf=load(manifest);files=mf['files']+mf['aliases'];provenance=[]
    for p in [SRC/n for n in ['plan.json','geometry.json','propagation.json','items.json','hint-poses.json',
                             'audit/checks.json','audit/source-inner-rectangles.json']]:
        matches=[r for r in files if r['sha256']==digest(p)];assert matches,p
        provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),
                           'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),
                           'member':matches[0]['path']})
    core_ids=[i['index'] for i in items if i['family'] in ['frame','cog']]
    assert [c['released_items'] for c in plan['cases']]==[list(pair) for pair in combinations(core_ids,2)]
    roles=['bracket','restored0','restored1'];subsets=[list(s) for k in [1,2,3] for s in combinations(roles,k)]
    assert plan['roles']==roles and plan['role_subsets']==subsets
    query_count=obstacle_count=cell_count=critical_count=anchor_count=free_count=occupied_count=inequality_count=pose_count=0
    case_checks=[]
    for ci,case in enumerate(plan['cases']):
        assert time.perf_counter()-start<120
        assert case['index']==ci;owners=case['released_items'];originals=[items[i] for i in owners]
        assert case['families']==[i['family'] for i in originals] and case['source_indices']==[i['source_index'] for i in originals]
        saved=load(BASE/'cases'/f'{ci:03d}.json');assert saved['case']==case and saved['complete']
        remaining=[h for h in hints if h['item'] not in owners];assert len(remaining)==62
        counts=Counter(h['family'] for h in remaining);counts.update(i['family'] for i in originals);counts['bracket']+=2
        assert counts==Counter(plan['required_original_counts'])
        covers={s:{r:[] for r in roles} for s in [0,1]};proxyareas=defaultdict(set);seen=defaultdict(set);covered=[False,False]
        expected_queries=[]
        for ri,role in enumerate(roles):
            part=None if ri==0 else originals[ri-1]
            if part is None:choices=[m for m in g['modes'] if m['family']=='bracket']
            elif part['family']=='cog':choices=[{'index':s,'sheet':s,'class':None,'coordinate_bounds':g['cog_center_bounds'][s]} for s in [0,1]]
            else:choices=[m for m in g['modes'] if m['index'] in part['allowed_modes']]
            for m in choices:
                components=aux['cog_inner_components'] if m['class'] is None else aux['inner_non_cog_components'][m['class']]['components']
                expected_queries.append({'index':len(expected_queries),'role':role,'family':'bracket' if part is None else part['family'],
                                         'mode':m['index'],'class':m['class'],'sheet':m['sheet'],'domain':m['coordinate_bounds'],'components':components})
        assert [q['query'] for q in saved['queries']]==expected_queries
        for row in saved['queries']:
            q=row['query'];role=q['role'];seen[role].add(q['mode']);domain=q['domain'];components=q['components']
            proxyareas[role].add(sum((r[2]-r[0])*(r[3]-r[1]) for r in components))
            boxes=[r['bounds'] for r in fixed if r['sheet']==q['sheet'] and r['item'] not in owners]
            assert row['fixed_inner_components']==len(boxes);obstacles=[]
            for fixed_rect,moving_rect in product(boxes,components):
                low=[max(domain[d],fixed_rect[d]-moving_rect[d+2]+1) for d in [0,1]]
                high=[min(domain[d+2],fixed_rect[d+2]-moving_rect[d]-1) for d in [0,1]]
                if all(low[d]<=high[d] for d in [0,1]):obstacles.append(low+high)
            assert Counter(map(tuple,obstacles))==Counter(map(tuple,row['forbidden_integer_rectangles']))
            cells=row['free_integer_cells'];assert all(domain[0]<=r[0]<=r[2]<=domain[2] and domain[1]<=r[1]<=r[3]<=domain[3] for r in cells)
            xs=sorted({domain[0],domain[2]+1}|{x for r in obstacles+cells for x in [r[0],r[2]+1]})
            ys=sorted({domain[1],domain[3]+1}|{y for r in obstacles+cells for y in [r[1],r[3]+1]})
            blocked=coverage(obstacles,xs,ys,True);opened=coverage(cells,xs,ys,True)
            assert np.all(blocked>=0) and np.all((opened==0)|(opened==1)) and np.array_equal(opened==1,blocked==0)
            weights=np.diff(np.array(xs,dtype=np.int64))[:,None]*np.diff(np.array(ys,dtype=np.int64))[None,:]
            free=int(weights[opened==1].sum());assert free==row['free_integer_anchor_count']==sum((r[2]-r[0]+1)*(r[3]-r[1]+1) for r in cells)
            occupied=sorted(set((c[0]+r[0],c[1]+r[1],c[2]+r[2],c[3]+r[3]) for c,r in product(cells,components)))
            assert [list(r) for r in occupied]==row['outward_occupied_cover_rectangles']
            covers[q['sheet']][role].extend(occupied)
            query_count+=1;obstacle_count+=len(obstacles);cell_count+=len(cells);critical_count+=opened.size
            anchor_count+=int(weights.sum());free_count+=free;occupied_count+=len(occupied)
            if role!='bracket':
                k=int(role[-1]);hint=hintmap[owners[k]]
                if hint['sheet']==q['sheet'] and hint['mode']==q['mode']:
                    covered[k]=any(c[0]<=hint['x_units']<=c[2] and c[1]<=hint['y_units']<=c[3] for c in cells)
        assert seen['bracket']=={m['index'] for m in g['modes'] if m['family']=='bracket'}
        assert all(seen[f'restored{k}']==set(originals[k]['allowed_modes']) for k in [0,1]) and all(covered)
        pose_count+=2;assert all(len(a)==1 for a in proxyareas.values())
        proxy={k:next(iter(v)) for k,v in proxyareas.items()}
        assert proxy==saved['proxy_required_area_units_squared']
        areas={s:{'|'.join(sub):area([r for role in sub for r in covers[s][role]]) for sub in subsets} for s in [0,1]}
        assert {str(s):v for s,v in areas.items()}==saved['outward_occupied_cover_area_units_squared']
        basearea=[sum(aux['part_areas'][h['family']]['lower_units'] for h in remaining if h['sheet']==s) for s in [0,1]]
        assert basearea==saved['base_original_area_units'];allocations=[]
        allowed=[sorted({q['sheet'] for q in expected_queries if q['role']==f'restored{k}'}) for k in [0,1]]
        for destinations in product(*allowed):
            for on_second in [0,1,2]:
                ns=[2-on_second,on_second];fails=[]
                for sheet in [0,1]:
                    amounts={'bracket':ns[sheet],**{f'restored{k}':int(destinations[k]==sheet) for k in [0,1]}}
                    charge=basearea[sheet]+ns[sheet]*aux['part_areas']['bracket']['lower_units']
                    for k in [0,1]:
                        if destinations[k]==sheet:charge+=aux['part_areas'][originals[k]['family']]['lower_units']
                    cap=aux['sheet_capacities'][sheet]['upper_area_units']
                    if charge>cap:fails.append({'sheet':sheet,'condition':'original_area_capacity','required':charge,'upper':cap})
                    for sub in subsets:
                        label='|'.join(sub);required=sum(amounts[r]*proxy[r] for r in sub)
                        if required>areas[sheet][label]:fails.append({'sheet':sheet,'condition':label+'_occupied_cover','required':required,'upper':areas[sheet][label]})
                    inequality_count+=8
                allocations.append({'restored_sheets':list(destinations),'brackets_per_sheet':ns,'passes_necessary_bounds':not fails,'failures':fails})
        assert allocations==saved['allocations'];survivors=[a for a in allocations if a['passes_necessary_bounds']]
        assert saved['excluded_by_necessary_bounds']==(not survivors) and saved['surviving_allocations']==len(survivors)
        case_checks.append({'case':ci,'released_items':owners,'families':case['families'],'excluded':not survivors,'surviving_allocations':survivors})
    assert query_count==9984 and cell_count==result['total_free_cells']
    assert sum(r['excluded'] for r in case_checks)==result['excluded_cases']
    assert sum(len(r['surviving_allocations']) for r in case_checks)==result['surviving_allocations']
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance})
    write(OUT/'case-checks.json',case_checks);write(OUT/'surviving-neighborhoods.json',[r for r in case_checks if not r['excluded']])
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_input_matches':len(provenance),
            'cases':528,'queries':query_count,'independently_checked_integer_obstacles':obstacle_count,
            'free_integer_cells_exactly_partition_complements':cell_count,'critical_integer_cells':critical_count,
            'domain_integer_anchors':anchor_count,'free_integer_anchors':free_count,
            'outward_occupied_rectangles_reconstructed':occupied_count,'released_original_source_poses_covered':pose_count,
            'exact_allocation_inequalities_checked':inequality_count,'excluded_cases':result['excluded_cases'],
            'surviving_cases':result['surviving_cases'],'surviving_allocations':result['surviving_allocations'],
            'every_case_preserves62_plus2_plus2_original_parts':True,'all_seven_role_subsets_checked':True,
            'all_bounds_necessary_only_for_recorded_neighborhoods':True,'no_layout_claimed_from_area_survival':True,
            'solver_calls':0,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
