"""One bounded four-part construction across every audited surviving core pair."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_pair_core_model import verify

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-pair-core-relocation-regions-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert load(BASE/'audit/checks.json')['passed']
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    survivors=load(BASE/'audit/surviving-neighborhoods.json');assert len(survivors)==229
    aux=load(SRC/'propagation.json');hints=load(SRC/'hint-poses.json')
    cases={s['case']:load(BASE/'cases'/f"{s['case']:03d}.json") for s in survivors}
    params={'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,
            'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/n for n in ['plan.json','result.json','audit/checks.json','audit/surviving-neighborhoods.json']]
    inputs += [BASE/'cases'/f"{s['case']:03d}.json" for s in survivors]
    inputs += [SRC/'propagation.json',SRC/'hint-poses.json',ROOT/'output/audit_h5_pair_core_model.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'construction_limit_seconds':120,'independent_model_audit_limit_seconds':120,
          'maximum_solver_calls':1,'parameters':params,'cases':229,'allocations':424,
          'fixed_original_parts':62,'mandatory_movable_parts':4,
          'required_original_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},
          'method':'Select exactly one of all229 surviving core pairs and one of its audited sheet allocations. Four shared physical-part anchors represent two mandatory extra brackets and both restored originals. Each selects one complete free cell of a role/mode in the chosen case; allowed sheets are only those occurring in audited surviving allocations. Components share their anchor and orientation. Up to14 coupled inner rectangles use two NoOverlap2D constraints with sheet/component-presence links; absent frame arms have no active intervals. Original-area capacity retained. No hints, objective, copy order or candidate sampling. Complete encoding audit before exactly one60-second call. Positive output is a proxy requiring original-outline/native diagnosis; no H5 qualification or unrestricted negative claim.'})
    for s in survivors:
        owners=s['released_items'];remaining=[h for h in hints if h['item'] not in owners]
        counts=Counter(h['family'] for h in remaining);counts.update(s['families']);counts['bracket']+=2
        assert len(remaining)==62 and counts=={'frame':18,'bracket':12,'insert':21,'cog':15}
    start=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*a for i,a in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] for i in en])
    loinf=cp_model.INT_MIN
    active={s['case']:var(f"case{s['case']}-active",0,1) for s in survivors}
    model.add_exactly_one([vs[v] for v in active.values()]);allocations=[]
    for s in survivors:
        rows=[]
        for j,a in enumerate(s['surviving_allocations']):
            enabled=var(f"case{s['case']}-allocation{j}",0,1);rows.append(enabled)
            charge=[]
            for sheet in [0,1]:
                v=cases[s['case']]['base_original_area_units'][sheet]+a['brackets_per_sheet'][sheet]*aux['part_areas']['bracket']['lower_units']
                v+=sum(aux['part_areas'][s['families'][k]]['lower_units'] for k in [0,1] if a['restored_sheets'][k]==sheet)
                assert v<=aux['sheet_capacities'][sheet]['upper_area_units'];charge.append(v)
            allocations.append({'case':s['case'],'allocation':j,'active':enabled,'value':a,'charges':charge})
        linear([(v,1) for v in rows]+[(active[s['case']],-1)],0,0)
    parts=[]
    for pi,role in enumerate(['bracket','bracket','restored0','restored1']):
        name=f'part{pi}';x=var(name+'-x',0,150000);y=var(name+'-y',0,300000);sheet=var(name+'-sheet',0,1);modes=[]
        for s in survivors:
            available=set()
            for a in s['surviving_allocations']:
                available.update([si for si in [0,1] if a['brackets_per_sheet'][si]] if role=='bracket' else [a['restored_sheets'][pi-2]])
            group=[]
            for row in cases[s['case']]['queries']:
                q=row['query']
                if q['role']!=role or q['sheet'] not in available:continue
                tag=name+f"-case{s['case']}-q{q['index']}";enabled=var(tag+'-active',0,1);cells=[]
                for j,c in enumerate(row['free_integer_cells']):
                    selected=var(tag+f'-cell{j}',0,1);cells.append(selected)
                    linear([(x,1)],c[0],c[2],[selected]);linear([(y,1)],c[1],c[3],[selected])
                linear([(v,1) for v in cells]+[(enabled,-1)],0,0);group.append(enabled)
                modes.append({'case':s['case'],'query':q['index'],'active':enabled,'cells':cells,'sheet':q['sheet'],'components':q['components']})
            linear([(v,1) for v in group]+[(active[s['case']],-1)],0,0)
        linear([(sheet,1)]+[(m['active'],-m['sheet']) for m in modes],0,0)
        components=[]
        for arm in range(2 if role=='bracket' else 5):
            present=var(name+f'-arm{arm}-present',0,1)
            linear([(present,1)]+[(m['active'],-1) for m in modes if arm<len(m['components'])],0,0)
            offsets=[]
            for axis in range(4):
                offset=var(name+f'-arm{arm}-offset{axis}',-50000,100000)
                linear([(offset,1)]+[(m['active'],-m['components'][arm][axis]) for m in modes if arm<len(m['components'])],0,0)
                offsets.append(offset)
            components.append({'present':present,'offsets':offsets})
        parts.append({'index':pi,'role':role,'x':x,'y':y,'sheet':sheet,'modes':modes,'components':components})
    for k in [0,1]:
        linear([(parts[k+2]['sheet'],1)]+[(a['active'],-a['value']['restored_sheets'][k]) for a in allocations],0,0)
    linear([(parts[0]['sheet'],1),(parts[1]['sheet'],1)]+[(a['active'],-a['value']['brackets_per_sheet'][1]) for a in allocations],0,0)
    for s in [0,1]:linear([(a['active'],a['charges'][s]) for a in allocations],loinf,aux['sheet_capacities'][s]['upper_area_units'])
    sheets=[{'x':[],'y':[]} for _ in [0,1]];rectangles=[]
    for p in parts:
        for arm,c in enumerate(p['components']):
            name=f"part{p['index']}-rect{arm}"
            coords=[var(name+'-'+suffix,-50000,400000) for suffix in ['sx','sy','ex','ey']]
            w=var(name+'-w',0,100000);h=var(name+'-h',0,100000)
            for d,v in enumerate(coords):linear([(v,1),(p['x'] if d%2==0 else p['y'],-1),(c['offsets'][d],-1)],0,0)
            linear([(w,1),(coords[2],-1),(coords[0],1)],0,0);linear([(h,1),(coords[3],-1),(coords[1],1)],0,0)
            on=[var(name+f'-on{s}',0,1) for s in [0,1]]
            linear([(on[0],1),(on[1],1),(c['present'],-1)],0,0)
            linear([(on[1],1),(p['sheet'],-1)],loinf,0);linear([(on[0],1),(p['sheet'],1)],loinf,1)
            intervals=[]
            for s in [0,1]:
                xi=model.new_optional_interval_var(vs[coords[0]],vs[w],vs[coords[2]],vs[on[s]],name+f'-sheet{s}-x')
                yi=model.new_optional_interval_var(vs[coords[1]],vs[h],vs[coords[3]],vs[on[s]],name+f'-sheet{s}-y')
                sheets[s]['x'].append(xi);sheets[s]['y'].append(yi);intervals.append([xi.index,yi.index])
            rectangles.append({'part':p['index'],'arm':arm,'coords':coords,'width':w,'height':h,'on':on,'intervals':intervals})
    for s in sheets:model.add_no_overlap_2d(s['x'],s['y'])
    mapping={'cases':active,'allocations':allocations,'parts':parts,'rectangles':rectangles}
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',mapping)
    build_seconds=time.perf_counter()-start;assert build_seconds<120
    print({'construction_seconds':build_seconds,'variables':len(vs)},flush=True)
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    oracle,stats=verify(actual,survivors,cases,aux);assert oracle==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    audit_seconds=time.perf_counter()-start;assert audit_seconds<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':build_seconds,'audit_seconds':audit_seconds,
          'all_variables_constraints_and_parameters_independently_reconstructed':True,**stats,
          'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),
          'python':sys.version,'ortools':ortools.__version__})
    print(load(OUT/'model-audit.json'),flush=True)
    def positions(value):
        selected=[a for a in allocations if value(vs[a['active']])];assert len(selected)==1;a=selected[0];rows=[]
        for p in parts:
            modes=[m for m in p['modes'] if value(vs[m['active']])];assert len(modes)==1;m=modes[0]
            cells=[j for j,v in enumerate(m['cells']) if value(vs[v])];assert len(cells)==1 and m['case']==a['case']
            q=cases[m['case']]['queries'][m['query']]['query']
            rows.append({'part':p['index'],'role':p['role'],'case':m['case'],'query':m['query'],'cell':cells[0],
                         'x_units':value(vs[p['x']]),'y_units':value(vs[p['y']]),'sheet':value(vs[p['sheet']]),
                         'family':q['family'],'mode':q['mode'],'class':q['class']})
        return {'case':a['case'],'allocation':a['allocation'],'released_items':cases[a['case']]['case']['released_items'],'movable_parts':rows}
    incumbents=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            record=positions(self.value);write(OUT/f'incumbent-{len(incumbents)}.json',record)
            incumbents.append({'index':len(incumbents),'seconds':self.wall_time,'case':record['case']});print(incumbents[-1],flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush())
        start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if feasible:write(OUT/'positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'incumbents':incumbents,
            'has_full_proxy_solution':feasible,'response_stats':solver.response_stats(),
            'scope':'All229 complete surviving two-core-release neighborhoods with424 surviving allocations;62 original proxy poses fixed, four mandatory movable parts. UNKNOWN is unresolved. Any infeasibility is conditional on these neighborhoods and finite source orientation inventory. A positive proxy still requires original-outline/native diagnosis.',
            'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
