from pathlib import Path
from datetime import datetime,timezone
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-pair-core-relocation-regions-20261025/repository-sync'
OUT.mkdir()
shutil.copyfile(ROOT/'output/seal_h5_pair_core_relocation.py',OUT/'sealer-before-ci-recovery.py')
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
write(OUT/'initial-sealer-failure.json',{'utc_recorded':datetime.now(timezone.utc).isoformat(),
      'stage':'Read existing main CI40233299884 before creating evidence destination',
      'command':['gh','run','view','40233299884','--json','status,conclusion,jobs,headSha,url'],
      'exit_code':1,'stderr':'error connecting to api.github.com; check your internet connection or https://githubstatus.com',
      'destination_created':False,'analysis_or_solver_repeated':False,
      'recovery':'A read of the same live run subsequently succeeded with five checks successful and Windows checks in progress. Capture that same run separately and let archival consume its immutable snapshot.'})
r=subprocess.run(['gh','run','view','40233299884','--json','status,conclusion,jobs,headSha,url'],cwd=ROOT,capture_output=True)
(OUT/'snapshot.stderr.txt').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
ci=json.loads(r.stdout);assert ci['headSha']=='247e823a9feef2bf906e27204981b957dc55cdfc'
write(OUT/'main-ci.json',ci)
write(OUT/'snapshot.json',{'utc':datetime.now(timezone.utc).isoformat(),'run_id':40233299884,'status':ci['status'],'conclusion':ci['conclusion'],
      'successful_jobs':sum(j['conclusion']=='success' for j in ci['jobs']),'total_jobs':len(ci['jobs']),'same_run_no_restart':True})
print(json.dumps(json.loads((OUT/'snapshot.json').read_bytes())))
