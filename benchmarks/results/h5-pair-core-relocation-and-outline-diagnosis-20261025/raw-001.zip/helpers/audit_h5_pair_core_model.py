"""Independent protobuf oracle for the complete four-part relocation model."""
from collections import Counter
from itertools import combinations
from ortools.sat import cp_model_pb2

def verify(actual,survivors,cases,aux):
    vi=ci=mode_count=cell_count=own_pairs=0
    def vcheck(name,lo,hi):
        nonlocal vi
        expected=cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi])
        assert actual.variables[vi]==expected,(vi,name)
        vi+=1;return vi-1
    def lcheck(terms,lo,hi,en=()):
        nonlocal ci
        merged=Counter()
        for v,c in terms:merged[v]+=c
        ids=sorted(i for i,c in merged.items() if c)
        expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.extend(en)
        expected.linear.vars.extend(ids);expected.linear.coeffs.extend(merged[i] for i in ids);expected.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected)
        ci+=1
    def ccheck(expected):
        nonlocal ci
        assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected)
        ci+=1
    active={s['case']:vcheck(f"case{s['case']}-active",0,1) for s in survivors}
    expected=cp_model_pb2.ConstraintProto();expected.exactly_one.literals.extend(active.values());ccheck(expected)
    allocations=[]
    for s in survivors:
        enabled=[]
        for j,a in enumerate(s['surviving_allocations']):
            vid=vcheck(f"case{s['case']}-allocation{j}",0,1);enabled.append(vid);charges=[]
            for sheet in [0,1]:
                required=cases[s['case']]['base_original_area_units'][sheet]
                required+=aux['part_areas']['bracket']['lower_units']*a['brackets_per_sheet'][sheet]
                for k,destination in enumerate(a['restored_sheets']):
                    if destination==sheet:required+=aux['part_areas'][s['families'][k]]['lower_units']
                assert required<=aux['sheet_capacities'][sheet]['upper_area_units'];charges.append(required)
            allocations.append({'case':s['case'],'allocation':j,'active':vid,'value':a,'charges':charges})
        lcheck([(v,1) for v in enabled]+[(active[s['case']],-1)],0,0)
    assert len(active)==229 and len(allocations)==424
    parts=[]
    for pi in range(4):
        role='bracket' if pi<2 else f'restored{pi-2}';name=f'part{pi}'
        x=vcheck(name+'-x',0,150000);y=vcheck(name+'-y',0,300000);sheet=vcheck(name+'-sheet',0,1);modes=[]
        for s in survivors:
            if pi<2:
                available={sheet for sheet in [0,1] if any(a['brackets_per_sheet'][sheet]>0 for a in s['surviving_allocations'])}
            else:available={a['restored_sheets'][pi-2] for a in s['surviving_allocations']}
            enabled=[]
            for record in cases[s['case']]['queries']:
                q=record['query']
                if q['role']!=role or q['sheet'] not in available:continue
                prefix=f"part{pi}-case{s['case']}-q{q['index']}";vid=vcheck(prefix+'-active',0,1);enabled.append(vid);cells=[]
                for j,bounds in enumerate(record['free_integer_cells']):
                    cell=vcheck(prefix+f'-cell{j}',0,1);cells.append(cell)
                    lcheck([(x,1)],bounds[0],bounds[2],[cell]);lcheck([(y,1)],bounds[1],bounds[3],[cell])
                lcheck([(v,1) for v in cells]+[(vid,-1)],0,0);cell_count+=len(cells);mode_count+=1
                for rect in q['components']:assert rect[0]<rect[2] and rect[1]<rect[3]
                for a,b in combinations(q['components'],2):
                    assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
                    own_pairs+=1
                modes.append({'case':s['case'],'query':q['index'],'active':vid,'cells':cells,'sheet':q['sheet'],'components':q['components']})
            lcheck([(v,1) for v in enabled]+[(active[s['case']],-1)],0,0)
        lcheck([(sheet,1)]+[(m['active'],-1) for m in modes if m['sheet']==1],0,0)
        components=[]
        for arm in range([2,2,5,5][pi]):
            present=vcheck(name+f'-arm{arm}-present',0,1)
            lcheck([(present,1)]+[(m['active'],-1) for m in modes if len(m['components'])>arm],0,0)
            offsets=[]
            for coordinate in [0,1,2,3]:
                off=vcheck(name+f'-arm{arm}-offset{coordinate}',-50000,100000)
                lcheck([(off,1)]+[(m['active'],-m['components'][arm][coordinate]) for m in modes if len(m['components'])>arm],0,0)
                offsets.append(off)
            components.append({'present':present,'offsets':offsets})
        parts.append({'index':pi,'role':role,'x':x,'y':y,'sheet':sheet,'modes':modes,'components':components})
    for k in [0,1]:lcheck([(parts[2+k]['sheet'],1)]+[(a['active'],-a['value']['restored_sheets'][k]) for a in allocations],0,0)
    lcheck([(parts[0]['sheet'],1),(parts[1]['sheet'],1)]+[(a['active'],-a['value']['brackets_per_sheet'][1]) for a in allocations],0,0)
    for sheet in [0,1]:lcheck([(a['active'],a['charges'][sheet]) for a in allocations],-2**63,aux['sheet_capacities'][sheet]['upper_area_units'])
    rectangles=[];groups=[{'x':[],'y':[]} for _ in [0,1]]
    for p in parts:
        for arm,component in enumerate(p['components']):
            name=f"part{p['index']}-rect{arm}"
            coords=[vcheck(name+'-'+n,-50000,400000) for n in ['sx','sy','ex','ey']]
            w=vcheck(name+'-w',0,100000);h=vcheck(name+'-h',0,100000)
            for j in range(4):
                anchor=p['x'] if j in [0,2] else p['y']
                lcheck([(coords[j],1),(anchor,-1),(component['offsets'][j],-1)],0,0)
            lcheck([(coords[0],1),(coords[2],-1),(w,1)],0,0);lcheck([(coords[1],1),(coords[3],-1),(h,1)],0,0)
            present=[vcheck(name+f'-on{sheet}',0,1) for sheet in [0,1]]
            lcheck([(present[0],1),(present[1],1),(component['present'],-1)],0,0)
            lcheck([(present[1],1),(p['sheet'],-1)],-2**63,0);lcheck([(present[0],1),(p['sheet'],1)],-2**63,1)
            # Truth-table check: every present arm belongs only to its part's sheet;
            # absent arms create no active interval, including zero-size placeholders.
            for cp in [0,1]:
                for sheet in [0,1]:
                    feasible=[(a,b) for a in [0,1] for b in [0,1] if a+b==cp and b<=sheet and a+sheet<=1]
                    assert feasible==[(cp*(1-sheet),cp*sheet)]
            intervals=[]
            for sheet in [0,1]:
                ids=[]
                for axis,start,size,end in [('x',coords[0],w,coords[2]),('y',coords[1],h,coords[3])]:
                    idx=ci;expected=cp_model_pb2.ConstraintProto(name=name+f'-sheet{sheet}-{axis}')
                    expected.enforcement_literal.append(present[sheet])
                    for expression,value in [(expected.interval.start,start),(expected.interval.size,size),(expected.interval.end,end)]:
                        expression.vars.append(value);expression.coeffs.append(1)
                    ccheck(expected);ids.append(idx);groups[sheet][axis].append(idx)
                intervals.append(ids)
            rectangles.append({'part':p['index'],'arm':arm,'coords':coords,'width':w,'height':h,'on':present,'intervals':intervals})
    for sheet in [0,1]:
        expected=cp_model_pb2.ConstraintProto();expected.no_overlap_2d.x_intervals.extend(groups[sheet]['x'])
        expected.no_overlap_2d.y_intervals.extend(groups[sheet]['y']);ccheck(expected)
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints')
    assert not extra.ListFields()
    return {'cases':active,'allocations':allocations,'parts':parts,'rectangles':rectangles}, {
        'variables':vi,'constraints':ci,'cases':len(active),'allocations':len(allocations),
        'original_required_parts_per_case':66,'fixed_original_parts_per_case':62,'mandatory_movable_parts':4,
        'role_mode_options':mode_count,'complete_free_cell_options':cell_count,'maximum_inner_rectangles':14,
        'optional_intervals':56,'global_no_overlap_2d_constraints':2,'original_area_capacity_constraints':2,
        'own_component_disjointness_checks':own_pairs,'sheet_component_presence_truth_tables_checked':True,
        'hints':0,'objectives':0,'copy_order_constraints':0,'no_optional_original_parts':True}
