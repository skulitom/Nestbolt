"""Prepare a new guarded normal push after the current main CI passed all6 jobs."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58'
source=(ROOT/'output/push_h5_cover_checkpoints_20261028.py').read_text(encoding='utf-8')
changes={
 'output/h5-cover-checkpoints-main-sync-20261028':'output/h5-bracket-bound-main-sync-20261028',
 "OLD='75ee537cdd9855c40216eccd5b011817ea91378e';NEW='608fecf12c287805fddcd8e64b9db7fef4950b70'":"OLD='608fecf12c287805fddcd8e64b9db7fef4950b70';NEW='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58'",
 "['benchmarks/results/h5-joint-sheet-and-union-covers-20261028','benchmarks/results/h5-union-cover-resolution-and-transfer-20261028']":"['benchmarks/results/h5-transfer-and-hybrid-row-clearance-20261028','benchmarks/results/h5-bracket-source-regions-and-fixed-layout-bound-20261028']",
 '40764537562':'40771628220'
}
for old,new in changes.items():
 assert old in source,old
 source=source.replace(old,new)
with (ROOT/'output/push_h5_bracket_bound_checkpoint_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'head':head,'prior_CI':40771628220,'guard_prepared':True})
