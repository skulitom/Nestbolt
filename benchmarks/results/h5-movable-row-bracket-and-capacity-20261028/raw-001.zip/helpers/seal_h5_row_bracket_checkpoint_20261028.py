"""Seal the closed movable row/bracket model and audited necessary-capacity preflight."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-row-bracket-source-20261028';PUB=BASE/'publication';NAME='h5-movable-row-bracket-and-capacity-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58' and not git('diff','HEAD','--name-only')
for a in ['geometry-audit','model-audit','source-bridge-audit','row-identity-audit','response-audit','simplification-study/audit','capacity-preflight/audit']:assert load(BASE/a/'checks.json')['passed']
response=load(BASE/'search/result.json');assert response['closed'] and response['solver_calls']==1 and response['status']=='UNKNOWN' and not response['has_solution']
model=load(BASE/'model-audit/checks.json');assert model['mandatory_blocks']==43 and model['target_originals']==66 and model['all903_block_pairs_covered'] and model['all8_old_false_rejections_removed']
simp=load(BASE/'simplification-study/audit/checks.json');assert simp['both_variants_ineligible_under_frozen_policy'] and simp['selected'] is None
cap=load(BASE/'capacity-preflight/audit/checks.json');assert cap['new_constraints_necessary_for_original_parts'] and not cap['new_model_created'] and cap['solver_calls']==0 and cap['positive_controls_verified']==9 and cap['negative_control_overflows_both_capacities']
prior=load(ROOT/'benchmarks/results/h5-bracket-source-regions-and-fixed-layout-bound-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
releases=load(PUB/'nestbolt-releases.json');assert [(r['tag_name'],r['prerelease'],r['draft']) for r in releases]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];assert main==head;jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==5 and live==['checks (windows-latest)']
receipt=load(ROOT/'output/h5-bracket-bound-main-sync-20261028/receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-bracket-bound-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set((ROOT/'output').glob('*row_bracket*20261028.py'))
helpers.update(ROOT/'output'/n for n in ['h5_adjacent_convex_cells_20261028.py','pack_h5_evidence_archive.py','ccd1.py','prepare_h5_bracket_bound_push_20261028.py','push_h5_bracket_bound_checkpoint_20261028.py','verify_h5_row_bracket_archive_20261028.py',Path(__file__).name])
for p in helpers:add('helpers/'+p.name,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('geometry-audit/checks.json','source-region-audit.json'),('model-audit/checks.json','model-audit.json'),('source-bridge-audit/checks.json','source-bridge-audit.json'),('row-identity-audit/checks.json','row-identity-audit.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json'),('simplification-study/result.json','simplification-results.json'),('simplification-study/audit/checks.json','simplification-audit.json'),('capacity-preflight/audit/checks.json','capacity-audit.json'),('capacity-preflight/audit/necessity-proof.json','capacity-proof.json'),('capacity-preflight/audit/control-checks.json','capacity-controls.json')]:shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');shutil.copyfile(ROOT/'output/h5-bracket-bound-main-sync-20261028/receipt.json',OUT/'prior-push-receipt.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40777420353,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'full_target_originals':66,'first_sheet_originals':54,'independently_movable_first_sheet_blocks':43,'fixed_short_sheet_originals':12,'closed_solver_calls':1,'solver_status':'UNKNOWN','source_valid66_count':0,'actual_or_global_infeasibility_claimed':False,'simplification_variants_rejected':2,'capacity_containment_audited':True,'capacity_model_created':False,'capacity_solver_calls':0,'valid64_preserved':True,'remaining_necessary_allocations':444,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
