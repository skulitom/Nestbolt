"""Independent original-source clearance and rational cell proof for all16 row/bracket types."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box,Point
from shapely.affinity import translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-source-20261028';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';OUT=BASE/'geometry-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
modes=load(BASE/'modes.json');job=load(JOB);parts={p['id']:p for p in job['parts']};assert parts['bracket']['rotations']=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]} and parts['bracket']['allow_mirror'];assert {(modes[i]['quarter'],modes[i]['mirrored']) for i in range(2,10)}=={(q,mir) for q in range(4) for mir in [False,True]};counts={'types':0,'source_cog_bracket_pairs':0,'independent_minkowski_hulls':0,'cells':0,'planes':0};records=[]
def polygon(family,a,mir,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1;return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in parts[family]['geometry'][0]['outer']])
def triangles(g):
    tt=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(tt).equals(g) and all(p.equals(p.convex_hull) for p in tt);return tt
def limits(m):
    a,b,c,d=m['source_bounds_mm'];return [math.ceil(6513-a*1000),math.ceil(6513-b*1000),math.floor(1493487-c*1000),math.floor(2993487-d*1000)]
angle=math.radians(7);raw=polygon('cog',angle,False,[0,0]);x0,y0,_,_=raw.bounds
for ri,mi in product([12,13],range(2,10)):
    data=load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json');row,br=modes[ri],modes[mi];assert (data['row_mode'],data['bracket_mode'])==(ri,mi) and row['row_size']==len(row['source_instances']);moving=polygon('bracket',br['angle'],br['mirrored'],br['source_translation_offset']);mt=triangles(moving);forbidden=shape(data['forbidden_geometry']);intrinsic=shape(load(STUDY/'obstacles'/f'{mi:02d}-cog-phase7.json'));assert data['row_member_offsets_mm']==[[j*258.9,0.] for j in range(row['row_size'])] and forbidden.equals(unary_union([translate(intrinsic,*offset) for offset in data['row_member_offsets_mm']]))
    for j,instance in enumerate(row['source_instances']):
        offset=[j*258.9-x0,-y0];assert instance['angle']==angle and not instance['mirrored'] and max(abs(a-b) for a,b in zip(offset,instance['translation']))<1e-9;fixed=polygon('cog',angle,False,offset);tt=triangles(fixed);hulls=[MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(a.exterior.coords)[:-1] for v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(tt,mt)];required=unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,quad_segs=16);assert forbidden.covers(required),(ri,mi,j,required.difference(forbidden).area);counts['independent_minkowski_hulls']+=len(hulls);counts['source_cog_bracket_pairs']+=1
    aa,bb=limits(row),limits(br);bounds=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];assert bounds==data['relative_bounds_um'] and max(abs(bounds[0]),abs(bounds[2]))<=1600000 and max(abs(bounds[1]),abs(bounds[3]))<=3100000;domain=shape(data['domain_geometry']);assert domain.equals(box(*(v/1000 for v in bounds)).difference(forbidden));polys=[]
    for cell in data['cells']:
        p=shape(cell['geometry']);assert p.is_valid and not p.interiors and p.equals(p.convex_hull);polys.append(p);vv=[tuple(F(str(x)) for x in pt) for pt in list(p.exterior.coords)[:-1]];assert len(vv)==len(cell['halfplanes']) and sum(u[0]*v[1]-u[1]*v[0] for u,v in zip(vv,vv[1:]+vv[:1]))>0
        for (u,v),(aa,bb,cc) in zip(zip(vv,vv[1:]+vv[:1]),cell['halfplanes']):
            nx,ny=u[1]-v[1],v[0]-u[0];norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm;assert all(nx*(w[0]-u[0])+ny*(w[1]-u[1])>=0 for w in vv);assert aa==round(nx*10**9) and bb==round(ny*10**9);target=10**12*(nx*u[0]+ny*u[1]);error=abs(aa-10**9*nx)*1600000+abs(bb-10**9*ny)*3100000;assert F(cc)>target+error and F(cc-1)<=target+error+1;counts['planes']+=1
        counts['cells']+=1
    assert unary_union(polys).equals(domain);partition=data['partition'];initial=len(list(shapely.constrained_delaunay_triangles(domain).geoms));assert partition['initial_triangles']==initial and partition['convex_pieces']==len(polys) and partition['accepted_merges']==initial-len(polys);counts['types']+=1;records.append({'row_mode':ri,'bracket_mode':mi,'source_pairs':row['row_size'],'cells':len(polys),'original_clearance_contained':True})
controls=load(BASE/'control-region-checks.json');assert len(controls)==33
for c in controls:
    data=load(BASE/'row-bracket'/f"{c['row_mode']:02d}-{c['bracket_mode']:02d}.json");x,y=c['delta_um'];assert c['source_domain_contains'] and shape(data['domain_geometry']).covers(Point(x/1000,y/1000));selected=next((i for i,cell in enumerate(data['cells']) if all(a*x+b*y>=v for a,b,v in cell['halfplanes'])),None);assert selected==c['selected_cell'] and selected is not None
for r in load(BASE/'zero-negative-checks.json'):
    data=load(BASE/'row-bracket'/f"{r['row_mode']:02d}-{r['bracket_mode']:02d}.json");assert r['zero_rejected'] and not any(all(v<=0 for a,b,v in c['halfplanes']) for c in data['cells'])
prepared=load(BASE/'prepared.json');assert counts['cells']==prepared['convex_cells'] and counts['planes']==prepared['halfplanes'] and counts['source_cog_bracket_pairs']==prepared['source_cog_bracket_pairs']==72
write(OUT/'types.json',records);inputs=[BASE/'plan.json',BASE/'prepared.json',BASE/'typed-summary.json',BASE/'control-region-checks.json',BASE/'zero-negative-checks.json',JOB]+list((BASE/'row-bracket').glob('*.json'));write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,**counts,'positive_control_displacements_verified':33,'zero_displacements_rejected':16,'all8_legal_bracket_modes_verified':True,'all_typed_domains_cover_required_source_clearance':True,'every_integer_halfplane_proved_conservative':True,'target_row_bracket_owner_pairs':15,'target_row_bracket_mode_cases':120,'existing_first_sheet_originals_remain_movable':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
