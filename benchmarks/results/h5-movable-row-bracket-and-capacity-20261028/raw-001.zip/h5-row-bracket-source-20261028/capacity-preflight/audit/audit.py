"""Exact source containment and complete-control capacity proof; no solver model."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-source-20261028';DATA=BASE/'capacity-preflight';OUT=DATA/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';HYBRID=ROOT/'output/h5-hybrid43-guarded-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def ring(points,a,mir,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1;return [tuple(F(str(v)) for v in (sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1])) for x,y in points]
def segment_hits(a,b,r):
    lo,hi=F(0),F(1)
    for axis in [0,1]:
        delta=b[axis]-a[axis]
        if delta==0:
            if not r[axis]<=a[axis]<=r[axis+2]:return False
        else:
            u,v=sorted([(r[axis]-a[axis])/delta,(r[axis+2]-a[axis])/delta]);lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
def inside(point,vv):
    x,y=point;answer=False
    for a,b in zip(vv,vv[1:]+vv[:1]):
        if (a[1]>y)!=(b[1]>y):
            crossing=a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1])
            if x<crossing:answer=not answer
    return answer
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(DATA/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
modes=load(BASE/'modes.json');blocks=load(BASE/'blocks43.json');rows=load(DATA/'mode-contained-rectangles.json');job=load(JOB);parts={p['id']:p for p in job['parts']};edge_checks=rect_count=disjoint=0;assert len(rows)==len(modes)==14
for m,saved in zip(modes,rows):
    assert saved['mode']==m['id'] and saved['family']==m['family'];vv=[]
    if m['family']=='cog-row':
        a=math.radians(7);raw=ring(parts['cog']['geometry'][0]['outer'],a,False,[0,0]);lo=[min(v[k] for v in raw) for k in [0,1]]
        # Independently reproduce the original-source bridge offsets, not the saved template translations.
        for j in range(m['row_size']):vv.append(ring(parts['cog']['geometry'][0]['outer'],a,False,[j*258.9-float(lo[0]),-float(lo[1])]))
    else:
        q=m['quarter'];c,s=[(1,0),(0,1),(-1,0),(0,-1)][q];sign=-1 if m['mirrored'] else 1;raw=[(sign*x*c-y*s,sign*x*s+y*c) for x,y in parts[m['family']]['geometry'][0]['outer']];offset=[-min(v[k] for v in raw) for k in [0,1]];vv=[ring(parts[m['family']]['geometry'][0]['outer'],q*math.pi/2,m['mirrored'],offset)]
    assert saved['source_instances']==len(vv)
    for component in saved['components']:
        ix=component['source_instance'];r=component['rectangle_um'];assert 0<=ix<len(vv) and all(type(v)==int for v in r) and r[0]<r[2] and r[1]<r[3];rr=[F(v,1000) for v in r];assert inside(rr[:2],vv[ix])
        for a,b in zip(vv[ix],vv[ix][1:]+vv[ix][:1]):assert not segment_hits(a,b,rr);edge_checks+=1
        rect_count+=1
    rects=[v['rectangle_um'] for v in saved['components']]
    for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];disjoint+=1
    assert saved['contained_area_um2']==sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)
controls=[('source52',load(BASE/'control.json'),True)]+[(f"source62-mode{w['mode']}",load(HYBRID/'control.json')+[w['pose']],True) for w in load(STUDY/'witness-summary.json')]+[('negative66',load(BASE/'negative.json'),False)];summary=load(DATA/'control-sweeps-summary.json');records=[]
for name,poses,valid in controls:
    rectangles=[]
    for p in poses:
        assert blocks[p['block']]['family']==modes[p['mode']]['family'];x,y=p['anchor_um'];rectangles.extend([a+x,b+y,c+x,d+y] for a,b,c,d in [v['rectangle_um'] for v in rows[p['mode']]['components']])
    sweeps=[]
    for axis,capacity in [(0,2987000),(1,1487000)]:
        events={}
        for r in rectangles:
            a,b=r[axis],r[axis+2];amount=r[3-axis]-r[1-axis];events[a]=events.get(a,0)+amount;events[b]=events.get(b,0)-amount
        current=peak=0;states=[]
        for where,delta in sorted(events.items()):current+=delta;peak=max(peak,current);states.append([where,current])
        assert current==0;sweeps.append({'axis':axis,'capacity_um':capacity,'maximum_demand_um':peak,'slack_um':capacity-peak,'events':states})
    assert sweeps==load(DATA/(name+'-sweeps.json'));accepted=all(v['slack_um']>=0 for v in sweeps);assert accepted==valid;record={'control':name,'components':len(rectangles),'capacity_valid':accepted,'slack_um':[v['slack_um'] for v in sweeps]};assert record==next(r for r in summary if r['control']==name);records.append(record)
plan=load(BASE/'plan.json');assert plan['source_stocks']['sheet-0']==[6.5,6.5,1493.5,2993.5] and not plan['common_line_part_in_hole'];prepared=load(DATA/'prepared.json');options=sum(len(rows[m['id']]['components']) for b in blocks for m in modes if m['family']==b['family'] and (b['family']!='cog-row' or m['row_size']==b['row_size']));assert prepared['mode_contained_rectangles']==rect_count and prepared['expanded_optional_components']==options and prepared['proposed_interval_constraints']==2*options
write(OUT/'necessity-proof.json',{'statement':'Each active rectangle lies strictly inside one original filled outer. Exact rational ray parity and source-edge parametric clipping prove containment; exact integer comparisons prove disjoint interiors within each entire row or singleton mode. Distinct placed originals in a valid common-line layout cannot overlap their filled outers, so their contained rectangles have disjoint interiors. All lie inside the original first-sheet source stock. At every open X section the sum of their Y lengths is at most2987000um; at every open Y section the sum of X lengths is at most1487000um. Half-open scheduling endpoints preserve these bounds. A future model can condition each component on the existing unique source mode selector and impose these two necessary global cumulatives without removing any valid original placement. No extra clearance, exterior cover or row-to-row rectangle disjointness is assumed.','scope':'All43 selected first-sheet blocks, containing54 originals; exact short12 is unchanged. This proof adds no constraints to an existing model yet.'});write(OUT/'control-checks.json',records);inputs=[DATA/'plan.json',DATA/'prepared.json',DATA/'mode-contained-rectangles.json',DATA/'control-sweeps-summary.json']+list(DATA.glob('*-sweeps.json'))+[BASE/'plan.json',BASE/'modes.json',BASE/'blocks43.json',JOB];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':14,'exact_contained_rectangles_verified':rect_count,'exact_source_segment_checks':edge_checks,'same_mode_disjoint_rectangle_pairs':disjoint,'expanded_optional_components':options,'proposed_interval_constraints':2*options,'proposed_global_cumulatives':2,'proposed_extra_variables':0,'positive_controls_verified':9,'negative_control_overflows_both_capacities':all(v<0 for v in records[-1]['slack_um']),'new_constraints_necessary_for_original_parts':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
