"""Prepare only necessary whole-sheet capacities from source-contained rectangles."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-source-20261028';OUT=BASE/'capacity-preflight';CAP=ROOT/'output/h5-free23-capacity-20261028';OLDMODES=ROOT/'output/h5-free23-source-regions-20261028/modes.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';HYBRID=ROOT/'output/h5-hybrid43-guarded-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transformed(points,a,mir,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1;return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in points])
def inner(g):
    a,b,c,d=g.bounds;rr=[math.ceil(a*1000)+2,math.ceil(b*1000)+2,math.floor(c*1000)-2,math.floor(d*1000)-2];assert g.contains(box(*(v/1000 for v in rr)));return rr
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'search/result.json')['closed'] and load(BASE/'simplification-study/audit/checks.json')['both_variants_ineligible_under_frozen_policy'];inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','control.json','negative.json','model/model.pb','model/mapping.json','model-audit/plan.json','model-audit/checks.json','response-audit/plan.json','response-audit/checks.json','search/result.json','simplification-study/audit/plan.json','simplification-study/audit/checks.json']]+[CAP/'plan.json',CAP/'mode-rectangles.json',CAP/'geometry-audit-corrected/plan.json',CAP/'geometry-audit-corrected/checks.json',OLDMODES,JOB,STUDY/'audit/checks.json',STUDY/'witness-summary.json',HYBRID/'control.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare a new necessary global-capacity strengthening of the closed precise row/bracket model. Preserve all existing source regions, modes, mandatory originals and collision constraints. Derive rectangles strictly inside every original source instance: reuse the audited5mm cog grid, translate to each actual row member and round inward another2um; use inward2um source rectangles for frames, inserts and the two bracket components. Verify exact source-edge containment and disjoint rectangle interiors across every entire mode. Proposed cumulative constraints include all43 selected blocks simultaneously, with1487000um width and2987000um height capacities. Source rectangles carry no additional clearance demand and do not cover empty space. The short12 remains unchanged. Source52 and all8 source62 control sweeps must pass; overlapping66 must overflow. This preflight constructs no new solver model and calls no optimizer. A future model must preserve every old field and add only the proved necessary capacities before one separately frozen call.','capacity_width_um':1487000,'capacity_height_um':2987000,'source_holes_reserved':True,'new_capacity_constraints_necessary':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
modes=load(BASE/'modes.json');blocks=load(BASE/'blocks43.json');job=load(JOB);parts={p['id']:p for p in job['parts']};oldcg=load(OLDMODES)[0];cgrects=load(CAP/'mode-rectangles.json')[0]['rectangles_um'];rows=[]
for m in modes:
    components=[]
    if m['family']=='cog-row':
        for j,spec in enumerate(m['source_instances']):
            assert spec['angle']==oldcg['angle'] and not spec['mirrored'];dx,dy=[spec['translation'][k]-oldcg['source_translation_offset'][k] for k in [0,1]];g=transformed(parts['cog']['geometry'][0]['outer'],spec['angle'],False,spec['translation'])
            for a,b,c,d in cgrects:
                rr=[math.ceil(a+dx*1000)+2,math.ceil(b+dy*1000)+2,math.floor(c+dx*1000)-2,math.floor(d+dy*1000)-2];assert g.contains(box(*(v/1000 for v in rr)));components.append({'source_instance':j,'rectangle_um':rr})
    else:
        rings=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]] if m['family']=='bracket' else [parts[m['family']]['geometry'][0]['outer']]
        for ring in rings:components.append({'source_instance':0,'rectangle_um':inner(transformed(ring,m['angle'],m['mirrored'],m['source_translation_offset']))})
    for a,b in combinations([c['rectangle_um'] for c in components],2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
    rows.append({'mode':m['id'],'family':m['family'],'source_instances':m.get('row_size',1),'components':components,'contained_area_um2':sum((r['rectangle_um'][2]-r['rectangle_um'][0])*(r['rectangle_um'][3]-r['rectangle_um'][1]) for r in components)})
write(OUT/'mode-contained-rectangles.json',rows);controls=[{'name':'source52','poses':load(BASE/'control.json'),'valid':True}]+[{'name':f"source62-mode{w['mode']}",'poses':load(HYBRID/'control.json')+[w['pose']],'valid':True} for w in load(STUDY/'witness-summary.json')]+[{'name':'negative66','poses':load(BASE/'negative.json'),'valid':False}];checks=[]
for case in controls:
    rectangles=[]
    for p in case['poses']:
        x,y=p['anchor_um'];rectangles.extend([a+x,b+y,c+x,d+y] for a,b,c,d in [v['rectangle_um'] for v in rows[p['mode']]['components']])
    axes=[]
    for axis,capacity in [(0,2987000),(1,1487000)]:
        events={}
        for r in rectangles:
            a,b=r[axis],r[axis+2];d=r[3-axis]-r[1-axis];events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
        current=maximum=0;states=[]
        for where,delta in sorted(events.items()):current+=delta;maximum=max(maximum,current);states.append([where,current])
        assert current==0;axes.append({'axis':axis,'capacity_um':capacity,'maximum_demand_um':maximum,'slack_um':capacity-maximum,'events':states})
    accepted=all(r['slack_um']>=0 for r in axes);assert accepted==case['valid'];write(OUT/(case['name']+'-sweeps.json'),axes);checks.append({'control':case['name'],'components':len(rectangles),'capacity_valid':accepted,'slack_um':[r['slack_um'] for r in axes]})
options=sum(len(rows[m['id']]['components']) for b in blocks for m in modes if m['family']==b['family'] and (b['family']!='cog-row' or m['row_size']==b['row_size']));write(OUT/'control-sweeps-summary.json',checks);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_modes':14,'mode_contained_rectangles':sum(len(r['components']) for r in rows),'source_cog_rectangles_per_cog':len(cgrects),'expanded_optional_components':options,'proposed_interval_constraints':2*options,'proposed_global_cumulatives':2,'proposed_extra_variables':0,'positive_controls':9,'negative_controls':1,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'));print(checks)
