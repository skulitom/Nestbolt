"""Fully movable43-block source row/bracket replacement; every original stays mandatory."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-source-20261028';OLD=ROOT/'output/h5-hybrid43-guarded-source-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(BASE/'geometry-audit/checks.json')['passed']
for n,h in load(BASE/'geometry-audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());oldmp=load(OLD/'model/mapping.json');modes=load(BASE/'modes.json');items=oldmp['items'];groups=[];replaced=[]
for row in [40,41,42,None]:
    members=[p for p in items if (p['source_block']['family']!='cog-row' if row is None else p['source_block']['family'] in ['frame','insert'] or p['index']==row)];xs=[];ys=[];widths=[];heights=[]
    for item in members:
        for o in item['options']:
            for c,(a,b,d,e) in zip(o['components'],modes[o['mode']]['cover_rectangles_um']):xs.append(c['x_interval']);ys.append(c['y_interval']);widths.append(d-a);heights.append(e-b)
    group={'row':row,'members':[p['index'] for p in members],'xs':xs,'ys':ys,'widths':widths,'heights':heights}
    if row is not None:
        oldgroup=next(g for g in oldmp['collision_groups'] if g['row']==row);ix,xc,yc=oldgroup['constraints'];group['constraints']=[ix,xc,yc];replaced.extend(group['constraints'])
        for j in group['constraints']:old.constraints[j].Clear()
        old.constraints[ix].no_overlap_2d.x_intervals.extend(xs);old.constraints[ix].no_overlap_2d.y_intervals.extend(ys)
        for j,ints,demands,cap in [(xc,xs,heights,2987202),(yc,ys,widths,1487202)]:
            ct=old.constraints[j].cumulative;ct.intervals.extend(ints);ct.capacity.offset=cap
            for d in demands:ct.demands.add(offset=d)
    groups.append(group)
old.ClearField('solution_hint');model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(old));g=groups[-1];xs=[model.get_interval_var_from_proto_index(i) for i in g['xs']];ys=[model.get_interval_var_from_proto_index(i) for i in g['ys']];g['constraints']=[model.add_no_overlap_2d(xs,ys).index,model.add_cumulative(xs,g['heights'],2987202).index,model.add_cumulative(ys,g['widths'],1487202).index];pairgroups=[]
for ri,bi in product([40,41,42],range(5)):
    row,br=items[ri],items[bi];rm=row['options'][0]['mode'];dx=model.get_int_var_from_proto_index(br['x'])-model.get_int_var_from_proto_index(row['x']);dy=model.get_int_var_from_proto_index(br['y'])-model.get_int_var_from_proto_index(row['y']);options=[]
    for o in br['options']:
        mi=o['mode'];cells=load(BASE/'row-bracket'/f'{rm:02d}-{mi:02d}.json')['cells'];selectors=[];planes=[]
        for k,cell in enumerate(cells):
            s=model.new_bool_var(f'row_bracket_{ri}_{bi}_{mi}_{k}');selectors.append(s.index);indices=[]
            for aa,bb,cc in cell['halfplanes']:
                ct=model.add(aa*dx+bb*dy>=cc);ct.only_enforce_if(s);indices.append(ct.index)
            planes.append(indices)
        choice=model.add(sum(model.get_int_var_from_proto_index(i) for i in selectors)==model.get_int_var_from_proto_index(o['selector']));options.append({'mode':mi,'mode_selector':o['selector'],'cells':selectors,'plane_constraints':planes,'choice':choice.index})
    pairgroups.append({'row':ri,'bracket':bi,'row_mode':rm,'options':options})
mapping={'items':items,'orders':oldmp['orders'],'row_pairs':oldmp['row_pairs'],'collision_groups':groups,'row_bracket_pairs':pairgroups,'base_variable_count':len(old.variables),'base_constraint_count':len(old.constraints),'replaced_base_constraints':replaced}
def assignment(poses):
    known={p['block']:p for p in poses};values=[0]*len(model.proto.variables)
    for item in items:
        p=known.get(item['index'])
        if p is None:continue
        values[item['presence']]=1;values[item['x']],values[item['y']]=p['anchor_um']
        for o in item['options']:values[o['selector']]=int(o['mode']==p['mode'])
    for pair in mapping['row_pairs']:
        left,right=known.get(pair['left']),known.get(pair['right'])
        if left is None or right is None:continue
        delta=[right['anchor_um'][j]-left['anchor_um'][j] for j in [0,1]];cells=load(BASE/'relative'/f"{pair['region']}.json")['cells'];sel=next((k for k,c in enumerate(cells) if all(a*delta[0]+b*delta[1]>=v for a,b,v in c['halfplanes'])),None)
        for k,s in enumerate(pair['selectors']):values[s]=int(sel==k)
    for pair in pairgroups:
        row,br=known.get(pair['row']),known.get(pair['bracket'])
        if row is None or br is None:continue
        delta=[br['anchor_um'][j]-row['anchor_um'][j] for j in [0,1]]
        for o in pair['options']:
            if br['mode']!=o['mode']:continue
            cells=load(BASE/'row-bracket'/f"{pair['row_mode']:02d}-{o['mode']:02d}.json")['cells'];sel=next((k for k,c in enumerate(cells) if all(a*delta[0]+b*delta[1]>=v for a,b,v in c['halfplanes'])),None)
            for k,s in enumerate(o['cells']):values[s]=int(sel==k)
    return values
control=load(BASE/'control.json');known={p['block'] for p in control};sol=assignment(control);bad=assignment(load(BASE/'negative.json'));hints={}
for item in items:
    hints[item['presence']]=1
    if item['index'] in known:
        for k in ['x','y']:hints[item[k]]=sol[item[k]]
        for o in item['options']:hints[o['selector']]=sol[o['selector']]
for p in mapping['row_pairs']:
    if p['left'] in known and p['right'] in known:
        for s in p['selectors']:hints[s]=sol[s]
for p in pairgroups:
    if p['row'] in known and p['bracket'] in known:
        for o in p['options']:
            for s in o['cells']:hints[s]=sol[s]
for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
mapping['control_disabled_mandatory_constraints']=[p['mandatory'] for p in items if p['index'] not in known]
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mapping);write(OUT/'partial-control-assignment.json',sol);write(OUT/'negative-assignment.json',bad);write(OUT/'partial-hints.json',{str(k):v for k,v in hints.items()})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','control.json','negative.json','geometry-audit/plan.json','geometry-audit/checks.json']]+list((BASE/'row-bracket').glob('*.json'))+list((BASE/'relative').glob('*.json'))+[OLD/'model/model.pb',OLD/'model/mapping.json',OLD/'model-audit/plan.json',OLD/'model-audit/checks.json'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0});write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_blocks':43,'target_originals':66,'independently_movable_first_sheet_originals':54,'fixed_short_originals':12,'row_bracket_owner_pairs':15,'row_bracket_mode_cases':120,'row_bracket_cell_selectors':sum(len(o['cells']) for p in pairgroups for o in p['options']),'partial_control_originals':52,'partial_hints':len(hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
