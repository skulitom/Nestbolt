"""Verify the entire model chain and all primary, negative and eight source witnesses."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_transfer43_cp_reader_20261028 import inspect as inspect_original
from h5_hybrid43_cp_reader_20261028 import inspect as inspect_previous
from h5_row_bracket_cp_reader_20261028 import inspect,control_values,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-source-20261028';OLD=ROOT/'output/h5-hybrid43-guarded-source-20261028';ORIGINAL=ROOT/'output/h5-transfer43-source-20261028';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(path):
    p=cp_model_pb2.CpModelProto();p.ParseFromString(path.read_bytes());return p
OUT.mkdir();(OUT/'witnesses').mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,BASE/'geometry-audit',MODEL,OLD/'model-audit',ORIGINAL/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
original=proto(ORIGINAL/'model/model.pb');omp=load(ORIGINAL/'model/mapping.json');original_check,_=inspect_original(original,omp,load(ORIGINAL/'blocks43.json'),load(ORIGINAL/'modes.json'),load(ORIGINAL/'control.json'),load(ORIGINAL/'negative.json'),load(ORIGINAL/'model/partial-hints.json'),load(ORIGINAL/'model/partial-control-assignment.json'),load(ORIGINAL/'model/negative-assignment.json'));write(OUT/'original-model-recheck.json',original_check)
old=proto(OLD/'model/model.pb');oldmp=load(OLD/'model/mapping.json');relative={k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']};previous_check,_=inspect_previous(old,oldmp,original,omp,load(OLD/'modes.json'),relative,load(OLD/'control.json'),load(OLD/'negative.json'),load(OLD/'model/partial-hints.json'),load(OLD/'model/partial-control-assignment.json'),load(OLD/'model/negative-assignment.json'));write(OUT/'previous-model-recheck.json',previous_check)
p=proto(MODEL/'model.pb');mp=load(MODEL/'mapping.json');sol=load(MODEL/'partial-control-assignment.json');bad=load(MODEL/'negative-assignment.json');built=load(MODEL/'built.json');assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256'];typed={(ri,mi):load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json') for ri,mi in product([12,13],range(2,10))};checked,disabled=inspect(p,mp,old,oldmp,load(BASE/'modes.json'),relative,typed,load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),sol,bad)
failure=violations(p,sol);assert failure['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in disabled] and failure['cover_collisions']==0;write(OUT/'partial-target-rejections.json',failure)
def partial_check(values,absent):
    copy=cp_model_pb2.CpModelProto();copy.CopyFrom(p)
    for ix in absent:copy.constraints[ix].linear.domain[:]=[0,0]
    valid=evaluate(copy,values,0);assert not violations(copy,values)['failed_constraints']
    for ix in absent:copy.constraints[ix].linear.domain[:]=[1,1]
    assert copy.SerializeToString()==p.SerializeToString();return valid
valid=partial_check(sol,disabled);assert valid['expanded_pairs']==102184;write(OUT/'partial-control-check.json',valid)
negative=violations(p,bad);badmodes={r['block']:r['mode'] for r in load(BASE/'negative.json')};expected={ix for g in mp['collision_groups'] for ix in g['constraints']}|{g['choice'] for g in mp['row_pairs']}|{o['choice'] for g in mp['row_bracket_pairs'] for o in g['options'] if o['mode']==badmodes[g['bracket']]};assert len(expected)==30 and {r['constraint'] for r in negative['failed_constraints']}==expected and negative['cover_collisions']>0;write(OUT/'negative-target-rejections.json',negative)
witness_records=[]
for w in load(STUDY/'witness-summary.json'):
    mi=w['mode'];poses=load(OLD/'control.json')+[w['pose']];known={r['block'] for r in poses};values=control_values(p,mp,relative,typed,poses);absent=[r['mandatory'] for r in mp['items'] if r['index'] not in known];fail=violations(p,values);assert len(absent)==4 and fail['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in absent] and fail['cover_collisions']==0;verified=partial_check(values,absent);assert verified['expanded_pairs']==112002;oldfail=violations(old,values[:len(old.variables)]);oldfailed={r['constraint'] for r in oldfail['failed_constraints']};oldcover={ix for g in oldmp['collision_groups'] for ix in g['constraints']};assert set(absent)<oldfailed and oldfailed<=set(absent)|oldcover and oldfail['cover_collisions']==w['cover_collision_count'];write(OUT/'witnesses'/f'{mi:02d}-assignment.json',values);write(OUT/'witnesses'/f'{mi:02d}-old-rejections.json',oldfail);witness_records.append({'mode':mi,'source_originals':62,'new_target_rejects_only4_missing_brackets':True,'new_partial_model_cover_pairs':verified['expanded_pairs'],'old_false_cover_collisions':oldfail['cover_collisions']})
write(OUT/'witness-checks.json',witness_records);inputs=[BASE/'plan.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',MODEL/'plan.json',MODEL/'model.pb',MODEL/'mapping.json',MODEL/'partial-hints.json',MODEL/'partial-control-assignment.json',MODEL/'negative-assignment.json',OLD/'model/model.pb',OLD/'model/mapping.json',ORIGINAL/'model/model.pb',ORIGINAL/'model/mapping.json',STUDY/'audit/plan.json',STUDY/'audit/checks.json',STUDY/'witness-summary.json',ROOT/'output/h5_row_bracket_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-start,'primary_control_originals':52,'primary_rejected_by_exactly14_mandatory_constraints':True,'primary_cover_pair_visits':valid['expanded_pairs'],'source62_controls_verified':len(witness_records),'all8_old_false_rejections_removed':True,'negative66_rejected_by30_collision_constraints':True,'negative_cover_collision_visits':negative['cover_collisions'],'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
