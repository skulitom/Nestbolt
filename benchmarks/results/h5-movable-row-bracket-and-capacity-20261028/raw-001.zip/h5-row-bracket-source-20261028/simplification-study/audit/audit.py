"""Recheck both declared simplifications and preserve every failed eligibility condition."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,shutil,time
from shapely.geometry import shape,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-source-20261028';DATA=BASE/'simplification-study';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';OUT=DATA/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(DATA/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
result=load(DATA/'result.json');modes=load(BASE/'modes.json');controls=load(BASE/'control-region-checks.json');counts={'types':0,'cells':0,'planes':0};records=[]
for variant in plan['variants']:
    folder=DATA/variant;summary=load(folder/'summary.json');cc=load(folder/'controls.json');saved=load(folder/'result.json');losses=[];control_checks=[]
    for ri,mi in product([12,13],range(2,10)):
        original_data=load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json');original=shape(original_data['forbidden_geometry']);intrinsic=shape(load(STUDY/'obstacles'/f'{mi:02d}-cog-phase7.json'));pieces=[translate(intrinsic,j*258.9,0) for j in range(modes[ri]['row_size'])];expected=original.convex_hull if variant=='full-hull' else unary_union([pieces[0],pieces[-1],unary_union(pieces[1:-1]).convex_hull]);d=load(folder/f'{ri:02d}-{mi:02d}.json');g=shape(d['forbidden_geometry']);assert g.equals(expected) and d['relative_bounds_um']==original_data['relative_bounds_um'];contains=g.covers(original);assert contains==d['contains_precise_obstacle'];domain=shape(d['domain_geometry']);assert domain.equals(box(*(v/1000 for v in d['relative_bounds_um'])).difference(g));polys=[]
        if not contains:
            outside=original.difference(g);record={'row_mode':ri,'bracket_mode':mi,'outside_geometry_type':outside.geom_type,'outside_area_mm2':outside.area};losses.append(record);write(OUT/f'{variant}-{ri:02d}-{mi:02d}-outside.json',mapping(outside))
        for cell in d['cells']:
            p=shape(cell['geometry']);assert p.is_valid and not p.interiors and p.equals(p.convex_hull);polys.append(p);vv=[tuple(F(str(x)) for x in pt) for pt in list(p.exterior.coords)[:-1]];assert len(vv)==len(cell['halfplanes']) and sum(u[0]*v[1]-u[1]*v[0] for u,v in zip(vv,vv[1:]+vv[:1]))>0
            for (u,v),(aa,bb,ccv) in zip(zip(vv,vv[1:]+vv[:1]),cell['halfplanes']):
                nx,ny=u[1]-v[1],v[0]-u[0];norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm;assert all(nx*(w[0]-u[0])+ny*(w[1]-u[1])>=0 for w in vv);assert aa==round(nx*10**9) and bb==round(ny*10**9);target=10**12*(nx*u[0]+ny*u[1]);error=abs(aa-10**9*nx)*1600000+abs(bb-10**9*ny)*3100000;assert F(ccv)>target+error and F(ccv-1)<=target+error+1;counts['planes']+=1
            counts['cells']+=1
        assert unary_union(polys).equals(domain);counts['types']+=1;row=next(r for r in summary if (r['row_mode'],r['bracket_mode'])==(ri,mi));assert row['contains_precise_obstacle']==contains and row['cells']==len(polys) and row['planes']==sum(len(c['halfplanes']) for c in d['cells']) and row['additional_forbidden_area_mm2']==g.area-original.area;zero=not any(all(v<=0 for a,b,v in c['halfplanes']) for c in d['cells']);assert zero==row['zero_rejected']
        for c in [c for c in controls if (c['row_mode'],c['bracket_mode'])==(ri,mi)]:
            x,y=c['delta_um'];selected=next((i for i,cell in enumerate(d['cells']) if all(a*x+b*y>=v for a,b,v in cell['halfplanes'])),None);control_checks.append({**c,'selected_cell':selected,'accepted':selected is not None})
    assert control_checks==cc;cells=sum(r['cells']*(10 if r['row_mode']==12 else 5) for r in summary);planes=sum(r['planes']*(10 if r['row_mode']==12 else 5) for r in summary);eligible=not losses and len(cc)==33 and all(c['accepted'] for c in cc) and all(r['zero_rejected'] for r in summary) and planes*4<=result['baseline_expanded_planes']*3;assert eligible==saved['eligible'] and cells==saved['expanded_cell_selectors'] and planes==saved['expanded_plane_constraints'];records.append({'variant':variant,'eligible':eligible,'positive_controls_accepted':sum(c['accepted'] for c in cc),'positive_control_failures':[c for c in cc if not c['accepted']],'containment_failures':losses,'expanded_planes':planes,'expanded_selectors':cells})
eligible=[r for r in records if r['eligible']];selected=min(eligible,key=lambda r:(r['expanded_planes'],r['expanded_selectors'],plan['variants'].index(r['variant'])))['variant'] if eligible else None;assert selected==result['selected'] is None;write(OUT/'variant-checks.json',records);inputs=[DATA/'plan.json',DATA/'result.json']+[p for name in plan['variants'] for p in (DATA/name).glob('*.json')];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,**counts,'variants_independently_verified':2,'selected':None,'full_hull_rejects_positive_controls':2,'middle_hull_containment_failures':len(records[1]['containment_failures']),'middle_hull_outside_area_mm2':sum(r['outside_area_mm2'] for r in records[1]['containment_failures']),'both_variants_ineligible_under_frozen_policy':True,'source_thresholds_not_relaxed':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'));print(records)
