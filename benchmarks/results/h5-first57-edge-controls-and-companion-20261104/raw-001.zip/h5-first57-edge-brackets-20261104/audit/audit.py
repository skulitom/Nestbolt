"""Independent endpoint-event replay and original-source readback of both controls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-brackets-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for folder in [BASE,MOV/'audit',OBS/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(MOV/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
sites=load(PRE/'source-cog-sites.json');low=min(r['transform']['translation'][1] for r in sites)
bottom=[i for i,r in enumerate(sites) if r['transform']['translation'][1]==low]
empty=max(bottom,key=lambda i:sites[i]['transform']['translation'][0]);assert empty==4 and len(bottom)==5
boxes=load(OBS/'disjoint-mask-boxes.json');modes=load(MOV/'family-modes.json')['bracket'];rects=load(MOV/'mode-rectangles.json')['bracket']
actual=load(BASE/'edge-mode-domains.json');assert len(actual)==16;expected=[];projection_count=0
for side in ['left','right']:
    for mode in modes:
        x=mode['integer_lower_left_bounds'][0][0 if side=='left' else 1];lo,hi=mode['integer_lower_left_bounds'][1]
        events=Counter({lo:0,hi+1:0});n=0
        for piece in rects[mode['mode']]['rectangles']:
            a,b,c,d=piece['outward_offsets_grid']
            for mask,u,v,w,z,*_ in boxes:
                if not mask&~(1<<empty) or x+a>=w or x+c+23<=u:continue
                n+=1;first=max(lo,v-d-23+1);last=min(hi,z-b-1)
                if first<=last:events[first]+=1;events[last+1]-=1
        cuts=sorted(events);count=0;free=[]
        for a,b in zip(cuts,cuts[1:]):
            count+=events[a];assert count>=0
            if count==0:
                if free and free[-1][1]+1==a:free[-1][1]=b-1
                else:free.append([a,b-1])
        count+=events[cuts[-1]];assert count==0
        expected.append({'side':side,'mode':mode['mode'],'x_grid':x,'y_domain_grid':[lo,hi],'free_y_intervals_grid':free,
                         'lowest_y_grid':free[0][0] if free else None,'projected_forbidden_intervals':n})
        projection_count+=n
assert actual==expected
selected=load(BASE/'selected-brackets.json');assert len(selected)==2
for record,side,identity in zip(selected,['left','right'],[['bracket',0],['bracket',1]]):
    best=min((r for r in expected if r['side']==side and r['lowest_y_grid'] is not None),key=lambda r:(r['lowest_y_grid'],r['mode']))
    assert record['side']==side and record['identity']==identity and record['mode']==best['mode'] and record['lower_left_grid']==[best['x_grid'],best['lowest_y_grid']]
    mode=modes[record['mode']];xy=[v/100 for v in record['lower_left_grid']]
    source={'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in range(2)]}}
    assert record['source']==source
source=load(PRE/'fixed29.json')+[r for i,r in enumerate(sites) if i!=empty]+[r['source'] for r in selected]
assert source==load(BASE/'source45.json') and len(source)==45
spec=load(PRE/'plan.json');check=audit(load(JOB),source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in source])
assert check==load(BASE/'source-checks.json') and check['valid']
assert check['same_sheet_pairs']==990 and check['stock_edges']==180 and check['cutouts']==49 and check['hole_vertices']==4946
selection=load(BASE/'selection.json');assert selection['lowest_row_sites']==bottom and selection['omitted_site']==empty
assert selection['remaining_candidate_sites']==[i for i in range(15) if i!=empty] and selection['additional_empty_sites_required']==2 and selection['remaining_cog_choices']==91
assert selection['fixed31_source_rows']==load(PRE/'fixed29.json')+[r['source'] for r in selected]
inventory=load(PRE/'inventory.json');remaining=[i for i in inventory['moving16_orthogonal_identities'] if i not in [['bracket',0],['bracket',1]]]
assert selection['remaining_moving14_identities']==remaining and len(remaining)==14
first=[(r['part_id'],r['copy_index']) for r in selection['fixed31_source_rows']]+list(map(tuple,remaining))+list(map(tuple,inventory['required_cog12_identities']))
assert len(first)==len(set(first))==57 and set(first)==set(map(tuple,inventory['first57_identities']))
assert set(first).isdisjoint(map(tuple,inventory['short9_identities'])) and set(first)|set(map(tuple,inventory['short9_identities']))==set(map(tuple,inventory['full66_identities']))
assert selected[1]['lower_left_grid'][1]/100<spec['construction_stock'][1]
write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','edge-mode-domains.json','selected-brackets.json','source45.json','source-checks.json','selection.json']]+[PRE/n for n in ['plan.json','fixed29.json','source-cog-sites.json','inventory.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]+[OBS/n for n in ['audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'The selected omitted cog is the geometric rightmost site in the lowest source row. The event replay independently recovers all allowed integer Y intervals at both full-stock X edges for every bracket mode, against every active audited obstacle box and both source-covering bracket components. The selected anchors are the deterministic lowest controls. Saved transforms are reconstructed from original modes and read back against the original job. All45 control identities, holes,990 pairs and180 stock edges pass. Any12-of14 remaining cog subset preserves these pair/stock checks, while full57 and short9 inventory identities remain disjoint and exhaustive. The45-reference control itself is not a full66 layout and does not include the short sheet. No choice or allocation is excluded.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'edge_mode_domains_verified':16,'projected_obstacle_intervals_verified':projection_count,
    'source_valid45':True,'same_sheet_pairs':990,'stock_edges':180,'cutouts':49,'hole_vertices':4946,'omitted_site':4,
    'fixed_originals':31,'remaining_moving_originals':14,'candidate_twelve_cog_subsets':91,'full66_identity_partition_preserved':True,
    'right_bracket_uses_previously_excluded_lower_stock':True,'site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
