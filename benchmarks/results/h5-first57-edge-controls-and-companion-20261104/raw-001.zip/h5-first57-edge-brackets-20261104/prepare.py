"""Direct edge-anchored bracket controls after omitting one geometric cog site."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-edge-brackets-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def free_intervals(lo,hi,blocked):
    merged=[]
    for a,b in sorted(blocked):
        a,b=max(lo,a),min(hi,b)
        if a>b:continue
        if merged and a<=merged[-1][1]+1:merged[-1][1]=max(merged[-1][1],b)
        else:merged.append([a,b])
    free=[];cursor=lo
    for a,b in merged:
        if cursor<a:free.append([cursor,a-1])
        cursor=b+1
    if cursor<=hi:free.append([cursor,hi])
    return free
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','fixed29.json','source-cog-sites.json','inventory.json','audit/plan.json','audit/checks.json']]+[MOV/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]+[OBS/n for n in ['plan.json','audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New direct full-stock positive control. Select the rightmost cog in the lowest source-cog row solely from its source transform, omit that site and retain all14 others. For each of8 legal bracket modes and each physical left/right anchor edge, project every active audited fixed obstacle against both expanded moving component rectangles onto the integer Y axis. Compute all allowed integer intervals, then choose the lowest Y (mode index breaks ties) separately on each stock edge. Validate the two selected original bracket contours together with fixed29 and all14 reference cogs. This does not read capacity tables or earlier optimized positions. If valid, any12-of14 cog subset preserves the control and exactly14 orthogonal movers remain for first57. No feasibility or exclusion follows from a failed control.',
    'left_bracket_identity':['bracket',0],'right_bracket_identity':['bracket',1],
    'preparation_cap_seconds':10,'maximum_process_seconds':20,'new_solver_calls':0,'native_calls':0,'independent_audit_required':True})
assert load(MOV/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
sites=load(PRE/'source-cog-sites.json');lowest=min(r['transform']['translation'][1] for r in sites)
row=[i for i,r in enumerate(sites) if r['transform']['translation'][1]==lowest]
empty=max(row,key=lambda i:sites[i]['transform']['translation'][0])
assert len(row)==5
boxes=load(OBS/'disjoint-mask-boxes.json')
present=[(i,b) for i,b in enumerate(boxes) if b[0]&~(1<<empty)]
modes=load(MOV/'family-modes.json')['bracket'];rectangles=load(MOV/'mode-rectangles.json')['bracket'];options=[]
for side in ['left','right']:
    for m in modes:
        x=m['integer_lower_left_bounds'][0][0 if side=='left' else 1];lo,hi=m['integer_lower_left_bounds'][1];blocked=[]
        for piece in rectangles[m['mode']]['rectangles']:
            a,b,c,d=piece['outward_offsets_grid']
            for oi,ob in present:
                _,u,v,w,z=ob[:5]
                if x+a<w and x+c+23>u:
                    blocked.append((v-d-23+1,z-b-1))
        free=free_intervals(lo,hi,blocked)
        options.append({'side':side,'mode':m['mode'],'x_grid':x,'y_domain_grid':[lo,hi],'free_y_intervals_grid':free,
                        'lowest_y_grid':free[0][0] if free else None,'projected_forbidden_intervals':len(blocked)})
        assert time.perf_counter()-started<10
write(OUT/'edge-mode-domains.json',options)
selected=[]
for side,identity in [('left',['bracket',0]),('right',['bracket',1])]:
    choices=[r for r in options if r['side']==side and r['lowest_y_grid'] is not None]
    assert choices,'No positive edge control; no negative claim.'
    r=min(choices,key=lambda r:(r['lowest_y_grid'],r['mode']));m=modes[r['mode']];xy=[r['x_grid']/100,r['lowest_y_grid']/100]
    selected.append({'side':side,'identity':identity,'mode':r['mode'],'lower_left_grid':[r['x_grid'],r['lowest_y_grid']],
        'source':{'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0',
                  'transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],
                               'translation':[xy[k]+m['translation_from_lower_left'][k] for k in range(2)]}}})
controls=load(PRE/'fixed29.json')+[r for i,r in enumerate(sites) if i!=empty]+[r['source'] for r in selected]
spec=load(PRE/'plan.json');job=load(JOB)
check=audit(job,controls,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in controls])
write(OUT/'source45.json',controls);write(OUT/'source-checks.json',check);write(OUT/'selected-brackets.json',selected)
write(OUT/'selection.json',{'lowest_row_sites':row,'omitted_site':empty,'remaining_candidate_sites':[i for i in range(15) if i!=empty],'remaining_cog_choices':91,'additional_empty_sites_required':2,
    'fixed31_source_rows':load(PRE/'fixed29.json')+[r['source'] for r in selected],
    'remaining_moving14_identities':[i for i in load(PRE/'inventory.json')['moving16_orthogonal_identities'] if i not in [['bracket',0],['bracket',1]]]})
checks={'prepared':True,'seconds':time.perf_counter()-started,'source_valid45':check['valid'],'source_control_parts':len(controls),'omitted_cog_site':empty,
    'edge_mode_domains':len(options),'selected_lower_left_mm':[[v/100 for v in r['lower_left_grid']] for r in selected],
    'selected_source_modes':[r['mode'] for r in selected],'selected_bracket_identities':[r['identity'] for r in selected],
    'same_sheet_pairs':check['same_sheet_pairs'],'stock_edges':check['stock_edges'],'cutouts':check['cutouts'],'hole_vertices':check['hole_vertices'],
    'remaining_independent_orthogonal_movers':14,'candidate_twelve_cog_subsets':91,'independent_original_source_audit_pending':True,
    'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
assert check['valid'] and len(controls)==45 and checks['seconds']<10
