"""Rebuild disjoint obstacles and the twelve-original companion geometry."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from fractions import Fraction as F
import json,time,shutil,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-edge-companion-v2-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';OLD=ROOT/'output/h5-first57-disjoint-obstacles-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104'
BR=ROOT/'output/h5-first57-edge-brackets-20261104';INS=ROOT/'output/h5-first57-edge-inserts-20261104'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def deadline():assert time.perf_counter()-started<20,'Declared preparation cap reached; no solver call is permitted.'
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),PIECES,ROOT/'output/prepare_h5_first57_edge_companion_v2_helper_20261104.py',ROOT/'output/prepare_h5_first57_edge_companion_20261104.py',ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/plan.json',ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/checks.json']+[OLD/n for n in ['plan.json','audit/plan.json','audit/checks.json','source-cover-obstacles.json']]+[MOV/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]+[BR/n for n in ['audit/plan.json','audit/checks.json','selected-brackets.json']]+[INS/n for n in ['audit/plan.json','audit/checks.json','selected-inserts.json','selection.json']]+[PRE/n for n in ['inventory.json','fixed29.json','source-cog-sites.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Positive fixed-edge companion, retaining every original identity. Remove cog sites4 and10 from the audited source-covering obstacle set. Recompute outward source-covering component boxes directly from exact rational representations of the saved binary64 world transforms for the independently valid two edge brackets and two adjoining inserts, with the same right/top0.23mm expansion. This version repairs the preserved unverified first preparation: adding integer anchor coordinates to mode-relative rounded boxes did not always cover saved binary64 world vertices at grid boundaries. Rebuild exact disjoint source-mask boxes. Keep all12 legal full-stock source modes for six remaining brackets and six inserts; derive18 rigid components and8 moving-pair cover groups from scratch. Only group0 and a ninth group for its six complementary bracket pieces need fixed obstacles. Exactly one additional candidate cog site may be empty. This is a13-choice constructive restriction, not a reduction of the259 necessary frontier. Original fixed33/cog13 source checks and full66 identity inventory remain mandatory.',
    'coordinate_units_per_mm':100,'world_origin_mm':[0,0],'mandatory_empty_sites':[4,10],'additional_empty_sites':1,
    'preparation_cap_seconds':20,'maximum_process_seconds':30,'maximum_mask_cells':40000000,'solver_calls':0,'independent_geometry_audit_required':True})
for directory in [OLD,MOV,BR,INS]:assert load(directory/'audit/checks.json')['passed']
selection=load(INS/'selection.json');assert selection['omitted_sites']==[4,10]
rectangles=load(MOV/'mode-rectangles.json');obstacles=[r for r in load(OLD/'source-cover-obstacles.json') if r['site_bit'] not in [4,10]]
additions=[];canonical=load(PIECES)
for r in load(BR/'selected-brackets.json')+load(INS/'selected-inserts.json'):
    family=r['identity'][0];t=r['source']['transform'];co,si=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']))
    mirror=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    for piece,vertices in enumerate(canonical[family]):
        world=[(mirror*F(x)*co-F(y)*si+tx,mirror*F(x)*si+F(y)*co+ty) for x,y in vertices]
        box=[math.floor(min(x for x,y in world)*100),math.floor(min(y for x,y in world)*100),math.ceil(max(x for x,y in world)*100)+23,math.ceil(max(y for x,y in world)*100)+23]
        addition={'site_bit':15,'added_fixed_identity':r['identity'],'source_mode':r['mode'],'piece':piece,'bounds_grid':box}
        additions.append(addition);obstacles.append(addition)
write(OUT/'added-fixed-source-covers.json',additions);write(OUT/'source-cover-obstacles.json',obstacles)
xs=np.array(sorted({v for r in obstacles for v in [r['bounds_grid'][0],r['bounds_grid'][2]]}),dtype=np.int64)
ys=np.array(sorted({v for r in obstacles for v in [r['bounds_grid'][1],r['bounds_grid'][3]]}),dtype=np.int64)
assert (len(xs)-1)*(len(ys)-1)<=40000000
xi={int(x):i for i,x in enumerate(xs)};yi={int(y):i for i,y in enumerate(ys)}
mask=np.zeros((len(ys)-1,len(xs)-1),dtype=np.uint16)
for r in obstacles:
    a,b,c,d=r['bounds_grid'];mask[yi[b]:yi[d],xi[a]:xi[c]]|=np.uint16(1<<r['site_bit'])
np.savez_compressed(OUT/'mask-classes.npz',xcuts_grid=xs,ycuts_grid=ys,mask=mask)
boxes=[];active={}
def close(key,span):
    m,xa,xb=key;ya,yb=span;boxes.append([m,int(xs[xa]),int(ys[ya]),int(xs[xb]),int(ys[yb]),xa,ya,xb,yb])
for y,row in enumerate(mask):
    starts=np.r_[0,np.flatnonzero(row[1:]!=row[:-1])+1];ends=np.r_[starts[1:],len(row)];current={}
    for xa,xb in zip(starts.tolist(),ends.tolist()):
        m=int(row[xa])
        if not m:continue
        key=(m,xa,xb);current[key]=[active[key][0] if key in active else y,y+1]
    for key,span in active.items():
        if key not in current:close(key,span)
    active=current
    if y%128==0:deadline()
for key,span in active.items():close(key,span)
boxes.sort();write(OUT/'disjoint-mask-boxes.json',boxes)
for name in ['family-modes.json','mode-rectangles.json']:shutil.copyfile(MOV/name,OUT/name)
shutil.copyfile(PRE/'inventory.json',OUT/'inventory.json');write(OUT/'fixed33.json',selection['fixed33_source_rows']);write(OUT/'selection.json',selection)
modes=load(OUT/'family-modes.json');identities=selection['remaining_moving12_identities']
instances=[{'identity':i,'mode_count':len(modes[i[0]])} for i in identities];components=[]
for owner,identity in enumerate(identities):
    for piece in range(2 if identity[0]=='bracket' else 1):components.append({'component':len(components),'owner':owner,'identity':identity,'piece':piece})
labels={o:i+1 for i,o in enumerate(o for o,v in enumerate(identities) if v[0]=='bracket')}
groups=[]
for code in range(8):
    members=[c['component'] for c in components if c['identity'][0]=='insert' or c['piece']==((code&labels[c['owner']]).bit_count()%2)]
    assert len(members)==len(identities)==12 and len({components[i]['owner'] for i in members})==12
    groups.append({'group':code,'components':members})
certificates=[]
for a,b in combinations(components,2):
    if a['owner']==b['owner']:continue
    witnesses=[g['group'] for g in groups if a['component'] in g['components'] and b['component'] in g['components']]
    assert len(witnesses)>=2
    certificates.append({'components':[a['component'],b['component']],'groups':witnesses})
remaining=sorted(set(range(len(components)))-set(groups[0]['components']))
factorized=[{**g,'includes_fixed_obstacles':g['group']==0} for g in groups]+[{'group':8,'components':remaining,'includes_fixed_obstacles':True}]
assert len(remaining)==6
for name,data in [('instances.json',instances),('components.json',components),('pair-cover-groups.json',groups),('pair-cover-certificates.json',certificates),('factorized-groups.json',factorized)]:write(OUT/name,data)
checks={'prepared':True,'seconds':time.perf_counter()-started,'fixed_originals':33,'saved_world_transforms_rounded_outward':True,'prior_unverified_preparation_preserved':True,'added_source_component_covers':len(additions),'world_source_cover_rectangles':len(obstacles),
    'mask_cells':int(mask.size),'disjoint_obstacle_boxes':len(boxes),'unique_masks':len({r[0] for r in boxes}),
    'remaining_moving_originals':len(identities),'legal_mode_selectors':sum(r['mode_count'] for r in instances),'rigid_components':len(components),
    'moving_pair_groups':len(groups),'different_owner_component_pairs':len(certificates),'factorized_groups':len(factorized),'fixed_obstacle_groups':2,
    'rectangle_references':2*len(boxes)+8*12+6,'candidate_twelve_cog_subsets':13,'independent_geometry_audit_pending':True,
    'site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
deadline();write(OUT/'checks.json',checks);print(checks)
