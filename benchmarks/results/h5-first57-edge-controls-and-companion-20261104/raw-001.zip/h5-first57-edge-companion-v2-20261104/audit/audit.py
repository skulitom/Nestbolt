"""Exact added-world-source coverage, mask partition and twelve-part interaction audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-companion-v2-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';OLD=ROOT/'output/h5-first57-disjoint-obstacles-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104'
BR=ROOT/'output/h5-first57-edge-brackets-20261104';INS=ROOT/'output/h5-first57-edge-inserts-20261104'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for directory in [BASE,OLD/'audit',MOV/'audit',BR/'audit',INS/'audit']:
    for n,h in load(directory/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for directory in [OLD,MOV,BR,INS]:assert load(directory/'audit/checks.json')['passed']
selection=load(INS/'selection.json');assert load(BASE/'selection.json')==selection and selection['omitted_sites']==[4,10]
canonical=load(PIECES);selected=load(BR/'selected-brackets.json')+load(INS/'selected-inserts.json')
additions=load(BASE/'added-fixed-source-covers.json');index=0;vertices_checked=0
for record in selected:
    t=record['source']['transform'];c=F(math.cos(t['rotation_radians']));s=F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    for pi,piece in enumerate(canonical[record['identity'][0]]):
        world=[(m*F(v[0])*c-F(v[1])*s+tx,m*F(v[0])*s+F(v[1])*c+ty) for v in piece]
        bounds=[math.floor(min(v[0] for v in world)*100),math.floor(min(v[1] for v in world)*100),math.ceil(max(v[0] for v in world)*100)+23,math.ceil(max(v[1] for v in world)*100)+23]
        expected={'site_bit':15,'added_fixed_identity':record['identity'],'source_mode':record['mode'],'piece':pi,'bounds_grid':bounds}
        assert additions[index]==expected
        assert all(F(bounds[0],100)<=x<=F(bounds[2]-23,100) and F(bounds[1],100)<=y<=F(bounds[3]-23,100) for x,y in world)
        vertices_checked+=len(world);index+=1
assert index==len(additions)==6
expected=[r for r in load(OLD/'source-cover-obstacles.json') if r['site_bit'] not in [4,10]]+additions
assert load(BASE/'source-cover-obstacles.json')==expected and len(expected)==5690
xs=sorted({v for r in expected for v in [r['bounds_grid'][0],r['bounds_grid'][2]]});ys=sorted({v for r in expected for v in [r['bounds_grid'][1],r['bounds_grid'][3]]})
xi={x:i for i,x in enumerate(xs)};yi={y:i for i,y in enumerate(ys)}
with np.load(BASE/'mask-classes.npz',allow_pickle=False) as data:
    assert set(data.files)=={'xcuts_grid','ycuts_grid','mask'} and data['xcuts_grid'].dtype==data['ycuts_grid'].dtype==np.dtype('int64')
    assert data['xcuts_grid'].tolist()==xs and data['ycuts_grid'].tolist()==ys
    mask=data['mask'];assert mask.dtype==np.dtype('uint16') and mask.shape==(len(ys)-1,len(xs)-1)
replay=np.zeros(mask.shape,dtype=np.uint16)
for bit in range(16):
    diff=np.zeros((len(ys),len(xs)),dtype=np.int32);events=0
    for r in expected:
        if r['site_bit']!=bit:continue
        a,b,c,d=r['bounds_grid'];xa,xb=xi[a],xi[c];ya,yb=yi[b],yi[d];assert xa<xb and ya<yb
        diff[ya,xa]+=1;diff[ya,xb]-=1;diff[yb,xa]-=1;diff[yb,xb]+=1;events+=1
    counts=np.cumsum(np.cumsum(diff,axis=0,dtype=np.int32),axis=1,dtype=np.int32)
    assert counts.min()>=0 and counts.max()<=events
    replay[counts[:-1,:-1]>0]|=np.uint16(1<<bit)
assert np.array_equal(replay,mask) and not np.any(mask&((1<<4)|(1<<10)))
boxes=load(BASE/'disjoint-mask-boxes.json');covered=np.zeros(mask.shape,dtype=np.uint8)
for row in boxes:
    assert len(row)==9 and all(type(v) is int for v in row)
    m,a,b,c,d,xa,ya,xb,yb=row
    assert 0<m<65536 and 0<=xa<xb<len(xs) and 0<=ya<yb<len(ys)
    assert [a,b,c,d]==[xs[xa],ys[ya],xs[xb],ys[yb]] and np.all(mask[ya:yb,xa:xb]==m)
    covered[ya:yb,xa:xb]+=1
assert np.array_equal(covered,(mask>0).astype(np.uint8))
for name in ['family-modes.json','mode-rectangles.json']:assert (BASE/name).read_bytes()==(MOV/name).read_bytes()
assert (BASE/'inventory.json').read_bytes()==(PRE/'inventory.json').read_bytes()
fixed=load(BASE/'fixed33.json');assert fixed==selection['fixed33_source_rows'] and len(fixed)==33
identities=selection['remaining_moving12_identities'];modes=load(BASE/'family-modes.json')
instances=load(BASE/'instances.json');assert instances==[{'identity':i,'mode_count':len(modes[i[0]])} for i in identities]
assert len(identities)==12 and len(set(map(tuple,identities)))==12 and sum(i[0]=='bracket' for i in identities)==6
components=load(BASE/'components.json');wanted=[]
for owner,identity in enumerate(identities):
    for piece in range(len(canonical[identity[0]])):wanted.append({'component':len(wanted),'owner':owner,'identity':identity,'piece':piece})
assert components==wanted and len(components)==18
groups=load(BASE/'pair-cover-groups.json');factorized=load(BASE/'factorized-groups.json');certs=load(BASE/'pair-cover-certificates.json')
assert len(groups)==8 and [g['group'] for g in groups]==list(range(8))
for g in groups:
    assert len(g['components'])==12 and {components[i]['owner'] for i in g['components']}==set(range(12))
pairset={tuple(sorted((a['component'],b['component']))) for a,b in combinations(components,2) if a['owner']!=b['owner']}
verified=[]
for a,b in sorted(pairset):
    witnesses=[g['group'] for g in groups if a in g['components'] and b in g['components']]
    assert len(witnesses)>=2;verified.append({'components':[a,b],'groups':witnesses})
assert certs==verified and len(pairset)==147
assert len(factorized)==9 and [g['group'] for g in factorized]==list(range(9))
assert [{k:v for k,v in g.items() if k!='includes_fixed_obstacles'} for g in factorized[:8]]==groups
assert [g['group'] for g in factorized if g['includes_fixed_obstacles']]==[0,8]
assert sorted(i for g in factorized if g['includes_fixed_obstacles'] for i in g['components'])==list(range(18))
all_pairs=set()
for g in factorized:
    assert len({components[i]['owner'] for i in g['components']})==len(g['components'])
    all_pairs.update(tuple(sorted(p)) for p in combinations(g['components'],2))
assert all_pairs==pairset
inventory=load(BASE/'inventory.json');first=[(r['part_id'],r['copy_index']) for r in fixed]+list(map(tuple,identities))+list(map(tuple,inventory['required_cog12_identities']))
assert len(first)==len(set(first))==57 and set(first)==set(map(tuple,inventory['first57_identities']))
assert set(first).isdisjoint(map(tuple,inventory['short9_identities'])) and set(first)|set(map(tuple,inventory['short9_identities']))==set(map(tuple,inventory['full66_identities']))
failure=load(ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/checks.json')
assert not failure['passed'] and failure['components_with_uncovered_vertices']==6 and failure['uncovered_vertices']==9 and not failure['new_model_permitted']
inputs=[Path(__file__),PIECES]+[BASE/n for n in ['plan.json','checks.json','source-cover-obstacles.json','added-fixed-source-covers.json','mask-classes.npz','disjoint-mask-boxes.json','family-modes.json','mode-rectangles.json','inventory.json','fixed33.json','selection.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','factorized-groups.json']]+[d/n for d in [OLD,MOV,BR,INS] for n in ['audit/plan.json','audit/checks.json']]+[BR/'selected-brackets.json',INS/'selected-inserts.json',INS/'selection.json',ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'The exact audited old source cover is restricted to all13 candidate cog sites and fixed29. Six added component rectangles contain every exact original-source vertex after its actual saved binary64 world transform, before the0.23mm right/top expansion. Source convex partition certificates extend vertex containment to the entire fixed source. Independent per-bit event counts reproduce every cell, and every active cell is covered exactly once, certifying disjoint fixed obstacle boxes and all source boundaries. Full-stock mover geometry is byte-identical to its audited source. All147 moving-component pairs remain covered, all18 moving components occur exactly once with all fixed boxes, and no same-owner pair is introduced. Fixed33/cog13 source validity and full66 inventory are inherited through verified source controls. The prior six-component grid-boundary coverage failure remains preserved and was never used in a model.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'added_fixed_source_components_verified':6,'exact_saved_world_vertices_verified':vertices_checked,
    'world_source_cover_rectangles_verified':len(expected),'mask_cells_independently_verified':int(mask.size),'site_bit_fields_replayed':16,
    'disjoint_obstacle_boxes_verified':len(boxes),'unique_masks':len({r[0] for r in boxes}),
    'all_nonzero_cells_covered_exactly_once':True,'all_source_boundaries_covered':True,'full_stock_moving_geometry_byte_identical':True,
    'fixed_originals':33,'remaining_moving_originals':12,'legal_mode_selectors':72,'rigid_components':18,
    'different_owner_component_pairs':147,'factorized_groups':9,'fixed_obstacle_groups':2,'rectangle_references':2*len(boxes)+102,
    'mandatory_empty_sites':[4,10],'candidate_twelve_cog_subsets':13,'full66_identity_partition_preserved':True,
    'prior_unverified_cover_failure_preserved':True,'new_model_prepared':False,'source_valid66':False,'site_choices_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
