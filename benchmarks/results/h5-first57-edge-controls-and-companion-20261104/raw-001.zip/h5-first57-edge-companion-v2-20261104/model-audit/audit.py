"""Independent exhaustive readback of the disjoint-obstacle full-stock model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-companion-v2-20261104';MODEL=BASE/'model';OUT=BASE/'model-audit'
OBS=BASE
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63);MAX=2**63-1
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,BASE/'audit',OBS,OBS/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes())
assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'}
mapping=load(MODEL/'mapping.json');modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json')
rectangles=load(BASE/'mode-rectangles.json');raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
obstacles=load(OBS/'disjoint-mask-boxes.json')
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,0] and mapping['rectangle_gap_grid']==23 and mapping['full_physical_stock']
assert len(mapping['owners'])==len(instances)==12
used_v=set();used_c=set()
def variable(i,name,domain):
    assert i not in used_v;used_v.add(i);v=p.variables[i]
    assert {f.name for f,x in v.ListFields()}=={'name','domain'} and v.name==name and list(v.domain)==domain
def linear(i,co,lo,hi,guard=None):
    assert i not in used_c;used_c.add(i);c=p.constraints[i]
    assert {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert list(c.enforcement_literal)==([] if guard is None else [guard])
    expected={k:v for k,v in co.items() if v}
    assert len(c.linear.vars)==len(expected) and dict(zip(c.linear.vars,c.linear.coeffs))==expected
    assert list(c.linear.domain)==[lo,hi]
def expr(actual,index,offset=0):
    assert list(actual.vars)==[index] and list(actual.coeffs)==[1] and actual.offset==offset
mode_count=0
for i,(o,instance) in enumerate(zip(mapping['owners'],instances)):
    assert o['owner']==i and o['identity']==instance['identity'] and o['positions']==[2*i,2*i+1]
    fm=modes[o['identity'][0]]
    for axis in [0,1]:
        variable(o['positions'][axis],f'owner_{i}_axis_{axis}',[min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm)])
    assert len(o['modes'])==len(fm)
    for actual,source in zip(o['modes'],fm):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source
        selector=actual['selector'];variable(selector,f'mode_{i}_{source["mode"]}',[0,1])
        assert len(actual['stock_constraints'])==2
        for axis,(lo,hi) in enumerate(source['integer_lower_left_bounds']):linear(actual['stock_constraints'][axis],{o['positions'][axis]:1},lo,hi,selector)
        mode_count+=1
    linear(o['one_mode_constraint'],{m['selector']:1 for m in o['modes']},1,1)
empty=mapping['empty_site_selectors'];assert len(empty)==15
for i,v in enumerate(empty):variable(v,f'empty_site_{i}',[0,1])
linear(mapping['exactly_three_empty_constraint'],{v:1 for v in empty},3,3)
assert [r['site'] for r in mapping['mandatory_empty_constraints']]==[4,10]
for record in mapping['mandatory_empty_constraints']:linear(record['constraint'],{empty[record['site']]:1},1,1)
expected_masks=sorted({r[0] for r in obstacles});assert [r['mask'] for r in mapping['obstacle_masks']]==expected_masks
presence_constraints=0
for record in mapping['obstacle_masks']:
    mask=record['mask'];sites=[i for i in range(15) if mask&(1<<i)];assert record['sites']==sites and record['fixed']==bool(mask&32768)
    if record['fixed']:assert record['selector'] is None and record['constraints']==[]
    else:
        selector=record['selector'];variable(selector,f'obstacle_mask_{mask}',[0,1])
        assert len(record['constraints'])==len(sites)+1
        for ct,site in zip(record['constraints'][:-1],sites):linear(ct,{selector:1,empty[site]:1},1,MAX)
        linear(record['constraints'][-1],{selector:1,**{empty[s]:1 for s in sites}},MIN,len(sites));presence_constraints+=len(sites)+1
assert len(mapping['components'])==len(raw_components)==18
links=0
for actual,raw in zip(mapping['components'],raw_components):
    for k,v in raw.items():assert actual[k]==v
    owner=mapping['owners'][raw['owner']];family=owner['identity'][0];piece=raw['piece'];coords=actual['coordinates']
    assert len(coords)==4
    for k,v in enumerate(coords):
        axis=k%2
        lo=min(m['integer_lower_left_bounds'][axis][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        hi=max(m['integer_lower_left_bounds'][axis][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        variable(v,f'component_{raw["component"]}_edge_{k}',[lo,hi])
    assert len(actual['mode_links'])==len(owner['modes'])
    for link,m in zip(actual['mode_links'],owner['modes']):
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid']
        assert link['mode']==m['mode'] and link['selector']==m['selector'] and link['offsets']==offsets and len(link['constraints'])==4
        for k,(ct,value) in enumerate(zip(link['constraints'],offsets)):linear(ct,{coords[k]:1,owner['positions'][k%2]:-1},value,value,m['selector']);links+=1
    assert len(actual['sizes'])==len(actual['size_links'])==len(actual['interval_constraints'])==2
    for axis in [0,1]:
        possible=[rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis+2]-rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis]+23 for m in owner['modes']]
        size=actual['sizes'][axis];variable(size,f'component_{raw["component"]}_size_{axis}',[min(possible),max(possible)])
        linear(actual['size_links'][axis],{size:1,coords[axis+2]:-1,coords[axis]:1},23,23)
        index=actual['interval_constraints'][axis];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
        assert {f.name for f,v in ct.ListFields()}=={'name','interval'} and ct.name==f'component_{raw["component"]}_interval_{axis}'
        expr(ct.interval.start,coords[axis]);expr(ct.interval.size,size);expr(ct.interval.end,coords[axis+2],23)
by_mask={r['mask']:r for r in mapping['obstacle_masks']}
assert len(mapping['fixed_obstacles'])==len(obstacles)==9054
for i,(record,source) in enumerate(zip(mapping['fixed_obstacles'],obstacles)):
    mask,left,bottom,right,top=source[:5];presence=by_mask[mask]['selector']
    assert record['obstacle']==i and record['mask']==mask and record['bounds_grid']==[left,bottom,right,top] and record['presence_selector']==presence
    assert len(record['interval_constraints'])==2
    for axis,(a,b) in enumerate([(left,right),(bottom,top)]):
        index=record['interval_constraints'][axis];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
        assert {f.name for f,v in ct.ListFields()}=={'name','interval'}|({'enforcement_literal'} if presence is not None else set())
        assert ct.name==f'obstacle_{i}_axis_{axis}' and list(ct.enforcement_literal)==([] if presence is None else [presence])
        for expression,expected in [(ct.interval.start,a),(ct.interval.size,b-a),(ct.interval.end,b)]:
            assert not expression.vars and not expression.coeffs and expression.offset==expected
factorization=BASE
assert load(factorization/'audit/checks.json')['passed']
for name,h in load(factorization/'audit/plan.json')['inputs'].items():assert digest(ROOT/name)==h
factorized=load(factorization/'factorized-groups.json');assert len(mapping['packing_groups'])==len(factorized)==9
rectangle_references=0
for actual,source in zip(mapping['packing_groups'],factorized):
    fixed=mapping['fixed_obstacles'] if source['includes_fixed_obstacles'] else []
    assert {k:v for k,v in actual.items() if k not in ['constraint','fixed_obstacles']}=={k:v for k,v in source.items() if k!='includes_fixed_obstacles'}
    assert actual['fixed_obstacles']==len(fixed)
    index=actual['constraint'];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
    assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'}
    assert list(ct.no_overlap_2d.x_intervals)==[o['interval_constraints'][0] for o in fixed]+[mapping['components'][i]['interval_constraints'][0] for i in source['components']]
    assert list(ct.no_overlap_2d.y_intervals)==[o['interval_constraints'][1] for o in fixed]+[mapping['components'][i]['interval_constraints'][1] for i in source['components']]
    rectangle_references+=len(fixed)+len(source['components'])
assert rectangle_references==18210
expected_symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in mapping['owners'] if o['identity'][0]==family),key=lambda o:o['identity'][1])
    expected_symmetry.extend((family,a['owner'],b['owner']) for a,b in zip(peers,peers[1:]))
assert [(s['family'],*s['owners']) for s in mapping['symmetry_constraints']]==expected_symmetry
for s in mapping['symmetry_constraints']:
    a,b=s['owners'];linear(s['constraint'],{2*a:1,2*b:-1},MIN,0)
assert used_v==set(range(len(p.variables))) and used_c==set(range(len(p.constraints)))
ledger=load(MODEL/'final-preparation-charges.json')
for name,h in ledger['inputs'].items():assert digest(ROOT/name)==h
old=load(MODEL/'preparation-charges.json');internal=old.pop('model_internal_seconds_pending_complete_process_charge')
process=load(ROOT/'output/h5-first57-edge-model-process-20261104/process.json');assert process['exit_code']==0 and not process['timeout']
old['model_complete_process_seconds']=process['complete_process_seconds']
assert ledger['charges']==old and ledger['internal_model_seconds_replaced']==internal and ledger['preparation_seconds_charged']==sum(old.values())
assert ledger['algorithm_seconds']==60 and ledger['shared_seconds']==90 and ledger['source_validation_reserve_seconds']==4 and ledger['maximum_calls']==1 and not ledger['retry_permitted']
assert len(p.variables)==250 and len(p.constraints)==18918 and mode_count==72 and links==480
inputs=[Path(__file__),ROOT/'output/prepare_h5_first57_edge_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_factorized_model_20261104.py',BASE/'fixed33.json',BASE/'selection.json',ROOT/'output/prepare_h5_first57_factorized_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_disjoint_model_20261104.py',factorization/'audit/plan.json',factorization/'audit/checks.json',factorization/'factorized-groups.json',ROOT/'output/prepare_h5_first57_disjoint_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_grouped_model_20261104.py']+[BASE/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json','instances.json','inventory.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[OBS/n for n in ['plan.json','audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json','final-preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'all_model_fields_exhaustively_verified':True,'variables_verified':len(used_v),'constraints_verified':len(used_c),
    'source_mode_selectors_verified':mode_count,'source_covering_fixed_boxes_verified':9054,'shared_mask_records_verified':36,'optional_mask_literals_verified':31,
    'mask_presence_constraints_verified':presence_constraints,'rigid_mode_coordinate_links_verified':links,'moving_intervals_verified':36,'fixed_intervals_verified':18108,
    'global_pair_cover_groups_verified':9,'fixed_obstacle_groups_verified':2,'rectangle_references_verified':18210,'full_physical_stock':True,'prior_positive_regions_consumed':False,'prior_capacity_results_consumed':False,
    'all66_inventory_geometry_audited':True,'fixed_source_originals':33,'mandatory_empty_sites':[4,10],'candidate_cog_subsets':13,'preparation_seconds_charged':ledger['preparation_seconds_charged'],
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'maximum_calls':1,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
