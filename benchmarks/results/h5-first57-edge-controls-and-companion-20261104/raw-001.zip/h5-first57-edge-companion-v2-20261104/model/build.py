"""Full-stock first57 packing against source-covering disjoint obstacle boxes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-companion-v2-20261104';OUT=BASE/'model'
OBS=BASE;PRE=ROOT/'output/h5-first57-direct-short9-20261104'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'
RID=ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'] and load(OBS/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');rectangles=load(BASE/'mode-rectangles.json')
raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json');obstacles=load(OBS/'disjoint-mask-boxes.json')
model=cp_model.CpModel()
def var(i):return model.get_int_var_from_proto_index(i)
def linear(co,lo,hi,guard=None):
    ct=model.add_linear_constraint(sum(v*var(i) for i,v in co.items() if v),lo,hi)
    if guard is not None:ct.only_enforce_if(var(guard))
    return ct.index
owners=[]
for index,instance in enumerate(instances):
    fm=modes[instance['identity'][0]];xy=[]
    for axis in [0,1]:xy.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm),f'owner_{index}_axis_{axis}').index)
    owners.append({'owner':index,'identity':instance['identity'],'positions':xy,'modes':[]})
for owner in owners:
    for m in modes[owner['identity'][0]]:
        selector=model.new_bool_var(f'mode_{owner["owner"]}_{m["mode"]}').index
        saved={**m,'selector':selector,'stock_constraints':[linear({owner['positions'][k]:1},a,b,selector) for k,(a,b) in enumerate(m['integer_lower_left_bounds'])]}
        owner['modes'].append(saved)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
empty=[model.new_bool_var(f'empty_site_{i}').index for i in range(15)]
exact_three=linear({i:1 for i in empty},3,3)
mandatory_empty=[{'site':i,'constraint':linear({empty[i]:1},1,1)} for i in [4,10]]
presence=[]
for mask in sorted({r[0] for r in obstacles}):
    sites=[i for i in range(15) if mask&(1<<i)]
    if mask&32768:
        presence.append({'mask':mask,'fixed':True,'sites':sites,'selector':None,'constraints':[]})
    else:
        p=model.new_bool_var(f'obstacle_mask_{mask}').index
        links=[linear({p:1,empty[i]:1},1,cp_model.INT_MAX) for i in sites]
        links.append(linear({p:1,**{empty[i]:1 for i in sites}},cp_model.INT_MIN,len(sites)))
        presence.append({'mask':mask,'fixed':False,'sites':sites,'selector':p,'constraints':links})
components=[];intervals_x=[];intervals_y=[];gap=23;coordinate_links=0
for raw in raw_components:
    owner=owners[raw['owner']];family=owner['identity'][0];piece=raw['piece'];coords=[]
    for k in range(4):
        axis=k%2;fm=owner['modes']
        lo=min(m['integer_lower_left_bounds'][axis][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in fm)
        hi=max(m['integer_lower_left_bounds'][axis][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in fm)
        coords.append(model.new_int_var(lo,hi,f'component_{raw["component"]}_edge_{k}').index)
    saved={**raw,'coordinates':coords,'mode_links':[],'sizes':[],'size_links':[],'interval_constraints':[]}
    for m in owner['modes']:
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid']
        links=[linear({coords[k]:1,owner['positions'][k%2]:-1},value,value,m['selector']) for k,value in enumerate(offsets)]
        saved['mode_links'].append({'mode':m['mode'],'selector':m['selector'],'offsets':offsets,'constraints':links});coordinate_links+=4
    for axis in [0,1]:
        possible=[rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis+2]-rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis]+gap for m in owner['modes']]
        size=model.new_int_var(min(possible),max(possible),f'component_{raw["component"]}_size_{axis}').index
        saved['sizes'].append(size);saved['size_links'].append(linear({size:1,coords[axis+2]:-1,coords[axis]:1},gap,gap))
        interval=model.new_interval_var(var(coords[axis]),var(size),var(coords[axis+2])+gap,f'component_{raw["component"]}_interval_{axis}')
        saved['interval_constraints'].append(interval.index)
        (intervals_x if axis==0 else intervals_y).append(interval)
    components.append(saved)
fixed_x=[];fixed_y=[];fixed_records=[];by_mask={r['mask']:r for r in presence}
for index,row in enumerate(obstacles):
    mask,left,bottom,right,top=row[:5];p=by_mask[mask]['selector'];cts=[]
    for axis,(a,b) in enumerate([(left,right),(bottom,top)]):
        name=f'obstacle_{index}_axis_{axis}'
        interval=model.new_interval_var(a,b-a,b,name) if p is None else model.new_optional_interval_var(a,b-a,b,var(p),name)
        cts.append(interval.index);(fixed_x if axis==0 else fixed_y).append(interval)
    fixed_records.append({'obstacle':index,'mask':mask,'bounds_grid':[left,bottom,right,top],'presence_selector':p,'interval_constraints':cts})
packing=[]
first_members=set(groups[0]['components'])
factorized=[(g,g['group']==0) for g in groups]+[({'group':len(groups),'components':[c['component'] for c in raw_components if c['component'] not in first_members]},True)]
for g,includes_fixed in factorized:
    fx,fy=(fixed_x,fixed_y) if includes_fixed else ([],[])
    ct=model.add_no_overlap_2d(fx+[intervals_x[i] for i in g['components']],fy+[intervals_y[i] for i in g['components']])
    packing.append({**g,'constraint':ct.index,'fixed_obstacles':len(fx)})
symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):symmetry.append({'family':family,'owners':[a['owner'],b['owner']],'constraint':linear({a['positions'][0]:1,b['positions'][0]:-1},cp_model.INT_MIN,0)})
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert not validation,validation
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'empty_site_selectors':empty,'mandatory_empty_constraints':mandatory_empty,'exactly_three_empty_constraint':exact_three,'components':components,
    'obstacle_masks':presence,'fixed_obstacles':fixed_records,'packing_groups':packing,'symmetry_constraints':symmetry,
    'position_units_per_mm':100,'world_origin_mm':[0,0],'rectangle_gap_grid':gap,'full_physical_stock':True}
write(OUT/'mapping.json',mapping);elapsed=time.perf_counter()-started
charges={'fixed_source_mode_geometry_preparation_seconds':load(FIRST/'checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(SLOTS/'checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(RID/'checks.json')['seconds'],
    'direct_short9_and_inventory_complete_process_seconds':load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds'],
    'disjoint_source_obstacles_complete_process_seconds':load(ROOT/'output/h5-first57-disjoint-obstacles-process-20261104/process.json')['complete_process_seconds'],
    'full_stock_movers_complete_process_seconds':load(ROOT/'output/h5-first57-disjoint-movers-process-20261104/process.json')['complete_process_seconds'],
    'edge_bracket_control_complete_process_seconds':load(ROOT/'output/h5-first57-edge-brackets-process-20261104/process.json')['complete_process_seconds'],
    'edge_insert_control_complete_process_seconds':load(ROOT/'output/h5-first57-edge-inserts-process-20261104/process.json')['complete_process_seconds'],
    'preserved_failed_companion_preparation_complete_process_seconds':load(ROOT/'output/h5-first57-edge-companion-process-20261104/process.json')['complete_process_seconds'],
    'corrected_companion_preparation_complete_process_seconds':load(ROOT/'output/h5-first57-edge-companion-v2-process-20261104/process.json')['complete_process_seconds'],
    'model_internal_seconds_pending_complete_process_charge':elapsed}
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),ROOT/'output/prepare_h5_first57_edge_model_builder_20261104.py',ROOT/'output/build_h5_first57_factorized_model_20261104.py',BASE/'selection.json',BASE/'fixed33.json',BASE/'factorized-groups.json']+[ROOT/'output'/n/'process.json' for n in ['h5-first57-edge-brackets-process-20261104','h5-first57-edge-inserts-process-20261104','h5-first57-edge-companion-process-20261104','h5-first57-edge-companion-v2-process-20261104']]+[ROOT/'output/prepare_h5_first57_factorized_model_builder_20261104.py',ROOT/'output/build_h5_first57_disjoint_model_20261104.py',FIRST/'checks.json',SLOTS/'checks.json',RID/'checks.json',ROOT/'output/prepare_h5_first57_disjoint_model_builder_20261104.py',ROOT/'output/build_h5_first57_grouped_model_20261104.py']+[ROOT/'output'/n/'process.json' for n in ['h5-first57-direct-short9-process-20261104','h5-first57-disjoint-obstacles-process-20261104','h5-first57-disjoint-movers-process-20261104']]+[BASE/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json','instances.json','inventory.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[OBS/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','disjoint-mask-boxes.json']]+[PRE/'plan.json',PRE/'audit/plan.json',PRE/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New positive companion to independently source-valid fixed33: original fixed29 plus two edge brackets and two inserts. All12 remaining orthogonal originals (six brackets and six inserts) retain full physical stock domains and72 legal mode selectors. Cog sites4 and10 are fixed empty, with exactly one additional empty among13 candidates. Fresh disjoint source-covering obstacles include the exact saved world transforms of the four new fixed originals. Eight moving-pair groups cover all147 component pairs; fixed obstacles appear only with group0 and its complementary six bracket pieces. Source coverage, all46 reference controls and complete66 identity inventory are independently audited before the model. The ledger conservatively charges the failed first companion preparation as well as its corrected replacement. No previous solver call, old optimized coordinates or capacity tables are reused. Audit every field and final complete-process ledger before one bounded call.',
    'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'provisional_preparation_seconds':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'owners':12,'source_mode_selectors':72,'empty_site_selectors':15,'required_empty_sites':3,
    'shared_obstacle_masks':len(presence),'optional_obstacle_masks':sum(r['selector'] is not None for r in presence),
    'source_covering_disjoint_obstacles':len(obstacles),'obstacle_interval_constraints':2*len(obstacles),
    'rigid_components':18,'coordinate_mode_links':coordinate_links,'moving_interval_constraints':36,'interval_size_constraints':36,
    'global_no_overlap_2d_constraints':9,'same_family_symmetry_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),
    'interaction_factorization':True,'fixed_obstacle_groups':2,'rectangle_references':18210,'fixed_source_originals':33,'mandatory_empty_sites':[4,10],'candidate_cog_subsets':13,'full_physical_stock':True,'prior_positive_regions_consumed':False,'prior_capacity_results_consumed':False,
    'final_complete_process_ledger_pending':True,'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
assert elapsed<15
write(OUT/'checks.json',checks);print(checks)
