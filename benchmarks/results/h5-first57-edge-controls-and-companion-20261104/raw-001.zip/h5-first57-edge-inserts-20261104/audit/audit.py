"""Reconstruct both insert formulas, source controls and complete identity inventory."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-inserts-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';EDGE=ROOT/'output/h5-first57-edge-brackets-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for folder in [BASE,EDGE/'audit',MOV/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(EDGE/'audit/checks.json')['passed'] and load(MOV/'audit/checks.json')['passed']
sites=load(PRE/'source-cog-sites.json');highest=max(r['transform']['translation'][1] for r in sites)
top=[i for i,r in enumerate(sites) if r['transform']['translation'][1]==highest];assert len(top)==5
second_empty=min(top,key=lambda i:sites[i]['transform']['translation'][0]);assert second_empty==10
edge=load(EDGE/'selection.json');empty=sorted([edge['omitted_site'],second_empty]);assert empty==[4,10]
selected=load(BASE/'selected-inserts.json');brackets=load(EDGE/'selected-brackets.json')
modes=load(MOV/'family-modes.json');rectangles=load(MOV/'mode-rectangles.json');assert len(selected)==2
for record,side,identity,mi in zip(selected,['left','right'],[['insert',6],['insert',7]],[1,0]):
    assert record['side']==side and record['identity']==identity and record['mode']==mi
    br=next(r for r in brackets if r['side']==side);bx,by=br['lower_left_grid']
    br_rects=[r['outward_offsets_grid'] for r in rectangles['bracket'][br['mode']]['rectangles']]
    ir=rectangles['insert'][mi]['rectangles'][0]['outward_offsets_grid'];mode=modes['insert'][mi]
    if side=='left':
        heights=[r[3]-r[1] for r in br_rects];assert heights.count(max(heights))==1
        leg=br_rects[heights.index(max(heights))]
        xy=[bx+leg[2]+23-ir[0],by+23-ir[1]]
    else:xy=[bx+23-ir[0],by+max(r[3] for r in br_rects)+23-ir[1]]
    assert record['lower_left_grid']==xy
    source={'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/100+mode['translation_from_lower_left'][k] for k in range(2)]}}
    assert record['source']==source
fixed=edge['fixed31_source_rows']+[r['source'] for r in selected];control=fixed+[r for i,r in enumerate(sites) if i not in empty]
assert control==load(BASE/'source46.json') and len(control)==46
spec=load(PRE/'plan.json');check=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
assert check==load(BASE/'source-checks.json') and check['valid']
assert check['same_sheet_pairs']==1035 and check['stock_edges']==184 and check['cutouts']==50 and check['hole_vertices']==4990
selection=load(BASE/'selection.json');remaining=[i for i in edge['remaining_moving14_identities'] if i not in [['insert',6],['insert',7]]]
assert selection=={'highest_row_sites':top,'omitted_sites':empty,'remaining_candidate_sites':[i for i in range(15) if i not in empty],
    'additional_empty_sites_required':1,'remaining_cog_choices':13,'fixed33_source_rows':fixed,'remaining_moving12_identities':remaining}
assert len(remaining)==12 and sum(i[0]=='bracket' for i in remaining)==sum(i[0]=='insert' for i in remaining)==6
inventory=load(PRE/'inventory.json')
first=[(r['part_id'],r['copy_index']) for r in fixed]+list(map(tuple,remaining))+list(map(tuple,inventory['required_cog12_identities']))
assert len(first)==len(set(first))==57 and set(first)==set(map(tuple,inventory['first57_identities']))
assert set(first).isdisjoint(map(tuple,inventory['short9_identities'])) and set(first)|set(map(tuple,inventory['short9_identities']))==set(map(tuple,inventory['full66_identities']))
write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','selected-inserts.json','source46.json','source-checks.json','selection.json']]+[PRE/n for n in ['plan.json','source-cog-sites.json','inventory.json']]+[EDGE/n for n in ['audit/plan.json','audit/checks.json','selected-brackets.json','selection.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Both insert anchors are reconstructed directly from the original-mode component boxes and0.23mm offsets, then all46 reference originals are independently re-read from the job. Full source contours, holes,1035 same-sheet pairs and184 stock edges pass. Removing any one of the13 candidate cogs preserves every pair and stock check; fixed33 plus12 original cog identities plus12 remaining orthogonal identities gives first57, disjoint from source-valid short9. This is a positive restricted construction with13 candidate site subsets, not a negative reduction of the259 necessary choices or440 whole-job allocations.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'source_valid46':True,'same_sheet_pairs':1035,'stock_edges':184,'cutouts':50,'hole_vertices':4990,
    'omitted_sites':[4,10],'fixed_originals':33,'remaining_brackets':6,'remaining_inserts':6,'candidate_twelve_cog_subsets':13,
    'full66_identity_partition_preserved':True,'source_valid66':False,'site_choices_excluded':0,'whole_allocations_excluded':0,
    'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
