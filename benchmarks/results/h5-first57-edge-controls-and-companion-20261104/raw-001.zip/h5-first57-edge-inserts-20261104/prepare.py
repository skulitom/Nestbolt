"""Direct two-insert controls adjoining the audited edge brackets."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-edge-inserts-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';EDGE=ROOT/'output/h5-first57-edge-brackets-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','source-cog-sites.json','inventory.json']]+[EDGE/n for n in ['plan.json','audit/plan.json','audit/checks.json','selected-brackets.json','selection.json']]+[MOV/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New direct positive control from audited edge brackets. Additionally omit the leftmost cog in the highest source row, selected from source transforms. Place a90degree insert to the right of the left bracket long vertical component, at the bracket baseline plus0.23mm. Place a0degree insert immediately above the right bracket outer top, with its left edge0.23mm inside the bracket lower-left anchor. Coordinates are computed from audited outward component boxes and0.23mm gaps, without optimization or capacity tables. Validate fixed29, two edge brackets, two inserts and all13 remaining source cogs together. If valid, any12-of13 cog subset preserves the control and twelve independent orthogonal movers remain for first57. A failed control is retained and excludes nothing.',
    'left_insert_identity':['insert',6],'right_insert_identity':['insert',7],'left_insert_mode':1,'right_insert_mode':0,
    'preparation_cap_seconds':10,'maximum_process_seconds':20,'new_solver_calls':0,'native_calls':0,'independent_audit_required':True})
assert load(EDGE/'audit/checks.json')['passed'] and load(MOV/'audit/checks.json')['passed']
sites=load(PRE/'source-cog-sites.json');highest=max(r['transform']['translation'][1] for r in sites)
top=[i for i,r in enumerate(sites) if r['transform']['translation'][1]==highest]
second_empty=min(top,key=lambda i:sites[i]['transform']['translation'][0])
edge=load(EDGE/'selection.json');empty=sorted([edge['omitted_site'],second_empty]);assert len(set(empty))==2 and len(top)==5
brackets=load(EDGE/'selected-brackets.json');modes=load(MOV/'family-modes.json');rectangles=load(MOV/'mode-rectangles.json')
selected=[]
for side,identity,mode_index in [('left',['insert',6],1),('right',['insert',7],0)]:
    br=next(r for r in brackets if r['side']==side);bx,by=br['lower_left_grid']
    br_rects=[r['outward_offsets_grid'] for r in rectangles['bracket'][br['mode']]['rectangles']]
    mode=modes['insert'][mode_index];ir=rectangles['insert'][mode_index]['rectangles'][0]['outward_offsets_grid']
    if side=='left':
        leg=max(br_rects,key=lambda r:r[3]-r[1])
        xy=[bx+leg[2]+23-ir[0],by+23-ir[1]]
    else:
        xy=[bx+23-ir[0],by+max(r[3] for r in br_rects)+23-ir[1]]
    source={'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/100+mode['translation_from_lower_left'][k] for k in range(2)]}}
    selected.append({'side':side,'identity':identity,'mode':mode_index,'lower_left_grid':xy,'source':source})
fixed=edge['fixed31_source_rows']+[r['source'] for r in selected]
controls=fixed+[r for i,r in enumerate(sites) if i not in empty]
spec=load(PRE/'plan.json');job=load(JOB)
check=audit(job,controls,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in controls])
write(OUT/'source46.json',controls);write(OUT/'source-checks.json',check);write(OUT/'selected-inserts.json',selected)
write(OUT/'selection.json',{'highest_row_sites':top,'omitted_sites':empty,'remaining_candidate_sites':[i for i in range(15) if i not in empty],
    'additional_empty_sites_required':1,'remaining_cog_choices':13,'fixed33_source_rows':fixed,
    'remaining_moving12_identities':[i for i in edge['remaining_moving14_identities'] if i not in [['insert',6],['insert',7]]]})
checks={'prepared':True,'seconds':time.perf_counter()-started,'source_valid46':check['valid'],'source_control_parts':len(controls),'omitted_cog_sites':empty,
    'selected_insert_lower_left_mm':[[v/100 for v in r['lower_left_grid']] for r in selected],'selected_insert_modes':[r['mode'] for r in selected],
    'same_sheet_pairs':check['same_sheet_pairs'],'stock_edges':check['stock_edges'],'cutouts':check['cutouts'],'hole_vertices':check['hole_vertices'],
    'fixed_originals':33,'remaining_independent_orthogonal_movers':12,'candidate_twelve_cog_subsets':13,
    'independent_original_source_audit_pending':True,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
assert check['valid'] and len(controls)==46 and checks['seconds']<10
