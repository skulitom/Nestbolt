"""Exact diagnostic for saved fixed transforms at grid-rounding boundaries."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-companion-20261104';OUT=BASE/'source-cover-preflight'
BR=ROOT/'output/h5-first57-edge-brackets-20261104';INS=ROOT/'output/h5-first57-edge-inserts-20261104'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();canonical=load(PIECES)
selected=load(BR/'selected-brackets.json')+load(INS/'selected-inserts.json');actual=load(BASE/'added-fixed-source-covers.json')
records=[];failures=[];index=0
for r in selected:
    family=r['identity'][0];t=r['source']['transform'];co,si=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));mirror=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    for pi,piece in enumerate(canonical[family]):
        vertices=[(mirror*F(x)*co-F(y)*si+tx,mirror*F(x)*si+F(y)*co+ty) for x,y in piece]
        bounds=actual[index]['bounds_grid'];assert actual[index]['added_fixed_identity']==r['identity'] and actual[index]['piece']==pi
        limits=[F(bounds[0],100),F(bounds[1],100),F(bounds[2]-23,100),F(bounds[3]-23,100)]
        failed=[i for i,(x,y) in enumerate(vertices) if not (limits[0]<=x<=limits[2] and limits[1]<=y<=limits[3])]
        expected=[math.floor(min(x for x,y in vertices)*100),math.floor(min(y for x,y in vertices)*100),math.ceil(max(x for x,y in vertices)*100)+23,math.ceil(max(y for x,y in vertices)*100)+23]
        record={'identity':r['identity'],'piece':pi,'actual_bounds_grid':bounds,'exact_world_outward_bounds_grid':expected,'uncovered_vertex_indices':failed}
        records.append(record)
        if failed:failures.append(record)
        index+=1
write(OUT/'fixed-world-readback.json',records)
inputs=[Path(__file__),PIECES,BASE/'plan.json',BASE/'added-fixed-source-covers.json',BR/'selected-brackets.json',INS/'selected-inserts.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Read saved binary64 fixed translations as exact rationals, transform every original convex-piece vertex, and compare with the unexpanded source-cover bounds. Integer-anchor arithmetic and a later binary64 source translation may differ at grid boundaries. Any uncovered vertex prevents certification of this prepared obstacle cover; a corrected version must round the exact saved world transforms outward.'})
checks={'passed':not failures,'seconds':time.perf_counter()-started,'fixed_source_components_checked':len(records),'components_with_uncovered_vertices':len(failures),
    'uncovered_vertices':sum(len(r['uncovered_vertex_indices']) for r in failures),'source46_layout_itself_still_valid':True,
    'new_model_permitted':not failures,'solver_calls':0}
write(OUT/'checks.json',checks);print(checks)
