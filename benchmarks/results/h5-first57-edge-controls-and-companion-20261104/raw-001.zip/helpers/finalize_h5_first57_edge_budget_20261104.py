from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-companion-v2-20261104';MODEL=BASE/'model'
PROCESS=ROOT/'output/h5-first57-edge-model-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
charges=load(MODEL/'preparation-charges.json');internal=charges.pop('model_internal_seconds_pending_complete_process_charge')
p=load(PROCESS/'process.json');assert p['exit_code']==0 and not p['timeout'] and p['closed']
charges['model_complete_process_seconds']=p['complete_process_seconds'];assert internal<charges['model_complete_process_seconds']
inputs=[Path(__file__),MODEL/'preparation-charges.json',PROCESS/'opened.json',PROCESS/'process.json']
record={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'charges':charges,'internal_model_seconds_replaced':internal,'preparation_seconds_charged':sum(charges.values()),
    'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False}
with (MODEL/'final-preparation-charges.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
