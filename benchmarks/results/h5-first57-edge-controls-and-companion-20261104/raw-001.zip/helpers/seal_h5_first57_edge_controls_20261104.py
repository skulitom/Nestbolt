"""Seal both valid edge controls, the preserved rounding failure and the companion."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-first57-edge-controls-and-companion-20261104';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-edge-companion-v2-20261104';BR=ROOT/'output/h5-first57-edge-brackets-20261104';INS=ROOT/'output/h5-first57-edge-inserts-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104','h5-independent-cog-rows-and-expanded-domains-20261104','h5-expanded-joint-and-staged-row-constructions-20261104','h5-row-reductions-and-three-cog-allocation-20261104','h5-direct-short9-and-grouped-first57-20261104','h5-first57-necessary-capacities-20261104','h5-first57-full-stock-obstacles-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for folder in [BR/'audit',INS/'audit',BASE/'audit',BASE/'model-audit',BASE/'response-audit']:assert load(folder/'checks.json')['passed']
failure=ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight'
assert not load(failure/'checks.json')['passed'] and not load(failure/'checks.json')['new_model_permitted']
response=load(BASE/'response-audit/checks.json')
assert response['closed_solver_calls']==1 and response['solver_status']=='UNKNOWN' and response['assignments']==0 and response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for name in ['h5-first57-edge-brackets-20261104','h5-first57-edge-brackets-process-20261104','h5-first57-edge-inserts-20261104','h5-first57-edge-inserts-process-20261104','h5-first57-edge-companion-20261104','h5-first57-edge-companion-process-20261104','h5-first57-edge-companion-v2-20261104','h5-first57-edge-companion-v2-process-20261104','h5-first57-edge-model-process-20261104']:
    folder=ROOT/'output'/name
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_first57_edge*20261104.py','check_h5_edge_companion_fixed_source_cover_20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,'h5-first57-edge-controls-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(BR/'audit/checks.json','bracket-control-audit.json'),(INS/'audit/checks.json','insert-control-audit.json'),
    (BR/'selected-brackets.json','selected-brackets.json'),(INS/'selected-inserts.json','selected-inserts.json'),
    (failure/'checks.json','fixed-source-cover-failure.json'),(failure/'fixed-world-readback.json','fixed-source-cover-readback.json'),
    (BASE/'audit/checks.json','corrected-geometry-audit.json'),(BASE/'fixed33.json','fixed33.json'),
    (BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),
    (BASE/'model/final-preparation-charges.json','preparation-charges.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],'closed_call_status':'UNKNOWN','closed_call_must_not_be_repeated':True,
    'source_valid45_bracket_control':True,'source_valid46_bracket_insert_control':True,'fixed_originals':33,'remaining_brackets':6,'remaining_inserts':6,
    'constructive_omitted_sites':[4,10],'constructive_candidate_twelve_cog_subsets':13,
    'next_method':'Evaluate a new direct top-edge row for the six remaining original inserts15..20. Derive a common inward stock-safe Y for horizontal insert mode0, start X to the right of the upper-left fixed bracket using its exact saved-world outward cover, and space the original inserts by the audited0.23mm source gap. Check all original sources against fixed33 and every remaining candidate cog before claiming a source-valid52 reference control. Such a shelf would leave six brackets, but may consume space they need: derive fresh necessary source-body capacity bounds for that fixed layout over all13 candidate cog subsets before any new call. Preserve any failed control or capacity result; do not restart the closed twelve-mover companion. No shelf or six-bracket model has been prepared.',
    'top_shelf_prepared':False,'necessary_first57_site_choices':259,'older_fixed13_cog_frontier':{'site_choices':2,'count_distributions':3},'remaining_allocation_candidates':440,
    'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'source_valid45':True,'source_valid46':True,'fixed_originals':33,'remaining_orthogonal_movers':12,'constructive_cog_subsets':13,
    'failed_coverage_components_preserved':6,'failed_coverage_vertices_preserved':9,'corrected_coverage_audited':True,'failed_preparation_charged':True,
    'model_variables':250,'model_constraints':18918,'closed_solver_calls':1,'solver_status':'UNKNOWN','assignments':0,
    'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,
    'new_site_choices_excluded':0,'necessary_first57_site_choices':259,'remaining_allocation_candidates':440,
    'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-first57-edge-controls-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 edge controls and twelve-part companion:** [independent original-source audits]({link}) validate two fixed edge brackets and two adjoining inserts. The controls check 45/46 reference parts, including all holes, and preserve the full66 identity partition. The right bracket uses space below the older top strip; fixed33 leaves six brackets and six inserts moving, with 13 constructive cog subsets. A saved-world rounding coverage failure is preserved and corrected before model use; both preparation processes are charged. Every field of the 250-variable / 18,918-constraint companion passes audit. Its sole call closes UNKNOWN after 4,234 branches, without an assignment. The 0.024632 s solve-slice overrun is retained; algorithm/shared totals 56.039587/56.107026 s remain within 60/90 s. No new necessary selection or whole allocation is excluded. The 259-choice necessary frontier, full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [full-stock obstacle packing](../benchmarks/results/h5-first57-full-stock-obstacles-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [edge controls and twelve-part companion](../benchmarks/results/{NAME}.md).',1)
a='The direct 4/2/3 short sheet passes source checks in 0.297 s. Two new full-stock\nobstacle models close UNKNOWN without a placement. Exact interaction factorization\nremoves 87.4% of rectangle references and reaches search, but full66 remains open.\nThe necessary capacity proofs still exclude 196 of the 455 fixed-core twelve-cog\nselections, leaving 259. Fresh side-pocket source controls remain to investigate.'
b='The direct 4/2/3 short sheet passes source checks in 0.297 s. New source-valid\nedge controls fix two brackets and two inserts, leaving six of each moving.\nThe audited twelve-part companion closes UNKNOWN without a complete placement.\nThe necessary capacity proofs still exclude 196 of the 455 fixed-core twelve-cog\nselections, leaving 259. A direct top insert shelf and fresh bracket capacities\nremain to investigate before another construction.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
