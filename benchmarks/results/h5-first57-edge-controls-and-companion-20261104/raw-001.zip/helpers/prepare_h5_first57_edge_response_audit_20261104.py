from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_first57_factorized_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-disjoint-movers-20261104','h5-first57-edge-companion-v2-20261104')
s=s.replace("MODEL=BASE/'model-factorized';SEARCH=BASE/'search-factorized';OUT=BASE/'factorized-response-audit'","MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'")
s=s.replace('factorized-model-audit','model-audit').replace('h5-first57-factorized-model-process-20261104','h5-first57-edge-model-process-20261104')
s=s.replace("queue=list(roots);","roots.extend([ROOT/'output'/n/'opened.json' for n in ['h5-first57-edge-brackets-process-20261104','h5-first57-edge-inserts-process-20261104','h5-first57-edge-companion-process-20261104','h5-first57-edge-companion-v2-process-20261104']])\nqueue=list(roots);",1)
s=s.replace("assert charges==expected","""for folder,key in [
    ('h5-first57-edge-brackets-process-20261104','edge_bracket_control_complete_process_seconds'),
    ('h5-first57-edge-inserts-process-20261104','edge_insert_control_complete_process_seconds'),
    ('h5-first57-edge-companion-process-20261104','preserved_failed_companion_preparation_complete_process_seconds'),
    ('h5-first57-edge-companion-v2-process-20261104','corrected_companion_preparation_complete_process_seconds')]:
    p=load(ROOT/'output'/folder/'process.json');assert p['exit_code']==0 and not p['timeout'] and p['closed']
    expected[key]=p['complete_process_seconds']
assert charges==expected""")
s=s.replace('len(model.variables)==324 and len(model.constraints)==22066','len(model.variables)==250 and len(model.constraints)==18918')
s=s.replace('response.num_branches==2005 and response.num_conflicts==77','response.num_branches==4234 and response.num_conflicts==623')
s=s.replace('Starting search at 11.10s','Starting search at 6.63s').replace("'search_started_after_solver_seconds':11.10","'search_started_after_solver_seconds':6.63")
s=s.replace("'model_variables':324,'model_constraints':22066","'model_variables':250,'model_constraints':18918")
s=s.replace("write(OUT/'source-bindings.json',bindings)","assert not load(ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/checks.json')['passed']\nassert load(BASE/'audit/checks.json')['prior_unverified_cover_failure_preserved']\nassert load(ROOT/'output/h5-first57-edge-brackets-20261104/audit/checks.json')['source_valid45']\nassert load(ROOT/'output/h5-first57-edge-inserts-20261104/audit/checks.json')['source_valid46']\nwrite(OUT/'source-bindings.json',bindings)")
with (ROOT/'output/audit_h5_first57_edge_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
