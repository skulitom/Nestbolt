from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/check_h5_first57_disjoint_candidate_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-disjoint-movers-20261104','h5-first57-edge-companion-v2-20261104')
s=s.replace("rows=load(PRE/'fixed29.json')+load(PRE/'short9-source.json')","rows=load(BASE/'fixed33.json')+load(PRE/'short9-source.json')")
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),BASE/'fixed33.json',BASE/'selection.json',",1)
with (ROOT/'output/check_h5_first57_edge_candidate_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_first57_disjoint_model_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-disjoint-movers-20261104','h5-first57-edge-companion-v2-20261104').replace('check_h5_first57_disjoint_candidate_20261104','check_h5_first57_edge_candidate_20261104')
s=s.replace("inputs = [Path(__file__),","inputs = [Path(__file__), BASE/'fixed33.json', BASE/'selection.json',",1)
with (ROOT/'output/run_h5_first57_edge_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
