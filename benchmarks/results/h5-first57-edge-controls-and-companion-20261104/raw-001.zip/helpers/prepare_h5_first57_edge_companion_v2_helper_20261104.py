from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/prepare_h5_first57_edge_companion_20261104.py').read_text(encoding='utf-8')
s=s.replace("OUT=ROOT/'output/h5-first57-edge-companion-20261104'","OUT=ROOT/'output/h5-first57-edge-companion-v2-20261104'")
s=s.replace('import json,time,shutil','from fractions import Fraction as F\nimport json,time,shutil,math')
s=s.replace("load=lambda p:","PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'\nload=lambda p:",1)
s=s.replace("inputs=[Path(__file__)]","inputs=[Path(__file__),PIECES,ROOT/'output/prepare_h5_first57_edge_companion_v2_helper_20261104.py',ROOT/'output/prepare_h5_first57_edge_companion_20261104.py',ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/plan.json',ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/checks.json']",1)
s=s.replace("Add outward source-covering component boxes for the independently valid two edge brackets and two adjoining inserts, with the same right/top0.23mm expansion.","Recompute outward source-covering component boxes directly from exact rational representations of the saved binary64 world transforms for the independently valid two edge brackets and two adjoining inserts, with the same right/top0.23mm expansion. This version repairs the preserved unverified first preparation: adding integer anchor coordinates to mode-relative rounded boxes did not always cover saved binary64 world vertices at grid boundaries.")
a=s.index('additions=[]');b=s.index("write(OUT/'added-fixed-source-covers.json'",a)
s=s[:a]+'''additions=[];canonical=load(PIECES)
for r in load(BR/'selected-brackets.json')+load(INS/'selected-inserts.json'):
    family=r['identity'][0];t=r['source']['transform'];co,si=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']))
    mirror=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    for piece,vertices in enumerate(canonical[family]):
        world=[(mirror*F(x)*co-F(y)*si+tx,mirror*F(x)*si+F(y)*co+ty) for x,y in vertices]
        box=[math.floor(min(x for x,y in world)*100),math.floor(min(y for x,y in world)*100),math.ceil(max(x for x,y in world)*100)+23,math.ceil(max(y for x,y in world)*100)+23]
        addition={'site_bit':15,'added_fixed_identity':r['identity'],'source_mode':r['mode'],'piece':piece,'bounds_grid':box}
        additions.append(addition);obstacles.append(addition)
'''+s[b:]
s=s.replace("'fixed_originals':33,'added_source_component_covers'","'fixed_originals':33,'saved_world_transforms_rounded_outward':True,'prior_unverified_preparation_preserved':True,'added_source_component_covers'")
with (ROOT/'output/prepare_h5_first57_edge_companion_v2_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
r=(ROOT/'output/run_h5_first57_edge_companion_20261104.py').read_text(encoding='utf-8')
r=r.replace('h5-first57-edge-companion-process-20261104','h5-first57-edge-companion-v2-process-20261104').replace('prepare_h5_first57_edge_companion_20261104.py','prepare_h5_first57_edge_companion_v2_20261104.py')
with (ROOT/'output/run_h5_first57_edge_companion_v2_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(r)
