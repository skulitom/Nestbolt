"""Archive complete two-center source preparation, cache controls and coverage."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-two-center-preflight-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-two-center-preflight-20261107';F=BASE/'audit';D=BASE/'coverage-audit'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-current-mode-relocation-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['optimizer_calls']==0 and front['key_minima']==2854 and front['strictly_improves_current'] and front['owner_mode_models_verified']==222",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-two-center-preparation-process-20261107',ROOT/'output/h5-two-center-audit-process-20261107']",
    "['*h5*mixed*mode*20261107.py']":"['*h5*two*center*20261107.py','prepare_h5_current_mode_construction_push_20261107.py','push_h5_current_mode_construction_checkpoints_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_two_center_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','center-combination-coverage.json']",
    'archive,_=pack':"add('generator-correction.json',ROOT/'output/h5-two-center-generator-correction-20261107.json')\narchive,_=pack",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(F/'checks.json','preflight-audit.json'),(F/'selection-replay/checks.json','selection-replay.json'),(F/'cache-controls.json','cache-controls.json'),(F/'inherited-source-domains.json','inherited-source-domains.json'),(F/'selected-model-controls.json','selected-model-controls.json'),(F/'deadline-controls.json','deadline-controls.json'),(F/'policy-stop-controls.json','policy-stop-controls.json'),(BASE/'selection.json','initial-selection.json'),(BASE/'closed-problems.json','closed-problems.json'),(D/'checks.json','coverage-audit.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-two-center-generator-correction-20261107.json','generator-correction.json')]
for stage in ['preparation','audit']:copies.append((ROOT/'output'/f'h5-two-center-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
cover=load(D/'checks.json');cache=load(F/'cache-controls.json');assert cover['passed'] and cache['passed']
write(OUT/'next-step.json',{'status':'two_center_finite_search_contract_required','finding':'Complete two-distinct-center source preparation and independent score/key/model/deadline/cache audits pass. Every old one-center raw proposal remains represented. Coverage comparison uses the same16closed identities and records whether the best eligible starting placement actually changes; no packing benefit is assumed from larger coverage. No optimizer has opened.',
    'requirements':['Start only from this verified original A/W source selected state. Exclude all16closed complete objective/physical-mode/weight identities; different coordinates cannot reopen a key. Never seed from prior optimized/stopping winners or validation outputs.','Preserve both distinct scored centers for every111physical owner/mode and the full23419raw current/single/joint combination set. Every runtime call must calculate all9102current-state grid/clamped scores, use all528weighted original/clearance pairs and15coefficient1auxiliary terms, group all2854key minima and apply strict1e-6improvement after closure exclusion.','The source cache is bound to exact geometry,state,weights,identity and regions. A changed runtime context must use full recalculation. Preserve cached/full deadline stops, all partial evidence and no selected candidate from incomplete output. Keep area-only weight updates and continuous15cog angles unchanged.','Charge the full preparation stated here before new construction. Freeze a finite60/90second contract with the source reserve using the measured full-selector cost, not the faster cached source time. Do not assume the previous two8s schedule fits. Record full I/O/model/source time and any slice overruns; never extend the call count or deadlines after closure.','Read every dynamic model, evaluation and all three winner streams; independently reconstruct every runtime full score and key minimum. Full66source validity remains required before native validation, material claims or H5credit.'],
    'complete_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'validation_only_full_selector_seconds':cache['full_recalculation_seconds'],'source_coverage_comparison':cover,'new_source_state_prepared':True,'finite_search_contract_prepared':False,'new_optimizer_calls':0,'closed_augmented_problems':9,'closed_prior_weighted_problems':7,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
sel=load(F/'selection-replay/checks.json');model=load(F/'selected-model-controls.json');dead=load(F/'deadline-controls.json');prep=load(OUT/'preparation-process.json');audit=load(OUT/'audit-process.json');ci=load(BASE/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
assert prep['passed'] and audit['passed'] and model['owner_replacements']==[[16,0],[28,0]] and model['physical_mode_changes']==[[16,1,0]]
placement_statement=('The best eligible starting placement changes.' if cover['selected_placement_changed'] else 'The best eligible starting placement is unchanged from the one-center pool when both use the same sixteen exclusions.')
report=f'''# Two-center source preflight — 2026-11-07

The source neighborhood now retains two distinct centers for every physical
owner/orientation and scores all their single/joint combinations. Complete
independent checks pass for **23,419 raw proposals**, **2,854 problem-key minima**
and the selected source initializer. **No optimizer has run and no valid full66
packing is established.** H2/H5 remain open at **60% completed milestone weight**.

## Complete source and key coverage

[Score reconstruction]({NAME}/selection-replay.json) independently rebuilds all
**9,102 nominal center scores** and **23,419 complete proposal scores**:
**32,521 full original/clearance/auxiliary scores**. Every one of 111 physical
owner-mode choices retains its first two distinct centers in the unchanged
score/XY/local-index order. All 147 representative/alias bindings, 9,051 unique
owner-mode centers and 51 exact coordinate aliases are retained. The same
9×9 grid plus clamped control, geometry, domains, original weights and
incoming cog angles are used; all fifteen angles remain continuous in the model.

Raw coverage is one baseline, 222 single replacements and 23,196 joint
replacements. Each joint replaces its mutual pair exactly once. Grouping by
the existing complete objective/physical-mode/weight identity yields 2,854 keys:
the baseline has 2,179 raw members, 78 single-physical-change keys have 130 each,
and 2,775 two-physical-change keys have four each. Independent readback checks
both center ranks, every raw combination and every key minimum. Maximum
component score error is {sel['maximum_component_score_error_mm2']:.3e} mm²;
{sel['different_numerical_rankings_within_predeclared_tolerance']} numerical ranking
differences within the frozen 1e-6 mm² tolerance remain explicit.

All [sixteen closed identities]({NAME}/closed-problems.json) stay excluded.
Five occur in this source pool and exclude **2,321 raw proposals**. Multiple
coordinate choices do not authorize another call on a closed identity.

[Coverage comparison]({NAME}/coverage-audit.json) reconciles every old one-center
proposal with its identical placement in the expanded pool, using independent
scores and the same sixteen exclusions. There are 17,508 additional raw
proposals. Key minima strictly improve in **{cover['keys_strictly_improved']}** cases,
including **{cover['eligible_keys_strictly_improved']} eligible keys**; the maximum
independently verified decrease is {cover['maximum_independent_key_improvement_mm2']:.6f} mm².
{placement_statement}
The accepted centers have zero-based individual ranks
**{cover['selected_center_ranks_zero_based']}**. A broader pool alone is not a
packing improvement, and none is claimed here.

## Source cache, geometry and selected model

The original 9,102-trial table is reused only with exact source hashes and the
full **27.204689 s** of prior preparation retained. The cache context binds
the complete library, modes, coordinates, weights, objective identity and
auxiliary regions. [Cache controls]({NAME}/cache-controls.json) reject changes
in all six categories. A complete uncached calculation reproduces the cached
construction exactly, including every center, raw proposal and selection;
this validation-only calculation takes {cache['full_recalculation_seconds']:.6f} s.
Runtime states with different coordinates or weights cannot reuse the source cache.

[Inherited original-source domain controls]({NAME}/inherited-source-domains.json)
are bound to the identical table and original state. They retain all 163,836
nominal fixed-pair checks, 36,408 stock edges, 18,841 cutouts and 2,394,464 hole
vertices, plus all 33 fixed originals. The full source-domain certificate is
unchanged. New readback verifies **222 owner/mode/center models**, membership
of both selected centers in the original trial sets and the complete selected
model. These checks do not resolve mutual moving-part clearance.

The [accepted initializer]({NAME}/initial-selection.json) changes insert owner 16
from physical mode 1 to 0 and relocates cog owner 28 in its existing mode 0.
It comes solely from original unoptimized A/W source coordinates and weights.
Its augmented score is **{model['augmented_objective_mm2']:.6f} mm²**, with
**{model['original_overlap_mm2']:.6f} mm² original overlap**. The
[complete model]({NAME}/selected-model-controls.json) preserves 81 coordinates,
33 movers, all 528 weighted original/clearance pairs and 15 coefficient-1
auxiliary terms. Its {model['scalar_directed_gradient_terms']} directed scalar
gradient terms agree within {model['maximum_scalar_gradient_error_mm']:.3e} mm
under the existing documented boundary conventions.

## Stops, preparation and next work

[Eighteen deadline controls]({NAME}/deadline-controls.json) check six synthetic
and one real interruption in each cached/full path, plus four key-grouping
interruptions. Every partial result remains recorded and selects no proposal.
The real cached/full cooperative overruns are respectively
{dead['neighborhood_real_cases'][0]['observed_overrun_seconds']:.6f}/
{dead['neighborhood_real_cases'][1]['observed_overrun_seconds']:.6f} s. One in-progress
batch can overrun; the verified Windows Job remains the outer time/memory bound.
[Three policy controls]({NAME}/policy-stop-controls.json) reject incomplete pools
and select nothing when all keys are closed or strict improvement is absent.

[New source preparation]({NAME}/preparation-process.json) takes **{prep['complete_seconds']:.6f} s**,
including imports, cache validation and output. The retained total is now
**{front['complete_preparation_seconds']:.6f} s**. [Independent validation]({NAME}/audit-process.json)
closes in {audit['complete_seconds']:.6f} s. All processes close with zero optimizer
calls. A [generator replacement-order failure]({NAME}/generator-correction.json)
was preserved and corrected before any source preparation opened; it created
no prepared files and consumed no optimizer attempt.

[Next]({NAME}/next-step.json), freeze a finite search contract using this source
state, the actual full-selector cost and the existing preparation-inclusive
60/90 s limits with a source reserve. The faster source cache does not estimate
the cost of changed runtime states. No search contract is prepared. All sixteen
identities and prior finite pipelines stay closed; no historical optimized
winner or validation state may seed a successor. Four earlier arrangements
and 440 allocations remain. No native call, exclusion or H5 credit follows.

[Main CI at review]({NAME}/main-ci-at-review.json) on b8a14317 has {success} passed
jobs and {live} live jobs. This checkpoint and a5cba93c await the ordinary push
gate. Product code, README claims and releases remain unchanged.

[Archive verification]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 two-center source preflight:** [independent source/model/selection checks]({{link}}) verify two distinct scored centers for all 111 physical owner-mode choices, 23,419 complete raw proposals and 2,854 key minima. All 32,521 full center/proposal scores replay. Sixteen closed identities exclude 2,321 raw proposals across five source keys. Every old proposal remains represented; {cover["eligible_keys_strictly_improved"]} eligible key minima improve under the same exclusions, while changed best-start placement is {cover["selected_placement_changed"]}. Both selected center ranks are recorded. All 222 owner/mode/center models and the selected 81-coordinate model read back; inherited source-domain evidence remains exactly bound. Cached/full construction agrees exactly, six stale-cache contexts are rejected, and eighteen deadline plus three policy controls pass. Complete new preparation is {prep["complete_seconds"]:.6f} s, bringing retained preparation to {front["complete_preparation_seconds"]:.6f} s; full uncached selector validation takes {cache["full_recalculation_seconds"]:.6f} s. Every process closes, no optimizer opens and no full66 valid layout follows. Next freeze a finite contract using the actual full runtime cost within 60/90 seconds; none is prepared. The generator replacement-order failure was preserved before preparation. All sixteen keys stay closed. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Main b8a14317 has {success} passed CI jobs and {live} live jobs at review; a5cba93c and this checkpoint await the ordinary push gate. Product code, README and releases are unchanged.'
entry=entry.replace(f', while changed best-start placement is {cover["selected_placement_changed"]}.', '. '+placement_statement)
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [two-center source preflight](../benchmarks/results/{NAME}.md).
Two distinct centers per owner/orientation now produce 23,419 raw proposals.
Independent reconstruction verifies all 32,521 center/proposal scores and 2,854
complete key minima. Sixteen closed identities exclude 2,321 raw proposals.
All old one-center proposals remain represented; {cover['eligible_keys_strictly_improved']} eligible key minima improve
under the same exclusions. {placement_statement}
All 222 representative models and the selected model read back. Cached/full
calculations agree exactly; six stale contexts, eighteen deadline cases and
three policy stops pass. Source-domain evidence remains exactly bound.
Retained preparation is {front['complete_preparation_seconds']:.6f} s; full uncached selector validation takes
{cache['full_recalculation_seconds']:.6f} s. All processes close with zero optimizer calls.
No full66 valid layout is established. Next freeze a finite contract using the
full runtime cost within the existing 60/90 s limits. None is prepared.
All sixteen identities and prior pipelines remain closed. Four earlier
arrangements and 440 allocations remain; H2/H5 stay open at 60%.
Main b8a14317 has {success} passed CI jobs and {live} live jobs at review; a5cba93c
and this checkpoint await the ordinary push gate. Product code, README and
releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
