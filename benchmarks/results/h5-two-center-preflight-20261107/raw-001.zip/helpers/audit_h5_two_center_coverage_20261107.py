"""Read-only comparison of one/two-center coverage under the same closed keys."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-center-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107';OUT=BASE/'coverage-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();start=time.perf_counter()
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','audit/checks.json','neighbors.json','closed-problems.json','key-minima.json','center-selections.json','selection.json','audit/selection-replay/proposal-score-controls.json']]+[U/n for n in ['neighbors.json','audit/selection-replay/proposal-score-controls.json','audit/selection-replay/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconcile every old raw proposal against its identical new center/mode placement; compare per-key minima and best eligible choice using the same16closed keys and independent complete scores. Identify second-center use, without constructing any alternate optimizer seed or changing a candidate.','optimizer_calls':0})
old=load(U/'neighbors.json');new=load(BASE/'neighbors.json');closed={r['key'] for r in load(BASE/'closed-problems.json')};assert len(closed)==16
old_scores={r['sequence']:r['augmented_objective_mm2'] for r in load(U/'audit/selection-replay/proposal-score-controls.json')};new_scores={r['sequence']:r['augmented_objective_mm2'] for r in load(BASE/'audit/selection-replay/proposal-score-controls.json')}
def signature(row):return tuple(map(tuple,row['changes'])),tuple(map(tuple,row['centers']))
def rank(row):return row['augmented_objective_mm2'],row['modes'],len(row['changes']),row['changes'],row['centers'],row['sequence']
by_signature={signature(r):r for r in new};assert len(by_signature)==23419
old_groups={};bindings=[]
for row in old:
    actual=by_signature[signature(row)];assert {k:v for k,v in row.items() if k not in ['sequence','excluded','exclusion_reason']}=={k:v for k,v in actual.items() if k not in ['sequence','excluded','exclusion_reason']}
    assert abs(old_scores[row['sequence']]-new_scores[actual['sequence']])<1e-6
    old_groups.setdefault(row['key'],[]).append(row);bindings.append({'old_sequence':row['sequence'],'new_sequence':actual['sequence'],'key':row['key']})
assert len(old)==5911 and len(old_groups)==2854
minima=load(BASE/'key-minima.json');controls=[];old_minima=[]
for row in minima:
    previous=min(old_groups[row['key']],key=rank);old_minima.append(previous);delta=old_scores[previous['sequence']]-new_scores[row['sequence']];assert delta>=-1e-6
    controls.append({'key':row['key'],'old_sequence':previous['sequence'],'new_sequence':row['sequence'],'excluded':row['key'] in closed,'independent_improvement_mm2':delta,'strictly_improved':delta>1e-6,'placement_changed':signature(row)!=signature(previous)})
old_best=min((r for r in old_minima if r['key'] not in closed),key=rank);new_best=load(BASE/'selection.json')['accepted_choice'];assert new_best is not None
options={(r['owner'],r['mode']):r['selected'] for r in load(BASE/'center-selections.json')};ranks=[]
for (owner,mode),center in zip(new_best['changes'],new_best['centers']):ranks.append(next(i for i,row in enumerate(options[owner,mode]) if row['center']==center))
write(OUT/'old-proposal-bindings.json',bindings);write(OUT/'key-improvement-controls.json',controls)
summary={'passed':True,'seconds':time.perf_counter()-start,'old_raw_proposals_preserved':len(bindings),'additional_raw_proposals':len(new)-len(old),'keys_compared':len(controls),'keys_strictly_improved':sum(r['strictly_improved'] for r in controls),'eligible_keys_strictly_improved':sum(r['strictly_improved'] and not r['excluded'] for r in controls),'maximum_independent_key_improvement_mm2':max(r['independent_improvement_mm2'] for r in controls),'same_closed_keys':len(closed),'old_best_eligible_key':old_best['key'],'new_best_eligible_key':new_best['key'],'selected_placement_changed':signature(old_best)!=signature(new_best),'independent_best_eligible_improvement_mm2':old_scores[old_best['sequence']]-new_scores[new_best['sequence']],'selected_center_ranks_zero_based':ranks,'optimizer_calls':0,'candidate_changed_by_diagnostic':False,'new_successor_seed_created':False,'H5_complete':False};write(OUT/'checks.json',summary);print(summary)
