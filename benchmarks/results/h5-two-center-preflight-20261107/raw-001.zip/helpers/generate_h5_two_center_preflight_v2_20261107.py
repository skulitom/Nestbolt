"""Correct a generator replacement order before any source preparation opens."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/generate_h5_two_center_preflight_20261107.py';source=old.read_text(encoding='utf-8')
a="'audit_h5_current_mode_relocations_20261107':'audit_h5_two_center_preflight_20261107'";b="'audit_h5_two_center_neighbors_20261107':'audit_h5_two_center_preflight_20261107'"
assert a in source
for name in ['prepare_h5_two_center_preflight_20261107.py','audit_h5_two_center_preflight_20261107.py','run_h5_two_center_stage_20261107.py']:assert not (ROOT/'output'/name).exists()
record={'failed_generator':old.relative_to(ROOT).as_posix(),'failed_generator_sha256':sha256(old.read_bytes()).hexdigest(),'failure':'AssertionError: audit_h5_current_mode_relocations_20261107','cause':'An earlier module-name replacement also changed the auditor filename before its explicit replacement.','correction':'Match the already-transformed auditor filename.','prepared_files_created_before_failure':0,'source_preparation_opened':False,'optimizer_calls':0}
with (ROOT/'output/h5-two-center-generator-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
exec(compile(source.replace(a,b),str(old),'exec'))
