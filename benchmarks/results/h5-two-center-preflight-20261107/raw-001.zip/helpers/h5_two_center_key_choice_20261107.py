"""Keep one deterministic minimum per complete objective/physical-mode/weight key."""
import math,time
from collections import Counter

def rank(row):
    return (row['augmented_objective_mm2'],row['modes'],len(row['changes']),row['changes'],row['centers'],row['sequence'])

class KeySelectionDeadline(Exception):
    def __init__(self,evidence):
        self.evidence=evidence
        super().__init__('Complete key grouping stopped at its deadline')

def choose(records,deadline,clock=time.perf_counter):
    assert math.isfinite(deadline) and len(records)==23419 and [r['sequence'] for r in records]==list(range(23419))
    assert records[0]['changes']==[] and all(math.isfinite(r['augmented_objective_mm2']) for r in records)
    groups={};minima=[];checks=0
    def checkpoint(stage):
        nonlocal checks
        checks+=1;observed=clock()
        if observed>=deadline:raise KeySelectionDeadline({'complete':False,'status':'KEY_SELECTION_DEADLINE','stage':stage,'checkpoints':checks,'deadline':deadline,'observed':observed,'overrun_seconds':observed-deadline,'group_members':groups,'key_minima':minima,'selected_proposal':None,'optimizer_calls':0})
    checkpoint('before-key-grouping')
    for row in records:groups.setdefault(row['key'],[]).append(row['sequence'])
    assert len(groups)==2854 and dict(Counter(map(len,groups.values())))=={2179:1,130:78,4:2775}
    checkpoint('after-key-grouping')
    for key in sorted(groups):
        rows=[records[i] for i in groups[key]];assert len({r['excluded'] for r in rows})==1 and len({tuple(r['physical_key']) for r in rows})==1
        minima.append(min(rows,key=rank))
    checkpoint('after-key-ranking')
    eligible=[r for r in minima if not r['excluded']];best=min(eligible,key=rank) if eligible else None
    singles=[r for r in records if not r['excluded'] and len(r['changes'])==1];joints=[r for r in records if not r['excluded'] and len(r['changes'])==2]
    single=min(singles,key=rank) if singles else None;joint=min(joints,key=rank) if joints else None;baseline=records[0]['augmented_objective_mm2'];improves=best is not None and best['augmented_objective_mm2']<baseline-1e-6
    selection={'best_single':single,'best_joint':joint,'best_admissible':best,'current_score':baseline,'strictly_improves_current':improves,'accepted_choice':best if improves else None,'raw_proposals':len(records),'distinct_keys':len(groups),'excluded_keys':sum(r['excluded'] for r in minima),'excluded_raw_proposals':sum(r['excluded'] for r in records)}
    checkpoint('complete-choice')
    return selection,groups,minima
