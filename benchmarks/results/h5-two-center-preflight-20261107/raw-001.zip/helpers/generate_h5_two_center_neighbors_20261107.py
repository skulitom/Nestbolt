"""Version two distinct centers without changing objective, grid or problem keys."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/h5_current_mode_relocations_20261107.py').read_text(encoding='utf-8')
source=source.replace('compile_model,Objective,problem_key','compile_model,Objective,problem_key,canonical_digest')
source=source.replace('deadline,clock=time.perf_counter):','deadline,clock=time.perf_counter,cached_trials=None):')
source=source.replace('    assert math.isfinite(deadline)\n',"    assert math.isfinite(deadline)\n    if cached_trials is not None:assert cached_trials['context']==cache_context(library,modes,values,weights,identity,region_data) and len(cached_trials['trials'])==9102\n",1)
insert="""
def cache_context(library,modes,values,weights,identity,region_data):
    return canonical_digest({'library':library,'modes':modes,'values':values,'weights':weights,'identity':identity,'regions':region_data})

def two_distinct(rows):
    result=[];seen=set()
    for row in sorted(rows,key=lambda r:(r['augmented_objective_mm2'],r['center'],r['local_index'])):
        key=tuple(row['center'])
        if key in seen:continue
        seen.add(key);result.append(row)
        if len(result)==2:return result
    raise AssertionError('Two distinct source centers are required')

"""
source=source.replace('class SelectionDeadline(Exception):',insert+'class SelectionDeadline(Exception):')
start=source.index('            angle=point[');end=source.index("            checkpoint('after-mode')",start)
replacement="""            start=len(trials)
            angle=point[model['owners'][i]['angle_coordinate']]/library['angle_scale_mm'] if family=='cog' else 0.
            cached=None
            if cached_trials is not None:
                cached=cached_trials['trials'][start:start+82];first={}
                for local,(row,center,idx) in enumerate(zip(cached,centers,origin)):
                    duplicate=first.get(idx);first.setdefault(idx,start+local)
                    assert row['sequence']==start+local and row['owner']==i and row['mode']==mi and row['local_index']==local and row['center']==center and row['unique_index']==idx and row['duplicate_of']==duplicate
                    assert row['kind']==('clamped' if local==0 else 'grid') and row['grid_index']==(None if local==0 else [(local-1)%9,(local-1)//9])
                    assert all(math.isfinite(row[k]) for k in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2'])
                selected=two_distinct(cached);candidate_centers=[row['center'] for row in selected]
            else:candidate_centers=unique
            candidate_shapes=[owner_shapes(library,family,mi,c,angle) for c in candidate_centers];losses=np.zeros((len(candidate_centers),count));auxiliary=np.zeros_like(losses)
            for level in range(2):
                left=np.asarray([s[level] for s in candidate_shapes],dtype=object);right=np.asarray([s[level] for s in shapes],dtype=object);losses+=shapely.area(shapely.intersection(left[:,None],right[None,:]))
            losses[:,i]=0.
            if i<6:
                for k,center in enumerate(candidate_centers):
                    for j in range(6):
                        if i!=j:auxiliary[k,j]=depth(i,mi,center,j,modes[j],point[2*j:2*j+2])
            affected=[(k,b if a==i else a) for k,(a,b) in enumerate(pairs) if i in (a,b)];scores=[]
            for loss,extra in zip(losses,auxiliary):
                full=baseline.copy();full_aux=baseline_aux.copy()
                for pair,other in affected:
                    full[pair]=loss[other]
                    if i<6 and other<6:full_aux[aux_indices[tuple(sorted((i,other)))]]=extra[other]
                weighted=float(np.dot(weights,full));aux=float(sum(full_aux));scores.append((weighted+aux,weighted,aux))
            if cached is None:
                first={}
                for local,(center,idx) in enumerate(zip(centers,origin)):
                    duplicate=first.get(idx);first.setdefault(idx,len(trials));total,weighted,aux=scores[idx]
                    trials.append({'sequence':len(trials),'owner':i,'mode':mi,'local_index':local,'kind':'clamped' if local==0 else 'grid','grid_index':None if local==0 else [(local-1)%9,(local-1)//9],'center':center,'unique_index':idx,'duplicate_of':duplicate,'augmented_objective_mm2':total,'weighted_area_objective_mm2':weighted,'auxiliary_bracket_depth_mm2':aux})
                selected=two_distinct(trials[start:]);indices_selected=[row['unique_index'] for row in selected]
            else:
                for row,score in zip(selected,scores):
                    assert all(abs(row[field]-actual)<1e-6 for field,actual in zip(['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2'],score))
                trials.extend(cached);indices_selected=[0,1]
            selections.append({'owner':i,'mode':mi,'nominal_trials':len(centers),'unique_centers':len(unique),'selected':selected})
            for row,idx in zip(selected,indices_selected):options[i].append({'owner':i,'mode':mi,'class':cls,'center':row['center'],'shape':candidate_shapes[idx],'losses':losses[idx],'auxiliary':auxiliary[idx]})
            aliases.append({'owner':i,'mode':mi,'class':cls,'representative':mi,'kind':'current_physical_choice' if cls==classes[family][modes[i]] else 'new_physical_choice'})
"""
source=source[:start]+replacement+source[end:]
source=source.replace('len(records)==5911','len(records)==23419')
outputs={'h5_two_center_neighbors_20261107.py':source}
for old,new in [('h5_current_mode_key_choice_20261107.py','h5_two_center_key_choice_20261107.py'),('h5_current_mode_key_readback_20261107.py','h5_two_center_key_readback_20261107.py')]:
    text=(ROOT/'output'/old).read_text(encoding='utf-8').replace('5911','23419').replace('{562:1,33:78,1:2775}','{2179:1,130:78,4:2775}');outputs[new]=text
for name,text in outputs.items():compile(text,name,'exec');assert not (ROOT/'output'/name).exists()
for name,text in outputs.items():
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
