"""Version complete independent score and two-distinct-center membership replay."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/h5_current_mode_selection_readback_20261107.py').read_text(encoding='utf-8').replace('h5_current_mode_key_readback_20261107','h5_two_center_key_readback_20261107')
a=s.index('    expected={()}');b=s.index('    assert len(trials)==9102',a);s=s[:a]+"    assert len(records)==23419\n"+s[b:]
a=s.index('        best=min(rows,');b=s.index("    write('center-score-controls.json'",a)
s=s[:a]+"""        ordered=sorted(rows,key=lambda r:(r['augmented_objective_mm2'],r['center'],r['local_index']));best=[];used=set()
        for row in ordered:
            if tuple(row['center']) in used:continue
            used.add(tuple(row['center']));best.append(row)
            if len(best)==2:break
        assert len(best)==2 and selection['selected']==best and selection['nominal_trials']==82 and selection['unique_centers']==len(first)
        used=set()
        for rank,choice in enumerate(best):
            available=[r for r in rows if tuple(r['center']) not in used];oracle=min(available,key=lambda r:(independent[r['sequence']],r['center'],r['local_index']));gap=independent[choice['sequence']]-independent[oracle['sequence']];assert gap<=tolerance
            if choice['sequence']!=oracle['sequence']:near_ties.append({'kind':'center','rank':rank,'owner':i,'mode':mi,'recorded_sequence':choice['sequence'],'independent_sequence':oracle['sequence'],'independent_score_gap_mm2':gap})
            used.add(tuple(choice['center']))
        chosen_centers[i,mi]=[r['center'] for r in best];position+=82
    owner_options={i:[(i,mi,tuple(center)) for mi in options[i] for center in chosen_centers[i,mi]] for i in range(33)}
    expected={()}|{(option,) for i in range(33) for option in owner_options[i]}|{(a,b) for i,j in combinations(range(33),2) for a,b in product(owner_options[i],owner_options[j])}
    observed={tuple((i,mi,tuple(center)) for (i,mi),center in zip(r['changes'],r['centers'])) for r in records}
    assert len(expected)==len(observed)==len(records)==23419 and expected==observed
"""+s[b:]
s=s.replace('assert center==chosen_centers[i,mi]','assert center in chosen_centers[i,mi]')
s=s.replace("{'bracket/bracket':1500,'bracket/insert':2160,'bracket/cog':900,'insert/insert':594,'insert/cog':540,'cog/cog':105}","{'bracket/bracket':6000,'bracket/insert':8640,'bracket/cog':3600,'insert/insert':2376,'insert/cog':2160,'cog/cog':420}")
s=s.replace("'raw_proposals':5911","'raw_proposals':23419").replace("{'1':2775,'33':78,'562':1}","{'4':2775,'130':78,'2179':1}")
compile(s,'h5_two_center_selection_readback_20261107.py','exec')
with (ROOT/'output/h5_two_center_selection_readback_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
