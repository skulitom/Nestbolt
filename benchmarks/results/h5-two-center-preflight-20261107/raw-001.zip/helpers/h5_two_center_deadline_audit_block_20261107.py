# Validation-only: complete full recalculation must equal the cached construction.
cache={'context':cache_context(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions),'trials':load(Q/'center-trials.json')}
assert load(BASE/'cache-context.json')=={'context':cache['context'],'source_trials_sha256':digest(Q/'center-trials.json'),'original_source_only':True}
before=time.perf_counter();full=neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=before+30);assert full==(records,aliases,trials,selections);full_seconds=time.perf_counter()-before
cache_controls=[]
for case in ['coordinates','modes','weights','library','identity','regions']:
    args=[lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys]
    index={'library':0,'modes':1,'coordinates':2,'weights':3,'identity':4,'regions':5}[case];args[index]=copy.deepcopy(args[index])
    if case=='coordinates':args[index][0]+=1
    elif case=='modes':args[index][0]=(args[index][0]+1)%10
    elif case=='weights':args[index][0]+=.25
    elif case=='library':args[index]['stock_guard_mm']+=.001
    elif case=='identity':args[index]['version']+='-stale'
    elif case=='regions':args[index]['policy']['coefficient']=2.
    try:neighbors(*args,deadline=time.perf_counter()+5,cached_trials=cache)
    except AssertionError:cache_controls.append({'case':case,'rejected':True,'optimizer_calls':0})
    else:raise AssertionError('Stale source cache accepted')
write(OUT/'cache-controls.json',{'passed':True,'full_recalculation_exactly_equal':True,'full_recalculation_seconds':full_seconds,'rejections':cache_controls,'validation_only':True,'optimizer_calls':0})
deadline_controls=[];real_controls=[]
for flavor,cached in [('cached',cache),('full',None)]:
    for expiry in plan['deadline_controls']['neighborhood_expiry_checkpoints']:
        timer=Clock(expiry);before=time.perf_counter()
        try:neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=1.,clock=timer,cached_trials=cached)
        except SelectionDeadline as exc:
            evidence=exc.evidence;check_prefix(evidence);assert timer.calls==expiry;write(OUT/f'{flavor}-neighborhood-deadline-{expiry:05d}.json',evidence)
            deadline_controls.append({'flavor':flavor,'expiry_checkpoint':expiry,'stage':evidence['stage'],'preserved_trials':len(evidence['trials']),'preserved_proposals':len(evidence['records']),'seconds':time.perf_counter()-before,'selected_proposal':None})
        else:raise AssertionError('Partial neighborhood returned normally')
        print(deadline_controls[-1],flush=True)
    before=time.perf_counter();deadline=before+plan['deadline_controls']['real_neighborhood_seconds']
    try:neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=deadline,cached_trials=cached)
    except SelectionDeadline as exc:
        evidence=exc.evidence;check_prefix(evidence);write(OUT/f'{flavor}-neighborhood-deadline-real.json',evidence);real_controls.append({'flavor':flavor,'stage':evidence['stage'],'elapsed_seconds':time.perf_counter()-before,'requested_seconds':.05,'observed_overrun_seconds':evidence['overrun_seconds'],'preserved_trials':len(evidence['trials']),'preserved_proposals':len(evidence['records']),'selected_proposal':None})
    else:raise AssertionError('Real partial neighborhood returned normally')
key_controls=[]
for expiry in plan['deadline_controls']['key_choice_expiry_checkpoints']:
    timer=Clock(expiry)
    try:choose(records,deadline=1.,clock=timer)
    except KeySelectionDeadline as exc:
        evidence=exc.evidence;assert evidence['complete'] is False and evidence['status']=='KEY_SELECTION_DEADLINE' and evidence['selected_proposal'] is None and evidence['optimizer_calls']==0 and timer.calls==expiry
        assert evidence['group_members']==({} if expiry==1 else groups) and evidence['key_minima']==([] if expiry<3 else minima)
        write(OUT/f'key-deadline-{expiry}.json',evidence);key_controls.append({'expiry_checkpoint':expiry,'stage':evidence['stage'],'preserved_keys':len(evidence['group_members']),'preserved_minima':len(evidence['key_minima']),'selected_proposal':None})
    else:raise AssertionError('Partial key grouping returned normally')
write(OUT/'deadline-controls.json',{'passed':True,'neighborhood_synthetic_cases':deadline_controls,'neighborhood_real_cases':real_controls,'key_choice_cases':key_controls,'cooperative_limit':'Stops between complete geometry batches, proposals or grouping stages; one in-progress stage may overrun and is recorded. Windows Job is the outer process/time/memory bound. Interrupted output is retained and never selected.','validation_only':True,'optimizer_calls':0})
