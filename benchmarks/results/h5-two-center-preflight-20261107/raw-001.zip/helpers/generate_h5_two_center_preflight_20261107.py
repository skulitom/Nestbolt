"""Freeze source-cache reuse and independent complete two-center preflight."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
prep=(ROOT/'output/prepare_h5_current_mode_relocations_20261107.py').read_text(encoding='utf-8')
changes={
    'h5_current_mode_relocations_20261107':'h5_two_center_neighbors_20261107',
    'h5_current_mode_key_choice_20261107':'h5_two_center_key_choice_20261107',
    'h5_current_mode_selection_readback_20261107':'h5_two_center_selection_readback_20261107',
    'h5_current_mode_key_readback_20261107':'h5_two_center_key_readback_20261107',
    'audit_h5_current_mode_relocations_20261107':'audit_h5_two_center_preflight_20261107',
    "OUT=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'":"OUT=ROOT/'output/h5-two-center-preflight-20261107';Q=ROOT/'output/h5-current-mode-relocation-preflight-20261107'",
    'h5-best-admissible-augmented-construction-20261107':'h5-current-mode-relocation-construction-20261107',
    'from h5_two_center_neighbors_20261107 import neighbors,apply_neighbor,SelectionDeadline':'from h5_two_center_neighbors_20261107 import neighbors,apply_neighbor,SelectionDeadline,cache_context',
    "'search/epoch-02/closed-problem.json',":"",
    'outcome-diagnostic/neighborhood-coverage.json':'outcome-diagnostic/center-combination-coverage.json',
    "'runtime-bindings.json']]+[A/n":"'runtime-bindings.json','center-trials.json','audit/selection-replay/checks.json','audit/source-domains/checks.json']]+[A/n",
    'for epoch in [0,1,2]':'for epoch in [0,1]',
    "len(closed)==len(keys)==14":"len(closed)==len(keys)==16",
    "'raw_proposals':5911":"'raw_proposals':23419",
    "{'1':2775,'33':78,'562':1}":"{'4':2775,'130':78,'2179':1}",
    "'closed_keys':14":"'closed_keys':16",
    "'deadline_seconds_from_preparation_start':28,'preparation_cap_seconds':30":"'deadline_seconds_from_preparation_start':20,'preparation_cap_seconds':22",
    '[1,4,225,226,3000,6136]':'[1,4,225,226,12000,23644]',
    'deadline=start+28':'deadline=start+20',
    'Recompute every fixed9x9source-grid/clamped trial under the complete528area+15coefficient1auxiliary objective. Score5911raw current/single/joint proposals':'Reuse the exact verified original-source9102trial table, bound to full geometry/state/weights/objective/regions context and with its full consumed cost retained. Keep the first two distinct centers per physical owner/mode by existing score/XY/local-index ranking. Reconstruct selected-center losses and score23419raw current/single/joint combinations',
    'all14closed keys':'all16closed keys',
    "'prior_lineage_cost_retained_despite_full_score_recomputation':True":"'prior_lineage_cost_retained_for_cache_reuse':True,'distinct_centers_per_owner_mode':2",
    "'complete_prior_preparation_seconds':load(Q/'audit/checks.json')['complete_preparation_seconds']":"'complete_prior_preparation_seconds':load(Q/'audit/checks.json')['complete_preparation_seconds']",
}
for a,b in changes.items():assert a in prep,a;prep=prep.replace(a,b)
prep=prep.replace("try:\n    records,aliases,trials,selections=neighbors", "cache={'context':cache_context(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions),'trials':load(Q/'center-trials.json')};assert load(Q/'audit/selection-replay/checks.json')['passed'] and load(Q/'audit/source-domains/checks.json')['passed'];write(OUT/'cache-context.json',{'context':cache['context'],'source_trials_sha256':digest(Q/'center-trials.json'),'original_source_only':True})\ntry:\n    records,aliases,trials,selections=neighbors")
prep=prep.replace('regions,keys,deadline=start+20)','regions,keys,deadline=start+20,cached_trials=cache)')

audit=(ROOT/'output/audit_h5_current_mode_relocations_20261107.py').read_text(encoding='utf-8')
changes={
    'h5_current_mode_relocations_20261107':'h5_two_center_neighbors_20261107',
    'h5_current_mode_key_choice_20261107':'h5_two_center_key_choice_20261107',
    'h5_current_mode_selection_readback_20261107':'h5_two_center_selection_readback_20261107',
    "BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107';OUT=BASE/'audit';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-two-center-preflight-20261107';OUT=BASE/'audit';Q=ROOT/'output/h5-current-mode-relocation-preflight-20261107'",
    'h5-current-mode-relocation-preparation-process-20261107':'h5-two-center-preparation-process-20261107',
    'from h5_two_center_neighbors_20261107 import neighbors,SelectionDeadline':'from h5_two_center_neighbors_20261107 import neighbors,SelectionDeadline,cache_context',
    'for epoch in [0,1,2]':'for epoch in [0,1]',
    'len(closed)==14':'len(closed)==16',
    'len(keys)==14':'len(keys)==16',
    "'closed_keys':14":"'closed_keys':16",
    "'key-minima.json','runtime-bindings.json'":"'key-minima.json','runtime-bindings.json','cache-context.json'",
    'all9102nominal original-source center scores and5911complete proposals':'all9102nominal original-source center scores and23419complete proposals',
    'all2854key minima and strict ranking':'both distinct center ranks, all2854key minima and strict ranking',
    'Read every owner-mode model and source grid placement with holes, stock and fixed parts.':'Read every selected owner-mode-center model; bind exact inherited original-source grid placements, holes, stock and fixed-part controls. Verify cached and full calculation equality and stale-cache rejection.',
    'Validate six synthetic neighborhood deadlines, one real deadline, four key-grouping deadlines':'Validate six synthetic and one real neighborhood deadline in each cached/full path, plus four key-grouping deadlines',
}
for a,b in changes.items():assert a in audit,a;audit=audit.replace(a,b)
old="domains=verify_domains(load(JOB),lib,initial['modes'],initial['values'],trials,OUT/'source-domains')"
new="""assert trials==load(Q/'center-trials.json') and aliases==load(Q/'owner-aliases.json')
domains=load(Q/'audit/source-domains/checks.json');assert domains['passed'] and domains['nominal_centers']==9102
write(OUT/'inherited-source-domains.json',{'passed':True,'original_source_state_unchanged':True,'all_trial_bytes_semantically_equal':True,'controls':domains,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Q/'plan.json',Q/'audit/source-domains/checks.json',Q/'audit/source-domains/grid-source-checks.json',Q/'audit/source-domains/fixed-source-checks.json',Q/'center-trials.json',A/'library.json',A/'initial-state.json',JOB]}})
inputs.append(OUT/'inherited-source-domains.json')"""
assert old in audit;audit=audit.replace(old,new)
a=audit.index('model_rows=[]');b=audit.index("chosen=selected['accepted_choice']",a)
audit=audit[:a]+"""model_rows=[]
for control in selections:
    for rank,choice in enumerate(control['selected']):
        owner,mode=control['owner'],control['mode'];modes=initial['modes'].copy();values=initial['values'].copy();modes[owner]=mode;values[2*owner:2*owner+2]=choice['center'];model=compile_model(lib,modes,values,initial['pair_weights'],identity)
        assert verify(model,lib,modes,values,initial['pair_weights'],identity)
        model_rows.append({'owner':owner,'mode':mode,'center_rank':rank,'model_sha256':sha256(json.dumps(model,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),'selected_center':choice['center'],'bounds':model['bounds'],'parameters':model['parameters'],'passed':True})
assert len(model_rows)==222;write(OUT/'owner-mode-model-controls.json',model_rows)
"""+audit[b:]
a=audit.index('deadline_controls=[]');b=audit.index('policies=[];',a)
controls=(ROOT/'output/h5_two_center_deadline_audit_block_20261107.py').read_text(encoding='utf-8');audit=audit[:a]+controls+'\n'+audit[b:]
audit=audit.replace("'deadline_controls':len(deadline_controls)+len(key_controls)+1","'deadline_controls':len(deadline_controls)+len(key_controls)+len(real_controls),'cache_rejection_controls':len(cache_controls),'source_domain_controls_reused':True")
audit=audit.replace("z.name in ['plan.json','opened.json','plan-v2.json']","z.name in ['plan.json','opened.json','plan-v2.json','inherited-source-domains.json']")
stage=(ROOT/'output/run_h5_current_mode_relocations_stage_20261107.py').read_text(encoding='utf-8').replace('h5-current-mode-relocation-','h5-two-center-').replace('prepare_h5_current_mode_relocations_20261107.py','prepare_h5_two_center_preflight_20261107.py').replace('audit_h5_current_mode_relocations_20261107.py','audit_h5_two_center_preflight_20261107.py').replace("20261107.py',30)","20261107.py',22)")
outputs={'prepare_h5_two_center_preflight_20261107.py':prep,'audit_h5_two_center_preflight_20261107.py':audit,'run_h5_two_center_stage_20261107.py':stage}
for name,text in outputs.items():compile(text,name,'exec');assert not (ROOT/'output'/name).exists()
for name,text in outputs.items():
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
