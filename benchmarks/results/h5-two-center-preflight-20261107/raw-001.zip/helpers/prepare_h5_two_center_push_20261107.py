"""Prepare an ordinary push for the closed construction and two-center preflight."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_current_mode_construction_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-current-mode-construction-main-sync-20261107':'h5-two-center-main-sync-20261107',
    "prefixes=('benchmarks/results/h5-current-mode-relocation-construction-20261107',)":"prefixes=('benchmarks/results/h5-current-mode-relocation-construction-20261107','benchmarks/results/h5-two-center-preflight-20261107')",
    "['h5-current-mode-relocation-construction-20261107']":"['h5-current-mode-relocation-construction-20261107','h5-two-center-preflight-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
compile(source,'push_h5_two_center_checkpoints_20261107.py','exec')
with (ROOT/'output/push_h5_two_center_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
