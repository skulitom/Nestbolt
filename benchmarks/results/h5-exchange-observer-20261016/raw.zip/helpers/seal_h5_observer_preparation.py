"""Archive matched observers and the rejected cached binary before the pilot."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PROBE=ROOT/'output/h5-exchange-probe'
OUT=ROOT/'benchmarks/results/h5-exchange-observer-20261016'
assert not OUT.exists()
OUT.mkdir()
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
baseline=load(PROBE/'observer-build-baseline-v1.json')
candidate=load(PROBE/'observer-build-candidate-v2.json')
assert baseline['exit_code']==candidate['exit_code']==0 and candidate['fresh_target']
assert baseline['driver_sha256']==candidate['driver_sha256']
assert baseline['binary_sha256']!=candidate['binary_sha256']
assert digest(PROBE/'nestbolt-baseline-exchange-observer.exe')==baseline['binary_sha256']
assert digest(PROBE/'nestbolt-candidate-exchange-observer-v2.exe')==candidate['binary_sha256']
observer=load(PROBE/'observer-checks-v1.json')
assert observer['all_checks_pass'] and len(observer['records'])==8
original=load(PROBE/'baseline.json')
changed=[]
for row in original['files']:
    assert digest(ROOT/row['path'])==row['sha256']
    assert digest(PROBE/'baseline-workspace'/row['path'])==row['sha256']
    if digest(PROBE/'workspace'/row['path'])!=row['sha256']:
        changed.append(row['path'])
assert changed==['crates/core/src/sheets.rs','crates/core/src/sheets/vstrip.rs']
sys.path.insert(0,str(ROOT/'scripts'))
import h4_preview_matrix as h4
rows,_,_=h4.cases()
assert h4.guards(rows)==load(ROOT/'benchmarks/results/h4-preview-development-20261016/plan.json')['guards']

command=[sys.executable,str(ROOT/'output/ccd1.py'),sys.executable,'-m','unittest','discover','-s','scripts','-p','test_h5_exchange_pilot.py','-v']
with (OUT/'runner-tests.log').open('wb') as stream:
    result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
assert result.returncode==0
write(OUT/'runner-tests.json',{'command':command,'exit_code':result.returncode,'tests_passed':5})

members={}
def include(path,name):
    assert name not in members
    members[name]=path
for path in sorted((PROBE/'baseline-workspace').rglob('*')):
    if path.is_file(): include(path,path.relative_to(PROBE).as_posix())
for name in changed+['crates/core/src/sheets/vstrip/exchange.rs','crates/core/examples/exchange_probe.rs']:
    include(PROBE/'workspace'/name,'candidate-source/'+name)
for path in sorted(PROBE.glob('observer*')):
    if path.is_file(): include(path,path.name)
    elif path.is_dir():
        for p in sorted(path.rglob('*')):
            if p.is_file(): include(p,p.relative_to(PROBE).as_posix())
for path in sorted((PROBE/'public-work-v7').rglob('*')):
    if path.is_file(): include(path,path.relative_to(PROBE).as_posix())
for name in ['baseline.json','driver-preparation.json','exchange_probe.rs',
             'nestbolt-baseline-exchange-observer.exe','nestbolt-candidate-exchange-observer.exe',
             'nestbolt-candidate-exchange-observer-v2.exe']:
    include(PROBE/name,name)
for name in ['prepare_h5_exchange_drivers.py','build_h5_exchange_drivers.py','rebuild_h5_candidate_observer.py',
             'check_h5_exchange_observers.py','seal_h5_observer_preparation.py','ccd1.py']:
    include(ROOT/'output'/name,'helpers/'+name)
for name in ['h5_exchange_pilot.py','test_h5_exchange_pilot.py']:
    include(ROOT/'scripts'/name,'scripts/'+name)
checks={'scope':__doc__,'production_source_unchanged':True,'current_H4_guards_unchanged':True,
    'baseline_build':baseline,'candidate_build':candidate,'public_CLI_agreement':observer,
    'candidate_product_changes':changed+['crates/core/src/sheets/vstrip/exchange.rs'],
    'identical_observer_source_sha256':baseline['driver_sha256'],
    'rejected_shared_target_candidate_preserved':True,'measurement_started':False,
    'held_out_geometry_read':False,'runner_tests_passed':5,
    'previous_functional_evidence_archive': 'benchmarks/results/h5-directed-exchange-functional-20261016/raw.zip',
    'previous_functional_evidence_sha256':digest(ROOT/'benchmarks/results/h5-directed-exchange-functional-20261016/raw.zip')}
write(OUT/'checks.json',checks)
for path in [OUT/'checks.json',OUT/'runner-tests.log',OUT/'runner-tests.json']:
    include(path,path.name)
archive=OUT/'raw.zip'
inventory={name:{'sha256':digest(path),'bytes':path.stat().st_size} for name,path in members.items()}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in members.items(): z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,expected in inventory.items():
        raw=z.read(name)
        assert len(raw)==expected['bytes'] and sha256(raw).hexdigest()==expected['sha256']
write(OUT/'integrity.json',{'archive_sha256':digest(archive),'bytes':archive.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
print(json.dumps({'folder':str(OUT),'members':len(inventory),'bytes':archive.stat().st_size,'archive_sha256':digest(archive)},indent=2))
