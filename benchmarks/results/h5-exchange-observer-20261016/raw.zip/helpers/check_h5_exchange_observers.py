"""Check observer/CLI agreement on authored fixed-work inputs on CCD1."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import traceback

import psutil

ROOT=Path(__file__).resolve().parents[1]
PROBE=ROOT/'output/h5-exchange-probe'
OUT=PROBE/'observer-checks-v1'
INPUT=PROBE/'public-work-v7'
CLI=PROBE/'nestbolt-baseline.exe'
BINARIES={'baseline':PROBE/'nestbolt-baseline-exchange-observer.exe',
          'candidate':PROBE/'nestbolt-candidate-exchange-observer-v2.exe'}
assert not OUT.exists()
OUT.mkdir()
psutil.Process().cpu_affinity(list(range(16,32)))
records=[]

def load(path): return json.loads(path.read_bytes())
def write(path,data): path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(command,name):
    result=subprocess.run(list(map(str,command)),capture_output=True,timeout=60)
    (OUT/(name+'-stdout.json')).write_bytes(result.stdout)
    (OUT/(name+'-stderr.log')).write_bytes(result.stderr)
    write(OUT/(name+'-command.json'),{'command':list(map(str,command)),'exit_code':result.returncode})
    assert result.returncode==0,(name,result.stderr.decode(errors='replace'))
    return result

try:
    for seed in [0,1]:
        for mode in ['normal','common']:
            for arm,binary in BINARIES.items():
                name=f'{arm}-{mode}-s{seed}'
                folder=OUT/name
                run([binary,INPUT/'library.json',INPUT/(mode+'.json'),folder,3,seed,'work'],name)
                result=load(folder/'search.json')
                assert result['repeatable'] and result['validation']['valid']
                if mode=='common' and arm=='baseline':
                    reference=OUT/f'cli-baseline-common-s{seed}'
                    run([CLI,'nest','--library',INPUT/'library.json','--request',INPUT/'common.json',
                         '--out-dir',reference,'--seconds',3,'--seed',seed,'--repeatable','--time-limit',30],reference.name)
                else:
                    label='first' if mode=='common' else arm
                    reference=INPUT/f'{mode}-s{seed}-{label}'
                assert load(folder/'layout.json')==load(reference/'layout.json'), 'Observer changed layout from CLI'
                assert load(folder/'job.json')==load(reference/'job.json')
                assert result['validation']==load(reference/'report.json')['validation']
                checked=run([CLI,'validate','--library',INPUT/'library.json','--request',INPUT/(mode+'.json'),
                             '--layout',folder/'layout.json'],name+'-validate')
                assert json.loads(checked.stdout)['valid']
                if mode=='common': assert result['riders']==0
                records.append({'seed':seed,'mode':mode,'arm':arm,'binary_sha256':sha256(binary.read_bytes()).hexdigest(),
                    'exact_CLI_layout_and_metrics':True,'independently_valid':True,'stats':result['stats'],
                    'riders':result['riders']})
                write(PROBE/'observer-check-progress-v1.json',records)
    result={'all_checks_pass':True,'scope':__doc__,'observer_runs':8,'additional_baseline_CLI_runs':2,
            'held_out_geometry_read':False,'performance_measurement':False,'records':records}
except BaseException:
    write(PROBE/'observer-check-failure-v1.json',{'error':traceback.format_exc(),'records':records})
    raise
write(PROBE/'observer-checks-v1.json',result)
print(json.dumps({'all_checks_pass':True,'observer_runs':8,'additional_baseline_CLI_runs':2,
    'candidate_exchange_attempts':[r['stats'].get('directed_exchange_attempts',0) for r in records if r['arm']=='candidate']}))
