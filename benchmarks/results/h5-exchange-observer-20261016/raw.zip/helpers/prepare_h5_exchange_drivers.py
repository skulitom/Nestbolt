"""Prepare matched observation drivers without editing production sources."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parents[1]
out=root/'output/h5-exchange-probe'
baseline=out/'baseline-workspace'
candidate=out/'workspace'
assert not baseline.exists()
files=json.loads((out/'baseline.json').read_bytes())['files']
for row in files:
    source=root/row['path']
    assert sha256(source.read_bytes()).hexdigest()==row['sha256']
    target=baseline/row['path']; target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
driver=out/'exchange_probe.rs'
for workspace in [baseline,candidate]:
    target=workspace/'crates/core/examples/exchange_probe.rs'
    assert not target.exists()
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(driver,target)
(out/'driver-preparation.json').write_text(json.dumps({
    'scope': 'Matched observer around public request.prepare/PreparedRequest.optimize; counters after search',
    'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'production_files':files,'driver_sha256':sha256(driver.read_bytes()).hexdigest(),
    'candidate_extra_source':'crates/core/examples/exchange_probe.rs',
    'root_unchanged':True,'measured_search_started':False},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared identical driver in baseline/candidate isolated workspaces.')
