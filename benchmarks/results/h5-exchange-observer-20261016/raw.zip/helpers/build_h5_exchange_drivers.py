"""Build and pin both matched drivers on CCD1; never replace measured engines."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
out=root/'output/h5-exchange-probe'
for arm,workspace in [('baseline','baseline-workspace'),('candidate','workspace')]:
    log=out/f'observer-build-{arm}-v1.log'
    assert not log.exists()
    command=[sys.executable,str(root/'output/ccd1.py'),'cargo','build','--release','-p','nestbolt-core',
             '--example','exchange_probe','--locked','--target-dir',str(root/'output/ci-curve-probe/target')]
    started=datetime.now(timezone.utc).isoformat()
    with log.open('wb') as stream:
        result=subprocess.run(command,cwd=out/workspace,stdout=stream,stderr=subprocess.STDOUT)
    record={'arm':arm,'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
            'exit_code':result.returncode,'driver_sha256':sha256((out/workspace/'crates/core/examples/exchange_probe.rs').read_bytes()).hexdigest()}
    if result.returncode==0:
        target=out/f'nestbolt-{arm}-exchange-observer.exe'
        assert not target.exists()
        shutil.copyfile(root/'output/ci-curve-probe/target/release/examples/exchange_probe.exe',target)
        record['binary_sha256']=sha256(target.read_bytes()).hexdigest()
    (out/f'observer-build-{arm}-v1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(record),flush=True)
    if result.returncode:
        print(log.read_text(encoding='utf-8',errors='replace')[-8000:])
        raise SystemExit(result.returncode)
