"""Reject the shared-target observer result; build candidate in a fresh target."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
out=root/'output/h5-exchange-probe'
base=json.loads((out/'observer-build-baseline-v1.json').read_bytes())
old=json.loads((out/'observer-build-candidate-v1.json').read_bytes())
assert base['binary_sha256']==old['binary_sha256']
differences=[]
for name in ['crates/core/src/sheets.rs','crates/core/src/sheets/vstrip.rs']:
    assert (out/'baseline-workspace'/name).read_bytes()!=(out/'workspace'/name).read_bytes()
    differences.append(name)
diagnosis={'scope':'Pre-measurement provenance failure, no performance trials started',
    'rejected_result':'observer-build-candidate-v1.json',
    'reason':'Shared Cargo target returned identical baseline/candidate executables despite distinct source; candidate build did not recompile the changed core.',
    'source_differences':differences+['crates/core/src/sheets/vstrip/exchange.rs'],
    'original_results_preserved':True,'remedy':'Fresh candidate-only target directory; preserve v1 artifacts.'}
(out/'observer-cache-failure.json').write_text(json.dumps(diagnosis,indent=2)+'\n',encoding='utf-8',newline='\n')
target=root/'output/h5-exchange-observer-candidate-target'
assert not target.exists()
command=[sys.executable,str(root/'output/ccd1.py'),'cargo','build','--release','-p','nestbolt-core',
    '--example','exchange_probe','--locked','--target-dir',str(target)]
started=datetime.now(timezone.utc).isoformat()
with (out/'observer-build-candidate-v2.log').open('xb') as stream:
    result=subprocess.run(command,cwd=out/'workspace',stdout=stream,stderr=subprocess.STDOUT)
record={'arm':'candidate','command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
    'exit_code':result.returncode,'fresh_target':True,'driver_sha256':sha256((out/'workspace/crates/core/examples/exchange_probe.rs').read_bytes()).hexdigest()}
if result.returncode==0:
    binary=out/'nestbolt-candidate-exchange-observer-v2.exe'
    assert not binary.exists()
    shutil.copyfile(target/'release/examples/exchange_probe.exe',binary)
    record['binary_sha256']=sha256(binary.read_bytes()).hexdigest()
    assert record['binary_sha256']!=base['binary_sha256'], 'Candidate still matches baseline despite changed code'
(out/'observer-build-candidate-v2.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record),flush=True)
raise SystemExit(result.returncode)
