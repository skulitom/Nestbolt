"""Independent source transforms, conservative covers, controls and envelope bound."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-row-covers-20261028';OUT=BASE/'geometry-audit';STUDY=ROOT/'output/h5-rational-source-20261028/row-cover-study';CORE=ROOT/'output/h5-mixed26-height-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');blocks=load(BASE/'blocks39.json');short=load(BASE/'short15.json');oldmodes=load(CORE/'modes.json')
assert len(modes)==13 and Counter(m['family'] for m in modes)=={'frame':2,'bracket':8,'insert':2,'cog-row':1}
assert blocks==load(STUDY/'first39-blocks.json') and short==load(STUDY/'short15.json') and not plan['common_line_part_in_hole']
keys=[(r['part_id'],r['copy_index']) for r in short]
for b in blocks:keys += [('cog',i) for i in b['copy_indices']] if b['family']=='cog-row' else [(b['family'],b['copy_index'])]
assert len(keys)==len(set(keys))==66 and set(keys)=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
radius=plan['required_source_gap_mm']/2/math.cos(math.pi/64)+1e-7;mode_checks=[];pairs=0
for m in modes:
    rects=m['cover_rectangles_um'];cover=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rects]);sources=[]
    instances=m['source_instances'] if m['family']=='cog-row' else [{'part_id':m['family'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}]
    for r in instances:
        p=parts[r['part_id']];a=r['angle'];c,s=math.cos(a),math.sin(a);sign=-1 if r['mirrored'] else 1;ox,oy=r['translation'];g=Polygon([(sign*x*c-y*s+ox,sign*x*s+y*c+oy) for x,y in p['geometry'][0]['outer']]);assert cover.covers(g.buffer(radius,quad_segs=16));sources.append(g)
    source=unary_union(sources);assert max(abs(a-b) for a,b in zip(source.bounds,m['source_bounds_mm']))<1e-9
    if m['family']!='cog-row':
        old=oldmodes[m['old_mode']];assert rects==old['expanded_rectangles_um'] and m['family']==old['family'] and m['quarter']==old['quarter'] and m['mirrored']==old['mirrored']
    else:assert m['source_instances']==load(STUDY/'row-mode.json')['source_instances'] and rects==load(STUDY/'row-mode.json')['cover_rectangles_um']
    for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    sb,cb=source.bounds,cover.bounds;overhang=[sb[0]-cb[0],sb[1]-cb[1],cb[2]-sb[2],cb[3]-sb[3]];assert max(overhang)<=.114
    for axis in [0,1]:
        low=math.ceil(6513-m['source_bounds_mm'][axis]*1000);high=math.floor([1493487,2993487][axis]-m['source_bounds_mm'][axis+2]*1000)
        assert low+min(r[axis] for r in rects)>=6399 and high+max(r[axis+2] for r in rects)<=[1493601,2993601][axis]
    mode_checks.append({'mode':m['id'],'source_originals':len(sources),'cover_components':len(rects),'max_overhang_mm':max(overhang),'required_clearance_discs_covered':True})
write(OUT/'mode-checks.json',mode_checks)
checks=[]
for name,expected_valid,count in [('control-source51',True,51),('negative-source66',False,66)]:
    rows=load(BASE/(name+'.json'));expected=[(r['part_id'],r['copy_index']) for r in rows];r=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert r['valid']==expected_valid and len(rows)==count and not r['stock_failures'];write(OUT/(name+'.json'),r);checks.append({'name':name,'originals':count,'pairs':r['same_sheet_pairs'],'collisions':len(r['pair_failures']),'holes':r['cutouts'],'hole_vertices':r['hole_vertices']})
control=load(BASE/'control.json');rectangles=[]
for p in control:
    m=modes[p['mode']];x,y=p['anchor_um'];rectangles += [[a+x,b+y,c+x,d+y] for a,b,c,d in m['cover_rectangles_um']]
for a,b in combinations(rectangles,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
assert len(control)==28 and len(rectangles)==145
# Recheck the saved exact section weights for this larger cover envelope.
widths=load(STUDY/'section-bound/widths.json');cert=load(STUDY/'section-bound/certificate.json');weights=[F(*v) for v in cert['width_weights']];families=['frame','frame','insert','insert','bracket','bracket','bracket'];caps={'frame':18,'bracket':6,'insert':12};patterns=[]
assert 2*min(widths[8:])>1487202
def visit(k,chosen):
    used=sum(n*w for n,w in zip(chosen,widths))
    if k==8:
        patterns.append(chosen+[-1])
        for j,w in enumerate(widths[8:]):
            if used+w<=1487202:patterns.append(chosen+[j])
        return
    f=families[k];used_family=sum(n for n,other in zip(chosen,families) if f==other)
    for n in range(min((1487202-used)//widths[k],caps[f]-used_family)+1):visit(k+1,chosen+[n])
visit(0,[]);maximum=max(sum(n*w for n,w in zip(p[:8],weights[:8]))+(weights[8+p[8]] if p[8]>=0 else 0) for p in patterns);assert maximum>0
span=F(*cert['span_lower_um'])/maximum;write(OUT/'envelope-section-bound.json',{'cover_envelope_width_um':1487202,'cover_envelope_height_um':2987202,'patterns':len(patterns),'maximum_saved_weight':[maximum.numerator,maximum.denominator],'normalization_applied':maximum!=1,'span_lower_um':[span.numerator,span.denominator],'span_lower_mm':float(span/1000),'slack_mm':float((2987202-span)/1000),'cover_model_excluded':span>2987202,'original_source_feasibility_excluded':False,'linear_programs':0})
write(OUT/'envelope-patterns.json',patterns);assert span<=2987202
inputs=[BASE/n for n in ['plan.json','modes.json','blocks39.json','short15.json','control.json','control-source51.json','negative.json','negative-source66.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'modes_verified':len(modes),'same_owner_rectangle_pairs':pairs,'source_stock_and_cover_envelope_verified':True,'cover_bounds_um':plan['cover_bounds_um'],'x_capacity_um':2987202,'y_capacity_um':1487202,'all66_originals_accounted_once':True,'positive_control_originals':51,'control_blocks':28,'control_cover_components':145,'control_cover_pairs':len(rectangles)*(len(rectangles)-1)//2,'control_missing_originals':15,'control_missing_blocks':11,'negative_control_originals':66,'source_cases':checks,'envelope_section_patterns':len(patterns),'envelope_span_lower_mm':float(span/1000),'envelope_slack_mm':float((2987202-span)/1000),'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
