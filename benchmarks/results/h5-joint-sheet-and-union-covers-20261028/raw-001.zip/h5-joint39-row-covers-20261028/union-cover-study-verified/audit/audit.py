"""Independent original-triangle expansion, cover partition and stagger control proof."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-row-covers-20261028';STUDY=BASE/'union-cover-study-verified';OUT=STUDY/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(STUDY/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
old=load(BASE/'modes.json');modes=load(STUDY/'modes.json');assert modes[:-1]==old[:-1]
newrow=dict(modes[-1]);oldrow=dict(old[-1]);rects=newrow.pop('cover_rectangles_um');oldrects=oldrow.pop('cover_rectangles_um');assert newrow==oldrow
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');cover=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rects]);hullcover=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in oldrects]);assert cover.difference(hullcover).area==load(STUDY/'prepared.json')['cover_outside_old_hull_mm2']
triangles=0;source_polys=[];expanded=[];plan=load(BASE/'plan.json');radius=plan['required_source_gap_mm']/2/math.cos(math.pi/64)+1e-7
for r in newrow['source_instances']:
    c,s=math.cos(r['angle']),math.sin(r['angle']);x,y=r['translation'];g=Polygon([(c*a-s*b+x,s*a+c*b+y) for a,b in part['geometry'][0]['outer']]);source_polys.append(g);assert cover.covers(g.buffer(radius,quad_segs=16))
    tris=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(tris).equals(g)
    for tri in tris:
        square=MultiPoint([(x+dx,y+dy) for x,y in list(tri.exterior.coords)[:-1] for dx in [-.112,.112] for dy in [-.112,.112]]).convex_hull;assert cover.covers(square);expanded.append(square);triangles+=1
geometry=load(STUDY/'row-geometry.json');assert cover.equals(shape(geometry['cover'])) and unary_union(source_polys).equals(shape(geometry['source_union'])) and unary_union(expanded).symmetric_difference(shape(geometry['expanded_union'])).area<1e-8
for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
proof=load(STUDY/'row-separation.json');dy=proof['chosen_adjacent_dy_um'];verified={}
for dx in [80000,-80000,0]:
    needed=0
    for a in rects:
        for b in rects:
            if max(a[0],b[0]+dx)<min(a[2],b[2]+dx):needed=max(needed,a[3]-b[1])
    verified[dx]=needed
assert verified[80000]==proof['max_upward_separation_plus80_um'] and verified[-80000]==proof['max_upward_separation_minus80_um'] and verified[0]==proof['max_upward_separation_zero_um'] and dy>max(verified[80000],verified[-80000]) and 2*dy>verified[0]
blocks=load(BASE/'blocks39.json');control=load(STUDY/'control29.json');source=load(STUDY/'source56.json');allrects=[]
for p in control:
    b=blocks[p['block']];m=modes[p['mode']];x,y=p['anchor_um'];allrects.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in m['cover_rectangles_um']]);expected=m['source_instances'] if b['family']=='cog-row' else [{'part_id':b['family'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}];copies=b['copy_indices'] if b['family']=='cog-row' else [b['copy_index']]
    for r,copy in zip(expected,copies):
        saved=next(s for s in source if s['part_id']==r['part_id'] and s['copy_index']==copy);assert saved['sheet_id']=='sheet-0' and saved['transform']['rotation_radians']==r['angle'] and saved['transform']['mirrored']==r['mirrored'] and max(abs(a-b) for a,b in zip(saved['transform']['translation'],[x/1000+r['translation'][0],y/1000+r['translation'][1]]))<1e-9
control_pairs=0
for a,b in combinations(allrects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];control_pairs+=1
r=audit(job,source,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],[(p['part_id'],p['copy_index']) for p in source]);assert r==load(STUDY/'source56-audit.json') and r['valid'] and len(source)==56 and r['cutouts']==74 and r['hole_vertices']==8074
prepared=load(STUDY/'prepared.json');new_area=sum((c-a)*(d-b) for a,b,c,d in rects);old_area=sum((c-a)*(d-b) for a,b,c,d in oldrects);assert new_area<old_area and prepared['new_union_components_per_row']==len(rects) and prepared['area_reduction_all3_rows_mm2']==3*(old_area-new_area)/1e6
inputs=[STUDY/n for n in ['plan.json','modes.json','row-geometry.json','row-separation.json','control29.json','source56.json','source56-audit.json','prepared.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});result={'passed':True,'seconds':time.perf_counter()-started,'original_cogs_per_row':5,'independent_triangle_square_hulls':triangles,'new_union_components_per_row':len(rects),'cover_subset_of_old_hull':hullcover.covers(cover),'cover_outside_old_hull_mm2':cover.difference(hullcover).area,'whole_source_clearance_covered':True,'source_holes_reserved':True,'new_cover_area_per_row_mm2':new_area/1e6,'area_reduction_all3_rows_mm2':3*(old_area-new_area)/1e6,'row_dy_mm':dy/1000,'control_originals':56,'control_missing_originals':10,'source_pairs':r['same_sheet_pairs'],'source_holes':r['cutouts'],'source_hole_vertices':r['hole_vertices'],'control_cover_components':len(allrects),'control_cover_pairs':control_pairs,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
