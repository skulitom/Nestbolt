"""Study tighter covers of the actual five-cog union, preserving rigid source rows."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,mapping
from shapely.ops import unary_union
from h5_outer_cover_geometry_20261028 import square_expand,slab_cover,rectangle_union
from h5_joint39_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-row-covers-20261028';OUT=BASE/'union-cover-study-verified';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'study.py');started=time.perf_counter();assert load(BASE/'search/result.json')['closed'] and load(BASE/'response-audit/checks.json')['passed'];job=load(JOB);modes=load(BASE/'modes.json');old=modes[-1];part=next(p for p in job['parts'] if p['id']=='cog');sources=[];expanded=[]
for r in old['source_instances']:
    c,s=math.cos(r['angle']),math.sin(r['angle']);x,y=r['translation'];outer=[(c*a-s*b+x,s*a+c*b+y) for a,b in part['geometry'][0]['outer']];sources.append(Polygon(outer));expanded.append(square_expand(outer,.112))
joined=unary_union(expanded);rects,slabs=slab_cover(joined,5000);cover=rectangle_union(rects);hullcover=rectangle_union(old['cover_rectangles_um']);assert cover.covers(joined)
new={**old,'cover_rectangles_um':rects};modes[-1]=new;write(OUT/'modes.json',modes);write(OUT/'row-geometry.json',{'source_union':mapping(unary_union(sources)),'expanded_union':mapping(joined),'cover':mapping(cover),'slabs':slabs,'cover_rectangles_um':rects})
def separation(dx):
    terms=[a[3]-b[1] for a in rects for b in rects if a[0]<b[2]+dx and b[0]+dx<a[2]];assert terms;return max(terms)
positive=separation(80000);negative=separation(-80000);zero=separation(0);dy=max(positive,negative,(zero+1)//2)+1
blocks=load(BASE/'blocks39.json');control=[p for p in load(BASE/'control.json') if blocks[p['block']]['family']!='cog-row']
owners=[i for i,b in enumerate(blocks) if b['family']=='cog-row']
for i,x,y in zip(owners,[6700,86700,6700],[2160000,2160000+dy,2160000+2*dy]):control.append({'block':i,'mode':new['id'],'anchor_um':[x,y]})
rows,error=reconstruct(job,blocks,modes,control,load(BASE/'short15.json'));plan=load(BASE/'plan.json');source=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);write(OUT/'control29.json',control);write(OUT/'source56.json',rows);write(OUT/'source56-audit.json',source)
allrects=[]
for p in control:
    x,y=p['anchor_um'];allrects.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in modes[p['mode']]['cover_rectangles_um']])
failures=sum(not(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]) for a,b in combinations(allrects,2));write(OUT/'row-separation.json',{'row_x_offsets_um':[0,80000,0],'max_upward_separation_plus80_um':positive,'max_upward_separation_minus80_um':negative,'max_upward_separation_zero_um':zero,'chosen_adjacent_dy_um':dy,'nonadjacent_separation_um':2*dy,'exact_control_cover_collisions':failures,'control_cover_components':len(allrects)})
new_area=sum((c-a)*(d-b) for a,b,c,d in rects);old_area=sum((c-a)*(d-b) for a,b,c,d in old['cover_rectangles_um']);orth_area=sum(sum((c-a)*(d-b) for a,b,c,d in next(m for m in modes if m['family']==b['family'])['cover_rectangles_um']) for b in blocks if b['family']!='cog-row');inputs=[JOB,BASE/'plan.json',BASE/'modes.json',BASE/'blocks39.json',BASE/'short15.json',BASE/'control.json',BASE/'search/result.json',BASE/'response-audit/checks.json',BASE/'union-cover-study/study.py',BASE/'union-cover-study/failure-diagnosis.json',BASE/'union-cover-study/diagnose.py',ROOT/'output/h5_outer_cover_geometry_20261028.py',ROOT/'output/h5_joint39_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Geometry study only. Preserve each exact five-cog rigid source row but replace its convex-hull cover with a5mm slab cover of the union of112um square-expanded original filled cog outers. No source holes are freed. Derive an exact safe upward row separation for the predetermined0/80/0mm X-offset packet from all intersecting-X cover rectangles, then check all source56 originals and cover pairs. This cover has smaller area but is not an exact subset of the old slab cover: floating source reconstruction shifts the first slab grid by1um. The failed subset assumption and0.209406mm2 outside area are preserved separately. Full-source clearance coverage remains mandatory; no source geometry or acceptance margin is relaxed. This is a new geometry construction, not a restart of the closed hull-cover model. No new packing model or solver is created here.','slab_width_um':5000,'pad_um':112,'solver_calls':0})
result={'seconds':time.perf_counter()-started,'old_hull_components_per_row':len(old['cover_rectangles_um']),'new_union_components_per_row':len(rects),'old_hull_area_per_row_mm2':old_area/1e6,'new_union_area_per_row_mm2':new_area/1e6,'area_reduction_all3_rows_mm2':3*(old_area-new_area)/1e6,'first_sheet_cover_area_mm2':(orth_area+3*new_area)/1e6,'cover_subset_of_old_hull':hullcover.covers(cover),'cover_outside_old_hull_mm2':cover.difference(hullcover).area,'source56_valid':source['valid'],'source56_collisions':source['pair_failures'],'source56_stock_failures':source['stock_failures'],'control_cover_collisions':failures,'control29_blocks':len(control),'control_missing_originals':10,'row_dy_mm':dy/1000,'source_full66_verified':False,'solver_calls':0,'H5_complete':False};write(OUT/'prepared.json',result);print(result)
