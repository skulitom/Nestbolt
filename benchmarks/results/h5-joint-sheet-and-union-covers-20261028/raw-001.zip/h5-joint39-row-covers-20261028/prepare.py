"""Prepare all51 movable first-sheet originals as36 singletons and3 rigid rows."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-row-covers-20261028';STUDY=ROOT/'output/h5-rational-source-20261028/row-cover-study';CORE=ROOT/'output/h5-mixed26-height-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');assert load(STUDY/'audit/checks.json')['passed'] and load(STUDY/'section-bound/audit/checks.json')['passed']
inputs=[JOB,STUDY/'plan.json',STUDY/'audit/checks.json',STUDY/'row-mode.json',STUDY/'first39-blocks.json',STUDY/'short15.json',STUDY/'section-bound/certificate.json',STUDY/'section-bound/widths.json',STUDY/'section-bound/audit/checks.json',CORE/'modes.json',CORE/'response-audit/selected-poses.json',CORE/'source-audit/checks.json',ROOT/'output/h5_legacy64_source_readback.py']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New whole-first-sheet source-cover model. All36 orthogonal originals and3 rigid five-cog rows move independently; no rectangular core or cog pose is fixed. All39 blocks mandatory, representing all51 first-sheet originals plus fixed short15. Mode-independent NoOverlap2D over disjoint conservative outer-cover partitions. Three legal phase7 rows at258.9mm pitch are a declared constructive subset, not original-source replacements.',
    'target_originals':66,'movable_originals':51,'mandatory_blocks':39,'fixed_short_originals':15,'common_line_part_in_hole':False,'mode_subset':'frame0/90; all8 bracket quarter/mirror; insert0/90; cog-row7degrees',
    'source_stock_guard_um':13,'cover_bounds_um':[6399,6399,1493601,2993601],'cover_bounds_method':'Source bbox anchors enforce the original6.5mm stock boundary plus13um guard. Clearance covers may extend at most114um beyond the source bbox, so the global cover envelope is guarded stock expanded114um. Covers are not unnecessarily required inside the original stock rectangle.',
    'source_stocks':{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},'required_source_gap_mm':.21170867250963943,'native_stock_guard_mm':.011444091796875,
    'positive_control':'26 orthogonal source originals from the audited core, relabelled within identical families for X symmetry, plus2 rigid rows (10cogs), plus short15 =51 original parts. Eleven blocks representing15 originals absent only in control. No complete66 witness is claimed.',
    'negative_control':'All39 blocks present with one legal mode each at source bbox anchor7000,7000um. Original stock checks pass but physical and cover collisions must fail.',
    'solver_seconds':60,'shared_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_solver_calls':1,'retry_permitted':False,'source_and_native_required_for_full66':True,'H5_complete':False})
blocks=load(STUDY/'first39-blocks.json');short=load(STUDY/'short15.json');write(BASE/'blocks39.json',blocks);write(BASE/'short15.json',short)
modes=[]
for old in load(CORE/'modes.json'):
    if old['family'] in ['frame','insert'] and old['quarter']>1:continue
    modes.append({'id':len(modes),'old_mode':old['id'],'family':old['family'],'quarter':old['quarter'],'angle':old['quarter']*math.pi/2,'mirrored':old['mirrored'],'source_translation_offset':[-v/1000 for v in old['transformed_min_um']],'outer_mm':[[x/1000,y/1000] for x,y in old['outer_um']],'source_bounds_mm':[0,0,old['width_um']/1000,old['height_um']/1000],'cover_rectangles_um':old['expanded_rectangles_um']})
row=load(STUDY/'row-mode.json');modes.append({'id':len(modes),'family':'cog-row','source_instances':row['source_instances'],'source_bounds_mm':row['source_bounds_mm'],'cover_rectangles_um':row['cover_rectangles_um']});write(BASE/'modes.json',modes)
oldposes=load(CORE/'response-audit/selected-poses.json');oldmodes=load(CORE/'modes.json');control=[]
for family in ['bracket','frame','insert']:
    poses=sorted([p for p in oldposes if p['family']==family],key=lambda p:tuple(p['anchor_um']));owners=[i for i,b in enumerate(blocks) if b['family']==family]
    for i,p in zip(owners,poses):
        old=oldmodes[p['mode']];q=old['quarter'] if family=='bracket' else old['quarter']%2
        m=next(m for m in modes if m['family']==family and m['quarter']==q and m['mirrored']==old['mirrored']);control.append({'block':i,'mode':m['id'],'anchor_um':p['anchor_um']})
rowowners=[i for i,b in enumerate(blocks) if b['family']=='cog-row']
for i,y in zip(rowowners,[2160000,2441000]):control.append({'block':i,'mode':modes[-1]['id'],'anchor_um':[6700,y]})
write(BASE/'control.json',control)
negative=[{'block':i,'mode':next(m['id'] for m in modes if m['family']==b['family']),'anchor_um':[7000,7000]} for i,b in enumerate(blocks)];write(BASE/'negative.json',negative)
def reconstruct(poses):
    result=list(short)
    for p in poses:
        b=blocks[p['block']];m=modes[p['mode']];x,y=[v/1000 for v in p['anchor_um']]
        instances=[{'part_id':b['family'],'copy_index':b['copy_index'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}] if b['family']!='cog-row' else [{**r,'copy_index':copy} for r,copy in zip(m['source_instances'],b['copy_indices'])]
        for r in instances:result.append({'part_id':r['part_id'],'copy_index':r['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':r['angle'],'mirrored':r['mirrored'],'translation':[x+r['translation'][0],y+r['translation'][1]]}})
    return result
write(BASE/'control-source51.json',reconstruct(control));write(BASE/'negative-source66.json',reconstruct(negative));write(BASE/'prepared.json',{'modes':len(modes),'mandatory_blocks':39,'movable_originals':51,'partial_control_blocks':len(control),'partial_control_originals':51,'negative_originals':66,'solver_calls':0});print(load(BASE/'prepared.json'))
