"""Seal the closed whole-sheet search and independently verified union-cover study."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-joint39-row-covers-20261028';PUB=BASE/'publication';NAME='h5-joint-sheet-and-union-covers-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='75ee537cdd9855c40216eccd5b011817ea91378e' and not git('diff','HEAD','--name-only')
audits=['geometry-audit-verified','model-audit','source-bridge-audit','response-audit','union-cover-study-verified/audit'];assert all(load(BASE/a/'checks.json')['passed'] for a in audits)
result=load(BASE/'search/result.json');assert result['closed'] and result['solver_calls']==1 and result['status']=='UNKNOWN' and not result['has_solution'] and not result['source_full66_verified']
union=load(BASE/'union-cover-study-verified/audit/checks.json');assert union['new_union_components_per_row']==523 and union['control_originals']==56 and union['control_cover_pairs']==1276003 and not union['source_full66_verified']
prior=load(ROOT/'benchmarks/results/h5-rational-source-and-row-covers-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main==head;receipt=load(ROOT/'output/h5-rational-main-sync-20261028/receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==3 and len(live)==3
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-rational-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_joint39_rows_20261028.py','audit_h5_joint39_geometry_20261028.py','audit_h5_joint39_geometry_corrected_20261028.py','audit_h5_joint39_geometry_verified_20261028.py','build_h5_joint39_model_20261028.py','h5_joint39_cp_reader_20261028.py','audit_h5_joint39_model_20261028.py','h5_joint39_source_bridge_20261028.py','audit_h5_joint39_source_bridge_20261028.py','check_h5_joint39_candidate_20261028.py','run_h5_joint39_model_20261028.py','audit_h5_joint39_response_20261028.py','study_h5_row_union_covers_20261028.py','audit_h5_row_union_study_20261028.py','diagnose_h5_row_union_cover_bounds_20261028.py','study_h5_row_union_covers_verified_20261028.py','audit_h5_row_union_study_verified_20261028.py','prepare_h5_rational_checkpoint_push_20261028.py','push_h5_rational_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_joint39_archive_20261028.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies={'geometry-audit-verified/checks.json':'geometry-audit.json','geometry-audit-verified/envelope-section-bound.json':'envelope-section-bound.json','model-audit/checks.json':'model-audit.json','model-audit/negative-target-rejections.json':'negative-model-checks.json','source-bridge-audit/checks.json':'source-bridge-audit.json','response-audit/checks.json':'response-audit.json','search/result.json':'search-result.json','union-cover-study-verified/audit/checks.json':'union-cover-audit.json','union-cover-study-verified/prepared.json':'union-cover-study.json','union-cover-study-verified/row-separation.json':'union-row-separation.json','union-cover-study/failure-diagnosis.json':'union-subset-failure.json'}
for a,b in copies.items():shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'previous_checkpoint_pushed':True,'prior_main_CI':40758320213,'prior_main_all6_pass':True,'main_CI':40764537562,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audit_groups':len(audits),'closed_packing_sequences':1,'solver_calls':1,'complete_candidates':0,'source_valid66_count':0,'all39_blocks_mandatory':True,'all51_first_sheet_originals_movable':True,'two_reader_failures_preserved':True,'incorrect_cover_subset_assumption_preserved':True,'union_cover_control_originals':56,'new_union_cover_solver_calls':0,'valid64_preserved':True,'remaining_necessary_allocations':444,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 movable first sheet and tighter row covers, 2026-10-28:** [the evidence]({link})
closes one complete 39-block hull-cover search UNKNOWN with no candidate.
All 51 first-sheet originals move; 228 variables and 998 constraints are
independently audited. Partial51 passes source/cover checks but fails exactly
11 target requirements; negative66 correctly fails with 825 source collisions.
Search begins at 0.26 s; algorithm/shared times are 60.076083/60.146931 s, with
the 0.076083 s algorithm overrun preserved. A new geometry-only union-cover
study removes 263,585.241270 mm² of cover area across three rows and verifies
a partial56 control, including all 1,276,003 cover pairs. The failed exact-subset
assumption from a 1 µm slab-grid shift and two reader errors remain preserved;
independent source-clearance proofs pass. Next build and audit the complete
union-cover model before one new fixed-budget solve; the hull search stays
closed. Prior checkpoint75ee537c is pushed after all six checks passed;
CI40764537562 has three passes and three running jobs. Production/READMEs,
valid64,444 necessary allocations,H2 gate and22 unopened vectors are unchanged.
H2/H5 remain open at60%; no new release qualifies.
'''
for a,b in [('checkpoint75','checkpoint 75'),('CI407','CI 407'),('valid64,444','valid 64, 444'),('allocations,H2','allocations, H2'),('and22','and 22'),('at60%','at 60%')]:note=note.replace(a,b)
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
