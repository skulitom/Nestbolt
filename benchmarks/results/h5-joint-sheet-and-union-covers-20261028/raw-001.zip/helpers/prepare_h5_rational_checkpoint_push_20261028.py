"""Prepare a fresh normal push guard after all six current main checks passed."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='75ee537cdd9855c40216eccd5b011817ea91378e'
source=(ROOT/'output/push_h5_collision_checkpoint_20261028.py').read_text(encoding='utf-8')
changes={"output/h5-collision-generation-main-sync-20261028":"output/h5-rational-main-sync-20261028","OLD='a0d6f9af9c1e577263e138c3b2993f2c17591ec7';NEW='571738d8c229781092d8f8a3ebf1b77cef56604a'":"OLD='571738d8c229781092d8f8a3ebf1b77cef56604a';NEW='75ee537cdd9855c40216eccd5b011817ea91378e'","['benchmarks/results/h5-source-collision-generation-20261028']":"['benchmarks/results/h5-rational-source-and-row-covers-20261028']",'40753599821':'40758320213'}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_rational_checkpoint_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'head':head,'prior_CI':40758320213,'guard_prepared':True})
