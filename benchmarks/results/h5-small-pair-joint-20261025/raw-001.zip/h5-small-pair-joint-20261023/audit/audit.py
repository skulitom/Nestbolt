"""Independent complete new-edge reconstruction and all four original seed checks."""
from collections import Counter
import shutil,time
import numpy as np
import shapely
from audit_h5_cog_lattices import shape
from build_h5_small_pair_joint import ROOT,SRC,OLD,REG,OUT as BASE,load,write,digest,read_graph
OUT=BASE/'audit'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    start=time.perf_counter();mp=load(BASE/'mapping.json');oldmp=load(OLD/'mapping.json');pool=load(BASE/'candidates.json');oldpool=load(OLD/'candidates.json');ids=mp['candidates'];n0=len(oldmp['candidates']);assert mp==load(REG/'audit/mapping.json') and pool==load(REG/'candidates.json') and pool[:len(oldpool)]==oldpool and ids[:n0]==oldmp['candidates'] and mp['core_groups']==oldmp['core_groups'] and mp['compatible_groups'][:n0]==oldmp['compatible_groups'];source=read_graph(OLD/'adjacency.bin.gz',n0);expected=source.copy()+[0]*(len(ids)-n0);actual=read_graph(BASE/'adjacency.bin.gz',len(ids));job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);bb=shapely.bounds(gs);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);indexes=np.arange(len(ids));poss=exact=edges=0
    for j in range(n0,len(ids)):
        eligible=(sheets==sheets[j])&(indexes<j);poss+=int(eligible.sum());a,b,c,d=bb[j];dx=np.maximum(np.maximum(bb[:,0]-c,a-bb[:,2]),0);dy=np.maximum(np.maximum(bb[:,1]-d,b-bb[:,3]),0);ks=np.flatnonzero(eligible&(dx*dx+dy*dy<=(clear+1e-7)**2));exact+=len(ks);ds=shapely.distance(gs[ks],gs[j])
        for k,v in zip(ks,ds):
            if v<clear-1e-7:k=int(k);expected[j]|=1<<k;expected[k]|=1<<j;edges+=1
    assert expected==actual and all(not((v>>j)&1) for j,v in enumerate(actual));mask=(1<<n0)-1;assert all(actual[j]&mask==source[j] for j in range(n0));local={i:j for j,i in enumerate(ids)};seedcounts=[]
    for seed in mp['mapped_seeds']:
        chosen=seed['selected_variable_candidates'];js=[local[i] for i in chosen];selected=sum(1<<j for j in js);counts=Counter(pool[i]['placement']['part_id'] for i in chosen);assert len(chosen)==len(set(chosen)) and dict(counts)==seed['counts'] and all(not(actual[j]&selected) and seed['core_group'] in mp['compatible_groups'][j] for j in js);assert sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in chosen)==seed['objective'];fixed=mp['core_groups'][seed['core_group']]['fixed_candidates'];assert len(fixed)==33 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15) and len(set(fixed+chosen))==len(fixed+chosen);seedcounts.append(len(fixed+chosen))
    assert seedcounts==[64,64,63,63];reported=load(BASE/'result.json');assert edges==reported['new_geometric_edges'] and sum(v.bit_count() for v in actual)//2==reported['total_geometric_edges']
    checks={'passed':True,'seconds':time.perf_counter()-start,'all_input_hashes_verified':True,'old_pool_core_and_membership_prefixes_preserved':True,'variable_poses':len(ids),'new_same_sheet_possibilities':poss,'independent_new_exact_distances':exact,'new_geometric_edges':edges,'old_geometric_edges':reported['old_geometric_edges'],'total_geometric_edges':reported['total_geometric_edges'],'every_graph_row_matches':True,'every_old_old_row_unchanged':True,'baseline_counts':seedcounts,'seed_floor':815800000,'best_seed_score':816200000,'full_score':895800000,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
