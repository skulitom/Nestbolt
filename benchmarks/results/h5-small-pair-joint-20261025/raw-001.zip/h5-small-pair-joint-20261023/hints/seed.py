"""Retain all independently verified mapped baselines, with no extra greedy search."""
from collections import Counter
from datetime import datetime,timezone
import shutil
from build_h5_small_pair_joint import ROOT,OUT as BASE,load,write,digest,read_graph
RED=BASE/'reduced';OUT=BASE/'hints'
def main():
    assert load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    inputs=[BASE/n for n in ['plan.json','candidates.json','audit/checks.json']]+[RED/n for n in ['mapping.json','adjacency.bin.gz','checks.json','best-hint.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Retain every mapped complete 64/63-part baseline, independently checking variable conflicts, core compatibility, original count caps and exact objective. Select the first highest-scoring valid baseline as the solver hint. No additional greedy search or solver call.','additional_greedy_hint_calls':0})
    mp=load(RED/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=read_graph(RED/'adjacency.bin.gz',len(ids));seeds=mp['mapped_seeds'];assert len(seeds)==4
    for r in seeds:
        chosen=r['selected_variable_candidates'];mask=sum(1<<local[i] for i in chosen);counts=Counter(pool[i]['placement']['part_id'] for i in chosen)
        assert len(chosen)==len(set(chosen))==sum(r['counts'].values()) and dict(counts)==r['counts']
        assert all(not(adj[local[i]]&mask) and r['core_group'] in mp['compatible_groups'][local[i]] for i in chosen)
        assert sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in chosen)==r['objective'] and r['objective']>=815800000
    best=max(seeds,key=lambda r:r['objective']);write(OUT/'hints.json',seeds);write(OUT/'best-hint.json',best)
    check={'passed':True,'mapped_baselines_checked':len(seeds),'best_objective':best['objective'],'best_core':best['core_group'],'additional_greedy_hint_calls':0,'full_inventory_hint':False,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
