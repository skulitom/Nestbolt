"""Adapt verified mechanics to four mixed-count seeds while preserving the original floor."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    for name in ['reduce','seed','solve','audit']:
        suffix='layouts' if name=='audit' else 'joint';old=f'{name}_h5_shifted_core_small_{suffix}.py';new=f'{name}_h5_small_pair_{suffix}.py';text=(ROOT/'output'/old).read_text(encoding='utf-8');text=text.replace('h5_shifted_core_small_joint','h5_small_pair_joint').replace('h5-shifted-core-small-joint-20261023','h5-small-pair-joint-20261023').replace('seven-core small-part','pair-contact small-part')
        if name=='reduce':
            text=text.replace('both exact original 64-part seeds','all four original 64/63-part seeds').replace("assert len(chosen)==len(set(chosen))==31 and counts==Counter(bracket=10,insert=21)","assert len(chosen)==len(set(chosen))==sum(seed['counts'].values()) and dict(counts)==seed['counts']")
            text=text.replace("assert row['objective']==815800000","assert row['objective']==seed['objective']").replace('assert len(mapped)==2;best=mapped[0]',"assert len(mapped)==4;best=max(mapped,key=lambda r:r['objective'])").replace('both_exact_64_seeds_counts_groups_and_full_graph_checked','all_four_64_63_seeds_counts_groups_and_full_graph_checked').replace("'mapped-64-part-seed'","'mapped-64-or-63-part-seed'")
        elif name=='seed':
            text=text.replace('complete 64-part baseline','complete 64/63-part baseline').replace('assert len(seeds)==2','assert len(seeds)==4').replace("assert len(chosen)==len(set(chosen))==31 and counts==Counter(bracket=10,insert=21)","assert len(chosen)==len(set(chosen))==sum(r['counts'].values()) and dict(counts)==r['counts']").replace("==r['objective']==815800000","==r['objective'] and r['objective']>=815800000")
        elif name=='solve':
            before="low=sum(w*v for w,v in zip(weights,hint));high=sum(area[f]*caps[f] for f in names);assert low==best['objective']>=815800000 and high==895800000"
            after="hint_score=sum(w*v for w,v in zip(weights,hint));low=815800000;high=sum(area[f]*caps[f] for f in names);assert hint_score==best['objective']==816200000 and low<=hint_score and high==895800000"
            assert before in text;text=text.replace(before,after).replace("'seed_score':low,'full_score':high","'seed_score':low,'hint_score':hint_score,'full_score':high")
        else:text=text.replace('if i>=39488','if i>=43488')
        with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
if __name__=='__main__':main()
