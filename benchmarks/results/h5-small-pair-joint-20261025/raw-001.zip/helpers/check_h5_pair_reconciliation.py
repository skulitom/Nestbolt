"""Verify the resumed merge and refreshed upstream stop-rule evidence."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys,urllib.request
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pair-reconciliation-20261025';sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();local='23cb3074';remote='4045822eb1fce0bb9253d637ca56df8b22cc8b6e';base='0526421ede59de232edbf2979362e9641e749ee6';head=git('rev-parse','HEAD').decode().strip();rows=[]
    for kind,ref,parent in [('incoming',remote,base),('local',local,local+'^')]:
        paths=git('diff','--name-only','-z',parent,ref).decode().split('\0')[:-1]
        for name in paths:
            expected=git('show',ref+':'+name);actual=(ROOT/name).read_bytes();assert actual==expected,(kind,name);rows.append({'kind':kind,'path':name,'bytes':len(actual),'sha256':sha256(actual).hexdigest()})
    assert sum(r['kind']=='incoming' for r in rows)==9 and sum(r['kind']=='local' for r in rows)==37
    prior=json.loads((ROOT/'benchmarks/results/h5-shifted-core-small-joint-20261023/source-review.json').read_bytes());assert source_digest()==prior['production_digest'];assert {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in prior['current_readmes']}==prior['current_readmes'];ci=[]
    for run in ['39991641757','40081381157','40083254178']:
        data=json.loads(subprocess.check_output(['gh','run','view',run,'--json','status,conclusion,jobs,headSha,url'],cwd=ROOT));assert data['conclusion']=='success'
        if run!='40083254178':assert len(data['jobs'])==6 and all(j['conclusion']=='success' for j in data['jobs'])
        write(OUT/f'ci-{run}.json',data);ci.append({'run':run,'conclusion':data['conclusion'],'head':data['headSha']})
    upstream={}
    for name,endpoint in [('sparrow-head','repos/JeroenGar/sparrow/commits/main'),('sparrow-release','repos/JeroenGar/sparrow/releases/latest'),('studio-head','repos/JeroenGar/sparrow-studio/commits/main')]:
        cp=subprocess.run(['gh','api',endpoint],cwd=ROOT,capture_output=True,timeout=30);(OUT/(name+'.stdout')).write_bytes(cp.stdout);(OUT/(name+'.stderr')).write_bytes(cp.stderr);assert cp.returncode==0;data=json.loads(cp.stdout);upstream[name]={'sha':data.get('sha'),'tag':data.get('tag_name'),'url':data.get('html_url'),'published':data.get('published_at'),'message':data.get('commit',{}).get('message')};write(OUT/(name+'.json'),data)
    url='https://sparrowstudio.app/';html=urllib.request.urlopen(url,timeout=30).read();(OUT/'studio.html').write_bytes(html);text=html.decode('utf-8');assert 'does not allocate parts across multiple fixed-size sheets' in text and 'placing other parts inside holes is not supported' in text
    result={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'head':head,'remote_merged':remote,'local_checkpoint_preserved':git('rev-parse',local).decode().strip(),'all_incoming_files_byte_exact':9,'all_local_checkpoint_files_byte_exact':37,'files':rows,'production_digest':source_digest(),'readmes_unchanged':True,'parent_checks':ci,'upstream':upstream,'published_studio_url':url,'published_studio_sha256':sha256(html).hexdigest(),'published_studio_explicitly_strip_only_without_part_in_hole':True,'stop_rule_triggered':False};write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k not in ['files','upstream']},flush=True);print(upstream,flush=True)
if __name__=='__main__':main()
