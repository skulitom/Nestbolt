"""Independent pair census, event replay, original geometry and all new core memberships."""
from collections import Counter,deque
from datetime import datetime,timezone
from itertools import combinations
import math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Point,shape as from_geojson
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_small_pair_contacts import ROOT,SRC,PRIOR,OUT as BASE,load,write,digest
OUT=BASE/'audit'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');mp=load(BASE/'mapping.json');oldmp=load(PRIOR/'mapping.json');pool=load(BASE/'candidates.json');oldpool=load(PRIOR/'candidates.json');oldn=len(oldpool);new=mp['new_candidates'];assert oldn==43488 and pool[:oldn]==oldpool and new==list(range(oldn,len(pool)))
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','result.json','pair-census.json','neighborhoods.json','source-layouts.json','mapped-seeds.json','events.json','pending.json','cache-checks.json','append-opportunities.json']];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Match prior inputs against committed raw evidence, independently reconstruct the complete same-sheet pair census and neighborhood ordering, verify saved regions/proposals and replay the capped queue exactly. Reconstruct original polygons for every admitted event, independently verify every remaining fixed-part distance and released-pair blocker, stock padding, allowed transforms and area. Compute every new candidate membership against each original33-part core by individual part distances and complete filled core unions. Retain unchanged old memberships only after exact source mapping/hash verification. Recheck all four complete mapped baseline layouts and original filled-area weights. No generation, search retry, pending-list continuation or solver call.'})
    manifest=ROOT/'benchmarks/results/h5-shifted-core-small-joint-20261023/raw-manifest.json';data=load(manifest);hashes={r['path']:r['sha256'] for r in data['files']+data['aliases']};provenance=[]
    for name,h in plan['inputs'].items():
        p=ROOT/name;assert digest(p)==h
        if p.is_relative_to(PRIOR):key=PRIOR.name+'/'+p.relative_to(PRIOR).as_posix()
        elif p.suffix=='.py':key='helpers/'+p.name
        else:key='source-inputs/'+p.relative_to(ROOT).as_posix()
        assert hashes[key]==h;provenance.append({'source':name,'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key,'sha256':h})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];target=load(SRC/'conditional-target.json');m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];padding=plan['construction_padding_mm'];groups=mp['core_groups'];assert groups==oldmp['core_groups'] and mp['candidates']==oldmp['candidates'] and mp['compatible_groups']==oldmp['compatible_groups'];layouts=load(BASE/'source-layouts.json');neighbors=load(BASE/'neighborhoods.json');fixedids=sorted({i for g in groups for i in g['fixed_candidates']}|{i for l in layouts for i in l['selected_indices']});geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixedids};census=[];expected=[]
    for li,l in enumerate(layouts):
        selected=l['selected_indices'];assert len(selected)==63 and Counter(pool[i]['placement']['part_id'] for i in selected)==Counter(frame=18,cog=15,bracket=11,insert=19);small=sorted(i for i in selected if pool[i]['placement']['part_id'] in ['bracket','insert'])
        for i,j in combinations(small,2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            d=geometry[i].distance(geometry[j]);row={'layout':li,'pair':[i,j],'sheet_id':pool[i]['placement']['sheet_id'],'distance_mm':d,'eligible':d<=plan['adjacency_distance_mm']};census.append(row)
            if row['eligible']:expected.append({**row,'fixed_candidates':sorted(set(selected)-{i,j}),'released_counts':dict(Counter(pool[k]['placement']['part_id'] for k in [i,j])),'core_group':l['core_group']})
    expected.sort(key=lambda r:(r['distance_mm'],r['layout'],r['pair']));expected=[{**r,'index':i} for i,r in enumerate(expected)];assert census==load(BASE/'pair-census.json') and neighbors==expected
    queries=[];regions=[]
    for index,spec in enumerate(plan['queries'][:result['completed_queries']]):
        q=load(BASE/'regions'/f'{index:04d}.json');assert all(q[k]==v for k,v in spec.items());orientation=plan['specifications'][q['specification']];t={'rotation_radians':math.radians(orientation['degrees']),'mirrored':orientation['mirrored'],'translation':[0.,0.]};assert q['family']==orientation['family'] and q['transform']==t;moving=shape(parts[q['family']],t);a,b,c,d=moving.bounds;height=stock['height'] if q['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert q['domain_bounds']==[m['left']+edge+padding-a,m['bottom']+edge+padding-b,stock['width']-m['right']-edge-padding-c,height-m['top']-edge-padding-d];g=from_geojson(q['region']);assert g.is_valid and g.is_empty==q['empty'] and abs(g.area-q['region_area_mm2'])<1e-7 and proposals(g)==q['proposals'];queries.append(q);regions.append(g)
    caches=load(BASE/'cache-checks.json')
    for r in caches:
        saved=load(BASE/'obstacles'/f"{r['index']:03d}.json");assert all(saved[k]==v for k,v in r.items()) and r['hausdorff_error_mm']<1e-7 and r['area_error_mm2']<1e-4 and from_geojson(saved['geometry']).is_valid
    events=load(BASE/'events.json');queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];keys={identity(p['placement']):i for i,p in enumerate(oldpool)};made=[];counts=Counter();ei=0;event_points=[];appendable=[]
    while queue:
        qi,pi=queue.popleft();q=queries[qi];f=q['family']
        if counts[f]>=plan['new_pose_caps'][f]:deferred.append([qi,pi]);continue
        if ei==len(events):queue.appendleft((qi,pi));break
        event=events[ei];ei+=1;assert (event['query'],event['proposal'],event['neighborhood'])==(qi,pi,q['neighborhood']);t={**q['transform'],'translation':q['proposals'][pi]['point']};p={'part_id':f,'sheet_id':q['sheet_id'],'transform':t};key=identity(p);assert regions[qi].distance(Point(*t['translation']))<=1e-8
        if key in keys:assert event['outcome']=='exact_duplicate' and event['candidate']==keys[key]
        else:
            assert event['outcome']=='added';i=oldn+len(made);assert event['candidate']==i and pool[i]['placement']==p and pool[i]['index']==i;made.append(i);keys[key]=i;counts[f]+=1
        event_points.append((event['candidate'],q['neighborhood'],event['released_blockers']))
        if not event['released_blockers']:appendable.append({'candidate':event['candidate'],'layout':neighbors[q['neighborhood']]['layout'],'query':qi,'proposal':pi})
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    pending=load(BASE/'pending.json');assert ei==len(events) and made==new and dict(counts)==result['new_candidates_by_family'] and pending=={'queries':plan['queries'][len(queries):],'lists':deferred+list(map(list,queue))};assert appendable==load(BASE/'append-opportunities.json')
    eventids=sorted({i for i,_,_ in event_points});geometry.update({i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in eventids});checked={};fixedpairs=removedpairs=0;minimum=math.inf
    for i,ni,blockers in event_points:
        n=neighbors[ni];fixed=[j for j in n['fixed_candidates'] if pool[j]['placement']['sheet_id']==n['sheet_id']];fixedpairs+=len(fixed);removedpairs+=2
        if (i,ni) in checked:assert blockers==checked[i,ni];continue
        g=geometry[i];ds=[g.distance(geometry[j]) for j in fixed];assert all(g.disjoint(geometry[j]) for j in fixed) and min(ds)>=clear+padding-1e-7;minimum=min(minimum,min(ds)-clear);actual=[j for j in n['pair'] if g.distance(geometry[j])<clear-1e-7];assert blockers==actual;checked[i,ni]=actual;a,b,c,d=g.bounds;height=stock['height'] if n['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert a>=m['left']+edge+padding-1e-7 and b>=m['bottom']+edge+padding-1e-7 and c<=stock['width']-m['right']-edge-padding+1e-7 and d<=height-m['top']-edge-padding+1e-7
    assert fixedpairs==result['original_fixed_pair_checks']
    gs=np.asarray([geometry[i] for i in new],dtype=object);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in new]);per_sheet={s:np.flatnonzero(sheets==s) for s in ['sheet-0','sheet-1']};coreids=sorted({i for g in groups for i in g['fixed_candidates']});distances={};corepartpairs=0
    for i in coreids:
        ix=per_sheet[pool[i]['placement']['sheet_id']];distances[i]=np.full(len(new),np.inf);distances[i][ix]=shapely.distance(gs[ix],geometry[i]);corepartpairs+=len(ix)
    compat={i:[] for i in new};memberships=corepairs=0
    for g in groups:
        fixed=g['fixed_candidates'];assert len(fixed)==33 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15)
        for i,j in combinations(fixed,2):
            if pool[i]['placement']['sheet_id']==pool[j]['placement']['sheet_id']:assert geometry[i].disjoint(geometry[j]) and geometry[i].distance(geometry[j])>=clear-1e-7;corepairs+=1
        for sheet,ix in per_sheet.items():
            here=[i for i in fixed if pool[i]['placement']['sheet_id']==sheet];by_part=np.minimum.reduce([distances[i][ix] for i in here]);by_union=shapely.distance(gs[ix],unary_union([geometry[i] for i in here]));assert np.array_equal(by_part>=clear-1e-7,by_union>=clear-1e-7)
            for j,d in zip(ix,by_union):
                memberships+=1
                if d>=clear-1e-7:compat[new[int(j)]].append(g['index'])
    for i in new:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees']);assert geometry[i].is_valid and abs(geometry[i].area-pool[i]['filled_area_mm2'])<1e-6 and pool[i]['source']['core_group'] in compat[i]
    ids=oldmp['candidates']+new;compatible=oldmp['compatible_groups']+[compat[i] for i in new];local={i:j for j,i in enumerate(ids)};seedpairs=0;seedcounts=[]
    for seed in mp['mapped_seeds']:
        chosen=seed['selected_variable_candidates'];allids=groups[seed['core_group']]['fixed_candidates']+chosen;counts=Counter(pool[i]['placement']['part_id'] for i in chosen);assert dict(counts)==seed['counts'] and len(allids)==len(set(allids)) and all(seed['core_group'] in compatible[local[i]] for i in chosen);assert sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in chosen)==seed['objective'];seedcounts.append(len(allids))
        geometry.update({i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in allids if i not in geometry})
        for i,j in combinations(allids,2):
            if pool[i]['placement']['sheet_id']==pool[j]['placement']['sheet_id']:assert geometry[i].disjoint(geometry[j]) and geometry[i].distance(geometry[j])>=clear-1e-7;seedpairs+=1
    assert seedcounts==[64,64,63,63]
    for f,w in mp['area_weights'].items():assert shape(parts[f],{'rotation_radians':0.,'mirrored':False,'translation':[0.,0.]}).area*1000==w
    write(OUT/'memberships.json',[{'candidate':i,'compatible_groups':compat[i]} for i in new]);write(OUT/'mapping.json',{**mp,'candidates':ids,'compatible_groups':compatible});write(OUT/'provenance.json',{'passed':True,'source_members_matching_committed_evidence':provenance})
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_members_verified':len(provenance),'original_pool_records_preserved':oldn,'same_sheet_pair_census_verified':len(census),'pair_neighborhoods_verified':len(neighbors),'query_regions_and_proposals_verified':len(queries),'cache_equivalence_records_verified':len(caches),'events_replayed':len(events),'family_cap_deferrals_replayed':len(deferred),'pending_queries_preserved':len(pending['queries']),'pending_proposal_lists_preserved':len(pending['lists']),'new_poses_checked':len(new),'original_generating_pair_relationships_verified':fixedpairs,'released_pair_relationships_verified':removedpairs,'distinct_event_neighborhoods_geometry_checked':len(checked),'minimum_construction_padding_mm':minimum,'append_opportunities_verified':len(appendable),'new_core_part_distances':corepartpairs,'all_new_core_memberships_checked_both_methods':memberships,'core_pairs_checked':corepairs,'unchanged_old_memberships_retained':len(oldmp['candidates']),'four_baseline_counts':seedcounts,'baseline_same_sheet_pairs_checked':seedpairs,'total_variable_choices':len(ids),'seed_floor':815800000,'best_seed_score':816200000,'full_score':895800000,'full_mutual_graph_and_selection_pending':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
