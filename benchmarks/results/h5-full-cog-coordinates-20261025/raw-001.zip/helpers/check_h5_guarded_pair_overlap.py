from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-cog-coordinates-20261025/guarded-cog-pairs';OLD=ROOT/'output/h5-convex-domain-conflicts-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(BASE/'audit/checks.json')['passed'];p=OLD/'second-sheet-pair-proofs/audit/certified-pair-exclusions.json';prior=load(p)['domain_row_pairs'];results=[]
for case in [162,163]:
    old=(OLD/'cases'/f'{case:03d}.bin').read_bytes();new=(BASE/'cases'/f'{case:03d}.bin').read_bytes();m=load(BASE/'cases'/f'{case:03d}.json');n=m['domain_count']
    added=[[i//n,i%n] for i in range(n*n) if new[i//8]&(128>>(i%8)) and not old[i//8]&(128>>(i%8))]
    overlap=[r for r in added if case==163 and r in prior];fresh=[r for r in added if r not in overlap]
    results.append({'case':case,'query':m['query'],'new_vs_raw_table':len(added),'already_in_exact_second_sheet_proofs':len(overlap),'new_vs_previous_master_pair_clauses':len(fresh),'new_ordered_pairs':fresh})
value={'passed':True,'source_interval_sha256':digest(p),'cases':results,'all15_physical_cog_pair_uses':15*sum(r['new_vs_previous_master_pair_clauses'] for r in results)}
with (BASE/'prior-interval-overlap.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print({**value,'cases':[{k:v for k,v in r.items() if k!='new_ordered_pairs'} for r in results]},flush=True)
