from pathlib import Path
R=Path(__file__).resolve().parent
OLD='output/h5-cog-region-capacities-20261025/disk-search';NEW='output/h5-full-cog-coordinates-20261025/shared-search'
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'solve_h5_cog_coordinate_master.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('from audit_h5_cog_coordinate_master import verify','from audit_h5_full_cog_master import verify')
s=s.replace("    disk_path=regional_path/'disk-relaxation';assert load(disk_path/'checks.json')['passed'];disk=load(disk_path/'polygon.json')","    fullpath=ROOT/'output/h5-full-cog-coordinates-20261025';assert load(fullpath/'audit/checks.json')['passed'];atlas=load(fullpath/'atlas.json');mutual=load(SOURCE/'mutual/081.json')")
s=s.replace("ROOT/'output/audit_h5_cog_coordinate_master.py',disk_path/'polygon.json',disk_path/'checks.json'","ROOT/'output/audit_h5_full_cog_master.py',fullpath/'atlas.json',fullpath/'audit/checks.json',SOURCE/'mutual/081.json'")
a=s.index('    cog_positions=[]');b=s.index("    mapping={'parts':parts",a)
s=s[:a]+'''    cog_positions=[]
    boxes=[f['coordinate_bounds'] for q in [18,19] for f in queries[q]['domains']];bounds=[min(b[k] for b in boxes) if k<2 else max(b[k] for b in boxes) for k in range(4)]
    for i in regional['applicable_cog_parts']:
        x=var(f'cog{i}-anchor-x',bounds[0],bounds[2]);y=var(f'cog{i}-anchor-y',bounds[1],bounds[3]);cog_positions.append({'part':i,'x':x,'y':y})
        for m in parts[i]['modes']:
            box=atlas['query_anchor_bounds'][str(m['query'])]
            for v,lo,hi in [(x,box[0],box[2]),(y,box[1],box[3])]:
                model.add_linear_constraint(vs[v],lo,cp_model.INT_MAX).only_enforce_if(vs[m['active']])
                model.add_linear_constraint(vs[v],cp_model.INT_MIN,hi).only_enforce_if(vs[m['active']])
            for row,selector in enumerate(m['domains']):
                for h in queries[m['query']]['domains'][row]['halfplanes']:
                    model.add_linear_constraint(vs[x]*h['a']+vs[y]*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[selector])
    for a,b in combinations(cog_positions,2):
        i,j=a['part'],b['part'];sa,sb=parts[i]['sheet'],parts[j]['sheet']
        for f in atlas['faces']:
            if f['always_separated']:continue
            dirs=[];source=next(row for row in mutual['faces'] if row['index']==f['face'])
            for k in f['possible_edges']:
                h=source['outside_halfplanes'][k];d=var(f"cog-pair{i}-{j}-original-face{f['face']}-edge{k}",0,1);dirs.append(d)
                model.add_linear_constraint((vs[b['x']]-vs[a['x']])*h['a']+(vs[b['y']]-vs[a['y']])*h['b'],h['bound'],cp_model.INT_MAX).only_enforce_if(vs[d])
            model.add_bool_or([vs[d] for d in dirs]+[vs[sa],vs[sb]])
            model.add_bool_or([vs[d] for d in dirs]+[vs[sa].Not(),vs[sb].Not()])
'''+s[b:]
s=s.replace('certificate,pair_exclusions,capacity,regional,disk);','certificate,pair_exclusions,capacity,regional,atlas,mutual);')
a=s.index("        'method':'");b=s.index("'})",a)
s=s[:a]+"        'method':'Retain every independently audited master domain choice, original count and area charge, complete refined pair table, global three-region exclusion,480 exact second-sheet pair clauses, sheet capacity and35 regional capacities. Bind12 simultaneous cog coordinates to all selected original inward domains and explicit whole-query boxes. Enforce every guarded full-original cog/cog forbidden piece for every same-sheet pair, using only independently proved integer-bound reductions. The complete inherited and new protobuf is independently reconstructed before one call. Construction, audits, this call, any selected-domain/full-cog witness audit and any full original-coordinate call share one parent60-second budget. Each call receives only the remaining time; no retries. A cog witness is not a complete66-original witness; all remaining geometry and native/H5 gates remain required."+s[b:]
s=s.replace('A feasible domain assignment has no anchor witness yet','A feasible assignment has full-original cog anchors but still requires full-coordinate validation of all remaining originals')
save('solve_h5_full_cog_master.py',s)
s=(R/'audit_h5_cog_coordinate_selection.py').read_text(encoding='utf-8').replace(OLD,NEW)
needle="    write(OUT/'selected-domains.json',domains);"
addition='''    positions=load(NEW/'solve/necessary-cog-positions.json');assert [p['part'] for p in positions]==[3,4,5,6,7,8]
    mutual=load(SOURCE/'mutual/081.json');inside=piecechecks=0
    for p in positions:
        selected=parts[p['part']];q=spec['queries'][selected['query']];d=load(SOURCE/'queries'/f"{selected['query']:03d}.json")['domains'][selected['domain_row']];x,y=p['x_units'],p['y_units']
        for b in [d['coordinate_bounds'],q['anchor_bounds_units1000']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];inside+=1
    for a,b in combinations(positions,2):
        if parts[a['part']]['sheet']!=parts[b['part']]['sheet']:continue
        dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units']
        for f in mutual['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']);piecechecks+=1
    write(OUT/'full-original-cog-check.json',{'passed':True,'anchors':6,'inward_halfplanes_checked':inside,'complete_original_forbidden_piece_checks':piecechecks,'all_other_originals_need_full_coordinate_validation':True})
'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle)
save('audit_h5_full_cog_selection.py',s)
s=(R/'solve_h5_cog_coordinate_anchors.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace("inputs=[BASE/'budget.json'","inputs=[BASE/'selection-audit/full-original-cog-check.json',BASE/'budget.json'")
save('solve_h5_full_cog_anchors.py',s)
s=(R/'run_h5_cog_coordinate_search.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-cog-region-capacities-20261025';OUT=BASE/'disk-search'","BASE=ROOT/'output/h5-full-cog-coordinates-20261025';REGIONAL=ROOT/'output/h5-cog-region-capacities-20261025';OUT=BASE/'shared-search'")
s=s.replace('solve_h5_cog_coordinate_master.py','solve_h5_full_cog_master.py').replace('audit_h5_cog_coordinate_selection.py','audit_h5_full_cog_selection.py').replace('solve_h5_cog_coordinate_anchors.py','solve_h5_full_cog_anchors.py')
s=s.replace("[BASE/'capacities.json',BASE/'audit/checks.json',BASE/'disk-relaxation/polygon.json',BASE/'disk-relaxation/checks.json']","[REGIONAL/'capacities.json',REGIONAL/'audit/checks.json',BASE/'atlas.json',BASE/'audit/checks.json']")
s=s.replace('and a certified inner collision polygon','and every full-original cog collision piece')
save('run_h5_full_cog_search.py',s)
print('Prepared exact full-original cog search with a distinct shared60-second budget.')
