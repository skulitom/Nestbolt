"""Complete original-outline collision-core relaxation with necessary rounding."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,math,shutil,traceback
import shapely
from shapely.geometry import shape,mapping
from shapely.geometry.polygon import orient
from build_h5_strong_pair_domains import convex_faces
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-cog-coordinates-20261025';OUT=BASE/'original-core-relaxation';OLD=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+60
    paths=[OLD/'cores/081.json',OLD/'audit/checks.json',SOURCE/'mutual/081.json',ROOT/'benchmarks/results/h5-cog-region-capacities-20261025/raw-manifest.json',ROOT/'output/build_h5_strong_pair_domains.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_and_audit_limit_seconds':60,'merge_attempt_limit':10000,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'coordinate_units_per_mm':1000,'normal_coefficient_scale':10000000,'signed_difference_absolute_bounds':[1500000,3000000],
        'method':'Decompose the complete previously certified0.0001mm inset raw ORIGINAL cog/cog collision core, retaining every source-angle tooth and concavity. All convex pieces must lie strictly inside the actual raw original collision polygon, and their whole union must equal the core. Use necessary outside rounding: round normalized edge coefficients, bound their exact rational error over the full signed coordinate range, then FLOOR the edge bound MINUS that error. Any original nonoverlapping pair necessarily satisfies at least one weakened outside inequality per piece. This is an original-outline necessary relaxation; it omits positive moving-pair clearance only in the master, never in full-original/native validation or H5. No solver call and no claim that a positive is valid.'})
    manifest=load(paths[3]);known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in paths[:1]+paths[2:3]:assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    assert load(paths[1])['passed'];core=shape(load(paths[0])['core']);raw=shape(load(paths[2])['raw_forbidden']);assert raw.contains_properly(core)
    faces,merge=convex_faces(core,deadline);assert not merge['merge_time_reached'];union=shapely.union_all(faces);assert union.equals(core)
    rows=[];edgecount=crosschecks=0;minimum=math.inf
    for i,poly in enumerate(faces):
        assert time.perf_counter()<deadline;poly=orient(poly,sign=1);assert raw.contains_properly(poly);minimum=min(minimum,raw.boundary.distance(poly));pts=list(poly.exterior.coords);planes=[]
        exact=[tuple(map(F,p)) for p in pts[:-1]]
        for p,q in zip(pts,pts[1:]):
            x,y=map(F,p);u,v=map(F,q);a,b=v-y,x-u
            if not a and not b:continue
            norm=max(abs(a),abs(b));a/=norm;b/=norm;c=a*x+b*y;A,B=round(a*10**7),round(b*10**7)
            error=abs(F(A)-a*10**7)*1500000+abs(F(B)-b*10**7)*3000000+1;bound=math.floor(c*1000*10**7-error)
            planes.append({'edge':[list(p),list(q)],'a':A,'b':B,'bound':bound,'sense':'ge','exact_error_bound':[error.numerator,error.denominator]});edgecount+=1
            # Independent rational checks: convex halfplanes, integer rounding interval and error bound.
            for px,py in exact:assert (u-x)*(py-y)-(v-y)*(px-x)>=0;crosschecks+=1
            assert F(bound)<=c*1000*10**7-error<F(bound+1)
            assert error>abs(F(A)-a*10**7)*1500000+abs(F(B)-b*10**7)*3000000
            assert max(abs(bound),2*(abs(A)*1500000+abs(B)*3000000))<2**60
        rows.append({'index':i,'geometry':mapping(poly),'outside_halfplanes':planes})
    assert minimum>.00009
    write(OUT/'pieces.json',{'coordinate_units_per_mm':1000,'normal_coefficient_scale':10000000,'source_core_sha256':digest(paths[0]),'faces':rows,
        'necessity_proof':'For any true outside edge a*dx+b*dy >= c*Q, the rounded integer projection is >= c*Q*S-error >= floor(c*Q*S-error). Every original nonoverlapping pair is outside every piece strictly contained in the original collision region. Positive solutions require complete guarded-original validation.'})
    result={'seconds':time.perf_counter()-start,'original_core_convex_pieces':len(rows),'necessary_outside_edges':edgecount,'physical_six_cog_pair_direction_upper_bound':15*edgecount,
        'old_guarded_pair_direction_count':39540,'whole_union_equals_complete_original_core':True,'all_pieces_strictly_inside_actual_raw_collision':True,'minimum_original_boundary_margin_mm':minimum,
        'exact_rational_convexity_checks':crosschecks,'exact_necessary_rounding_checks':edgecount,'merge':merge,'solver_calls':0,'positive_requires_full_guarded_validation':True,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);write(OUT/'checks.json',{'passed':True,**result,'committed_core_and_original_source_verified':True});print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
