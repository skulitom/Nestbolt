"""Read-back audit of complete collision-core pieces and necessary inequalities."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,time,shutil
import shapely
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-cog-coordinates-20261025/original-core-relaxation';OUT=BASE/'audit';OLD=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();data=load(BASE/'pieces.json');plan=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'pieces.json',BASE/'result.json',OLD/'cores/081.json',SOURCE/'mutual/081.json']},
        'method':'Read back all71 pieces and352 outside inequalities. Independently check exact rational convexity and match each stored edge to its source polygon boundary. Recalculate normalized exact edge coefficients and prove the claimed error dominates all integer coefficient rounding over the full signed coordinate box. Check bound+error <= exact edge offset, which proves necessary outside rounding regardless of the builder rounding implementation. Re-union all pieces and require exact geometric equality to the committed core; require strict containment of each whole piece in the actual raw original no-fit polygon. Positive master feasibility remains insufficient for clearance/native acceptance.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    core=shape(load(OLD/'cores/081.json')['core']);raw=shape(load(SOURCE/'mutual/081.json')['raw_forbidden']);assert digest(OLD/'cores/081.json')==data['source_core_sha256']
    polys=[];nplanes=ncross=0;minimum=float('inf')
    for i,row in enumerate(data['faces']):
        assert time.perf_counter()-start<60 and row['index']==i;poly=shape(row['geometry']);pts=list(poly.exterior.coords);assert poly.is_valid and len(poly.interiors)==0 and raw.contains_properly(poly)
        minimum=min(minimum,raw.boundary.distance(poly));polys.append(poly);edges=[(p,q) for p,q in zip(pts,pts[1:]) if p!=q];assert len(edges)==len(row['outside_halfplanes'])
        for (p,q),h in zip(edges,row['outside_halfplanes']):
            assert h['edge']==[list(p),list(q)] and h['sense']=='ge';x,y=map(F,p);u,v=map(F,q);dx,dy=u-x,v-y;scale=max(abs(dx),abs(dy));a,b=dy/scale,-dx/scale;c=a*x+b*y
            for point in pts[:-1]:
                px,py=map(F,point);assert dx*(py-y)-dy*(px-x)>=0;ncross+=1
            actual_error=abs(F(h['a'])-10000000*a)*1500000+abs(F(h['b'])-10000000*b)*3000000
            error=F(*h['exact_error_bound']);assert error>actual_error and F(h['bound'])+error<=c*1000*10000000
            assert h['a'] or h['b'];nplanes+=1
    assert shapely.union_all(polys).equals(core) and minimum>.00009
    checks={'passed':True,'seconds':time.perf_counter()-start,'whole_core_convex_pieces_verified':len(polys),'exact_necessary_edge_inequalities_verified':nplanes,
        'exact_rational_convexity_checks':ncross,'minimum_actual_original_boundary_margin_mm':minimum,'union_equals_entire_committed_original_core':True,
        'weak_rounding_preserves_all_true_outside_points_in_coordinate_range':True,'full_guarded_and_native_validation_still_required':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
