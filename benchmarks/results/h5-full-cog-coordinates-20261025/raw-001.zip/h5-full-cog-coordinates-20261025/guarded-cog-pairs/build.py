"""Complete guarded original-cog refinement of the two same-sheet domain tables."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
import numpy as np
import shapely
from shapely.geometry import shape,mapping
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-cog-coordinates-20261025';OLD=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'guarded-cog-pairs'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+60
    paths=[SOURCE/'mutual/081.json',SOURCE/'queries/018.json',SOURCE/'queries/019.json',SOURCE/'audit/checks.json',OLD/'audit/checks.json',BASE/'shared-search/result.json']+[OLD/'cases'/f'{i:03d}.{ext}' for i in [162,163] for ext in ['json','bin']]
    assert load(paths[3])['passed'] and load(paths[4])['passed'] and load(paths[5])['status']=='MASTER_UNKNOWN'
    oldrows={i:load(OLD/'cases'/f'{i:03d}.json') for i in [162,163]};planned=sum(r['domain_pairs']-r['conflicts'] for r in oldrows.values());assert planned<=300000
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':60,'maximum_refined_pairs':300000,'cases':[162,163],'queries':[18,19],
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'unmarked_pairs_planned':planned,'whole_difference_padding_mm':.00001,'guarded_core_inset_mm':.0001,
        'method':'Retain all previously certified raw-original cog pair bits. Examine every remaining pair in complete q18/q18 and q19/q19 tables using the whole actual inset-domain convex difference padded outward by0.00001mm. Exclude a pair only if that whole hull lies strictly inside a0.0001mm inset of the complete independently audited guarded original cog no-fit polygon, whose whole region is covered by the full source-model forbidden pieces. These new bits are exclusions for the declared original guarded construction, not an unrestricted or native-optimum impossibility claim. No solver call, guard change, omitted part or relaxed material target.'})
    mutual=load(paths[0]);expanded=shape(mutual['expanded_forbidden']);core=expanded.buffer(-.0001,join_style='mitre').intersection(expanded);assert not core.is_empty and expanded.contains_properly(core)
    pieces=shapely.union_all([shape(f['expanded_face']) for f in mutual['faces']]);assert pieces.covers(expanded)
    margin=core.boundary.distance(expanded.boundary);write(OUT/'core.json',{'geometry':mapping(core),'guarded_boundary_margin_mm':margin,'source_guarded_sha256':digest(paths[0]),'full_model_piece_union_covers_guarded_region':True})
    shapely.prepare(core);summary=[];tested=added=0
    for case,qi in [(162,18),(163,19)]:
        if time.perf_counter()>=deadline:break
        meta=oldrows[case];d=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];vertices=[list(shape(f['inset_face']).exterior.coords)[:-1] for f in d];width=max(map(len,vertices));a=np.array([v+[v[0]]*(width-len(v)) for v in vertices])
        raw=(OLD/'cases'/f'{case:03d}.bin').read_bytes();assert sha256(raw).hexdigest()==meta['packed_sha256'];flags=np.unpackbits(np.frombuffer(raw,dtype=np.uint8),bitorder='big')[:len(d)**2].reshape(len(d),len(d)).astype(bool)
        ai,bi=np.nonzero(~flags);batch=max(1,min(2048,131072//(width*width)));checked=found=0
        for lo in range(0,len(ai),batch):
            if time.perf_counter()>=deadline:break
            ia,ib=ai[lo:lo+batch],bi[lo:lo+batch];diff=(a[ib,None,:,:]-a[ia,:,None,:]).reshape(len(ia),-1,2)
            hulls=shapely.convex_hull(shapely.multipoints(diff));padded=shapely.buffer(hulls,.00001,join_style='mitre');assert not np.any(shapely.is_empty(padded));good=shapely.contains_properly(core,padded)
            flags[ia[good],ib[good]]=True;checked+=len(ia);found+=int(np.count_nonzero(good))
        p=OUT/'cases'/f'{case:03d}.bin';p.write_bytes(np.packbits(flags.reshape(-1),bitorder='big').tobytes())
        row={'case':case,'query':qi,'domain_count':len(d),'domain_indices':[x['index'] for x in d],'source_raw_conflicts':meta['conflicts'],'unmarked_pairs_planned':len(ai),
            'unmarked_pairs_tested':checked,'new_guarded_conflicts':found,'total_conflicts':int(np.count_nonzero(flags)),'remaining_unexcluded_pairs':len(d)**2-int(np.count_nonzero(flags)),
            'complete':checked==len(ai),'packed_bit_order':'big','packed_layout':'row-major A then B','packed_bytes':p.stat().st_size,'packed_sha256':digest(p)}
        write(OUT/'cases'/f'{case:03d}.json',row);summary.append(row);tested+=checked;added+=found
        print({k:v for k,v in row.items() if k!='domain_indices'},flush=True)
        if not row['complete']:break
    pending=[i for i in [162,163] if not any(r['case']==i and r['complete'] for r in summary)];write(OUT/'pending-cases.json',pending)
    result={'seconds':time.perf_counter()-start,'planned_pairs':planned,'tested_pairs':tested,'new_guarded_conflicts':added,'complete_cases':sum(r['complete'] for r in summary),'pending_cases':pending,
        'guarded_core_boundary_margin_mm':margin,'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
