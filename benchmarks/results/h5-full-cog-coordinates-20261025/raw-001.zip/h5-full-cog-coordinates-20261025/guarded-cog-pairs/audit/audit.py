"""Independent nanometre enclosures for all added guarded cog conflicts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,math,time,shutil,traceback
import numpy as np
import shapely
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-cog-coordinates-20261025/guarded-cog-pairs';OUT=BASE/'audit';OLD=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    assert result['complete_cases']==2 and not load(BASE/'pending-cases.json') and result['tested_pairs']==result['planned_pairs']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Verify source hashes, every old raw bit, complete scan counts, exact domain order and all packed lengths/padding. Construct different complete difference enclosures: exact-rational vertices become outward integer nanometre boxes with one extra unit on each side; take all four corners of every B-box minus A-box. Certify every added whole hull strictly inside the guarded core, and independently verify that core is inside the source guarded polygon and whole union of all61 full model forbidden pieces. A false bit remains nonproof; these exclusions apply to the declared guarded construction only.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-cog-region-capacities-20261025/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for n in ['queries/018.json','queries/019.json','mutual/081.json']:
        p=SOURCE/n;assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    mutual=load(SOURCE/'mutual/081.json');expanded=shape(mutual['expanded_forbidden']);core=shape(load(BASE/'core.json')['geometry'])
    assert expanded.contains_properly(core) and expanded.boundary.distance(core)>0.00009
    full_union=shapely.union_all([shape(f['expanded_face']) for f in mutual['faces']]);assert full_union.covers(core)
    shapely.prepare(core);added=retained=vertexcount=tested=0;cases=[];Q=1000000;assert F(math.ulp(3001.0))<F(1,Q)
    for case,qi in [(162,18),(163,19)]:
        meta=load(BASE/'cases'/f'{case:03d}.json');oldmeta=load(OLD/'cases'/f'{case:03d}.json');domains=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];n=len(domains);lists=[]
        assert meta['domain_indices']==oldmeta['domain_indices_a']==oldmeta['domain_indices_b']==[d['index'] for d in domains] and meta['domain_count']==n
        for d in domains:
            boxes=[]
            for x,y in list(shape(d['inset_face']).exterior.coords)[:-1]:
                a,b=F(x)*Q,F(y)*Q;r=[math.floor(a)-1,math.floor(b)-1,math.ceil(a)+1,math.ceil(b)+1]
                assert r[0]+1<=a<=r[2]-1 and r[1]+1<=b<=r[3]-1;boxes.append(r);vertexcount+=1
            lists.append(boxes)
        width=max(map(len,lists));arr=np.array([r+[r[0]]*(width-len(r)) for r in lists],dtype=np.int64)
        def bits(p,expected_hash):
            assert digest(p)==expected_hash and p.stat().st_size==(n*n+7)//8
            b=np.unpackbits(np.frombuffer(p.read_bytes(),dtype=np.uint8),bitorder='big');assert not np.any(b[n*n:]);return b[:n*n].reshape(n,n).astype(bool)
        new=bits(BASE/'cases'/f'{case:03d}.bin',meta['packed_sha256']);old=bits(OLD/'cases'/f'{case:03d}.bin',oldmeta['packed_sha256']);assert not np.any(old & ~new)
        ai,bi=np.nonzero(new & ~old);assert len(ai)==meta['new_guarded_conflicts'] and int(np.count_nonzero(new))==meta['total_conflicts'] and int(np.count_nonzero(old))==meta['source_raw_conflicts']
        assert meta['complete'] and meta['unmarked_pairs_tested']==meta['unmarked_pairs_planned']==n*n-int(np.count_nonzero(old))
        batch=max(1,min(2048,131072//(4*width*width)))
        for lo in range(0,len(ai),batch):
            assert time.perf_counter()-start<60
            a,b=arr[ai[lo:lo+batch]],arr[bi[lo:lo+batch]]
            lx=b[:,None,:,0]-a[:,:,None,2];ly=b[:,None,:,1]-a[:,:,None,3];hx=b[:,None,:,2]-a[:,:,None,0];hy=b[:,None,:,3]-a[:,:,None,1]
            corners=np.stack([np.stack([lx,ly],axis=-1),np.stack([lx,hy],axis=-1),np.stack([hx,hy],axis=-1),np.stack([hx,ly],axis=-1)],axis=-2).reshape(len(a),-1,2)
            assert np.max(np.abs(corners))<3001000000
            hulls=shapely.convex_hull(shapely.multipoints(corners/Q));assert np.all(shapely.contains_properly(core,hulls))
        added+=len(ai);retained+=int(np.count_nonzero(old));tested+=meta['unmarked_pairs_tested'];cases.append({'case':case,'query':qi,'new_guarded_conflicts_verified':len(ai),'remaining_unexcluded_pairs':n*n-int(np.count_nonzero(new))})
    assert added==result['new_guarded_conflicts'] and tested==result['tested_pairs'];write(OUT/'cases.json',cases)
    checks={'passed':True,'seconds':time.perf_counter()-start,'complete_cases':2,'all_original_raw_conflicts_retained':retained,'all_added_guarded_conflicts_verified':added,
        'all_previously_unmarked_pairs_scanned':tested,'exact_outward_vertex_boxes_checked':vertexcount,'whole_guarded_core_covered_by_all61_source_model_pieces':True,
        'independent_whole_convex_enclosures':True,'packed_order_hashes_counts_and_padding_verified':True,'not_unrestricted_packing_impossibility':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
