"""Retain the terminal full-cog UNKNOWN and measured budget overrun accurately."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-cog-coordinates-20261025';RUN=BASE/'shared-search';OUT=BASE/'search-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();r=load(RUN/'result.json');b=load(RUN/'budget.json');model=load(RUN/'solve/model-audit.json');solved=load(RUN/'solve/result.json');opened=load(RUN/'solve/opened.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in RUN.rglob('*') if p.is_file()},
        'method':'Audit terminal status, source/model/parameter hashes and one-call-only pipeline accounting. Record, rather than hide or pass, any solver soft-limit overshoot and shared60-second overrun. UNKNOWN without an incumbent is no feasibility or impossibility proof, and does not authorize retry or continuation.'})
    for plan in [load(RUN/'plan.json'),load(RUN/'solve/plan.json')]:
        for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    assert model['passed'] and digest(RUN/'solve/model.pb')==model['model_sha256'] and digest(RUN/'solve/parameters.pbtxt')==model['parameters_sha256']
    params=text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
    assert params.max_time_in_seconds==opened['seconds_limit']==model['remaining_shared_budget_at_parameter_set'] and 0<params.max_time_in_seconds<=60
    assert params.num_search_workers==8 and params.random_seed==0 and params.cp_model_presolve and params.cp_model_probing_level==0 and params.symmetry_level==0
    assert b['shared_seconds']==60 and b['deadline_perf_counter']==b['start_perf_counter']+60 and r['master_solver_calls']==1 and r['anchor_solver_calls']==0
    assert r['status']=='MASTER_UNKNOWN' and solved['status']=='UNKNOWN' and not solved['has_necessary_domain_candidate'] and solved['solver_calls']==1
    assert len(r['stages'])==1 and r['stages'][0]['stage']=='master' and r['stages'][0]['exit_code']==0 and r['elapsed_seconds']>=r['stages'][0]['seconds']
    assert model['construction_seconds']+model['audit_seconds']+solved['seconds']<=r['stages'][0]['seconds']
    assert not (RUN/'solve/selection.json').exists() and not (RUN/'solve/necessary-cog-positions.json').exists() and not (RUN/'anchor-solve').exists()
    checks={'passed':True,'seconds':time.perf_counter()-start,'terminal_status':'UNKNOWN','incumbent':False,'master_solver_calls':1,'anchor_solver_calls':0,
        'declared_shared_seconds':60,'actual_shared_seconds':r['elapsed_seconds'],'shared_budget_honored':r['elapsed_seconds']<=60,'shared_overrun_seconds':max(0,r['elapsed_seconds']-60),
        'declared_solver_seconds':params.max_time_in_seconds,'actual_solver_seconds':solved['seconds'],'solver_soft_limit_overshoot_seconds':max(0,solved['seconds']-params.max_time_in_seconds),
        'source_model_and_parameters_verified':True,'completed_call_closed_no_retry':True,'no_feasibility_or_impossibility_claim':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
