"""Bounded exact full-original cog separation inventory and independent oracle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,time,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';BASE=ROOT/'output/h5-full-cog-coordinates-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    BASE.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');start=time.perf_counter();paths=[SOURCE/'plan.json',SOURCE/'queries/018.json',SOURCE/'queries/019.json',SOURCE/'mutual/081.json',SOURCE/'audit/checks.json',ROOT/'benchmarks/results/h5-cog-region-capacities-20261025/raw-manifest.json']
    write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_and_audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'Retain every guarded full-original cog/cog forbidden piece from audited case81. Obtain each sheet\'s whole allowed cog-anchor box from every original domain. Compute exact projection minima/maxima of every outside inequality over both same-sheet difference rectangles. A whole piece may be omitted only when an edge always separates for both sheets; a direction may be omitted only if neither rectangle can reach its bound. Add explicit selected-query box conditions in the model so every reduction is directly implied by its variables. Independently reconstruct all extrema from all four rectangle corners and verify committed input hashes. No solver call or weakening of original geometry.'})
    assert load(paths[4])['passed'];spec=load(paths[0]);mutual=load(paths[3]);assert mutual['case']['profile_a']==mutual['case']['profile_b']==9
    bounds={};diff={}
    for q in [18,19]:
        ds=load(SOURCE/'queries'/f'{q:03d}.json')['domains'];b=[min(d['coordinate_bounds'][i] for d in ds) if i<2 else max(d['coordinate_bounds'][i] for d in ds) for i in range(4)]
        bounds[str(q)]=b;diff[str(q)]=[b[0]-b[2],b[1]-b[3],b[2]-b[0],b[3]-b[1]]
    faces=[]
    for f in mutual['faces']:
        edges=[]
        for i,h in enumerate(f['outside_halfplanes']):
            limits={q:[sum(min(c*lo,c*hi) for c,lo,hi in [(h['a'],r[0],r[2]),(h['b'],r[1],r[3])]),sum(max(c*lo,c*hi) for c,lo,hi in [(h['a'],r[0],r[2]),(h['b'],r[1],r[3])])] for q,r in diff.items()}
            edges.append({'edge':i,'sheet_query_projection_bounds':limits,'always':min(v[0] for v in limits.values())>=h['bound'],'possible':max(v[1] for v in limits.values())>=h['bound']})
        always=any(e['always'] for e in edges);faces.append({'face':f['index'],'edges':edges,'always_separated':always,'possible_edges':[] if always else [e['edge'] for e in edges if e['possible']]})
    atlas={'queries':[18,19],'profile':9,'mutual_case':81,'query_anchor_bounds':bounds,'same_sheet_difference_bounds':diff,'faces':faces,'source_mutual_sha256':digest(paths[3])}
    write(BASE/'atlas.json',atlas)
    # Independent oracle uses a committed manifest and all four corners, not separable extrema.
    manifest=load(paths[5]);known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in paths[:4]:assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    cogs=[p for p in spec['parts'] if p['family']=='cog'];assert len(cogs)==6 and all(p['profiles']==[9] and p['queries']==[18,19] for p in cogs)
    vertex_projections=0
    for q in [18,19]:
        ds=load(SOURCE/'queries'/f'{q:03d}.json')['domains'];b=bounds[str(q)]
        assert all(b[0]<=d['coordinate_bounds'][0]<=d['coordinate_bounds'][2]<=b[2] and b[1]<=d['coordinate_bounds'][1]<=d['coordinate_bounds'][3]<=b[3] for d in ds)
        assert [min(d['coordinate_bounds'][0] for d in ds),min(d['coordinate_bounds'][1] for d in ds),max(d['coordinate_bounds'][2] for d in ds),max(d['coordinate_bounds'][3] for d in ds)]==b
    for source,row in zip(mutual['faces'],faces):
        assert source['index']==row['face'];always=[];possible=[]
        for i,(h,e) in enumerate(zip(source['outside_halfplanes'],row['edges'])):
            assert e['edge']==i
            vals={}
            for q,r in diff.items():
                v=[h['a']*x+h['b']*y for x,y in product([r[0],r[2]],[r[1],r[3]])];vals[q]=[min(v),max(v)];vertex_projections+=len(v)
            assert vals==e['sheet_query_projection_bounds'];a=all(v[0]>=h['bound'] for v in vals.values());p=any(v[1]>=h['bound'] for v in vals.values())
            assert a==e['always'] and p==e['possible'];always.append(a)
            if p:possible.append(i)
        assert row['always_separated']==any(always) and row['possible_edges']==([] if any(always) else possible)
    remaining=[f for f in faces if not f['always_separated']];count=sum(len(f['possible_edges']) for f in remaining)
    result={'seconds':time.perf_counter()-start,'original_forbidden_faces':len(faces),'whole_same_sheet_bound_separated_faces':len(faces)-len(remaining),
        'remaining_full_piece_disjunctions_per_pair':len(remaining),'original_edge_directions_per_pair':sum(len(f['edges']) for f in faces),'retained_directions_per_pair':count,
        'physical_cog_pairs':15,'physical_direction_variables':15*count,'physical_sheet_gated_piece_clauses':30*len(remaining),'exact_corner_projections_checked':vertex_projections,
        'all_source_original_faces_preserved_or_exactly_redundant':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(BASE/'result.json',result);(BASE/'audit').mkdir();write(BASE/'audit/checks.json',{'passed':True,**result,'committed_source_hashes_verified':True,'exact_integer_only':True});print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if BASE.exists():(BASE/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
