"""Exact integer outer cover of all full-guarded valid pair displacements."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,time,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-outer-displacement-boxes-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def merge_intervals(rows):
    merged=[]
    for lo,hi in sorted(rows):
        if merged and lo<=merged[-1][1]+1:merged[-1][1]=max(hi,merged[-1][1])
        else:merged.append([lo,hi])
    return merged
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+120
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']};uses={}
    for a,b in combinations(spec['parts'],2):
        for qa,qb in product(a['queries'],b['queries']):
            if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']:uses.setdefault((qa,qb),[]).append([a['part'],b['part']])
    cases=[{'index':i,'query_a':qa,'query_b':qb,'sheet':spec['queries'][qa]['sheet'],'mutual_case':lookup[(spec['queries'][qa]['profile'],spec['queries'][qb]['profile'])],'physical_pairs':uses[qa,qb]} for i,(qa,qb) in enumerate(sorted(uses))]
    assert len(cases)==164 and sum(len(c['physical_pairs']) for c in cases)==394
    paths=[SOURCE/'plan.json',SOURCE/'audit/checks.json']+[SOURCE/'queries'/f'{q:03d}.json' for q in queries]+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in spec['mutual_cases']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'cases':cases,'construction_seconds':120,'slab_width_coordinate_units':5000,'coordinate_units_per_mm':1000,'maximum_allowed_boxes':200000,'solver_calls':0,
        'method':'Build a necessary outer cover, not a safe packing representation, for all 164 full-guarded pair cases and 394 physical uses. Partition each complete integer difference rectangle into disjoint inclusive x slabs of width at most 5000 micrometres. For every source forbidden face derive a y interval whose entire slab rectangle fails every outside inequality: max(a*x)+b*y <= bound-1. Use exact integer floor/ceiling only. Remove the union of these certified failure rectangles, retain every remaining integer interval and merge only adjacent slabs with identical retained y bounds. The integer partition is complete and has no gaps. Therefore every displacement satisfying all original guarded source clauses is retained. Accepted boxes may contain invalid displacements, so positive assignments need full source and original geometry validation; a negative can only exclude the retained source angles/inward integer domains/fixed source, not unrestricted packing. No original clearance, stock, material requirement or part count changes.'})
    records=[];total=0;mutual={c['index']:load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in spec['mutual_cases']}
    for case in cases:
        if time.perf_counter()>=deadline or total>=200000:break
        bounds=[]
        for qi in [case['query_a'],case['query_b']]:
            ds=queries[qi]['domains'];bounds.append([min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)])
        a,b=bounds;r=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];columns=[];rectangles=[];active={};x=r[0];inner_count=0
        while x<=r[2]:
            hi=min(r[2],(x//5000+1)*5000-1);assert x<=hi and hi-x<5000;inside=[]
            for face in mutual[case['mutual_case']]['faces']:
                low,up=r[1],r[3]
                for h in face['outside_halfplanes']:
                    rhs=h['bound']-1-max(h['a']*x,h['a']*hi);B=h['b']
                    if B>0:up=min(up,rhs//B)
                    elif B<0:low=max(low,-((-rhs)//B))
                    elif rhs<0:low,up=1,0
                    if low>up:break
                if low<=up:inside.append({'face':face['index'],'y':[low,up]})
            forbidden=merge_intervals([p['y'] for p in inside]);allowed=[];cursor=r[1]
            for low,up in forbidden:
                if cursor<low:allowed.append([cursor,low-1])
                cursor=max(cursor,up+1)
            if cursor<=r[3]:allowed.append([cursor,r[3]])
            previous=active;active={}
            for low,up in allowed:
                key=(low,up)
                if key in previous and rectangles[previous[key]]['coordinate_bounds'][2]+1==x:
                    idx=previous[key];rectangles[idx]['coordinate_bounds'][2]=hi;rectangles[idx]['last_slab']=len(columns)
                else:
                    idx=len(rectangles);rectangles.append({'index':idx,'coordinate_bounds':[x,low,hi,up],'first_slab':len(columns),'last_slab':len(columns)})
                active[key]=idx
            columns.append({'x':[x,hi],'certified_failure_intervals':inside,'merged_failure_intervals':forbidden,'retained_y_intervals':allowed});inner_count+=len(inside);x=hi+1
        dest=OUT/'cases'/f"{case['index']:03d}.json";write(dest,{'case':case,'anchor_union_bounds_units1000':bounds,'difference_bounds_units1000':r,'slabs':columns,'domains':rectangles,'retained_box_is_not_a_safety_certificate':True})
        row={**case,'slabs':len(columns),'certified_inner_failure_rectangles':inner_count,'outer_allowed_boxes':len(rectangles),'physical_box_flags':len(rectangles)*len(case['physical_pairs'])};records.append(row);total+=len(rectangles)
        if len(records)%20==0:print({'completed_cases':len(records),'boxes':total,'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'summary.json',records);write(OUT/'pending-cases.json',cases[len(records):])
    result={'seconds':time.perf_counter()-start,'planned_cases':164,'completed_cases':len(records),'pending_cases':164-len(records),'integer_slabs':sum(r['slabs'] for r in records),'certified_inner_failure_rectangles':sum(r['certified_inner_failure_rectangles'] for r in records),'outer_allowed_boxes':total,'physical_box_flags':sum(r['physical_box_flags'] for r in records),
        'independent_audit_pending':True,'positive_safety_claim':False,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
