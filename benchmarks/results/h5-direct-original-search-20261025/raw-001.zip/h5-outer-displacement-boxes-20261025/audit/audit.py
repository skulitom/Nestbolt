"""Prove complete integer coverage and exact safety of every removed box."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction
from itertools import combinations,product
import json,time,math,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-outer-displacement-boxes-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert (BASE/'result.json').is_file();OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Rebuild the full pair inventory and source bounding rectangles. Independently derive every source-face slab interval with rational floor/ceiling, then check each removed rectangle at all four integer corners against every full original source failure inequality. Verify disjoint inclusive x-slab coverage and exact y complement partition, including boundaries. Expand each merged allowed box back across its declared slabs and require exact one-to-one coverage of all retained intervals with no omission or extra extent. Only removed rectangles are proved invalid; retained boxes are a necessary outer cover, not safe placements. No solver calls.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    assert result['completed_cases']==164 and not result['pending_cases'] and not load(BASE/'pending-cases.json') and result['seconds']<120
    manifest=load(ROOT/'benchmarks/results/h5-all-original-cell-search-20261025/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    for p in [SOURCE/'plan.json']+list((SOURCE/'queries').glob('*.json'))+list((SOURCE/'mutual').glob('*.json')):assert digest(p)==known['source-inputs/'+p.relative_to(ROOT).as_posix()]
    uses={}
    for a,b in combinations(spec['parts'],2):
        for qa,qb in product(a['queries'],b['queries']):
            if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']:uses.setdefault((qa,qb),[]).append([a['part'],b['part']])
    assert len(uses)==164 and sum(map(len,uses.values()))==394
    rows=[];corners=slabs_count=inner_count=boxcount=0
    for ci,(qa,qb) in enumerate(sorted(uses)):
        assert time.perf_counter()-start<120
        data=load(BASE/'cases'/f'{ci:03d}.json');case=data['case'];mi=next(c['index'] for c in spec['mutual_cases'] if c['profile_a']==spec['queries'][qa]['profile'] and c['profile_b']==spec['queries'][qb]['profile'])
        assert case==plan['cases'][ci]=={'index':ci,'query_a':qa,'query_b':qb,'sheet':spec['queries'][qa]['sheet'],'mutual_case':mi,'physical_pairs':uses[qa,qb]}
        boxes=[]
        for qi in [qa,qb]:
            ds=queries[qi]['domains'];boxes.append([min(d['coordinate_bounds'][k] for d in ds) if k<2 else max(d['coordinate_bounds'][k] for d in ds) for k in range(4)])
        a,b=boxes;r=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];assert boxes==data['anchor_union_bounds_units1000'] and r==data['difference_bounds_units1000']
        faces=load(SOURCE/'mutual'/f'{mi:03d}.json')['faces'];columns=data['slabs'];cursor=r[0];expected=[]
        for index,col in enumerate(columns):
            x,hi=col['x'];assert x==cursor and hi==min(r[2],(x//5000+1)*5000-1) and x<=hi;cursor=hi+1;slabs_count+=1
            inner=[]
            for face in faces:
                lows=[r[1]];highs=[r[3]];impossible=False
                for h in face['outside_halfplanes']:
                    limit=h['bound']-1-max(h['a']*x,h['a']*hi)
                    if h['b']>0:highs.append(math.floor(Fraction(limit,h['b'])))
                    elif h['b']<0:lows.append(math.ceil(Fraction(limit,h['b'])))
                    elif limit<0:impossible=True
                lo,up=max(lows),min(highs)
                if impossible or lo>up:continue
                inner.append({'face':face['index'],'y':[lo,up]});inner_count+=1
                for px,py in product([x,hi],[lo,up]):
                    for h in face['outside_halfplanes']:assert h['a']*px+h['b']*py<=h['bound']-1;corners+=1
            assert inner==col['certified_failure_intervals']
            # Sweep all endpoints, retaining integer intervals covered by no certified failure rectangle.
            events={r[1]:0,r[3]+1:0}
            for entry in inner:
                lo,up=entry['y'];events[lo]=events.get(lo,0)+1;events[up+1]=events.get(up+1,0)-1
            points=sorted(events);level=0;allowed=[];forbidden=[]
            for lo,nextpoint in zip(points,points[1:]):
                level+=events[lo];assert level>=0;target=forbidden if level else allowed;up=nextpoint-1
                if target and target[-1][1]+1==lo:target[-1][1]=up
                else:target.append([lo,up])
            assert level+events[points[-1]]==0 and allowed==col['retained_y_intervals'] and forbidden==col['merged_failure_intervals'];expected.extend((index,lo,up) for lo,up in allowed)
        assert cursor==r[2]+1
        expanded=[];seen_indices=[]
        for d in data['domains']:
            lo,up=d['first_slab'],d['last_slab'];b=d['coordinate_bounds'];assert 0<=lo<=up<len(columns) and b[0]==columns[lo]['x'][0] and b[2]==columns[up]['x'][1] and r[1]<=b[1]<=b[3]<=r[3]
            expanded.extend((i,b[1],b[3]) for i in range(lo,up+1));seen_indices.append(d['index'])
        assert seen_indices==list(range(len(data['domains']))) and len(expanded)==len(set(expanded)) and sorted(expanded)==sorted(expected)
        boxcount+=len(data['domains']);rows.append({'case':ci,'slabs':len(columns),'outer_boxes':len(data['domains']),'full_integer_partition_verified':True,'removed_rectangles_satisfy_complete_source_failure_clause':True})
        if len(rows)%20==0:print({'audited_cases':len(rows),'exact_corner_inequalities':corners,'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'case-checks.json',rows)
    checks={'passed':True,'seconds':time.perf_counter()-start,'cases':164,'physical_pair_mode_uses':394,'integer_slabs':slabs_count,'certified_inner_failure_rectangles':inner_count,'exact_corner_inequalities':corners,'outer_allowed_boxes':boxcount,
        'entire_integer_difference_rectangles_partitioned_without_gaps':True,'every_full_guarded_source_valid_integer_displacement_retained':True,'every_removed_box_proved_invalid':True,'retained_box_is_not_a_safety_certificate':True,
        'explicit_original_query_difference_bounds_required':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<120 and boxcount==result['outer_allowed_boxes'] and inner_count==result['certified_inner_failure_rectangles'];write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
