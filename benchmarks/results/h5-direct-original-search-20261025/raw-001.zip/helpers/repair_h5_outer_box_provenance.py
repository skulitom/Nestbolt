"""Keep the failed lookup and resolve the cog source in its committed archive."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-outer-displacement-boxes-20261025'
s=(ROOT/'output/audit_h5_outer_displacement_boxes.py').read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-provenance-repaired'")
needle="    spec=load(SOURCE/'plan.json');"
insert="    earlier=load(ROOT/'benchmarks/results/h5-six-cog-guided-search-20261025/raw-manifest.json');cogkey='source-inputs/output/h5-full-original-joint-prepared-20261025/mutual/081.json';previous={r['path']:r['sha256'] for r in earlier['files']+earlier['aliases']};assert cogkey not in known;known[cogkey]=previous[cogkey]\n"
assert needle in s;s=s.replace(needle,insert+needle)
with (ROOT/'output/audit_h5_outer_displacement_boxes_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (BASE/'audit/repair-record.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'failure_preserved':True,'cause':'The newest archive contains remaining non-cog mutual sources; cog source 081 is preserved in the prior guided-search archive. A lookup assumed both lived in the newer manifest.',
        'repair':'Resolve only source mutual/081.json against the committed h5-six-cog-guided-search-20261025 manifest. Keep all other source checks and the full exact partition/invalid-box audit unchanged. Use a separate repaired audit directory.',
        'geometry_regenerated':False,'solver_calls':0},f,indent=2);f.write('\n')
print('Prepared corrected provenance lookup; original failure retained.')
