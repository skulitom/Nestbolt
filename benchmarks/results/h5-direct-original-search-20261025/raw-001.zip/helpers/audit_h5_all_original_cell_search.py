"""Read back the closed complete-coordinate search and any positive positions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-all-original-cell-search-20261025';RUN=BASE/'shared-search';OUT=BASE/'search-audit';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';CELLS=ROOT/'output/h5-remaining-displacement-cells-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert (RUN/'result.json').is_file();OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in RUN.rglob('*') if p.is_file()},
        'method':'Verify source hashes, actual model and parameters, closed one-call status and shared timing. For a positive, reconstruct mandatory selected identities, every inward domain and all original guarded same-sheet separation clauses directly from source, verify exact cell activation/membership and the certified exclusion. No solver continuation. Original geometry/native verification remains separate and is never inferred from a partial or negative result.'})
    budget=load(RUN/'budget.json');result=load(RUN/'result.json');model=load(RUN/'solve/model-audit.json');solved=load(RUN/'solve/result.json');opened=load(RUN/'solve/opened.json')
    for path in [RUN/'plan.json',RUN/'solve/plan.json']:
        p=load(path)
        for n,h in p['inputs'].items():assert digest(ROOT/n)==h
        for field,folder in [('query_hashes',SOURCE/'queries'),('group_hashes',ROOT/'output/h5-convex-domain-conflicts-20261025/groups')]:
            for i,h in p.get(field,{}).items():assert digest(folder/f'{int(i):03d}.json')==h
    assert model['passed'] and model['all36_physical_pairs_have_full_guarded_coordinates'] and model['simultaneous_original_anchor_variables']==18 and model['hints']==79 and model['required_originals']==66
    assert digest(RUN/'solve/model.pb')==model['model_sha256']==opened['model_sha256'] and digest(RUN/'solve/parameters.pbtxt')==model['parameters_sha256']
    params=text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
    assert params.max_time_in_seconds==opened['seconds_limit']==min(45,model['remaining_shared_budget_at_parameter_set']) and params.num_search_workers==8 and params.random_seed==0
    assert budget['shared_seconds']==60 and budget['master_solver_cap_seconds']==45 and budget['solver_shutdown_reserve_seconds']==2 and budget['deadline_perf_counter']==budget['start_perf_counter']+60
    assert params.cp_model_presolve and params.cp_model_probing_level==0 and params.symmetry_level==0
    assert solved['solver_calls']==result['solver_calls_opened']==1 and result['status']=='MASTER_'+solved['status'] and result['stage']['exit_code']==0
    assert solved['seconds']+model['construction_seconds']+model['audit_seconds']<=result['stage']['seconds']<=result['elapsed_seconds']
    positive=solved['status'] in ['OPTIMAL','FEASIBLE'];assert positive==solved['has_full_original_model_candidate']==solved['has_necessary_domain_candidate'];planes=pieces=cellplanes=0;same_pairs=0
    if positive:
        selected=load(RUN/'solve/selection.json');positions=load(RUN/'solve/original-positions.json');spec=load(SOURCE/'plan.json');parts=selected['movable_parts'];assert selected['fixed_items']==spec['fixed_items'] and selected['required_originals']==66 and [p['part'] for p in positions]==list(range(9))
        for i,(p,xy) in enumerate(zip(parts,positions)):
            original=spec['parts'][i];assert p['part']==i and p['item']==original['index'] and p['family']==original['family'] and p['query'] in original['queries']
            q=spec['queries'][p['query']];assert q['profile']==p['profile'] and q['sheet']==p['sheet'];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];x,y=xy['x_units'],xy['y_units'];assert isinstance(x,int) and isinstance(y,int)
            for b in [q['anchor_bounds_units1000'],d['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
            for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];planes+=1
        clauses=[]
        for a,b in combinations(parts,2):
            if a['sheet']!=b['sheet']:continue
            mi=next(c['index'] for c in spec['mutual_cases'] if c['profile_a']==a['profile'] and c['profile_b']==b['profile']);x=positions[b['part']]['x_units']-positions[a['part']]['x_units'];y=positions[b['part']]['y_units']-positions[a['part']]['y_units'];count=0
            for face in load(SOURCE/'mutual'/f'{mi:03d}.json')['faces']:assert any(h['a']*x+h['b']*y>=h['bound'] for h in face['outside_halfplanes']);pieces+=1;count+=1
            clauses.append({'parts':[a['part'],b['part']],'mutual_case':mi,'original_guarded_clauses':count});same_pairs+=1
        rows=load(RUN/'solve/remaining-cell-selection.json');plan=load(CELLS/'plan.json');expected=[(c['index'],pair) for c in plan['cases'] for pair in c['physical_pairs']];assert [(r['case'],r['parts']) for r in rows]==expected
        for row in rows:
            case=plan['cases'][row['case']];i,j=row['parts'];active=parts[i]['query']==case['query_a'] and parts[j]['query']==case['query_b'];assert active==row['active'] and len(row['chosen_cells'])==int(active)
            if not active:continue
            data=load(CELLS/'cases'/f"{row['case']:03d}"/'selected.json');d=next(d for d in data['domains'] if d['index']==row['chosen_cells'][0]);x=positions[j]['x_units']-positions[i]['x_units'];y=positions[j]['y_units']-positions[i]['y_units']
            for b in [data['difference_bounds_units1000'],d['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
            for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];cellplanes+=1
        excluded=load(ROOT/'output/h5-six-cog-guided-search-20261025/conflict-proof-audit-completed/certified-selected-combination-exclusion.json')['parts'];assert any((a['query'],a['domain_row'])!=(b['query'],b['domain_row']) for a,b in zip(parts,excluded))
        write(OUT/'original-pair-clause-checks.json',clauses);write(OUT/'verified-original-positions.json',[{**p,**xy} for p,xy in zip(parts,positions)])
    else:
        assert solved['status'] in ['UNKNOWN','INFEASIBLE'] and not (RUN/'solve/selection.json').exists() and not (RUN/'solve/original-positions.json').exists()
    checks={'passed':True,'seconds':time.perf_counter()-start,'terminal_status':solved['status'],'integer_candidate':positive,'solver_calls':1,'actual_solver_seconds':solved['seconds'],'declared_solver_seconds':params.max_time_in_seconds,
        'solver_soft_limit_overshoot_seconds':max(0,solved['seconds']-params.max_time_in_seconds),'actual_shared_seconds':result['elapsed_seconds'],'shared_budget_honored':result['elapsed_seconds']<=60,'shared_overrun_seconds':max(0,result['elapsed_seconds']-60),
        'mandatory_moving_originals':9,'fixed_originals':57,'required_originals':66,'same_sheet_original_pairs_checked':same_pairs,'source_inward_halfplanes_checked':planes,'source_full_guarded_clauses_checked':pieces,'remaining_cell_halfplanes_checked':cellplanes,
        'completed_call_closed_no_retry':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
