"""Prepare the runner and read-back for one new projected-model call."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'output'
def save(name,s):
    with (R/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'run_h5_all_original_cell_search.py').read_text(encoding='utf-8').replace('h5-all-original-cell-search-20261025','h5-direct-original-search-20261025').replace('solve_h5_all_original_cell_master.py','solve_h5_direct_original_model.py')
s=s.replace("ROOT/'output/audit_h5_all_original_cell_master.py'","ROOT/'output/h5-all-original-cell-search-20261025/direct-geometry-projection/audit/checks.json'")
s=s.replace("'solver_shutdown_reserve_seconds':2","'solver_shutdown_reserve_seconds':10")
s=s.replace('One new full original-coordinate model, with all nine anchors and all 36 moving-pair guarded separations. Model construction, independent protobuf reconstruction and the sole capped solver call share 60 seconds with a two-second solver shutdown reserve.',
    'One distinct table-free original-coordinate model, retaining all nine anchors and all 36 direct guarded pair relations. Loading the archived independently audited model, exact import/export verification and the sole capped solver call share 60 seconds with a ten-second shutdown reserve. Prior model construction/projection audit stays offline and is not a production-budget pass.')
save('run_h5_direct_original_search.py',s)
s=(R/'audit_h5_all_original_cell_search.py').read_text(encoding='utf-8').replace('h5-all-original-cell-search-20261025','h5-direct-original-search-20261025').replace("budget['solver_shutdown_reserve_seconds']==2","budget['solver_shutdown_reserve_seconds']==10")
save('audit_h5_direct_original_search.py',s)
print('Prepared new one-call runner and terminal read-back with ten-second reserve.')
