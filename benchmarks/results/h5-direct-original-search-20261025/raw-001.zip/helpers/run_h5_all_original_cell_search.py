"""One complete original-coordinate call inside a shared 60-second budget."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-all-original-cell-search-20261025';OUT=BASE/'shared-search'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();deadline=start+60
    inputs=[ROOT/'output/h5-remaining-displacement-cells-20261025/audit-repaired/checks.json',ROOT/'output/h5-cog-displacement-cells-20261025/audit/checks.json',ROOT/'output/h5-six-cog-guided-search-20261025/conflict-proof-audit-completed/checks.json',ROOT/'output/solve_h5_all_original_cell_master.py',ROOT/'output/audit_h5_all_original_cell_master.py']
    assert all(load(p)['passed'] for p in inputs[:3])
    write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'start_perf_counter':start,'deadline_perf_counter':deadline,'master_solver_cap_seconds':45,'solver_shutdown_reserve_seconds':2,'maximum_solver_calls':1,'workers':8,'random_seed':0,'previous_calls_remain_closed':True})
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'budget':'budget.json',
        'method':'One new full original-coordinate model, with all nine anchors and all 36 moving-pair guarded separations. Model construction, independent protobuf reconstruction and the sole capped solver call share 60 seconds with a two-second solver shutdown reserve. Offline displacement preparation is retained separately and is not a production-budget pass. Stop at the terminal call; never retry, extend or reseed. A positive must undergo separate saved-position read-back, complete original geometry and native validation before any target-witness claim. A negative only concerns the stated constructive subset.'})
    status='NOT_STARTED';record={};began=time.perf_counter()
    try:
        r=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(ROOT/'output/solve_h5_all_original_cell_master.py')],cwd=ROOT,capture_output=True,timeout=max(.01,deadline-time.perf_counter()))
        (OUT/'master-stdout.txt').write_bytes(r.stdout);(OUT/'master-stderr.txt').write_bytes(r.stderr);record={'seconds':time.perf_counter()-began,'exit_code':r.returncode};write(OUT/'master-process.json',record);print(r.stdout.decode(errors='replace'),flush=True)
        status=('MASTER_'+load(OUT/'solve/result.json')['status']) if r.returncode==0 else 'STAGE_FAILED'
    except subprocess.TimeoutExpired as e:
        (OUT/'master-stdout.txt').write_bytes(e.stdout or b'');(OUT/'master-stderr.txt').write_bytes(e.stderr or b'');status='SHARED_BUDGET_PROCESS_TIMEOUT';record={'seconds':time.perf_counter()-began,'timeout':True}
    result={'status':status,'elapsed_seconds':time.perf_counter()-start,'shared_budget_seconds':60,'stage':record,'solver_calls_opened':int((OUT/'solve/opened.json').exists()),'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
