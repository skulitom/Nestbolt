"""One call using the exact independently audited table-free original model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,sys,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-original-search-20261025';OUT=BASE/'shared-search/solve';PREP=ROOT/'output/h5-all-original-cell-search-20261025/direct-geometry-projection';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter();projection=load(PREP/'result.json');verified=load(PREP/'audit/checks.json');assert verified['passed'] and projection['solver_calls']==0
    paths=[PREP/n for n in ['plan.json','result.json','model.pb','model.pbtxt','mapping.json','projection.json','audit/checks.json','audit/solver-import-roundtrip.pb']]+[SOURCE/'plan.json',OUT.parent/'budget.json',ROOT/'benchmarks/results/h5-all-original-cell-search-20261025/raw-manifest.json']
    manifest=load(paths[-1]);known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in paths[:8]:assert digest(p)==known[p.relative_to(ROOT/'output').as_posix()]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_solver_calls':1,'workers':8,'random_seed':0,'solver_cap_seconds':45,'shutdown_reserve_seconds':10,
        'method':'Load the exact archived projection whose 173814 retained constraints and 32074 variables were independently inverse-verified against the complete guarded original-coordinate model. Check committed hashes, parse the recorded text into the actual solver model, validate and export it, and require complete protobuf equality with the archived binary before the sole call. All 66 originals, nine movable and 57 fixed, and all 36 direct guarded pair relations remain mandatory. Only the obsolete compatibility table/private auxiliaries are absent. Preserve the 79 advisory hints. Loading and verification share a new 60-second budget with a single call capped at min(45, remaining minus 10) seconds; the larger reserve follows the previous observed soft overrun. This is a distinct model/call, not continuation of a closed search. Offline cells and prior projection audit are not a production-budget pass. A positive needs independent full original geometry and native validation.'})
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((PREP/'model.pb').read_bytes());assert digest(PREP/'model.pb')==projection['model_sha256']
    mapping=load(PREP/'mapping.json');spec=load(SOURCE/'plan.json');model=cp_model.CpModel();assert model.proto.parse_text_format((PREP/'model.pbtxt').read_text()) and model.validate()==''
    assert model.export_to_file(str(OUT/'model.pb'));loaded=time.perf_counter()-start;start=time.perf_counter();roundtrip=cp_model_pb2.CpModelProto();roundtrip.ParseFromString((OUT/'model.pb').read_bytes());assert roundtrip==actual
    assert len(actual.variables)==32074 and len(actual.constraints)==173814 and len(actual.solution_hint.vars)==79 and len(mapping['simultaneous_original_coordinates'])==9
    assert len(mapping['remaining_original_cell_pairs'])==364 and 'groups' not in mapping and verified['all_original_domain_area_count_and_guarded_pair_constraints_unchanged']
    write(OUT/'mapping.json',mapping)
    remaining=load(OUT.parent/'budget.json')['deadline_perf_counter']-time.perf_counter()-10;assert remaining>0
    params={'max_time_in_seconds':min(45,remaining),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');checked=time.perf_counter()-start
    audit={'passed':True,'construction_seconds':loaded,'construction_scope':'Load archived independently verified model, validate and export; original cell preparation and projection audit were offline.','audit_seconds':checked,'variables':32074,'constraints':173814,'required_originals':66,'mandatory_moving_originals':9,'fixed_originals':57,
        'simultaneous_original_anchor_variables':18,'all36_physical_pairs_have_full_guarded_coordinates':True,'hints':79,'optional_originals':0,'objectives':0,'compatibility_table_groups':0,'compatibility_table_literals':0,
        'actual_solver_import_export_matches_independently_verified_model':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining,'shutdown_reserve_seconds':10,'python':sys.version,'ortools':ortools.__version__}
    write(OUT/'model-audit.json',audit);print(audit,flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds'],'model_sha256':audit['model_sha256']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    def value(i):return solver.value(model.get_int_var_from_proto_index(i))
    if positive:
        selected=[]
        for p in mapping['parts']:
            modes=[m for m in p['modes'] if value(m['active'])];assert len(modes)==1;m=modes[0];rows=[i for i,v in enumerate(m['domains']) if value(v)];assert len(rows)==1;q=spec['queries'][m['query']];d=load(SOURCE/'queries'/f"{m['query']:03d}.json")['domains'][rows[0]]
            selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':rows[0],'domain_index':d['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':value(p['choice'])})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66})
        positions=[{'part':p['part'],'x_units':value(p['x']),'y_units':value(p['y'])} for p in mapping['simultaneous_original_coordinates']];write(OUT/'original-positions.json',positions);write(OUT/'necessary-cog-positions.json',positions[3:])
        chosen=[]
        for pair in mapping['guarded_displacement_cell_pairs']:
            chosen.append({'parts':pair['parts'],'chosen_cells':[{'query':m['query'],'cell_index':c['index']} for m in pair['sheet_modes'] if value(m['active']) for c in m['cells'] if value(c['flag'])]})
        write(OUT/'guarded-cog-cell-selection.json',chosen)
        write(OUT/'remaining-cell-selection.json',[{'parts':p['parts'],'case':p['case'],'active':bool(value(p['active'])),'chosen_cells':[c['index'] for c in p['cells'] if value(c['flag'])]} for p in mapping['remaining_original_cell_pairs']])
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_full_original_model_candidate':positive,'has_necessary_domain_candidate':positive,'response_stats':solver.response_stats(),
        'scope':'Complete direct original-coordinate constructive subset with all source domains/angles and fixed 57, stricter guarded cells and mandatory 66 originals. Not unrestricted packing. Offline preparation is not production qualification.','full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
