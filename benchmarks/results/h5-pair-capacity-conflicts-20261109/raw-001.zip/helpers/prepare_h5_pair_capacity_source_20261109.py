"""Transpose the complete certified covers and freeze a finite pair scope."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,time
from h5_pair_capacity_bitsets_20261109 import physical_columns,weight_planes,pair_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-combined-reference-20261109';OUT=ROOT/'output/h5-pair-capacity-source-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),ROOT/'output/h5_pair_capacity_bitsets_20261109.py',BASE/'round-00/audit/checks.json',BASE/'round-00/audit/plan.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json',ROOT/'output/h5-pair-capacity-controls-20261109/checks.json',ROOT/'output/h5-pair-capacity-controls-20261109/source-bindings.json',ROOT/'output/h5-pair-capacity-controls-process-20261109/process.json',ROOT/'output/h5-combined-reference-round-00-audit-process-20261109/process.json']
old=load(BASE/'round-00/audit/checks.json');assert old['passed'] and old['joint_fixed_point']
for p in inputs[-2:]:
    result=load(p);assert result['passed'] and result['closed'] and result['job']['active_processes']==0
for name,h in load(ROOT/'output/h5-pair-capacity-controls-20261109/source-bindings.json').items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
assert load(ROOT/'output/h5-pair-capacity-controls-20261109/checks.json')['passed']
summaries=[];batches=[]
for case in [1,9]:
    paths=[BASE/f'choice-{case:02d}-queries.json',BASE/f'round-00/choice-{case:02d}-signatures.json',BASE/f'round-00/choice-{case:02d}-queries.json',BASE/f'round-00/choice-{case:02d}-frontier.json'];inputs.extend(paths)
    source=load(paths[0]);maps=[{int(k,16):int(v,16) for k,v in rows} for rows in load(paths[1])];old_areas=load(paths[2]);front=load(paths[3]);active=set(front['remaining_current_positions']);qcount=len(source['query_positions']);qfull=(1<<qcount)-1
    masks=[[],[]];weights=[];pieces=[]
    for piece in load(inputs[4]):
        if piece['refinement_index']!=case:continue
        path=ROOT/piece['folder']/'atoms.json';inputs.append(path);records=load(path);pieces.append({'path':path.relative_to(ROOT).as_posix(),'offset':len(weights),'count':len(records)})
        for b,i,w in records:
            weights.append(w);masks[0].append(qfull^maps[0][int(b,16)]);masks[1].append(qfull^maps[1][int(i,16)])
    columns=[physical_columns(rows,qcount) for rows in masks];planes=weight_planes(weights);width=(len(weights)+7)//8
    for family in [0,1]:
        with (OUT/f'choice-{case:02d}-family-{family}-columns.bin').open('xb') as f:
            for column in columns[family]:f.write(column.to_bytes(width,'little'))
    for q in range(qcount):assert pair_areas(columns[0][q],columns[1][q],columns[0][q],columns[1][q],planes)==old_areas[q]['family_and_joint_area_upper_um2']
    targets=[[p for p in values if p in active] for values in source['query_targets']]
    eligible=[q for q in range(qcount) if targets[q]];anchors=[];rankings=[]
    for family in [0,1]:
        required=source['required_by_reference_family_um2'][family]
        ordered=sorted((q for q in eligible if source['query_families'][q]==family),key=lambda q:(min(Fraction(a,r) for a,r in zip(old_areas[q]['family_and_joint_area_upper_um2'],required)),q))
        chosen=ordered[:16];assert len(chosen)==16;anchors.extend(chosen);rankings.append(chosen)
    anchors=sorted(anchors);anchor_set=set(anchors);pairs=[]
    for anchor in anchors:
        # When both queries are anchors, the lower anchor owns the sole record.
        current=[sorted([anchor,q]) for q in eligible if not (q in anchor_set and q<anchor) and (q!=anchor or len(targets[q])>1)]
        pairs.extend(current)
        batches.append({'batch_index':len(batches),'refinement_index':case,'anchor_query':anchor,'pairs':current,'pair_count':len(current),'hard_cap_seconds':30,'audit_hard_cap_seconds':30})
    assert len(pairs)==len(set(tuple(v) for v in pairs))
    data={'refinement_index':case,'query_count':qcount,'physical_records':len(weights),'column_bytes':width,'weights':weights,'physical_pieces':pieces,'query_families':source['query_families'],'query_positions':source['query_positions'],'current_query_targets':targets,'eligible_queries':eligible,'anchors':anchors,'anchors_by_family':rankings,'pairs':len(pairs),'anchor_selection':'For each reference family, sixteen eligible queries with smallest exact minimum area/required ratio over the three audited single-reference bounds; query-index ties. All eligible partner queries, including same-query pairs only when at least two distinct targets exist.'}
    write(OUT/f'choice-{case:02d}-source.json',data)
    summaries.append({'refinement_index':case,'queries':qcount,'eligible_queries':len(eligible),'current_targets':sum(map(len,targets)),'physical_records':len(weights),'anchors':len(anchors),'complete_declared_pairs':len(pairs),'single_bounds_replayed':qcount*3})
write(OUT/'batches.json',batches)
cost=old['complete_preparation_seconds_if_consumed']+load(ROOT/'output/h5-pair-capacity-controls-process-20261109/process.json')['complete_seconds']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Pair remaining-family envelope = intersection of both conservative single-reference family covers; joint = union of these two intersections. Retain exact original physical rows. Every declared pair gets all three bounds. Exclude only coexistence of distinct current mapped targets. This finite pilot does not cover every possible reference pair. No graph mutation or optimizer in this stage.','inherited_numeric_preparation_seconds':cost,'pair_batches':len(batches),'producer_cap_seconds':30,'audit_cap_seconds':30,'scope_frozen_before_pair_evaluation':True,'optimizer_calls':0})
checks={'passed':True,'complete_cases':2,'complete_queries':sum(r['queries'] for r in summaries),'current_targets':sum(r['current_targets'] for r in summaries),'physical_records':sum(r['physical_records'] for r in summaries),'single_area_bounds_replayed':sum(r['single_bounds_replayed'] for r in summaries),'declared_pair_batches':len(batches),'declared_pair_queries':sum(r['complete_declared_pairs'] for r in summaries),'source_pair_bounds_evaluated':0,'seconds':time.perf_counter()-began,'H5_complete':False}
write(OUT/'case-results.json',summaries);write(OUT/'checks.json',checks);print(checks);print(summaries)
