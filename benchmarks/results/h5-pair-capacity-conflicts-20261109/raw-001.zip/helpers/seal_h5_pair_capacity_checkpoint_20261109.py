"""Seal the complete frozen pair pilot, new conflict proofs and frontier audit."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-pair-capacity-conflicts-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-pair-capacity-source-20261109';F=ROOT/'output/h5-pair-capacity-frontier-20261109/audit';D=F.parent",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-combined-fixed-point-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['complete_declared_pairs']==206356 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-pair-capacity-controls-20261109',ROOT/'output/h5-all-pair-capacity-batches-20261109',ROOT/'output/h5-combined-fixed-point-main-sync-20261109']+[ROOT/'output'/(r['stage']+'-process-20261109') for r in load(D/'process-summary.json')]+[ROOT/'output'/('h5-pair-capacity-frontier'+suffix+'-process-20261109') for suffix in ['', '-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*pair_capacity*20261109.py','run_h5_remaining_pair_batches_20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_pair_capacity_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json').items()":"load(F/'plan.json')['inputs'].items()",
}
for before,after in changes.items():assert before in prefix,before;prefix=prefix.replace(before,after)
exec(prefix)
processes=load(D/'process-summary.json')
for suffix in ['', '-audit']:
    label='h5-pair-capacity-frontier'+suffix;p=load(ROOT/'output'/(label+'-process-20261109')/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':suffix==''})
inherited=load(PARENT/'process-summary.json')+load(PARENT/'inherited-process-summary.json')
assert len(processes)==133 and len(inherited)==596 and all(p['closed'] and p['active_processes']==0 for p in inherited)
write(OUT/'process-summary.json',processes);write(OUT/'inherited-process-summary.json',inherited)
copies=[(F/'checks.json','frontier-audit.json'),(F/'case-results.json','case-results.json'),(BASE/'plan.json','complete-plan.json'),(BASE/'case-results.json','source-cases.json'),(BASE/'audit/checks.json','complete-source-audit.json'),(BASE/'batches.json','frozen-pair-batches.json'),(ROOT/'output/h5-pair-capacity-controls-20261109/checks.json','pair-controls.json'),(ROOT/'output/h5-all-pair-capacity-batches-20261109/checks.json','all64-batches.json'),(ROOT/'output/h5-combined-fixed-point-main-sync-20261109/receipt.json','prior-main-push-receipt.json')]
for case in [1,9]:copies.extend([(D/f'choice-{case:02d}-new-edges.json',f'choice-{case:02d}-new-edges.json'),(D/f'choice-{case:02d}-frontier.json',f'choice-{case:02d}-frontier.json')])
for source,name in copies:shutil.copyfile(source,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42551023684','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='afe23d6f19cca4145f27e4e8f2ea3e3fe590de25';write(OUT/'main-ci-at-review.json',ci)
cost=front['complete_preparation_seconds_if_consumed'];cases=load(F/'case-results.json');edges=front['new_unique_conflict_edges'];removed=front['clique_exclusions'];remaining=front['remaining_nodes'];open_cases=front['remaining_fixed29_cases'];incompatible=front['incompatible_query_pairs']
assert edges>0 and open_cases==2
write(OUT/'checks.json',{**front,**archive,'passed':True,'new_processes_closed':133,'inherited_processes_closed':596,'all729_processes_closed':True,'completion_percent':60,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'all_possible_reference_pairs_checked':False})
proposal='New pair-capacity edges change the necessary compatibility graph. Freeze complete direct-reference queries for every remaining bracket and insert cell under the original graph plus the independently verified symmetric edge overlay. Preserve all original possible-node sets P and physical keys; their source-coverage containment still holds. Check each direct self witness, target identity, both family requirements, every projected P membership and every complete physical area sum before propagating exclusions. Do not reuse fictional bracket-representative rows with target-specific new edges without a fresh implication proof. No next direct-reference plan, projection or solver is prepared. Preserve complete preparation; no optimizer or timed H5 acceptance from this lineage.'
write(OUT/'next-step.json',{'status':'pair_capacity_adds_certified_conflicts_both_cases_open','proposal':proposal,'next_direct_reference_stage_prepared':False,'authoritative_current_masks':'output/h5-pair-capacity-frontier-20261109/choice-{01,09}-frontier.json remaining_current_positions','edge_overlay':'output/h5-pair-capacity-frontier-20261109/choice-{01,09}-new-edges.json','consumed_preparation_seconds':cost,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'H5_complete':False})
table='\n'.join(f"| {r['refinement_index']:02d} | {r['complete_declared_pairs']:,} | {r['incompatible_query_pairs']:,} | {r['new_unique_conflict_edges']:,} | {r['clique_exclusions']:,} | {r['remaining_nodes']:,} |" for r in cases)
passed=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Two-reference capacity conflicts — 2026-11-09

**The complete frozen pair pilot proves {edges:,} new conflict edges and excludes {removed:,} cells by clique implications.**
Both fixed29 choices `[0,5,10]` and `[5,10,11]` remain open with {remaining:,}
cells. H2/H5 remain open at **60% completed milestone weight**.

## Conservative pair bound and frozen scope

The [previous complete single-reference proof](h5-combined-fixed-point-20261109.md)
reached a joint fixed point. Selecting two distinct cells restricts remaining
bracket geometry to the intersection of their two conservative bracket covers;
the same holds for inserts. The joint bound is the union of those two family
intersections. The remaining required area subtracts both selected original
part areas. A deficit proves only that their mapped cells cannot coexist.

[Controls]({NAME}/pair-controls.json) check all 16 pointwise cover states,
two strict cross-family examples, all four family requirements, 1,221 scalar
area answers, 1,824,262 transpose membership bits, byte padding, large integer
weights and six invalid-input rejections. [The complete source audit]({NAME}/complete-source-audit.json)
inverts the physical transpose and verifies **1,042,971,280 membership bits**
against all 151,597 original records, plus all 8,551 current target identities.
All 19,950 prior single-reference bounds reproduce before any pair is evaluated.

The [scope frozen before evaluation]({NAME}/frozen-pair-batches.json) selects
sixteen bracket and sixteen insert anchors per case, ranked by the smallest
exact ratio of audited single-reference area to its requirement, with query-index
ties. Every eligible current reference is a partner; duplicate anchor pairs
are removed. Same-reference pairs require at least two distinct mapped targets.
This gives **206,356 pairs in 64 batches**, covering every declared pair but
not every possible pair of references. Bracket implications retain the original
certified mapping; insert targets are direct.

## Independent complete audit and new conflicts

The producer computes exact physical-bit intersections and integer weighted
population counts. Each independent auditor instead reads every original
physical record and sums positive covered query masks, using binary carries.
[All 64 batches]({NAME}/all64-batches.json) verify all **619,068 area bounds**.
There are {incompatible:,} incompatible query pairs in this declared scope.

The [final audit]({NAME}/frontier-audit.json) verifies every threshold sign,
target expansion, original graph bit, new symmetric edge and proof reference.
Existing conflicts receive no new credit. Original graph files remain intact;
new conflicts are a separate overlay. Every candidate in every simultaneous
root-clique pass replays independently, with at most eight passes.

| Case | Declared pairs | Incompatible query pairs | New edges | Cells excluded | Remaining cells |
|---|---:|---:|---:|---:|---:|
{table}

Both arrangements remain unresolved. The 453/455 prior whole-choice exclusions
stand, including 428 at zero clearance. Common-line occupied outer envelopes
reserve holes; all 90 cutting holes remain. No ordinary part-in-hole or
whole-allocation exclusion is claimed.

## Closure and next step

[All 133 new numerical processes]({NAME}/process-summary.json) pass and close
with zero descendants; [596 inherited processes]({NAME}/inherited-process-summary.json)
are terminal, including four preserved failures. Numeric workers retain CCD1
logical processors 16–31, one BLAS/OMP/MKL thread and 2 GiB Windows Job caps.
Controls use 20 s; other new workers use 30 s each. Consumed preparation is
**{cost:.6f} s**. Independent audits are external verification. No optimizer,
timer reset or timed H5 pass follows.

[Next]({NAME}/next-step.json), prepare complete direct-reference bounds under
the new graph overlay. Target-specific new edges cannot be attached to fictional
bracket representatives without a new implication proof. Existing certified
possible-node sets and physical records remain usable conservative inputs.
No next reference plan, projection or solver is prepared.

All 440 whole-job allocations, full66 source/native/material validation,
production integration and the H5 matrix remain open. Valid64 stays best;
eight older first32 and 680 five-column cores remain closed. Product, README
and releases are unchanged.

[The three preceding checkpoints reached main `afe23d6f`]({NAME}/prior-main-push-receipt.json)
after all six prior checks passed, preserving 52 protected files.
[Current CI at review]({NAME}/main-ci-at-review.json) has {passed} passed / {live} live jobs.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete chain.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 two-reference capacity conflicts:** [complete frozen pilot and independent frontier audit]({{link}}) verifies 206,356 declared pairs and 619,068 area bounds across 64 batches. All 1,042,971,280 transposed membership bits and 8,551 target identities check against original physical records. The {incompatible:,} incompatible query pairs imply {edges:,} new unique conflict edges; clique propagation excludes {removed:,} cells, leaving {remaining:,} across both open choices. The pilot covers its full declared scope, not every possible reference pair. All 133 new and 596 inherited processes are terminal; inherited failures remain preserved. Consumed preparation {cost:.6f} s cannot reset or open an optimizer. Next prepare complete direct-reference bounds under the certified overlay; none is prepared. All 440 allocations/full66/H5 remain open, valid64 stays best, H2/H5 remain at 60%, common-line holes stay reserved, and product/README/releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [two-reference capacity conflicts](../benchmarks/results/{NAME}.md).
The frozen 64-batch pilot verifies all 206,356 declared pairs and 619,068 area
bounds independently. It proves {edges:,} new conflict edges and excludes
{removed:,} cells through clique implications, leaving {remaining:,} cells in
both open fixed29 choices. This is a complete check of the declared pilot,
not every possible reference pair. The 453/455 prior exclusions stand,
including 428 at zero clearance. Common-line holes remain reserved; no
ordinary part-in-hole or whole-allocation exclusion is claimed. All 133 new
and 596 inherited processes are terminal; four inherited failures remain.
Consumed preparation is {cost:.6f} s; no optimizer or timer reset is permitted.
Next prepare complete direct-reference bounds under the certified graph
overlay; none is prepared. All 440 allocations and full66/H5 remain open,
valid64 stays best, and H2/H5 remain at 60%. Eight older first32 and 680
five-column cores stay closed. Product, README and releases are unchanged.
The three preceding checkpoints reached main afe23d6f after all six prior
checks passed, preserving 52 files. Fresh CI has {passed} passed/{live} live
jobs at review; this checkpoint awaits ordinary push.
'''
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content[:start]+intro+content[end:])
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text\n')
print({'passed':True,'archive':archive,'source_bindings':len(bindings),'historical_references':len(external),'new_conflict_edges':edges,'excluded_cells':removed,'remaining_cells':remaining,'complete_preparation_seconds':cost})
