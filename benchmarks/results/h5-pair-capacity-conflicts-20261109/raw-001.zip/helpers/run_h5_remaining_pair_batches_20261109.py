"""Administrative serial driver; completed first batch is observed, never repeated."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-all-pair-capacity-batches-20261109';OUT.mkdir();start=time.perf_counter()
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'batches':64,'first_batch_already_closed':True,'sequential_only':True,'retry_permitted':False})
for index in range(64):
    for audit in [False,True]:
        suffix='-audit' if audit else '';folder=ROOT/f'output/h5-pair-capacity-batch-{index:02d}{suffix}-process-20261109'
        if index==0:assert folder.exists()
        else:
            assert not folder.exists()
            wrapper=ROOT/f'output/run_h5_pair_capacity_batch_{index:02d}{"_audit" if audit else ""}_stage_20261109.py'
            result=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(wrapper)],cwd=ROOT,capture_output=True,timeout=45)
            (OUT/f'batch-{index:02d}{suffix}-stdout.txt').write_bytes(result.stdout);(OUT/f'batch-{index:02d}{suffix}-stderr.txt').write_bytes(result.stderr)
            assert result.returncode==0,(index,audit,result.stderr.decode(errors='replace'))
        process=load(folder/'process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
    check=load(ROOT/f'output/h5-pair-capacity-source-20261109/pair-batch-{index:02d}/audit/checks.json');assert check['passed']
    write(OUT/f'batch-{index:02d}-closed.json',check)
    print({'closed_batch':index,'pairs':check['complete_pairs'],'incompatible_query_pairs':check['verified_incompatible_query_pairs']},flush=True)
write(OUT/'checks.json',{'passed':True,'closed_batches':64,'closed_numerical_processes':128,'seconds':time.perf_counter()-start,'optimizer_calls':0,'H5_complete':False})
