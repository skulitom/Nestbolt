"""Exact two-reference cover intersections over weighted physical records."""
import numpy as np


def physical_columns(query_masks, query_count):
    """Transpose complete per-record query masks to per-query physical masks."""
    assert query_count > 0
    limit=(1<<query_count)-1; width=(query_count+7)//8
    assert all(isinstance(m,int) and m>=0 and not m&~limit for m in query_masks)
    if not query_masks:return [0]*query_count
    raw=b''.join(m.to_bytes(width,'little') for m in query_masks)
    rows=np.frombuffer(raw,dtype=np.uint8).reshape(len(query_masks),width)
    bits=np.unpackbits(rows,axis=1,bitorder='little')[:,:query_count]
    packed=np.packbits(bits,axis=0,bitorder='little').T.copy()
    return [int.from_bytes(row.tobytes(),'little') for row in packed]


def weight_planes(weights):
    assert all(isinstance(w,int) and 0<=w<2**64 for w in weights)
    if not weights:return []
    values=np.array(weights,dtype=np.uint64)
    return [int.from_bytes(np.packbits(((values>>digit)&1).astype(np.uint8),bitorder='little').tobytes(),'little') for digit in range(max(weights).bit_length())]


def weighted_area(mask, planes):
    assert isinstance(mask,int) and mask>=0
    return sum((mask&plane).bit_count()<<digit for digit,plane in enumerate(planes))


def pair_areas(bracket_left, insert_left, bracket_right, insert_right, planes):
    bracket=bracket_left&bracket_right
    insert=insert_left&insert_right
    return [weighted_area(mask,planes) for mask in (bracket,insert,bracket|insert)]


def required_areas(left_family,right_family):
    assert left_family in (0,1) and right_family in (0,1)
    counts=[8-(left_family==family)-(right_family==family) for family in (0,1)]
    areas=[counts[0]*39999000000,counts[1]*19799000000]
    return areas+[sum(areas)]
