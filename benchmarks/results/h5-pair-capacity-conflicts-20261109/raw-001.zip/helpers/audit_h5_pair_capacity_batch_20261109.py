"""Independently sum all original positive physical areas for one pair anchor."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pair-capacity-source-20261109';PREVIOUS=ROOT/'output/h5-combined-reference-20261109';index=int(sys.argv[1]);SOURCE=BASE/f'pair-batch-{index:02d}';OUT=SOURCE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/f'output/h5-pair-capacity-batch-{index:02d}-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();batch=load(BASE/'batches.json')[index];case=batch['refinement_index'];data=load(BASE/f'choice-{case:02d}-source.json');qcount=data['query_count'];qfull=(1<<qcount)-1;anchor=batch['anchor_query'];anchorbit=1<<anchor
bindings=dict(load(SOURCE/'plan.json')['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
for name,h in load(BASE/'audit/plan.json')['inputs'].items():
    assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    bindings[name]=h
signatures=load(PREVIOUS/f'round-00/choice-{case:02d}-signatures.json');maps=[{int(k,16):int(v,16) for k,v in rows} for rows in signatures];groups=[{}, {}, {}];physical=0
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    if piece['refinement_index']!=case:continue
    for b,i,weight in load(ROOT/piece['folder']/'atoms.json'):
        b=qfull-maps[0][int(b,16)];i=qfull-maps[1][int(i,16)]
        allowed_b=b if b&anchorbit else 0;allowed_i=i if i&anchorbit else 0
        for family,mask in enumerate([allowed_b,allowed_i,allowed_b|allowed_i]):
            if mask:groups[family][mask]=groups[family].get(mask,0)+weight
        physical+=1
areas=[weighted_query_sums(list(g.items()),qcount) for g in groups];saved=load(SOURCE/'query-results.json');assert len(saved)==len(batch['pairs']);failed=0
for pair,row in zip(batch['pairs'],saved):
    left,right=pair;assert anchor in pair;other=right if left==anchor else left
    count_b=8-int(data['query_families'][left]==0)-int(data['query_families'][right]==0);count_i=14-count_b
    required=[count_b*39999000000,count_i*19799000000];required.append(sum(required))
    values=[areas[f][other] for f in range(3)];fails=[f for f in range(3) if values[f]<required[f]]
    assert row=={'left_query':left,'right_query':right,'family_and_joint_area_upper_um2':values,'required_area_um2':required,'failing_area_indices':fails};failed+=bool(fails)
assert physical==data['physical_records']
summary=load(SOURCE/'checks.json');assert summary['complete_pairs']==len(saved) and summary['conditional_area_bounds']==len(saved)*3 and summary['provisional_incompatible_query_pairs']==failed
for p in [Path(__file__),ROOT/'output/h5_weighted_query_masks_20261109.py',process_path,process_path.parent/'opened.json']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Every original physical record contributes positive weight to all covered partner-query bits if its family also covers the anchor. Joint masks union the two family results before summation. Independent exact binary carry sums, without reading the producer physical columns for arithmetic.'})
checks={'passed':True,'batch_index':index,'refinement_index':case,'complete_pairs':len(saved),'conditional_area_bounds':len(saved)*3,'original_physical_records':physical,'verified_incompatible_query_pairs':failed,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
