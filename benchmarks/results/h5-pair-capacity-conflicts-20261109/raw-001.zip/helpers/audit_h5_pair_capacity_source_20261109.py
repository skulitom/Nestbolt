"""Inverse byte transpose and complete scalar identities for the pair preflight."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,time,numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pair-capacity-source-20261109';PREVIOUS=ROOT/'output/h5-combined-reference-20261109';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-pair-capacity-source-process-20261109/process.json';process=load(process_path)
assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings=dict(plan['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
for name,h in load(PREVIOUS/'round-00/audit/plan.json')['inputs'].items():
    assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    bindings[name]=h
batches=load(BASE/'batches.json');expected_batches=[];memberships=0;physical_records=0;targets_total=0;pair_total=0
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-source.json');source=load(PREVIOUS/f'choice-{case:02d}-queries.json');saved_rows=load(PREVIOUS/f'round-00/choice-{case:02d}-queries.json');active=set(load(PREVIOUS/f'round-00/choice-{case:02d}-frontier.json')['remaining_current_positions'])
    qcount=len(source['query_positions']);width=(data['physical_records']+7)//8;record_count=data['physical_records'];assert data['query_count']==qcount and data['column_bytes']==width
    maps=[{int(k,16):int(v,16) for k,v in rows} for rows in load(PREVIOUS/f'round-00/choice-{case:02d}-signatures.json')];weights=[];expected_masks=[[],[]];pieces=[];qfull=(1<<qcount)-1
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index']!=case:continue
        path=ROOT/piece['folder']/'atoms.json';records=load(path);pieces.append({'path':path.relative_to(ROOT).as_posix(),'offset':len(weights),'count':len(records)})
        for b,i,w in records:
            weights.append(w)
            expected_masks[0].append(qfull-maps[0][int(b,16)]);expected_masks[1].append(qfull-maps[1][int(i,16)])
    assert len(weights)==record_count and weights==data['weights'] and pieces==data['physical_pieces']
    for family in [0,1]:
        path=BASE/f'choice-{case:02d}-family-{family}-columns.bin';raw=path.read_bytes();assert len(raw)==qcount*width
        array=np.frombuffer(raw,dtype=np.uint8).reshape(qcount,width)
        bits=np.unpackbits(array,axis=1,bitorder='little');assert not bits[:,record_count:].any()
        rows=np.packbits(bits[:,:record_count],axis=0,bitorder='little').T.copy()
        reconstructed=[int.from_bytes(row.tobytes(),'little') for row in rows]
        assert reconstructed==expected_masks[family];memberships+=qcount*record_count
        bindings[path.relative_to(ROOT).as_posix()]=sha256(raw).hexdigest()
        del bits,rows,reconstructed
    targets=[[p for p in values if p in active] for values in source['query_targets']]
    assert data['current_query_targets']==targets and data['query_families']==source['query_families'] and data['query_positions']==source['query_positions']
    flat=[p for values in targets for p in values];assert len(flat)==len(set(flat)) and set(flat)==active;targets_total+=len(flat)
    eligible=[q for q,values in enumerate(targets) if values];assert data['eligible_queries']==eligible
    anchors=[];by_family=[]
    for family in [0,1]:
        candidates=[]
        for q in eligible:
            if source['query_families'][q]!=family:continue
            ratios=[Fraction(saved_rows[q]['family_and_joint_area_upper_um2'][f],source['required_by_reference_family_um2'][family][f]) for f in range(3)]
            candidates.append((min(ratios),q))
        selected=[q for _,q in sorted(candidates)[:16]];anchors.extend(selected);by_family.append(selected)
    anchors=sorted(anchors);assert data['anchors']==anchors and data['anchors_by_family']==by_family
    unique=set()
    for anchor in anchors:
        pairs=[]
        for other in eligible:
            if other in anchors and other<anchor:continue
            if other==anchor and len(targets[anchor])<2:continue
            pair=tuple(sorted((anchor,other)));assert pair not in unique;unique.add(pair);pairs.append(list(pair))
        expected_batches.append({'batch_index':len(expected_batches),'refinement_index':case,'anchor_query':anchor,'pairs':pairs,'pair_count':len(pairs),'hard_cap_seconds':30,'audit_hard_cap_seconds':30})
    assert data['pairs']==len(unique);pair_total+=len(unique);physical_records+=record_count
assert batches==expected_batches and len(batches)==64 and physical_records==151597 and targets_total==8551
for p in [Path(__file__),process_path,process_path.parent/'opened.json']+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Read column bytes in the opposite orientation, require zero padding, reconstruct and exactly compare every original physical query-mask integer. Rebuild weights, source ordering, all target identities and the complete frozen anchor/partner scope independently. No source pair evaluated.'})
checks={'passed':True,'membership_bits_verified':memberships,'physical_records':physical_records,'current_targets':targets_total,'declared_pair_batches':len(batches),'declared_pair_queries':pair_total,'source_pair_bounds_evaluated':0,'complete_preparation_seconds_if_consumed':plan['inherited_numeric_preparation_seconds']+process['complete_seconds'],'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
