"""Reconcile every declared pair and propagate only independently proved edges."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pair-capacity-source-20261109';PREVIOUS=ROOT/'output/h5-combined-reference-20261109';OUT=ROOT/'output/h5-pair-capacity-frontier-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(ROOT/'output/h5-all-pair-capacity-batches-20261109/checks.json')['passed']
OUT.mkdir();began=time.perf_counter();batches=load(BASE/'batches.json');inputs=[Path(__file__),BASE/'batches.json',BASE/'audit/plan.json',BASE/'audit/checks.json',ROOT/'output/h5-all-pair-capacity-batches-20261109/checks.json'];cases=[];processes=[]
cost=load(BASE/'audit/checks.json')['complete_preparation_seconds_if_consumed']
for label,charge in [('h5-pair-capacity-controls',True),('h5-pair-capacity-source',True),('h5-pair-capacity-source-audit',False)]+[(f'h5-pair-capacity-batch-{n:02d}'+suffix,suffix=='') for n in range(64) for suffix in ['', '-audit']]:
    folder=ROOT/'output'/(label+'-process-20261109');p=load(folder/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    inputs.extend([folder/'process.json',folder/'opened.json']);processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':charge})
    if label.startswith('h5-pair-capacity-batch-') and charge:cost+=p['complete_seconds']
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-source.json');source=load(PREVIOUS/f'choice-{case:02d}-queries.json');old=load(PREVIOUS/f'round-00/choice-{case:02d}-frontier.json');graph=ROOT/source['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8;original=[int.from_bytes(raw[p*width:(p+1)*width],'little') for p in range(len(nodes))];new=[0]*len(nodes);proofs={};pair_count=failed=target_pairs=existing=0;seen=set()
    inputs.extend([BASE/f'choice-{case:02d}-source.json',PREVIOUS/f'choice-{case:02d}-queries.json',PREVIOUS/f'round-00/choice-{case:02d}-frontier.json',graph/'nodes.json',graph/'conflicts.bin'])
    for batch in batches:
        if batch['refinement_index']!=case:continue
        folder=BASE/f"pair-batch-{batch['batch_index']:02d}";check=load(folder/'audit/checks.json');rows=load(folder/'query-results.json');assert check['passed'] and len(rows)==batch['pair_count']==check['complete_pairs'];assert [[r['left_query'],r['right_query']] for r in rows]==batch['pairs']
        inputs.extend([folder/'query-results.json',folder/'checks.json',folder/'audit/checks.json',folder/'audit/plan.json'])
        for row in rows:
            q,r=row['left_query'],row['right_query'];assert (q,r) not in seen;seen.add((q,r));pair_count+=1
            if not row['failing_area_indices']:continue
            failed+=1
            for left in data['current_query_targets'][q]:
                for right in data['current_query_targets'][r]:
                    if left==right:continue
                    a,b=sorted((left,right));target_pairs+=1
                    if original[a]&(1<<b):assert original[b]&(1<<a);existing+=1;continue
                    new[a]|=1<<b;new[b]|=1<<a
                    proofs.setdefault((a,b),{'left_current_position':a,'right_current_position':b,'batch_index':batch['batch_index'],'left_query':q,'right_query':r})
    assert pair_count==data['pairs']
    active=old['remaining_current_positions'];mask=sum(1<<p for p in active);cliques=[[int(v,16) for v in family] for family in source['root_clique_masks_hex']];rounds=[]
    for step in range(8):
        removed=[]
        for p in active:
            if not mask&(1<<p):continue
            allowed=mask&~(original[p]|new[p]|(1<<p));upper=[sum(bool(group&allowed) for group in family) for family in cliques];required=[8-int(nodes[p]['family']==f) for f in [0,1]]
            if any(a<b for a,b in zip(upper,required)):removed.append({'current_position':p,'upper':upper,'required':required})
        rounds.append({'pass_index':step,'removed':removed});mask&=~sum(1<<v['current_position'] for v in removed)
        if not removed:break
    retained=[p for p in active if mask&(1<<p)];counts=[sum(bool(group&mask) for group in family) for family in cliques]
    summary={'refinement_index':case,'complete_declared_pairs':pair_count,'incompatible_query_pairs':failed,'failed_pair_target_expansions':target_pairs,'already_proved_target_expansions':existing,'new_unique_conflict_edges':len(proofs),'input_nodes':len(active),'remaining_nodes':len(retained),'clique_exclusions':len(active)-len(retained),'global_clique_upper_counts':counts,'scope_excluded':any(n<8 for n in counts),'clique_fixed_point':not rounds[-1]['removed']}
    write(OUT/f'choice-{case:02d}-new-edges.json',[proofs[key] for key in sorted(proofs)]);write(OUT/f'choice-{case:02d}-frontier.json',{**summary,'input_active_positions':active,'remaining_current_positions':retained,'clique_rounds':rounds});cases.append(summary)
write(OUT/'case-results.json',cases);write(OUT/'process-summary.json',processes)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'maximum_simultaneous_clique_passes':8,'method':'Reconcile all 64 independently audited frozen batches; transfer failed pair bounds only to distinct current target pairs; distinguish original conflicts from genuinely new symmetric edges; apply at most eight simultaneous necessary root-clique passes. No graph search or source atlas repeated.'})
checks={'passed':True,'complete_cases':2,'complete_declared_pairs':sum(r['complete_declared_pairs'] for r in cases),'incompatible_query_pairs':sum(r['incompatible_query_pairs'] for r in cases),'new_unique_conflict_edges':sum(r['new_unique_conflict_edges'] for r in cases),'clique_exclusions':sum(r['clique_exclusions'] for r in cases),'remaining_nodes':sum(r['remaining_nodes'] for r in cases),'remaining_fixed29_cases':sum(not r['scope_excluded'] for r in cases),'complete_preparation_seconds_before_this_stage':cost,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks);print(cases)
