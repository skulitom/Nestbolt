"""Administrative creation of once-only wrappers for the frozen pair batches."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
template=(ROOT/'output/run_h5_combined_reference_round_00_stage_20261109.py').read_text(encoding='utf-8')
for index in range(64):
    for auditor in (False,True):
        suffix='-audit' if auditor else '';script=('audit' if auditor else 'build')+'_h5_pair_capacity_batch_20261109.py'
        text=template.replace('build_h5_combined_reference_round_20261109.py',script).replace(".py',60)",".py',30)").replace('h5-combined-reference-round-00-process-20261109',f'h5-pair-capacity-batch-{index:02d}{suffix}-process-20261109').replace("str(SCRIPT),'0'",f"str(SCRIPT),'{index}'")
        path=ROOT/'output'/f'run_h5_pair_capacity_batch_{index:02d}{"_audit" if auditor else ""}_stage_20261109.py'
        with path.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'wrappers_prepared':128,'stages_opened':0})
