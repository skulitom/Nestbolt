"""Scalar, set-algebra, padding and large-weight controls before pair proofs."""
from pathlib import Path
from hashlib import sha256
import json,time,itertools
from h5_pair_capacity_bitsets_20261109 import physical_columns,weight_planes,pair_areas,required_areas
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-pair-capacity-controls-20261109';OUT.mkdir();began=time.perf_counter()
cases=pair_checks=scalar_bounds=transpose_bits=0
for records,queries in [(0,1),(1,1),(7,7),(8,8),(9,9),(63,63),(64,64),(65,65),(129,1134),(129,2006),(129,3834)]:
    weights=[0 if p%17==0 else (1<<(p%31+31))+p*1009 for p in range(records)]
    # Irregular masks include low, high and byte-boundary bits deterministically.
    masks=[[sum(1<<q for q in range(queries) if (q*71+p*43+family*29)%19<8) for p in range(records)] for family in (0,1)]
    cols=[physical_columns(rows,queries) for rows in masks]
    for family in (0,1):
        expected=[sum(1<<p for p,m in enumerate(masks[family]) if m&(1<<q)) for q in range(queries)]
        assert cols[family]==expected;transpose_bits+=records*queries
    planes=weight_planes(weights)
    selected=sorted(set([0,queries-1]+[p for p in [1,7,8,63,64,1132,1133,2004,2005] if p<queries]))
    for q,r in itertools.product(selected,repeat=2):
        expected=[0,0,0]
        for p,w in enumerate(weights):
            b=bool(masks[0][p]&(1<<q)) and bool(masks[0][p]&(1<<r))
            i=bool(masks[1][p]&(1<<q)) and bool(masks[1][p]&(1<<r))
            for f,covered in enumerate([b,i,b or i]):expected[f]+=w*covered
        actual=pair_areas(cols[0][q],cols[1][q],cols[0][r],cols[1][r],planes)
        assert actual==expected
        assert actual==pair_areas(cols[0][r],cols[1][r],cols[0][q],cols[1][q],planes)
        pair_checks+=1;scalar_bounds+=3
    cases+=1
# Every possible pointwise cover state. Joint area is the union AFTER each
# family's intersection; intersecting the two joint covers is only an upper
# relaxation and is strictly looser for the cross-family counterexample.
strict_cross_examples=0
for b0,i0,b1,i1 in itertools.product([False,True],repeat=4):
    covers=[int(v) for v in [b0,i0,b1,i1]]
    got=pair_areas(*covers,[1])
    expected=[int(b0 and b1),int(i0 and i1),int((b0 and b1) or (i0 and i1))]
    assert got==expected and got[2]<=int((b0 or i0) and (b1 or i1))
    strict_cross_examples+=got[2]<int((b0 or i0) and (b1 or i1))
assert strict_cross_examples==2
requirements={}
for left,right in itertools.product((0,1),repeat=2):
    population=[39999000000]*8+[19799000000]*8
    population.remove([39999000000,19799000000][left]);population.remove([39999000000,19799000000][right])
    expected=[sum(w for w in population if w==39999000000),sum(w for w in population if w==19799000000),sum(population)]
    assert required_areas(left,right)==expected
    requirements[f'{left}-{right}']=expected
rejected=0
for operation in [lambda:physical_columns([2],1),lambda:physical_columns([-1],2),lambda:physical_columns([0],0),lambda:weight_planes([-1]),lambda:weight_planes([2**64]),lambda:required_areas(2,0)]:
    try:operation()
    except AssertionError:rejected+=1
    else:raise AssertionError('Invalid control accepted')
checks={'passed':True,'transpose_cases':cases,'transpose_memberships_checked':transpose_bits,'scalar_pairs_checked':pair_checks,'scalar_area_bounds_checked':scalar_bounds,'pointwise_cover_states':16,'strict_cross_family_counterexamples':strict_cross_examples,'required_area_cases':requirements,'invalid_inputs_rejected':rejected,'maximum_query_index':3833,'large_integer_weights':True,'seconds':time.perf_counter()-began,'optimizer_calls':0,'source_pair_bounds_evaluated':0,'H5_complete':False}
bindings={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'output/h5_pair_capacity_bitsets_20261109.py']}
for name,v in [('checks.json',checks),('source-bindings.json',bindings)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
print(checks)
