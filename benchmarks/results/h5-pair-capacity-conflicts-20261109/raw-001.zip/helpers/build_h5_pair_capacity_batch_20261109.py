"""Evaluate every frozen pair using exact weighted physical bit intersections."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_pair_capacity_bitsets_20261109 import weight_planes,pair_areas,required_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pair-capacity-source-20261109';index=int(sys.argv[1]);batch=json.loads((BASE/'batches.json').read_bytes())[index];OUT=BASE/f'pair-batch-{index:02d}'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed']
p=load(ROOT/'output/h5-pair-capacity-source-audit-process-20261109/process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();case=batch['refinement_index'];data=load(BASE/f'choice-{case:02d}-source.json');width=data['column_bytes'];columns=[]
inputs=[Path(__file__),ROOT/'output/h5_pair_capacity_bitsets_20261109.py',BASE/'plan.json',BASE/'batches.json',BASE/'audit/plan.json',BASE/'audit/checks.json',BASE/f'choice-{case:02d}-source.json']
pins=load(BASE/'audit/plan.json')['inputs']
for family in [0,1]:
    path=BASE/f'choice-{case:02d}-family-{family}-columns.bin';raw=path.read_bytes();assert sha256(raw).hexdigest()==pins[path.relative_to(ROOT).as_posix()]
    inputs.append(path);columns.append([int.from_bytes(raw[start:start+width],'little') for start in range(0,len(raw),width)])
planes=weight_planes(data['weights']);rows=[];failed=0
for left,right in batch['pairs']:
    areas=pair_areas(columns[0][left],columns[1][left],columns[0][right],columns[1][right],planes);required=required_areas(data['query_families'][left],data['query_families'][right]);fails=[f for f in range(3) if areas[f]<required[f]]
    rows.append({'left_query':left,'right_query':right,'family_and_joint_area_upper_um2':areas,'required_area_um2':required,'failing_area_indices':fails});failed+=bool(fails)
write(OUT/'query-results.json',rows)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'batch_index':index,'method':'Exact pair-family intersection of certified physical columns, then joint union; integer weight-plane population counts. No cell or graph mutation.'})
checks={'passed':True,'batch_index':index,'refinement_index':case,'anchor_query':batch['anchor_query'],'complete_pairs':len(rows),'conditional_area_bounds':len(rows)*3,'provisional_incompatible_query_pairs':failed,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
