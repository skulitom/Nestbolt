"""Independently reconstruct all new conflict causes and each clique removal."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-pair-capacity-source-20261109';PREVIOUS=ROOT/'output/h5-combined-reference-20261109';SOURCE=ROOT/'output/h5-pair-capacity-frontier-20261109';OUT=SOURCE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-pair-capacity-frontier-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings=dict(load(SOURCE/'plan.json')['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
all_batches=load(BASE/'batches.json');results=[];checked_pairs=0
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-source.json');source=load(PREVIOUS/f'choice-{case:02d}-queries.json');saved=load(SOURCE/f'choice-{case:02d}-frontier.json');old=load(PREVIOUS/f'round-00/choice-{case:02d}-frontier.json');assert saved['input_active_positions']==old['remaining_current_positions'];active=old['remaining_current_positions'];graph=ROOT/source['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    expected={};new=[0]*len(nodes);failed=expanded=existing=total=0;visited=set()
    for qi,targets in enumerate(data['current_query_targets']):assert all(nodes[p]['family']==data['query_families'][qi] for p in targets)
    for batch in all_batches:
        if batch['refinement_index']!=case:continue
        folder=BASE/f"pair-batch-{batch['batch_index']:02d}";rows=load(folder/'query-results.json');audit=load(folder/'audit/checks.json');assert audit['passed'] and audit['complete_pairs']==len(rows)==batch['pair_count']
        pins=load(folder/'audit/plan.json')['inputs'];name=(folder/'query-results.json').relative_to(ROOT).as_posix();assert sha256((ROOT/name).read_bytes()).hexdigest()==pins[name]
        assert [[r['left_query'],r['right_query']] for r in rows]==batch['pairs']
        for row in rows:
            a,b=row['left_query'],row['right_query'];assert (a,b) not in visited;visited.add((a,b));total+=1
            counts=[8-sum(data['query_families'][q]==f for q in [a,b]) for f in [0,1]];required=[counts[0]*39999000000,counts[1]*19799000000];required.append(sum(required));fails=[f for f in range(3) if row['family_and_joint_area_upper_um2'][f]<required[f]]
            assert row['required_area_um2']==required and row['failing_area_indices']==fails
            if not fails:continue
            failed+=1
            for p in data['current_query_targets'][a]:
                for q in data['current_query_targets'][b]:
                    if p==q:continue
                    left,right=min(p,q),max(p,q);expanded+=1
                    forward=bool(raw[left*width+right//8]&(1<<(right%8)));reverse=bool(raw[right*width+left//8]&(1<<(left%8)));assert forward==reverse
                    if forward:existing+=1;continue
                    expected.setdefault((left,right),{'left_current_position':left,'right_current_position':right,'batch_index':batch['batch_index'],'left_query':a,'right_query':b})
                    new[left]|=1<<right;new[right]|=1<<left
    assert total==data['pairs'] and load(SOURCE/f'choice-{case:02d}-new-edges.json')==[expected[key] for key in sorted(expected)]
    mask=sum(1<<p for p in active);groups=[[int(v,16) for v in family] for family in source['root_clique_masks_hex']];rounds=saved['clique_rounds'];assert 1<=len(rounds)<=8
    for step,round_saved in enumerate(rounds):
        rejected=[]
        for p in active:
            if not mask&(1<<p):continue
            row=int.from_bytes(raw[p*width:(p+1)*width],'little');allowed=mask&~row&~new[p]&~(1<<p);counts=[sum((group&allowed)>0 for group in family) for family in groups];required=[7 if nodes[p]['family']==f else 8 for f in [0,1]]
            if counts[0]<required[0] or counts[1]<required[1]:rejected.append({'current_position':p,'upper':counts,'required':required})
        assert round_saved=={'pass_index':step,'removed':rejected}
        if not rejected:assert step==len(rounds)-1
        mask&=~sum(1<<r['current_position'] for r in rejected)
    retained=[p for p in active if mask&(1<<p)];assert retained==saved['remaining_current_positions'];counts=[sum((group&mask)>0 for group in family) for family in groups]
    summary={'refinement_index':case,'complete_declared_pairs':total,'incompatible_query_pairs':failed,'failed_pair_target_expansions':expanded,'already_proved_target_expansions':existing,'new_unique_conflict_edges':len(expected),'input_nodes':len(active),'remaining_nodes':len(retained),'clique_exclusions':len(active)-len(retained),'global_clique_upper_counts':counts,'scope_excluded':any(n<8 for n in counts),'clique_fixed_point':not rounds[-1]['removed']}
    assert all(saved[key]==v for key,v in summary.items());results.append(summary);checked_pairs+=total
assert checked_pairs==206356 and results==load(SOURCE/'case-results.json')
cost=load(ROOT/'benchmarks/results/h5-combined-fixed-point-20261109/checks.json')['complete_preparation_seconds_if_consumed'];processes=load(SOURCE/'process-summary.json');assert len(processes)==131
for row in processes:
    p=load(ROOT/'output'/(row['stage']+'-process-20261109')/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0 and row['complete_seconds']==p['complete_seconds']
    expected_charge=row['stage'] in ['h5-pair-capacity-controls','h5-pair-capacity-source'] or row['stage'].startswith('h5-pair-capacity-batch-') and not row['stage'].endswith('-audit')
    assert row['charged']==expected_charge
    if expected_charge:cost+=p['complete_seconds']
assert abs(cost-load(SOURCE/'checks.json')['complete_preparation_seconds_before_this_stage'])<1e-8
cost+=process['complete_seconds']
for p in [Path(__file__),process_path,process_path.parent/'opened.json']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Complete pair-scope reconciliation, all threshold signs, direct byte checks against original graph, independent target-pair expansion and exact new-edge provenance. Replay every simultaneous clique implication and all preparation charges. Pair numerical bounds remain pinned to their full original-piece independent audits.'})
checks={'passed':True,'complete_cases':2,'complete_declared_pairs':checked_pairs,'conditional_area_bounds':3*checked_pairs,'incompatible_query_pairs':sum(r['incompatible_query_pairs'] for r in results),'new_unique_conflict_edges':sum(r['new_unique_conflict_edges'] for r in results),'clique_exclusions':sum(r['clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'remaining_fixed29_cases':sum(not r['scope_excluded'] for r in results),'complete_preparation_seconds_if_consumed':cost,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'case-results.json',results);write(OUT/'checks.json',checks);print(checks);print(results)
