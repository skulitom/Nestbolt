"""Independent event-slope readback of every finite band minimum."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';BAND=BASE/'band-capacity-diagnosis';OUT=BAND/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BAND/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
rects=load(BASE/'mode-inner-rectangles.json');modes=load(BASE/'modes.json');fixed=load(BASE/'fixed-inner-rectangles-inset.json');ranges=load(BAND/'anchor-y-intervals.json');control=load(BASE/'control.json')
for i in range(11):
    raw=[]
    for c in load(BASE/'free'/f'{i:02d}.json')['cells']:
        ys=[F(str(y))*1000 for x,y in c['geometry']['coordinates'][0]];raw.append([math.floor(min(ys))-1,math.ceil(max(ys))+1])
    points=sorted(set(v for r in raw for v in r));want=[]
    for a,b in sorted(raw):
        if want and a<=want[-1][1]:want[-1][1]=max(want[-1][1],b)
        else:want.append([a,b])
    assert ranges[str(i)]==want
counts={f:sum(r['family']==f for r in load(BASE/'remaining25.json')) for f in ['bracket','cog','insert']};assert plan['counts']==counts and sum(counts.values())==25
def overlap(rs,y,lo,hi):return sum((c-a)*max(0,min(y+d,hi)-max(y+b,lo)) for a,b,c,d in rs)
event_points=0
def sweep(mi,lo,hi):
    global event_points
    rs=rects[mi]['rectangles_um'];events={}
    for a,b,c,d in rs:
        w=c-a
        for t,coef in [(lo-d,w),(lo-b,-w),(hi-d,-w),(hi-b,w)]:events[t]=events.get(t,0)+coef
    ordered=sorted(events.items());best=None
    for low,high in ranges[str(mi)]:
        value=overlap(rs,low,lo,hi);slope=sum(v for t,v in ordered if t<=low);position=low;best=value if best is None else min(best,value)
        for t,change in ordered:
            if low<t<high:
                value+=slope*(t-position);position=t;slope+=change;best=min(best,value);event_points+=1
        value+=slope*(high-position);assert value==overlap(rs,high,lo,hi);best=min(best,value)
    return best
rows=load(BAND/'bands.json');bounds=plan['boundaries_um'];assert len(rows)==len(bounds)*(len(bounds)-1)//2
assert [r['band_um'] for r in rows]==[[a,b] for n,a in enumerate(bounds) for b in bounds[n+1:]]
overloads=0;partial_checks=0;positive_mover_bands=0;best_mover=None
for row in rows:
    lo,hi=row['band_um'];family_values={}
    for f in counts:
        minimum=min(sweep(m['index'],lo,hi) for m in modes if m['family']==f);saved=row['family_minima'][f];mi=saved['mode'];y=saved['anchor_y_um']
        assert modes[mi]['family']==f and any(a<=y<=b for a,b in ranges[str(mi)]) and overlap(rects[mi]['rectangles_um'],y,lo,hi)==minimum==saved['minimum_area_um2'];family_values[f]=minimum
    fixed_area=overlap([r['rectangle_um'] for r in fixed],0,lo,hi);cap=1487000*(hi-lo);moving=sum(counts[f]*v for f,v in family_values.items());total=fixed_area+moving
    assert row['capacity_um2']==cap and row['fixed_area_um2']==fixed_area and row['mandatory_area_lower_bound_um2']==total and row['slack_um2']==cap-total;overloads+=total>cap
    actual_control=fixed_area+sum(overlap(rects[c['mode']]['rectangles_um'],c['anchor_um'][1],lo,hi) for c in control);assert fixed_area+15*family_values['cog']<=actual_control<=cap;partial_checks+=1
    if moving:
        positive_mover_bands+=1
        if best_mover is None or F(row['slack_um2'],hi-lo)<F(best_mover['slack_um2'],best_mover['band_um'][1]-best_mover['band_um'][0]):best_mover=row
assert overloads==load(BAND/'checks.json')['overload_count']==0
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BAND/'plan.json',BAND/'bands.json',BAND/'checks.json',BAND/'anchor-y-intervals.json',BASE/'control.json']}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'bands_independently_verified':len(rows),'slope_event_points_verified':event_points,'source56_partial_control_band_checks':partial_checks,'overload_count':overloads,'bands_with_positive_mover_lower_bound':positive_mover_bands,'tightest_mean_section_slack_with_movers':best_mover,'no_fixed_core_exclusion_proved':True,'no_feasibility_proved':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
