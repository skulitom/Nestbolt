"""Finite exact integer band necessities; no placement solver or continuation."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';OUT=BASE/'band-capacity-diagnosis';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def merged(intervals):
    result=[]
    for a,b in sorted(intervals):
        if result and a<=result[-1][1]:result[-1][1]=max(b,result[-1][1])
        else:result.append([a,b])
    return result
OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py');started=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'capacity-audit/checks.json')['passed']
modes=load(BASE/'modes.json');rects=load(BASE/'mode-inner-rectangles.json');fixed=load(BASE/'fixed-inner-rectangles-inset.json');remaining=load(BASE/'remaining25.json');counts={f:sum(r['family']==f for r in remaining) for f in ['bracket','cog','insert']}
yranges={}
for i in range(11):
    intervals=[]
    for c in load(BASE/'free'/f'{i:02d}.json')['cells']:
        ys=[F(str(y))*1000 for x,y in c['geometry']['coordinates'][0]];intervals.append([math.floor(min(ys))-1,math.ceil(max(ys))+1])
    yranges[i]=merged(intervals)
boundaries=sorted({6500,2993500,*range(6500,2993501,50000),*[r['rectangle_um'][k] for r in fixed for k in [1,3]]})
assert boundaries[0]==6500 and boundaries[-1]==2993500
inputs=[BASE/'plan.json',BASE/'response-audit/checks.json',BASE/'capacity-audit/checks.json',BASE/'modes.json',BASE/'mode-inner-rectangles.json',BASE/'fixed-inner-rectangles-inset.json',BASE/'remaining25.json']+sorted((BASE/'free').glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Necessary full-width horizontal-band occupied area, using only source-contained rectangles. Anchor-Y intervals conservatively enclose every verified convex free cell. Rectangle-band overlap is piecewise linear in anchor-Y; its exact integer minimum occurs at an interval endpoint or a band-edge minus rectangle-edge breakpoint. Minimize over every mode and interval independently for each owner, then sum all25 mandatory minima plus fixed occupied area. This drops X and collision couplings and is a necessary relaxation only. Scan all pairs of the frozen boundaries; absence of overload is not sufficiency. No solver calls, no changes to any closed search.','boundaries_um':boundaries,'width_um':1487000,'counts':counts,'hard_arithmetic_bound':5000000000000,'solver_calls':0})
write(OUT/'anchor-y-intervals.json',yranges)
arrays={i:np.array(r['rectangles_um'],dtype=np.int64) for i,r in enumerate(rects)}
def minimum(i,lo,hi):
    rs=arrays[i];candidates=set()
    for a,b in yranges[i]:
        candidates.update([a,b])
        for edge in [lo,hi]:
            for v in rs[:,1].tolist()+rs[:,3].tolist():
                y=edge-v
                if a<=y<=b:candidates.add(y)
    ys=np.array(sorted(candidates),dtype=np.int64)
    overlaps=np.maximum(0,np.minimum(ys[:,None]+rs[:,3],hi)-np.maximum(ys[:,None]+rs[:,1],lo))
    areas=(overlaps*(rs[:,2]-rs[:,0])).sum(axis=1);ix=int(areas.argmin());return int(areas[ix]),int(ys[ix])
rows=[];best=None;overloads=[]
for n,lo in enumerate(boundaries):
    for hi in boundaries[n+1:]:
        fm=sum((c-a)*max(0,min(d,hi)-max(b,lo)) for a,b,c,d in [r['rectangle_um'] for r in fixed]);mins={}
        for family in counts:
            choices=[(*minimum(m['index'],lo,hi),m['index']) for m in modes if m['family']==family];value,y,mi=min(choices);mins[family]={'minimum_area_um2':value,'mode':mi,'anchor_y_um':y}
        occupied=fm+sum(counts[f]*v['minimum_area_um2'] for f,v in mins.items());capacity=1487000*(hi-lo);slack=capacity-occupied
        row={'band_um':[lo,hi],'capacity_um2':capacity,'fixed_area_um2':fm,'family_minima':mins,'mandatory_area_lower_bound_um2':occupied,'slack_um2':slack};rows.append(row)
        if best is None or slack/(hi-lo)<best['slack_um2']/(best['band_um'][1]-best['band_um'][0]):best=row
        if slack<0:overloads.append(row)
write(OUT/'bands.json',rows);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'frozen_boundaries':len(boundaries),'bands_checked':len(rows),'overload_count':len(overloads),'tightest_mean_section_slack':best,'integer_piecewise_linear_minima':True,'all25_mandatory':True,'fixed_core_exclusion_only_if_overload':bool(overloads),'no_overload_does_not_prove_feasible':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
