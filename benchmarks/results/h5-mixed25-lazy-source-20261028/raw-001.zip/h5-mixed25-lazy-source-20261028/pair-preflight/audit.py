"""Exercise every family/mode-pair direction without solving or altering the base."""
from pathlib import Path
import json,shutil,time
from hashlib import sha256
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from h5_lazy_cp_builder_20261028 import add_pairs
from h5_lazy_cp_reader_20261028 import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';OUT=BASE/'pair-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model/model.pbtxt').read_text());mp=load(BASE/'model/mapping.json')
remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)}
groups={f:[i['index'] for i in mp['items'] if i['family']==f] for f in ['bracket','cog','insert']};b,c,i=[groups[f] for f in ['bracket','cog','insert']];pairs=[(b[0],b[1]),(b[0],c[0]),(b[0],i[0]),(c[0],c[1]),(c[0],i[0]),(i[0],i[1])]
add_pairs(model,mp,pairs,relative);assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',mp)
p=cp_model_pb2.CpModelProto();p.ParseFromString((OUT/'model.pb').read_bytes());previous=cp_model_pb2.CpModelProto();previous.ParseFromString((BASE/'model/model.pb').read_bytes())
assert list(p.variables[:len(previous.variables)])==list(previous.variables) and list(p.constraints[:len(previous.constraints)])==list(previous.constraints) and p.solution_hint==previous.solution_hint
checks,sol=audit(p,mp,remaining,modes,free,load(BASE/'fixed-inner-rectangles-inset.json'),load(BASE/'mode-inner-rectangles.json'),relative,load(BASE/'control.json'))
write(OUT/'partial-control-assignment.json',sol);write(OUT/'checks.json',{**checks,'seconds':time.perf_counter()-started,'model_sha256':digest(OUT/'model.pb'),'all6_family_pairs':True,'all66_intrinsic_mode_pair_domains':True,'reverse_displacement_sign_exercised':True,'prefix_unchanged':True,'solver_calls':0})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'model/model.pb',BASE/'model/model.pbtxt',BASE/'model/mapping.json',ROOT/'output/h5_lazy_cp_builder_20261028.py',ROOT/'output/h5_lazy_cp_reader_20261028.py']}})
print(load(OUT/'checks.json'))
