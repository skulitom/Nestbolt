"""Independently read the closed no-candidate response and its one-call budget."""
from pathlib import Path
from hashlib import sha256
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_lazy_cp_reader_20261028 import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';SEARCH=BASE/'search';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for path in [BASE/'plan.json',BASE/'model/plan.json',BASE/'capacity-audit/plan.json',SEARCH/'opened.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert result['closed'] and result['reason']=='NO_CANDIDATE_UNKNOWN' and result['distinct_solves']==len(result['records'])==1
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<=90 and result['algorithm_seconds']<60 and result['algorithm_soft_overrun_seconds']==0
assert not result['source_full66_verified'] and result['native_calls']==0 and not result['full66_exclusion_claimed'] and not result['H5_complete']
folders=[p for p in SEARCH.iterdir() if p.is_dir()];assert len(folders)==1 and folders[0].name=='00';folder=folders[0];p=cp_model_pb2.CpModelProto();p.ParseFromString((folder/'model.pb').read_bytes());mp=load(folder/'mapping.json')
free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)}
check,_=audit(p,mp,load(BASE/'remaining25.json'),load(BASE/'modes.json'),free,load(BASE/'fixed-inner-rectangles-inset.json'),load(BASE/'mode-inner-rectangles.json'),relative,load(BASE/'control.json'));assert check['passed'] and check['pair_constraints']==0
assert digest(folder/'model.pb')==digest(BASE/'model/model.pb') and digest(folder/'mapping.json')==digest(BASE/'model/mapping.json')
params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert {f.name for f,v in params.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','ignore_subsolvers','log_search_progress','log_to_stdout'}
assert params.max_time_in_seconds==15 and params.num_search_workers==4 and params.random_seed==0 and list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
r=cp_model_pb2.CpSolverResponse();r.ParseFromString((folder/'response.pb').read_bytes());record=result['records'][0];assert r.status==cp_model_pb2.UNKNOWN and not r.solution and not r.additional_solutions
assert record==load(folder/'result.json') and record['status']=='UNKNOWN' and record['incumbents']==0 and not record['has_solution']
assert record['solver_wall_seconds']==r.wall_time and record['returned_response_branches']==r.num_branches and record['returned_response_conflicts']==r.num_conflicts
assert record['soft_overrun_seconds']==max(0.,record['returned_solve_seconds']-15)
assert not list(folder.glob('incumbent-*.json')) and not (folder/'assignment.json').exists() and not (folder/'source-audit.json').exists() and not (folder/'next-owner-pairs.json').exists()
search_start=float(re.search(r'Starting search at ([0-9.]+)s',(folder/'solver.log').read_text()).group(1))
inputs=[BASE/'plan.json',BASE/'model/checks.json',BASE/'pair-preflight/checks.json',SEARCH/'opened.json',SEARCH/'process.json',SEARCH/'result.json',folder/'model.pb',folder/'mapping.json',folder/'response.pb',folder/'parameters.pbtxt',folder/'solver.log']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'status':'UNKNOWN','distinct_solves':1,'all25_mandatory':True,'base_model_reaudited':check,'search_started_seconds':search_start,'returned_solve_seconds':record['returned_solve_seconds'],'solver_wall_seconds':r.wall_time,'solve_soft_overrun_seconds':record['soft_overrun_seconds'],'algorithm_seconds':result['algorithm_seconds'],'shared_seconds':process['seconds'],'no_candidate_stop_obeyed':True,'source_candidate_count':0,'dynamic_owner_constraints_added':0,'no_identical_model_repeat':True,'full66_witness':False,'native_calls':0,'actual_or_global_infeasibility_claimed':False,'H5_complete':False})
print(load(OUT/'checks.json'))
