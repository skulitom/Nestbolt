"""Inset the updated fixed core and independently check source-contained capacities."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';OUT=BASE/'capacity-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
assert load(BASE/'audit/checks.json')['passed']
raw=load(BASE/'fixed-inner-rectangles.json');fixed=[]
for r in raw:
    a,b,c,d=r['rectangle_um'];fixed.append({**r,'rectangle_um':[a+2,b+2,c-2,d-2]})
write(BASE/'fixed-inner-rectangles-inset.json',fixed)
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');mode_rows=load(BASE/'mode-inner-rectangles.json')
def source(part,angle,mirrored,offset):
    c,s=math.cos(angle),math.sin(angle);sign=-1 if mirrored else 1
    xy=[(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in part['geometry'][0]['outer']]
    return [tuple(F(str(v)) for v in p) for p in xy],Polygon(xy)
def segment_hits(a,b,r):
    lo,hi=F(0),F(1)
    for axis in [0,1]:
        delta=b[axis]-a[axis]
        if delta==0:
            if not r[axis]<=a[axis]<=r[axis+2]:return False
        else:
            u,v=sorted([(r[axis]-a[axis])/delta,(r[axis+2]-a[axis])/delta]);lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
def inside(point,vertices):
    x,y=point;result=False
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        if (a[1]>y)!=(b[1]>y) and x<a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]):result=not result
    return result
edges=rectangles=pairs=0
def verify(vertices,poly,rs):
    global edges,rectangles,pairs
    for rr in rs:
        assert all(isinstance(v,int) for v in rr) and rr[0]<rr[2] and rr[1]<rr[3]
        r=[F(v,1000) for v in rr];assert inside(r[:2],vertices)
        for a,b in zip(vertices,vertices[1:]+vertices[:1]):assert not segment_hits(a,b,r);edges+=1
        assert poly.contains(box(*map(float,r)));rectangles+=1
    for a,b in combinations(rs,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
assert len(modes)==len(mode_rows)==11
for m,r in zip(modes,mode_rows):
    assert (r['mode'],r['family'])==(m['index'],m['family'])
    vertices,poly=source(parts[m['family']],m['angle'],m['mirrored'],m['source_translation_offset']);verify(vertices,poly,r['rectangles_um'])
    area=sum((c-a)*(d-b) for a,b,c,d in r['rectangles_um'])/1e6;assert area==r['contained_area_mm2'] and poly.area==r['source_filled_area_mm2']
first=[r for r in load(BASE/'fixed41.json') if r['sheet_id']=='sheet-0'];assert len(first)==26
assert {tuple(r['owner']) for r in fixed}=={(r['part_id'],r['copy_index']) for r in first}
for r in first:
    t=r['transform'];vertices,poly=source(parts[r['part_id']],t['rotation_radians'],t['mirrored'],t['translation'])
    verify(vertices,poly,[v['rectangle_um'] for v in fixed if v['owner']==[r['part_id'],r['copy_index']]])
components=[r['rectangle_um'] for r in fixed]
for r in load(BASE/'control.json'):
    x,y=r['anchor_um'];components += [[a+x,b+y,c+x,d+y] for a,b,c,d in mode_rows[r['mode']]['rectangles_um']]
sweeps=[]
assert job['stocks'][0]['width']==1500 and job['stocks'][0]['height']==3000 and job['edge_clearance']==1.5 and all(v==5 for v in job['stocks'][0]['margins'].values())
for axis,cap in [(0,2987000),(1,1487000)]:
    events={}
    for r in components:
        amount=r[3-axis]-r[1-axis];events[r[axis]]=events.get(r[axis],0)+amount;events[r[axis+2]]=events.get(r[axis+2],0)-amount
    total=maximum=0
    for _,d in sorted(events.items()):total+=d;maximum=max(total,maximum);assert 0<=total<=cap
    assert total==0;sweeps.append({'axis':axis,'capacity_um':cap,'maximum_um':maximum,'slack_um':cap-maximum})
write(OUT/'necessity-proof.json',{'statement':'Every audited rectangle is strictly inside its original filled polygon, and rectangles within an owner have disjoint interiors. Disjoint original parts inside the stock therefore imply disjoint rectangle sections: vertical sections sum to at most2987000um and horizontal sections to at most1487000um. Optional rectangles share their selected mode literal. These capacities add only necessary conditions; holes remain reserved. Source free cells remain a constructive subset. Fixed rectangle edges were inset2um independently of the preserved preliminary exact rectangles.','local_containment':'Exact decimal Fraction ray parity and source-segment clipping; secondary Shapely containment.','source_holes_reserved':True})
inputs=[BASE/'plan.json',BASE/'audit/checks.json',BASE/'fixed41.json',BASE/'fixed-inner-rectangles.json',BASE/'fixed-inner-rectangles-inset.json',BASE/'modes.json',BASE/'mode-inner-rectangles.json',BASE/'control.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'fixed_originals':26,'contained_rectangles':rectangles,'source_segment_checks':edges,'same_owner_rectangle_pairs':pairs,'partial_control_components':len(components),'sweeps':sweeps,'solver_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
