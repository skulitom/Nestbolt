"""Save and independently read the small base before any search."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_lazy_cp_builder_20261028 import build
from h5_lazy_cp_reader_20261028 import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
for folder in [BASE,BASE/'audit',BASE/'capacity-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'capacity-audit/checks.json')['passed']
remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};fixed=load(BASE/'fixed-inner-rectangles-inset.json');rects=load(BASE/'mode-inner-rectangles.json');control=load(BASE/'control.json')
model,mp,hints,values=build(remaining,modes,free,fixed,rects,control);assert model.export_to_file(str(OUT/'model.pb'));assert model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mp);write(OUT/'hints.json',{str(k):v for k,v in hints.items()});write(OUT/'partial-control-assignment.json',values)
p=cp_model_pb2.CpModelProto();p.ParseFromString((OUT/'model.pb').read_bytes());checks,sol=audit(p,mp,remaining,modes,free,fixed,rects,relative,control);assert sol==values
write(OUT/'checks.json',{**checks,'seconds':time.perf_counter()-started,'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'H5_complete':False})
inputs=[BASE/'plan.json',BASE/'audit/checks.json',BASE/'capacity-audit/checks.json',BASE/'remaining25.json',BASE/'modes.json',BASE/'fixed41.json',BASE/'fixed-inner-rectangles-inset.json',BASE/'mode-inner-rectangles.json',BASE/'control.json']+sorted((BASE/'free').glob('*.json'))+sorted((BASE/'relative').glob('*.json'))+[ROOT/'output'/n for n in ['h5_lazy_cp_builder_20261028.py','h5_lazy_cp_reader_20261028.py','h5_rectangle_cp_evaluator_20261028.py']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'base_model_has_no_mover_pair_exclusions':True,'mandatory_movers':25,'all_originals_required':66,'saved_partial_control_is_not_target':True})
print(load(OUT/'checks.json'))
