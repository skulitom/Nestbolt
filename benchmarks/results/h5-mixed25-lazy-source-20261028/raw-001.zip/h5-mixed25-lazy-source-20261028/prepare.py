"""Freeze current-owner source cells and reusable intrinsic collision domains."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from shapely.geometry import shape
from h5_source_convex_cells_20261028 import encode,selected_cell
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';CORE=ROOT/'output/h5-mixed26-height-20261028';OLD=ROOT/'output/h5-free23-source-regions-20261028';COV=ROOT/'output/h5-mixed25-outer-covers-20261028';CAP=ROOT/'output/h5-free23-capacity-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();[(BASE/n).mkdir() for n in ['free','source-free','relative']];shutil.copyfile(__file__,BASE/'prepare.py');started=time.perf_counter()
assert load(CORE/'source-audit/checks.json')['passed'] and load(CORE/'new-free-regions/audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed'] and load(CAP/'geometry-audit-corrected/checks.json')['passed']
assert load(COV/'response-audit/checks.json')['status']=='UNKNOWN' and load(COV/'search/result.json')['closed']
inputs=[CORE/'response-audit/source41.json',CORE/'response-audit/selected-poses.json',CORE/'modes.json',CORE/'remaining25.json',CORE/'source-audit/checks.json',CORE/'new-free-regions/plan.json',CORE/'new-free-regions/audit/checks.json',OLD/'plan.json',OLD/'modes.json',OLD/'audit/checks.json',CAP/'mode-rectangles.json',CAP/'geometry-audit-corrected/checks.json',COV/'control-corrected/plan.json',COV/'control-corrected/control.json',COV/'control-corrected/control-source56.json',COV/'geometry-audit-corrected/checks.json',COV/'response-audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5_source_convex_cells_20261028.py',ROOT/'output/diagnose_h5_concave_gaps.py',ROOT/'output/h5_legacy64_source_readback.py']
inputs+=sorted((OLD/'relative').glob('*.json'))+[CORE/'new-free-regions'/f'{i:02d}.json' for i in range(11)]
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'one new source constraint-generation sequence, all25 movers mandatory around updated fixed41; initial source free cells and necessary contained-rectangle capacities; add complete pre-audited mode-pair relative-cell constraints only for owner pairs exposed by full original-source candidate checks','mode_count':11,'constructive_mode_subset':'phase7 cog, all8 bracket quarter/mirror modes, insert0/90; no free-angle or full-mode coverage claim','required_pair_gap_mm':.21170867250963943,'construction_extra_margin_mm':.0126,'stock_guard_mm':.011444091796875,'coordinate_grid_um':1,'absolute_coordinate_bounds_um':[1600000,3100000],'fixed_originals':41,'mandatory_movers':25,'target_originals':66,'algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_solves':8,'maximum_seconds_per_solve':15,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'no_repeat_identical_model':True,'stop_after_no_candidate_response':True,'budget_includes_dynamic_build_solve_and_source_checks':True,'source_checks_before_acceptance':True,'source_stocks':{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},'source56_control_is_partial_only':True,'native_calls':0,'H5_complete':False})
for src,dst in [(CORE/'response-audit/source41.json','fixed41.json'),(CORE/'remaining25.json','remaining25.json'),(OLD/'modes.json','modes.json'),(CAP/'mode-rectangles.json','mode-inner-rectangles.json'),(COV/'control-corrected/control.json','control.json'),(COV/'control-corrected/control-source56.json','control-source56.json')]:shutil.copyfile(src,BASE/dst)
assert digest(BASE/'modes.json')==digest(ROOT/'output/h5-staggered25-source-regions-20261028/modes.json')
summaries=[]
for i in range(11):
    src=CORE/'new-free-regions'/f'{i:02d}.json';shutil.copyfile(src,BASE/'source-free'/src.name);domain=encode(shape(load(src)));write(BASE/'free'/src.name,domain)
    summaries.append({'mode':i,'cells':len(domain['cells']),'halfplanes':sum(len(c['halfplanes']) for c in domain['cells'])})
for src in sorted((OLD/'relative').glob('*.json')):shutil.copyfile(src,BASE/'relative'/src.name)
fixed=[];old_modes=load(CORE/'modes.json')
for row in load(CORE/'response-audit/selected-poses.json'):
    x,y=row['anchor_um'];md=old_modes[row['mode']]
    for k,(a,b,c,d) in enumerate(md['original_rectangles_um']):fixed.append({'owner':[row['family'],row['copy_index']],'component':k,'rectangle_um':[x+a,y+b,x+c,y+d]})
write(BASE/'fixed-inner-rectangles.json',fixed)
control=load(BASE/'control.json');checks=[]
for row in control:
    cell=selected_cell(load(BASE/'free'/f"{row['mode']:02d}.json")['cells'],*row['anchor_um']);assert cell is not None;checks.append({'copy_index':row['copy_index'],'free_cell':cell})
write(BASE/'control-free-cell-hints.json',checks);write(BASE/'cells-summary.json',summaries)
write(BASE/'prepared.json',{'seconds':time.perf_counter()-started,'new_fixed_owner_domains':11,'new_free_cells':sum(r['cells'] for r in summaries),'new_free_halfplanes':sum(r['halfplanes'] for r in summaries),'byte_identical_intrinsic_pair_domains':66,'mode_inner_rectangles':sum(len(r['rectangles_um']) for r in load(BASE/'mode-inner-rectangles.json')),'updated_fixed_inner_rectangles':len(fixed),'source56_control_free_cells_pass':True,'solver_calls':0,'H5_complete':False})
print(load(BASE/'prepared.json'))
