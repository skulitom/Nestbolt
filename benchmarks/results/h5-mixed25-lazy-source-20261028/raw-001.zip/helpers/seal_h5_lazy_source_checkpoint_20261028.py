"""Seal the closed small relaxation, exact finite band checks and unchanged gates."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-mixed25-lazy-source-20261028';PUB=BASE/'publication';NAME='h5-mixed25-lazy-source-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='4d84aa40b65a8b897e2d8ee90b91a776d4bdb53f' and not git('diff','HEAD','--name-only')
audits=['audit/checks.json','capacity-audit/checks.json','model/checks.json','pair-preflight/checks.json','response-audit/checks.json','band-capacity-diagnosis/audit/checks.json']
assert all(load(BASE/n)['passed'] for n in audits);response=load(BASE/'response-audit/checks.json');assert response['status']=='UNKNOWN' and response['distinct_solves']==1
bands=load(BASE/'band-capacity-diagnosis/audit/checks.json');assert bands['overload_count']==0
prior=load(ROOT/'benchmarks/results/h5-mixed25-outer-covers-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='b699d1c1845828fe1bfaa675804b32fc4a894528';jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for p in BASE.rglob('*'):
    if p.is_file():add(BASE.name+'/'+p.relative_to(BASE).as_posix(),p)
helpers=['h5_source_convex_cells_20261028.py','prepare_h5_mixed25_lazy_geometry_20261028.py','make_h5_lazy_geometry_readers_20261028.py','audit_h5_mixed25_lazy_geometry_20261028.py','prepare_audit_h5_lazy_capacity_20261028.py','h5_lazy_cp_builder_20261028.py','h5_lazy_cp_reader_20261028.py','build_audit_h5_lazy_base_20261028.py','preflight_h5_lazy_pair_reader_20261028.py','check_h5_lazy_source_candidate_20261028.py','run_h5_lazy_constraint_generation_20261028.py','audit_h5_lazy_response_20261028.py','diagnose_h5_lazy_band_capacity_20261028.py','audit_h5_lazy_band_capacity_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('audit/checks.json','geometry-audit.json'),('capacity-audit/checks.json','capacity-audit.json'),('model/checks.json','base-model-audit.json'),('pair-preflight/checks.json','pair-preflight.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json'),('band-capacity-diagnosis/checks.json','band-diagnosis.json'),('band-capacity-diagnosis/audit/checks.json','band-audit.json'),('publication/main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40748909850,'main_all6_pass':True,'normal_push_still_requires_fresh_remote_ancestry_and_live_run_guards':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='The source-cell capacity relaxation is CLOSED UNKNOWN after its first15s solve, with no assignment; stop rule honored and remaining sequence time is not reusable. Base342vars4017cts, search starts0.44s, returned15.038662s, algorithm15.235108s/shared15.948386s, preserve0.038662s solve soft overrun. No runtime pair cuts or source candidates occurred. Fresh geometry77domains1138cells4129planes and fixed26 inset capacities139rectangles7592source edges pass. Independent6-family pair preflight covers all66 intrinsic mode domains including reversed deltas and keeps actual25mandatory distinct from partial56. Exact finite4278 full-width band necessities, independently checked by slope events, show no overload and prove neither feasibility nor fixed-core exclusion. Next prepare a materially different collision-first constraint-generation relaxation: keep all25 mandatory movers around the same fresh fixed41 and owner free cells, but omit the1471-component cumulative constraints that prevented any complete candidate here. Contained capacities can remain read-only diagnostics. Keep original source pair/stock/90hole10026vertex checks as the sole acceptance path; omission of model capacities never permits an invalid layout. Before solving, audit the new serialized model and a deliberately colliding complete66 diagnostic to exercise source reconstruction and pair identification, with no solver or success credit for that diagnostic. Then freeze one60s total algorithm/90s shared sequence, at most8 distinct solves of at most15s each, stop after any no-candidate response, and add full audited relative-cell mode variants for every exposed mover pair. Do not restart/reseed/extend this or any closed search, reset budgets per iteration, reuse old fixed-owner regions, or infer infeasibility from UNKNOWN. Source/native/material/fullH5 checks remain required for any complete candidate. Preserve valid64,444 necessary allocations,the original H2 gate and22 unopened vectors. Main b699d1c1 CI40748909850 now has all6passing jobs; two evidence checkpoints can be pushed after fresh normal atomic guards. Production/READMEs unchanged; no qualified release.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':6,'search_closed':True,'distinct_solves':1,'status':'UNKNOWN','all25_mandatory':True,'full_target_originals':66,'source56_control_is_partial_only':True,'new_source_candidates':0,'runtime_pair_constraints_added':0,'bands_checked':4278,'band_overloads':0,'source64_preserved':True,'remaining_necessary_allocations':444,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Full mixed-part source relaxation and band diagnosis — 2026-10-28

The smaller model keeps **all 25 remaining originals mandatory** around the
updated 41 fixed parts. Its first bounded call returns **UNKNOWN without a
candidate**, so the whole sequence stops. The subsequent finite band diagnosis
finds **no capacity contradiction**. Neither result proves feasibility or
infeasibility. H2/H5 remain open at **60% completed milestone weight**.

The initial model uses fresh fixed-owner free regions and necessary capacities
from rectangles contained in the original filled polygons. It has **342 variables,
4,017 constraints, 50 independent anchor coordinates, 1,471 rectangle options
and 205 partial hints**. It has no mover-pair collision constraints initially;
the planned generation loop would add those only after full source readback
exposed a collision. All holes remain reserved. The declared constructive modes
are one 7° cog orientation, eight bracket quarter/mirror choices and two insert
orientations, with no free-angle or complete-orientation claim.

Geometry readback checks **77 domains, 1,138 convex cells and 4,129 integer
halfplanes**, including 286 fixed-neighbour checks and 13,299 independently
constructed Minkowski hulls. Only intrinsic mode-pair domains are reused;
the fixed-owner regions correspond to the updated mixed26 core. The source56
control passes 925 pairs, 224 stock edges and 74 holes / 8,074 hole vertices.

The preliminary fixed rectangles remain preserved. A separately named copy
insets each edge by 2 µm for strict source containment. Independent exact
Fraction segment checks verify **139 contained rectangles against 7,592 source
edges**, plus 4,197 same-owner rectangle pairs. The source56 control passes
both cumulative capacities, with 132,524 µm and 7,024 µm slack.

The serialized model reader verifies every field and all 25 mandatory
constraints. A separate partial-control copy disables exactly ten mandatory
presences; restoring those ten domains reproduces the real model. The partial
control fails those ten requirements in the actual full66 target. A no-solve
preflight exercises all six family pairings, all 66 intrinsic mode domains and
the reversed displacement convention: **1,708 variables / 9,221 constraints**,
95 mode-pair groups, unchanged base prefix and a valid partial control.
This verifies the pair builder but is not a runtime generated-cut result.

The frozen sequence allowed at most eight distinct solves, each at most
15 seconds, within **one 60-second total algorithm budget and 90-second shared
limit**. Search starts at **0.44 s** and the first call returns UNKNOWN after
**15.038662 s returned / 15.037422 s solver time**. Total algorithm time is
**15.235108 s**, shared time **15.948386 s**. The **0.038662 s solve soft overrun**
is preserved. Its response reports 107,154 branches and 20,353 conflicts for
the returned worker, not an aggregate portfolio count. There are no assignments,
incumbents, source candidates, runtime generated cuts or native calls.
The stop-after-no-candidate rule is obeyed; unused time is not a new budget.

A separate read-only diagnosis freezes 93 horizontal boundaries and checks
all **4,278 bands**. For each mandatory part it minimizes the area of its
contained rectangles in each band over conservative anchor-Y intervals and
all permitted modes. These are exact integer piecewise-linear minima at
interval endpoints or rectangle/band breakpoints. Summing the independent
minima and fixed occupied area is a necessary lower bound only.

An independent event-slope implementation verifies all 4,278 results through
**143,421 slope events**, and checks the valid partial control against every
band. It finds **zero overloads**; 486 bands have a positive mover lower bound.
This finite check excludes no fixed-core construction and supplies no full
layout. Contained rectangles cover only part of each original, and X, mode
and inter-part couplings were deliberately relaxed in this diagnosis.

The next formulation will test collision generation before imposing the large
cumulative system. It must still require all66 originals, use the fresh owner
regions, reject every failing source candidate and add complete pair-mode
constraints for exposed collisions. Its complete diagnostic reconstruction,
serialized model and one total time budget must be audited before execution.
No closed solve is restarted or extended. Any successful source construction
still requires native, material and full H5 validation before integration.

[Main CI 40748909850](https://github.com/skulitom/Nestbolt/actions/runs/40748909850)
now passes all six jobs on b699d1c1. The prior outer-cover and this checkpoint
are ready for a normal atomic push after fresh remote guards. Production,
READMEs and upstream heads/releases are unchanged. The valid64 frontier,
444 necessary allocations, original H2 gate and 22 unopened reserved vectors
remain preserved. No new release qualifies.

Evidence: [geometry audit]({NAME}/geometry-audit.json),
[contained-capacity audit]({NAME}/capacity-audit.json),
[base-model reader]({NAME}/base-model-audit.json),
[pair preflight]({NAME}/pair-preflight.json),
[closed response]({NAME}/response-audit.json),
[independent band audit]({NAME}/band-audit.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all bound inputs, helpers, model fields, control,
solver response/logs, every band and publication snapshot.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 smaller source relaxation and exact bands, 2026-10-28:** [the evidence]({link})
verifies fresh owner regions, all25 mandatory movers and the smaller342-variable /
4017-constraint model. The first15s call is CLOSED UNKNOWN with no candidate;
the sequence stops immediately, preserving0.038662s solve soft overrun
(15.235108s algorithm /15.948386s shared). No dynamic pair cuts or native calls
occur. The no-solve pair preflight covers all66 intrinsic mode domains and
keeps partial56 distinct from actual66. Independent exact checks of4278 bands
find zero overloads, proving neither feasibility nor fixed-core exclusion.
Next audit collision-first generation with the large cumulative system omitted
from the initial model, while keeping all66 required and source checks as the
acceptance path. Predeclare one total bounded sequence; no closed solve restarts.
All six jobs of main b699d1c1 CI40748909850 now pass; the two reviewed evidence
checkpoints can be pushed after fresh guards. Production/READMEs, valid64,
444 necessary allocations,H2 gate and22 reserved vectors remain unchanged.
H2/H5 stay open at60%; no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
