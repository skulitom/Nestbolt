"""Create independent readers from closed audit sources without editing them."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_staggered25_regions_20261028.py').read_text(encoding='utf-8')
source=source.replace("BASE=ROOT/'output/h5-staggered25-source-regions-20261028'","BASE=ROOT/'output/h5-mixed25-lazy-source-20261028'")
source=source.replace("process=load(BASE/'process.json');assert not process['timeout'] and process['exit_code']==0 and process['seconds']<120","assert load(BASE/'prepared.json')['solver_calls']==0")
source=source.replace("result=load(BASE/'result.json')","result=load(BASE/'prepared.json')")
source=source.replace("assert load(BASE/'fixed-source-readback.json')['valid']", """from h5_legacy64_source_readback import audit
plan=load(BASE/'plan.json');expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};fixedkeys={(r['part_id'],r['copy_index']) for r in fixed};remaining={(r['family'],r['copy_index']) for r in load(BASE/'remaining25.json')}
assert len(fixedkeys)==41 and len(remaining)==25 and fixedkeys.isdisjoint(remaining) and fixedkeys|remaining==expected
source_fixed=audit(job,fixed,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],fixedkeys);assert source_fixed['valid'];write(OUT/'fixed-source-readback.json',source_fixed)
control=load(BASE/'control-source56.json');source_control=audit(job,control,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],fixedkeys|{('cog',i) for i in range(15)});assert source_control['valid'];write(OUT/'control-source-readback.json',source_control)
anchors=load(BASE/'control.json');selected=[]
for row in anchors:
    x,y=row['anchor_um'];cells=load(BASE/'free'/f\"{row['mode']:02d}.json\")['cells'];cell=next((i for i,c in enumerate(cells) if all(a*x+b*y>=v for a,b,v in c['halfplanes'])),None);assert cell is not None;selected.append({'copy_index':row['copy_index'],'free_cell':cell})
assert selected==load(BASE/'control-free-cell-hints.json')
for a,b in combinations(anchors,2):
    dx,dy=[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]];assert any(all(x*dx+y*dy>=v for x,y,v in c['halfplanes']) for c in load(BASE/'relative/00-00.json')['cells'])
""")
source=source.replace("BASE/'result.json'","BASE/'prepared.json'")
source=source.replace("'source_modes_verified':11","'all66_accounted_once':True,'source56_control_pairs':source_control['same_sheet_pairs'],'source56_control_holes':source_control['cutouts'],'source56_control_hole_vertices':source_control['hole_vertices'],'control_cog_pair_cells_checked':105,'source_modes_verified':11")
with (ROOT/'output/audit_h5_mixed25_lazy_geometry_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'created':'audit_h5_mixed25_lazy_geometry_20261028.py'})
