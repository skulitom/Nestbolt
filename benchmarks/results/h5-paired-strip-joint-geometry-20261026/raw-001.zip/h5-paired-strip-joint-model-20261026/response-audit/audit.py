"""Check the closed response, budgets and every assignment row when one is returned."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-joint-model-20261026';SEARCH=BASE/'search';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();audit=load(BASE/'model-audit/checks.json');assert audit['passed'] and audit['all17_required']
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert digest(SEARCH/'model.pb')==audit['model_sha256']==digest(BASE/'model.pb');model=pb.CpModelProto();model.ParseFromString((SEARCH/'model.pb').read_bytes());response=pb.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes())
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=60.,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False)
result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');budget=load(SEARCH/'budget.json');status=pb.CpSolverStatus.Name(response.status);assert process['exit_code']==0 and not process['timeout'] and process['seconds']<budget['shared_seconds']==90
assert status==result['status'] and status in ['UNKNOWN','INFEASIBLE','OPTIMAL','FEASIBLE'] and result['closed'] and result['solver_calls']==budget['maximum_calls']==1 and not budget['retry_permitted']
assert 0<response.wall_time==result['solver_wall_seconds']<=result['returned_solve_seconds']<=process['seconds'];assert result['solver_soft_overrun_seconds']==max(0,response.wall_time-60) and result['returned_soft_overrun_seconds']==max(0,result['returned_solve_seconds']-60)
assert response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts'];assert bool(response.solution)==result['has_solution']==(status in ['OPTIMAL','FEASIBLE'])
values=list(response.solution);assignment_checks=0
def domain(value,bounds):return any(bounds[k]<=value<=bounds[k+1] for k in range(0,len(bounds),2))
def expression(e):return e.offset+sum(values[i]*k for i,k in zip(e.vars,e.coeffs))
if values:
    assert len(values)==len(model.variables)
    for v,value in zip(model.variables,values):assert domain(value,v.domain)
    saved=load(SEARCH/'assignment.json');assert saved=={v.name:value for v,value in zip(model.variables,values)}
    for row in model.constraints:
        if not all(values[i] if i>=0 else not values[-i-1] for i in row.enforcement_literal):continue
        kind=row.WhichOneof('constraint')
        if kind=='linear':assert domain(sum(values[i]*k for i,k in zip(row.linear.vars,row.linear.coeffs)),row.linear.domain)
        elif kind=='interval':assert expression(row.interval.start)+expression(row.interval.size)==expression(row.interval.end) and expression(row.interval.size)>0
        elif kind=='table':
            actual=[expression(e) for e in row.table.exprs];n=len(actual);assert not row.table.negated and actual in [list(row.table.values[k:k+n]) for k in range(0,len(row.table.values),n)]
        elif kind=='no_overlap_2d':
            boxes=[]
            for xi,yi in zip(row.no_overlap_2d.x_intervals,row.no_overlap_2d.y_intervals):
                x,y=model.constraints[xi].interval,model.constraints[yi].interval;boxes.append([expression(x.start),expression(y.start),expression(x.end),expression(y.end)])
            for a,b in combinations(boxes,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
        else:raise AssertionError(kind)
        assignment_checks+=1
    write(OUT/'necessary-centers-and-inserts.json',{'cogs':[{'original':i,'center_units1000':[saved[f'c{i}-x'],saved[f'c{i}-y']]} for i in range(51,66)],'inserts':[{'original':i,'mode':saved[f'i{i}-mode'],'ideal_anchor_units1000':[saved[f'i{i}-x'],saved[f'i{i}-y']]} for i in [48,49]],'source_angles_and_geometry_still_required':True,'full66_target_witness':False})
log=(SEARCH/'solver.log').read_text();lines=log.splitlines();assert re.findall(r'^status:\s+(\w+)',log,re.M)[-1]==status;assert abs(float(re.findall(r'^walltime:\s+([0-9.]+)',log,re.M)[-1])-response.wall_time)<.0005
workers=[]
if any(line.startswith('Search stats') for line in lines):
    k=next(i for i,line in enumerate(lines) if line.startswith('Search stats'))+1
    while k<len(lines) and lines[k].strip():
        match=re.match(r"\s+'([^']+)':\s+([0-9']+)\s+([0-9']+)\s+([0-9']+)",lines[k]);assert match;name,bools,conflicts,branches=match.groups();workers.append({'worker':name,'booleans':int(bools.replace("'",'')),'conflicts':int(conflicts.replace("'",'')),'branches':int(branches.replace("'",''))});k+=1
write(OUT/'worker-stats.json',workers)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'solver_calls':1,'closed':True,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'shared_budget_honored':True,'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'returned_worker_branches':response.num_branches,'returned_worker_conflicts':response.num_conflicts,'search_started':any(line.startswith('Starting search at') for line in lines),'workers_with_branches':sum(w['branches']>0 for w in workers),'model_variables':len(model.variables),'model_constraints':len(model.constraints),'mandatory_inserts':2,'mandatory_cogs':15,'all17_required':True,'assignment_constraints_verified':assignment_checks,'necessary_positive_only':bool(values),'fixed34_neighborhood_excluded':status=='INFEASIBLE','formal_unsat_certificate_claimed':False,'source_witness_found':False,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
