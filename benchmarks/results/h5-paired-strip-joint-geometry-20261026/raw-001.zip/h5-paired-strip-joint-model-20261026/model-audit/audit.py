"""Full independent reconstruction by semantic names, without trusting the saved mapping."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json,math,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-joint-model-20261026';GEO=ROOT/'output/h5-paired-strip-joint-geometry-20261026';FAC=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'];m=pb.CpModelProto();m.ParseFromString((BASE/'model.pb').read_bytes());assert text_format.Parse((BASE/'model.pbtxt').read_text(),pb.CpModelProto())==m and not m.HasField('objective') and not m.HasField('solution_hint')
names={v.name:i for i,v in enumerate(m.variables)};rows={r.name:(i,r) for i,r in enumerate(m.constraints)};assert len(names)==len(m.variables) and len(rows)==len(m.constraints);seen=set();checked=set();I64=2**63-1
def V(name,lo,hi):
    assert name not in seen and name in names;seen.add(name);i=names[name];assert m.variables[i]==pb.IntegerVariableProto(name=name,domain=[lo,hi]);return i
def check(name,expected):
    assert name not in checked;checked.add(name);expected.name=name;assert rows[name][1]==expected,name;return rows[name][0]
def ex(v=None,offset=0):
    e=pb.LinearExpressionProto(offset=offset)
    if v is not None:e.vars.append(v);e.coeffs.append(1)
    return e
def linear(name,terms,lo,hi,flags=()):
    c=pb.ConstraintProto();c.enforcement_literal.extend(flags)
    for i,k in sorted(terms.items()):
        if k:c.linear.vars.append(i);c.linear.coeffs.append(k)
    c.linear.domain.extend([lo,hi]);check(name,c)
def interval(name,left,right,size):
    c=pb.ConstraintProto();c.interval.start.CopyFrom(ex(left));c.interval.end.CopyFrom(ex(right));c.interval.size.CopyFrom(ex(size));return check(name,c)
def disjunction(prefix,alternatives):
    flags=[]
    for j,(terms,limits) in enumerate(alternatives):
        flag=V(prefix+f'-choice{j}',0,1);flags.append(flag);linear(prefix+f'-direction{j}',terms,*limits,[flag])
    linear(prefix+'-one',dict.fromkeys(flags,1),1,1)
    return flags
spec=load(GEO/'inventory.json');stock=load(GEO/'constants.json')['relaxed_stock_bounds_units1000'];profiles=load(GEO/'insert-profiles.json');inserts=[];all_x=[];all_y=[]
assert spec['mandatory_moving_first_noncogs']==[48,49] and spec['mandatory_moving_first_cogs']==list(range(51,66)) and sorted(spec['fixed_first_originals']+spec['fixed_short_originals']+spec['mandatory_moving_first_originals'])==list(range(66))
for original in [48,49]:
    p={'original':original};prefix=f'i{original}'
    for role in ['x','y','left','bottom','right','top','center_x','center_y']:
        axis=0 if role in ['x','left','right','center_x'] else 1;p[role]=V(prefix+'-'+role,stock[axis],stock[axis+2])
    p['mode']=V(prefix+'-mode',0,3)
    for role in ['width','height']:p[role]=V(prefix+'-'+role,110000,180000)
    for role in ['inner_width','inner_height']:p[role]=V(prefix+'-'+role,109992,179992)
    row=pb.ConstraintProto()
    for role in ['mode','width','height']:row.table.exprs.add().CopyFrom(ex(p[role]))
    for mode in range(4):row.table.values.extend([mode,180000 if mode%2==0 else 110000,110000 if mode%2==0 else 180000])
    check(prefix+'-modes',row)
    for axis,size,limit in [('x','width',stock[2]),('y','height',stock[3])]:linear(prefix+'-stock-'+axis,{p[axis]:1,p[size]:1},-I64,limit)
    for edge,anchor,size,offset in [('left','x',None,4),('bottom','y',None,4),('right','x','width',-4),('top','y','height',-4)]:
        terms={p[edge]:1,p[anchor]:-1}
        if size is not None:terms[p[size]]=-1
        linear(prefix+'-'+edge,terms,offset,offset)
    for axis,dimension in [('x','width'),('y','height')]:
        linear(prefix+'-inner-'+dimension,{p['inner_'+dimension]:1,p[dimension]:-1},-8,-8)
        linear(prefix+'-center-'+axis,{p['center_'+axis]:2,p[axis]:-2,p[dimension]:-1},0,0)
    all_x.append(interval(prefix+'-x-interval',p['left'],p['right'],p['inner_width']));all_y.append(interval(prefix+'-y-interval',p['bottom'],p['top'],p['inner_height']));inserts.append(p)
for r in load(GEO/'fixed-clearance-boxes.json'):
    bb=r['bounds_units1000']
    for axis,target,k in [('x',all_x,0),('y',all_y,1)]:
        row=pb.ConstraintProto();row.interval.start.CopyFrom(ex(offset=bb[k]));row.interval.end.CopyFrom(ex(offset=bb[k+2]));row.interval.size.CopyFrom(ex(offset=bb[k+2]-bb[k]));target.append(check(f"clearance{r['index']}-{axis}",row))
row=pb.ConstraintProto();row.no_overlap_2d.x_intervals.extend(all_x);row.no_overlap_2d.y_intervals.extend(all_y);check('insert-and-fixed-clearance-nonoverlap',row);linear('insert-x-order',{inserts[1]['x']:1,inserts[0]['x']:-1},0,I64)
domains=load(GEO/'domains.json');caps=load(GEO/'domain-capacities.json');extent=[(min(r['bounds_units1000'][k] for r in domains),max(r['bounds_units1000'][k+2] for r in domains)) for k in [0,1]];cogs=[]
for original in range(51,66):
    p={'original':original,'x':V(f'c{original}-x',*extent[0]),'y':V(f'c{original}-y',*extent[1]),'domains':[]}
    for r in domains:
        prefix=f"c{original}-domain{r['index']}";flag=V(prefix,0,1);p['domains'].append(flag);b=r['bounds_units1000'];linear(prefix+'-x',{p['x']:1},b[0],b[2],[flag]);linear(prefix+'-y',{p['y']:1},b[1],b[3],[flag])
    linear(f'c{original}-one-domain',dict.fromkeys(p['domains'],1),1,1);cogs.append(p)
occupancies=[]
for j,cap in enumerate(caps):
    assert cap['domain']==j;v=V(f'domain{j}-occupancy',0,cap['capacity']);occupancies.append(v);terms={p['domains'][j]:1 for p in cogs};terms[v]=-1;linear(f'domain{j}-count',terms,0,0)
for a,b in load(GEO/'unit-domain-conflicts.json'):assert caps[a]['capacity']==caps[b]['capacity']==1;linear(f'domain-conflict{a}-{b}',{occupancies[a]:1,occupancies[b]:1},0,1)
for a,b in zip(cogs,cogs[1:]):linear(f"cog-order{a['original']}-{b['original']}",{b['x']:1,a['x']:-1},0,I64)
facets=load(FAC/'facets.json');inner=load(GEO/'cog-insert-facets.json');normals=load(ROOT/'output/h5-paired-strip-oblique-capacity-20261026/unit-normals.json');pair_count=circles=strips=vertex_boxes=0
for a,b in combinations(cogs,2):
    alternatives=[]
    for f in facets:
        nx,ny=f['normal'];alternatives.append(({b['x']:nx,a['x']:-nx,b['y']:ny,a['y']:-ny},[f['rhs'],I64]))
    disjunction(f"cog-pair{a['original']}-{b['original']}",alternatives);pair_count+=1
for cog in cogs:
    for box in inserts:
        tag=f"c{cog['original']}-i{box['original']}";alternatives=[]
        for f in inner:
            nx,ny=f['normal'];alternatives.append(({cog['x']:nx,box['center_x']:-nx,cog['y']:ny,box['center_y']:-ny},[f['rhs'],I64]))
        disjunction(tag+'-inner-circles',alternatives);circles+=1
        def outside(prefix,bounds):
            # Closed integer forbidden bounds, translated by the insert edges.
            left,bottom,right,top=bounds
            disjunction(prefix,[({cog['x']:1,box['left']:-1},[-I64,left-1]),({cog['x']:1,box['right']:-1},[right+1,I64]),({cog['y']:1,box['bottom']:-1},[-I64,bottom-1]),({cog['y']:1,box['top']:-1},[top+1,I64])])
        outside(tag+'-strip-horizontal',[15000+2,-139270+2,-15000-2,139270-2]);outside(tag+'-strip-vertical',[-139270+2,15000+2,139270-2,-15000-2]);strips+=2
        for ni,(nx,ny,den) in enumerate(normals):
            corners=[(F(nx*p-ny*q,den),F(ny*p+nx*q,den)) for p,q in product([139270,140001],[-15000,15000])];lx=min(p[0] for p in corners);ux=max(p[0] for p in corners);ly=min(p[1] for p in corners);uy=max(p[1] for p in corners)
            bb=[math.ceil(-lx)+2,math.ceil(-ly)+2,math.floor(-ux)-2,math.floor(-uy)-2];assert bb[0]+lx>0 and bb[1]+ly>0 and bb[2]+1+ux<0 and bb[3]+1+uy<0
            outside(tag+f'-vertex{ni}',bb);vertex_boxes+=1
assert seen==set(names) and checked==set(rows) and len(seen)==8440 and len(checked)==10044 and (pair_count,circles,strips,vertex_boxes)==(105,30,60,840)
largest=0
for row in m.constraints:
    if row.WhichOneof('constraint')=='linear':
        absolute=sum(abs(k)*max(abs(v) for v in m.variables[i].domain) for i,k in zip(row.linear.vars,row.linear.coeffs));assert absolute<2**62;largest=max(largest,absolute)
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));roundtrip=pb.CpModelProto();roundtrip.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert roundtrip==m
write(OUT/'necessity-proof.json',{'statement':'Every source layout for this fixed34/short15 core maps all17 movers into the independently verified geometry: two allowed insert modes and integer ideal-anchor floors, and15 floor-rounded cog centers. Global2Dnonoverlap follows because moving inner boxes lie inside actual insert outers and current fixed rectangles are forbidden by required clearance. Merged domains cover all cog floor centers, with integer-grid capacities and exact unit-domain conflicts. Valid cog pairs lie outside the inner254297 polygon. Each cog/insert model-circle pair lies outside its scaled inner164109 polygon. Both support-strip and all28 translated support-vertex forbidden boxes must be avoided, so at least one exact outside direction exists for each disjunction. Identical insert and cog copies may be relabelled in nondecreasing X without altering geometry. Independent semantic reconstruction verifies every variable, table, interval, equation and disjunction; all66 identities remain accounted once. Any positive remains necessary only and requires actual source cog angles, guarded geometry, full66 native/material validation and the completeH5 gate.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':len(seen),'constraints_verified':len(checked),'mandatory_inserts':2,'mandatory_cogs':15,'all17_required':True,'all66_identities_accounted_once':True,'mode_tables':2,'nonoverlap_boxes':26,'complete_cog_domains':29,'cog_domain_flags':435,'cog_pairs':pair_count,'cog_insert_circle_pairs':circles,'support_strips':strips,'support_vertex_boxes':vertex_boxes,'largest_linear_absolute_activity':largest,'actual_import_export_verified':True,'no_objective_or_hints':True,'saved_mapping_trusted':False,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
