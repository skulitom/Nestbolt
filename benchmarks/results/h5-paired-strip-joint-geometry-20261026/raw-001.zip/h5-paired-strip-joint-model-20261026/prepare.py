"""Joint necessary model of every remaining insert and cog, with current-owner geometry."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-joint-model-20261026';GEO=ROOT/'output/h5-paired-strip-joint-geometry-20261026';FAC=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';NORMAL=ROOT/'output/h5-paired-strip-oblique-capacity-20261026/unit-normals.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(GEO/'audit/checks.json')['passed']
inputs=[GEO/n for n in ['plan.json','inventory.json','domains.json','domain-capacities.json','unit-domain-conflicts.json','insert-profiles.json','fixed-clearance-boxes.json','constants.json','cog-insert-facets.json','audit/checks.json','audit/necessity-proof.json']]+[FAC/'vertices.json',FAC/'facets.json',NORMAL]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'solver_seconds':60,'shared_seconds':90,'workers':4,'seed':0,'method':'One joint necessary model requires both original inserts48/49 and all15 cogs51..65. Insert mode tables cover all original quarter turns with continuous ideal anchors represented by integer floors. Two certified inner rectangles and24 current clearance-forbidden boxes obey global2Dnonoverlap. All cogs choose complete29-domain coverage with certified capacities and85 unit-domain conflicts. All105 cog pairs choose an outward32-gon facet; all30 cog/insert inner-circle pairs choose a scaled outward facet. Every cog/insert pair avoids two support strips and28 exact rational support-vertex boxes. Every disjunction is derived from independently checked original geometry with rounding margins; no sampled source pose is fixed. Identical movers are ordered by X without fixing the originals. No objective or hints. A positive is necessary only and still needs source angles, original geometry, full66 native/material checks, production integration and theH5 matrix. All earlier models remain closed. One new60solver/90shared call after independent full model reconstruction, no retry or extension.'})
spec=load(GEO/'inventory.json');domains=load(GEO/'domains.json');capacities=load(GEO/'domain-capacities.json');profiles=load(GEO/'insert-profiles.json');fixed=load(GEO/'fixed-clearance-boxes.json');stock=load(GEO/'constants.json')['relaxed_stock_bounds_units1000'];facets=load(FAC/'facets.json');inner_facets=load(GEO/'cog-insert-facets.json');normals=load(NORMAL)
m=pb.CpModelProto();mapping={'inserts':[],'cogs':[],'interval_boxes':[],'occupancies':[],'cog_pairs':[],'cog_insert_circle_pairs':[],'support_strips':[],'support_vertex_boxes':[]};I64=2**63-1
def var(name,lo,hi):
    index=len(m.variables);m.variables.add(name=name,domain=[lo,hi]);return index
def expr(v=None,offset=0):return pb.LinearExpressionProto(vars=[] if v is None else [v],coeffs=[] if v is None else [1],offset=offset)
def linear(name,terms,lo,hi,flags=()):
    terms={i:k for i,k in terms.items() if k};indices=sorted(terms);m.constraints.add(name=name,enforcement_literal=flags,linear=pb.LinearConstraintProto(vars=indices,coeffs=[terms[i] for i in indices],domain=[lo,hi]))
def interval(name,start,end,size):
    index=len(m.constraints);m.constraints.add(name=name,interval=pb.IntervalConstraintProto(start=expr(start),end=expr(end),size=expr(size)));return index
def choices(prefix,rows):
    flags=[]
    for j,(terms,lo,hi) in enumerate(rows):
        flag=var(prefix+f'-choice{j}',0,1);flags.append(flag);linear(prefix+f'-direction{j}',terms,lo,hi,[flag])
    linear(prefix+'-one',dict.fromkeys(flags,1),1,1);return flags
for original in spec['mandatory_moving_first_noncogs']:
    prefix=f'i{original}';p={'original':original}
    for role,lo,hi in [('x',stock[0],stock[2]),('y',stock[1],stock[3]),('mode',0,3),('width',110000,180000),('height',110000,180000),('left',stock[0],stock[2]),('bottom',stock[1],stock[3]),('right',stock[0],stock[2]),('top',stock[1],stock[3]),('inner_width',109992,179992),('inner_height',109992,179992),('center_x',stock[0],stock[2]),('center_y',stock[1],stock[3])]:p[role]=var(prefix+'-'+role,lo,hi)
    table=[[r['mode'],*r['outer_size_units1000']] for r in profiles];m.constraints.add(name=prefix+'-modes',table=pb.TableConstraintProto(exprs=[expr(p[k]) for k in ['mode','width','height']],values=[v for r in table for v in r]))
    linear(prefix+'-stock-x',{p['x']:1,p['width']:1},-I64,stock[2]);linear(prefix+'-stock-y',{p['y']:1,p['height']:1},-I64,stock[3])
    for role,axis,dim,offset in [('left','x',None,4),('bottom','y',None,4),('right','x','width',-4),('top','y','height',-4)]:
        terms={p[role]:1,p[axis]:-1}
        if dim:terms[p[dim]]=-1
        linear(prefix+'-'+role,terms,offset,offset)
    linear(prefix+'-inner-width',{p['inner_width']:1,p['width']:-1},-8,-8);linear(prefix+'-inner-height',{p['inner_height']:1,p['height']:-1},-8,-8)
    linear(prefix+'-center-x',{p['center_x']:2,p['x']:-2,p['width']:-1},0,0);linear(prefix+'-center-y',{p['center_y']:2,p['y']:-2,p['height']:-1},0,0)
    p['x_interval']=interval(prefix+'-x-interval',p['left'],p['right'],p['inner_width']);p['y_interval']=interval(prefix+'-y-interval',p['bottom'],p['top'],p['inner_height']);mapping['inserts'].append(p);mapping['interval_boxes'].append({'kind':'insert','original':original,'x_interval':p['x_interval'],'y_interval':p['y_interval']})
for fixed_box in fixed:
    a,b,c,d=fixed_box['bounds_units1000'];indices=[]
    for axis,lo,hi in [('x',a,c),('y',b,d)]:
        indices.append(len(m.constraints));m.constraints.add(name=f"clearance{fixed_box['index']}-{axis}",interval=pb.IntervalConstraintProto(start=expr(offset=lo),end=expr(offset=hi),size=expr(offset=hi-lo)))
    mapping['interval_boxes'].append({'kind':'fixed_clearance','region':fixed_box['index'],'x_interval':indices[0],'y_interval':indices[1]})
m.constraints.add(name='insert-and-fixed-clearance-nonoverlap',no_overlap_2d=pb.NoOverlap2DConstraintProto(x_intervals=[b['x_interval'] for b in mapping['interval_boxes']],y_intervals=[b['y_interval'] for b in mapping['interval_boxes']]))
a,b=mapping['inserts'];linear('insert-x-order',{b['x']:1,a['x']:-1},0,I64)
extent=[[min(d['bounds_units1000'][k] for d in domains),max(d['bounds_units1000'][k+2] for d in domains)] for k in range(2)]
for original in spec['mandatory_moving_first_cogs']:
    p={'original':original,'x':var(f'c{original}-x',*extent[0]),'y':var(f'c{original}-y',*extent[1]),'domains':[]};mapping['cogs'].append(p)
    for d in domains:
        prefix=f"c{original}-domain{d['index']}";flag=var(prefix,0,1);p['domains'].append(flag);a,b,c,e=d['bounds_units1000'];linear(prefix+'-x',{p['x']:1},a,c,[flag]);linear(prefix+'-y',{p['y']:1},b,e,[flag])
    linear(f'c{original}-one-domain',dict.fromkeys(p['domains'],1),1,1)
for j,cap in enumerate(capacities):
    v=var(f'domain{j}-occupancy',0,cap['capacity']);mapping['occupancies'].append(v);linear(f'domain{j}-count',{**{p['domains'][j]:1 for p in mapping['cogs']},v:-1},0,0)
for a,b in load(GEO/'unit-domain-conflicts.json'):linear(f'domain-conflict{a}-{b}',{mapping['occupancies'][a]:1,mapping['occupancies'][b]:1},0,1)
for a,b in zip(mapping['cogs'],mapping['cogs'][1:]):linear(f"cog-order{a['original']}-{b['original']}",{b['x']:1,a['x']:-1},0,I64)
for a,b in combinations(mapping['cogs'],2):
    rows=[]
    for f in facets:
        nx,ny=f['normal'];rows.append(({b['x']:nx,a['x']:-nx,b['y']:ny,a['y']:-ny},f['rhs'],I64))
    flags=choices(f"cog-pair{a['original']}-{b['original']}",rows);mapping['cog_pairs'].append({'originals':[a['original'],b['original']],'flags':flags})
for cog in mapping['cogs']:
    for box in mapping['inserts']:
        tag=f"c{cog['original']}-i{box['original']}";rows=[]
        for f in inner_facets:
            nx,ny=f['normal'];rows.append(({cog['x']:nx,box['center_x']:-nx,cog['y']:ny,box['center_y']:-ny},f['rhs'],I64))
        flags=choices(tag+'-inner-circles',rows);mapping['cog_insert_circle_pairs'].append({'cog':cog['original'],'insert':box['original'],'flags':flags})
        for axis,offsets in [('horizontal',[15002,-139268,-15002,139268]),('vertical',[-139268,15002,139268,-15002])]:
            rows=[({cog['x']:1,box['left']:-1},-I64,offsets[0]-1),({cog['x']:1,box['right']:-1},offsets[2]+1,I64),({cog['y']:1,box['bottom']:-1},-I64,offsets[1]-1),({cog['y']:1,box['top']:-1},offsets[3]+1,I64)]
            flags=choices(tag+'-strip-'+axis,rows);mapping['support_strips'].append({'cog':cog['original'],'insert':box['original'],'axis':axis,'flags':flags})
        for ni,(nx,ny,den) in enumerate(normals):
            lowx=F(min(nx*139270,nx*140001)-abs(ny)*15000,den);highx=F(max(nx*139270,nx*140001)+abs(ny)*15000,den);lowy=F(min(ny*139270,ny*140001)-abs(nx)*15000,den);highy=F(max(ny*139270,ny*140001)+abs(nx)*15000,den)
            offsets=[math.ceil(-lowx)+2,math.ceil(-lowy)+2,math.floor(-highx)-2,math.floor(-highy)-2]
            rows=[({cog['x']:1,box['left']:-1},-I64,offsets[0]-1),({cog['x']:1,box['right']:-1},offsets[2]+1,I64),({cog['y']:1,box['bottom']:-1},-I64,offsets[1]-1),({cog['y']:1,box['top']:-1},offsets[3]+1,I64)]
            flags=choices(tag+f'-vertex{ni}',rows);mapping['support_vertex_boxes'].append({'cog':cog['original'],'insert':box['original'],'normal':ni,'offsets':offsets,'flags':flags})
assert len(mapping['inserts'])==2 and len(mapping['cogs'])==15 and len(mapping['cog_pairs'])==105 and len(mapping['cog_insert_circle_pairs'])==30 and len(mapping['support_strips'])==60 and len(mapping['support_vertex_boxes'])==840
(OUT/'model.pb').write_bytes(m.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'mapping.json',mapping);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(OUT/'model.pb'),'mandatory_inserts':2,'mandatory_cogs':15,'fixed_clearance_boxes':24,'domains':29,'cog_domain_choices':435,'cog_pairs':105,'cog_insert_circle_pairs':30,'support_strips':60,'support_vertex_boxes':840,'solver_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
