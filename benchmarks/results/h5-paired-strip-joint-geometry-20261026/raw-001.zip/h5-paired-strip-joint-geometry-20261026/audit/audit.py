"""Independently certify merged lattice coverage, insert geometry and joint necessities."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product,combinations
import json,math,shutil,time
from h5_rational_geometry_helpers import point_bounds,sub,mul
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-joint-geometry-20261026';OUT=BASE/'audit';CLIP=ROOT/'output/h5-paired-strip-clipped-capacity-20261026';CLR=ROOT/'output/h5-paired-strip-clearance-capacity-20261026';FAC=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(CLIP/'audit/checks.json')['passed'] and load(CLR/'audit/checks.json')['passed']
spec=load(BASE/'inventory.json');assert sorted(spec['fixed_first_originals']+spec['fixed_short_originals']+spec['mandatory_moving_first_originals'])==list(range(66)) and spec['mandatory_moving_first_noncogs']==[48,49] and spec['mandatory_moving_first_cogs']==list(range(51,66))
expected=[]
for f in load(CLIP/'footprints.json'):
    for j,b in enumerate(f['integer_rectangles']):expected.append({'index':len(expected),'original_cell':f['original_cell'],'piece':j,'bounds_units1000':b})
pieces=load(BASE/'source-pieces.json');assert pieces==expected;domains=load(BASE/'domains.json');seen=[];atoms=0;capacities=[];step=179815;D=254297;assert 2*(step-1)**2<D**2
for i,r in enumerate(domains):
    assert r['index']==i;a,b,c,d=r['bounds_units1000'];members=[pieces[k]['bounds_units1000'] for k in r['members']];assert len(set(r['members']))==len(members) and members
    assert all(a<=p[0]<=p[2]<=c and b<=p[1]<=p[3]<=d for p in members)
    xs=sorted({a,c+1}|{p[k]+(1 if k==2 else 0) for p in members for k in [0,2]});ys=sorted({b,d+1}|{p[k]+(1 if k==3 else 0) for p in members for k in [1,3]})
    covered=0
    for xindex,yindex in product(range(len(xs)-1),range(len(ys)-1)):
        x,y=xs[xindex],ys[yindex];assert any(p[0]<=x<=p[2] and p[1]<=y<=p[3] for p in members);covered+=(xs[xindex+1]-x)*(ys[yindex+1]-y);atoms+=1
    assert covered==(c-a+1)*(d-b+1);seen+=r['members']
    x_count=len(range(a,c+1,step));y_count=len(range(b,d+1,step));capacities.append({'domain':i,'capacity':x_count*y_count})
assert sorted(seen)==list(range(len(pieces))) and capacities==load(BASE/'domain-capacities.json');conflicts=[]
for i,j in combinations(range(len(domains)),2):
    if capacities[i]['capacity']!=1 or capacities[j]['capacity']!=1:continue
    a,b=domains[i]['bounds_units1000'],domains[j]['bounds_units1000'];maximum=max((x-u)**2+(y-v)**2 for x,y in product([a[0],a[2]],[a[1],a[3]]) for u,v in product([b[0],b[2]],[b[1],b[3]]))
    if maximum<D*D:conflicts.append([i,j])
assert conflicts==load(BASE/'unit-domain-conflicts.json')
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='insert');source=[tuple(map(F,p)) for p in part['geometry'][0]['outer']];assert source==[(0,0),(180,0),(180,110),(0,110)] and not part['allow_mirror'] and part['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]}
profiles=load(BASE/'insert-profiles.json');const=load(BASE/'constants.json');assert const['moving_inset']==4 and const['relaxed_stock_bounds_units1000']==[6480,6480,1493520,2993520];corners=edges=0;max_error=F(0)
for mode,p in enumerate(profiles):
    assert p['mode']==mode and p['degrees']==90*mode and p['rotation_radians']==math.radians(90*mode) and not p['mirrored']
    def ideal(x,y):return [(x,y),(-y,x),(-x,-y),(y,-x)][mode]
    ideal_points=[ideal(x,y) for x,y in source];mn=[min(v[k] for v in ideal_points) for k in range(2)];size=[int((max(v[k] for v in ideal_points)-mn[k])*1000) for k in range(2)];assert p['ideal_outer_min_mm']==mn and p['outer_size_units1000']==size and p['components_units1000']==[[0,0,*size]]
    t={'rotation_radians':p['rotation_radians'],'mirrored':False,'translation':[-mn[0],-mn[1]]};true=[point_bounds(v,t) for v in source]
    for actual,ideal_point in zip(true,ideal_points):
        for k in range(2):max_error=max(max_error,*(abs(q-(ideal_point[k]-mn[k])) for q in actual[k]))
    inner=[4,4,size[0]-4,size[1]-4]
    for x,y in product([F(inner[0],1000),F(inner[2],1000)],[F(inner[1],1000),F(inner[3],1000)]):
        point=((x-F(1,1000),x),(y-F(1,1000),y))
        for a,b in zip(true,true[1:]+true[:1]):
            cr=sub(mul(sub(b[0],a[0]),sub(point[1],a[1])),mul(sub(b[1],a[1]),sub(point[0],a[0])));assert cr[0]>0;edges+=1
        corners+=1
    w,h=inner[2]-inner[0],inner[3]-inner[1];assert min(w,h)//2==54996 and min(w,h)>30000 and min(w,h)+109115>140001
assert max_error<F(1,1000000) and max_error*1000+1<20
fixed=load(BASE/'fixed-clearance-boxes.json');assert fixed==load(CLR/'merged-clearance-rectangles.json') and len(fixed)==24
for a,b in combinations(fixed,2):
    a,b=a['bounds_units1000'],b['bounds_units1000'];assert min(a[2],b[2])<=max(a[0],b[0]) or min(a[3],b[3])<=max(a[1],b[1])
vertices=load(FAC/'vertices.json');facets=load(FAC/'facets.json');assert len(vertices)==len(facets)==32
for k,(a,b) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
    nx,ny=b[1]-a[1],a[0]-b[0];rhs=nx*a[0]+ny*a[1];assert facets[k]=={'normal':[nx,ny],'rhs':rhs} and rhs>0 and all(nx*x+ny*y<=rhs for x,y in vertices) and a[0]**2+a[1]**2<D**2
    c=vertices[(k+2)%32];assert (b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])>0
radius=164109;assert radius+2==109115+54996
scaled=load(BASE/'cog-insert-facets.json');assert scaled==[{'normal':f['normal'],'rhs':math.floor(F(f['rhs']*radius,D))} for f in facets] and all(f['rhs']>0 for f in scaled)
normals=load(ROOT/'output/h5-paired-strip-oblique-capacity-20261026/unit-normals.json');assert len(normals)==28 and all(nx*nx+ny*ny==den*den for nx,ny,den in normals);assert 140001**2-139270**2<=15000**2
write(OUT/'necessity-proof.json',{'statement':'The1067 source rectangles retain every source floor-rounded center. Independent integer-atom coverage proves each merged domain exactly equals its assigned rectangle union; every member is used once. Domains may share boundaries, and choosing any one containing domain preserves all valid centers. Integer tiles of side179815 have point-set diagonal below254297, proving the recorded capacities; unit-domain farthest corners prove all85 conflicts. The four original insert quarter turns are freshly checked with exact Taylor bounds. Each4-micrometre-inset model box lies inside its true source outer for every fractional ideal anchor in closed[0,1]^2 micrometres, and20 micrometres of outward stock relaxation covers errors and flooring. The24 fixed boxes are current clearance-forbidden rectangles, so source-valid inserts must not overlap them. Every moving insert inner box contains a circle of radius54996 at its integer center. A true cog contains radius109115; valid center separation from that fixed model-circle center is at least164111, so its floor-rounded center has distance greater than164109. Uniform scaling of the strictly inner32-gon and downward rounding of its facet RHS preserves containment within the164109 forbidden disk. Every valid pair can therefore choose an outward facet. The same verified inner32-gon for254297 applies to all105 cog pairs. Existing support-strip conditions hold for the insert inner dimensions. Exact rational support-vertex boxes can also be translated by its integer edges with the same2-unit floor margin. These constraints are necessary only. All15 cogs and both inserts remain mandatory; a positive model needs actual original geometry and a complete66-part native/material witness.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_rectangles_verified':len(pieces),'merged_domains_verified':len(domains),'integer_union_atoms_checked':atoms,'capacity_tile_diagonal_verified':True,'unit_domain_conflicts_verified':len(conflicts),'insert_profiles_verified':len(profiles),'fractional_anchor_corners_verified':corners,'exact_interval_edge_tests':edges,'fixed_clearance_rectangles_verified':len(fixed),'cog_pair_facets_verified':32,'cog_insert_facets_verified':32,'cog_insert_rounded_separation_units1000':radius,'all17_movers_mandatory':True,'all66_identities_accounted_once':True,'old_owner_geometry_used':False,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
