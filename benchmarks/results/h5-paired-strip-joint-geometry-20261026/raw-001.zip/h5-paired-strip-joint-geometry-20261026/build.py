"""Current-owner domains and intrinsic insert certificates for all17 required movers."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-joint-geometry-20261026';CLIP=ROOT/'output/h5-paired-strip-clipped-capacity-20261026';CLR=ROOT/'output/h5-paired-strip-clearance-capacity-20261026';INTR=ROOT/'output/h5-compact-joint-geometry-20261026';INV=ROOT/'output/h5-paired-strip-core-20261026/audit';FAC=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[CLIP/'footprints.json',CLIP/'audit/checks.json',CLIP/'audit/necessity-proof.json',CLIP/'response-audit/checks.json',CLR/'merged-clearance-rectangles.json',CLR/'audit/checks.json',CLR/'audit/necessity-proof.json',INTR/'plan.json',INTR/'profiles.json',INTR/'constants.json',INTR/'audit/plan.json',INTR/'audit/checks.json',INTR/'audit/component-certificates.json',INTR/'audit/necessity-proof.json',INV/'next-neighborhood.json',INV/'checks.json',FAC/'vertices.json',FAC/'facets.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-paired-strip-oblique-capacity-20261026/unit-normals.json']
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New joint necessary geometry after the cog-only clipped model closed UNKNOWN. Keep both inserts48/49 and all15 cogs51..65 mandatory, with the current fixed34/short15 inventory unchanged. Coalesce clipped integer rectangles only along an axis with identical transverse interval and overlapping or adjacent inclusive integer intervals; preserve member provenance. The union therefore keeps every source floor-rounded cog center. For each merged rectangle derive an integer-grid capacity using tiles of side179815, whose diagonal is below254297. Verify unit-domain conflicts by exact farthest corners. Reuse only the intrinsic four insert quarter-turn source certificates and source separation facets, bound to the identical original job; do not transfer old owner geometry. Use the24 exact current required-clearance rectangles as forbidden fixed boxes for moving insert inner rectangles. Add all-angle cog/insert support-strip, support-vertex and inner-circle necessities in the joint model. Independently verify coverage, reused intrinsic data and new radius/facet scaling before any solver.','tile_step_units1000':179815,'rounded_cog_separation_units1000':254297,'insert_inner_circle_radius_units1000':54996,'cog_insert_rounded_separation_units1000':164109,'solver_calls':0})
spec=load(INV/'next-neighborhood.json');assert spec['mandatory_moving_first_noncogs']==[48,49] and spec['mandatory_moving_first_cogs']==list(range(51,66))
pieces=[]
for f in load(CLIP/'footprints.json'):
    for j,b in enumerate(f['integer_rectangles']):pieces.append({'index':len(pieces),'original_cell':f['original_cell'],'piece':j,'bounds_units1000':b})
merged=[{'bounds_units1000':p['bounds_units1000'],'members':[p['index']]} for p in pieces];changed=True
while changed:
    changed=False
    for axis in [0,1]:
        other=1-axis;groups={}
        for r in merged:
            b=r['bounds_units1000'];groups.setdefault((b[other],b[other+2]),[]).append(r)
        result=[]
        for _,group in sorted(groups.items()):
            active=None
            for r in sorted(group,key=lambda r:(r['bounds_units1000'][axis],r['bounds_units1000'][axis+2])):
                b=r['bounds_units1000']
                if active is not None and b[axis]<=active['bounds_units1000'][axis+2]+1:
                    active['bounds_units1000'][axis+2]=max(active['bounds_units1000'][axis+2],b[axis+2]);active['members']+=r['members'];changed=True
                else:
                    if active is not None:result.append(active)
                    active={'bounds_units1000':list(b),'members':list(r['members'])}
            if active is not None:result.append(active)
        merged=result
merged.sort(key=lambda r:tuple(r['bounds_units1000']));domains=[{'index':i,**r} for i,r in enumerate(merged)]
caps=[{'domain':r['index'],'capacity':((r['bounds_units1000'][2]-r['bounds_units1000'][0]+179815)//179815)*((r['bounds_units1000'][3]-r['bounds_units1000'][1]+179815)//179815)} for r in domains];conflicts=[]
for i,a in enumerate(domains):
    if caps[i]['capacity']!=1:continue
    aa=a['bounds_units1000']
    for j in range(i+1,len(domains)):
        if caps[j]['capacity']!=1:continue
        b=domains[j]['bounds_units1000'];dx=max(abs(aa[0]-b[2]),abs(aa[2]-b[0]));dy=max(abs(aa[1]-b[3]),abs(aa[3]-b[1]))
        if dx*dx+dy*dy<254297**2:conflicts.append([i,j])
profiles=load(INTR/'profiles.json')['insert'];constants=load(INTR/'constants.json');fixed=load(CLR/'merged-clearance-rectangles.json');facets=load(FAC/'facets.json');scaled=[{'normal':f['normal'],'rhs':f['rhs']*164109//254297} for f in facets]
for n,v in [('source-pieces.json',pieces),('domains.json',domains),('domain-capacities.json',caps),('unit-domain-conflicts.json',conflicts),('insert-profiles.json',profiles),('fixed-clearance-boxes.json',fixed),('constants.json',constants),('cog-insert-facets.json',scaled),('inventory.json',spec)]:write(OUT/n,v)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'input_rectangles':len(pieces),'merged_domains':len(domains),'unit_domains':sum(c['capacity']==1 for c in caps),'unit_domain_conflicts':len(conflicts),'maximum_domain_capacity':max(c['capacity'] for c in caps),'insert_profiles':len(profiles),'fixed_clearance_boxes':len(fixed),'mandatory_inserts':2,'mandatory_cogs':15,'all17_movers_required':True,'all66_identities_accounted_once':True,'old_fixed_owner_geometry_used':False,'solver_calls':0,'independent_audit_pending':True,'H5_complete':False});print(load(OUT/'result.json'))
