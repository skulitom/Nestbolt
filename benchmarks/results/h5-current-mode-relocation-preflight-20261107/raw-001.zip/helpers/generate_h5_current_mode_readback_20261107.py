"""Extend full source reconstruction without changing the independent score oracle."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/h5_augmented_selection_readback_20261107.py').read_text(encoding='utf-8');source=source[:source.index('    winners=[]')]
changes={
    'from h5_augmented_selection_score_reference_20261107 import FullScore':'from h5_augmented_selection_score_reference_20261107 import FullScore\nfrom h5_current_mode_key_readback_20261107 import reconstruct_choice',
    "options[i]=[];seen={classes[family][modes[i]]:modes[i]}\n        for mi,cls in enumerate(classes[family]):":"options[i]=[];seen={}\n        order=[modes[i]]+[mi for mi in range(len(classes[family])) if mi!=modes[i]]\n        for mi in order:\n            cls=classes[family][mi]",
    "if cls in seen:kind='current' if cls==classes[family][modes[i]] else 'alias';representative=seen[cls]":"if cls in seen:kind='alias';representative=seen[cls]",
    "else:kind='new_physical_choice';representative=mi;seen[cls]=mi;options[i].append(mi)":"else:kind='current_physical_choice' if cls==classes[family][modes[i]] else 'new_physical_choice';representative=mi;seen[cls]=mi;options[i].append(mi)",
    'len(records)==len(expected)==2854':'len(records)==len(expected)==5911',
    'len(trials)==6396 and len(selections)==78':'len(trials)==9102 and len(selections)==111',
    "assert key not in keys and row['physical_key']==physical":"assert row['physical_key']==physical",
    "assert family_counts=={'bracket/bracket':1215,'bracket/insert':1296,'insert/insert':264}":"assert len(keys)==2854 and family_counts=={'bracket/bracket':1500,'bracket/insert':2160,'bracket/cog':900,'insert/insert':594,'insert/cog':540,'cog/cog':105}",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
source+='''    result,groups,minima,controls,key_near=reconstruct_choice(records,proposal_results);near_ties.extend(key_near)
    write('group-members.json',groups);write('key-minima.json',minima);write('key-ranking-controls.json',controls);write('near-tie-rankings.json',near_ties)
    write('checks.json',{'passed':True,'owner_aliases_verified':len(aliases),'center_trials':9102,'unique_centers':unique_count,'center_aliases':alias_count,'physical_owner_mode_choices':111,'raw_proposals':5911,'distinct_keys':len(groups),'key_size_histogram':{'1':2775,'33':78,'562':1},'joint_family_counts':family_counts,'independent_full_scores':score.calls,'maximum_component_score_error_mm2':max(score_errors),'maximum_scalar_reduction_error_mm2':score.max_scalar_reduction_error,'maximum_rational_auxiliary_error_mm2':score.max_rational_auxiliary_error,'different_numerical_rankings_within_predeclared_tolerance':len(near_ties),'closed_keys':len(closed),'excluded_keys':result['excluded_keys'],'excluded_raw_proposals':result['excluded_raw_proposals'],'strictly_improves_current':result['strictly_improves_current']})
    return result,groups,minima
'''
compile(source,'current-mode-readback','exec')
with (ROOT/'output/h5_current_mode_selection_readback_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
