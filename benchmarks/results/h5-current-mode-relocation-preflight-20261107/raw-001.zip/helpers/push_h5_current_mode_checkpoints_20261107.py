from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-current-mode-relocation-main-sync-20261107'
OLD_MAIN='a69021b6f67de0cf1c01cbf3f2d33209d5cca4b9';OLD_BRANCH='a69021b6f67de0cf1c01cbf3f2d33209d5cca4b9';BRANCH='codex/v1-1-shop-files'
def command(*args):return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not OUT.exists() and command('git','branch','--show-current')==BRANCH and not command('git','diff','HEAD','--name-only')
new=command('git','rev-parse','HEAD')
paths=command('git','diff','--name-only',OLD_MAIN+'..'+new).splitlines()
allowed={'.gitattributes','BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md'}
prefixes=('benchmarks/results/h5-best-admissible-augmented-construction-20261107','benchmarks/results/h5-current-mode-relocation-preflight-20261107')
assert paths and all(p in allowed or p.startswith(prefixes) for p in paths)
ci=json.loads(command('gh','run','view','42377560004','--json','databaseId,status,conclusion,headSha,jobs,url'))
assert ci['headSha']==OLD_MAIN and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
live=json.loads(command('gh','run','list','--branch','main','--limit','100','--json','databaseId,status,conclusion,headSha,workflowName,url'))
assert all(r['status']=='completed' for r in live)
refs=dict(reversed(line.split()) for line in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines())
assert refs=={'refs/heads/main':OLD_MAIN,'refs/heads/'+BRANCH:OLD_BRANCH}
for old in [OLD_MAIN,OLD_BRANCH]:subprocess.run(['git','merge-base','--is-ancestor',old,new],cwd=ROOT,check=True)
remote_files=json.loads((ROOT/'output/h5-resume-reconciliation-20261106/remote-files.json').read_bytes())
for p,h in remote_files.items():assert command('git','rev-parse',new+':'+p)==h,p
assert json.loads((ROOT/'benchmarks/results/h5-clearance-pair-proofs-20261106/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-frontier-refined-proofs-20261106/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-sat-certificate-pilot-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-clique-sat-frontier-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-polygon-clearance-proofs-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-exact-circle-forest-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-strip-capacity-models-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-twelve-cog-row-construction-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-twelve-cog-543-constructions-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-independent-twelve-cog-preparation-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-independent-cog-search-and-halfplanes-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-cog-halfplane-search-and-capacity-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-cog-capacity-search-and-initial-model-v2-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-staged-cog-candidate-and-projections-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-cog-convex-repair-and-choice-proofs-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-mixed-mode-source-repair-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-two-phase-geometry-and-angular-variations-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-target-cog-repair-and-source-gradients-20261107/archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'benchmarks/results/h5-direct-source-pose-construction-20261107/archive-checks.json').read_bytes())['passed']
for name in ['h5-best-admissible-augmented-construction-20261107','h5-current-mode-relocation-preflight-20261107']:
    assert json.loads((ROOT/'benchmarks/results'/name/'archive-checks.json').read_bytes())['passed']
OUT.mkdir();write(OUT/'prior-main-ci.json',ci);write(OUT/'pre-push-live-run-check.json',live);write(OUT/'changed-paths.json',paths)
r=subprocess.run(['git','push','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/'+BRANCH],cwd=ROOT,capture_output=True)
(OUT/'push-stdout.txt').write_bytes(r.stdout);(OUT/'push-stderr.txt').write_bytes(r.stderr);assert r.returncode==0,r.stderr
refs=dict(reversed(line.split()) for line in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines());assert set(refs.values())=={new}
new_ci=None
for _ in range(15):
    runs=json.loads(command('gh','run','list','--branch','main','--commit',new,'--workflow','Checks','--limit','10','--json','databaseId,status,conclusion,headSha,url'))
    if runs:new_ci=runs[0];break
    time.sleep(2)
record={'utc':datetime.now(timezone.utc).isoformat(),'old_main':OLD_MAIN,'old_working_branch':OLD_BRANCH,'new_main':new,
    'normal_atomic_fast_forward':True,'working_branch_also_updated':True,'prior_main_all6_pass':True,'prior_CI_run':42377560004,'new_main_CI':new_ci,
    'remote_files_preserved':len(remote_files),'changed_paths_relative_to_prior_main':len(paths),'evidence_and_status_only_relative_to_prior_main':True,'live_run_cancelled':False,
    'first57_original_site_choices':455,'first57_excluded_site_choices':451,'first57_remaining_site_choices':4,'remaining_allocation_candidates':440,
    'completion_percent':60,'H2_complete':False,'H5_complete':False,'release_created':False}
write(OUT/'receipt.json',record);print(record)
