"""Archive full current-mode source coverage, key grouping and deadline controls."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-current-mode-relocation-preflight-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107';F=BASE/'audit';D=F",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-best-admissible-augmented-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['optimizer_calls']==0 and front['key_minima']==2854 and front['strictly_improves_current']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-current-mode-relocation-preparation-process-20261107','h5-current-mode-relocation-audit-process-20261107']]",
    "['*h5*mixed*mode*20261107.py']":"['*h5*current*mode*20261107.py','prepare_h5_best_admissible_augmented_push_20261107.py','push_h5_best_admissible_augmented_checkpoints_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_current_mode_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(F/'checks.json','preflight-audit.json'),(F/'selection-replay/checks.json','selection-replay.json'),(F/'source-domains/checks.json','source-grid-domains.json'),(F/'source-domains/fixed-source-checks.json','fixed-source-checks.json'),(F/'selected-model-controls.json','selected-model-controls.json'),(F/'deadline-controls.json','deadline-controls.json'),(F/'policy-stop-controls.json','policy-stop-controls.json'),(BASE/'selection.json','initial-selection.json'),(BASE/'closed-problems.json','closed-problems.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for stage in ['preparation','audit']:copies.append((ROOT/'output'/f'h5-current-mode-relocation-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'broader_current_mode_finite_search_contract_required','finding':'The previously omitted current-mode center neighborhood is now fully prepared and independently replayed. Its accepted original-source initializer changes insert17 to mode2 and relocates cog28 in its current mode0. All5911raw placements are retained;2854complete key minima exclude14closed identities, including565raw placements across4source keys. No optimizer has opened and no full66packing follows from preflight.',
    'requirements':['Start only from this verified original-source selected state; no historical optimized/stopping winner or audit output may seed search. Keep all14closed complete objective/physical-mode/weight keys excluded; coordinate changes alone never reopen them.','Preserve all111owner-mode choices,9102nominal centers,5911raw proposals and complete2854key minima at each later runtime selection. Reconcile runtime closure flags and independent full scores, not only the winning proposal. Retain incoming cog angles in grid scoring and all15continuous angles in optimization.','Charge the complete source preparation recorded here before additional construction. Freeze a finite60/90-second pipeline with a source reserve before measurement; account for the larger selection taking about9seconds in this source preparation. Do not assume the preceding three-call schedule fits.','Use both tested cooperative deadline helpers and the outer verified Windows Job. A partial neighborhood or incomplete key grouping must retain evidence and select no candidate. Keep the fixed bounded area-only weight update and coefficient1auxiliary terms. Read every dynamic model before its sole call, retain every evaluation and all three winner streams.','Stop on the frozen count, time, no strict improvement, source-valid candidate or inconsistency. No restart, extra epoch, reseed or extension after closure. Fully replay all66originals before any native validation, material claim or H5credit.'],
    'complete_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'closed_augmented_problems':7,'closed_prior_weighted_problems':7,'new_neighborhood_prepared':True,'new_source_state_prepared':True,'finite_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
sel=load(F/'selection-replay/checks.json');dom=load(F/'source-domains/checks.json');model=load(F/'selected-model-controls.json');dead=load(F/'deadline-controls.json');prep=load(OUT/'preparation-process.json');audit=load(OUT/'audit-process.json');ci=load(BASE/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
assert prep['passed'] and audit['passed'] and model['physical_mode_changes']==[[17,0,2]] and model['owner_replacements']==[[17,2],[28,0]]
report=f'''# Current-mode relocation preflight — 2026-11-07

The broader source neighborhood now explicitly tests relocations in every
owner's current physical mode, including all fifteen cogs. Its selected
initializer combines an insert mode change with a cog relocation. Complete
independent source and ranking checks pass, but **no new optimizer has run and
no valid full66 packing is established**. H2/H5 remain open at **60% completed
milestone weight**.

## Complete source and key coverage

[Full score reconstruction]({NAME}/selection-replay.json) checks **9,102 nominal
centers** across **111 physical owner-mode choices**, plus **5,911 complete
current/single/joint proposals**: **15,013 full objective scores** in total.
This adds 33 current-mode options and 2,706 nominal centers to the old pool.
All 147 representative/alias bindings, 9,051 unique centers and 51 exact center
aliases are preserved. Grid scoring retains each incoming cog angle; the model
still has fifteen continuous angular coordinates.

The raw proposals map to **2,854 complete objective/physical-mode/weight keys**.
The unchanged physical vector has 562 placement variants, each of 78 single
physical changes has 33 variants, and 2,775 two-change vectors have one variant.
The independent reader verifies a deterministic minimum for every key before
global ranking. Maximum component score error is
**{sel['maximum_component_score_error_mm2']:.3e} mm²**; maximum scalar reduction
error is {sel['maximum_scalar_reduction_error_mm2']:.3e} mm² and the alternate
exact-rational auxiliary reconstruction differs by at most
{sel['maximum_rational_auxiliary_error_mm2']:.3e} mm². All
{sel['different_numerical_rankings_within_predeclared_tolerance']} differently
ordered numerical ties within the predeclared 1e-6 mm² tolerance remain recorded.

All [fourteen closed keys]({NAME}/closed-problems.json) remain excluded.
Four appear in this source pool, excluding **565 raw proposals**, including
all 562 variants of the closed baseline. Different coordinates cannot reopen
that identity. Raw single/joint diagnostics and every member of each key group
remain in the complete archive; no proposal is discarded before scoring.

## Original geometry and selected model

[Source-domain reconstruction]({NAME}/source-grid-domains.json) rebuilds every
grid placement directly from original job rings, legal transforms and cutouts.
It checks {dom['nominal_fixed_pair_checks']:,} nominal moving/fixed pairs and
{dom['nominal_stock_edges']:,} stock edges against {dom['same_sheet_fixed_originals']}
same-sheet fixed originals. There are {dom['unique_source_geometries']:,} distinct
owner/mode/center placements, {dom['unique_fixed_pair_checks']:,} distinct fixed-pair checks,
{dom['unique_holes_checked']:,} cutouts and {dom['unique_hole_vertices_checked']:,}
hole vertices. Every check passes. Minimum fixed gap is
{dom['minimum_fixed_gap_mm']:.12f} mm and minimum stock extra is
{dom['minimum_extra_stock_mm']:.12f} mm. These are finite trial checks; the
previously certified hard domains remain the continuum evidence. Mutual moving
part clearance is still unresolved. [All 33 fixed originals]({NAME}/fixed-source-checks.json)
are independently checked as well.

The [selected raw proposal]({NAME}/initial-selection.json) moves owner 17 from
physical mode 0 to 2 and relocates cog owner 28 in its existing physical mode 0.
Two coordinate replacements therefore constitute **one physical mode change**.
It is reconstructed only from the original unoptimized A/W source state, with
unchanged weights, geometry and hard domains. Its augmented score is
**{model['augmented_objective_mm2']:.6f} mm²** and original overlap is
**{model['original_overlap_mm2']:.6f} mm²**; this is an invalid initializer, not
a finished layout or a comparison with optimized historical winners.

[Model readback]({NAME}/selected-model-controls.json) preserves 81 coordinates,
33 movers, all 528 weighted original/clearance pairs and all 15 unweighted
coefficient-1 auxiliary terms. All 111 representative owner-mode models are
also read back. The selected model's {model['scalar_directed_gradient_terms']}
directed scalar gradient terms agree within
{model['maximum_scalar_gradient_error_mm']:.3e} mm under the existing explicit
source-boundary/nearest-feature conventions; no global smoothness claim follows.

## Stops, preparation and next work

[Eleven deadline controls]({NAME}/deadline-controls.json) cover six synthetic
neighborhood interruptions, one real 0.05 s interruption and four key-grouping
interruptions. Every partial result is retained and yields no selected proposal.
The real interruption overruns its cooperative boundary by
{dead['neighborhood_real_case']['observed_overrun_seconds']:.6f} s, recorded
explicitly. An in-progress geometry batch or grouping stage can overrun; the
verified Windows Job supplies the outer time and 2 GiB memory limit.
[Three policy controls]({NAME}/policy-stop-controls.json) reject an incomplete
pool and select nothing with all keys closed or zero strict improvement.
These controls are validation only and never seed search.

[Complete preparation]({NAME}/preparation-process.json) takes
**{prep['complete_seconds']:.6f} s**, including imports and output. Retaining the
entire prior 18.187213 s source lineage gives **{front['complete_preparation_seconds']:.6f} s**
of preparation before any new search. [The independent audit]({NAME}/audit-process.json)
closes in {audit['complete_seconds']:.6f} s. Both process trees close, with no
optimizer calls. No time allowance has been reset.

[Next]({NAME}/next-step.json), freeze a finite search contract for this audited
source state and the larger runtime neighborhood. The extra selection cost
must fit inside the existing preparation-inclusive 60/90 s limits and source
reserve. No new search contract is prepared. All fourteen closed identities
and prior finite pipelines stay closed. Four earlier arrangements and all
440 allocation candidates remain; no native call, exclusion or H5 credit follows.

[Main CI at review]({NAME}/main-ci-at-review.json) has {success} passed jobs and
{live} live jobs on a69021b6. This checkpoint and 85d36097 await the ordinary
push gate. Product code, README claims and releases remain unchanged.

[Archive verification]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 current-mode relocation preflight:** [independent complete source/model/selection checks]({{link}}) verify 111 owner-mode choices, 9,102 nominal centers and 5,911 raw proposals, totaling 15,013 full objective scores. All 2,854 complete key minima replay; 14 closed identities exclude 565 raw proposals across four source keys, and coordinates alone never reopen them. Source reconstruction checks {dom["nominal_fixed_pair_checks"]:,} nominal fixed pairs and 36,408 stock edges with all cutouts intact. The fresh original-source initializer changes insert 17 from mode 0 to 2 and relocates cog 28 in mode 0; its augmented score is {model["augmented_objective_mm2"]:.6f} mm² with {model["original_overlap_mm2"]:.6f} mm² original overlap. All 111 representative models and the complete 81-coordinate selected model read back. Eleven deadline controls and three policy stops pass; incomplete output selects nothing. Complete new preparation is {prep["complete_seconds"]:.6f} s, bringing retained source preparation to {front["complete_preparation_seconds"]:.6f} s. Both process trees close; no optimizer or full66 valid layout follows. Next freeze a finite search contract that accounts for the larger runtime selector within 60/90 seconds; none is prepared. All 14 closed keys and prior pipelines stay closed. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Main a69021b6 has {success} passed CI jobs and {live} live jobs at review; this checkpoint and 85d36097 await the ordinary push gate. Product, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [current-mode relocation preflight](../benchmarks/results/{NAME}.md).
Every current physical mode now has explicit grid relocation trials, including
all fifteen cogs. Independent replay verifies 9,102 centers, 5,911 raw proposals
and 2,854 complete key minima. All fourteen closed identities remain excluded;
four source keys exclude 565 raw placements. Original geometry passes all
{dom['nominal_fixed_pair_checks']:,} nominal fixed-pair and 36,408 stock-edge checks.
The fresh source initializer changes insert 17 to mode 2 and relocates cog 28
in its existing mode. All 111 representative models and the complete selected
model read back. Eleven deadline controls and three policy stops pass.
Complete source preparation is {front['complete_preparation_seconds']:.6f} s; both process trees close.
No optimizer has run on this state, and no valid full66 packing is established.
Next freeze a finite contract accounting for the larger runtime selector within
the existing 60/90 s limits. No new search contract is prepared.
All fourteen keys and prior pipelines stay closed. Four earlier arrangements
and 440 allocations remain; H2/H5 stay open at 60%. Main a69021b6 has {success}
passed CI jobs and {live} live jobs at review; this checkpoint and 85d36097 await
the ordinary push gate. Product code, README and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
