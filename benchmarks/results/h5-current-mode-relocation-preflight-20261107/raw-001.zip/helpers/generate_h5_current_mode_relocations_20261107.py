"""Version the scored neighborhood to include each owner's current physical mode."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/h5_augmented_deadline_neighbors_20261107.py').read_text(encoding='utf-8')
changes={
    "options[i]=[];seen={classes[family][modes[i]]:modes[i]}\n        for mode in library['family_modes'][family]:":"options[i]=[];seen={}\n        order=[modes[i]]+[m['mode'] for m in library['family_modes'][family] if m['mode']!=modes[i]]\n        for mi in order:\n            mode=library['family_modes'][family][mi]",
    "'kind':'current' if cls==classes[family][modes[i]] else 'alias'":"'kind':'alias'",
    "'kind':'new_physical_choice'":"'kind':'current_physical_choice' if cls==classes[family][modes[i]] else 'new_physical_choice'",
    "assert len(records)==2854 and len(trials)==6396 and len(selections)==78 and len({r['key'] for r in records})==2854":"assert len(records)==5911 and len(trials)==9102 and len(selections)==111 and len({r['key'] for r in records})==2854",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
compile(source,'current-mode-neighbors','exec')
with (ROOT/'output/h5_current_mode_relocations_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
