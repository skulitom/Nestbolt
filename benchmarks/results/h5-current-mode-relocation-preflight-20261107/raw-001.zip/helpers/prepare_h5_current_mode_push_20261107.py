"""Prepare an ordinary main/working-branch push for both audited checkpoints."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_best_admissible_augmented_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-best-admissible-augmented-main-sync-20261107':'h5-current-mode-relocation-main-sync-20261107',
    "prefixes=('benchmarks/results/h5-best-admissible-augmented-construction-20261107',)":"prefixes=('benchmarks/results/h5-best-admissible-augmented-construction-20261107','benchmarks/results/h5-current-mode-relocation-preflight-20261107')",
    "['h5-best-admissible-augmented-construction-20261107']":"['h5-best-admissible-augmented-construction-20261107','h5-current-mode-relocation-preflight-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_current_mode_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
