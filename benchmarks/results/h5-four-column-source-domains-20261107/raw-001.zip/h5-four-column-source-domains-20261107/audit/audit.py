from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product,combinations
from collections import Counter
import json,math,time,shutil
from shapely.geometry import Polygon,shape,MultiPoint
from h5_exact_convex_partition_tools_20261029 import area,cross,hull
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-four-column-source-domains-20261107';OUT=BASE/'audit';PREVIOUS=ROOT/'output/h5-mixed-direct-pose-v2-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def orient(v,positive=True):
    p=[tuple(map(F,x)) for x in v]
    return p if (area(p)>0)==positive else p[::-1]
def polygons(g):
    if g.geom_type=='Polygon':return [g]
    return [p for child in g.geoms for p in polygons(child)]
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(BASE/'library.json');job=load(JOB);parts={p['id']:p for p in job['parts']};old=load(PREVIOUS/'library.json');priorcheck=load(PREVIOUS/'audit/checks.json');assert priorcheck['passed'] and digest(PREVIOUS/'library.json')==priorcheck['library_sha256'];assert lib['families']==old['families'];stocks=lib['source_stocks'];guard=lib['stock_guard_mm'];required=lib['required_pair_gap_mm'];assert stocks==old['source_stocks'] and guard==old['stock_guard_mm'] and required==old['required_pair_gap_mm'];safe=[stocks['sheet-0'][0]+.025,stocks['sheet-0'][1]+.025,stocks['sheet-0'][2]-.025,stocks['sheet-0'][3]-.025];assert lib['safe_source_stock_mm']==safe
theta=math.pi/2;c,s=math.cos(theta),math.sin(theta);raw=[(x*c-y*s,x*s+y*c) for x,y in parts['frame']['geometry'][0]['outer']];width=max(p[0] for p in raw)-min(p[0] for p in raw);height=max(p[1] for p in raw)-min(p[1] for p in raw);frames=[];framev=[]
for col,n in enumerate([5,5,4,4]):
    for row in range(n):
        tx=safe[0]+col*(width+.23)-min(p[0] for p in raw);ty=safe[1]+row*(height+.23)-min(p[1] for p in raw);frames.append({'part_id':'frame','copy_index':len(frames),'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':False,'translation':[tx,ty]}});framev.append([[x+tx,y+ty] for x,y in raw])
fixed=frames+load(PREVIOUS/'short9-source.json');assert lib['fixed_source_rows']==fixed==load(BASE/'fixed27-source.json') and lib['fixed_frame_vertices']==framev;check=audit(job,fixed,stocks,required,guard);assert check==load(BASE/'fixed27-checks.json') and check['valid'];used={(r['part_id'],r['copy_index']) for r in fixed};ids=[[family,i] for family in ['bracket','insert','cog'] for i in range(parts[family]['quantity']) if (family,i) not in used];allids=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])];assert len(ids)==39 and ids==lib['identities'] and allids==lib['all66_identities'] and lib['pairs']==[[i,j] for i,j in combinations(range(39),2)] and len(lib['pairs'])==741 and lib['continuous_parameters']==90 and lib['angle_coordinate_start']==78 and lib['first_cog_owner']==27
radius=lib['angle_scale_mm'];center=lib['families']['cog']['source_center'];assert F(radius)**2>max(sum((F(v[k])-F(center[k]))**2 for k in [0,1]) for v in parts['cog']['geometry'][0]['outer']);assert lib['angle_bounds']==[[-math.pi*radius,math.pi*radius] for _ in range(12)];partitions=load(PREVIOUS/'partitions.json');proofs=load(BASE/'cell-source-supports.json');indexed={(p['family'],p['mode'],p['cell'],p['piece'],p['frame']):p for p in proofs};assert len(indexed)==len(proofs);seen=set();cells=0;minimum=math.inf;corner_controls=[];modecount=0;owneroptions=0
for family,options in lib['family_modes'].items():
    expected=[(False,0.)] if family=='cog' else [(mir,math.radians(degrees)) for mir in ([False,True] if parts[family]['allow_mirror'] else [False]) for degrees in parts[family]['rotations']['degrees']];assert len(options)==len(expected);owneroptions+=sum(x[0]==family for x in ids)*len(options)
    for mi,(option,(mir,angle)) in enumerate(zip(options,expected)):
        assert option['mode']==mi and option['mirrored']==mir and option['rotation_radians']==angle and option['continuous_rotation']==(family=='cog');modecount+=1;c,s=math.cos(angle),math.sin(angle);sign=-1 if mir else 1;px,py=lib['families'][family]['source_center'];local=option['local_containment_pieces']
        originals=[list(product([-radius,radius],repeat=2))] if family=='cog' else [[(sign*(x-px)*c-(y-py)*s,sign*(x-px)*s+(y-py)*c) for x,y in p] for p in partitions[family]['pieces']];assert len(local)==len(originals)
        for a,b in zip(local,originals):assert set(map(tuple,a))==set(b) and abs(area([tuple(map(F,p)) for p in a]))==abs(area(hull([tuple(map(F,p)) for p in a])))
        allv=[p for piece in originals for p in piece];bb=[safe[0]-min(p[0] for p in allv)+.000001,safe[1]-min(p[1] for p in allv)+.000001,safe[2]-max(p[0] for p in allv)-.000001,safe[3]-max(p[1] for p in allv)-.000001];assert bb==option['stock_center_bounds'];cc=[orient(p) for p in option['convex_center_cells']];free=shape(option['free_geometry']);rings=[]
        for p in polygons(free):rings.append(orient(list(p.exterior.coords)[:-1]));rings.extend(orient(list(r.coords)[:-1],False) for r in p.interiors)
        vertices={v for p in cc+rings for v in p}
        def boundary(pp):
            counts=Counter()
            for p in pp:
                for a,b in zip(p,p[1:]+p[:1]):
                    vv=sorted(v for v in vertices if cross(a,b,v)==0 and all(min(a[k],b[k])<=v[k]<=max(a[k],b[k]) for k in [0,1]));vv=vv if a<b else vv[::-1];assert vv[0]==a and vv[-1]==b
                    for x,y in zip(vv,vv[1:]):counts[min(x,y),max(x,y)]+=1 if x<y else -1
            return {k:v for k,v in counts.items() if v}
        assert boundary(cc)==boundary(rings) and sum(map(area,cc))==sum(map(area,rings)) and all(area(p)>0 and area(p)==area(hull(p)) for p in cc)
        for ci,cell in enumerate(cc):
            for pi,piece in enumerate(local):
                moved=hull([(a[0]+F(b[0]),a[1]+F(b[1])) for a,b in product(cell,piece)])
                for k in [0,1]:assert min(p[k] for p in moved)>F(safe[k]) and max(p[k] for p in moved)<F(safe[k+2])
                for fi,frame in enumerate(framev):
                    key=(family,mi,ci,pi,fi);record=indexed[key];seen.add(key);nx,ny=map(F,record['normal']);norm=nx*nx+ny*ny;d=min(F(x)*nx+F(y)*ny for x,y in frame)-max(x*nx+y*ny for x,y in moved);assert norm>0 and d>0 and d*d>=F('.22')**2*norm;minimum=min(minimum,float(d)/math.sqrt(float(norm)))
            for point in cell:
                for phase in ([-math.pi/3,0,math.pi/4] if family=='cog' else [angle]):
                    c,s=math.cos(phase),math.sin(phase);xy=list(map(float,point));partcopy=next(r[1] for r in ids if r[0]==family);row={'part_id':family,'copy_index':partcopy,'sheet_id':'sheet-0','transform':{'rotation_radians':phase,'mirrored':mir,'translation':[xy[0]-(sign*px*c-py*s),xy[1]-(sign*px*s+py*c)]}};source=audit(job,fixed+[row],stocks,required,guard);assert source['valid'];corner_controls.append({'family':family,'mode':mi,'cell':ci,'point':xy,'angle':phase,'minimum_original_gap_mm':source['minimum_pair_gap_mm'],'minimum_stock_mm':source['minimum_extra_stock_mm']})
        cells+=len(cc)
assert seen==set(indexed) and cells==29 and len(seen)==864 and modecount==13 and owneroptions==152;write(OUT/'source-corner-controls.json',corner_controls);prep=load(ROOT/'output/h5-four-column-source-preparation-process-20261107/prepare.json');assert prep['passed'] and prep['job']['closed'];charge=priorcheck['complete_failed_and_corrected_preparation_seconds']+prep['complete_seconds'];inputs=[Path(__file__),JOB,ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-four-column-source-preparation-process-20261107/prepare.json']+[BASE/n for n in ['plan.json','checks.json','library.json','cell-source-supports.json','fixed27-source.json','fixed27-checks.json']]+[PREVIOUS/n for n in ['library.json','partitions.json','short9-source.json','audit/checks.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct18frame sourceposes plusunchangedshort9;all39moving identities and741pair obligations. Check every legalmode and localsourcepiece/all-angle radius. Exact directedboundary cancellation verifies29convexallowedcenter cells. Check whole-cell Minkowski source envelopes againstall18originalframes using864exactrational supportproofs and exact stockbounds. Reconstruct actual original shapes at everycellvertex,including3continuouscogangle controls. Safety only;no continuous-feasibility completeness or exclusion is asserted.'});checks={'passed':True,'seconds':time.perf_counter()-start,'fixed_source_originals':27,'fixed_source_pairs':check['same_sheet_pairs'],'fixed_source_valid':True,'moving_originals':39,'moving_pairs_required':741,'owner_mode_options':owneroptions,'convex_center_cells':cells,'exact_whole_cell_source_supports':len(seen),'minimum_certified_fixed_gap_mm':minimum,'source_corner_controls':len(corner_controls),'complete_preparation_seconds':charge,'library_sha256':digest(BASE/'library.json'),'source_initializer_prepared':False,'complete_model_prepared':False,'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
