from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-four-column-source-domains-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-four-column-source-domains-20261107';F=ROOT/'output/h5-four-column-checkpoint-20261107';D=BASE","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-mixed-direct-source-construction-20261107'","front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==0 and front['moving_originals']==39","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F]+[ROOT/'output'/n for n in ['h5-four-column-source-preparation-process-20261107','h5-four-column-source-audit-process-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*four*column*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_four_column_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
for p,name in [(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(BASE/'audit/checks.json','source-domain-audit.json'),(BASE/'audit/source-corner-controls.json','source-corner-controls.json'),(BASE/'fixed27-checks.json','fixed-source-checks.json'),(ROOT/'output/h5-four-column-source-preparation-process-20261107/process.json','preparation-process.json'),(ROOT/'output/h5-four-column-source-audit-process-20261107/process.json','audit-process.json')]:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Four-column source domains for 39 moving originals — 2026-11-07

A changed source construction passes **864 exact whole-region separation
proofs and 132 original-source corner controls**. Its 27 fixed originals are
valid; all 39 remaining originals still need placement. No initializer,
complete optimization model, solver or native call is prepared or opened.
H2/H5 remain open at **60% completed milestone weight**. Four fixed arrangements
and 440 allocations remain; no layout or allocation exclusion is established.

## Changed physical scope

The large sheet fixes eighteen quarter-turned frames in four columns with
5/5/4/4 frames. The verified short sheet retains four brackets, two inserts
and three cogs. This leaves **eight brackets, nineteen inserts and twelve
cogs** movable on the large sheet: eleven more inserts than the preceding
continuous-angle construction. All legal bracket/insert modes and continuous
cog rotations remain obligations, totaling **152 owner/mode options, 90
continuous parameters and 741 moving pairs**.

The frame topology is historical. A closed 26 October search tried the same
column counts with five finite cog modes and a distance-based objective. It
does not supply an initializer here. The recent mixed direct-area search
allowed continuous cog angles but fixed eleven side-strip inserts and a
different frame core. This preparation changes both the fixed obstacles and
the free-insert/continuous-angle scope. Neither prior search is reopened.

Only the preceding source preparation's audited original partitions,
clearance contours, short sheet and acceptance data are reused. Its complete
**2.988826 s** cost, including its failed preparation, remains charged. The
optimized candidate and its selected modes or positions are not consumed.
The new frame poses derive directly from original dimensions and stock limits.
[All 27 fixed originals]({NAME}/fixed-source-checks.json) pass 189 same-sheet
pair checks; all source contours and holes remain unchanged.

## Certified placement regions

For each legal bracket/insert mode, the construction subtracts all original
convex-piece/frame forbidden regions from the source stock box. Each forbidden
region is expanded by a 0.23 mm square. Cogs use a source-derived
140.000002 mm all-angle radius and its circumscribing square. These cog
domains are conservative safe subsets; no claim of complete feasible-space
coverage is made.

The resulting nonrectangular domains have **29 convex cells across 13 family
modes**. [Independent exact directed-boundary and area readback]({NAME}/source-domain-audit.json)
verifies their decomposition. For every cell, each moving source piece is
added to the entire center region; exact rational support inequalities then
separate that whole translated envelope from every one of the eighteen
original frames. All **864 proofs** pass a 0.22 mm lower bound. The minimum
certified gap is **0.229999999611 mm**, above the unchanged source threshold
of 0.211708672510 mm. Exact stock-envelope checks also pass.

[132 corner controls]({NAME}/source-corner-controls.json) independently reconstruct
actual original shapes at every region vertex, including three continuous
cog-angle controls. Every control passes all original pair and stock checks
against the fixed 27. These checks prove that the allowed regions are safe;
they do not place the 39 movers together or discharge their 741 mutual pairs.

[Complete preparation]({NAME}/preparation-process.json) takes **0.607814 s**;
the consumed preparation charge is now **3.596640 s**. The separate
[independent audit]({NAME}/audit-process.json) takes **1.542762 s**. Both runs
close all descendants under their time and 2 GiB limits. No optimizer runs.

## Remaining work

[Next freeze a deterministic initializer and complete model]({NAME}/next-step.json),
with all candidates and preparation charged. Any region-distance penalty or
projection needs inside, outside, corner and derivative controls. Every mode,
coordinate, angle and pair binding must be independently read back before
one bounded pipeline. Source regions must not be mistaken for a full packing
result or an exclusion outside these safe subsets.

Every complete candidate still requires all 66 original-source checks before
native validation, material acceptance, the unchanged H5 matrix and production
UI/CLI/MCP parity. The H2 gate remains open under the earlier user decision.
[Main 30a26572 CI]({NAME}/main-ci-at-review.json) has five passed jobs and a live
Windows native job. The preceding 007b7efc checkpoint and this checkpoint await
the ordinary fast-forward push gate. Production, README and releases are unchanged.

[Raw evidence]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) preserve exact reused inputs.
Independent archive readback is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 four-column source domains:** [independent original-source audits]({link}) verify 27 fixed originals, 29 convex center regions, 864 exact whole-cell support proofs and 132 source corner controls. The changed construction frees nineteen inserts, eight brackets and twelve continuously rotating cogs: 39 movers, 152 owner/mode options, 90 continuous parameters and 741 mutual pairs still to satisfy. The four-column topology is historical; prior finite-angle and recent fixed-side-insert calls remain closed. The minimum certified fixed-frame gap is 0.229999999611 mm. Complete new preparation is 0.607814 s, bringing the consumed preparation charge to 3.596640 s. All processes close. Next freeze and verify one deterministic initializer and complete model; neither is prepared and no optimizer or native call opens. No full66 witness or exclusion follows. Four fixed arrangements and 440 allocations remain; H2/H5 stay at 60%. Main30a26572 has five passed CI jobs and a live Windows native job; checkpoint007b7efc and this checkpoint await the ordinary push gate. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
path=ROOT/'docs/STATUS.md';s=path.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a);intro=f'''Latest H5 evidence: [four-column source domains](../benchmarks/results/{NAME}.md).
A changed frame/free-insert construction retains 27 source-valid fixed originals
and leaves 39 movers with 12 continuous cog angles. All 29 allowed center regions
pass 864 exact whole-cell source separation proofs and 132 source corner controls.
The historical frame topology is acknowledged; earlier closed calls remain closed.
Complete consumed preparation is 3.596640 s. Next freeze one deterministic initializer
and complete 90-parameter model, then verify all mode, region, angle and pair bindings
before a bounded search. No initializer, complete model or optimizer call is prepared.
The preceding broader mixed-mode search closed with 41 source overlaps after one
call and 80 unsuccessful orientation changes. No full layout or exclusion follows.
Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%.
Full source/native/material validation, production parity and the unchanged H5
matrix remain required. Main 30a26572 has five passed CI jobs and a live Windows
native job. Checkpoint 007b7efc and this checkpoint await the ordinary push gate.
No release qualifies.
''';path.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
