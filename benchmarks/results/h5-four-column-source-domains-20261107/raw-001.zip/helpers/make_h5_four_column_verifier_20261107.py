from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/verify_h5_direct_pose_checkpoint_20261107.py').read_text(encoding='utf-8').replace('h5-direct-source-pose-construction-20261107','h5-four-column-source-domains-20261107')
with (ROOT/'output/verify_h5_four_column_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
