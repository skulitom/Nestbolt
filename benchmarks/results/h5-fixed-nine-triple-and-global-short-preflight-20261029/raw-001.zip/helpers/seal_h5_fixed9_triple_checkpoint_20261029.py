"""Seal all fixed-nine exclusions and the independently checked global short13 preflight."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
INV=ROOT/'output/h5-short-fixed9-inventory-20261029';PAIR=ROOT/'output/h5-short-fixed9-joint-20261029';BASE=ROOT/'output/h5-short-fixed9-triples-20261029';PRE=BASE/'global-short-preflight';PUB=BASE/'publication';NAME='h5-fixed-nine-triple-and-global-short-preflight-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='1d545cac683c6f15642443781f0350411eeedeb2' and not git('diff','HEAD','--name-only')
iv=load(INV/'audit/checks.json');pa=load(PAIR/'audit/checks.json');tr=load(BASE/'audit/checks.json');gp=load(PRE/'audit/checks.json');assert all(r['passed'] for r in [iv,pa,tr,gp])
assert iv['all_angle_fixed9_single_cog_excluded_geometries']==144 and pa['combined_fixed9_geometries_excluded']==195 and tr['combined_fixed9_geometries_excluded']==200 and tr['combined_identity_variants_excluded']==330
assert pa['depth40_partial_cases_retained']==20 and tr['all15_required_triple_cases_verified'] and tr['minimum_parent_poses_that_must_change']==4
assert gp['source_to_integer_core_mapping_proved_with_positive_gap_and_expanded_stock'] and not gp['CP_model_created'] and not gp['search_opened']
prior=load(ROOT/'benchmarks/results/h5-fixed-ten-joint-cog-bound-20261029/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert main=='6b0a1d0b2e2f5abdcddf9a3fb73c27cdb0d8e641' and ci['head_sha']==main and ci['status']=='in_progress' and len(jobs)==6
passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [INV,PAIR,BASE]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_short_fixed9_inventory_20261029.py','audit_h5_short_fixed9_inventory_20261029.py','prove_h5_short_fixed9_joint_20261029.py','audit_h5_short_fixed9_joint_20261029.py','h5_joint_core_certificate_reader_20261029.py','h5_multiple_core_coverage_20261029.py','prove_h5_short_fixed9_triples_20261029.py','audit_h5_short_fixed9_triples_20261029.py','prepare_h5_global_short_core_preflight_20261029.py','audit_h5_global_short_core_preflight_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_fixed9_triple_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(INV,'result.json','inventory-result.json'),(INV,'audit/checks.json','inventory-audit.json'),(PAIR,'result.json','pair-bound-result.json'),(PAIR,'geometry-summary.json','pair-geometry-summary.json'),(PAIR,'audit/checks.json','pair-bound-audit.json'),(BASE,'result.json','triple-bound-result.json'),(BASE,'geometry-summary.json','triple-geometry-summary.json'),(BASE,'audit/checks.json','triple-bound-audit.json'),(BASE,'audit/necessity-proof.json','necessity-proof.json'),(PRE,'plan.json','global-preflight-plan.json'),(PRE,'checks.json','global-preflight.json'),(PRE,'audit/checks.json','global-preflight-audit.json'),(PRE,'controls.json','global-controls.json'),(PRE,'rounding-proof.json','global-rounding-proof.json'),(PRE,'inventory.json','global-inventory.json')]
for folder,a,b in copies:shutil.copyfile(folder/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40789500705,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Build and independently audit the already frozen global short13 necessary CP-SAT model before its sole60/90-second call. All13 source originals must have independently movable anchors and mandatory presence. Use8 bracket modes,4 insert modes,16 orthogonal core pieces,32 cog/rectangle predicates with the audited36 symbolic facet directions, and one32-facet cog/cog predicate. Keep source stock, margins, gap and all66 identities unchanged. Reuse the positive source11 control only by disabling its two explicit missing-presence requirements during validation; the full target remains13. Audit protobuf semantics, mode/anchor/core mapping and the full negative13 control before search. The proved rounding map makes this a necessary integer relaxation. Any feasible core assignment still needs original cog-angle and full contour realization, then a complete first53 placement and independent66 check before native validation. Do not reopen any fixed-eleven, fixed-ten or fixed-nine study.','CP_model_created':False,'search_opened':False,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'fixed9_inventory_variants':330,'distinct_fixed9_source_geometries':200,'single_cog_excluded_geometries':144,'additional_pair_excluded_geometries':51,'additional_triple_excluded_geometries':5,'all200_geometries_and330_variants_excluded':True,'minimum_parent_poses_that_must_change':4,'pair_depth_limited_cases_preserved':20,'all15_triple_cases_covered':True,'global_short_target_originals':13,'mandatory_first_sheet_originals':53,'all13_short_poses_independently_movable_in_next_model':True,'global_source_geometry_preflight_passed':True,'CP_model_created':False,'search_opened':False,'construction_calls':0,'solver_calls':0,'native_calls':0,'new_source_valid13':False,'new_source_valid66':False,'full_allocation_or_original_job_excluded':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
