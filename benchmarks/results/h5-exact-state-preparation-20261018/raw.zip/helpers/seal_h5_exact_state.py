"""Seal the qualified observation source and checks before measurement."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exact-state-20261018'
out=root/'benchmarks/results/h5-exact-state-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_exact_state as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '116 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert load(probe/'reconstruction.json')['all_formatted_files_exact']
assert runner.prior.source_digest()==plan['production_digest']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==14
assert len(reader['malformed_records_rejected'])==37 and reader['reader_sha256']==digest(root/'scripts/h5_exact_state.py')
method=load(probe/'runner-method.json');assert method['measurement_function_AST_exact_except_expected_count'] and method['runner_sha256']==reader['reader_sha256']
binaries=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
assert digest(binaries[0])==reader['test_binary_sha256'];shutil.copyfile(binaries[0],probe/'authored-tests.exe')
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_exact_state.py','build_h5_exact_state.py','prepare_h5_exact_state_runner.py','check_h5_exact_state_reader.py','check_h5_exact_state_source.py','seal_h5_exact_state.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_exact_state.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
write(out/'checks.json',{'all_qualified':True,'optimized_core_tests_passed':116,'original_tests_unchanged':113,'new_exact_state_tests':3,
    'strict_lint_passed':True,'observer_build_passed':True,'authored_test_traces':14,'malformed_records_rejected':37,
    'exact_parent_reconstruction':True,'unchanged_other_files':153,'production_unchanged':True,'measured_search_started':False,'H5_complete':False})
for name in ['preparation.json','build.json','reconstruction.json','instrumentation.patch','runner-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'authored-trace-reader/checks.json',out/'reader-checks.json')
doc='''# Exact-state observation — preparation, 2026-10-18

The [preceding timings](h5-larger-stage-20261018.md) identify expensive neutral
panel proposals, but do not establish identical geometry. This separate copy
compares exact internal float bits, reflection, original item identity and
multiplicity, with shared immutable container and item objects. Placement keys
and insertion order are ignored. Negative results are conservative: equivalent
angles or signed zeros can differ. Same inventory alone proves nothing.

The comparison only records observations; every original repair, validation,
material guard, decision and work charge remains. Neutral rejections retain
complete incumbent/trial public layouts for independent validation and exact
pose-multiset comparison. All 113 original optimized tests plus three new
identity tests pass, with strict lint/build, fourteen authored trace cases,
37 malformed-observation rejections and exact reconstruction of all 154 files.

Two serial panel-hardware diagnostics use kerfs 0.2/1.5 mm, seed zero, 60 seconds
and physical CCD0 CPU 8. The run method changes only its expected count from
four to two. Observation overhead can affect deadlines; this is not a quality
comparison or a speedup claim. Only an observed exact match could motivate a
later early-rejection experiment; changed states retain full validation.
The failed pilot remains authoritative. Production and reserved inputs stay
unchanged; H2/H5 remain open at 60%.

[Checks](h5-exact-state-preparation-20261018/checks.json),
[source reconstruction](h5-exact-state-preparation-20261018/reconstruction.json),
[reader checks](h5-exact-state-preparation-20261018/reader-checks.json),
[archive integrity](h5-exact-state-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-exact-state-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size,'all_qualified':True}))
