"""Observe exact physical-state equality; change no search decision or guard."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1]
out=root/'output/h5-exact-state-20261018';old=root/'output/h5-larger-stage-20261018/workspace'
work=out/'workspace';out.mkdir();shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs';path=work/rel
original=path.read_text(encoding='utf-8');text=original;changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,(before,text.count(before))
    text=text.replace(before,after);changes.append((before,after))
helper='''// Diagnostic only: exact bits and shared immutable model identity.
// Ignore placement keys and order, retain multiplicity. A false result does
// not prove changed geometry (e.g. -0 versus +0); true is conservative.
fn exact_physical_state(a: &JLayout, b: &JLayout) -> bool {
    use std::sync::Arc;
    if !Arc::ptr_eq(a.container().base_cde(), b.container().base_cde())
        || !Arc::ptr_eq(a.container().outer_orig(), b.container().outer_orig())
        || !Arc::ptr_eq(a.container().outer_cd(), b.container().outer_cd())
        || a.placed_items().len() != b.placed_items().len()
    {
        return false;
    }
    let keys = |layout: &JLayout| {
        let mut keys: Vec<_> = layout.placed_items().values().map(|p| {
            let dt = p.d_transf();
            let (x,y) = dt.translation();
            (p.item().idx(), Arc::as_ptr(p.item()) as usize,
                [dt.rotation().to_bits(), x.to_bits(), y.to_bits()], dt.reflected)
        }).collect();
        keys.sort_unstable();
        keys
    };
    keys(a) == keys(b)
}

'''
replace('fn exchange_increases_material(',helper+'fn exchange_increases_material(')
replace('    validation_elapsed: Option<f64>,','    validation_elapsed: Option<f64>,\n    identity_elapsed: Option<f64>,\n    exact_state: Option<bool>,\n    neutral_layouts: Option<serde_json::Value>,')
replace('                        validation_elapsed: None,','                        validation_elapsed: None,\n                        identity_elapsed: None,\n                        exact_state: None,\n                        neutral_layouts: None,')
replace('                    let validation_started = Instant::now();','''                    let identity_started = Instant::now();
                    trace.attempts[index].exact_state = Some(exact_physical_state(&sep.layout, &trial));
                    trace.attempts[index].identity_elapsed = Some(identity_started.elapsed().as_secs_f64());
                    let validation_started = Instant::now();''')
replace('                        self.stats.neutral_exchange_rejections += 1;','''                        self.stats.neutral_exchange_rejections += 1;
                        let mut incumbent_sheets = frozen.to_vec();
                        incumbent_sheets.extend(strip.split(&sep.layout, shape.sheets)?);
                        let mut trial_sheets = frozen.to_vec();
                        trial_sheets.extend(strip.split(&trial, shape.sheets)?);
                        trace.attempts[index].neutral_layouts = Some(serde_json::json!({
                            "incumbent":self.model.to_layout(&incumbent_sheets),
                            "trial":self.model.to_layout(&trial_sheets)
                        }));''')
tests='''
    // BEGIN exact-state observation tests
    #[test]
    fn exact_state_ignores_order_and_keys_but_retains_multiplicity() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let before = sheets[1].layout();
        let mut after = JLayout::new(before.container().clone());
        let parts: Vec<_> = before.placed_items().values().collect();
        let dummy = after.place_item(parts[0].item(), parts[0].d_transf());
        after.remove_item(dummy);
        for p in parts.iter().rev() { after.place_item(p.item(), p.d_transf()); }
        assert!(exact_physical_state(before, &JLayout::from_snapshot(&before.save())));
        assert!(exact_physical_state(before, &after));
        assert_ne!(before.placed_items().keys().collect::<Vec<_>>(), after.placed_items().keys().collect::<Vec<_>>());
        let key = after.place_item(parts[0].item(), parts[0].d_transf());
        assert!(!exact_physical_state(before, &after));
        after.remove_item(key);
        let key = after.placed_items().keys().next().unwrap();
        after.remove_item(key);
        assert!(!exact_physical_state(before, &after));
    }

    #[test]
    fn exact_state_rejects_one_ulp_rotation_reflection_and_changed_distribution() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let before = sheets[1].layout();
        let (key, p) = before.placed_items().iter().find(|(_,p)|p.item().area()==1350.0).unwrap();
        let pose = p.d_transf(); let (x,y) = pose.translation();
        for changed in [
            DTransformation::new(pose.rotation(), (f32::from_bits(x.to_bits()+1),y)).with_reflection(pose.reflected),
            DTransformation::new(pose.rotation(), (x,f32::from_bits(y.to_bits()+1))).with_reflection(pose.reflected),
            DTransformation::new(pose.rotation()+0.01, (x,y)).with_reflection(pose.reflected),
            DTransformation::new(pose.rotation(), (x,y)).with_reflection(!pose.reflected),
        ] {
            let mut after=JLayout::from_snapshot(&before.save());
            after.remove_item(key);after.place_item(p.item(),changed);
            assert!(!exact_physical_state(before,&after));
        }
        let mut after=JLayout::from_snapshot(&before.save());
        let same: Vec<_> = before.placed_items().iter().filter(|(_,q)|std::sync::Arc::ptr_eq(p.item(),q.item())).collect();
        assert_eq!(same.len(),2);
        after.remove_item(same[1].0);after.place_item(p.item(),pose);
        assert_eq!(before.placed_items().len(),after.placed_items().len());
        assert!(!exact_physical_state(before,&after));
    }

    #[test]
    fn exact_state_rejects_different_original_item_model_and_container() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap(); let sheets=model.sheets_of(&layout).unwrap();
        let other_model=Model::new(&job).unwrap(); let other_sheets=other_model.sheets_of(&layout).unwrap();
        let before=sheets[1].layout();
        let (key,p)=before.placed_items().iter().next().unwrap();
        let other=other_sheets[1].layout().placed_items().values().find(|q|q.item().idx()==p.item().idx()).unwrap();
        let mut after=JLayout::from_snapshot(&before.save());
        after.remove_item(key); after.place_item(other.item(),p.d_transf());
        assert!(!exact_physical_state(before,&after));
        let different=sheets[0].layout().placed_items().values().find(|q|q.item().idx()!=p.item().idx()).unwrap();
        let mut after=JLayout::from_snapshot(&before.save());
        after.remove_item(key);after.place_item(different.item(),p.d_transf());
        assert!(!exact_physical_state(before,&after));
        let mut after=JLayout::new(other_sheets[1].layout().container().clone());
        for q in before.placed_items().values(){after.place_item(q.item(),q.d_transf());}
        assert!(!exact_physical_state(before,&after));
    }
    // END exact-state observation tests
'''
replace('    fn rectangle(id: &str, width: f64, height: f64) -> Part {',tests+'\n    fn rectangle(id: &str, width: f64, height: f64) -> Part {')
reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n')
(out/'changes.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='prior/'+rel,tofile='observed/'+rel)),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
files=[{'path':p.relative_to(old).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(old.rglob('*')) if p.is_file()]
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_source':str(old),'changed_file':rel,'changed_files':[rel],
    'source_files':files,'production_digest':source_digest(),'target':str(root/'output/h5-exact-state-target-20261018'),
    'reversible_to_exact_parent':True,'original_tests':113,'added_tests':3,'decisions_unchanged':True,
    'measurement_planned':{'jobs':['m-mechanical-panel-hardware'],'kerfs':[.2,1.5],'seed':0,'seconds':60,'cpu':8,'serial':True}}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_larger_stage_v2.py').read_text(encoding='utf-8').replace('h5-larger-stage','h5-exact-state')
builder=builder.replace("assert (OUT/'exchange-before-format.rs').exists()", "assert not TARGET.exists()")
builder=builder.replace('-v2.log','.log').replace('opened-v2','opened').replace('progress-v2','progress').replace('failure-v2','failure')
(root/'output/build_h5_exact_state.py').write_text(builder,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'exact_parent_reversal':True,'changed_files':1,'unchanged_files':len(files)-1,'tests_expected':116}))
