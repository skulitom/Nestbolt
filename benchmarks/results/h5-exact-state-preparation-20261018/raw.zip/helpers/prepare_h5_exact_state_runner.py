"""Keep the qualified diagnostic method; add exact-state schema checks."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];out=root/'output/h5-exact-state-20261018'
original=(root/'scripts/h5_larger_stage.py').read_text(encoding='utf-8')
text=original.replace('h5-larger-stage','h5-exact-state').replace('h5_larger_stage','h5_exact_state')
text=text.replace('Four diagnostic-only searches: both mechanical development jobs, both kerfs,','Two diagnostic-only searches: panel hardware, both kerfs,')
text=text.replace("JOBS = ['m-mechanical-large-plates', 'm-mechanical-panel-hardware']","JOBS = ['m-mechanical-panel-hardware']")
text=text.replace("'attempts':4", "'attempts':2").replace('len(records)==4','len(records)==2')
text=text.replace('import math\n','import math\nimport struct\n')
text=text.replace('Every inserted observation reverses exactly; no decision or work charge changes.',
    'Also compare complete internal pose multisets using exact float bits and shared original item/container identity, and retain both public layouts for each neutral rejection. Every inserted observation reverses exactly; no decision or work charge changes.')
needle='def check_traces(traces, stats=None):'
helper='''def public_signature(layout):
    assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
    result=Counter()
    for p in layout['placements']:
        t=p['transform'];values=[t['rotation_radians'],*t['translation']]
        assert len(values)==3 and all(type(v) in [int,float] and math.isfinite(v) for v in values)
        assert type(t['mirrored']) is bool
        result[(p['sheet_id'],p['part_id'],*(struct.pack('!d',float(v)) for v in values),t['mirrored'])]+=1
    return result


'''
assert text.count(needle)==1;text=text.replace(needle,helper+needle)
needle="            outcome=a['outcome']";assert text.count(needle)==1
text=text.replace(needle,'''            value=a['identity_elapsed']
            assert value is None or (type(value) in [int,float] and math.isfinite(value) and value>=0)
            assert (value is None)==(a['after_last_extent'] is None)
            if value is None:assert a['exact_state'] is None
            else:assert type(a['exact_state']) is bool
            views=a['neutral_layouts']
            if a['outcome']=='neutral_inventory_rejected':
                assert type(views) is dict and set(views)=={'incumbent','trial'}
                assert views['incumbent']['sheets']==views['trial']['sheets']
                left=public_signature(views['incumbent']);right=public_signature(views['trial'])
                assert Counter(p['part_id'] for p in views['incumbent']['placements'])==Counter(p['part_id'] for p in views['trial']['placements'])
                if a['exact_state']:assert left==right
            else:assert views is None
'''+needle)
path=root/'scripts/h5_exact_state.py';assert not path.exists();path.write_text(text,encoding='utf-8',newline='\n');compile(text,str(path),'exec')
functions=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
assert functions(original.replace('len(records)==4','len(records)==2'))['run']==functions(text)['run']
method={'measurement_function_AST_exact_except_expected_count':True,'prior_expected_count':4,'current_expected_count':2,
    'original_runner_sha256':sha256(original.encode()).hexdigest(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),'quality_or_scoring_change':False}
(out/'runner-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
check=(root/'output/check_h5_larger_stage_reader.py').read_text(encoding='utf-8').replace('h5-larger-stage','h5-exact-state').replace('h5_larger_stage','h5_exact_state')
needle="record={'all_checks_pass':True";assert check.count(needle)==1
extra='''rejected += [
    rejects('negative identity time',lambda t:modify_attempt(t,identity_elapsed=-1)),
    rejects('nonboolean exact-state observation',lambda t:modify_attempt(t,exact_state=1)),
    rejects('missing exact-state observation',lambda t:modify_attempt(t,exact_state=None)),
    rejects('missing identity duration',lambda t:modify_attempt(t,identity_elapsed=None)),
]
neutral_attempt=next(a for a in neutral_trace['attempts'] if a['outcome']=='neutral_inventory_rejected')
def neutral_mutation(t,fn):
    fn(next(a for a in t['attempts'] if a['outcome']=='neutral_inventory_rejected'))
rejected.append(rejects_trace('missing neutral layout pair',lambda t:neutral_mutation(t,lambda a:a.update(neutral_layouts=None))))
synthetic=copy.deepcopy(neutral_trace)
a=next(a for a in synthetic['attempts'] if a['outcome']=='neutral_inventory_rejected')
a['exact_state']=True;a['neutral_layouts']['trial']=copy.deepcopy(a['neutral_layouts']['incumbent'])
runner.check_traces([synthetic])
a['neutral_layouts']['trial']['placements'][0]['transform']['translation'][0]+=0.001
try:runner.check_traces([synthetic])
except AssertionError:rejected.append('exact-state flag contradicts saved public poses')
else:raise AssertionError('Reader accepted contradictory exact-state flag')
'''
check=check.replace(needle,extra+needle)
check=check.replace("'quality_claim':False}","'quality_claim':False,'synthetic_exact_state_reader_check':True,'actual_exact_state_true':sum(a.get('exact_state') is True for a in summary['attempt_rows'])}")
path=root/'output/check_h5_exact_state_reader.py';path.write_text(check,encoding='utf-8',newline='\n');compile(check,str(path),'exec')
print(json.dumps(method))
