from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_component_count_model_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-first55-component-count-model-20261029','h5-first55-canonical-components-model-20261029')
a=s.index('symmetry=[]\nfor family');b=s.index('count_choices=[]',a)
s=s[:a]+'symmetry=[]\n'+s[b:]
a="count_choices.append({'empty_sites':sites,'pair_selector':pair_var,'pair_and_constraints':pair_links,'distributions':distributions,'distribution_pair_constraint':dist_link,'component_counts':group_constraints})"
b='''owner_groups=[]
    peers={family:sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1]) for family in ['bracket','insert']}
    for distribution in distributions:
        assigned=[None]*len(owners)
        for family in ['bracket','insert']:
            blocks=[]
            for gi,group in enumerate(row['groups']):
                if group['family']==family:blocks.extend([gi]*distribution['counts'][gi])
            assert len(blocks)==len(peers[family])
            for owner,gi in zip(peers[family],blocks):assigned[owner['owner']]=gi
        assert all(v is not None for v in assigned)
        distribution['canonical_owner_groups']=assigned;distribution['within_component_order']=[]
        for family in ['bracket','insert']:
            for left,right in zip(peers[family],peers[family][1:]):
                ai,bi=left['owner'],right['owner']
                if assigned[ai]!=assigned[bi]:continue
                ymin=min(m['integer_lower_left_bounds'][1][0] for o in [left,right] for m in o['modes']);ymax=max(m['integer_lower_left_bounds'][1][1] for o in [left,right] for m in o['modes']);scale=ymax-ymin+1
                coefficient={left['positions'][0]:scale,right['positions'][0]:-scale,left['positions'][1]:1,right['positions'][1]:-1}
                ct=linear(coefficient,cp_model.INT_MIN,0,distribution['selector'])
                distribution['within_component_order'].append({'family':family,'owners':[ai,bi],'group':assigned[ai],'x_scale':scale,'constraint':ct})
    for owner in owners:
        family=owner['identity'][0];coefficients={};members=[]
        for region in owner['unary_regions']:
            if not set(region['required_empty_sites'])<=set(sites):continue
            gi=attribution[(family,region['geometry'],region['region'])];coefficients[region['selector']]=gi+1;members.append({'selector':region['selector'],'group':gi})
        for distribution in distributions:coefficients[distribution['selector']]=-(distribution['canonical_owner_groups'][owner['owner']]+1)
        owner_groups.append({'owner':owner['owner'],'region_groups':members,'constraint':linear(coefficients,0,0,pair_var)})
    count_choices.append({'empty_sites':sites,'pair_selector':pair_var,'pair_and_constraints':pair_links,'distributions':distributions,'distribution_pair_constraint':dist_link,'component_counts':group_constraints,'canonical_owner_component_constraints':owner_groups})'''
assert a in s;s=s.replace(a,b)
a="'same_family_order_constraints':len(symmetry),";b="'same_family_order_constraints':len(symmetry),'canonical_owner_component_equalities':sum(len(r['canonical_owner_component_constraints']) for r in count_choices),'within_component_lexicographic_order_constraints':sum(len(d['within_component_order']) for r in count_choices for d in r['distributions']),"
assert a in s;s=s.replace(a,b)
s=s.replace('Same-family X order remains.','Interchangeable copies are assigned by component first, then ordered lexicographically by X/Y within that component. The earlier unconditional X order is removed; every feasible placement has a canonical relabelling that preserves the complete moving inventory.')
p=ROOT/'output/build_h5_canonical_component_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'canonical_component_order_replaces_unconditional_x_order':True})
