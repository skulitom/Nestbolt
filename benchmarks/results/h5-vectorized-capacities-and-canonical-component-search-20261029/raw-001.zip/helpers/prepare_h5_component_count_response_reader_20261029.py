from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_local_grid_response_20261029.py').read_text(encoding='utf-8')
changes=[
("BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';MODEL=", "BASE=ROOT/'output/h5-first55-component-count-model-20261029';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';MODEL="),
("BASE/'plan.json'","GEO/'plan.json'"),
('len(model.variables)==8336 and len(model.constraints)==43571','len(model.variables)==8497 and len(model.constraints)==43817'),
("result['returned_response_branches']==33140","result['returned_response_branches']==92981"),
("result['returned_response_conflicts']==770","result['returned_response_conflicts']==22162"),
("'max_lp':          0            9       0         0  12'829           0","'max_lp':          0            1       1         0  8'537           0"),
("'default_lp':          0            0       0         0      19           0","'default_lp':          0            0       3         0    331           0"),
("'max_lp_cut_equal_propagations':9,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':12829,'default_lp_bad_statistic':19", "'max_lp_cut_equal_propagations':1,'max_lp_adjust_statistic':1,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':8537,'default_lp_adjust_statistic':3,'default_lp_bad_statistic':331")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/audit_h5_component_count_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'internal_solve_slice_overrun_preserved':True})
