from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_component_count_model_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-first55-component-count-model-20261029','h5-first55-canonical-components-model-20261029').replace('43817','45359')
a=s.index("expected=[]\nfor family in ['bracket','insert']:");b=s.index('source_choices=',a)
s=s[:a]+"assert mapping['symmetry_constraints']==[]\n"+s[b:]
block='''canonical_equalities=lexicographic_constraints=0
for owner in owners:
    peers=[o for o in owners if o['identity'][0]==owner['identity'][0]]
    for peer in peers:
        assert [list(p.variables[v].domain) for v in owner['positions']]==[list(p.variables[v].domain) for v in peer['positions']]
        assert [(r['geometry'],r['region'],r['required_empty_sites']) for r in owner['unary_regions']]==[(r['geometry'],r['region'],r['required_empty_sites']) for r in peer['unary_regions']]
        assert [{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in owner['modes']]==[{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in peer['modes']]
expected_rect_pairs=[list(pair) for pair in combinations(range(len(components)),2) if components[pair[0]]['owner']!=components[pair[1]]['owner']]
assert [r['components'] for r in separations]==expected_rect_pairs
for actual,source in zip(choices,source_choices):
    peers={f:sorted((o for o in owners if o['identity'][0]==f),key=lambda o:o['identity'][1]) for f in ['bracket','insert']}
    for distribution in actual['distributions']:
        assigned=[None]*len(owners)
        for family,family_owners in peers.items():
            cursor=0
            for gi,g in enumerate(source['groups']):
                if g['family']!=family:continue
                count=distribution['counts'][gi]
                for rank in range(cursor,cursor+count):assigned[family_owners[rank]['owner']]=gi
                cursor+=count
            assert cursor==len(family_owners)
        assert distribution['canonical_owner_groups']==assigned and all(v is not None for v in assigned)
        expected_order=[]
        for family,family_owners in peers.items():
            for a,b in zip(family_owners,family_owners[1:]):
                if assigned[a['owner']]==assigned[b['owner']]:expected_order.append((family,a,b,assigned[a['owner']]))
        assert len(distribution['within_component_order'])==len(expected_order)
        for record,(family,a,b,group) in zip(distribution['within_component_order'],expected_order):
            ymin=min(list(p.variables[o['positions'][1]].domain)[0] for o in [a,b]);ymax=max(list(p.variables[o['positions'][1]].domain)[1] for o in [a,b]);scale=ymax-ymin+1
            assert record['family']==family and record['owners']==[a['owner'],b['owner']] and record['group']==group and record['x_scale']==scale and scale>ymax-ymin
            linear(record['constraint'],{a['positions'][0]:scale,b['positions'][0]:-scale,a['positions'][1]:1,b['positions'][1]:-1},MIN,0,distribution['selector']);lexicographic_constraints+=1
    lookup={}
    for family,mode,gid,ri,ci in source['region_component_assignments']:
        key=(family,gid,ri)
        if key in lookup:assert lookup[key]==ci
        lookup[key]=ci
    assert len(actual['canonical_owner_component_constraints'])==len(owners)
    for record,owner in zip(actual['canonical_owner_component_constraints'],owners):
        expected=[];co={};family=owner['identity'][0]
        for r in owner['unary_regions']:
            if set(r['required_empty_sites'])-set(source['empty_sites']):continue
            group=lookup[(family,r['geometry'],r['region'])];expected.append({'selector':r['selector'],'group':group});co[r['selector']]=group+1
        for distribution in actual['distributions']:co[distribution['selector']]=-(distribution['canonical_owner_groups'][owner['owner']]+1)
        assert record['owner']==owner['owner'] and record['region_groups']==expected
        linear(record['constraint'],co,0,0,actual['pair_selector']);canonical_equalities+=1
assert canonical_equalities==377 and lexicographic_constraints==1176
'''
a='expected_charges=load(';assert a in s;s=s.replace(a,block+a)
s=s.replace("'same_family_order_constraints_verified':11", "'same_family_order_constraints_verified':0,'canonical_owner_component_equalities_verified':377,'within_component_lexicographic_order_constraints_verified':1176,'same_family_owner_domains_and_geometry_identical':True,'all_different_owner_rectangle_pairs_present':True,'canonical_relabelling_preserves_every_feasible_placement':True")
p=ROOT/'output/audit_h5_canonical_component_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'permutation_invariance_and_all_new_constraints_checked':True})
