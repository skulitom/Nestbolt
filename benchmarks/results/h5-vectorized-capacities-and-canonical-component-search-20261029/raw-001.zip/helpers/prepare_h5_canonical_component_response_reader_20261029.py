from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_component_count_response_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-component-count-model-20261029','h5-first55-canonical-components-model-20261029'),('len(model.constraints)==43817','len(model.constraints)==45359'),("result['returned_response_branches']==92981","result['returned_response_branches']==80460"),("result['returned_response_conflicts']==22162","result['returned_response_conflicts']==19006"),("'max_lp':          0            1       1         0  8'537           0","'max_lp':          1            0       0         0  9'931           0"),("'default_lp':          0            0       3         0    331           0","'default_lp':          0            0       0         0    128           0"),("'max_lp_cut_equal_propagations':1,'max_lp_adjust_statistic':1,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':8537,'default_lp_adjust_statistic':3,'default_lp_bad_statistic':331","'max_lp_cut_propagations':1,'max_lp_cut_equal_propagations':0,'max_lp_adjust_statistic':0,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':9931,'default_lp_adjust_statistic':0,'default_lp_bad_statistic':128")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/audit_h5_canonical_component_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'closed_call_overrun_preserved':True})
