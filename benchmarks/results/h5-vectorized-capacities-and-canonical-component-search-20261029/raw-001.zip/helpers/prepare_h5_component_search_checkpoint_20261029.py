from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/seal_h5_finite_pose_checkpoint_20261029.py').read_text(encoding='utf-8')
archive=old[old.index('OUT.mkdir();members='):old.index('copies=[]')]
archive=archive.replace('for folder in [CENTROID,BOUNDARY,FAST,BASE,DIAGONAL,SYNC]:','for folder in [FAST,COUNT,BASE,SYNC]:')
a=archive.index('helpers=set()');b=archive.index('while queue:')
archive=archive[:a]+'''helpers=set()
for pattern in ['*h5_vectorized*20261029.py','*h5_component_count*20261029.py','*h5_canonical_component*20261029.py','*h5_component_search*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','push_h5_joint_capacity_checkpoint_20261029.py','build_h5_local_grid_model_20261029.py','audit_h5_local_grid_model_20261029.py','run_h5_local_grid_model_20261029.py','check_h5_local_grid_candidate_20261029.py','audit_h5_local_grid_response_20261029.py','bound_h5_joint_component_capacity_20261029.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
'''+archive[b:]
header='''"""Seal generic vectorized preparation and two source placement models with closed responses."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
FAST=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';COUNT=ROOT/'output/h5-first55-component-count-model-20261029';BASE=ROOT/'output/h5-first55-canonical-components-model-20261029';SYNC=ROOT/'output/h5-joint-capacity-main-sync-20261029';PUB=BASE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-vectorized-capacities-and-canonical-component-search-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write(v)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='bd68c96727069582227ce5826453724ccc719bb4' and not git('diff','HEAD','--name-only')
fast=load(FAST/'audit/checks.json');assert fast['passed'] and fast['exact_certificates_identical_to_independently_verified_witnesses']==39 and fast['remaining_count_distributions']==132 and fast['all_retained_count_sets_identical']
responses=[]
for folder,cts in [(COUNT,43817),(BASE,45359)]:
    model=load(folder/'model-audit/checks.json');assert model['passed'] and model['all_model_fields_exhaustively_verified'] and model['variables_verified']==8497 and model['constraints_verified']==cts
    r=load(folder/'response-audit/checks.json');responses.append(r);assert r['passed'] and r['solver_status']=='UNKNOWN' and r['closed_solver_calls']==1 and r['assignments']==0 and r['source_checker_calls']==r['native_calls']==0 and r['solve_slice_overrun_seconds']>0 and r['overall_algorithm_shared_overruns_seconds']==0 and not r['infeasibility_proven'] and not r['any_allocation_excluded']
assert load(BASE/'model-audit/checks.json')['canonical_relabelling_preserves_every_feasible_placement']
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-joint-component-count-capacities-20261029/publication-review.json');production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert load(PUB/'main.json')['commit']['sha']==ci['head_sha']==head and ci['id']==40836007698
assert len(jobs)==6 and sum(j['conclusion']=='success' for j in jobs)==5 and [(j['name'],j['status']) for j in jobs if j['conclusion']!='success']==[('checks (windows-latest)','in_progress')]
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
'''
footer='''copies=[(FAST/'checks.json','vectorized-preparation.json'),(FAST/'audit/checks.json','vectorized-equivalence-audit.json')]
for prefix,folder in [('count',COUNT),('canonical',BASE)]:copies.extend([(folder/'model/checks.json',prefix+'-model.json'),(folder/'model-audit/checks.json',prefix+'-model-audit.json'),(folder/'model/preparation-charges.json',prefix+'-preparation-charges.json'),(folder/'response-audit/checks.json',prefix+'-response-audit.json'),(folder/'response-audit/lp-diagnostics.txt',prefix+'-lp-diagnostics.txt')])
copies.extend([(BASE/'next-step.json','next-step.json'),(SYNC/'receipt.json','prior-main-push-receipt.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')])
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40836007698,'main_all6_pass':False,'successful_jobs_at_snapshot':5,'pending_job':'checks (windows-latest)','normal_push_requires_all6_and_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'generic_preparation_seconds':fast['generic_preparation_seconds'],'exact_count_certificates_preserved':39,'remaining_count_distributions':132,'all_source_mode_aliases_agree_on_component':True,'conditional_count_model_audited':True,'canonical_component_model_audited':True,'canonical_relabelling_preserves_every_feasible_placement':True,'closed_new_solver_calls':2,'solver_statuses':['UNKNOWN','UNKNOWN'],'assignments':0,'solve_slice_overruns_seconds':[r['solve_slice_overrun_seconds'] for r in responses],'overall_algorithm_shared_overruns_seconds':0,'source_checker_calls':0,'native_calls':0,'infeasibility_proven':False,'new_restricted_site_exclusions':0,'restricted_site_pairs_remaining':29,'new_allocation_exclusions':0,'remaining_candidates':440,'source_valid_short11_preserved':True,'valid64_preserved':True,'source_valid66_created':False,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [joint component count capacities](../benchmarks/results/h5-joint-component-count-capacities-20261029.md).';new=f'Latest H5 evidence: [vectorized capacities and canonical component search](../benchmarks/results/{NAME}.md).';assert s.count(old)==1
with status.open('w',encoding='utf-8',newline='\\n') as f:f.write(s.replace(old,new,1))
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'closed_calls':2,'source_valid66':False,'remaining_count_distributions':132,'restricted_site_pairs_remaining':29,'remaining_allocations':440,'completion_percent':60})
'''
s=header+archive+footer;p=ROOT/'output/seal_h5_component_search_checkpoint_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
v=(ROOT/'output/verify_h5_local_grid_archive_20261029.py').read_text(encoding='utf-8').replace('h5-local-grid-construction-and-component-halfspaces-20261029','h5-vectorized-capacities-and-canonical-component-search-20261029')
with (ROOT/'output/verify_h5_component_search_archive_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(v)
print({'prepared':p.name})
