from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/check_h5_local_grid_candidate_20261029.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';SEARCH=", "BASE=ROOT/'output/h5-first55-component-count-model-20261029';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';SEARCH=")
s=s.replace("BASE/'inventory.json'","GEO/'inventory.json'")
p=ROOT/'output/check_h5_component_count_candidate_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_local_grid_model_20261029.py').read_text(encoding='utf-8')
changes=[("BASE = ROOT / 'output/h5-first55-local-grid-regions-20261029'", "BASE = ROOT / 'output/h5-first55-component-count-model-20261029'\nGEO = ROOT / 'output/h5-first55-local-grid-regions-20261029'"),("for folder in [BASE, MODEL, BASE / 'model-audit', BASE / 'geometry-audit']:","for folder in [GEO, MODEL, BASE / 'model-audit', GEO / 'geometry-audit']:"),('check_h5_local_grid_candidate_20261029.py','check_h5_component_count_candidate_20261029.py'),("BASE / 'plan.json'","GEO / 'plan.json'"),("BASE / 'inventory.json'","GEO / 'inventory.json'"),("BASE / 'geometry-audit/plan.json'","GEO / 'geometry-audit/plan.json'"),("BASE / 'geometry-audit/checks.json'","GEO / 'geometry-audit/checks.json'")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
s=s.replace('on a micrometre grid','with source-hull positions and audited component counts')
p=ROOT/'output/run_h5_component_count_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'full66_original_source_checker_prepared':True,'maximum_new_calls':1})
