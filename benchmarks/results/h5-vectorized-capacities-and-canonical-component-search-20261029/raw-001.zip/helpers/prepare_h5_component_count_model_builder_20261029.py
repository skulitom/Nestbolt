from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_local_grid_model_20261029.py').read_text(encoding='utf-8')
changes=[
("OUT=BASE/'model';PRIOR=", "TARGET=ROOT/'output/h5-first55-component-count-model-20261029';COUNT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';AXIS=BASE/'component-halfspace-bound';OUT=TARGET/'model';PRIOR="),
("assert load(BASE/'geometry-audit/checks.json')['passed']", "assert load(BASE/'geometry-audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['passed']\nassert load(COUNT/'audit/checks.json')['all_source_mode_aliases_agree_on_component']\nTARGET.mkdir()"),
("allowed=load(BASE/'allowed-empty-site-pairs.json')", "allowed=load(COUNT/'audit/allowed-empty-site-pairs.json')"),
('assert len(forbidden)==70','assert len(forbidden)==76'),
("'forbidden_site_pairs':forbidden}","'forbidden_site_pairs':forbidden,'component_count_choices':count_choices,'one_site_pair_choice_constraint':one_pair_choice,'one_count_distribution_constraint':one_distribution}"),
("'cp_model_build_seconds':elapsed}","'component_axis_capacity_bound_seconds':load(AXIS/'checks.json')['seconds'],'generic_component_count_preparation_seconds':load(COUNT/'checks.json')['seconds'],'cp_model_build_seconds':elapsed}"),
("inputs=[Path(__file__),", "inputs=[Path(__file__),COUNT/'plan.json',COUNT/'checks.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all29-vectorized-bounds.json',COUNT/'audit/allowed-empty-site-pairs.json',AXIS/'plan.json',AXIS/'checks.json',"),
('and35 audited surviving empty-site pairs','and29 audited surviving empty-site pairs, with all132 independently verified component-count distributions'),
("'retained_empty_site_pairs':35,'forbidden_site_pair_constraints':70", "'retained_empty_site_pairs':29,'forbidden_site_pair_constraints':76,'component_pair_selectors':len(count_choices),'component_distribution_selectors':len(all_distributions),'conditional_component_count_equalities':sum(len(r['component_counts']) for r in count_choices)")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
block='''count_choices=[];all_distributions=[]
for pair_index,row in enumerate(load(COUNT/'all29-vectorized-bounds.json')):
    sites=row['empty_sites'];a,b=sites;pair_var=model.new_bool_var(f'component_site_pair_{a}_{b}').index
    pair_links=[linear({pair_var:1,empty[a]:-1},cp_model.INT_MIN,0),linear({pair_var:1,empty[b]:-1},cp_model.INT_MIN,0),linear({pair_var:1,empty[a]:-1,empty[b]:-1},-1,cp_model.INT_MAX)]
    distributions=[]
    for di,counts in enumerate(row['remaining_distributions']):
        var=model.new_bool_var(f'component_distribution_{pair_index}_{di}').index;distributions.append({'counts':counts,'selector':var});all_distributions.append(var)
    dist_link=linear({**{r['selector']:1 for r in distributions},pair_var:-1},0,0)
    attribution={}
    for family,mode,gid,region,group in row['region_component_assignments']:
        key=(family,gid,region)
        if key in attribution:assert attribution[key]==group
        attribution[key]=group
    observed=set();group_vars=[[] for _ in row['groups']]
    for owner in owners:
        family=owner['identity'][0]
        for region in owner['unary_regions']:
            if not set(region['required_empty_sites'])<=set(sites):continue
            key=(family,region['geometry'],region['region']);assert key in attribution;observed.add(key);group_vars[attribution[key]].append(region['selector'])
    assert observed==set(attribution)
    group_constraints=[]
    for gi,(group,selectors) in enumerate(zip(row['groups'],group_vars)):
        assert selectors
        co={var:1 for var in selectors}
        co.update({r['selector']:-r['counts'][gi] for r in distributions if r['counts'][gi]})
        group_constraints.append({'group':gi,'family':group['family'],'region_selectors':selectors,'constraint':linear(co,0,0,pair_var)})
    count_choices.append({'empty_sites':sites,'pair_selector':pair_var,'pair_and_constraints':pair_links,'distributions':distributions,'distribution_pair_constraint':dist_link,'component_counts':group_constraints})
one_pair_choice=linear({r['pair_selector']:1 for r in count_choices},1,1)
one_distribution=linear({v:1 for v in all_distributions},1,1)
'''
a='validation=model.validate();';assert a in s;s=s.replace(a,block+a)
p=ROOT/'output/build_h5_component_count_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'all_sources_and_132_count_distributions_retained':True})
