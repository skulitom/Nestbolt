from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_local_grid_model_20261029.py').read_text(encoding='utf-8')
changes=[
("MODEL=BASE/'model';OUT=BASE/'model-audit';RID=BASE", "TARGET=ROOT/'output/h5-first55-component-count-model-20261029';COUNT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';MODEL=TARGET/'model';OUT=TARGET/'model-audit';RID=BASE"),
('len(p.variables)==8336 and len(p.constraints)==43571','len(p.variables)==8497 and len(p.constraints)==43817'),
("allowed=load(BASE/'allowed-empty-site-pairs.json')","allowed=load(COUNT/'audit/allowed-empty-site-pairs.json')"),
('len(allowed)==35 and len(expected_forbidden)==70','len(allowed)==29 and len(expected_forbidden)==76'),
('used_vars==set(range(8336)) and used_ct==set(range(43571))','used_vars==set(range(8497)) and used_ct==set(range(43817))'),
("inputs=[Path(__file__),","inputs=[Path(__file__),COUNT/'plan.json',COUNT/'checks.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all29-vectorized-bounds.json',COUNT/'audit/allowed-empty-site-pairs.json',BASE/'model/preparation-charges.json',BASE/'component-halfspace-bound/checks.json',"),
("'all35_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':70", "'all29_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':76,'component_pair_selectors_verified':29,'count_distribution_selectors_verified':132,'conditional_component_equalities_verified':122,'all_source_mode_aliases_agree_on_component':True,'recursive_bindings':len(bindings)")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
prefix='''assert load(COUNT/'audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['all_source_mode_aliases_agree_on_component']
queue=[MODEL/'plan.json',COUNT/'audit/plan.json',BASE/'geometry-audit/plan.json'];seen=set();bindings={}
while queue:
    source=queue.pop()
    if source in seen:continue
    seen.add(source)
    for name,h in load(source).get('inputs',{}).items():
        path=ROOT/name;assert path.is_relative_to(ROOT) and not {'.claude','.cache'}&set(path.parts) and digest(path)==h,name;bindings[name]=h
        if path.name in ['plan.json','opened.json']:queue.append(path)
'''
a='p=cp_model_pb2.CpModelProto();';assert a in s;s=s.replace(a,prefix+a)
block='''source_choices=load(COUNT/'all29-vectorized-bounds.json');choices=mapping['component_count_choices'];assert len(choices)==len(source_choices)==29
all_d=[];all_p=[];component_equalities=0
for pair_index,(actual,source) in enumerate(zip(choices,source_choices)):
    sites=source['empty_sites'];a,b=sites;assert actual['empty_sites']==sites
    pv=actual['pair_selector'];all_p.append(pv);variable(pv,f'component_site_pair_{a}_{b}',[0,1]);assert len(actual['pair_and_constraints'])==3
    linear(actual['pair_and_constraints'][0],{pv:1,empty[a]:-1},MIN,0)
    linear(actual['pair_and_constraints'][1],{pv:1,empty[b]:-1},MIN,0)
    linear(actual['pair_and_constraints'][2],{pv:1,empty[a]:-1,empty[b]:-1},-1,2**63-1)
    assert [r['counts'] for r in actual['distributions']]==source['remaining_distributions']
    for di,distribution in enumerate(actual['distributions']):
        var=distribution['selector'];variable(var,f'component_distribution_{pair_index}_{di}',[0,1]);all_d.append(var)
    linear(actual['distribution_pair_constraint'],{**{r['selector']:1 for r in actual['distributions']},pv:-1},0,0)
    lookup={}
    for family,mode,gid,ri,ci in source['region_component_assignments']:lookup.setdefault((family,gid,ri),set()).add(ci)
    assert all(len(v)==1 for v in lookup.values());expected=[[] for _ in source['groups']];observed=set()
    for owner in owners:
        family=owner['identity'][0]
        for region in owner['unary_regions']:
            if set(region['required_empty_sites'])-set(sites):continue
            key=(family,region['geometry'],region['region']);assert key in lookup;ci=next(iter(lookup[key]));expected[ci].append(region['selector']);observed.add(key)
    assert observed==set(lookup) and len(actual['component_counts'])==len(source['groups'])
    for ci,(record,group,selectors) in enumerate(zip(actual['component_counts'],source['groups'],expected)):
        assert record['group']==ci and record['family']==group['family'] and record['region_selectors']==selectors and selectors
        co={v:1 for v in selectors}
        for distribution in actual['distributions']:
            count=distribution['counts'][ci]
            if count:co[distribution['selector']]=-count
        linear(record['constraint'],co,0,0,pv);component_equalities+=1
assert len(all_p)==29 and len(all_d)==132 and component_equalities==122
linear(mapping['one_site_pair_choice_constraint'],{v:1 for v in all_p},1,1)
linear(mapping['one_count_distribution_constraint'],{v:1 for v in all_d},1,1)
expected_charges=load(BASE/'model/preparation-charges.json');expected_charges['cp_model_build_seconds']=load(MODEL/'checks.json')['seconds'];expected_charges['component_axis_capacity_bound_seconds']=load(BASE/'component-halfspace-bound/checks.json')['seconds'];expected_charges['generic_component_count_preparation_seconds']=load(COUNT/'checks.json')['seconds']
assert load(MODEL/'preparation-charges.json')==expected_charges
write(OUT/'source-bindings.json',bindings)
'''
a='assert used_vars==set(range(8497))';assert a in s;s=s.replace(a,block+a)
p=ROOT/'output/audit_h5_component_count_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'every_protobuf_field_and_new_count_constraint_checked':True})
