"""Exact all-angle subset, rounding, stock and forbidden-rectangle audit."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import Polygon,box,Point,shape
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rotation-independent-geometry-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(poly):return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if len(poly)>2 else F(0)
def edge_distance2(a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];n=dx*dx+dy*dy;t=-(a[0]*dx+a[1]*dy)
    if t<=0:return a[0]**2+a[1]**2
    if t>=n:return b[0]**2+b[1]**2
    return (a[0]*b[1]-a[1]*b[0])**2/n
def clip(poly,a,b,inside):
    out=[]
    for u,v in zip(poly,poly[1:]+poly[:1]):
        fu,fv=cross(a,b,u),cross(a,b,v);inu=fu>=0 if inside else fu<=0;inv=fv>=0 if inside else fv<=0
        if inu:out.append(u)
        if inu!=inv:
            t=fu/(fu-fv);out.append((u[0]+t*(v[0]-u[0]),u[1]+t*(v[1]-u[1])))
    return out
def subtract_convex(poly,hull):
    inside=poly;outside=[]
    for a,b in zip(hull,hull[1:]+hull[:1]):
        if not inside:break
        removed=clip(inside,a,b,False)
        if area(removed)>0:outside.append(removed)
        inside=clip(inside,a,b,True)
    return outside
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240;write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'audit_limit_seconds':240,'method':'Reconstruct original centered80-vertex cog and exact point-segment distances independently using projection/cross-product formulas. Check origin winding and hull halfplanes, every inner polygon vertex norm, rotation-invariant disk reasoning, continuous floor-rounding slack and independently rounded stock domains. Reconstruct original bracket/insert transforms and every2micrometre inset. For each Minkowski hull, prove convexity, all generated sums contained and every hull vertex among sums. Prove each entire central forbidden rectangle with0.1micrometre expansion is covered by the hull union using exact rational polygon subtraction. This coverage is stronger than numeric sample or boundary checks. No solver or native-layout inference.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
spec=load(BASE/'plan.json');proof=load(BASE/'original-cog-proof.json');originals=load(SOURCE/'profiles.json');job=load(JOB);families={p['id']:p for p in job['parts']};cog=families['cog'];center=originals[9]['original_center'];pts=[(F(x)-F(center[0]),F(y)-F(center[1])) for x,y in cog['geometry'][0]['outer']]
assert proof['center']==center and proof['centered_vertices_rational']==[[ratio(x),ratio(y)] for x,y in pts] and len(pts)==80 and cog['rotations']['kind']=='free' and Polygon([(float(x),float(y)) for x,y in pts]).is_valid
winding=0
for a,b in zip(pts,pts[1:]+pts[:1]):
    if a[1]<=0<b[1] and cross(a,b,(0,0))>0:winding+=1
    if b[1]<=0<a[1] and cross(a,b,(0,0))<0:winding-=1
assert abs(winding)==1
distances=[edge_distance2(a,b) for a,b in zip(pts,pts[1:]+pts[:1])];assert [ratio(v) for v in distances]==proof['edge_distance_squared_mm2'];r2=min(distances);r0=proof['original_inscribed_radius_units1000'];inner=proof['quantization_safe_radius_units1000'];assert F(r0,1000)**2<=r2<F(r0+1,1000)**2 and r0-inner==2 and (r0-inner)**2>2
hull=[tuple(F(*v) for v in xy) for xy in proof['convex_hull_vertices_rational']];h0=proof['all_angle_stock_support_radius_units1000'];hds=[]
for a,b in zip(hull,hull[1:]+hull[:1]):
    assert a in pts and b in pts and all(cross(a,b,p)>=0 for p in pts);det=cross(a,b,(0,0));assert det>0 and det*det>=F(h0,1000)**2*((b[0]-a[0])**2+(b[1]-a[1])**2);hds.append(edge_distance2(a,b))
assert [ratio(v) for v in hds]==proof['hull_edge_distance_squared_mm2'] and F(h0,1000)**2<=min(hds)<F(h0+1,1000)**2
stock=[F(*v) for v in spec['stock_bounds_rational']];relaxed=[stock[0]-F(1,50),stock[1]-F(1,50),stock[2]+F(1,50),stock[3]+F(1,50)];assert [ratio(v) for v in relaxed]==spec['relaxed_stock_bounds_rational'];bounds=load(BASE/'anchor-bounds.json');profiles=load(BASE/'profiles.json');assert [p['index'] for p in profiles]==list(range(9))+[10,11];components={};rect_count=0
for p in profiles:
    if p['family']=='cog':continue
    original=originals[p['index']];family=families[p['family']];co,si=math.cos(original['rotation_radians']),math.sin(original['rotation_radians']);mi=-1 if original['mirrored'] else 1;assert not original['mirrored'] or family['allow_mirror'];rot=affine_transform(Polygon(family['geometry'][0]['outer']),[mi*co,-si,mi*si,co,0,0]);g=affine_transform(rot,[1,0,0,1,-rot.bounds[0],-rot.bounds[1]]);assert g.hausdorff_distance(Polygon(original['vertices']))<1e-7
    original_poly=Polygon(original['vertices']);levels=[sorted({round(v[a]*1000) for v in original['vertices']}) for a in range(2)];expected=[]
    for xl,xh in zip(levels[0],levels[0][1:]):
        for yl,yh in zip(levels[1],levels[1][1:]):
            if original_poly.contains(Point((xl+xh)/2000,(yl+yh)/2000)):expected.append([xl+2,yl+2,xh-2,yh-2])
    assert expected==p['rectangles_units1000'];components[p['index']]=[]
    for b in expected:
        rect=box(*(v/1000 for v in b));assert original_poly.contains(rect) and rect.distance(original_poly.boundary)>.00199999>math.sqrt(2)/1000;components[p['index']].append([(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3])]);rect_count+=1
    ob=[F(v) for v in original['bounds']];want=[math.floor((relaxed[a]-ob[a])*1000) for a in range(2)]+[math.floor((relaxed[a+2]-ob[a+2])*1000) for a in range(2)];assert bounds[str(p['index'])]==want
cp=profiles[-1];ring=[tuple(v) for v in cp['vertices_units1000']];assert len(ring)==128 and all(x*x+y*y<=inner*inner for x,y in ring) and set(ring)=={(-x,-y) for x,y in ring};assert all(cross(a,b,c)>=0 for a,b,c in zip(ring,ring[1:]+ring[:1],ring[2:]+ring[:2]));components[11]=[ring];assert bounds['11']==[math.floor(relaxed[a]*1000+h0) for a in range(2)]+[math.floor(relaxed[a+2]*1000-h0) for a in range(2)]
details=[];generated=0
for case in load(BASE/'pair-bounds.json'):
    assert time.perf_counter()<deadline
    pa,pb=case['profiles'];assert pb==11;assert len(case['convex_hulls_units1000'])==len(components[pa]);hulls=[]
    for part,stored in zip(components[pa],case['convex_hulls_units1000']):
        sums={(a[0]-b[0],a[1]-b[1]) for a in part for b in ring};h=[tuple(v) for v in stored];assert all(v in sums for v in h) and all(cross(a,b,v)>=0 for a,b in zip(h,h[1:]+h[:1]) for v in sums);generated+=len(sums);hulls.append([(F(x),F(y)) for x,y in h])
    aa,bb=bounds[str(pa)],bounds['11'];lo,hi=bb[1]-aa[3],bb[3]-aa[1];assert [lo,hi]==case['relative_y_units1000'];L,R=case['left_maximum_dx_units1000'],case['right_minimum_dx_units1000'];eps=F(1,10);rectangle=[(L+1-eps,lo-eps),(R-1+eps,lo-eps),(R-1+eps,hi+eps),(L+1-eps,hi+eps)];remaining=[rectangle]
    for h in hulls:remaining=[q for poly in remaining for q in subtract_convex(poly,h)]
    assert not remaining,(pa,[(float(area(p))) for p in remaining]);details.append({'profiles':[pa,pb],'convex_components':len(hulls),'exact_rectangle_expansion_units1000':ratio(eps),'uncovered_area_units1000_squared':0,'passed':True})
group=load(BASE/'profile-bounds.json');gap=load(BASE/'result.json')['cog_minimum_dx_units1000'];assert gap==load(BASE/'pair-bounds.json')[-1]['right_minimum_dx_units1000'];assert len(group)==10 and all(r['common_cog_dx_units1000']==gap and r['right_minimum_dx_units1000']+gap-r['left_maximum_dx_units1000']==r['order_contradiction_margin_units1000']>0 for r in group)
write(OUT/'exact-forbidden-coverage.json',details)
write(OUT/'necessity-proof.json',{'all_real_cog_rotations':True,'all_continuous_anchors':True,'native_acceptance_claimed':False,'finite_angle_coefficients_reused':False,'statement':'The original filled cog boundary contains the centered109.115mm disk by exact edge distances and winding. Rotation about that center preserves it. Flooring both anchor coordinates moves a part by less than sqrt(2)micrometres. The109.113mm proxy disk plus that displacement stays inside the original disk; its rational128-gon is therefore an inner subset for every angle and continuous anchor. Every2micrometre-inset bracket/insert rectangle has larger boundary margin than that displacement, so the same mapping preserves subset containment. Disjoint original filled outers imply disjoint mapped proxies. The original convex hull contains a139.270mm disk, proving necessary support for every stock axis at every rotation. Outward0.020mm stock relaxation and flooring both anchor bounds cover all continuous placements contained in that relaxed stock. Exact Minkowski hull sums and rational subtraction prove every central forbidden rectangle, expanded by0.1micrometre, lies in a proxy collision union. Hence all integer points strictly between L and R collide, and the direction and monotone-order bounds are necessary. This is a rotation/position relaxation of the fixed nine-original composition, with no source clearance assumption. A positive does not establish original geometry or full-job/native acceptance.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_edges_verified':80,'convex_hull_edges_verified':len(hull),'original_inner_rectangles_verified':rect_count,'common_proxy_vertices_verified':128,'exact_minkowski_cases':len(details),'exact_generated_sum_points_checked':generated,'whole_expanded_rectangles_verified':len(details),'all_real_rotations_proved':True,'continuous_anchor_flooring_proved':True,'necessary_stock_domains_verified':True,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
