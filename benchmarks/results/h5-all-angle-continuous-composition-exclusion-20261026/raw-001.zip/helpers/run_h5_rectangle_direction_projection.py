"""One nine-original strip model:20solver seconds within30shared seconds."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys,time,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rectangle-direction-projection-20261026';OUT=BASE/'search'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2,sat_parameters_pb2
    from ortools.sat.python import cp_model
    budget=load(OUT/'budget.json');assert load(BASE/'model-audit/checks.json')['passed']
    for plan in [BASE/'plan.json',BASE/'model-audit/plan.json']:
        for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
    rows=load(BASE/'inventory.json');results=[]
    for r in rows:
        if time.perf_counter()>budget['deadline_perf_counter']-25:break
        began=time.perf_counter();folder=OUT/f"{r['index']:03d}";folder.mkdir();model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'models'/f"{r['index']:03d}.pbtxt").read_text()) and model.validate()=='' and model.export_to_file(str(folder/'model.pb'));saved=cp_model_pb2.CpModelProto();saved.ParseFromString((folder/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((BASE/'models'/f"{r['index']:03d}.pb").read_bytes());assert saved==expected
        solver=cp_model.CpSolver();params={'max_time_in_seconds':r['solver_seconds'],'num_search_workers':4,'random_seed':0,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
        for k,v in params.items():setattr(solver.parameters,k,v)
        assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params);(folder/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(folder/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'pair':r['index'],'maximum_calls':1,'model_sha256':digest(folder/'model.pb'),'parameters_sha256':digest(folder/'parameters.pbtxt'),'seconds_limit':r['solver_seconds']})
        with (folder/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
            solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-start
        response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(folder/'response.pb').write_bytes(response.SerializeToString());record={'pair':r['index'],'parts':r['parts'],'status':solver.status_name(status),'seconds':elapsed,'stage_seconds':time.perf_counter()-began,'solver_calls':1,'solver_soft_overshoot_seconds':max(0,elapsed-r['solver_seconds']),'original_coordinates_units1000':list(response.solution[:2*len(r['parts'])]) if response.solution else None};write(folder/'result.json',record);results.append(record)
    write(OUT/'census.json',{'results':results,'pending_pairs':[r['index'] for r in rows[len(results):]],'solver_calls':len(results),'counts':{s:sum(r['status']==s for r in results) for s in ['OPTIMAL','FEASIBLE','UNKNOWN','INFEASIBLE']},'full_target_witness':False,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'start_perf_counter':start,'deadline_perf_counter':start+30,'shared_seconds':30,'maximum_calls':1,'per_group_solver_seconds':20,'workers':4,'seed':0,'previous_calls_closed':True})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,start+30-time.perf_counter()));(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);r={'exit_code':p.returncode,'seconds':time.perf_counter()-start,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');r={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',r);print(r);print(load(OUT/'census.json') if (OUT/'census.json').exists() else 'No final census; all opened calls closed.')
if __name__=='__main__':
    try:child() if '--child' in sys.argv else main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
