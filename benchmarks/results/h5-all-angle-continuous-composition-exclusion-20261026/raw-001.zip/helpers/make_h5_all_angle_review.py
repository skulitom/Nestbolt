from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_compact_checkpoint.py').read_text().replace('h5-compact-cog-checkpoint-review-20261026','h5-all-angle-checkpoint-review-20261026').replace('7271cc8beb5caae3a3dced77d129ffcdcb1ec7ed','6246967c2962095d78b15693ae34550fbe163743')
with (ROOT/'output/review_h5_all_angle_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
