"""Prepare new one-shot runner and response checks, without calling solver."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,dest in [('run_h5_rectangle_direction_projection.py','run_h5_all_angle_projection.py'),('audit_h5_rectangle_projection_response.py','audit_h5_all_angle_projection_response.py')]:
    s=(ROOT/'output'/source).read_text().replace('h5-rectangle-direction-projection-20261026','h5-all-angle-projection-20261026').replace('h5-eight-phase-band-capacity-20261026','h5-rotation-independent-bands-20261026').replace('any(p>=12 for p in chosen[5:])','chosen[5:]==[11]*4')
    with (ROOT/'output'/dest).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('New20/30 second runner and response auditor prepared; no call started.')
