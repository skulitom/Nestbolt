"""Exact fresh band minima for all-angle, quantization-safe inner profiles."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from bisect import bisect_right
from functools import lru_cache
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-rotation-independent-geometry-20261026';OUT=ROOT/'output/h5-rotation-independent-bands-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'profiles').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240;assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');bounds=load(SOURCE/'anchor-bounds.json');stock=[F(*v) for v in spec['relaxed_stock_bounds_rational']];bands=[];lo=stock[1]
while lo<stock[3]:hi=min(stock[3],lo+5);bands.append([lo,hi]);lo=hi
paths=[SOURCE/n for n in ['plan.json','profiles.json','anchor-bounds.json','audit/checks.json','audit/necessity-proof.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'construction_limit_seconds':240,'audit_limit_seconds':240,'profiles':[p['index'] for p in profiles],'required_original_counts':spec['required_original_counts'],'stock_bounds_rational':spec['relaxed_stock_bounds_rational'],'bands_mm':[[ratio(a),ratio(b)] for a,b in bands],'coordinate_units_per_mm':1000,'area_units_per_mm2':1000,'method':'Recompute all band coefficients from the exact rational inner subsets and all-angle stock domains. Components have disjoint interiors. Integrate each rational polygon slice, then minimize total proxy area in each5mm stock band over every continuous anchor in each complete integer1mm cell. Include all edge/band breakpoints and quadratic stationary points. Quantization-safe inner proxies lie within any original continuous placement, so floored per-cell minima are necessary for all real cog rotations. No finite-angle coefficients, padding or exclusions are reused. No solving.'})
details=[];total_cells=coefficients=0
for p in profiles:
    assert time.perf_counter()<deadline
    raw=[p['vertices_units1000']] if p['family']=='cog' else [[(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3])] for b in p['rectangles_units1000']];rings=[[(F(x,1000),F(y,1000)) for x,y in r] for r in raw];edges=[];knots=set();area=F(0)
    for ring in rings:
        twice=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(ring,ring[1:]+ring[:1]));assert twice>0;area+=twice/2;knots.update(y for x,y in ring)
        for a,b in zip(ring,ring[1:]+ring[:1]):
            if a[1]==b[1]:continue
            sign=1 if b[1]>a[1] else -1;m=(b[0]-a[0])/(b[1]-a[1]);c=a[0]-m*a[1];edges.append((min(a[1],b[1]),max(a[1],b[1]),sign*m,sign*c))
    knots=sorted(knots);segments=[];prefix=F(0)
    for a,b in zip(knots,knots[1:]):
        mid=(a+b)/2;m=sum(e[2] for e in edges if e[0]<mid<e[1]);c=sum(e[3] for e in edges if e[0]<mid<e[1]);segments.append((m,c,prefix));prefix+=m*(b*b-a*a)/2+c*(b-a)
    assert prefix==area
    @lru_cache(None)
    def below(y):
        if y<=knots[0]:return F(0)
        if y>=knots[-1]:return area
        i=bisect_right(knots,y)-1;m,c,base=segments[i];a=knots[i];return base+m*(y*y-a*a)/2+c*(y-a)
    def slope(y):
        if y<=knots[0] or y>=knots[-1]:return F(0),F(0)
        return segments[bisect_right(knots,y)-1][:2]
    ylo,yhi=bounds[str(p['index'])][1::2];cells=[]
    for low in range(ylo,yhi+1,1000):
        high=min(low+999,yhi);t0,t1=F(low,1000),F(high,1000);demands=[]
        for a,b in bands:
            stops=sorted({t0,t1}|{bound-k for bound in [a,b] for k in knots if t0<bound-k<t1});candidates=list(stops)
            for u,v in zip(stops,stops[1:]):
                mid=(u+v)/2;ma,ca=slope(a-mid);mb,cb=slope(b-mid);A=mb-ma;B=ma*a+ca-mb*b-cb
                if A:
                    root=-B/A
                    if u<root<v:candidates.append(root)
            value=min(below(b-t)-below(a-t) for t in candidates);assert value>=0;demands.append(math.floor(value*1000));coefficients+=1
        cells.append({'index':len(cells),'y_bounds_units1000':[low,high],'band_lower_area_units':demands})
    write(OUT/'profiles'/f"{p['index']:03d}.json",{'profile':p['index'],'family':p['family'],'y_bounds_units1000':[ylo,yhi],'filled_proxy_area_mm2':ratio(area),'cells':cells});details.append({'profile':p['index'],'cells':len(cells)});total_cells+=len(cells)
write(OUT/'band-capacities.json',[math.floor((stock[2]-stock[0])*(b-a)*1000) for a,b in bands]);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'profiles':len(profiles),'bands':len(bands),'vertical_cells':total_cells,'exact_lower_area_coefficients':coefficients,'profile_summary':details,'all_profiles_complete':True,'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
