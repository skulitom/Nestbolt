"""Independent rational edge-integral minima and full cell coverage."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from functools import lru_cache
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rotation-independent-bands-20261026';SOURCE=ROOT/'output/h5-rotation-independent-geometry-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240;write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'audit_limit_seconds':240,'method':'Reconstruct exact rational edges from audited integer inner rectangles and common all-angle128-gon. Independently integrate each oriented edge below each band boundary, derive derivative coefficients from two rational interior evaluations, and include all endpoints, edge breakpoints and interior stationary minima. Verify every coefficient, complete stock-anchor cell cover and exact capacities. No finite-angle stock or coefficients are used; no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(BASE/'plan.json');source=load(SOURCE/'plan.json');assert spec['stock_bounds_rational']==source['relaxed_stock_bounds_rational'];stock=[F(*v) for v in spec['stock_bounds_rational']];bands=[[F(*v) for v in r] for r in spec['bands_mm']];assert len(bands)==63 and bands[0][0]==stock[1] and bands[-1][1]==stock[3] and all(a[1]==b[0] for a,b in zip(bands,bands[1:]));caps=[math.floor((stock[2]-stock[0])*(b-a)*1000) for a,b in bands];assert caps==load(BASE/'band-capacities.json');bounds=load(SOURCE/'anchor-bounds.json');checked=count=stationary=covered=0
for p in load(SOURCE/'profiles.json'):
    assert time.perf_counter()<deadline
    rings=[p['vertices_units1000']] if p['family']=='cog' else [[(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3])] for b in p['rectangles_units1000']];edges=[];ys=set();full=F(0)
    for raw in rings:
        pts=[(F(x,1000),F(y,1000)) for x,y in raw];twice=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(pts,pts[1:]+pts[:1]));assert twice>0;full+=twice/2;ys.update(y for x,y in pts)
        for a,b in zip(pts,pts[1:]+pts[:1]):
            if a[1]==b[1]:continue
            k=1 if b[1]>a[1] else -1;m=(b[0]-a[0])/(b[1]-a[1]);c=a[0]-m*a[1];edges.append((min(a[1],b[1]),max(a[1],b[1]),m,c,k))
    ys=sorted(ys)
    @lru_cache(None)
    def below(y):
        if y<=ys[0]:return F(0)
        if y>=ys[-1]:return full
        return sum(k*(m*(min(y,hi)**2-lo**2)/2+c*(min(y,hi)-lo)) for lo,hi,m,c,k in edges if y>lo)
    def width(y):return sum(k*(m*y+c) for lo,hi,m,c,k in edges if lo<y<hi)
    data=load(BASE/'profiles'/f"{p['index']:03d}.json");assert F(*data['filled_proxy_area_mm2'])==full;lo,hi=bounds[str(p['index'])][1::2];assert data['y_bounds_units1000']==[lo,hi];following=lo
    for ordinal,cell in enumerate(data['cells']):
        low,high=cell['y_bounds_units1000'];assert cell['index']==ordinal and low==following and high==min(low+999,hi);following=high+1;covered+=high-low+1;t0,t1=F(low,1000),F(high,1000)
        for (a,b),want in zip(bands,cell['band_lower_area_units']):
            points=sorted({t0,t1}|{bound-y for bound in [a,b] for y in ys if t0<bound-y<t1});candidates=list(points)
            for u,v in zip(points,points[1:]):
                x,y=(2*u+v)/3,(u+2*v)/3;dx,dy=width(a-x)-width(b-x),width(a-y)-width(b-y);slope=(dy-dx)/(y-x)
                if slope:
                    root=x-dx/slope
                    if u<root<v:candidates.append(root);stationary+=1
            exact=min(below(b-t)-below(a-t) for t in candidates);assert exact>=0 and math.floor(exact*1000)==want,(p['index'],ordinal,a,b);checked+=1
        assert len(cell['band_lower_area_units'])==63;count+=1
    assert following==hi+1
assert checked==count*63;write(OUT/'necessity-proof.json',{'all_real_cog_angles':True,'continuous_original_anchors':True,'statement':'Every continuous original placement maps by anchor flooring to the audited inner proxies, each contained in its original. These mapped proxies are disjoint and contained in the outward-relaxed stock. Choose the unique integer anchor cell for each proxy. Its actual occupied band area is at least the exact minimum over that entire cell. The sum of floored demand units cannot exceed the floored stock-band area. Thus all63 freshly computed constraints are necessary; independent cell minima deliberately relax shared anchor choices. No finite-angle coefficients or source guard restrictions transfer.'});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'proxy_profiles_verified':11,'complete_vertical_cells_verified':count,'integer_y_values_covered':covered,'exact_band_coefficients_recomputed':checked,'stationary_candidates_checked':stationary,'stock_bands_verified':63,'all_angle_continuous_placement_implication':True,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
