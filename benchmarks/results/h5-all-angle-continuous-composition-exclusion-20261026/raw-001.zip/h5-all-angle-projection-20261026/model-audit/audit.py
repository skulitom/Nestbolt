"""Independent reconstruction of the fresh all-angle necessary projection."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-all-angle-projection-20261026';SOURCE=ROOT/'output/h5-rotation-independent-geometry-20261026';DATA=ROOT/'output/h5-rotation-independent-bands-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reconstruct all1768 variables and2374 complete constraint fields from newly audited all-angle inner geometry and bands. Check mandatory originals, all bracket choices, both inserts, common cog proxy, full relaxed-stock cells, every band coefficient, necessary directions and monotonicity,6 cog gaps and all98 optional rectangles. Verify relabelling symmetry and actual import/export. No finite-angle model, cut, guard or coefficient is copied.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert all(load(p/'audit/checks.json')['passed'] for p in [SOURCE,DATA]);proof=load(SOURCE/'audit/necessity-proof.json');assert proof['all_real_cog_rotations'] and proof['all_continuous_anchors'];assert load(DATA/'audit/necessity-proof.json')['continuous_original_anchors']
allowed=[list(range(8))]*4+[[8,10]]+[[11]]*4;bounds=load(SOURCE/'anchor-bounds.json');m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};vi=ci=0
def var(name,dom):
    global vi
    v=vi;assert m.variables[v]==cp_model_pb2.IntegerVariableProto(name=name,domain=dom);vi+=1;return v
def check(c):
    global ci
    assert c==m.constraints[ci],ci;ci+=1
def lin(terms,lo,hi,enforce=()):
    vs=sorted(v for v,k in terms.items() if k);check(cp_model_pb2.ConstraintProto(enforcement_literal=enforce,linear=cp_model_pb2.LinearConstraintProto(vars=vs,coeffs=[terms[v] for v in vs],domain=[lo,hi])))
for i,ps in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in ps),max(bounds[str(p)][axis+2] for p in ps)])
flags={i:{p:var(f'p{i}-profile{p}',[0,1]) for p in ps} for i,ps in enumerate(allowed)}
assert {str(i):{str(p):v for p,v in fs.items()} for i,fs in flags.items()}==load(BASE/'profile-flags.json')
for i in range(9):
    lin(dict.fromkeys(flags[i].values(),1),1,1)
    for p,v in flags[i].items():
        for axis in range(2):lin({2*i+axis:1},bounds[str(p)][axis],bounds[str(p)][axis+2],[v])
for i in [0,1,2,5,6,7]:lin({2*i:1,2*(i+1):-1},-2**63,0)
assert (vi,ci)==(56,91)
ds={r['profile']:r for r in load(SOURCE/'profile-bounds.json')};cases={r['profiles'][0]:r for r in load(SOURCE/'pair-bounds.json')};gap=cases[11]['right_minimum_dx_units1000'];dirs={};req=[]
for a,b in product(range(5),range(5,9)):
    v=var(f'pair-{a}-{b}-right',[0,1]);dirs[f'{a}-{b}']=v
    for p in allowed[a]:
        r=ds[p];left,right=r['left_maximum_dx_units1000'],r['right_minimum_dx_units1000'];assert left==cases[p]['left_maximum_dx_units1000'] and right==cases[p]['right_minimum_dx_units1000'] and right+gap-left>0
        lin({2*a:-1,2*b:1},-2**63,left,[flags[a][p],-v-1]);lin({2*a:-1,2*b:1},right,2**63-1,[flags[a][p],v]);req.append({'parts':[a,b],'profile':p,'left':left,'right':right})
for a,b in product(range(5),range(5,8)):check(cp_model_pb2.ConstraintProto(bool_or=cp_model_pb2.BoolArgumentProto(literals=[-dirs[f'{a}-{b}']-1,dirs[f'{a}-{b+1}']])) )
for a,b in combinations(range(5,9),2):lin({2*a:-1,2*b:1},gap,2**63-1)
assert dirs==load(BASE/'direction-flags.json') and req==load(BASE/'direction-requirements.json');cells=[];groups=[];covered=0
for i,ps in enumerate(allowed):
    for p in ps:
        data=load(DATA/'profiles'/f'{p:03d}.json');lo,hi=bounds[str(p)][1::2];assert data['y_bounds_units1000']==[lo,hi];following=lo;ids=[]
        for ordinal,c in enumerate(data['cells']):
            low,high=c['y_bounds_units1000'];assert c['index']==ordinal and low==following and high==min(low+999,hi);following=high+1;covered+=high-low+1;v=var(f'p{i}-profile{p}-cell{ordinal}',[0,1]);lin({2*i+1:1},low,high,[v]);ids.append(v);cells.append({'variable':v,'part':i,'profile':p,'cell':ordinal,'y_bounds_units1000':[low,high],'demands':c['band_lower_area_units']})
        assert following==hi+1;groups.append({'part':i,'profile':p,'profile_flag':flags[i][p],'cell_flags':ids})
for g in groups:lin({g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)},0,0)
caps=load(DATA/'band-capacities.json');assert len(caps)==63
for band,cap in enumerate(caps):lin({r['variable']:r['demands'][band] for r in cells if r['demands'][band]},-2**63,cap)
assert (vi,ci)==(1768,2177) and cells==load(BASE/'cell-selectors.json') and groups==load(BASE/'cell-groups.json')
data={p['index']:p for p in load(SOURCE/'profiles.json')};rects=[];xs=[];ys=[]
for part in range(5):
    for p in allowed[part]:
        for ordinal,b in enumerate(data[p]['rectangles_units1000']):
            ids=[]
            for axis in range(2):
                ids.append(ci);low,high=b[axis::2];expr=lambda offset:cp_model_pb2.LinearExpressionProto(vars=[2*part+axis],coeffs=[1],offset=offset);check(cp_model_pb2.ConstraintProto(enforcement_literal=[flags[part][p]],interval=cp_model_pb2.IntervalConstraintProto(start=expr(low),end=expr(high),size=cp_model_pb2.LinearExpressionProto(offset=high-low))))
            xs.append(ids[0]);ys.append(ids[1]);rects.append({'part':part,'profile':p,'rectangle':ordinal,'presence':flags[part][p],'interval_constraints':ids,'bounds_units1000':b})
check(cp_model_pb2.ConstraintProto(no_overlap_2d=cp_model_pb2.NoOverlap2DConstraintProto(x_intervals=xs,y_intervals=ys)));assert rects==load(BASE/'optional-rectangles.json')
r=load(BASE/'inventory.json')[0];assert vi==len(m.variables)==r['variables']==1768 and ci==len(m.constraints)==r['constraints']==2374 and digest(BASE/'models/000.pb')==r['model_sha256'] and r['allowed_profiles']==allowed and r['originals']==load(SOURCE/'plan.json')['required_originals']==[21,22,25,26,37,53,63,64,65] and r['solver_seconds']==20
counts={}
for family,offset,options in [('bracket',0,list(range(8))),('cog',5,[11])]:
    n=0
    for chosen in product(options,repeat=4):
        for ranks in permutations(range(4)):
            order=sorted(range(4),key=lambda k:ranks[k]);assigned=[chosen[k] for k in order];assert sorted(chosen)==sorted(assigned) and all(p in allowed[offset+i] for i,p in enumerate(assigned));n+=1
    counts[family]=n
assert counts=={'bracket':98304,'cog':24}
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'necessity-proof.json',{'necessary_for_all_real_cog_angles':True,'necessary_for_continuous_original_anchors':True,'converse_claimed':False,'statement':'Use the separately proved all-angle continuous-anchor-to-grid inner-subset map. Sort identical bracket and cog copies with their proxy choices. Every mapped source placement satisfies fresh relaxed stock domains, exact-one profile counts, central forbidden-rectangle disjunctions, necessary cog gap and monotone side clauses, freshly audited complete band cells and all optional inner-rectangle nonoverlap. All constraints are consequences or relaxations; no sampled-angle branch restriction remains. Thus a negative excludes only this fixed nine-original composition in the declared outward-relaxed stock. A positive is only a necessary allocation and cannot establish original geometry, first-sheet completion, native validation or H5 acceptance.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'cell_selectors':len(cells),'cell_band_coefficients_checked':len(cells)*63,'complete_profile_y_values_covered':covered,'optional_inner_rectangles':len(rects),'symmetry_cases':counts,'all_fields_reconstructed':True,'actual_import_export_verified':True,'necessary_all_angle_continuous_projection':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
