"""Fresh necessary model for every cog angle and continuous source anchor."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-rotation-independent-geometry-20261026';DATA=ROOT/'output/h5-rotation-independent-bands-20261026';OUT=ROOT/'output/h5-all-angle-eight-projection-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert all(load(f/'audit/checks.json')['passed'] for f in [SOURCE,DATA]);s=load(SOURCE/'plan.json');bounds=load(SOURCE/'anchor-bounds.json');allowed=[list(range(8)) for _ in range(4)]+[[11] for _ in range(4)]
paths=[p for folder in [SOURCE,DATA] for p in folder.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':allowed,'originals':(s['required_originals'][:4]+s['required_originals'][5:]),'pending_first_sheet_originals':[28,29,37],'removed_from_short_sheet_only':37,'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Fresh necessary projection for all real cog rotations and all continuous original anchors. Four brackets choose all8 profiles independently and all four cogs use the common inner128-gon. Use only newly audited outward-relaxed stock domains, necessary proxy disjunctions, common cog spacing, complete fresh band minima and optional inner rectangles. Sort identical copies with profiles by x. No finite-angle exclusions, old guards, coefficients, fixed pose or hint. Positives are only necessary allocations; negatives exclude only this eight-original composition in the declared relaxed stock, subject to the audited continuous-to-grid inner-subset mapping. One20solver/30shared second4worker seed0 call after independent complete reconstruction and actual import audit.'})
m=cp_model_pb2.CpModelProto()
def var(name,dom):
    v=len(m.variables);m.variables.add(name=name,domain=dom);return v
def lin(terms,lo,hi,enforce=()):
    vs=sorted(v for v,k in terms.items() if k);c=m.constraints.add();c.enforcement_literal.extend(enforce);c.linear.vars.extend(vs);c.linear.coeffs.extend(terms[v] for v in vs);c.linear.domain.extend([lo,hi])
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in options),max(bounds[str(p)][axis+2] for p in options)])
flags={i:{p:var(f'p{i}-profile{p}',[0,1]) for p in options} for i,options in enumerate(allowed)}
for i in range(8):
    lin(dict.fromkeys(flags[i].values(),1),1,1)
    for p,v in flags[i].items():
        for axis in range(2):lin({2*i+axis:1},bounds[str(p)][axis],bounds[str(p)][axis+2],[v])
for i in [0,1,2,4,5,6]:lin({2*i:1,2*(i+1):-1},-2**63,0)
assert (len(m.variables),len(m.constraints))==(52,86)
dirs={};dmap={r['profile']:r for r in load(SOURCE/'profile-bounds.json')};requirements=[]
for a,b in product(range(4),range(4,8)):
    v=var(f'pair-{a}-{b}-right',[0,1]);dirs[f'{a}-{b}']=v
    for p in allowed[a]:
        d=dmap[p];left,right=d['left_maximum_dx_units1000'],d['right_minimum_dx_units1000'];lin({2*a:-1,2*b:1},-2**63,left,[flags[a][p],-v-1]);lin({2*a:-1,2*b:1},right,2**63-1,[flags[a][p],v]);requirements.append({'parts':[a,b],'profile':p,'left':left,'right':right})
for a,b in product(range(4),range(4,7)):m.constraints.add().bool_or.literals.extend([-dirs[f'{a}-{b}']-1,dirs[f'{a}-{b+1}']])
gap=load(SOURCE/'result.json')['cog_minimum_dx_units1000']
for a,b in combinations(range(4,8),2):lin({2*a:-1,2*b:1},gap,2**63-1)
selectors=[];groups=[]
for i,options in enumerate(allowed):
    for p in options:
        ids=[]
        for cell in load(DATA/'profiles'/f'{p:03d}.json')['cells']:
            v=var(f'p{i}-profile{p}-cell{cell["index"]}',[0,1]);lin({2*i+1:1},*cell['y_bounds_units1000'],[v]);ids.append(v);selectors.append({'variable':v,'part':i,'profile':p,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
        groups.append({'part':i,'profile':p,'profile_flag':flags[i][p],'cell_flags':ids})
for g in groups:lin({g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)},0,0)
for b,cap in enumerate(load(DATA/'band-capacities.json')):lin({r['variable']:r['demands'][b] for r in selectors},-2**63,cap)
assert (len(m.variables),len(m.constraints))==(1424,1815)
profiles={p['index']:p for p in load(SOURCE/'profiles.json')};rects=[];xs=[];ys=[]
for part in range(4):
    for p in allowed[part]:
        for j,b in enumerate(profiles[p]['rectangles_units1000']):
            ids=[]
            for axis in range(2):
                ids.append(len(m.constraints));c=m.constraints.add();c.enforcement_literal.append(flags[part][p]);c.interval.start.vars.append(2*part+axis);c.interval.start.coeffs.append(1);c.interval.start.offset=b[axis];c.interval.end.vars.append(2*part+axis);c.interval.end.coeffs.append(1);c.interval.end.offset=b[axis+2];c.interval.size.offset=b[axis+2]-b[axis]
            xs.append(ids[0]);ys.append(ids[1]);rects.append({'part':part,'profile':p,'rectangle':j,'presence':flags[part][p],'interval_constraints':ids,'bounds_units1000':b})
c=m.constraints.add();c.no_overlap_2d.x_intervals.extend(xs);c.no_overlap_2d.y_intervals.extend(ys);assert (len(m.variables),len(m.constraints))==(1424,2008)
for n,v in [('profile-flags.json',flags),('direction-flags.json',dirs),('direction-requirements.json',requirements),('cell-selectors.json',selectors),('cell-groups.json',groups),('optional-rectangles.json',rects)]:write(OUT/n,v)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');r={'index':0,'parts':list(range(8)),'originals':(s['required_originals'][:4]+s['required_originals'][5:]),'allowed_profiles':allowed,'variables':len(m.variables),'constraints':len(m.constraints),'solver_seconds':20,'model_sha256':digest(p),'cell_selectors':len(selectors),'profile_cell_equalities':len(groups),'direction_flags':16,'direction_inequalities':256,'monotone_clauses':12,'cog_spacing_constraints':6,'band_inequalities':63,'optional_inner_rectangles':96,'optional_intervals':192,'no_overlap_2d_constraints':1};write(OUT/'inventory.json',[r]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**r,'solver_calls':0});print(load(OUT/'prepared.json'))
