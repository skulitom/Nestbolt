"""One finite guided pipeline with new coefficient vectors and original scoring."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-mixed-rows-model-20261107';SOURCE=ROOT/'output/h5-mixed-rows-continuous-model-20261107';OUT=BASE/'search';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def problem_key(physical,weights):return sha256(json.dumps({'physical':list(physical),'weights':weights},separators=(',',':'),allow_nan=False).encode()).hexdigest()

def child(started):
    import numpy as np,scipy
    from scipy.optimize import minimize
    from h5_weighted_original_model_20261107 import compile_model,Objective,update_weights
    from h5_weighted_original_readback_20261107 import verify
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
    from h5_legacy64_source_readback import audit
    assert scipy.__version__=='1.17.1';plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,r in load(BASE/'audit-v2/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256']
    lib=load(BASE/'library.json');initial=load(BASE/'initial-state.json');classes=family_classes(lib);job=load(JOB);options=load(BASE/'audit-v2/optimizer-controls.json')['options'];modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];visited=set();summaries=[];global_best=None;valid_witness=None;total_trials=0;stop='MAXIMUM_EPOCHS';calls=0;valid=False
    for epoch in range(plan['maximum_optimizer_calls']):
        if time.perf_counter()-started>=56:stop='TIME_STOP_BEFORE_EPOCH';break
        folder=OUT/f'epoch-{epoch:02d}';folder.mkdir();(folder/'points').mkdir();incoming=values.copy();incoming_modes=modes.copy();write(folder/'opened.json',{'epoch':epoch,'incoming_values':incoming,'incoming_modes':incoming_modes,'weights_before_update':weights,'visited_weighted_problems':sorted(visited),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        if epoch:
            previous=compile_model(lib,modes,values,weights);losses=Objective(previous).pair_losses(values).tolist();updated=update_weights(weights,losses);write(folder/'weight-transition.json',{'before':weights,'pair_losses_mm2':losses,'after':updated,'source':'previous_epoch_weighted_best'});weights=updated
            choices=[modes.copy()]
            for i,(family,_) in enumerate(lib['identities']):
                for option in lib['family_modes'][family]:
                    if option['mode']==modes[i]:continue
                    candidate=modes.copy();candidate[i]=option['mode'];choices.append(candidate)
            seen=set();trials=[];skipped=[];chosen=None;complete=True
            for sequence,candidate in enumerate(choices):
                key=problem_key(physical_key(lib,classes,candidate),weights)
                if key in visited or key in seen:skipped.append({'sequence':sequence,'key':key,'reason':'closed_weighted_problem' if key in visited else 'equivalent_choice'});continue
                if time.perf_counter()-started>=56:complete=False;break
                seen.add(key);mm=compile_model(lib,candidate,incoming,weights);assert verify(mm,lib,candidate,incoming,weights);score=Objective(mm).score(mm['initial']);r={'sequence':sequence,'modes':candidate,'key':key,'weighted_objective_mm2':score};trials.append(r);total_trials+=1;tie=(score,candidate)
                if chosen is None or tie<chosen[0]:chosen=(tie,r,mm)
            write(folder/'mode-trials.json',{'complete':complete,'trials':trials,'skipped':skipped})
            if not complete:stop='TIME_STOP_DURING_MODE_SELECTION';break
            if chosen is None:stop='NO_NEW_WEIGHTED_PROBLEM';break
            _,selection,model=chosen;modes=selection['modes'];write(folder/'selected-mode.json',selection)
        else:model=compile_model(lib,modes,values,weights)
        assert verify(model,lib,modes,incoming,weights) and any(w!=1 for w in weights);key=problem_key(physical_key(lib,classes,modes),weights);assert key not in visited;allocated=min(10.,56-(time.perf_counter()-started))
        if allocated<=0:stop='TIME_STOP_BEFORE_CALL';break
        write(folder/'model.json',model);assert verify(load(folder/'model.json'),lib,modes,incoming,weights);obj=Objective(model);point=np.asarray(model['initial']);energy,g,details=obj.evaluate(point,True);bounds=np.asarray(model['bounds'])
        def row(sequence,evaluation,x,value,gradient,d,improved_weighted,improved_unweighted):return {'sequence':sequence,'evaluation':evaluation,'values':x.tolist(),'weighted_objective_mm2':value,'unweighted_objective_mm2':d['unweighted_objective_mm2'],'gradient':gradient.tolist(),'improved_weighted':improved_weighted,'improved_unweighted':improved_unweighted}
        first=row(0,0,point,energy,g,details,True,True);write(folder/'points/00000.json',first);state={'evaluations':0,'saved':1,'weighted':first,'unweighted':first};calls+=1;visited.add(key);write(folder/'optimizer-opened.json',{'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'parameters':81,'allocated_seconds':allocated,'key':key,'model_sha256':digest(folder/'model.json'),'uniform_weight_problem':False,'maximum_calls_for_weighted_problem':1,'retry_permitted':False,'algorithm_seconds_including_preparation':time.perf_counter()-started})
        class Deadline(Exception):pass
        def function(x):
            if time.perf_counter()>=deadline:raise Deadline()
            value,gradient,d=obj.evaluate(x,True);state['evaluations']+=1;iw=value<state['weighted']['weighted_objective_mm2'];iu=d['unweighted_objective_mm2']<state['unweighted']['unweighted_objective_mm2']
            if iw or iu:
                r=row(state['saved'],state['evaluations'],x,value,gradient,d,iw,iu);write(folder/'points'/f'{state["saved"]:05d}.json',r);state['saved']+=1
                if iw:state['weighted']=r
                if iu:state['unweighted']=r
            return value,gradient
        def callback(x):
            if state['unweighted']['unweighted_objective_mm2']<=1e-16:raise StopIteration()
        before=time.perf_counter();deadline=before+allocated;numerical=None
        try:
            r=minimize(function,point,jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options);status='RETURNED';numerical={'success':bool(r.success),'status':int(r.status),'message':str(r.message),'iterations':int(r.nit),'function_evaluations':int(r.nfev),'objective_mm2':float(r.fun),'values':r.x.tolist()}
        except Deadline:status='TIME_STOP'
        elapsed=time.perf_counter()-before;readbacks={}
        for label in ['weighted','unweighted']:
            selected=state[label];x=selected['values'];value,gradient,d=obj.evaluate(x,True);assert value==selected['weighted_objective_mm2'] and d['unweighted_objective_mm2']==selected['unweighted_objective_mm2'] and np.array_equal(gradient,selected['gradient']) and np.all(np.asarray(x)>=bounds[:,0]) and np.all(np.asarray(x)<=bounds[:,1]);rows=source_rows(model,x);write(folder/(label+'-source66.json'),rows);checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));write(folder/(label+'-source-checks.json'),checked);assert checked['stock_failures']==0 and checked['originals']==66;readbacks[label]={'unweighted_objective_mm2':d['unweighted_objective_mm2'],'original_overlap_mm2':d['original_overlap_area_mm2'],'pair_failures':checked['pair_failures'],'source_valid66':checked['valid']};valid=valid or checked['valid']
        for label in ['weighted','unweighted']:
            if readbacks[label]['source_valid66'] and valid_witness is None:valid_witness={'epoch':epoch,'label':label,'modes':modes,'values':state[label]['values'],'source66_path':(folder/(label+'-source66.json')).relative_to(ROOT).as_posix()}
        candidate={'epoch':epoch,'modes':modes,'values':state['unweighted']['values'],'unweighted_objective_mm2':state['unweighted']['unweighted_objective_mm2'],'source_pair_failures':readbacks['unweighted']['pair_failures'],'source_valid66':readbacks['unweighted']['source_valid66']}
        if global_best is None or candidate['unweighted_objective_mm2']<global_best['unweighted_objective_mm2'] or candidate['source_valid66']:global_best=candidate
        write(folder/'response.json',{'closed':True,'key':key,'status':status,'numerical_result':numerical,'allocated_seconds':allocated,'returned_seconds':elapsed,'slice_overrun_seconds':max(0.,elapsed-allocated),'evaluations':state['evaluations'],'saved_points':state['saved'],'weighted_best':state['weighted'],'unweighted_best':state['unweighted'],'source_readbacks':readbacks,'global_best':global_best,'algorithm_seconds_including_preparation':time.perf_counter()-started});summaries.append({'epoch':epoch,'key':key,'minimum_weight':min(weights),'maximum_weight':max(weights),'status':status,'weighted_best_unweighted_objective_mm2':state['weighted']['unweighted_objective_mm2'],'best_unweighted_objective_mm2':state['unweighted']['unweighted_objective_mm2'],'source_pair_failures':readbacks['unweighted']['pair_failures'],'source_valid66':valid});print(summaries[-1],flush=True);values=state['weighted']['values']
        if valid:stop='SOURCE_VALID_CANDIDATE';break
        if time.perf_counter()-started>=56:stop='TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started;write(OUT/'result.json',{'closed':True,'status':stop,'optimizer_calls':calls,'unique_weighted_problems':len(visited),'mode_trials':total_trials,'epochs':summaries,'best_global_unweighted':global_best,'source_valid66':valid,'valid_witness':valid_witness,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'native_calls':0,'uniform_weight_calls':0,'old_calls_resumed':False,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False});print(load(OUT/'result.json'))

def main():
    checked=load(BASE/'audit-v2/checks.json');assert checked['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');charge=checked['complete_preparation_seconds'];started=time.perf_counter()-charge
    files=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_weighted_original_model_20261107.py','h5_weighted_original_readback_20261107.py','h5_movable_roof_model_20261107.py','h5_mixed_rows_continuous_readback_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5-weighted-mixed-rows-model-preparation-process-20261107/process.json']]+[BASE/n for n in ['plan.json','checks.json','library.json','model.json','initial-state.json','initial-weight-transition.json','initial-objective.json','audit-v2/plan.json','audit-v2/checks.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json','audit-v2/physical-mode-controls.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'complete_preparation_seconds':charge,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_optimizer_calls':4,'optimizer_slice_seconds':10,'blas_threads':1,'method':'One finite weighted exact-geometry pipeline from the unoptimized source initializer, including all preparation. Initial coefficients already contain one audited update; no uniform-weight optimizer call reopens. At each later epoch update all528 coefficients using the previous epoch weighted-best point and the frozen positive bounded rule. Score the unchanged mode vector and all distinct single-owner physical neighbors under those new coefficients; select by weighted objective then full mode vector, excluding every previously optimized coefficient/physical-mode problem. At most four10s L-BFGS-B calls, with only the remaining algorithm allowance allocated. Track weighted progress for guided continuation and unweighted progress independently at every function evaluation. Save every improvement of either measure. Independently reconstruct and source-check both local winners after each call; keep global best by unweighted original-plus-clearance sum. Uniform-weight calls and all historical optimized candidates are excluded. All fixed and stock domains remain hard. Stop on validity, finite count,56s reserve boundary,no new problem or inconsistency. This does not extend any closed unweighted pipeline.','retry_permitted':False,'restarts':0})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'complete_preparation_seconds':charge,'memory_bytes':2**31,'retry_permitted':False});env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0;write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'retry_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; pipeline remains closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
