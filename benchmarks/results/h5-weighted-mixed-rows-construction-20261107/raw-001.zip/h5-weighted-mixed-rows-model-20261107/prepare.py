"""One weighted model preparation from the unoptimized source initializer."""
from pathlib import Path
from hashlib import sha256
import json,time,shutil
import numpy as np
from h5_weighted_original_model_20261107 import compile_model,Objective,update_weights,POLICY
from h5_weighted_original_readback_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-mixed-rows-continuous-model-20261107';OUT=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');prior=load(SOURCE/'audit/checks.json');assert prior['passed']
assert digest(SOURCE/'library.json')==prior['library_sha256'] and digest(SOURCE/'model.json')==prior['model_sha256']
inputs=[Path(__file__)]+[ROOT/'output'/n for n in ['h5_weighted_original_model_20261107.py','h5_weighted_original_readback_20261107.py','h5_movable_roof_model_20261107.py','h5_mixed_rows_continuous_readback_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py']]+[SOURCE/n for n in ['plan.json','checks.json','library.json','model.json','initial-mode-values.json','initial-objective.json','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json','audit/physical-mode-controls.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare a separately specified positive pair-weight objective on the unchanged exact original/clearance model. Consume only the unoptimized source initializer. Compute all528 pair losses, then apply one frozen weight update to unit coefficients before any optimizer. Every coefficient stays in[1,64]; collisions multiply by1.2+0.8*loss/max_loss, noncollisions decay by0.95 with floor1. The same coefficient multiplies both geometry levels and all associated gradient components. Hard fixed-part/stock domains and all original identities/holes remain unchanged. No optimized prior candidate or closed uniform-weight optimizer call is consumed or reopened. This stage prepares no optimizer.','weight_policy':POLICY,'complete_prior_preparation_seconds':prior['complete_preparation_seconds'],'preparation_internal_target_seconds':12,'preparation_process_cap_seconds':15,'algorithm_seconds':60,'shared_seconds':90,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib=load(SOURCE/'library.json');initial=load(SOURCE/'initial-mode-values.json');modes=initial['modes'];values=initial['values'];unit=[1.]*528
base=compile_model(lib,modes,values,unit);losses=Objective(base).pair_losses(values);weights=update_weights(unit,losses);assert any(w>1 for w in weights)
model=compile_model(lib,modes,values,weights);assert verify(model,lib,modes,values,weights)
weighted,g,details=Objective(model).evaluate(values,True);assert abs(weighted-Objective(model).score(values))<1e-7 and abs(details['unweighted_objective_mm2']-load(SOURCE/'initial-objective.json')['energy_mm2'])<1e-7
write(OUT/'library.json',lib);write(OUT/'initial-state.json',{'modes':modes,'values':values,'pair_weights':weights});write(OUT/'initial-weight-transition.json',{'before':unit,'pair_losses_mm2':losses.tolist(),'after':weights});write(OUT/'model.json',model);write(OUT/'initial-objective.json',{'weighted_objective_mm2':weighted,'gradient':g.tolist(),**details})
assert time.perf_counter()-started<12
result={'passed':True,'seconds':time.perf_counter()-started,'moving_originals':33,'parameters':81,'moving_pairs':528,'initial_positive_pairs':int(np.sum(losses>0)),'minimum_weight':min(weights),'maximum_weight':max(weights),'nonunit_weights':sum(w!=1 for w in weights),'weighted_objective_mm2':weighted,'unweighted_objective_mm2':details['unweighted_objective_mm2'],'original_overlap_mm2':details['original_overlap_area_mm2'],'complete_prior_preparation_seconds':prior['complete_preparation_seconds'],'model_sha256':digest(OUT/'model.json'),'library_sha256':digest(OUT/'library.json'),'initial_state_sha256':digest(OUT/'initial-state.json'),'optimizer_calls':0,'uniform_weight_call_reopened':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
