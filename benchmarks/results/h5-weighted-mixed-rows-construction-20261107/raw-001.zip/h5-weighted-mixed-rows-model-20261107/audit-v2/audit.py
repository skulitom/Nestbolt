"""Independent coefficients, weighted geometry, derivatives and update controls."""
from pathlib import Path
from hashlib import sha256
from itertools import product
from fractions import Fraction as F
import json,math,time,copy,shutil
import numpy as np
from shapely.geometry import Polygon
from h5_weighted_original_model_20261107 import compile_model,Objective,update_weights
from h5_weighted_original_readback_20261107 import verify
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-mixed-rows-model-20261107';SOURCE=ROOT/'output/h5-mixed-rows-continuous-model-20261107';OUT=BASE/'audit-v2'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(BASE/'library.json');assert lib==load(SOURCE/'library.json');state=load(BASE/'initial-state.json');prior=load(SOURCE/'audit/checks.json');assert prior['passed'];initial=load(SOURCE/'initial-mode-values.json');assert state['modes']==initial['modes'] and state['values']==initial['values'];modes=state['modes'];values=np.asarray(state['values']);weights=state['pair_weights'];model=load(BASE/'model.json');assert verify(model,lib,modes,values,weights) and model==compile_model(lib,modes,values,weights)
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
def shapes(mm,x):
    out=[]
    for i,o in enumerate(mm['owners']):
        family=o['identity'][0];mode=lib['family_modes'][family][o['mode']];theta=x[66+i-18]/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx=x[2*i]-(sign*px*c-py*s);ty=x[2*i+1]-(sign*px*s+py*c)
        out.append([Polygon([(sign*a*c-b*s+tx,sign*a*s+b*c+ty) for a,b in lib['families'][family][kind]]) for kind in ['original','clearance']])
    return out
def loss_vector(mm,x):
    ps=shapes(mm,x);return [sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for i,j in lib['pairs']]
def full_score(mm,x):return sum(w*a for w,a in zip(mm['pair_weights'],loss_vector(mm,x)))
def independent_update(before,losses):
    peak=max(losses,default=0.);out=[]
    for w,a in zip(before,losses):
        if a==0:value=float(F(w)*F(.95))
        else:
            ratio=float(F(a)/F(peak));scaled=float(F(.8)*F(ratio));factor=float(F(1.2)+F(scaled));value=float(F(w)*F(factor))
        out.append(min(64.,max(1.,value)))
    return out
losses=loss_vector(model,values);transition=load(BASE/'initial-weight-transition.json');assert transition['before']==[1.]*528 and np.max(np.abs(np.asarray(losses)-transition['pair_losses_mm2']))<1e-7
expected=independent_update([1.]*528,losses);assert np.max(np.abs(np.asarray(expected)-weights))<1e-12 and transition['after']==weights and weights==update_weights(transition['before'],transition['pair_losses_mm2']);assert any(w>1 for w in weights)
obj=Objective(model);energy,g,details=obj.evaluate(values,True);saved=load(BASE/'initial-objective.json');assert saved=={'weighted_objective_mm2':energy,'gradient':g.tolist(),**details};assert abs(energy-full_score(model,values))<1e-7 and abs(energy-obj.score(values))<1e-7 and np.max(np.abs(np.asarray(losses)-obj.pair_losses(values)))<1e-7
assert abs(sum(losses)-load(SOURCE/'initial-objective.json')['energy_mm2'])<1e-7
update_controls=[]
cases=[[0.]*528,[1.]*528,[float(i) for i in range(528)],losses,[1e308 if i%2 else 0. for i in range(528)]]
before_cases=[[1.]*528,[64.]*528,[1.+i%64 for i in range(528)]]
for a,b in product(range(len(before_cases)),range(len(cases))):
    before=before_cases[a];ll=cases[b];expected=independent_update(before,ll);actual=update_weights(before,ll);assert expected==actual and all(1<=w<=64 and math.isfinite(w) for w in actual)
    update_controls.append({'before_case':a,'loss_case':b,'coefficients':528,'minimum':min(actual),'maximum':max(actual),'at_floor':sum(w==1 for w in actual),'at_ceiling':sum(w==64 for w in actual)})
write(OUT/'weight-update-controls.json',update_controls)
reference=np.zeros(81);ps=shapes(model,values);scalar_terms=0
for pair_index,(i,j) in enumerate(lib['pairs']):
    for k in [0,1]:
        if ps[i][k].intersection(ps[j][k]).area<=0:continue
        for own,other in [(i,j),(j,i)]:
            gg,_,_=moving_boundary_gradient(ps[own][k],ps[other][k],[values[2*own],values[2*own+1]]);reference[2*own:2*own+2]+=weights[pair_index]*gg[:2]
            if own>=18:reference[66+own-18]+=weights[pair_index]*gg[2]/lib['angle_scale_mm']
            scalar_terms+=1
assert np.max(np.abs(reference-g))<1e-7
derivatives=[]
for variation in [0,1]:
    selected=modes.copy() if variation==0 else [(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(modes)]
    ww=weights if variation==0 else [1.+i%64 for i in range(528)];mm=compile_model(lib,selected,values,ww);assert verify(mm,lib,selected,values,ww);bb=np.asarray(mm['bounds']);margin=.03+np.arange(81)*.00037;point=np.clip(np.asarray(mm['initial'])+.137*np.sin(np.arange(81)*2**.5+.2+variation),bb[:,0]+margin,bb[:,1]-margin);val,gg=Objective(mm).evaluate(point);assert abs(val-full_score(mm,point))<1e-6;errors=[]
    for coordinate in range(81):
        for step in [1e-5,1e-6]:
            plus=point.copy();minus=point.copy();plus[coordinate]+=step;minus[coordinate]-=step;numeric=(full_score(mm,plus)-full_score(mm,minus))/(2*step);err=abs(numeric-gg[coordinate]);assert err<.02+3e-6*abs(gg[coordinate]),(variation,coordinate,step,numeric,gg[coordinate],err);errors.append(float(err))
    derivatives.append({'variation':variation,'coordinates':81,'steps':[1e-5,1e-6],'samples':162,'minimum_weight':min(ww),'maximum_weight':max(ww),'maximum_absolute_error':max(errors)})
write(OUT/'derivative-controls.json',derivatives)
bindings=0;bounds_controls=[]
for i,identity in enumerate(lib['identities']):
    for option in lib['family_modes'][identity[0]]:
        selected=modes.copy();selected[i]=option['mode'];mm=compile_model(lib,selected,values,weights);assert verify(mm,lib,selected,values,weights);ll=loss_vector(mm,mm['initial']);unweighted=sum(ll);weighted=full_score(mm,mm['initial']);assert abs(weighted-Objective(mm).score(mm['initial']))<1e-6 and unweighted<=weighted+1e-7 and weighted<=64*unweighted+1e-7;bindings+=1
        bounds_controls.append({'owner':i,'mode':option['mode'],'unweighted':unweighted,'weighted':weighted})
assert bindings==147;write(OUT/'all-mode-weighted-controls.json',bounds_controls)
zero_controls=[]
for index in range(528):
    a=[0.]*528;b=a.copy();b[index]=1.;assert sum(w*v for w,v in zip(weights,a))==0 and sum(w*v for w,v in zip(weights,b))==weights[index]>0;zero_controls.append({'pair_index':index,'weight':weights[index],'isolated_positive_term_retained':True})
write(OUT/'positive-coefficient-controls.json',zero_controls);write(OUT/'zero-equivalence-proof.json',{'all_pair_terms_present':528,'geometry_terms_per_pair':2,'area_nonnegative':True,'coefficient_lower_bound':1,'coefficient_upper_bound':64,'inequality':'unweighted_sum <= weighted_sum <= 64 * unweighted_sum','conclusion':'For nonnegative finite intersection areas and every coefficient in[1,64], weighted_sum=0 iff every original/clearance intersection area=0. This changes no source-gap acceptance rule.','model_weights_all_positive':True})
negative=[]
for kind in ['missing','extra','zero','negative','nan','infinity','above_cap','changed_positive','wrong_policy','wrong_pair','wrong_bound','wrong_owner_angle','unexpected_field']:
    mm=copy.deepcopy(model)
    if kind=='missing':mm['pair_weights'].pop()
    elif kind=='extra':mm['pair_weights'].append(1.)
    elif kind in ['zero','negative','nan','infinity','above_cap','changed_positive']:mm['pair_weights'][0]={'zero':0.,'negative':-1.,'nan':float('nan'),'infinity':float('inf'),'above_cap':65.,'changed_positive':weights[0]+.001}[kind]
    elif kind=='wrong_policy':mm['weight_policy']['noncollision_decay']=.9
    elif kind=='wrong_pair':mm['pairs'][0],mm['pairs'][1]=mm['pairs'][1],mm['pairs'][0]
    elif kind=='wrong_bound':mm['bounds'][0][0]+=1
    elif kind=='wrong_owner_angle':mm['owners'][18]['angle_coordinate']=67
    else:mm['extra']=True
    caught=False
    try:verify(mm,lib,modes,values,weights)
    except AssertionError:caught=True
    assert caught;negative.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',negative)
for name in ['optimizer-controls.json','tool-provenance.json','physical-mode-controls.json']:
    shutil.copyfile(SOURCE/'audit'/name,OUT/name)
for name,r in load(OUT/'tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256']
process=load(ROOT/'output/h5-weighted-mixed-rows-model-preparation-process-20261107/process.json');assert process['closed'] and process['passed'];charge=prior['complete_preparation_seconds']+process['complete_seconds']
inputs=[Path(__file__),BASE/'weight-update-rounding-diagnostic.json',ROOT/'output/audit_h5_weighted_mixed_rows_model_20261107.py',ROOT/'output/h5-weighted-mixed-rows-model-audit-process-20261107/process.json',ROOT/'output/h5-weighted-mixed-rows-model-preparation-process-20261107/process.json']+[ROOT/'output'/n for n in ['h5_weighted_original_model_20261107.py','h5_weighted_original_readback_20261107.py','h5_original_overlap_gradient_v2_20261107.py','h5_mixed_rows_continuous_readback_20261107.py']]+[SOURCE/n for n in ['plan.json','library.json','initial-mode-values.json','initial-objective.json','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json','audit/physical-mode-controls.json']]+[BASE/n for n in ['plan.json','checks.json','library.json','model.json','initial-state.json','initial-weight-transition.json','initial-objective.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent source-ring transforms and both original/clearance pair intersections, all528 initial coefficients and15 complete528-weight update controls including saturation/extreme finite losses. Independently accumulate weighted scalar gradients and two81-coordinate/two-step derivative controls,147 mode/full-score controls,528 isolated-positive-term controls,positive-coefficient zero-equivalence proof and13 corrupted-model controls. Only the original unoptimized initializer is consumed. Verification only; no optimizer.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'pair_coefficients_verified':528,'scalar_weighted_gradient_terms':scalar_terms,'independent_central_coordinates':162,'independent_central_samples':324,'owner_mode_full_scores':bindings,'weight_update_vectors':15,'weight_update_coefficients':15*528,'positive_term_controls':528,'corruption_controls':len(negative),'positive_weight_zero_equivalence_verified':True,'unoptimized_source_initializer_exact':True,'weighted_objective_mm2':energy,'unweighted_objective_mm2':details['unweighted_objective_mm2'],'minimum_initial_weight':min(weights),'maximum_initial_weight':max(weights),'complete_preparation_seconds':charge,'library_sha256':digest(BASE/'library.json'),'model_sha256':digest(BASE/'model.json'),'initial_state_sha256':digest(BASE/'initial-state.json'),'optimizer_calls':0,'uniform_weight_call_reopened':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
