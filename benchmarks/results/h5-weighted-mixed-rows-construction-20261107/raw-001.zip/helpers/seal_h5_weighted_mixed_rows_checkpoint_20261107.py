"""Preserve weighted exact geometry, checker correction and finite search."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-weighted-mixed-rows-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-weighted-mixed-rows-model-20261107';F=BASE/'response-audit';D=BASE/'audit-v2'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-mixed-rows-continuous-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==4 and front['source_pair_failures']==49 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-weighted-mixed-rows-model-preparation-process-20261107','h5-weighted-mixed-rows-model-audit-process-20261107','h5-weighted-mixed-rows-model-audit-v2-process-20261107','h5-weighted-mixed-rows-response-audit-process-20261107','h5-mixed-rows-main-sync-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*weighted*20261107.py','diagnose_h5_weight_update_rounding_20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_weighted_mixed_rows_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','weight-update-rounding-diagnostic.json']"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
runtime={name:r['sha256'] for name,r in load(D/'tool-provenance.json')['tool_files'].items()}
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'checks.json','model-audit.json'),(D/'derivative-controls.json','derivative-controls.json'),(D/'weight-update-controls.json','weight-update-controls.json'),(D/'zero-equivalence-proof.json','zero-equivalence-proof.json'),(D/'negative-controls.json','negative-controls.json'),(BASE/'weight-update-rounding-diagnostic.json','rounding-diagnostic.json'),(ROOT/'output/h5-weighted-mixed-rows-model-audit-process-20261107/process.json','preserved-failed-audit-process.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-03-unweighted-source-checks.json','source-failures.json'),(BASE/'search/process.json','closed-process.json'),(ROOT/'output/h5-mixed-rows-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'cross_pair_boundary_batching_preflight_required','proposal':'Assess batching clipped boundary integration across all active owner/pair terms, while preserving the existing exact per-edge integral and shared-boundary half contribution. Current code vectorizes edges within each interaction but still invokes Shapely intersection and collection handling separately for every active directed pair.','reason':'The new weighted model remains invalid and all four10-second calls stop on time. Its exact geometry is independently audited, so a numerical/performance-only preflight can determine whether cross-pair batching reduces evaluation overhead without changing any candidate, objective or derivative. No speedup is assumed.','requirements':['Bind the current per-pair vector implementation and weighted model; preserve their source and every closed search result.','Retain explicit source-edge, interaction, owner and coefficient mappings through empty/point/line/multiline/collection decomposition. Degenerate edges contribute zero. Shared collinear boundary uses exactly the current half convention.','Independently compare all directed interaction integrals, all weighted owner gradients, source/clearance scores and central derivatives on frozen validation cases. Include actual boundary contacts, containment, empty and multipart intersections and maximum allowed weights.','Measure alternating timings on the same frozen unoptimized and saved validation cases under CCD1, one BLAS thread, with no optimizer or candidate mutation. Record every timing and numerical tolerance before drawing a speed conclusion.','A faster kernel alone does not authorize restarting or extending a closed weighted/unweighted call. Any later packing method requires a separately specified mechanism, complete accounting and finite contract; no such method or call is prepared here.'],'new_kernel_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Weighted mixed-row construction — 2026-11-07

The new weighted original-geometry model passes independent checks and closes
its finite four-epoch search. It still has no valid full layout: the best
unweighted candidate fails **49 original pairs**, with **28,207.754973 mm²**
overlap. Fixed-part and stock checks pass. H2/H5 remain open at **60%**
completed milestone weight; no native call or allocation exclusion follows.

## Positive weights preserve the original conditions

The source geometry, hard domains, 33 moving originals, 81 parameters and all
528 moving pairs are unchanged from the [mixed-row model](h5-mixed-rows-continuous-construction-20261107.md).
Only its unoptimized initializer is consumed; its complete preparation is
charged. No optimized ancestor or closed uniform-weight call is reopened.

Each pair has one coefficient multiplying both original-outline and certified
clearance-outline overlap and every corresponding gradient contribution.
Coefficients stay in **[1, 64]**. The frozen update multiplies colliding terms
by `1.2 + 0.8 × (loss / maximum loss)` and decays noncolliding terms by 0.95,
with the stated floor and ceiling. An initial update gives 33 nonunit weights,
between 1 and 2. [The positive-coefficient proof]({NAME}/zero-equivalence-proof.json)
establishes `unweighted ≤ weighted ≤ 64 × unweighted`, so zero weighted overlap
cannot hide a nonzero term. Original-source acceptance remains separate.

[Independent model checks]({NAME}/model-audit.json) reconstruct all 528
coefficients, 147 mode/full-score controls, 132 scalar gradient terms and
**324 central samples over 162 coordinates**. [Both derivative steps pass]({NAME}/derivative-controls.json),
including a control using weights up to 64. Fifteen update cases verify
**7,920 coefficients**, including floor, ceiling and extreme finite losses.
All 528 isolated positive terms remain detectable, and thirteen corrupted
models are rejected. The original unoptimized initializer is byte-equivalent
in geometry and coordinates. Complete consumed preparation is **9.437444 s**.

## Preserved verifier failure and exact rounding correction

The [first audit failed]({NAME}/preserved-failed-audit-process.json) because
its algebraically equivalent update formula multiplied the loss by 0.8 before
dividing by the maximum, while the model normalizes first. A
[separate diagnostic]({NAME}/rounding-diagnostic.json) finds 79 coefficient
differences, at most two binary64 steps, over all 7,920 controls. It reconstructs
each specified operation from exact rational values and reproduces every actual
coefficient. The versioned audit uses that independent rounding oracle.
The original failure, checker and process remain preserved; model, weights
and initializer are unchanged. No optimization preceded the passing audit.

## Four closed weighted problems and two progress measures

The declared pipeline permits four ten-second calls within preparation-inclusive
60/90-second limits. Each later epoch updates coefficients from the previous
weighted winner, then scores the current physical mode vector and every
distinct single-owner neighbor. Weighted-objective and full-vector ordering
select the next unseen coefficient/mode problem. The first change affects
bracket8, the second insert8; the final epoch retains its modes with different
coefficients. These are four distinct weighted problems, not four distinct
physical mode vectors.

Every evaluation tracks weighted and unweighted progress independently. Every
improvement of either measure is retained. [Response replay]({NAME}/response-audit.json)
verifies **237 proposal scores, 1,584 runtime weight updates and 388 retained
points**, reconciling 455 recorded function evaluations. The two winners differ
in two epochs. All **eight full66 source readbacks** reconstruct 1,380 same-sheet
pairs, 264 stock edges, 90 holes and 10,026 hole vertices; fixed-part and stock
checks pass throughout. The unweighted winners fail 51, 54, 49 and 49 pairs.

The best unweighted objective is 57,660.128728 mm². Its
[49 source failures]({NAME}/source-failures.json) comprise 44 positive
intersections and five clearance-only failures. The final weighted winner is
retained separately: it fails 51 pairs and has 28,330.845832 mm² original
overlap. [Both measures and every epoch]({NAME}/epoch-reconciliation.json)
remain explicit; lower penalty is not material savings or validity.

The declared epoch limit closes the whole search. Algorithm/shared totals are
**54.481227/54.556267 s**, including complete preparation. Slice overruns of
0.069841, 0.005191, 0.073293 and 0.060825 s are preserved. All five
[search processes close]({NAME}/closed-process.json), with 94,785,536 bytes
peak aggregate committed memory. None of these calls may resume.

## Next numerical preflight and repository state

[The next preflight]({NAME}/next-step.json) assesses batching the exact
boundary integral across active pair interactions. The existing kernel already
vectorizes edges within each interaction; the proposed distinction is batching
across those interactions. Every edge/owner/weight mapping and shared-boundary
convention needs independent checks before alternating timings on frozen cases.
This is a numerical/performance review only: no new kernel or optimizer is
prepared, and a faster evaluator alone does not authorize a closed-call restart.

[The two prior checkpoints reached main]({NAME}/prior-main-push-receipt.json)
at d8aa6a90 after all six preceding CI jobs passed, preserving all 52 protected
remote files. Fresh main CI42366837555 is queued at that receipt. This checkpoint
awaits its ordinary push gate. Four earlier fixed arrangements and 440
allocations remain unresolved. Full66 source/native/material validity,
production parity and the unchanged H5 matrix remain required. H2 retains its
original gate and reserved vectors. Product code, README and releases are unchanged.

[Raw evidence]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json)
and [pinned runtime files]({NAME}/runtime-bindings.json) preserve the failure,
correction, exact model and closed outcomes.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 weighted mixed-row construction:** [independent weighted-model and response audits]({link}) retain all 528 original/clearance pair terms, hard stock/fixed domains and the unoptimized source initializer. Positive weights in [1,64] preserve zero-overlap equivalence. The original verifier rounding failure remains preserved; exact rational reconstruction reproduces all 7,920 update coefficients, with 79 old-order differences of at most two binary64 steps and no model change. Model checks cover 147 mode scores, 132 scalar gradient terms, 324 central samples, 528 positive-term controls and thirteen corruptions. Four distinct weighted problems and 237 proposal scores close at the declared epoch limit; 1,584 runtime coefficients, 388 retained points, 455 evaluation counters and both winners in all four epochs replay. The best unweighted candidate still fails 49 pairs with 28,207.754973 mm² original overlap; fixed-part and stock checks pass. Complete preparation is 9.437444 s and algorithm/shared totals are 54.481227/54.556267 s; all slice overruns remain and every process closes. No native call or exclusion follows. Next independently assess cross-pair batching of the exact boundary integral, with frozen-case numerical checks and alternating timings only; no new kernel or optimizer exists and no closed call may resume. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Prior checkpoints 15f55b9a and d8aa6a90 reached main normally after all six prior CI checks passed, preserving 52 remote files; fresh CI42366837555 is queued at the push receipt. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [weighted mixed-row construction](../benchmarks/results/{NAME}.md).
The exact original/clearance model retains every pair and all hard stock/fixed
domains. Bounded positive weights cannot hide an overlap. Independent checks
verify 7,920 update coefficients, 147 mode scores and 324 derivative samples;
the original checker rounding failure and exact correction remain preserved.
Four distinct weighted problems close at their declared limit. All 388 retained
points and eight full66 winner readbacks replay; 455 evaluation counters and
1,584 runtime coefficients reconcile. The best unweighted candidate still
fails 49 pairs with 28,207.754973 mm² overlap; all fixed/stock checks pass.
Complete preparation is 9.437444 s and algorithm/shared totals are
54.481227/54.556267 s, with all processes closed and overruns retained.
No full66 witness, native call or allocation exclusion follows. Next assess
cross-pair batching of exact boundary integration through numerical controls
and alternating timings only; no new kernel or optimizer is prepared.
Four earlier arrangements and 440 allocations remain. H2/H5 stay at 60%
completed milestone weight. Both prior checkpoints reached main d8aa6a90 after
all six previous CI jobs passed, preserving all 52 protected remote files.
Fresh main CI42366837555 is queued at the receipt; this checkpoint awaits the
ordinary push gate. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
