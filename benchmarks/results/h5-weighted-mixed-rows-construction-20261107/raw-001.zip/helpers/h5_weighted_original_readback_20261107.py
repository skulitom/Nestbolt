"""Independent complete weighted-model schema and coefficient readback."""
import math
from h5_mixed_rows_continuous_readback_20261107 import verify as verify_geometry

def verify(model,library,modes,values,weights):
    assert verify_geometry(model,library,modes,values)
    assert set(model)=={'families','owners','pairs','fixed_source_rows','parameters','bounds','initial','objective_weights','pair_weights','weight_policy'}
    assert len(weights)==len(model['pair_weights'])==len(model['pairs'])==528
    assert model['pair_weights']==list(weights)
    assert all(type(w) in (int,float) and math.isfinite(w) and 1<=w<=64 for w in model['pair_weights'])
    assert model['weight_policy']=={'minimum':1.,'maximum':64.,'collision_multiplier_base':1.2,'collision_multiplier_scale':.8,'noncollision_decay':.95,'loss':'original_plus_clearance_area','positive_threshold':0.}
    return True
