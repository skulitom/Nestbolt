from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,math
from h5_weighted_original_model_20261107 import update_weights
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
losses=load(BASE/'initial-weight-transition.json')['pair_losses_mm2'];cases=[[0.]*528,[1.]*528,[float(i) for i in range(528)],losses,[1e308 if i%2 else 0. for i in range(528)]];befores=[[1.]*528,[64.]*528,[1.+i%64 for i in range(528)]];records=[];maximum=0.;checked=0
for ai,before in enumerate(befores):
    for bi,ll in enumerate(cases):
        peak=max(ll);actual=update_weights(before,ll)
        for index,(w,a,v) in enumerate(zip(before,ll,actual)):
            legacy=max(1.,w*.95) if a==0 else min(64.,max(1.,w*(1.2+.8*a/peak)))
            if a==0:exact=float(F(w)*F(.95))
            else:
                ratio=float(F(a)/F(peak));scaled=float(F(.8)*F(ratio));factor=float(F(1.2)+F(scaled));exact=float(F(w)*F(factor))
            exact=min(64.,max(1.,exact));assert exact==v;checked+=1
            if legacy!=v:
                ulps=abs(legacy-v)/math.ulp(v);maximum=max(maximum,ulps);records.append({'before_case':ai,'loss_case':bi,'coefficient':index,'legacy':legacy,'actual':v,'difference_ulps':ulps})
assert records and maximum<=2
result={'passed':True,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),ROOT/'output/h5_weighted_original_model_20261107.py',ROOT/'output/audit_h5_weighted_mixed_rows_model_20261107.py',BASE/'initial-weight-transition.json',ROOT/'output/h5-weighted-mixed-rows-model-audit-process-20261107/process.json']},'cause':'The original verifier multiplied loss by0.8 before dividing by peak, whereas the declared implementation normalizes loss first. Algebraically equal expressions can round differently. Exact rational reconstruction of each specified binary64 operation reproduces every actual coefficient.','coefficients_checked':checked,'legacy_differences':len(records),'maximum_legacy_difference_ulps':maximum,'records':records,'model_changed':False,'weights_changed':False,'optimizer_calls':0}
with (BASE/'weight-update-rounding-diagnostic.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print({k:v for k,v in result.items() if k not in ['inputs','records']})
