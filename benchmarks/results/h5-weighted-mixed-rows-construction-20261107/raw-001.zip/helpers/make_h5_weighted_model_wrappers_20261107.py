from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind,old,new,changes in [
    ('prepare','run_h5_mixed_roof_source_preparation_20261107.py','run_h5_weighted_mixed_rows_model_preparation_20261107.py', [('h5-mixed-roof-source','h5-weighted-mixed-rows-model'),('prepare_h5_mixed_roof_source','prepare_h5_weighted_mixed_rows_model')]),
    ('audit','run_h5_mixed_rows_continuous_model_audit_20261107.py','run_h5_weighted_mixed_rows_model_audit_20261107.py',[('h5-mixed-rows-continuous-model','h5-weighted-mixed-rows-model'),('audit_h5_mixed_rows_continuous_model','audit_h5_weighted_mixed_rows_model')])]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,a;s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
