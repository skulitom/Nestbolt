"""Positive bounded pair weights on exact original and clearance overlap."""
import math
import numpy as np
import shapely
from h5_movable_roof_model_20261107 import compile_model as unweighted_model, Objective as Unweighted
from h5_vector_boundary_gradient_20261107 import boundary_gradient

POLICY={'minimum':1.,'maximum':64.,'collision_multiplier_base':1.2,'collision_multiplier_scale':.8,'noncollision_decay':.95,'loss':'original_plus_clearance_area','positive_threshold':0.}

def check_weights(weights,count):
    assert len(weights)==count
    assert all(type(w) in (float,int) and math.isfinite(w) and 1.<=w<=64. for w in weights)

def update_weights(weights,losses):
    check_weights(weights,len(losses));losses=np.asarray(losses,dtype=float)
    assert losses.ndim==1 and np.all(np.isfinite(losses)) and np.all(losses>=0)
    peak=float(np.max(losses)) if len(losses) else 0.
    out=[]
    for w,loss in zip(weights,losses):
        factor=1.2+.8*(float(loss)/peak) if loss>0 else .95
        out.append(float(min(64.,max(1.,float(w)*factor))))
    check_weights(out,len(weights));return out

def compile_model(library,modes,values,weights):
    check_weights(weights,len(library['pairs']))
    model=unweighted_model(library,modes,values)
    model.update(pair_weights=list(map(float,weights)),weight_policy=POLICY.copy())
    return model

class Objective(Unweighted):
    def __init__(self,model):
        super().__init__(model);check_weights(model['pair_weights'],len(model['pairs']))
        assert model['weight_policy']==POLICY
        self.weights=np.asarray(model['pair_weights'],dtype=float)

    def pair_losses(self,values):
        losses=np.zeros(len(self.model['pairs']))
        for entries in self.geometry(values,False):
            shapes=np.asarray([e[1] for e in entries],dtype=object)
            losses+=shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]))
        assert np.all(np.isfinite(losses)) and np.all(losses>=0)
        return losses

    def score(self,values):return float(np.dot(self.weights,self.pair_losses(values)))

    def evaluate(self,values,details=False):
        gradient=np.zeros(self.model['parameters']);levels=[];weighted=[];records=[]
        losses=np.zeros(len(self.model['pairs']));segments=0;shared=0.
        for kind,entries in zip(['original','clearance'],self.geometry(values)):
            shapes=np.asarray([e[1] for e in entries],dtype=object)
            areas=shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]))
            losses+=areas;levels.append(float(np.sum(areas)));weighted.append(float(np.dot(areas,self.weights)))
            for index in np.flatnonzero(areas>0):
                i,j=self.model['pairs'][index];weight=self.weights[index]
                if details:records.append({'kind':kind,'owners':[i,j],'area_mm2':float(areas[index]),'weight':float(weight)})
                for own,other in [(i,j),(j,i)]:
                    vertices,poly,lines,pivot=entries[own]
                    g,n,coincident=boundary_gradient(vertices,lines,entries[other][1],pivot)
                    gradient[2*own:2*own+2]+=weight*g[:2];owner=self.model['owners'][own]
                    if owner['angle_coordinate'] is not None:gradient[owner['angle_coordinate']]+=weight*g[2]/owner['angle_scale_mm']
                    segments+=n;shared+=coincident
        value=sum(weighted);assert math.isfinite(value) and np.all(np.isfinite(gradient))
        if details:return value,gradient,{'unweighted_objective_mm2':sum(levels),'original_overlap_area_mm2':levels[0],'clearance_overlap_area_mm2':levels[1],'weighted_original_overlap_area_mm2':weighted[0],'weighted_clearance_overlap_area_mm2':weighted[1],'pair_losses_mm2':losses.tolist(),'positive_terms':records,'clipped_segments':segments,'coincident_boundary_length_mm':shared}
        return value,gradient
