from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_weighted_mixed_rows_model_20261107.py').read_text(encoding='utf-8')
s=s.replace('from itertools import product','from itertools import product\nfrom fractions import Fraction as F')
s=s.replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
a="""        if a==0:out.append(max(1.,w*.95))
        else:out.append(min(64.,max(1.,w*(1.2+.8*a/peak))))"""
b="""        if a==0:value=float(F(w)*F(.95))
        else:
            ratio=float(F(a)/F(peak));scaled=float(F(.8)*F(ratio));factor=float(F(1.2)+F(scaled));value=float(F(w)*F(factor))
        out.append(min(64.,max(1.,value)))"""
assert a in s;s=s.replace(a,b)
a="inputs=[Path(__file__),ROOT/'output/h5-weighted-mixed-rows-model-preparation-process-20261107/process.json']"
b="inputs=[Path(__file__),BASE/'weight-update-rounding-diagnostic.json',ROOT/'output/audit_h5_weighted_mixed_rows_model_20261107.py',ROOT/'output/h5-weighted-mixed-rows-model-audit-process-20261107/process.json',ROOT/'output/h5-weighted-mixed-rows-model-preparation-process-20261107/process.json']"
assert a in s;s=s.replace(a,b)
with (ROOT/'output/audit_h5_weighted_mixed_rows_model_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_weighted_mixed_rows_model_audit_20261107.py').read_text(encoding='utf-8').replace('h5-weighted-mixed-rows-model-audit-process','h5-weighted-mixed-rows-model-audit-v2-process').replace('audit_h5_weighted_mixed_rows_model_20261107.py','audit_h5_weighted_mixed_rows_model_v2_20261107.py')
with (ROOT/'output/run_h5_weighted_mixed_rows_model_audit_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
