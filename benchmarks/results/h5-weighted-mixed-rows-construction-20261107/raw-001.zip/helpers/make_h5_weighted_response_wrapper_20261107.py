from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_mixed_rows_continuous_response_audit_20261107.py').read_text(encoding='utf-8')
s=s.replace('h5-mixed-rows-continuous-response-audit-process','h5-weighted-mixed-rows-response-audit-process').replace('audit_h5_mixed_rows_continuous_response','audit_h5_weighted_mixed_rows_response')
with (ROOT/'output/run_h5_weighted_mixed_rows_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
