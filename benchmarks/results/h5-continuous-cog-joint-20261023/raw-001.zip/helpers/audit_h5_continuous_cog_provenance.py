"""Match reused inputs to committed evidence and derive the cog cap from the original job."""
from collections import Counter
from datetime import datetime,timezone
from build_h5_continuous_cog_joint import ROOT,SRC,OLD,REG,OUT,load,write,digest
def main():
    checks=[]
    for report,root,names in [('h5-one-cog-release-joint-20261023',OLD,['plan.json','candidates.json','mapping.json','adjacency.bin.gz','audit/checks.json']),('h5-one-cog-continuous-regions-20261023',REG,['plan.json','candidates.json','audit/plan.json','audit/checks.json','audit/mapping.json','next-step.json'])]:
        manifest=ROOT/'benchmarks/results'/report/'raw-manifest.json';data=load(manifest);hashes={r['path']:r['sha256'] for r in data['files']+data['aliases']}
        for name in names:
            p=root/name;key=root.name+'/'+name;assert digest(p)==hashes[key];checks.append({'source':p.relative_to(ROOT).as_posix(),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key,'sha256':hashes[key]})
    pool=load(OUT/'candidates.json');mp=load(OUT/'mapping.json');job=load(SRC/'job.json');quantities={p['id']:p['quantity'] for p in job['parts']};assert quantities=={'bracket':12,'frame':18,'cog':15,'insert':21}
    for g in mp['core_groups']:
        counts=Counter(pool[i]['placement']['part_id'] for i in g['fixed_candidates']);assert counts==Counter(frame=18,cog=14) and quantities['cog']-counts['cog']==1
    assert mp['family_caps']=={'bracket':quantities['bracket'],'cog':1,'insert':quantities['insert']} and len(mp['core_groups'])==30
    result={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'source_members_matching_committed_evidence':checks,'original_job_sha256':digest(SRC/'job.json'),'original_cog_quantity':15,'fixed_cogs_in_each_core':14,'derived_maximum_variable_cogs':1,'all_30_core_counts_verified':True,'other_original_family_caps_unchanged':True};write(OUT/'provenance-audit.json',result);print({'passed':True,'committed_source_members_verified':len(checks),'original_quantity_minus_fixed_cogs':1},flush=True)
if __name__=='__main__':main()
