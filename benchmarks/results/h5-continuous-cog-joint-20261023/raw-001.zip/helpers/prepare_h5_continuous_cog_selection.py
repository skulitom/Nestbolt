"""Prepare one new verified-candidate repair solve with a count-derived cog clique."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/reduce_h5_one_cog_release_joint.py').read_text()
s=replace(s,'build_h5_one_cog_release_joint','build_h5_continuous_cog_joint')
s=replace(s,'Order by original degree then global index.','Order by complete constraint-graph degree then global index, including the independently justified cog-cap clique.')
s=replace(s,'then compress the exact induced graph by first-fit lowest-index clique expansion.','then seed the exact derived cog clique and compress the induced graph by first-fit lowest-index clique expansion. The20-second compression timer includes the seeded clique.')
s=replace(s,"remaining=projected.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(projected) if a];heapq.heapify(heap);cliques=[];covered=0;start=time.perf_counter()",'''start=time.perf_counter();remaining=projected.copy();cogclique=[j for j,i in enumerate(globals_kept) if pool[i]['placement']['part_id']=='cog'];cogmask=sum(1<<j for j in cogclique)
    assert mp['family_caps']['cog']==1 and len(cogclique)>=2 and all(not((cogmask^(1<<j))&~projected[j]) for j in cogclique)
    cliques=[cogclique];covered=0
    for j in cogclique:
        before=remaining[j].bit_count();remaining[j]&=~cogmask;covered+=before-remaining[j].bit_count()
    assert covered==len(cogclique)*(len(cogclique)-1)
    heap=[(-a.bit_count(),i) for i,a in enumerate(remaining) if a];heapq.heapify(heap)''')
s=replace(s,"'compression_seconds':compression_seconds,","'compression_seconds':compression_seconds,'seeded_derived_cog_clique_size':len(cogclique),'derived_cog_clique_already_implied_by_original_cap':True,")
put('reduce_h5_continuous_cog_joint.py',s)
s=(ROOT/'output/seed_h5_one_cog_release_joint.py').read_text();s=replace(s,'build_h5_one_cog_release_joint','build_h5_continuous_cog_joint');put('seed_h5_continuous_cog_joint.py',s)
s=(ROOT/'output/solve_h5_one_cog_release_joint.py').read_text();s=replace(s,'h5-one-cog-release-joint-20261023','h5-continuous-cog-joint-20261023');s=replace(s,"domains={f:[0,caps[f]] for f in names}","domains={f:[0,caps[f]] for f in names}\n    assert caps['cog']==1 and audit['derived_cog_clique_justified_by_cap'] and mp['fixed_family_counts']=={'frame':18,'cog':14}")
s=replace(s,"'zero_variable_cog_permitted':True,","'zero_variable_cog_permitted':True,'derived_cog_clique_requires_original_cog_cap':1,")
s=replace(s,"assert audit['passed'] and load(RED/'checks.json')","assert audit['passed'] and load(BASE/'provenance-audit.json')['passed'] and load(RED/'checks.json')")
s=replace(s,"['plan.json','candidates.json','mapping.json','audit/checks.json']","['plan.json','candidates.json','mapping.json','audit/checks.json','provenance-audit.json']")
put('solve_h5_continuous_cog_joint.py',s)
s=(ROOT/'output/audit_h5_one_cog_release_layouts.py').read_text();s=replace(s,'build_h5_one_cog_release_joint','build_h5_continuous_cog_joint');s=replace(s,"'variable_objective':r['objective'],","'variable_objective':r['objective'],'new_continuous_cog_poses_selected':sorted(i for i in sm if i in set(mp['new_candidates'])),")
put('audit_h5_continuous_cog_layouts.py',s)
print('Prepared fresh reduction, preserved baselines, one bounded solver and original-layout audit; no solve called.')
