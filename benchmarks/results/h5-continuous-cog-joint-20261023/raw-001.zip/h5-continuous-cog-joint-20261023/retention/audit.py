"""Describe retained new geometry and select review cores without claiming a layout improvement."""
from collections import Counter
from datetime import datetime,timezone
import math,shutil
from audit_h5_cog_lattices import shape
from build_h5_continuous_cog_joint import ROOT,SRC,REG,OUT as BASE,load,write,digest
OUT=BASE/'retention'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');mp=load(BASE/'reduced/mapping.json');pool=load(BASE/'candidates.json');rows=load(REG/'new-pose-diagnostics.json');kept=set(mp['candidates']);new=set(mp['new_candidates']);oldcount=mp['source_original_candidate_count'];replacements=load(BASE/'reduced/substitutions.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    inputs=[BASE/n for n in ['candidates.json','reduced/mapping.json','reduced/substitutions.json','reduced/checks.json','solve/result.json','layout-audit/checks.json']]+[REG/'new-pose-diagnostics.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read the completed reduction and original-layout checks. Count genuinely retained new cog poses and substitutions; do not continue either search. For a next contact-generation review, rank retained new poses that expose old bracket choices by descending (gained choices minus lost choices), then gain, then fewer lost choices, then candidate id. Select at most one pose per generating core, at most six total. Keep the complete ranking and exact resulting 33-part cores. This is a transparent diagnostic ranking of candidate positions, not an area objective, inventory count, native qualification or new solver result.','maximum_review_cores':6,'solver_calls':0,'new_poses_generated':0})
    retained=[r for r in rows if r['candidate'] in kept];ranked=sorted([r for r in retained if r['newly_available_bracket_candidates']],key=lambda r:(-(len(r['newly_available_bracket_candidates'])-len(r['newly_blocked_bracket_candidates'])),-len(r['newly_available_bracket_candidates']),len(r['newly_blocked_bracket_candidates']),r['candidate']));chosen=[];used=set();pairs=0
    for r in ranked:
        core=r['core_group']
        if core in used:continue
        if len(chosen)>=6:break
        used.add(core);fixed=sorted(mp['core_groups'][core]['fixed_candidates']+[r['candidate']]);assert len(fixed)==len(set(fixed))==33 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15);gs={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixed};minimum=math.inf
        for at,i in enumerate(fixed):
            for j in fixed[at+1:]:
                if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
                pairs+=1;distance=gs[i].distance(gs[j]);minimum=min(minimum,distance);assert gs[i].disjoint(gs[j]) and distance>=job['clearance']-1e-7
        chosen.append({'index':len(chosen),'source_core_group':core,'new_cog_candidate':r['candidate'],'fixed_candidates':fixed,'gained_bracket_candidate_positions':len(r['newly_available_bracket_candidates']),'lost_bracket_candidate_positions':len(r['newly_blocked_bracket_candidates']),'net_bracket_candidate_positions':len(r['newly_available_bracket_candidates'])-len(r['newly_blocked_bracket_candidates']),'minimum_original_distance_mm':minimum,'native_margin_qualified':False})
    write(OUT/'ranked-new-cogs.json',ranked);write(OUT/'review-cores.json',chosen)
    checks={'passed':True,'new_poses_before_reduction':len(new),'new_poses_retained':len(new&kept),'old_poses_retained':len(kept-new),'new_poses_removed':len(new-kept),'new_removed_replaced_by_old':sum(r['removed'] in new and r['replacement'] not in new for r in replacements),'new_removed_replaced_by_new':sum(r['removed'] in new and r['replacement'] in new for r in replacements),'old_removed_replaced_by_new':sum(r['removed'] not in new and r['replacement'] in new for r in replacements),'retained_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in kept)),'retained_new_exposing_old_bracket_choices':len(ranked),'retained_new_with_positive_bracket_candidate_net':sum(len(r['newly_available_bracket_candidates'])>len(r['newly_blocked_bracket_candidates']) for r in retained),'review_cores':len(chosen),'review_core_original_geometry_pairs':pairs,'new_poses_selected_by_any_returned_layout':sum(bool(r['new_continuous_cog_poses_selected']) for r in load(BASE/'layout-audit/checks.json')['records']),'solver_calls':0,'new_layout_qualification':False,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True);print(chosen,flush=True)
if __name__=='__main__':main()
