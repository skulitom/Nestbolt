"""Independent bounds-scan graph audit, including a separately justified count-derived clique."""
from collections import Counter
from datetime import datetime,timezone
import shutil,time
import numpy as np
import shapely
from audit_h5_cog_lattices import shape
from build_h5_continuous_cog_joint import ROOT,SRC,OLD,REG,OUT as BASE,load,write,digest,read_graph
OUT=BASE/'audit'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    start=time.perf_counter();mp=load(BASE/'mapping.json');oldmp=load(OLD/'mapping.json');pool=load(BASE/'candidates.json');oldpool=load(OLD/'candidates.json');ids=mp['candidates'];n0=len(oldmp['candidates']);assert pool[:len(oldpool)]==oldpool and ids[:n0]==oldmp['candidates'] and mp['core_groups']==oldmp['core_groups'] and mp['mapped_seeds']==oldmp['mapped_seeds'] and mp['compatible_groups'][:n0]==oldmp['compatible_groups']
    source=read_graph(OLD/'adjacency.bin.gz',n0);expected=source.copy()+[0]*(len(ids)-n0);actual=read_graph(BASE/'adjacency.bin.gz',len(ids));job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);bb=shapely.bounds(gs);families=np.asarray([pool[i]['placement']['part_id'] for i in ids]);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);poss=exact=edges=0
    for j in range(n0,len(ids)):
        assert families[j]=='cog';eligible=(families!='cog')&(sheets==sheets[j]);poss+=int(eligible.sum());a,b,c,d=bb[j];dx=np.maximum(np.maximum(bb[:,0]-c,a-bb[:,2]),0);dy=np.maximum(np.maximum(bb[:,1]-d,b-bb[:,3]),0);ix=np.flatnonzero(eligible&(dx*dx+dy*dy<=(clear+1e-7)**2));exact+=len(ix);ds=shapely.distance(gs[ix],gs[j])
        for k,v in zip(ix,ds):
            if v<clear-1e-7:k=int(k);expected[j]|=1<<k;expected[k]|=1<<j;edges+=1
    cogs=list(map(int,np.flatnonzero(families=='cog')));mask=sum(1<<j for j in cogs);assert mp['family_caps']['cog']==mp['variable_family_caps']['cog']==1
    # Every feasible conditional assignment has at most one member of this
    # set. Its complete clique is equivalent under the unchanged count cap.
    for j in cogs:expected[j]|=mask^(1<<j)
    assert expected==actual and all(not((v>>j)&1) for j,v in enumerate(actual));oldmask=(1<<n0)-1;changed=0
    for j in range(n0):
        difference=(actual[j]&oldmask)^source[j]
        if difference:assert families[j]=='cog' and not(difference&~mask);changed+=difference.bit_count()
    local={i:j for j,i in enumerate(ids)};seeds=0
    for seed in mp['mapped_seeds']:
        chosen=seed['selected_variable_candidates'];js=[local[i] for i in chosen];selected=sum(1<<j for j in js);counts=Counter(pool[i]['placement']['part_id'] for i in chosen);assert len(chosen)==len(set(chosen))==32 and counts==Counter(bracket=10,cog=1,insert=21)
        assert all(not(actual[j]&selected) and seed['core_group'] in mp['compatible_groups'][j] for j in js)
        assert sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in chosen)==seed['objective']==865862719;fixed=mp['core_groups'][seed['core_group']]['fixed_candidates'];assert Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=14) and len(set(fixed+chosen))==64;seeds+=1
    reported=load(BASE/'result.json');assert reported['new_cog_non_cog_geometric_edges']==edges and reported['total_constraint_graph_edges']==sum(v.bit_count() for v in actual)//2
    checks={'passed':True,'seconds':time.perf_counter()-start,'all_input_hashes_verified':True,'all_original_pool_records_and_core_mappings_preserved':True,'variable_poses':len(ids),'new_pose_non_cog_same_sheet_possibilities':poss,'independent_new_pose_exact_distances':exact,'new_cog_non_cog_geometric_edges':edges,'old_geometric_edges_inherited_from_unchanged_unreduced_graph':sum(v.bit_count() for v in source)//2,'derived_cog_clique_justified_by_cap':True,'variable_cog_count':len(cogs),'complete_derived_cog_clique_edges':len(cogs)*(len(cogs)-1)//2,'additional_old_old_cog_edges':changed//2,'total_constraint_graph_edges':reported['total_constraint_graph_edges'],'every_constraint_graph_row_matches':True,'all_30_exact_64_baselines_verified':seeds==30,'seed_score':865862719,'full_score':945862719,'zero_variable_cogs_remain_allowed':True,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
