"""Audit source controls and all saved new-policy native layouts without reruns."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import ast,copy,difflib,itertools,json,math,re,shutil,subprocess,sys,traceback
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-frontier-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=probe/'policy-native-audit';out.mkdir();cache={};records=[];pairs=0
sys.path.insert(0,str(root/'scripts'));import h5_joint_trace as reader
from h2_import_audit import source_digest
cli=root/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
template=root/'output/check_h5_joint_observer_geometry.py'
nodes=[n for n in ast.parse(template.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['write','validate']]
assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(template),'exec'))
try:
    raw=(probe/'policy-checks/core-tests.log').read_text(encoding='utf-8')
    oldraw=(root/'output/h5-joint-repair-probe-20261018/core-tests.log').read_text(encoding='utf-8')
    witnessraw=(probe/'initial-witness/witness.log').read_text(encoding='utf-8')
    def captured(s):
        result={};name=None
        for line in s.splitlines():
            m=re.match(r'^test (\S+) \.\.\. ',line)
            if m:name=m[1];result[name]=[]
            if name and '_WITNESS ' in line:
                marker=re.search(r'([A-Z_]+_WITNESS) (\{.*)',line)
                if marker:result[name].append([marker[1],json.loads(marker[2])])
        return result
    original=captured(oldraw)|captured(witnessraw);current=captured(raw)
    assert len(original)==166 and len(current)==171,(len(original),len(current))
    for name,values in original.items():assert current[name]==values,name
    baseline=probe/'baseline';work=probe/'candidate';rel='crates/core/src/sheets/vstrip/exchange.rs'
    old=(baseline/rel).read_text(encoding='utf-8');new=(work/rel).read_text(encoding='utf-8')
    test_marker='#[cfg(test)]\nmod tests {'
    assert new.split(test_marker,1)[1].startswith(old.split(test_marker,1)[1].rsplit('\n}',1)[0])
    for start,end in [('    fn provisional_exchange_chain(','    #[cfg(test)]\n    pub(super) fn directed_exchange_window('),
        ('    fn joint_repair_pair(','    #[cfg(test)]\n    pub(super) fn assignment_bridge_window(')]:
        a=old[old.index(start):old.index(end,old.index(start))]
        b=new[new.index(start):new.index(end,new.index(start))];assert a==b,start
    changes=load(probe/'policy-plan.json')['changed_files'];unchanged=[];patch=''
    for p in sorted(baseline.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(baseline).as_posix()
        if rel not in changes:assert digest(p)==digest(work/rel);unchanged.append(rel)
    for rel in changes:
        a=(baseline/rel).read_text(encoding='utf-8') if (baseline/rel).exists() else ''
        b=(work/rel).read_text(encoding='utf-8')
        patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='baseline/'+rel,tofile='candidate/'+rel))
    (out/'candidate.patch').write_text(patch,encoding='utf-8',newline='\n')
    observed=[json.loads(line.split('FRONTIER_POLICY_WITNESS ',1)[1]) for line in raw.splitlines() if 'FRONTIER_POLICY_WITNESS ' in line]
    assert observed
    for i,w in enumerate(observed):
        for name in ['before','after']:
            validate(w['job'],w[name],True,None,{'witness':i,'stage':name})
        stats=w['stats'];attempt=stats.get('joint_repair_attempts',0)
        assert attempt==sum(stats.get('joint_repair_'+name,0) for name in ['completed','failed','expired'])
        assert stats.get('source_frontier_attempts',0)<=stats.get('directed_exchange_attempts',0)
        assert stats.get('joint_exchanges',0)<=stats.get('joint_repair_completed',0)
        assert w['moved']<=4 and stats.get('assignment_bridge_steps',0)<=4
    write(out/'witnesses.json',observed)
    assert source_digest()==load(probe/'preparation.json')['production_digest']
    result={'all_source_and_saved_geometry_checks_passed':True,'native_suite_passed':'171 passed; 0 failed' in raw,
        'prior_tests_exact':166,'prior_witnesses_exact':sum(len(v) for v in original.values()),
        'new_policy_witnesses':len(observed),'CLI_checks':len(records),'filled_outer_pairs':pairs,'records':records,
        'unchanged_other_files':len(unchanged),'shared_provisional_chain_and_joint_helper_exact':True,
        'production_unchanged':True,'absolute_clearance_tolerance_mm':1e-7,'new_searches':0,
        'test_log_sha256':digest(probe/'policy-checks/core-tests.log'),'CLI_sha256':digest(cli)}
    write(out/'checks.json',result);shutil.copyfile(__file__,out/'check.py');shutil.copyfile(template,out/'geometry-template.py')
    print(json.dumps({k:v for k,v in result.items() if k!='records'}),flush=True)
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'completed':records});raise
