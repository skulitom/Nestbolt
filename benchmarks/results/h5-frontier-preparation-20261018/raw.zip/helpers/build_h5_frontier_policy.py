"""Qualify the changed isolated frontier policy, retaining every failed stage."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,traceback
ROOT=Path(__file__).resolve().parents[1];PROBE=ROOT/'output/h5-frontier-probe-20261018'
WORK=PROBE/'candidate';TARGET=ROOT/'output/h5-frontier-target-20261018';OUT=PROBE/'policy-checks';OUT.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=json.loads((PROBE/'policy-plan.json').read_bytes());original=json.loads((PROBE/'preparation.json').read_bytes())
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def run(label,args):
    assert source_digest()==original['production_digest']
    for r in original['source_files']:assert digest(Path(original['old_source'])/r['path'])==r['sha256']
    command=list(map(str,args));started=datetime.now(timezone.utc).isoformat()
    with (OUT/(label+'.log')).open('xb') as log:r=subprocess.run(command,cwd=WORK,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    row={'label':label,'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'log_sha256':digest(OUT/(label+'.log'))}
    records.append(row);write(OUT/'progress.json',records);print(json.dumps(row),flush=True)
    assert r.returncode==0,label
try:
    run('core-tests',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',TARGET,'--','--nocapture','--test-threads=1'])
    run('clippy',['cargo','clippy','--locked','-p','nestbolt-core','--lib','--example','exchange_probe','--target-dir',TARGET,'--','-D','warnings'])
    run('build',['cargo','build','--release','--locked','-p','nestbolt-core','--example','exchange_probe','--target-dir',TARGET])
    shutil.copyfile(TARGET/'release/examples/exchange_probe.exe',PROBE/'frontier-candidate.exe')
    binaries=list((TARGET/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
    shutil.copyfile(binaries[0],OUT/'authored-tests.exe')
    write(OUT/'build.json',{'all_passed':True,'stages':records,'binary_sha256':digest(PROBE/'frontier-candidate.exe'),
        'source_files':{p:digest(WORK/p) for p in plan['changed_files']}})
except BaseException:
    write(OUT/'failure.json',{'error':traceback.format_exc(),'stages':records})
    binaries=list((TARGET/'release/deps').glob('nestbolt_core-*.exe'))
    if 'Running unittests' in (OUT/'core-tests.log').read_text(encoding='utf-8') and len(binaries)==1:shutil.copyfile(binaries[0],OUT/'authored-tests.exe')
    for rel in plan['changed_files']:
        p=OUT/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WORK/rel,p)
    raise
