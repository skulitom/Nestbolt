"""Preserve the passing original-runtime witness before any policy changes."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
ROOT=Path(__file__).resolve().parents[1];PROBE=ROOT/'output/h5-frontier-probe-20261018'
OUT=ROOT/'benchmarks/results/h5-frontier-witness-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
g=load(PROBE/'geometry-checks/checks.json');c=load(PROBE/'initial-witness/checks.json')
assert g['all_saved_geometry_checks_passed'] and c['witness_passed'] and g['runtime_unchanged']
OUT.mkdir()
files={p.relative_to(PROBE).as_posix():p for p in PROBE.rglob('*') if p.is_file()}
for name in ['prepare_h5_frontier_witness.py','check_h5_frontier_witness.py','check_h5_frontier_geometry.py','seal_h5_frontier_witness.py']:
    files['helpers/'+name]=ROOT/'output'/name
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
with zipfile.ZipFile(OUT/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in files.items():z.write(path,name)
with zipfile.ZipFile(OUT/'raw.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
record={'all_members_and_crc_verified':True,'archive':'raw.zip','bytes':(OUT/'raw.zip').stat().st_size,'sha256':digest(OUT/'raw.zip'),'members':inventory}
(OUT/'integrity.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
for source,name in [('preparation.json','preparation.json'),('initial-witness/checks.json','native-checks.json'),
    ('geometry-checks/checks.json','geometry-checks.json'),('geometry-checks/witness.json','witness.json'),
    ('geometry-checks/pair-witnesses.json','pair-witnesses.json'),('witness.patch','witness.patch')]:
    shutil.copyfile(PROBE/source,OUT/name)
print(json.dumps({'sealed':True,'members':len(inventory),'bytes':record['bytes']}))
