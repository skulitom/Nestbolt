"""Use an exposed nonempty source boundary in the isolated joint-repair tail."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-frontier-probe-20261018';WORK=OUT/'candidate'
REL='crates/core/src/sheets/vstrip/exchange.rs';path=WORK/REL
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(ROOT/'benchmarks/results/h5-frontier-witness-20261018/integrity.json')['all_members_and_crc_verified']
shutil.copytree(WORK,OUT/'baseline')
text=path.read_text(encoding='utf-8');old=text;edits=[]
def change(a,b):
    global text
    assert text.count(a)==1,(a[:100],text.count(a));text=text.replace(a,b);edits.append([a,b])
change('    JointRepair,\n}', '    #[cfg_attr(not(test), allow(dead_code))]\n    JointRepair,\n    JointFrontier,\n}')
start=text.index('    pub(super) fn joint_exchange_window(');end=text.index('    // Repair only these two inventories.',start)
methods=text[start:end].replace('joint_exchange_window','source_frontier_window').replace('joint_exchange_chain','source_frontier_chain').replace('ExchangePolicy::JointRepair','ExchangePolicy::JointFrontier')
change('    pub(super) fn joint_exchange_window(',methods+'    #[cfg(test)]\n    pub(super) fn joint_exchange_window(')
change('    fn joint_exchange_chain(','    #[cfg(test)]\n    fn joint_exchange_chain(')
change('ExchangePolicy::AssignmentBridge | ExchangePolicy::JointRepair\n',
       'ExchangePolicy::AssignmentBridge | ExchangePolicy::JointRepair | ExchangePolicy::JointFrontier\n')
change('        let joint = policy == ExchangePolicy::JointRepair;',
       '        let frontier = policy == ExchangePolicy::JointFrontier;\n        let joint = matches!(policy, ExchangePolicy::JointRepair | ExchangePolicy::JointFrontier);')
change('                let proposal_until = self.last_step(exchange_until);',
'''                // Selected members are already absent; returns have not been added.
                // A nonempty exposed source supplies a geometric target. If it is
                // empty, preserve the old crop: forcing an empty last sheet would
                // unnecessarily reject useful exchanges that cannot eliminate it.
                let source_last = if frontier {
                    source_frontier_target(strip, &source, shape.last)
                } else {
                    shape.last
                };
                let proposal_until = self.last_step(exchange_until);''')
change('''                    let repaired = if joint {
                        self.joint_repair_pair(''',
'''                    let repaired = if joint {
                        self.stats.source_frontier_attempts += u64::from(source_last < shape.last);
                        self.joint_repair_pair(''')
change('''                            next_source,
                            shape.last,
                            exchange_until,''','''                            next_source,
                            source_last,
                            exchange_until,''')
helper='''// Use the existing fitted bounds, with the original crop as a hard upper limit.
// Charge this additional scan; its caller retains the absolute phase deadline.
fn source_frontier_target(strip: &Strip, source: &JLayout, original: f32) -> f32 {
    if source.placed_items().is_empty() {
        return original;
    }
    strip.clock.charge(Work::RegisteredItem, source.placed_items().len() as f64);
    strip.fit_last(source, Shape { sheets: 1, last: original }).min(original)
}

'''
change('// Stable original-part order gives equal inventories exactly equal areas,',helper+'// Stable original-part order gives equal inventories exactly equal areas,')
# Preserve every earlier test body. New policy tests get an explicit separate
# harness; the earlier joint policy remains a test-only baseline control.
a=old.index('    fn joint_policy_exercise(');b=old.index('    // BEGIN joint-repair policy tests',a)
harness=old[a:b].replace('joint_policy_exercise','frontier_policy_exercise').replace('joint_exchange_window','source_frontier_window').replace('joint_exchange_chain','source_frontier_chain').replace('JOINT_POLICY_WITNESS','FRONTIER_POLICY_WITNESS')
harness=harness.replace('            _ => unreachable!(),','''            4 => search.source_frontier_chain(&strip, frozen, &mut sep, shape, until, 4).unwrap(),
            _ => unreachable!(),''')
tests=r'''
    fn frontier_fixture() -> (Job,Layout) {
        let job=serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../examples/frontier-job.json"))).unwrap();
        let layout=serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../examples/frontier-before.json"))).unwrap();
        (job,layout)
    }
    #[test]
    fn frontier_new_policy_reaches_lower_layout_and_replays() {
        let (job,before)=frontier_fixture();
        let (moved,after,stats)=frontier_policy_exercise(&job,&before,0,true,(0.0,12.0,1),1);
        assert!(moved>0 && moved<=4 && stats.joint_exchanges>0 && stats.source_frontier_attempts>0);
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<26000.0);
        let (again,replay,replay_stats)=frontier_policy_exercise(&job,&before,0,true,(0.0,12.0,1),1);
        assert_eq!(moved,again);
        assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(replay).unwrap());
        assert_eq!(serde_json::to_value(stats).unwrap(),serde_json::to_value(replay_stats).unwrap());
    }
    #[test]
    fn frontier_new_empty_source_keeps_useful_joint_exchange() {
        let (job,before)=fixture();
        let (old,baseline,old_stats)=joint_policy_exercise(&job,&before,0,true,(0.0,12.0,1),0);
        let (moved,after,stats)=frontier_policy_exercise(&job,&before,0,true,(0.0,12.0,1),0);
        assert!(old>0 && moved>0 && stats.joint_exchanges>0);
        assert_eq!(stats.source_frontier_attempts,0);
        assert_eq!(old,moved);
        assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(baseline).unwrap());
        assert_eq!(serde_json::to_value(stats).unwrap(),serde_json::to_value(old_stats).unwrap());
    }
    #[test]
    fn frontier_new_fast_phase_deadline_and_shared_cap_preserved() {
        let (job,before)=larger_return_fixture();
        let (fast,baseline,_)=chain_exercise(&job,&before,3,true,3.0,0);
        let (moved,after,stats)=frontier_policy_exercise(&job,&before,3,true,(3.0,5.0,2),0);
        assert!(fast>0);assert_eq!(fast,moved);assert_eq!(stats.source_frontier_attempts,0);
        assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(baseline).unwrap());
        let (job,before)=frontier_fixture();
        for (enabled,budget,mode) in [(false,12.0,1),(true,0.0,1),(true,1e-9,1),(true,12.0,4)] {
            let (moved,_,stats)=frontier_policy_exercise(&job,&before,0,enabled,(0.0,budget,mode),1);
            assert_eq!(moved,0);assert_eq!(stats.source_frontier_attempts,0);assert_eq!(stats.joint_exchanges,0);
        }
        let (moved,_,stats)=frontier_policy_exercise(&job,&before,0,true,(0.0,12.0,3),1);
        assert!(moved<=1 && stats.assignment_bridge_steps<=1);
    }
    #[test]
    fn frontier_new_target_is_charged_clamped_and_does_not_mutate_source() {
        let (job,before)=frontier_fixture();let model=Model::new(&job).unwrap();
        let clock=Clock::new(Timing::Work,30.0);
        let strip=Strip{model:&model,gap:2.0,clock:clock.clone(),containers:Default::default()};
        let sheets=model.sheets_of(&before).unwrap();let source=sheets[2].layout();
        let initial=fingerprint(source);let old_count=clock.counts().registered_items;
        let target=source_frontier_target(&strip,source,model.full_width);
        assert!(target<model.full_width);
        assert_eq!(clock.counts().registered_items-old_count,source.placed_items().len() as f64);
        assert_eq!(source_frontier_target(&strip,source,10.0),10.0);
        assert_eq!(fingerprint(source),initial);
        let empty=JLayout::new(source.container().clone());let old_count=clock.counts().registered_items;
        assert_eq!(source_frontier_target(&strip,&empty,model.full_width),model.full_width);
        assert_eq!(clock.counts().registered_items,old_count);
    }
    #[test]
    fn frontier_new_flat_partial_sequence_still_rolls_back() {
        let (job,_)=assignment_bridge_fixture();
        let before:Layout=serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../examples/joint-rollback-compacted.json"))).unwrap();
        let (moved,_,stats)=frontier_policy_exercise(&job,&before,0,true,(0.0,12.0,3),0);
        assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);assert_eq!(stats.joint_exchanges,0);
        assert!(stats.assignment_bridge_rolled_back>0 && stats.joint_repair_completed>0);
    }
'''
pos=text.rindex('\n}');text=text[:pos]+'\n'+harness+tests+text[pos:]
path.write_text(text,encoding='utf-8',newline='\n')
p=WORK/'crates/core/src/sheets/vstrip.rs';t=p.read_text(encoding='utf-8');assert t.count('self.joint_exchange_window(')==1
p.write_text(t.replace('self.joint_exchange_window(','self.source_frontier_window('),encoding='utf-8',newline='\n')
p=WORK/'crates/core/src/sheets.rs';t=p.read_text(encoding='utf-8');needle='    pub joint_exchanges: u64,\n'
assert t.count(needle)==1;p.write_text(t.replace(needle,needle+'    #[serde(skip_serializing_if = "is_zero")]\n    pub source_frontier_attempts: u64,\n'),encoding='utf-8',newline='\n')
w=load(OUT/'geometry-checks/witness.json')
for key,name in [('job','frontier-job.json'),('before','frontier-before.json')]:
    (WORK/'examples'/name).write_text(json.dumps(w[key],indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=WORK,check=True)
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'changed_files':[REL,'crates/core/src/sheets/vstrip.rs','crates/core/src/sheets.rs','examples/frontier-job.json','examples/frontier-before.json'],
    'prior_tests':166,'new_tests':5,'unchanged_limits':True,'empty_source':'Keep original crop to allow useful non-eliminating exchanges.',
    'counter':'source_frontier_attempts counts proposals passed to joint helper with a stricter source crop, including helper early expiry.',
    'claims':'Isolated policy awaiting qualification; no H5, quality, production or release claim.'}
(OUT/'policy-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,OUT/'implement.py');print(json.dumps(plan),flush=True)
