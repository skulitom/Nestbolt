"""Run the one authored frontier witness once, retaining success or failure."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-frontier-probe-20261018'
plan=json.loads((OUT/'preparation.json').read_bytes());TARGET=Path(plan['target'])
CHECK=OUT/'initial-witness';CHECK.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for r in plan['source_files']:assert digest(Path(plan['old_source'])/r['path'])==r['sha256']
shutil.copyfile(OUT/'candidate'/plan['changed_file'],CHECK/'exchange.rs')
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',str(TARGET),
    'source_frontier_existing_joint_repair','--','--nocapture','--test-threads=1']
assert not TARGET.exists()
started=datetime.now(timezone.utc).isoformat()
with (CHECK/'witness.log').open('xb') as log:
    result=subprocess.run(command,cwd=OUT/'candidate',stdout=log,stderr=subprocess.STDOUT,timeout=1800)
raw=(CHECK/'witness.log').read_text(encoding='utf-8');binaries=list((TARGET/'release/deps').glob('nestbolt_core-*.exe'))
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
    'exit_code':result.returncode,'log_sha256':digest(CHECK/'witness.log'),
    'witness_passed':result.returncode==0 and '1 passed; 0 failed' in raw,'benchmark_searches':0}
if 'Running unittests' in raw and len(binaries)==1:
    shutil.copyfile(binaries[0],CHECK/'authored-tests.exe');record['binary_sha256']=digest(binaries[0])
(CHECK/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,CHECK/'check.py');print(json.dumps(record),flush=True)
assert record['witness_passed']
