"""Seal qualified isolated source-frontier policy and append its evidence."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-frontier-probe-20261018'
out=root/'benchmarks/results/h5-frontier-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def append(p,text):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(text)
build=load(probe/'policy-checks/build.json');native=load(probe/'policy-native-audit/checks.json');public=load(probe/'public-checks/checks.json')
assert build['all_passed'] and native['native_suite_passed'] and public['all_passed']
assert native['prior_tests_exact']==166 and native['prior_witnesses_exact']==139
assert public['frontier_attempts_including_replays']==4
assert digest(probe/'frontier-candidate.exe')==build['binary_sha256']
for rel,value in build['source_files'].items():assert digest(probe/'candidate'/rel)==value
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==load(probe/'preparation.json')['production_digest']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_frontier_witness.py','check_h5_frontier_witness.py','check_h5_frontier_geometry.py',
    'seal_h5_frontier_witness.py','implement_h5_frontier_policy.py','build_h5_frontier_policy.py',
    'check_h5_frontier_policy_native.py','check_h5_frontier_public.py','seal_h5_frontier_policy.py']:
    files['helpers/'+name]=root/'output'/name
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(out/'raw.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'all_members_and_crc_verified':True,'archive':'raw.zip','bytes':(out/'raw.zip').stat().st_size,'sha256':digest(out/'raw.zip'),'members':inventory})
for source,name in [('policy-plan.json','plan.json'),('policy-checks/build.json','build.json'),
    ('policy-native-audit/checks.json','native-checks.json'),('policy-native-audit/witnesses.json','native-witnesses.json'),
    ('policy-native-audit/candidate.patch','candidate.patch'),('public-checks/checks.json','public-checks.json')]:
    shutil.copyfile(probe/source,out/name)
checks={'qualified_for_matched_pilot':True,'native_tests':171,'unchanged_prior_tests':166,'exact_prior_witnesses':139,
    'native_CLI_checks':7,'native_filled_outer_pairs':34,'public_outcomes':6,'public_CLI_checks':6,
    'public_filled_outer_pairs':856,'public_frontier_attempts_including_replays':4,
    'strict_lint_and_build_passed':True,'production_unchanged':True,'integrated':False,'H5_complete':False,
    'completed_weight_percent':60,'development_measurement_started':False}
write(out/'checks.json',checks)
doc='''# Source-frontier policy qualification — 2026-10-18

**The isolated automatic policy passes qualification; mechanical quality is still unmeasured.**

The [original-runtime witness](h5-frontier-witness-20261018.md) establishes that
an explicit lower source boundary can make actual joint repair productive. The
candidate now derives that boundary after selected members are removed and before
returns are added. It uses the existing fitted-container calculation, clamps it
to the original crop and charges the additional scan. When no source member
remains, it retains the original crop so useful exchanges need not eliminate
the last sheet. The new counter records proposals passed to the joint helper
with a tighter crop, including any helper that then declines an expired call.

The original short phase, absolute remaining deadline, validation reserve,
shared four-step cap, exact container checks, independent whole-job guard and
provisional rollback remain. The joint helper and shared provisional-chain
implementation are byte-for-byte unchanged. Prior joint policy remains a
test-only control; automatic search calls the new frontier policy.

All **171 optimized native tests** pass, including five new tests. Automatic
selection reduces the constructed whole job from **28,849.9994 to 25,200.0558 mm²**
and repeats its complete result and counters exactly. It keeps the fixed prefix,
commits one improving step, and rolls back two subsequent flat steps. A separate
one-slot case rolls back an actual unfinished flat step. Tests also cover the
empty-source fallback, expired/disabled calls, the unchanged fast-phase result,
the shared cap, crop clamping, work accounting and unchanged source input.

All **166 earlier test bodies** and **139 recorded outputs** remain exact.
There are 154 unchanged unrelated files; only three existing source files and
two new authored fixture files differ from the original-runtime witness workspace.
Independent CLI checks validate seven unique new-policy layouts and 34 filled
outer pairs. The earlier explicit-helper witness has its own separate seven
layout checks and 26 pair checks.

Six authored public outcomes and six independent CLI validations pass. Ordinary
mode matches saved parent results exactly except elapsed wall time. Both
common-mode seeds replay exactly, including cutting reports. The public path
actually attempts four tighter crops including replays. Source holes remain
reserved: four common outcomes pass 856 filled-outer pair checks at 1e-7 mm.
Strict lint and the optimized executable build also pass.

This qualifies the changed implementation for a newly planned matched pilot.
It makes no quality or speed claim and does not erase the earlier failed
72-run joint-repair pilot. Keep the same cases, seeds, budgets and material
limits; commit the new plan before measuring. Production, release assets and
all three accurate READMEs remain unchanged. H2/H5 remain open at 60%.

[Checks](h5-frontier-preparation-20261018/checks.json),
[native audit](h5-frontier-preparation-20261018/native-checks.json),
[public checks](h5-frontier-preparation-20261018/public-checks.json),
[candidate patch](h5-frontier-preparation-20261018/candidate.patch) and
[archive integrity](h5-frontier-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
note='''**N4 source-frontier qualification, 2026-10-18:** [the explicit witness and automatic policy pass](../benchmarks/results/h5-frontier-preparation-20261018.md).
The original helper leaves the authored source at 87.200677 mm with its old crop
and finds 51.000558 mm under the exposed boundary. Automatic selection also finds
a valid strict gain and rolls back unfinished flat steps. All 171 native tests,
166 unchanged earlier tests, 139 exact earlier outputs, strict lint/build and six
public checks pass. Independent audits preserve quantities, fixed sheets and
reserved holes, including 856 public filled-outer pairs. The extra target scan
is charged; empty sources keep the original crop. All deadlines, the shared cap,
material limits and production remain unchanged. A new matched pilot is still
required; no H5 or release credit. H2/H5 remain open at 60%.
'''
prior=subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root)
assert (root/'BENCHMARKS.md').read_bytes()==prior
append(root/'BENCHMARKS.md','\n'+note.replace('../benchmarks/','benchmarks/'))
for name in ['docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:append(root/name,'\n'+note)
p=root/'docs/STATUS.md';s=p.read_text(encoding='utf-8');marker='**N4 actual joint-repair diagnosis, 2026-10-18:**'
assert s.count(marker)==1;p.write_text(s.replace(marker,note+'\n'+marker),encoding='utf-8',newline='\n')
append(root/'.gitattributes','\nbenchmarks/results/h5-frontier-witness-20261018/** -text -whitespace\nbenchmarks/results/h5-frontier-preparation-20261018/** -text -whitespace\n')
assert (root/'BENCHMARKS.md').read_bytes().startswith(prior)
print(json.dumps({'qualified':True,'archive_members':len(inventory),'archive_bytes':(out/'raw.zip').stat().st_size,'development_measurement_started':False}))
