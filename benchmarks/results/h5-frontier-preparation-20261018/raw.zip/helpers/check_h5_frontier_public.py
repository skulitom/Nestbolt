"""Authored fixed-work public repeatability, ordinary-mode parity and reserved-hole checks."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,itertools,json,math,shutil,subprocess,sys,traceback
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-frontier-probe-20261018'
parent=root/'output/h5-joint-repair-probe-20261018/public-checks';out=probe/'public-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def deterministic(value):
    value=copy.deepcopy(value);value.pop('elapsed_seconds');return value
assert load(probe/'policy-checks/build.json')['all_passed']
assert load(probe/'policy-native-audit/checks.json')['native_suite_passed']
out.mkdir();binary=probe/'frontier-candidate.exe';cli=parent/'nestbolt-validator.exe'
assert digest(binary)==load(probe/'policy-checks/build.json')['binary_sha256']
assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
for name in ['library.json','normal.json','common.json']:shutil.copyfile(parent/name,out/name)
guards={str(p):digest(p) for p in [binary,cli,out/'library.json',out/'normal.json',out/'common.json']}
write(out/'plan.json',{'scope':__doc__,'seconds':20,'seeds':[0,1],'modes':['normal','common'],
    'common_replays':2,'guards':guards,'development_measurement':False,'held_out_access':False})
rows=[];pairs=0;holes=0
def run(label,command):
    assert not (out/(label+'-command.json')).exists()
    command=list(map(str,command));r=subprocess.run(command,capture_output=True,timeout=90)
    (out/(label+'-stdout.json')).write_bytes(r.stdout);(out/(label+'-stderr.log')).write_bytes(r.stderr)
    write(out/(label+'-command.json'),{'command':command,'exit_code':r.returncode})
    assert r.returncode==0,(label,r.stderr.decode(errors='replace'))
    return r.stdout
try:
    for mode in ['normal','common']:
        for seed in [0,1]:
            results=[]
            for replay in range(2 if mode=='common' else 1):
                label=f'candidate-{mode}-s{seed}'+('-replay' if replay else '')
                folder=out/label
                run(label,[binary,out/'library.json',out/(mode+'.json'),folder,20,seed,'work'])
                r=load(folder/'search.json');assert r['repeatable'] and r['validation']['valid']
                checked=json.loads(run(label+'-validate',[cli,'validate','--library',out/'library.json','--request',out/(mode+'.json'),'--layout',folder/'layout.json']))
                assert checked['valid'] and checked['metrics']==r['validation']['metrics']
                if mode=='normal':
                    reference=parent/f'candidate-normal-s{seed}'
                    assert deterministic(r)==deterministic(load(reference/'search.json'))
                    assert r['stats'].get('source_frontier_attempts',0)==0
                else:
                    assert r['riders']==0 and load(folder/'cutting-report.json')['valid']
                    if replay:
                        assert deterministic(r)==deterministic(results[0])
                        assert load(folder/'cutting-report.json')==load(out/f'candidate-common-s{seed}'/'cutting-report.json')
                    job=load(folder/'job.json');parts={p['id']:p for p in job['parts']};sheets={}
                    holes+=sum(len(g['holes']) for p in parts.values() for g in p['geometry'])
                    assert Counter(p['part_id'] for p in r['layout']['placements'])==Counter({p['id']:p['quantity'] for p in parts.values()})
                    for p in r['layout']['placements']:
                        assert len(parts[p['part_id']]['geometry'])==1
                        shape=Polygon(parts[p['part_id']]['geometry'][0]['outer']);assert shape.is_valid
                        t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
                        shape=affine_transform(shape,[m*c,-s,m*s,c,*t['translation']]);assert shape.is_valid
                        sheets.setdefault(p['sheet_id'],[]).append(shape)
                    for shapes in sheets.values():
                        for a,b in itertools.combinations(shapes,2):
                            pairs+=1;assert a.disjoint(b) and a.distance(b)-job['clearance']>=-1e-7
                results.append(r)
                rows.append({'label':label,'valid':True,'repeatable':True,'stats':r['stats'],'layout_sha256':digest(folder/'layout.json')})
                write(out/'progress.json',rows);print(json.dumps({'completed':label}),flush=True)
    for name,expected in guards.items():assert digest(Path(name))==expected
    assert holes>0 and sum(r['stats'].get('joint_repair_attempts',0) for r in rows)>0
    record={'all_passed':True,'public_outcomes':6,'CLI_validations':6,'normal_exact_except_elapsed':True,
        'common_replays_exact_except_elapsed':True,'holes_reserved':True,'source_holes_present':True,'filled_outer_pairs':pairs,
        'frontier_attempts_including_replays':sum(r['stats'].get('source_frontier_attempts',0) for r in rows),
        'absolute_clearance_tolerance_mm':1e-7,'shapely_version':shapely.__version__,'records':rows,
        'quality_or_speed_claim':False,'held_out_access':False}
    write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
    print(json.dumps({k:v for k,v in record.items() if k!='records'}),flush=True)
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'completed':rows});raise
