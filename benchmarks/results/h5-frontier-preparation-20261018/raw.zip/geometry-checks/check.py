"""Audit the saved source-frontier witness without rerunning either repair."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import ast,copy,itertools,json,math,shutil,subprocess,sys,traceback
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-frontier-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=probe/'geometry-checks';out.mkdir();cache={};records=[];pairs=0
sys.path.insert(0,str(root/'scripts'));import h5_joint_trace as reader
from h2_import_audit import source_digest
cli=root/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
template=root/'output/check_h5_joint_observer_geometry.py'
nodes=[n for n in ast.parse(template.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['write','validate']]
assert len(nodes)==2
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(template),'exec'))
try:
    check=load(probe/'initial-witness/checks.json');plan=load(probe/'preparation.json')
    raw=(probe/'initial-witness/witness.log').read_text(encoding='utf-8')
    assert digest(probe/'initial-witness/witness.log')==check['log_sha256']
    witnesses=[json.loads(line.split('SOURCE_FRONTIER_WITNESS ',1)[1]) for line in raw.splitlines() if 'SOURCE_FRONTIER_WITNESS ' in line]
    paired=[json.loads(line.split('JOINT_PAIR_WITNESS ',1)[1]) for line in raw.splitlines() if 'JOINT_PAIR_WITNESS ' in line]
    assert len(witnesses)==1 and len(paired)==2
    w=witnesses[0];write(out/'witness.json',w);write(out/'pair-witnesses.json',paired)
    for name in ['before','proposal','authored_feasible','old_after','target_after']:
        report=w.get(name.replace('_after','_report')) if name.endswith('_after') else None
        validate(w['job'],w[name],True,report['metrics'] if report else None,{'stage':name})
    for index,r in enumerate(paired):
        assert r['job']==w['job'] and r['proposal']==w['proposal']
        assert r['after']==w[['old_after','target_after'][index]]
        assert r['budget']==12 and r['enabled'] and r['valid']
        if r['success']:assert r['finished']<r['until']
        for name in ['before','after']:
            validate(r['job'],r[name],True,None,{'pair':index,'stage':name})
        fixed=lambda layout:sorted((json.dumps(p,sort_keys=True) for p in layout['placements'] if p['sheet_id']=='sheet-0'))
        assert fixed(r['before'])==fixed(r['after'])
    remaining=w['source_remaining'];job=copy.deepcopy(w['job'])
    quantities=reader.inventory(remaining['placements']);job['parts']=[p for p in job['parts'] if quantities[p['id']]]
    for p in job['parts']:p['quantity']=quantities[p['id']]
    validate(job,remaining,True,None,{'stage':'selected_member_removed','component_quantities_only':True})
    for name in ['before','proposal','old_after','target_after']:
        assert all(p['transform']['rotation_radians']==0 and not p['transform']['mirrored'] for p in w[name]['placements'])
    assert paired[1]['source_last']==w['target_internal']<paired[0]['source_last']
    prior=Path(plan['old_source']);rel=plan['changed_file'];original=(prior/rel).read_text(encoding='utf-8')
    current=(probe/'candidate'/rel).read_text(encoding='utf-8');pos=original.rindex('\n}')
    assert current.startswith(original[:pos]) and current.endswith(original[pos:])
    assert current.split('#[cfg(test)]\nmod tests',1)[0]==original.split('#[cfg(test)]\nmod tests',1)[0]
    assert digest(probe/'initial-witness/exchange.rs')==digest(probe/'candidate'/rel)
    unchanged=0
    for r in plan['source_files']:
        assert digest(prior/r['path'])==r['sha256']
        if r['path']!=rel:
            assert digest(probe/'candidate'/r['path'])==r['sha256'];unchanged+=1
    assert source_digest()==plan['production_digest']
    result={'all_saved_geometry_checks_passed':True,'witness_test_passed':check['witness_passed'],
        'CLI_checks':len(records),'filled_outer_pairs':pairs,'records':records,
        'old_top_mm':w['old_top'],'target_top_mm':w['target_top'],'target_success':w['target_success'],
        'old_material_mm2':w['old_report']['metrics']['material_area'],'target_material_mm2':w['target_report']['metrics']['material_area'],
        'unchanged_other_source_files':unchanged,'all_165_prior_tests_unchanged':True,'runtime_unchanged':True,
        'production_unchanged':True,'original_repair_allowance_preserved':True,'fixed_prefix_exact':True,
        'quantities_and_orientations_preserved':True,'absolute_clearance_tolerance_mm':1e-7,
        'CLI_sha256':digest(cli),'geometry_template_sha256':digest(template),'shapely_version':shapely.__version__,
        'new_searches':0,'scope':'Actual helper repairs only; no automatic proposal selection, runtime policy, quality or H5 claim.'}
    write(out/'checks.json',result);shutil.copyfile(__file__,out/'check.py');shutil.copyfile(template,out/'geometry-template.py')
    print(json.dumps({k:v for k,v in result.items() if k not in ['records']}),flush=True)
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'completed':records});raise
