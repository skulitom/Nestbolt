"""Reconstruct every original contour and classify all source failures."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,sys,time
from h5_legacy64_source_readback import audit
from h5_independent_cog_lazy_source_cuts_20261107 import classify
ROOT=Path(__file__).resolve().parents[1];I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
round_dir=Path(sys.argv[1]).resolve();assert round_dir.is_relative_to(ROOT/'output/h5-independent-cog-lazy-20261107/search')
started=float(sys.argv[2]);OUT=round_dir/'source-response';OUT.mkdir();mapping=load(round_dir/'mapping.json');values=load(round_dir/'assignment.json');inventory=load(I/'inventory.json');request=load(round_dir/'request.json')
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,2100] and mapping['active_cog_pairs']==request['active_pairs']
assert not load(round_dir/'assignment-check.json')['failed_constraints']
rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json');chosen=[];selected={}
for o in mapping['owners']:
    active=[m for m in o['modes'] if values[m['selector']]];assert len(active)==1;m=active[0];selected[o['owner']]=m;xy=[values[v] for v in o['positions']]
    assert all(lo<=value<=hi for value,(lo,hi) in zip(xy,m['integer_world_lower_left_bounds']))
    world=[xy[k]/100+mapping['world_origin_mm'][k] for k in [0,1]]
    rows.append({'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[world[k]+m['translation_from_lower_left'][k] for k in [0,1]]}})
    chosen.append({'owner':o['owner'],'identity':o['identity'],'mode':m['mode'],'world_lower_left_mm':world})
assert [p['pair'] for p in mapping['cog_interactions']]==request['active_pairs']
for pair in mapping['cog_interactions']:
    active=[r for r in pair['regions'] if values[r['selector']]];assert len(active)==1;r=active[0];a,b=pair['owners']
    if pair['kind']=='cog_orthogonal':
        mode=selected[b];link=next(x for x in pair['coordinate_links'] if x['mode']==mode['mode']);assert link['selector']==mode['selector'] and link['class']==r['class']
        d=[values[mapping['owners'][b]['positions'][k]]-values[mapping['owners'][a]['positions'][k]] for k in [0,1]]
        assert [values[v] for v in pair['canonical_positions']]==[sum(link['matrix'][k][j]*d[j] for j in [0,1])+link['offset_grid'][k] for k in [0,1]]
    else:assert pair['kind']=='cog_cog' and r['class']=='cog_cog'
job=load(JOB);spec=load(FIRST/'plan.json');expected=list(map(tuple,inventory['full66_identities']));assert len(rows)==66 and len(chosen)==28
source=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
decision=classify(source,mapping['owners'],load(I/'owner-pairs.json'),request['active_pairs'])
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-modes.json',chosen);write(OUT/'original-source-checks.json',source);write(OUT/'decision.json',decision)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_independent_cog_lazy_source_cuts_20261107.py',JOB,FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'short9-source.json',I/'inventory.json',I/'owner-pairs.json',round_dir/'request.json',round_dir/'mapping.json',round_dir/'assignment.json',round_dir/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read all28 selected original modes and coordinates, with exact active-pair mode coupling. Reconstruct fixed29+short9+28movers and check every original filled outer and all90 holes, all1632 same-sheet pairs and264stock edges against unchanged source limits. Classify every failure by original identity. Only newly failing, previously unconstrained cog pairs may produce later complete source interactions; any fixed/short/stock/orthogonal/already-constrained failure stops the pipeline.'})
checks={'source_valid66':source['valid'],'originals':66,'same_sheet_pairs':1632,'stock_edges':264,'holes':90,'hole_vertices':10026,'source_checker_calls':1,'decision':decision['status'],'new_pairs':decision['new_pairs'],'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
