"""Map failed original identities to complete source interactions; never ignore inconsistencies."""
def classify(source,owners,source_pairs,active_pairs):
    lookup={tuple(o['identity']):o['owner'] for o in owners}
    assert len(lookup)==len(owners)==28 and sorted(lookup.values())==list(range(28))
    pairs={tuple(sorted(p['owners'])):i for i,p in enumerate(source_pairs)}
    assert len(pairs)==len(source_pairs)==258
    active=set(active_pairs);new=set();failures=[];inconsistent=[]
    assert source['pair_failures']==sum(not p['passed'] for p in source['pairs'])
    assert source['stock_failures']==sum(not p['passed'] for p in source['stock'])
    assert source['valid']==(source['pair_failures']==source['stock_failures']==0)
    for row in source['pairs']:
        if row['passed']:continue
        a,b=map(tuple,row['keys']);entry={'keys':[list(a),list(b)]}
        if a not in lookup or b not in lookup:entry['reason']='fixed-or-short-original';inconsistent.append(entry)
        else:
            key=tuple(sorted((lookup[a],lookup[b])))
            if key not in pairs:entry['owners']=list(key);entry['reason']='orthogonal-only';inconsistent.append(entry)
            else:
                pair=pairs[key];entry['pair']=pair;entry['owners']=list(key);failures.append(entry)
                if pair in active:entry['reason']='already-constrained';inconsistent.append(entry)
                else:new.add(pair)
    for row in source['stock']:
        if not row['passed']:inconsistent.append({'reason':'stock','key':row['key']})
    if source['valid']:status='SOURCE_VALID_CANDIDATE'
    elif inconsistent:status='SOURCE_INCONSISTENCY'
    elif new:status='NEW_SOURCE_PAIRS'
    else:status='NO_NEW_CUT'
    return {'status':status,'source_valid66':source['valid'],'new_pairs':sorted(new) if status=='NEW_SOURCE_PAIRS' else [],'failed_cog_pairs':failures,'inconsistencies':inconsistent,'pair_failures':source['pair_failures'],'stock_failures':source['stock_failures']}
