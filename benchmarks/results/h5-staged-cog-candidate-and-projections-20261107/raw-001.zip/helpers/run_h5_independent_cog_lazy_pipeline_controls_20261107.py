from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-independent-cog-lazy-controls-process-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe';SCRIPT=ROOT/'output/check_h5_independent_cog_lazy_pipeline_controls_20261107.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,EXE,EXE.parent/'checks.json']},'maximum_ms':60000,'memory_bytes':2**31,'verification_only':True,'solver_calls':0,'retry_permitted':False})
start=time.perf_counter();args=[str(EXE),'60000',str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(SCRIPT)]),str(ROOT),'version4'];r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=68)
(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');passed=r.returncode==0 and job['reason_code']==job['error_code']==0 and job['closed'] and job['active_processes']==0
result={'passed':passed,'closed':job['closed'],'complete_seconds':time.perf_counter()-start,'exit_code':r.returncode,'job':job,'verification_only':True,'solver_calls':0,'retry_permitted':False};write(OUT/'process.json',result);print(result)
