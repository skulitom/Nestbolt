"""Archive the closed staged candidate and fresh exact convex repair preparation."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1]
prior=(ROOT/'output/seal_h5_cog_capacity_search_checkpoint_v2_20261107.py').read_text(encoding='utf-8');prefix=prior[:prior.index('copies=[')]
prefix=prefix.replace("NAME='h5-cog-capacity-search-and-initial-model-v2-20261107'","NAME='h5-staged-cog-candidate-and-projections-20261107'")
prefix=prefix.replace("H=ROOT/'output/h5-independent-cog-capacity-20261107';C=ROOT/'output/h5-independent-cog-lazy-20261107';F=ROOT/'output/h5-cog-capacity-search-checkpoint-20261107'", "H=ROOT/'output/h5-independent-cog-lazy-20261107';C=ROOT/'output/h5-cog-candidate-projections-20261107';F=ROOT/'output/h5-staged-cog-candidate-checkpoint-20261107'")
prefix=prefix.replace("front['closed_solver_calls']==1 and front['closed_solver_status']=='UNKNOWN' and not front['pipeline_prepared']", "front['closed_solver_calls']==2 and front['last_solver_status']=='UNKNOWN' and not front['new_repair_model_prepared']")
prefix=prefix.replace("'h5-cog-halfplane-search-and-capacity-20261107'])", "'h5-cog-halfplane-search-and-capacity-20261107','h5-cog-capacity-search-and-initial-model-v2-20261107'])")
prefix=prefix.replace("['h5-independent-cog-capacity-model-process-20261107','h5-independent-cog-lazy-initial-process-20261107','h5-cog-halfplane-capacity-main-sync-20261107']", "['h5-independent-cog-lazy-controls-process-20261107','h5-cog-candidate-projections-process-20261107','h5-cog-capacity-search-main-sync-20261107']")
prefix=prefix.replace("['*h5*independent*cog*capacity*20261107.py','*h5*independent*cog*lazy*20261107.py','*h5*cog*capacity*search*20261107.py']", "['*h5*independent*cog*lazy*20261107.py','*h5*cog*candidate*projections*20261107.py','*h5*staged*cog*candidate*20261107.py']")
prefix=prefix.replace("for name in ['ccd1.py'", "for name in ['seal_h5_cog_capacity_search_checkpoint_v2_20261107.py','ccd1.py'")
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'next-preparation-charges.json','next-preparation-charges.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(H/'pipeline-controls/checks.json','pipeline-controls.json'),(H/'response-audit/checks.json','response-audit.json'),(H/'response-audit/round-checks.json','round-model-checks.json'),(H/'search/process.json','closed-pipeline-process.json'),(H/'source-audit/checks.json','original-source-audit.json'),(H/'source-audit/collision-graph.json','candidate-collision-graph.json'),(C/'checks.json','projection-preparation.json'),(C/'audit/checks.json','projection-audit.json'),(ROOT/'output/h5-cog-candidate-projections-process-20261107/process.json','projection-process.json'),(ROOT/'output/h5-cog-capacity-search-main-sync-20261107/receipt.json','main-push-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Staged cog candidate and exact safe-region projections — 2026-11-07

The new staged construction returns one **necessary 66-part candidate**, whose
original-source check fails on **32 pairs**. It adds all 32 complete certified
interactions, then stops when the changed model returns UNKNOWN. The pipeline
is closed. A new exact projection preparation now proposes one safe convex
region for every cog interaction; its repair model has not been built or solved.
No source-valid full66 layout or exclusion follows. Four fixed arrangements
and all 440 allocations remain, with H2/H5 open at **60% completed milestone
weight**.

## Controlled staged construction

[Preflight controls]({NAME}/pipeline-controls.json) verify **1,220 routing cases**:
all 258 cog interactions in both original-identity orders, active and inactive;
all 120 orthogonal pairs; all 38 fixed/short originals; all 28 movable stock
identities; and mixed/valid cases. Three distinct changed-model controls pass
full independent readback. Five deliberately corrupted models are rejected.
No control calls a solver. The complete verification process takes 2.263694 s.

The frozen pipeline permits at most four strictly changing rounds under one
preparation-inclusive 60/90-second and 2 GiB budget. The first solve is capped
at 30 seconds and later solves at eight, each further limited by remaining time
and a four-second source-check reserve. Solver processes close before separate
source-check processes start. No unchanged model can be retried.

[Independent response and model readback]({NAME}/response-audit.json) verifies
the actual **two closed calls**. The 1,332-variable / 4,712-constraint initial
model returns OPTIMAL for its necessary constraints after **8.416443 seconds**,
with 67,526 branches and 13,485 conflicts. Its one incumbent and returned
assignment satisfy every model constraint; this alone does not validate the
original contours.

[Original-source replay]({NAME}/original-source-audit.json) reconstructs every
original identity and repeats all **1,632 same-sheet pairs, 264 stock edges,
90 holes and 10,026 hole vertices**. It confirms 31 positive-area overlaps and
one clearance-only failure, with zero stock failures. The [observed collision
graph]({NAME}/candidate-collision-graph.json) involves 24 movers in one connected
component. These facts describe only this candidate.

All 32 failures map to previously unconstrained cog interactions. The changed
model has **5,041 variables and 12,819 constraints**, including 3,671 pair-region
selectors, 7,769 guarded source planes, 272 exact mode-coordinate links and
34 class marginals. [Every changed-model field is independently checked]({NAME}/round-model-checks.json)
before its call. That call returns **UNKNOWN**, with no incumbent, after
**8.030114 seconds** against its eight-second slice. The **0.030114-second
overrun is preserved**. The pipeline stops immediately; rounds 2 and 3 do not run.

[The complete process]({NAME}/closed-pipeline-process.json) closes all nine
processes with zero active descendants. Peak aggregate committed memory is
**1,009,483,776 bytes**, below 2 GiB. Charged initial preparation is 5.105639 s;
algorithm/shared totals are **27.116847 / 27.155075 seconds** including it.
No candidate passes full source geometry, no native call runs, and no
continuous or whole-allocation exclusion is claimed.

## Fresh exact safe-region projections

The new repair hypothesis retains this candidate's **28 selected legal modes**
and allows all 56 translation coordinates to move. It is a different convex
construction from either closed staged model. [Preparation]({NAME}/projection-preparation.json)
clips all **303 certified source regions** against their complete relative
coordinate bounds using rational arithmetic; four resulting sets are empty.

[Independent projection readback]({NAME}/projection-audit.json) reconstructs
the regions by enumerating pairwise boundary-line intersections and verifies
all **1,055 exact vertices**. It rechecks **470 pocket-plane implications for
real coordinates** and **557 retained-halfplane original-source support proofs**.
This establishes that relaxing coordinate integrality does not discard the
source safety margins of the selected regions.

For every actual candidate pair difference, every nonempty region of its
selected mode class receives an exact closest point. The auditor verifies
**18,882 projection optimality certificates**: exact membership and squared
distance, plus the convex variational inequality against every region vertex.
Exact distance and deterministic kind/id ordering select one region per pair.
**226 cog pairs already lie in a certified region; 32 require relative motion.**
Every one of 268 orthogonal component pairs retains an already satisfied
source-safe axis separator, independently reconstructed from original mode
offsets. No new solver is invoked during this preparation.

[The complete projection process]({NAME}/projection-process.json) takes
**2.767059 seconds** to prepare; its separate complete audit takes 4.146106 s.
Both stages close normally. These projections propose compatible individual
pair requirements; they do not prove that all choices can be satisfied together.

## Next one-call convex repair

[The next-model specification]({NAME}/next-step.json) uses 56 original
translation variables plus 56 absolute-motion auxiliaries, minimizing total
translation change from the candidate. Keep every selected source mode's stock
bounds, all four relative-domain bounds and all retained planes for each chosen
cog region, all 268 orthogonal separators, and the cog X-order chain needed by
the nonnegative relative-X domains. Eliminate canonical coordinates exactly
through their signed-permutation matrices and shifts.

Every model row, numeric scaling and pinned solver control requires independent
checking before **one** newly frozen call. [The complete charge before its
model build]({NAME}/next-preparation-charges.json) is **29.922133 seconds**:
the entire consumed 27.155075-second candidate pipeline, including both rounds
and its original preparation, plus complete projection preparation. The original
preparation must not be counted twice, and the new complete build still counts.

No repair model, LP call or valid layout is prepared here. Any infeasibility
would apply only to these selected modes and convex-region choices, without
excluding other regions, the continuous source domain or any whole allocation.
A returned candidate still requires all66 original-source checks, native/material
validation, production integration and the unchanged full H5 matrix.

[The preceding checkpoint reached main 548f5b40 normally]({NAME}/main-push-receipt.json)
after all six prior CI checks passed, preserving all 52 remote files and updating
the working branch atomically. [Current main CI at review]({NAME}/main-ci-at-review.json)
is preserved; no live run is cancelled. H2 retains its original gate and unopened
reserved vectors. Production, READMEs and release assets are unchanged.

[The archive]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) preserve all consumed evidence.
The prior hash-bound invalid sealer source remains raw historical evidence,
with its expected syntax failure checked; no frozen failure bytes are edited.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 staged candidate and exact projections:** [independent pipeline, source and projection audits]({link}) verify two closed calls. The initial necessary model returns a 66-part candidate; original-source replay finds 31 overlaps and one clearance failure, with all stock edges passing. All 32 new cog-pair interactions are added to a fully audited 5,041-variable/12,819-constraint model, whose eight-second call stops UNKNOWN. The 0.030114 s solve-slice overrun remains recorded; preparation-inclusive algorithm/shared totals are 27.116847/27.155075 s and all descendants close. New exact safe-region preparation verifies 303 clipped regions, 1,055 vertices and 18,882 projection certificates, with 226 cog pairs already safe and 32 needing relative motion. All 268 orthogonal separators pass. One distinct convex translation repair is next, with all 28 selected legal modes fixed and complete charge29.922133 s before its model build. No repair model or solver is prepared, no valid full66 layout or exclusion follows, and all previous calls stay closed. Four fixed arrangements and 440 allocations remain; H2/H5 stay at 60%. Main548f5b40 was pushed after all six prior CI checks passed, preserving52 remote files; no release is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
current=f"Latest H5 evidence: [staged cog candidate and exact projections](../benchmarks/results/{NAME}.md).\nThe staged search returns one necessary 66-part candidate, but full original-\nsource replay finds 32 failing pairs. The next model adds all 32 interactions\nand stops UNKNOWN within its frozen slice. Both calls stay closed; no valid\nlayout or exclusion follows. New exact projections verify 18,882 closest-point\ncertificates across certified source regions, identifying 32 pairs needing\nrelative movement. A distinct continuous convex repair is next; its complete\nsource charge is 29.922133 s before model building. No repair model is prepared.\nFour fixed arrangements and all 440 allocations remain; full66 source/material/\nnative checks and the full H5 gate are open. H2/H5 stay open at 60%.\nThe preceding checkpoint reached main 548f5b40 after all six prior CI checks\npassed, preserving all 52 remote files. New CI is underway; no release is made.\n"
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s[:a]+current+s[b:])
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'closed_solver_calls':2,'new_repair_calls':0,'source_valid66':False})
