"""Verification-only controls for cut routing and changed-model readback; no solver."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from copy import deepcopy
import ast,json,time,shutil
from ortools.sat import cp_model_pb2
from h5_independent_cog_lazy_model_20261107 import build
from h5_independent_cog_lazy_model_reader_20261107 import verify
from h5_independent_cog_lazy_source_cuts_20261107 import classify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-lazy-20261107';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';OUT=BASE/'pipeline-controls'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'controls.py');start=time.perf_counter();mapping=load(BASE/'initial-model/mapping.json');owners=mapping['owners'];pairs=load(I/'owner-pairs.json');inventory=load(I/'inventory.json')
def source(keys=(),stock=()):
    return {'valid':not keys and not stock,'pair_failures':len(keys),'stock_failures':len(stock),'pairs':[{'keys':list(k),'passed':False} for k in keys],'stock':[{'key':k,'passed':False} for k in stock]}
controls=[]
for pi,pair in enumerate(pairs):
    keys=[owners[o]['identity'] for o in pair['owners']]
    for reverse in [False,True]:
        ordered=keys[::-1] if reverse else keys
        for active in [[],[pi]]:
            decision=classify(source([ordered]),owners,pairs,active);expected='SOURCE_INCONSISTENCY' if active else 'NEW_SOURCE_PAIRS'
            assert decision['status']==expected and decision['new_pairs']==([] if active else [pi]);controls.append({'pair':pi,'reversed':reverse,'already_active':bool(active),'passed':True})
for a,b in combinations(range(16),2):
    d=classify(source([[owners[a]['identity'],owners[b]['identity']]]),owners,pairs,[]);assert d['status']=='SOURCE_INCONSISTENCY' and d['inconsistencies'][0]['reason']=='orthogonal-only' and d['new_pairs']==[];controls.append({'orthogonal_owners':[a,b],'passed':True})
fixed=[x for x in inventory['full66_identities'] if x not in [o['identity'] for o in owners]];assert len(fixed)==38
for key in fixed:
    d=classify(source([[key,owners[0]['identity']]]),owners,pairs,[]);assert d['status']=='SOURCE_INCONSISTENCY' and d['inconsistencies'][0]['reason']=='fixed-or-short-original';controls.append({'fixed_original':key,'passed':True})
for o in owners:
    d=classify(source(stock=[o['identity']]),owners,pairs,[]);assert d['status']=='SOURCE_INCONSISTENCY' and d['inconsistencies'][0]['reason']=='stock';controls.append({'stock_original':o['identity'],'passed':True})
assert classify(source(),owners,pairs,[])['status']=='SOURCE_VALID_CANDIDATE';controls.append({'valid_source':True,'passed':True})
keys=[owners[o]['identity'] for o in pairs[0]['owners']];d=classify(source([keys],stock=[owners[0]['identity']]),owners,pairs,[]);assert d['status']=='SOURCE_INCONSISTENCY' and d['new_pairs']==[];controls.append({'mixed_new_pair_and_stock':True,'passed':True})
assert len(controls)==1220;write(OUT/'cut-routing-controls.json',controls)
selected=[next(i for i,p in enumerate(pairs) if p['kind']=='cog_orthogonal' and owners[p['owners'][1]]['identity'][0]==family) for family in ['bracket','insert']]+[next(i for i,p in enumerate(pairs) if p['kind']=='cog_cog')]
positive=[]
for count in [1,2,3]:
    active=sorted(selected[:count]);model,mp=build(active);folder=OUT/f'model-{count}';folder.mkdir();assert model.export_to_file(str(folder/'model.pb'));write(folder/'mapping.json',mp)
    proto=cp_model_pb2.CpModelProto();proto.ParseFromString((folder/'model.pb').read_bytes());check=verify(proto,mp,active);assert check['passed'] and check['active_cog_pairs_verified']==count;write(folder/'checks.json',check);positive.append({'active_pairs':active,'model_sha256':digest(folder/'model.pb'),'variables':len(proto.variables),'constraints':len(proto.constraints)})
negative=[]
for kind in ['cleared-global','wrong-owner-offset','missing-active-pairs','extra-objective','changed-control-hint']:
    wrong=cp_model_pb2.CpModelProto();wrong.CopyFrom(proto);expected=active
    if kind=='cleared-global':wrong.constraints[mp['source_capacity']['profiles'][0]['constraint']].Clear()
    elif kind=='wrong-owner-offset':wrong.constraints[mp['source_capacity']['profiles'][0]['intervals'][0]['interval']].interval.start.offset+=1
    elif kind=='missing-active-pairs':expected=[]
    elif kind=='extra-objective':wrong.objective.scaling_factor=1
    else:wrong.solution_hint.values[0]+=1
    try:verify(wrong,mp,expected)
    except AssertionError:negative.append({'case':kind,'rejected':True})
    else:raise AssertionError('Malformed model accepted: '+kind)
write(OUT/'changed-model-controls.json',positive);write(OUT/'rejection-controls.json',negative)
scripts=['run_h5_independent_cog_lazy_pipeline_20261107.py','check_h5_independent_cog_lazy_candidate_20261107.py','h5_independent_cog_lazy_source_cuts_20261107.py','h5_independent_cog_lazy_model_20261107.py','h5_independent_cog_lazy_model_reader_20261107.py','h5_independent_cog_capacity_model_reader_20261107.py','h5_source_projection_short_core_reader_20261029.py','h5_legacy64_source_readback.py']
for name in scripts:ast.parse((ROOT/'output'/name).read_text(encoding='utf-8'))
inputs=[Path(__file__),BASE/'initial-model/plan.json',BASE/'initial-audit/plan.json',BASE/'initial-audit/checks.json',I/'owner-pairs.json',I/'inventory.json']+[ROOT/'output'/s for s in scripts]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Verification-only controls, never a solver or geometry search. Check both identity orders and active/inactive routing for all258 cog interactions, all120 orthogonal pairs, all38 fixed/short originals and all28 stock identities, plus mixed and valid cases. Build three distinct small changed-pair models to exercise bracket,insert andcog interactions and require exhaustive independent readback. Reject five corrupted model controls. These control model outputs are not used by the runtime construction; their verification time is recorded separately. Freeze the executable pipeline code and initial model before its one bounded call.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'cut_routing_controls':len(controls),'changed_model_readbacks':len(positive),'corrupt_models_rejected':len(negative),'all258_cog_pairs_both_orders_active_and_inactive':True,'control_model_outputs_consumed_as_runtime_geometry':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
