"""Replay the actual66 original contours and describe the observed collision graph."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-lazy-20261107';ROUND=BASE/'search/round-00';OUT=BASE/'source-audit';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();assert load(BASE/'response-audit/checks.json')['passed']
job=load(JOB);rows=load(ROUND/'source-response/candidate-source66.json');spec=load(FIRST/'plan.json');expected=list(map(tuple,load(I/'inventory.json')['full66_identities']))
replayed=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected);assert replayed==load(ROUND/'source-response/original-source-checks.json')
assert replayed['originals']==66 and replayed['same_sheet_pairs']==1632 and replayed['stock_edges']==264 and replayed['cutouts']==90 and replayed['hole_vertices']==10026 and replayed['pair_failures']==32 and replayed['stock_failures']==0 and not replayed['valid']
owners=load(ROUND/'mapping.json')['owners'];lookup={tuple(o['identity']):o['owner'] for o in owners};bad=[p for p in replayed['pairs'] if not p['passed']];adj={o['owner']:set() for o in owners};families=Counter()
for p in bad:
    a,b=map(tuple,p['keys']);aa,bb=lookup[a],lookup[b];adj[aa].add(bb);adj[bb].add(aa);families[tuple(sorted((a[0],b[0])))]+=1
components=[];seen=set()
for owner in adj:
    if owner in seen:continue
    todo=[owner];comp=[]
    while todo:
        x=todo.pop()
        if x in seen:continue
        seen.add(x);comp.append(x);todo.extend(adj[x]-seen)
    components.append({'owners':sorted(comp),'originals':[owners[i]['identity'] for i in sorted(comp)],'edges':sum(len(adj[i]) for i in comp)//2})
details={'scope':'This one returned candidate only; no packing capacity or allocation exclusion.','failing_pairs':bad,'family_pair_counts':[{'families':list(k),'pairs':v} for k,v in sorted(families.items())],'colliding_movers':sum(bool(v) for v in adj.values()),'connected_components':components,'positive_area_intersections':sum(p['intersection_area_mm2']>0 for p in bad),'clearance_only_failures':sum(p['intersection_area_mm2']==0 for p in bad),'summed_pairwise_intersection_area_mm2':sum(p['intersection_area_mm2'] for p in bad),'maximum_pair_intersection_area_mm2':max(p['intersection_area_mm2'] for p in bad)}
write(OUT/'replayed-source-checks.json',replayed);write(OUT/'collision-graph.json',details)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',I/'inventory.json',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',ROUND/'mapping.json',ROUND/'source-response/candidate-source66.json',ROUND/'source-response/original-source-checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replay every original outer and hole from the saved66 poses and require exact agreement with the runtime source check for all1632 pairs and264stock edges. Describe only the observed collision graph of this candidate, including involved movers, connected components and intersection areas. The graph cannot establish a continuous or whole-allocation exclusion. Preserve the invalid candidate for a genuinely new source-derived repair analysis; never reopen its closed search.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'originals_replayed':66,'same_sheet_pairs':1632,'stock_edges':264,'holes':90,'hole_vertices':10026,'pair_failures':32,'stock_failures':0,'source_valid66':False,'colliding_movers':details['colliding_movers'],'positive_area_intersections':details['positive_area_intersections'],'clearance_only_failures':details['clearance_only_failures'],'nontrivial_collision_components':sum(c['edges']>0 for c in components),'source_pair_checks_identical_to_runtime':True,'solver_calls':0,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
