"""Independent readback of the closed two-round staged construction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_independent_cog_lazy_model_reader_20261107 import verify
from h5_source_projection_short_core_reader_20261029 import violations
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-lazy-20261107';SEARCH=BASE/'search';OUT=BASE/'response-audit';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[SEARCH/'plan.json',SEARCH/'supervisor-opened.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
plan=load(SEARCH/'plan.json');result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');job=load(SEARCH/'job.json');supervisor=load(SEARCH/'supervisor-opened.json')
assert plan['algorithm_seconds']==60 and plan['shared_seconds']==90 and plan['maximum_pipeline_calls']==1 and plan['maximum_rounds']==4 and plan['maximum_solver_calls_per_pair_set']==1
assert plan['first_solver_cap_seconds']==30 and plan['later_solver_cap_seconds']==8 and plan['source_check_reserve_seconds']==4 and not plan['retry_permitted'] and plan['every_runtime_build_audit_source_check_and_solve_charged']
charge=load(BASE/'initial-model/budget.json')['preparation_seconds_charged'];assert charge==sum(load(BASE/'initial-model/final-preparation-charges.json').values())==plan['preparation_seconds_charged']==result['preparation_seconds_charged']==supervisor['preparation_seconds_charged']
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['tree_closed'] and not process['repeat_permitted'] and job==process['job'] and job['closed'] and job['active_processes']==0
assert job['reason_code']==job['error_code']==job['root_exit_code']==0 and job['assigned_before_resume'] and job['resumed'] and job['job_committed_memory_limit']==supervisor['aggregate_memory_bytes']==2**31 and job['peak_job_committed_memory']<2**31
assert job['maximum_ms']==supervisor['maximum_ms'] and job['complete_ms']<job['maximum_ms'] and process['seconds_including_preparation']>=charge+job['complete_ms']/1000
assert result['closed'] and result['status']=='UNKNOWN' and result['rounds_attempted']==result['solver_calls_with_returned_results']==result['solver_calls_opened']==2 and result['source_checker_processes']==1 and result['unchanged_model_retries']==0 and not result['source_valid66'] and not result['any_allocation_excluded']
assert len(result['rounds'])==2 and not (SEARCH/'round-02').exists() and not (SEARCH/'round-03').exists()
active=[];details=[];assignments=incumbents=0;source_pairs=load(I/'owner-pairs.json');last_time=charge
for index in [0,1]:
    folder=SEARCH/f'round-{index:02d}';request=load(folder/'request.json');opened=load(folder/'opened.json');r=load(folder/'result.json');prep=load(folder/'preparation.json');child=load(folder/'solver-child-process.json')
    assert request['round']==opened['round']==index and request['active_pairs']==opened['active_pairs']==active and request['maximum_calls']==opened['maximum_calls']==1 and not request['retry_permitted'] and not opened['retry_permitted']
    assert request['changed_pair_set_required']==(index>0) and request['algorithm_seconds']==60 and request['shared_seconds']==90 and request['source_check_reserve_seconds']==4 and request['per_call_limit_seconds']==[30,8][index]
    proto=cp_model_pb2.CpModelProto();proto.ParseFromString((folder/'model.pb').read_bytes());assert proto==text_format.Parse((folder/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto())
    mapping=load(folder/'mapping.json');checked=verify(proto,mapping,active);saved=load(folder/'model-audit.json')
    for k,v in checked.items():assert saved[k]==v,(index,k)
    assert digest(folder/'model.pb')==prep['model_sha256']==opened['model_sha256'] and prep['active_pairs']==active and prep['initial_frozen_model_reused']==(index==0) and prep['fresh_complete_model_audit']==(index>0)
    if index==0:assert digest(folder/'model.pb')==digest(BASE/'initial-model/model.pb') and len(proto.variables)==1332 and len(proto.constraints)==4712
    else:assert len(proto.variables)==5041 and len(proto.constraints)==12819 and len(active)==32
    parameters=text_format.Parse((folder/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters())
    assert {f.name for f,v in parameters.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','log_search_progress','log_to_stdout','ignore_subsolvers'}
    assert parameters.max_time_in_seconds==opened['parameters']['max_time_in_seconds']==r['allocated_solve_seconds']==[30,8][index]
    assert parameters.num_search_workers==4 and parameters.random_seed==0 and parameters.log_search_progress and not parameters.log_to_stdout and list(parameters.ignore_subsolvers)==['fj']
    assert parameters.max_time_in_seconds+opened['algorithm_seconds_including_preparation_at_open']<=56
    response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());status=cp_model_pb2.CpSolverStatus.Name(response.status)
    assert status==r['solver_status']==['OPTIMAL','UNKNOWN'][index] and r['closed'] and r['solver_calls']==1 and r['has_assignment']==bool(response.solution) and response.wall_time==r['solver_wall_seconds'] and response.num_branches==r['branches'] and response.num_conflicts==r['conflicts']
    assert r['returned_solve_seconds']>=response.wall_time and r['solve_slice_overrun_seconds']==max(0.,r['returned_solve_seconds']-r['allocated_solve_seconds'])
    assert last_time<=prep['algorithm_seconds_including_preparation']<=opened['algorithm_seconds_including_preparation_at_open']<=r['algorithm_seconds_including_preparation']<=child['algorithm_seconds_including_preparation']
    assert child['exit_code']==0 and not child['timeout'] and child['seconds']>=prep['seconds']+r['returned_solve_seconds'] and result['rounds'][index]['solver_child_process']==child and result['rounds'][index]['result']==r
    assert (folder/'solver-child-stderr.txt').read_bytes()==b'' and 'status: '+status in (folder/'solver.log').read_text(encoding='utf-8')
    files=sorted((folder/'incumbents').glob('*.json'));assert len(files)==r['incumbents']==[1,0][index]
    for sequence,p in enumerate(files):
        inc=load(p);assert inc['sequence']==sequence;check=violations(proto,inc['values']);assert not check['failed_constraints'];incumbents+=1
    next_pairs=[]
    if response.solution:
        values=load(folder/'assignment.json');assert values==list(response.solution);check=violations(proto,values);assert not check['failed_constraints'] and check==load(folder/'assignment-check.json');assignments+=1
        rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json');identities=[]
        for o in mapping['owners']:
            modes=[m for m in o['modes'] if values[m['selector']]];assert len(modes)==1;m=modes[0];identities.append(o['identity']);xy=[values[v]/100+mapping['world_origin_mm'][k] for k,v in enumerate(o['positions'])]
            rows.append({'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]+m['translation_from_lower_left'][k] for k in [0,1]]}})
        assert rows==load(folder/'source-response/candidate-source66.json') and len(rows)==66 and sorted((r['part_id'],r['copy_index']) for r in rows)==sorted(map(tuple,load(I/'inventory.json')['full66_identities']))
        source=load(folder/'source-response/original-source-checks.json');decision=load(folder/'source-response/decision.json');summary=load(folder/'source-response/checks.json');source_process=load(folder/'source-child-process.json')
        assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026 and source['pair_failures']==sum(not p['passed'] for p in source['pairs'])==32 and source['stock_failures']==0 and not source['valid']
        owner_by_id={tuple(o['identity']):o['owner'] for o in mapping['owners']};pair_by_owners={tuple(sorted(p['owners'])):i for i,p in enumerate(source_pairs)}
        expected=[]
        for p in source['pairs']:
            if p['passed']:continue
            aa,bb=map(tuple,p['keys']);assert aa in owner_by_id and bb in owner_by_id;key=tuple(sorted([owner_by_id[aa],owner_by_id[bb]]));assert key in pair_by_owners;pi=pair_by_owners[key];assert pi not in active;expected.append(pi)
        next_pairs=sorted(expected);assert len(set(next_pairs))==len(next_pairs)==32 and decision['status']==summary['decision']=='NEW_SOURCE_PAIRS' and decision['new_pairs']==summary['new_pairs']==next_pairs and not decision['inconsistencies'] and not summary['source_valid66']
        assert source_process['exit_code']==0 and not source_process['timeout'] and child['algorithm_seconds_including_preparation']<=summary['algorithm_seconds_including_preparation']<=source_process['algorithm_seconds_including_preparation'] and (folder/'source-child-stderr.txt').read_bytes()==b''
        assert result['rounds'][index]['source_child_process']==source_process and result['rounds'][index]['new_pairs']==next_pairs and result['rounds'][index]['source_pair_failures']==32 and result['rounds'][index]['source_stock_failures']==0
        for name,h in load(folder/'source-response/plan.json')['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
        last_time=source_process['algorithm_seconds_including_preparation'];active=sorted(set(active)|set(next_pairs))
    else:
        assert not (folder/'assignment.json').exists() and not (folder/'source-response').exists();last_time=child['algorithm_seconds_including_preparation']
    details.append({'round':index,**checked,'status':status,'branches':response.num_branches,'conflicts':response.num_conflicts,'allocated_solve_seconds':r['allocated_solve_seconds'],'returned_solve_seconds':r['returned_solve_seconds'],'solve_slice_overrun_seconds':r['solve_slice_overrun_seconds'],'new_source_pairs':next_pairs})
assert active==result['accumulated_pairs_for_next_round'] and len(active)==32 and assignments==incumbents==1 and last_time<=result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']
assert result['algorithm_overrun_seconds']==max(0.,result['algorithm_seconds_including_preparation']-60)==0 and process['seconds_including_preparation']<90
for name in ['stderr.txt','supervisor-stdout.txt','supervisor-stderr.txt']:assert (SEARCH/name).read_bytes()==b''
write(OUT/'round-checks.json',details);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),ROOT/'output/h5_independent_cog_lazy_model_reader_20261107.py',ROOT/'output/h5_independent_cog_capacity_model_reader_20261107.py',ROOT/'output/h5_source_projection_short_core_reader_20261029.py']+[p for p in SEARCH.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently read both complete model protobufs and every field, all parameters, response bytes, assignments and incumbents. Reconstruct all66 poses independently from the first assignment. Recompute the complete32-pair cut set directly from every failed original identity pair rather than trusting the routing helper. Require strictly changed model pairs, original60/90-second charged budget, fixed30/8 solver caps, no repeat after UNKNOWN and calibrated Windows Job closure. Geometry itself is replayed in a separate original-source audit; this audit does not turn a necessary candidate into a valid layout.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_input_bindings_verified':len(bindings),'closed_pipeline_calls':1,'closed_solver_calls':2,'statuses':['OPTIMAL','UNKNOWN'],'first_necessary_assignment_originals':66,'source_valid66':False,'assignments_verified':assignments,'incumbents_verified':incumbents,'full_source_checker_calls':1,'source_pair_failures':32,'source_stock_failures':0,'new_complete_source_pair_constraints':32,'initial_variables':1332,'initial_constraints':4712,'second_variables':5041,'second_constraints':12819,'preparation_seconds_charged':charge,'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'algorithm_overrun_seconds':0,'shared_overrun_seconds':0,'solve_slice_overrun_seconds':[r['solve_slice_overrun_seconds'] for r in details],'peak_job_committed_memory_bytes':job['peak_job_committed_memory'],'all_descendants_closed':True,'no_unchanged_model_retry':True,'source_geometry_replay_still_required':True,'any_allocation_excluded':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
