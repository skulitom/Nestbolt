"""One bounded pipeline; every later solver call needs a new source-witnessed pair set."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-lazy-20261107';INITIAL=BASE/'initial-model';OUT=BASE/'search'
PY=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe';SHOP=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def round_child(folder,started):
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    from h5_independent_cog_lazy_model_20261107 import build
    from h5_independent_cog_lazy_model_reader_20261107 import verify
    from h5_source_projection_short_core_reader_20261029 import violations
    request=load(folder/'request.json');index=request['round'];active=request['active_pairs'];assert active==sorted(set(active))
    if index==0:assert active==[]
    else:
        prior=OUT/f'round-{index-1:02d}';before=load(prior/'request.json')['active_pairs'];decision=load(prior/'source-response/decision.json')
        assert decision['status']=='NEW_SOURCE_PAIRS' and decision['new_pairs'] and not set(before)&set(decision['new_pairs']) and active==sorted(set(before)|set(decision['new_pairs'])) and set(before)<set(active)
    begin=time.perf_counter()
    if index==0:
        frozen=load(BASE/'initial-audit/checks.json');assert frozen['passed'] and digest(INITIAL/'model.pb')==frozen['model_sha256']
        model=cp_model.CpModel();assert model.proto.parse_text_format((INITIAL/'model.pbtxt').read_text(encoding='utf-8')) and model.validate()==''
        mapping=load(INITIAL/'mapping.json');model_check=frozen
    else:model,mapping=build(active)
    assert model.export_to_file(str(folder/'model.pb')) and model.export_to_file(str(folder/'model.pbtxt'));write(folder/'mapping.json',mapping)
    proto=cp_model_pb2.CpModelProto();proto.ParseFromString((folder/'model.pb').read_bytes());assert proto==text_format.Parse((folder/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto())
    if index==0:assert digest(folder/'model.pb')==frozen['model_sha256']
    else:model_check=verify(proto,mapping,active)
    assert model_check['passed'] and mapping['active_cog_pairs']==active and model.validate()==''
    write(folder/'model-audit.json',model_check);write(folder/'preparation.json',{'seconds':time.perf_counter()-begin,'initial_frozen_model_reused':index==0,'fresh_complete_model_audit':index>0,'model_sha256':digest(folder/'model.pb'),'active_pairs':active,'algorithm_seconds_including_preparation':time.perf_counter()-started})
    remaining=min(30 if index==0 else 8,60-(time.perf_counter()-started)-4)
    if remaining<=0:
        write(folder/'result.json',{'closed':True,'solver_calls':0,'solver_status':None,'reason':'NO_SOLVE_TIME','has_assignment':False,'incumbents':0,'algorithm_seconds_including_preparation':time.perf_counter()-started});return
    solver=cp_model.CpSolver();parameters={'max_time_in_seconds':remaining,'num_search_workers':4,'random_seed':0,'log_search_progress':True,'log_to_stdout':False,'ignore_subsolvers':['fj']}
    for k,v in parameters.items():
        if isinstance(v,list):getattr(solver.parameters,k).extend(v)
        else:setattr(solver.parameters,k,v)
    with (folder/'parameters.pbtxt').open('x',encoding='utf-8',newline='\n') as f:f.write(str(solver.parameters))
    write(folder/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'round':index,'active_pairs':active,'parameters':parameters,'model_sha256':digest(folder/'model.pb'),'maximum_calls':1,'retry_permitted':False,'algorithm_seconds_including_preparation_at_open':time.perf_counter()-started})
    class Capture(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.count=0
        def on_solution_callback(self):
            write(folder/'incumbents'/f'{self.count:03d}.json',{'sequence':self.count,'solver_wall_seconds':self.wall_time,'values':[self.value(model.get_int_var_from_proto_index(i)) for i in range(len(model.proto.variables))]});self.count+=1
    capture=Capture()
    with (folder/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda value:(f.write(value+'\n'),f.flush());begin=time.perf_counter();status=solver.solve(model,capture);elapsed=time.perf_counter()-begin
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(folder/'response.pb').write_bytes(response.SerializeToString())
    if response.solution:
        values=list(response.solution);checked=violations(proto,values);assert not checked['failed_constraints'];write(folder/'assignment.json',values);write(folder/'assignment-check.json',checked)
    result={'closed':True,'solver_calls':1,'solver_status':solver.status_name(status),'allocated_solve_seconds':remaining,'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'solve_slice_overrun_seconds':max(0.,elapsed-remaining),'branches':response.num_branches,'conflicts':response.num_conflicts,'has_assignment':bool(response.solution),'incumbents':capture.count,'algorithm_seconds_including_preparation':time.perf_counter()-started};write(folder/'result.json',result)

def run_process(command,folder,stem,started):
    begin=time.perf_counter()
    try:
        r=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-started)));stdout,stderr=r.stdout,r.stderr;record={'exit_code':r.returncode,'timeout':False}
    except subprocess.TimeoutExpired as exc:stdout,stderr=exc.stdout or b'',exc.stderr or b'';record={'exit_code':None,'timeout':True}
    (folder/(stem+'-stdout.txt')).write_bytes(stdout);(folder/(stem+'-stderr.txt')).write_bytes(stderr);record['seconds']=time.perf_counter()-begin;record['algorithm_seconds_including_preparation']=time.perf_counter()-started;write(folder/(stem+'-process.json'),record);return record

def pipeline_child(started):
    opened=load(OUT/'plan.json')
    # Source bindings and prepared code are immutable for all rounds.
    queue=[OUT/'plan.json'];seen=set()
    while queue:
        p=queue.pop()
        if p in seen:continue
        seen.add(p)
        for name,h in load(p).get('inputs',{}).items():
            z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name
            if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
    active=[];rounds=[];status='ROUND_LIMIT';source_valid=False
    for index in range(4):
        if time.perf_counter()-started>=56:status='ALGORITHM_TIME_LIMIT';break
        folder=OUT/f'round-{index:02d}';folder.mkdir();(folder/'incumbents').mkdir()
        write(folder/'request.json',{'round':index,'active_pairs':active,'per_call_limit_seconds':30 if index==0 else 8,'maximum_calls':1,'retry_permitted':False,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'changed_pair_set_required':index>0})
        process=run_process([str(PY),str(Path(__file__)),'--round',str(folder),str(started)],folder,'solver-child',started)
        record={'round':index,'active_pairs':active,'solver_child_process':process};rounds.append(record)
        if process['timeout'] or process['exit_code']!=0 or not (folder/'result.json').exists():status='ROUND_PROCESS_STOP';record['missing_completed_result']=True;break
        result=load(folder/'result.json');record['result']=result
        if result['solver_calls']==0:assert result['reason']=='NO_SOLVE_TIME';status='ALGORITHM_TIME_LIMIT';break
        if not result['has_assignment']:
            assert result['solver_status'] in ['UNKNOWN','INFEASIBLE','MODEL_INVALID'];status=result['solver_status'];break
        assert result['solver_status'] in ['FEASIBLE','OPTIMAL']
        process=run_process([str(SHOP),str(ROOT/'output/check_h5_independent_cog_lazy_candidate_20261107.py'),str(folder),str(started)],folder,'source-child',started);record['source_child_process']=process
        if process['timeout'] or process['exit_code']!=0 or not (folder/'source-response/decision.json').exists():status='SOURCE_PROCESS_STOP';break
        decision=load(folder/'source-response/decision.json');record['source_decision']=decision['status'];record['new_pairs']=decision['new_pairs'];record['source_pair_failures']=decision['pair_failures'];record['source_stock_failures']=decision['stock_failures']
        if decision['status']=='SOURCE_VALID_CANDIDATE':source_valid=True;status=decision['status'];break
        if decision['status']!='NEW_SOURCE_PAIRS':status=decision['status'];break
        assert decision['new_pairs'] and not set(active)&set(decision['new_pairs']);active=sorted(set(active)|set(decision['new_pairs']))
        print({'round':index,'new_source_pairs':len(decision['new_pairs']),'next_active_pairs':len(active),'algorithm_seconds_including_preparation':time.perf_counter()-started},flush=True)
    elapsed=time.perf_counter()-started
    write(OUT/'result.json',{'closed':True,'status':status,'rounds':rounds,'rounds_attempted':len(rounds),'solver_calls_with_returned_results':sum(r.get('result',{}).get('solver_calls',0) for r in rounds),'solver_calls_opened':sum((OUT/f'round-{r["round"]:02d}'/'opened.json').exists() for r in rounds),'source_checker_processes':sum('source_child_process' in r for r in rounds),'source_valid66':source_valid,'accumulated_pairs_for_next_round':active,'preparation_seconds_charged':opened['preparation_seconds_charged'],'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'unchanged_model_retries':0,'any_allocation_excluded':False,'native_calls':0,'H5_complete':False})

def main():
    assert load(BASE/'initial-audit/checks.json')['passed'] and load(BASE/'pipeline-controls/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py')
    charge=load(INITIAL/'budget.json')['preparation_seconds_charged'];started=time.perf_counter()-charge
    files=[Path(__file__),ROOT/'output/h5_independent_cog_lazy_model_20261107.py',ROOT/'output/h5_independent_cog_lazy_model_reader_20261107.py',ROOT/'output/h5_independent_cog_capacity_model_reader_20261107.py',ROOT/'output/check_h5_independent_cog_lazy_candidate_20261107.py',ROOT/'output/h5_independent_cog_lazy_source_cuts_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_source_projection_short_core_reader_20261029.py',BASE/'initial-audit/plan.json',BASE/'initial-audit/checks.json',BASE/'pipeline-controls/plan.json',BASE/'pipeline-controls/checks.json']+[p for p in INITIAL.glob('*') if p.is_file()]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'algorithm_seconds':60,'shared_seconds':90,'maximum_pipeline_calls':1,'maximum_rounds':4,'maximum_solver_calls_per_pair_set':1,'first_solver_cap_seconds':30,'later_solver_cap_seconds':8,'source_check_reserve_seconds':4,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'retry_permitted':False,'preparation_seconds_charged':charge,'every_runtime_build_audit_source_check_and_solve_charged':True,'originals_required_each_candidate':66,'stop_on_unknown_infeasible_invalid_or_inconsistency':True,'same_model_retry_forbidden':True,'method':'One new staged construction. Import the frozen necessary initial model. After each returned assignment independently check every constraint and reconstruct all66 original contours. Only complete interactions for all new source-witnessed cog-pair failures may be added; preserve all old pairs and independently read every changed model before its one call. Round solver processes end before source-check processes start, so their memory lifetimes do not overlap. The single calibrated Windows Job bounds the entire descendant tree; all measured costs and overruns are preserved.'})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
    cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'aggregate_memory_bytes':2**31,'preparation_seconds_charged':charge,'retry_permitted':False})
    command=subprocess.list2cmdline([str(PY),str(Path(__file__)),'--pipeline',str(started)])
    args=[str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),command,str(ROOT),'version4']
    completed=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap/1000+8);(OUT/'supervisor-stdout.txt').write_bytes(completed.stdout);(OUT/'supervisor-stderr.txt').write_bytes(completed.stderr)
    job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    result={'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':completed.returncode,'timeout':job['reason_code']==1,'job':job,'tree_closed':True,'repeat_permitted':False};write(OUT/'process.json',result);print(result,flush=True);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed pipeline result; this pipeline stays closed.',flush=True)

if __name__=='__main__':
    if '--round' in sys.argv:round_child(Path(sys.argv[2]),float(sys.argv[3]))
    elif '--pipeline' in sys.argv:pipeline_child(float(sys.argv[2]))
    else:main()
