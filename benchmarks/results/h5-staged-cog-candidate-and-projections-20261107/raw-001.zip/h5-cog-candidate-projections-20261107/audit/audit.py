"""Enumerate exact region vertices and prove each projection by the variational inequality."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time,shutil
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-candidate-projections-20261107';OUT=BASE/'audit';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';H=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';L=ROOT/'output/h5-independent-cog-lazy-20261107';ROUND=L/'search/round-00'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
templates=load(H/'templates.json');regions=load(BASE/'regions.json');expected=[];continuous_planes=source_supports=0
for t in templates:
    box=t['relative_grid_bounds'];bounds=[{'coefficients':[-1,0],'upper':-box[0][0]},{'coefficients':[1,0],'upper':box[0][1]},{'coefficients':[0,-1],'upper':-box[1][0]},{'coefficients':[0,1],'upper':box[1][1]}]
    for p in t['halfplanes']:
        if p['halfplane'] not in t['retained_halfplane_ids']:continue
        assert F(p['lower'],100)>=max(F(v['threshold_mm']) for v in p['source_supports']) and p['normal_length_integer_upper']**2>=sum(v*v for v in p['coefficients']);source_supports+=len(p['source_supports'])
        expected.append({'class':t['class'],'kind':'halfplane','source_id':p['halfplane'],'planes':bounds+[{'coefficients':[-x for x in p['coefficients']],'upper':-p['lower']}]})
    for r in t['pockets']:
        vertices=[tuple(map(F,p)) for p in r['hull_vertices']]
        for edge,(a,b,p) in enumerate(zip(vertices,vertices[1:]+vertices[:1],r['planes'])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));normal=[dy/den,-dx/den];error=sum(abs(normal[k]-F(p['unreduced_coefficients'][k],1000000))*F(max(map(abs,box[k])),100) for k in [0,1]);rhs=sum(normal[k]*a[k] for k in [0,1])
            assert F(p['rounding_error_bound_mm'])==error and F(p['divisor']*p['upper'],100000000)+error<=rhs-F('1e-7')
            if edge not in r['retained_edges']:assert sum(max(c*lo,c*hi) for c,(lo,hi) in zip(p['coefficients'],box))<=p['upper']
            continuous_planes+=1
        expected.append({'class':t['class'],'kind':'pocket','source_id':r['region'],'planes':bounds+[{'coefficients':r['planes'][e]['coefficients'],'upper':r['planes'][e]['upper']} for e in r['retained_edges']]})
assert len(expected)==len(regions)==303
vertex_count=0
for wanted,row in zip(expected,regions):
    assert {k:v for k,v in row.items() if k not in ['vertices','empty']}==wanted;planes=row['planes'];vertices=[]
    for a,b in combinations(planes,2):
        ax,ay=a['coefficients'];bx,by=b['coefficients'];det=ax*by-ay*bx
        if not det:continue
        p=(F(a['upper']*by-ay*b['upper'],det),F(ax*b['upper']-a['upper']*bx,det))
        if all(sum(c*x for c,x in zip(q['coefficients'],p))<=q['upper'] for q in planes):vertices.append(p)
    vertices=sorted(set(vertices));vertices=vertices if len(vertices)<=2 else hull(vertices);actual=[tuple(map(F,p)) for p in row['vertices']]
    assert set(vertices)==set(actual) and len(vertices)==len(actual) and row['empty']==(not vertices);vertex_count+=len(vertices)
owners=load(BASE/'owners.json');mapping=load(ROUND/'mapping.json');values=load(ROUND/'assignment.json');assert len(owners)==28
for o,m in zip(owners,mapping['owners']):
    chosen=[x for x in m['modes'] if values[x['selector']]];assert len(chosen)==1;x=chosen[0]
    assert o=={'owner':m['owner'],'identity':m['identity'],'mode':x['mode'],'position_grid':[values[v] for v in m['positions']],'position_bounds_grid':x['integer_world_lower_left_bounds'],'rotation_radians':x['rotation_radians'],'mirrored':x['mirrored'],'translation_from_lower_left':x['translation_from_lower_left']}
lookup={(r['class'],r['kind'],r['source_id']):r for r in regions};aliases=load(I/'aliases.json');source=load(I/'owner-pairs.json');pairs=load(BASE/'pair-projections.json');ranks=load(BASE/'all-ranked-projections.json');assert len(source)==len(pairs)==len(ranks)==258
count=zero=0
for pi,(s,p,rank) in enumerate(zip(source,pairs,ranks)):
    a,b=(owners[i] for i in s['owners']);delta=[b['position_grid'][k]-a['position_grid'][k] for k in [0,1]]
    if s['kind']=='cog_orthogonal':
        alias=next(x for x in aliases if x['family']==b['identity'][0] and x['mode']==b['mode']);cid=alias['class'];q=alias['matrix'];offset=alias['offset_grid']
    else:cid='cog_cog';q=[[1,0],[0,1]];offset=[0,0]
    point=[sum(q[k][j]*delta[j] for j in [0,1])+offset[k] for k in [0,1]]
    assert p['pair']==rank['pair']==pi and p['owners']==s['owners'] and p['kind']==s['kind'] and p['class']==cid and p['matrix']==q and p['offset_grid']==offset and p['candidate_relative_grid']==point
    required={(r['kind'],r['source_id']) for r in regions if r['class']==cid and not r['empty']};actual={(r['kind'],r['source_id']) for r in rank['ranked']};assert actual==required and len(actual)==len(rank['ranked'])
    for r in rank['ranked']:
        region=lookup[(cid,r['kind'],r['source_id'])];v=list(map(F,r['point_grid']));distance=F(r['distance_squared_grid']);assert distance==sum((v[k]-point[k])**2 for k in [0,1])
        assert all(sum(a*x for a,x in zip(plane['coefficients'],v))<=plane['upper'] for plane in region['planes'])
        # For convex K, q is the Euclidean projection of p iff
        # (p-q) dot (z-q) <= 0 for every vertex z of K.
        assert all(sum((point[k]-v[k])*(F(z[k])-v[k]) for k in [0,1])<=0 for z in region['vertices']);count+=1
    assert rank['ranked']==sorted(rank['ranked'],key=lambda r:(F(r['distance_squared_grid']),r['kind'],r['source_id']))
    best=rank['ranked'][0];assert p['selected_kind']==best['kind'] and p['selected_source_id']==best['source_id'] and p['selected_projection_grid']==best['point_grid'] and p['distance_squared_grid']==best['distance_squared_grid'];zero+=F(best['distance_squared_grid'])==0
components=load(I/'components.json');rectangles=load(I/'mode-rectangles.json');orthogonal=load(BASE/'orthogonal-separators.json');source_orth=load(I/'component-pairs.json');assert len(orthogonal)==len(source_orth)==268
for r,s in zip(orthogonal,source_orth):
    assert r['components']==s['components'] and r['owners']==s['owners'];a,b=(components[i] for i in s['components']);oa,ob=(owners[i] for i in s['owners']);aa=rectangles[oa['identity'][0]][oa['mode']]['rectangles'][a['piece']]['outward_offsets_grid'];bb=rectangles[ob['identity'][0]][ob['mode']]['rectangles'][b['piece']]['outward_offsets_grid']
    opts=[(0,oa['owner'],ob['owner'],bb[0]-aa[2]-23),(0,ob['owner'],oa['owner'],aa[0]-bb[2]-23),(1,oa['owner'],ob['owner'],bb[1]-aa[3]-23),(1,ob['owner'],oa['owner'],aa[1]-bb[3]-23)];slacks=[upper-(owners[x]['position_grid'][axis]-owners[y]['position_grid'][axis]) for axis,x,y,upper in opts];best=max(range(4),key=lambda i:(slacks[i],-i));assert slacks[best]>=0 and r['direction']==best and (r['axis'],r['positive_owner'],r['negative_owner'],r['upper'])==opts[best] and r['candidate_slack_grid']==slacks[best]
summary=load(BASE/'checks.json');assert summary['cached_source_regions']==303 and summary['exact_point_region_projections']==count and summary['candidate_pairs_already_in_certified_region']==zero and summary['candidate_pairs_needing_relative_motion']==258-zero
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py']+list(BASE.glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently enumerate intersections of every pair of region-boundary lines and keep all feasible vertices, then compare exact hulls with the clipped polygons. Recheck retained halfplane lower bounds and pocket rounding-error/inset implications for real coordinates, including redundant-edge domain maxima. Reconstruct every chosen original mode and canonical pair difference. For every point/region projection require exact membership, squared distance and the convex variational inequality against every vertex; then verify deterministic nearest ranking. Check every already satisfied source rectangle separator directly from original mode offsets. This prepares one source-safe convex-region choice per pair, not a placement, LP result or global exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'source_region_polytopes_verified':303,'exact_region_vertices_verified':vertex_count,'real_coordinate_pocket_plane_implications':continuous_planes,'retained_halfplane_original_support_proofs':source_supports,'exact_projection_optimality_certificates':count,'original_selected_modes_verified':28,'cog_physical_pairs_verified':258,'zero_distance_pairs':zero,'pairs_requiring_relative_motion':258-zero,'orthogonal_component_separators_verified':268,'recursive_bindings_verified':len(bindings),'model_prepared':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
