"""Exact projections of the new necessary candidate into certified pair regions."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_exact_convex_partition_tools_20261029 import hull,area
ROOT=Path(__file__).resolve().parents[1];I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';H=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';L=ROOT/'output/h5-independent-cog-lazy-20261107';ROUND=L/'search/round-00';OUT=ROOT/'output/h5-cog-candidate-projections-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clip(poly,n,b):
    out=[]
    for a,z in zip(poly,poly[1:]+poly[:1]):
        fa=sum(n[k]*a[k] for k in [0,1])-b;fz=sum(n[k]*z[k] for k in [0,1])-b
        if fa<=0:out.append(a)
        if (fa<0<fz) or (fz<0<fa):
            t=fa/(fa-fz);out.append(tuple(a[k]+t*(z[k]-a[k]) for k in [0,1]))
    points=sorted(set(out));return points if len(points)<=2 else hull(points)
def nearest(poly,planes,p):
    if all(sum(n[k]*p[k] for k in [0,1])<=b for n,b in planes):return p,F(0)
    if len(poly)==1:return poly[0],sum((poly[0][k]-p[k])**2 for k in [0,1])
    choices=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        v=[b[k]-a[k] for k in [0,1]];den=sum(x*x for x in v)
        if not den:continue
        t=max(F(0),min(F(1),sum((p[k]-a[k])*v[k] for k in [0,1])/den));q=tuple(a[k]+t*v[k] for k in [0,1]);d=sum((q[k]-p[k])**2 for k in [0,1]);choices.append((d,q))
    assert choices;d,q=min(choices);return q,d
assert load(L/'response-audit/checks.json')['passed'] and load(L/'source-audit/checks.json')['passed'] and load(H/'audit-v2/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();templates=load(H/'templates.json');cache=[]
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',H/'plan.json',H/'templates.json',H/'audit-v2/plan.json',H/'audit-v2/checks.json',I/'audit/plan.json',I/'audit/checks.json',I/'family-modes.json',I/'aliases.json',I/'owner-pairs.json',I/'mode-rectangles.json',I/'component-pairs.json',I/'components.json',ROUND/'mapping.json',ROUND/'assignment.json',ROUND/'source-response/candidate-source66.json',L/'response-audit/plan.json',L/'response-audit/checks.json',L/'source-audit/plan.json',L/'source-audit/checks.json',L/'search/process.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A genuinely new local construction derived from the returned66-part necessary candidate, not another call to its closed model. Hold the selected legal source modes and consider all28 original translations. Clip each certified halfplane/pocket against its full relative domain using exact rationals; project every actual candidate pair difference onto every nonempty convex choice. Rank by exact squared distance and deterministic kind/id tie-break. Choose the nearest source-safe region for each of258 cog interactions and an already satisfied axis separator for each of268 orthogonal component pairs. These choices propose one convex translation repair; no LP or full-source-valid layout is claimed here. The complete closed pipeline process must be charged before any later construction consuming this candidate.','position_units_per_mm':100,'world_origin_mm':[0,2100],'prepare_cap_seconds':30,'audit_cap_seconds':90,'solver_calls':0,'retry_permitted':False})
for t in templates:
    bounds=t['relative_grid_bounds'];boxplanes=[([-1,0],-bounds[0][0]),([1,0],bounds[0][1]),([0,-1],-bounds[1][0]),([0,1],bounds[1][1])]
    options=[('halfplane',r['halfplane'],[([-v for v in r['coefficients']],-r['lower'])]) for r in t['halfplanes'] if r['halfplane'] in t['retained_halfplane_ids']]
    options.extend(('pocket',r['region'],[(r['planes'][e]['coefficients'],r['planes'][e]['upper']) for e in r['retained_edges']]) for r in t['pockets'])
    for kind,rid,source_planes in options:
        poly=[(F(bounds[0][0]),F(bounds[1][0])),(F(bounds[0][1]),F(bounds[1][0])),(F(bounds[0][1]),F(bounds[1][1])),(F(bounds[0][0]),F(bounds[1][1]))];planes=boxplanes+source_planes
        for n,b in source_planes:
            poly=clip(poly,n,b)
            if not poly:break
        assert all(all(sum(n[k]*v[k] for k in [0,1])<=b for n,b in planes) for v in poly)
        cache.append({'class':t['class'],'kind':kind,'source_id':rid,'planes':[{'coefficients':n,'upper':b} for n,b in planes],'vertices':[[str(v) for v in p] for p in poly],'empty':not poly})
mapping=load(ROUND/'mapping.json');values=load(ROUND/'assignment.json');owners=[]
for o in mapping['owners']:
    active=[m for m in o['modes'] if values[m['selector']]];assert len(active)==1;mode=active[0];owners.append({'owner':o['owner'],'identity':o['identity'],'mode':mode['mode'],'position_grid':[values[v] for v in o['positions']],'position_bounds_grid':mode['integer_world_lower_left_bounds'],'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation_from_lower_left':mode['translation_from_lower_left']})
aliases=load(I/'aliases.json');pairs=[];all_projections=[]
for pi,pair in enumerate(load(I/'owner-pairs.json')):
    a,b=(owners[i] for i in pair['owners']);delta=[b['position_grid'][k]-a['position_grid'][k] for k in [0,1]]
    if pair['kind']=='cog_orthogonal':
        alias=next(r for r in aliases if r['family']==b['identity'][0] and r['mode']==b['mode']);cid=alias['class'];matrix=alias['matrix'];offset=alias['offset_grid']
    else:cid='cog_cog';matrix=[[1,0],[0,1]];offset=[0,0]
    p=tuple(F(sum(matrix[k][j]*delta[j] for j in [0,1])+offset[k]) for k in [0,1]);ranked=[]
    for region in cache:
        if region['class']!=cid or region['empty']:continue
        poly=[tuple(map(F,q)) for q in region['vertices']];planes=[(r['coefficients'],r['upper']) for r in region['planes']];q,d=nearest(poly,planes,p)
        ranked.append({'kind':region['kind'],'source_id':region['source_id'],'point_grid':[str(x) for x in q],'distance_squared_grid':str(d)})
    ranked.sort(key=lambda r:(F(r['distance_squared_grid']),r['kind'],r['source_id']));assert ranked
    pairs.append({'pair':pi,'owners':pair['owners'],'kind':pair['kind'],'class':cid,'matrix':matrix,'offset_grid':offset,'candidate_relative_grid':[int(x) for x in p],'selected_kind':ranked[0]['kind'],'selected_source_id':ranked[0]['source_id'],'selected_projection_grid':ranked[0]['point_grid'],'distance_squared_grid':ranked[0]['distance_squared_grid']})
    all_projections.append({'pair':pi,'ranked':ranked});assert time.perf_counter()-started<30
rects=load(I/'mode-rectangles.json');components=load(I/'components.json');orthogonal=[]
for item in load(I/'component-pairs.json'):
    aa,bb=(components[i] for i in item['components']);oa,ob=(owners[i] for i in item['owners']);ra=rects[oa['identity'][0]][oa['mode']]['rectangles'][aa['piece']]['outward_offsets_grid'];rb=rects[ob['identity'][0]][ob['mode']]['rectangles'][bb['piece']]['outward_offsets_grid']
    choices=[(0,oa['owner'],ob['owner'],rb[0]-ra[2]-23),(0,ob['owner'],oa['owner'],ra[0]-rb[2]-23),(1,oa['owner'],ob['owner'],rb[1]-ra[3]-23),(1,ob['owner'],oa['owner'],ra[1]-rb[3]-23)]
    satisfied=[(upper-(owners[a]['position_grid'][axis]-owners[b]['position_grid'][axis]),direction,axis,a,b,upper) for direction,(axis,a,b,upper) in enumerate(choices) if owners[a]['position_grid'][axis]-owners[b]['position_grid'][axis]<=upper];assert satisfied
    slack,direction,axis,a,b,upper=max(satisfied,key=lambda r:(r[0],-r[1]));orthogonal.append({**item,'direction':direction,'axis':axis,'positive_owner':a,'negative_owner':b,'upper':upper,'candidate_slack_grid':slack})
write(OUT/'regions.json',cache);write(OUT/'owners.json',owners);write(OUT/'pair-projections.json',pairs);write(OUT/'all-ranked-projections.json',all_projections);write(OUT/'orthogonal-separators.json',orthogonal)
checks={'passed':True,'seconds':time.perf_counter()-started,'cached_source_regions':len(cache),'empty_regions':sum(r['empty'] for r in cache),'original_movers':len(owners),'selected_source_modes':len(owners),'cog_physical_pairs':len(pairs),'exact_point_region_projections':sum(len(r['ranked']) for r in all_projections),'candidate_pairs_already_in_certified_region':sum(F(p['distance_squared_grid'])==0 for p in pairs),'candidate_pairs_needing_relative_motion':sum(F(p['distance_squared_grid'])>0 for p in pairs),'orthogonal_component_separators':len(orthogonal),'consumed_candidate_pipeline_complete_seconds':load(L/'search/process.json')['seconds_including_preparation'],'model_prepared':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
