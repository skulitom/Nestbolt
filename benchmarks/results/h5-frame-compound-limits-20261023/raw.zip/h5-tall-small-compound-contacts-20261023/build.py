"""Original-outline small-part and compound contacts for the tall-frame 8+4+3 core."""
from collections import Counter,deque
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,time,traceback
from shapely.geometry import box,Polygon,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_cog_insert_contacts import graph
from build_h5_group_choice import ROOT,SRC,load,write,digest
OLD=ROOT/'output/h5-two-sheet-cog-group-choice-20261023';CORE=ROOT/'output/h5-tall-frame-cog-subassembly-20261023';CAT=ROOT/'output/h5-cog-lattices-20261018'
OUT=ROOT/'output/h5-tall-small-compound-contacts-20261023'

def members(spec,patterns):
    if spec['kind']=='single':return [{'part_id':spec['family'],'transform':{'rotation_radians':math.radians(spec['degrees']),'mirrored':spec['mirrored'],'translation':[0.,0.]}}]
    angle=math.radians(spec['degrees']);c,s=math.cos(angle),math.sin(angle);result=[]
    for p in patterns[spec['pattern']]['members']:
        t=copy.deepcopy(p['transform']);x,y=t['translation'];t['translation']=[c*x-s*y,s*x+c*y];t['rotation_radians']+=angle;result.append({'part_id':p['part_id'],'transform':t})
    return result

def main():
    OUT.mkdir();(OUT/'regions').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    patterns=load(CAT/'all-patterns.json');names=sorted(n for n,p in patterns.items() if len(p['members'])>1 and all(m['part_id'] in ['bracket','insert'] for m in p['members']));assert len(names)==36
    single=[{'kind':'single','family':f,'degrees':a,'mirrored':mir} for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for mir in mirrors for a in angles]
    compound=[{'kind':'compound','pattern':n,'degrees':a} for n in names for a in [0,90,180,270]]
    planned=[{'sheet':s,**item} for s in ['sheet-0','sheet-1'] for item in single+compound]
    inputs=[OLD/'candidates.json',CORE/'layout.json',CORE/'checks.json',CAT/'all-patterns.json',CAT/'audit/checks.json']+[SRC/n for n in ['job.json','conditional-target.json']]
    prior_audit=load(CAT/'audit/checks.json')
    assert load(CORE/'checks.json')['passed'] and prior_audit['source_hashes_unchanged'] and prior_audit['all_lattice_transforms_reconstructed'] and prior_audit['lattice_pairs']==45360
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'queries':planned,'compound_patterns':names,'query_seconds':90,'generation_seconds':120,'new_pose_caps':{'bracket':2000,'insert':1600},'compression_seconds':20,'reduction_seconds':30,'reduction_comparisons':10000000,'hint_seconds':30,'hint_cases':20,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'construction_padding_mm':.0126,
      'method':'Fix exactly the checked 18 tall frames and 15 cogs in an 8+4+3 arrangement. Preserve the full preceding source pool and map/append the exact fixed poses by identity. Retain every prior bracket/insert pose compatible with all 33 fixed original filled outlines. Query all eight bracket orientations/reflections and both insert classes, plus all 36 saved two-to-four-member bracket/insert compounds at four whole-group quarter turns, on both original target sheets. Compound global reflections are not sampled; each member retains its original allowed reflection. Construct actual-outline exclusions as the union of the individual member Minkowski obstacles, with zero-origin caches translated by fixed translation minus local member translation. A compound is not replaced by its filled bounding rectangle. Its bounding box only restricts translations to stock. Query representatives, vertices and edge midpoints, then process member events round-robin under fresh family caps. Keep every duplicate, rejection, unbuilt query and pending member position. Compound members remain independently selectable in the final complete conflict model. Do not resume any previous capped list or whole-bounding-rectangle heuristic.',
      'padding_scope':'Positive construction padding applies between newly proposed members and the fixed core/stock. Saved internal compound distances retain their original validated values; no native-margin qualification is implied.',
      'selection':'Independently audit original geometry, caches, every candidate origin and the full changed graph. Permit only fresh count/area-preserving same-family substitutions with full original-neighbor subset certificates. Compare 20 declared greedy starts from the empty-small 33-part subassembly, then make at most one bounded selection call for original caps 12 brackets and 21 inserts. Keep the previous higher-area and higher-count partials separately. No complete job, production repair or H5 pass is assumed.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');gap.EPS=.0126
    pool=copy.deepcopy(load(OLD/'candidates.json'));source_size=len(pool);keys={identity(p['placement']):i for i,p in enumerate(pool)};fixed=[];newfixed=[]
    for p in load(CORE/'layout.json')['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');k=identity(p)
        if k not in keys:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'tall-frame-cog-core'},'filled_area_mm2':shape(parts[p['part_id']],p['transform']).area});keys[k]=i;newfixed.append(i)
        fixed.append(keys[k])
    fixed=sorted(fixed);assert len(fixed)==len(set(fixed))==33 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15)
    write(OUT/'source-pool.json',pool);write(OUT/'fixed-mapping.json',{'source_pool_size':source_size,'new_fixed_candidates':newfixed,'fixed_candidates':fixed})
    oldsmall=[i for i,p in enumerate(pool) if p['placement']['part_id'] in ['bracket','insert']];geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixed+oldsmall};here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    filters=[];eligible=[]
    for i in oldsmall:
        blockers=[j for j in here[pool[i]['placement']['sheet_id']] if geometry[i].distance(geometry[j])<clear-1e-7];filters.append({'candidate':i,'fixed_blockers':blockers})
        if not blockers:eligible.append(i)
    pattern_checks=[]
    for name in names:
        p=patterns[name];gg=[shape(parts[v['part_id']],v['transform']) for v in p['members']];minimum=math.inf
        for a,b in combinations(gg,2):d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=clear-1e-7
        pattern_checks.append({'pattern':name,'members':len(gg),'pairs':len(gg)*(len(gg)-1)//2,'minimum_distance_mm':minimum})
    write(OUT/'pattern-checks.json',pattern_checks)
    caches={};cache_geometries={};cache_records=[]
    def exclusion(fixed_id,moving):
        fp=pool[fixed_id]['placement'];ft=fp['transform'];mt=moving['transform'];fz={**ft,'translation':[0.,0.]};mz={**mt,'translation':[0.,0.]};k=(fp['part_id'],float(ft['rotation_radians']).hex(),ft['mirrored'],moving['part_id'],float(mt['rotation_radians']).hex(),mt['mirrored'])
        if k not in caches:
            index=len(caches);caches[k]=index;g=gap.obstacle(shape(parts[fp['part_id']],fz),shape(parts[moving['part_id']],mz),clear);cache_geometries[index]=g
            r={'index':index,'fixed_part':fp['part_id'],'fixed_zero_transform':fz,'moving_part':moving['part_id'],'moving_zero_transform':mz,'first_fixed_pose':fp,'first_moving_member':moving,'geometry':mapping(g)};write(OUT/'obstacles'/f'{index}.json',r);cache_records.append({k:v for k,v in r.items() if k!='geometry'})
        return translate(cache_geometries[caches[k]],ft['translation'][0]-mt['translation'][0],ft['translation'][1]-mt['translation'][1])
    queries=[]
    for item in planned:
        if time.perf_counter()-start>=90:break
        qstart=time.perf_counter();mm=members(item,patterns);gg=[shape(parts[p['part_id']],p['transform']) for p in mm];a=min(g.bounds[0] for g in gg);b=min(g.bounds[1] for g in gg);c=max(g.bounds[2] for g in gg);d=max(g.bounds[3] for g in gg);h=stock['height'] if item['sheet']=='sheet-0' else target['required_used_height_mm']
        bounds=[m['left']+edge+gap.EPS-a,m['bottom']+edge+gap.EPS-b,stock['width']-m['right']-edge-gap.EPS-c,h-m['top']-edge-gap.EPS-d]
        if bounds[0]>=bounds[2] or bounds[1]>=bounds[3]:region=Polygon()
        else:region=box(*bounds).difference(unary_union([exclusion(i,member) for i in here[item['sheet']] for member in mm]))
        q={'index':len(queries),**item,'members':mm,'domain_bounds':bounds,'region':mapping(region),'proposals':proposals(region),'seconds':time.perf_counter()-qstart};write(OUT/'regions'/f"query-{q['index']}.json",q);queries.append(q)
        if len(queries)%50==0:print({'queries':len(queries),'seconds':time.perf_counter()-start},flush=True)
    query_seconds=time.perf_counter()-start;queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];events=[];added=[];counts=Counter();caps={'bracket':2000,'insert':1600}
    while queue and time.perf_counter()-start<120:
        qi,at=queue.popleft();q=queries[qi];pi,mi=divmod(at,len(q['members']));member=q['members'][mi];f=member['part_id']
        if counts[f]>=caps[f]:deferred.append([qi,at]);continue
        t=copy.deepcopy(member['transform']);x,y=t['translation'];dx,dy=q['proposals'][pi]['point'];t['translation']=[x+dx,y+dy];p={'part_id':f,'sheet_id':q['sheet'],'transform':t};g=shape(parts[f],t);a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7
        blockers=[j for j in here[p['sheet_id']] if g.distance(geometry[j])<clear-1e-7];event={'query':qi,'proposal':pi,'member':mi}
        if outside or blockers:event.update(added=False,reason='geometry',outside=bool(outside),blockers=blockers)
        elif identity(p) in keys:event.update(added=False,reason='duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'tall-small-compound-contact','query':qi,'proposal':pi,'member':mi},'filled_area_mm2':g.area});keys[identity(p)]=i;geometry[i]=g;added.append(i);counts[f]+=1;event.update(added=True,candidate=i)
        events.append(event)
        if at+1<len(q['proposals'])*len(q['members']):queue.append((qi,at+1))
    elapsed=time.perf_counter()-start;ids=sorted(eligible+added);pending={'queries':planned[len(queries):],'member_lists':sorted(deferred+list(map(list,queue)))}
    write(OUT/'candidates.json',pool);write(OUT/'old-filter.json',filters);write(OUT/'source-events.json',events);write(OUT/'cache-index.json',cache_records);write(OUT/'pending.json',pending)
    write(OUT/'mapping.json',{'candidates':ids,'fixed_candidates':fixed,'seed_candidates':[],'old_eligible':eligible,'new_candidates':added,'source_pool_size':source_size,'new_fixed_candidates':newfixed})
    result={'generation_seconds':elapsed,'query_phase_seconds':query_seconds,'planned_queries':len(planned),'completed_queries':len(queries),'cache_entries':len(caches),'compound_patterns':len(names),'old_eligible':len(eligible),'new_candidates':dict(counts),'retained_candidates':len(ids),'events':len(events),'pending_queries':len(pending['queries']),'pending_lists':len(pending['member_lists']),'generation_limit_reached':elapsed>=120,**graph(OUT,ids,pool,geometry,clear)}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
