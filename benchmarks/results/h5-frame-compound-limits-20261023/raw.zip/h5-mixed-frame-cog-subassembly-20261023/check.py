"""Check a concrete mixed-column frame and 9+1+5 cog subassembly for new contacts."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,subprocess
from audit_h5_cog_lattices import shape
from build_h5_two_sheet_cog_group_choice import ROOT,SRC,OUT as PRIOR,load,write,digest
OUT=ROOT/'output/h5-mixed-frame-cog-subassembly-20261023'
ALIGNED=ROOT/'output/h5-aligned-stagger-20261018'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py')
    inputs=[SRC/n for n in ['job.json','conditional-target.json']]+[PRIOR/n for n in ['layout-audit/layout-final.json','layout-audit/checks.json']]+[ALIGNED/n for n in ['patterns.json','audit.json']]+[ROOT/'output/h5-cog-lattices-20261018/frames.json']
    assert load(PRIOR/'layout-audit/checks.json')['passed']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_cases':1,
      'frame_columns':[6,6,6],'frame_rotation_degrees':[0,0,90],'frame_gap_mm':0.225,'extra_edge_mm':0.025,
      'cog_components':[{'source':'aligned-f0-n9-c3','member_indices':list(range(9)),'sheet':'sheet-0','region':'above first two shorter columns'},{'source':'aligned-f0-n1-c1','member_indices':[0],'sheet':'sheet-0','region':'above the last taller column'},{'source':'aligned-f0-n5-c5','member_indices':list(range(5)),'sheet':'sheet-1','region':'bottom left of the original last-sheet target'}],
      'method':'Construct exactly 18 frames in three six-frame columns: two unturned and one quarter-turned. Use the audited nine-cog square over the two shorter columns, one cog over the taller column and the five-cog row on the last sheet, preserving every source transform before translation normalization. Use 0.225mm bounding clearance. This changes the narrow four-tall-column residual strip into a wider right strip, but does not presume bracket feasibility. Recompute every original member, allowed transform, stock bound and all same-sheet filled-outer pairs, and validate the resulting 33-part subassembly with the frozen original CLI. Report every historical mixed-orientation column pattern; do not claim a first-ever frame orientation. No bracket/insert completion or solver is performed. This prepares a changed construction after the checked all-wide and all-tall frame searches; it is not a full-job witness, production repair or native-margin qualification.',
      'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');clear=job['clearance'];origin=[m['left']+edge+.025,m['bottom']+edge+.025];sep=.225
    placements=[];column_bounds=[];x=origin[0]
    for angle in [0.,0.,math.pi/2]:
        frame_t={'rotation_radians':angle,'translation':[0.,0.],'mirrored':False};fb=shape(parts['frame'],frame_t).bounds;fw,fh=fb[2]-fb[0],fb[3]-fb[1]
        for row in range(6):
            y=origin[1]+row*(fh+sep);t={**frame_t,'translation':[x-fb[0],y-fb[1]]};placements.append({'part_id':'frame','sheet_id':'sheet-0','copy_index':len(placements),'transform':t})
        column_bounds.append([x,origin[1],x+fw,y+fh]);x+=fw+sep
    patterns=load(ALIGNED/'patterns.json');plan=load(OUT/'plan.json');components=[]
    anchors=[[origin[0],max(r[3] for r in column_bounds[:2])+sep],[column_bounds[2][0],max(r[3] for r in column_bounds[2:])+sep],origin]
    for spec,anchor in zip(plan['cog_components'],anchors):
        raw=[copy.deepcopy(patterns[spec['source']]['members'][i]) for i in spec['member_indices']];gg=[shape(parts['cog'],p['transform']) for p in raw];x0=min(g.bounds[0] for g in gg);y0=min(g.bounds[1] for g in gg)
        width=max(g.bounds[2] for g in gg)-x0;height=max(g.bounds[3] for g in gg)-y0;poses=[]
        for p in raw:
            assert p['part_id']=='cog';t=p['transform'];t['translation']=[t['translation'][0]-x0+anchor[0],t['translation'][1]-y0+anchor[1]]
            pose={'part_id':'cog','sheet_id':spec['sheet'],'copy_index':sum(v['part_id']=='cog' for v in placements),'transform':t};placements.append(pose);poses.append(copy.deepcopy(pose))
        components.append({**spec,'anchor':anchor,'width':width,'height':height,'placements':poses})
    counts=Counter(p['part_id'] for p in placements);assert counts==Counter(frame=18,cog=15)
    original=load(PRIOR/'layout-audit/layout-final.json');layout={'version':1,'units':'mm','sheets':original['sheets'],'placements':placements};gs=[];tops=Counter()
    for p in placements:
        part=parts[p['part_id']];t=p['transform'];assert not t['mirrored']
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        g=shape(part,t);a,b,c,d=g.bounds;h=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert g.is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=st['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7;gs.append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],d+m['top']+edge)
    pairs=0;minimum=math.inf
    for i,j in combinations(range(len(gs)),2):
        if placements[i]['sheet_id']!=placements[j]['sheet_id']:continue
        pairs+=1;dist=gs[i].distance(gs[j]);minimum=min(minimum,dist);assert gs[i].disjoint(gs[j]) and dist>=clear-1e-7
    material=st['width']*(st['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
    write(OUT/'layout.json',layout);write(OUT/'components.json',components);write(OUT/'column-bounds.json',column_bounds)
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    source=ROOT/'output/h5-coordinated-placement-selection-20261018';cmd=[str(cli),'validate','--library',str(source/'library.json'),'--request',str(source/'request.json'),'--layout',str(OUT/'layout.json')];cp=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'command.json',{'command':cmd,'exit_code':cp.returncode});public=load(OUT/'public.json')
    expected=[{'code':'quantity','message':'part bracket: expected 12, found 0'},{'code':'quantity','message':'part insert: expected 21, found 0'}];assert sorted(public['violations'],key=lambda v:v['message'])==expected and not public['valid'] and cp.returncode!=0
    historical=[{'index':i,'counts':r['counts'],'method':r['method']} for i,r in enumerate(load(ROOT/'output/h5-cog-lattices-20261018/frames.json')) if any(r['rotations']) and not all(r['rotations'])]
    checks={'passed':True,'counts':dict(counts),'missing':{'bracket':12,'insert':21},'original_geometry_pairs':pairs,'minimum_distance_mm':minimum,'material_mm2':material,'filled_area_mm2':sum(g.area for g in gs),'historical_mixed_column_patterns':historical,'component_counts':[len(r['placements']) for r in components],'original_CLI_valid':False,'fresh_frozen_CLI_calls':1,'full_target_witness':False,'native_margin_qualified':False,'this_is_not_a_partial_improvement':True,'solver_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
