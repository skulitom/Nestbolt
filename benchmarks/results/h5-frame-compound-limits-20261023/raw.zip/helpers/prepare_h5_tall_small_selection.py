"""Prepare fresh fixed-core selection helpers; does not execute a search."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def save(name,s):
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)

s=(ROOT/'reduce_h5_two_sheet_cog_group_choice.py').read_text(encoding='utf-8')
s=replace(s,'from build_h5_two_sheet_cog_group_choice import ROOT,OUT as BASE,load,write,digest,save_rows','from build_h5_tall_small_compound_contacts import ROOT,OUT as BASE,load,write,digest\nfrom build_h5_group_choice import save_rows')
s=replace(s,'Fresh substitutions preserving every complete-group compatibility and original count.','Fresh substitutions preserving fixed-core original family counts and filled area.')
s=replace(s,'On the complete newly audited graph and all 365 group-compatibility lists,','On the complete newly audited fixed-core graph,')
s=replace(s,', and every group compatible with b also compatible with a','')
s=replace(s,'neighbors and groups','neighbors')
s=replace(s,'and every group choice','and the fixed 33-part core')
s=replace(s,'Map the exact prior 63-part seed only through these fresh certificates and verify its full count, graph and group feasibility.','The starting small-part seed is empty; fresh greedy hints follow separately.')
s=replace(s,";allowed=[sum(1<<g for g in groups) for groups in mp['compatible_groups']]",'')
s=replace(s,' and not(allowed[b]&~allowed[a])','')
s=replace(s,'certificate_neighbors=certificate_groups=0','certificate_neighbors=0')
s=replace(s,"        for g in mp['compatible_groups'][b]:certificate_groups+=1;assert g in mp['compatible_groups'][a]\n",'')
a=s.index("    seed=sorted(replacements.get(i,i)")
b=s.index("    checks=",a)
s=s[:a]+"    assert mp['seed_candidates']==[]\n    write(OUT/'mapping.json',{**mp,'candidates':kept_global,'seed_candidates':[],'original_seed_candidates':[]})\n"+s[b:]
s=replace(s,"'certificate_group_memberships_independently_verified':certificate_groups,",'')
s=replace(s,'all_substitutions_preserve_family_count_area_and_group_choice','all_substitutions_preserve_family_count_area_and_fixed_core')
s=replace(s,"'prior_63_part_seed_mapped_and_verified':True","'empty_small_seed_verified':True")
save('reduce_h5_tall_small_compound_contacts.py',s)

s=(ROOT/'solve_h5_complete_cog_small_pool.py').read_text(encoding='utf-8')
s=replace(s,'30-second','60-second')
s=replace(s,'h5-complete-cog-small-pool-20261023','h5-tall-small-compound-contacts-20261023')
s=replace(s,"OUT=BASE/'solve'","OUT=BASE/'solve';RED=BASE/'reduced';HINT=BASE/'hints'")
s=replace(s,"assert load(BASE/'audit/checks.json')['passed'];","assert all(load(p/'checks.json')['passed'] for p in [BASE/'audit',RED,HINT]);")
s=replace(s,"mp=load(BASE/'mapping.json')","mp=load(RED/'mapping.json')")
s=replace(s,"BASE/'cliques.jsonl.gz'","RED/'cliques.jsonl.gz'")
s=replace(s,"hint=[int(i in set(mp['seed_candidates'])) for i in ids]","best=load(HINT/'best-hint.json');hint=[int(i in set(best['selected_small_candidates'])) for i in ids]")
s=replace(s,"assert {f:sum(hint[j] for j in js) for f,js in families.items()}=={'bracket':9,'insert':19}","assert {f:sum(hint[j] for j in js) for f,js in families.items()}=={f:best['counts'].get(f,0) for f in caps}\n    assert low==best['objective'] and all(best['counts'].get(f,0)<=caps[f] for f in caps)")
s=replace(s,'max_time_in_seconds=30','max_time_in_seconds=60')
s=replace(s,"'seconds_limit':30","'seconds_limit':60")
s=replace(s,"BASE/'mapping.json',RED/'cliques.jsonl.gz',BASE/'audit/checks.json',BASE/'source-pool.json',BASE/'seed-mapping.json'","RED/'mapping.json',RED/'cliques.jsonl.gz',RED/'checks.json',RED/'substitutions.json',HINT/'best-hint.json',HINT/'checks.json',BASE/'audit/checks.json',BASE/'source-pool.json',BASE/'fixed-mapping.json'")
save('solve_h5_tall_small_compound_contacts.py',s)

s=(ROOT/'audit_h5_complete_cog_small_layouts.py').read_text(encoding='utf-8')
s=replace(s,'returned wider-frame layout','returned tall-frame layout')
s=replace(s,'from build_h5_complete_cog_small_pool import OUT,SEED','from build_h5_tall_small_compound_contacts import OUT,CORE as SEED')
s=replace(s,";RED=OUT",";RED=OUT/'reduced'")
s=replace(s,"old/'layout-audit/layout-0.json'","old/'layout.json'")
s=replace(s,"old/'layout-audit/public-0.json'","old/'public.json'")
s=replace(s,"old/'layout-audit/command-0.json'","old/'command.json'")
s=replace(s,"best={'selected_small_candidates':mp['seed_candidates'],'objective':9*load(AREA/'mapping.json')['area_weights']['bracket']+19*load(AREA/'mapping.json')['area_weights']['insert']};seed=sorted(mp['fixed_candidates']+mp['seed_candidates'])","best=load(OUT/'hints/best-hint.json');seed=sorted(mp['fixed_candidates']+best['selected_small_candidates'])")
save('audit_h5_tall_small_compound_layouts.py',s)
print('Prepared reduction, single-call solver and original layout audit.')
