"""Prepare one mixed-column core with 9+1+5 original cog placements."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
s=(ROOT/'check_h5_tall_frame_cog_subassembly.py').read_text(encoding='utf-8')
def change(a,b):
    global s
    assert a in s,a
    s=s.replace(a,b)
change('four-column frame and 8+4+3 cog','mixed-column frame and 9+1+5 cog')
change('h5-tall-frame-cog-subassembly-20261023','h5-mixed-frame-cog-subassembly-20261023')
change("'frame_columns':[4,4,5,5],'frame_rotation_degrees':90","'frame_columns':[6,6,6],'frame_rotation_degrees':[0,0,90]")
change("'source':'aligned-f0-n15-c4','member_indices':[0,1,4,5,8,9,12,13]","'source':'aligned-f0-n9-c3','member_indices':list(range(9))")
change("'source':'aligned-f0-n15-c4','member_indices':[0,1,4,5]","'source':'aligned-f0-n1-c1','member_indices':[0]")
change("'source':'aligned-f0-n3-c3','member_indices':[0,1,2]","'source':'aligned-f0-n5-c5','member_indices':list(range(5))")
change('above last two taller columns','above the last taller column')
change('Construct exactly 18 quarter-turned frames in four columns, two of four frames and two of five. Derive 8-cog and 4-cog components as specified subsets of an already audited aligned 15-cog lattice, preserving every local transform before translation normalization. Place them above the shorter and taller column pairs with a 0.225mm bounding clearance. Place the saved three-cog row at the last-sheet lower left.','Construct exactly 18 frames in three six-frame columns: two unturned and one quarter-turned. Use the audited nine-cog square over the two shorter columns, one cog over the taller column and the five-cog row on the last sheet, preserving every source transform before translation normalization. Use 0.225mm bounding clearance. This changes the narrow four-tall-column residual strip into a wider right strip, but does not presume bracket feasibility.')
change('Report historical four-tall-column frame patterns when present; do not claim a first-ever frame orientation.','Report every historical mixed-orientation column pattern; do not claim a first-ever frame orientation.')
change('This prepares a changed construction after the all-wide-frame candidate searches','This prepares a changed construction after the checked all-wide and all-tall frame searches')
a=s.index("    frame_t=")
b=s.index("    patterns=",a)
s=s[:a]+'''    placements=[];column_bounds=[];x=origin[0]
    for angle in [0.,0.,math.pi/2]:
        frame_t={'rotation_radians':angle,'translation':[0.,0.],'mirrored':False};fb=shape(parts['frame'],frame_t).bounds;fw,fh=fb[2]-fb[0],fb[3]-fb[1]
        for row in range(6):
            y=origin[1]+row*(fh+sep);t={**frame_t,'translation':[x-fb[0],y-fb[1]]};placements.append({'part_id':'frame','sheet_id':'sheet-0','copy_index':len(placements),'transform':t})
        column_bounds.append([x,origin[1],x+fw,y+fh]);x+=fw+sep
'''+s[b:]
change("if len(r['rotations'])==4 and all(r['rotations'])","if any(r['rotations']) and not all(r['rotations'])")
change('historical_four_tall_column_patterns','historical_mixed_column_patterns')
with (ROOT/'check_h5_mixed_frame_cog_subassembly.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared one new mixed-column construction.')
