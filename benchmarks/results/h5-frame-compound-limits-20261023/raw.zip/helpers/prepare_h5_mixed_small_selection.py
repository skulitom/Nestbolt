"""Prepare a changed-core experiment without resuming any tall-core pending list."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
names=['build_h5_tall_small_compound_contacts.py','audit_h5_tall_small_compound_contacts.py','reduce_h5_tall_small_compound_contacts.py','seed_h5_tall_small_compound_contacts.py','solve_h5_tall_small_compound_contacts.py','audit_h5_tall_small_compound_layouts.py']
for name in names:
    s=(ROOT/name).read_text(encoding='utf-8')
    s=s.replace('tall_small_compound','mixed_small_compound').replace('h5-tall-small-compound','h5-mixed-small-compound').replace('h5-tall-frame-cog','h5-mixed-frame-cog').replace('tall-frame-cog-core','mixed-frame-cog-core').replace('tall-small-compound-contact','mixed-small-compound-contact')
    s=s.replace('tall-frame 8+4+3 core','mixed-frame 9+1+5 core').replace('18 tall frames and 15 cogs in an 8+4+3 arrangement','18 mixed-orientation frames and 15 cogs in a 9+1+5 arrangement').replace('tall-frame/cog core','mixed-frame/cog core').replace('tall-frame layout','mixed-frame layout')
    if name.startswith('build_'):
        s=s.replace("OLD=ROOT/'output/h5-two-sheet-cog-group-choice-20261023'","OLD=ROOT/'output/h5-tall-small-compound-contacts-20261023'")
    with (ROOT/name.replace('tall_small_compound','mixed_small_compound')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared fresh mixed-core helpers with preceding complete pool preserved.')
