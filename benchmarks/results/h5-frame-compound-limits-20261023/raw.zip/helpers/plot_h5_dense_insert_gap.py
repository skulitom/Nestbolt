from pathlib import Path
from collections import Counter
import json, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
root=Path(__file__).resolve().parents[1]
src=root/'output/h5-dense-insert-gap-20261023'
job=json.loads((root/'output/h5-skeleton-contact-selection-20261020/job.json').read_bytes())
layout=json.loads((src/'layout.json').read_bytes())
target=json.loads((root/'output/h5-skeleton-contact-selection-20261020/conditional-target.json').read_bytes())
parts={p['id']:p for p in job['parts']};colors={'frame':'#d8e4ef','bracket':'#f4c78d','insert':'#8ed4b0','cog':'#c3a0d8'}
fig,(ax,extra)=plt.subplots(1,2,figsize=(11,11),gridspec_kw={'width_ratios':[1,1]})
for s,axis in [('sheet-0',ax),('sheet-1',extra)]:
    height=3000 if s=='sheet-0' else target['required_used_height_mm']
    axis.add_patch(Rectangle((6.5,6.5),1487,height-13,fill=False,color='#333333',lw=1))
    for p in layout['placements']:
        if p['sheet_id']!=s:continue
        t=p['transform'];c,ss=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mir=-1 if t['mirrored'] else 1
        points=[(mir*x*c-y*ss+t['translation'][0],mir*x*ss+y*c+t['translation'][1]) for x,y in parts[p['part_id']]['geometry'][0]['outer']]
        axis.add_patch(Polygon(points,facecolor=colors[p['part_id']],edgecolor='#454545',lw=.5))
        x=sum(q[0] for q in points)/len(points);y=sum(q[1] for q in points)/len(points)
        axis.text(x,y,p['part_id'][0].upper()+str(p['copy_index']),ha='center',va='center',fontsize=6)
    axis.set_xlim(-10,1510);axis.set_ylim(-10,height+10);axis.set_aspect('equal');axis.set_title(f'{s}: 1500 × {height:.3f} mm');axis.set_xlabel('mm');axis.set_ylabel('mm')
fig.suptitle('Improved partial: 64 of 66 parts; missing two cogs\nFrame holes remain reserved. This is not a cutting layout.',fontsize=12)
fig.tight_layout();fig.savefig(src/'partial-layout.png',dpi=150);plt.close(fig)
