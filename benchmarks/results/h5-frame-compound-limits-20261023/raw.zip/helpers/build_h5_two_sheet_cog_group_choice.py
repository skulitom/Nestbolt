"""New joint choice among 365 complete-cog cases across both sheets and free small parts."""
from collections import Counter,deque
from datetime import datetime,timezone
import copy,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_cog_insert_contacts import graph
from build_h5_group_choice import ROOT,SRC,load,write,digest,save_rows
OLD=ROOT/'output/h5-complete-cog-group-choice-20261023'
COVER=ROOT/'output/h5-cog-sheet-group-coverage-20261023'
BLOCK=ROOT/'output/h5-dense-group-blockers-20261023'
CAT=ROOT/'output/h5-wide-catalogue-coverage-20261023'
BEST=ROOT/'output/h5-dense-insert-gap-20261023'
OUT=ROOT/'output/h5-two-sheet-cog-group-choice-20261023'

def main():
    OUT.mkdir();(OUT/'regions').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    pool=copy.deepcopy(load(OLD/'candidates.json'));source_size=len(pool);keys={identity(p['placement']):i for i,p in enumerate(pool)};assert len(keys)==len(pool)
    original=load(OLD/'layout-audit/layout-final.json');selected=sorted(keys[identity(p)] for p in original['placements'])
    fixed=sorted(i for i in selected if pool[i]['placement']['part_id']=='frame');seed=sorted(i for i in selected if pool[i]['placement']['part_id'] in ['bracket','insert'])
    assert len(fixed)==18 and Counter(pool[i]['placement']['part_id'] for i in seed)==Counter(bracket=9,insert=21)
    groups=copy.deepcopy(load(OLD/'mapping.json')['cog_groups']);assert len(groups)==165
    for r in load(COVER/'new-cases.json'):
        groups.append({'index':len(groups),'source_coverage_case':r['index'],'first_group':r['first_group'],'last_group':r['last_group'],'candidates':r['candidates']})
    assert len(groups)==365 and len({tuple(g['candidates']) for g in groups})==365
    assert set(groups[144]['candidates'])==set(selected)-set(fixed)-set(seed)
    orient=[{'family':f,'degrees':a,'mirrored':mir} for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for mir in mirrors for a in angles]
    queries=[];query_keys={}
    prior_query_keys={(q['sheet'],tuple(q['neighbors']),q['family'],q['degrees'],q['mirrored']) for q in load(OLD/'plan.json')['queries']}
    for group in groups[165:]:
        for sheet in ['sheet-0','sheet-1']:
            neighbors=[i for i in fixed+group['candidates'] if pool[i]['placement']['sheet_id']==sheet]
            for o in orient:
                k=(sheet,tuple(neighbors),o['family'],o['degrees'],o['mirrored'])
                if k in prior_query_keys:continue
                if k not in query_keys:
                    query_keys[k]=len(queries);queries.append({'index':len(queries),'case':group['index'],'sheet':sheet,'neighbors':neighbors,**o})
    inputs=[OLD/n for n in ['candidates.json','layout-audit/layout-final.json','layout-audit/checks.json','solve/result.json']]+[COVER/n for n in ['new-cases.json','checks.json']]+[OLD/n for n in ['mapping.json','plan.json']]+[CAT/'placements.json',BEST/'layout.json']+[SRC/n for n in ['job.json','conditional-target.json']]
    assert load(OLD/'layout-audit/checks.json')['passed'] and load(COVER/'checks.json')['passed']
    plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'generation_seconds':120,'query_seconds':90,'new_contact_caps':{'bracket':1600,'insert':1200},'compression_seconds':20,
      'hint_seconds':30,'hint_cases_maximum':7300,'reduction_seconds':30,'reduction_comparisons':10000000,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'construction_padding_mm':0.0126,
      'groups':groups,'queries':queries,
      'method':'Retain all 165 earlier complete 15-cog cases and append the 200 newly audited cross-sheet groups, with the same 18 original frames. Preserve every source candidate and exact global index. Recompute every bracket/insert compatibility against frames and each unique cog pose, retaining every small pose compatible with at least one whole case. For each distinct added-case/sheet/neighborhood absent from the prior query set, generate all eight bracket orientation/reflection and two insert size classes with translated zero-origin Minkowski caches. Share queries only when the exact ordered neighbor ids, sheet and moving orientation match. Process representatives, boundary vertices and midpoints round-robin under fresh family caps; preserve every rejected/duplicate event and pending suffix. Groups are discrete choices, not independent cog variables. Retain the prior checked 63-part case-144 seed. Audit the full changed compatibility and small-pair graph. Allow a new bounded same-family substitution only when the replacement is adjacent, its other full-graph neighbors are a subset, and it is compatible with every complete group allowed by the removed candidate. Independently enumerate every certificate, project every retained conflict, and preserve exact counts/area and group choice. Compare bounded greedy starts across all 365 groups, then make at most one new group-selection solver call after independent checks. Do not reuse earlier substitution certificates or resume the 980 old capped lists.',
      'scope':'This adds the missing 10+5, 12+3 and alternative 14+1 sheet distributions to the complete-group decision; it is not a retry or time extension of either previous model. Finite sampled contacts do not establish continuous impossibility. Native margins, original repair limits/budget and full H5 remain required.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0}
    write(OUT/'plan.json',plan);beg=time.perf_counter();job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');gap.EPS=plan['construction_padding_mm']
    oldsmall=[i for i,r in enumerate(pool) if r['placement']['part_id'] in ['bracket','insert']];cogs=sorted({i for g in groups for i in g['candidates']})
    geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixed+oldsmall+cogs}
    filters=[];oldframes=[]
    for i in oldsmall:
        blockers=[j for j in fixed if pool[j]['placement']['sheet_id']==pool[i]['placement']['sheet_id'] and geometry[i].distance(geometry[j])<clear-1e-7]
        filters.append({'candidate':i,'frame_blockers':blockers})
        if not blockers:oldframes.append(i)
    cache={};cache_geometries={};cache_records=[]
    def exclusion(p,moving,o):
        t=p['transform'];zero={**t,'translation':[0.,0.]};k=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],o['family'],o['degrees'],o['mirrored'])
        if k not in cache:
            index=len(cache);cache[k]=index;g=gap.obstacle(shape(parts[p['part_id']],zero),moving,clear);cache_geometries[index]=g
            r={'index':index,'fixed_part':p['part_id'],'fixed_transform':zero,'moving':o,'geometry':mapping(g),'first_actual_fixed':p};write(OUT/'obstacles'/f'{index}.json',r);cache_records.append({k:v for k,v in r.items() if k!='geometry'})
        return translate(cache_geometries[cache[k]],*t['translation'])
    done=[]
    for item in queries:
        if time.perf_counter()-beg>=plan['query_seconds']:break
        qbeg=time.perf_counter();o={k:item[k] for k in ['family','degrees','mirrored']};moving=shape(parts[o['family']],{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]});a,b,c,d=moving.bounds
        h=stock['height'] if item['sheet']=='sheet-0' else target['required_used_height_mm']
        domain=box(m['left']+edge+gap.EPS-a,m['bottom']+edge+gap.EPS-b,stock['width']-m['right']-edge-gap.EPS-c,h-m['top']-edge-gap.EPS-d)
        region=domain.difference(unary_union([exclusion(pool[i]['placement'],moving,o) for i in item['neighbors']]))
        q={**item,'rotation_radians':math.radians(o['degrees']),'region':mapping(region),'proposals':proposals(region),'seconds':time.perf_counter()-qbeg}
        write(OUT/'regions'/f"query-{q['index']}.json",q);done.append(q)
        if len(done)%200==0:print({'queries':len(done),'seconds':time.perf_counter()-beg},flush=True)
    query_seconds=time.perf_counter()-beg;queue=deque((q['index'],0) for q in done if q['proposals']);deferred=[];events=[];added=[];counts=Counter()
    while queue and time.perf_counter()-beg<plan['generation_seconds']:
        qi,pi=queue.popleft();q=done[qi];f=q['family']
        if counts[f]>=plan['new_contact_caps'][f]:deferred.append([qi,pi]);continue
        p={'part_id':f,'sheet_id':q['sheet'],'transform':{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':q['proposals'][pi]['point']}}
        g=shape(parts[f],p['transform']);a,b,c,d=g.bounds;h=stock['height'] if q['sheet']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7
        blockers=[i for i in q['neighbors'] if g.distance(geometry[i])<clear-1e-7];event={'query':qi,'proposal':pi}
        if outside or blockers:event.update(added=False,reason='geometry',outside=bool(outside),blockers=blockers)
        elif identity(p) in keys:event.update(added=False,reason='duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'two-sheet-cog-group-contact','query':qi,'proposal':pi},'filled_area_mm2':g.area});keys[identity(p)]=i;geometry[i]=g;added.append(i);counts[f]+=1;event.update(added=True,candidate=i)
        events.append(event)
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    generation_seconds=time.perf_counter()-beg;allsmall=oldframes+added;blocked={i:set() for i in allsmall};cog_edges=[]
    for sheet in ['sheet-0','sheet-1']:
        sm=[i for i in allsmall if pool[i]['placement']['sheet_id']==sheet];cg=[i for i in cogs if pool[i]['placement']['sheet_id']==sheet]
        gg=np.asarray([geometry[i] for i in sm],dtype=object);tree=STRtree(gg)
        for i in cg:
            near=tree.query(geometry[i],predicate='dwithin',distance=clear+1e-7)
            for j in near[shapely.distance(geometry[i],gg[near])<clear-1e-7]:
                other=sm[int(j)];blocked[other].add(i);cog_edges.append([i,other])
    compatibility=[{'candidate':i,'compatible_groups':[g['index'] for g in groups if not blocked[i].intersection(g['candidates'])]} for i in allsmall]
    ids=[r['candidate'] for r in compatibility if r['compatible_groups']];compatible=[r['compatible_groups'] for r in compatibility if r['compatible_groups']]
    assert ids==sorted(ids) and set(seed)<=set(ids) and all(144 in compatible[ids.index(i)] for i in seed)
    save_rows(OUT/'cog-conflicts.jsonl.gz',sorted(cog_edges));write(OUT/'compatibility.json',compatibility);write(OUT/'frame-filter.json',filters);write(OUT/'source-events.json',events);write(OUT/'cache-index.json',cache_records);write(OUT/'candidates.json',pool)
    pending={'queries':queries[len(done):],'proposal_lists':sorted(deferred+list(map(list,queue)))};write(OUT/'pending.json',pending)
    write(OUT/'mapping.json',{'candidates':ids,'fixed_candidates':fixed,'cog_groups':groups,'compatible_groups':compatible,'seed_candidates':seed,'seed_group':144,'old_frame_compatible':oldframes,'new_candidates':added,'source_pool_size':source_size})
    result={'generation_seconds':generation_seconds,'query_phase_seconds':query_seconds,'planned_queries':len(queries),'completed_queries':len(done),'cache_entries':len(cache_records),'new_candidates':dict(counts),'events':len(events),'old_frame_compatible':len(oldframes),'retained_candidates':len(ids),'unique_cog_poses':len(cogs),'cog_conflicts':len(cog_edges),'pending_queries':len(pending['queries']),'pending_lists':len(pending['proposal_lists']),'generation_limit_reached':generation_seconds>=120,**graph(OUT,ids,pool,geometry,clear)}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
