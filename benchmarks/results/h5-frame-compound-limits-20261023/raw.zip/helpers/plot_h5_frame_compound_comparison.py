"""Render independently checked partials only; no geometry modification."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
template=(ROOT/'plot_h5_dense_insert_gap.py').read_text(encoding='utf-8')
for kind in ['tall','mixed']:
    name=f'h5-{kind}-small-compound-contacts-20261023'
    audit=json.loads((ROOT/name/'layout-audit/checks.json').read_bytes())
    record=max(audit['records'],key=lambda r:(r['filled_area_mm2'],str(r['incumbent'])=='final'))
    count=sum(record['counts'].values());missing=', '.join(f'{v} {k if v==1 else k+"s"}' for k,v in record['missing'].items())
    s=template.replace('h5-dense-insert-gap-20261023',name).replace("src/'layout.json'",f"src/'layout-audit/layout-{record['incumbent']}.json'")
    s=s.replace('Improved partial: 64 of 66 parts; missing two cogs',f'{kind.capitalize()} frame diagnostic: {count} of 66 parts; missing {missing}')
    exec(compile(s,str(ROOT/'plot_h5_dense_insert_gap.py'),'exec'),{'__file__':str(ROOT/'plot_h5_frame_compound_comparison.py'),'__name__':'__main__'})
