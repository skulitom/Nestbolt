"""Twenty fresh deterministic hints around the fixed mixed-frame/cog core."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations
import gzip,json,shutil,time
from build_h5_mixed_small_compound_contacts import ROOT,OUT as BASE,load,write,digest
RED=BASE/'reduced';OUT=BASE/'hints'
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    mp=load(RED/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=[0]*len(ids)
    with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);mask=sum(1<<j for j in row)
            for j in row:adj[j]|=mask^(1<<j)
    weights=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights'];caps={'bracket':12,'insert':21};family=[pool[i]['placement']['part_id'] for i in ids];poses=[pool[i]['placement'] for i in ids]
    orders=[]
    def coordinate(j,kind,reverse):
        p=poses[j];x,y=p['transform']['translation'];sheet=(p['sheet_id']=='sheet-1')^reverse
        if kind=='degree':return (adj[j].bit_count(),sheet,y,x,ids[j])
        return (sheet,-y if kind=='top-left' else y,-x if kind=='bottom-right' else x,ids[j])
    for f in permutations(caps):
        for kind in ['bottom-left','top-left','bottom-right','degree']:
            for reverse in [False,True]:
                rank={name:i for i,name in enumerate(f)};orders.append(({'families':list(f),'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:(rank[family[j]],coordinate(j,kind,reverse)))))
    for kind in ['area','degree-per-area']:
        for reverse in [False,True]:
            orders.append(({'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:((poses[j]['sheet_id']=='sheet-1')^reverse,-weights[family[j]] if kind=='area' else Fraction(adj[j].bit_count(),weights[family[j]]),adj[j].bit_count(),ids[j]))))
    assert len(orders)==20 and mp['seed_candidates']==[]
    inputs=[BASE/n for n in ['plan.json','candidates.json','audit/checks.json']]+[RED/n for n in ['mapping.json','cliques.jsonl.gz','checks.json','substitutions.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_cases':20,'ordering_specs':[d for d,o in orders],
      'method':'Start each of twenty declared orders from no brackets or inserts around the exact fixed 18-frame/15-cog core. Add poses greedily subject to the complete audited adjacency and original caps. Record every result, pending order, count and original filled-area score. This is a new construction census, not a resumed search or production repair.'})
    hints=[];start=time.perf_counter()
    for description,order in orders:
        if time.perf_counter()-start>=30:break
        counts=Counter();mask=0;chosen=[]
        for j in order:
            if counts[family[j]]>=caps[family[j]] or adj[j]&mask:continue
            chosen.append(j);mask|=1<<j;counts[family[j]]+=1
            if counts==caps:break
        hints.append({'index':len(hints),'source':'fixed-core-greedy','ordering':description,'selected_small_candidates':sorted(ids[j] for j in chosen),'counts':dict(counts),'objective':sum(weights[family[j]] for j in chosen)})
    elapsed=time.perf_counter()-start
    best=max(hints,key=lambda r:(r['objective'],len(r['selected_small_candidates']),r['selected_small_candidates'])) if hints else {'source':'empty','selected_small_candidates':[],'counts':{},'objective':0}
    for r in hints+[best]:
        chosen=[local[i] for i in r['selected_small_candidates']];mask=sum(1<<j for j in chosen);counts=Counter(family[j] for j in chosen)
        assert len(chosen)==len(set(chosen)) and dict(counts)==r['counts'] and all(counts[f]<=caps[f] for f in caps)
        assert all(not(adj[j]&mask) for j in chosen) and sum(weights[family[j]] for j in chosen)==r['objective']
    write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best);write(OUT/'pending.json',[d for d,o in orders[len(hints):]])
    checks={'passed':True,'seconds':elapsed,'planned_cases':20,'completed_cases':len(hints),'pending_cases':20-len(hints),'limit_reached':elapsed>=30,'every_result_full_graph_counts_score_checked':True,'best_hint':{k:v for k,v in best.items() if k!='selected_small_candidates'},'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
