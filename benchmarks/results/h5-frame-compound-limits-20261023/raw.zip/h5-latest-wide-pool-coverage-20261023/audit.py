"""Fresh fixed-frame coverage of the accumulated pool; no search or graph solve."""
from collections import Counter
from datetime import datetime,timezone
import copy,math,shutil,time
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_group_choice import ROOT,SRC,load,write,digest
BASE=ROOT/'output/h5-mixed-small-compound-contacts-20261023'
WIDE=ROOT/'output/h5-two-sheet-cog-group-choice-20261023'
EARLIER=ROOT/'output/h5-dense-wide-contacts-20261023'
OUT=ROOT/'output/h5-latest-wide-pool-coverage-20261023'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    inputs=[BASE/n for n in ['candidates.json','audit/checks.json','layout-audit/checks.json']]+[WIDE/n for n in ['mapping.json','layout-audit/layout-final.json','layout-audit/checks.json']]+[EARLIER/n for n in ['candidates.json','mapping.json','audit/checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]+[ROOT/'output/h5-dense-insert-gap-20261023/layout.json']
    assert all(load(p)['passed'] for p in [BASE/'audit/checks.json',BASE/'layout-audit/checks.json',WIDE/'layout-audit/checks.json',EARLIER/'audit/checks.json'])
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Preserve the latest complete pool. Fix only the exact 18 wide frames used by the current highest-filled-area 63-part partial. Reconsider every original cog/bracket/insert pose against those frames and original stock, without reusing older filtered subsets. Compare surviving poses with the earlier dense-wide all-family model and map both the current 63-part and earlier 64-part witnesses by exact pose identity. Audit all retained stock/transform checks and both full partial geometries. This coverage check prepares a changed all-family graph; no previous solver or capped list is resumed, no new pose is generated, and no selection call occurs. A future graph, fresh safe reduction and independently checked model are still required.', 'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=load(BASE/'candidates.json');old=load(EARLIER/'candidates.json');assert pool[:len(old)]==old
    fixed=load(WIDE/'mapping.json')['fixed_candidates'];assert len(fixed)==18 and all(pool[i]['placement']['part_id']=='frame' for i in fixed)
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');clear=job['clearance']
    geom={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)};keys={identity(p['placement']):i for i,p in enumerate(pool)};eligible=[];filters=[];pairs=0
    for i,p in enumerate(pool):
        p=p['placement']
        if p['part_id']=='frame':continue
        blockers=[]
        for j in fixed:
            if p['sheet_id']==pool[j]['placement']['sheet_id']:
                pairs+=1
                if geom[i].distance(geom[j])<clear-1e-7:blockers.append(j)
        filters.append({'candidate':i,'fixed_blockers':blockers})
        if not blockers:eligible.append(i)
    for i in eligible+fixed:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];g=geom[i];a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
    previous=set(load(EARLIER/'mapping.json')['candidates']);assert previous<=set(eligible)
    additions=sorted(set(eligible)-previous);counts=lambda ids:dict(Counter(pool[i]['placement']['part_id'] for i in ids));seeds=[]
    for path in [WIDE/'layout-audit/layout-final.json',ROOT/'output/h5-dense-insert-gap-20261023/layout.json']:
        layout=load(path);ids=[]
        for p in layout['placements']:
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert pool[i]['placement']==p;ids.append(i)
        assert len(ids)==len(set(ids)) and set(fixed)<=set(ids) and set(ids)-set(fixed)<=set(eligible)
        gp=0;minimum=math.inf
        for at,i in enumerate(ids):
            for j in ids[at+1:]:
                if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
                gp+=1;d=geom[i].distance(geom[j]);minimum=min(minimum,d);assert geom[i].disjoint(geom[j]) and d>=clear-1e-7
        seeds.append({'source':path.relative_to(ROOT).as_posix(),'source_sha256':digest(path),'selected_indices':sorted(ids),'counts':counts(ids),'filled_area_mm2':sum(geom[i].area for i in ids),'geometry_pairs':gp,'minimum_distance_mm':minimum})
    write(OUT/'filter.json',filters);write(OUT/'mapping.json',{'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'fixed_candidates':fixed,'candidates':eligible,'additional_candidates':additions,'seeds':seeds})
    check={'passed':True,'seconds':time.perf_counter()-start,'complete_source_pool_size':len(pool),'earlier_prefix_size':len(old),'earlier_prefix_exact':True,'fixed_frame_pairs':pairs,'retained_candidates':len(eligible),'retained_by_family':counts(eligible),'earlier_candidate_count':len(previous),'all_earlier_choices_preserved':True,'additional_candidates':len(additions),'additional_by_family':counts(additions),'both_previous_partial_geometries_checked':True,'complete_new_conflict_graph_pending':True,'solver_calls':0,'new_poses_generated':0,'full_target_witness':False,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
