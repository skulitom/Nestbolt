"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_bracket_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-tiered-source-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';X=ROOT/'output/h5-indexed-source-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==1
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-01/original-source-checks.json','search/epoch-01/response.json','search/epoch-01/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json',Q/'response-audit/checks.json',U/'response-audit/checks.json',V/'response-audit/checks.json',X/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-01/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-01/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-01/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P),('prior_best_admissible',Q),('prior_current_mode',U),('prior_two_center',V),('prior_indexed_source',X)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))




# Read-only costs and an exact empty-intersection screen in the closed runtime context.
import shapely
from h5_mixed_direct_pose_20261107 import owner_shapes
from h5_bracket_augmented_objective_20261107 import compile_model
E=BASE/'search/epoch-01';runtime_audit=BASE/'response-audit/epoch-01-selection'
assert load(runtime_audit/'checks.json')['passed']
opened=load(E/'opened.json');call=load(E/'optimizer-opened.json');first_call=load(BASE/'search/epoch-00/optimizer-opened.json');result=load(BASE/'search/result.json');selection=load(E/'selection.json');trials=load(E/'center-trials.json');selections=load(E/'center-selections.json');lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');weights=load(E/'weight-transition.json')['after'];modes=opened['incoming_modes'];values=opened['incoming_values']
model=compile_model(lib,modes,values,weights,identity);obj=Objective(model,regions,identity);entries=obj.geometry(values,False)
right=[np.asarray([e[1] for e in level],dtype=object) for level in entries];right_bounds=[shapely.bounds(r) for r in right]
proof=[];totals={'dense_pairs':0,'kept_pairs':0,'omitted_pairs':0,'dense_seconds':[0.,0.],'screened_seconds':[0.,0.]};position=0
for selected in selections:
    i,mi=selected['owner'],selected['mode'];rows=trials[position:position+82];assert len(rows)==82 and all(r['owner']==i and r['mode']==mi for r in rows);position+=82
    centers=[]
    for row in rows:
        if row['center'] not in centers:centers.append(row['center'])
    family=lib['identities'][i][0];angle=values[model['owners'][i]['angle_coordinate']]/lib['angle_scale_mm'] if family=='cog' else 0.
    shapes=[owner_shapes(lib,family,mi,c,angle) for c in centers]
    for level in range(2):
        left=np.asarray([shape[level] for shape in shapes],dtype=object);rb=right_bounds[level];lb=shapely.bounds(left);assert np.all(np.isfinite(lb)) and np.all(np.isfinite(rb))
        def screened():
            # Strictly disjoint bounding boxes cannot have positive intersection area.
            keep=(lb[:,None,0]<=rb[None,:,2])&(lb[:,None,2]>=rb[None,:,0])&(lb[:,None,1]<=rb[None,:,3])&(lb[:,None,3]>=rb[None,:,1])
            a,b=np.nonzero(keep);areas=np.zeros((len(left),len(right[level])))
            areas[a,b]=shapely.area(shapely.intersection(left[a],right[level][b]))
            return areas,keep
        observed=[];times=[]
        for kind in ['dense','screened','screened','dense']:
            before=time.perf_counter()
            if kind=='dense':areas=shapely.area(shapely.intersection(left[:,None],right[level][None,:]));mask=None
            else:areas,mask=screened()
            times.append(time.perf_counter()-before);observed.append(areas)
        assert all(np.array_equal(observed[0],a) for a in observed[1:])
        _,mask=screened();assert np.count_nonzero(observed[0][~mask])==0
        count=mask.size;kept=int(np.count_nonzero(mask));totals['dense_pairs']+=count;totals['kept_pairs']+=kept;totals['omitted_pairs']+=count-kept
        for index,k in enumerate([0,3]):totals['dense_seconds'][index]+=times[k]
        for index,k in enumerate([1,2]):totals['screened_seconds'][index]+=times[k]
        proof.append({'owner':i,'mode':mi,'level':level,'unique_centers':len(centers),'dense_pairs':count,'kept_pairs':kept,'omitted_pairs':count-kept,'all_four_area_matrices_identical':True,'omitted_positive_areas':0,'ABBA_kernel_seconds':times})
assert position==9102 and len(proof)==222
paths=[Path(__file__),ROOT/'output/h5_tiered_runtime_cost_diagnosis_20261107.py',ROOT/'output/h5_mixed_direct_pose_20261107.py',A/'library.json',A/'objective-identity.json',B/'regions.json']+[E/n for n in ['opened.json','optimizer-opened.json','selection.json','center-trials.json','center-selections.json','weight-transition.json','response.json']]+[runtime_audit/'checks.json',BASE/'search/epoch-00/optimizer-opened.json',BASE/'search/result.json',BASE/'response-audit/checks.json']
write(OUT/'runtime-cost-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Reconcile saved complete-primary selection interval and shortened optimizer allocation. On every unique source-grid geometry in the closed runtime context, compare full broadcast polygon intersection areas with strictly disjoint-bounding-box screening. Keep touching bounding boxes. All222owner/mode/level matrices must match exactly; omitted positive areas must be zero. Fixed dense/screened/screened/dense kernel order per matrix, two aggregate samples each. Shape construction and bound extraction excluded from kernel timing; no whole-selector speed claim. Diagnostic only, no runtime implementation/source state/optimizer change.'})
write(OUT/'bounding-box-controls.json',proof)
write(OUT/'runtime-costs.json',{'passed':True,'runtime_complete_primary_proposals':5911,'runtime_center_trials':9102,'runtime_key_minima':2854,'selected_changes':selection['accepted_choice']['changes'],'selected_centers':selection['accepted_choice']['centers'],'selected_augmented_mm2':selection['accepted_choice']['augmented_objective_mm2'],'runtime_weight_selection_output_model_interval_seconds':call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'],'first_call_startup_after_preparation_seconds':first_call['algorithm_seconds_including_preparation']-result['complete_preparation_seconds'],'second_optimizer_allocated_seconds':call['allocated_seconds'],'geometry_matrices_verified':222,**totals,'shape_construction_and_bounds_timed':False,'whole_selector_speedup_claimed':False,'new_screened_selector_prepared':False,'validation_only':True,'optimizer_calls':0,'new_source_state_prepared':False,'closed_search_resumed':False,'H5_complete':False})
print(load(OUT/'runtime-costs.json'))
