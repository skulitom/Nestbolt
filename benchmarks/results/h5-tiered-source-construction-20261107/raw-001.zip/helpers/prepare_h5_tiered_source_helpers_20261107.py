"""Version source preparation and independent primary-tier readback helpers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
def save(name,s):
    p=O/name
    if p.exists():
        assert p.read_text()==s
        return
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def change(s,a,b):
    assert a in s,a
    return s.replace(a,b)
s=(O/'h5_two_center_key_readback_20261107.py').read_text()
s=change(s,'assert len(records)==len(independent_rows)==23419','assert len(records)==len(independent_rows)==5911\n    by_sequence={r["sequence"]:r for r in records};assert len(by_sequence)==5911')
s=change(s,'assert set(actual)==set(range(23419))','assert set(actual)==set(by_sequence)')
s=change(s,'{2179:1,130:78,4:2775}','{562:1,33:78,1:2775}')
s=change(s,'rows=[records[s] for s in sequences]','rows=[by_sequence[s] for s in sequences]')
save('h5_tiered_primary_key_readback_20261107.py',s)
s=(O/'h5_two_center_selection_readback_20261107.py').read_text()
s=change(s,'from h5_two_center_key_readback_20261107','from h5_tiered_primary_key_readback_20261107')
s=change(s,'assert len(records)==23419','assert len(records)==5911')
a="    owner_options={i:[(i,mi,tuple(center)) for mi in options[i] for center in chosen_centers[i,mi]] for i in range(33)}"
b=a+"\n    canonical=[()]+[(option,) for i in range(33) for option in owner_options[i]]+[(a,b) for i,j in combinations(range(33),2) for a,b in product(owner_options[i],owner_options[j])]\n    primary_order=[(k,row) for k,row in enumerate(canonical) if all(center==tuple(chosen_centers[i,mi][0]) for i,mi,center in row)]\n    assert len(canonical)==23419 and len(primary_order)==5911\n    expected_sequences=[k for k,row in primary_order]\n    owner_options={i:[(i,mi,tuple(chosen_centers[i,mi][0])) for mi in options[i]] for i in range(33)}"
s=change(s,a,b)
s=change(s,'assert len(expected)==len(observed)==len(records)==23419 and expected==observed','assert len(expected)==len(observed)==len(records)==5911 and expected==observed\n    assert [r["sequence"] for r in records]==expected_sequences\n    assert [tuple((i,mi,tuple(center)) for (i,mi),center in zip(r["changes"],r["centers"])) for r in records]==[row for k,row in primary_order]')
s=change(s,"for sequence,row in enumerate(records):\n        chosen=modes.copy();point=values.copy();assert row['sequence']==sequence","for index,row in enumerate(records):\n        sequence=expected_sequences[index];chosen=modes.copy();point=values.copy();assert row['sequence']==sequence")
s=change(s,"{'bracket/bracket':6000,'bracket/insert':8640,'bracket/cog':3600,'insert/insert':2376,'insert/cog':2160,'cog/cog':420}","{'bracket/bracket':1500,'bracket/insert':2160,'bracket/cog':900,'insert/insert':594,'insert/cog':540,'cog/cog':105}")
s=change(s,"'raw_proposals':23419","'raw_proposals':5911")
s=change(s,"{'4':2775,'130':78,'2179':1}","{'1':2775,'33':78,'562':1}")
save('h5_tiered_primary_selection_readback_20261107.py',s)
s=(O/'prepare_h5_indexed_source_preflight_20261107.py').read_text()
for a,b in [('all18closed','all19closed'),('h5-indexed-source-preflight-20261107','h5-tiered-source-preflight-20261107'),('h5-selector-equivalence-20261107','h5-tiered-selector-preflight-20261107'),("from h5_two_center_key_choice_20261107 import choose,KeySelectionDeadline","from h5_tiered_key_choice_20261107 import choose,KeySelectionDeadline,PRIMARY_SEQUENCES\nfrom h5_mixed_direct_pose_20261107 import source_rows\nfrom h5_legacy64_source_readback import audit as source_audit"),("P/'equivalence-audit.json'","P/'selector-audit.json'"),('audit_h5_indexed_source_preflight_20261107.py','audit_h5_tiered_source_preflight_20261107.py'),("'h5_two_center_key_choice_20261107.py','h5_two_center_key_readback_20261107.py'","'h5_tiered_key_choice_20261107.py','h5_tiered_primary_key_readback_20261107.py','h5_tiered_primary_selection_readback_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py'"),("load(V/'audit/checks.json')['complete_preparation_seconds']","load(X/'audit/checks.json')['complete_preparation_seconds']"),("'closed_keys':18","'closed_keys':19"),("'raw_proposals':23419","'raw_proposals':5911"),("'closure_deadline_checkpoints':[1,2,3,95,185]","'closure_deadline_checkpoints_inherited':[1,2,3,95,185]"),("choose(records,deadline=","choose(records,'primary',deadline=")]:s=change(s,a,b)
s=change(s,"load=lambda p:","X=ROOT/'output/h5-indexed-source-preflight-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'\nload=lambda p:")
s=change(s,"paths=[Path(__file__),","paths=[Path(__file__),JOB,X/'audit/checks.json',X/'closed-problems.json',X/'search/epoch-00/closed-problem.json',P/'cost-profile.json',P/'deadline-controls.json',")
s=change(s,"expected=load(V/'closed-problems.json')+[load(V/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]]","expected=load(X/'closed-problems.json')+[load(X/'search/epoch-00/closed-problem.json')]")
s=change(s,"==18;keys=","==19;keys=")
s=change(s,"write(OUT/'neighbors.json',records)","assert len(records)==23419\nrecords=[records[k] for k in PRIMARY_SEQUENCES];assert len(records)==5911\nwrite(OUT/'neighbors.json',records)")
s=change(s,"Regroup complete2854key minima", "Retain only the complete5911first-center neighborhood with canonical full-pool sequence IDs, then regroup complete2854key minima")
s=change(s,"if chosen is not None:\n    modes", "if chosen is not None:\n    model_started=time.perf_counter()\n    modes")
s=change(s,"runtime=load(V/'runtime-bindings.json')", "    model_returned=time.perf_counter();rows=source_rows(model,values);write(OUT/'initializer-source66.json',rows)\n    checked=source_audit(load(JOB),rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])))\n    assert checked['stock_failures']==0 and checked['originals']==66\n    write(OUT/'initializer-source-checks.json',checked)\n    write(OUT/'model-and-source-costs.json',{'model_construction_verification_and_serialization_seconds':model_returned-model_started,'source_output_and_validation_seconds':time.perf_counter()-model_returned,'source_valid66':checked['valid'],'pair_failures':checked['pair_failures'],'optimizer_calls':0})\nruntime=load(V/'runtime-bindings.json')")
save('prepare_h5_tiered_source_preflight_20261107.py',s)
