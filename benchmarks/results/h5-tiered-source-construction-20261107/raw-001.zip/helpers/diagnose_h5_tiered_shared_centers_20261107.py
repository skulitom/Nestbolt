"""Prove identical source-grid geometry reuse without preparing a new selector."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,time,os
import numpy as np
import shapely
from h5_bracket_augmented_objective_20261107 import Objective,compile_model
from h5_mixed_direct_pose_20261107 import owner_shapes
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-tiered-source-preflight-20261107';E=BASE/'search/epoch-01';OUT=BASE/'shared-center-diagnostic';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[n]=='1' for n in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'response-audit/epoch-01-selection/checks.json')['passed']
inputs=[Path(__file__)]+[E/n for n in ['opened.json','weight-transition.json','center-trials.json','center-selections.json']]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-01-selection/checks.json','response-audit/epoch-01-selection/center-score-controls.json','outcome-diagnostic/runtime-costs.json']]+[A/'library.json',A/'objective-identity.json',B/'regions.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Validation-only shared raw intersection rows in the closed runtime context. Use exact family, nominal mode, angle and center keys; never physical alias alone. Rebuild both shapes at every trial and require exact WKB identity on repeats. Cache only raw unmasked pair-area rows against the unchanged whole context. Copy the baseline full pair vector and replace the current owner affected pairs, leaving cache rows immutable. Require exact recorded weighted-area scores for all9102trials and agreement with independent full-score controls. Auxiliary depth/ranking remains outside this diagnostic. No new selector, source initializer, optimizer or changed-context cache.','maximum_seconds':60,'memory_bytes':2**31,'optimizer_calls':0})
opened=load(E/'opened.json');modes=opened['incoming_modes'];values=opened['incoming_values'];weights=load(E/'weight-transition.json')['after'];lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');model=compile_model(lib,modes,values,weights,identity);obj=Objective(model,regions,identity)
right=[np.asarray([r[1] for r in level],dtype=object) for level in obj.geometry(values,False)];baseline=obj.pair_losses(values);pairs=model['pairs'];trials=load(E/'center-trials.json');oracles=load(BASE/'response-audit/epoch-01-selection/center-score-controls.json');assert len(trials)==len(oracles)==9102
cache={};members={};controls=[];families=Counter();unique_owner_centers=sum(r['duplicate_of'] is None for r in trials);max_error=0.
for row,oracle in zip(trials,oracles):
    assert row['sequence']==oracle['sequence'];i,mi=row['owner'],row['mode'];family=lib['identities'][i][0];angle=values[model['owners'][i]['angle_coordinate']]/lib['angle_scale_mm'] if family=='cog' else 0.
    key=(family,mi,angle,tuple(row['center']));shapes=owner_shapes(lib,family,mi,row['center'],angle);wkb=tuple(p.wkb for p in shapes);hit=key in cache
    if not hit:
        raw=sum((shapely.area(shapely.intersection(p,other)) for p,other in zip(shapes,right)),np.zeros(33));raw.setflags(write=False);cache[key]=(wkb,raw);members[key]=[];families[family]+=1
    else:assert cache[key][0]==wkb
    raw=cache[key][1];assert not raw.flags.writeable
    full=baseline.copy()
    for k,(a,b) in enumerate(pairs):
        if a==i or b==i:full[k]=raw[b if a==i else a]
    weighted=float(np.dot(weights,full));assert weighted==row['weighted_area_objective_mm2'];error=abs(weighted-oracle['weighted_area_objective_mm2']);assert error<1e-6;max_error=max(max_error,error)
    members[key].append({'sequence':row['sequence'],'owner':i,'duplicate_of':row['duplicate_of']});controls.append({'sequence':row['sequence'],'geometry_cache_hit':hit,'weighted_area_exact':True,'independent_score_error_mm2':error})
groups=[{'family':key[0],'nominal_mode':key[1],'angle':key[2],'center':key[3],'shape_sha256':[sha256(w).hexdigest() for w in cache[key][0]],'members':v,'distinct_owners':len({r['owner'] for r in v})} for key,v in members.items()]
write(OUT/'geometry-groups.json',groups);write(OUT/'score-controls.json',controls)
summary={'passed':True,'seconds':time.perf_counter()-started,'nominal_trials':9102,'unique_owner_mode_centers':unique_owner_centers,'distinct_geometry_keys':len(cache),'cross_owner_shared_keys':sum(r['distinct_owners']>1 for r in groups),'nominal_cache_hits':sum(r['geometry_cache_hit'] for r in controls),'distinct_geometry_keys_by_family':dict(families),'dense_geometry_pair_calls_before':unique_owner_centers*66,'dense_geometry_pair_calls_with_shared_rows':len(cache)*66,'weighted_area_scores_exact':len(controls),'max_independent_weighted_area_error_mm2':max_error,'raw_rows_readonly':True,'all_repeated_shape_bytes_equal':True,'cache_scope':'single immutable closed runtime context only','auxiliary_depth_and_complete_selector_not_tested_here':True,'whole_selector_speedup_claimed':False,'new_selector_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
