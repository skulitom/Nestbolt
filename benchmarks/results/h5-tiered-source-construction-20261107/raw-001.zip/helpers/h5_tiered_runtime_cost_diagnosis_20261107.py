# Read-only costs and an exact empty-intersection screen in the closed runtime context.
import shapely
from h5_mixed_direct_pose_20261107 import owner_shapes
from h5_bracket_augmented_objective_20261107 import compile_model
E=BASE/'search/epoch-01';runtime_audit=BASE/'response-audit/epoch-01-selection'
assert load(runtime_audit/'checks.json')['passed']
opened=load(E/'opened.json');call=load(E/'optimizer-opened.json');first_call=load(BASE/'search/epoch-00/optimizer-opened.json');result=load(BASE/'search/result.json');selection=load(E/'selection.json');trials=load(E/'center-trials.json');selections=load(E/'center-selections.json');lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');weights=load(E/'weight-transition.json')['after'];modes=opened['incoming_modes'];values=opened['incoming_values']
model=compile_model(lib,modes,values,weights,identity);obj=Objective(model,regions,identity);entries=obj.geometry(values,False)
right=[np.asarray([e[1] for e in level],dtype=object) for level in entries];right_bounds=[shapely.bounds(r) for r in right]
proof=[];totals={'dense_pairs':0,'kept_pairs':0,'omitted_pairs':0,'dense_seconds':[0.,0.],'screened_seconds':[0.,0.]};position=0
for selected in selections:
    i,mi=selected['owner'],selected['mode'];rows=trials[position:position+82];assert len(rows)==82 and all(r['owner']==i and r['mode']==mi for r in rows);position+=82
    centers=[]
    for row in rows:
        if row['center'] not in centers:centers.append(row['center'])
    family=lib['identities'][i][0];angle=values[model['owners'][i]['angle_coordinate']]/lib['angle_scale_mm'] if family=='cog' else 0.
    shapes=[owner_shapes(lib,family,mi,c,angle) for c in centers]
    for level in range(2):
        left=np.asarray([shape[level] for shape in shapes],dtype=object);rb=right_bounds[level];lb=shapely.bounds(left);assert np.all(np.isfinite(lb)) and np.all(np.isfinite(rb))
        def screened():
            # Strictly disjoint bounding boxes cannot have positive intersection area.
            keep=(lb[:,None,0]<=rb[None,:,2])&(lb[:,None,2]>=rb[None,:,0])&(lb[:,None,1]<=rb[None,:,3])&(lb[:,None,3]>=rb[None,:,1])
            a,b=np.nonzero(keep);areas=np.zeros((len(left),len(right[level])))
            areas[a,b]=shapely.area(shapely.intersection(left[a],right[level][b]))
            return areas,keep
        observed=[];times=[]
        for kind in ['dense','screened','screened','dense']:
            before=time.perf_counter()
            if kind=='dense':areas=shapely.area(shapely.intersection(left[:,None],right[level][None,:]));mask=None
            else:areas,mask=screened()
            times.append(time.perf_counter()-before);observed.append(areas)
        assert all(np.array_equal(observed[0],a) for a in observed[1:])
        _,mask=screened();assert np.count_nonzero(observed[0][~mask])==0
        count=mask.size;kept=int(np.count_nonzero(mask));totals['dense_pairs']+=count;totals['kept_pairs']+=kept;totals['omitted_pairs']+=count-kept
        for index,k in enumerate([0,3]):totals['dense_seconds'][index]+=times[k]
        for index,k in enumerate([1,2]):totals['screened_seconds'][index]+=times[k]
        proof.append({'owner':i,'mode':mi,'level':level,'unique_centers':len(centers),'dense_pairs':count,'kept_pairs':kept,'omitted_pairs':count-kept,'all_four_area_matrices_identical':True,'omitted_positive_areas':0,'ABBA_kernel_seconds':times})
assert position==9102 and len(proof)==222
paths=[Path(__file__),ROOT/'output/h5_tiered_runtime_cost_diagnosis_20261107.py',ROOT/'output/h5_mixed_direct_pose_20261107.py',A/'library.json',A/'objective-identity.json',B/'regions.json']+[E/n for n in ['opened.json','optimizer-opened.json','selection.json','center-trials.json','center-selections.json','weight-transition.json','response.json']]+[runtime_audit/'checks.json',BASE/'search/epoch-00/optimizer-opened.json',BASE/'search/result.json',BASE/'response-audit/checks.json']
write(OUT/'runtime-cost-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Reconcile saved complete-primary selection interval and shortened optimizer allocation. On every unique source-grid geometry in the closed runtime context, compare full broadcast polygon intersection areas with strictly disjoint-bounding-box screening. Keep touching bounding boxes. All222owner/mode/level matrices must match exactly; omitted positive areas must be zero. Fixed dense/screened/screened/dense kernel order per matrix, two aggregate samples each. Shape construction and bound extraction excluded from kernel timing; no whole-selector speed claim. Diagnostic only, no runtime implementation/source state/optimizer change.'})
write(OUT/'bounding-box-controls.json',proof)
write(OUT/'runtime-costs.json',{'passed':True,'runtime_complete_primary_proposals':5911,'runtime_center_trials':9102,'runtime_key_minima':2854,'selected_changes':selection['accepted_choice']['changes'],'selected_centers':selection['accepted_choice']['centers'],'selected_augmented_mm2':selection['accepted_choice']['augmented_objective_mm2'],'runtime_weight_selection_output_model_interval_seconds':call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'],'first_call_startup_after_preparation_seconds':first_call['algorithm_seconds_including_preparation']-result['complete_preparation_seconds'],'second_optimizer_allocated_seconds':call['allocated_seconds'],'geometry_matrices_verified':222,**totals,'shape_construction_and_bounds_timed':False,'whole_selector_speedup_claimed':False,'new_screened_selector_prepared':False,'validation_only':True,'optimizer_calls':0,'new_source_state_prepared':False,'closed_search_resumed':False,'H5_complete':False})
print(load(OUT/'runtime-costs.json'))
