"""Freeze a new primary-tier-only finite search and complete response replay."""
from pathlib import Path
O=Path(__file__).resolve().parent
def change(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def save(name,s):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_indexed_source_search_20261107.py').read_text()
for a,b in [('h5-indexed-source-preflight-20261107','h5-tiered-source-preflight-20261107'),('h5-selector-equivalence-20261107','h5-tiered-selector-preflight-20261107'),('audit_h5_indexed_source_response_20261107.py','audit_h5_tiered_source_response_20261107.py'),('run_h5_indexed_source_response_stage_20261107.py','run_h5_tiered_source_response_stage_20261107.py'),("from h5_indexed_two_center_neighbors_20261107 import neighbors,apply_neighbor,SelectionDeadline","from h5_indexed_two_center_neighbors_20261107 import apply_neighbor\n    from h5_tiered_selection_20261107 import select"),("    from h5_two_center_key_choice_20261107 import choose,KeySelectionDeadline\n",''),("'h5_two_center_key_choice_20261107.py','h5_two_center_key_readback_20261107.py','h5_two_center_selection_readback_20261107.py'","'h5_tiered_selection_20261107.py','h5_tiered_neighbors_20261107.py','h5_tiered_key_choice_20261107.py','h5_tiered_primary_key_readback_20261107.py','h5_tiered_primary_selection_readback_20261107.py'"),("['plan.json','equivalence-audit.json','cache-controls.json','deadline-controls.json','timings.json','archive-checks.json']","['plan.json','selector-audit.json','stale-cache-controls.json','deadline-controls.json','timings.json','cost-profile.json','archive-checks.json']")]:s=change(s,a,b)
start=s.index('            try:\n                records,aliases,trials,selections=neighbors(');end=s.index("            write(folder/'selection.json',selection)",start)
s=s[:start]+'''            tier=select(lib,modes,incoming,weights,identity,regions,visited,primary_deadline=started+plan['selection_boundary_seconds'],extension_deadline=None,cached_trials=None)
            if tier['status']!='PRIMARY_COMPLETE':
                assert tier['status']=='NO_COMPLETE_PRIMARY' and tier['selected_proposal'] is None
                write(folder/'incomplete-primary.json',tier);stop='PRIMARY_SELECTION_DEADLINE';break
            assert tier['completed_tier']=='primary' and tier['extended'] is None and tier['partial'] is None
            records=tier['primary']['records'];selection=tier['primary']['selection'];groups=tier['primary']['groups'];minima=tier['primary']['minima']
            aliases,trials,selections=[tier[n] for n in ['aliases','trials','selections']]
            write(folder/'selection-tier.json',{'completed_tier':'primary','raw_proposals':5911,'distinct_keys':2854,'extension_attempted':False,'selected_proposal':tier['selected_proposal']})
            write(folder/'neighbors.json',records);write(folder/'owner-aliases.json',aliases);write(folder/'center-trials.json',trials);write(folder/'center-selections.json',selections);total_trials+=len(records);total_centers+=len(trials)
''' +s[end:]
s=change(s,"'complete_runtime_proposals':total_trials","'neighborhood_tier':'primary','extension_attempts':0,'complete_runtime_proposals':total_trials")
s=change(s,"checked['strictly_improves_current'];OUT.mkdir();charge=checked['complete_preparation_seconds'];started=time.perf_counter()-charge","checked['strictly_improves_current'];OUT.mkdir();charge=checked['complete_preparation_seconds'];assert charge<46;started=time.perf_counter()-charge")
s=change(s,"'source-cache-bindings.json']]+[K/n", "'source-cache-bindings.json','model-and-source-costs.json','initializer-source66.json','initializer-source-checks.json','audit/initializer-source-controls.json']]+[K/n")
start=s.index("'method':'One fresh finite adaptive pipeline");end=s.index(",'retry_permitted':False,'restarts':0",start)
method="One new finite adaptive pipeline from the independently verified original A/W source initializer under all19closed identities, charging all inherited and new source preparation. Source initialization uses only exact hash/context-bound original-source scores and complete5911first-center proposals. Runtime evaluates the declared complete PRIMARY tier only:9x9plusclamped source centers,111physical owner/mode options,9102trials,5911raw proposals,2854complete key minima. Second-center extension is deliberately disabled in this finite contract to reserve the remaining budget for optimizer/source checks; its separate validated implementation does not make incomplete output eligible. Runtime geometry always recalculates with cached_trials=None. Keep528weighted area terms,15coefficient1auxiliary terms,33movers/15continuousangles and the existing bounded area-only weight update. At most two4second calls, each shortened at54seconds for source checks; primary selection/grouping stop at52seconds. Timing observations support this bounded attempt, not a guarantee of a second call. Every exact objective/physical-mode/weight key closes after one call; changed coordinates/code cannot reopen it. Preserve every evaluation, three winner streams and full66source outputs. Stop on finite count, time, no strict1e-6improvement, source validity or inconsistency.60/90second preparation-inclusive algorithm/shared limits,2GiBverifiedJobv4. No restart/reseed/refinement/native call."
s=s[:start]+"'neighborhood_tier':'primary','extension_attempts':0,'method':"+repr(method)+s[end:]
marker="    controls=load(EXE.parent/'checks.json');"
budget="""    profile=load(K/'cost-profile.json');runtime_profile=next(r for r in profile['profiles'] if r['context']=='runtime-uncached');timings=load(K/'timings.json');selector=max(r['selector_and_grouping_seconds'] for r in timings if r['context']=='runtime' and r['kind']=='primary');cost=load(BASE/'model-and-source-costs.json');planned=charge+8+selector+runtime_profile['serialization']['wall_seconds']+2*(cost['model_construction_verification_and_serialization_seconds']+3*cost['source_output_and_validation_seconds'])+1.
    assert planned<60
    write(OUT/'budget-assessment.json',{'complete_preparation_seconds':charge,'maximum_optimizer_seconds':8,'primary_selector_observed_upper_seconds':selector,'runtime_serialization_observed_seconds':runtime_profile['serialization']['wall_seconds'],'per_model_observed_seconds':cost['model_construction_verification_and_serialization_seconds'],'per_source_check_observed_seconds':cost['source_output_and_validation_seconds'],'unmeasured_startup_planning_allowance_seconds':1.,'planned_algorithm_seconds':planned,'limits_guaranteed_by_estimate':False,'actual_deadlines_required':True,'source_variation_retained':True,'optimizer_calls':0})
"""
s=change(s,marker,budget+marker)
save('run_h5_tiered_source_search_20261107.py',s)
s=(O/'audit_h5_indexed_source_response_20261107.py').read_text()
for a,b in [('h5-indexed-source-preflight-20261107','h5-tiered-source-preflight-20261107'),('h5_two_center_selection_readback_20261107','h5_tiered_primary_selection_readback_20261107'),('h5_two_center_key_readback_20261107','h5_tiered_primary_key_readback_20261107'),('len(old_closed)==18','len(old_closed)==19'),("==result['historical_closed_keys']==18","==result['historical_closed_keys']==19"),("'prior_closed_keys':18","'prior_closed_keys':19")]:s=change(s,a,b)
start=s.index("        if (folder/'partial-selection.json').exists():");end=s.index("        assert selection==load(folder/'selection.json')",start)
s=s[:start]+'''        if (folder/'incomplete-primary.json').exists():
            from h5_tiered_neighbors_20261107 import primary
            saved=load(folder/'incomplete-primary.json');captured=saved['partial']
            assert saved['status']=='NO_COMPLETE_PRIMARY' and saved['completed_tier'] is None and saved['selected_proposal'] is None and saved['optimizer_calls']==0 and result['status']=='PRIMARY_SELECTION_DEADLINE'
            pool=primary(lib,modes,incoming,weights,identity,regions,visited,deadline=time.perf_counter()+60,cached_trials=None);full=(pool.primary,pool.aliases,pool.trials,pool.selections)
            selection,groups,minima=verify_selection(lib,modes,incoming,weights,identity,regions,visited,*full,OUT/f'epoch-{epoch:02d}-partial-reference');partial+=1
            if captured['status']=='SELECTION_DEADLINE':
                assert not captured['primary_complete'] and captured['primary_records']==[]
                for field,rows in zip(['records','aliases','trials','selections'],full):assert captured[field]==rows[:len(captured[field])]
            else:
                assert captured['status']=='KEY_SELECTION_DEADLINE' and saved['primary']['records']==full[0]
                assert captured['group_members']==({} if captured['checkpoints']==1 else groups) and captured['key_minima']==([] if captured['checkpoints']<3 else minima)
                for field,rows in zip(['aliases','trials','selections'],full[1:]):assert saved[field]==rows
            assert captured['observed']>=captured['deadline'] and captured['overrun_seconds']==captured['observed']-captured['deadline'] and not (folder/'optimizer-opened.json').exists();inputs.append(folder/'incomplete-primary.json');break
        records=load(folder/'neighbors.json');aliases=load(folder/'owner-aliases.json');trials=load(folder/'center-trials.json');selections=load(folder/'center-selections.json')
        selection,groups,minima=verify_selection(lib,modes,incoming,weights,identity,regions,visited,records,aliases,trials,selections,OUT/f'epoch-{epoch:02d}-selection');centers+=len(trials);proposals+=len(records)
        tier=load(folder/'selection-tier.json');assert tier=={'completed_tier':'primary','raw_proposals':5911,'distinct_keys':2854,'extension_attempted':False,'selected_proposal':selection['accepted_choice']}
        inputs+=[folder/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','selection-tier.json']]
''' +s[end:]
s=change(s,"'SELECTION_DEADLINE','KEY_SELECTION_DEADLINE'","'PRIMARY_SELECTION_DEADLINE'")
s=change(s,"inputs=[Path(__file__)]+", "inputs=[Path(__file__),S/'budget-assessment.json']+")
s=change(s,"assert plan['maximum_optimizer_calls']==2", "assert plan['neighborhood_tier']==result['neighborhood_tier']=='primary' and plan['extension_attempts']==result['extension_attempts']==0\nassert plan['maximum_optimizer_calls']==2")
save('audit_h5_tiered_source_response_20261107.py',s)
s=(O/'run_h5_indexed_source_response_stage_20261107.py').read_text().replace('h5_indexed_source','h5_tiered_source').replace('h5-indexed-source','h5-tiered-source')
save('run_h5_tiered_source_response_stage_20261107.py',s)
