"""Archive the closed primary-tier construction and complete independent replay."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-tiered-source-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-tiered-source-preflight-20261107';F=BASE/'response-audit';D=BASE/'outcome-diagnostic'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-tiered-selector-preflight-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==2 and front['best_original']['pair_failures']==51 and not front['source_valid66'] and front['independent_runtime_full_scores']==15013",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/f'h5-tiered-source-{stage}-process-20261107' for stage in ['preparation','audit','response-audit','diagnosis','shared-centers']]+[ROOT/'output/h5-indexed-source-main-sync-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*tiered*source*20261107.py','h5_tiered_runtime_cost_diagnosis_20261107.py','diagnose_h5_tiered_shared_centers_20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_tiered_source_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'audit/checks.json','source-preflight-audit.json'),(BASE/'audit/selected-model-controls.json','source-model-controls.json'),(BASE/'audit/initializer-source-controls.json','initializer-source-controls.json'),(BASE/'audit/inherited-source-domains.json','inherited-source-domains.json'),(BASE/'audit/cache-rejection-controls.json','source-cache-controls.json'),(BASE/'audit/deadline-controls.json','source-deadline-controls.json'),(BASE/'source-cache-bindings.json','source-cache-bindings.json'),(BASE/'model-and-source-costs.json','source-costs.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-01/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-selection/checks.json','runtime-selection-audit.json'),(BASE/'search/plan.json','search-plan.json'),(BASE/'search/budget-assessment.json','budget-assessment.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-search-process.json'),(D/'checks.json','outcome-diagnostic.json'),(D/'family-failures.json','family-failures.json'),(D/'runtime-costs.json','runtime-costs.json'),(D/'bounding-box-controls.json','bounding-box-controls.json'),(BASE/'shared-center-diagnostic/checks.json','shared-center-diagnostic.json'),(BASE/'search/main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-indexed-source-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['preparation','audit','response-audit','diagnosis','shared-centers']:copies.append((ROOT/'output'/f'h5-tiered-source-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
closed=load(BASE/'closed-problems.json')+[load(BASE/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]];assert len(closed)==len({r['key'] for r in closed})==21;write(OUT/'closed-problems.json',closed)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
prep=load(OUT/'source-preflight-audit.json');model=load(OUT/'source-model-controls.json');diag=load(OUT/'outcome-diagnostic.json');cost=load(OUT/'runtime-costs.json');process=load(OUT/'closed-search-process.json');selection=load(OUT/'runtime-selection-audit.json');ci=load(OUT/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
assert all(r['passed'] for r in [prep,model,diag,cost,selection])
dense=sum(cost['dense_seconds'])/2;screened=sum(cost['screened_seconds'])/2;shared=load(OUT/'shared-center-diagnostic.json');assert shared['passed'] and shared['weighted_area_scores_exact']==9102 and shared['distinct_geometry_keys']==2342
write(OUT/'next-step.json',{'status':'shared_center_rows_full_selector_equivalence_required',
'finding':'The complete primary tier finishes and opens a second call, but the complete weight/selection/output/model interval leaves only1.2592204005923122s before the source-check reserve. Both calls close with invalid candidates. A bounding-box screen is exact here but saves only about0.29s in the measured kernel. A separate diagnostic identifies2342distinct geometries among9066unique owner/mode centers and reproduces all9102weighted-area scores exactly using immutable raw rows shared within this unchanged context. This targets a larger source of duplicate work without relaxing geometry.',
'proposal':'Assess a separately versioned selector that shares exact raw center geometry and unmasked intersection rows across owners within one immutable invocation, keyed by exact family, nominal mode, angle and center. Copy raw rows before owner-specific self masking; recalculate all affected auxiliary terms and never cache across a changed runtime context. Prove full source/runtime record, center ranking, key/minimum, snapshot and deadline equivalence against independent references, then measure complete selector cost. Do not pursue another search merely from the small bounding-box kernel saving. No shared-row selector, new source model or search contract is prepared.',
'requirements':['Preserve all21closed objective/physical-mode/weight keys and earlier finite stops. Faster code cannot reopen any key, optimized candidate or validation state.','Keep all9102source-grid trials,111physical modes,5911primary and23419extended raw memberships,2854key minima,528weighted area and15auxiliary terms,33movers/15angles, source geometry, strict1e-6improvement and stable tie handling. Every shared geometry must be exactly identical, cached raw rows must remain unmodified by owner masking, and cache scope is one unchanged invocation.','Prove complete geometry/score equality on original source and separately bound changed runtime contexts, stale cache rejection, isolation and all incomplete-tier deadline cases before any source preparation. Measure whole-selector cost, including cache/key creation, private snapshots, grouping and all outputs.','Any future initializer comes only from original unoptimized A/W data after exact source payload/context checks. Retain37.6806913993787s prior preparation plus all new work, then independently verify the model/source/output budget before a fresh finite60/90s2GiB contract.','H5 still requires a valid66source result, native/material evidence, production parity and its original matrix. Four fixed arrangements and440allocations remain unresolved.'],
'closed_problem_keys':21,'source_only_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'shared_row_selector_prepared':False,'new_source_state_prepared':False,'new_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
report=f'''# Primary-tier source construction — 2026-11-07

The new finite attempt completes the primary neighborhood and makes **two optimizer
calls**. The best candidate still has **51 failing source pairs** and
**{front['best_original']['score_mm2']:,.6f} mm² original overlap**. All stock checks
pass; no full66 valid layout, native/material result or allocation exclusion follows.
H2/H5 remain open at **60% completed milestone weight**.

[Fresh source preflight]({NAME}/source-preflight-audit.json) binds the original
A/W payloads and full context, derives the complete 5,911 first-center proposals,
and updates exclusions for all nineteen closed keys. All 2,854 key minima read back;
seven matching keys exclude 664 proposals. The 66 changed flags are retained.
Independent source scores, ten cache rejection controls, four new key deadlines
and three no-candidate policies pass, with unchanged closure/tier controls inherited.
[Source geometry domains]({NAME}/inherited-source-domains.json) remain bound.

The [new model]({NAME}/source-model-controls.json) changes owners {model['changes']}
at source centers {model['source_centers']}. Its 81 coordinates, 33 movers,
15 continuous angles, 528 weighted area pairs and 15 auxiliary terms read back.
Independent scalar-gradient error is {model['maximum_scalar_gradient_error_mm']:.3e}
across {model['directed_scalar_gradient_terms']} directed terms. The initializer's
[66 original parts]({NAME}/initializer-source-controls.json) retain 1,380 same-sheet
pairs, 264 stock edges, 90 cutouts and 10,026 hole vertices; it has 38 failing pairs.
This is a source-only initializer, never an optimized or validation-state seed.

The entire [preparation process]({NAME}/preparation-process.json) adds
{prep['new_source_preparation_seconds']:.6f} s to the retained 36.028144 s, for
**{front['complete_preparation_seconds']:.6f} s**. [Model/source costs]({NAME}/source-costs.json)
and the [budget estimate]({NAME}/budget-assessment.json) are recorded separately.
The estimate does not replace deadlines or promise both full four-second slices.

[The frozen contract]({NAME}/search-plan.json) declares the complete primary tier
only, at most two four-second calls, selection/grouping cutoff at 52 s and call
shortening at 54 s to reserve source checks. The optional second-center extension
is disabled for this attempt. Runtime geometry recalculates fully.
[Independent runtime replay]({NAME}/runtime-selection-audit.json) verifies all
**9,102 center scores, 5,911 proposals and 2,854 key minima**. Every canonical
sequence gap, center rank, physical alias, closure flag and strict choice is checked.
The complete weight/selection/output/model interval is
**{cost['runtime_weight_selection_output_model_interval_seconds']:.6f} s**, leaving
**{cost['second_optimizer_allocated_seconds']:.6f} s** for the second call.

[Response replay]({NAME}/response-audit.json) verifies all
**{front['total_evaluation_records_verified']} evaluation records**, **{front['saved_points_verified']}
saved points**, 528 updated weights and six full66 winner outputs. All three winner
streams coincide within each epoch. The first candidate has 55 failed pairs;
the second has [51]({NAME}/best-original-source-checks.json). Both distinct problem
identities join the [twenty-one closed keys]({NAME}/closed-problems.json).
Algorithm/shared totals are **{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**.
Slice overruns {front['slice_overruns_seconds']} are preserved. [All five search
processes close]({NAME}/closed-search-process.json), peak committed memory
{process['job']['peak_job_committed_memory']:,} bytes; overall 60/90 s and 2 GiB limits hold.

[Residual diagnosis]({NAME}/outcome-diagnostic.json) finds {diag['positive_area_pairs']}
positive area pairs, {diag['flat_available_pair_gradient_count']} flat available gradients,
{diag['bracket_bracket_source_failures']} bracket/bracket source failures and
{diag['cog_lower_y_negative_gradient_blocked']} cogs blocked at their lower-y bound.
[Family failures]({NAME}/family-failures.json) remain explicit. These historical
outcomes do not isolate a causal improvement from the new selector policy.

[A validation-only bounding-box screen]({NAME}/bounding-box-controls.json) compares
all **{cost['geometry_matrices_verified']} owner/mode/level area matrices**, retaining
touching boxes and omitting only strictly disjoint boxes. All four matrices in each
dense/screened/screened/dense control are exactly equal, with no omitted positive
area. Of {cost['dense_pairs']:,} unique geometry pairs, {cost['omitted_pairs']:,} are
screened out. [Aggregate kernel times]({NAME}/runtime-costs.json) average
{dense:.6f} s dense and {screened:.6f} s screened. Shape construction and bounds are
outside these timings. Two observations per kernel and one runtime context do not
prove whole-selector savings or a packing benefit.

The roughly {dense-screened:.6f} s kernel saving alone does not justify a successor
search. A [separate shared-center diagnostic]({NAME}/shared-center-diagnostic.json)
finds **{shared['distinct_geometry_keys']:,} distinct exact geometries** among
{shared['unique_owner_mode_centers']:,} unique owner/mode centers. Repeated shapes
have identical WKB bytes, and immutable raw area rows shared only inside this
unchanged context reproduce **all 9,102 weighted-area scores exactly**, agreeing
with the independent controls within {shared['max_independent_weighted_area_error_mm2']:.3e} mm².
That would reduce raw pair-area calculations from {shared['dense_geometry_pair_calls_before']:,}
to {shared['dense_geometry_pair_calls_with_shared_rows']:,} before owner-specific masking.
Auxiliary terms and complete selector behavior are outside this diagnostic.

[Next]({NAME}/next-step.json), verify complete selector equivalence and timing for
that shared-row approach before any fresh source model. No shared-row selector or
successor search is prepared. All prior calls remain closed; four arrangements and all
440 allocation candidates remain unresolved.

The earlier indexed checkpoint reached main **831ad47e** after all six preceding
CI checks passed, preserving 52 protected files. [The receipt]({NAME}/prior-main-push-receipt.json)
and [current CI snapshot]({NAME}/main-ci-at-review.json) are retained
({success} passed, {live} live at review). The tier-selector checkpoint and this
checkpoint await the next ordinary push gate. Product code, README and releases
remain unchanged.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical evidence]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 primary-tier source construction:** [complete source and response evidence]({{link}}) verifies a fresh original-source initializer under nineteen closures, all 5,911 primary proposals and 2,854 keys. Full preparation is {front["complete_preparation_seconds"]:.6f} s. The bounded attempt makes two calls; the second receives {cost["second_optimizer_allocated_seconds"]:.6f} s after complete runtime selection. Its best candidate remains invalid with 51 failed pairs and {front["best_original"]["score_mm2"]:.6f} mm² original overlap. All {front["total_evaluation_records_verified"]} records, {front["saved_points_verified"]} saved points, 528 updated weights, 15,013 runtime full scores and six source outputs replay. Algorithm/shared totals are {front["algorithm_seconds"]:.6f}/{front["shared_seconds"]:.6f} s; all processes close. Twenty-one keys remain closed. A bounding-box screen is exact but saves only about 0.29 s in the measured kernel. A separate shared-row diagnostic identifies 2,342 exact geometries among 9,066 unique owner/mode centers and reproduces all 9,102 weighted-area scores. Next verify complete selector equivalence and timing for shared raw rows; no implementation or successor search is prepared. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. Main remains 831ad47e; fresh CI has {success} passed / {live} live at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [primary-tier source construction](../benchmarks/results/{NAME}.md).
A fresh original-source initializer and full {front['complete_preparation_seconds']:.6f} s preparation charge
pass independent readback. The complete primary tier supplies a second call within
the finite budget; its allocation is {cost['second_optimizer_allocated_seconds']:.6f} s. Both calls close, with the
best candidate still invalid: 51 failed pairs and {front['best_original']['score_mm2']:.6f} mm² original overlap.
All {front['total_evaluation_records_verified']} evaluation records, {front['saved_points_verified']} saved points, 528 updated weights, 15,013
runtime full scores and six original-source outputs replay. Algorithm/shared totals
are {front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s; all processes close. Twenty-one keys remain closed.
A bounding-box screen is exact but its measured kernel saving is only about 0.29 s.
A separate shared-row diagnostic finds 2,342 exact geometries among 9,066 unique
owner/mode centers and reproduces all 9,102 weighted-area scores. Next verify whole
selector equivalence and timing for shared raw rows before any new source model
or search. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. Main
remains 831ad47e, with {success} passed / {live} live CI jobs at review. Product code,
README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
