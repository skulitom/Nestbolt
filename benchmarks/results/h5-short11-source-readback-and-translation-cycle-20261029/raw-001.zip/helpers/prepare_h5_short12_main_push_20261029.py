"""Prepare the guarded normal push of the two reviewed source-bound checkpoints."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1];new=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert new.startswith('9dab2f4e');s=(ROOT/'output/push_h5_source_pair_checkpoint_20261029.py').read_text(encoding='utf-8')
for a,b in [("OUT=ROOT/'output/h5-source-pair-main-sync-20261029'","OUT=ROOT/'output/h5-short12-main-sync-20261029'"),("OLD='d3b652b6400057aab92bc47f8121e8a339a88d2d';NEW='3e33dedbed809b2fdd3b97a8784b50a25732c3c0'", "OLD='3e33dedbed809b2fdd3b97a8784b50a25732c3c0';NEW='"+new+"'"),('40795603963','40800774981'),('benchmarks/results/h5-global-short-core-searches-20261029','benchmarks/results/h5-short-source-reference-exclusion-20261029'),('benchmarks/results/h5-short-strip-capacity-and-source-pair-20261029','benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029')]:assert a in s;s=s.replace(a,b)
p=ROOT/'output/push_h5_short12_checkpoint_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'target_head':new,'requires_all6_prior_CI_and_no_live_main_run':True,'normal_atomic_fast_forward_only':True})
