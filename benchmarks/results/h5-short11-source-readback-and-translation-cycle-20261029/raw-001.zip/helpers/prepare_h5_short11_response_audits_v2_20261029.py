"""Prepare separate response and original-transform readers for short11."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
response=(ROOT/'output/audit_h5_minimum_two_cog_response_20261029.py').read_text(encoding='utf-8');source=(ROOT/'output/audit_h5_minimum_two_cog_source_20261029.py').read_text(encoding='utf-8')
for a,b in [("output/h5-five-bracket-two-cog-core-20261029'","output/h5-source-projection-short11-20261029'"),('short7','short11'),('source7','source11'),('source_valid7','source_valid11'),('first59','first55')]:response=response.replace(a,b);source=source.replace(a,b)
for a,b in [('necessary_core7_geometry_valid','necessary_core11_geometry_valid'),("source['original_orthogonal_source_pair_failures']==source['original_orthogonal_source_stock_failures']==4","source['original_orthogonal_source_pair_failures']==5 and source['original_orthogonal_source_stock_failures']==4"),("source['baseline_source11_pair_failures']==source['baseline_source11_stock_failures']==5","source['baseline_source11_pair_failures']==10 and source['baseline_source11_stock_failures']==6"),('all7_active_and6_inactive_owners_verified','all11_active_and2_inactive_owners_verified'),("'original_bracket_pair_failures':4","'original_orthogonal_pair_failures':5"),("'original_bracket_stock_failures':4","'original_orthogonal_stock_failures':4"),("'original_source11_pair_failures':5","'original_source11_pair_failures':10"),("'original_source11_stock_failures':5","'original_source11_stock_failures':6")]:response=replace(response,a,b)
for a,b in [('decoded-core7','decoded-core11'),('orthogonal-source5','orthogonal-source9'),('len(saved)==7','len(saved)==11'),('saved[:5]==orth and len(orth)==5','saved[:9]==orth and len(orth)==9'),("if d['family']=='bracket':","if d['family'] in ['bracket','insert']:"),("parts['bracket']['geometry']","parts[d['family']]['geometry']"),('all7_original_identities_verified','all11_original_identities_verified'),('original_bracket_quarters_and_mirrors_verified','original_orthogonal_quarters_and_mirrors_verified'),('replayed-bracket-checks','replayed-orthogonal-checks'),("'bracket_pair_failures'","'orthogonal_pair_failures'"),("'bracket_stock_failures'","'orthogonal_stock_failures'")]:source=replace(source,a,b)
for name,s in [('audit_h5_source_projection_short11_response_20261029.py',response),('audit_h5_source_projection_short11_source_20261029.py',source)]:
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Independent short11 response/source readers prepared; no solver call.')
