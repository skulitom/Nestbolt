"""Preserve a failed cosmetic replacement assertion and prepare a separate correction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short11-20261029';OUT=BASE/'audit-preparation';OUT.mkdir();old=ROOT/'output/prepare_h5_short11_response_audits_20261029.py';s=old.read_text(encoding='utf-8');token="('seven original','eleven original'),";assert token in s;s=s.replace(token,'',1);new=ROOT/'output/prepare_h5_short11_response_audits_v2_20261029.py';compile(s,str(new),'exec')
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (OUT/'failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'failed_script':old.relative_to(ROOT).as_posix(),'failed_sha256':sha256(old.read_bytes()).hexdigest(),'failure':'AssertionError: seven original; cosmetic docstring text was absent in source template. No reader file had been written. Two attempted dependent audit commands then failed because the reader files did not exist.','separate_corrected_script':new.relative_to(ROOT).as_posix(),'solver_rerun':False,'original_model_search_and_response_preserved':True},f,indent=2);f.write('\n')
print('Failed preparation preserved; separate correction ready.')
