"""Seal the failed original-source witness, restricted contradiction and next axis choices."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-source-projection-short11-20261029';SYNC=ROOT/'output/h5-short12-main-sync-20261029';PUB=BASE/'publication';NAME='h5-short11-source-readback-and-translation-cycle-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='9dab2f4e5290a72c208d132f6e21ad31340f365c' and not git('diff','HEAD','--name-only')
for n in ['model-audit','response-audit','source-audit-v2','source-translation-preflight','source-translation-preflight/audit','source-translation-audit','source-translation-cycle-audit','source-axis-choice-preflight']:assert load(BASE/n/'checks.json')['passed']
cp=load(BASE/'response-audit/checks.json');lp=load(BASE/'source-translation-audit/checks.json');cycle=load(BASE/'source-translation-cycle-audit/checks.json');assert cp['status']=='OPTIMAL' and not cp['source_valid11'] and lp['solver_reported_status']=='INFEASIBLE' and cycle['restricted_frozen_branch_infeasibility_certified'] and not cycle['allocation_excluded'];receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
prior=load(ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up);assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert main==head and ci['head_sha']==head and ci['id']==40805531238 and len(jobs)==6 and len(passed)==4 and set(live)=={'checks (ubuntu-latest)','checks (windows-latest)'}
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';rows=load(frontier);assert len(rows)==4576 and sum(r['excluded_by'] is None for r in rows)==440 and digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_source_projection_short11_20261029.py','build_h5_source_projection_short11_20261029.py','audit_h5_source_projection_short11_model_20261029.py','prepare_h5_source_projection_short11_call_20261029.py','run_h5_source_projection_short11_20261029.py','check_h5_source_projection_short11_candidate_20261029.py','prepare_h5_short11_response_audits_20261029.py','repair_h5_short11_audit_preparation_20261029.py','prepare_h5_short11_response_audits_v2_20261029.py','audit_h5_source_projection_short11_response_20261029.py','audit_h5_source_projection_short11_source_20261029.py','repair_h5_short11_source_inventory_assertion_20261029.py','audit_h5_source_projection_short11_source_v2_20261029.py','prepare_h5_short11_source_translation_20261029.py','audit_h5_short11_source_translation_20261029.py','run_h5_short11_source_translation_20261029.py','audit_h5_short11_translation_response_20261029.py','verify_h5_short11_axis_cycle_20261029.py','prepare_h5_short11_axis_choices_20261029.py','prepare_h5_short12_main_push_20261029.py','push_h5_short12_checkpoint_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_short11_translation_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[('model-audit/checks.json','short11-model-audit.json'),('model-audit/inactive-owner-proof.json','short11-inactive-owner-proof.json'),('response-audit/checks.json','short11-response-audit.json'),('source-audit-v2/checks.json','short11-source-audit.json'),('source-audit-v2/replayed-source11-checks.json','short11-source-failures.json'),('search/source-response/decoded-core11.json','short11-core-placement.json'),('source-translation-preflight/checks.json','translation-preflight.json'),('source-translation-preflight/audit/checks.json','translation-geometry-audit.json'),('source-translation-preflight/method.json','translation-method.json'),('source-translation-search/result.json','translation-result.json'),('source-translation-audit/checks.json','translation-response-audit.json'),('source-translation-cycle-audit/certificate.json','translation-cycle-certificate.json'),('source-translation-cycle-audit/checks.json','translation-cycle-audit.json'),('source-axis-choice-preflight/method.json','next-axis-choice-method.json'),('source-axis-choice-preflight/checks.json','next-axis-choice-preflight.json')]
for a,b in copies:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'preserved-failures.json',[load(BASE/'audit-preparation/failure.json'),load(BASE/'source-audit/failure.json')]);shutil.copyfile(SYNC/'receipt.json',OUT/'prior-main-push-receipt.json');shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40805531238,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Build and independently audit the prepared fixed-orientation six-axis-choice source model. It replaces exactly six certified contradictory pair-axis rows with90 one-of-many binary selectors in six groups. Keep all other8720 piece-pair constraints, all22 free translations, all stock domains, original gap0.225mm/stock clearance0.025mm and all11/55 original identities. Expected dimensions113 variables/8860 rows. Verify M values over stock domains and every coefficient/guard/selector before the sole declared60/90-second mixed-integer algorithm call with128-node limit; charge preparation and reserve3seconds for original-source readback. Preserve all closed CP and fixed-axis LP calls. A negative or stopped result is restricted to this finite family; never exclude the allocation from it. Full66 construction, original/native/material validation, production integration and the H5 matrix still remain.','choice_groups':6,'candidate_axis_variants':90,'model_created':False,'search_opened':False,'short_originals':11,'first_originals':55,'remaining_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'closed_cp_calls':1,'closed_translation_lp_calls':1,'cp_status':'OPTIMAL','original_source11_rejected':True,'original_source_pair_failures':10,'original_source_stock_failures':6,'translation_solver_status':'INFEASIBLE','restricted_translation_cycle_independently_certified':True,'cycle_sum_mm':cycle['negative_sum_mm_approx'],'new_allocation_exclusions':0,'remaining_candidates':440,'valid64_preserved':True,'all_calls_within_budgets':True,'next_axis_choices_prepared':90,'next_model_created':False,'source_valid66_created':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [the 5/5/2 short-sheet allocation is excluded](../benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029.md),\nleaving 440 necessary allocation candidates.';new=f'Latest H5 evidence: [short11 source readback and a restricted translation contradiction](../benchmarks/results/{NAME}.md).\nThe 440 necessary allocation candidates remain open.';assert old in s;s=s.replace(old,new,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'remaining_candidates':440,'completion_percent':60})
