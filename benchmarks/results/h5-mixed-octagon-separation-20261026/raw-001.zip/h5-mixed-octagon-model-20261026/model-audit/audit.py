"""Independent serialized audit of the unchanged base and every mixed clause."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-octagon-model-20261026';OLD=ROOT/'output/h5-allocation-model-20261026'
GEO=ROOT/'output/h5-mixed-octagon-geometry-20261026';WIT=ROOT/'output/h5-retained64-proxy-regions-20261026/completion-model-audit';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
base=cp_model_pb2.CpModelProto();base.ParseFromString((OLD/'model.pb').read_bytes())
p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes())
assert len(base.variables)==609 and len(base.constraints)==5016
for a,b in zip(base.variables,p.variables):assert a.SerializeToString()==b.SerializeToString()
for a,b in zip(base.constraints,p.constraints):assert a.SerializeToString()==b.SerializeToString()
prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(p);del prefix.variables[609:];del prefix.constraints[5016:];prefix.ClearField('solution_hint');assert prefix.SerializeToString()==base.SerializeToString()
assert load(OLD/'model-audit/checks.json')['passed'] and load(WIT/'checks.json')['model_sha256']==digest(OLD/'model.pb')
assert load(GEO/'audit/checks.json')['passed']
assignment=load(WIT/'assignment.json');hints=[assignment[v.name] for v in base.variables]
assert list(p.solution_hint.vars)==list(range(609)) and list(p.solution_hint.values)==hints
for v,value in zip(base.variables,hints):assert any(a<=value<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
mp=load(OLD/'mapping.json');new=load(BASE/'mapping.json');assert new['base_mapping']==mp
polys={(r['variant'],r['component']):r for r in load(GEO/'forbidden-polygons.json')};pairs=load(GEO/'demonstrated-pairs.json')
vi=609;ci=5016;ri=0;rejections={};activated=0
for pair_index,pair in enumerate(pairs):
    bi,gi=pair['bracket_original_index'],pair['cog_original_index'];br,cg=mp['originals'][bi],mp['originals'][gi]
    assert 18<=bi<30 and 51<=gi<66
    for variant in range(8):
        for sheet in range(2):
            zs=[next(o['selector'] for o in record['options'] if (o['variant'],o['sheet'])==(v,sheet)) for record,v in [(br,variant),(cg,12)]]
            for component in range(3):
                faces=polys[variant,component]['inward_faces'];assert len(faces)==12;fs=[];cts=[];outside=[]
                for j,(nx,ny,rhs) in enumerate(faces):
                    variable=p.variables[vi];assert variable.name==f'mixed_{pair_index}_{variant}_{sheet}_{component}_{j}' and list(variable.domain)==[0,1]
                    ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==[vi]
                    coeff={cg['coordinate_indices'][0]:nx,cg['coordinate_indices'][1]:ny,br['coordinate_indices'][0]:-nx,br['coordinate_indices'][1]:-ny};coeff={k:v for k,v in sorted(coeff.items()) if v}
                    assert list(ct.linear.vars)==list(coeff) and list(ct.linear.coeffs)==list(coeff.values()) and list(ct.linear.domain)==[-9223372036854775808,rhs]
                    value=sum(c*hints[v] for v,c in coeff.items());outside.append(value<=rhs);fs.append(vi);cts.append(ci);vi+=1;ci+=1
                ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='bool_or' and list(ct.enforcement_literal)==zs and list(ct.bool_or.literals)==fs
                assert new['mixed_separation'][ri]=={'pair':pair_index,'bracket':bi,'cog':gi,'variant':variant,'sheet':sheet,'component':component,'selectors':zs,'facet_variables':fs,'facet_constraints':cts,'or_constraint':ci}
                if all(hints[z] for z in zs):
                    activated+=1
                    if not any(outside):rejections.setdefault(pair_index,[]).append(component)
                ci+=1;ri+=1
assert (vi,ci,ri)==(5217,10008,384) and len(p.variables)==vi and len(p.constraints)==ci and len(new['mixed_separation'])==ri
assert activated==24 and set(rejections)==set(range(8))
for k,components in rejections.items():assert components==pairs[k]['violated_components']
write(OUT/'hint-rejections.json',rejections)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'base609_variables_and5016_constraints_byte_identical':True,'advisory_hints_verified':609,'original_variables_fixed':0,'all66_required':True,'all8_demonstrated_pairs_rejected':True,'conditional_or_clauses_verified':384,'halfplanes_verified':4608,'all8_bracket_variants_and2_sheets_and3_components':True,'inactive_cases_can_disable_all_facets':True,'all_real_cog_rotations_retained':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
