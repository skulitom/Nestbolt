"""Strengthen the all-original model with demonstrated mixed collision necessities."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-allocation-model-20261026'
GEO=ROOT/'output/h5-mixed-octagon-geometry-20261026';OUT=ROOT/'output/h5-mixed-octagon-model-20261026'
WIT=ROOT/'output/h5-retained64-proxy-regions-20261026/completion-model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'audit/checks.json')['passed'] and load(OLD/'model-audit/checks.json')['passed'] and load(WIT/'checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
paths=[OLD/n for n in ['model.pb','model.pbtxt','mapping.json','model-audit/checks.json','plan.json']]+[WIT/n for n in ['assignment.json','checks.json']]
paths += [p for p in GEO.rglob('*') if p.is_file()]
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'ignore_subsolvers':['fj'],
    'hints':'609 prior necessary values, advisory only; known to violate the new collision clauses','objective':None,'all66_originals_required':True,
    'method':'Append exact source-contained octagon/rectangle separation necessities for eight demonstrated canonical bracket/cog pairs to the immutable coupled allocation model. Every pair covers all8 bracket variants, both sheets and all3 bracket components. Conditional OR requires an outside halfplane only when the two originals select that variant on the same sheet. Inactive clauses may use allfalse facet selectors. Boundary contact allowed. The octagon lies inside every rotation of the original cog, so no actual cog angle is selected or excluded. All original variables, domains and constraints remain byte-identical, with coordinates and sheet/mode choices free. Hints are not fixed. Independent whole-prefix and appended-constraint audit precedes one60-second call within90 shared seconds. No old model retry. Any positive necessary assignment requires actual original-ring readback before native validation.'})
proto=cp_model_pb2.CpModelProto();proto.ParseFromString((OLD/'model.pb').read_bytes())
assert len(proto.variables)==609 and len(proto.constraints)==5016 and not proto.solution_hint.vars
mp=load(OLD/'mapping.json');polys=load(GEO/'forbidden-polygons.json');pairs=load(GEO/'demonstrated-pairs.json');records=[]
for pair_index,pair in enumerate(pairs):
    bi,ci=pair['bracket_original_index'],pair['cog_original_index'];br,cg=mp['originals'][bi],mp['originals'][ci]
    for variant in range(8):
        for sheet in range(2):
            zbr=next(o['selector'] for o in br['options'] if (o['variant'],o['sheet'])==(variant,sheet))
            zcg=next(o['selector'] for o in cg['options'] if (o['variant'],o['sheet'])==(12,sheet))
            for component in range(3):
                poly=next(p for p in polys if (p['variant'],p['component'])==(variant,component))
                fs=[];facets=[]
                for face_index,(nx,ny,rhs) in enumerate(poly['inward_faces']):
                    ix=len(proto.variables);v=proto.variables.add(name=f'mixed_{pair_index}_{variant}_{sheet}_{component}_{face_index}');v.domain.extend([0,1]);fs.append(ix)
                    coeff={cg['coordinate_indices'][0]:nx,cg['coordinate_indices'][1]:ny,br['coordinate_indices'][0]:-nx,br['coordinate_indices'][1]:-ny}
                    coeff={k:v for k,v in sorted(coeff.items()) if v};ct_index=len(proto.constraints);ct=proto.constraints.add();ct.enforcement_literal.append(ix)
                    ct.linear.vars.extend(coeff);ct.linear.coeffs.extend(coeff.values());ct.linear.domain.extend([-9223372036854775808,rhs]);facets.append(ct_index)
                or_index=len(proto.constraints);ct=proto.constraints.add();ct.enforcement_literal.extend([zbr,zcg]);ct.bool_or.literals.extend(fs)
                records.append({'pair':pair_index,'bracket':bi,'cog':ci,'variant':variant,'sheet':sheet,'component':component,'selectors':[zbr,zcg],
                    'facet_variables':fs,'facet_constraints':facets,'or_constraint':or_index})
assignment=load(WIT/'assignment.json')
for i,v in enumerate(proto.variables[:609]):proto.solution_hint.vars.append(i);proto.solution_hint.values.append(assignment[v.name])
assert len(proto.variables)==5217 and len(proto.constraints)==10008
(OUT/'model.pb').write_bytes(proto.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(proto),encoding='utf-8',newline='\n')
model=cp_model.CpModel();assert model.proto.parse_text_format((OUT/'model.pbtxt').read_text()) and model.validate()==''
write(OUT/'mapping.json',{'base_mapping':mp,'mixed_separation':records})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(proto.variables),'constraints':len(proto.constraints),'added_boolean_facet_selectors':4608,'conditional_separation_clauses':384,'demonstrated_pairs':8,'advisory_hint_values':609,'fixed_original_variables':0,'all66_required':True,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
