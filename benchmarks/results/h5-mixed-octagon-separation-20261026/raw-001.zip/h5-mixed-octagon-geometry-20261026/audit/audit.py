"""Independent support/vertex certificate for exact source Minkowski polygons."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-octagon-geometry-20261026';OUT=BASE/'audit'
GEO=ROOT/'output/h5-allocation-geometry-20261026';OLD=ROOT/'output/h5-retained64-proxy-regions-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed']
v=load(GEO/'variants.json');octagon=load(BASE/'octagon.json');r=octagon['radius_um'];a=octagon['diagonal_um'];points=octagon['vertices_um']
assert r==v[-1]['source_disk_radius_um']==109113 and 2*a*a<=r*r<2*(a+1)*(a+1)
assert {tuple(p) for p in points}=={(r,0),(a,a),(0,r),(-a,a),(-r,0),(-a,-a),(0,-r),(a,-a)}
assert all(x*x+y*y<=r*r for x,y in points)
polygons=load(BASE/'forbidden-polygons.json');assert len(polygons)==24
assert {(p['variant'],p['component']) for p in polygons}=={(i,j) for i in range(8) for j in range(3)}
support_checks=0;facets=0
for p in polygons:
    b=v[p['variant']]['coarse_rectangles_um'][p['component']];assert p['rectangle_um']==b
    sums={(x-u,y-w) for x in [b[0],b[2]] for y in [b[1],b[3]] for u,w in points}
    ring=p['vertices_um'];faces=p['inward_faces'];assert len(ring)==len(faces)==12 and len({tuple(q) for q in ring})==12
    assert all(tuple(q) in sums for q in ring)
    for k,(q,z) in enumerate(zip(ring,ring[1:]+ring[:1])):
        dx,dy=z[0]-q[0],z[1]-q[1];g=math.gcd(abs(dx),abs(dy));nx,ny=-dy//g,dx//g;rhs=nx*q[0]+ny*q[1]
        assert faces[k]==[nx,ny,rhs]
        assert all(nx*x+ny*y>=rhs for x,y in sums)
        assert all(nx*x+ny*y>rhs for j,(x,y) in enumerate(ring) if j not in [k,(k+1)%len(ring)])
        support_checks+=len(sums);facets+=1
lookup={(p['variant'],p['component']):p for p in polygons};poses={p['original_index']:p for p in load(OLD/'construction/canonical-necessary-poses.json')}
ids={(p['family'],p['copy_index']):p['index'] for p in load(GEO/'originals.json')};expected=set()
for fail in load(OLD/'completion-source-audit/added-bracket-source-failures.json'):
    keys={k[0]:k for k in fail['keys']};expected.add((ids[tuple(keys['bracket'])],ids[tuple(keys['cog'])]))
pairs=load(BASE/'demonstrated-pairs.json');assert len(pairs)==8 and {(p['bracket_original_index'],p['cog_original_index']) for p in pairs}==expected
for p in pairs:
    br,cog=poses[p['bracket_original_index']],poses[p['cog_original_index']];delta=[cog['anchor_um'][k]-br['anchor_um'][k] for k in [0,1]]
    assert p['known_variant']==br['variant'] and p['known_relative_anchor_um']==delta
    violated=[k for k in range(3) if all(nx*delta[0]+ny*delta[1]>rhs for nx,ny,rhs in lookup[br['variant'],k]['inward_faces'])]
    assert p['violated_components']==violated and violated
fixed={p['original_index']:p for p in load(OLD/'fixed64.json')};cells={(p['variant'],i):b for p in load(OLD/'bracket-regions.json') for i,b in enumerate(p['coarse_free_cells'])}
coverage=load(BASE/'fixed-cell-coverage.json');assert len(coverage)==26 and {(p['variant'],p['cell_index']) for p in coverage}==set(cells)
corner_facets=0
for p in coverage:
    cell=cells[p['variant'],p['cell_index']];cog=fixed[p['cog_original_index']];assert cog['family']=='cog' and cog['sheet']==0
    margins=[]
    for x in [cell[0],cell[2]]:
        for y in [cell[1],cell[3]]:
            dx,dy=cog['anchor_um'][0]-x,cog['anchor_um'][1]-y
            margins.append([nx*dx+ny*dy-rhs for nx,ny,rhs in lookup[p['variant'],p['component']]['inward_faces']]);corner_facets+=12
    assert p['corner_facet_margins']==margins and p['minimum_integer_facet_margin']==min(min(row) for row in margins)>0
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'exact_source_octagon_vertices_verified':8,
    'convex_minkowski_polygons_verified':24,'integer_facets_verified':facets,'pair_sum_support_checks':support_checks,
    'all8_actual_collision_pairs_rejected_by_necessary_geometry':True,'fixed_anchor_cells_covered':26,
    'exact_corner_facet_checks':corner_facets,'all_real_cog_rotations_retained':True,
    'boundary_contact_allowed_as_necessary_relaxation':True,'full_source_readback_still_required':True,
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
