"""Exact source-contained octagon/rectangle separation for demonstrated mixed collisions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-mixed-octagon-geometry-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';OLD=ROOT/'output/h5-retained64-proxy-regions-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    ps=sorted(set(points));lower=[];upper=[]
    for p in ps:
        while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    for p in ps[::-1]:
        while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[GEO/n for n in ['variants.json','originals.json','audit/checks.json']]+[OLD/n for n in ['fixed64.json','bracket-regions.json',
    'construction/canonical-necessary-poses.json','completion-source-audit/added-bracket-source-failures.json',
    'completion-model-audit/checks.json','disk-exclusion/audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'solver_calls':0,'method':'Use the audited all-angle quantization-safe cog disk of radius109113um. Inscribe an exact integer centered octagon with cardinal reachr and diagonal reachfloor(sqrt(r*r/2)). Build the convex Minkowski sum of each of24 source-contained bracket rectangles and this centrally symmetric octagon; store integer inward facet inequalities. Strict interior overlap is forbidden; non-overlap is represented by at least one facet having nx*(cogX-bracketX)+ny*(cogY-bracketY)<=rhs. Retain boundary contacts as a necessary relaxation. Identify all8 demonstrated canonical bracket/cog collisions and verify the old assignment violates these necessities. Check all26 fixed-position bracket anchor cells are also covered by this compact geometry. Future constraints must be conditional on the selected bracket variant and both originals sharing a sheet, with all original positions/options free. No solver is opened here.'})
variants=load(GEO/'variants.json');originals=load(GEO/'originals.json');r=variants[-1]['source_disk_radius_um'];a=math.isqrt(r*r//2)
octagon=hull([(r,0),(a,a),(0,r),(-a,a),(-r,0),(-a,-a),(0,-r),(a,-a)])
assert len(octagon)==8 and all(x*x+y*y<=r*r for x,y in octagon)
polygons=[]
for v in variants:
    if v['family']!='bracket':continue
    for component,b in enumerate(v['coarse_rectangles_um']):
        rect=[(x,y) for x in [b[0],b[2]] for y in [b[1],b[3]]]
        polygon=hull([(x-u,y-w) for x,y in rect for u,w in octagon]);faces=[]
        for p,q in zip(polygon,polygon[1:]+polygon[:1]):
            nx,ny=-(q[1]-p[1]),q[0]-p[0];rhs=nx*p[0]+ny*p[1];g=math.gcd(abs(nx),abs(ny));assert rhs%g==0
            faces.append([nx//g,ny//g,rhs//g])
        polygons.append({'variant':v['id'],'component':component,'rectangle_um':b,'vertices_um':polygon,'inward_faces':faces})
lookup={(p['variant'],p['component']):p for p in polygons};ids={(p['family'],p['copy_index']):p['index'] for p in originals}
poses={p['original_index']:p for p in load(OLD/'construction/canonical-necessary-poses.json')};pairs=[]
for fail in load(OLD/'completion-source-audit/added-bracket-source-failures.json'):
    keys={k[0]:k for k in fail['keys']};assert set(keys)=={'bracket','cog'}
    bi,ci=ids[tuple(keys['bracket'])],ids[tuple(keys['cog'])];br,cog=poses[bi],poses[ci]
    delta=[cog['anchor_um'][k]-br['anchor_um'][k] for k in [0,1]]
    violated=[component for component in range(3) if all(nx*delta[0]+ny*delta[1]>rhs for nx,ny,rhs in lookup[br['variant'],component]['inward_faces'])]
    assert violated
    pairs.append({'bracket_original_index':bi,'cog_original_index':ci,'keys':[keys['bracket'],keys['cog']],
                  'known_variant':br['variant'],'known_relative_anchor_um':delta,'violated_components':violated})
assert len(pairs)==8 and len({(p['bracket_original_index'],p['cog_original_index']) for p in pairs})==8
fixed=load(OLD/'fixed64.json');coverage=[]
for result in load(OLD/'bracket-regions.json'):
    for cell_index,cell in enumerate(result['coarse_free_cells']):
        candidates=[]
        for cog in fixed:
            if cog['family']!='cog' or cog['sheet']!=0:continue
            for component in range(3):
                faces=lookup[result['variant'],component]['inward_faces'];corners=[]
                for x in [cell[0],cell[2]]:
                    for y in [cell[1],cell[3]]:
                        delta=[cog['anchor_um'][0]-x,cog['anchor_um'][1]-y]
                        corners.append([nx*delta[0]+ny*delta[1]-rhs for nx,ny,rhs in faces])
                margin=min(min(row) for row in corners)
                if margin>0:candidates.append({'variant':result['variant'],'cell_index':cell_index,'cog_original_index':cog['original_index'],
                    'component':component,'corner_facet_margins':corners,'minimum_integer_facet_margin':margin})
        assert candidates,(result['variant'],cell_index)
        coverage.append(max(candidates,key=lambda p:p['minimum_integer_facet_margin']))
write(OUT/'octagon.json',{'radius_um':r,'diagonal_um':a,'vertices_um':octagon})
write(OUT/'forbidden-polygons.json',polygons);write(OUT/'demonstrated-pairs.json',pairs);write(OUT/'fixed-cell-coverage.json',coverage)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_octagon_vertices':8,'forbidden_convex_polygons':len(polygons),
    'integer_facets':sum(len(p['inward_faces']) for p in polygons),'demonstrated_pairs':len(pairs),
    'fixed_anchor_cells_covered':len(coverage),'all_real_cog_angles':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
