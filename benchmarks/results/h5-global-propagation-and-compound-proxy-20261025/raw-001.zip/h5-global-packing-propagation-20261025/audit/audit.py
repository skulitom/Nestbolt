"""Independent original area, subset and full coverage checks for propagation."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-packing-propagation-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');g=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');old=ROOT/'output/h5-global-disk-relaxation-prepared-20261025';manifest=ROOT/'benchmarks/results/h5-guarded-core-and-global-relaxation-20261025/raw-manifest.json';mf=load(manifest);files=mf['files']+mf['aliases'];provenance=[]
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    for p in [old/'plan.json',old/'geometry.json',old/'audit/checks.json',old/'solve/model-audit.json',old/'solve/result.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-coordinated-placement-selection-20261018/conditional-target.json',ROOT/'output/h5-cog-center-capacity-20261020/disk.json']:
        matches=[r for r in files if r['sha256']==digest(p)];assert matches;provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':matches[0]['path']})
    assert digest(BASE/'geometry.json')==digest(old/'geometry.json');assert load(old/'audit/checks.json')['passed'];assert load(old/'solve/result.json')['status']=='UNKNOWN';job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');target=load(ROOT/'output/h5-coordinated-placement-selection-20261018/conditional-target.json');parts={p['id']:p for p in job['parts']};assert plan['required_counts']=={p['id']:p['quantity'] for p in job['parts']};assert aux['area_units_per_mm2']==1000
    total=F(0);lower=0
    for p in job['parts']:
        assert len(p['geometry'])==1;vs=[[F(x),F(y)] for x,y in p['geometry'][0]['outer']];base=vs[0];a=abs(sum((vs[i][0]-base[0])*(vs[i+1][1]-base[1])-(vs[i][1]-base[1])*(vs[i+1][0]-base[0]) for i in range(1,len(vs)-1)))/2;r=aux['part_areas'][p['id']];assert F(*r['exact_filled_outer_mm2'])==a;assert F(r['lower_units'])<=a*1000<F(r['lower_units']+1);total+=a*p['quantity'];lower+=r['lower_units']*p['quantity']
    stock=job['stocks'][0];m=stock['margins'];e=F(job['edge_clearance']);w=F(stock['width'])-F(m['left'])-F(m['right'])-2*e;bounds=[]
    for si,height in enumerate([stock['height'],target['required_used_height_mm']]):
        h=F(height)-F(m['bottom'])-F(m['top'])-2*e;a=w*h;c=aux['sheet_capacities'][si];assert F(*c['exact_usable_area_mm2'])==a;assert c['upper_area_units']-1<a*1000<=c['upper_area_units'];assert c['width_upper_coordinate_units']-1<w*100<=c['width_upper_coordinate_units'];assert c['height_upper_coordinate_units']-1<h*100<=c['height_upper_coordinate_units'];bounds.append([F(m['left'])+e,F(m['bottom'])+e,F(stock['width'])-F(m['right'])-e,F(height)-F(m['top'])-e])
    assert bounds==[[F(*v) for v in b] for b in g['stock_bounds_rational']]
    components=corner_checks=0
    for c,r in zip(g['classes'],aux['inner_non_cog_components']):
        assert r['class']==c['index'] and len(r['components'])==len(c['components'])
        for actual,inner in zip(c['components'],r['components']):
            assert inner==[int(actual[0])*100+1,int(actual[1])*100+1,int(actual[2])*100-1,int(actual[3])*100-1] and inner[0]<inner[2] and inner[1]<inner[3];components+=1
            # Consider the full closed error square [0,1]^2; this contains every floor error.
            for dx,dy in [(0,0),(1,0),(1,1),(0,1)]:
                assert actual[0]*100<=inner[0]-dx<=inner[2]-dx<=actual[2]*100;assert actual[1]*100<=inner[1]-dy<=inner[3]-dy<=actual[3]*100;corner_checks+=1
        if c['family']=='bracket':
            a,b=r['components'];assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
    disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');radius=F(disk['radius_units'],100);assert radius==F(*aux['cog_radius_coordinate_units_rational']);half=aux['cog_inner_square_half_coordinate_units'];assert aux['cog_inner_square_offsets']==[-half,-half,half,half] and half>0;maxdist=0
    for x,y in [(-half,-half),(half,-half),(half,half),(-half,half)]:
        for dx,dy in [(0,0),(1,0),(1,1),(0,1)]:
            d=(x-dx)**2+(y-dy)**2;assert d<radius*radius;maxdist=max(maxdist,d)
    assert aux['global_no_overlap_2d_constraints']==2 and aux['orthogonal_cumulative_constraints']==4 and aux['part_area_constraints']==2;assert 18+12*2+21+15==78
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'committed_source_matches':len(provenance),'original_continuous_outer_geometry_unchanged':True,'original_filled_part_areas_independently_recomputed':4,'exact_total_filled_area_mm2':float(total),'total_lower_area_units':lower,'sheet_upper_area_units':[c['upper_area_units'] for c in aux['sheet_capacities']],'orientation_component_subset_certificates':components,'non_cog_floor_error_corner_checks':corner_checks,'cog_floor_error_corner_checks':16,'cog_maximum_corner_radius_squared_units':maxdist,'inner_rectangles_per_layout':78,'floor_grid_auxiliary_shapes_inside_original_parts':True,'same_part_arms_independently_disjoint':True,'global_profile_capacities_outward':True,'all66_parts_remain_movable':True,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
