"""Prepare certified necessary sheet capacity and inner-rectangle propagation."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from math import floor,ceil,isqrt
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-global-disk-relaxation-prepared-20261025';OUT=ROOT/'output/h5-global-packing-propagation-20261025';SRC=ROOT/'output/h5-coordinated-placement-selection-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');plan=load(OLD/'plan.json');inputs=[OLD/'plan.json',OLD/'geometry.json',OLD/'audit/checks.json',OLD/'solve/model-audit.json',OLD/'solve/result.json',SRC/'job.json',SRC/'conditional-target.json',ROOT/'output/h5-cog-center-capacity-20261020/disk.json',ROOT/'benchmarks/results/h5-guarded-core-and-global-relaxation-20261025/raw-manifest.json',ROOT/'benchmarks/results/h5-guarded-core-and-global-relaxation-20261025/next-step.json'];plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'model_construction_limit_seconds':120,'independent_model_audit_limit_seconds':120,'maximum_solver_calls':1,'method':plan['method']+' Add original filled-area lower bounds against outward sheet-area capacities. Add shrunken inner rectangle components and rotation-invariant cog squares to per-sheet NoOverlap2D and both orthogonal cumulative profiles. These are independently certified necessary conditions of original placements, not assumptions that the cog outer shapes equal their inscribed proxies.','scope':'A strengthened necessary relaxation, not an unchanged retry: all66 parts remain movable; same material cap, exact counts, original non-cog orientations and arbitrary cog angles. One new60-second call only after complete geometric and model audits. No objective, hint, reduced inventory or production acceptance.'});write(OUT/'plan.json',plan)
    start=time.perf_counter();shutil.copyfile(OLD/'geometry.json',OUT/'geometry.json');g=load(OUT/'geometry.json');job=load(SRC/'job.json');disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');areas={}
    for p in job['parts']:
        assert len(p['geometry'])==1;vs=[[F(x),F(y)] for x,y in p['geometry'][0]['outer']];a=abs(sum(x*v-y*u for (x,y),(u,v) in zip(vs,vs[1:]+vs[:1])))/2;areas[p['id']]={'exact_filled_outer_mm2':[a.numerator,a.denominator],'lower_units':floor(a*1000)}
    bounds=[[F(*v) for v in b] for b in g['stock_bounds_rational']];capacities=[]
    for b in bounds:
        w,h=b[2]-b[0],b[3]-b[1];a=w*h;capacities.append({'exact_usable_area_mm2':[a.numerator,a.denominator],'upper_area_units':ceil(a*1000),'width_upper_coordinate_units':ceil(w*100),'height_upper_coordinate_units':ceil(h*100)})
    r=F(disk['radius_units'],100);half=isqrt((r*r/2).numerator//(r*r/2).denominator)-1;assert 2*(half+1)**2<r*r
    inner=[]
    for c in g['classes']:
        inner.append({'class':c['index'],'components':[[int(a)*100+1,int(b)*100+1,int(d)*100-1,int(e)*100-1] for a,b,d,e in c['components']]})
    aux={'area_units_per_mm2':1000,'part_areas':areas,'sheet_capacities':capacities,'inner_non_cog_components':inner,'cog_inner_square_half_coordinate_units':half,'cog_inner_square_offsets':[-half,-half,half,half],'cog_radius_coordinate_units_rational':[r.numerator,r.denominator],'floor_anchor_error_coordinate_units':[0,1],'same_part_bracket_arms_disjoint':True,'global_no_overlap_2d_constraints':2,'orthogonal_cumulative_constraints':4,'part_area_constraints':2};write(OUT/'propagation.json',aux);elapsed=time.perf_counter()-start;assert elapsed<120;write(OUT/'generation.json',{'seconds':elapsed,'original_geometry_copied_without_changes':True,'full_original_area_lower_units':sum(areas[p['id']]['lower_units']*p['quantity'] for p in job['parts']),'cog_half_square_units':half,'physical_parts':66,'inner_rectangles':78,'solver_calls':0,'H5_complete':False});print(load(OUT/'generation.json'),flush=True)
if __name__=='__main__':main()
