"""Apply every new global condition to the preserved original partial witness."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from collections import Counter,defaultdict
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compound-cog-proxy-20261025';OLD=ROOT/'output/h5-global-disk-relaxation-prepared-20261025';OUT=BASE/'baseline-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();source=OLD/'baseline-audit/positions.json';manifest=ROOT/'benchmarks/results/h5-guarded-core-and-global-relaxation-20261025/raw-manifest.json';mf=load(manifest);matches=[r for r in mf['files']+mf['aliases'] if r['sha256']==digest(source)];assert matches;assert load(OLD/'baseline-audit/checks.json')['passed'];aux=load(BASE/'propagation.json');poses=load(source);rects=[];sheetareas=[0,0]
    inputs=[source,manifest,OLD/'baseline-audit/checks.json',BASE/'geometry.json',BASE/'propagation.json',BASE/'audit/checks.json'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'baseline_member':matches[0]['path'],'scope':'Partial64 original parts only, missing two brackets. These positions are not supplied as a hint and do not satisfy the66-part requirement.'})
    for i,p in enumerate(poses):
        offsets=aux['cog_inner_components'] if p['family']=='cog' else aux['inner_non_cog_components'][p['class']]['components'];sheetareas[p['sheet']]+=aux['part_areas'][p['family']]['lower_units']
        for j,(x0,y0,x1,y1) in enumerate(offsets):
            r=[p['x']+x0,p['y']+y0,p['x']+x1,p['y']+y1];assert 0<=r[0]<r[2]<=150000 and 0<=r[1]<r[3]<=300000;rects.append({'part':i,'arm':j,'sheet':p['sheet'],'rectangle':r})
    pairs=own=0
    for a,b in combinations(rects,2):
        if a['sheet']!=b['sheet']:continue
        x,y=a['rectangle'],b['rectangle'];assert x[2]<=y[0] or y[2]<=x[0] or x[3]<=y[1] or y[3]<=x[1];pairs+=1;own+=a['part']==b['part']
    profiles=[]
    for sheet in [0,1]:
        assert sheetareas[sheet]<=aux['sheet_capacities'][sheet]['upper_area_units']
        for axis in [0,1]:
            events=defaultdict(int)
            for row in rects:
                if row['sheet']!=sheet:continue
                r=row['rectangle'];d=r[3-axis]-r[1-axis];events[r[axis]]+=d;events[r[axis+2]]-=d
            active=peak=0
            for x in sorted(events):active+=events[x];peak=max(peak,active);assert active>=0
            assert active==0;capacity=aux['sheet_capacities'][sheet]['height_upper_coordinate_units' if axis==0 else 'width_upper_coordinate_units'];assert peak<=capacity;profiles.append({'sheet':sheet,'time_axis':'x' if axis==0 else 'y','maximum_demand_units':peak,'capacity_units':capacity,'event_coordinates':len(events)})
    assert len(rects)==134 and Counter(p['family'] for p in poses)=={'frame':18,'bracket':10,'insert':21,'cog':15};write(OUT/'rectangles.json',rects);write(OUT/'profiles.json',profiles);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_partial_parts':64,'missing_brackets':2,'inner_rectangles':len(rects),'same_sheet_inner_rectangle_pairs':pairs,'same_part_bracket_pairs':own,'original_partial_area_units_by_sheet':sheetareas,'complete_sweep_profiles_checked':4,'positions_used_as_hint':False,'full_model_solution':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
