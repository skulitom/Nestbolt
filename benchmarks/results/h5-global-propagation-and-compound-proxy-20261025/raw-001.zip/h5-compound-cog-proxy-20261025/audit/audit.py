"""Independent complete error-square containment and component disjointness."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-global-packing-propagation-20261025';BASE=ROOT/'output/h5-compound-cog-proxy-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');aux=load(BASE/'propagation.json');oldaux=load(OLD/'propagation.json')
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    assert digest(BASE/'geometry.json')==digest(OLD/'geometry.json');assert load(OLD/'audit/checks.json')['passed'];assert load(OLD/'solve/result.json')['status']=='UNKNOWN';assert {k:v for k,v in aux.items() if k not in ['cog_inner_components','inner_rectangles_per_layout']}==oldaux;assert plan['required_counts']=={'frame':18,'bracket':12,'insert':21,'cog':15}
    rs=aux['cog_inner_components'];assert len(rs)==5;radius=F(*aux['cog_radius_coordinate_units_rational']);checks=0;maxr=0;area=0
    for x0,y0,x1,y1 in rs:
        assert all(isinstance(v,int) for v in [x0,y0,x1,y1]) and x0<x1 and y0<y1;area+=(x1-x0)*(y1-y0)
        for x,y in product([x0,x1],[y0,y1]):
            for dx,dy in product([0,1],[0,1]):
                d=(x-dx)**2+(y-dy)**2;assert d<radius*radius;checks+=1;maxr=max(maxr,d)
    pairs=0
    for a,b in combinations(rs,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    assert aux['inner_rectangles_per_layout']==18+24+21+15*5==138;assert area>4*aux['cog_inner_square_half_coordinate_units']**2
    write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'inherited_original_area_and_non_cog_subset_audit':digest(OLD/'audit/checks.json'),'unchanged_continuous_source_geometry':True,'five_components_coupled_to_each_cog_center':True,'exact_error_square_corner_checks':checks,'own_cog_component_disjoint_pairs':pairs,'maximum_corner_radius_squared_units':maxr,'certified_proxy_area_per_cog_mm2':area/10000,'all66_parts_movable':True,'all_original_orientations_and_material_domains_preserved':True,'pairwise_polygon_disjunctions_deliberately_omitted':True,'positive_result_only_proxy_geometry':True,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
