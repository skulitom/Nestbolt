"""One bounded all-parts-movable outer model, with full protobuf audit first."""
from pathlib import Path
from collections import Counter
from itertools import combinations,product
from hashlib import sha256
from datetime import datetime,timezone
import gc,json,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from h5_global_propagation_encoding import build as build_propagation, verify as verify_propagation
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-packing-propagation-20261025';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');geo=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');plan=load(BASE/'plan.json');parameters=plan['solver_parameters'];required=plan['required_counts'];classes=geo['classes'];modes=geo['modes'];mx,my=geo['coordinate_maxima'];stride=(mx+1)*(my+1);loint,hiint=cp_model.INT_MIN,cp_model.INT_MAX
    inputs=[BASE/'plan.json',BASE/'geometry.json',BASE/'propagation.json',BASE/'audit/checks.json',BASE/'solver-template-provenance.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'parameters':parameters,'maximum_solver_calls':1,'required_counts':required,'fixed_parts':0,'hint':None,'objective':None,'quantities':'All66 mandatory; no unplaced variables','interpretation':'The inherited all-movable cog-polygon model is strengthened by original-area sheet bounds and independently certified inner-rectangle global propagation. It remains a necessary relaxation without actual cog angles or accepted geometry. No native or H5 qualification.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[];items=[];pairs=[]
    def var(lo,hi,n):
        v=model.new_int_var(lo,hi,n);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*v for i,v in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] if i>=0 else vs[-i-1].Not() for i in en])
    for family in ['frame','bracket','insert','cog']:
        for copy in range(required[family]):
            prefix=f'{family}-{copy}';x=var(0,mx,prefix+'-x');y=var(0,my,prefix+'-y');sheet=var(0,1,prefix+'-sheet');key=var(0,2*stride-1,prefix+'-key');qs=([{'index':i,'sheet':i,'coordinate_bounds':b} for i,b in enumerate(geo['cog_center_bounds'])] if family=='cog' else [m for m in modes if m['family']==family]);active={q['index']:var(0,1,prefix+f"-mode{q['index']}") for q in qs};components=[]
            for arm in range(0 if family=='cog' else 2 if family=='bracket' else 1):
                coords=[]
                for axis in range(4):
                    values=[classes[q['class']]['components'][arm][axis]*100 for q in qs];coords.append(var(min(values),max(values),prefix+f'-arm{arm}-offset{axis}'))
                components.append(coords)
            model.add_exactly_one([vs[v] for v in active.values()])
            for q in qs:
                a,b,c,d=q['coordinate_bounds'];linear([(x,1)],a,c,[active[q['index']]]);linear([(y,1)],b,d,[active[q['index']]])
            linear([(sheet,1)]+[(active[q['index']],-q['sheet']) for q in qs],0,0)
            for arm,coords in enumerate(components):
                for axis,v in enumerate(coords):linear([(v,1)]+[(active[q['index']],-classes[q['class']]['components'][arm][axis]*100) for q in qs],0,0)
            linear([(key,1),(sheet,-stride),(y,-(mx+1)),(x,-1)],0,0);items.append({'index':len(items),'family':family,'copy':copy,'x':x,'y':y,'sheet':sheet,'key':key,'modes':active,'components':components})
    for family in required:
        rows=[r for r in items if r['family']==family]
        for a,b in zip(rows,rows[1:]):linear([(a['key'],1),(b['key'],-1)],loint,0)
    for a,b in combinations(items,2):
        name=f"pair-{a['index']}-{b['index']}";same=var(0,1,name+'-same');linear([(a['sheet'],1),(b['sheet'],-1)],0,0,[same]);model.add(vs[a['sheet']]!=vs[b['sheet']]).only_enforce_if(vs[same].Not());blocks=[]
        if b['family']!='cog':
            for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
                aa,bb=a['components'][ai],b['components'][bi];dirs=[var(0,1,name+f'-rect{ai}-{bi}-dir{j}') for j in range(4)];terms=[[(a['x'],1),(aa[2],1),(b['x'],-1),(bb[0],-1)],[(b['x'],1),(bb[2],1),(a['x'],-1),(aa[0],-1)],[(a['y'],1),(aa[3],1),(b['y'],-1),(bb[1],-1)],[(b['y'],1),(bb[3],1),(a['y'],-1),(aa[1],-1)]]
                for d,t in zip(dirs,terms):linear(t,loint,1,[same,d])
                model.add_bool_or([vs[same].Not()]+[vs[d] for d in dirs]);blocks.append({'kind':'rect-rect','a':ai,'b':bi,'directions':dirs})
        elif a['family']!='cog':
            qs=[m for m in modes if m['family']==a['family']]
            for arm in range(len(a['components'])):
                dirs=[var(0,1,name+f'-disk-rect{arm}-dir{j}') for j in range(len(geo['normals']))]
                for j,((nx,ny),d) in enumerate(zip(geo['normals'],dirs)):
                    terms=[(b['x'],nx),(b['y'],ny),(a['x'],-nx),(a['y'],-ny)]+[(a['modes'][q['index']],-classes[q['class']]['cog_rect_separation_lower_units'][arm][j]) for q in qs];linear(terms,0,hiint,[same,d])
                model.add_bool_or([vs[same].Not()]+[vs[d] for d in dirs]);blocks.append({'kind':'disk-rect','a':arm,'directions':dirs})
        else:
            dirs=[var(0,1,name+f'-disks-dir{j}') for j in range(len(geo['cog_pair_separation']))]
            for r,d in zip(geo['cog_pair_separation'],dirs):linear([(b['x'],r['a']),(b['y'],r['b']),(a['x'],-r['a']),(a['y'],-r['b'])],r['lower'],hiint,[same,d])
            model.add_bool_or([vs[same].Not()]+[vs[d] for d in dirs]);blocks.append({'kind':'disk-disk','directions':dirs})
        pairs.append({'a':a['index'],'b':b['index'],'same':same,'blocks':blocks})
    propagation=build_propagation(model,vs,items,geo,aux,var,linear);write(OUT/'propagation-mapping.json',propagation)
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',{'items':items,'pairs':pairs,'stride':stride});build_seconds=time.perf_counter()-start;assert build_seconds<plan['model_construction_limit_seconds'];print({'construction_seconds':build_seconds,'variables':len(vs),'physical_parts':len(items)},flush=True)
    # Read serialized protobuf independently. Reconstruct all fields from audited geometry.
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());vi=ci=0;oracle=[];oraclepairs=[]
    def vcheck(name,lo,hi):
        nonlocal vi
        expected=cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);assert actual.variables[vi]==expected,(vi,name);vi+=1;return vi-1
    def lcheck(terms,lo,hi,en=()):
        nonlocal ci
        merged=Counter()
        for idx,coef in terms:merged[idx]+=coef
        ids=sorted(i for i,c in merged.items() if c);expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.extend(en);expected.linear.vars.extend(ids);expected.linear.coeffs.extend(merged[i] for i in ids);expected.linear.domain.extend([lo,hi]);assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1
    def bcheck(kind,ids):
        nonlocal ci
        expected=cp_model_pb2.ConstraintProto();getattr(expected,kind).literals.extend(ids);assert actual.constraints[ci]==expected,(ci,kind);ci+=1
    for family,count in [('frame',18),('bracket',12),('insert',21),('cog',15)]:
        for copy in range(count):
            name=f'{family}-{copy}';x=vcheck(name+'-x',0,150000);y=vcheck(name+'-y',0,300000);s=vcheck(name+'-sheet',0,1);key=vcheck(name+'-key',0,2*stride-1);qs=([{'index':i,'sheet':i,'coordinate_bounds':geo['cog_center_bounds'][i]} for i in [0,1]] if family=='cog' else [q for q in geo['modes'] if q['family']==family]);active={q['index']:vcheck(name+f"-mode{q['index']}",0,1) for q in qs};comps=[]
            for arm in range({'frame':1,'bracket':2,'insert':1,'cog':0}[family]):
                ids=[]
                for axis in range(4):
                    vals=[int(geo['classes'][q['class']]['components'][arm][axis])*100 for q in qs];ids.append(vcheck(name+f'-arm{arm}-offset{axis}',min(vals),max(vals)))
                comps.append(ids)
            bcheck('exactly_one',list(active.values()))
            for q in qs:
                bound=q['coordinate_bounds'];lcheck([(x,1)],bound[0],bound[2],[active[q['index']]]);lcheck([(y,1)],bound[1],bound[3],[active[q['index']]])
            lcheck([(s,1)]+[(active[q['index']],-1) for q in qs if q['sheet']==1],0,0)
            for arm,comp in enumerate(comps):
                for axis,v in enumerate(comp):lcheck([(v,1)]+[(active[q['index']],-int(geo['classes'][q['class']]['components'][arm][axis])*100) for q in qs],0,0)
            lcheck([(key,1),(s,-stride),(y,-150001),(x,-1)],0,0);oracle.append({'index':len(oracle),'family':family,'copy':copy,'x':x,'y':y,'sheet':s,'key':key,'modes':active,'components':comps})
    for family in required:
        rows=[r for r in oracle if r['family']==family]
        for a,b in zip(rows,rows[1:]):lcheck([(a['key'],1),(b['key'],-1)],-2**63,0)
    for a,b in combinations(oracle,2):
        name=f"pair-{a['index']}-{b['index']}";same=vcheck(name+'-same',0,1);lcheck([(a['sheet'],1),(b['sheet'],-1)],0,0,[same]);expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.append(-same-1);expected.linear.vars.extend([a['sheet'],b['sheet']]);expected.linear.coeffs.extend([1,-1]);expected.linear.domain.extend([-2**63,-1,1,2**63-1]);assert actual.constraints[ci]==expected;ci+=1;blocks=[]
        if b['family']!='cog':
            for ai,aa in enumerate(a['components']):
                for bi,bb in enumerate(b['components']):
                    dirs=[vcheck(name+f'-rect{ai}-{bi}-dir{j}',0,1) for j in range(4)]
                    for j,(left,right,lp,rp,end,st) in enumerate([(a,b,aa,bb,2,0),(b,a,bb,aa,2,0),(a,b,aa,bb,3,1),(b,a,bb,aa,3,1)]):
                        axis='x' if j<2 else 'y';lcheck([(left[axis],1),(lp[end],1),(right[axis],-1),(rp[st],-1)],-2**63,1,[same,dirs[j]])
                    bcheck('bool_or',[-same-1]+dirs);blocks.append({'kind':'rect-rect','a':ai,'b':bi,'directions':dirs})
        elif a['family']!='cog':
            qs=[q for q in geo['modes'] if q['family']==a['family']]
            for arm in range(len(a['components'])):
                ds=[vcheck(name+f'-disk-rect{arm}-dir{j}',0,1) for j in range(20)]
                for j,(nx,ny) in enumerate(geo['normals']):
                    t=[(a['x'],-nx),(a['y'],-ny),(b['x'],nx),(b['y'],ny)]+[(a['modes'][q['index']],-geo['classes'][q['class']]['cog_rect_separation_lower_units'][arm][j]) for q in qs];lcheck(t,0,2**63-1,[same,ds[j]])
                bcheck('bool_or',[-same-1]+ds);blocks.append({'kind':'disk-rect','a':arm,'directions':ds})
        else:
            ds=[vcheck(name+f'-disks-dir{j}',0,1) for j in range(16)]
            for j,r in enumerate(geo['cog_pair_separation']):lcheck([(a['x'],-r['a']),(a['y'],-r['b']),(b['x'],r['a']),(b['y'],r['b'])],r['lower'],2**63-1,[same,ds[j]])
            bcheck('bool_or',[-same-1]+ds);blocks.append({'kind':'disk-disk','directions':ds})
        oraclepairs.append({'a':a['index'],'b':b['index'],'same':same,'blocks':blocks})
    assert oracle==items and oraclepairs==pairs
    def ccheck(expected):
        nonlocal ci
        assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1
    verified_propagation=verify_propagation(oracle,geo,aux,vcheck,lcheck,ccheck,lambda:ci);assert verified_propagation==propagation and len(propagation)==78
    assert vi==len(actual.variables)==len(vs) and ci==len(actual.constraints);extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields();solver=cp_model.CpSolver()
    for n,v in parameters.items():setattr(solver.parameters,n,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**parameters);(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audit_seconds=time.perf_counter()-start;assert audit_seconds<plan['independent_model_audit_limit_seconds'];counts=Counter(block['kind'] for p in pairs for block in p['blocks']);assert counts=={'rect-rect':1941,'disk-rect':945,'disk-disk':105};write(OUT/'model-audit.json',{'passed':True,'construction_seconds':build_seconds,'audit_seconds':audit_seconds,'all_variables_constraints_and_parameters_independently_reconstructed':True,'variables':vi,'constraints':ci,'original_required_parts':len(items),'fixed_parts':0,'modes':sum(len(i['modes']) for i in items),'physical_part_pairs':len(pairs),'component_pairs_by_kind':dict(counts),'explicit_same_part_pair_disjunctions':0,'own_bracket_components_in_global_no_overlap':True,'inner_rectangles':78,'optional_intervals':312,'global_no_overlap_2d_constraints':2,'orthogonal_cumulative_constraints':4,'original_area_constraints':2,'copy_order_constraints':62,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    records=[]
    def positions(value):
        rows=[]
        for i in items:
            active=[q for q,v in i['modes'].items() if value(vs[v])];assert len(active)==1;rows.append({'family':i['family'],'copy':i['copy'],'x_units':value(vs[i['x']]),'y_units':value(vs[i['y']]),'sheet':value(vs[i['sheet']]),'mode':active[0]})
        assert Counter(r['family'] for r in rows)==Counter(required);return rows
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            rows=positions(self.value);record={'index':len(records),'seconds':self.wall_time,'relaxation_parts':len(rows)};write(OUT/f"incumbent-{len(records)}-positions.json",rows);records.append(record);print(record,flush=True)
    del actual,extra,oracle,oraclepairs;gc.collect();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush());start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
    if feasible:write(OUT/'relaxed-positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'has_full_relaxation_solution':feasible,'incumbents':records,'response_stats':solver.response_stats(),'all_parts_movable':True,'original_cog_shapes_and_angles_unresolved':True,'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False,'interpretation':'A positive solution is only an inscribed-polygon relaxation. UNKNOWN is unresolved and does not prove infeasibility. No original cutting layout or acceptance result is created.'};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
