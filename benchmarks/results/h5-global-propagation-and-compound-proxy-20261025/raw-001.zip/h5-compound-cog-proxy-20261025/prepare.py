"""Replace pairwise polygon disjunctions with disjoint, certified inner rectangles."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations,product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-global-packing-propagation-20261025';OUT=ROOT/'output/h5-compound-cog-proxy-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');plan=load(OLD/'plan.json');inputs=[OLD/n for n in ['plan.json','geometry.json','propagation.json','audit/checks.json','audit/provenance.json','solve/result.json','solve/model-audit.json']];plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Keep all original66 parts movable, original orientation/sheet modes, original filled-area bounds, per-sheet NoOverlap2D and orthogonal cumulative profiles. Each cog now uses five coupled disjoint axis rectangles strictly within its all-angle inscribed disk; all original non-cog components retain their floor-safe inner rectangles. Omit all pairwise polygon/rectangle separating disjunctions, replacing those collision constraints with global propagation only. No hints, missing-part variables, changed material cap or positive-clearance acceptance.','scope':'A different, weaker necessary relaxation intended to expose all-parts arrangements with a much smaller encoding. A positive outcome must be checked against the larger inscribed16-gons and original filled outlines; never count a proxy placement as an accepted layout. A negative needs full coverage/model proofs. One60-second call after audits, no repeat or extension.'});write(OUT/'plan.json',plan);start=time.perf_counter()
    for n in ['geometry.json']:shutil.copyfile(OLD/n,OUT/n)
    aux=load(OLD/'propagation.json');g=load(OUT/'geometry.json');h=aux['cog_inner_square_half_coordinate_units'];vertex=g['polygon_units'][1];wide=vertex[0]//100-1;narrow=vertex[1]//100-1;assert 0<narrow<h<wide
    pieces=[[-h,-h,h,h],[-wide,-narrow,-h,narrow],[h,-narrow,wide,narrow],[-narrow,-wide,narrow,-h],[-narrow,h,narrow,wide]];aux['cog_inner_components']=pieces;aux['inner_rectangles_per_layout']=138;write(OUT/'propagation.json',aux);elapsed=time.perf_counter()-start;assert elapsed<120;write(OUT/'generation.json',{'seconds':elapsed,'cog_components':pieces,'parts':66,'fixed_parts':0,'inner_rectangles':138,'source_geometry_unchanged':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'generation.json'),flush=True)
if __name__=='__main__':main()
