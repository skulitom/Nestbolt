"""Build and independently verify necessary global packing propagation."""
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model

def build(model,vs,items,geo,aux,var,linear):
    total=sum(aux['part_areas'][i['family']]['lower_units'] for i in items);terms=[(i['sheet'],aux['part_areas'][i['family']]['lower_units']) for i in items]
    linear(terms,total-aux['sheet_capacities'][0]['upper_area_units'],cp_model.INT_MAX)
    linear(terms,cp_model.INT_MIN,aux['sheet_capacities'][1]['upper_area_units'])
    records=[];sheets=[{'x':[],'y':[],'width':[],'height':[]} for _ in range(2)]
    for item in items:
        for arm in range(5 if item['family']=='cog' else len(item['components'])):
            name=f"prop-{item['index']}-arm{arm}";sx=var(0,150000,name+'-sx');sy=var(0,300000,name+'-sy');ex=var(0,150000,name+'-ex');ey=var(0,300000,name+'-ey')
            if item['family']=='cog':
                rect=aux['cog_inner_components'][arm];widths=[rect[2]-rect[0]];heights=[rect[3]-rect[1]]
            else:
                qs=[q for q in geo['modes'] if q['family']==item['family']];rs=[aux['inner_non_cog_components'][q['class']]['components'][arm] for q in qs];widths=[r[2]-r[0] for r in rs];heights=[r[3]-r[1] for r in rs]
            w=var(min(widths),max(widths),name+'-w');h=var(min(heights),max(heights),name+'-h')
            if item['family']=='cog':
                for v,anchor,offset in [(sx,item['x'],rect[0]),(sy,item['y'],rect[1]),(ex,item['x'],rect[2]),(ey,item['y'],rect[3])]:linear([(v,1),(anchor,-1)],offset,offset)
            else:
                offsets=item['components'][arm]
                for v,anchor,off,delta in [(sx,item['x'],offsets[0],1),(sy,item['y'],offsets[1],1),(ex,item['x'],offsets[2],-1),(ey,item['y'],offsets[3],-1)]:linear([(v,1),(anchor,-1),(off,-1)],delta,delta)
            linear([(w,1),(ex,-1),(sx,1)],0,0);linear([(h,1),(ey,-1),(sy,1)],0,0);intervals=[]
            for si in [0,1]:
                present=vs[item['sheet']] if si else vs[item['sheet']].Not();xi=model.new_optional_interval_var(vs[sx],vs[w],vs[ex],present,name+f'-sheet{si}-x');yi=model.new_optional_interval_var(vs[sy],vs[h],vs[ey],present,name+f'-sheet{si}-y');intervals.append([xi.index,yi.index]);sheets[si]['x'].append(xi);sheets[si]['y'].append(yi);sheets[si]['width'].append(vs[w]);sheets[si]['height'].append(vs[h])
            records.append({'item':item['index'],'component':arm,'sx':sx,'sy':sy,'ex':ex,'ey':ey,'width':w,'height':h,'intervals':intervals})
    for si,s in enumerate(sheets):
        model.add_no_overlap_2d(s['x'],s['y']);model.add_cumulative(s['x'],s['height'],aux['sheet_capacities'][si]['height_upper_coordinate_units']);model.add_cumulative(s['y'],s['width'],aux['sheet_capacities'][si]['width_upper_coordinate_units'])
    return records

def verify(items,geo,aux,vcheck,lcheck,ccheck,cursor):
    # Derive ranges from original geometry, not the generated variable mapping.
    terms=[(i['sheet'],aux['part_areas'][i['family']]['lower_units']) for i in items];total=sum(a for _,a in terms);lcheck(terms,total-aux['sheet_capacities'][0]['upper_area_units'],2**63-1);lcheck(terms,-2**63,aux['sheet_capacities'][1]['upper_area_units']);records=[];groups=[{'x':[],'y':[],'w':[],'h':[]} for _ in range(2)]
    def expr(target,vid):target.vars.append(vid);target.coeffs.append(1)
    for item in items:
        count={'frame':1,'bracket':2,'insert':1,'cog':5}[item['family']]
        for arm in range(count):
            name=f"prop-{item['index']}-arm{arm}";sx=vcheck(name+'-sx',0,150000);sy=vcheck(name+'-sy',0,300000);ex=vcheck(name+'-ex',0,150000);ey=vcheck(name+'-ey',0,300000)
            if item['family']=='cog':
                rect=aux['cog_inner_components'][arm];widths=[rect[2]-rect[0]];heights=[rect[3]-rect[1]]
            else:
                cs=[geo['classes'][m['class']]['components'][arm] for m in geo['modes'] if m['family']==item['family']];widths=[int(r[2]-r[0])*100-2 for r in cs];heights=[int(r[3]-r[1])*100-2 for r in cs]
            w=vcheck(name+'-w',min(widths),max(widths));h=vcheck(name+'-h',min(heights),max(heights))
            for k,(vid,anchor) in enumerate([(sx,item['x']),(sy,item['y']),(ex,item['x']),(ey,item['y'])]):
                if item['family']=='cog':rhs=rect[k];t=[(vid,1),(anchor,-1)]
                else:rhs=1 if k<2 else -1;t=[(vid,1),(anchor,-1),(item['components'][arm][k],-1)]
                lcheck(t,rhs,rhs)
            lcheck([(sx,1),(ex,-1),(w,1)],0,0);lcheck([(sy,1),(ey,-1),(h,1)],0,0);intervals=[]
            for si in [0,1]:
                ids=[]
                for axis,start,size,end in [('x',sx,w,ex),('y',sy,h,ey)]:
                    idx=cursor();expected=cp_model_pb2.ConstraintProto(name=name+f'-sheet{si}-{axis}');expected.enforcement_literal.append(item['sheet'] if si else -item['sheet']-1);expr(expected.interval.start,start);expr(expected.interval.size,size);expr(expected.interval.end,end);ccheck(expected);ids.append(idx);groups[si][axis].append(idx)
                groups[si]['w'].append(w);groups[si]['h'].append(h);intervals.append(ids)
            records.append({'item':item['index'],'component':arm,'sx':sx,'sy':sy,'ex':ex,'ey':ey,'width':w,'height':h,'intervals':intervals})
    for si,g in enumerate(groups):
        expected=cp_model_pb2.ConstraintProto();expected.no_overlap_2d.x_intervals.extend(g['x']);expected.no_overlap_2d.y_intervals.extend(g['y']);ccheck(expected)
        for axis,demand,capacity in [('x','h','height_upper_coordinate_units'),('y','w','width_upper_coordinate_units')]:
            expected=cp_model_pb2.ConstraintProto();expected.cumulative.intervals.extend(g[axis]);expected.cumulative.capacity.offset=aux['sheet_capacities'][si][capacity]
            for vid in g[demand]:expr(expected.cumulative.demands.add(),vid)
            ccheck(expected)
    return records
