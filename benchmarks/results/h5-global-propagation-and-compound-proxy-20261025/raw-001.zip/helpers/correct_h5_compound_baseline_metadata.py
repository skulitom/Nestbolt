"""Preserve and correct a label copied from the single-square baseline audit."""
from pathlib import Path
from itertools import combinations
from collections import Counter
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compound-cog-proxy-20261025/baseline-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
    path=BASE/'checks.json';old=load(path);shutil.copyfile(path,BASE/'checks-original.json');poses=load(ROOT/'output/h5-global-disk-relaxation-prepared-20261025/baseline-audit/positions.json');rects=load(BASE/'rectangles.json');counts=Counter()
    for a,b in combinations(rects,2):
        if a['sheet']==b['sheet'] and a['part']==b['part']:counts[poses[a['part']]['family']]+=1
    assert counts=={'bracket':10,'cog':150} and sum(counts.values())==old['same_part_bracket_pairs'];updated={**old,'same_part_bracket_pairs':counts['bracket'],'same_part_cog_pairs':counts['cog'],'same_part_inner_component_pairs':sum(counts.values())}
    with path.open('w',encoding='utf-8',newline='\n') as f:json.dump(updated,f,indent=2);f.write('\n')
    with (BASE/'metadata-correction.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'original_checks_sha256':digest(BASE/'checks-original.json'),'corrected_checks_sha256':digest(path),'reason':'The inherited single-square audit labelled all same-part pairs as bracket pairs. With five cog components it also checks150 cog pairs. Recount verifies10 bracket+150 cog=160. All geometric/profile checks and inputs remain unchanged; no search or audit phase rerun.','counts':dict(counts)},f,indent=2);f.write('\n')
if __name__=='__main__':main()
