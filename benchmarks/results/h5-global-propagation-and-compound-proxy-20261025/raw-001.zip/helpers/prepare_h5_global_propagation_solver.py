"""Record exact template changes before the strengthened model's sole search."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-packing-propagation-20261025';TEMPLATE=ROOT/'output/solve_h5_global_disks.py';TARGET=ROOT/'output/solve_h5_global_propagation.py'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
    text=TEMPLATE.read_text(encoding='utf-8');original=text;changes=[
        ("BASE=ROOT/'output/h5-global-disk-relaxation-prepared-20261025'","BASE=ROOT/'output/h5-global-packing-propagation-20261025'"),
        ('from ortools.sat.python import cp_model','from ortools.sat.python import cp_model\nfrom h5_global_propagation_encoding import build as build_propagation, verify as verify_propagation'),
        ("geo=load(BASE/'geometry.json');plan=load(BASE/'plan.json');", "geo=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');plan=load(BASE/'plan.json');"),
        ("inputs=[BASE/'plan.json',BASE/'geometry.json',BASE/'audit/checks.json']", "inputs=[BASE/'plan.json',BASE/'geometry.json',BASE/'propagation.json',BASE/'audit/checks.json',BASE/'solver-template-provenance.json']"),
        ("    assert model.validate()=='';assert model.export_to_file", "    propagation=build_propagation(model,vs,items,geo,aux,var,linear);write(OUT/'propagation-mapping.json',propagation)\n    assert model.validate()=='';assert model.export_to_file"),
        ("    assert oracle==items and oraclepairs==pairs and vi==len(actual.variables)==len(vs) and ci==len(actual.constraints);extra=", "    assert oracle==items and oraclepairs==pairs\n    def ccheck(expected):\n        nonlocal ci\n        assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1\n    verified_propagation=verify_propagation(oracle,geo,aux,vcheck,lcheck,ccheck,lambda:ci);assert verified_propagation==propagation and len(propagation)==78\n    assert vi==len(actual.variables)==len(vs) and ci==len(actual.constraints);extra="),
        ("'same_part_components_separated':0", "'explicit_same_part_pair_disjunctions':0,'own_bracket_components_in_global_no_overlap':True,'inner_rectangles':78,'optional_intervals':312,'global_no_overlap_2d_constraints':2,'orthogonal_cumulative_constraints':4,'original_area_constraints':2"),
        ("'interpretation':'Cogs are strictly inscribed polygons with free centers; no actual cog rotations are chosen. Results are only necessary-relaxation diagnostics. No native or H5 qualification.'", "'interpretation':'The inherited all-movable cog-polygon model is strengthened by original-area sheet bounds and independently certified inner-rectangle global propagation. It remains a necessary relaxation without actual cog angles or accepted geometry. No native or H5 qualification.'")
    ]
    for old,new in changes:
        assert text.count(old)==1,(old,text.count(old));text=text.replace(old,new)
    with TARGET.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    shutil.copyfile(TEMPLATE,BASE/'base-model-template.py');shutil.copyfile(ROOT/'output/h5_global_propagation_encoding.py',BASE/'propagation-encoding.py')
    with (BASE/'solver-template-provenance.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'template':TEMPLATE.relative_to(ROOT).as_posix(),'template_sha256':digest(TEMPLATE),'target':TARGET.relative_to(ROOT).as_posix(),'target_sha256':digest(TARGET),'propagation_module_sha256':digest(ROOT/'output/h5_global_propagation_encoding.py'),'changes':[{'old':a,'new':b} for a,b in changes],'prior_model_geometry_and_constraints_preserved':True,'new_independently_checked_propagation_constraints':True,'solver_calls':0},f,indent=2);f.write('\n')
    print({'target':str(TARGET),'recorded_template_changes':len(changes),'target_sha256':digest(TARGET)})
if __name__=='__main__':main()
