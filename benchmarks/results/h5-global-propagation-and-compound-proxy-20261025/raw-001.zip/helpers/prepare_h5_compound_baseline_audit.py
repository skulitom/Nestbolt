"""Prepare the same independent partial-witness checks for the five-piece proxy."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compound-cog-proxy-20261025'
def main():
    source=ROOT/'output/audit_h5_global_propagation_baseline.py';target=ROOT/'output/audit_h5_compound_proxy_baseline.py';text=source.read_text(encoding='utf-8');changes=[("BASE=ROOT/'output/h5-global-packing-propagation-20261025'","BASE=ROOT/'output/h5-compound-cog-proxy-20261025'"),("offsets=[aux['cog_inner_square_offsets']] if p['family']=='cog'","offsets=aux['cog_inner_components'] if p['family']=='cog'"),("assert len(rects)==74","assert len(rects)==134")]
    for a,b in changes:assert text.count(a)==1;text=text.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    with (BASE/'baseline-audit-template.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'changes':[{'old':a,'new':b} for a,b in changes]},f,indent=2);f.write('\n')
if __name__=='__main__':main()
