"""Record exact removal of pairwise disjunctions and five-piece proxy changes."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compound-cog-proxy-20261025'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def replace_once(text,old,new,changes):
    assert text.count(old)==1,(old,text.count(old));changes.append({'old':old,'new':new});return text.replace(old,new)
def main():
    module=ROOT/'output/h5_global_propagation_encoding.py';text=module.read_text(encoding='utf-8');changes=[]
    pairs=[
        ("range(1 if item['family']=='cog' else len(item['components']))","range(5 if item['family']=='cog' else len(item['components']))"),
        ("half=aux['cog_inner_square_half_coordinate_units'];widths=heights=[2*half]","rect=aux['cog_inner_components'][arm];widths=[rect[2]-rect[0]];heights=[rect[3]-rect[1]]"),
        ("[(sx,item['x'],-half),(sy,item['y'],-half),(ex,item['x'],half),(ey,item['y'],half)]","[(sx,item['x'],rect[0]),(sy,item['y'],rect[1]),(ex,item['x'],rect[2]),(ey,item['y'],rect[3])]"),
        ("count={'frame':1,'bracket':2,'insert':1,'cog':1}","count={'frame':1,'bracket':2,'insert':1,'cog':5}"),
        ("half=aux['cog_inner_square_half_coordinate_units'];widths=heights=[half*2]","rect=aux['cog_inner_components'][arm];widths=[rect[2]-rect[0]];heights=[rect[3]-rect[1]]"),
        ("rhs=(-1 if k<2 else 1)*half;t=","rhs=rect[k];t=")
    ]
    for a,b in pairs:text=replace_once(text,a,b,changes)
    targetmod=ROOT/'output/h5_compound_proxy_encoding.py'
    with targetmod.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    template=ROOT/'output/solve_h5_global_propagation.py';text=template.read_text(encoding='utf-8');modelchanges=[]
    for begin,end in [("    for a,b in combinations(items,2):\n","    propagation=build_propagation"),("    for a,b in combinations(oracle,2):\n","    assert oracle==items and oraclepairs==pairs\n")]:
        assert text.count(begin)==text.count(end)==1;lo=text.index(begin);hi=text.index(end,lo);removed=text[lo:hi];text=replace_once(text,removed,'',modelchanges)
    pairs=[("BASE=ROOT/'output/h5-global-packing-propagation-20261025'","BASE=ROOT/'output/h5-compound-cog-proxy-20261025'"),
        ('from h5_global_propagation_encoding import','from h5_compound_proxy_encoding import'),
        ("len(propagation)==78","len(propagation)==138"),
        ("assert counts=={'rect-rect':1941,'disk-rect':945,'disk-disk':105}","assert counts=={}"),
        ("'inner_rectangles':78,'optional_intervals':312","'inner_rectangles':138,'optional_intervals':552,'own_cog_components_in_global_no_overlap':True"),
        ("'interpretation':'The inherited all-movable cog-polygon model is strengthened by original-area sheet bounds and independently certified inner-rectangle global propagation. It remains a necessary relaxation without actual cog angles or accepted geometry. No native or H5 qualification.'","'interpretation':'All66 parts remain movable under original area bounds and complete inner-rectangle global propagation. Each cog has five coupled, disjoint inner rectangles; pairwise polygon disjunctions are omitted. A positive proxy outcome requires larger-polygon and original-outline diagnosis. No native or H5 qualification.'"),
        ("A positive solution is only an inscribed-polygon relaxation.","A positive solution is only an inner-rectangle proxy relaxation.")]
    for a,b in pairs:text=replace_once(text,a,b,modelchanges)
    target=ROOT/'output/solve_h5_compound_proxy.py'
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    shutil.copyfile(module,BASE/'propagation-module-template.py');shutil.copyfile(template,BASE/'base-model-template.py');shutil.copyfile(targetmod,BASE/'proxy-encoding.py')
    with (BASE/'solver-template-provenance.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'template':template.relative_to(ROOT).as_posix(),'template_sha256':digest(template),'target_sha256':digest(target),'module_template_sha256':digest(module),'module_target_sha256':digest(targetmod),'module_changes':changes,'model_changes':modelchanges,'solver_calls':0},f,indent=2);f.write('\n')
    print({'model':str(target),'module_changes':len(changes),'model_changes':len(modelchanges),'model_sha256':digest(target)})
if __name__=='__main__':main()
