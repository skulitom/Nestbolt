"""Audit exact existential equivalence of shared integer direction predicates."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from math import gcd,ceil
from fractions import Fraction
from collections import Counter
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-shared-direction-source-model-20261026'
PARENT=ROOT/'output/h5-area-constrained-source-model-20261026'
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lin(terms,lo,hi,en=()):
    coefficients={v:sum(n for w,n in terms if w==v) for v,_ in terms}
    ids=sorted(v for v in coefficients if coefficients[v])
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend(coefficients[v] for v in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(en);return c
def disj(active,flags):
    c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-active-1]+flags);return c
def bag(rows):return Counter(r.SerializeToString() for r in rows)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Independently reconstruct old and new constraint multisets from the immutable source mapping and raw halfplanes. Check complete original auxiliary-variable coverage, unchanged base/area/hints and non-constraint fields, exact positive-gcd integer normalization, complementary truth definitions, all active-mode OR clauses and two-way existential projection. Verify source hashes through committed manifests and the independently audited area parent. Compare actual CpModel import/export. No solver call.'})
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    pa=load(PARENT/'audit/plan.json')
    for n,h in pa['inputs'].items():assert digest(ROOT/n)==h,n
    pc=load(PARENT/'audit/checks.json');assert pc['passed'] and pc['entire_original_parent_restored'] and pc['all14_area_inequalities_independently_reconstructed']
    known={r['sha256'] for name in ['h5-bounded-source-search-20261026','h5-first-sheet-cog-neighborhoods-20261026'] for r in sum([load(ROOT/'benchmarks/results'/name/'raw-manifest.json')[key] for key in ['files','aliases']],[])}
    for n,h in load(PARENT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
    sourcefiles=[SOURCE/'plan.json']+sorted((SOURCE/'mutual').glob('*.json'))
    for p in sourcefiles:assert digest(p) in known,p
    old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes())
    new=cp_model_pb2.CpModelProto();new.ParseFromString((BASE/'model.pb').read_bytes())
    assert len(old.variables)==167044 and len(old.constraints)==376377
    assert new.variables[:10255]==old.variables[:10255] and new.constraints[:57577]==old.constraints[:57577]
    assert new.constraints[57577:57591]==old.constraints[376363:376377]
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(new);del restored.variables[10255:];restored.variables.extend(old.variables[10255:]);del restored.constraints[57577:];restored.constraints.extend(old.constraints[57577:]);assert restored==old
    assert len(new.solution_hint.vars)==72 and all(v<10255 for v in new.solution_hint.vars)
    for c in new.constraints[:57591]:
        k=c.WhichOneof('constraint');assert k in ['linear','bool_or','bool_and','exactly_one','at_most_one']
        refs=list(c.enforcement_literal)+list(c.linear.vars if k=='linear' else getattr(c,k).literals)
        assert all((v if v>=0 else -v-1)<10255 for v in refs)
    om=load(PARENT/'mapping.json');nm=load(BASE/'mapping.json')
    assert {k:v for k,v in om.items() if k!='source_pair_faces'}=={k:v for k,v in nm.items() if k!='source_pair_faces'}
    assert len(om['source_pair_faces'])==len(nm['source_pair_faces'])==394
    coords={p['part']:p for p in om['simultaneous_original_coordinates']};assert set(coords)==set(range(9))
    defs=load(BASE/'shared-directions.json');projections=load(BASE/'old-direction-projection.json')
    assert [r['flag'] for r in defs]==list(range(10255,111710)) and [r['old_flag'] for r in projections]==list(range(10255,167044))
    assert all(list(v.domain)==[0,1] for v in old.variables[10255:]) and all(list(v.domain)==[0,1] for v in new.variables[10255:])
    byflag={r['flag']:r for r in defs};byold={r['old_flag']:r for r in projections};keys={};expected_new=[];expected_old=[];usedold=set();usednew=set();counts=Counter();cache={}
    def terms(parts,a,b):
        u,v=[coords[i] for i in parts];return [(v['x'],a),(u['x'],-a),(v['y'],b),(u['y'],-b)]
    definition_indices=set()
    for r in defs:
        key=tuple(r['parts'])+(r['a'],r['b'],r['bound']);assert key not in keys;keys[key]=r['flag']
        assert gcd(abs(r['a']),abs(r['b']))==1
        t=terms(r['parts'],r['a'],r['b']);pair=[lin(t,r['bound'],2**63-1,[r['flag']]),lin(t,-2**63,r['bound']-1,[-r['flag']-1])]
        a,b=r['constraint_span'];assert b==a+2 and a>=57591 and list(new.constraints[a:b])==pair
        assert not definition_indices.intersection(range(a,b));definition_indices.update(range(a,b));expected_new.extend(pair)
    previous_old=57577;previous_new=57591
    for op,np in zip(om['source_pair_faces'],nm['source_pair_faces']):
        for k in ['parts','case','mutual_case','query_a','query_b','active']:assert op[k]==np[k]
        assert op['parts'][0]<op['parts'][1] and op['active']<10255
        oa,ob=op['constraint_span'];na,nb=np['constraint_span'];assert oa==previous_old and na==previous_new;previous_old=ob;previous_new=nb
        pairnew=list(old.constraints[oa:oa+2]);pairold=list(pairnew)
        assert new.constraints[na:na+2]==old.constraints[oa:oa+2]
        case=op['mutual_case']
        if case not in cache:cache[case]=load(SOURCE/'mutual'/f'{case:03d}.json')
        assert len(op['clauses'])==len(np['clauses'])
        for oc,nc in zip(op['clauses'],np['clauses']):
            assert oc['face']==nc['face'] and oc['live_edges']==nc['live_edges'];edges=oc['live_edges'];active=op['active']
            if len(edges)<2:
                assert not oc['directions'] and not nc['directions']
                if not edges:c=lin([(active,1)],0,0);counts['impossible_faces']+=1
                else:
                    h=cache[case]['faces'][oc['face']]['outside_halfplanes'][edges[0]];c=lin(terms(op['parts'],h['a'],h['b']),h['bound'],2**63-1,[active]);counts['single_direction_faces']+=1
                pairnew.append(c);pairold.append(c);continue
            assert [d['edge'] for d in oc['directions']]==[d['edge'] for d in nc['directions']]==edges
            for od,nd in zip(oc['directions'],nc['directions']):
                h=cache[case]['faces'][oc['face']]['outside_halfplanes'][od['edge']];g=gcd(h['a'],h['b']);assert g>0
                normalized=[h['a']//g,h['b']//g,ceil(Fraction(h['bound'],g))]
                assert h['a']==normalized[0]*g and h['b']==normalized[1]*g and (normalized[2]-1)*g<h['bound']<=normalized[2]*g
                key=tuple(op['parts'])+tuple(normalized);assert keys[key]==nd['flag']
                r={'old_flag':od['flag'],'shared_flag':nd['flag'],'active':active,'parts':op['parts'],'raw_halfplane':[h['a'],h['b'],h['bound']],'gcd':g};assert byold[od['flag']]==r
                if od['flag'] not in usedold:
                    expected_old.extend([lin(terms(op['parts'],h['a'],h['b']),h['bound'],2**63-1,[od['flag']]),lin([(od['flag'],1),(active,-1)],-2**63,0)])
                    usedold.add(od['flag'])
                usednew.add(nd['flag']);counts['direction_uses']+=1
            pairold.append(disj(active,[d['flag'] for d in oc['directions']]))
            pairnew.append(disj(active,sorted({d['flag'] for d in nc['directions']})));counts['disjunctive_faces']+=1
        assert [c for i,c in enumerate(new.constraints[na:nb],na) if i not in definition_indices]==pairnew
        expected_old.extend(pairold);expected_new.extend(pairnew)
    assert previous_old==376363 and previous_new==len(new.constraints)==265709 and len(new.variables)==111710
    assert usedold==set(byold) and usednew==set(byflag)
    assert bag(expected_old)==bag(old.constraints[57577:376363])
    assert bag(expected_new)==bag(new.constraints[57591:])
    result=load(BASE/'result.json');assert result['model_sha256']==digest(BASE/'model.pb') and all(result[k]==v for k,v in counts.items())
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==new
    write(OUT/'equivalence-proof.json',{'scope':'Exact equality of the feasible projection onto original10255 variables within the audited finite source angles/inward integer domains/fixed57 construction; not unrestricted physical packing.','new_to_old':'Retain base variables. For each old flag set active AND shared truth. Every old direction implication and flag<=active holds. Every active old OR has a true shared disjunct and hence a true assigned old flag. Inactive ORs hold via not active.','old_to_new':'Retain base variables. Set every shared flag to the unique truth of its normalized integer inequality. Each active old OR has an old true flag implying the original plane, exactly equivalent to its normalized plane, so the new OR holds. All shared truth/complement definitions hold, including inactive modes.','normalization':'For positive gcd g, lhs/g is integral. Lhs>=bound iff lhs/g>=ceil(bound/g); its exact complement is <=ceil(bound/g)-1. Boundary inequalities were checked for every occurrence.','verified_old_flags':len(usedold),'verified_shared_flags':len(usednew),'all_old_and_new_auxiliary_constraints_accounted_for':True,'original_base_area_and_nonconstraint_fields_exactly_preserved':True})
    checks={'passed':True,'seconds':time.perf_counter()-start,'source_files_verified_against_committed_hashes':len(sourcefiles),'variables':len(new.variables),'constraints':len(new.constraints),'hints':72,'old_flags_verified':len(usedold),'shared_direction_flags':len(usednew),'physical_pair_modes':394,**counts,'base_and14_area_constraints_unchanged':True,'all_original_full_guarded_source_clauses_retained':True,'shared_direction_equivalence_verified':True,'both_auxiliary_constraint_multisets_verified':True,'all_original_nonconstraint_fields_restored':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':9,'fixed_originals':57,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
