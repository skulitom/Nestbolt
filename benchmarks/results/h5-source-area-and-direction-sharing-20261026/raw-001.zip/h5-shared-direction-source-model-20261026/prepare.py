"""Share integer-equivalent source direction truth values across each physical pair's modes."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from math import gcd
from collections import Counter
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-area-constrained-source-model-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-shared-direction-source-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def linear(terms,lo,hi,en=()):
    d=Counter()
    for v,c in terms:d[v]+=c
    ids=sorted(v for v,c in d.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(d[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);return p
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(PARENT/'audit/checks.json')['passed']
    paths=[PARENT/n for n in ['model.pb','mapping.json','result.json','area-additions.json','audit/checks.json']]+[ROOT/'output/h5-source-direction-reuse-20261026.json',SOURCE/'plan.json']+sorted((SOURCE/'mutual').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'required_originals':66,'moving_originals':9,'fixed_originals':57,'solver_calls':0,'method':'Keep the complete10255-variable/57577-constraint original base, all14 verified area constraints and72 base-variable hints. Replace only the prior156789 pair-mode direction flags and their source-clause suffix. For each physical ordered pair, normalize a*dx+b*dy>=bound by positive gcd(abs(a),abs(b)), using ceil(bound/gcd) exactly. Share an identical normalized inequality across all query/profile/sheet modes of that same physical pair. Define each shared Boolean as the exact truth value: true implies >=bound, false implies <=bound-1. Retain every original active-mode displacement box, zero/single-edge clause and complete OR of original live edges. No cross-pair sharing, approximate coefficient merge, new geometry, witness lock, domain removal or count change. Existential projection onto original coordinates/choices must equal the entire parent model; audit the two-way auxiliary assignment proof and actual import before any distinct bounded search.'})
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());assert len(parent.variables)==167044 and len(parent.constraints)==376377
    model=cp_model_pb2.CpModelProto();model.CopyFrom(parent);del model.variables[10255:];del model.constraints[57577:]
    for c in parent.constraints[376363:]:model.constraints.add().CopyFrom(c)
    assert len(model.constraints)==57591 and len(model.solution_hint.vars)==72 and all(v<10255 for v in model.solution_hint.vars)
    for c in model.constraints:
        kind=c.WhichOneof('constraint');refs=list(c.enforcement_literal)+list(c.linear.vars if kind=='linear' else getattr(c,kind).literals);assert all((v if v>=0 else -v-1)<10255 for v in refs)
    m=load(PARENT/'mapping.json');coords={p['part']:p for p in m['simultaneous_original_coordinates']};cache={};shared={};definitions=[];newpairs=[];oldflags={};counts=Counter()
    for pair in m['source_pair_faces']:
        a,b=[coords[i] for i in pair['parts']];active=pair['active'];assert active<10255;begin=len(model.constraints);vbegin=len(model.variables)
        for c in parent.constraints[pair['constraint_span'][0]:pair['constraint_span'][0]+2]:model.constraints.add().CopyFrom(c)
        case=pair['mutual_case']
        if case not in cache:cache[case]=load(SOURCE/'mutual'/f'{case:03d}.json')
        clauses=[]
        for row in pair['clauses']:
            fi=row['face'];live=row['live_edges'];directions=[]
            if not live:model.constraints.add().CopyFrom(linear([(active,1)],0,0));counts['impossible_faces']+=1
            elif len(live)==1:
                h=cache[case]['faces'][fi]['outside_halfplanes'][live[0]];terms=[(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])];model.constraints.add().CopyFrom(linear(terms,h['bound'],2**63-1,[active]));counts['single_direction_faces']+=1
            else:
                assert [d['edge'] for d in row['directions']]==live
                for d in row['directions']:
                    h=cache[case]['faces'][fi]['outside_halfplanes'][d['edge']];g=gcd(abs(h['a']),abs(h['b']));assert g>0;A=h['a']//g;B=h['b']//g;C=-(-h['bound']//g);key=(*pair['parts'],A,B,C)
                    if key not in shared:
                        flag=len(model.variables);shared[key]=flag;model.variables.add(name=f"shared-direction-{pair['parts'][0]}-{pair['parts'][1]}-{len(shared)-1}",domain=[0,1]);terms=[(b['x'],A),(a['x'],-A),(b['y'],B),(a['y'],-B)];start_constraints=len(model.constraints)
                        model.constraints.add().CopyFrom(linear(terms,C,2**63-1,[flag]));model.constraints.add().CopyFrom(linear(terms,-2**63,C-1,[-flag-1]));definitions.append({'flag':flag,'parts':pair['parts'],'a':A,'b':B,'bound':C,'constraint_span':[start_constraints,len(model.constraints)]})
                    flag=shared[key];directions.append({'edge':d['edge'],'flag':flag});record={'old_flag':d['flag'],'shared_flag':flag,'active':active,'parts':pair['parts'],'raw_halfplane':[h['a'],h['b'],h['bound']],'gcd':g}
                    if d['flag'] in oldflags:assert oldflags[d['flag']]==record
                    oldflags[d['flag']]=record;counts['direction_uses']+=1
                c=model.constraints.add();c.bool_or.literals.extend([-active-1]+sorted({d['flag'] for d in directions}));counts['disjunctive_faces']+=1
            clauses.append({'face':fi,'live_edges':live,'directions':directions})
        newpairs.append({**{k:pair[k] for k in ['parts','case','mutual_case','query_a','query_b','active']},'clauses':clauses,'constraint_span':[begin,len(model.constraints)],'new_variable_span':[vbegin,len(model.variables)]})
    assert len(oldflags)==156789 and len(shared)==101455 and len(model.variables)==111710 and len(model.constraints)==265709
    mapping={k:v for k,v in m.items() if k!='source_pair_faces'};mapping['source_pair_faces']=newpairs;write(OUT/'mapping.json',mapping);write(OUT/'shared-directions.json',definitions);write(OUT/'old-direction-projection.json',[oldflags[i] for i in sorted(oldflags)])
    write(OUT/'transformation.json',{'retained_original_variable_prefix':10255,'retained_original_constraint_prefix':57577,'retained_area_parent_constraint_span':[376363,376377],'retained_area_new_constraint_span':[57577,57591],'parent_direction_flags_removed':156789,'shared_direction_flags':101455,'retained_hints':72,'all394_source_pair_modes_retained':True,'old_assignment_from_new':'old_flag = active_mode AND shared_truth_flag','new_assignment_from_old':'Evaluate every shared normalized inequality at the original integer coordinates. Every active old OR has a true old flag implying that inequality, hence its shared OR holds. Inactive shared flags always have their uniquely consistent truth values.','integer_normalization':'g=gcd(abs(a),abs(b))>0; original lhs is a multiple of g, so lhs>=bound iff lhs/g>=ceil(bound/g). False is <=ceil(bound/g)-1.'})
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':72,'old_variables':len(parent.variables),'old_constraints':len(parent.constraints),'variables_removed':55334,'constraints_removed':110668,'shared_direction_flags':len(shared),'physical_pair_modes':len(newpairs),**counts,'model_sha256':digest(OUT/'model.pb'),'required_originals':66,'moving_originals':9,'fixed_originals':57,'area_inequalities_retained':14,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
