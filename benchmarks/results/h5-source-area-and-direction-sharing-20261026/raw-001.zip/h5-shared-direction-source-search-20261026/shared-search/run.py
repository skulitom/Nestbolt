"""One bounded call for the complete source-clause model; no restart."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,sys,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-direction-source-search-20261026';RUN=BASE/'shared-search';PREP=ROOT/'output/h5-shared-direction-source-model-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    OUT=RUN/'solve';OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter()
    import ortools
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2,sat_parameters_pb2
    from ortools.sat.python import cp_model
    checked=load(PREP/'audit/checks.json');assert checked['passed'] and checked['all_original_full_guarded_source_clauses_retained'] and checked['shared_direction_equivalence_verified']
    paths=[PREP/n for n in ['plan.json','result.json','model.pb','model.pbtxt','mapping.json','transformation.json','shared-directions.json','old-direction-projection.json','audit/plan.json','audit/checks.json','audit/solver-import-roundtrip.pb']]+[SOURCE/'plan.json',RUN/'budget.json']
    known=load(PREP/'audit/plan.json')['inputs']
    for p in paths:
        if p.relative_to(ROOT).as_posix() in known:assert digest(p)==known[p.relative_to(ROOT).as_posix()]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_solver_calls':1,'workers':8,'random_seed':0,'solver_cap_seconds':45,'shutdown_reserve_seconds':10,'method':'One distinct equivalent nine-mover source representation: share101455 exact normalized direction truth flags across physical-pair modes, replacing156789 old mode-specific flags. Independent audit verifies two-way existential projection, all old/new auxiliary constraints and the unchanged original base plus14 area rules. All394 full source pair modes, original constraints and72 advisory hints remain. No witness cog coordinates or focused empty-domain exclusions are added. Import and verify actual model equals independent audit. All66 originals mandatory; nine movable in original inward integer domains/recorded angles and57 fixed. Loading/import/audit/search share60seconds, with at most45 solver seconds and ten seconds reserved for shutdown. No outer-box or strict safe-cell relation remains. A positive requires full original source/geometry readback and native validation; a negative remains conditional on the original source-angle/inward-grid/fixed-57 construction. Offline preparation is not production qualification. All earlier calls remain closed.'})
    expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());model=cp_model.CpModel();assert model.proto.parse_text_format((PREP/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'model.pb'));loading=time.perf_counter()-start;start=time.perf_counter()
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());assert actual==expected and len(actual.variables)==111710 and len(actual.constraints)==265709 and len(actual.solution_hint.vars)==72
    mapping=load(PREP/'mapping.json');assert len(mapping['source_pair_faces'])==394 and len(mapping['simultaneous_original_coordinates'])==9;write(OUT/'mapping.json',mapping)
    remaining=load(RUN/'budget.json')['deadline_perf_counter']-time.perf_counter()-10;assert remaining>0
    params={'max_time_in_seconds':min(45,remaining),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params);(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audit_seconds=time.perf_counter()-start
    audit={'passed':True,'loading_seconds':loading,'audit_seconds':audit_seconds,'variables':111710,'constraints':265709,'hints':72,'required_originals':66,'mandatory_moving_originals':9,'fixed_originals':57,'original_anchor_variables':18,'complete_source_pair_mode_uses':394,'verified_source_region_area_inequalities':14,'witness_coordinate_locks_added':0,'shared_direction_equivalence_verified':True,'shared_direction_flags':101455,'all_original_full_guarded_source_clauses_retained':True,'actual_solver_import_export_matches_independently_verified_model':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining,'shutdown_reserve_seconds':10,'python':sys.version,'ortools':ortools.__version__};write(OUT/'model-audit.json',audit);print(audit,flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds'],'model_sha256':audit['model_sha256']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    def value(i):return solver.value(model.get_int_var_from_proto_index(i))
    if positive:
        selected=[];spec=load(SOURCE/'plan.json')
        for p in mapping['parts']:
            modes=[m for m in p['modes'] if value(m['active'])];assert len(modes)==1;m=modes[0];ds=[i for i,v in enumerate(m['domains']) if value(v)];assert len(ds)==1;q=spec['queries'][m['query']];d=load(SOURCE/'queries'/f"{m['query']:03d}.json")['domains'][ds[0]]
            selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':ds[0],'domain_index':d['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':value(p['choice'])})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66});write(OUT/'original-positions.json',[{'part':p['part'],'x_units':value(p['x']),'y_units':value(p['y'])} for p in mapping['simultaneous_original_coordinates']])
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_full_guarded_source_candidate':positive,'response_stats':solver.response_stats(),'scope':'Full original guarded pair relations, all66 originals mandatory, nine moving with source angles/inward integer domains,57 fixed. Positive requires full geometry/native validation. Negative is not unrestricted packing impossibility. Offline preparation is not production qualification.','full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
def main():
    BASE.mkdir();RUN.mkdir();shutil.copyfile(__file__,RUN/'run.py');start=time.perf_counter();deadline=start+60;assert load(PREP/'audit/checks.json')['passed']
    write(RUN/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'start_perf_counter':start,'deadline_perf_counter':deadline,'solver_cap_seconds':45,'solver_shutdown_reserve_seconds':10,'maximum_solver_calls':1,'workers':8,'random_seed':0,'previous_calls_remain_closed':True})
    write(RUN/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [PREP/'audit/checks.json',Path(__file__)]},'method':'One distinct full-source representation with verified exact shared-direction equivalence, removing55334 variables and110668 constraints while retaining all14 area rules and the original base. All9 movers remain free in their recorded source domains; no witness locks or focused exclusions are reused. Shared60second loading/verification/search budget, solver cap45seconds and shutdown reserve10seconds. No retry, continuation or reseed. Offline preparation is not production qualification.'})
    began=time.perf_counter();record={}
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,deadline-time.perf_counter()));record={'seconds':time.perf_counter()-began,'exit_code':p.returncode};(RUN/'master-stdout.txt').write_bytes(p.stdout);(RUN/'master-stderr.txt').write_bytes(p.stderr);write(RUN/'master-process.json',record);print(p.stdout.decode(errors='replace'),flush=True);status='MASTER_'+load(RUN/'solve/result.json')['status'] if p.returncode==0 else 'STAGE_FAILED'
    except subprocess.TimeoutExpired as e:
        (RUN/'master-stdout.txt').write_bytes(e.stdout or b'');(RUN/'master-stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-began,'timeout':True};status='SHARED_BUDGET_PROCESS_TIMEOUT'
    result={'status':status,'elapsed_seconds':time.perf_counter()-start,'shared_budget_seconds':60,'stage':record,'solver_calls_opened':int((RUN/'solve/opened.json').exists()),'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(RUN/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:child() if '--child' in sys.argv else main()
    except Exception:
        folder=RUN/'solve' if '--child' in sys.argv else RUN
        if folder.exists():(folder/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
