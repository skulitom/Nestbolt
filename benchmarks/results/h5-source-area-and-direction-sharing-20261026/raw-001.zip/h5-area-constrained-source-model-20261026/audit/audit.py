"""Verify all source area coefficients, units, activations and exact parent preservation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-bounded-source-model-20261026';BASE=ROOT/'output/h5-area-constrained-source-model-20261026';CAP=ROOT/'output/h5-source-area-caps-20261026/audit-provenance-repaired';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Check all input hashes against committed parent and source-area archives. Remove only the14 appended constraints and recover the complete parent protobuf including all variables, clauses, objectives and hints. Independently enumerate original part/query sheet activations and family lower-area coefficients in integer square millimetres; reconstruct every new inequality without using the producer term list as an inventory. Verify every mode remains present and every activation is Boolean. Compare all42 complementary sheet allocations with the independent geometric area certificate and the original global-area constraints. Validate actual CpModel import/export equals the audited child. No solver call or focused witness assumption.'})
    known={}
    for name in ['h5-bounded-source-search-20261026','h5-first-sheet-cog-neighborhoods-20261026']:
        manifest=load(ROOT/'benchmarks/results'/name/'raw-manifest.json')
        for r in manifest['files']+manifest['aliases']:known.setdefault(r['sha256'],[]).append(r['path'])
    checked={}
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n;checked[n]={'sha256':h,'committed_reference':known[h][0]}
    capcheck=load(CAP/'checks.json');assert capcheck['passed'] and capcheck['no_cog_witness_pose_assumed'] and capcheck['capacity_regions']==14
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());actual=cp_model_pb2.CpModelProto();actual.ParseFromString((BASE/'model.pb').read_bytes());assert len(parent.variables)==167044 and len(parent.constraints)==376363 and len(actual.constraints)==376377
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(actual);del restored.constraints[376363:];assert restored==parent
    spec=load(SOURCE/'plan.json');m=load(BASE/'mapping.json');assert m==load(PARENT/'mapping.json') and [p['part'] for p in m['parts']]==list(range(9))
    bounds=load(CAP/'verified-capacity-inequalities.json');recorded=load(BASE/'area-additions.json');expected=[];terms_checked=0
    for i,bound in enumerate(bounds['inequalities']):
        terms=[]
        for index,original in enumerate(spec['parts']):
            p=m['parts'][index];assert p['item']==original['index'] and p['family']==original['family'] and [r['query'] for r in p['modes']]==original['queries']
            if original['family'] not in bound['families']:continue
            for query in original['queries']:
                if spec['queries'][query]['sheet']!=bound['sheet']:continue
                mode=next(r for r in p['modes'] if r['query']==query);v=mode['active'];assert list(actual.variables[v].domain)==[0,1]
                terms.append({'part':index,'item':original['index'],'family':original['family'],'query':query,'variable':v,'coefficient_mm2':bounds['area_lower_bounds_mm2'][original['family']]});terms_checked+=1
        terms.sort(key=lambda t:t['variable']);assert len(terms)==len({t['variable'] for t in terms})
        row={'index':i,'constraint':376363+i,'sheet':bound['sheet'],'families':bound['families'],'upper_area_mm2':bound['upper_area_mm2'],'terms':terms};assert row==recorded[i]
        c=cp_model_pb2.ConstraintProto();c.linear.domain.extend([-2**63,bound['upper_area_mm2']]);c.linear.vars.extend(t['variable'] for t in terms);c.linear.coeffs.extend(t['coefficient_mm2'] for t in terms);expected.append(c)
    assert list(actual.constraints[376363:])==expected and len(recorded)==len(expected)==14
    families=['bracket','insert','cog'];allocation_rows=load(CAP/'all-nine-sheet-allocations.json');assert len(allocation_rows)==42
    global_area=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json');comparison=[]
    for counts,row in zip(product(range(3),range(2),range(7)),allocation_rows):
        other=tuple(total-value for total,value in zip([2,1,6],counts));assert dict(zip(families,counts))==row['first_sheet_counts'] and dict(zip(families,other))==row['second_sheet_counts'];fail=[]
        for i,b in enumerate(bounds['inequalities']):
            local=counts if b['sheet']==0 else other;demand=sum(local[families.index(f)]*bounds['area_lower_bounds_mm2'][f] for f in b['families'])
            if demand>b['upper_area_mm2']:fail.append(i)
        assert fail==row['failed_capacity_indices'] and bool(fail)==row['excluded']
        totals=[spec['fixed_original_area_units_per_sheet'][s]+sum(n*global_area['part_areas'][f]['lower_units'] for f,n in zip(families,local)) for s,local in enumerate([counts,other])];old_ok=all(n<=r['upper_area_units'] for n,r in zip(totals,global_area['sheet_capacities']))
        comparison.append({**row,'original_global_area_constraints_pass':old_ok,'newly_rejected_beyond_original_global_area':old_ok and bool(fail)})
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    imported=cp_model_pb2.CpModelProto();imported.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert imported==actual
    write(OUT/'source-provenance.json',checked);write(OUT/'allocation-propagation-comparison.json',comparison)
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_input_files_verified':len(checked),'variables':len(actual.variables),'constraints':len(actual.constraints),'hints':len(actual.solution_hint.vars),'entire_original_parent_restored':True,'all14_area_inequalities_independently_reconstructed':True,'sheet_mode_area_terms_checked':terms_checked,'area_units_are_integer_square_mm':True,'all42_count_allocations_match_independent_area_certificate':True,'original_global_area_allowed_allocations':sum(r['original_global_area_constraints_pass'] for r in comparison),'newly_excluded_beyond_original_global_area':sum(r['newly_rejected_beyond_original_global_area'] for r in comparison),'no_fixed_witness_coordinate_or_focused_domain_exclusion_added':True,'all_original_full_guarded_source_clauses_retained':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':9,'fixed_originals':57,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
