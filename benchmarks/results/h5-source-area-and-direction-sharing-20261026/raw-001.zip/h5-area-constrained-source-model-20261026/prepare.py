"""Add verified source-region area propagation to the full nine-mover model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-bounded-source-model-20261026';CAP=ROOT/'output/h5-source-area-caps-20261026/audit-provenance-repaired';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-area-constrained-source-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(PARENT/'audit/checks.json')['passed'] and load(CAP/'checks.json')['passed'] and load(CAP/'checks.json')['no_cog_witness_pose_assumed']
    paths=[PARENT/n for n in ['model.pb','mapping.json','result.json','audit/checks.json']]+[CAP/n for n in ['checks.json','verified-capacity-inequalities.json','all-nine-sheet-allocations.json']]+[SOURCE/'plan.json',ROOT/'output/h5-source-orientation-construction-20261025/propagation.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'required_originals':66,'moving_originals':9,'fixed_originals':57,'new_inequalities':14,'solver_calls':0,'method':'Begin from the original complete-source-clause parent, not a focused model. Preserve every parent variable, constraint and hint unchanged. Append exactly14 independently verified source-region area inequalities. Each coefficient is a conservative integer square-mm family area lower bound; sum every matching original part/query activation on the specified sheet and family subset. The right side is the conservative integer square-mm available-region upper bound. All9 moving originals, including all6 cogs, remain movable; no witness locks or focused exclusions are imported. All66 originals, source angles/domains, original guards/material target and parent constructive restrictions remain required. This is distinct global source-region propagation, not continuation or reseeding of any closed call. Independent parent restoration, coefficient/unit/inventory and actual solver import audits precede a separate bounded search. Offline preparation is not production qualification.'})
    m=load(PARENT/'mapping.json');spec=load(SOURCE/'plan.json');bounds=load(CAP/'verified-capacity-inequalities.json');model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());assert len(model.variables)==167044 and len(model.constraints)==376363 and len(model.solution_hint.vars)==72 and len(m['parts'])==9
    additions=[]
    for i,row in enumerate(bounds['inequalities']):
        terms=[]
        for p in m['parts']:
            if p['family'] not in row['families']:continue
            for mode in p['modes']:
                if spec['queries'][mode['query']]['sheet']==row['sheet']:terms.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':mode['query'],'variable':mode['active'],'coefficient_mm2':bounds['area_lower_bounds_mm2'][p['family']]})
        terms.sort(key=lambda t:t['variable']);assert len({t['variable'] for t in terms})==len(terms)
        c=model.constraints.add();c.linear.vars.extend(t['variable'] for t in terms);c.linear.coeffs.extend(t['coefficient_mm2'] for t in terms);c.linear.domain.extend([-2**63,row['upper_area_mm2']])
        additions.append({'index':i,'constraint':len(model.constraints)-1,'sheet':row['sheet'],'families':row['families'],'upper_area_mm2':row['upper_area_mm2'],'terms':terms})
    assert len(additions)==14 and len(model.constraints)==376377
    write(OUT/'mapping.json',m);write(OUT/'area-additions.json',additions);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'parent_constraints_retained':376363,'appended_area_constraints':14,'new_variables':0,'fixed_witness_coordinates_added':0,'focused_domain_exclusions_added':0,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'required_originals':66,'moving_originals':9,'fixed_originals':57,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
