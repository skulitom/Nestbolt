"""Quantify exact sharing of direction inequalities across modes of each physical pair."""
from pathlib import Path
from hashlib import sha256
from math import gcd
from datetime import datetime,timezone
import json,time
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-area-constrained-source-model-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-source-direction-reuse-20261026.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
start=time.perf_counter();m=load(PARENT/'mapping.json');original={};raw=set();normalized=set();uses=0;cache={}
for pair in m['source_pair_faces']:
    case=pair['mutual_case']
    if case not in cache:cache[case]=load(SOURCE/'mutual'/f'{case:03d}.json')
    for clause in pair['clauses']:
        for item in clause['directions']:
            h=cache[case]['faces'][clause['face']]['outside_halfplanes'][item['edge']];key=(tuple(pair['parts']),h['a'],h['b'],h['bound']);g=gcd(abs(h['a']),abs(h['b']));assert g>0
            if item['flag'] in original:assert original[item['flag']]==key
            original[item['flag']]=key;raw.add(key);normalized.add((tuple(pair['parts']),h['a']//g,h['b']//g,-(-h['bound']//g)));uses+=1
assert len(original)==156789
result={'utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-start,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [PARENT/'model.pb',PARENT/'mapping.json',PARENT/'audit/checks.json']},'physical_pair_modes':len(m['source_pair_faces']),'old_direction_flags':len(original),'direction_uses':uses,'physical_pair_shared_raw_directions':len(raw),'physical_pair_shared_integer_normalized_directions':len(normalized),'predicted_new_variables':10255+len(normalized),'predicted_variable_reduction':167044-10255-len(normalized),'integer_equivalence':'With integer dx,dy and g=gcd(abs(a),abs(b))>0, a*dx+b*dy>=bound iff (a/g)*dx+(b/g)*dy>=ceil(bound/g). A shared flag can be defined as exactly this truth value and reused only for the same physical ordered pair, across its query/profile/sheet modes. Every active source-clause OR remains required. No witness or source geometry is changed.','solver_calls':0,'full_target_witness':False,'H5_complete':False}
with OUT.open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(result,flush=True)
