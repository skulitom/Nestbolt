"""Read closed logs only and record the next exact representation question."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import re,json
ROOT=Path(__file__).resolve().parents[1];rows=[]
for name in ['area-constrained','shared-direction']:
    p=ROOT/f'output/h5-{name}-source-search-20261026/shared-search/solve/solver.log';s=p.read_text();match=re.search(r'Starting search at ([0-9.]+)s with (\d+) workers\.',s);assert match
    rows.append({'representation':name,'source':p.relative_to(ROOT).as_posix(),'source_sha256':sha256(p.read_bytes()).hexdigest(),'logged_search_start_seconds':float(match[1]),'workers':int(match[2]),'terminal_status':'UNKNOWN'})
out=ROOT/'output/h5-source-model-timing-20261026.json'
record={'utc':datetime.now(timezone.utc).isoformat(),'closed_log_comparison':rows,'solver_calls':0,'conclusion':'Both preparations leave a substantial fraction of the one-shot solver window for search and neither finds a candidate. Fewer variables does not establish an end-to-end speed or packing improvement.','next_structural_question':'Can shared direction variables retain only flag=>normalized_plane, removing all101455 false=>complement clauses? Active face ORs still require a true direction. The existential layout projection should be unchanged: map one-sided flags to old mode-specific flags as active AND shared_flag; map an old assignment to shared flags as the OR of all old flags sharing the exact normalized plane. Audit this independently, preserve the original base/14 area rules/all394 modes, and validate actual import before a separately declared bounded call. This is a new smaller representation, never a restart or extension of either closed call.','predicted_variables':111710,'predicted_constraints':164254,'constraints_to_remove':101455,'all66_originals_required':True,'native_full_job_qualified':False,'H5_complete':False}
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
