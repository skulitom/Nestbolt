"""Declare a distinct one-shot search for the audited equivalent smaller model."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1]
names=['run_h5_area_constrained_source_search.py','audit_h5_area_constrained_source_search.py']
records=[]
for name in names:
    p=ROOT/'output'/name;s=p.read_text();original=s
    s=s.replace('h5-area-constrained-source-','h5-shared-direction-source-')
    if name.startswith('run_'):
        s=s.replace("'area-additions.json'","'transformation.json','shared-directions.json','old-direction-projection.json'")
        s=s.replace("for p in paths[:6]:assert digest(p)==known[p.relative_to(ROOT).as_posix()]","for p in paths:\n        if p.relative_to(ROOT).as_posix() in known:assert digest(p)==known[p.relative_to(ROOT).as_posix()]")
        s=s.replace("checked['all_original_full_guarded_source_clauses_retained']","checked['all_original_full_guarded_source_clauses_retained'] and checked['shared_direction_equivalence_verified']")
        s=s.replace('167044','111710').replace('376377','265709')
        s=s.replace('One distinct full nine-mover source model with exactly14 independently verified family-subset source-region area inequalities appended to the unchanged complete parent.','One distinct equivalent nine-mover source representation: share101455 exact normalized direction truth flags across physical-pair modes, replacing156789 old mode-specific flags. Independent audit verifies two-way existential projection, all old/new auxiliary constraints and the unchanged original base plus14 area rules.')
        s=s.replace('One distinct full-source model using14 verified region-area inequalities that exclude9 sheet allocations beyond the original global-area constraints.','One distinct full-source representation with verified exact shared-direction equivalence, removing55334 variables and110668 constraints while retaining all14 area rules and the original base.')
        s=s.replace("'witness_coordinate_locks_added':0,","'witness_coordinate_locks_added':0,'shared_direction_equivalence_verified':True,'shared_direction_flags':101455,")
    else:
        s=s.replace("assert model['verified_source_region_area_inequalities']==14", "assert model['shared_direction_equivalence_verified'] and model['shared_direction_flags']==101455 and model['variables']==111710 and model['constraints']==265709\n    assert model['verified_source_region_area_inequalities']==14")
    q=ROOT/'output'/name.replace('area_constrained','shared_direction');assert not q.exists()
    compile(s,str(q),'exec');q.write_text(s,encoding='utf-8',newline='\n');records.append({'source':p.relative_to(ROOT).as_posix(),'source_sha256':sha256(p.read_bytes()).hexdigest(),'generated':q.relative_to(ROOT).as_posix(),'generated_sha256':sha256(q.read_bytes()).hexdigest()})
out=ROOT/'output/h5-shared-direction-search-helper-generation-20261026.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump({'helpers':records,'maximum_solver_calls':1,'solver_seconds':45,'total_seconds':60,'workers':8,'random_seed':0,'previous_completed_calls_remain_closed':True},f,indent=2);f.write('\n')
print(records)
