"""Prepare a distinct one-shot full-source search with verified area propagation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-area-constrained-source-model-20261026';assert json.loads((BASE/'audit/checks.json').read_bytes())['passed'];records=[]
src=ROOT/'output/run_h5_bounded_source_search.py';s=src.read_text(encoding='utf-8');replacements={
    'h5-bounded-source-search-20261026':'h5-area-constrained-source-search-20261026',
    'h5-bounded-source-model-20261026':'h5-area-constrained-source-model-20261026',
    'all_original_full_guarded_source_clauses_equivalent':'all_original_full_guarded_source_clauses_retained',
    "'transformation.json'":"'area-additions.json'",
    '376363':'376377',
    'One distinct complete-source-clause model, with all394 pair modes, exact four-corner bound simplification, proved original domain/capacity exclusions and 72 advisory hints.':'One distinct full nine-mover source model with exactly14 independently verified family-subset source-region area inequalities appended to the unchanged complete parent. All394 full source pair modes, original constraints and72 advisory hints remain. No witness cog coordinates or focused empty-domain exclusions are added.',
    'One distinct full source-clause model using exact corner simplification and all proved original-domain/capacity constraints.':'One distinct full-source model using14 verified region-area inequalities that exclude9 sheet allocations beyond the original global-area constraints. All9 movers remain free in their recorded source domains; no witness locks or focused exclusions are reused.',
    "'complete_source_pair_mode_uses':394":"'complete_source_pair_mode_uses':394,'verified_source_region_area_inequalities':14,'witness_coordinate_locks_added':0",
}
for a,b in replacements.items():assert a in s,a;s=s.replace(a,b)
dst=ROOT/'output/run_h5_area_constrained_source_search.py';compile(s,str(dst),'exec')
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dst.relative_to(ROOT).as_posix(),'target_sha256':sha256(dst.read_bytes()).hexdigest(),'replacements':replacements})
src=ROOT/'output/audit_h5_bounded_source_search.py';s=src.read_text(encoding='utf-8');replacements={'h5-bounded-source-search-20261026':'h5-area-constrained-source-search-20261026','all_original_full_guarded_source_clauses_equivalent':'all_original_full_guarded_source_clauses_retained'}
for a,b in replacements.items():assert a in s,a;s=s.replace(a,b)
marker="    write(OUT/'plan.json',";assert s.count(marker)==1;s=s.replace(marker,"    inputs += [ROOT/'output/h5-area-constrained-source-model-20261026/audit/checks.json',ROOT/'output/h5-source-area-caps-20261026/audit-provenance-repaired/verified-capacity-inequalities.json']\n"+marker)
marker="        verified=[{**p,**xy} for p,xy in zip(parts,positions)]";assert s.count(marker)==1
addition="        area_spec=load(ROOT/'output/h5-source-area-caps-20261026/audit-provenance-repaired/verified-capacity-inequalities.json');area_rows=[]\n        for r in area_spec['inequalities']:\n            demand=sum(area_spec['area_lower_bounds_mm2'][p['family']] for p in parts if p['sheet']==r['sheet'] and p['family'] in r['families']);assert demand<=r['upper_area_mm2'];area_rows.append({**r,'actual_lower_demand_mm2':demand,'passed':True})\n        write(OUT/'source-region-area-checks.json',area_rows)\n"
s=s.replace(marker,addition+marker)
marker="    assert model['passed']";assert s.count(marker)==1;s=s.replace(marker,"    assert model['verified_source_region_area_inequalities']==14 and model['witness_coordinate_locks_added']==0\n"+marker)
dst=ROOT/'output/audit_h5_area_constrained_source_search.py';compile(s,str(dst),'exec')
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dst.relative_to(ROOT).as_posix(),'target_sha256':sha256(dst.read_bytes()).hexdigest(),'replacements':replacements,'positive_source_region_area_recheck_added':True,'extra_inputs_recorded':True})
with (BASE/'search-helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'maximum_solver_calls':1,'solver_cap_seconds':45,'shared_import_audit_search_seconds':60,'shutdown_reserve_seconds':10,'previous_calls_remain_closed':True},f,indent=2);f.write('\n')
print({'search_helpers_prepared':2,'solver_calls':0})
