from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_twelve_cog_543_row_model_build_20261107.py').read_text(encoding='utf-8').replace('h5-twelve-cog-543-row-integer-20261107','h5-independent-twelve-cog-integer-20261107').replace('h5-twelve-cog-543-row-model-process-20261107','h5-independent-twelve-cog-model-process-20261107').replace('h5_twelve_cog_543_row_model','h5_independent_twelve_cog_model')
ast.parse(s)
with (ROOT/'output/run_h5_independent_twelve_cog_model_build_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['build_h5_independent_twelve_cog_model_20261107.py','audit_h5_independent_twelve_cog_model_20261107.py']:ast.parse((ROOT/'output'/name).read_text(encoding='utf-8'))
print('Model build/audit helpers parse; no model executed yet.')
