from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-independent-twelve-cog-halfplanes-audit-v2-process-20261107'
EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';SCRIPT=ROOT/'output/audit_h5_independent_twelve_cog_halfplanes_v2_20261107.py';PY=ROOT/'.cache/shop-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();controls=load(EXE.parent/'checks.json');assert controls['passed'] and digest(EXE)==controls['runner_sha256']
inputs=[Path(__file__),SCRIPT,EXE,EXE.parent/'checks.json',ROOT/'output/h5-independent-twelve-cog-halfplane-audit-correction-20261107.json']
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'audit_cap_seconds':60,'memory_bytes':2*1024**3,'source_preparation_repeated':False,'solver_calls':0})
args=[str(EXE),'60000',str(2*1024**3),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(SCRIPT)]),str(ROOT),'version4'];t=time.perf_counter();r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=68)
(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json')
result={'closed':job['closed'],'complete_seconds':time.perf_counter()-t,'exit_code':r.returncode,'job':job,'passed':r.returncode==0 and job['closed'] and job['active_processes']==0 and job['reason_code']==job['error_code']==0,'source_preparation_repeated':False,'solver_calls':0};write(OUT/'process.json',result);print(result)
