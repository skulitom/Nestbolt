"""Format only this unpublished appended note, preserving every committed log byte."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1];NAME='h5-independent-twelve-cog-preparation-20261107'
marker='**2026-11-07 H5 independent twelve-cog preparation:**'
note='''**2026-11-07 H5 independent twelve-cog preparation:** [source, coordinate and integer audits]({link}) verify 28 original movers with 12 independently positioned cogs, all 108 source modes, 25,348 source pair checks and 258 cog interactions. Exact mode-coupled quarter-turn coordinates reduce the initial 80,202 region choices to 29,640, with 6,728 new original-source support proofs and minimum certified gap 0.232399392 mm. All 1,244 integer implications and 31 dominance proofs pass, leaving 27,594 choices and 97,284 guarded planes. The 50-original partial control retains all 66 cog-pair checks; 16 companions remain unplaced. Complete charged preparation so far is 3.242979 s. A complete model and independent protobuf audit are next, before one frozen 60/90-second call. No solver or native call opened and no arrangement or allocation is excluded. Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Both earlier row checkpoints reached main 3baf15d1 normally after all six prior checks passed, preserving 52 remote files. Current Windows CI is live at review. The pre-execution shell quoting failure remains documented; all bounded processes closed. No release is made.
'''
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    p=ROOT/name;s=p.read_text(encoding='utf-8');i=s.rindex(marker);prior=subprocess.check_output(['git','show','HEAD:'+name],cwd=ROOT).decode('utf-8')
    assert marker not in prior
    result=s[:i]+note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md')
    if name=='BENCHMARKS.md':assert result.startswith(prior)
    with p.open('w',encoding='utf-8',newline='\n') as f:f.write(result)
print('Unpublished note formatted; committed benchmark log preserved.')
