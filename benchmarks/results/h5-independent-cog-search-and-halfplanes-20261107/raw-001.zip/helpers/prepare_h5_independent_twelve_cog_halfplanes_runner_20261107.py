from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_independent_twelve_cog_integer_20261107.py').read_text(encoding='utf-8').replace('twelve-cog-integer-process','twelve-cog-halfplanes-process').replace('twelve_cog_integer','twelve_cog_halfplanes')
ast.parse(s)
with (ROOT/'output/run_h5_independent_twelve_cog_halfplanes_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for stage in ['prepare','audit','run']:ast.parse((ROOT/'output'/(stage+'_h5_independent_twelve_cog_halfplanes_20261107.py')).read_text(encoding='utf-8'))
print('Halfplane preparation/audit helpers parse; no source process opened.')
