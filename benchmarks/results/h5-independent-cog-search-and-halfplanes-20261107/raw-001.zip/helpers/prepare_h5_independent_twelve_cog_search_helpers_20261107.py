from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_twelve_cog_543_row_model_20261107.py').read_text(encoding='utf-8')
runner=runner.replace('h5-twelve-cog-543-row-integer-20261107','h5-independent-twelve-cog-integer-20261107').replace('h5_twelve_cog_543_row_candidate','h5_independent_twelve_cog_candidate').replace("BASE / 'geometry-audit'","BASE / 'audit'").replace("BASE / 'geometry-audit/plan.json'","BASE / 'audit/plan.json'").replace("BASE / 'geometry-audit/checks.json'","BASE / 'audit/checks.json'")
a=runner.index('    inputs = [');b=runner.index("    write(OUT / 'opened.json'",a)
runner=runner[:a]+'''    inputs = [Path(__file__), ROOT/'output/prepare_h5_independent_twelve_cog_search_helpers_20261107.py',
              ROOT/'output/h5_source_projection_short_core_reader_20261029.py',
              ROOT/'output/check_h5_independent_twelve_cog_candidate_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',
              BASE/'plan.json',BASE/'audit/plan.json',BASE/'audit/checks.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',
              MODEL/'plan.json',MODEL/'budget.json',MODEL/'final-preparation-charges.json',MODEL/'build-process.json',MODEL/'model.pb',MODEL/'mapping.json',
              BASE/'inventory.json',BASE/'family-modes.json',BASE/'aliases.json',BASE/'owner-pairs.json',BASE/'control-positions.json',BASE/'control-regions.json']
'''+runner[b:]
audit=(ROOT/'output/audit_h5_twelve_cog_543_row_response_20261107.py').read_text(encoding='utf-8')
audit=audit.replace('"""Independently read the sole movable-packet response, assignments and budget."""','"""Independently read the sole individual-cog model response, assignments and charges."""').replace('h5-twelve-cog-543-row-integer-20261107','h5-independent-twelve-cog-integer-20261107').replace("charges['direct_short9_and_inventory_complete_process_seconds']","charges['direct_short9_inventory_complete_process_seconds']")
for name,body in [('run_h5_independent_twelve_cog_model_20261107.py',runner),('audit_h5_independent_twelve_cog_response_20261107.py',audit)]:
    ast.parse(body)
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(body)
ast.parse((ROOT/'output/check_h5_independent_twelve_cog_candidate_20261107.py').read_text(encoding='utf-8'))
print('Single-call runner, source checker and response auditor prepared; no solve opened.')
