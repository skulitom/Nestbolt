from pathlib import Path
from hashlib import sha256
import ast,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/audit_h5_independent_twelve_cog_halfplanes_20261107.py';new=ROOT/'output/audit_h5_independent_twelve_cog_halfplanes_v2_20261107.py'
s=old.read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
needle="assert not any('/model/' in name or '/search/' in name or '/model-audit/' in name or '/memory-stop-audit/' in name for name in bindings)"
assert needle in s
s=s.replace(needle,"legacy_model_bindings=[name for name in bindings if any(v in name for v in ['/model/','/search/','/model-audit/','/memory-stop-audit/'])]\ncurrent_failed_model_bindings=[name for name in legacy_model_bindings if name.startswith('output/h5-independent-twelve-cog-integer-20261107/')]\nassert not current_failed_model_bindings\nwrite(OUT/'historical-model-bindings.json',legacy_model_bindings)")
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/h5-independent-twelve-cog-halfplane-audit-correction-20261107.json',")
s=s.replace('No prior solver model or response is consumed, no full66 feasibility or global infeasibility is claimed.','The current failed individual-cog model and search are absent from the input graph. Historical provenance retains older model/search bindings; these remain recorded and are not removed. No full66 feasibility or global infeasibility is claimed.')
s=s.replace("'old_model_or_solver_in_input_graph':False","'current_failed_model_or_solver_in_input_graph':False,'historical_model_search_bindings':len(legacy_model_bindings)")
ast.parse(s)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
record={'failed_auditor':old.relative_to(ROOT).as_posix(),'failed_auditor_sha256':sha256(old.read_bytes()).hexdigest(),'failure_stage':'Final input-lineage scope assertion, after all source-support, exact clipping, cover-chain, control and count checks passed.','preserved_failure':'output/h5-independent-twelve-cog-halfplanes-process-20261107/audit-stderr.txt','cause':'The assertion rejected every historical model/search binding. Source provenance legitimately retains464 older bindings, already present in the integer-geometry input graph. No current failed individual-cog model/search input is present.','correction':'Version2 records historical bindings and verifies absence of only the current failed individual-cog model/search. Geometry, source support, clipping, cover chains and all numeric assertions remain unchanged.','producer_wording_correction':'The original preparation plan says no previous model/search is consumed too broadly. Its direct geometry inputs exclude the current failed model/search, but recursive historical provenance retains older model/search references. Preserve the original wording and this correction.','source_preparation_repeated':False,'model_or_solver_started':False,'source_geometry_bytes_changed':False}
with (ROOT/'output/h5-independent-twelve-cog-halfplane-audit-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print('Versioned lineage-scope audit correction prepared; original preserved.')
