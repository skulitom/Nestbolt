"""Reconstruct every original contour from independent world positions and source modes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';SEARCH=BASE/'search';OUT=SEARCH/'source-response'
FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir();mapping=load(BASE/'model/mapping.json');values=load(SEARCH/'assignment.json');inventory=load(BASE/'inventory.json');assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,2100]
rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json');chosen=[];selected_modes={}
for owner in mapping['owners']:
    active=[m for m in owner['modes'] if values[m['selector']]];assert len(active)==1;mode=active[0];selected_modes[owner['owner']]=mode
    world=[values[v] for v in owner['positions']];assert all(lo<=x<=hi for x,(lo,hi) in zip(world,mode['integer_world_lower_left_bounds']))
    xy=[world[k]/100+mapping['world_origin_mm'][k] for k in [0,1]]
    rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
    chosen.append({'owner':owner['owner'],'identity':owner['identity'],'mode':mode['mode'],'world_lower_left_mm':xy})
pair_choices=[]
for pair in mapping['cog_interactions']:
    active=[r for r in pair['regions'] if values[r['selector']]];assert len(active)==1;region=active[0];a,b=pair['owners'];record={'owners':[a,b],'class':region['class'],'region':region['region']}
    if pair['kind']=='cog_orthogonal':
        mode=selected_modes[b];link=next(r for r in pair['coordinate_links'] if r['mode']==mode['mode']);assert link['selector']==mode['selector'] and link['class']==region['class']
        d=[values[mapping['owners'][b]['positions'][k]]-values[mapping['owners'][a]['positions'][k]] for k in [0,1]];z=[values[v] for v in pair['canonical_positions']]
        assert z==[sum(link['matrix'][k][j]*d[j] for j in [0,1])+link['offset_grid'][k] for k in [0,1]];record['relative_grid']=d;record['canonical_grid']=z
    else:assert pair['kind']=='cog_cog' and region['class']=='cog_cog'
    pair_choices.append(record)
job,spec=load(JOB),load(FIRST/'plan.json');expected=list(map(tuple,inventory['full66_identities']));assert len(rows)==66 and len(chosen)==28 and len(pair_choices)==258
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert check['same_sheet_pairs']==1632 and check['stock_edges']==264 and check['cutouts']==90 and check['hole_vertices']==10026
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-modes.json',chosen);write(OUT/'selected-pair-regions.json',pair_choices);write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'short9-source.json',BASE/'inventory.json',BASE/'model/mapping.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read each of28 independent world positions with its one selected original source mode; verify all258 selected cog regions and exact mode-coupled canonical maps. Restore original transform offsets and retain fixed29 and direct short9. Validate every original filled outline and all90 cutouts against source gap and stock guards, all1632 same-sheet pairs and264 stock edges. No rigid-row or finite-site reconstruction is used.'})
result={'source_valid66':check['valid'],'originals':66,'first_originals':57,'short_originals':9,'independent_cogs':12,'same_sheet_pairs':1632,'stock_edges':264,'cutouts':90,'hole_vertices':10026,'source_checker_calls':1,'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
