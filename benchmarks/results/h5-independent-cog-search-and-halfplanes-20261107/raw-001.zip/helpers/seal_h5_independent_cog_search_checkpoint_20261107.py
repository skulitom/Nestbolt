from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-independent-cog-search-and-halfplanes-20261107';OUT=ROOT/'benchmarks/results'/NAME
I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';H=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';F=ROOT/'output/h5-independent-cog-search-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['closed_solver_calls']==1 and not front['solver_response_available'] and not front['new_model_created']
inventory_ast=ast.parse((ROOT/'output/seal_h5_polygon_clearance_proofs_20261107.py').read_text(encoding='utf-8')).body
def assignment(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
inventory_start=next(i for i,node in enumerate(inventory_ast) if assignment(node,'setup'));inventory_end=next(i for i,node in enumerate(inventory_ast) if assignment(node,'walker'))
exec(compile(ast.Module(body=inventory_ast[inventory_start:inventory_end],type_ignores=[]),'historical-parent-archives','exec'))
PARENTS.extend(ROOT/'benchmarks/results'/name for name in ['h5-polygon-clearance-proofs-20261107','h5-exact-circle-forest-20261107','h5-strip-capacity-models-20261107','h5-twelve-cog-row-construction-20261107','h5-twelve-cog-543-constructions-20261107','h5-independent-twelve-cog-preparation-20261107'])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[I,H,F]+[ROOT/'output'/n for n in ['h5-independent-twelve-cog-model-process-20261107','h5-independent-twelve-cog-halfplanes-process-20261107','h5-independent-twelve-cog-halfplanes-audit-v2-process-20261107','h5-independent-twelve-cog-main-sync-20261107']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*independent*twelve*cog*20261107.py','*h5*independent*cog*search*20261107.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
correction=ROOT/'output/h5-independent-twelve-cog-halfplane-audit-correction-20261107.json';add('audit-correction.json',correction)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_polygon_clearance_proofs_20261107.py']:add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'next-preparation-charges.json','next-preparation-charges.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(I/'model-audit/checks.json','model-audit.json'),(I/'model/final-preparation-charges.json','closed-model-preparation-charges.json'),(I/'memory-stop-audit/checks.json','memory-stop-audit.json'),(I/'search/process.json','closed-search-process.json'),(H/'audit-v2/checks.json','support-halfplane-audit.json'),(correction,'audit-correction.json'),(ROOT/'output/h5-independent-twelve-cog-main-sync-20261107/receipt.json','prior-push-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Individual-cog search and source support halfplanes — 2026-11-07

The complete individual-cog model passes its full audit, but its **sole search
stops at the 2 GiB memory limit without a solver response or placement**.
Every process closes. A distinct source-certified representation is now ready:
one support inequality per convex exterior choice cuts the proposed guarded
geometry planes from **97,284 to 53,070**. Its complete model is not built yet.
Four fixed arrangements and all 440 whole allocations remain; H2/H5 stay open
at **60% completed milestone weight**.

## Complete model and preserved bounded failure

[Full protobuf readback]({NAME}/model-audit.json) verifies all **29,310 variables
and 102,383 constraints**, binary/text agreement and an actual OR-Tools import.
The model retains all 28 original movers, twelve individually positioned cogs,
108 source-mode selectors and 56 world coordinates. The 192 cog/orthogonal pairs
have 384 canonical coordinates, 2,304 exact conditional mode links and 288 class
marginals. All 258 cog interactions and all 120 orthogonal-owner interactions
are present; the latter use 24 rigid rectangles, 640 mode links and 268 component
pairs. There are 25 valid identical-copy X-order constraints.

The partial hint contains 6,702 values and satisfies all 380 fully hinted active
constraints. It places only the twelve cogs; it is not a complete layout.
[Complete preparation and model building]({NAME}/closed-model-preparation-charges.json)
consume **6.701406 seconds**, including the 3.458427-second full build process.

[The failure audit]({NAME}/memory-stop-audit.json) binds the one call's exact
model, parameters, log and Windows Job result. Four workers and seed zero receive
**48.349494 seconds** of solve time. The log reaches search after 9.17 seconds of
presolve, with 29,098 variables and 124,289 constraints in the presolved model.
The calibrated supervisor then reports memory reason 3 and exit 124.

The [closed process]({NAME}/closed-search-process.json) records **32.031 seconds**
inside the job and **38.762725 seconds including charged preparation**. Its peak
aggregate committed memory is **2,151,796,736 bytes**, 4,313,088 bytes above the
2,147,483,648-byte monitored threshold. The overshoot remains recorded; this is
not a claim of an instantaneous hard cap. All descendants close with zero active
processes. No incumbent, assignment, source check, result JSON or response protobuf
exists. There is no returned solver status, branch count or solve-duration result
to report; **UNKNOWN and INFEASIBLE are not synthesized**. This call is closed
and will not be repeated, reseeded or extended.

## New original-source support inequalities

The next construction keeps the same source domains and mode-coupled coordinates,
but replaces clipped convex exterior polygons with direct inequalities
`n dot z >= lower`. Candidate integer normals come from exact rational source-hull
differences. For each normal, the lower bound uses the largest actual source
support difference across every applicable mode alias, plus 0.23 mm times an
integer upper bound on the normal's Euclidean length. No floating source symmetry
or clipped-domain boundary is needed to prove this separator safe.

[Independent support readback]({NAME}/support-halfplane-audit.json) verifies
**174 candidate halfplanes and 576 exact original-source support proofs**.
Minimum certified Euclidean gap is **0.23000000000000054 mm**. Exact rectangle
intersection checks prove six halfplanes empty in their complete coordinate
domains. Thirteen more are contained in retained choices; every cover chain
terminates at a retained halfplane. No original placement is excluded by a
global infeasibility claim.

The new representation retains **155 halfplanes and 148 unchanged certified
concave pockets**, giving **26,538 expanded choices and 53,070 guarded planes**.
All 66 cog-control pairs still pass: 49 use halfplanes and 17 use pockets.
The complete halfplane preparation takes **0.688040 seconds**. With all prior
source preparation, [the next construction's charge before model building]({NAME}/next-preparation-charges.json)
is **3.931019 seconds**. The future complete build must still be charged.

## Preserved audit correction and next model

The first halfplane audit passes all numeric/source/clip/control checks, then
fails an overly broad input-lineage assertion. Historical source provenance
contains 464 older model/search bindings. A [separate correction]({NAME}/audit-correction.json)
preserves the original producer wording, failed auditor and process; version 2
records those historical bindings and verifies that the **current failed
individual-cog model and search are absent** from the new geometry's input graph.
All numerical assertions and source geometry bytes remain unchanged. Only the
corrected independent audit is rerun; source preparation and solver calls are not.

[The next full-model plan]({NAME}/next-step.json) preserves all owners, modes,
canonical links, class coupling and rigid component checks. Halfplane choices use
lower bounds, while pocket choices retain their upper-bound planes. Every field,
the new partial-control mapping and complete costs must pass independent readback
before one newly frozen call under the same 2 GiB and 60/90-second limits.
No such model or call is opened here. Full66 source/native/material validation,
production integration and the complete unchanged H5 matrix remain required.

[The prior checkpoint reached main c339bc7a normally]({NAME}/prior-push-receipt.json)
after all six previous checks passed, preserving all 52 remote files.
[Current CI at report review]({NAME}/main-ci-at-review.json) is retained; no live
run is cancelled. Production, READMEs and release assets are unchanged.

[The archive]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) preserve all consumed evidence.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 individual-cog model and support halfplanes:** [full model, process and new source audits]({link}) verify 29,310 variables and 102,383 constraints for all 28 movers and 108 modes. The sole call reaches search after presolve, then stops at the 2 GiB monitored memory limit without any solver response, incumbent or assignment. All descendants close; the 4,313,088-byte peak overshoot and 38.762725-second preparation-inclusive process remain recorded. No solver status or exclusion is invented, and the call stays closed. A distinct geometry representation has 576 exact source support proofs, 155 retained halfplanes and 148 unchanged concave pockets, reducing proposed guarded planes from 97,284 to 53,070 and choices to 26,538. Its 66 cog-control pairs pass; charged source preparation is 3.931019 s before the next complete model build. A preserved lineage-scope audit failure is corrected separately without changing geometry or repeating preparation. The new complete model and independent readback are next; no new call is prepared. Four fixed arrangements and 440 allocations remain, with H2/H5 open at 60%. Main c339bc7a was pushed normally after all six prior checks passed, preserving 52 remote files; no release is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
s=s[:a]+f'''Latest H5 evidence: [individual-cog search and support halfplanes](../benchmarks/results/{NAME}.md).
The complete 28-mover model passes all 29,310 variable and 102,383 constraint
checks. Its sole call stops at the monitored 2 GiB memory limit without a solver
response or placement; all descendants close and the memory overshoot is preserved.
The call stays closed. Fresh original-source support inequalities reduce the
next model's guarded geometry planes to 53,070, with all 108 source modes retained.
Source, exact clipping, cover-chain and partial-control checks pass. A complete
new model and independent serialized-model audit are next, before one bounded call.
Four fixed arrangements and all 440 allocations remain; full66 source/material/
native checks and the full H5 gate are open. H2/H5 stay open at 60%.
The preceding checkpoint reached main c339bc7a after all six prior checks passed;
its current CI snapshot is preserved in the report. No release is made.
'''+s[b:]
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'closed_solver_calls':1,'source_valid66':False})
