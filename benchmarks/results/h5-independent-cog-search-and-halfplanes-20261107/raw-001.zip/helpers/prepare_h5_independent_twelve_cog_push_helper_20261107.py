from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/push_h5_twelve_cog_543_checkpoint_20261107.py').read_text(encoding='utf-8')
s=s.replace('h5-twelve-cog-543-main-sync-20261107','h5-independent-twelve-cog-main-sync-20261107').replace('9e8782435232308c3c17411b414e0be0f281ce5d','3baf15d164fb03dca5be7d460c6d4c1496ad6445').replace('42328915911','42331520271')
s=s.replace("prefixes=('benchmarks/results/h5-twelve-cog-row-construction-20261107','benchmarks/results/h5-twelve-cog-543-constructions-20261107')","prefixes=('benchmarks/results/h5-independent-twelve-cog-preparation-20261107',)")
needle="OUT.mkdir();write(OUT/'prior-main-ci.json',ci)"
assert needle in s
s=s.replace(needle,"assert json.loads((ROOT/'benchmarks/results/h5-independent-twelve-cog-preparation-20261107/archive-checks.json').read_bytes())['passed']\n"+needle)
ast.parse(s)
with (ROOT/'output/push_h5_independent_twelve_cog_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared guarded ordinary push helper; push not executed.')
