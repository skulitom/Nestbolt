"""Complete28-mover construction with mode-coupled individual-cog coordinates."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';OUT=BASE/'model';PRE=ROOT/'output/h5-independent-twelve-cog-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'] and load(PRE/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
model=cp_model.CpModel();modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');aliases=load(BASE/'aliases.json');templates={t['class']:t for t in load(BASE/'templates.json')}
def linear(co,lo,hi,guard=None):
    expr=sum(c*model.get_int_var_from_proto_index(i) for i,c in co.items() if c);ct=model.add_linear_constraint(expr,lo,hi)
    if guard is not None:ct.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return ct.index
owners=[]
for i,item in enumerate(instances):
    opts=modes[item['identity'][0]];coords=[model.new_int_var(min(m['integer_world_lower_left_bounds'][k][0] for m in opts),max(m['integer_world_lower_left_bounds'][k][1] for m in opts),f'world_{i}_{k}_grid').index for k in [0,1]]
    owners.append({'owner':i,'identity':item['identity'],'positions':coords,'modes':[]})
for owner in owners:
    i=owner['owner']
    for mode in modes[owner['identity'][0]]:
        sel=model.new_bool_var(f'mode_{i}_{mode["mode"]}').index
        owner['modes'].append({**mode,'selector':sel,'stock_constraints':[linear({owner['positions'][k]:1},*mode['integer_world_lower_left_bounds'][k],sel) for k in [0,1]]})
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
pairs=[];links=region_count=plane_count=class_marginals=0
for pi,source in enumerate(load(BASE/'owner-pairs.json')):
    ai,bi=source['owners'];a,b=owners[ai],owners[bi];record={**source,'pair':pi,'canonical_positions':None,'coordinate_links':[],'regions':[],'class_marginals':[]}
    if source['kind']=='cog_orthogonal':
        family=b['identity'][0];maps=[r for r in aliases if r['family']==family];coords=[]
        for k in [0,1]:coords.append(model.new_int_var(min(r['canonical_relative_grid_bounds'][k][0] for r in maps),max(r['canonical_relative_grid_bounds'][k][1] for r in maps),f'canonical_{ai}_{bi}_{k}_grid').index)
        record['canonical_positions']=coords
        for mode in b['modes']:
            alias=next(r for r in maps if r['mode']==mode['mode']);q=alias['matrix'];shift=alias['offset_grid'];cts=[]
            for k in [0,1]:
                co={coords[k]:1}
                for j in [0,1]:co[b['positions'][j]]=-q[k][j];co[a['positions'][j]]=q[k][j]
                cts.append(linear(co,shift[k],shift[k],mode['selector']));links+=1
            record['coordinate_links'].append({'mode':mode['mode'],'selector':mode['selector'],'class':alias['class'],'matrix':q,'offset_grid':shift,'constraints':cts})
    for cid in source['classes']:
        template=templates[cid]
        for region in template['regions']:
            if region['region'] not in template['retained_region_ids']:continue
            rid=region['region'];sel=model.new_bool_var(f'pair_region_{pi}_{cid}_{rid}').index;cts=[]
            for ei in region['retained_edges']:
                plane=region['planes'][ei];nx,ny=plane['coefficients']
                if source['kind']=='cog_orthogonal':co={record['canonical_positions'][0]:nx,record['canonical_positions'][1]:ny}
                else:co={b['positions'][0]:nx,b['positions'][1]:ny,a['positions'][0]:-nx,a['positions'][1]:-ny}
                cts.append(linear(co,cp_model.INT_MIN,plane['upper'],sel));plane_count+=1
            record['regions'].append({'class':cid,'region':rid,'selector':sel,'source_edges':region['retained_edges'],'constraints':cts});region_count+=1
    record['one_region_constraint']=linear({r['selector']:1 for r in record['regions']},1,1)
    if source['kind']=='cog_orthogonal':
        for cid in source['classes']:
            mode_ids={r['mode'] for r in aliases if r['family']==b['identity'][0] and r['class']==cid};ms=[m['selector'] for m in b['modes'] if m['mode'] in mode_ids];rs=[r['selector'] for r in record['regions'] if r['class']==cid]
            record['class_marginals'].append({'class':cid,'mode_selectors':ms,'region_selectors':rs,'constraint':linear({**{v:-1 for v in ms},**{v:1 for v in rs}},0,0)});class_marginals+=1
    pairs.append(record)
rectangles=load(BASE/'mode-rectangles.json');components=[];rectangle_links=0
for item in load(BASE/'components.json'):
    owner=owners[item['owner']];family=owner['identity'][0];piece=item['piece'];coords=[]
    for k,label in enumerate(['left','bottom','right','top']):
        lo=min(m['integer_world_lower_left_bounds'][k%2][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes']);hi=max(m['integer_world_lower_left_bounds'][k%2][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        coords.append(model.new_int_var(lo,hi,f'rect_{item["component"]}_{label}_grid').index)
    record={**item,'coordinates':coords,'mode_links':[]}
    for mode in owner['modes']:
        offsets=rectangles[family][mode['mode']]['rectangles'][piece]['outward_offsets_grid'];cts=[linear({coords[k]:1,owner['positions'][k%2]:-1},v,v,mode['selector']) for k,v in enumerate(offsets)]
        rectangle_links+=len(cts);record['mode_links'].append({'mode':mode['mode'],'mode_selector':mode['selector'],'offsets':offsets,'constraints':cts})
    components.append(record)
separations=[]
for item in load(BASE/'component-pairs.json'):
    ai,bi=item['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];sels=[];cts=[]
    for d,co in enumerate([{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]):
        sel=model.new_bool_var(f'separate_{ai}_{bi}_{d}').index;sels.append(sel);cts.append(linear(co,cp_model.INT_MIN,-23,sel))
    separations.append({**item,'selectors':sels,'constraints':cts,'one_direction_constraint':linear({v:1 for v in sels},1,1)})
symmetry=[]
for family in ['bracket','insert','cog']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):symmetry.append({'family':family,'owners':[a['owner'],b['owner']],'constraint':linear({a['positions'][0]:1,b['positions'][0]:-1},cp_model.INT_MIN,0)})
hints={};control=load(BASE/'control-positions.json');selected={tuple(r['owners']):r['region'] for r in load(BASE/'control-regions.json')}
for owner,xy in zip(owners[16:],control):
    hints.update({owner['positions'][0]:xy[0],owner['positions'][1]:xy[1]-210000,owner['modes'][0]['selector']:1})
for pair in pairs:
    if pair['kind']=='cog_cog':hints.update({r['selector']:int(r['region']==selected[tuple(pair['owners'])]) for r in pair['regions']})
for i,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(i),v)
mapping={'owners':owners,'cog_interactions':pairs,'rigid_components':components,'rectangle_separations':separations,'symmetry_constraints':symmetry,'partial_cog_hint':[[i,v] for i,v in sorted(hints.items())],'position_units_per_mm':100,'world_origin_mm':[0,2100],'rectangle_gap_grid':23};write(OUT/'mapping.json',mapping)
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert validation=='';assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
elapsed=time.perf_counter()-started;charges=load(PRE/'preparation-charges.json');charges['cp_model_build_seconds']=elapsed;write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),BASE/'audit/plan.json',BASE/'audit/checks.json',PRE/'plan.json',PRE/'checks.json',PRE/'preparation-charges.json']+list(BASE.glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Complete28-mover satisfaction model with56 world coordinates, all108 mode selectors and all258 cog interactions. Every cog/orthogonal pair has two exact canonical relative coordinates linked under every original mode by the audited signed permutation and integer shift. Region class marginals enforce that same source mode; every retained certified halfplane applies to those coordinates. All66 cog/cog pairs use independent world differences. All24 rigid source component rectangles,640 source-mode links and268 different-owner separations remain. Same-family interchangeable copies receive X ordering, including all12 cogs as required by the nonnegative cog-pair domain. Partial hint contains only12 source-valid cog positions, their12 fixed modes and66 complete integer region selections. No objective, rigid cog row, fixed-site choice or capacity table is used. Charge all previous consumed preparation and complete model process before one fresh60/90-second call.','algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'original_movers':28,'independent_cogs':12,'world_position_variables':56,'source_mode_selectors':108,'canonical_relative_variables':384,'canonical_coordinate_links':links,'region_class_marginals':class_marginals,'region_selectors':region_count,'guarded_region_planes':plane_count,'rigid_components':24,'rigid_component_coordinate_links':rectangle_links,'different_owner_component_pairs':len(separations),'same_family_order_constraints':len(symmetry),'partial_cog_hint_values':len(hints),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_required':True,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
