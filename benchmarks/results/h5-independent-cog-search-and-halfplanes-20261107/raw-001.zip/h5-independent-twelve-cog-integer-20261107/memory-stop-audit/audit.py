"""A bounded process failure is not a solver response or an infeasibility proof."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,re
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'memory-stop-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();queue=[MODEL/'plan.json',BASE/'model-audit/plan.json',SEARCH/'opened.json',SEARCH/'supervisor-opened.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
ma=load(BASE/'model-audit/checks.json');opened=load(SEARCH/'opened.json');process=load(SEARCH/'process.json');job=load(SEARCH/'job.json');supervisor=load(SEARCH/'supervisor-opened.json');budget=load(SEARCH/'budget.json')
assert ma['passed'] and digest(MODEL/'model.pb')==digest(SEARCH/'model.pb')==ma['model_sha256']==opened['model_sha256']
proto=cp_model_pb2.CpModelProto();proto.ParseFromString((SEARCH/'model.pb').read_bytes());assert len(proto.variables)==ma['variables_verified']==29310 and len(proto.constraints)==ma['constraints_verified']==102383
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters())
assert {f.name for f,v in params.ListFields()}=={'max_time_in_seconds','random_seed','num_search_workers','log_search_progress','log_to_stdout','ignore_subsolvers'}
assert params.max_time_in_seconds==opened['parameters']['max_time_in_seconds']>0 and params.num_search_workers==4 and params.random_seed==0 and params.log_search_progress and not params.log_to_stdout and list(params.ignore_subsolvers)==['fj']
charge=load(MODEL/'budget.json')['preparation_seconds_charged'];assert charge==sum(load(MODEL/'final-preparation-charges.json').values())==ma['complete_preparation_seconds_charged']==opened['preparation_seconds_charged']==budget['preparation_seconds_charged']==supervisor['preparation_seconds_charged']
assert opened['maximum_calls']==budget['maximum_calls']==1 and not opened['retry_permitted'] and not budget['retry_permitted'] and not supervisor['retry_permitted'] and not process['repeat_permitted']
assert charge+params.max_time_in_seconds<=56 and opened['algorithm_seconds']==budget['algorithm_seconds']==60 and opened['shared_seconds']==budget['shared_seconds']==90
assert job==process['job'] and job['reason_code']==3 and job['error_code']==0 and job['root_exit_code']==process['exit_code']==124
assert job['assigned_before_resume'] and job['resumed'] and job['closed'] and job['active_processes']==0 and process['closed'] and process['tree_closed'] and not process['timeout']
assert job['job_committed_memory_limit']==supervisor['aggregate_memory_bytes']==2*1024**3 and job['peak_job_committed_memory']>=job['job_committed_memory_limit']
assert job['maximum_ms']==supervisor['maximum_ms'] and job['complete_ms']<job['maximum_ms'] and process['seconds_including_preparation']>=charge+job['complete_ms']/1000
controls=load(ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json');assert controls['passed'];control=next(c for c in controls['controls'] if c['control']=='memory');assert control['job']['reason_code']==3 and control['runner_exit_code']==124 and control['job']['closed']
missing=['response.pb','result.json','assignment.json','assignment-check.json','source-response'];assert not any((SEARCH/n).exists() for n in missing) and not list((SEARCH/'incumbents').iterdir())
log=(SEARCH/'solver.log').read_text(encoding='utf-8');matches=re.findall(r'Starting search at ([0-9.]+)s with 4 workers\.',log);assert len(matches)==1 and 'CpSolverResponse summary:' not in log
assert "#Model   9.17s var:29098/29098 constraints:124289/124289" in log
for name in ['stderr.txt','stdout.txt','supervisor-stderr.txt','supervisor-stdout.txt']:assert (SEARCH/name).read_bytes()==b''
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',MODEL/'budget.json',MODEL/'final-preparation-charges.json',ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json']+[p for p in SEARCH.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently bind the complete audited model, parsed solver parameters, all preparation charges, supervisor and raw child outputs. The calibrated Windows Job reason3 proves a memory stop with no active descendants. The log proves one search started after presolve; absence of result/response/assignment/incumbents proves no usable result was returned. Preserve the peak above the polled memory cap. Do not synthesize UNKNOWN/INFEASIBLE, invent branches or returned solve time, or claim a source/allocation exclusion. The single call is closed and cannot be repeated.'})
result={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings_verified':len(bindings),'closed_solver_calls':1,'observed_result':'process-memory-stop-no-solver-response','solver_status':None,'solver_search_started':True,'presolve_log_seconds':float(matches[0]),'presolved_variables_in_log':29098,'presolved_constraints_in_log':124289,'variables_verified':29310,'constraints_verified':102383,'incumbents':0,'assignments':0,'source_checker_calls':0,'source_valid66':False,'preparation_seconds_charged':charge,'allocated_solve_seconds':params.max_time_in_seconds,'returned_solve_seconds':None,'job_complete_seconds':job['complete_ms']/1000,'shared_seconds_including_preparation':process['seconds_including_preparation'],'shared_overrun_seconds':max(0.,process['seconds_including_preparation']-90),'memory_limit_bytes':job['job_committed_memory_limit'],'peak_job_committed_memory_bytes':job['peak_job_committed_memory'],'peak_over_memory_threshold_bytes':job['peak_job_committed_memory']-job['job_committed_memory_limit'],'all_descendants_closed':True,'retry_permitted':False,'independent_unsat_certificate_available':False,'any_allocation_excluded':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
