"""New one-inequality hull separators with exact original-source support bounds."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';D=ROOT/'output/h5-independent-twelve-cog-geometry-20261107'
OUT=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def affine(points,m):
    c,s=F(math.cos(m['rotation_radians'])),F(math.sin(m['rotation_radians']));sgn=-1 if m['mirrored'] else 1;tx,ty=map(F,m['translation_from_lower_left'])
    return [(sgn*F(x)*c-F(y)*s+tx,sgn*F(x)*s+F(y)*c+ty) for x,y in points]
def clip(bounds,co,lower):
    x0,x1=bounds[0];y0,y1=bounds[1];poly=[(F(x0),F(y0)),(F(x1),F(y0)),(F(x1),F(y1)),(F(x0),F(y1))];result=[]
    value=lambda p:sum(c*x for c,x in zip(co,p))-lower
    for a,b in zip(poly,poly[1:]+poly[:1]):
        va,vb=value(a),value(b)
        if va>=0:result.append(a)
        if (va<0<vb) or (vb<0<va):
            f=va/(va-vb);result.append((a[0]+f*(b[0]-a[0]),a[1]+f*(b[1]-a[1])))
    return hull(result)
assert load(I/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB]+[I/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','aliases.json','templates.json','owner-pairs.json','control-positions.json','control-regions.json','instances.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A distinct positive representation replaces every clipped convex-hull exterior polygon by one original-source support halfplane. Obtain candidate integer normals from exact rational convex hull differences; compute each separator lower bound from the maximum actual source support over all mode aliases plus0.23mm times an integer upper bound on the normal Euclidean length. This proves clearance globally along the halfplane and avoids artificial clipping edges. Retain every previously certified integer concave-pocket region. Remove only halfplanes proved empty on the complete template coordinate rectangle or contained in another active halfplane there, using exact rational clipping. Independently verify every source-support certificate, complete clip, dominance chain and control pair before a new model. No previous model, failed search or response is consumed; all earlier source preparation remains chargeable.','grid_units_per_mm':100,'normal_scale':1000000,'support_clearance_mm':'0.23','preparation_target_seconds':20,'complete_process_cap_seconds':30,'independent_audit_cap_seconds':60,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'solver_calls':0})
parts={p['id']:p for p in load(JOB)['parts']};modes=load(I/'family-modes.json');cg=affine(parts['cog']['geometry'][0]['outer'],modes['cog'][0]);aliases=load(I/'aliases.json');old=load(I/'templates.json');templates=[];source_cases={}
for t in old:
    cid=t['class'];cases=[]
    if cid=='cog_cog':cases=[{'family':'cog','mode':0,'fixed':cg,'moving':cg}]
    else:
        for a in aliases:
            if a['class']!=cid:continue
            q=a['matrix'];shift=a['offset_grid'];moving=affine(parts[a['family']]['geometry'][0]['outer'],modes[a['family']][a['mode']])
            fixed=[tuple(sum(q[k][j]*p[j] for j in [0,1])+F(shift[k],100) for k in [0,1]) for p in cg]
            moving=[tuple(sum(q[k][j]*p[j] for j in [0,1]) for k in [0,1]) for p in moving]
            cases.append({'family':a['family'],'mode':a['mode'],'fixed':fixed,'moving':moving})
    source_cases[cid]=cases;ref=cases[0];a,b=hull(ref['fixed']),hull(ref['moving']);obstacle=hull([(x-u,y-v) for x,y in a for u,v in b]);normals=set()
    for p,q in zip(obstacle,obstacle[1:]+obstacle[:1]):
        dx,dy=q[0]-p[0],q[1]-p[1];den=max(abs(dx),abs(dy));raw=[round(dy/den*1000000),round(-dx/den*1000000)];div=math.gcd(*map(abs,raw));assert div>0;normals.add(tuple(v//div for v in raw))
    halfplanes=[]
    for index,co in enumerate(sorted(normals)):
        norm2=sum(x*x for x in co);upper=math.isqrt(norm2)
        if upper*upper<norm2:upper+=1
        proofs=[];requirements=[]
        for case in cases:
            ma=max(sum(c*x for c,x in zip(co,p)) for p in case['fixed']);mb=min(sum(c*x for c,x in zip(co,p)) for p in case['moving']);threshold=ma-mb+F(23,100)*upper;requirements.append(threshold)
            proofs.append({'family':case['family'],'mode':case['mode'],'maximum_fixed_support':str(ma),'minimum_moving_support':str(mb),'threshold_mm':str(threshold)})
        lower=math.ceil(max(requirements)*100);poly=clip(t['relative_grid_bounds'],co,lower)
        halfplanes.append({'halfplane':index,'coefficients':list(co),'lower':lower,'normal_squared_length':norm2,'normal_length_integer_upper':upper,'source_supports':proofs,'domain_intersection_grid':[[str(x),str(y)] for x,y in poly],'empty_on_domain':not bool(poly),'covered_by':None})
    active={p['halfplane'] for p in halfplanes if not p['empty_on_domain']}
    for p in halfplanes:
        if p['halfplane'] not in active:continue
        poly=[tuple(map(F,v)) for v in p['domain_intersection_grid']]
        for q in halfplanes:
            if q['halfplane'] not in active or q is p:continue
            if not all(sum(c*x for c,x in zip(q['coefficients'],v))>=q['lower'] for v in poly):continue
            reverse=all(sum(c*x for c,x in zip(p['coefficients'],v))>=p['lower'] for v in [tuple(map(F,w)) for w in q['domain_intersection_grid']])
            if reverse and q['halfplane']>p['halfplane']:continue
            p['covered_by']=q['halfplane'];active.remove(p['halfplane']);break
    pockets=[r for r in t['regions'] if r['kind']=='concave_pocket' and r['region'] in t['retained_region_ids']]
    assert active or pockets
    templates.append({'class':cid,'relative_grid_bounds':t['relative_grid_bounds'],'halfplanes':halfplanes,'retained_halfplane_ids':sorted(active),'pockets':pockets})
    assert time.perf_counter()-start<20
positions=load(I/'control-positions.json');cg_template=templates[3];controls=[]
for a,b in combinations(range(12),2):
    d=[positions[b][k]-positions[a][k] for k in [0,1]];selected=None
    for p in cg_template['halfplanes']:
        if p['halfplane'] in cg_template['retained_halfplane_ids'] and sum(c*x for c,x in zip(p['coefficients'],d))>=p['lower']:selected={'kind':'halfplane','id':p['halfplane']};break
    if selected is None:
        for r in cg_template['pockets']:
            if all(sum(c*x for c,x in zip(p['coefficients'],d))<=p['upper'] for p in r['planes']):selected={'kind':'pocket','id':r['region']};break
    assert selected,(a,b,d);controls.append({'owners':[a+16,b+16],'relative_grid':d,**selected})
lookup={t['class']:t for t in templates};pairs=load(I/'owner-pairs.json')
expanded=sum(len(lookup[c]['retained_halfplane_ids'])+len(lookup[c]['pockets']) for p in pairs for c in p['classes'])
expanded_planes=sum(len(lookup[c]['retained_halfplane_ids'])+sum(len(r['retained_edges']) for r in lookup[c]['pockets']) for p in pairs for c in p['classes'])
for name,data in [('templates.json',templates),('control-regions.json',controls)]:write(OUT/name,data)
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-start,'classes':4,'original_source_aliases':13,'candidate_halfplanes':sum(len(t['halfplanes']) for t in templates),'exact_source_supports':sum(len(p['source_supports']) for t in templates for p in t['halfplanes']),'empty_halfplanes':sum(p['empty_on_domain'] for t in templates for p in t['halfplanes']),'covered_halfplanes':sum(p['covered_by'] is not None for t in templates for p in t['halfplanes']),'retained_halfplanes':sum(len(t['retained_halfplane_ids']) for t in templates),'retained_pockets':sum(len(t['pockets']) for t in templates),'expanded_selectors':expanded,'expanded_guarded_planes':expanded_planes,'previous_expanded_selectors':27594,'previous_expanded_guarded_planes':97284,'integer_cog_control_pairs':66,'independent_source_audit_required':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
