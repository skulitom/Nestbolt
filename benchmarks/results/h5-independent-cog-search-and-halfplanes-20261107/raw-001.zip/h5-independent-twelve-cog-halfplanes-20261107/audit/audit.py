"""Independent exact support, box clipping, cover-chain and partial-control proof."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';OUT=BASE/'audit';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107'
PROCESS=ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
assert load(I/'audit/checks.json')['passed'];parts={p['id']:p for p in load(JOB)['parts']};modes=load(I/'family-modes.json');aliases=load(I/'aliases.json');old=load(I/'templates.json');templates=load(BASE/'templates.json')
def points(family,mode):
    a,b=map(F,[math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians'])]);sgn=-1 if mode['mirrored'] else 1;tx,ty=map(F,mode['translation_from_lower_left'])
    return [(tx+sgn*F(x)*a-F(y)*b,ty+sgn*F(x)*b+F(y)*a) for x,y in parts[family]['geometry'][0]['outer']]
def transformed(v,q,offset):return [tuple(sum(F(q[k][j])*p[j] for j in [0,1])+F(offset[k],100) for k in [0,1]) for p in v]
cg=points('cog',modes['cog'][0]);count=empty=covered=pockets_count=0;minimum=math.inf;chains=[];max_activity=0
assert len(templates)==4 and [t['class'] for t in templates]==[0,1,2,'cog_cog']
for t,prior in zip(templates,old):
    assert t['class']==prior['class'] and t['relative_grid_bounds']==prior['relative_grid_bounds'];cid=t['class'];bounds=t['relative_grid_bounds'];cases={}
    if cid=='cog_cog':cases['cog',0]=(cg,cg)
    else:
        for alias in aliases:
            if alias['class']!=cid:continue
            family,mid=alias['family'],alias['mode'];cases[family,mid]=(transformed(cg,alias['matrix'],alias['offset_grid']),transformed(points(family,modes[family][mid]),alias['matrix'],[0,0]))
    assert len(cases)==(1 if cid=='cog_cog' else 4)
    normals=set();polygons={}
    for index,p in enumerate(t['halfplanes']):
        co=p['coefficients'];lower=p['lower'];assert p['halfplane']==index and tuple(co) not in normals and math.gcd(*map(abs,co))==1;normals.add(tuple(co));assert all(abs(v)<=1000000 for v in co)
        norm2=sum(v*v for v in co);nu=p['normal_length_integer_upper'];assert norm2==p['normal_squared_length']>0 and (nu-1)**2<norm2<=nu**2
        supports=p['source_supports'];assert [(s['family'],s['mode']) for s in supports]==list(cases);required=[]
        for support,(a,b) in zip(supports,cases.values()):
            maximum=max(co[0]*x+co[1]*y for x,y in a);minimum_b=min(co[0]*x+co[1]*y for x,y in b);threshold=maximum-minimum_b+F(23,100)*nu
            assert F(support['maximum_fixed_support'])==maximum and F(support['minimum_moving_support'])==minimum_b and F(support['threshold_mm'])==threshold;required.append(threshold)
            gap=F(lower,100)-maximum+minimum_b;assert gap>0 and gap*gap>=F(23,100)**2*norm2;minimum=min(minimum,float(gap)/math.sqrt(norm2));count+=1
        target=max(required)*100;assert F(lower)>=target>F(lower-1)
        # Independently enumerate every box corner and all boundary intersections.
        x0,x1=map(F,bounds[0]);y0,y1=map(F,bounds[1]);corners=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)];vertices=[]
        evaluate=lambda v:co[0]*v[0]+co[1]*v[1]-lower
        vertices.extend(v for v in corners if evaluate(v)>=0)
        for a,b in zip(corners,corners[1:]+corners[:1]):
            va,vb=evaluate(a),evaluate(b)
            if va==vb:continue
            if min(va,vb)<=0<=max(va,vb):
                f=va/(va-vb);assert 0<=f<=1;vertices.append((a[0]+f*(b[0]-a[0]),a[1]+f*(b[1]-a[1])))
        poly=hull(vertices);assert [[str(x),str(y)] for x,y in poly]==p['domain_intersection_grid'] and p['empty_on_domain']==(len(poly)==0);polygons[index]=poly
        if not poly:empty+=1;assert p['covered_by'] is None
        activity=max(abs(co[0]*x+co[1]*y) for x,y in corners);assert activity<2**53 and abs(lower)<2**53;max_activity=max(max_activity,activity)
    for p in t['halfplanes']:
        if p['covered_by'] is None:continue
        covered+=1;assert polygons[p['halfplane']];chain=[p['halfplane']];current=p
        while current['covered_by'] is not None:
            target=current['covered_by'];assert target not in chain and 0<=target<len(t['halfplanes']);q=t['halfplanes'][target];assert polygons[target]
            assert all(sum(c*x for c,x in zip(q['coefficients'],v))>=q['lower'] for v in polygons[current['halfplane']]);chain.append(target);current=q
        assert current['halfplane'] in t['retained_halfplane_ids'];chains.append({'class':cid,'chain':chain})
    assert t['retained_halfplane_ids']==[p['halfplane'] for p in t['halfplanes'] if not p['empty_on_domain'] and p['covered_by'] is None]
    assert t['pockets']==[r for r in prior['regions'] if r['kind']=='concave_pocket' and r['region'] in prior['retained_region_ids']];pockets_count+=len(t['pockets'])
    assert time.perf_counter()-start<55
positions=load(I/'control-positions.json');controls=load(BASE/'control-regions.json');assert len(controls)==66;cg_template=templates[3];halfplane_controls=0
for r,(a,b) in zip(controls,combinations(range(12),2)):
    delta=[positions[b][k]-positions[a][k] for k in [0,1]];assert r['owners']==[a+16,b+16] and r['relative_grid']==delta
    if r['kind']=='halfplane':
        assert r['id'] in cg_template['retained_halfplane_ids'];p=cg_template['halfplanes'][r['id']];assert sum(c*x for c,x in zip(p['coefficients'],delta))>=p['lower'];halfplane_controls+=1
    else:
        assert r['kind']=='pocket';region=next(p for p in cg_template['pockets'] if p['region']==r['id']);assert all(sum(c*x for c,x in zip(p['coefficients'],delta))<=p['upper'] for p in region['planes'])
lookup={t['class']:t for t in templates};pairs=load(I/'owner-pairs.json');expanded=sum(len(lookup[c]['retained_halfplane_ids'])+len(lookup[c]['pockets']) for p in pairs for c in p['classes'])
planes=sum(len(lookup[c]['retained_halfplane_ids'])+sum(len(r['retained_edges']) for r in lookup[c]['pockets']) for p in pairs for c in p['classes'])
prep=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json');summary=load(BASE/'checks.json');assert prep['passed'] and prep['job']['closed'] and prep['job']['active_processes']==0 and prep['complete_seconds']<=30 and prep['complete_seconds']>=summary['seconds_including_evidence_serialization'] and summary['seconds_including_evidence_serialization']<=20
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert (summary['exact_source_supports'],summary['empty_halfplanes'],summary['covered_halfplanes'],summary['retained_pockets'],summary['expanded_selectors'],summary['expanded_guarded_planes'])==(count,empty,covered,pockets_count,expanded,planes)
assert not any('/model/' in name or '/search/' in name or '/model-audit/' in name or '/memory-stop-audit/' in name for name in bindings)
write(OUT/'source-bindings.json',bindings);write(OUT/'cover-chains.json',chains)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,I/'audit/plan.json',I/'audit/checks.json']+list(BASE.glob('*.json'))+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct every actual affine source outline and exact mode-coupled coordinates. For every integer normal and source alias prove the separator lower bound yields at least0.23mm Euclidean gap using an exact squared comparison. Enumerate all rectangle corners and boundary-line intersections to verify every complete continuous clipped domain, empty result and cover-chain implication. Verify unchanged certified concave-pocket bytes and all66 source-control integer pair choices. Source-safe halfplanes are unbounded outside their support line; finite rectangles serve only valid redundancy proofs. No prior solver model or response is consumed, no full66 feasibility or global infeasibility is claimed.'})
result={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings_verified':len(bindings),'candidate_integer_halfplanes':sum(len(t['halfplanes']) for t in templates),'exact_source_support_proofs':count,'minimum_halfplane_source_gap_mm':minimum,'empty_halfplanes_verified':empty,'covered_halfplanes_verified':covered,'retained_halfplanes':sum(len(t['retained_halfplane_ids']) for t in templates),'retained_certified_pockets':pockets_count,'expanded_selectors':expanded,'expanded_guarded_planes':planes,'previous_expanded_guarded_planes':97284,'integer_cog_control_pairs':66,'control_halfplanes':halfplane_controls,'control_pockets':66-halfplane_controls,'maximum_halfplane_activity':int(max_activity),'complete_halfplane_preparation_seconds':prep['complete_seconds'],'old_model_or_solver_in_input_graph':False,'independent_model_audit_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
