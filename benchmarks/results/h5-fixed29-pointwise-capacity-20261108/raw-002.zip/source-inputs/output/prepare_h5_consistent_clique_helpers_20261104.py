from pathlib import Path
O=Path(__file__).resolve().parent
renames={'mandatory_clique_insert_bounds':'consistent_insert_bounds','clique_pruned_areas':'consistent_pruned_areas','mandatory_occupancy':'consistent_occupancy'}
paths={'h5-first57-mandatory-clique-insert-bounds':'h5-first57-consistent-insert-bounds','h5-first57-clique-pruned-areas':'h5-first57-consistent-pruned-areas','h5-first57-mandatory-occupancy':'h5-first57-consistent-occupancy'}
for stem in renames:
    for kind in ['prepare','audit','run']:
        old=f'{kind}_h5_{stem}_20261104.py';s=(O/old).read_text(encoding='utf-8')
        for a,b in paths.items():s=s.replace(a,b)
        for a,b in renames.items():s=s.replace(f'{a}_20261104.py',f'{b}_20261104.py')
        if kind!='run':
            s=s.replace("load(BR/f'choice-{i:02d}.json')","refined_br(i)").replace("load(BR/f'choice-{choice:02d}.json')","refined_br(choice)")
            marker="load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()\n"
            assert marker in s
            s=s.replace(marker,marker+"""AC=ROOT/'output/h5-first57-mandatory-clique-consistency-20261104'
def refined_br(index):
    assert load(AC/'audit/checks.json')['passed']
    data=load(BR/f'choice-{index:02d}.json');refined=load(AC/f'choice-{index:02d}.json')
    assert refined['empty_sites']==data['empty_sites'] and not refined['diagnostic_excluded']
    assert len(refined['remaining_cliques'])==len(data['cliques'])==8
    for clique,nodes in zip(data['cliques'],refined['remaining_cliques']):
        assert nodes and set(nodes)<=set(clique['nodes']);clique['nodes']=nodes
    return data
""")
            s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_consistent_clique_helpers_20261104.py',AC/'audit/plan.json',AC/'audit/checks.json',AC/'choice-00.json',AC/'choice-01.json',AC/'choice-02.json',")
            if kind=='prepare':s=s.replace("'method':'","'method':'Use the independently verified surviving bracket nodes after mandatory-clique consistency; every valid packing remains covered. ")
        new=f'{kind}_h5_{renames[stem]}_20261104.py'
        with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared distinct follow-up bounds using certified bracket-node eliminations; no solver calls.')
