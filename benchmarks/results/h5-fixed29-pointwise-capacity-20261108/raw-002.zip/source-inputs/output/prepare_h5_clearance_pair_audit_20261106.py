from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_union_conflict_edges_20261106.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-union-conflict-edges-20261106','h5-first57-clearance-pair-edges-20261106')
s=s.replace('h5-first57-union-conflict-edges-process-20261106','h5-first57-clearance-pair-edges-process-20261106')
s=s.replace('h5-first57-joint-optional-trees-20261106','h5-first57-clearance-cog-trees-20261106')
s=s.replace("load=lambda p:", "CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'\nAUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'\nJOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'\nload=lambda p:",1)
s=s.replace("inputs={Path(__file__),","inputs={Path(__file__),ROOT/'output/prepare_h5_clearance_pair_audit_20261106.py',ROOT/'output/audit_h5_union_conflict_edges_20261106.py',JOB,CLEAR/'plan.json',")
s=s.replace("PROBE/'audit-v2']:","PROBE/'audit-v2',CLEAR/'audit-v2',AUG/'audit']:")
a="selection=[r for r in load(INS/'audit/joint-candidates.json') if tuple(r['empty_sites']) in remaining]"
b="selection=[r|{'clearance_pruning_index':i} for i,r in enumerate(load(CLEAR/'plan.json')['selection']) if tuple(r['empty_sites']) in remaining]"
assert a in s;s=s.replace(a,b)
s=s.replace('len(selection)==52','len(selection)==28')
a="geometry=load(SOURCE/'geometry-domains.json');point_checks=[0]"
b="""plan=load(BASE/'plan.json')
assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2
assert plan['pair_expansion_square_radius_um']==140 and not plan['zero_clearance_exclusion_claimed']
assert 2*140**2<200**2
for x,y in product([-140,140],repeat=2):assert x*x+y*y<200**2
geometry=load(SOURCE/'geometry-domains.json');point_checks=[0]"""
assert a in s;s=s.replace(a,b)
a="    edges=data['added_conflict_edges'];"
b="""    domain_path=CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json"
    old_path=AUG/f"choice-{row['augmentation_index']:02d}.json";inputs.update([domain_path,old_path])
    domain=load(domain_path);old=load(old_path)
    assert domain['empty_sites']==old['empty_sites']==row['empty_sites']
    retained=set(domain['retained_bracket_nodes']+domain['retained_insert_nodes'])
    old_edges=set(map(tuple,old['added_conflict_edges']))
    edges=data['added_conflict_edges'];"""
assert a in s;s=s.replace(a,b)
s=s.replace("assert 0<=a<b<len(nodes)","assert 0<=a<b<len(nodes) and a in retained and b in retained and (a,b) not in old_edges")
s=s.replace("        assert covered(box,rectangles)","        expanded=[[r[0]-140,r[1]-140,r[2]+140,r[3]+140] for r in rectangles]\n        assert covered(box,expanded)")
s=s.replace("'augmentation_index':choice","'clearance_edge_index':choice")
start=s.index("    'proof':");end=s.index("\nresult=",start)
s=s[:start]+"""    'proof':'The authoritative original job requires0.2mm clearance. Each axis-square expansion vector has squared Euclidean norm at most2*140^2<200^2 micrometres squared. Exact rectangle Minkowski differences plus this square are contained in the source-distance forbidden region. Independently reconstruct every full closed relative-anchor box and expanded component rectangle. Replay every Cartesian boundary/open-interval class with strict exact doubled-integer membership. Each edge joins two retained parent cells and is absent from prior single-component and saved union edges, so it genuinely strengthens the recorded necessary graph. Existing complete domains and edges remain valid; missing scan edges merely weaken the relaxation. This proves required-clearance pair conflicts, not necessarily zero-clearance overlap. Partial scans make no augmentation-completeness claim and no whole-arrangement exclusion follows without a later complete tree.'})
""" +s[end:]
s=s.replace("'whole_arrangements_excluded':0,'remaining_fixed29_choices':52,'total_fixed29_choices_excluded':403,","'required_job_clearance_mm':0.2,'pair_expansion_square_radius_um':140,'zero_clearance_exclusion_claimed':False,\n    'whole_arrangements_excluded':0,'remaining_fixed29_choices':28,'total_fixed29_choices_excluded':427,")
with (O/'audit_h5_clearance_pair_edges_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent original-clearance and every-edge replay.')
