"""One bounded union-coverage scan on four new refined source domains."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-refined-polygon-union-20261107'
G=ROOT/'output/h5-six-polygon-clearance-v2-20261107';RAW=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';FRONT=ROOT/'output/h5-polygon-sat-batch-20261107/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(G/'audit/checks.json')['passed'] and load(FRONT/'checks.json')['passed']
selection=sorted(load(FRONT/'remaining-source-graphs.json'),key=lambda r:r['refinement_index']);assert len(selection)==4
inputs=[Path(__file__),G/'audit/plan.json',G/'audit/checks.json',G/'collision-polygons.json',G/'cells.json',RAW/'integer-source.json',FRONT/'checks.json',FRONT/'remaining-source-graphs.json',ROOT/'output/prepare_h5_cog_union_subdivision_20261106.py']
for row in selection:inputs.extend(ROOT/row['graph']/n for n in ['nodes.json','root-covers.json','conflicts.bin','checks.json'])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':selection,'maximum_subdivision_depth':8,'maximum_expanded_nodes_per_query':511,'query_search_cutoff_seconds':0.02,'query_complete_cap_seconds':0.05,'global_query_cutoff_seconds':25,'preparation_cap_seconds':35,'maximum_process_seconds':45,'repeat_permitted':False,'solver_calls':0,'native_validation_calls':0,'full_construction_budget_claimed':False,'method':'Current refined child cells and sixteen-direction clearance polygons are distinct from the closed old coarse/unexpanded union scan. Exact integer closed-child subdivision proves coverage by the union of present-cog source collision polygons. Only completely covered roots are removed; all limited/unproved cells and every alias/boundary remain. Restrict the certified parent graph and clique partition exactly to retained nodes. No new solver call is justified by an unchanged case.'})
raw=load(RAW/'integer-source.json');D=int(raw['scaled_units_per_micrometre']);shifts=[tuple(map(int,s['translation_scaled'])) for s in raw['sites']]
cells=load(G/'cells.json');keys={(c['geometry'],*c['bounds_um']):c['cell'] for c in cells};templates=load(G/'collision-polygons.json')
world=[];bygeom={g:[] for g in range(10)}
for t in templates:
    for site,(sx,sy) in enumerate(shifts):
        poly=[(int(x)+sx,int(y)+sy) for x,y in t['vertices_scaled']];planes=[]
        for a,b in zip(poly,poly[1:]+poly[:1]):
            nx,ny=a[1]-b[1],b[0]-a[0];planes.append((nx,ny,-nx*a[0]-ny*a[1]))
        w={'site':site,'geometry':t['geometry'],'bounds':(min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly)),'planes':planes}
        bygeom[t['geometry']].append(len(world));world.append(w)
def meets(a,b):return a[0]<=b[2] and b[0]<=a[2] and a[1]<=b[3] and b[1]<=a[3]
def box_inside(box,pi):return all(nx*(box[0] if nx>=0 else box[2])+ny*(box[1] if ny>=0 else box[3])+c>0 for nx,ny,c in world[pi]['planes'])
def point_inside(point,pi):return all(nx*point[0]+ny*point[1]+c>0 for nx,ny,c in world[pi]['planes'])
candidate_cache={};querykeys={};queries=[];results=[]
for row in selection:
    old=ROOT/row['graph'];nodes=load(old/'nodes.json');folder=OUT/f"choice-{row['refinement_index']:02d}";folder.mkdir()
    omitted=set(row['empty_sites']);references=[];removed=[]
    for ni,node in enumerate(nodes):
        ci=keys[node['geometry'],*node['bounds_um']];box=tuple(v*D for v in node['bounds_um'])
        if ci not in candidate_cache:candidate_cache[ci]=tuple(pi for pi in bygeom[node['geometry']] if meets(box,world[pi]['bounds']))
        candidates=tuple(pi for pi in candidate_cache[ci] if world[pi]['site'] not in omitted);key=(ci,candidates)
        if key not in querykeys:
            qi=len(queries);querykeys[key]=qi;records=[];qstart=time.perf_counter();deadline=min(start+25,qstart+0.02);expanded=[0]
            def visit(bounds,depth,allowed,skip=False):
                index=len(records);record={'node':index};records.append(record)
                if skip:record.update({'kind':'open','reason':'earlier_unproved_child'});return index,False
                if time.perf_counter()>=deadline or expanded[0]>=511:
                    record.update({'kind':'open','reason':'time_or_node_limit','query_elapsed':time.perf_counter()-qstart,'global_elapsed':time.perf_counter()-start});return index,False
                expanded[0]+=1;allowed=[pi for pi in allowed if meets(bounds,world[pi]['bounds'])]
                for pi in allowed:
                    if box_inside(bounds,pi):record.update({'kind':'closed_source_polygon','polygon':pi});return index,True
                samples=[((bounds[0]+bounds[2])//2,(bounds[1]+bounds[3])//2)]+list(product([bounds[0],bounds[2]],[bounds[1],bounds[3]]))
                for point in samples:
                    if not any(point_inside(point,pi) for pi in allowed):record.update({'kind':'open_source_inner_sample','point_scaled':list(map(str,point))});return index,False
                if depth>=8:record.update({'kind':'open','reason':'depth_limit'});return index,False
                axis=max(range(2),key=lambda a:bounds[a+2]-bounds[a]);cut=(bounds[axis]+bounds[axis+2])//2
                if not bounds[axis]<cut<bounds[axis+2]:record.update({'kind':'open','reason':'no_interior_split'});return index,False
                lo=list(bounds);hi=list(bounds);lo[axis+2]=cut;hi[axis]=cut
                left,lc=visit(tuple(lo),depth+1,allowed);right,rc=visit(tuple(hi),depth+1,allowed,skip=not lc)
                record.update({'kind':'split','axis':axis,'cut_scaled':str(cut),'left':left,'right':right});return index,lc and rc
            root,closed=visit(box,0,list(candidates));elapsed=time.perf_counter()-qstart
            queries.append({'query':qi,'source_cell':ci,'candidate_polygons':list(candidates),'root':root,'records':records,'expanded_nodes':expanded[0],'query_seconds':elapsed,'query_complete_cap_overrun_seconds':max(0,elapsed-0.05),'whole_closed_cell_covered':closed})
        qi=querykeys[key];references.append({'node':ni,'query':qi})
        if queries[qi]['whole_closed_cell_covered']:removed.append({'node':ni,'query':qi})
    removedids={r['node'] for r in removed};kept=[i for i in range(len(nodes)) if i not in removedids];newnodes=[nodes[i] for i in kept];inverse={v:i for i,v in enumerate(kept)}
    N=len(nodes);oldgraph=np.unpackbits(np.frombuffer((old/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(N,(N+7)//8),axis=1,bitorder='little')[:,:N]
    graph=oldgraph[np.ix_(kept,kept)];covers=[[[inverse[i] for i in group if i in inverse] for group in family] for family in load(old/'root-covers.json')];covers=[[group for group in family if group] for family in covers]
    (folder/'conflicts.bin').write_bytes(np.packbits(graph,axis=1,bitorder='little').tobytes())
    for name,value in [('nodes.json',newnodes),('kept-old-node-ids.json',kept),('removed.json',removed),('node-queries.json',references),('root-covers.json',covers)]:write(folder/name,value)
    checks={'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source_selection':row['source_selection'],'old_graph':row['graph'],'original_nodes':N,'compact_nodes':len(newnodes),'bracket_nodes':sum(n['family']==0 for n in newnodes),'insert_nodes':sum(n['family']==1 for n in newnodes),'row_bytes':(len(newnodes)+7)//8,'removed_nodes':len(removed),'added_edges':0,'genuinely_stronger':bool(removed),'root_clique_counts':list(map(len,covers)),'conflict_bytes_sha256':digest(folder/'conflicts.bin')}
    write(folder/'checks.json',checks);results.append(checks);assert time.perf_counter()-start<35
    print(json.dumps(checks),flush=True)
write(OUT/'queries.json',queries);elapsed=time.perf_counter()-start
write(OUT/'checks.json',{'prepared':True,'seconds':elapsed,'choices':results,'unique_queries':len(queries),'tree_records':sum(len(q['records']) for q in queries),'closed_whole_cell_queries':sum(q['whole_closed_cell_covered'] for q in queries),'new_removed_nodes':sum(r['removed_nodes'] for r in results),'query_cap_overrun_seconds':sum(q['query_complete_cap_overrun_seconds'] for q in queries),'solver_calls':0,'native_validation_calls':0,'independent_audit_pending':True,'H5_complete':False})
assert elapsed<35
