"""New complete optional-clique proof method on the 67 unprocessed bracket covers."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-optional-bracket-trees-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104'
FRONTIER=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def members(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask-=bit
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(BR/'audit/checks.json')['passed'] and load(FRONTIER/'audit/checks.json')['passed']
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[{'choice_index':i,'empty_sites':r['empty_sites'],'nodes':r['nodes'],
            'root_clique_count':r['continuous_bracket_capacity_upper_bound']}
           for i,r in enumerate(load(BR/'audit/checks.json')['choices'])
           if tuple(r['empty_sites']) in remaining and r['continuous_bracket_capacity_upper_bound']>8]
assert len(selection)==67 and len(remaining)==68
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='conflict']
assert len(functions)==1;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json',FRONTIER/'audit/remaining-fixed29-choices.json']+[b/n for b in [BR,FRONTIER] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'per_choice_seconds':0.45,'maximum_expanded_nodes_per_choice':5000,
    'preparation_cap_seconds':40,'maximum_process_seconds':50,'global_search_cutoff_seconds':35,
    'stop_case_after_first_necessary_graph_witness':True,'repeat_permitted':False,
    'method':'Use every source-certified cell of each of the 67 complete bracket covers above eight. An exact source-inner conflict graph is a necessary relaxation. At each node bound the possible remaining independent cells by a complete pairwise-conflicting clique partition. Fewer cliques than required closes a leaf. Otherwise choose one whole clique: branch once on every cell in it, retaining every compatible candidate on inclusion, plus a branch skipping the whole clique. The clique admits at most one original bracket, so this exhausts every possibility. Stop at eight compatible cells with a necessary graph witness, never a source placement. Preserve explicit open leaves for every budget cutoff or unvisited branch. Only independent complete tree replay may exclude a fixed arrangement.',
    'placement_solver_calls':0,'native_calls':0})
summaries=[]
for choice,row in enumerate(selection):
    case_started=time.perf_counter();deadline=min(started+35,case_started+0.45)
    data=load(BR/f"choice-{row['choice_index']:02d}.json")
    nodes=data['nodes'];assert len(nodes)==row['nodes'] and data['empty_sites']==row['empty_sites']
    original=[sum(1<<n for n in c['nodes']) for c in data['cliques']]
    assert len(original)==row['root_clique_count']
    universe=(1<<len(nodes))-1;compatible={n:0 for n in range(len(nodes))}
    graph_complete=True
    for a in range(len(nodes)):
        if time.perf_counter()>=deadline:graph_complete=False;break
        for b in range(a+1,len(nodes)):
            if conflict(nodes[a],nodes[b]) is None:
                compatible[a]|=1<<b;compatible[b]|=1<<a
    conflicting={n:universe&~compatible[n] for n in compatible}
    records=[];witness=None;expanded=0
    def cover(mask,need):
        best=[g&mask for g in original if g&mask]
        if len(best)<need:return best
        vertices=list(members(mask))
        for order in [vertices,sorted(vertices,key=lambda n:(-(conflicting[n]&mask).bit_count(),n))]:
            groups=[]
            for v in order:
                possible=[i for i,g in enumerate(groups) if not g&~conflicting[v]]
                if possible:
                    i=max(possible,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
                else:groups.append(1<<v)
            if len(groups)<len(best):best=groups
            if len(best)<need:break
        return best
    def visit(available,chosen):
        global expanded,witness
        index=len(records);record={'node':index};records.append(record)
        if not graph_complete or witness is not None or time.perf_counter()>=deadline or expanded>=5000:
            record.update({'kind':'open','reason':'graph_preparation_limit' if not graph_complete else 'earlier_necessary_graph_witness' if witness is not None else 'time_or_expansion_limit'})
            return index
        expanded+=1;need=8-len(chosen)
        if need==0:
            witness=chosen;record.update({'kind':'open_graph_witness','witness':chosen});return index
        groups=cover(available,need)
        if len(groups)<need:
            record.update({'kind':'closed_count_cover','cover':[list(members(g)) for g in groups]});return index
        group=min(groups,key=lambda g:(g.bit_count(),next(members(g))))
        values=list(members(group));record.update({'kind':'branch_clique','clique':values,'children':[]})
        for value in values:
            record['children'].append({'value':value,'node':visit(available&compatible[value],chosen+[value])})
        record['skip']=visit(available&~group,list(chosen))
        return index
    root=visit(universe,[])
    open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
    result={'source_selection':row,'empty_sites':row['empty_sites'],'graph_complete':graph_complete,
            'root':root,'records':records,'expanded_nodes':expanded,'open_nodes':open_nodes,
            'necessary_graph_witness':witness,'case_seconds':time.perf_counter()-case_started,
            'diagnostic_excluded':not open_nodes}
    write(OUT/f'choice-{choice:02d}.json',result)
    summary={k:v for k,v in result.items() if k not in ['records','open_nodes','source_selection','necessary_graph_witness']}|{'records':len(records),'open_leaves':len(open_nodes),'has_necessary_graph_witness':witness is not None}
    summaries.append(summary);print(summary,flush=True)
    assert time.perf_counter()-started<40
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,
    'independent_tree_audit_pending':True,'source_valid66':False,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
