from pathlib import Path
O=Path(__file__).resolve().parent
for kind in ['prepare','audit']:
    s=(O/f'{kind}_h5_consistent_insert_bounds_20261104.py').read_text(encoding='utf-8')
    s=s.replace('h5-first57-consistent-insert-bounds-20261104','h5-first57-frontier-insert-bounds-20261106')
    s=s.replace('h5-first57-local-conflict-covers-20261104','h5-first57-full-frontier-cliques-20261104')
    s=s.replace('h5-first57-mandatory-clique-consistency-20261104','h5-first57-frontier-clique-consistency-20261104')
    a=s.index('def refined_br(index):');b=s.index('def write(',a)
    s=s[:a]+'''selection=load(AC/'audit/consistent-mandatory-choices.json')
assert len(selection)==20 and len({r['choice_index'] for r in selection})==20
def refined_br(index):
    assert load(AC/'audit/checks.json')['passed']
    row=selection[index]
    data=load(BR/f"choice-{row['choice_index']:02d}.json")
    refined=load(AC/f"choice-{row['consistency_index']:02d}.json")
    assert refined['empty_sites']==data['empty_sites']==row['empty_sites'] and not refined['diagnostic_excluded']
    assert data['bracket_capacity_upper_bound']==8 and len(refined['remaining_cliques'])==len(data['cliques'])==8
    for clique,nodes in zip(data['cliques'],refined['remaining_cliques']):
        assert nodes and set(nodes)<=set(clique['nodes']);clique['nodes']=nodes
    return data
'''+s[b:]
    common="""inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_insert_helpers_20261106.py',SOURCE/'geometry-domains.json',AC/'audit/consistent-mandatory-choices.json']+[b/n for b in [BR,AC] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]+[AC/f"choice-{r['consistency_index']:02d}.json" for r in selection]+[COVER/f'geometry-{g:02d}-cover.json' for g in [8,9]]"""
    lines=s.splitlines()
    for i,line in enumerate(lines):
        if line.startswith('inputs='):lines[i]=common+("+[HELPER]" if kind=='prepare' else "+[BASE/'plan.json',BASE/'checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(len(selection))]")
    s='\n'.join(lines)+'\n'
    if kind=='prepare':
        s=s.replace("for choice,bc in enumerate(load(BR/'audit/checks.json')['choices']):\n    assert bc['every_clique_mandatory_for_eight_brackets']","for choice,row in enumerate(selection):")
        s=s.replace("'method':'","'method':'Process all20 independently retained mandatory bracket choices, preserving their original frontier and consistency indices. ")
        s=s.replace("data={'empty_sites':empty","data={'source_selection':row,'empty_sites':empty")
    else:
        s=s.replace("for base in [BASE,BR/'audit']:","for base in [BASE,BR/'audit',AC/'audit']:")
        s=s.replace("for choice,empty in enumerate([[0,4,14],[5,11,13],[5,11,14]]):","for choice,row in enumerate(selection):\n    empty=row['empty_sites']")
        s=s.replace("assert data['empty_sites']==br['empty_sites']==empty","assert data['source_selection']==row\n    assert data['empty_sites']==br['empty_sites']==empty")
        a=s.index('inputs=[Path(__file__),')
        s=s[:a]+"""prior=load(AC/'audit/remaining-fixed29-choices.json');assert len(prior)==87
excluded={tuple(r['empty_sites']) for r in checks if r['excluded']}
remaining=[r for r in prior if tuple(r['empty_sites']) not in excluded]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'joint-distribution-candidates.json',[{'insert_choice_index':i,**selection[i],'insert_cliques':r['continuous_insert_capacity_upper_bound']} for i,r in enumerate(checks) if not r['excluded']])
"""+s[a:]
        s=s.replace("'whole_allocations_excluded':0","'previous_fixed29_choices_excluded':368,'remaining_fixed29_choices':len(remaining),'total_fixed29_choices_excluded':368+len(excluded),'whole_allocations_excluded':0")
    with (O/f'{kind}_h5_frontier_insert_bounds_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_consistent_insert_bounds_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-consistent-insert-bounds','h5-first57-frontier-insert-bounds').replace('20261104','20261106')
s=s.replace('prepare_h5_consistent_insert_bounds','prepare_h5_frontier_insert_bounds')
with (O/'run_h5_frontier_insert_bounds_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared complete20-case insert pruning and independent source/index/coverage certificate replay.')
