from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_clearance_cog_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace("OUT=ROOT/'output/h5-first57-clearance-cog-trees-20261106'","OUT=ROOT/'output/h5-first57-clearance-pair-trees-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-clearance-cog-trees-20261106'")
s=s.replace("SOURCE=ROOT/","PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'\nSOURCE=ROOT/",1)
s=s.replace("assert load(PRUNE/'audit-v2/checks.json')['passed']","assert load(PRUNE/'audit-v2/checks.json')['passed'] and load(PAIR/'audit/checks.json')['passed']")
a="selection=[r['source_selection']|{'clearance_pruning_index':r['clearance_pruning_index']} for r in load(PRUNE/'audit-v2/stronger-model-candidates.json')]\nassert len(selection)==27"
b="selection=[r['source_selection']|{'clearance_edge_index':r['clearance_edge_index']} for r in load(PAIR/'audit/stronger-model-candidates.json')]\nassert len(selection)==28"
assert a in s;s=s.replace(a,b)
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_clearance_pair_tree_helpers_20261106.py',ROOT/'output/prepare_h5_clearance_cog_trees_20261106.py',PAIR/'audit/stronger-model-candidates.json',PAIR/'audit/plan.json',PAIR/'audit/checks.json',")
a='for r in selection]\nwrite(OUT/'
b='for r in selection]+[PAIR/f"choice-{r[\'clearance_edge_index\']:02d}.json" for r in selection]\nwrite(OUT/'
assert a in s;s=s.replace(a,b,1)
s=s.replace("assert pruning['empty_sites']==row['empty_sites'] and pruning['removed']","assert pruning['empty_sites']==row['empty_sites']")
a="    for a,b in augmentation['added_conflict_edges']:blocked[a,b]=blocked[b,a]=True"
b="""    pair_edges=load(PAIR/f"choice-{row['clearance_edge_index']:02d}.json")
    assert pair_edges['empty_sites']==row['empty_sites'] and pair_edges['added_conflict_edges']
    for a,b in augmentation['added_conflict_edges']+pair_edges['added_conflict_edges']:blocked[a,b]=blocked[b,a]=True"""
assert a in s;s=s.replace(a,b)
s=s.replace("'graph_complete':graph_complete,","'graph_complete':graph_complete,'new_clearance_pair_edges':len(pair_edges['added_conflict_edges']),")
start=s.index("    'method':");end=s.index('\nsummaries=[]',start)
s=s[:start]+"""    'pair_expansion_square_radius_um':140,
    'method':'Distinct necessary model on28 cases, all with newly independently certified required-clearance pair edges. Preserve complete certified clearance-cog root domains and every prior pair edge. New edges use exact unions of source-inner difference rectangles expanded by a140 micrometre axis square inside the200 micrometre clearance ball. Fresh0.70/0.75-second case caps,1500 nodes and50/55/65 global caps. Complete include/skip trees alone exclude fixed29/current cog poses at required0.2mm clearance. Partial trees remain unresolved and graph witnesses are not source placements. No previous process is repeated or extended.'})
""" +s[end:]
with (O/'prepare_h5_clearance_pair_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_clearance_cog_trees_20261106.py').read_text(encoding='utf-8').replace('clearance-cog-trees','clearance-pair-trees').replace('prepare_h5_clearance_cog_trees','prepare_h5_clearance_pair_trees')
with (O/'run_h5_clearance_pair_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared distinct28-case clearance-pair trees.')
