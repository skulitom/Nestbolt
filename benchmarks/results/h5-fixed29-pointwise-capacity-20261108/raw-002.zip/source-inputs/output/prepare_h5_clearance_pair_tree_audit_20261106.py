from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_clearance_cog_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first57-clearance-cog-trees-20261106'","BASE=ROOT/'output/h5-first57-clearance-pair-trees-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-clearance-cog-trees-20261106'")
s=s.replace('h5-first57-clearance-cog-trees-process-20261106','h5-first57-clearance-pair-trees-process-20261106')
s=s.replace("SOURCE=ROOT/","PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'\nSOURCE=ROOT/",1)
s=s.replace("inputs={Path(__file__),","inputs={Path(__file__),ROOT/'output/prepare_h5_clearance_pair_tree_audit_20261106.py',ROOT/'output/audit_h5_clearance_cog_trees_20261106.py',PAIR/'audit/stronger-model-candidates.json',")
s=s.replace("PRUNE/'audit-v2',SUB/'audit']:","PRUNE/'audit-v2',SUB/'audit',PAIR/'audit']:")
s=s.replace("for base in [BR,INS,FRONTIER,AUG,SUB]:","for base in [BR,INS,FRONTIER,AUG,SUB,PAIR]:")
a="selection=[r['source_selection']|{'clearance_pruning_index':r['clearance_pruning_index']} for r in load(PRUNE/'audit-v2/stronger-model-candidates.json')]\nassert len(selection)==27"
b="selection=[r['source_selection']|{'clearance_edge_index':r['clearance_edge_index']} for r in load(PAIR/'audit/stronger-model-candidates.json')]\nassert len(selection)==28"
assert a in s;s=s.replace(a,b)
s=s.replace("total_added=0;point_checks=[0]","total_added=0;new_clearance_edges=0;point_checks=[0]")
s=s.replace("assert pruning['empty_sites']==row['empty_sites'] and pruning['removed']","assert pruning['empty_sites']==row['empty_sites']")
s=s.replace("assert removed<=parent_b|parent_i and removed","assert removed<=parent_b|parent_i")
a="    evaluated=[0]\n    @lru_cache"
b="""    pair_path=PAIR/f"choice-{row['clearance_edge_index']:02d}.json";inputs.add(pair_path);pair_data=load(pair_path)
    assert pair_data['empty_sites']==row['empty_sites']
    pair_edges=set(map(tuple,pair_data['added_conflict_edges']))
    assert pair_edges and len(pair_edges)==len(pair_data['added_conflict_edges'])==data['new_clearance_pair_edges']
    assert not pair_edges.intersection(edges)
    retained=set(pruning['retained_bracket_nodes']+pruning['retained_insert_nodes'])
    assert plan['pair_expansion_square_radius_um']==140 and 2*140**2<200**2
    for a,b in pair_edges:
        assert 0<=a<b<len(nodes) and a in retained and b in retained and not exact_conflict(nodes[a],nodes[b])
        left,right=nodes[a],nodes[b]
        box=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]+[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
        rectangles=[[ra[0]-rb[2]-140,ra[1]-rb[3]-140,ra[2]-rb[0]+140,ra[3]-rb[1]+140]
                    for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um'])]
        assert covered(box,rectangles)
    new_clearance_edges+=len(pair_edges)
    edges.update(pair_edges)
    evaluated=[0]
    @lru_cache"""
assert a in s;s=s.replace(a,b)
s=s.replace("'clearance_root_removals_verified':root_removals,","'new_clearance_pair_edges_verified':new_clearance_edges,'pair_expansion_square_radius_um':140,'clearance_root_removals_verified':root_removals,")
s=s.replace("and each of27 cases has a strictly smaller certified domain.","and every retained parent cell remains.")
s=s.replace("This is a genuinely stronger necessary problem; prior union edges are retained.","Every case has newly replayed pair edges from expanded source-inner differences. Their140 micrometre square has maximum squared norm2*140^2<200^2, so complete relative-box coverage proves a violation of the original clearance. All28 graphs have genuinely new certified edges; prior union edges and the retained root domains remain.")
with (O/'audit_h5_clearance_pair_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent28-case clearance pair and full-tree replay.')
