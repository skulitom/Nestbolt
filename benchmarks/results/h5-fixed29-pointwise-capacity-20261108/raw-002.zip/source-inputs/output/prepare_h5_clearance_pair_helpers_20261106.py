from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_union_conflict_edges_20261106.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-union-conflict-edges-20261106','h5-first57-clearance-pair-edges-20261106')
s=s.replace('h5-first57-joint-optional-trees-20261106','h5-first57-clearance-cog-trees-20261106')
s=s.replace("HELPER=ROOT/", "CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'\nAUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'\nJOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'\nHELPER=ROOT/",1)
s=s.replace("PROBE/'audit-v2/checks.json']:","PROBE/'audit-v2/checks.json',CLEAR/'audit-v2/checks.json',AUG/'audit/checks.json']:")
a="selection=[r for r in load(INS/'audit/joint-candidates.json') if tuple(r['empty_sites']) in remaining];assert len(selection)==52"
b="""selection=[r|{'clearance_pruning_index':i} for i,r in enumerate(load(CLEAR/'plan.json')['selection']) if tuple(r['empty_sites']) in remaining];assert len(selection)==28
assert load(JOB)['clearance']==0.2 and 2*140**2<200**2"""
assert a in s;s=s.replace(a,b)
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_clearance_pair_helpers_20261106.py',ROOT/'output/prepare_h5_union_conflict_edges_20261106.py',JOB,CLEAR/'plan.json',CLEAR/'audit-v2/plan.json',CLEAR/'audit-v2/checks.json',AUG/'audit/plan.json',AUG/'audit/checks.json',")
a='for r in selection]\nwrite(OUT/'
b='for r in selection]+[CLEAR/f"choice-{r[\'clearance_pruning_index\']:02d}.json" for r in selection]+[AUG/f"choice-{r[\'augmentation_index\']:02d}.json" for r in selection]\nwrite(OUT/'
assert a in s;s=s.replace(a,b,1)
start=s.index("    'method':");end=s.index("    'repeat_permitted'",start)
s=s[:start]+"""    'required_job_clearance_mm':0.2,'pair_expansion_square_radius_um':140,'zero_clearance_exclusion_claimed':False,
    'method':'Retain every certified continuous domain and prior conflict. Scan only retained node pairs. Expand each source-inner difference rectangle by a140 micrometre axis square, whose Euclidean norm is at most sqrt(2)*140<200 micrometres. Exact coverage of the closed relative-anchor box by the open expanded union proves source distance below the original required0.2mm clearance. Exclude existing single-component and saved union edges so every saved edge genuinely strengthens the current graph. Freeze0.35/0.40 case and25/30/40 global caps. Partial scans retain only independently verified edges; absence never proves compatibility. No whole arrangement is excluded by this edge preparation.',
""" + s[end:]
s=s.replace("templates={}","templates={};original_templates={}")
s=s.replace("    templates[(ga,gb)]=rects","    original_templates[(ga,gb)]=rects\n    templates[(ga,gb)]=[[r[0]-140,r[1]-140,r[2]+140,r[3]+140] for r in rects]")
a="    nodes=br['nodes']+ins['nodes'];bounds="
b="""    domain=load(CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json")
    augmentation=load(AUG/f"choice-{row['augmentation_index']:02d}.json")
    assert domain['empty_sites']==augmentation['empty_sites']==row['empty_sites']
    retained=set(domain['retained_bracket_nodes']+domain['retained_insert_nodes'])
    old_edges=set(map(tuple,augmentation['added_conflict_edges']))
    nodes=br['nodes']+ins['nodes'];bounds="""
assert a in s;s=s.replace(a,b)
s=s.replace("if n['geometry']==g]","if n['geometry']==g and i in retained]")
s=s.replace("for x,y,z,w in rects:eligible","for x,y,z,w in original_templates[(ga,gb)]:eligible")
a="            checked+=1\n            box="
b="""            edge=tuple(sorted([int(ia[ai]),int(ib[bi])]))
            if edge in old_edges:continue
            checked+=1
            box="""
assert a in s;s=s.replace(a,b)
s=s.replace("'remaining_fixed29_choices':52","'remaining_fixed29_choices':28")
with (O/'prepare_h5_clearance_pair_edges_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_union_conflict_edges_20261106.py').read_text(encoding='utf-8').replace('union-conflict-edges','clearance-pair-edges').replace('prepare_h5_union_conflict_edges','prepare_h5_clearance_pair_edges')
with (O/'run_h5_clearance_pair_edges_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared fresh retained-domain clearance pair scan.')
