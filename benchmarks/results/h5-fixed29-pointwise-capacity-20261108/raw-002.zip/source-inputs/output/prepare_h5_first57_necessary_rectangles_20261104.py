"""Exact source-contained rectangle obstacles for continuous anchor-domain bounds."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-necessary-rectangles-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def transform(v,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    p=[(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in v]
    return p if area(p)>0 else list(reversed(p))
def inside(r,p):
    return all(cross(a,b,v)>=0 for a,b in zip(p,p[1:]+p[:1]) for v in product([r[0],r[2]],[r[1],r[3]]))
def section(p,y):
    xs=[]
    for a,b in zip(p,p[1:]+p[:1]):
        if a[1]==b[1]:
            if y==a[1]:xs.extend([a[0],b[0]])
        elif min(a[1],b[1])<=y<=max(a[1],b[1]):
            xs.append(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]))
    return min(xs),max(xs)
def inward(r):
    return [math.ceil(r[0]*1000),math.ceil(r[1]*1000),math.floor(r[2]*1000),math.floor(r[3]*1000)]
def near_orthogonal_inner(p):
    eps=F('0.000001')
    r=inward([min(x for x,y in p)+eps,min(y for x,y in p)+eps,max(x for x,y in p)-eps,max(y for x,y in p)-eps])
    assert inside([F(v,1000) for v in r],p)
    return r
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),JOB,PIECES]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed29.json','source-cog-sites.json','family-modes.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Necessary relaxation from original filled source geometry. Construct exact axis rectangles inside each original cog convex piece, then translate to all15 candidate sites. Include source-contained inner rectangles for all29 fixed frame/insert originals. For each legal orthogonal moving mode, use all canonical component rectangles shrunk inward and certify their exact containment. Anchor domains cover the entire physical first-sheet stock, rounded outward; no positive-construction strip bound is imported. Zero clearance deliberately enlarges feasible geometry. These rectangles will induce open forbidden anchor boxes labelled by cog-site bits or the mandatory fixed-core bit. All open intervals and boundary points require exhaustive verification before any exclusion.',
    'coordinate_units_per_mm':1000,'preparation_cap_seconds':25,'maximum_process_seconds':35,'fixed_core_mask_bit':15,
    'required_empty_cog_sites':3,'candidate_site_triples':455,'solver_calls':0,'global_allocation_exclusion':False})
assert load(PRE/'audit/checks.json')['passed']
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);modes=load(PRE/'family-modes.json')
cg=modes['cog'][0];t={'rotation_radians':cg['rotation_radians'],'mirrored':cg['mirrored'],'translation':cg['translation_from_lower_left']}
normalized_pieces=[transform(v,t) for v in canonical['cog']];candidates=[]
for pi,p in enumerate(normalized_pieces):
    ys=sorted({v[1] for v in p});sections={y:section(p,y) for y in ys}
    for i,a in enumerate(ys):
        for b in ys[i+1:]:
            left=max(sections[a][0],sections[b][0]);right=min(sections[a][1],sections[b][1])
            r=inward([left,a,right,b])
            if r[0]<r[2] and r[1]<r[3]:
                assert inside([F(v,1000) for v in r],p)
                candidates.append({'piece':pi,'bounds_um':r})
unique={}
for r in candidates:unique.setdefault(tuple(r['bounds_um']),r)
retained=[]
for r in sorted(unique.values(),key=lambda r:-(r['bounds_um'][2]-r['bounds_um'][0])*(r['bounds_um'][3]-r['bounds_um'][1])):
    a,b,c,d=r['bounds_um']
    if not any(q['bounds_um'][0]<=a and q['bounds_um'][1]<=b and c<=q['bounds_um'][2] and d<=q['bounds_um'][3] for q in retained):retained.append(r)
sites=load(PRE/'source-cog-sites.json');world=[]
for site,row in enumerate(sites):
    assert row['transform']['rotation_radians']==cg['rotation_radians'] and row['transform']['mirrored']==cg['mirrored']
    shift=[F(row['transform']['translation'][k])-F(t['translation'][k]) for k in [0,1]]
    pieces=[transform(v,row['transform']) for v in canonical['cog']]
    for inner in retained:
        moved=[F(v,1000)+shift[k%2] for k,v in enumerate(inner['bounds_um'])];r=inward(moved)
        assert r[0]<r[2] and r[1]<r[3] and inside([F(v,1000) for v in r],pieces[inner['piece']])
        world.append({'site_bit':site,'piece':inner['piece'],'bounds_um':r})
    assert time.perf_counter()-started<25
fixed=load(PRE/'fixed29.json');fixed_rects=[]
for index,row in enumerate(fixed):
    poly=transform(parts[row['part_id']]['geometry'][0]['outer'],row['transform'])
    assert len(poly)==4 and all(cross(a,b,c)>0 for a,b,c in zip(poly,poly[1:]+poly[:1],poly[2:]+poly[:2]))
    fixed_rects.append({'fixed_owner':index,'identity':[row['part_id'],row['copy_index']],'site_bit':15,'bounds_um':near_orthogonal_inner(poly)})
stock=list(map(F,load(PRE/'plan.json')['source_stocks']['sheet-0']))
moving=[];geometries={}
for family in ['bracket','insert']:
    for mode in modes[family]:
        mt={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':mode['translation_from_lower_left']}
        rects=[near_orthogonal_inner(transform(v,mt)) for v in canonical[family]]
        outer=transform(parts[family]['geometry'][0]['outer'],mt)
        full=[stock[0]-min(x for x,y in outer),stock[1]-min(y for x,y in outer),stock[2]-max(x for x,y in outer),stock[3]-max(y for x,y in outer)]
        domain=[math.floor(full[0]*1000),math.floor(full[1]*1000),math.ceil(full[2]*1000),math.ceil(full[3]*1000)]
        record={'family':family,'mode':mode['mode'],'geometry':mode['normalized_geometry'],'source_mode':mode,'inner_rectangles_um':rects,
            'exact_stock_anchor_domain_mm':list(map(str,full)),'outward_anchor_domain_um':domain}
        moving.append(record);gid=mode['normalized_geometry']
        if gid not in geometries:geometries[gid]={'geometry':gid,'inner_rectangles_um':sorted(rects),'anchor_domain_um':domain.copy(),'aliases':[]}
        g=geometries[gid];assert g['inner_rectangles_um']==sorted(rects)
        g['aliases'].append([family,mode['mode']])
        g['anchor_domain_um']=[min(g['anchor_domain_um'][k],domain[k]) if k<2 else max(g['anchor_domain_um'][k],domain[k]) for k in range(4)]
assert set(geometries)==set(range(10)) and len(moving)==12
for name,value in [('normalized-cog-inner-rectangles.json',retained),('world-cog-inner-rectangles.json',world),('fixed-core-inner-rectangles.json',fixed_rects),
    ('moving-source-inner-rectangles.json',moving),('geometry-domains.json',[geometries[i] for i in range(10)])]:write(OUT/name,value)
checks={'prepared':True,'seconds':time.perf_counter()-started,'normalized_cog_inner_rectangles':len(retained),'world_cog_inner_rectangles':len(world),
    'fixed_core_inner_rectangles':len(fixed_rects),'legal_moving_modes':len(moving),'unique_moving_geometries':len(geometries),
    'full_physical_stock_domains':True,'zero_clearance_relaxation':True,'independent_containment_audit_pending':True,'source_mask_domains_not_built':True,
    'new_site_choices_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
