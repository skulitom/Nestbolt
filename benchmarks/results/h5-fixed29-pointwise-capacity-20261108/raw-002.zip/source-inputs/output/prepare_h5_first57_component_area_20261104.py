"""Direct body-component capacities over all455 necessary site selections."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import json,time,shutil
from shapely import box,union_all,STRtree
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
OUT=ROOT/'output/h5-first57-component-area-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def deadline():assert time.perf_counter()-started<55,'Frozen preparation cap reached; unaudited exclusions cannot be used.'
assert load(SOURCE/'audit/checks.json')['passed'] and load(COVER/'audit/checks.json')['passed']
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__)]+[SOURCE/p for p in ['geometry-domains.json','world-cog-inner-rectangles.json','fixed-core-inner-rectangles.json','audit/plan.json','audit/checks.json']]+[COVER/p for p in ['audit/plan.json','audit/checks.json']]+[COVER/f'geometry-{g:02d}-cover.json' for g in range(8)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Enumerate all455 choices directly from source-contained rectangles and the exhaustive continuous cover. Each eligible anchor box carries both swept inner bracket rectangles in one node. Merge nodes when any swept rectangles intersect. For each resulting node group, union its swept rectangles and subtract fixed source-contained obstacles. Any bracket assigned to a cover box belongs wholly to that group; area bounds its count. Sum floored group capacities. Group areas may overlap without invalidating this upper bound. Floating GEOS generation requires an independent exact integer sweep and exhaustive anchor-box assignment audit before exclusions.',
    'required_brackets':8,'required_empty_sites':3,'preparation_cap_seconds':55,'maximum_process_seconds':75,'solver_calls':0,'certified_exclusions':0,
    'not_using_prior_global_area_results':True})
geometries=load(SOURCE/'geometry-domains.json')
sources=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
fixed=union_all([box(*r['bounds_um']) for r in sources if r['site_bit']==15])
cogs=[union_all([box(*r['bounds_um']) for r in sources if r['site_bit']==i]) for i in range(15)]
allboxes=[load(COVER/f'geometry-{g:02d}-cover.json') for g in range(8)]
minimum_area=min(sum((r[2]-r[0])*(r[3]-r[1]) for r in g['inner_rectangles_um']) for g in geometries[:8])
records=[]
for index,empty in enumerate(combinations(range(15),3)):
    bits=sum(1<<i for i in empty);nodes=[];shapes=[];owners=[]
    for gid in range(8):
        for ri,row in enumerate(allboxes[gid]):
            m,x,y,z,w=row[:5]
            if m&~bits:continue
            node=len(nodes);nodes.append([gid,ri])
            for a,b,c,d in geometries[gid]['inner_rectangles_um']:
                shapes.append(box(x+a,y+b,z+c,w+d));owners.append(node)
    parent=list(range(len(nodes)))
    def root(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    def join(i,j):
        i,j=root(i),root(j)
        if i!=j:parent[max(i,j)]=min(i,j)
    edges=STRtree(shapes).query(shapes,predicate='intersects')
    for a,b in zip(*edges):join(owners[int(a)],owners[int(b)])
    grouped={}
    for i,node in enumerate(nodes):grouped.setdefault(root(i),[]).append(i)
    obstacle=union_all([fixed]+[c for i,c in enumerate(cogs) if i not in empty])
    groups=[]
    for indices in grouped.values():
        selected=set(indices)
        area=float(union_all([p for p,owner in zip(shapes,owners) if owner in selected]).difference(obstacle).area)
        groups.append({'anchor_boxes':[nodes[i] for i in indices],'reachable_area_um2':area,
                       'minimum_bracket_area_um2':minimum_area,'capacity':int(area//minimum_area)})
    row={'index':index,'empty_sites':list(empty),'eligible_anchor_boxes':len(nodes),'groups':groups,
         'bracket_capacity':sum(g['capacity'] for g in groups),'diagnostic_excluded':sum(g['capacity'] for g in groups)<8}
    write(OUT/f'choice-{index:03d}.json',row)
    records.append({k:v for k,v in row.items() if k!='groups'}|{'group_count':len(groups),'group_capacities':[g['capacity'] for g in groups]})
    deadline()
    if index%50==0:print({'completed':index+1,'seconds':time.perf_counter()-started,'diagnostic_excluded':sum(r['diagnostic_excluded'] for r in records)},flush=True)
write(OUT/'all-choices.json',records)
checks={'prepared':True,'seconds':time.perf_counter()-started,'choices':len(records),
    'diagnostic_excluded':sum(r['diagnostic_excluded'] for r in records),'diagnostic_remaining':sum(not r['diagnostic_excluded'] for r in records),
    'group_count_histogram':dict(Counter(r['group_count'] for r in records)),'capacity_histogram':dict(Counter(r['bracket_capacity'] for r in records)),
    'independent_exact_area_and_assignment_audit_pending':True,'new_site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
