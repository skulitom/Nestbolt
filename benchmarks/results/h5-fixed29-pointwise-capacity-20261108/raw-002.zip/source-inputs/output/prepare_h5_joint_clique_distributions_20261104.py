from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-joint-clique-distributions-20261104'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';AC=ROOT/'output/h5-first57-mandatory-clique-consistency-20261104';INS=ROOT/'output/h5-first57-consistent-insert-bounds-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [BR,AC,INS]:assert load(base/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='conflict'];assert len(functions)==1
exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json']+[b/n for b in [BR,AC,INS] for n in ['audit/plan.json','audit/checks.json']]+[b/f'choice-{i:02d}.json' for b in [BR,AC,INS] for i in range(3)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Enumerate every eight-of-k selection of the independently certified insert-clique cover. Every valid joint packing must occupy such a selection and all eight bracket cliques. Within each selection repeatedly remove a candidate node that conflicts for all anchors with every currently possible node in another mandatory clique. Preserve the complete ordered elimination trace and remaining domains. Only an independently replayed contradiction in every selection can exclude the continuous fixed29/cog choice.',
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'solver_calls':0,'native_calls':0})
records=[]
def members(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask-=bit
for choice in range(3):
    br=load(BR/f'choice-{choice:02d}.json');ac=load(AC/f'choice-{choice:02d}.json');ins=load(INS/f'choice-{choice:02d}.json')
    empty=br['empty_sites'];assert empty==ac['empty_sites']==ins['empty_sites'];offset=len(br['nodes']);nodes=br['nodes']+ins['nodes']
    bg=ac['remaining_cliques'];ig=[[offset+n for n in g['nodes']] for g in ins['insert_cliques']]
    eligible=sorted({n for group in bg+ig for n in group});adj={}
    for a in eligible:
        mask=0
        for b in eligible:
            if a!=b and conflict(nodes[a],nodes[b]) is None:mask|=1<<b
        adj[a]=mask
    branches=[]
    for selected in combinations(range(len(ig)),8):
        original=bg+[ig[i] for i in selected];active=[sum(1<<n for n in group) for group in original];trace=[];rounds=0
        while all(active):
            rounds+=1;changed=False
            for own in range(16):
                for node in list(members(active[own])):
                    for other in range(16):
                        if own!=other and not active[other]&adj[node]:
                            trace.append([node,own,other]);active[own]&=~(1<<node);changed=True;break
                    if not active[own]:break
                if not all(active):break
            if not changed:break
        branches.append({'insert_cliques':list(selected),'ordered_removals':trace,'remaining_cliques':[list(members(m)) for m in active],'rounds':rounds,'diagnostic_excluded':not all(active)})
        assert time.perf_counter()-started<25
    result={'empty_sites':empty,'original_bracket_node_count':offset,'insert_clique_count':len(ig),'branches':branches,'diagnostic_excluded':all(b['diagnostic_excluded'] for b in branches)}
    write(OUT/f'choice-{choice:02d}.json',result)
    row={'empty_sites':empty,'insert_cliques':len(ig),'distributions':len(branches),'diagnostic_excluded_distributions':sum(b['diagnostic_excluded'] for b in branches),'remaining_distributions':sum(not b['diagnostic_excluded'] for b in branches),'ordered_removals':sum(len(b['ordered_removals']) for b in branches),'diagnostic_excluded':result['diagnostic_excluded']}
    records.append(row);print(row,flush=True)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':records,'independent_exact_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
