from pathlib import Path
O=Path(__file__).resolve().parent
for kind in ['prepare','audit']:
    s=(O/f'{kind}_h5_joint_clique_distributions_20261104.py').read_text(encoding='utf-8')
    s=s.replace('import ast,json,time,shutil','import ast,json,time,shutil,math').replace('import json,time,shutil','import json,time,shutil,math')
    s=s.replace('h5-first57-joint-clique-distributions-20261104','h5-first57-frontier-joint-distributions-20261106')
    s=s.replace('h5-first57-local-conflict-covers-20261104','h5-first57-full-frontier-cliques-20261104')
    s=s.replace('h5-first57-mandatory-clique-consistency-20261104','h5-first57-frontier-clique-consistency-20261104')
    s=s.replace('h5-first57-consistent-insert-bounds-20261104','h5-first57-frontier-insert-bounds-20261106')
    marker="load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()\n"
    assert marker in s
    s=s.replace(marker,marker+"""all_candidates=load(INS/'audit/joint-distribution-candidates.json')
selection=[r for r in all_candidates if math.comb(r['insert_cliques'],8)<=20000]
deferred=[r for r in all_candidates if math.comb(r['insert_cliques'],8)>20000]
assert len(all_candidates)==20 and len(selection)==15 and len(deferred)==5
assert sum(math.comb(r['insert_cliques'],8) for r in selection)==21738
""")
    s=s.replace('for choice in range(3):','for choice,row in enumerate(selection):')
    s=s.replace("load(BR/f'choice-{choice:02d}.json')",'load(BR/f"choice-{row[\'choice_index\']:02d}.json")')
    s=s.replace("load(AC/f'choice-{choice:02d}.json')",'load(AC/f"choice-{row[\'consistency_index\']:02d}.json")')
    s=s.replace("load(INS/f'choice-{choice:02d}.json')",'load(INS/f"choice-{row[\'insert_choice_index\']:02d}.json")')
    common="""inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_distribution_helpers_20261106.py',SOURCE/'geometry-domains.json',INS/'audit/joint-distribution-candidates.json',AC/'audit/remaining-fixed29-choices.json']+[b/n for b in [BR,AC,INS] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]+[AC/f"choice-{r['consistency_index']:02d}.json" for r in selection]+[INS/f"choice-{r['insert_choice_index']:02d}.json" for r in selection]"""
    lines=s.splitlines()
    for i,line in enumerate(lines):
        if line.startswith('inputs='):lines[i]=common+("+[HELPER]" if kind=='prepare' else "+[BASE/'plan.json',BASE/'checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(len(selection))]")
    s='\n'.join(lines)+'\n'
    if kind=='prepare':
        s=s.replace("'method':'","'method':'Freeze a maximum20000 eight-of-k distributions per choice: process all15 eligible cases (21738 distributions) and retain the five larger cases without exclusion. ")
        s=s.replace("'preparation_cap_seconds':25","'per_choice_distribution_limit':20000,'expected_distributions':21738,'deferred_choices':deferred,'preparation_cap_seconds':25")
        s=s.replace("result={'empty_sites':empty","result={'source_selection':row,'empty_sites':empty")
    else:
        s=s.replace("assert data['empty_sites']==br['empty_sites']==ac['empty_sites']==ins['empty_sites']","assert data['source_selection']==row\n    assert data['empty_sites']==br['empty_sites']==ac['empty_sites']==ins['empty_sites']==row['empty_sites']")
        a=s.index("assert load(CAP/'audit/checks.json')")
        b=s.index('inputs=[Path(__file__),',a)
        s=s[:a]+"""assert load(AC/'audit/checks.json')['passed']
prior=load(AC/'audit/remaining-fixed29-choices.json');assert len(prior)==87
removed=set(map(tuple,excluded));assert removed<=set(tuple(r['empty_sites']) for r in prior)
remaining=[r for r in prior if tuple(r['empty_sites']) not in removed]
assert len(remaining)==87-len(removed)
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'deferred-large-distributions.json',deferred)
"""+s[b:]
        s=s.replace("'new_fixed29_choices_excluded':3","'new_fixed29_choices_excluded':len(removed)")
        s=s.replace("'previous_fixed29_choices_excluded':196","'previous_fixed29_choices_excluded':368")
        s=s.replace("'total_fixed29_choices_excluded':199","'total_fixed29_choices_excluded':368+len(removed)")
        s=s.replace("'remaining_fixed29_choices':256","'remaining_fixed29_choices':len(remaining)")
        s=s.replace('only three fixed29 pose selections','only the completely contradicted fixed29 pose selections')
        s=s.replace('Each enumerated selection ends with an empty mandatory clique, so no continuous original-source packing can realize this fixed29 plus twelve selected cog poses, even at zero clearance.','A fixed29 choice is excluded only if every enumerated selection ends with an empty mandatory clique. Every combination is checked for each of the15 selected cases; five larger cases remain deferred without exclusion.')
        s=s.replace("'continuous_zero_clearance_exclusions':True","'continuous_zero_clearance_exclusions':True,'deferred_large_choices':len(deferred)")
    with (O/f'{kind}_h5_frontier_joint_distributions_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_joint_clique_distributions_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-joint-clique-distributions','h5-first57-frontier-joint-distributions').replace('prepare_h5_joint_clique_distributions','prepare_h5_frontier_joint_distributions').replace('20261104','20261106')
with (O/'run_h5_frontier_joint_distributions_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Frozen15-case complete joint distributions; five larger cases explicitly remain unresolved.')
