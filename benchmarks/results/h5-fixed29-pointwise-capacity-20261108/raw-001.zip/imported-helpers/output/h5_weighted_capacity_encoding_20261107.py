"""Explicit weighted prefix-threshold circuit with a checked at-most output."""
from h5_sat_encoding_20261107 import neg,simplify
def atmost(selectors,weights,limit,top):
    assert len(selectors)==len(weights) and all(type(w) is int and w>0 for w in weights) and limit>=0
    clauses=[];gates=[];prev={0:True};prefix=0;threshold=limit+1
    for i,(x,w) in enumerate(zip(selectors,weights),1):
        prefix+=w;current={0:True}
        for j in range(1,min(prefix,threshold)+1):
            top+=1;y=top;a=prev.get(j,False);b=True if j<=w else prev[j-w]
            gates.append({'i':i,'j':j,'weight':w,'x':x,'a':a,'b':b,'y':y})
            for row in [[neg(a),y],[neg(x),neg(b),y],[neg(y),a,x],[neg(y),a,b]]:
                row=simplify(row)
                if row is not None:clauses.append(row)
            current[j]=y
        prev=current
    final=prev.get(threshold,False)
    if final is not False:clauses.append([-final])
    return clauses,gates,top,final
