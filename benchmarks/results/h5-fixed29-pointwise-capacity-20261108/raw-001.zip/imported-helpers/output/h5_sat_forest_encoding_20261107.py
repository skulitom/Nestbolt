"""Factor conflict clauses through a complete interval tree of cell selectors."""
def forest(n,rows):
    tree=[];masks=[];top=n
    def build(lo,hi):
        nonlocal top
        if hi-lo==1:
            node={'node':len(tree),'lo':lo,'hi':hi,'variable':lo+1};mask=1<<lo
        else:
            mid=(lo+hi)//2;left=build(lo,mid);right=build(mid,hi);top+=1
            node={'node':len(tree),'lo':lo,'hi':hi,'variable':top,'left':left,'right':right};mask=masks[left]|masks[right]
        tree.append(node);masks.append(mask);return node['node']
    root=build(0,n);clauses=[]
    for node in tree:
        if 'left' in node:
            clauses.extend([[-tree[node[key]]['variable'],node['variable']] for key in ['left','right']])
    implications=len(clauses);blocks=[]
    for a,row in enumerate(rows):
        selected=row&~((1<<(a+1))-1)&((1<<n)-1);segments=[]
        def cover(index):
            overlap=selected&masks[index]
            if not overlap:return
            if overlap==masks[index]:segments.append(index);return
            node=tree[index];cover(node['left']);cover(node['right'])
        cover(root);blocks.append({'cell':a,'segments':segments})
        clauses.extend([[-(a+1),-tree[i]['variable']] for i in segments])
    return tree,blocks,clauses,top,implications
