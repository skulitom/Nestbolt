"""Small explicit threshold circuit; no native or opaque cardinality constraints."""
def neg(x):return not x if isinstance(x,bool) else -x
def simplify(xs):
    if any(x is True for x in xs):return None
    out=list(dict.fromkeys(x for x in xs if x is not False))
    if any(-x in out for x in out):return None
    return out
def threshold(selectors,k,top):
    clauses=[];gates=[];prev={0:True}
    for i,x in enumerate(selectors,1):
        current={0:True}
        for j in range(1,min(i,k)+1):
            top+=1;y=top;a=prev.get(j,False);b=prev[j-1]
            gate={'i':i,'j':j,'x':x,'a':a,'b':b,'y':y};gates.append(gate)
            for row in [[neg(a),y],[neg(x),neg(b),y],[neg(y),a,x],[neg(y),a,b]]:
                row=simplify(row)
                if row is not None:clauses.append(row)
            current[j]=y
        prev=current
    final=prev.get(k,False)
    clauses.append([] if final is False else [final])
    return clauses,gates,top,final
