"""Independent two-family proof replay; no preparation/search helper is imported."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
from functools import lru_cache
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-clearance-cog-trees-20261106';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106';AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106'
PRUNE=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
SUB=ROOT/'output/h5-first57-cog-union-subdivision-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';PROCESS=ROOT/'output/h5-first57-clearance-cog-trees-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/prepare_h5_clearance_cog_tree_audit_20261106.py',ROOT/'output/audit_h5_cog_pruned_trees_20261106.py',JOB,ROOT/'output/prepare_h5_cog_pruned_tree_audit_20261106.py',ROOT/'output/audit_h5_union_augmented_trees_20261106.py',PRUNE/'audit-v2/stronger-model-candidates.json',PRUNE/'integer-source.json',PRUNE/'cells.json',PRUNE/'collision-polygons.json',PRUNE/'certificates.json',ROOT/'output/prepare_h5_augmented_tree_audit_20261106.py',ROOT/'output/audit_h5_joint_optional_trees_20261106.py',ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py',FRONTIER/'audit/remaining-fixed29-choices.json',BASE/'plan.json',BASE/'checks.json',SOURCE/'geometry-domains.json',
        INS/'audit/joint-candidates.json',INS/'audit/remaining-fixed29-choices.json',
        AUG/'audit/stronger-model-candidates.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,BR/'audit',INS/'audit',FRONTIER/'audit',AUG/'audit',PRUNE/'audit-v2',SUB/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR,INS,FRONTIER,AUG,SUB]:
    inputs.add(base/'audit/checks.json');assert load(base/'audit/checks.json')['passed']
inputs.add(PRUNE/'audit-v2/checks.json');assert load(PRUNE/'audit-v2/checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
selection=[r['source_selection']|{'clearance_pruning_index':r['clearance_pruning_index']} for r in load(PRUNE/'audit-v2/stronger-model-candidates.json')]
assert len(selection)==27
plan=load(BASE/'plan.json');assert plan['selection']==selection
assert plan['every_case_has_new_source_certified_constraints']
assert plan['per_case_search_cutoff_seconds']==0.70 and plan['maximum_expanded_nodes_per_case']==1500
geometry=load(SOURCE/'geometry-domains.json');results=[];excluded=[];witnesses=[];total_evaluations=0
total_added=0;point_checks=[0]
integer_source=load(PRUNE/'integer-source.json');scale=int(integer_source['scaled_units_per_micrometre']);assert scale>0
pruning_cells=load(PRUNE/'cells.json');pruning_certificates=load(PRUNE/'certificates.json')
pruning_templates=load(PRUNE/'collision-polygons.json')
pruning_polygons=[[tuple(map(int,p)) for p in t['vertices_scaled']] for t in pruning_templates]
pruning_shifts=[tuple(map(int,r['translation_scaled'])) for r in integer_source['sites']]
root_removals=0;root_corner_checks=0;parent_union_removals=0
assert load(JOB)['clearance']==0.2
assert integer_source['required_job_clearance_mm']==0.2 and integer_source['clearance_diamond_radius_um']==199
assert 199<200
for x,y in [(199,0),(0,199),(-199,0),(0,-199)]:assert x*x+y*y==199**2<200**2
assert plan['required_job_clearance_mm']==0.2 and plan['conservative_clearance_radius_um']==199 and not plan['zero_clearance_exclusion_claimed']


helper=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
functions=[n for n in ast.parse(helper.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['classes','covered']]
assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(helper),'exec'))
def exact_conflict(left,right):
    x0,y0,x1,y1=left['bounds_um'];u0,v0,u1,v1=right['bounds_um']
    for ax0,ay0,ax1,ay1 in geometry[left['geometry']]['inner_rectangles_um']:
        for bx0,by0,bx1,by1 in geometry[right['geometry']]['inner_rectangles_um']:
            if x1+ax0<u0+bx1 and u1+bx0<x0+ax1 and y1+ay0<v0+by1 and v1+by0<y0+ay1:return True
    return False
for choice,row in enumerate(selection):
    paths=[BASE/f'choice-{choice:02d}.json',BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json"]
    inputs.update(paths);data,br,ins=map(load,paths);offset=len(br['nodes']);nodes=br['nodes']+ins['nodes']
    assert data['source_selection']==row and data['empty_sites']==br['empty_sites']==ins['empty_sites']==row['empty_sites']
    assert offset==data['original_bracket_node_count']==row['bracket_nodes']
    assert len(ins['nodes'])==row['complete_insert_cells']
    apath=AUG/f"choice-{row['augmentation_index']:02d}.json";inputs.add(apath);augmentation=load(apath)
    assert augmentation['empty_sites']==row['empty_sites'] and augmentation['added_conflict_edges']
    edges=set(map(tuple,augmentation['added_conflict_edges']))
    assert data['added_source_conflict_edges']==len(edges)==len(augmentation['added_conflict_edges'])
    for a,b in edges:
        assert 0<=a<b<len(nodes) and not exact_conflict(nodes[a],nodes[b])
        left,right=nodes[a],nodes[b]
        box=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]+[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
        rectangles=[[ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]]
                    for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um'])]
        assert covered(box,rectangles)
    total_added+=len(edges)
    ppath=PRUNE/f"choice-{row['clearance_pruning_index']:02d}.json";inputs.add(ppath);pruning=load(ppath)
    assert pruning['empty_sites']==row['empty_sites'] and pruning['removed']
    assert data['original_source_removed_nodes']==len(pruning['removed'])
    assert pruning['original_bracket_node_count']==offset and len(pruning['node_cells'])==len(nodes)
    removed=set()
    for removal in pruning['removed']:
        n=removal['node'];assert 0<=n<len(nodes) and n not in removed;removed.add(n)
        proof=pruning_certificates[removal['certificate']]
        assert proof['cell']==pruning['node_cells'][n] and proof['site'] not in row['empty_sites']
        cell=pruning_cells[proof['cell']];template=pruning_templates[proof['template']]
        assert cell['geometry']==nodes[n]['geometry']==template['geometry'] and cell['bounds_um']==nodes[n]['bounds_um']
        shift=pruning_shifts[proof['site']]
        poly=[(x+shift[0],y+shift[1]) for x,y in pruning_polygons[proof['template']]]
        x0,y0,x1,y1=cell['bounds_um']
        for a,b in zip(poly,poly[1:]+poly[:1]):
            for x,y in product([x0*scale,x1*scale],[y0*scale,y1*scale]):
                assert (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>0;root_corner_checks+=1
    parent_path=SUB/f"choice-{row['subdivision_index']:02d}.json";inputs.add(parent_path);parent=load(parent_path)
    assert parent['empty_sites']==row['empty_sites'] and parent['original_bracket_node_count']==offset
    parent_b=set(parent['retained_bracket_nodes']);parent_i=set(parent['retained_insert_nodes'])
    assert parent_b<=set(range(offset)) and parent_i<=set(range(offset,len(nodes)))
    assert removed<=parent_b|parent_i and removed
    assert pruning['retained_bracket_nodes']==sorted(parent_b-removed)
    assert pruning['retained_insert_nodes']==sorted(parent_i-removed)
    parent_union_removals+=len(parent['additional_removed'])
    root_removals+=len(removed)
    evaluated=[0]
    @lru_cache(maxsize=None)
    def conflict(a,b):
        evaluated[0]+=1
        return exact_conflict(nodes[a],nodes[b]) or tuple(sorted((a,b))) in edges
    for n in range(len(nodes)):assert conflict(n,n)
    records=data['records'];seen=set();opened=[];found=[];expanded=[0]
    stats={'branch_cliques':0,'closed_count_leaves':0,'propagation_covers':0,
           'propagation_removals':0,'mandatory_support_pair_checks':0,'clique_pair_checks':0,
           'time_or_node_limit_leaves':0,'graph_preparation_limit_leaves':0}
    def verify_cover(cover,candidates):
        flat=[v for g in cover for v in g]
        assert len(flat)==len(set(flat)) and set(flat)==candidates and all(cover)
        for group in cover:
            for a,b in combinations(group,2):
                assert conflict(a,b);stats['clique_pair_checks']+=1
    def replay(index,available,chosen):
        assert isinstance(index,int) and 0<=index<len(records) and index not in seen
        seen.add(index);record=records[index];assert record['node']==index
        available=[set(a) for a in available];chosen=[list(c) for c in chosen]
        for f in range(2):
            assert len(chosen[f])==len(set(chosen[f]))<=8 and not available[f].intersection(chosen[f])
            assert all((n<offset)==(f==0) for n in available[f]|set(chosen[f]))
            if len(chosen[f])==8:assert not available[f]
        selected=chosen[0]+chosen[1]
        for a,b in combinations(selected,2):assert not conflict(a,b)
        for a in selected:
            for b in available[0]|available[1]:assert not conflict(a,b)
        assert type(record['expanded']) is bool
        expanded[0]+=record['expanded']
        assert expanded[0]<=1500
        if not record['expanded']:assert not record['propagation'] and record['kind']=='open'
        for step in record['propagation']:
            assert record['expanded'] and data['graph_complete']
            mf=step['mandatory_family'];assert mf in [0,1]
            cover=step['cover'];verify_cover(cover,available[mf])
            assert len(cover)==8-len(chosen[mf])>0 and step['removals']
            groups=[set(g) for g in cover];stats['propagation_covers']+=1
            for f,value,group in step['removals']:
                assert f in [0,1] and value in available[f] and 0<=group<len(groups)
                targets=groups[group]&available[mf]
                assert targets and value not in targets
                for target in targets:
                    assert conflict(value,target);stats['mandatory_support_pair_checks']+=1
                available[f].remove(value);stats['propagation_removals']+=1
        kind=record['kind']
        if kind=='open':
            reason=record['reason']
            if reason=='earlier_joint_graph_witness':assert found and not record['expanded']
            elif reason=='graph_preparation_limit':
                assert not data['graph_complete'] and not record['expanded'];stats['graph_preparation_limit_leaves']+=1
            else:
                assert reason=='time_or_expansion_limit'
                assert expanded[0]>=1500 or record['case_elapsed']>=0.70 or record['global_elapsed']>=50
                stats['time_or_node_limit_leaves']+=1
            opened.append(index);return False
        assert record['expanded'] and data['graph_complete']
        if kind=='open_graph_witness':
            assert list(map(len,chosen))==[8,8] and record['witness']==chosen
            found.append(chosen);opened.append(index);return False
        if kind=='closed_count_cover':
            f=record['family'];assert f in [0,1]
            verify_cover(record['cover'],available[f])
            assert len(record['cover'])<8-len(chosen[f])
            stats['closed_count_leaves']+=1;return True
        assert kind=='branch_clique'
        f=record['family'];assert f in [0,1] and len(chosen[f])<8
        group=record['clique'];assert group and len(group)==len(set(group)) and set(group)<=available[f]
        for a,b in combinations(group,2):
            assert conflict(a,b);stats['clique_pair_checks']+=1
        children=record['children'];values=[r['value'] for r in children]
        assert len(values)==len(set(values)) and set(values)==set(group)
        stats['branch_cliques']+=1;closed=[]
        for child in children:
            value=child['value'];child_available=[{n for n in a if n!=value and not conflict(n,value)} for a in available]
            child_chosen=[list(c) for c in chosen];child_chosen[f].append(value)
            if len(child_chosen[f])==8:child_available[f]=set()
            closed.append(replay(child['node'],child_available,child_chosen))
        skipped=[set(a) for a in available];skipped[f]-=set(group)
        closed.append(replay(record['skip'],skipped,chosen))
        return all(closed)
    closed=replay(data['root'],[set(pruning['retained_bracket_nodes']),set(pruning['retained_insert_nodes'])],[[],[]])
    assert seen==set(range(len(records))) and sorted(opened)==data['open_nodes']
    assert data['diagnostic_excluded']==closed==(not opened) and data['expanded_nodes']==expanded[0]
    assert data['case_complete_cap_overrun_seconds']==max(0,data['case_seconds']-0.75)
    assert len(found)<=1 and data['joint_graph_witness']==(found[0] if found else None)
    if closed:excluded.append(row['empty_sites'])
    if found:
        witness=found[0]
        witnesses.append({'source_selection':row,'selected_nodes':witness,
            'bracket_cells':[nodes[n] for n in witness[0]],'insert_cells':[nodes[n] for n in witness[1]],
            'source_placement':False,'carried_prior_witness':False})
    total_evaluations+=evaluated[0]
    results.append({'empty_sites':row['empty_sites'],'tree_records_verified':len(records),**stats,
        'strict_source_inner_pair_evaluations':evaluated[0],'open_leaves':len(opened),
        'joint_graph_witness':bool(found),'case_complete_cap_overrun_seconds':data['case_complete_cap_overrun_seconds'],
        'continuous_fixed29_choice_excluded':closed})
prior=load(FRONTIER/'audit/remaining-fixed29-choices.json');assert len(prior)==28
removed=set(map(tuple,excluded));assert len(removed)==len(excluded) and removed<={tuple(r['empty_sites']) for r in prior}
remaining=[r for r in prior if tuple(r['empty_sites']) not in removed]
write(OUT/'remaining-fixed29-choices.json',remaining);write(OUT/'joint-graph-witnesses.json',witnesses)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Complete continuous root covers retain every original bracket and insert, with self-conflicts allowing at most one original per cell. A complete conflict-clique cover equal to a family required count makes every group mandatory. Each ordered support removal conflicts with every active target in a nonempty mandatory group distinct from the removed cell. Optional clique branches exhaust choosing each cell once versus skipping the whole clique; include children retain exactly all compatible cells of both families. Closed leaves have complete conflict-clique counts below the remaining family requirement. Every tree record is reached once and every open leaf prevents exclusion. Every case has added constraints independently replayed through all Cartesian boundary classes of open source-inner collision unions. Every root cover is the independently certified polygon-union parent domain minus only additional clearance-invalid cells. Exact integer corner halfplanes replay every removal. The independently audited Minkowski polygons add a199 micrometre L1 diamond, contained inside the199 micrometre Euclidean ball, strictly below the original200 micrometre requirement. Membership proves source separation below required clearance; it does not prove zero-clearance overlap. Every other parent cell remains, and each of27 cases has a strictly smaller certified domain. This is a genuinely stronger necessary problem; prior union edges are retained. Graph witnesses are not actual placements. Only fully closed trees exclude fixed29/current cog poses at the original required0.2mm clearance, not at zero clearance and not whole allocations or changed placements.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['tree_records_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks']},
    'strict_source_inner_pair_evaluations':total_evaluations,'new_joint_graph_witnesses':len(witnesses),
    'clearance_root_removals_verified':root_removals,'inherited_union_root_removals':parent_union_removals,'required_job_clearance_mm':0.2,'conservative_clearance_radius_um':199,'zero_clearance_exclusion_claimed':False,'strict_root_corner_checks':root_corner_checks,'added_source_conflict_edges_verified':total_added,'union_boundary_class_checks':point_checks[0],'total_joint_graph_witnesses':len(witnesses),
    'budget_limited_cases':[r['empty_sites'] for r in results if r['time_or_node_limit_leaves'] or r['graph_preparation_limit_leaves']],
    'case_complete_cap_overrun_seconds':sum(r['case_complete_cap_overrun_seconds'] for r in results),
    'new_fixed29_choices_excluded':len(removed),'original_fixed29_choices':455,'previous_fixed29_choices_excluded':427,
    'total_fixed29_choices_excluded':427+len(removed),'remaining_fixed29_choices':len(remaining),
    'whole_allocations_excluded':0,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
