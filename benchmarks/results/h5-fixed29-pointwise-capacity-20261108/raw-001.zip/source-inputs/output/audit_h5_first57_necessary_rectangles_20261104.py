"""Prove every necessary-body rectangle is inside the exact original source."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import product
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-necessary-rectangles-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(v):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(v,v[1:]+v[:1]))/2
def orient(v):return v if area(v)>0 else list(reversed(v))
def transform(v,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    return orient([(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in v])
def containment(bounds,poly):
    a,b,c,d=[F(v,1000) for v in bounds];assert a<c and b<d
    assert all(cross(p,q,r)>=0 for p,q in zip(poly,poly[1:]+poly[:1]) for r in product([a,c],[b,d]))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);modes=load(PRE/'family-modes.json')
partition=[]
for family in ['bracket','insert','cog']:
    pieces=[orient([tuple(map(F,v)) for v in p]) for p in canonical[family]]
    outer=orient([tuple(map(F,v)) for v in parts[family]['geometry'][0]['outer']])
    points={v for p in pieces for v in p}|set(outer)
    def boundary(polygons):
        edges=Counter()
        for p in polygons:
            assert area(p)>0
            for a,b in zip(p,p[1:]+p[:1]):
                vertices=sorted((v for v in points if cross(a,b,v)==0 and min(a[0],b[0])<=v[0]<=max(a[0],b[0]) and min(a[1],b[1])<=v[1]<=max(a[1],b[1])),reverse=a>b)
                assert vertices[0]==a and vertices[-1]==b;edges.update(zip(vertices,vertices[1:]))
        for a,b in list(edges):
            n=min(edges[a,b],edges[b,a]);edges[a,b]-=n;edges[b,a]-=n
        return +edges
    assert all(all(cross(a,b,c)>0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2])) for p in pieces)
    assert sum(area(p) for p in pieces)==area(outer) and boundary(pieces)==boundary([outer])
    partition.append({'family':family,'positive_convex_pieces':len(pieces),'exact_partition_boundary_and_area':True})
cg=modes['cog'][0];ct={'rotation_radians':cg['rotation_radians'],'mirrored':cg['mirrored'],'translation':cg['translation_from_lower_left']}
normalized=load(BASE/'normalized-cog-inner-rectangles.json')
npieces=[transform(p,ct) for p in canonical['cog']]
assert len(normalized)==75
for r in normalized:containment(r['bounds_um'],npieces[r['piece']])
sites=load(PRE/'source-cog-sites.json');world=load(BASE/'world-cog-inner-rectangles.json')
assert len(sites)==15 and len(world)==1125
for site,row in enumerate(sites):
    assert row['transform']['rotation_radians']==cg['rotation_radians'] and row['transform']['mirrored']==cg['mirrored']
    records=[r for r in world if r['site_bit']==site];assert len(records)==len(normalized)
    pieces=[transform(p,row['transform']) for p in canonical['cog']]
    delta=[F(row['transform']['translation'][k])-F(ct['translation'][k]) for k in [0,1]]
    for r,source in zip(records,normalized):
        assert r['piece']==source['piece']
        actual=[F(v,1000)+delta[k%2] for k,v in enumerate(source['bounds_um'])]
        expected=[math.ceil(v*1000) if k<2 else math.floor(v*1000) for k,v in enumerate(actual)]
        assert r['bounds_um']==expected;containment(r['bounds_um'],pieces[r['piece']])
fixed=load(PRE/'fixed29.json');fixed_rect=load(BASE/'fixed-core-inner-rectangles.json')
assert len(fixed)==len(fixed_rect)==29
for i,(r,source) in enumerate(zip(fixed_rect,fixed)):
    assert r['fixed_owner']==i and r['identity']==[source['part_id'],source['copy_index']] and r['site_bit']==15
    poly=transform(parts[source['part_id']]['geometry'][0]['outer'],source['transform'])
    assert len(poly)==4 and all(cross(a,b,c)>0 for a,b,c in zip(poly,poly[1:]+poly[:1],poly[2:]+poly[:2]))
    containment(r['bounds_um'],poly)
stock=list(map(F,load(PRE/'plan.json')['source_stocks']['sheet-0']))
moving=load(BASE/'moving-source-inner-rectangles.json');geometries=load(BASE/'geometry-domains.json');assert len(moving)==12 and len(geometries)==10
assert {(r['family'],r['mode']) for r in moving}=={(family,m['mode']) for family in ['bracket','insert'] for m in modes[family]}
for r in moving:
    family=r['family'];m=modes[family][r['mode']];assert r['source_mode']==m and r['geometry']==m['normalized_geometry']
    assert m['rotation_degrees'] in parts[family]['rotations']['degrees'] and (not m['mirrored'] or parts[family]['allow_mirror'])
    t={'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':m['translation_from_lower_left']}
    assert len(r['inner_rectangles_um'])==len(canonical[family])
    for rectangle,piece in zip(r['inner_rectangles_um'],canonical[family]):containment(rectangle,transform(piece,t))
    outer=transform(parts[family]['geometry'][0]['outer'],t)
    domain=[stock[0]-min(x for x,y in outer),stock[1]-min(y for x,y in outer),stock[2]-max(x for x,y in outer),stock[3]-max(y for x,y in outer)]
    assert list(map(F,r['exact_stock_anchor_domain_mm']))==domain
    ticks=r['outward_anchor_domain_um']
    assert ticks==[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(domain)]
    assert all(F(ticks[k],1000)<=domain[k] if k<2 else F(ticks[k],1000)>=domain[k] for k in range(4))
for gid,g in enumerate(geometries):
    eligible=[r for r in moving if r['geometry']==gid];assert eligible and g['geometry']==gid
    assert g['aliases']==[[r['family'],r['mode']] for r in eligible]
    assert all(sorted(r['inner_rectangles_um'])==g['inner_rectangles_um'] for r in eligible)
    expected=[min(r['outward_anchor_domain_um'][k] for r in eligible) if k<2 else max(r['outward_anchor_domain_um'][k] for r in eligible) for k in range(4)]
    assert g['anchor_domain_um']==expected
write(OUT/'exact-source-partitions.json',partition)
inputs=[Path(__file__),JOB,PIECES]+[PRE/n for n in ['plan.json','family-modes.json','fixed29.json','source-cog-sites.json']]+[BASE/n for n in ['plan.json','checks.json','normalized-cog-inner-rectangles.json','world-cog-inner-rectangles.json','fixed-core-inner-rectangles.json','moving-source-inner-rectangles.json','geometry-domains.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'implication':'If two strictly positive source-contained rectangles overlap in their interiors, their filled original sources overlap. For a moving inner rectangle [a,b,c,d] and fixed inner rectangle [u,v,w,z], the open forbidden anchor rectangle is (u-c,v-d,w-a,z-b). Ignoring required positive clearance enlarges feasible anchors. Outward full-stock domains and unions of source-mode alias domains also enlarge them. A mask naming every cog site whose open obstacle contains the anchor is necessary: all its bits must be among the chosen three empty sites, and the fixed-core bit must be absent. This does not cover moved cog poses, different cog angles or a changed fixed29 core.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'exact_source_partitions':3,'normalized_cog_inner_rectangles_verified':75,
    'world_cog_inner_rectangles_verified':1125,'mandatory_fixed_core_rectangles_verified':29,'source_moving_modes_verified':12,
    'moving_inner_rectangles_verified':20,'full_stock_geometry_domains_verified':10,'all_mode_aliases_covered':True,
    'positive_region_or_strip_bound_reused':False,'continuous_necessary_relaxation_certified':True,'mask_cover_not_yet_built':True,
    'site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
