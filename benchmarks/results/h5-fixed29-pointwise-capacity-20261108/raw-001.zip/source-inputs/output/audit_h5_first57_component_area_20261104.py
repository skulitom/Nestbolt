"""Exact source-cover assignment and integer area replay for all component bounds."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
BASE=ROOT/'output/h5-first57-component-area-20261104';OUT=BASE/'audit'
HELPER=ROOT/'output/audit_h5_first57_reachable_area_20261104.py'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
assert load(SOURCE/'audit/checks.json')['passed'] and load(COVER/'audit/checks.json')['passed']
for directory in [SOURCE/'audit',COVER/'audit',BASE]:
    for path,h in load(directory/'plan.json')['inputs'].items():assert digest(ROOT/path)==h,path
# Reuse only the side-effect-free exact integer sweep from the independent auditor.
# It shares no implementation or geometry engine with either preparation process.
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='exact_area']
assert len(functions)==1
scope={};exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'),scope);exact_area=scope['exact_area']
geometries=load(SOURCE/'geometry-domains.json')
rects=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
all_boxes=[load(COVER/f'geometry-{g:02d}-cover.json') for g in range(8)]
minimum_area=min(sum((c-a)*(d-b) for a,b,c,d in g['inner_rectangles_um']) for g in geometries[:8])
for g in geometries[:8]:
    assert all(f=='bracket' for f,m in g['aliases'])
    a,b=g['inner_rectangles_um']
    assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
actual=load(BASE/'all-choices.json');assert len(actual)==455
records=[];total_groups=total_assignments=0
for index,empty in enumerate(combinations(range(15),3)):
    bits=sum(1<<i for i in empty)
    expected={(gid,ri) for gid in range(8) for ri,row in enumerate(all_boxes[gid]) if row[0]&~bits==0}
    claim=load(BASE/f'choice-{index:03d}.json')
    assert claim['index']==index and claim['empty_sites']==list(empty) and claim['eligible_anchor_boxes']==len(expected)
    seen=set();verified=[]
    for group in claim['groups']:
        assignments=[tuple(r) for r in group['anchor_boxes']]
        assert assignments and len(set(assignments))==len(assignments) and not seen.intersection(assignments)
        assert set(assignments)<=expected;seen.update(assignments)
        reachable=[]
        for gid,ri in assignments:
            _,x,y,z,w,*_=all_boxes[gid][ri]
            for a,b,c,d in geometries[gid]['inner_rectangles_um']:reachable.append((x+a,y+b,z+c,w+d))
        reachable=sorted(set(reachable))
        bounds=[min(r[0] for r in reachable),min(r[1] for r in reachable),max(r[2] for r in reachable),max(r[3] for r in reachable)]
        obstacles=[r['bounds_um'] for r in rects if r['site_bit'] not in empty and max(r['bounds_um'][0],bounds[0])<min(r['bounds_um'][2],bounds[2]) and max(r['bounds_um'][1],bounds[1])<min(r['bounds_um'][3],bounds[3])]
        area,stats=exact_area(reachable,obstacles)
        assert area==group['reachable_area_um2'] and group['minimum_bracket_area_um2']==minimum_area and group['capacity']==area//minimum_area
        verified.append({'anchor_boxes':len(assignments),'exact_reachable_area_um2':area,'exact_capacity':area//minimum_area,'sweep':stats})
    assert seen==expected
    capacity=sum(g['exact_capacity'] for g in verified);excluded=capacity<8
    assert claim['bracket_capacity']==capacity and claim['diagnostic_excluded']==excluded
    assert actual[index]=={k:v for k,v in claim.items() if k!='groups'}|{'group_count':len(verified),'group_capacities':[g['exact_capacity'] for g in verified]}
    records.append({'index':index,'empty_sites':list(empty),'exact_bracket_capacity':capacity,'excluded':excluded,'groups':verified})
    total_groups+=len(verified);total_assignments+=len(expected)
    if index%50==0:print({'verified':index+1,'seconds':time.perf_counter()-started,'excluded':sum(r['excluded'] for r in records)},flush=True)
write(OUT/'verified-choices.json',records)
write(OUT/'retained-choices.json',[{'index':r['index'],'empty_sites':r['empty_sites'],'bracket_capacity':r['exact_bracket_capacity'],'group_capacities':[g['exact_capacity'] for g in r['groups']]} for r in records if not r['excluded']])
inputs=[Path(__file__),HELPER,BASE/'plan.json',BASE/'checks.json',BASE/'all-choices.json',SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',COVER/'audit/plan.json',COVER/'audit/checks.json']+[BASE/f'choice-{i:03d}.json' for i in range(455)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every eligible necessary anchor box appears exactly once in an assigned group. A feasible bracket anchor may lie in multiple closed cover boxes; assign it arbitrarily to one such box and hence one group. Both of its source-contained inner rectangles then lie wholly inside that group reachable swept-body region and outside every fixed source-contained obstacle. Distinct brackets have disjoint interiors. Therefore the number assigned to a group is bounded by floor(exact reachable area/minimum one-bracket inner area). Summing these capacities is valid even if group regions overlap. All group areas are independently recomputed by Python-integer interval-event trees. No geometric clustering assumption, floating-point area, sampled anchor or prior positive region is needed for the proof. Scope is fixed29 plus the selected twelve of the15 original cog poses.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'choices_verified':len(records),'exact_group_areas':total_groups,'eligible_anchor_box_assignments':total_assignments,
    'new_site_choices_excluded':sum(r['excluded'] for r in records),'remaining_site_choices':sum(not r['excluded'] for r in records),
    'capacity_histogram':dict(Counter(r['exact_bracket_capacity'] for r in records)),
    'continuous_source_necessary_bound':True,'all_eligible_boxes_assigned_once':True,'fixed29_and_candidate_cog_pose_scope_only':True,
    'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
