"""Independent continuous coverage and strict-inner-overlap certificate replay."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-full-frontier-cliques-20261104';OUT=BASE/'audit'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
FRONTIER=ROOT/'output/h5-first57-joint-clique-distributions-20261104/audit'
assert load(FRONTIER/'checks.json')['passed']
frontier=load(FRONTIER/'remaining-fixed29-choices.json')
selected=[r['empty_sites'] for r in frontier]
assert len(selected)==len(set(map(tuple,selected)))==256
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,SOURCE/'audit',COVER/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [SOURCE,COVER]:assert load(base/'audit/checks.json')['passed']
geometries=load(SOURCE/'geometry-domains.json');covers=[load(COVER/f'geometry-{g:02d}-cover.json') for g in range(8)]
def certify(a,b,ai,bi):
    ra=geometries[a['geometry']]['inner_rectangles_um'][ai];rb=geometries[b['geometry']]['inner_rectangles_um'][bi]
    # Maximal left edge must be strictly less than the other minimal right edge, in both axes.
    for axis in [0,1]:
        assert a['bounds_um'][axis+2]+ra[axis] < b['bounds_um'][axis]+rb[axis+2]
        assert b['bounds_um'][axis+2]+rb[axis] < a['bounds_um'][axis]+ra[axis+2]
checks=[];pair_count=0;cell_count=0
for choice,empty in enumerate(selected):
    data=load(BASE/f'choice-{choice:02d}.json');assert data['empty_sites']==empty
    expected={};bits=sum(1<<i for i in empty)
    for gid,cover in enumerate(covers):
        for ri,row in enumerate(cover):
            mask,x,y,z,w,*_=row
            if mask&~bits:continue
            nx=max(1,(z-x+49999)//50000);ny=max(1,(w-y+49999)//50000)
            for xi in range(nx):
                for yi in range(ny):expected[(gid,ri,xi,yi)]=[x+xi*50000,y+yi*50000,min(z,x+(xi+1)*50000),min(w,y+(yi+1)*50000)]
    nodes=data['nodes'];assert len(nodes)==len(expected) and len(data['self_certificates'])==len(nodes)
    actual={}
    for i,node in enumerate(nodes):
        assert node['node']==i
        key=(node['geometry'],node['cover_box'],*node['cell']);assert key not in actual
        actual[key]=node['bounds_um'];certify(node,node,*data['self_certificates'][i])
    assert actual==expected
    seen=set()
    for clique in data['cliques']:
        group=clique['nodes'];assert group and not seen.intersection(group) and len(group)==len(set(group));seen.update(group)
        pairs={(a,b) for k,a in enumerate(group) for b in group[k+1:]};received=set()
        for a,b,ai,bi in clique['strict_overlap_certificates']:
            assert (a,b) in pairs and (a,b) not in received;received.add((a,b));certify(nodes[a],nodes[b],ai,bi);pair_count+=1
        assert pairs==received
    assert seen==set(range(len(nodes)))
    capacity=len(data['cliques']);assert capacity==data['bracket_capacity_upper_bound']==min(data['candidate_cover_counts'])
    assert data['diagnostic_excluded']==(capacity<8)
    checks.append({'empty_sites':empty,'continuous_bracket_capacity_upper_bound':capacity,'every_clique_mandatory_for_eight_brackets':capacity==8,'excluded':capacity<8,'nodes':len(nodes)})
    cell_count+=len(nodes)
excluded={tuple(r['empty_sites']) for r in checks if r['excluded']}
remaining=[r for r in frontier if tuple(r['empty_sites']) not in excluded]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'mandatory-eight-clique-choices.json',[{'choice_index':i,'empty_sites':r['empty_sites'],'nodes':r['nodes']} for i,r in enumerate(checks) if r['every_clique_mandatory_for_eight_brackets']])
inputs=[Path(__file__),ROOT/'output/prepare_h5_full_frontier_clique_helpers_20261104.py',FRONTIER/'plan.json',FRONTIER/'checks.json',FRONTIER/'remaining-fixed29-choices.json',BASE/'plan.json',BASE/'checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(256)]+[b/n for b in [SOURCE,COVER] for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every continuous legal bracket anchor belongs to an eligible original necessary box and one closed subcell. Each subcell is self-conflicting, so at most one original can choose it. All subcells are partitioned into cliques, every pair independently verified to have strictly overlapping source-inner rectangles for all anchors. Any valid packing assigns distinct chosen nodes and at most one to each clique. Thus the clique count bounds original brackets continuously, even at zero clearance. If exactly eight cliques cover the required eight brackets, each clique must contain one chosen bracket. No claim of an attainable packing or whole-allocation exclusion follows.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':checks,'complete_continuous_cells_verified':cell_count,'strict_pair_certificates_verified':pair_count,'source_inner_zero_clearance_bound':True,'new_site_choices_excluded':sum(c['excluded'] for c in checks),'previous_fixed29_choices_excluded':199,'remaining_fixed29_choices':len(remaining),'total_fixed29_choices_excluded':199+len(excluded),'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
