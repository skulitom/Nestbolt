from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-cog-union-subdivision-20261106';OUT=BASE/'audit'
PRUNE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
PROCESS=ROOT/'output/h5-first57-cog-union-subdivision-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'queries.json',PRUNE/'integer-source.json',PRUNE/'cells.json',PRUNE/'collision-polygons.json',
        PRUNE/'audit/stronger-model-candidates.json',FRONTIER/'audit/remaining-fixed29-choices.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,PRUNE/'audit',FRONTIER/'audit',BR/'audit',INS/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for b in [PRUNE,FRONTIER,BR,INS]:
    inputs.add(b/'audit/checks.json');assert load(b/'audit/checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
prior=load(FRONTIER/'audit/remaining-fixed29-choices.json');assert len(prior)==28
remaining={tuple(r['empty_sites']) for r in prior}
selection=[r['source_selection']|{'pruning_index':r['pruning_index']} for r in load(PRUNE/'audit/stronger-model-candidates.json') if tuple(r['source_selection']['empty_sites']) in remaining]
assert len(selection)==28 and load(BASE/'plan.json')['selection']==selection
integer=load(PRUNE/'integer-source.json');D=int(integer['scaled_units_per_micrometre']);assert D>0
cells=load(PRUNE/'cells.json');templates=load(PRUNE/'collision-polygons.json')
shifts=[tuple(map(int,s['translation_scaled'])) for s in integer['sites']]
world=[];by_geometry={g:[] for g in range(10)}
for template in templates:
    for site,(dx,dy) in enumerate(shifts):
        polygon=[(int(x)+dx,int(y)+dy) for x,y in template['vertices_scaled']]
        world.append({'site':site,'geometry':template['geometry'],'vertices':polygon,
            'bounds':(min(x for x,y in polygon),min(y for x,y in polygon),max(x for x,y in polygon),max(y for x,y in polygon))})
        by_geometry[template['geometry']].append(len(world)-1)
def inside(point,polygon):
    return all(cross(a,b,point)>0 for a,b in zip(polygon,polygon[1:]+polygon[:1]))
def intersects(a,b):return max(a[0],b[0])<=min(a[2],b[2]) and max(a[1],b[1])<=min(a[3],b[3])
queries=load(BASE/'queries.json');keys=set();query_closed=[];total_records=total_expanded=closed_leaves=split_nodes=open_samples=0
strict_corner_checks=0;query_overrun=0;open_reasons={};max_depth=0
for qi,query in enumerate(queries):
    assert query['query']==qi;ci=query['source_cell'];assert 0<=ci<len(cells)
    candidates=query['candidate_polygons'];assert candidates==sorted(set(candidates))
    box=tuple(v*D for v in cells[ci]['bounds_um'])
    assert all(0<=pi<len(world) and world[pi]['geometry']==cells[ci]['geometry'] and intersects(box,world[pi]['bounds']) for pi in candidates)
    key=(ci,tuple(candidates));assert key not in keys;keys.add(key)
    records=query['records'];seen=set();expanded=[0]
    def replay(index,bounds,depth,skip=False):
        global strict_corner_checks,closed_leaves,split_nodes,open_samples,max_depth
        assert 0<=index<len(records) and index not in seen;seen.add(index)
        record=records[index];assert record['node']==index;max_depth=max(max_depth,depth)
        kind=record['kind']
        if skip:
            assert kind=='open' and record['reason']=='earlier_unproved_child'
            open_reasons[record['reason']]=open_reasons.get(record['reason'],0)+1;return False
        if kind=='open' and record['reason']=='time_or_node_limit':
            assert expanded[0]>=511 or record['query_elapsed']>=0.02 or record['global_elapsed']>=25
            open_reasons[record['reason']]=open_reasons.get(record['reason'],0)+1;return False
        expanded[0]+=1;assert expanded[0]<=511 and depth<=8
        if kind=='closed_source_polygon':
            pi=record['polygon'];assert pi in candidates
            polygon=world[pi]['vertices']
            for a,b in zip(polygon,polygon[1:]+polygon[:1]):
                for point in product([bounds[0],bounds[2]],[bounds[1],bounds[3]]):
                    assert cross(a,b,point)>0;strict_corner_checks+=1
            closed_leaves+=1;return True
        if kind=='open_source_inner_sample':
            point=tuple(map(int,record['point_scaled']));assert len(point)==2
            assert bounds[0]<=point[0]<=bounds[2] and bounds[1]<=point[1]<=bounds[3]
            assert all(not inside(point,world[pi]['vertices']) for pi in candidates)
            open_samples+=1;return False
        if kind=='open':
            assert record['reason'] in ['depth_limit','no_interior_split']
            if record['reason']=='depth_limit':assert depth==8
            else:assert max(bounds[2]-bounds[0],bounds[3]-bounds[1])<=1
            open_reasons[record['reason']]=open_reasons.get(record['reason'],0)+1;return False
        assert kind=='split' and depth<8;axis=record['axis'];cut=int(record['cut_scaled'])
        assert axis in [0,1] and bounds[axis]<cut<bounds[axis+2]
        lower=list(bounds);upper=list(bounds);lower[axis+2]=cut;upper[axis]=cut
        assert lower[axis]==bounds[axis] and upper[axis+2]==bounds[axis+2] and lower[axis+2]==upper[axis]
        lc=replay(record['left'],tuple(lower),depth+1)
        rc=replay(record['right'],tuple(upper),depth+1,skip=not lc)
        split_nodes+=1;return lc and rc
    closed=replay(query['root'],box,0)
    assert seen==set(range(len(records))) and query['whole_closed_cell_covered']==closed
    assert query['expanded_nodes']==expanded[0]
    assert query['query_complete_cap_overrun_seconds']==max(0,query['query_seconds']-0.05)
    query_overrun+=query['query_complete_cap_overrun_seconds'];query_closed.append(closed)
    total_records+=len(records);total_expanded+=expanded[0]
records=[];used_queries=set();cell_candidates={};excluded=[]
for choice,row in enumerate(selection):
    paths=[BASE/f'choice-{choice:02d}.json',PRUNE/f"choice-{row['pruning_index']:02d}.json",
           BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json"]
    inputs.update(paths);data,parent,br,ins=map(load,paths)
    assert data['source_selection']==row and data['empty_sites']==parent['empty_sites']==br['empty_sites']==ins['empty_sites']==row['empty_sites']
    offset=parent['original_bracket_node_count'];assert data['original_bracket_node_count']==offset==len(br['nodes'])
    retained=parent['retained_bracket_nodes']+parent['retained_insert_nodes']
    assert [r['node'] for r in data['node_queries']]==retained
    present=((1<<15)-1)^sum(1<<i for i in row['empty_sites']);expected_removed=[]
    for reference in data['node_queries']:
        node,qi=reference['node'],reference['query'];assert 0<=qi<len(queries)
        used_queries.add(qi);query=queries[qi];ci=parent['node_cells'][node];assert query['source_cell']==ci
        if ci not in cell_candidates:
            box=tuple(v*D for v in cells[ci]['bounds_um'])
            cell_candidates[ci]=[pi for pi in by_geometry[cells[ci]['geometry']] if intersects(box,world[pi]['bounds'])]
        expected=[pi for pi in cell_candidates[ci] if present&(1<<world[pi]['site'])]
        assert query['candidate_polygons']==expected
        if query_closed[qi]:expected_removed.append(reference)
    assert data['additional_removed']==expected_removed
    removed={r['node'] for r in expected_removed}
    rbr=[n for n in parent['retained_bracket_nodes'] if n not in removed]
    rins=[n for n in parent['retained_insert_nodes'] if n not in removed]
    assert data['retained_bracket_nodes']==rbr and data['retained_insert_nodes']==rins
    bb=sum(bool(set(c['nodes'])&set(rbr)) for c in br['cliques'])
    ib=sum(bool({offset+n for n in c['nodes']}&set(rins)) for c in ins['insert_cliques'])
    contradiction=min(bb,ib)<8
    if contradiction:excluded.append(row['empty_sites'])
    records.append({'subdivision_index':choice,'source_selection':row,'new_removed_nodes':len(removed),
        'remaining_bracket_nodes':len(rbr),'remaining_insert_nodes':len(rins),'retained_bracket_clique_bound':bb,
        'retained_insert_clique_bound':ib,'continuous_fixed29_choice_excluded':contradiction})
assert used_queries==set(range(len(queries)))
removed_cases=set(map(tuple,excluded));updated=[r for r in prior if tuple(r['empty_sites']) not in removed_cases]
write(OUT/'remaining-fixed29-choices.json',updated)
write(OUT/'stronger-model-candidates.json',[r for r in records if r['new_removed_nodes'] and not r['continuous_fixed29_choice_excluded']])
write(OUT/'unchanged-domain-cases.json',[r for r in records if not r['new_removed_nodes'] and not r['continuous_fixed29_choice_excluded']])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Reconstruct every world collision polygon from the previously certified exact integer source polygons and translations. Each query contains exactly all present-site polygons of the correct moving geometry whose closed bounds meet the source cell. Every cached use rechecks that full candidate set. Independently replay every tree record and exact interior split; the two closed children cover the parent, including their shared boundary. Every closed leaf has all four corners strictly inside one source polygon. Only a fully closed root is removed. Every uncovered sample, depth/time/node limit or skipped child keeps the complete original cell. All referenced root queries are checked once, every mapping is preserved and retained node lists equal the prior certified domains minus only complete new proofs. Exclusions, if any, remain conditional on the fixed core/current cog poses.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,
    'unique_queries_verified':len(queries),'tree_records_verified':total_records,'expanded_nodes_verified':total_expanded,
    'exact_split_nodes':split_nodes,'closed_source_polygon_leaves':closed_leaves,'strict_corner_halfplane_checks':strict_corner_checks,
    'open_source_inner_samples':open_samples,'open_leaf_reasons':open_reasons,'maximum_depth_verified':max_depth,
    'closed_whole_cell_queries':sum(query_closed),'new_removed_node_occurrences':sum(r['new_removed_nodes'] for r in records),
    'cases_with_strictly_smaller_domains':sum(r['new_removed_nodes']>0 for r in records),
    'query_complete_cap_overrun_seconds':query_overrun,'complete_continuous_retained_domains':True,
    'new_fixed29_choices_excluded':len(removed_cases),'total_fixed29_choices_excluded':427+len(removed_cases),
    'remaining_fixed29_choices':len(updated),'whole_allocations_excluded':0,'whole_allocation_candidates':440,
    'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
