"""Independent complete-cover, exact-subdivision and graph-restriction audit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-refined-polygon-union-20261107';OUT=BASE/'audit'
G=ROOT/'output/h5-six-polygon-clearance-v2-20261107';RAW=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';FRONT=ROOT/'output/h5-polygon-sat-batch-20261107/audit';PROCESS=ROOT/'output/h5-refined-polygon-union-process-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def inside(p,poly):return all(cross(a,b,p)>0 for a,b in zip(poly,poly[1:]+poly[:1]))
def intersects(a,b):return max(a[0],b[0])<=min(a[2],b[2]) and max(a[1],b[1])<=min(a[3],b[3])
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'queries.json',G/'audit/plan.json',G/'audit/checks.json',G/'cells.json',G/'collision-polygons.json',RAW/'integer-source.json',FRONT/'checks.json',FRONT/'remaining-fixed29-choices.json',PROCESS/'prepare.json',PROCESS/'opened.json'}
for folder in [BASE,G/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(G/'audit/checks.json')['passed'] and load(FRONT/'checks.json')['passed'] and load(PROCESS/'prepare.json')['passed']
assert load(PROCESS/'prepare.json')['job']['active_processes']==0
selection=sorted(load(FRONT/'remaining-source-graphs.json'),key=lambda r:r['refinement_index']);assert plan['selection']==selection and len(selection)==4
raw=load(RAW/'integer-source.json');D=int(raw['scaled_units_per_micrometre']);assert D>0
cells=load(G/'cells.json');templates=load(G/'collision-polygons.json');shifts=[tuple(map(int,r['translation_scaled'])) for r in raw['sites']]
world=[];bygeom={g:[] for g in range(10)}
for template in templates:
    for site,(dx,dy) in enumerate(shifts):
        poly=[(int(x)+dx,int(y)+dy) for x,y in template['vertices_scaled']]
        bygeom[template['geometry']].append(len(world));world.append({'site':site,'geometry':template['geometry'],'vertices':poly,'bounds':(min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly))})
queries=load(BASE/'queries.json');query_closed=[];keys=set();total_records=total_expanded=closed_leaves=split_nodes=open_samples=corner_checks=max_depth=0;query_overrun=0;open_reasons={}
for qi,query in enumerate(queries):
    assert query['query']==qi;ci=query['source_cell'];assert 0<=ci<len(cells)
    candidates=query['candidate_polygons'];assert candidates==sorted(set(candidates));box=tuple(v*D for v in cells[ci]['bounds_um'])
    assert all(0<=pi<len(world) and world[pi]['geometry']==cells[ci]['geometry'] and intersects(box,world[pi]['bounds']) for pi in candidates)
    key=(ci,tuple(candidates));assert key not in keys;keys.add(key);records=query['records'];seen=set();expanded=[0]
    def replay(index,bounds,depth,skip=False):
        global corner_checks,closed_leaves,split_nodes,open_samples,max_depth
        assert 0<=index<len(records) and index not in seen;seen.add(index);record=records[index];assert record['node']==index
        max_depth=max(max_depth,depth);kind=record['kind']
        if skip:
            assert kind=='open' and record['reason']=='earlier_unproved_child';open_reasons[record['reason']]=open_reasons.get(record['reason'],0)+1;return False
        if kind=='open' and record['reason']=='time_or_node_limit':
            assert expanded[0]>=511 or record['query_elapsed']>=.02 or record['global_elapsed']>=25
            open_reasons[record['reason']]=open_reasons.get(record['reason'],0)+1;return False
        expanded[0]+=1;assert expanded[0]<=511 and depth<=8
        if kind=='closed_source_polygon':
            pi=record['polygon'];assert pi in candidates;poly=world[pi]['vertices']
            for a,b in zip(poly,poly[1:]+poly[:1]):
                for point in product([bounds[0],bounds[2]],[bounds[1],bounds[3]]):assert cross(a,b,point)>0;corner_checks+=1
            closed_leaves+=1;return True
        if kind=='open_source_inner_sample':
            point=tuple(map(int,record['point_scaled']));assert len(point)==2 and bounds[0]<=point[0]<=bounds[2] and bounds[1]<=point[1]<=bounds[3]
            assert all(not inside(point,world[pi]['vertices']) for pi in candidates);open_samples+=1;return False
        if kind=='open':
            assert record['reason'] in ['depth_limit','no_interior_split']
            if record['reason']=='depth_limit':assert depth==8
            else:assert max(bounds[2]-bounds[0],bounds[3]-bounds[1])<=1
            open_reasons[record['reason']]=open_reasons.get(record['reason'],0)+1;return False
        assert kind=='split' and depth<8;axis=record['axis'];cut=int(record['cut_scaled']);assert axis in [0,1] and bounds[axis]<cut<bounds[axis+2]
        lo=list(bounds);hi=list(bounds);lo[axis+2]=cut;hi[axis]=cut
        assert lo[axis]==bounds[axis] and hi[axis+2]==bounds[axis+2] and lo[axis+2]==hi[axis]
        lc=replay(record['left'],tuple(lo),depth+1);rc=replay(record['right'],tuple(hi),depth+1,skip=not lc)
        split_nodes+=1;return lc and rc
    closed=replay(query['root'],box,0);assert seen==set(range(len(records))) and query['whole_closed_cell_covered']==closed
    assert query['expanded_nodes']==expanded[0] and query['query_complete_cap_overrun_seconds']==max(0,query['query_seconds']-.05)
    query_overrun+=query['query_complete_cap_overrun_seconds'];query_closed.append(closed);total_records+=len(records);total_expanded+=expanded[0]
assert query_overrun==0
results=[];used_queries=set();candidate_cache={};excluded=[];all_pairs=0
for row in selection:
    old=ROOT/row['graph'];folder=BASE/f"choice-{row['refinement_index']:02d}";original=load(old/'nodes.json');N=len(original)
    for name in ['checks.json','node-queries.json','removed.json','nodes.json','kept-old-node-ids.json','root-covers.json','conflicts.bin']:inputs.add(folder/name)
    references=load(folder/'node-queries.json');assert [r['node'] for r in references]==list(range(N));expected_removed=[]
    for ref in references:
        qi=ref['query'];node=original[ref['node']];assert 0<=qi<len(queries);used_queries.add(qi);query=queries[qi];ci=query['source_cell'];cell=cells[ci]
        assert (cell['geometry'],cell['bounds_um'])==(node['geometry'],node['bounds_um'])
        if ci not in candidate_cache:
            box=tuple(v*D for v in cell['bounds_um']);candidate_cache[ci]=[pi for pi in bygeom[cell['geometry']] if intersects(box,world[pi]['bounds'])]
        assert query['candidate_polygons']==[pi for pi in candidate_cache[ci] if world[pi]['site'] not in row['empty_sites']]
        if query_closed[qi]:expected_removed.append(ref)
    assert load(folder/'removed.json')==expected_removed;removed={r['node'] for r in expected_removed}
    kept=load(folder/'kept-old-node-ids.json');ns=load(folder/'nodes.json');assert kept==[i for i in range(N) if i not in removed] and ns==[original[i] for i in kept];n=len(ns)
    oldmatrix=np.unpackbits(np.frombuffer((old/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(N,(N+7)//8),axis=1,bitorder='little')[:,:N]
    newmatrix=np.unpackbits(np.frombuffer((folder/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(n,(n+7)//8),axis=1,bitorder='little');assert not np.any(newmatrix[:,n:]);actual=newmatrix[:,:n]
    assert np.array_equal(actual,oldmatrix[np.ix_(kept,kept)]) and np.all(actual==actual.T) and np.all(np.diag(actual));all_pairs+=n*(n-1)//2
    inverse={v:i for i,v in enumerate(kept)};covers=load(folder/'root-covers.json');expected=[[[inverse[i] for i in group if i in inverse] for group in family] for family in load(old/'root-covers.json')];expected=[[g for g in family if g] for family in expected]
    assert covers==expected
    for f,groups in enumerate(covers):
        assert sorted(i for group in groups for i in group)==[i for i,node in enumerate(ns) if node['family']==f]
        assert all(np.all(actual[np.ix_(group,group)]) for group in groups)
    reported=load(folder/'checks.json');assert reported['removed_nodes']==len(removed) and reported['genuinely_stronger']==bool(removed) and reported['conflict_bytes_sha256']==digest(folder/'conflicts.bin')
    contradiction=any(len(c)<8 for c in covers)
    if contradiction:excluded.append(row['empty_sites'])
    results.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source_selection':row['source_selection'],'graph':folder.relative_to(ROOT).as_posix(),'removed_nodes':len(removed),'retained_nodes':n,'root_clique_counts':list(map(len,covers)),'genuinely_stronger':bool(removed),'fixed_arrangement_excluded_by_complete_clique_bound':contradiction})
assert used_queries==set(range(len(queries)))
prior=load(FRONT/'remaining-fixed29-choices.json');exset=set(map(tuple,excluded));remaining=[r for r in prior if tuple(r['empty_sites']) not in exset]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},'proof':'Reconstruct current exact world source hulls. Every cached query has exactly all present-cog polygons of the correct moving geometry whose closed bounding boxes meet the closed source cell. Every tree branch preserves both closed children and their common boundary. Exact four-corner halfplanes prove closed leaves; only wholly closed roots remove cells. Every unproved sample/limit/skipped child retains the entire old cell. Each new graph is exactly the old certified graph restricted to retained node identities, preserving every mode alias. Every complete clique partition and its pairs are verified. No unchanged graph justifies another solver call.'})
result={'passed':True,'seconds':time.perf_counter()-start,'choices':results,'unique_queries_verified':len(queries),'tree_records_verified':total_records,'expanded_nodes_verified':total_expanded,'exact_split_nodes':split_nodes,'closed_source_polygon_leaves':closed_leaves,'strict_corner_halfplane_checks':corner_checks,'open_source_inner_samples':open_samples,'open_leaf_reasons':open_reasons,'maximum_depth_verified':max_depth,'closed_whole_cell_queries':sum(query_closed),'new_removed_node_occurrences':sum(r['removed_nodes'] for r in results),'genuinely_stronger_cases':sum(r['genuinely_stronger'] for r in results),'all_retained_graph_pairs':all_pairs,'query_complete_cap_overrun_seconds':query_overrun,'complete_continuous_retained_domains':True,'new_fixed29_exclusions':len(excluded),'total_excluded_at_required_clearance':451+len(excluded),'remaining_fixed29_choices':len(remaining),'whole_allocation_candidates':440,'solver_calls':0,'native_validation_calls':0,'source_valid66':False,'H5_complete':False}
for name,value in [('checks.json',result),('remaining-fixed29-choices.json',remaining),('stronger-model-candidates.json',[r for r in results if r['genuinely_stronger'] and not r['fixed_arrangement_excluded_by_complete_clique_bound']]),('unchanged-domain-cases.json',[r for r in results if not r['genuinely_stronger']])]:write(OUT/name,value)
print(json.dumps(result),flush=True)
