"""Verify every added graph edge against exact source component unions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-union-conflict-edges-20261106';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
FRONTIER=ROOT/'output/h5-first57-joint-optional-trees-20261106'
PROBE=ROOT/'output/h5-first57-union-conflict-probe-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
PROCESS=ROOT/'output/h5-first57-union-conflict-edges-process-20261106';HELPER=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),HELPER,BASE/'plan.json',BASE/'checks.json',SOURCE/'geometry-domains.json',
        INS/'audit/joint-candidates.json',FRONTIER/'audit/remaining-fixed29-choices.json',
        PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,BR/'audit',INS/'audit',FRONTIER/'audit',PROBE/'audit-v2']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR/'audit',INS/'audit',FRONTIER/'audit',PROBE/'audit-v2']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(INS/'audit/joint-candidates.json') if tuple(r['empty_sites']) in remaining]
assert load(BASE/'plan.json')['selection']==selection and len(selection)==52
geometry=load(SOURCE/'geometry-domains.json');point_checks=[0]
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['classes','covered']]
assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
records=[];total=0;family_counts=[0,0,0]
for choice,row in enumerate(selection):
    paths=[BASE/f'choice-{choice:02d}.json',BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json"]
    inputs.update(paths);data,br,ins=map(load,paths);offset=len(br['nodes']);nodes=br['nodes']+ins['nodes']
    assert data['source_selection']==row and data['empty_sites']==br['empty_sites']==ins['empty_sites']==row['empty_sites']
    assert data['original_bracket_node_count']==offset==row['bracket_nodes']
    assert data['total_nodes']==len(nodes) and len(ins['nodes'])==row['complete_insert_cells']
    edges=data['added_conflict_edges'];assert edges==sorted(edges) and len(edges)==len(set(map(tuple,edges)))
    for a,b in edges:
        assert 0<=a<b<len(nodes)
        left,right=nodes[a],nodes[b]
        box=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]+[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
        rectangles=[[ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]]
                    for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um'])]
        assert not any(all(r[i]<box[i] and box[i+2]<r[i+2] for i in [0,1]) for r in rectangles)
        assert covered(box,rectangles)
        family_counts[int(a>=offset)+int(b>=offset)]+=1
    assert data['candidate_pairs_checked']>=len(edges) and not data['whole_arrangement_excluded']
    assert data['case_complete_cap_overrun_seconds']==max(0,data['case_seconds']-0.40)
    if data['all_eligible_pairs_checked']:assert data['geometry_templates_completed']==55
    total+=len(edges)
    records.append({'augmentation_index':choice,'source_selection':row,'new_edges_verified':len(edges),
        'reported_scan_completed':data['all_eligible_pairs_checked'],
        'case_complete_cap_overrun_seconds':data['case_complete_cap_overrun_seconds']})
write(OUT/'stronger-model-candidates.json',[r for r in records if r['new_edges_verified']])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'All original bracket and insert candidates remain in the separately verified complete continuous source covers. Independently reconstruct each added edge relative-anchor box and every source-inner collision rectangle. Verify absence of any single-component certificate, then replay every Cartesian boundary/open-interval class using strict exact doubled-integer membership. Every recorded new edge is a genuine stronger conflict for all anchors. This audit claims safety of all added edges, not completeness of the optional augmentation scan. Missing added edges merely weaken the necessary graph; no original candidate is removed. Only a later complete augmented-graph contradiction could exclude a whole fixed arrangement.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,
    'added_source_conflict_edges_verified':total,'cartesian_class_point_checks':point_checks[0],
    'bracket_bracket_edges':family_counts[0],'bracket_insert_edges':family_counts[1],'insert_insert_edges':family_counts[2],
    'cases_with_genuinely_stronger_constraints':sum(r['new_edges_verified']>0 for r in records),
    'reported_complete_scans':sum(r['reported_scan_completed'] for r in records),
    'augmentation_completeness_claimed':False,'complete_original_source_domains_preserved':True,
    'case_complete_cap_overrun_seconds':sum(r['case_complete_cap_overrun_seconds'] for r in records),
    'whole_arrangements_excluded':0,'remaining_fixed29_choices':52,'total_fixed29_choices_excluded':403,
    'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
