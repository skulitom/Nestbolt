from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-joint-clique-distributions-20261104';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';AC=ROOT/'output/h5-first57-mandatory-clique-consistency-20261104';INS=ROOT/'output/h5-first57-consistent-insert-bounds-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';CAP=ROOT/'output/h5-first57-component-area-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,BR/'audit',AC/'audit',INS/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR,AC,INS]:assert load(base/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json');records=[];pair_checks=0
def conflict(a,b):
    for ra in geometry[a['geometry']]['inner_rectangles_um']:
        for rb in geometry[b['geometry']]['inner_rectangles_um']:
            if all(a['bounds_um'][axis+2]+ra[axis]<b['bounds_um'][axis]+rb[axis+2] and b['bounds_um'][axis+2]+rb[axis]<a['bounds_um'][axis]+ra[axis+2] for axis in [0,1]):return True
    return False
excluded=[]
for choice in range(3):
    data=load(BASE/f'choice-{choice:02d}.json');br=load(BR/f'choice-{choice:02d}.json');ac=load(AC/f'choice-{choice:02d}.json');ins=load(INS/f'choice-{choice:02d}.json')
    assert data['empty_sites']==br['empty_sites']==ac['empty_sites']==ins['empty_sites']
    offset=len(br['nodes']);nodes=br['nodes']+ins['nodes'];bg=ac['remaining_cliques'];ig=[[offset+n for n in c['nodes']] for c in ins['insert_cliques']]
    assert data['original_bracket_node_count']==offset and data['insert_clique_count']==len(ig)
    expected=list(map(list,combinations(range(len(ig)),8)));assert [b['insert_cliques'] for b in data['branches']]==expected
    failures=0;removals=0
    for branch in data['branches']:
        active=[set(g) for g in bg+[ig[i] for i in branch['insert_cliques']]]
        assert len(active)==16 and all(active)
        for node,own,other in branch['ordered_removals']:
            assert all(active) and 0<=own<16 and 0<=other<16 and own!=other and node in active[own]
            for target in active[other]:
                assert conflict(nodes[node],nodes[target]);pair_checks+=1
            active[own].remove(node);removals+=1
        assert [sorted(g) for g in active]==branch['remaining_cliques']
        contradiction=not all(active);assert branch['diagnostic_excluded']==contradiction;failures+=contradiction
    assert data['diagnostic_excluded']==(failures==len(expected))
    if failures==len(expected):excluded.append(data['empty_sites'])
    records.append({'empty_sites':data['empty_sites'],'complete_eight_insert_clique_distributions':len(expected),'contradictory_distributions':failures,'remaining_distributions':len(expected)-failures,'ordered_removals_verified':removals,'continuous_fixed29_choice_excluded':failures==len(expected)})
assert load(CAP/'audit/checks.json')['passed'];prior=load(CAP/'audit/retained-choices.json');assert len(prior)==259
removed=set(map(tuple,excluded));assert len(removed)==3 and removed<=set(tuple(r['empty_sites']) for r in prior)
remaining=[r for r in prior if tuple(r['empty_sites']) not in removed];assert len(remaining)==256
write(OUT/'remaining-fixed29-choices.json',remaining)
inputs=[Path(__file__),BASE/'plan.json',BASE/'checks.json',CAP/'audit/plan.json',CAP/'audit/checks.json',CAP/'audit/retained-choices.json']+[BASE/f'choice-{i:02d}.json' for i in range(3)]+[b/n for b in [BR,AC,INS] for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every original bracket and insert has at least one node in the independently complete continuous necessary covers. Bracket candidates already exclude only independently proved impossible nodes. Each original bracket must occupy a distinct one of eight mandatory cliques. Eight original inserts occupy eight distinct cliques of their complete retained cover. Enumerate every such eight-of-k selection exactly once. For each selection independently replay every ordered removal, proving strict source-inner overlap with every active target in another mandatory clique. Inductively every valid packing survives each removal. Each enumerated selection ends with an empty mandatory clique, so no continuous original-source packing can realize this fixed29 plus twelve selected cog poses, even at zero clearance. This excludes only three fixed29 pose selections, not changed poses, changed fixed core or any whole allocation.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,'complete_distributions_verified':sum(r['complete_eight_insert_clique_distributions'] for r in records),'ordered_removals_verified':sum(r['ordered_removals_verified'] for r in records),'strict_source_inner_pair_checks':pair_checks,
    'new_fixed29_choices_excluded':3,'original_fixed29_choices':455,'previous_fixed29_choices_excluded':196,'total_fixed29_choices_excluded':199,'remaining_fixed29_choices':256,
    'continuous_zero_clearance_exclusions':True,'whole_allocations_excluded':0,'whole_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
