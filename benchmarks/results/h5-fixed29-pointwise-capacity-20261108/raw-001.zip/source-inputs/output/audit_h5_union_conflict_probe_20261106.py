"""Independent Cartesian boundary-class replay of the open-rectangle union test."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-union-conflict-probe-20261106';OUT=BASE/'audit'
PREVIOUS=ROOT/'output/h5-first57-joint-optional-trees-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
PROCESS=ROOT/'output/h5-first57-union-conflict-probe-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'boundary-controls.json',
        PREVIOUS/'audit/plan.json',PREVIOUS/'audit/checks.json',PREVIOUS/'audit/joint-graph-witnesses.json',
        SOURCE/'geometry-domains.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,PREVIOUS/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(PREVIOUS/'audit/checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
point_checks=[0]
def classes(lo,hi,rectangles,axis):
    boundaries=sorted({lo,hi}|{r[k] for r in rectangles for k in [axis,axis+2] if lo<=r[k]<=hi})
    return sorted([2*v for v in boundaries]+[a+b for a,b in zip(boundaries,boundaries[1:])])
def covered(box,rectangles):
    xs=classes(box[0],box[2],rectangles,0);ys=classes(box[1],box[3],rectangles,1)
    for x,y in product(xs,ys):
        point_checks[0]+=1
        if not any(2*r[0]<x<2*r[2] and 2*r[1]<y<2*r[3] for r in rectangles):return False
    return True
controls=load(BASE/'boundary-controls.json');assert len(controls)==711
axis=list(combinations([-1,0,1,2],2));rectangles=[[x0,y0,x1,y1] for x0,x1 in axis for y0,y1 in axis]
expected=[[]]+[[r] for r in rectangles]+[[a,b] for a,b in combinations(rectangles,2)]
assert [r['rectangles'] for r in controls[:703]]==expected
assert all(r['box']==[0,0,1,1] for r in controls[:703])
for row in controls:
    exact=covered(row['box'],row['rectangles'])
    assert row['diagnostic_covered']==exact
    if 'expected' in row:assert exact==row['expected']
geometry=load(SOURCE/'geometry-domains.json');witnesses=load(PREVIOUS/'audit/joint-graph-witnesses.json');assert len(witnesses)==32
results=[];additional_pairs=0
for wi,witness in enumerate(witnesses):
    path=BASE/f'witness-{wi:02d}.json';inputs.add(path);data=load(path)
    assert data['source_witness_index']==wi and data['empty_sites']==witness['source_selection']['empty_sites']
    assert data['complete_pairs']==120 and not data['whole_arrangement_excluded']
    cells=witness['bracket_cells']+witness['insert_cells'];expected_edges={}
    for a,b in combinations(range(16),2):
        left,right=cells[a],cells[b]
        lower=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]
        upper=[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
        box=lower+upper;rectangles=[]
        for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um']):
            rectangles.append([ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]])
        assert not any(all(r[i]<box[i] and box[i+2]<r[i+2] for i in [0,1]) for r in rectangles)
        if covered(box,rectangles):expected_edges[(a,b)]=(box,rectangles)
    actual_edges={tuple(e['pair']):e for e in data['new_conflict_edges']}
    assert len(actual_edges)==len(data['new_conflict_edges']) and set(actual_edges)==set(expected_edges)
    for pair,(box,rectangles) in expected_edges.items():
        edge=actual_edges[pair]
        assert edge['relative_anchor_box_um']==box and edge['open_collision_rectangles_um']==rectangles
        assert [c['x_twice'] for c in edge['columns']]==classes(box[0],box[2],rectangles,0)
        for c in edge['columns']:
            x=c['x_twice'];active=[i for i,r in enumerate(rectangles) if 2*r[0]<x<2*r[2]]
            assert c['active_rectangles']==active
            lo,hi=c['spanning_open_y_interval'];assert lo<box[1] and box[3]<hi
            # Certify this open Y component through a strict-overlap interval graph.
            eligible={i for i in active if rectangles[i][1]>=lo and rectangles[i][3]<=hi}
            assert eligible
            reachable={min(eligible,key=lambda i:rectangles[i][1])}
            while True:
                added={i for i in eligible if any(max(rectangles[i][1],rectangles[j][1])<min(rectangles[i][3],rectangles[j][3]) for j in reachable)}
                if added<=reachable:break
                reachable|=added
            assert min(rectangles[i][1] for i in reachable)==lo and max(rectangles[i][3] for i in reachable)==hi
    additional_pairs+=len(expected_edges)
    results.append({'source_witness_index':wi,'empty_sites':data['empty_sites'],
        'new_pair_conflicts_verified':len(expected_edges),'witness_invalid_in_stronger_relaxation':bool(expected_edges)})
assert additional_pairs==44 and sum(r['witness_invalid_in_stronger_relaxation'] for r in results)==29
write(OUT/'retained-joint-graph-witnesses.json',[witnesses[r['source_witness_index']] for r in results if not r['witness_invalid_in_stronger_relaxation']])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'For each cell pair, exact subtraction constructs the complete closed relative-anchor box. Every source-inner component pair contributes an open rectangle where those two interiors overlap. Independently partition both axes at every obstacle boundary and target endpoint. Each Cartesian point/open-interval class has constant rectangle membership, checked with exact doubled integer samples and strict inequalities. Full class coverage proves some source-inner pair overlaps for every possible anchor pair, even if different component pairs cover different classes. The sweep certificate columns and open connected Y components are separately replayed. New conflicts rule out only the particular witness cell selections, not all selections of their arrangement.'})
result={'passed':True,'seconds':time.perf_counter()-started,'boundary_controls_verified':len(controls),
    'complete_witness_pairs_verified':3840,'cartesian_class_point_checks':point_checks[0],
    'new_pair_conflicts_verified':additional_pairs,'witnesses_invalid_in_stronger_relaxation':29,
    'witnesses_without_added_pair_conflict':3,'witnesses':results,'whole_arrangements_excluded':0,
    'remaining_fixed29_choices':52,'total_fixed29_choices_excluded':403,'whole_allocation_candidates':440,
    'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='witnesses'})
