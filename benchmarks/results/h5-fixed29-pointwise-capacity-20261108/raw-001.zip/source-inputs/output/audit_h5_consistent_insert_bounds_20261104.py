from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-consistent-insert-bounds-20261104';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
AC=ROOT/'output/h5-first57-mandatory-clique-consistency-20261104'
def refined_br(index):
    assert load(AC/'audit/checks.json')['passed']
    data=load(BR/f'choice-{index:02d}.json');refined=load(AC/f'choice-{index:02d}.json')
    assert refined['empty_sites']==data['empty_sites'] and not refined['diagnostic_excluded']
    assert len(refined['remaining_cliques'])==len(data['cliques'])==8
    for clique,nodes in zip(data['cliques'],refined['remaining_cliques']):
        assert nodes and set(nodes)<=set(clique['nodes']);clique['nodes']=nodes
    return data
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,BR/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BR/'audit/checks.json')['passed']
geometries=load(SOURCE/'geometry-domains.json')
def certify(a,b,ai,bi):
    ra=geometries[a['geometry']]['inner_rectangles_um'][ai];rb=geometries[b['geometry']]['inner_rectangles_um'][bi]
    for axis in [0,1]:
        assert a['bounds_um'][axis+2]+ra[axis] < b['bounds_um'][axis]+rb[axis+2]
        assert b['bounds_um'][axis+2]+rb[axis] < a['bounds_um'][axis]+ra[axis+2]
checks=[];mandatory_certificates=clique_certificates=0
for choice,empty in enumerate([[0,4,14],[5,11,13],[5,11,14]]):
    data=load(BASE/f'choice-{choice:02d}.json');br=refined_br(choice)
    assert data['empty_sites']==br['empty_sites']==empty and br['bracket_capacity_upper_bound']==8
    expected={};bits=sum(1<<i for i in empty)
    for gid in [8,9]:
        for ri,(mask,x,y,z,w,*_) in enumerate(load(COVER/f'geometry-{gid:02d}-cover.json')):
            if mask&~bits:continue
            nx=max(1,(z-x+49999)//50000);ny=max(1,(w-y+49999)//50000)
            for xi in range(nx):
                for yi in range(ny):expected[(gid,ri,xi,yi)]=[x+xi*50000,y+yi*50000,min(z,x+(xi+1)*50000),min(w,y+(yi+1)*50000)]
    nodes=data['nodes'];actual={}
    for i,node in enumerate(nodes):
        assert node['node']==i
        key=(node['geometry'],node['cover_box'],*node['cell']);assert key not in actual;actual[key]=node['bounds_um']
    assert actual==expected and len(nodes)==len(expected)
    removed=set()
    for row in data['removed']:
        index=row['insert_node'];assert index not in removed;removed.add(index)
        clique=br['cliques'][row['mandatory_bracket_clique']]
        proofs=row['strict_overlap_certificates'];assert [p[0] for p in proofs]==clique['nodes']
        for b,ai,bi in proofs:certify(nodes[index],br['nodes'][b],ai,bi);mandatory_certificates+=1
    retained=data['retained'];assert retained==sorted(set(range(len(nodes)))-removed)
    assert len(retained)==len(data['retained_self_certificates'])
    for i,proof in zip(retained,data['retained_self_certificates']):certify(nodes[i],nodes[i],*proof)
    seen=set()
    for clique in data['insert_cliques']:
        group=clique['nodes'];assert group and len(group)==len(set(group)) and not seen.intersection(group);seen.update(group)
        expected_pairs={(a,b) for k,a in enumerate(group) for b in group[k+1:]};actual_pairs=set()
        for a,b,ai,bi in clique['strict_overlap_certificates']:
            assert (a,b) in expected_pairs and (a,b) not in actual_pairs;actual_pairs.add((a,b))
            certify(nodes[a],nodes[b],ai,bi);clique_certificates+=1
        assert actual_pairs==expected_pairs
    assert seen==set(retained);capacity=len(data['insert_cliques'])
    assert capacity==data['insert_capacity_upper_bound']==min(data['candidate_cover_counts']) and data['diagnostic_excluded']==(capacity<8)
    checks.append({'empty_sites':empty,'complete_insert_cells':len(nodes),'certified_removed_cells':len(removed),'remaining_cells':len(retained),'continuous_insert_capacity_upper_bound':capacity,'excluded':capacity<8})
inputs=[Path(__file__),ROOT/'output/prepare_h5_consistent_clique_helpers_20261104.py',AC/'audit/plan.json',AC/'audit/checks.json',AC/'choice-00.json',AC/'choice-01.json',AC/'choice-02.json',BASE/'plan.json',BASE/'checks.json',BR/'audit/plan.json',BR/'audit/checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(3)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'The independent bracket proof gives eight cliques for eight required originals. Any valid packing must occupy every clique. For every removed insert subcell, every node of one mandatory bracket clique has a certified strictly overlapping source-inner rectangle pair for all anchors. Thus no valid insert can occupy the removed subcell. The original necessary continuous insert cover is completely subdivided, and every unremoved cell is covered by the verified insert-clique partition. This bounds inserts conditionally on all eight required brackets, even at zero clearance. No packing existence is inferred from an upper bound of at least eight.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':checks,'mandatory_clique_pair_certificates':mandatory_certificates,'insert_clique_pair_certificates':clique_certificates,
    'conditional_continuous_source_bound':True,'new_site_choices_excluded':sum(c['excluded'] for c in checks),'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
