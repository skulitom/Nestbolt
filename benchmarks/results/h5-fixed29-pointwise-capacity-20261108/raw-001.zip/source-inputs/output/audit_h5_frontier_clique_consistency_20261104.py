from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-frontier-clique-consistency-20261104';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
selected=load(BR/'audit/mandatory-eight-clique-choices.json')
assert len(selected)==38 and len({r['choice_index'] for r in selected})==38
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,BR/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BR/'audit/checks.json')['passed'];geometry=load(SOURCE/'geometry-domains.json')
def overlapping(a,b,ai,bi):
    ra=geometry[a['geometry']]['inner_rectangles_um'][ai];rb=geometry[b['geometry']]['inner_rectangles_um'][bi]
    return all(a['bounds_um'][axis+2]+ra[axis]<b['bounds_um'][axis]+rb[axis+2] and b['bounds_um'][axis+2]+rb[axis]<a['bounds_um'][axis]+ra[axis+2] for axis in [0,1])
def compatible(a,b):
    return not any(overlapping(a,b,ai,bi) for ai in range(len(geometry[a['geometry']]['inner_rectangles_um'])) for bi in range(len(geometry[b['geometry']]['inner_rectangles_um'])))
records=[];certificates=0
for i in range(len(selected)):
    data=load(BASE/f'choice-{i:02d}.json');br=load(BR/f"choice-{selected[i]['choice_index']:02d}.json");nodes=br['nodes'];assert data['empty_sites']==br['empty_sites']==selected[i]['empty_sites'] and br['bracket_capacity_upper_bound']==8
    active=[set(g['nodes']) for g in br['cliques']]
    for row in data['ordered_removals']:
        node,own,other=row['node'],row['own_clique'],row['other_clique'];assert own!=other and node in active[own] and active[other]
        assert [p[0] for p in row['targets']]==sorted(active[other])
        for target,ai,bi in row['targets']:
            assert overlapping(nodes[node],nodes[target],ai,bi);certificates+=1
        active[own].remove(node)
    assert [sorted(g) for g in active]==data['remaining_cliques'];excluded=not all(active);assert excluded==data['diagnostic_excluded']
    if not excluded:
        for own,group in enumerate(active):
            for node in group:
                for other,targets in enumerate(active):
                    if own!=other:assert any(compatible(nodes[node],nodes[b]) for b in targets)
    records.append({'empty_sites':data['empty_sites'],'removed_nodes':len(data['ordered_removals']),'remaining_counts':[len(g) for g in active],'fixed_point_verified':not excluded,'excluded':excluded})
prior=load(BR/'audit/remaining-fixed29-choices.json');assert len(prior)==105
excluded={tuple(r['empty_sites']) for r in records if r['excluded']}
remaining=[r for r in prior if tuple(r['empty_sites']) not in excluded]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'consistent-mandatory-choices.json',[{'consistency_index':i,**selected[i]} for i,r in enumerate(records) if not r['excluded']])
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_consistency_helpers_20261104.py',BR/'audit/mandatory-eight-clique-choices.json',BR/'audit/remaining-fixed29-choices.json',BASE/'plan.json',BASE/'checks.json',BR/'audit/plan.json',BR/'audit/checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(len(selected))]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every valid packing selects one node per original certified clique. Replay removals in order. A node that strictly conflicts with all still-possible nodes in another mandatory clique cannot be selected; the complete active target set and every original source-inner overlap are checked. Induction preserves every valid packing. An empty mandatory clique is a continuous contradiction; otherwise verify pairwise support to every other clique at the final fixed point, without claiming packing existence.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,'ordered_removals_verified':sum(r['removed_nodes'] for r in records),'strict_pair_certificates_verified':certificates,'new_site_choices_excluded':sum(r['excluded'] for r in records),'previous_fixed29_choices_excluded':350,'remaining_fixed29_choices':len(remaining),'total_fixed29_choices_excluded':350+len(excluded),'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
