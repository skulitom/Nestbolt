from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-exact-circle-graphs-20261107';OUT=BASE/'audit'
UNION=ROOT/'output/h5-refined-polygon-union-20261107';RAW=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PROCESS=ROOT/'output/h5-exact-circle-graphs-process-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'cells.json',BASE/'certificates.json',RAW/'integer-source.json',RAW/'collision-polygons.json',RAW/'audit/plan.json',RAW/'audit/checks.json',UNION/'audit/plan.json',UNION/'audit/checks.json',SRC/'geometry-domains.json',JOB,PROCESS/'prepare.json',PROCESS/'opened.json'}
for folder in [BASE,RAW/'audit',UNION/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(RAW/'audit/checks.json')['passed'] and load(UNION/'audit/checks.json')['passed'] and load(PROCESS/'prepare.json')['passed'] and load(PROCESS/'prepare.json')['job']['active_processes']==0
assert F(200,1000)<=F(load(JOB)['clearance']) and plan['strict_radius_um']==200
assert plan['selection']==load(UNION/'audit/checks.json')['choices']
raw=load(RAW/'integer-source.json');D=int(raw['scaled_units_per_micrometre']);shifts=[tuple(map(int,r['translation_scaled'])) for r in raw['sites']]
templates=load(RAW/'collision-polygons.json');polys=[[tuple(map(int,p)) for p in t['vertices_scaled']] for t in templates]
cells=load(BASE/'cells.json');certs=load(BASE/'certificates.json');geom=load(SRC/'geometry-domains.json');corner_count=0;distance_checks=0
assert all(i==c['cell'] for i,c in enumerate(cells)) and len({(c['geometry'],*c['bounds_um']) for c in cells})==len(cells)
for i,cert in enumerate(certs):
    assert cert['certificate']==i;cell=cells[cert['cell']];ti=cert['template'];assert templates[ti]['geometry']==cell['geometry'];poly=polys[ti];sx,sy=shifts[cert['site']]
    x0,y0,x1,y1=cell['bounds_um'];assert x0<=x1 and y0<=y1 and len(cert['corners'])==4
    for (x,y),proof in zip(product([x0,x1],[y0,y1]),cert['corners']):
        p=(x*D-sx,y*D-sy)
        if proof.get('inside'):
            assert all(cross(a,b,p)>=0 for a,b in zip(poly,poly[1:]+poly[:1]));q=p
        else:
            e=proof['edge'];assert 0<=e<len(poly);a,b=poly[e],poly[(e+1)%len(poly)]
            t=F(proof['parameter']) if 'parameter' in proof else F(int(proof['numerator']),int(proof['denominator']))
            assert 0<=t<=1;q=(F(a[0])+t*(b[0]-a[0]),F(a[1])+t*(b[1]-a[1]))
        assert (F(p[0])-q[0])**2+(F(p[1])-q[1])**2<(200*D)**2;corner_count+=1
results=[];all_pairs=0
for row in plan['selection']:
    old=ROOT/row['graph'];folder=BASE/f"choice-{row['refinement_index']:02d}";original=load(old/'nodes.json');N=len(original)
    for name in ['checks.json','nodes.json','kept-old-node-ids.json','removed.json','added-edges.json','root-covers.json','conflicts.bin']:inputs.add(folder/name)
    removed=load(folder/'removed.json');removed_ids=set()
    for record in removed:
        i=record['old_graph_node'];assert 0<=i<N and i not in removed_ids;removed_ids.add(i);proof=certs[record['certificate']];cell=cells[proof['cell']]
        assert proof['site'] not in row['empty_sites'] and (cell['geometry'],cell['bounds_um'])==(original[i]['geometry'],original[i]['bounds_um'])
    kept=load(folder/'kept-old-node-ids.json');ns=load(folder/'nodes.json');assert kept==[i for i in range(N) if i not in removed_ids] and ns==[original[i] for i in kept];n=len(ns)
    oldmatrix=np.unpackbits(np.frombuffer((old/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(N,(N+7)//8),axis=1,bitorder='little')[:,:N].astype(bool)
    expected=oldmatrix[np.ix_(kept,kept)].copy();edges=load(folder/'added-edges.json');seen=set()
    for e in edges:
        a,b=e['a'],e['b'];assert 0<=a<b<n and (a,b) not in seen and not expected[a,b];seen.add((a,b))
        ra=geom[ns[a]['geometry']]['inner_rectangles_um'][e['component_a']];rb=geom[ns[b]['geometry']]['inner_rectangles_um'][e['component_b']]
        rectangle=(ra[0]-rb[2],ra[1]-rb[3],ra[2]-rb[0],ra[3]-rb[1]);A,B=ns[a]['bounds_um'],ns[b]['bounds_um']
        # Independent pointwise clamping at all four closed relative-box corners.
        for x,y in product([B[0]-A[2],B[2]-A[0]],[B[1]-A[3],B[3]-A[1]]):
            qx=min(rectangle[2],max(rectangle[0],x));qy=min(rectangle[3],max(rectangle[1],y))
            assert (x-qx)**2+(y-qy)**2<40000;distance_checks+=1
        expected[a,b]=expected[b,a]=True
    unpacked=np.unpackbits(np.frombuffer((folder/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(n,(n+7)//8),axis=1,bitorder='little');assert not np.any(unpacked[:,n:]);actual=unpacked[:,:n].astype(bool)
    assert np.array_equal(actual,expected) and np.all(actual==actual.T) and np.all(np.diag(actual));all_pairs+=n*(n-1)//2
    inverse={v:i for i,v in enumerate(kept)};covers=load(folder/'root-covers.json');oldcovers=load(old/'root-covers.json');expectedcovers=[[[inverse[i] for i in group if i in inverse] for group in family] for family in oldcovers];expectedcovers=[[g for g in family if g] for family in expectedcovers];assert covers==expectedcovers
    for f,groups in enumerate(covers):
        assert sorted(i for g in groups for i in g)==[i for i,node in enumerate(ns) if node['family']==f] and all(np.all(actual[np.ix_(g,g)]) for g in groups)
    gc=load(folder/'checks.json');assert gc['removed_nodes']==len(removed) and gc['added_edges']==len(edges) and gc['genuinely_stronger']==bool(removed or edges) and gc['conflict_bytes_sha256']==digest(folder/'conflicts.bin')
    combined_removed=len(removed)+row['removed_nodes'];combined_stronger=bool(combined_removed or edges);assert gc['combined_new_removals_including_union']==combined_removed and gc['combined_genuinely_stronger']==combined_stronger
    results.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source_selection':row['source_selection'],'graph':folder.relative_to(ROOT).as_posix(),'removed_nodes':len(removed),'added_edges':len(edges),'combined_new_removals_including_union':combined_removed,'combined_genuinely_stronger':combined_stronger,'retained_nodes':n,'root_clique_counts':list(map(len,covers))})
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},'proof':'Original unexpanded cog/source-inner Minkowski hulls are independently certified upstream. For each closed-cell corner, exact rational arithmetic supplies a point on a source hull edge or inside the hull at distance strictly below200um. Convex combinations of these source points remain in the same convex hull and combinations of their error vectors remain strictly inside the200um disk, so the entire closed cell is forbidden. Each added pair edge independently clamps every relative-anchor-box corner onto one original source-inner difference rectangle and checks exact squared distance<40000um2; the same convexity argument covers the whole box. Full graph equality preserves inherited conflicts and adds only certified edges. Retained cells/aliases/boundaries and complete conflict-clique partitions remain exact. Combined source-change flags include the separately audited one-cell union removal; unchanged cases cannot justify a new call.'})
result={'passed':True,'seconds':time.perf_counter()-start,'choices':results,'cog_corner_distance_certificates':corner_count,'pair_corner_distance_checks':distance_checks,'new_cog_cell_removals':sum(r['removed_nodes'] for r in results),'new_pair_conflicts':sum(r['added_edges'] for r in results),'combined_new_cell_removals':sum(r['combined_new_removals_including_union'] for r in results),'cases_with_genuine_combined_source_changes':sum(r['combined_genuinely_stronger'] for r in results),'all_retained_graph_pairs':all_pairs,'whole_arrangements_excluded':0,'remaining_fixed29_choices':4,'solver_calls':0,'native_validation_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);write(OUT/'stronger-model-candidates.json',[r for r in results if r['combined_genuinely_stronger']]);print(json.dumps(result),flush=True)
