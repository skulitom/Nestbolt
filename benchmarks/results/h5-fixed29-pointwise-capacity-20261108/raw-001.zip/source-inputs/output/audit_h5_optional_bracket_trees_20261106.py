from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from functools import lru_cache
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-optional-bracket-trees-20261106';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104'
FRONTIER=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
PROCESS=ROOT/'output/h5-first57-optional-bracket-trees-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',SOURCE/'geometry-domains.json',
        FRONTIER/'audit/remaining-fixed29-choices.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,BR/'audit',FRONTIER/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR,FRONTIER]:
    inputs.add(base/'audit/checks.json');assert load(base/'audit/checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
prior=load(FRONTIER/'audit/remaining-fixed29-choices.json');assert len(prior)==68
remaining_set={tuple(r['empty_sites']) for r in prior}
selection=[{'choice_index':i,'empty_sites':r['empty_sites'],'nodes':r['nodes'],
            'root_clique_count':r['continuous_bracket_capacity_upper_bound']}
           for i,r in enumerate(load(BR/'audit/checks.json')['choices'])
           if tuple(r['empty_sites']) in remaining_set and r['continuous_bracket_capacity_upper_bound']>8]
plan=load(BASE/'plan.json')
assert plan['selection']==selection and len(selection)==67
assert plan['per_choice_seconds']==0.45 and plan['maximum_expanded_nodes_per_choice']==5000
geometry=load(SOURCE/'geometry-domains.json');results=[];excluded=[];witnesses=[];pair_count=0
for choice,row in enumerate(selection):
    path=BASE/f'choice-{choice:02d}.json';source=BR/f"choice-{row['choice_index']:02d}.json";inputs.update([path,source])
    data=load(path);br=load(source);nodes=br['nodes']
    assert data['source_selection']==row and data['empty_sites']==br['empty_sites']==row['empty_sites']
    assert len(nodes)==row['nodes'] and len(br['cliques'])==row['root_clique_count']
    evaluated=[0]
    @lru_cache(maxsize=None)
    def conflict(a,b):
        evaluated[0]+=1
        x0,y0,x1,y1=nodes[a]['bounds_um'];u0,v0,u1,v1=nodes[b]['bounds_um']
        for ax0,ay0,ax1,ay1 in geometry[nodes[a]['geometry']]['inner_rectangles_um']:
            for bx0,by0,bx1,by1 in geometry[nodes[b]['geometry']]['inner_rectangles_um']:
                if x1+ax0<u0+bx1 and u1+bx0<x0+ax1 and y1+ay0<v0+by1 and v1+by0<y0+ay1:return True
        return False
    for n in range(len(nodes)):assert conflict(n,n)
    records=data['records'];seen=set();opened=[];found=[];expanded=[0]
    stats={'branch_cliques':0,'closed_count_leaves':0,'closed_cover_pair_checks':0,
           'branch_clique_pair_checks':0,'time_or_node_limit_leaves':0}
    def replay(index,candidates,chosen):
        assert isinstance(index,int) and 0<=index<len(records) and index not in seen
        seen.add(index);record=records[index];assert record['node']==index
        assert len(chosen)==len(set(chosen))<=8 and not candidates.intersection(chosen)
        for a,b in combinations(chosen,2):assert not conflict(a,b)
        for a in chosen:
            for b in candidates:assert not conflict(a,b)
        kind=record['kind']
        if kind=='open':
            assert record['reason'] in ['earlier_necessary_graph_witness','time_or_expansion_limit','graph_preparation_limit']
            if record['reason']=='earlier_necessary_graph_witness':assert found
            elif record['reason']=='graph_preparation_limit':assert not data['graph_complete']
            else:
                stats['time_or_node_limit_leaves']+=1
                assert expanded[0]>=5000 or data['case_seconds']>=0.45 or load(BASE/'checks.json')['seconds']>=35
            opened.append(index);return False
        assert data['graph_complete'];expanded[0]+=1
        if kind=='open_graph_witness':
            assert len(chosen)==8 and record['witness']==chosen
            found.append(list(chosen));opened.append(index);return False
        need=8-len(chosen);assert need>0
        if kind=='closed_count_cover':
            cover=record['cover'];flat=[v for g in cover for v in g]
            assert len(flat)==len(set(flat)) and set(flat)==candidates and all(cover)
            assert len(cover)<need
            for group in cover:
                for a,b in combinations(group,2):
                    assert conflict(a,b);stats['closed_cover_pair_checks']+=1
            stats['closed_count_leaves']+=1;return True
        assert kind=='branch_clique'
        group=record['clique'];assert group and len(group)==len(set(group)) and set(group)<=candidates
        for a,b in combinations(group,2):
            assert conflict(a,b);stats['branch_clique_pair_checks']+=1
        children=record['children'];values=[r['value'] for r in children]
        assert len(values)==len(set(values)) and set(values)==set(group)
        stats['branch_cliques']+=1;closed=[]
        for child in children:
            value=child['value']
            child_candidates={n for n in candidates if n!=value and not conflict(n,value)}
            closed.append(replay(child['node'],child_candidates,chosen+[value]))
        closed.append(replay(record['skip'],candidates-set(group),list(chosen)))
        return all(closed)
    closed=replay(data['root'],set(range(len(nodes))),[])
    assert seen==set(range(len(records))) and sorted(opened)==data['open_nodes']
    assert data['diagnostic_excluded']==closed==(not opened)
    assert data['expanded_nodes']==expanded[0]<=5000
    assert 0<=data['case_seconds']<0.45
    assert len(found)<=1 and data['necessary_graph_witness']==(found[0] if found else None)
    if closed:excluded.append(row['empty_sites'])
    if found:witnesses.append({'source_selection':row,'bracket_nodes':found[0],
                               'bracket_cells':[nodes[n] for n in found[0]],'source_placement':False})
    pair_count+=evaluated[0]
    results.append({'empty_sites':row['empty_sites'],'tree_records_verified':len(records),**stats,
        'strict_source_inner_pair_evaluations':evaluated[0],'open_leaves':len(opened),
        'necessary_graph_witness':bool(found),'continuous_fixed29_choice_excluded':closed})
removed=set(map(tuple,excluded));assert len(removed)==len(excluded) and removed<=remaining_set
remaining=[r for r in prior if tuple(r['empty_sites']) not in removed]
write(OUT/'remaining-fixed29-choices.json',remaining);write(OUT/'necessary-graph-witnesses.json',witnesses)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Every original bracket occupies at least one cell of the independently complete continuous source cover. Self-conflicts allow at most one original per cell. Every selected branching clique is pairwise conflicting, so choosing each member once or skipping every member partitions all independent selections. Include children preserve exactly all nonconflicting candidates. Closed leaves have a complete disjoint conflict-clique cover smaller than the remaining required count. Every record is visited exactly once; all open leaves are preserved and prevent exclusion. The necessary graph witnesses assert no actual source placement. Only entirely closed trees exclude fixed29/current cog poses at zero clearance; no changed core, cog poses or whole allocation are excluded.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,
    'tree_records_verified':sum(r['tree_records_verified'] for r in results),
    'branch_cliques_verified':sum(r['branch_cliques'] for r in results),
    'closed_count_leaves_verified':sum(r['closed_count_leaves'] for r in results),
    'closed_cover_pair_checks':sum(r['closed_cover_pair_checks'] for r in results),
    'branch_clique_pair_checks':sum(r['branch_clique_pair_checks'] for r in results),
    'strict_source_inner_pair_evaluations':pair_count,
    'necessary_graph_witnesses':len(witnesses),'budget_limited_cases':[r['empty_sites'] for r in results if r['time_or_node_limit_leaves']],
    'new_fixed29_choices_excluded':len(removed),'original_fixed29_choices':455,
    'previous_fixed29_choices_excluded':387,'total_fixed29_choices_excluded':387+len(removed),
    'remaining_fixed29_choices':len(remaining),'whole_allocations_excluded':0,'whole_allocation_candidates':440,
    'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result)
print({k:v for k,v in result.items() if k!='choices'})
