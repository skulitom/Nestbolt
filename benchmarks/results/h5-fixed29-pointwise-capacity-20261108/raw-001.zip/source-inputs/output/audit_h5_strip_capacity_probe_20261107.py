"""Independently certify common-line strip capacity and graph-only violations."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-probe-20261107';OUT=BASE/'audit';PROCESS=ROOT/'output/h5-strip-capacity-probe-process-20261107'
SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',SRC/'geometry-domains.json',SRC/'audit/plan.json',SRC/'audit/checks.json',JOB,PROCESS/'opened.json',PROCESS/'prepare.json'}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h,p
assert load(PROCESS/'prepare.json')['passed'] and load(PROCESS/'prepare.json')['job']['active_processes']==0
assert load(SRC/'audit/checks.json')['passed']
for p,h in load(SRC/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
assert F(load(JOB)['clearance'])>=F(1,5) and plan['source_gap_um']==200
geom=load(SRC/'geometry-domains.json');results=[];capacity_constraints=[];member_checks=pair_checks=0
for row,reported in zip(plan['selection'],prepared['choices']):
    folder=BASE/f"choice-{row['refinement_index']:02d}";source=ROOT/row['graph'];gc=load(source/'checks.json');nodes=load(source/'nodes.json');n=len(nodes);rb=gc['row_bytes'];raw=(source/'conflicts.bin').read_bytes()
    assert digest(source/'conflicts.bin')==gc['conflict_bytes_sha256'] and reported==load(folder/'checks.json') and reported['case_complete_cap_overrun_seconds']==0 and reported['case_seconds']<12
    inputs.update([folder/'checks.json',folder/'candidate-order.json'])
    if not reported['capacity_witness_found']:
        assert not (folder/'capacity-certificate.json').exists();results.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source_capacity_not_implied_by_pairs_proved':False,'no_absence_claim':True});continue
    cert=load(folder/'capacity-certificate.json');inputs.add(folder/'capacity-certificate.json');axis=cert['axis'];other=1-axis;line=F(cert['line_doubled_um'],2);left,right=cert['strip_um'];gap=cert['gap_um'];assert axis in [0,1] and gap==200 and left<right
    assert cert['graph']==row['graph'] and cert['empty_sites']==row['empty_sites'] and not cert['source_valid_placement'] and not cert['full_model_witness']
    expected=[]
    for ni,node in enumerate(nodes):
        bounds=node['bounds_um'];eligible=[]
        for ri,rectangle in enumerate(geom[node['geometry']]['inner_rectangles_um']):
            band_lower=bounds[other+2]+rectangle[other];band_upper=bounds[other]+rectangle[other+2]
            extent=[bounds[axis]+rectangle[axis],bounds[axis+2]+rectangle[axis+2]]
            if band_lower<=line<=band_upper and left<=extent[0] and extent[1]<=right:
                width=rectangle[axis+2]-rectangle[axis];assert width>0;eligible.append({'node':ni,'component':ri,'width_um':width,'extent_um':extent})
        if eligible:expected.append(max(eligible,key=lambda r:(r['width_um'],-r['component'])))
    assert cert['members']==expected;member_checks+=len(expected);members={r['node']:r for r in expected};selected=cert['selected_nodes']
    assert len(selected)==len(set(selected)) and len(selected)>=3 and set(selected)<=set(members)
    for a,b in combinations(selected,2):
        assert not(raw[a*rb+b//8]>>(b%8)&1) and not(raw[b*rb+a//8]>>(a%8)&1);pair_checks+=1
    counts=[sum(nodes[i]['family']==f for i in selected) for f in [0,1]];assert counts==cert['selected_family_counts'] and all(c<=8 for c in counts)
    capacity=right-left+gap;weight=sum(members[i]['width_um']+gap for i in selected)
    assert weight==cert['selected_weight_um'] and capacity==cert['capacity_um'] and weight-capacity==cert['strict_excess_um']>0
    q=cert['quantum_um'];assert q in plan['quantum_candidates_descending_um']
    weights=[{'node':m['node'],'weight':(m['width_um']+gap)//q} for m in expected];weighted={m['node']:m['weight'] for m in weights};bound=capacity//q
    assert all(m['weight']>0 for m in weights) and sum(weighted[i] for i in selected)==cert['quantized_selected_weight']>bound==cert['quantized_capacity']
    # For any valid placement, common-line source intervals are pairwise separated
    # by at least200um. Ordering their disjoint intervals gives sum(width)+(k-1)gap
    # <=strip_span for k>=1. k=0 also satisfies sum(width+gap)<=strip_span+gap.
    # Downward floor weights preserve this inequality for every selector subset.
    constraint={'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'graph':row['graph'],'axis':axis,'line_doubled_um':cert['line_doubled_um'],'strip_um':[left,right],'source_gap_um':200,'quantum_um':q,'terms':weights,'maximum':bound,'pair_graph_counterexample':selected,'counterexample_family_counts':counts,'counterexample_excess':sum(weighted[i] for i in selected)-bound,'source_certificate':(folder/'capacity-certificate.json').relative_to(ROOT).as_posix(),'source_capacity_not_implied_by_pairs_proved':True,'full_model_counterexample_claimed':False}
    capacity_constraints.append(constraint);results.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'members':len(expected),'selected_nodes':len(selected),'selected_family_counts':counts,'strict_excess_um':weight-capacity,'quantum_um':q,'quantized_capacity':bound,'quantized_excess':constraint['counterexample_excess'],'source_capacity_not_implied_by_pairs_proved':True})
assert len(results)==4
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},'proof':'Every included source-inner rectangle crosses the certified line for every anchor in the original closed cell and stays wholly inside the specified strip along that line. Distinct placed parts have original Euclidean clearance at least200um, so their intervals on the same line have at least200um separation. Sorting the k selected intervals proves sum(width)+(k-1)*200<=strip_span for k>=1; the equivalent shifted bound sum(width+200)<=strip_span+200 also covers k=0. Each cell contributes at most one certified component. Downward quantization preserves the bound. Every reported violating partial selection has unique cells, no source-graph conflict and at most8 per family. It proves the capacity is not implied by pair clauses alone, not that a full-model witness or placement exists. Missing or limited probes yield no absence/exclusion claim.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'choices':results,'source_members_verified':member_checks,'nonconflicting_counterexample_pairs_verified':pair_checks,'independently_certified_capacity_constraints':len(capacity_constraints),'whole_arrangements_excluded':0,'remaining_fixed29_choices':4,'SAT_calls':0,'native_validation_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);write(OUT/'capacity-constraints.json',capacity_constraints);print(json.dumps(checks),flush=True)
