from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-broader-insert-covers-20261106';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';FRONTIER=ROOT/'output/h5-first57-optional-bracket-trees-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
PROCESS=ROOT/'output/h5-first57-broader-insert-covers-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',SOURCE/'geometry-domains.json',
        FRONTIER/'audit/remaining-fixed29-choices.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,BR/'audit',FRONTIER/'audit',COVER/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR,FRONTIER,COVER]:
    inputs.add(base/'audit/checks.json');assert load(base/'audit/checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
prior=load(FRONTIER/'audit/remaining-fixed29-choices.json');assert len(prior)==63
remaining_set={tuple(r['empty_sites']) for r in prior}
selection=[{'choice_index':i,'empty_sites':r['empty_sites'],'bracket_nodes':r['nodes'],
            'bracket_clique_bound':r['continuous_bracket_capacity_upper_bound']}
           for i,r in enumerate(load(BR/'audit/checks.json')['choices']) if tuple(r['empty_sites']) in remaining_set]
assert load(BASE/'plan.json')['selection']==selection and len(selection)==63
geometry=load(SOURCE/'geometry-domains.json');checks=[];pair_count=0;cell_count=0
def certify(a,b,ai,bi):
    ra=geometry[a['geometry']]['inner_rectangles_um'][ai];rb=geometry[b['geometry']]['inner_rectangles_um'][bi]
    for axis in [0,1]:
        assert a['bounds_um'][axis+2]+ra[axis]<b['bounds_um'][axis]+rb[axis+2]
        assert b['bounds_um'][axis+2]+rb[axis]<a['bounds_um'][axis]+ra[axis+2]
for choice,row in enumerate(selection):
    path=BASE/f'choice-{choice:02d}.json';source=BR/f"choice-{row['choice_index']:02d}.json";inputs.update([path,source])
    data=load(path);br=load(source)
    assert data['source_selection']==row and data['empty_sites']==br['empty_sites']==row['empty_sites']
    assert len(br['nodes'])==row['bracket_nodes'] and len(br['cliques'])==row['bracket_clique_bound']
    bits=sum(1<<i for i in row['empty_sites']);expected={}
    for gid in [8,9]:
        p=COVER/f'geometry-{gid:02d}-cover.json';inputs.add(p)
        for ri,(mask,x,y,z,w,*_) in enumerate(load(p)):
            if mask&~bits:continue
            for xi in range(max(1,(z-x+49999)//50000)):
                for yi in range(max(1,(w-y+49999)//50000)):
                    expected[(gid,ri,xi,yi)]=[x+xi*50000,y+yi*50000,min(z,x+(xi+1)*50000),min(w,y+(yi+1)*50000)]
    nodes=data['nodes'];actual={}
    assert len(nodes)==len(data['self_certificates'])
    for i,(node,proof) in enumerate(zip(nodes,data['self_certificates'])):
        assert node['node']==i
        key=(node['geometry'],node['cover_box'],*node['cell']);assert key not in actual
        actual[key]=node['bounds_um'];certify(node,node,*proof)
    assert actual==expected and len(nodes)==len(expected)
    covered=set();case_pairs=0
    for group in data['insert_cliques']:
        values=group['nodes'];assert values and len(values)==len(set(values)) and not covered.intersection(values)
        covered.update(values)
        pairs=list(combinations(values,2))
        assert [tuple(p[:2]) for p in group['strict_overlap_certificates']]==pairs
        for a,b,ai,bi in group['strict_overlap_certificates']:
            certify(nodes[a],nodes[b],ai,bi);case_pairs+=1
    assert covered==set(range(len(nodes)))
    count=len(data['insert_cliques'])
    assert data['insert_capacity_upper_bound']==count==min(data['candidate_cover_counts'])
    assert data['diagnostic_excluded']==(count<8)
    pair_count+=case_pairs;cell_count+=len(nodes)
    checks.append({'insert_choice_index':choice,**row,'complete_insert_cells':len(nodes),
                   'insert_clique_bound':count,'insert_pair_certificates':case_pairs,'excluded':count<8})
removed={tuple(r['empty_sites']) for r in checks if r['excluded']}
remaining=[r for r in prior if tuple(r['empty_sites']) not in removed]
write(OUT/'joint-candidates.json',[r for r in checks if not r['excluded']])
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Independently reconstruct every eligible continuous anchor box from the previously complete source-inner mask cover for both insert geometries and all their legal aliases. Closed50mm subdivisions retain every boundary and degenerate-axis class. No cells are removed. Every cell self-conflicts and every pair in each complete disjoint insert clique has exact strict source-inner overlap. Thus the cover count bounds original inserts; no placement existence is inferred.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':checks,
    'complete_insert_cells_verified':cell_count,'insert_clique_pair_certificates':pair_count,
    'new_fixed29_choices_excluded':len(removed),'total_fixed29_choices_excluded':392+len(removed),
    'remaining_fixed29_choices':len(remaining),'whole_allocations_excluded':0,'whole_allocation_candidates':440,
    'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
