from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time
from h5_weighted_capacity_encoding_20261107 import atmost
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-weighted-capacity-controls-20261107';OUT.mkdir();start=time.perf_counter();vectors=assignments=prefixes=0
for n in range(5):
    for weights in product(range(1,4),repeat=n):
        vectors+=1
        for limit in range(sum(weights)+2):
            clauses,gates,top,final=atmost(list(range(1,n+1)),list(weights),limit,n)
            for selected in product([False,True],repeat=n):
                values={i+1:x for i,x in enumerate(selected)}
                for gate in gates:
                    val=lambda x:x if type(x) is bool else values[x]
                    actual=val(gate['a']) or(val(gate['x']) and val(gate['b']))
                    expected=sum(w for w,x in zip(weights[:gate['i']],selected[:gate['i']]) if x)>=gate['j']
                    assert actual==expected;values[gate['y']]=actual;prefixes+=1
                satisfied=all(any(values[abs(l)]==(l>0) for l in clause) for clause in clauses)
                assert satisfied==(sum(w for w,x in zip(weights,selected) if x)<=limit);assignments+=1
result={'passed':True,'weight_vectors_including_empty':vectors,'selector_bound_assignments':assignments,'exact_weighted_prefix_checks':prefixes,'seconds':time.perf_counter()-start,'helper_sha256':sha256((ROOT/'output/h5_weighted_capacity_encoding_20261107.py').read_bytes()).hexdigest(),'SAT_calls':0,'claim':'All selector assignments for0..4inputs, weights1..3 and every bound0..sum+1; full research audits separately verify every local gate truth table, unique acyclic circuit, source class equivalence and exact final bound.'}
for name,value in [('checks.json',result),('plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'output/h5_weighted_capacity_encoding_20261107.py',ROOT/'output/h5_sat_encoding_20261107.py']}})]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(result)
