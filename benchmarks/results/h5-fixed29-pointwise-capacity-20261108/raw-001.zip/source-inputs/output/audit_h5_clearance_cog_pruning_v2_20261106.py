"""Independently certify exact source collision polygons and complete retained domains."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import json,time,shutil,math
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-clearance-cog-pruning-20261106';OUT=BASE/'audit-v2'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';FRONTIER=ROOT/'output/h5-first57-cog-union-subdivision-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
PROCESS=ROOT/'output/h5-first57-clearance-cog-pruning-process-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/audit_h5_clearance_cog_pruning_20261106.py',ROOT/'output/prepare_h5_clearance_cog_audit_v2_20261106.py',ROOT/'output/h5-clearance-proof-scope-correction-20261106.json',ROOT/'output/prepare_h5_clearance_cog_audit_20261106.py',ROOT/'output/audit_h5_source_cog_cell_pruning_20261106.py',JOB,FRONTIER/'plan.json',BASE/'plan.json',BASE/'checks.json',BASE/'integer-source.json',BASE/'collision-polygons.json',BASE/'cells.json',BASE/'certificates.json',
        SOURCE/'geometry-domains.json',SOURCE/'audit/exact-source-partitions.json',PRE/'source-cog-sites.json',PIECES,
        FRONTIER/'audit/remaining-fixed29-choices.json',AUG/'audit/stronger-model-candidates.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,BR/'audit',INS/'audit',AUG/'audit',FRONTIER/'audit',SOURCE/'audit',PRE/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for b in [BR,INS,AUG,FRONTIER,SOURCE,PRE]:
    inputs.add(b/'audit/checks.json');assert load(b/'audit/checks.json')['passed']
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
prior=load(FRONTIER/'audit/remaining-fixed29-choices.json');assert len(prior)==28
remaining={tuple(r['empty_sites']) for r in prior}
selection=[r|{'subdivision_index':i} for i,r in enumerate(load(FRONTIER/'plan.json')['selection']) if tuple(r['empty_sites']) in remaining]
assert len(selection)==28 and load(BASE/'plan.json')['selection']==selection
job=load(JOB);radius_um=199
assert F(job['clearance'])>F(radius_um,1000)>0
assert load(BASE/'plan.json')['required_job_clearance_mm']==job['clearance'] and load(BASE/'plan.json')['clearance_diamond_radius_um']==radius_um
geometry=load(SOURCE/'geometry-domains.json');canonical=load(PIECES)['cog'];sites=load(PRE/'source-cog-sites.json')
partition=load(SOURCE/'audit/exact-source-partitions.json')
assert any(r['family']=='cog' and r['positive_convex_pieces']==21 and r['exact_partition_boundary_and_area'] for r in partition)
integer=load(BASE/'integer-source.json');D=int(integer['scaled_units_per_micrometre']);assert D>0
assert integer['clearance_diamond_radius_um']==radius_um and integer['required_job_clearance_mm']==job['clearance']
diamond=[(radius_um*D,0),(-radius_um*D,0),(0,radius_um*D),(0,-radius_um*D)]
assert all(x*x+y*y==(radius_um*D)**2 for x,y in diamond)
angle=integer['rotation_radians'];mirror=integer['mirrored'];c,s=F(math.cos(angle)),F(math.sin(angle));sign=-1 if mirror else 1
assert integer['cosine_rational']==str(c) and integer['sine_rational']==str(s)
source_pieces=[]
for poly in canonical:
    expected=[]
    for x,y in poly:
        point=[1000*D*(sign*F(x)*c-F(y)*s),1000*D*(sign*F(x)*s+F(y)*c)]
        assert all(v.denominator==1 for v in point);expected.append(tuple(int(v) for v in point))
    source_pieces.append(expected)
assert integer['normalized_cog_pieces']==[[list(map(str,p)) for p in poly] for poly in source_pieces]
assert len(integer['sites'])==len(sites)==15
shifts=[];transformed_source_vertices=0
for i,(record,site) in enumerate(zip(integer['sites'],sites)):
    assert record['site']==i and record['source']==site
    transform=site['transform'];assert transform['rotation_radians']==angle and transform['mirrored']==mirror
    delta=[F(v)*1000*D for v in transform['translation']];assert all(v.denominator==1 for v in delta)
    shift=tuple(int(v) for v in delta);shifts.append(shift)
    assert record['translation_scaled']==list(map(str,shift))
    tx,ty=map(F,transform['translation'])
    for original,normalized in zip(canonical,source_pieces):
        for (x,y),(u,v) in zip(original,normalized):
            assert (sign*F(x)*c-F(y)*s+tx)*1000*D==u+shift[0]
            assert (sign*F(x)*s+F(y)*c+ty)*1000*D==v+shift[1]
            transformed_source_vertices+=1
templates=load(BASE/'collision-polygons.json');expected_keys={(g['geometry'],ri,pi) for g in geometry for ri in range(len(g['inner_rectangles_um'])) for pi in range(len(canonical))}
seen=set();polygons=[];hull_halfplanes=0
for i,record in enumerate(templates):
    assert record['template']==i;key=(record['geometry'],record['component'],record['source_piece'])
    assert key in expected_keys and key not in seen;seen.add(key)
    gid,ri,pi=key;r=geometry[gid]['inner_rectangles_um'][ri]
    differences={(x-u+dx,y-v+dy) for (x,y),(u,v),(dx,dy) in product(source_pieces[pi],product([r[0]*D,r[2]*D],[r[1]*D,r[3]*D]),diamond)}
    polygon=[tuple(map(int,p)) for p in record['vertices_scaled']]
    assert len(polygon)>=3 and len(polygon)==len(set(polygon)) and set(polygon)<=differences
    assert all(orient(a,b,c)>0 for a,b,c in zip(polygon,polygon[1:]+polygon[:1],polygon[2:]+polygon[:2]))
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        for point in differences:assert orient(a,b,point)>=0;hull_halfplanes+=1
    polygons.append(polygon)
assert seen==expected_keys and len(templates)==378
cells=load(BASE/'cells.json');cellkeys={};relevance=[0]*len(cells)
for i,cell in enumerate(cells):
    assert cell['cell']==i
    key=(cell['geometry'],*cell['bounds_um']);assert key not in cellkeys;cellkeys[key]=i
certificates=load(BASE/'certificates.json');cert_pairs=set();corner_halfplanes=0
for i,certificate in enumerate(certificates):
    assert certificate['certificate']==i;cell_index=certificate['cell'];site=certificate['site'];ti=certificate['template']
    assert 0<=cell_index<len(cells) and 0<=site<15 and 0<=ti<len(templates)
    assert (cell_index,site) not in cert_pairs;cert_pairs.add((cell_index,site))
    cell=cells[cell_index];template=templates[ti];assert cell['geometry']==template['geometry']
    assert cell['relevant_site_bits']&(1<<site)
    x0,y0,x1,y1=cell['bounds_um'];assert x0<=x1 and y0<=y1
    corners=list(product([x0*D,x1*D],[y0*D,y1*D]))
    poly=[(x+shifts[site][0],y+shifts[site][1]) for x,y in polygons[ti]]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        for point in corners:assert orient(a,b,point)>0;corner_halfplanes+=1
records=[];excluded=[];seen_cells=set()
for choice,row in enumerate(selection):
    paths=[BASE/f'choice-{choice:02d}.json',BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json"]
    inputs.update(paths);data,br,ins=map(load,paths);nodes=br['nodes']+ins['nodes'];offset=len(br['nodes'])
    ppath=FRONTIER/f"choice-{row['subdivision_index']:02d}.json";inputs.add(ppath);parent=load(ppath)
    assert parent['empty_sites']==row['empty_sites']
    parent_nodes=set(parent['retained_bracket_nodes']+parent['retained_insert_nodes'])
    assert data['source_selection']==row and data['empty_sites']==br['empty_sites']==ins['empty_sites']==row['empty_sites']
    assert data['original_bracket_node_count']==offset==row['bracket_nodes']
    assert len(data['node_cells'])==len(nodes);present=((1<<15)-1)^sum(1<<i for i in row['empty_sites'])
    for ni,(node,ci) in enumerate(zip(nodes,data['node_cells'])):
        assert cellkeys[node['geometry'],*node['bounds_um']]==ci
        seen_cells.add(ci)
        if ni in parent_nodes:relevance[ci]|=present
    removed=set()
    for record in data['removed']:
        n=record['node'];assert n not in removed and n in parent_nodes;removed.add(n)
        proof=certificates[record['certificate']]
        assert proof['cell']==data['node_cells'][n] and present&(1<<proof['site'])
    retained_br=sorted(set(parent['retained_bracket_nodes'])-removed);retained_ins=sorted(set(parent['retained_insert_nodes'])-removed)
    assert data['retained_bracket_nodes']==retained_br and data['retained_insert_nodes']==retained_ins
    br_bound=sum(bool(set(c['nodes'])&set(retained_br)) for c in br['cliques'])
    ins_bound=sum(bool({offset+n for n in c['nodes']}&set(retained_ins)) for c in ins['insert_cliques'])
    contradiction=min(br_bound,ins_bound)<8
    if contradiction:excluded.append(row['empty_sites'])
    records.append({'clearance_pruning_index':choice,'source_selection':row,'parent_union_removed_nodes':len(parent['additional_removed']),'combined_new_removed_nodes':len(removed)+len(parent['additional_removed']),'original_nodes':len(nodes),'certified_removed_nodes':len(removed),
        'remaining_bracket_nodes':len(retained_br),'remaining_insert_nodes':len(retained_ins),
        'retained_bracket_clique_bound':br_bound,'retained_insert_clique_bound':ins_bound,
        'continuous_fixed29_choice_excluded':contradiction})
assert seen_cells==set(range(len(cells))) and relevance==[c['relevant_site_bits'] for c in cells]
removed_cases=set(map(tuple,excluded));updated=[r for r in prior if tuple(r['empty_sites']) not in removed_cases]
write(OUT/'remaining-fixed29-choices.json',updated)
write(OUT/'stronger-model-candidates.json',[r for r in records if r['combined_new_removed_nodes'] and not r['continuous_fixed29_choice_excluded']])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Original cog convex-piece partitions and moving source-inner rectangles are independently certified upstream. Exact rational binary64 transforms are represented by one common integer scale; every source vertex/translation is replayed. Each stored collision polygon is proved equal to the convex hull of all cog-piece minus moving-rectangle vertex differences: its vertices are differences, it is strictly convex counterclockwise, and it contains every difference. This is the exact Minkowski sum of the source collision polygon and the closed199um L1 diamond. Each diamond vertex has Euclidean norm199um, so convexity bounds every diamond point by199um, strictly below the original job clearance0.2mm. Membership therefore proves source-body distance below required clearance, without assuming a zero-clearance collision. Every removed closed anchor cell has all four corners strictly inside a polygon for a cog site present in that arrangement, proving source separation below the required clearance for every anchor. All removed node identities, aliases and relevant site masks are checked. Retained nodes equal the separately certified parent union-pruned domains minus only the new clearance-impossible cells. Unproved/unsampled cells remain, so no pruning-completeness claim is required. Existing source-certified clique partitions still bound the retained original count. Any exclusion is conditional only on the fixed core/current cog sites; whole allocations remain open.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,
    'source_cog_piece_vertices_transformed':transformed_source_vertices,'exact_collision_polygons_verified':len(templates),
    'hull_difference_halfplane_checks':hull_halfplanes,'source_collision_certificates_verified':len(certificates),
    'strict_closed_cell_corner_halfplane_checks':corner_halfplanes,'unique_source_cells_verified':len(cells),
    'removed_node_occurrences_verified':sum(r['certified_removed_nodes'] for r in records),
    'cases_with_strictly_smaller_domains':sum(r['certified_removed_nodes']>0 for r in records),
    'pruning_completeness_claimed':False,'complete_continuous_retained_domains':True,
    'cases_with_stronger_combined_domains':sum(r['combined_new_removed_nodes']>0 for r in records),'required_job_clearance_mm':job['clearance'],'conservative_clearance_radius_um':radius_um,'zero_clearance_exclusion_claimed':False,'new_fixed29_choices_excluded':len(removed_cases),'total_fixed29_choices_excluded':427+len(removed_cases),
    'remaining_fixed29_choices':len(updated),'whole_allocations_excluded':0,'whole_allocation_candidates':440,
    'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
