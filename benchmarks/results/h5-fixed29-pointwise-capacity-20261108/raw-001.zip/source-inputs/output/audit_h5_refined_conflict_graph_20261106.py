"""Reconstruct all graph pairs using translated interval inequalities."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import ast,json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-refined-conflict-graph-20261106';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-first57-refined-conflict-graph-process-20261106'
REF=ROOT/'output/h5-first57-refined-anchor-cover-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';HELPER=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),HELPER,JOB,BASE/'plan.json',BASE/'checks.json',BASE/'nodes.json',BASE/'initial-covers.json',BASE/'conflicts.bin',BASE/'inherited.bin',
    PROCESS/'opened.json',PROCESS/'process.json',REF/'nodes.json',REF/'retained.json',SOURCE/'geometry-domains.json'}
for base in [BASE,REF/'audit',AUG/'audit',PAIR/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [REF/'audit',AUG/'audit',PAIR/'audit']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and not process['timeout'] and process['exit_code']==0 and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');checks=load(BASE/'checks.json');assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2 and plan['square_radius_um']==140
assert 2*140**2<200**2
row=plan['source_selection']
paths=[BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",AUG/f"choice-{row['augmentation_index']:02d}.json",PAIR/f"choice-{row['clearance_edge_index']:02d}.json"]
inputs.update(paths);br,ins,augmentation,pair=map(load,paths);parents=br['nodes']+ins['nodes'];oldoffset=len(br['nodes'])
allnodes=load(REF/'nodes.json');retained=load(REF/'retained.json');ids=retained['bracket']+retained['insert']
nodes=load(BASE/'nodes.json');assert nodes==[allnodes[i] for i in ids]
n=len(nodes);offset=len(retained['bracket']);assert checks['compact_nodes']==n and checks['bracket_nodes']==offset and checks['insert_nodes']==n-offset
assert all(r['family']==int(i>=offset) for i,r in enumerate(nodes))
geometry=load(SOURCE/'geometry-domains.json')
assert max(abs(v) for r in nodes+parents for v in r['bounds_um'])<10**8
assert max(abs(v) for g in geometry for r in g['inner_rectangles_um'] for v in r)<10**8
def translated_intersections(cells,gap):
    count=len(cells);answer=np.zeros((count,count),dtype=bool)
    bounds=np.array([r['bounds_um'] for r in cells],dtype=np.int64)
    groups={g:np.array([j for j,r in enumerate(cells) if r['geometry']==g],dtype=np.int64) for g in range(10)}
    for i,a in enumerate(cells):
        for g,js in groups.items():
            if not len(js):continue
            b=bounds[js];hit=np.zeros(len(js),dtype=bool)
            for ra in geometry[a['geometry']]['inner_rectangles_um']:
                for rb in geometry[g]['inner_rectangles_um']:
                    hit |= ((a['bounds_um'][2]+ra[0]<b[:,0]+rb[2]+gap)&
                            (b[:,2]+rb[0]<a['bounds_um'][0]+ra[2]+gap)&
                            (a['bounds_um'][3]+ra[1]<b[:,1]+rb[3]+gap)&
                            (b[:,3]+rb[1]<a['bounds_um'][1]+ra[3]+gap))
            answer[i,js]=hit
    return answer
parent_matrix=translated_intersections(parents,0);assert np.all(np.diag(parent_matrix)) and np.all(parent_matrix==parent_matrix.T)
point_checks=[0]
functions=[v for v in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(v,ast.FunctionDef) and v.name in ['classes','covered']]
assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
old_edges=0
for data,gap in [(augmentation,0),(pair,140)]:
    assert data['empty_sites']==row['empty_sites']
    for a,b in data['added_conflict_edges']:
        assert 0<=a<b<len(parents);left,right=parents[a],parents[b]
        box=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]+[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
        rectangles=[[ra[0]-rb[2]-gap,ra[1]-rb[3]-gap,ra[2]-rb[0]+gap,ra[3]-rb[1]+gap] for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um'])]
        assert covered(box,rectangles);parent_matrix[a,b]=parent_matrix[b,a]=True;old_edges+=1
parent_ids=np.array([r['parent_node'] for r in nodes],dtype=np.int64);expected_inherited=parent_matrix[np.ix_(parent_ids,parent_ids)]
expected=expected_inherited|translated_intersections(nodes,140)
rowbytes=(n+7)//8;assert rowbytes==checks['row_bytes']
for name,matrix,hkey in [('conflicts.bin',expected,'conflict_bytes_sha256'),('inherited.bin',expected_inherited,'inherited_bytes_sha256')]:
    data=(BASE/name).read_bytes();assert len(data)==rowbytes*n and digest(BASE/name)==checks[hkey]
    bits=np.unpackbits(np.frombuffer(data,dtype=np.uint8).reshape(n,rowbytes),axis=1,bitorder='little')
    assert not np.any(bits[:,n:]) and np.array_equal(bits[:,:n],matrix)
assert np.all(expected==expected.T) and np.all(np.diag(expected))
new=np.triu(expected&~expected_inherited,1);new_count=int(np.count_nonzero(new));assert new_count>0 and new_count==checks['genuinely_new_child_conflicts']
a,b=checks['new_conflict_example'];assert new[a,b]
covers=load(BASE/'initial-covers.json');cover_pairs=0
for f,cover in enumerate(covers):
    flat=[v for group in cover for v in group];assert sorted(flat)==list(range(0,offset) if f==0 else range(offset,n))
    for group in cover:
        assert group and np.all(expected[np.ix_(group,group)]);cover_pairs+=len(group)*(len(group)-1)//2
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'The independent complete child cover supplies every retained source possibility. Reconstruct all parent strict overlap pairs and independently replay every saved source-union/clearance edge. Expand those parent incompatibilities to their retained children. For every ordered child pair independently use translated interval inequalities, not the producer relative-box matrices, to prove source separation below required clearance via a140 micrometre square. Bounded exact int64 additions are below10^9 and cannot overflow. Compare every bit of both saved graphs, including zero padding, symmetry and diagonals; verify all initial conflict-clique cover pairs. All parent constraints remain, and151808 additional child pair constraints are independently proved. No unproved edge may be consumed by the later tree.'})
result={'passed':True,'seconds':time.perf_counter()-started,'compact_nodes_verified':n,'retained_bracket_children':offset,'retained_insert_children':n-offset,
    'all_unordered_child_pairs_verified':n*(n-1)//2,'all_ordered_parent_pairs_verified':len(parents)**2,
    'parent_union_edges_verified':old_edges,'parent_union_cartesian_classes':point_checks[0],
    'genuinely_new_child_conflicts':new_count,'initial_cover_pairs_verified':cover_pairs,'initial_clique_counts':list(map(len,covers)),
    'complete_retained_source_domains_preserved':True,'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,
    'whole_arrangements_excluded':0,'remaining_fixed29_choices':26,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
