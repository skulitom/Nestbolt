"""Independent complete child-cover and source-removal replay for all25 cases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-frontier-refined-covers-20261106';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-first57-frontier-refined-covers-process-20261106'
FRONT=ROOT/'output/h5-first57-refined-anchor-tree-20261106';OLD=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106';BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/prepare_h5_frontier_refinement_audit_20261106.py',ROOT/'output/audit_h5_refined_anchor_cover_20261106.py',
    JOB,BASE/'plan.json',BASE/'checks.json',PROCESS/'opened.json',PROCESS/'process.json',FRONT/'audit/remaining-fixed29-choices.json',OLD/'plan.json',
    CLEAR/'integer-source.json',CLEAR/'collision-polygons.json'}
for base in [BASE,FRONT/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [FRONT/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2 and plan['cog_diamond_radius_um']==199 and 199**2<200**2
remaining={tuple(r['empty_sites']) for r in load(FRONT/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(OLD/'plan.json')['selection'] if tuple(r['empty_sites']) in remaining and r['empty_sites']!=[4,5,10]]
assert len(selection)==25 and plan['selection']==selection and plan['already_refined_case_not_repeated']==[4,5,10]
results=[]
for ci,row in enumerate(selection):
    folder=BASE/f'choice-{ci:02d}';case_checks=load(folder/'checks.json')
    assert case_checks['refinement_index']==ci and case_checks['source_selection']==row
    inputs.update(folder/name for name in ['checks.json','nodes.json','parents.json','queries.json','retained.json'])
    paths=[BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json"]
    inputs.update(paths);br,ins,parent=map(load,paths);oldnodes=br['nodes']+ins['nodes'];offset=len(br['nodes']);assert offset==case_checks['parent_bracket_node_count']
    nodes=load(folder/'nodes.json');parents=load(folder/'parents.json');queries=load(folder/'queries.json');retained=load(folder/'retained.json')
    assert [r['parent_node'] for r in parents]==parent['retained_bracket_nodes']+parent['retained_insert_nodes']
    seen=set();areas=0
    for group in parents:
        pn=group['parent_node'];old=oldnodes[pn];box=old['bounds_um'];children=group['children']
        assert children and len(children)==len(set(children))
        bounds=[]
        for ci in children:
            assert ci not in seen;seen.add(ci);child=nodes[ci]
            assert child['node']==ci and child['parent_node']==pn and child['geometry']==old['geometry'] and child['family']==int(pn>=offset)
            b=child['bounds_um'];assert len(b)==4 and all(type(v) is int for v in b)
            assert all(box[i]<=b[i]<=b[i+2]<=box[i+2] for i in [0,1]);bounds.append(tuple(b))
        axes=[]
        for i in [0,1]:
            ends=sorted({v[j] for v in bounds for j in [i,i+2]})
            assert ends[0]==box[i] and ends[-1]==box[i+2]
            if box[i+2]-box[i]>=2:assert ends==[box[i],(box[i]+box[i+2])//2,box[i+2]]
            else:assert ends==sorted(set([box[i],box[i+2]]))
            axes.append(list(zip(ends,ends[1:])) if len(ends)>1 else [(ends[0],ends[0])])
        required={(x0,y0,x1,y1) for (x0,x1),(y0,y1) in product(*axes)}
        assert len(bounds)==len(required) and set(bounds)==required
        assert sum((b[2]-b[0])*(b[3]-b[1]) for b in bounds)==(box[2]-box[0])*(box[3]-box[1]);areas+=1
    assert seen==set(range(len(nodes)))
    source=load(CLEAR/'integer-source.json');scale=int(source['scaled_units_per_micrometre']);templates=load(CLEAR/'collision-polygons.json')
    assert source['required_job_clearance_mm']==0.2 and source['clearance_diamond_radius_um']==199
    keys=set();corner_checks=0
    for qi,q in enumerate(queries):
        assert q['query']==qi;key=(q['geometry'],tuple(q['bounds_um']));assert key not in keys;keys.add(key)
        proof=q['certificate']
        if proof is None:continue
        assert not q['scan_limited'] and proof['site'] not in row['empty_sites']
        t=templates[proof['template']];assert t['geometry']==q['geometry']
        dx,dy=map(int,source['sites'][proof['site']]['translation_scaled'])
        poly=[(int(x)+dx,int(y)+dy) for x,y in t['vertices_scaled']]
        x0,y0,x1,y1=[v*scale for v in q['bounds_um']]
        for a,b in zip(poly,poly[1:]+poly[:1]):
            for x,y in product([x0,x1],[y0,y1]):
                assert (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>0;corner_checks+=1
    expected=[[],[]];removed=[];consumed=set()
    for n,node in enumerate(nodes):
        q=queries[node['query']];consumed.add(node['query'])
        assert q['geometry']==node['geometry'] and q['bounds_um']==node['bounds_um']
        if q['certificate'] is not None:removed.append(n)
        else:expected[node['family']].append(n)
    assert consumed==set(range(len(queries))) and retained=={'bracket':expected[0],'insert':expected[1],'removed':removed}
    assert case_checks['parent_cells']==len(parents) and case_checks['child_cells']==len(nodes) and case_checks['source_certified_removed_children']==len(removed)
    assert case_checks['retained_children']==list(map(len,expected)) and case_checks['complete_case_cap_overrun_seconds']==max(0,case_checks['case_seconds']-2)
    results.append({'refinement_index':ci,'source_selection':row,'parent_cells_verified':len(parents),'closed_children_verified':len(nodes),
        'complete_axis_product_covers':areas,'unique_queries_verified':len(queries),'certified_child_removals':len(removed),
        'strict_corner_halfplane_checks':corner_checks,'retained_bracket_children':len(expected[0]),'retained_insert_children':len(expected[1]),
        'complete_case_cap_overrun_seconds':case_checks['complete_case_cap_overrun_seconds']})
write(OUT/'graph-candidates.json',results)
write(OUT/'remaining-fixed29-choices.json',load(FRONT/'audit/remaining-fixed29-choices.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Independently replay every closed Cartesian child cover and present-cog strict integer corner certificate for the25 previously unrefined survivors. Each parent is exactly covered, including shared boundaries, with unchanged source geometry and all aliases. Query caches are separate per case and each consumed certificate site must be present in that case. Remove only children proved below the original200 micrometre clearance by the audited199 micrometre diamond. Every unproved child remains. The previously refined[4,5,10] case is not repeated and remains in the full frontier.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['parent_cells_verified','closed_children_verified','complete_axis_product_covers','unique_queries_verified','certified_child_removals','strict_corner_halfplane_checks','retained_bracket_children','retained_insert_children','complete_case_cap_overrun_seconds']},
    'continuous_covers_complete':True,'all_source_aliases_preserved':True,'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,
    'new_whole_arrangement_exclusions':0,'remaining_fixed29_choices':26,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
