"""Independent every-pair reconstruction and complete root-cover proofs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import ast,json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-first57-frontier-refined-graphs-v2-process-20261106'
REF=ROOT/'output/h5-first57-frontier-refined-covers-20261106';FRONT=ROOT/'output/h5-first57-refined-anchor-tree-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';HELPER=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/prepare_h5_frontier_graph_audit_20261106.py',ROOT/'output/audit_h5_refined_conflict_graph_20261106.py',HELPER,JOB,BASE/'plan.json',BASE/'checks.json',
    PROCESS/'opened.json',PROCESS/'process.json',REF/'audit-v2/graph-candidates.json',SOURCE/'geometry-domains.json',FRONT/'audit/remaining-fixed29-choices.json'}
for base in [BASE,REF/'audit-v2',FRONT/'audit',AUG/'audit',PAIR/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [REF/'audit-v2',FRONT/'audit',AUG/'audit',PAIR/'audit']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and not process['timeout'] and process['exit_code']==0 and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2 and plan['square_radius_um']==140 and 2*140**2<200**2
selection=load(REF/'audit-v2/graph-candidates.json')
assert plan['selection']==selection and len(selection)==25 and all(r['refinement_index']==i and r['source_selection']['empty_sites']!=[4,5,10] for i,r in enumerate(selection))
results=[]
for case_index,selection_row in enumerate(selection):
    row=selection_row['source_selection'];folder=BASE/f'choice-{case_index:02d}';ref_folder=REF/f'choice-{case_index:02d}'
    checks=load(folder/'checks.json');assert checks['refinement_index']==case_index and checks['source_selection']==row
    inputs.update(folder/name for name in ['checks.json','nodes.json','initial-covers.json','root-covers.json','conflicts.bin','inherited.bin'])
    inputs.update(ref_folder/name for name in ['nodes.json','retained.json'])
    paths=[BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",AUG/f"choice-{row['augmentation_index']:02d}.json",PAIR/f"choice-{row['clearance_edge_index']:02d}.json"]
    inputs.update(paths);br,ins,augmentation,pair=map(load,paths);parents=br['nodes']+ins['nodes'];oldoffset=len(br['nodes'])
    allnodes=load(ref_folder/'nodes.json');retained=load(ref_folder/'retained.json');ids=retained['bracket']+retained['insert']
    nodes=load(folder/'nodes.json');assert nodes==[allnodes[i] for i in ids]
    n=len(nodes);offset=len(retained['bracket']);assert checks['compact_nodes']==n and checks['bracket_nodes']==offset and checks['insert_nodes']==n-offset
    assert all(r['family']==int(i>=offset) for i,r in enumerate(nodes))
    geometry=load(SOURCE/'geometry-domains.json')
    assert max(abs(v) for r in nodes+parents for v in r['bounds_um'])<10**8
    assert max(abs(v) for g in geometry for r in g['inner_rectangles_um'] for v in r)<10**8
    def translated_intersections(cells,gap):
        count=len(cells);answer=np.zeros((count,count),dtype=bool)
        bounds=np.array([r['bounds_um'] for r in cells],dtype=np.int64)
        groups={g:np.array([j for j,r in enumerate(cells) if r['geometry']==g],dtype=np.int64) for g in range(10)}
        for i,a in enumerate(cells):
            for g,js in groups.items():
                if not len(js):continue
                b=bounds[js];hit=np.zeros(len(js),dtype=bool)
                for ra in geometry[a['geometry']]['inner_rectangles_um']:
                    for rb in geometry[g]['inner_rectangles_um']:
                        hit |= ((a['bounds_um'][2]+ra[0]<b[:,0]+rb[2]+gap)&
                                (b[:,2]+rb[0]<a['bounds_um'][0]+ra[2]+gap)&
                                (a['bounds_um'][3]+ra[1]<b[:,1]+rb[3]+gap)&
                                (b[:,3]+rb[1]<a['bounds_um'][1]+ra[3]+gap))
                answer[i,js]=hit
        return answer
    parent_matrix=translated_intersections(parents,0);assert np.all(np.diag(parent_matrix)) and np.all(parent_matrix==parent_matrix.T)
    point_checks=[0]
    functions=[v for v in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(v,ast.FunctionDef) and v.name in ['classes','covered']]
    assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
    old_edges=0
    for data,gap in [(augmentation,0),(pair,140)]:
        assert data['empty_sites']==row['empty_sites']
        for a,b in data['added_conflict_edges']:
            assert 0<=a<b<len(parents);left,right=parents[a],parents[b]
            box=[right['bounds_um'][i]-left['bounds_um'][i+2] for i in [0,1]]+[right['bounds_um'][i+2]-left['bounds_um'][i] for i in [0,1]]
            rectangles=[[ra[0]-rb[2]-gap,ra[1]-rb[3]-gap,ra[2]-rb[0]+gap,ra[3]-rb[1]+gap] for ra,rb in product(geometry[left['geometry']]['inner_rectangles_um'],geometry[right['geometry']]['inner_rectangles_um'])]
            assert covered(box,rectangles);parent_matrix[a,b]=parent_matrix[b,a]=True;old_edges+=1
    parent_ids=np.array([r['parent_node'] for r in nodes],dtype=np.int64);expected_inherited=parent_matrix[np.ix_(parent_ids,parent_ids)]
    expected=expected_inherited|translated_intersections(nodes,140)
    rowbytes=(n+7)//8;assert rowbytes==checks['row_bytes']
    for name,matrix,hkey in [('conflicts.bin',expected,'conflict_bytes_sha256'),('inherited.bin',expected_inherited,'inherited_bytes_sha256')]:
        data=(folder/name).read_bytes();assert len(data)==rowbytes*n and digest(folder/name)==checks[hkey]
        bits=np.unpackbits(np.frombuffer(data,dtype=np.uint8).reshape(n,rowbytes),axis=1,bitorder='little')
        assert not np.any(bits[:,n:]) and np.array_equal(bits[:,:n],matrix)
    assert np.all(expected==expected.T) and np.all(np.diag(expected))
    new=np.triu(expected&~expected_inherited,1);new_count=int(np.count_nonzero(new));assert new_count>0 and new_count==checks['genuinely_new_child_conflicts']
    a,b=checks['new_conflict_example'];assert new[a,b]
    covers=load(folder/'initial-covers.json');cover_pairs=0
    for f,cover in enumerate(covers):
        flat=[v for group in cover for v in group];assert sorted(flat)==list(range(0,offset) if f==0 else range(offset,n))
        for group in cover:
            assert group and np.all(expected[np.ix_(group,group)]);cover_pairs+=len(group)*(len(group)-1)//2
    root_covers=load(folder/'root-covers.json');root_pairs=0
    for f,cover in enumerate(root_covers):
        flat=[v for group in cover for v in group];assert sorted(flat)==list(range(0,offset) if f==0 else range(offset,n))
        for group in cover:
            assert group and np.all(expected[np.ix_(group,group)]);root_pairs+=len(group)*(len(group)-1)//2
    root_bounds=list(map(len,root_covers));excluded=any(c<8 for c in root_bounds)
    assert checks['root_clique_counts']==root_bounds and checks['diagnostic_excluded']==excluded
    assert checks['complete_case_cap_overrun_seconds']==max(0,checks['case_seconds']-12)==0
    results.append({'refinement_index':case_index,'source_selection':row,'compact_nodes_verified':n,'retained_bracket_children':offset,'retained_insert_children':n-offset,
        'all_unordered_child_pairs_verified':n*(n-1)//2,'all_ordered_parent_pairs_verified':len(parents)**2,
        'parent_union_edges_verified':old_edges,'parent_union_cartesian_classes':point_checks[0],'genuinely_new_child_conflicts':new_count,
        'initial_cover_pairs_verified':cover_pairs,'root_cover_pairs_verified':root_pairs,'root_clique_bounds':root_bounds,'continuous_fixed29_choice_excluded':excluded})
    if (case_index+1)%5==0:print({'audited_cases':case_index+1},flush=True)
excluded={tuple(r['source_selection']['empty_sites']) for r in results if r['continuous_fixed29_choice_excluded']}
prior=load(FRONT/'audit/remaining-fixed29-choices.json');assert len(prior)==26
remaining=[r for r in prior if tuple(r['empty_sites']) not in excluded]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'stronger-tree-candidates.json',[r for r in results if not r['continuous_fixed29_choice_excluded'] and r['genuinely_new_child_conflicts']])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'For each independently complete new child cover, reconstruct every parent strict source overlap and saved union/clearance edge. Independently evaluate every ordered child pair with translated interval inequalities, verify exact bounded integer arithmetic and compare every bit of both stored graph matrices, including padding and diagonals. Retain all parent incompatibilities. Independently verify every pair and full family partition in initial and new root conflict-clique covers. A complete family cover below8 excludes only that fixed29/current-cog arrangement at required0.2mm clearance. Missing or partial proofs never exclude a case; the previously refined[4,5,10] case is not repeated.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['compact_nodes_verified','all_unordered_child_pairs_verified','all_ordered_parent_pairs_verified','parent_union_edges_verified','parent_union_cartesian_classes','genuinely_new_child_conflicts','initial_cover_pairs_verified','root_cover_pairs_verified']},
    'complete_retained_source_domains_preserved':True,'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,
    'new_fixed29_choices_excluded':len(excluded),'total_fixed29_choices_excluded_at_required_clearance':429+len(excluded),'remaining_fixed29_choices':len(remaining),
    'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
