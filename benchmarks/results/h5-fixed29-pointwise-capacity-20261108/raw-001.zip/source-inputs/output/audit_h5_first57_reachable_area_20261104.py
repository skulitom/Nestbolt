"""Independent integer event/tree area audit; no geometry library is used."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
BASE=ROOT/'output/h5-first57-reachable-area-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def exact_area(reachable,obstacles):
    xs=sorted({v for a,b,c,d in reachable+obstacles for v in (a,c)})
    ix={x:i for i,x in enumerate(xs)};n=len(xs)-1;size=4*n+8
    rc=[0]*size;oc=[0]*size;free=[0]*size;covered=[0]*size
    def initialize(k,l,r):
        free[k]=xs[r]-xs[l]
        if r-l>1:
            m=(l+r)//2;initialize(2*k,l,m);initialize(2*k+1,m,r)
    initialize(1,0,n)
    def update(k,l,r,a,b,delta,is_obstacle):
        if a<=l and r<=b:
            counts=oc if is_obstacle else rc;counts[k]+=delta
            assert counts[k]>=0
        else:
            m=(l+r)//2
            if a<m:update(2*k,l,m,a,b,delta,is_obstacle)
            if b>m:update(2*k+1,m,r,a,b,delta,is_obstacle)
        if oc[k]>0:free[k]=covered[k]=0
        else:
            free[k]=xs[r]-xs[l] if r-l==1 else free[2*k]+free[2*k+1]
            covered[k]=free[k] if rc[k]>0 else (0 if r-l==1 else covered[2*k]+covered[2*k+1])
    events={}
    for is_obstacle,rects in [(False,reachable),(True,obstacles)]:
        for a,b,c,d in rects:
            assert all(type(v) is int for v in (a,b,c,d)) and a<c and b<d
            events.setdefault(b,[]).append((ix[a],ix[c],1,is_obstacle))
            events.setdefault(d,[]).append((ix[a],ix[c],-1,is_obstacle))
    area=0;previous=min(events);peak=0
    for y in sorted(events):
        area+=(y-previous)*covered[1]
        # Applying starts before ends keeps the same canonical range's counters nonnegative.
        for a,b,delta,obs in sorted(events[y],key=lambda e:-e[2]):update(1,0,n,a,b,delta,obs)
        peak=max(peak,covered[1]);previous=y
    assert not any(rc) and not any(oc) and covered[1]==0 and free[1]==xs[-1]-xs[0]
    return area,{'x_intervals':n,'y_boundaries':len(events),'reachable_rectangles':len(reachable),'obstacle_rectangles':len(obstacles),'maximum_covered_x_um':peak}
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
assert load(SOURCE/'audit/checks.json')['passed'] and load(COVER/'audit/checks.json')['passed']
for directory in [SOURCE/'audit',COVER/'audit',BASE]:
    for path,h in load(directory/'plan.json')['inputs'].items():assert digest(ROOT/path)==h,path
geometries=load(SOURCE/'geometry-domains.json')
rects=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
all_boxes=[load(COVER/f'geometry-{g:02d}-cover.json') for g in range(8)]
min_area=min(sum((c-a)*(d-b) for a,b,c,d in g['inner_rectangles_um']) for g in geometries[:8])
for g in geometries[:8]:
    assert all(f=='bracket' for f,m in g['aliases'])
    a,b=g['inner_rectangles_um']
    assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
assert load(BASE/'source-inner-area-minima.json')['bracket']==min_area
actual=load(BASE/'all-choices.json');assert len(actual)==455
records=[]
for index,empty in enumerate(combinations(range(15),3)):
    bits=sum(1<<i for i in empty);reachable=[]
    for gid in range(8):
        for m,x,y,z,w,*_ in all_boxes[gid]:
            if m&~bits:continue
            for a,b,c,d in geometries[gid]['inner_rectangles_um']:reachable.append([x+a,y+b,z+c,w+d])
    reachable=sorted(set(tuple(r) for r in reachable))
    # Only geometrically disjoint obstacles are dropped, using a necessary enclosing box.
    bounds=[min(r[0] for r in reachable),min(r[1] for r in reachable),max(r[2] for r in reachable),max(r[3] for r in reachable)]
    obstacles=[r['bounds_um'] for r in rects if r['site_bit'] not in empty and max(r['bounds_um'][0],bounds[0])<min(r['bounds_um'][2],bounds[2]) and max(r['bounds_um'][1],bounds[1])<min(r['bounds_um'][3],bounds[3])]
    area,stats=exact_area(reachable,obstacles)
    claim=actual[index];assert claim==load(BASE/f'choice-{index:03d}.json') and claim['index']==index and claim['empty_sites']==list(empty)
    assert area==claim['reachable_area_um2']['bracket']
    assert claim['required_area_um2']['bracket']==8*min_area and claim['bracket_capacity_area']==area//min_area
    excluded=area<8*min_area;assert excluded==('bracket' in claim['diagnostic_excluded_by'])
    records.append({'index':index,'empty_sites':list(empty),'exact_reachable_area_um2':area,'minimum_one_bracket_inner_area_um2':min_area,'exact_area_capacity':area//min_area,'required_brackets':8,'excluded':excluded,'sweep':stats})
    if index%25==0:print({'verified':index+1,'seconds':time.perf_counter()-started,'excluded':sum(r['excluded'] for r in records)},flush=True)
write(OUT/'verified-choices.json',records)
inputs=[Path(__file__),BASE/'plan.json',BASE/'checks.json',BASE/'all-choices.json',BASE/'source-inner-area-minima.json',SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',COVER/'audit/plan.json',COVER/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'The prior exact source audit certifies two disjoint inner rectangles in every bracket mode. Every feasible anchor belongs to the continuous necessary cover and hence each inner rectangle belongs to the union of its box sweeps. It cannot intersect any original fixed body, therefore cannot intersect any fixed source-contained rectangle. Eight brackets require at least eight times the minimum inner-rectangle area. This independent Python-integer event sweep measures the exact area of swept rectangles minus fixed rectangles, with no polygon library, floating point, placement grid or omitted boundary class. Area ignores measure-zero boundaries, which cannot hold a positive-area body. An area deficit excludes this fixed29 and12-of15 fixed-pose construction only, never a whole allocation.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'choices_verified':len(records),'new_site_choices_excluded':sum(r['excluded'] for r in records),
    'remaining_site_choices':sum(not r['excluded'] for r in records),'bracket_area_all_choices_exactly_recomputed':True,
    'insert_and_combined_diagnostics_not_negative_certificates':True,'continuous_source_necessary_bound':True,'fixed29_and_candidate_cog_pose_scope_only':True,
    'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
