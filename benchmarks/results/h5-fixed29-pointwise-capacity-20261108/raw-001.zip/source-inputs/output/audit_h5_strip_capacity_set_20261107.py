from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-set-20261107';OUT=BASE/'audit';PROBE=ROOT/'output/h5-strip-capacity-probe-20261107';SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104';PROCESS=ROOT/'output/h5-strip-capacity-set-process-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');geom=load(SRC/'geometry-domains.json')
inputs={Path(__file__),BASE/'plan.json',BASE/'checks.json',PROBE/'audit/plan.json',PROBE/'audit/checks.json',PROBE/'audit/capacity-constraints.json',PROCESS/'prepare.json',PROCESS/'opened.json',SRC/'geometry-domains.json'}
for folder in [BASE,PROBE/'audit']:
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
assert load(PROBE/'audit/checks.json')['passed'] and load(PROCESS/'prepare.json')['passed'] and load(PROCESS/'prepare.json')['job']['active_processes']==0
assert plan['selection']==load(PROBE/'audit/capacity-constraints.json');member_count=pair_count=0;results=[];all_constraints=[]
for row in plan['selection']:
    p=BASE/f"choice-{row['refinement_index']:02d}.json";data=load(p);inputs.add(p);assert data['graph']==row['graph'] and data['seconds']<15 and len(data['constraints'])==4
    nodes=load(ROOT/row['graph']/'nodes.json');gc=load(ROOT/row['graph']/'checks.json');raw=(ROOT/row['graph']/'conflicts.bin').read_bytes();rb=gc['row_bytes'];assert sha256(raw).hexdigest()==gc['conflict_bytes_sha256'];inequalities=[]
    for index,c in enumerate(data['constraints']):
        axis=c['axis'];other=1-axis;line=F(c['line_doubled_um'],2);left,right=c['strip_um'];assert axis in [0,1] and left<right and c['gap_um']==200 and c['quantum_um']==1000 and c['maximum']==(right-left+200)//1000
        expected=[]
        for ni,node in enumerate(nodes):
            a=node['bounds_um'];eligible=[]
            for ri,r in enumerate(geom[node['geometry']]['inner_rectangles_um']):
                extent=[a[axis]+r[axis],a[axis+2]+r[axis+2]]
                if a[other+2]+r[other]<=line<=a[other]+r[other+2] and left<=extent[0] and extent[1]<=right:eligible.append({'node':ni,'component':ri,'width_um':r[axis+2]-r[axis],'extent_um':extent})
            if eligible:expected.append(max(eligible,key=lambda v:(v['width_um'],-v['component'])))
        assert c['members']==expected;member_count+=len(expected);terms=[{'node':m['node'],'weight':(m['width_um']+200)//1000} for m in expected];weights={t['node']:t['weight'] for t in terms}
        if index==0:
            assert c['source']=='previous-independent-counterexample' and terms==row['terms'] and c['maximum']==row['maximum'] and c['counterexample']==row['pair_graph_counterexample']
            selected=c['counterexample'];assert len(selected)==len(set(selected)) and set(selected)<=set(weights)
            for a,b in combinations(selected,2):assert not(raw[a*rb+b//8]>>(b%8)&1) and not(raw[b*rb+a//8]>>(a%8)&1);pair_count+=1
            assert sum(weights[i] for i in selected)>c['maximum'] and all(sum(nodes[i]['family']==f for i in selected)<=8 for f in [0,1])
        else:assert c['source']=='new-fixed-grid-capacity'
        inequalities.append({'index':index,'terms':terms,'maximum':c['maximum'],'axis':axis,'line_doubled_um':c['line_doubled_um'],'strip_um':c['strip_um'],'quantum_um':1000,'source_gap_um':200})
    all_constraints.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'graph':row['graph'],'constraints':inequalities,'genuine_new_source_constraint_counterexample':row['pair_graph_counterexample'],'full_model_counterexample_claimed':False})
    results.append({'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'constraints':4,'members_per_constraint':[len(c['terms']) for c in inequalities],'bounds':[c['maximum'] for c in inequalities],'source_necessary':True,'new_information_beyond_pair_clauses':True})
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},'proof':'Independently recompute every source component eligible for the guaranteed common line and whole-strip property. Select at most one component per cell and verify exact membership/weights. The prior source proof orders selected common-line intervals and enforces original200um separation, giving sum(width+200)<=strip_span+200; floor quantization by1000 is conservative. The first inequality per case preserves an independently rechecked graph-independent violating subset, establishing genuinely new source information beyond pair clauses. Additional inequalities obey the same exact source theorem regardless of diagnostic ranking. No full placement or full-model witness is claimed.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'choices':results,'source_necessary_inequalities':16,'source_members_verified':member_count,'graph_counterexample_pairs_rechecked':pair_count,'cases_with_genuine_new_source_information':4,'SAT_calls':0,'whole_arrangements_excluded':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);write(OUT/'capacity-constraints.json',all_constraints);print(json.dumps(checks),flush=True)
