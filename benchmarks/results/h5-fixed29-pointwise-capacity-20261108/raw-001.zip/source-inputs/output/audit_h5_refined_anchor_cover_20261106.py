"""Independent closed-cover completeness and exact source-distance removals."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-refined-anchor-cover-20261106';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-first57-refined-anchor-cover-process-20261106'
FRONT=ROOT/'output/h5-first57-clearance-pair-trees-20261106';CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),JOB,BASE/'plan.json',BASE/'checks.json',BASE/'nodes.json',BASE/'parents.json',BASE/'queries.json',BASE/'retained.json',
    PROCESS/'opened.json',PROCESS/'process.json',FRONT/'audit/joint-graph-witnesses.json',CLEAR/'integer-source.json',CLEAR/'collision-polygons.json'}
for base in [BASE,FRONT/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [FRONT/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2 and plan['cog_diamond_radius_um']==199
assert 199**2<200**2
witnesses=load(FRONT/'audit/joint-graph-witnesses.json')
chosen=min(witnesses,key=lambda w:(w['source_selection']['bracket_nodes']+w['source_selection']['complete_insert_cells'],w['source_selection']['empty_sites']))
row=chosen['source_selection'];assert row==plan['source_selection'] and row['empty_sites']==[4,5,10]
paths=[BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json"]
inputs.update(paths);br,ins,parent=map(load,paths);oldnodes=br['nodes']+ins['nodes'];offset=len(br['nodes']);assert offset==plan['parent_bracket_node_count']
nodes=load(BASE/'nodes.json');parents=load(BASE/'parents.json');queries=load(BASE/'queries.json');retained=load(BASE/'retained.json')
assert [r['parent_node'] for r in parents]==parent['retained_bracket_nodes']+parent['retained_insert_nodes']
seen=set();areas=0
for group in parents:
    pn=group['parent_node'];old=oldnodes[pn];box=old['bounds_um'];children=group['children']
    assert children and len(children)==len(set(children))
    bounds=[]
    for ci in children:
        assert ci not in seen;seen.add(ci);child=nodes[ci]
        assert child['node']==ci and child['parent_node']==pn and child['geometry']==old['geometry'] and child['family']==int(pn>=offset)
        b=child['bounds_um'];assert len(b)==4 and all(type(v) is int for v in b)
        assert all(box[i]<=b[i]<=b[i+2]<=box[i+2] for i in [0,1]);bounds.append(tuple(b))
    axes=[]
    for i in [0,1]:
        ends=sorted({v[j] for v in bounds for j in [i,i+2]})
        assert ends[0]==box[i] and ends[-1]==box[i+2]
        if box[i+2]-box[i]>=2:assert ends==[box[i],(box[i]+box[i+2])//2,box[i+2]]
        else:assert ends==sorted(set([box[i],box[i+2]]))
        axes.append(list(zip(ends,ends[1:])) if len(ends)>1 else [(ends[0],ends[0])])
    required={(x0,y0,x1,y1) for (x0,x1),(y0,y1) in product(*axes)}
    assert len(bounds)==len(required) and set(bounds)==required
    assert sum((b[2]-b[0])*(b[3]-b[1]) for b in bounds)==(box[2]-box[0])*(box[3]-box[1]);areas+=1
assert seen==set(range(len(nodes)))
source=load(CLEAR/'integer-source.json');scale=int(source['scaled_units_per_micrometre']);templates=load(CLEAR/'collision-polygons.json')
assert source['required_job_clearance_mm']==0.2 and source['clearance_diamond_radius_um']==199
keys=set();corner_checks=0
for qi,q in enumerate(queries):
    assert q['query']==qi;key=(q['geometry'],tuple(q['bounds_um']));assert key not in keys;keys.add(key)
    proof=q['certificate']
    if proof is None:continue
    assert not q['scan_limited'] and proof['site'] not in row['empty_sites']
    t=templates[proof['template']];assert t['geometry']==q['geometry']
    dx,dy=map(int,source['sites'][proof['site']]['translation_scaled'])
    poly=[(int(x)+dx,int(y)+dy) for x,y in t['vertices_scaled']]
    x0,y0,x1,y1=[v*scale for v in q['bounds_um']]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        for x,y in product([x0,x1],[y0,y1]):
            assert (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>0;corner_checks+=1
expected=[[],[]];removed=[];consumed=set()
for n,node in enumerate(nodes):
    q=queries[node['query']];consumed.add(node['query'])
    assert q['geometry']==node['geometry'] and q['bounds_um']==node['bounds_um']
    if q['certificate'] is not None:removed.append(n)
    else:expected[node['family']].append(n)
assert consumed==set(range(len(queries))) and retained=={'bracket':expected[0],'insert':expected[1],'removed':removed}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Every previously retained parent has exactly the Cartesian product of adjacent closed axis intervals covering its entire bounds, with shared boundaries included. Geometry and every original alias remain unchanged. Each removed child is strictly inside an independently audited present-cog source collision polygon plus199 micrometre diamond; every corner/halfplane is replayed with exact integers. The source distance is below the original200 micrometre clearance throughout that child. Every other child is retained. Full continuous source coverage therefore remains necessary, with genuinely finer cells and certified child removals. No whole-arrangement exclusion or placement follows yet.'})
result={'passed':True,'seconds':time.perf_counter()-started,'empty_sites':row['empty_sites'],'parent_cells_verified':len(parents),'closed_children_verified':len(nodes),
    'complete_axis_product_covers':areas,'unique_queries_verified':len(queries),'certified_child_removals':len(removed),
    'strict_corner_halfplane_checks':corner_checks,'retained_bracket_children':len(expected[0]),'retained_insert_children':len(expected[1]),
    'continuous_cover_complete':True,'all_source_aliases_preserved':True,'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,
    'whole_arrangements_excluded':0,'remaining_fixed29_choices':26,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
