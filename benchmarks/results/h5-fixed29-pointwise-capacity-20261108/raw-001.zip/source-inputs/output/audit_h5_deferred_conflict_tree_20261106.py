"""Independently replay complete source-inner trees using sets and integer inequalities."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from itertools import combinations
from functools import lru_cache
import json, time, shutil
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'output/h5-first57-deferred-conflict-tree-20261106'
OUT = BASE/'audit'
BR = ROOT/'output/h5-first57-full-frontier-cliques-20261104'
AC = ROOT/'output/h5-first57-frontier-clique-consistency-20261104'
INS = ROOT/'output/h5-first57-frontier-insert-bounds-20261106'
FRONTIER = ROOT/'output/h5-first57-frontier-joint-distributions-20261106'
SOURCE = ROOT/'output/h5-first57-necessary-rectangles-20261104'
PROCESS = ROOT/'output/h5-first57-deferred-conflict-tree-process-20261106'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
OUT.mkdir()
started = time.perf_counter()
shutil.copyfile(__file__, OUT/'audit.py')
inputs = {Path(__file__), BASE/'plan.json', BASE/'checks.json',
          SOURCE/'geometry-domains.json', FRONTIER/'audit/remaining-fixed29-choices.json',
          FRONTIER/'audit/deferred-large-distributions.json',
          PROCESS/'opened.json', PROCESS/'process.json'}
for base in [BASE, BR/'audit', AC/'audit', INS/'audit', FRONTIER/'audit']:
    p = base/'plan.json'; inputs.add(p)
    for name, h in load(p)['inputs'].items():
        assert digest(ROOT/name) == h, name
for base in [BR, AC, INS, FRONTIER]:
    p = base/'audit/checks.json'; inputs.add(p); assert load(p)['passed']
process = load(PROCESS/'process.json')
assert process['closed'] and process['exit_code'] == 0 and not process['timeout']
assert process['complete_process_cap_overrun_seconds'] == 0
plan = load(BASE/'plan.json')
assert plan['per_choice_seconds'] == 6 and plan['maximum_expanded_nodes_per_choice'] == 25000
selection = load(FRONTIER/'audit/deferred-large-distributions.json')
assert len(selection) == 5
geometry = load(SOURCE/'geometry-domains.json')
results = []; excluded = []; witnesses = []; total_pairs = 0
for choice, row in enumerate(selection):
    paths = [BASE/f'choice-{choice:02d}.json',
             BR/f"choice-{row['choice_index']:02d}.json",
             AC/f"choice-{row['consistency_index']:02d}.json",
             INS/f"choice-{row['insert_choice_index']:02d}.json"]
    inputs.update(paths)
    data, br, ac, ins = map(load, paths)
    assert data['source_selection'] == row
    assert data['empty_sites'] == br['empty_sites'] == ac['empty_sites'] == ins['empty_sites'] == row['empty_sites']
    offset = len(br['nodes'])
    assert data['original_bracket_node_count'] == offset
    nodes = br['nodes'] + ins['nodes']
    domains = [set(g) for g in ac['remaining_cliques']]
    available = {offset+n for n in ins['retained']}
    assert len(domains) == 8 and all(domains)
    assert sum(map(len, domains)) == len(set.union(*domains))
    assert not set.union(*domains) & available
    case_pairs = [0]
    @lru_cache(maxsize=None)
    def conflict(a, b):
        case_pairs[0] += 1
        left, right = nodes[a], nodes[b]
        x0, y0, x1, y1 = left['bounds_um']
        u0, v0, u1, v1 = right['bounds_um']
        for ax0, ay0, ax1, ay1 in geometry[left['geometry']]['inner_rectangles_um']:
            for bx0, by0, bx1, by1 in geometry[right['geometry']]['inner_rectangles_um']:
                if (x1+ax0 < u0+bx1 and u1+bx0 < x0+ax1
                        and y1+ay0 < v0+by1 and v1+by0 < y0+ay1):
                    return True
        return False
    for group in domains:
        for a in group:
            assert conflict(a, a)
        for a, b in combinations(sorted(group), 2):
            assert conflict(a, b)
    for a in available:
        assert conflict(a, a)
    records = data['records']; seen = set(); open_leaves = []; found_witnesses = []
    stats = {'bracket_removals': 0, 'insert_removals': 0,
             'closed_empty_bracket_leaves': 0, 'closed_insert_cover_leaves': 0,
             'bracket_branches': 0, 'insert_branches': 0, 'cover_pair_checks': 0}
    def replay(index, groups, candidates, chosen):
        assert isinstance(index, int) and 0 <= index < len(records) and index not in seen
        seen.add(index); record = records[index]; assert record['node'] == index
        groups = [set(g) for g in groups]; candidates = set(candidates)
        assert len(chosen) == len(set(chosen)) <= 8
        assert not candidates.intersection(chosen)
        for a, b in combinations(chosen, 2): assert not conflict(a, b)
        for a in chosen:
            assert all(not conflict(a, b) for b in candidates)
            assert all(not conflict(a, b) for g in groups for b in g)
        if record['kind'] == 'open':
            assert not record['bracket_removals'] and not record['insert_removals']
            assert record['reason'] in ['earlier_relaxation_witness', 'time_or_expansion_limit']
            if record['reason'] == 'earlier_relaxation_witness': assert found_witnesses
            open_leaves.append(index); return False
        for value, own, other in record['bracket_removals']:
            assert all(groups) and 0 <= own < 8 and 0 <= other < 8 and own != other
            assert value in groups[own]
            assert all(conflict(value, target) for target in groups[other])
            groups[own].remove(value); stats['bracket_removals'] += 1
        if not all(groups):
            assert record['kind'] == 'closed_empty_bracket' and not record['insert_removals']
            stats['closed_empty_bracket_leaves'] += 1; return True
        assert record['kind'] != 'closed_empty_bracket'
        for value, group in record['insert_removals']:
            assert value in candidates and 0 <= group < 8
            assert all(conflict(value, target) for target in groups[group])
            candidates.remove(value); stats['insert_removals'] += 1
        kind = record['kind']; need = 8-len(chosen)
        if kind == 'closed_insert_cover':
            cover = record['cover']; flat = [a for group in cover for a in group]
            assert len(flat) == len(set(flat)) and set(flat) == candidates
            assert len(cover) < need and all(cover)
            for group in cover:
                for a, b in combinations(group, 2):
                    assert conflict(a, b); stats['cover_pair_checks'] += 1
            stats['closed_insert_cover_leaves'] += 1; return True
        if kind == 'open_graph_witness':
            assert need == 0 and all(len(g) == 1 for g in groups)
            witness = {'bracket_nodes': [next(iter(g)) for g in groups], 'insert_nodes': chosen}
            assert record['witness'] == witness
            all_nodes = witness['bracket_nodes'] + chosen
            assert len(all_nodes) == len(set(all_nodes)) == 16
            for a, b in combinations(all_nodes, 2): assert not conflict(a, b)
            found_witnesses.append(witness); open_leaves.append(index); return False
        assert need > 0
        if kind == 'branch_bracket':
            group = record['group']; assert 0 <= group < 8 and len(groups[group]) > 1
            children = record['children']; values = [c['value'] for c in children]
            assert len(values) == len(set(values)) and set(values) == groups[group]
            stats['bracket_branches'] += 1; closed = []
            for child in children:
                next_groups = [set(g) for g in groups]; next_groups[group] = {child['value']}
                closed.append(replay(child['node'], next_groups, candidates, list(chosen)))
            return all(closed)
        assert kind == 'branch_insert' and all(len(g) == 1 for g in groups)
        value = record['value']; assert value in candidates
        stats['insert_branches'] += 1
        remaining = {a for a in candidates if a != value and not conflict(a, value)}
        included = replay(record['include'], groups, remaining, chosen+[value])
        rejected = replay(record['exclude'], groups, candidates-{value}, list(chosen))
        return included and rejected
    closed = replay(data['root'], domains, available, [])
    assert seen == set(range(len(records)))
    assert sorted(open_leaves) == data['open_nodes']
    assert data['diagnostic_excluded'] == closed == (not open_leaves)
    assert data['expanded_nodes'] == sum(r['kind'] != 'open' for r in records) <= 25000
    assert 0 <= data['case_seconds'] < 6
    assert len(found_witnesses) <= 1
    assert data['relaxation_witness'] == (found_witnesses[0] if found_witnesses else None)
    if closed: excluded.append(row['empty_sites'])
    if found_witnesses:
        witness = found_witnesses[0]
        witnesses.append({'source_selection': row, 'witness': witness,
                          'bracket_cells': [nodes[n] for n in witness['bracket_nodes']],
                          'insert_cells': [nodes[n] for n in witness['insert_nodes']],
                          'source_placement': False})
    total_pairs += case_pairs[0]
    results.append({'empty_sites': row['empty_sites'], 'tree_records_verified': len(records),
                    **stats, 'open_leaves': len(open_leaves), 'has_necessary_graph_witness': bool(found_witnesses),
                    'strict_source_inner_pair_evaluations': case_pairs[0],
                    'continuous_fixed29_choice_excluded': closed})
prior = load(FRONTIER/'audit/remaining-fixed29-choices.json'); assert len(prior) == 72
removed = set(map(tuple, excluded)); assert len(removed) == len(excluded)
assert removed <= {tuple(r['empty_sites']) for r in prior}
remaining = [r for r in prior if tuple(r['empty_sites']) not in removed]
assert len(remaining) == 72-len(removed)
write(OUT/'remaining-fixed29-choices.json', remaining)
write(OUT/'necessary-graph-witnesses.json', witnesses)
write(OUT/'plan.json', {'utc': datetime.now(timezone.utc).isoformat(),
    'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(inputs)},
    'proof': 'The independently complete continuous covers assign each original to at least one retained cell. Self-conflicts prohibit two originals in one cell; the eight disjoint bracket conflict cliques are mandatory. Every replayed removal conflicts strictly with every current member of another mandatory bracket clique, so it preserves every possible packing. Bracket branches exhaust every remaining candidate of a mandatory group. Insert branches partition possibilities into choosing the cell once or not choosing it; inclusion retains all compatible cells. Verified clique covers bound the remaining insert count. Every record is reached exactly once from its parent. Only trees with every leaf certified closed exclude fixed29 and current cog poses at zero clearance. An open graph witness does not prove any continuous source placement. No changed poses, changed core or whole allocation are excluded.'})
result = {'passed': True, 'seconds': time.perf_counter()-started, 'choices': results,
    'tree_records_verified': sum(r['tree_records_verified'] for r in results),
    'strict_source_inner_pair_evaluations': total_pairs,
    'new_fixed29_choices_excluded': len(removed), 'original_fixed29_choices': 455,
    'previous_fixed29_choices_excluded': 383, 'total_fixed29_choices_excluded': 383+len(removed),
    'remaining_fixed29_choices': len(remaining), 'necessary_graph_witnesses': len(witnesses),
    'whole_allocations_excluded': 0, 'whole_allocation_candidates': 440,
    'placement_solver_calls': 0, 'native_calls': 0, 'source_valid66': False, 'H5_complete': False}
write(OUT/'checks.json', result); print(result)
