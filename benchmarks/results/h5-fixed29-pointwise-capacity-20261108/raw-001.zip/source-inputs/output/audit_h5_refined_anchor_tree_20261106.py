"""Independent complete tree replay over the previously all-pair-audited graph."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from functools import lru_cache
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-refined-anchor-tree-20261106';OUT=BASE/'audit'
GRAPH=ROOT/'output/h5-first57-refined-conflict-graph-20261106';FRONT=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
PROCESS=ROOT/'output/h5-first57-refined-anchor-tree-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/prepare_h5_refined_tree_audit_20261106.py',ROOT/'output/audit_h5_clearance_pair_trees_20261106.py',
    BASE/'plan.json',BASE/'checks.json',BASE/'tree.json',GRAPH/'nodes.json',GRAPH/'conflicts.bin',GRAPH/'checks.json',PROCESS/'opened.json',PROCESS/'process.json',FRONT/'audit/remaining-fixed29-choices.json'}
for base in [BASE,GRAPH/'audit',FRONT/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [GRAPH/'audit',FRONT/'audit']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert plan['search_cutoff_seconds']==5.0 and plan['complete_case_cap_seconds']==5.5 and plan['maximum_expanded_nodes']==5000
data=load(BASE/'tree.json');row=plan['source_selection'];assert data['source_selection']==row and data['empty_sites']==row['empty_sites'] and data['graph_complete']
nodes=load(GRAPH/'nodes.json');n=len(nodes);offset=data['refined_bracket_node_count']
assert offset==load(GRAPH/'audit/checks.json')['retained_bracket_children']
assert all(r['family']==int(i>=offset) for i,r in enumerate(nodes))
raw=(GRAPH/'conflicts.bin').read_bytes();rowbytes=(n+7)//8
assert len(raw)==rowbytes*n and digest(GRAPH/'conflicts.bin')==load(GRAPH/'checks.json')['conflict_bytes_sha256']
evaluated=[0]
@lru_cache(maxsize=None)
def conflict(a,b):
    evaluated[0]+=1
    return bool(raw[a*rowbytes+b//8]&(1<<(b%8)))
for i in range(n):assert conflict(i,i)
records=data['records'];seen=set();opened=[];found=[];expanded=[0]
stats={'branch_cliques':0,'closed_count_leaves':0,'propagation_covers':0,'propagation_removals':0,'mandatory_support_pair_checks':0,'clique_pair_checks':0,'time_or_node_limit_leaves':0,'graph_preparation_limit_leaves':0}
def verify_cover(cover,candidates):
    flat=[v for g in cover for v in g]
    assert len(flat)==len(set(flat)) and set(flat)==candidates and all(cover)
    for group in cover:
        for a,b in combinations(group,2):
            assert conflict(a,b);stats['clique_pair_checks']+=1
def replay(index,available,chosen):
    assert isinstance(index,int) and 0<=index<len(records) and index not in seen
    seen.add(index);record=records[index];assert record['node']==index
    available=[set(a) for a in available];chosen=[list(c) for c in chosen]
    for f in range(2):
        assert len(chosen[f])==len(set(chosen[f]))<=8 and not available[f].intersection(chosen[f])
        assert all((n<offset)==(f==0) for n in available[f]|set(chosen[f]))
        if len(chosen[f])==8:assert not available[f]
    selected=chosen[0]+chosen[1]
    for a,b in combinations(selected,2):assert not conflict(a,b)
    for a in selected:
        for b in available[0]|available[1]:assert not conflict(a,b)
    assert type(record['expanded']) is bool
    expanded[0]+=record['expanded']
    assert expanded[0]<=5000
    if not record['expanded']:assert not record['propagation'] and record['kind']=='open'
    for step in record['propagation']:
        assert record['expanded'] and data['graph_complete']
        mf=step['mandatory_family'];assert mf in [0,1]
        cover=step['cover'];verify_cover(cover,available[mf])
        assert len(cover)==8-len(chosen[mf])>0 and step['removals']
        groups=[set(g) for g in cover];stats['propagation_covers']+=1
        for f,value,group in step['removals']:
            assert f in [0,1] and value in available[f] and 0<=group<len(groups)
            targets=groups[group]&available[mf]
            assert targets and value not in targets
            for target in targets:
                assert conflict(value,target);stats['mandatory_support_pair_checks']+=1
            available[f].remove(value);stats['propagation_removals']+=1
    kind=record['kind']
    if kind=='open':
        reason=record['reason']
        if reason=='earlier_joint_graph_witness':assert found and not record['expanded']
        elif reason=='graph_preparation_limit':
            assert not data['graph_complete'] and not record['expanded'];stats['graph_preparation_limit_leaves']+=1
        else:
            assert reason=='time_or_expansion_limit'
            assert expanded[0]>=5000 or record['case_elapsed']>=5.0 or record['global_elapsed']>=5.0
            stats['time_or_node_limit_leaves']+=1
        opened.append(index);return False
    assert record['expanded'] and data['graph_complete']
    if kind=='open_graph_witness':
        assert list(map(len,chosen))==[8,8] and record['witness']==chosen
        found.append(chosen);opened.append(index);return False
    if kind=='closed_count_cover':
        f=record['family'];assert f in [0,1]
        verify_cover(record['cover'],available[f])
        assert len(record['cover'])<8-len(chosen[f])
        stats['closed_count_leaves']+=1;return True
    assert kind=='branch_clique'
    f=record['family'];assert f in [0,1] and len(chosen[f])<8
    group=record['clique'];assert group and len(group)==len(set(group)) and set(group)<=available[f]
    for a,b in combinations(group,2):
        assert conflict(a,b);stats['clique_pair_checks']+=1
    children=record['children'];values=[r['value'] for r in children]
    assert len(values)==len(set(values)) and set(values)==set(group)
    stats['branch_cliques']+=1;closed=[]
    for child in children:
        value=child['value'];child_available=[{n for n in a if n!=value and not conflict(n,value)} for a in available]
        child_chosen=[list(c) for c in chosen];child_chosen[f].append(value)
        if len(child_chosen[f])==8:child_available[f]=set()
        closed.append(replay(child['node'],child_available,child_chosen))
    skipped=[set(a) for a in available];skipped[f]-=set(group)
    closed.append(replay(record['skip'],skipped,chosen))
    return all(closed)
closed=replay(data['root'],[set(range(offset)),set(range(offset,n))],[[],[]])
assert seen==set(range(len(records))) and sorted(opened)==data['open_nodes']
assert closed==data['diagnostic_excluded']==(not opened) and expanded[0]==data['expanded_nodes']
assert len(found)<=1 and data['joint_graph_witness']==(found[0] if found else None)
assert data['case_complete_cap_overrun_seconds']==max(0,data['case_seconds']-5.5)==0
prior=load(FRONT/'audit/remaining-fixed29-choices.json');assert len(prior)==26
remaining=[r for r in prior if not (closed and r['empty_sites']==row['empty_sites'])]
write(OUT/'remaining-fixed29-choices.json',remaining)
write(OUT/'joint-graph-witnesses.json',[{'source_selection':row,'selected_nodes':w,'bracket_cells':[nodes[i] for i in w[0]],'insert_cells':[nodes[i] for i in w[1]],'source_placement':False} for w in found])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'The separately audited closed child cover preserves every continuous source possibility and the separately all-pair-audited graph certifies every incompatibility bit. Independently reconstruct exact candidate sets for every include/skip branch. Each mandatory removal conflicts with every active member of a nonempty required clique. Each closed leaf has a full conflict cover smaller than the remaining family requirement. Every record is visited exactly once, selected pairs remain compatible, and open leaves prevent whole-arrangement exclusion. Only a fully closed tree can exclude fixed29/current-cog poses at original0.2mm clearance. Graph witnesses are not source placements.'})
result={'passed':True,'seconds':time.perf_counter()-started,'empty_sites':row['empty_sites'],'tree_records_verified':len(records),'expanded_nodes_verified':expanded[0],**stats,
    'distinct_audited_graph_pair_checks':evaluated[0],'open_leaves':len(opened),'joint_graph_witness':bool(found),'complete_case_cap_overrun_seconds':0,
    'new_fixed29_choices_excluded':int(closed),'previous_fixed29_choices_excluded_at_required_clearance':429,
    'total_fixed29_choices_excluded_at_required_clearance':429+int(closed),'remaining_fixed29_choices':len(remaining),
    'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
