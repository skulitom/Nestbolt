"""Complete point/open-interval proof of every fixed29 domain subtraction."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from h5_exact_rectangle_areas_20261108 import horizontal_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-pointwise-domains-20261108';OUT=BASE/'audit';DENSE=ROOT/'output/h5-fixed29-dense-cog-material-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';G=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def axis(cuts):
    values=np.array(sorted(cuts),dtype=np.int64);out=np.empty(2*len(values)-1,dtype=np.int64);out[::2]=2*values;out[1::2]=values[:-1]+values[1:];return out
OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,DENSE/'audit',OLD/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct every open forbidden rectangle from actual source-certified fixed/moving inner components and every current source node. Verify the chosen intersecting set exactly. For each original cell, enumerate every boundary point and open-interval class within its closure and prove original closed cell minus open forbidden union equals the produced closed-box union on EVERY Cartesian class. Producer subtraction is not reused. Independently reconstruct swept original alias envelopes and replay family/joint areas by horizontal interval merging, not vertical prefixes.'})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];newworld=load(DENSE/'world-new-inner-rectangles.json');oldworld=load(G/'world-cog-inner-rectangles.json');fixedcore=load(G/'fixed-core-inner-rectangles.json');prior={r['refinement_index']:r for r in load(DENSE/'audit/case-results.json')};cases=load(OLD/'audit/case-results.json');saved=load(BASE/'case-results.json');assert len(cases)==len(saved)==4;results=[];classes=0;maxclasses=0
for case,row in zip(cases,saved):
    index=case['refinement_index'];nodes=load(ROOT/case['source_graph']/'nodes.json');obstacles=[r['bounds_um'] for r in newworld if r['site_bit'] not in case['empty_sites']];forbidden=load(BASE/f'choice-{index:02d}-forbidden.json');assert len(forbidden)==10
    for g,record in zip(geometries,forbidden):
        expected=set()
        for comp in g['inner_rectangles_um']:
            for fixed in obstacles:expected.add((fixed[0]-comp[2],fixed[1]-comp[3],fixed[2]-comp[0],fixed[3]-comp[1]))
        assert record=={'geometry':g['geometry'],'open_forbidden_anchor_rectangles_um':[list(v) for v in sorted(expected)]}
    arrays=[np.array(r['open_forbidden_anchor_rectangles_um'],dtype=np.int64) for r in forbidden];records=load(BASE/f'choice-{index:02d}-covers.json');assert len(records)==len(nodes);regions={'bracket':set(),'insert':set()}
    for ni,(node,record) in enumerate(zip(nodes,records)):
        assert record['current_graph_position']==ni and record['source_node_label']==node['node'] and record['geometry']==node['geometry'];g=geometries[node['geometry']];l,b,r,t=node['bounds_um'];q=arrays[node['geometry']];indices=np.flatnonzero((q[:,0]<r)&(q[:,2]>l)&(q[:,1]<t)&(q[:,3]>b));assert indices.tolist()==record['intersecting_forbidden_indices'];blocks=q[indices].tolist();remaining=record['remaining_closed_anchor_boxes_um'];assert all(l<=v[0]<=v[2]<=r and b<=v[1]<=v[3]<=t for v in remaining)
        xx=axis({l,r}|{v[k] for v in blocks+remaining for k in [0,2] if l<=v[k]<=r});yy=axis({b,t}|{v[k] for v in blocks+remaining for k in [1,3] if b<=v[k]<=t});assert len(xx)*len(yy)<4000000
        def cover(rows,closed):
            grid=np.zeros((len(yy),len(xx)),dtype=bool)
            for a,c,d,e in rows:
                xa=int(np.searchsorted(xx,2*a,side='left' if closed else 'right'));xb=int(np.searchsorted(xx,2*d,side='right' if closed else 'left'));ya=int(np.searchsorted(yy,2*c,side='left' if closed else 'right'));yb=int(np.searchsorted(yy,2*e,side='right' if closed else 'left'));grid[ya:yb,xa:xb]=True
            return grid
        assert np.array_equal(~cover(blocks,False),cover(remaining,True)),(index,ni);classes+=len(xx)*len(yy);maxclasses=max(maxclasses,len(xx)*len(yy))
        for box in remaining:
            for component in g['all_alias_component_outer_rectangles_um']:
                v=[box[k]+component[k] for k in range(4)];v=(max(v[0],stock[0]),max(v[1],stock[1]),min(v[2],stock[2]),min(v[3],stock[3]))
                if v[0]<v[2] and v[1]<v[3]:regions[g['family']].add(v)
    fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+newworld if r['site_bit'] not in case['empty_sites']];regions={f:sorted(v) for f,v in regions.items()};assert load(BASE/f'choice-{index:02d}-regions.json')=={'family_component_regions_um':{f:[list(v) for v in rows] for f,rows in regions.items()},'fixed_source_inner_rectangles_um':fixed};totals=horizontal_areas(regions['bracket'],regions['insert'],fixed);previous=prior[index];old=[previous['family_area_upper_um2'][f] for f in ['bracket','insert']]+[previous['joint_area_upper_um2']];assert all(a<=b for a,b in zip(totals,old));excluded=any(a<b for a,b in zip(totals,[8*39999*10**6,8*19799*10**6,8*(39999+19799)*10**6]));expected={'refinement_index':index,'empty_sites':case['empty_sites'],'current_nodes':len(nodes),'nodes_fully_removed':sum(not r['remaining_closed_anchor_boxes_um'] for r in records),'nodes_refined':sum(r['remaining_closed_anchor_boxes_um']!=[n['bounds_um']] for r,n in zip(records,nodes)),'remaining_closed_anchor_boxes':sum(len(r['remaining_closed_anchor_boxes_um']) for r in records),'family_area_upper_um2':dict(zip(['bracket','insert'],totals[:2])),'joint_area_upper_um2':totals[2],'required_joint_area_lower_um2':8*(39999+19799)*10**6,'joint_area_reduction_um2':old[2]-totals[2],'provisional_exact_fixed_scope_excluded':excluded};assert expected==row;results.append({**row,'exact_fixed_scope_excluded':excluded});print({'choice':index,'classes_so_far':classes,'excluded':excluded},flush=True)
process=load(ROOT/'output/h5-fixed29-pointwise-domains-process-20261108/process.json');assert process['passed'] and process['closed'];remaining=[r for r in results if not r['exact_fixed_scope_excluded']];charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'current_fixed29_cases_verified':4,'latest_graph_nodes_verified':sum(r['current_nodes'] for r in results),'complete_point_and_open_interval_classes_verified':classes,'maximum_classes_in_one_cell':maxclasses,'nodes_fully_removed':sum(r['nodes_fully_removed'] for r in results),'nodes_refined':sum(r['nodes_refined'] for r in results),'remaining_closed_anchor_boxes':sum(r['remaining_closed_anchor_boxes'] for r in results),'source_aliases_preserved':12,'source_strip_inequalities_preserved':16,'exact_area_bounds_verified':12,'additional_fixed29_cases_excluded':4-len(remaining),'fixed29_cases_remaining':len(remaining),'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_excluded':0,'H5_complete':False});print(load(OUT/'checks.json'))
