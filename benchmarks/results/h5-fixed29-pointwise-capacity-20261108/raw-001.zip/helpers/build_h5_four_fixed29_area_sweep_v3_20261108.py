"""Prepare a memory-bounded exact replacement; never execute a consumed stage."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads(p.read_bytes())
def save(p,s):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
failure=ROOT/'output/h5-four-fixed29-current-areas-v2-process-20261108/process.json'
assert load(failure)['closed'] and not load(failure)['passed']
save(ROOT/'output/h5-four-fixed29-current-areas-v2-correction-20261108.json',json.dumps({
    'failed_preparation_sha256':sha256((ROOT/'output/prepare_h5_four_fixed29_current_areas_v2_20261108.py').read_bytes()).hexdigest(),
    'failed_complete_seconds':load(failure)['complete_seconds'],
    'reason':'The verified source-node mapping passed. The global Cartesian grid exceeded the preset four-million-cell guard before any case area or exclusion was produced.',
    'correction':'Replace dense Cartesian allocation with exact vertical strips, maintaining one-dimensional signed endpoint counts. Independently audit with horizontal active-rectangle interval merging and subtraction. Preserve all geometry, aliases, source labels, current nodes, and source strip constraints.',
    'failed_outputs_preserved':True,'failed_cost_remains_charged':True,'optimizer_calls':0
},indent=2)+'\n')
s=(ROOT/'output/prepare_h5_four_fixed29_current_areas_v2_20261108.py').read_text(encoding='utf-8').replace('current-areas-v2-','current-areas-v3-')
s=s.replace('inputs=[Path(__file__),','inputs=[Path(__file__),ROOT/\'output/h5-four-fixed29-current-areas-v2-correction-20261108.json\',ROOT/\'output/h5-four-fixed29-current-areas-v2-process-20261108/process.json\',ROOT/\'output/h5-four-fixed29-current-areas-v2-20261108/plan.json\',')
s=s.replace("+load(ROOT/'output/h5-four-fixed29-current-areas-process-20261108/process.json')['complete_seconds']", "+load(ROOT/'output/h5-four-fixed29-current-areas-process-20261108/process.json')['complete_seconds']+load(ROOT/'output/h5-four-fixed29-current-areas-v2-process-20261108/process.json')['complete_seconds']")
s=s.replace('and calculate exact bracket/insert/joint union areas.', 'and calculate exact bracket/insert/joint union areas using memory-bounded vertical strips and one-dimensional signed endpoint counts.')
start=s.index("    regions={f:sorted(v) for f,v in regions.items()};rectangles=")
end=s.index("    write(OUT/f'choice-",start)
s=s[:start]+'''    regions={f:sorted(v) for f,v in regions.items()};families=['bracket','insert'];rows=[regions[f] for f in families]+[fixed]
    ys=sorted({r[k] for group in rows for r in group for k in [1,3]});yi={y:i for i,y in enumerate(ys)};events={}
    for gi,group in enumerate(rows):
        for a,b,c,d in group:
            events.setdefault(a,[]).append((gi,yi[b],yi[d],1));events.setdefault(c,[]).append((gi,yi[b],yi[d],-1))
    xs=sorted(events);dy=np.diff(np.array(ys,dtype=np.int64));diff=np.zeros((3,len(ys)),dtype=np.int32);totals=[0,0,0]
    for left,right in zip(xs,xs[1:]):
        for gi,lo,hi,sign in events[left]:diff[gi,lo]+=sign;diff[gi,hi]-=sign
        counts=diff.cumsum(1,dtype=np.int32)[:,:-1];assert (counts>=0).all();clear=counts[2]==0;bmask=(counts[0]>0)&clear;imask=(counts[1]>0)&clear
        for k,mask in enumerate([bmask,imask,bmask|imask]):totals[k]+=int(dy[mask].sum())*(right-left)
    for gi,lo,hi,sign in events[xs[-1]]:diff[gi,lo]+=sign;diff[gi,hi]-=sign
    assert not diff.any();areas=dict(zip(families,totals[:2]));joint=totals[2];excluded=areas['bracket']<8*39999*10**6 or areas['insert']<8*19799*10**6 or joint<8*(39999+19799)*10**6
'''+s[end:]
save(ROOT/'output/prepare_h5_four_fixed29_current_areas_v3_20261108.py',s)
s=(ROOT/'output/audit_h5_four_fixed29_current_areas_v2_20261108.py').read_text(encoding='utf-8').replace('current-areas-v2-','current-areas-v3-')
s=s.replace('Independently fill exact coordinate cells by direct rectangle edge tests/boolean slices, not producer corner prefixes, and recompute every family/joint union-minus-fixed area and inventory threshold.', 'Independently sweep horizontal strips, maintaining active rectangle identities and merging/subtracting their x intervals. Recompute every family/joint union-minus-fixed area and inventory threshold without the producer vertical endpoint-prefix algorithm.')
start=s.index(";rectangles=np.array(")
end=s.index(";required=",start)
s=s[:start]+'''
    def merge(intervals):
        merged=[]
        for a,b in sorted(intervals):
            if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
            else:merged.append([a,b])
        return merged
    def length_minus(u,f):
        total=0;fi=0
        for a,b in u:
            while fi<len(f) and f[fi][1]<=a:fi+=1
            p=a;j=fi
            while j<len(f) and f[j][0]<b:
                c,d=f[j];total+=max(0,min(c,b)-p);p=max(p,d)
                if p>=b:break
                j+=1
            total+=max(0,b-p)
        return total
    groups=[sorted(regions['bracket']),sorted(regions['insert']),fixed];events={}
    for gi,rows in enumerate(groups):
        for ri,(a,b,c,d) in enumerate(rows):events.setdefault(b,[]).append((gi,ri,True));events.setdefault(d,[]).append((gi,ri,False))
    active=[set(),set(),set()];ys=sorted(events);totals=[0,0,0]
    for bottom,top in zip(ys,ys[1:]):
        for gi,ri,add in events[bottom]:
            if add:assert ri not in active[gi];active[gi].add(ri)
            else:active[gi].remove(ri)
        intervals=[merge((groups[gi][ri][0],groups[gi][ri][2]) for ri in selected) for gi,selected in enumerate(active)];fixed_intervals=intervals[2]
        for k,u in enumerate([intervals[0],intervals[1],merge(intervals[0]+intervals[1])]):totals[k]+=length_minus(u,fixed_intervals)*(top-bottom)
    for gi,ri,add in events[ys[-1]]:assert not add;active[gi].remove(ri)
    assert not any(active);areas=dict(zip(['bracket','insert'],totals[:2]));joint=totals[2]'''+s[end:]
save(ROOT/'output/audit_h5_four_fixed29_current_areas_v3_20261108.py',s)
for suffix in ['', '_audit']:
    p=ROOT/f'output/run_h5_four_fixed29_current_areas_v2{suffix}_stage_20261108.py'
    save(ROOT/f'output/run_h5_four_fixed29_current_areas_v3{suffix}_stage_20261108.py',p.read_text(encoding='utf-8').replace('current_areas_v2','current_areas_v3').replace('current-areas-v2','current-areas-v3'))
print('Prepared new v3 scripts; no numeric stage executed.')
