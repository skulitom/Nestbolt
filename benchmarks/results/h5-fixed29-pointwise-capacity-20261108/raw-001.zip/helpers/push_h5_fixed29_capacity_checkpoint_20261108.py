"""Ordinary verified atomic fast-forward of the free-angle evidence checkpoint."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-capacity-main-sync-20261108';OLD='38fec6c901084c91608064abf4b3f8268d90ec6c';BRANCH='codex/v1-1-shop-files';NAME='h5-fixed29-pointwise-capacity-20261108';RUN=42533572372
def command(*a):return subprocess.check_output(a,cwd=ROOT,text=True).strip()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not OUT.exists() and command('git','branch','--show-current')==BRANCH and not command('git','diff','HEAD','--name-only')
new=command('git','rev-parse','HEAD');paths=command('git','diff','--name-only',OLD+'..'+new).splitlines();allowed={'.gitattributes','BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md'};prefix='benchmarks/results/'+NAME
prefixes=[prefix];assert paths and all(p in allowed or any(p==q+'.md' or p.startswith(q+'/') for q in prefixes) for p in paths)
assert json.loads((ROOT/prefix/'archive-checks.json').read_bytes())['passed']
assert json.loads((ROOT/'output/h5-fixed29-capacity-staged-checks-20261108.json').read_bytes())['passed']
ci=json.loads(command('gh','run','view',str(RUN),'--json','databaseId,status,conclusion,headSha,jobs,url'));assert ci['headSha']==OLD and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
live=json.loads(command('gh','run','list','--branch','main','--limit','100','--json','databaseId,status,conclusion,headSha,workflowName,url'));assert all(r['status']=='completed' for r in live)
refs=dict(reversed(l.split()) for l in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines());assert refs=={'refs/heads/main':OLD,'refs/heads/'+BRANCH:OLD};subprocess.run(['git','merge-base','--is-ancestor',OLD,new],cwd=ROOT,check=True)
protected=json.loads((ROOT/'output/h5-resume-reconciliation-20261106/remote-files.json').read_bytes())
for p,h in protected.items():assert command('git','rev-parse',new+':'+p)==h,p
OUT.mkdir();write(OUT/'prior-main-ci.json',ci);write(OUT/'pre-push-run-check.json',live);write(OUT/'changed-paths.json',paths)
r=subprocess.run(['git','push','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/'+BRANCH],cwd=ROOT,capture_output=True);(OUT/'push-stdout.txt').write_bytes(r.stdout);(OUT/'push-stderr.txt').write_bytes(r.stderr);assert r.returncode==0,r.stderr
refs=dict(reversed(l.split()) for l in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines());assert set(refs.values())=={new};fresh=None
for _ in range(15):
    runs=json.loads(command('gh','run','list','--branch','main','--commit',new,'--workflow','Checks','--limit','10','--json','databaseId,status,conclusion,headSha,url'))
    if runs:fresh=runs[0];break
    time.sleep(2)
receipt={'utc':datetime.now(timezone.utc).isoformat(),'old_main':OLD,'new_main':new,'working_branch_also_updated':True,'normal_atomic_fast_forward':True,'prior_main_all6_pass':True,'prior_CI_run':RUN,'new_main_CI':fresh,'protected_files_preserved':len(protected),'changed_paths':len(paths),'evidence_and_status_only':True,'live_run_cancelled':False,'fixed_core_cases_remaining':0,'older_first32_cores_remaining':0,'earlier_arrangements_remaining':3,'whole_allocation_candidates_remaining':440,'completion_percent':60,'H2_complete':False,'H5_complete':False,'release_created':False};write(OUT/'receipt.json',receipt);print(receipt)
