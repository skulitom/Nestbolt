"""Pure exact rectangle unions minus fixed material, in square input units."""
import numpy as np

def vertical_areas(brackets,inserts,fixed):
    rows=[brackets,inserts,fixed]
    ys=sorted({r[k] for group in rows for r in group for k in [1,3]});yi={y:i for i,y in enumerate(ys)};events={}
    for gi,group in enumerate(rows):
        for a,b,c,d in group:
            assert a<c and b<d
            events.setdefault(a,[]).append((gi,yi[b],yi[d],1));events.setdefault(c,[]).append((gi,yi[b],yi[d],-1))
    xs=sorted(events);dy=np.diff(np.array(ys,dtype=np.int64));diff=np.zeros((3,len(ys)),dtype=np.int32);totals=[0,0,0]
    for left,right in zip(xs,xs[1:]):
        for gi,lo,hi,sign in events[left]:diff[gi,lo]+=sign;diff[gi,hi]-=sign
        counts=diff.cumsum(1,dtype=np.int32)[:,:-1];assert (counts>=0).all();clear=counts[2]==0;bmask=(counts[0]>0)&clear;imask=(counts[1]>0)&clear
        for k,mask in enumerate([bmask,imask,bmask|imask]):totals[k]+=int(dy[mask].sum())*(right-left)
    for gi,lo,hi,sign in events[xs[-1]]:diff[gi,lo]+=sign;diff[gi,hi]-=sign
    assert not diff.any()
    return totals

def horizontal_areas(brackets,inserts,fixed):
    def merge(intervals):
        merged=[]
        for a,b in sorted(intervals):
            if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
            else:merged.append([a,b])
        return merged
    def length_minus(u,f):
        total=0;fi=0
        for a,b in u:
            while fi<len(f) and f[fi][1]<=a:fi+=1
            p=a;j=fi
            while j<len(f) and f[j][0]<b:
                c,d=f[j];total+=max(0,min(c,b)-p);p=max(p,d)
                if p>=b:break
                j+=1
            total+=max(0,b-p)
        return total
    groups=[brackets,inserts,fixed];events={}
    for gi,rows in enumerate(groups):
        for ri,(a,b,c,d) in enumerate(rows):
            assert a<c and b<d
            events.setdefault(b,[]).append((gi,ri,True));events.setdefault(d,[]).append((gi,ri,False))
    active=[set(),set(),set()];ys=sorted(events);totals=[0,0,0]
    for bottom,top in zip(ys,ys[1:]):
        for gi,ri,add in events[bottom]:
            if add:assert ri not in active[gi];active[gi].add(ri)
            else:active[gi].remove(ri)
        intervals=[merge((groups[gi][ri][0],groups[gi][ri][2]) for ri in selected) for gi,selected in enumerate(active)];fixed_intervals=intervals[2]
        for k,u in enumerate([intervals[0],intervals[1],merge(intervals[0]+intervals[1])]):totals[k]+=length_minus(u,fixed_intervals)*(top-bottom)
    for gi,ri,add in events[ys[-1]]:assert not add;active[gi].remove(ri)
    assert not any(active)
    return totals
