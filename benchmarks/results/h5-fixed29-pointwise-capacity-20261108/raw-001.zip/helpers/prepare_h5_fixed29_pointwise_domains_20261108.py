"""Clip every current source-anchor cell by newly certified fixed cog material."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-pointwise-domains-20261108';DENSE=ROOT/'output/h5-fixed29-dense-cog-material-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';G=ROOT/'output/h5-first57-necessary-rectangles-20261104';HELPER=ROOT/'output/h5_exact_rectangle_areas_20261108.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def subtract(box,f):
    l,b,r,t=box;a,c,d,e=f
    if r<=a or l>=d or t<=c or b>=e:return [box]
    pieces=[]
    if l<=a:pieces.append((l,b,min(r,a),t))
    if r>=d:pieces.append((max(l,d),b,r,t))
    ml,mr=max(l,a),min(r,d)
    if ml<=mr:
        if b<=c:pieces.append((ml,b,mr,min(t,c)))
        if t>=e:pieces.append((ml,max(b,e),mr,t))
    return pieces
OUT.mkdir();began=time.perf_counter();parent=load(DENSE/'audit/checks.json');assert parent['passed'] and parent['fixed29_cases_remaining']==4;cases=load(OLD/'audit/case-results.json');inputs=[Path(__file__),HELPER,DENSE/'audit/checks.json',DENSE/'audit/plan.json',DENSE/'audit/case-results.json',DENSE/'world-new-inner-rectangles.json',OLD/'audit/checks.json',OLD/'audit/plan.json',OLD/'audit/case-results.json',OLD/'geometries.json',OLD/'stock-cover.json',G/'world-cog-inner-rectangles.json',G/'fixed-core-inner-rectangles.json']+[ROOT/r['source_graph']/'nodes.json' for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For every current compact graph position, retain its stable original source identity and all source aliases. Each original-common moving inner component and newly certified present fixed cog rectangle gives an OPEN forbidden lower-left-anchor rectangle. Subtract their union from the CLOSED current cell; preserve all points, lines and closed components on boundaries. Every original legal anchor remains in this refined cover. Recompute exact swept original-component family/joint union area minus all previously certified and new fixed material. No pairwise optimizer, model call or sampling is used.','process_cap_seconds':40,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];newworld=load(DENSE/'world-new-inner-rectangles.json');oldworld=load(G/'world-cog-inner-rectangles.json');fixedcore=load(G/'fixed-core-inner-rectangles.json');prior={r['refinement_index']:r for r in load(DENSE/'audit/case-results.json')};results=[]
for case in cases:
    index=case['refinement_index'];nodes=load(ROOT/case['source_graph']/'nodes.json');obstacles=[r['bounds_um'] for r in newworld if r['site_bit'] not in case['empty_sites']];forbidden=[]
    for g in geometries:
        rows=sorted({(l-c,b-d,r-a,t-e) for a,e,c,d in g['inner_rectangles_um'] for l,b,r,t in obstacles});forbidden.append(rows)
    write(OUT/f'choice-{index:02d}-forbidden.json',[{'geometry':i,'open_forbidden_anchor_rectangles_um':[list(v) for v in rows]} for i,rows in enumerate(forbidden)])
    arrays=[np.array(rows,dtype=np.int64) for rows in forbidden];records=[];regions={'bracket':set(),'insert':set()}
    for ni,node in enumerate(nodes):
        g=geometries[node['geometry']];l,b,r,t=node['bounds_um'];q=arrays[node['geometry']];indices=np.flatnonzero((q[:,0]<r)&(q[:,2]>l)&(q[:,1]<t)&(q[:,3]>b));pieces=[(l,b,r,t)]
        for fi in indices:
            pieces=sorted({p for box in pieces for p in subtract(box,forbidden[node['geometry']][int(fi)])})
            if not pieces:break
        records.append({'current_graph_position':ni,'source_node_label':node['node'],'geometry':node['geometry'],'intersecting_forbidden_indices':indices.tolist(),'remaining_closed_anchor_boxes_um':[list(v) for v in pieces]})
        for l,b,r,t in pieces:
            for a,c,d,e in g['all_alias_component_outer_rectangles_um']:
                rect=(max(l+a,stock[0]),max(b+c,stock[1]),min(r+d,stock[2]),min(t+e,stock[3]))
                if rect[0]<rect[2] and rect[1]<rect[3]:regions[g['family']].add(rect)
    fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+newworld if r['site_bit'] not in case['empty_sites']];regions={f:sorted(v) for f,v in regions.items()};totals=vertical_areas(regions['bracket'],regions['insert'],fixed);previous=prior[index];old=[previous['family_area_upper_um2'][f] for f in ['bracket','insert']]+[previous['joint_area_upper_um2']];assert all(a<=b for a,b in zip(totals,old));excluded=any(a<b for a,b in zip(totals,[8*39999*10**6,8*19799*10**6,8*(39999+19799)*10**6]))
    write(OUT/f'choice-{index:02d}-covers.json',records);write(OUT/f'choice-{index:02d}-regions.json',{'family_component_regions_um':{f:[list(v) for v in rows] for f,rows in regions.items()},'fixed_source_inner_rectangles_um':fixed});results.append({'refinement_index':index,'empty_sites':case['empty_sites'],'current_nodes':len(nodes),'nodes_fully_removed':sum(not r['remaining_closed_anchor_boxes_um'] for r in records),'nodes_refined':sum(r['remaining_closed_anchor_boxes_um']!=[n['bounds_um']] for r,n in zip(records,nodes)),'remaining_closed_anchor_boxes':sum(len(r['remaining_closed_anchor_boxes_um']) for r in records),'family_area_upper_um2':dict(zip(['bracket','insert'],totals[:2])),'joint_area_upper_um2':totals[2],'required_joint_area_lower_um2':8*(39999+19799)*10**6,'joint_area_reduction_um2':old[2]-totals[2],'provisional_exact_fixed_scope_excluded':excluded});print(results[-1],flush=True)
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':4,'current_nodes':sum(r['current_nodes'] for r in results),'provisional_exclusions':sum(r['provisional_exact_fixed_scope_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
