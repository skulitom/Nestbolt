"""Tighter source-contained fixed cog material for the four current exact scopes."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,math,time
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-dense-cog-material-20261108';BASE=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';G=ROOT/'output/h5-first57-necessary-rectangles-20261104';SOURCE=ROOT/'output/h5-first57-direct-short9-20261104';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json';HELPER=ROOT/'output/h5_exact_rectangle_areas_20261108.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();parent=load(BASE/'audit/checks.json');assert parent['passed'] and parent['fixed29_cases_remaining']==4
cases=load(BASE/'audit/case-results.json');inputs=[Path(__file__),HELPER,BASE/'audit/checks.json',BASE/'audit/plan.json',BASE/'audit/case-results.json',PIECES,G/'audit/checks.json',G/'audit/plan.json',G/'normalized-cog-inner-rectangles.json',G/'world-cog-inner-rectangles.json',G/'fixed-core-inner-rectangles.json',SOURCE/'family-modes.json',SOURCE/'source-cog-sites.json']+[BASE/f"choice-{r['refinement_index']:02d}-regions.json" for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Retain every current node and all12 original mode aliases. Enlarge only the certified mandatory fixed material by adding exact source-contained rectangles in horizontal bands at most1mm high inside each original cog convex piece. Binary64 transforms are exact rationals; signed integer halfplanes bound all band corners. Translate inward to all15 candidate cog sites, keep the75 earlier rectangles too, and use only the12 present sites for each exact scope. Recompute current family/joint swept areas minus the larger fixed-source union. This is an exclusion relaxation only: no placements, solver calls, positive-construction bounds or timer reset.','band_height_um':1000,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})
canonical=load(PIECES)['cog'];mode=load(SOURCE/'family-modes.json')['cog'][0];c,s=Q(math.cos(mode['rotation_radians'])),Q(math.sin(mode['rotation_radians']));sign=-1 if mode['mirrored'] else 1;tx,ty=map(Q,mode['translation_from_lower_left']);normalized=[];polygons=[]
for pi,piece in enumerate(canonical):
    posed=[(1000*(sign*Q(x)*c-Q(y)*s+tx),1000*(sign*Q(x)*s+Q(y)*c+ty)) for x,y in piece];D=math.lcm(*(v.denominator for p in posed for v in p));p=[tuple(int(v*D) for v in q) for q in posed]
    if sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))<0:p.reverse()
    polygons.append({'piece':pi,'denominator':str(D),'vertices_scaled':[[str(x),str(y)] for x,y in p]});bottom=-(-min(y for x,y in p)//D);top=max(y for x,y in p)//D
    for lo in range(bottom,top,1000):
        hi=min(lo+1000,top);left=None;right=None
        for a,b in zip(p,p[1:]+p[:1]):
            dx,dy=b[0]-a[0],b[1]-a[1]
            if not dy:assert all(dx*(y*D-a[1])>=0 for y in [lo,hi]);continue
            for y in [lo,hi]:
                num=a[0]*dy+dx*(y*D-a[1]);den=dy*D
                if dy<0:
                    bound=-(-(-num)//(-den));left=bound if left is None else max(left,bound)
                else:
                    bound=num//den;right=bound if right is None else min(right,bound)
        if left is not None and right is not None and left<right:normalized.append({'piece':pi,'bounds_um':[left,lo,right,hi]})
sites=load(SOURCE/'source-cog-sites.json');world=[]
for site,row in enumerate(sites):
    t=row['transform'];assert t['rotation_radians']==mode['rotation_radians'] and t['mirrored']==mode['mirrored'];shift=[1000*(Q(t['translation'][k])-Q(mode['translation_from_lower_left'][k])) for k in [0,1]]
    for r in normalized:
        q=[Q(v)+shift[k%2] for k,v in enumerate(r['bounds_um'])];bounds=[math.ceil(v) if k<2 else math.floor(v) for k,v in enumerate(q)]
        if bounds[0]<bounds[2] and bounds[1]<bounds[3]:world.append({'site_bit':site,'piece':r['piece'],'bounds_um':bounds})
write(OUT/'normalized-source-polygons.json',polygons);write(OUT/'normalized-new-inner-rectangles.json',normalized);write(OUT/'world-new-inner-rectangles.json',world);results=[];older=load(G/'world-cog-inner-rectangles.json');fixedcore=load(G/'fixed-core-inner-rectangles.json')
for case in cases:
    index=case['refinement_index'];data=load(BASE/f'choice-{index:02d}-regions.json');fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in older+world if r['site_bit'] not in case['empty_sites']];regions=data['family_component_regions_um'];totals=vertical_areas(regions['bracket'],regions['insert'],fixed);old=[case['family_area_upper_um2'][f] for f in ['bracket','insert']]+[case['joint_area_upper_um2']];assert all(a<=b for a,b in zip(totals,old));excluded=any(a<b for a,b in zip(totals,[8*39999*10**6,8*19799*10**6,8*(39999+19799)*10**6]))
    results.append({'refinement_index':index,'empty_sites':case['empty_sites'],'current_nodes':case['current_nodes'],'family_area_upper_um2':dict(zip(['bracket','insert'],totals[:2])),'joint_area_upper_um2':totals[2],'required_joint_area_lower_um2':8*(39999+19799)*10**6,'joint_area_reduction_um2':old[2]-totals[2],'fixed_source_rectangle_count':len(fixed),'provisional_exact_fixed_scope_excluded':excluded})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'normalized_new_rectangles':len(normalized),'world_new_rectangles':len(world),'cases':4,'provisional_exclusions':sum(r['provisional_exact_fixed_scope_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
