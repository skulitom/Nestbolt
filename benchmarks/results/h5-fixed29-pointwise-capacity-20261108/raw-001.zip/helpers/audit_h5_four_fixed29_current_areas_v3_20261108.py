"""Independent original-alias geometry and current-node swept-union area audit."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';OUT=BASE/'audit';G=ROOT/'output/h5-first57-necessary-rectangles-20261104';SOURCE=ROOT/'output/h5-first57-direct-short9-20261104';GRAPH=ROOT/'output/h5-exact-circle-graphs-20261107';CAP=ROOT/'output/h5-strip-capacity-set-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,G/'audit',SOURCE/'audit',GRAPH/'audit',CAP/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'source-alias-envelopes.json',BASE/'geometries.json',BASE/'stock-cover.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('choice-*-regions.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Verify every current capacity model names exactly the latest graph and retained source strip inequalities. Reconstruct all12 actual source mode transforms with rational matrix arithmetic, all source component vertices, alias envelope containment and exact original filled-area lower bounds. Reconstruct every current closed-node component sweep, all mandatory fixed29/cog-site source inner rectangles, and outward physical-stock clipping. Independently sweep horizontal strips, maintaining active rectangle identities and merging/subtracting their x intervals. Recompute every family/joint union-minus-fixed area and inventory threshold without the producer vertical endpoint-prefix algorithm. Parent audits bind complete continuous source covers, aliases and the exact latest conflict graphs; no closed call is rerun.'})
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES);modes=load(SOURCE/'family-modes.json');domains=load(G/'geometry-domains.json');geometry=load(BASE/'geometries.json');aliases=load(BASE/'source-alias-envelopes.json');assert len(aliases)==12 and len(geometry)==len(domains)==10;vertexchecks=0
for domain,g in zip(domains,geometry):
    assert all(g[k]==v for k,v in domain.items());envelopes=set()
    for family,mi in domain['aliases']:
        saved=next(r for r in aliases if r['geometry']==domain['geometry'] and r['family']==family and r['mode']==mi);mode=next(r for r in modes[family] if r['mode']==mi);c,s=Q(math.cos(mode['rotation_radians'])),Q(math.sin(mode['rotation_radians']));sign=-1 if mode['mirrored'] else 1;matrix=((sign*c,-s),(sign*s,c));shift=list(map(Q,mode['translation_from_lower_left']))
        def posed(piece):return [tuple(sum(matrix[k][j]*Q(p[j]) for j in range(2))+shift[k] for k in range(2)) for p in piece]
        assert len(saved['source_component_outer_rectangles_um'])==len(canonical[family])
        for component,box in zip(canonical[family],saved['source_component_outer_rectangles_um']):
            p=posed(component);a,b,r,t=map(lambda n:Q(n,1000),box);pad=Q(1,1000);assert all(a<=x-pad and x+pad<=r and b<=y-pad and y+pad<=t for x,y in p);envelopes.add(tuple(box));vertexchecks+=len(p)
        p=posed(parts[family]['geometry'][0]['outer']);area=abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])))/2;assert area==Q(saved['exact_posed_source_area_mm2'])>saved['source_area_lower_mm2']==(39999 if family=='bracket' else 19799)
    assert [list(v) for v in sorted(envelopes)]==g['all_alias_component_outer_rectangles_um']
physical=list(map(Q,load(SOURCE/'plan.json')['source_stocks']['sheet-0']));stock=load(BASE/'stock-cover.json')['outward_stock_rectangle_um'];assert stock==[6499,6499,1493501,2993501] and all(Q(stock[k],1000)<=physical[k] if k<2 else Q(stock[k],1000)>=physical[k] for k in range(4));choices=load(CAP/'audit/capacity-constraints.json');saved={r['refinement_index']:r for r in load(BASE/'case-results.json')};assert len(choices)==len(saved)==4;fixedcore=load(G/'fixed-core-inner-rectangles.json');world=load(G/'world-cog-inner-rectangles.json');results=[]
for choice in choices:
    index=choice['refinement_index'];folder=ROOT/choice['graph'];model=load(ROOT/'output'/f'h5-capacity-sat-{index:02d}-model-20261107'/'plan.json');assert model['graph']==choice['graph'] and model['capacity_source']=='output/h5-strip-capacity-set-20261107/audit';assert all(digest(ROOT/p)==h for p,h in model['inputs'].items());nodes=load(folder/'nodes.json');check=load(folder/'checks.json');priornodes=load(ROOT/check['old_graph']/'nodes.json');kept=load(folder/'kept-old-node-ids.json');assert len(nodes)==len(kept)==check['compact_nodes'] and len(set(kept))==len(kept) and len({n['node'] for n in nodes})==len(nodes);assert all(nodes[i]==priornodes[source_index] for i,source_index in enumerate(kept));fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in world if r['site_bit'] not in choice['empty_sites']];assert len(fixedcore)==29 and len({r['site_bit'] for r in world if r['site_bit'] not in choice['empty_sites']})==12;regions={'bracket':set(),'insert':set()}
    for ni,node in enumerate(nodes):
        g=geometry[node['geometry']];assert node['family']==(0 if g['family']=='bracket' else 1)
        for component in g['all_alias_component_outer_rectangles_um']:
            q=[node['bounds_um'][k]+component[k] for k in range(4)];q=(max(q[0],stock[0]),max(q[1],stock[1]),min(q[2],stock[2]),min(q[3],stock[3]))
            if q[0]<q[2] and q[1]<q[3]:regions[g['family']].add(q)
    data={'refinement_index':index,'empty_sites':choice['empty_sites'],'family_component_regions_um':{f:[list(v) for v in sorted(regions[f])] for f in regions},'fixed_source_inner_rectangles_um':fixed};assert data==load(BASE/f'choice-{index:02d}-regions.json')
    def merge(intervals):
        merged=[]
        for a,b in sorted(intervals):
            if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
            else:merged.append([a,b])
        return merged
    def length_minus(u,f):
        total=0;fi=0
        for a,b in u:
            while fi<len(f) and f[fi][1]<=a:fi+=1
            p=a;j=fi
            while j<len(f) and f[j][0]<b:
                c,d=f[j];total+=max(0,min(c,b)-p);p=max(p,d)
                if p>=b:break
                j+=1
            total+=max(0,b-p)
        return total
    groups=[sorted(regions['bracket']),sorted(regions['insert']),fixed];events={}
    for gi,rows in enumerate(groups):
        for ri,(a,b,c,d) in enumerate(rows):events.setdefault(b,[]).append((gi,ri,True));events.setdefault(d,[]).append((gi,ri,False))
    active=[set(),set(),set()];ys=sorted(events);totals=[0,0,0]
    for bottom,top in zip(ys,ys[1:]):
        for gi,ri,add in events[bottom]:
            if add:assert ri not in active[gi];active[gi].add(ri)
            else:active[gi].remove(ri)
        intervals=[merge((groups[gi][ri][0],groups[gi][ri][2]) for ri in selected) for gi,selected in enumerate(active)];fixed_intervals=intervals[2]
        for k,u in enumerate([intervals[0],intervals[1],merge(intervals[0]+intervals[1])]):totals[k]+=length_minus(u,fixed_intervals)*(top-bottom)
    for gi,ri,add in events[ys[-1]]:assert not add;active[gi].remove(ri)
    assert not any(active);areas=dict(zip(['bracket','insert'],totals[:2]));joint=totals[2];required=8*39999*10**6+8*19799*10**6;excluded=any(areas[f]<8*lower*10**6 for f,lower in [('bracket',39999),('insert',19799)]) or joint<required;row={'refinement_index':index,'empty_sites':choice['empty_sites'],'source_graph':choice['graph'],'current_nodes':len(nodes),'current_bracket_nodes':sum(r['family']==0 for r in nodes),'current_insert_nodes':sum(r['family']==1 for r in nodes),'source_strip_inequalities_preserved':len(choice['constraints']),'family_area_upper_um2':areas,'joint_area_upper_um2':joint,'required_joint_area_lower_um2':required,'provisional_exact_fixed_scope_excluded':excluded};assert row==saved[index];results.append({**row,'exact_fixed_scope_excluded':excluded})
process=load(ROOT/'output/h5-four-fixed29-current-areas-v3-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_fixed_scope_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'current_fixed29_cases_verified':4,'source_mode_aliases_verified':12,'source_component_vertices_verified':vertexchecks,'source_geometry_groups_verified':10,'latest_graph_nodes_verified':sum(r['current_nodes'] for r in results),'preserved_source_strip_inequalities':sum(r['source_strip_inequalities_preserved'] for r in results),'exact_area_bounds_verified':12,'additional_fixed29_cases_excluded':4-len(remaining),'fixed29_cases_remaining':len(remaining),'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
