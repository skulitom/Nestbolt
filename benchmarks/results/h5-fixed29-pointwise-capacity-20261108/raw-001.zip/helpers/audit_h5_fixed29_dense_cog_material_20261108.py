"""Independent direct source halfplane containment and horizontal area replay."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
from h5_exact_rectangle_areas_20261108 import horizontal_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-dense-cog-material-20261108';OUT=BASE/'audit';PARENT=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';G=ROOT/'output/h5-first57-necessary-rectangles-20261104';SOURCE=ROOT/'output/h5-first57-direct-short9-20261104';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,PARENT/'audit',G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py']+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently reconstruct every original cog convex piece at all15 exact binary64 source transforms. Verify all four corners of EVERY new world rectangle against EVERY oriented source halfplane using exact scaled integers; no producer band-section procedure is reused. Parent source boundary/area partition proof certifies these convex pieces are original material. Replay all four family/joint union-minus-fixed bounds with horizontal active-rectangle interval merging/subtraction, independent of producer vertical signed-prefix sweep. All current source covers and aliases remain unchanged.'})
pieces=load(PIECES)['cog'];sites=load(SOURCE/'source-cog-sites.json');world=load(BASE/'world-new-inner-rectangles.json');normalized=load(BASE/'normalized-new-inner-rectangles.json');assert len(sites)==15;cornerchecks=0;halfplanechecks=0
for site,row in enumerate(sites):
    t=row['transform'];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;matrix=((sign*c,-s),(sign*s,c));translation=list(map(Q,t['translation']));polygons=[]
    for piece in pieces:
        posed=[tuple((sum(matrix[k][j]*Q(p[j]) for j in range(2))+translation[k])*1000 for k in range(2)) for p in piece];D=math.lcm(*(q.denominator for p in posed for q in p));poly=[tuple(int(q*D) for q in p) for p in posed];signed=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(poly,poly[1:]+poly[:1]));assert signed!=0;polygons.append((D,poly,1 if signed>0 else -1))
    records=[r for r in world if r['site_bit']==site];assert records
    for r in records:
        D,p,orientation=polygons[r['piece']];a,b,c,d=r['bounds_um'];assert a<c and b<d
        for x,y in product([a,c],[b,d]):
            x*=D;y*=D
            for u,v in zip(p,p[1:]+p[:1]):assert orientation*((v[0]-u[0])*(y-u[1])-(v[1]-u[1])*(x-u[0]))>=0;halfplanechecks+=1
            cornerchecks+=1
assert all(0<=r['site_bit']<15 for r in world);oldworld=load(G/'world-cog-inner-rectangles.json');fixedcore=load(G/'fixed-core-inner-rectangles.json');saved=load(BASE/'case-results.json');cases=load(PARENT/'audit/case-results.json');assert len(cases)==len(saved)==4;results=[]
for case,row in zip(cases,saved):
    index=case['refinement_index'];data=load(PARENT/f'choice-{index:02d}-regions.json');fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+world if r['site_bit'] not in case['empty_sites']];regions=data['family_component_regions_um'];totals=horizontal_areas(regions['bracket'],regions['insert'],fixed);old=[case['family_area_upper_um2'][f] for f in ['bracket','insert']]+[case['joint_area_upper_um2']];assert all(a<=b for a,b in zip(totals,old));excluded=any(a<b for a,b in zip(totals,[8*39999*10**6,8*19799*10**6,8*(39999+19799)*10**6]));expected={'refinement_index':index,'empty_sites':case['empty_sites'],'current_nodes':case['current_nodes'],'family_area_upper_um2':dict(zip(['bracket','insert'],totals[:2])),'joint_area_upper_um2':totals[2],'required_joint_area_lower_um2':8*(39999+19799)*10**6,'joint_area_reduction_um2':old[2]-totals[2],'fixed_source_rectangle_count':len(fixed),'provisional_exact_fixed_scope_excluded':excluded};assert expected==row;results.append({**row,'exact_fixed_scope_excluded':excluded})
process=load(ROOT/'output/h5-fixed29-dense-cog-material-process-20261108/process.json');assert process['closed'] and process['passed'];remaining=[r for r in results if not r['exact_fixed_scope_excluded']];charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'world_source_rectangles_verified':len(world),'source_rectangle_corners_verified':cornerchecks,'exact_source_halfplanes_verified':halfplanechecks,'current_fixed29_cases_verified':4,'latest_graph_nodes_preserved':16267,'source_aliases_preserved':12,'source_strip_inequalities_preserved':16,'exact_area_bounds_verified':12,'additional_fixed29_cases_excluded':4-len(remaining),'fixed29_cases_remaining':len(remaining),'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_excluded':0,'H5_complete':False});print(load(OUT/'checks.json'))
