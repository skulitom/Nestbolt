"""Freeze new positive-clearance covers for the three remaining exact scopes."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(p,s):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for kind in ['prepare','audit']:
    s=(ROOT/f'output/{kind}_h5_fixed29_pointwise_domains_20261108.py').read_text(encoding='utf-8')
    s=s.replace('h5-fixed29-pointwise-domains-20261108','h5-fixed29-clearance-domains-20261108').replace('h5-fixed29-pointwise-domains-process-20261108','h5-fixed29-clearance-domains-process-20261108')
    s=s.replace('import json,time','from fractions import Fraction as Q\nimport json,time')
    anchor="load=lambda p:"
    pos=s.index(anchor)
    s=s[:pos]+"PREVIOUS=ROOT/'output/h5-fixed29-pointwise-domains-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'\n"+s[pos:]
    if kind=='prepare':
        s=s.replace("parent=load(DENSE/'audit/checks.json');assert parent['passed'] and parent['fixed29_cases_remaining']==4;cases=load(OLD/'audit/case-results.json');inputs=[Path(__file__),", "parent=load(PREVIOUS/'audit/checks.json');assert parent['passed'] and parent['fixed29_cases_remaining']==3;remaining={r['refinement_index'] for r in load(PREVIOUS/'audit/remaining-cases.json')};cases=[r for r in load(OLD/'audit/case-results.json') if r['refinement_index'] in remaining];assert load(JOB)['clearance']==.2 and Q(load(JOB)['clearance'])>=Q(1,5) and 2*141**2<200**2;inputs=[Path(__file__),JOB,PREVIOUS/'audit/checks.json',PREVIOUS/'audit/plan.json',PREVIOUS/'audit/case-results.json',PREVIOUS/'audit/remaining-cases.json',")
        s=s.replace('Each original-common moving inner component and newly certified present fixed cog rectangle gives an OPEN forbidden lower-left-anchor rectangle.', 'The original job requires0.2mm clearance. Enlarge every certified present fixed-source rectangle by141um on each axis; every buffer offset has squared distance at most39762um2, strictly less than40000um2. Moving source material must avoid each enlarged rectangle. Each original-common moving inner component gives an OPEN forbidden lower-left-anchor rectangle against this enlarged fixed material.')
        s=s.replace("'process_cap_seconds':40", "'clearance_mm':.2,'square_buffer_halfwidth_um':141,'maximum_squared_buffer_distance_um2':39762,'process_cap_seconds':40")
        s=s.replace("load(DENSE/'audit/case-results.json')", "load(PREVIOUS/'audit/case-results.json')")
        s=s.replace("obstacles=[r['bounds_um'] for r in newworld if r['site_bit'] not in case['empty_sites']];forbidden=[]", "source_obstacles=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+newworld if r['site_bit'] not in case['empty_sites']];obstacles=[(a-141,b-141,c+141,d+141) for a,b,c,d in source_obstacles];forbidden=[]")
        s=s.replace("fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+newworld if r['site_bit'] not in case['empty_sites']];regions=", "fixed=[list(v) for v in obstacles];regions=")
        s=s.replace("'cases':4", "'cases':3")
    else:
        s=s.replace("for folder in [BASE,DENSE/'audit',OLD/'audit']:", "for folder in [BASE,PREVIOUS/'audit',DENSE/'audit',OLD/'audit']:")
        s=s.replace('Reconstruct every open forbidden rectangle from actual source-certified fixed/moving inner components and every current source node.', 'Verify the original job clearance is0.2mm. Every141um-axis square-buffer corner has norm strictly below200um. Reconstruct each buffer from certified actual fixed-source rectangles, then every open forbidden rectangle against actual-common moving inner components and every current source node. A source point inside the buffer violates the original clearance by the explicit nearby-source rectangle witness; no larger clearance is substituted.')
        s=s.replace("prior={r['refinement_index']:r for r in load(DENSE/'audit/case-results.json')};cases=load(OLD/'audit/case-results.json');saved=load(BASE/'case-results.json');assert len(cases)==len(saved)==4;", "prior={r['refinement_index']:r for r in load(PREVIOUS/'audit/case-results.json')};remaining={r['refinement_index'] for r in load(PREVIOUS/'audit/remaining-cases.json')};cases=[r for r in load(OLD/'audit/case-results.json') if r['refinement_index'] in remaining];assert load(JOB)['clearance']==.2 and Q(load(JOB)['clearance'])>=Q(1,5) and all(x*x+y*y<200**2 for x in [-141,141] for y in [-141,141]);saved=load(BASE/'case-results.json');assert len(cases)==len(saved)==3;")
        s=s.replace("obstacles=[r['bounds_um'] for r in newworld if r['site_bit'] not in case['empty_sites']];forbidden=", "source_obstacles=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+newworld if r['site_bit'] not in case['empty_sites']];obstacles=[[q[k]+(-141 if k<2 else 141) for k in range(4)] for q in source_obstacles];forbidden=")
        s=s.replace("fixed=[r['bounds_um'] for r in fixedcore]+[r['bounds_um'] for r in oldworld+newworld if r['site_bit'] not in case['empty_sites']];regions=", "fixed=obstacles;regions=")
        s=s.replace("'current_fixed29_cases_verified':4", "'current_fixed29_cases_verified':3,'original_clearance_mm':.2,'square_buffer_halfwidth_um':141")
        s=s.replace("'additional_fixed29_cases_excluded':4-len(remaining)", "'additional_fixed29_cases_excluded':3-len(remaining)")
        s=s.replace("'source_strip_inequalities_preserved':16", "'source_strip_inequalities_preserved':12").replace("'exact_area_bounds_verified':12", "'exact_area_bounds_verified':9")
    save(ROOT/f'output/{kind}_h5_fixed29_clearance_domains_20261108.py',s)
for suffix in ['', '_audit']:
    s=(ROOT/f'output/run_h5_fixed29_pointwise_domains{suffix}_stage_20261108.py').read_text(encoding='utf-8').replace('fixed29_pointwise_domains','fixed29_clearance_domains').replace('fixed29-pointwise-domains','fixed29-clearance-domains')
    save(ROOT/f'output/run_h5_fixed29_clearance_domains{suffix}_stage_20261108.py',s)
print('Prepared three-case original-clearance proof; no stage opened.')
