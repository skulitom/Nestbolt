"""Archive independently verified fixed29 pointwise capacity and failed preparations."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
stage_names=['four-fixed29-current-areas-v3','fixed29-dense-cog-material','fixed29-pointwise-domains','fixed29-clearance-domains']
failed_names=['four-fixed29-current-areas','four-fixed29-current-areas-v2']
process_names=failed_names+[v+s for v in stage_names for s in ['', '-audit']]
process_paths=[ROOT/'output'/('h5-'+n+'-process-20261108') for n in process_names]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-fixed29-pointwise-capacity-20261108'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-fixed29-clearance-domains-20261108';F=BASE/'audit';D=ROOT/'output/h5-fixed29-pointwise-domains-20261108'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-older-cog-family-closure-20261108'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['current_fixed29_cases_verified']==3 and front['fixed29_cases_remaining']==3 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[ROOT/'output'/('h5-'+n+'-20261108') for n in stage_names+failed_names]+[ROOT/'output/h5-older-cog-closure-main-sync-20261108']+process_paths",
"['*h5*mixed*mode*20261107.py']":"['*h5_four_fixed29*20261108.py','*h5_fixed29_dense_cog_material*20261108.py','*h5_fixed29_pointwise_domains*20261108.py','*h5_fixed29_clearance_domains*20261108.py','*h5_fixed29_capacity*20261108.py','h5_exact_rectangle_areas_20261108.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_fixed29_capacity_checkpoint_20261108.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
copies=[];process_table=[]
for name in stage_names:
    folder=ROOT/'output'/('h5-'+name+'-20261108');assert load(folder/'audit/checks.json')['passed'];copies.extend([(folder/'plan.json',name+'-plan.json'),(folder/'audit/checks.json',name+'-audit.json'),(folder/'audit/case-results.json',name+'-cases.json')])
copies.extend([(F/'remaining-cases.json','remaining-fixed29-cases.json'),(ROOT/'output/h5-four-fixed29-current-areas-correction-20261108.json','failed-indexing-correction.json'),(ROOT/'output/h5-four-fixed29-current-areas-v2-correction-20261108.json','failed-grid-size-correction.json'),(ROOT/'output/h5-older-cog-closure-main-sync-20261108/receipt.json','prior-main-push-receipt.json')])
for name,folder in zip(process_names,process_paths):
    r=load(folder/'process.json');assert r['closed'] and r['job']['active_processes']==0 and r['passed']==(name not in failed_names);copies.append((folder/'process.json',name+'-process.json'));process_table.append({'stage':name,'seconds':r['complete_seconds'],'cap_seconds':r['job']['maximum_ms']/1000,'passed':r['passed'],'closed':True,'active_processes':0})
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'process-summary.json',process_table)
first=load(ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/audit/case-results.json');dense={r['refinement_index']:r for r in load(ROOT/'output/h5-fixed29-dense-cog-material-20261108/audit/case-results.json')};pointwise={r['refinement_index']:r for r in load(D/'audit/case-results.json')};clearance={r['refinement_index']:r for r in load(F/'case-results.json')};frontier=[]
for r in first:
    index=r['refinement_index'];p=pointwise[index];latest=clearance.get(index,p);assert p['exact_fixed_scope_excluded']==(index==16)
    frontier.append({'refinement_index':index,'empty_sites':r['empty_sites'],'current_graph':r['source_graph'],'current_nodes':r['current_nodes'],'initial_joint_area_upper_um2':r['joint_area_upper_um2'],'dense_material_joint_area_upper_um2':dense[index]['joint_area_upper_um2'],'pointwise_zero_clearance_joint_area_upper_um2':p['joint_area_upper_um2'],'original_clearance_joint_area_upper_um2':None if index==16 else latest['joint_area_upper_um2'],'required_joint_area_lower_um2':478384000000,'exact_fixed_scope_excluded':p['exact_fixed_scope_excluded'],'first_excluding_stage':'pointwise zero-clearance source cover' if index==16 else None})
assert len(frontier)==4 and sum(r['exact_fixed_scope_excluded'] for r in frontier)==1;write(OUT/'four-case-frontier.json',frontier)
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42533572372','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='38fec6c901084c91608064abf4b3f8268d90ec6c';success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
total=front['complete_preparation_seconds_if_consumed'];assert total>60
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'initial_fixed29_choices':4,'additional_fixed29_choices_excluded':1,'remaining_fixed29_choices':3,'fixed29_choices_excluded_of455':452,'fixed29_zero_clearance_exclusions_of455':428,'older_first32_cores_closed':8,'separate_five_column_cores_closed':680,'failed_preparations_preserved':2,'all 10_processes_closed':True,'whole_allocations_remaining':440})
write(OUT/'next-step.json',{'status':'one_additional_exact_fixed29_scope_excluded','remaining_fixed29_choices':[[0,5,10],[5,10,11],[11,12,13]],'closed_fixed29_choice':[10,11,12],'proposal':'Use the newly audited pointwise original-clearance covers as the complete domain authority for the three surviving exact fixed29/cog scopes. Do not reopen the removed scope or any unchanged closed model/call. A prospective next proof may condition on every possible cell of a required bracket and use actual source-material collision/area bounds for the remaining7brackets+8inserts; it must preserve all aliases, every boundary, original owners, selected-cell multiplicity, and existing conflict/strip constraints. No such conditional graph/model or call has been prepared. Whole-job alternatives remain open. Any future timed constructor must genuinely recompute numerical inputs from original geometry and pass a separate preparation-inclusive preflight; the present numeric lineage is exhausted.','numeric_cover_source':'output/h5-fixed29-clearance-domains-20261108','numeric_areas_are_relaxations':True,'source_cells_not_placements':True,'consumed_preparation_seconds':total,'optimizer_allowed_from_current_lineage':False,'closed_optimizer_calls_reopened':False,'new_optimizer_models_prepared':False,'whole_allocation_candidates_remaining':440,'source_valid66':False,'H5_complete':False})
table='\n'.join('| '+str(r['empty_sites'])+' | '+' | '.join('—' if r[k] is None else f"{r[k]/10**6:,.6f}" for k in ['initial_joint_area_upper_um2','dense_material_joint_area_upper_um2','pointwise_zero_clearance_joint_area_upper_um2','original_clearance_joint_area_upper_um2'])+' | '+('Excluded' if r['exact_fixed_scope_excluded'] else 'Open')+' |' for r in frontier)
process_rows='\n'.join(f"| {r['stage']} | {r['seconds']:.6f} | {r['cap_seconds']:.0f} | {'Pass' if r['passed'] else 'Preserved failure'} |" for r in process_table)
report=f'''# Fixed29 pointwise capacity — 2026-11-08

**One more exact fixed29/cog arrangement is excluded: omitted sites
`[10,11,12]`. Three remain: `[0,5,10]`, `[5,10,11]`, `[11,12,13]`.**
The excluded arrangement has at most **477,644.122166 mm²** available for
eight original brackets and eight original inserts, which require at least
**478,384 mm²**. The **739.877834 mm² deficit** holds even at zero clearance.
This brings the fixed29 family to **452 of 455 excluded**, including **428 at
zero clearance**. It is conditional on the actual fixed29 and twelve fixed
cog poses. No whole allocation or orientation class is excluded.

H2/H5 remain open at **60% completed milestone weight**; the valid 64-part layout
remains best. The separate eight older first32 cores and 680 five-column cores
remain closed. No optimizer call, placement, native validation or release occurs.

The current scope fixes 18 frames and 11 inserts, twelve of fifteen cog sites,
and leaves 8 brackets + 8 inserts free over their complete source orientation domains.
The independently validated short9 remains 4 brackets + 2 inserts + 3 cogs. Site-template
labels designate positions, not original cog-owner assignments. The earlier
[identity/scope reconciliation](h5-older-cog-family-closure-20261108/remaining-fixed29-scopes.json)
preserves all 66 original quantities and ownership constraints.

## Current domains and exact area controls

[The initial area audit]({NAME}/four-fixed29-current-areas-v3-audit.json) checks
all **16,267 current exact-circle graph cells**,10 geometry groups and12 original
mode aliases, including all 80 component vertices. The graph positions are
compacted; their source-node labels remain unchanged. Exact prior-node maps and
the subsequent capacity-model inputs are verified, preserving all 16 strip
inequalities. Each original component is enclosed outward, swept over every
closed anchor cell and clipped to outward physical stock. Required areas use
conservative source lower bounds 39,999/19,799 mm² per bracket/insert.

The first preparation failed an incorrect source-label/index equality. The
second passed the mapping check but hit its preset dense-grid size guard.
Neither produced a case area or exclusion. Both complete failures and corrections
are retained: [index mapping]({NAME}/failed-indexing-correction.json),
[grid-size guard]({NAME}/failed-grid-size-correction.json). A new bounded vertical
strip algorithm replaced dense allocation. Its exact signed endpoint prefixes
agree with an independent horizontal active-rectangle interval merge/subtraction.

[Finer source material]({NAME}/fixed29-dense-cog-material-audit.json) adds
**12,870 rectangles across 15 cog sites**, derived inside the original convex
source pieces in bands no more than 1 mm high. Exact binary64 transforms are
rational arithmetic. Independent replay checks **51,480 rectangle corners
against 678,960 source halfplanes**. The earlier 75 rectangles per cog remain.
The material union alone excludes no additional case.

[Pointwise source covers]({NAME}/fixed29-pointwise-domains-audit.json) then
subtract the OPEN forbidden anchor rectangles from every CLOSED current cell.
It refines **2,743 cells** into 20,290 closed boxes while removing no whole
current cell. Every boundary point and open-interval class is retained exactly:
**668,825 complete classes** pass independent set-equality checks, without reuse
of the producer subtraction algorithm. Exact swept-area conservation then
excludes `[10,11,12]`. Every source mode and every continuous anchor is covered.

[The original-clearance check]({NAME}/fixed29-clearance-domains-audit.json)
uses the unchanged 0.2 mm job requirement. Each certified fixed-source rectangle
is expanded 141 µm on both axes; every buffer offset has squared norm at most
39,762 µm², strictly below 40,000 µm². These are **forbidden clearance regions**,
not additional source material. A source point there would be too close to an
actual fixed-source point. Another **590,749 boundary/interior classes** and
nine exact area bounds pass; all three remaining cases stay open.

| Omitted sites | Current area | Finer fixed material | Pointwise, zero clearance | Original clearance | Result |
|---|---:|---:|---:|---:|---|
{table}

Areas are mm² upper bounds for the combined moving material. They must reach
478,384 mm²; a surplus is only a necessary relaxation, not a valid placement.
[The four-case frontier]({NAME}/four-case-frontier.json) and
[remaining cases]({NAME}/remaining-fixed29-cases.json) retain exact integers.

## Closed processes and remaining work

| Bounded stage | Complete process (s) | Cap (s) | Result |
|---|---:|---:|---|
{process_rows}

[All ten processes close]({NAME}/process-summary.json) with zero children,
unchanged CCD1/thread controls and 2 GiB Windows Job limits. Both failed
preparations remain charged. Consumed numeric preparation is **{total:.6f} s**;
no optimizer, timer reset or timed H5 acceptance is permitted from this lineage.

[Next]({NAME}/next-step.json), stronger conditional companion bounds may use
these complete pointwise covers. No conditional graph or optimizer model is
prepared. The three exact scopes, all 440 whole-job allocations, full 66-part
source/native/material checks, production integration and the full H5 matrix
remain open. Product, README and releases are unchanged.

[The prior checkpoint reached main 38fec6c9]({NAME}/prior-main-push-receipt.json).
[Its CI at review]({NAME}/main-ci-at-review.json) has **{success} passed / {live}
live jobs**; this checkpoint awaits the ordinary push gate.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve the evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-08 H5 fixed29 pointwise capacity:** [complete current source covers]({{link}}) exclude omitted cog sites[10,11,12] by 739.877834 mm² at zero clearance. Three exact fixed29 choices remain:[0,5,10],[5,10,11],[11,12,13];452/455 are excluded,428 even at zero clearance. All16267 latest graph cells,12 source aliases and16 strip inequalities reconcile. Finer actual cog material adds12870 rectangles, independently checking51480 corners and678960 halfplanes. Exact pointwise collision subtraction refines2743 cells;668825 complete boundary/interior classes and12area bounds pass. Original0.2mm clearance uses certified141µm square buffers;590749 additional classes and9area bounds pass without another exclusion. Both failed indexing/grid preparations remain preserved and charged; all 10 processes close. Consumed preparation {total:.6f}s cannot reset or open an optimizer. The separate8older and 680five-column cores remain closed; all 440 whole allocations remain, valid 64-part stays best and H2/H5 stay open at 60%. Prior main 38fec6c9 has {success} passed / {live} live CI jobs; ordinary push pending. Product/releases unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';content=p.read_text(encoding='utf-8');a=content.index('Latest H5 evidence:');b=content.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [fixed29 pointwise capacity](../benchmarks/results/{NAME}.md).
Complete source covers exclude omitted cog sites [10,11,12] by 739.877834 mm²
even at zero clearance. Three exact fixed29 choices remain: [0,5,10],
[5,10,11], [11,12,13]. This family now has 452/455 exclusions, 428 at zero
clearance. The separate eight older first32 and 680 five-column cores remain
closed. No whole allocation or orientation class is excluded.
Independent audits verify all 16,267 current cells,12 source aliases, finer
actual cog material and 1,259,574 complete boundary/interior classes across
zero-clearance and original 0.2 mm-clearance covers. All ten processes close;
two preparation failures remain preserved and charged. Consumed preparation
is {total:.6f} s; no optimizer or timer reset is permitted. All440 whole-job
allocations remain; valid 64-part stays best and H2/H5 stay open at 60%.
Prior checkpoint reached main 38fec6c9; its CI has {success} passed / {live} live
jobs at review. This checkpoint awaits ordinary push. Product/releases unchanged.
'''
p.write_text(content[:a]+intro+content[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'consumed_preparation_seconds':total,'fixed29_remaining':3,'main_ci_passed':success,'main_ci_live':live})
