"""Bind occupied-envelope semantics to the original job and common-line policy."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-reserved-hole-scope-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OLD=ROOT/'output/h5-first57-direct-short9-20261104';GEOM=ROOT/'output/h5-first57-necessary-rectangles-20261104';NEW=ROOT/'output/h5-fixed29-pointwise-domains-20261108';FINAL=ROOT/'output/h5-fixed29-clearance-domains-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(ring):
    p=[tuple(map(Q,v)) for v in ring];return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])))/2
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),JOB,ROOT/'docs/COMMON_LINES.md',ROOT/'crates/core/src/common_line.rs',ROOT/'crates/core/src/sheets.rs',ROOT/'crates/core/src/project/cutting.rs',ROOT/'crates/core/tests/common_line.rs',ROOT/'output/h5_legacy64_source_readback.py',OLD/'audit/plan.json',OLD/'audit/checks.json',GEOM/'audit/checks.json',GEOM/'audit/exact-source-partitions.json',NEW/'audit/checks.json',NEW/'audit/case-results.json',FINAL/'audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read the exact original holes and outer rings, original-source readback, common-line search/export code, policy docs and rejection test. Independently compute outer-envelope and net material areas and distinguish their roles. The existing geometry partitions and area bounds measure occupied original outer envelopes with holes reserved in common-line mode; they do not assert rectangles inside net material and do not exclude ordinary part-in-hole layouts. No geometric stage or closed optimization is rerun.','process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'inherited_numeric_preparation_seconds':load(FINAL/'audit/checks.json')['complete_preparation_seconds_if_consumed']})
doc=(ROOT/'docs/COMMON_LINES.md').read_text(encoding='utf-8');common=(ROOT/'crates/core/src/common_line.rs').read_text(encoding='utf-8');sheets=(ROOT/'crates/core/src/sheets.rs').read_text(encoding='utf-8');cutting=(ROOT/'crates/core/src/project/cutting.rs').read_text(encoding='utf-8');test=(ROOT/'crates/core/tests/common_line.rs').read_text(encoding='utf-8');readback=(ROOT/'output/h5_legacy64_source_readback.py').read_text(encoding='utf-8')
assert "Parts are not nested inside other parts' holes in this mode." in doc
assert 'common-line mode does not allow parts inside holes; nest again with part-in-hole disabled' in common
assert 'Common-line mode reserves every hole and therefore skips the rider pre-pass.' in sheets
assert 'let allow_part_in_hole = self.common_options.is_none();' in cutting
assert 'A valid part inside a host hole is rejected for common-line mode.' in test and '.contains("part-in-hole disabled")' in test
assert "filled=Polygon(ring(g['outer']))" in readback and "[p['part_id'],p['copy_index']],filled)" in readback
assert load(OLD/'audit/checks.json')['passed'] and load(GEOM/'audit/checks.json')['passed'];partition=load(GEOM/'audit/exact-source-partitions.json');assert all(p['exact_partition_boundary_and_area'] for p in partition)
job=load(JOB);parts={p['id']:p for p in job['parts']};records=[]
for family in ['bracket','insert','cog','frame']:
    p=parts[family];assert len(p['geometry'])==1;g=p['geometry'][0];outer=area(g['outer']);holes=sum((area(h) for h in g['holes']),Q(0));assert 0<holes<outer;records.append({'family':family,'quantity':p['quantity'],'holes_per_original':len(g['holes']),'exact_original_outer_envelope_area_mm2':str(outer),'exact_original_hole_area_mm2':str(holes),'exact_original_net_material_area_mm2':str(outer-holes),'capacity_occupancy':'original outer envelope, holes reserved'})
assert Q(records[0]['exact_original_outer_envelope_area_mm2'])==40000 and Q(records[1]['exact_original_outer_envelope_area_mm2'])==19800
assert sum(r['quantity'] for r in records)==66 and sum(r['quantity']*r['holes_per_original'] for r in records)==90
cases=load(NEW/'audit/case-results.json');excluded=[r for r in cases if r['exact_fixed_scope_excluded']];assert len(excluded)==1 and excluded[0]['empty_sites']==[10,11,12];assert excluded[0]['required_joint_area_lower_um2']==(8*39999+8*19799)*10**6 and excluded[0]['joint_area_upper_um2']==477644122166
write(OUT/'source-occupancy-areas.json',records);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'originals':66,'preserved_original_holes':90,'required_moving_originals':16,'required_reserved_outer_envelope_area_lower_mm2':478384,'excluded_scope_joint_reserved_area_upper_um2':477644122166,'excluded_scope_deficit_um2':739877834,'common_line_hole_reservation_required':True,'production_search_policy_verified':True,'production_export_rejection_verified':True,'existing_rejection_test_read':True,'original_source_filled_outer_readback_verified':True,'net_material_area_not_used_as_capacity':True,'rectangles_inside_net_material_claimed':False,'ordinary_part_in_hole_exclusions':0,'exclusion_with_reserved_holes_remains_valid':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
