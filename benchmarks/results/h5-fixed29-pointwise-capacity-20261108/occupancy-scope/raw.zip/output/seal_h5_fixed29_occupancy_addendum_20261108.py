"""Seal explicit common-line reserved-hole scope without changing prior raw evidence."""
from pathlib import Path
from hashlib import sha256
import json,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-reserved-hole-scope-20261108';PROCESS=ROOT/'output/h5-fixed29-reserved-hole-scope-process-20261108';NAME='h5-fixed29-pointwise-capacity-20261108';OUT=ROOT/'benchmarks/results'/NAME;ADD=OUT/'occupancy-scope'
load=lambda p:json.loads(p.read_bytes());digest=lambda b:sha256(b).hexdigest()
def write(p,v,mode='x'):
    with p.open(mode,encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'checks.json')['passed'];process=load(PROCESS/'process.json');assert process['closed'] and process['passed'] and process['job']['active_processes']==0
ADD.mkdir();inputs={}
for folder in [BASE,PROCESS]:
    for p in folder.rglob('*'):
        if p.is_file():inputs[p.relative_to(ROOT).as_posix()]=p
for p in [Path(__file__),ROOT/'output/audit_h5_fixed29_reserved_hole_scope_20261108.py',ROOT/'output/run_h5_fixed29_reserved_hole_scope_stage_20261108.py']:inputs[p.relative_to(ROOT).as_posix()]=p
for name,h in load(BASE/'plan.json')['inputs'].items():
    p=ROOT/name;assert digest(p.read_bytes())==h;inputs[name]=p
rows=[]
with zipfile.ZipFile(ADD/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(inputs.items()):
        data=p.read_bytes();rows.append({'path':name,'bytes':len(data),'sha256':digest(data)});z.writestr(name,data)
write(ADD/'manifest.json',{'archive':'raw.zip','archive_bytes':(ADD/'raw.zip').stat().st_size,'archive_sha256':digest((ADD/'raw.zip').read_bytes()),'files':rows})
with zipfile.ZipFile(ADD/'raw.zip') as z:
    assert z.testzip() is None and sorted(z.namelist())==sorted(inputs)
    for r in rows:
        data=z.read(r['path']);assert len(data)==r['bytes'] and digest(data)==r['sha256']==digest((ROOT/r['path']).read_bytes())
for name in ['plan.json','checks.json','source-occupancy-areas.json']:shutil.copyfile(BASE/name,ADD/name)
shutil.copyfile(PROCESS/'process.json',ADD/'process.json')
total=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds'];write(ADD/'archive-checks.json',{'passed':True,'members_verified':len(rows),'original_source_bindings_verified':len(load(BASE/'plan.json')['inputs']),'source_holes_preserved':90,'reserved_hole_scope_verified':True,'ordinary_part_in_hole_exclusions':0,'complete_preparation_seconds_if_consumed':total,'H5_complete':False})
checks=load(OUT/'checks.json');checks.update(common_line_hole_reservation_required=True,capacity_is_reserved_outer_envelope=True,rectangles_inside_net_material_claimed=False,ordinary_part_in_hole_exclusions=0,complete_preparation_seconds_if_consumed=total,all11_processes_closed=True);checks.pop('all10_processes_closed');write(OUT/'checks.json',checks,'w')
nextstep=load(OUT/'next-step.json');nextstep.update(common_line_hole_reservation_required=True,capacity_is_reserved_outer_envelope=True,consumed_preparation_seconds=total,occupancy_scope='The original outer rings, including reserved holes, are the occupied envelopes for common-line mode. Inner rectangle and source-area language in earlier raw scripts refers to these envelopes, not net material. No ordinary part-in-hole exclusion.');write(OUT/'next-step.json',nextstep,'w')
table=load(OUT/'process-summary.json');table.append({'stage':'fixed29-reserved-hole-scope','seconds':process['complete_seconds'],'cap_seconds':10,'passed':True,'closed':True,'active_processes':0});write(OUT/'process-summary.json',table,'w')
p=OUT.with_suffix('.md');s=p.read_text(encoding='utf-8');s=s.replace('## Current domains and exact area controls','''## Occupied envelope and mode scope

These bounds use **original outer envelopes with holes reserved**, as required
by common-line mode. The originals retain all90 holes in their cutting geometry;
the occupied envelopes reserve those holes during nesting. A bracket occupies
40,000mm² and an insert19,800mm² by this convention. Their net material areas
are smaller and are not the capacity quantities used here.

[The explicit scope audit](h5-fixed29-pointwise-capacity-20261108/occupancy-scope/checks.json)
binds the job, production search policy, export rejection, existing rejection
test and original-source filled-outer readback. The source convex partitions,
inner rectangles, collision obstacles and area lower bounds are statements
about these occupied envelopes. They are not claims that reserved cutouts
contain physical material. **No ordinary nesting configuration with parts
inside holes is excluded by this proof.** The arithmetic and common-line
exclusion remain valid under the original hole-reservation requirement.
[Separate source/net areas](h5-fixed29-pointwise-capacity-20261108/occupancy-scope/source-occupancy-areas.json),
[bounded process](h5-fixed29-pointwise-capacity-20261108/occupancy-scope/process.json)
and [archive readback](h5-fixed29-pointwise-capacity-20261108/occupancy-scope/archive-checks.json)
preserve this clarification without changing the earlier raw evidence.

## Current domains and exact area controls''')
s=s.replace('combined moving material','combined moving occupied envelopes').replace('source pieces in bands','outer-envelope pieces in bands').replace('actual fixed-source point','point in an occupied fixed envelope').replace('## Closed processes and remaining work','## Closed processes and remaining work').replace('[All ten processes close]','[All eleven processes close]').replace('**154.076606 s**',f'**{total:.6f} s**').replace('preparations remain charged.','preparations and the complete scope audit remain charged.').replace('all90 holes','all 90 holes').replace('40,000mm² and an insert19,800mm²','40,000 mm² and an insert 19,800 mm²')
s=s.replace('| fixed29-clearance-domains-audit | 41.276618 | 60 | Pass |',f'| fixed29-clearance-domains-audit | 41.276618 | 60 | Pass |\n| fixed29-reserved-hole-scope | {process["complete_seconds"]:.6f} | 10 | Pass |')
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
entry=f'**2026-11-08 H5 occupied-envelope scope clarification:** [explicit original/source-policy audit]({{link}}) confirms the fixed29 capacity proofs apply to common-line mode with holes reserved. All 90 original holes remain in the cutting geometry. The occupied outer-envelope areas, not net material areas, support the lower bounds and inner-rectangle collision proofs. No ordinary part-in-hole layout is excluded. The [10,11,12] common-line exclusion and three remaining exact choices stand. The complete {process["complete_seconds"]:.6f} s scope process is also charged, bringing consumed preparation to {total:.6f} s. All eleven processes close; no optimizer or timer reset is permitted. H2/H5 remain open at 60%.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'/occupancy-scope/checks.json'
    with (ROOT/name).open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a);intro=s[a:b].replace('Complete source covers exclude','Common-line source covers with holes reserved exclude').replace('actual cog material','occupied cog envelopes').replace('All ten processes close;','All eleven processes close;').replace('is 154.076606 s;',f'is {total:.6f} s;');intro+='The occupied envelopes reserve all original holes; no ordinary part-in-hole\nlayout is excluded by these capacity proofs.\n';s=s[:a]+intro+s[b:]
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
print({'passed':True,'scope_members_verified':len(rows),'consumed_preparation_seconds':total,'ordinary_part_in_hole_exclusions':0,'common_line_exclusion_preserved':True})
