"""Reconstruct every observer file and retain all original native witnesses."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,re,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-joint-observer-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');parent=Path(plan['old_source']);fresh=out/'reconstruction/workspace'
assert load(out/'build.json')['all_passed'];shutil.copytree(parent,fresh)
rel=plan['changed_file'];original=(parent/rel).read_text(encoding='utf-8');text=original
changes=load(out/'substitutions.json')
for before,after in changes:
    assert text.count(before)==1;text=text.replace(before,after)
reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
assert text.split('#[cfg(test)]\nmod tests {',1)[1]==original.split('#[cfg(test)]\nmod tests {',1)[1]
for expression in [r'self\.clock\.now\s*\(',r'self\.rng\.',r'\.charge\s*\(',r'self\.clock\.validated\s*\(']:
    assert len(re.findall(expression,text))==len(re.findall(expression,original)),expression
(fresh/rel).write_text(text,encoding='utf-8',newline='\n')
example='crates/core/examples/exchange_probe.rs';before,after=load(out/'example-comment.json')
assert (fresh/example).read_text(encoding='utf-8')==before
(fresh/example).write_text(after,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
records=[]
for row in plan['source_files']:
    rel=row['path'];assert digest(parent/rel)==row['sha256']
    assert (fresh/rel).read_bytes()==(out/'workspace'/rel).read_bytes(),rel
    if rel not in plan['changed_files']:assert digest(fresh/rel)==row['sha256']
    records.append({'path':rel,'sha256':digest(fresh/rel)})
log=(out/'core-tests.log').read_text(encoding='utf-8')
old_log=(parent.parent/'core-tests.log').read_text(encoding='utf-8')
assert '165 passed; 0 failed' in log
markers=['EXTENDED_REPAIR_WITNESS ','CHAIN_WITNESS ','PROFILE_REJECT_WITNESS ',
    'CONTINUOUS_REPAIR_WITNESS ','LARGER_RETURN_WITNESS ','MIXED_WITNESS ',
    'BRIDGE_STEP_WITNESS ','BRIDGE_MANUAL_WITNESS ','BRIDGE_RESULT_WITNESS ',
    'JOINT_REPAIR_SOURCE_WITNESS ','JOINT_REPAIR_WITNESS ','JOINT_PAIR_WITNESS ','JOINT_POLICY_WITNESS ']
retained=[]
for marker in markers:
    def capture(s):return Counter(json.dumps(json.loads(line.split(marker,1)[1]),sort_keys=True) for line in s.splitlines() if marker in line)
    old,new=capture(old_log),capture(log);assert old and old==new,marker
    retained.append({'marker':marker,'outcomes_exact':sum(old.values())})
target=Path(plan['target']);binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'))
assert len(binaries)==1;shutil.copyfile(binaries[0],out/'authored-tests.exe')
result={'exact_parent_reversal':True,'all_formatted_files_exact':True,'files':records,
    'unchanged_other_files':len(records)-2,'all_165_original_tests_unchanged':True,
    'all_old_native_witnesses_exact':retained,'test_log_sha256':digest(out/'core-tests.log'),
    'test_binary_sha256':digest(out/'authored-tests.exe'),'no_added_search_clock_rng_or_work_calls':True,
    'added_tests':0,'new_development_searches':0}
(out/'reconstruction.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check-source.py')
print(json.dumps({'source_files_exact':len(records),'other_files_unchanged':len(records)-2,'native_witnesses_exact':sum(x['outcomes_exact'] for x in retained)}))
