"""Fixed-work parity with saved unobserved outcomes; no quality measurement."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess,sys,traceback
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-observer-20261018'
parent=root/'output/h5-joint-repair-probe-20261018/public-checks'
out=probe/'public-checks';out.mkdir()
sys.path.insert(0,str(root/'scripts'));import h5_joint_trace as reader
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def deterministic(value):
    value=copy.deepcopy(value);value.pop('elapsed_seconds');return value
assert load(probe/'build.json')['all_passed']
for name in ['library.json','normal.json','common.json']:shutil.copyfile(parent/name,out/name)
cli=parent/'nestbolt-validator.exe';binary=probe/'exchange-diagnosis.exe';rows=[]
write(out/'plan.json',{'scope':__doc__,'work_seconds':20,'seeds':[0,1],'modes':['normal','common'],
    'binary_sha256':digest(binary),'CLI_sha256':digest(cli),'development_measurement':False})
try:
    for mode in ['normal','common']:
        for seed in [0,1]:
            label=f'candidate-{mode}-{seed}';folder=out/label
            command=[str(binary),str(out/'library.json'),str(out/(mode+'.json')),str(folder),'20',str(seed),'work']
            r=subprocess.run(command,capture_output=True,timeout=90)
            (out/(label+'-stdout.log')).write_bytes(r.stdout);(out/(label+'-stderr.log')).write_bytes(r.stderr)
            write(out/(label+'-command.json'),{'command':command,'exit_code':r.returncode})
            assert r.returncode==0,label
            current=load(folder/'search.json');saved=load(parent/label/'search.json')
            assert deterministic(current)==deterministic(saved),label
            assert load(folder/'cutting-report.json')==load(parent/label/'cutting-report.json')
            traces=reader.parse_log(r.stderr.decode());checks=reader.check_traces(traces,current['stats'])
            if mode=='normal':assert not traces
            else:assert traces and current['riders']==0
            cmd=[str(cli),'validate','--library',str(out/'library.json'),'--request',str(out/(mode+'.json')),'--layout',str(folder/'layout.json')]
            checked=subprocess.run(cmd,capture_output=True,timeout=90)
            (out/(label+'-validate.json')).write_bytes(checked.stdout);(out/(label+'-validate.stderr')).write_bytes(checked.stderr)
            write(out/(label+'-validate-command.json'),{'command':cmd,'exit_code':checked.returncode})
            report=json.loads(checked.stdout);assert checked.returncode==0 and report['valid']
            assert report['metrics']==current['validation']['metrics']
            rows.append({'mode':mode,'seed':seed,'exact_parent_result_except_elapsed':True,'trace_checks':checks,
                'layout_sha256':digest(folder/'layout.json'),'parent_layout_sha256':digest(parent/label/'layout.json')})
            write(out/'progress.json',rows)
    write(out/'checks.json',{'all_checks_pass':True,'public_fixed_work_outcomes':4,'public_CLI_validations':4,
        'original_results_exact_except_elapsed':True,'trace_counters_match':True,'records':rows,'quality_claim':False})
    shutil.copyfile(__file__,out/'check.py');print(json.dumps({'fixed_work_outcomes':4,'CLI_validations':4,'exact_parent_results':True}))
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'records':rows});raise
