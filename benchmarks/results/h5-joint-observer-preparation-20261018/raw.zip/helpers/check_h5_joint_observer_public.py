"""Fixed-work parity with saved unobserved outcomes; no quality measurement."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess,sys,traceback
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-observer-20261018'
parent=root/'output/h5-joint-repair-probe-20261018/public-checks'
out=probe/'public-checks';out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'scripts'));import h5_joint_trace as reader
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def deterministic(value):
    value=copy.deepcopy(value);value.pop('elapsed_seconds');return value
assert load(probe/'build.json')['all_passed']
for name in ['library.json','normal.json','common.json']:shutil.copyfile(parent/name,out/name)
cli=parent/'nestbolt-validator.exe';binary=probe/'exchange-diagnosis.exe';rows=[]
write(out/'plan.json',{'scope':__doc__,'work_seconds':20,'seeds':[0,1],'modes':['normal','common'],
    'binary_sha256':digest(binary),'CLI_sha256':digest(cli),'development_measurement':False})
try:
    for mode in ['normal','common']:
        for seed in [0,1]:
            label=f'candidate-{mode}-{seed}';folder=out/label
            command=[str(binary),str(out/'library.json'),str(out/(mode+'.json')),str(folder),'20',str(seed),'work']
            cached=out/(label+'-command.json')
            if cached.exists():
                prior=load(cached);assert prior=={'command':command,'exit_code':0}
                assert digest(binary)==load(out/'plan.json')['binary_sha256']
                r=subprocess.CompletedProcess(command,0,(out/(label+'-stdout.log')).read_bytes(),(out/(label+'-stderr.log')).read_bytes())
            else:
                r=subprocess.run(command,capture_output=True,timeout=90)
                (out/(label+'-stdout.log')).write_bytes(r.stdout);(out/(label+'-stderr.log')).write_bytes(r.stderr)
                write(cached,{'command':command,'exit_code':r.returncode})
            assert r.returncode==0,label
            reference=parent/f'candidate-{mode}-s{seed}'
            current=load(folder/'search.json');saved=load(reference/'search.json')
            assert deterministic(current)==deterministic(saved),label
            assert load(folder/'cutting-report.json')==load(reference/'cutting-report.json')
            traces=reader.parse_log(r.stderr.decode());checks=reader.check_traces(traces,current['stats'])
            if mode=='normal':assert not traces
            else:assert traces and current['riders']==0
            cmd=[str(cli),'validate','--library',str(out/'library.json'),'--request',str(out/(mode+'.json')),'--layout',str(folder/'layout.json')]
            checked=subprocess.run(cmd,capture_output=True,timeout=90)
            (out/(label+'-validate.json')).write_bytes(checked.stdout);(out/(label+'-validate.stderr')).write_bytes(checked.stderr)
            write(out/(label+'-validate-command.json'),{'command':cmd,'exit_code':checked.returncode})
            report=json.loads(checked.stdout);assert checked.returncode==0 and report['valid']
            assert report['metrics']==current['validation']['metrics']
            rows.append({'mode':mode,'seed':seed,'exact_parent_result_except_elapsed':True,'trace_checks':checks,
                'layout_sha256':digest(folder/'layout.json'),'parent_layout_sha256':digest(reference/'layout.json')})
            write(out/'progress.json',rows)
    write(out/'checks.json',{'all_checks_pass':True,'public_fixed_work_outcomes':4,'public_CLI_validations':4,
        'original_results_exact_except_elapsed':True,'trace_counters_match':True,'records':rows,'quality_claim':False,
        'first_reference_path_failure_preserved':True,'first_completed_outcome_reused_without_rerun':True})
    shutil.copyfile(__file__,out/'check.py');print(json.dumps({'fixed_work_outcomes':4,'CLI_validations':4,'exact_parent_results':True}))
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'records':rows});raise
