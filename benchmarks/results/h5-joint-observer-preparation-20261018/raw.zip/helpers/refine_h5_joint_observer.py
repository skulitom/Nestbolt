from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1];out=root/'output/h5-joint-observer-20261018'
path=out/'workspace/crates/core/src/sheets/vstrip/exchange.rs'
s=path.read_text(encoding='utf-8');changes=json.loads((out/'substitutions.json').read_bytes())
edits=[
('        let (snapshot, tracker) = repair.separate(&self.deadline(self.last_step(until)));',
 '        let diag_separator_started = Instant::now();\n        let (snapshot, tracker) = repair.separate(&self.deadline(self.last_step(until)));\n        let diag_separator_seconds = diag_separator_started.elapsed().as_secs_f64();'),
('diag.event("separator_exit",serde_json::json!({"loss":tracker.total_loss(),',
 'diag.event("separator_exit",serde_json::json!({"loss":tracker.total_loss(),"separator_seconds":diag_separator_seconds,'),
('        let mut source = source;\n        let mut keys:',
 '        let diag_lowering_started = Instant::now();\n        let mut source = source;\n        let mut keys:'),
('        source.rebuild();\n        diag.event("lowering_exit",serde_json::json!({"loss":source.tracker.total_loss(),',
 '        source.rebuild();\n        let diag_lowering_seconds = diag_lowering_started.elapsed().as_secs_f64();\n        diag.event("lowering_exit",serde_json::json!({"loss":source.tracker.total_loss(),"lowering_seconds":diag_lowering_seconds,')]
for before,after in edits:
    assert s.count(before)==1;s=s.replace(before,after);changes.append([before,after])
path.write_text(s,encoding='utf-8',newline='\n')
(out/'substitutions.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'refine.py')
print('Recorded direct elapsed timers around separation and source lowering; no search-clock reads added.')
