"""Reuse the serial diagnostic execution method with the qualified joint reader."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-observer-20261018'
reference=root/'scripts/h5_boundary_pair_observer.py'
s=reference.read_text(encoding='utf-8')
s=s.replace('h5_boundary_pair_pilot','h5_joint_repair_pilot')
s=s.replace('h5-boundary-pair-pilot','h5-joint-repair-pilot')
s=s.replace('h5-boundary-pair-observer','h5-joint-observer')
s=s.replace('h5_boundary_pair_observer','h5_joint_observer')
end=s.index('"""',3)+3
s='''"""Trace actual joint repairs in the failed mechanical development jobs.

Four diagnostic-only searches: large plates and panel hardware, both kerfs,
seed 0, 60 seconds each, serial physical CCD0 CPU 8. Original decisions,
inputs, deadlines and work charges remain. Logging may change wall trajectories;
these runs cannot support a quality or speed comparison or integration.
"""'''+s[end:]
s=s.replace("JOBS = ['m-mechanical-panel-hardware']", "JOBS = ['m-mechanical-large-plates','m-mechanical-panel-hardware']")
s=s.replace("ROOT/'scripts/h5_frontier_observer.py',", "ROOT/'scripts/h5_joint_trace.py',")
s=s.replace("PROBE/'authored-trace-reader/checks.json'", "PROBE/'reader-checks/checks.json'")
s=s.replace("PROBE/'reconstruction.json',", "PROBE/'reconstruction.json', PROBE/'geometry-checks/checks.json', PROBE/'public-checks/checks.json',")
s=s.replace("'attempts':2", "'attempts':4")
s=s.replace("'source_change':'Record the validated public baseline/job, credited and source sheet, original part names and exact public source poses for every choice, visited choices and actual attempted members with terminal outcome. All inserted observations reverse exactly; no decision or work charge changes.'",
    "'source_change':'Record nested chains, policies, initial proposals, repaired pair poses, extra net member migration, actual whole-job trials, repair/lowering elapsed durations, outcomes, acceptance and rollback. Original decisions and work charges remain; all instrumentation reverses exactly.'")
s=s.replace("'interpretation':'Diagnostic only; trace overhead can alter wall-clock outcomes. No quality comparison, no retry of the rejected paired pilot.'",
    "'interpretation':'Diagnostic only; trace overhead can alter wall-clock outcomes. Phase durations are observed elapsed time, not a controlled performance comparison. Pair identities are original part-type multisets and physical poses; same-family copy swaps can cancel in net migration counts. No retry of the rejected matched pilot.'")
a=s.index('def pose_key(');b=s.index('def run(out):',a)
s=s[:a]+'''def read_trace(archive,record):
    import h5_joint_trace as reader
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        traces=reader.parse_log(z.read('search-stderr.log').decode('utf-8'))
    assert traces,'No joint-chain observation'
    return reader.check_traces(traces,record.get('stats') if record['status']=='valid' else None)


'''+s[b:]
s=s.replace("len(records)==2", "len(records)==4")
s=s.replace("'outcomes':record.get('diagnosis',{}).get('outcomes')", "'outcomes':record.get('diagnosis',{}).get('attempt_outcomes')")
path=root/'scripts/h5_joint_observer.py';assert not path.exists();compile(s,str(path),'exec')
path.write_text(s,encoding='utf-8',newline='\n')
def fn(text,name):return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
old=reference.read_text(encoding='utf-8')
expected=old.replace("len(records)==2", "len(records)==4").replace("'outcomes':record.get('diagnosis',{}).get('outcomes')", "'outcomes':record.get('diagnosis',{}).get('attempt_outcomes')")
assert ast.dump(fn(s,'run'))==ast.dump(fn(expected,'run'))
record={'reference':reference.relative_to(root).as_posix(),'reference_sha256':sha256(reference.read_bytes()).hexdigest(),
    'run_AST_exact_except_four_case_completion_and_progress_field':True,
    'per_case_measurement_validation_export_archive_reused_unchanged':'scripts/h5_joint_repair_pilot.py:case',
    'runner_sha256':sha256(path.read_bytes()).hexdigest(),'new_searches':0}
(probe/'runner-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
