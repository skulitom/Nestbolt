"""Instrument the rejected joint policy without changing decisions or charged work."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1]
out=root/'output/h5-joint-observer-20261018'
old=root/'output/h5-joint-repair-probe-20261018/candidate'
work=out/'workspace'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
pilot=root/'benchmarks/results/h5-joint-repair-pilot-20261018'
assert load(pilot/'verification.json')['valid']==72
assert load(pilot/'source-review.json')['pilot_material_failures']==5
out.mkdir();shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs'
original=(old/rel).read_text(encoding='utf-8');text=original;changes=[]
def change(before,after):
    global text
    assert text.count(before)==1,(before[:100],text.count(before))
    text=text.replace(before,after);changes.append([before,after])
def region(start,end,edit):
    a=text.index(start);b=text.index(end,a)
    before=text[a:b];after=edit(before)
    change(before,after)
def insert(s,needle,extra,after=True):
    assert s.count(needle)==1,(needle[:90],s.count(needle))
    return s.replace(needle,needle+extra if after else extra+needle)
helper=r'''
// Diagnostic-only observer: pure serialization and Instant reads. No search
// clock reads, work charges, RNG calls, geometry changes or decision changes.
thread_local! {
    static JOINT_DIAG_PARENT: std::cell::Cell<Option<u64>> = const { std::cell::Cell::new(None) };
}
static JOINT_DIAG_ID: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
struct JointDiag {
    id: u64,
    parent: Option<u64>,
    kind: &'static str,
    started: Instant,
    data: serde_json::Value,
    events: Vec<serde_json::Value>,
    outcome: &'static str,
}
impl JointDiag {
    fn new(kind: &'static str, data: serde_json::Value) -> Self {
        let id = JOINT_DIAG_ID.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let parent = JOINT_DIAG_PARENT.with(|p| p.replace(Some(id)));
        Self { id, parent, kind, started: Instant::now(), data, events: vec![], outcome: "unresolved" }
    }
    fn event(&mut self, stage: &'static str, data: serde_json::Value) {
        self.events.push(serde_json::json!({"stage":stage,"elapsed_seconds":self.started.elapsed().as_secs_f64(),"data":data}));
    }
}
impl Drop for JointDiag {
    fn drop(&mut self) {
        JOINT_DIAG_PARENT.with(|p| p.set(self.parent));
        eprintln!("JOINT_DIAG {}",serde_json::json!({"id":self.id,"parent":self.parent,"kind":self.kind,
            "elapsed_seconds":self.started.elapsed().as_secs_f64(),"data":self.data,"events":self.events,"outcome":self.outcome}));
    }
}
fn joint_diag_event(trace: &mut Option<JointDiag>, stage: &'static str, data: serde_json::Value) {
    if let Some(trace) = trace { trace.event(stage,data); }
}
fn joint_diag_end(trace: &mut Option<JointDiag>, outcome: &'static str) {
    if let Some(trace) = trace { trace.outcome=outcome; }
}
fn joint_diag_single(strip: &Strip, layout: &JLayout) -> serde_json::Value {
    serde_json::json!(layout.placed_items().values().map(|p| {
        let item=p.item().idx();
        serde_json::json!({"part_id":strip.model.job.parts[strip.model.part[item]].id,
            "transform":strip.model.external(item,&p.d_transf())})
    }).collect::<Vec<_>>())
}
fn joint_diag_window(strip: &Strip, layout: &JLayout) -> serde_json::Value {
    serde_json::json!(layout.placed_items().values().filter(|p| !strip.is_blocker(p)).map(|p| {
        let item=p.item().idx();let sheet=strip.sheet_of(p.shape());
        serde_json::json!({"part_id":strip.model.job.parts[strip.model.part[item]].id,"active_sheet":sheet,
            "transform":strip.model.external(item,&shift(p.d_transf(),-strip.start(sheet)))})
    }).collect::<Vec<_>>())
}
'''
change('use material_profile::material_profile;','use material_profile::material_profile;\n'+helper)
def pair(s):
    needle='    ) -> Result<Option<[LayoutSnapshot; 2]>> {\n'
    s=insert(s,needle,'''        let mut diag = JointDiag::new("pair",serde_json::json!({
            "job":self.model.job,"source_crop_internal":last,"absolute_until":until,
            "proposed":[joint_diag_single(strip,&receiver),joint_diag_single(strip,&source)]}));
''')
    s=insert(s,'        if !self.allow_exchange || self.clock.now() >= self.last_step(until) {\n','            diag.outcome="not_started";\n')
    s=insert(s,'        self.stats.joint_repair_attempts += 1;\n','        diag.event("attempted",serde_json::json!({"counter":self.stats.joint_repair_attempts}));\n')
    s=insert(s,'        let (snapshot, tracker) = repair.separate(&self.deadline(self.last_step(until)));\n',
        '''        diag.event("separator_exit",serde_json::json!({"loss":tracker.total_loss(),
            "window":joint_diag_window(strip,&JLayout::from_snapshot(&snapshot))}));
''')
    # The original branch tests remain verbatim; observations run inside them.
    before='            self.stats.joint_repair_expired += 1;\n'
    assert s.count(before)==3
    for outcome in ['separator_expired','recrop_expired','lowering_expired']:
        idx=s.index(before);s=s[:idx]+s[idx:].replace(before,before+f'            diag.outcome="{outcome}";\n',1)
        # Avoid selecting the same branch again.
        s=s[:idx]+s[idx:].replace(before,'            self.stats.joint_repair_expired += 1; /* observed */\n',1)
    s=s.replace(' /* observed */','')
    before='            self.stats.joint_repair_failed += 1;\n'
    # The out-of-pair branch has deeper indentation and is handled separately.
    for needle,outcome in [
        ('        if tracker.total_loss() > 0.0 {\n','separator_failed'),
        ('            if index >= 2 {\n','outside_pair'),
        ('        if receiver.tracker.total_loss() > 0.0 || source.tracker.total_loss() > 0.0 {\n','recrop_failed'),
        ('        if source.tracker.total_loss() > 0.0 {\n','lowering_failed')]:
        indent='                ' if outcome=='outside_pair' else '            '
        s=insert(s,needle,indent+f'diag.outcome="{outcome}";\n')
    s=insert(s,'        let source = Separator::new(source, 0, EXPLORE, self.clock.clone());\n',
        '''        diag.event("recrop_exit",serde_json::json!({"losses":[receiver.tracker.total_loss(),source.tracker.total_loss()],
            "pair":[joint_diag_single(strip,&receiver.layout),joint_diag_single(strip,&source.layout)]}));
''')
    s=insert(s,'        source.rebuild();\n',
        '''        diag.event("lowering_exit",serde_json::json!({"loss":source.tracker.total_loss(),
            "pair":[joint_diag_single(strip,&receiver.layout),joint_diag_single(strip,&source.layout)]}));
''')
    s=insert(s,'        self.stats.joint_repair_completed += 1;\n','        diag.outcome="completed";\n')
    return s
region('    fn joint_repair_pair(', '    #[cfg(test)]\n    pub(super) fn assignment_bridge_window',pair)
def chain(s):
    s=insert(s,'        let (accepted, policy) = phase;\n',
        '''        let mut diag = (policy==ExchangePolicy::JointRepair).then(||JointDiag::new("chain",serde_json::json!({
            "accepted_short_steps":accepted,"stats":self.stats,"window":joint_diag_window(strip,&sep.layout)})));
''')
    s=insert(s,'        {\n            return Ok(0);\n', '            joint_diag_end(&mut diag,"not_started");\n',after=False) if False else s
    needle='        {\n            return Ok(0);\n'
    assert s.count(needle)==1;s=s.replace(needle,'        {\n            joint_diag_end(&mut diag,"not_started");\n            return Ok(0);\n')
    s=insert(s,'                self.stats.assignment_bridge_flat_steps += u64::from(!improved);\n',
        '                joint_diag_event(&mut diag,"step",serde_json::json!({"improved":improved,"pending":pending,"stats":self.stats}));\n')
    s=insert(s,'                    pending = 0;\n',
        '                    joint_diag_event(&mut diag,"committed",serde_json::json!({"committed":committed,"stats":self.stats}));\n')
    s=insert(s,'            ] = checkpoint.2;\n',
        '            joint_diag_event(&mut diag,"rollback",serde_json::json!({"pending":pending,"stats":self.stats,"window":joint_diag_window(strip,&sep.layout)}));\n')
    s=insert(s,'        outcome?;\n',
        '''        joint_diag_event(&mut diag,"finished",serde_json::json!({"committed":committed,"stats":self.stats,
            "window":joint_diag_window(strip,&sep.layout)}));
        joint_diag_end(&mut diag,"completed");
''')
    return s
region('    fn provisional_exchange_chain(', '    #[cfg(test)]\n    pub(super) fn directed_exchange_window',chain)
def policy(s):
    s=insert(s,'        let before = baseline.metrics.as_ref().expect("valid baseline");\n',
        '''        let mut diag_policy = joint.then(||JointDiag::new("policy",serde_json::json!({"job":self.model.job,
            "baseline":baseline_layout,"metrics":before,"frozen_count":frozen.len(),"active_sheets":shape.sheets})));
''')
    needle='                    let repaired = if joint {\n'
    s=insert(s,needle,'''                    let mut diag_attempt = joint.then(||JointDiag::new("attempt",serde_json::json!({
                        "receiver_active_sheet":target,"source_active_sheet":last_index,
                        "paired":paired,"mixed":mixed,"absolute_until":exchange_until,
                        "incoming":members.iter().map(|(_,item,pose)|serde_json::json!({
                            "part_id":self.model.job.parts[self.model.part[item.idx()]].id,
                            "transform":self.model.external(item.idx(),pose)})).collect::<Vec<_>>(),
                        "victims":victims.iter().map(|(_,item,pose)|serde_json::json!({
                            "part_id":self.model.job.parts[self.model.part[item.idx()]].id,
                            "transform":self.model.external(item.idx(),pose)})).collect::<Vec<_>>() })));
''',after=False)
    s=insert(s,'                    let Some([receiver_snapshot, source_snapshot]) = repaired else {\n',
        '                        joint_diag_end(&mut diag_attempt,"pair_unavailable");\n')
    s=insert(s,'                    if exact_physical_state(&sep.layout, &trial) {\n',
        '                        joint_diag_end(&mut diag_attempt,"exact_state");\n')
    needle='                            self.stats.material_profile_exchange_rejections += 1;\n'
    s=insert(s,needle,'                            joint_diag_end(&mut diag_attempt,"same_material_profile");\n')
    s=insert(s,'                    let report = self.exchange_report(&trial_layout)?;\n',
        '                    joint_diag_event(&mut diag_attempt,"validated_trial",serde_json::json!({"layout":trial_layout,"report":report}));\n')
    s=insert(s,'                    if !report.valid {\n','                        joint_diag_end(&mut diag_attempt,"invalid_trial");\n')
    needle='                    if exchange_increases_material(before, after)\n                        || self.clock.now() >= exchange_until\n                    {\n'
    s=insert(s,needle,'                        joint_diag_end(&mut diag_attempt,"material_guard_or_expiry");\n')
    s=insert(s,'                        if !area_improved {\n','                            joint_diag_end(&mut diag_attempt,"flat_area_guard");\n')
    s=insert(s,'                    if bridge && self.clock.now() >= exchange_until {\n','                        joint_diag_end(&mut diag_attempt,"acceptance_expired");\n')
    needle='                    if same_original_inventory(&members, &victims)\n                        && after.material_area >= before.material_area\n                    {\n'
    s=insert(s,needle,'                        joint_diag_end(&mut diag_attempt,"flat_same_inventory");\n')
    s=insert(s,'                    self.stats.mixed_exchanges += u64::from(mixed);\n',
        '''                    joint_diag_event(&mut diag_attempt,"accepted_step",serde_json::json!({"before":before,"after":after,"stats":self.stats}));
                    joint_diag_end(&mut diag_attempt,"accepted");
                    joint_diag_end(&mut diag_policy,"accepted");
''')
    needle='        Ok(None)\n    }\n}\n\n'
    s=insert(s,needle,'        joint_diag_end(&mut diag_policy,"exhausted");\n',after=False)
    return s
region('    fn directed_exchange_policy(', '#[cfg(test)]\nmod tests {',policy)
reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
assert text.split('#[cfg(test)]\nmod tests {',1)[1]==original.split('#[cfg(test)]\nmod tests {',1)[1]
(work/rel).write_text(text,encoding='utf-8',newline='\n')
example='crates/core/examples/exchange_probe.rs'
ex=(old/example).read_text(encoding='utf-8')
newex=ex.replace('//! Counters are written after search; no timed logging or hidden budget changes.',
    '//! Diagnostic library records timed observations; decision logic and budgets are unchanged.')
assert newex!=ex;(work/example).write_text(newex,encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_source':str(old),
    'source_files':[{'path':p.relative_to(old).as_posix(),'sha256':digest(p)} for p in sorted(old.rglob('*')) if p.is_file()],
    'changed_file':rel,'changed_files':[rel,example],'production_digest':source_digest(),
    'target':str(root/'output/h5-joint-observer-target-20261018'),
    'all_165_prior_tests_unchanged':True,'exact_preformat_reversal':True,
    'decisions_budgets_work_charges_unchanged':True,'no_added_search_clock_reads':True,
    'trace_overhead_can_change_wall_trajectory':True,'measured_search_started':False}
for name,value in [('preparation.json',plan),('substitutions.json',changes),('example-comment.json',[ex,newex])]:
    (out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='joint/'+rel,tofile='joint-observer/'+rel)),encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
build=(root/'output/build_h5_boundary_pair_observer.py').read_text(encoding='utf-8').replace('h5-boundary-pair-observer','h5-joint-observer')
build=build.replace("'--target-dir',TARGET])", "'--target-dir',TARGET,'--','--nocapture','--test-threads=1'])",1)
(root/'output/build_h5_joint_observer.py').write_text(build,encoding='utf-8',newline='\n')
print(json.dumps({'isolated_observer_prepared':True,'unchanged_tests':165,'source_files':len(plan['source_files']),'new_searches':0}))
