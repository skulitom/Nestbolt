"""Seal diagnostic qualification before any mechanical observation run."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-observer-20261018'
out=root/'benchmarks/results/h5-joint-observer-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
reader=load(probe/'reader-checks/checks.json');geometry=load(probe/'geometry-checks/checks.json');public=load(probe/'public-checks/checks.json')
assert build['all_passed'] and source['all_formatted_files_exact'] and len(source['files'])==157
assert source['unchanged_other_files']==155 and source['all_165_original_tests_unchanged']
assert source_digest()==plan['production_digest']
assert reader['all_checks_pass'] and len(reader['malformed_traces_rejected'])==9
assert reader['reader_sha256']==digest(root/'scripts/h5_joint_trace.py')
assert geometry['all_checks_passed'] and geometry['CLI_checks']==23
assert public['all_checks_pass'] and public['public_fixed_work_outcomes']==4
assert digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
recovery=load(probe/'public-checks/recovery.json')
for name,expected in recovery['existing_files'].items():assert digest(probe/'public-checks'/name)==expected,name
assert digest(probe/'public-checks/first-failure.json')==recovery['original_failure_sha256']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
parent=Path(plan['old_source']);patch=''
for rel in plan['changed_files']:
    before=(parent/rel).read_text(encoding='utf-8');after=(probe/'workspace'/rel).read_text(encoding='utf-8')
    patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='rejected/'+rel,tofile='observer/'+rel))
(probe/'observer-final.patch').write_text(patch,encoding='utf-8',newline='\n')
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_joint_observer.py','refine_h5_joint_observer.py','build_h5_joint_observer.py',
    'check_h5_joint_observer_source.py','check_h5_joint_observer_reader.py','check_h5_joint_observer_geometry.py',
    'check_h5_joint_observer_public.py','prepare_h5_joint_observer_runner.py','seal_h5_joint_observer.py']:
    files['helpers/'+name]=root/'output'/name
for name in ['h5_joint_trace.py','h5_joint_observer.py']:files['scripts/'+name]=root/'scripts'/name
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in files.items():z.write(path,name)
with zipfile.ZipFile(out/'raw.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'all_members_and_crc_verified':True,'archive':'raw.zip','bytes':(out/'raw.zip').stat().st_size,
    'sha256':digest(out/'raw.zip'),'members':inventory})
checks={'all_qualified':True,'optimized_core_tests_passed':165,'all_prior_tests_unchanged':True,
    'old_native_witnesses_exact':sum(x['outcomes_exact'] for x in source['all_old_native_witnesses_exact']),
    'native_trace_records':reader['trace_count'],'malformed_trace_checks':9,'native_CLI_checks':geometry['CLI_checks'],
    'native_filled_outer_pairs':geometry['filled_outer_pairs'],'public_fixed_work_checks':4,'public_CLI_checks':4,
    'fixed_work_results_exact_except_elapsed':True,'source_files_reconstructed':157,'unrelated_files_unchanged':155,
    'strict_lint_and_build_passed':True,'production_unchanged':True,'new_search_clock_rng_or_work_calls':False,
    'initial_public_reference_path_failure_preserved':True,'completed_outcome_reused_without_rerun':True,
    'development_measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','reconstruction.json','runner-method.json','observer-final.patch']:
    shutil.copyfile(probe/name,out/name)
for folder,name in [('reader-checks','reader-checks.json'),('geometry-checks','geometry-checks.json'),('public-checks','public-checks.json')]:
    shutil.copyfile(probe/folder/'checks.json',out/name)
doc=f'''# Joint-repair observation qualification — 2026-10-18

The [72-run joint-repair pilot](h5-joint-repair-pilot-20261018.md) fails five
material comparisons. This separate observer records individual repairs to
explain that failure. It changes no search decisions, RNG calls, work charges,
deadline, validation reserve, step cap or geometry policy. Production is unchanged.

Nested records link each provisional chain, policy call, proposed swap and pair
repair. They retain original part types and physical poses, proposed/repaired
membership, collision loss, terminal outcomes, actual whole-job trials and
metrics, accepted steps, commits and rollbacks. Direct elapsed timers surround
separation and source lowering. Serialization and logging can change wall-time
trajectories; this is diagnostic evidence, not a performance comparison. Net
part-type migration can miss same-family copy swaps that cancel in the multiset.

All **165 unchanged native tests** pass, and **86 earlier witness outputs** are
exact. All **157 source files** reconstruct after reversing the recorded inserts;
155 unrelated files are unchanged. The second changed file only corrects the
observer example's description. Strict lint and the release observer build pass.

The saved native log contains **48 linked trace records**. The reader checks
parent/child identity, stage coverage, terminal state, finite timings, exact
proposal membership and source poses, part conservation, unchanged nonselected
sheets, acceptance metrics, provisional steps and rollback counters. Nine
deliberately damaged records are rejected. Completed and failed repairs, expiry,
accepted steps and an actual provisional rollback are represented.

Independent public CLI validation passes for **23 unique saved layouts**; the
filled-outer check covers **53 pairs** at the unchanged 1e-7 mm tolerance.
Whole-job baselines/trials use the original job. Component checks use selected
pair quantities and original full stock geometry; they do not replace internal
crop validation or original whole-job stock-count checks. The prior thin-crop
tests and their exact witnesses remain preserved.

Four public fixed-work outcomes (ordinary/common mode, seeds zero and one) match
the unobserved candidate exactly except elapsed wall time, with four independent
CLI checks. Common-mode trace counts equal the actual search statistics. The
first checker used an incorrect parent folder name after saving one outcome;
its source and failure remain. Only the reference path was corrected, and that
completed outcome was reused without another search.

The separate proposed diagnostic uses large plates and panel hardware at both
kerfs, seed zero and the original 60-second search allowance, serially on CCD0
physical CPU 8. The existing per-case validation/export/archive method is reused.
Its plan must be committed before any development measurement. No pilot retry,
integration, new release, held-out access or H5 credit follows qualification.
The completed milestone weight remains 60%.

[Checks](h5-joint-observer-preparation-20261018/checks.json),
[trace reader](h5-joint-observer-preparation-20261018/reader-checks.json),
[independent geometry](h5-joint-observer-preparation-20261018/geometry-checks.json),
[exact source reconstruction](h5-joint-observer-preparation-20261018/reconstruction.json),
[archive integrity](h5-joint-observer-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
print(json.dumps({'qualified':True,'archive_members':len(inventory),'archive_bytes':(out/'raw.zip').stat().st_size,'development_measurement_started':False}))
