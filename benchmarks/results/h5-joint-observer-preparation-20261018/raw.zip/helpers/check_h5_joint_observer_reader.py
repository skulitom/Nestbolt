"""Use already completed native traces to qualify the reader; no new searches."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,sys,traceback
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-observer-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_joint_trace as reader
out=probe/'reader-checks';out.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
text=(probe/'core-tests.log').read_text(encoding='utf-8');assert '165 passed; 0 failed' in text
traces=reader.parse_log(text);write(out/'native-traces.json',traces)
try:
    result=reader.check_traces(traces)
    assert result['pair_outcomes'].get('completed',0)>0
    assert result['pair_outcomes'].get('not_started',0)>0
    assert result['attempt_outcomes'].get('accepted',0)>0
    assert any(any(e['stage']=='rollback' for e in t['events']) for t in traces)
    rejected=[]
    def reject(label,mutate):
        value=copy.deepcopy(traces);mutate(value)
        try:reader.check_traces(value)
        except (AssertionError,KeyError,TypeError,ValueError):rejected.append(label)
        else:raise AssertionError('Malformed trace accepted: '+label)
    def first(value,kind,outcome=None):return next(t for t in value if t['kind']==kind and (outcome is None or t['outcome']==outcome))
    reject('duplicate trace identity',lambda v:v.append(copy.deepcopy(v[0])))
    reject('missing parent',lambda v:first(v,'attempt').__setitem__('parent',999999999))
    reject('unfinished pair',lambda v:first(v,'pair','completed').__setitem__('outcome','unresolved'))
    reject('missing lowering evidence',lambda v:first(v,'pair','completed')['events'].pop())
    reject('nonfinite phase time',lambda v:first(v,'pair','completed')['events'][1]['data'].__setitem__('separator_seconds',float('nan')))
    reject('lost repaired part',lambda v:reader.event(first(v,'pair','completed'),'lowering_exit')['pair'][1].pop())
    reject('mismatched proposed incoming pose',lambda v:first(v,'attempt','accepted')['data']['incoming'][0]['transform']['translation'].__setitem__(0,999999))
    reject('accepted increased material',lambda v:reader.event(first(v,'attempt','accepted'),'accepted_step')['after'].__setitem__('material_area',1e99))
    reject('wrong committed count',lambda v:reader.event(first(v,'chain','completed'),'finished').__setitem__('committed',99999))
    write(out/'checks.json',{'all_checks_pass':True,**result,'malformed_traces_rejected':rejected,
        'reader_sha256':digest(root/'scripts/h5_joint_trace.py'),'log_sha256':digest(probe/'core-tests.log'),
        'new_searches':0})
    shutil.copyfile(__file__,out/'check.py');shutil.copyfile(root/'scripts/h5_joint_trace.py',out/'reader.py')
    print(json.dumps({**result,'malformed_rejected':len(rejected)}))
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'reader_sha256':digest(root/'scripts/h5_joint_trace.py')})
    shutil.copyfile(root/'scripts/h5_joint_trace.py',out/'failed-reader.py');raise
