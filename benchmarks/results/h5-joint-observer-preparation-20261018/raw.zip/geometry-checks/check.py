"""Independently validate saved diagnostic baselines, trials and completed pairs."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,itertools,json,math,shutil,subprocess,sys,traceback
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-observer-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_joint_trace as reader
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=probe/'geometry-checks';out.mkdir();cache={};records=[];pairs=0
traces=load(probe/'reader-checks/native-traces.json');reader.check_traces(traces)
cli=root/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def validate(job,layout,valid,metrics,origin):
    global pairs
    key=sha256(json.dumps([job,layout],sort_keys=True).encode()).hexdigest()
    if key in cache:
        prior=cache[key];assert prior['valid']==valid
        if valid and metrics is not None:assert prior['metrics']==metrics
        prior['origins'].append(origin);return
    folder=out/f'case-{len(cache):04d}';folder.mkdir();write(folder/'job.json',job);write(folder/'layout.json',layout)
    command=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/'layout.json')]
    r=subprocess.run(command,capture_output=True,timeout=60)
    (folder/'stdout.json').write_bytes(r.stdout);(folder/'stderr.log').write_bytes(r.stderr)
    write(folder/'command.json',{'command':command,'exit_code':r.returncode})
    report=json.loads(r.stdout);assert report['valid']==valid,(origin,report)
    assert (r.returncode==0)==valid
    count=0;slack=None
    if valid:
        if metrics is not None:assert report['metrics']==metrics,(origin,report['metrics'],metrics)
        expected=Counter({p['id']:p['quantity'] for p in job['parts']})
        assert reader.inventory(layout['placements'])==expected
        parts={p['id']:p for p in job['parts']};sheets={}
        for p in layout['placements']:
            t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
            assert len(parts[p['part_id']]['geometry'])==1
            shape=Polygon(parts[p['part_id']]['geometry'][0]['outer']);assert shape.is_valid
            moved=affine_transform(shape,[m*c,-s,m*s,c,*t['translation']]);assert moved.is_valid
            sheets.setdefault(p['sheet_id'],[]).append(moved)
        for shapes in sheets.values():
            for a,b in itertools.combinations(shapes,2):
                count+=1;assert a.disjoint(b),(origin,'filled outer overlap')
                distance=a.distance(b)-job['clearance'];slack=distance if slack is None else min(slack,distance)
                assert distance>=-1e-7,(origin,distance)
        pairs+=count
    row={'hash':key,'folder':folder.name,'valid':valid,'metrics':report.get('metrics'),
        'origins':[origin],'filled_outer_pairs':count,'minimum_clearance_slack_mm':slack}
    cache[key]=row;records.append(row)
try:
    for t in traces:
        if t['kind']=='policy':
            validate(t['data']['job'],t['data']['baseline'],True,t['data']['metrics'],{'trace':t['id'],'stage':'baseline'})
        elif t['kind']=='attempt':
            trials=[e['data'] for e in t['events'] if e['stage']=='validated_trial']
            if trials:
                policy=next(p for p in traces if p['id']==t['parent'])
                trial=trials[0];report=trial['report']
                validate(policy['data']['job'],trial['layout'],report['valid'],report.get('metrics'),{'trace':t['id'],'stage':'trial'})
        elif t['kind']=='pair':
            for stage in ['recrop_exit','lowering_exit']:
                values=[e['data'] for e in t['events'] if e['stage']==stage]
                if not values:continue
                value=values[0]
                losses=value['losses'] if stage=='recrop_exit' else [value['loss']]
                if any(v!=0 for v in losses):continue
                pair=value['pair'];counts=sum((reader.inventory(x) for x in pair),Counter())
                job=copy.deepcopy(t['data']['job'])
                job['parts']=[p for p in job['parts'] if counts[p['id']]>0]
                for p in job['parts']:p['quantity']=counts[p['id']]
                # This validates component geometry and orientation. Original
                # whole-job stock availability is validated separately above.
                job['stocks'][0]['count']=None
                layout={'version':1,'units':job['units'],'sheets':[],'placements':[]};copies=Counter()
                for i,members in enumerate(pair):
                    if not members:continue
                    sid=f'sheet-{i}';layout['sheets'].append({'id':sid,'stock_id':job['stocks'][0]['id']})
                    for p in members:
                        layout['placements'].append({'part_id':p['part_id'],'copy_index':copies[p['part_id']],
                            'sheet_id':sid,'transform':p['transform']});copies[p['part_id']]+=1
                validate(job,layout,True,None,{'trace':t['id'],'stage':stage,'component_geometry_only':True})
    result={'all_checks_passed':True,'CLI_checks':len(records),'valid_layouts':sum(r['valid'] for r in records),
        'expected_invalid_layouts':sum(not r['valid'] for r in records),'filled_outer_pairs':pairs,
        'all_frozen_and_nonselected_sheets_exact':True,'source_crop_regressions_preserved_by_exact_native_witnesses':True,
        'component_checks_use_original_full_stock_geometry_with_pair_quantities':True,
        'component_checks_do_not_replace_cropped_internal_or_original_stock_count_checks':True,
        'shapely_version':shapely.__version__,'absolute_clearance_tolerance_mm':1e-7,
        'CLI_sha256':digest(cli),'trace_sha256':digest(probe/'reader-checks/native-traces.json'),
        'new_searches':0,'records':records}
    write(out/'checks.json',result);shutil.copyfile(__file__,out/'check.py')
    print(json.dumps({k:result[k] for k in ['CLI_checks','valid_layouts','expected_invalid_layouts','filled_outer_pairs']}))
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'completed':records});raise
