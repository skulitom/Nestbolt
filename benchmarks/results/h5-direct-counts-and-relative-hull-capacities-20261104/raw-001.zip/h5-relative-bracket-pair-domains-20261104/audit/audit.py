"""Verify relative hull containment and closed forbidden-rectangle coverage exactly."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-higher-bracket-filtered-20261104';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';BASE=ROOT/'output/h5-relative-bracket-pair-domains-20261104';PROCESS=ROOT/'output/h5-relative-bracket-pair-process-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
row=next(r for r in load(COUNT/'all-filtered-bounds.json') if r['empty_sites']==[13,14]);assert row==load(BASE/'source-component.json') and row['groups'][0]['family']=='bracket' and all(d[0]==6 for d in row['remaining_distributions'])
keys=sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==0));nodes=load(BASE/'nodes.json');checks=load(BASE/'checks.json');assert [tuple(n['key']) for n in nodes]==keys
unit=int(checks['rational_unit_denominator']);gap=F(load(BASE/'plan.json')['gap_mm']);assert unit>0 and gap==F(149,1000) and 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
assert (gap*unit).denominator==1;q=int(gap*unit)
unary={(t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions']};inner=load(GEN/'source-inner-rectangles.json');hulls=[];pieces=[];bounds=[]
for n in nodes:
    family,mode,gid,ri=n['key'];h=[list(map(F,p)) for p in unary[(gid,ri)]['hull_vertices']];ps=[list(map(F,r)) for r in inner[family][mode]]
    assert [list(map(F,p)) for p in n['hull_vertices_mm']]==h and [list(map(F,r)) for r in n['contained_rectangles_mm']]==ps and len(ps)==2
    assert all((v*unit).denominator==1 for p in h+ps for v in p)
    hs=[tuple(int(v*unit) for v in p) for p in h];hulls.append(hs);pieces.append([[int(v*unit) for v in p] for p in ps]);bounds.append([min(p[0] for p in hs),min(p[1] for p in hs),max(p[0] for p in hs),max(p[1] for p in hs)])
all_pairs=list(combinations_with_replacement(range(len(nodes)),2));excluded=set();axis=load(BASE/'axis-certificates.json')
for cert in axis:
    a,b=cert['nodes'];ai,bi=cert['pieces'];assert 0<=a<=b<len(nodes) and (a,b) not in excluded
    A,B=bounds[a],bounds[b];r,s=pieces[a][ai],pieces[b][bi];v=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
    assert v==cert['maximum_gaps_units'] and all(x<q for x in v);excluded.add((a,b))
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def clip(poly,bound,lower):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ai=a[0]>=bound if lower else a[0]<=bound;bi=b[0]>=bound if lower else b[0]<=bound
        if ai:result.append(a)
        if ai!=bi:
            t=F(bound-a[0],b[0]-a[0]);result.append((F(bound),a[1]+t*(b[1]-a[1])))
    return result
relative=load(BASE/'relative-certificates.json');slabs=vertex_differences=0
for cert in relative:
    a,b=cert['nodes'];assert 0<=a<=b<len(nodes) and (a,b) not in excluded
    points={(B[0]-A[0],B[1]-A[1]) for A in hulls[a] for B in hulls[b]};h=[tuple(p) for p in cert['relative_hull_units']];assert len(h)>=3 and len(set(h))==len(h) and all(p in points for p in h)
    for k,p in enumerate(h):assert cross(p,h[(k+1)%len(h)],h[(k+2)%len(h)])>0
    for A,B in zip(h,h[1:]+h[:1]):assert all(cross(A,B,p)>=0 for p in points)
    # Convex recorded hull contains every source difference; its vertices are actual differences.
    vertex_differences+=len(points);rects=[]
    for A in pieces[a]:
        for B in pieces[b]:
            rects.append([A[0]-B[2]-q+1,A[1]-B[3]-q+1,A[2]-B[0]+q-1,A[3]-B[1]+q-1])
    assert all(r[0]<r[2] and r[1]<r[3] for r in rects)
    xmin=min(p[0] for p in h);xmax=max(p[0] for p in h);cursor=xmin
    assert cert['slabs']
    for slab in cert['slabs']:
        left,right=slab['left'],slab['right'];assert left==cursor and left<right<=xmax;cursor=right
        ids=slab['covering_rectangles'];assert ids==sorted(set(ids)) and ids and all(0<=i<4 for i in ids)
        assert all(rects[i][0]<=left<right<=rects[i][2] for i in ids)
        polygon=clip(clip([tuple(map(F,p)) for p in h],F(left),True),F(right),False);assert polygon
        low=min(p[1] for p in polygon);high=max(p[1] for p in polygon);covered=low
        for bottom,top in sorted((rects[i][1],rects[i][3]) for i in ids):
            if top<covered:continue
            if bottom>covered:break
            covered=max(covered,top)
            if covered>=high:break
        assert covered>=high;slabs+=1
    assert cursor==xmax;excluded.add((a,b))
retained=[list(p) for p in all_pairs if p not in excluded];assert retained==load(BASE/'retained-pairs.json')
assert checks['scan_complete'] and checks['processed_option_pairs']==len(all_pairs) and checks['axis_exclusions']==len(axis) and checks['relative_hull_cover_exclusions_pending_audit']==len(relative) and checks['necessary_pairs_remaining']==len(retained)
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['preparation_target_overrun_seconds']==process['complete_process_cap_overrun_seconds']==0
assert opened['script_sha256']==digest(ROOT/opened['script']) and opened['maximum_calls']==1 and not opened['retry_permitted']
assert process['complete_process_seconds']>=checks['seconds_including_evidence_serialization']>=checks['discovery_seconds']
write(OUT/'source-bindings.json',bindings);write(OUT/'retained-pairs.json',retained)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','nodes.json','source-component.json','axis-certificates.json','relative-certificates.json','retained-pairs.json']]+[PROCESS/n for n in ['opened.json','process.json','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Rebuild every exact source vertex and contained rectangle. Verify each recorded relative hull is convex, consists of genuine vertex differences, and contains all vertex differences. Independently clip that hull to each closed X slab with rational Sutherland-Hodgman clipping; prove its entire Y projection is covered by inset forbidden rectangles spanning the full slab. Check continuous coverage from hull minimum to maximum X. Thus every possible original-source relative translation violates necessary spacing for at least one rectangle pair.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_options_verified':len(nodes),'all_option_pairs_verified':len(all_pairs),'axis_exclusions_verified':len(axis),'relative_hull_cover_exclusions_verified':len(relative),'source_vertex_differences_verified':vertex_differences,'exact_vertical_slab_clippings_verified':slabs,'necessary_pairs_remaining':len(retained),'complete_process_seconds':process['complete_process_seconds'],'preparation_and_process_overruns_seconds':0,'six_bracket_component_excluded':False,'any_placement_proven':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
