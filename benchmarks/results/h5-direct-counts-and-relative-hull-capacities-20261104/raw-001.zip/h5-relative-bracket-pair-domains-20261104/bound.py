"""Necessary pair exclusions using exact relative-position hulls and rectangle covers."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import lcm
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-higher-bracket-filtered-20261104';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';OUT=ROOT/'output/h5-relative-bracket-pair-domains-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,separators=(',',':'));f.write('\n')
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
inputs=[Path(__file__),FIRST/'plan.json',PRIOR/'integer-preparation/unary-templates.json',GEN/'source-inner-rectangles.json',GEN/'audit/plan.json',GEN/'audit/checks.json']+[COUNT/n for n in ['plan.json','all-filtered-bounds.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Select the complete bracket component requiring six copies at empty cog sites13/14. For each source-option pair form the exact convex hull of all differences HB-HA between source translation hull vertices. Every feasible relative translation lies in this hull. Each different-owner pair of contained source rectangles forbids an open axis-aligned relative-translation rectangle under the necessary149/1000mm directional gap. Inset each forbidden rectangle by one exact integer unit. Exclude a pair only if its entire relative hull is covered by these closed inset rectangles, proved slab by slab. Preserve every other or unprocessed pair. Independently audit convex-hull equality and exact polygon clipping before using pair exclusions.','empty_sites':[13,14],'group':0,'gap_mm':'149/1000','discovery_stop_seconds':40,'complete_preparation_target_seconds':60,'shared_process_cap_seconds':90,'packing_solver_calls':0,'native_calls':0})
row=next(r for r in load(COUNT/'all-filtered-bounds.json') if r['empty_sites']==[13,14]);assert row['groups'][0]['family']=='bracket' and all(d[0]==6 for d in row['remaining_distributions'])
keys=sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==0));assert len(keys)==134
unary={(t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions']};inner=load(GEN/'source-inner-rectangles.json');nodes=[];hulls=[];pieces=[]
for family,mode,gid,ri in keys:
    hull=[list(map(F,p)) for p in unary[(gid,ri)]['hull_vertices']];ps=[list(map(F,r)) for r in inner[family][mode]];assert len(ps)==2
    hulls.append(hull);pieces.append(ps);nodes.append({'key':[family,mode,gid,ri],'hull_vertices_mm':[[str(v) for v in p] for p in hull],'contained_rectangles_mm':[[str(v) for v in p] for p in ps]})
gap=F(149,1000);assert 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
unit=lcm(gap.denominator,*(v.denominator for h in hulls for p in h for v in p),*(v.denominator for ps in pieces for r in ps for v in r));q=int(gap*unit)
ih=[[(int(p[0]*unit),int(p[1]*unit)) for p in h] for h in hulls];ip=[[[int(v*unit) for v in r] for r in ps] for ps in pieces]
ib=[[min(p[0] for p in h),min(p[1] for p in h),max(p[0] for p in h),max(p[1] for p in h)] for h in ih]
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def convex(points):
    points=sorted(set(points));lower=[];upper=[]
    for p in points:
        while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    for p in reversed(points):
        while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
def y_range(hull,left,right):
    values=[F(y) for x,y in hull if left<=x<=right]
    for a,b in zip(hull,hull[1:]+hull[:1]):
        dx=b[0]-a[0]
        if not dx:continue
        for x in [left,right]:
            if min(a[0],b[0])<=x<=max(a[0],b[0]):values.append(F(a[1]*dx+(b[1]-a[1])*(x-a[0]),dx))
    assert values;return min(values),max(values)
def cover(hull,rects):
    xmin=min(p[0] for p in hull);xmax=max(p[0] for p in hull);assert xmin<xmax
    cuts=sorted({xmin,xmax}|{r[k] for r in rects for k in [0,2] if xmin<r[k]<xmax});slabs=[]
    for left,right in zip(cuts,cuts[1:]):
        active=[i for i,r in enumerate(rects) if r[0]<=left and right<=r[2]]
        if not active:return None
        lo,hi=y_range(hull,left,right);intervals=sorted((rects[i][1],rects[i][3]) for i in active);merged=[]
        for bottom,top in intervals:
            if not merged or bottom>merged[-1][1]:merged.append([bottom,top])
            else:merged[-1][1]=max(merged[-1][1],top)
        if not any(bottom<=lo<=hi<=top for bottom,top in merged):return None
        slabs.append({'left':left,'right':right,'covering_rectangles':active})
    return slabs
all_pairs=list(combinations_with_replacement(range(len(nodes)),2));axis=[];relative=[];retained=[];processed=0
for a,b in all_pairs:
    if time.perf_counter()-started>=40:break
    A,B=ib[a],ib[b];bad=None
    for ai,r in enumerate(ip[a]):
        for bi,s in enumerate(ip[b]):
            maxima=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
            if max(maxima)<q:bad={'nodes':[a,b],'pieces':[ai,bi],'maximum_gaps_units':maxima};break
        if bad:break
    if bad:axis.append(bad)
    else:
        hull=convex([(p[0]-r[0],p[1]-r[1]) for p in ih[b] for r in ih[a]])
        rects=[[r[0]-s[2]-q+1,r[1]-s[3]-q+1,r[2]-s[0]+q-1,r[3]-s[1]+q-1] for r in ip[a] for s in ip[b]]
        assert all(r[0]<r[2] and r[1]<r[3] for r in rects);proof=cover(hull,rects)
        if proof is None:retained.append([a,b])
        else:relative.append({'nodes':[a,b],'relative_hull_units':hull,'slabs':proof})
    processed+=1
retained.extend(list(t) for t in all_pairs[processed:]);compute=time.perf_counter()-started
for name,data in [('nodes.json',nodes),('source-component.json',row),('axis-certificates.json',axis),('relative-certificates.json',relative),('retained-pairs.json',retained)]:write(OUT/name,data)
elapsed=time.perf_counter()-started
checks={'passed':True,'discovery_seconds':compute,'seconds_including_evidence_serialization':elapsed,'preparation_target_overrun_seconds':max(0,elapsed-60),'rational_unit_denominator':str(unit),'source_options':len(nodes),'initial_option_pairs':len(all_pairs),'processed_option_pairs':processed,'scan_complete':processed==len(all_pairs),'axis_exclusions':len(axis),'relative_hull_cover_exclusions_pending_audit':len(relative),'necessary_pairs_remaining':len(retained),'independent_audit_required':True,'six_bracket_component_excluded':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
