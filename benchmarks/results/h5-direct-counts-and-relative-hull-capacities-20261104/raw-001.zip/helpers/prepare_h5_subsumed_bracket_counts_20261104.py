"""Prepare a distinct prefix method: every certified subset excludes its supersets."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD='h5-direct-bracket-count-domains-20261104';NEW='h5-subsumed-bracket-count-domains-20261104'
POLD='h5-direct-bracket-count-process-20261104';PNEW='h5-subsumed-bracket-count-process-20261104'
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/bound_h5_direct_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('from itertools import combinations_with_replacement','from itertools import combinations,combinations_with_replacement')
s=s.replace('>=50','>=40').replace("'discovery_stop_seconds':50","'discovery_stop_seconds':40")
s=s.replace('Cache exact prefix exclusions across domains.','Cache exact exclusions across domains. Before solving a prefix, check every proper submultiset for a cached certificate: one impossible subset excludes the whole prefix. This subsumption avoids repeated disjunction searches for supersets of previously disproved combinations. Rebuild directly from original source inputs; import no previous search certificates.')
s=s.replace('Stop discovery at50seconds','Stop discovery at40seconds')
s=s.replace("        if prefix in negative:return 'excluded',None", "        if prefix in negative:return 'excluded',None\n        if any(subset in negative for size in range(2,len(prefix)) for subset in combinations(prefix,size)):return 'excluded',None")
s=s.replace("'prefix_exclusion_trees_pending_audit':len(negative)", "'prefix_exclusion_trees_pending_audit':len(negative),'certified_subset_subsumption_enabled':True,'previous_search_certificates_imported':False")
write('bound_h5_subsumed_bracket_counts_20261104.py',s)
s=(ROOT/'output/run_h5_direct_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(POLD,PNEW).replace('bound_h5_direct_bracket_counts_20261104.py','bound_h5_subsumed_bracket_counts_20261104.py').replace("'discovery_stop_seconds':50","'discovery_stop_seconds':40")
write('run_h5_subsumed_bracket_counts_20261104.py',s)
s=(ROOT/'output/audit_h5_direct_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW).replace(POLD,PNEW).replace('from itertools import combinations_with_replacement','from itertools import combinations,combinations_with_replacement')
s=s.replace('    if prefix in excluded:return', '    if any(t in excluded for size in range(2,len(prefix)+1) for t in combinations(prefix,size)):return')
s=s.replace('A complete count cover must end in a verified exclusion before reaching the demanded multiplicity.', 'A complete count cover must contain a verified excluded submultiset before reaching the demanded multiplicity. Enumerate every submultiset independently to check subsumption coverage.')
s=s.replace("'sixty_second_preparation_pass':False", "'sixty_second_preparation_pass':process['preparation_target_overrun_seconds']==0,'certified_subset_subsumption_verified':True")
write('audit_h5_subsumed_bracket_counts_20261104.py',s)
