from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_direct_bracket_counts_20261104.py').read_text(encoding='utf-8').replace('h5-direct-bracket-count-process-20261104','h5-relative-bracket-pair-process-20261104').replace('bound_h5_direct_bracket_counts_20261104.py','bound_h5_relative_bracket_pairs_20261104.py').replace("'discovery_stop_seconds':50","'discovery_stop_seconds':40")
p=ROOT/'output/run_h5_relative_bracket_pairs_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
