"""Preserve partial-proof scope and the producer's incomplete wall-time accounting."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-large-bracket-triple-domains-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
checks=load(BASE/'checks.json');audit=load(BASE/'audit-v2/checks.json');assert audit['passed'] and not checks['scan_complete']
initial=load(BASE/'initial-triples.json');retained={tuple(t) for t in load(BASE/'retained-triples.json')};processed=checks['processed_triples']
assert all(tuple(t) in retained for t in initial[processed:])
assert all(tuple(c['nodes']) not in retained for c in load(BASE/'exclusion-certificates.json'))
record={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'bound.py',BASE/'checks.json',BASE/'audit-v2/plan.json',BASE/'audit-v2/checks.json',BASE/'initial-triples.json',BASE/'retained-triples.json',BASE/'exclusion-certificates.json']},'partial_source_proofs_independently_verified':True,'unprocessed_triples_explicitly_verified_retained':len(initial)-processed,'reported_compute_seconds':checks['seconds'],'reported_compute_seconds_include_evidence_serialization':False,'complete_process_wall_time_measured':False,'performance_gate_eligible':False,'timing_limitation':'The producer snapshots elapsed time before writing its large JSON evidence files. Its58.6906676seconds is computation time, not a verified complete preparation time. Do not charge only that value to a construction or claim a60/90-second full-process pass. Preserve this attempt; a distinct efficient preparation must measure serialization and process time as well.','new_capacity_bound':False,'remaining_site_choices':9,'remaining_count_distributions':13,'remaining_allocation_candidates':440,'closed_packing_calls_repeated':False,'source_valid66':False,'native_calls':0,'H5_complete':False,'next_method':'Investigate exact integer-scaled pair capacities or direct count search without enumerating and serializing every large-domain triple. Keep the partial audited triples as research evidence; do not imply their relaxed survivors are placements.'}
with (BASE/'checkpoint.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print({k:record[k] for k in ['partial_source_proofs_independently_verified','unprocessed_triples_explicitly_verified_retained','performance_gate_eligible','new_capacity_bound','remaining_site_choices','remaining_count_distributions']})
