"""Seal bounded count proofs, all timing limitations, and exact relative-hull evidence."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-direct-counts-and-relative-hull-capacities-20261104';OUT=ROOT/'benchmarks/results'/NAME
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104']]
FOLDERS=['h5-large-bracket-triple-domains-20261104','h5-direct-bracket-count-domains-20261104','h5-direct-bracket-count-process-20261104','h5-subsumed-bracket-count-domains-20261104','h5-subsumed-bracket-count-process-20261104','h5-first55-direct-bracket-filtered-20261104','h5-relative-bracket-pair-domains-20261104','h5-relative-bracket-pair-process-20261104','h5-relative-bracket-count-domains-20261104','h5-relative-bracket-count-process-20261104','h5-first55-relative-bracket-filtered-20261104']
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for name in ['h5-large-bracket-triple-domains-20261104/audit-v2','h5-direct-bracket-count-domains-20261104/audit','h5-subsumed-bracket-count-domains-20261104/audit','h5-relative-bracket-pair-domains-20261104/audit','h5-relative-bracket-count-domains-20261104/audit','h5-first55-relative-bracket-filtered-20261104/audit']:assert load(ROOT/'output'/name/'checks.json')['passed']
final=load(ROOT/'output'/FOLDERS[-1]/'audit/checks.json');assert final['remaining_site_choices']==2 and final['remaining_count_distributions']==3
parent_by_hash={}
for parent in PARENTS:
    assert load(parent/'archive-checks.json')['passed'];manifest=load(parent/'raw-manifest.json');h=digest(parent/'raw-manifest.json')
    for row in manifest['files']:parent_by_hash.setdefault((row['sha256'],row['bytes']),(parent,h,row))
OUT.mkdir();members={};external={};queue=[];seen=set();bindings={}
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    h=digest(p);size=p.stat().st_size;prior=parent_by_hash.get((h,size))
    if prior:
        parent,mh,row=prior;external[name]={'manifest':(parent/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':mh,'archive':row['archive'],'member':row['path'],'bytes':size,'sha256':h}
    else:members[name]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for name in FOLDERS:
    folder=ROOT/'output'/name
    for p in folder.rglob('*'):
        if p.is_file():add(name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*large_bracket*20261104.py','*h5*direct_bracket*20261104.py','*h5*subsumed_bracket*20261104.py','*h5*relative*bracket*20261104.py','prepare_h5_relative_pair_runner_20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for name,h in load(p).get('inputs',{}).items():
            q=ROOT/name;assert digest(q)==h,name;bindings[name]=h;add('source-inputs/'+name,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
copies={
'partial-triple-audit.json':'h5-large-bracket-triple-domains-20261104/audit-v2/checks.json',
'partial-triple-timing-limitation.json':'h5-large-bracket-triple-domains-20261104/checkpoint.json',
'direct-count-audit.json':'h5-direct-bracket-count-domains-20261104/audit/checks.json',
'direct-process.json':'h5-direct-bracket-count-process-20261104/process.json',
'subsumed-count-audit.json':'h5-subsumed-bracket-count-domains-20261104/audit/checks.json',
'subsumed-process.json':'h5-subsumed-bracket-count-process-20261104/process.json',
'direct-filter-audit.json':'h5-first55-direct-bracket-filtered-20261104/audit/checks.json',
'relative-pair-audit.json':'h5-relative-bracket-pair-domains-20261104/audit/checks.json',
'relative-pair-process.json':'h5-relative-bracket-pair-process-20261104/process.json',
'relative-count-audit.json':'h5-relative-bracket-count-domains-20261104/audit/checks.json',
'relative-count-process.json':'h5-relative-bracket-count-process-20261104/process.json',
'final-filter-audit.json':'h5-first55-relative-bracket-filtered-20261104/audit/checks.json',
'all2-filtered-bounds.json':'h5-first55-relative-bracket-filtered-20261104/all-filtered-bounds.json'}
for name,path in copies.items():shutil.copyfile(ROOT/'output'/path,OUT/name)
write(OUT/'next-step.json',{'authoritative_count_table':'output/h5-first55-relative-bracket-filtered-20261104/all-filtered-bounds.json','remaining_site_choices':[[5,10],[10,11]],'remaining_count_distributions':3,'remaining_allocation_candidates':440,'next_work':'Develop a distinct construction for the surviving fixed-cog choices, or strengthen necessary source bounds if that resolves its geometry. A construction must place all thirteen original moving parts: seven brackets and six inserts, alongside fixed29, thirteen cogs and short11. The earlier fixed two-insert/eleven-companion choices are all excluded within their conservative source domains.','timing_requirement':'Measure and charge every prerequisite actually used. The standalone proof stages are not a complete60-second construction pipeline; do not treat the long or incompletely timed proof derivations as free preparation.','existing_calls_must_remain_closed':True,'source_valid66_required_before_native':True,'whole_job_infeasibility_proven':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'original_site_choices':9,'original_count_distributions':13,'remaining_site_choices':2,'remaining_count_distributions':3,'remaining_allocation_candidates':440,'direct_preparation_overrun_seconds':load(ROOT/'output/h5-direct-bracket-count-process-20261104/process.json')['preparation_target_overrun_seconds'],'partial_triple_full_timing_unverified':True,'complete_construction_budget_not_established':True,'source_valid66':False,'new_packing_solver_calls':0,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Direct count proofs and relative-hull capacities — 2026-11-04

Independent continuous-source proofs reduce the restricted fixed-cog construction
from **9 site choices / 13 count distributions to 2 choices / 3 distributions**.
The remaining choices are [5,10] and [10,11]. All 440 whole-job allocations,
the full 66-part layout and H5 matrix remain open. These are exclusions within
the specified conservative source domains, not whole-job infeasibility claims.

## Preserved partial pass and timing limitations

A larger triple pass reconstructs 497 source options over nine bracket domains.
[Its audit]({NAME}/partial-triple-audit.json) verifies 16,998 pair exclusions and
177,020 complete disjunction trees, while preserving 193,588 necessary triples.
All 46,982 unprocessed triples are explicitly retained. This pass yields no
capacity bound. [Its timing record]({NAME}/partial-triple-timing-limitation.json)
states that the reported 58.690668 seconds precedes evidence serialization;
complete process time was not captured. It is not performance-gate evidence.

## Direct count proofs and measured timing

A distinct direct method searches only prefixes needed for each demanded
multiplicity, scales rational bounds exactly, and reuses certified prefix
failures across source domains. [Independent full Floyd closure]({NAME}/direct-count-audit.json)
verifies 311,071 complete prefix trees and all 325,081 prefixes needed to cover
six complete count exclusions. [The full process]({NAME}/direct-process.json)
takes 63.843848 seconds: its **3.843848-second preparation-target overrun is
preserved**, while the 90-second process cap passes.

A revised algorithm checks every proper submultiset before solving a prefix,
so an impossible smaller combination rejects a larger one. It rebuilds directly
from original source inputs and imports no earlier search certificates.
[Its independent audit]({NAME}/subsumed-count-audit.json) verifies 211,129 trees,
859,992 proof nodes and the same six complete capacity bounds. [Full process
time]({NAME}/subsumed-process.json), including evidence serialization, is
50.408002 seconds. Both methods stop before completing every larger domain;
neither discards unprocessed possibilities or claims a placement.

[Applying the six proved bounds]({NAME}/direct-filter-audit.json) removes nine
count distributions and choices [0,5], [0,10], [5,11], [10,12], [10,13] and
[12,14], leaving three choices and four distributions. Every surviving source
field is unchanged. Proof validity and the recorded timing failure remain
separate facts; the failed timing is not relabelled as a pass.

## Stronger pair constraints from original source hulls

For choice [13,14], 134 bracket options must hold six copies. A new necessary
pair method preserves X/Y coupling: every relative translation lies in the
convex hull of differences between original source-hull vertices. It excludes
a pair only when that complete hull is covered by strictly inset forbidden
rectangles from the contained original-source components.

The [pair audit]({NAME}/relative-pair-audit.json) verifies all 9,045 option pairs,
4,597 axis exclusions, and **656 additional relative-hull exclusions**, using
12,196 exact source vertex differences and 1,927 independent rational polygon
clippings. The remaining necessary pair set has 3,792 entries. [The full
preparation process]({NAME}/relative-pair-process.json) takes 0.666982 seconds.

A new direct count proof uses those audited pair constraints and charges that
complete preparation time. [Independent readback]({NAME}/relative-count-audit.json)
verifies 78,129 complete trees, 338,457 proof nodes and all 103,919 count prefixes,
proving a maximum of five brackets in the six-bracket domain. [The measured
process]({NAME}/relative-count-process.json), including pair preparation and
evidence serialization, takes 18.168017 seconds with no overrun.

The [final filter audit]({NAME}/final-filter-audit.json) removes [13,14] and
verifies all 761 retained source-mode attributions. [The authoritative table]({NAME}/all2-filtered-bounds.json)
contains [5,10] with bracket/insert component counts [6,1,6] or [7,0,6], and
[10,11] with [6,1,6]. All four earlier fixed two-insert companion choices are
now excluded within their specified domains; their valid partial layouts and
all closed model calls remain preserved.

These timings measure standalone proof processes, not a complete H5 construction
pipeline. Any later construction must measure and charge all prerequisites it
actually uses. No new placement solver, source66 checker or native validator was
called. [Next work]({NAME}/next-step.json) requires all thirteen moving originals
for the surviving choices, or a distinct placement method with explicit scope.

The archive contains {archive['archive_members']} new canonical members and
{archive['archive_bytes']:,} compressed bytes. [The manifest]({NAME}/raw-manifest.json),
[external evidence map]({NAME}/external-evidence.json), and [source bindings]({NAME}/source-bindings.json)
preserve the complete new evidence and resolve reused bytes against two previous
committed manifests. Independent verification reads and hashes every referenced
member. H2/H5 remain open at **60%**; the original gates, held-out isolation,
production code and release status are unchanged.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 direct counts and relative-hull capacities:** [independent continuous-source audits]({link}) reduce the restricted construction from 9 choices / 13 count distributions to 2 / 3. Six direct capacity bounds remove nine distributions; a new exact relative-hull pair method then proves the six-bracket requirement impossible at [13,14]. The first direct process exceeded its preparation target by 3.843848 s; that failure and a separate unverified serialization timing remain preserved. Revised standalone proof processes take 50.408002 s and 18.168017 s, but no complete construction budget or full66 layout is established. All 440 whole-job allocations and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [continuous inserts and exact bracket capacities](../benchmarks/results/h5-continuous-inserts-and-bracket-capacities-20261104.md).\nThe restricted construction now has 9 site choices and 13 count distributions.';assert s.count(old)==1
s=s.replace(old,f'Latest H5 evidence: [direct count proofs and relative-hull capacities](../benchmarks/results/{NAME}.md).\nThe restricted construction now has 2 site choices and 3 count distributions.',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
