"""A new count proof that uses audited, coupled relative-position exclusions."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD='h5-subsumed-bracket-count-domains-20261104';NEW='h5-relative-bracket-count-domains-20261104'
POLD='h5-subsumed-bracket-count-process-20261104';PNEW='h5-relative-bracket-count-process-20261104'
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
extra="PAIR=ROOT/'output/h5-relative-bracket-pair-domains-20261104';PAIR_PROCESS=ROOT/'output/h5-relative-bracket-pair-process-20261104'\n"
input_expr="[PAIR/n for n in ['plan.json','checks.json','nodes.json','relative-certificates.json','audit/plan.json','audit/checks.json','audit/retained-pairs.json']]+[PAIR_PROCESS/'process.json']"
s=(ROOT/'output/bound_h5_subsumed_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace('load=lambda p:',extra+'load=lambda p:',1)
s=s.replace('started=time.perf_counter()',"started=time.perf_counter()-load(PAIR_PROCESS/'process.json')['complete_process_seconds'];assert load(PAIR/'audit/checks.json')['passed']",1)
s=s.replace('inputs=[Path(__file__),', 'inputs='+input_expr+'+[Path(__file__),',1)
s=s.replace("rows=load(COUNT/'all-filtered-bounds.json')", "rows=[r for r in load(COUNT/'all-filtered-bounds.json') if r['empty_sites']==[13,14]]")
anchor='prefix_calls=tree_nodes=0;timed_out=False;negative={};positive={}'
insert="assert [n['key'] for n in nodes]==[n['key'] for n in load(PAIR/'nodes.json')]\nrelative_retained={tuple(t) for t in load(PAIR/'audit/retained-pairs.json')};assert relative_retained<=compatible\nadditional_pairs=compatible-relative_retained;assert additional_pairs=={tuple(r['nodes']) for r in load(PAIR/'relative-certificates.json')}\ncompatible=relative_retained\n"
assert anchor in s;s=s.replace(anchor,insert+anchor)
s=s.replace('Reconstruct original source bracket domains directly.', 'Reconstruct the complete source bracket domain for empty cog sites13/14 directly. Strengthen pair compatibility with independently audited relative-hull forbidden-rectangle covers, preserving X/Y coupling from the source hulls. Charge the complete pair-preparation process time. Import no earlier count-search certificates.')
s=s.replace("'previous_search_certificates_imported':False", "'previous_search_certificates_imported':False,'relative_pair_exclusions_used':len(additional_pairs),'relative_pair_preparation_seconds_charged':load(PAIR_PROCESS/'process.json')['complete_process_seconds']")
write('bound_h5_relative_bracket_counts_20261104.py',s)
s=(ROOT/'output/run_h5_subsumed_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(POLD,PNEW).replace('bound_h5_subsumed_bracket_counts_20261104.py','bound_h5_relative_bracket_counts_20261104.py')
s=s.replace('OUT.mkdir();started=time.perf_counter()',"OUT.mkdir();charge=json.loads((ROOT/'output/h5-relative-bracket-pair-process-20261104/process.json').read_bytes())['complete_process_seconds'];started=time.perf_counter()-charge")
s=s.replace("'maximum_calls':1", "'relative_pair_preparation_seconds_charged':charge,'maximum_calls':1")
s=s.replace('timeout=90)', 'timeout=max(.01,90-charge))')
write('run_h5_relative_bracket_counts_20261104.py',s)
s=(ROOT/'output/audit_h5_subsumed_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW).replace(POLD,PNEW)
s=s.replace('load=lambda p:',extra+'load=lambda p:',1)
s=s.replace("rows=load(COUNT/'all-filtered-bounds.json')", "rows=[r for r in load(COUNT/'all-filtered-bounds.json') if r['empty_sites']==[13,14]]")
anchor="compatible=needed-bad;assert sorted(compatible)==[tuple(t) for t in load(BASE/'compatible-pairs.json')]"
replacement="assert load(PAIR/'audit/checks.json')['passed'] and [n['key'] for n in nodes]==[n['key'] for n in load(PAIR/'nodes.json')]\nextra_bad={tuple(r['nodes']) for r in load(PAIR/'relative-certificates.json')};assert not extra_bad&bad and extra_bad<=needed\nassert checks['relative_pair_exclusions_used']==len(extra_bad);bad.update(extra_bad)\ncompatible=needed-bad;assert sorted(compatible)==[tuple(t) for t in load(BASE/'compatible-pairs.json')]==[tuple(t) for t in load(PAIR/'audit/retained-pairs.json')]"
assert anchor in s;s=s.replace(anchor,replacement)
s=s.replace("assert opened['script_sha256']==", "assert opened['relative_pair_preparation_seconds_charged']==checks['relative_pair_preparation_seconds_charged']==load(PAIR_PROCESS/'process.json')['complete_process_seconds']\nassert opened['script_sha256']==")
s=s.replace('inputs=[Path(__file__)]', 'inputs='+input_expr+'+[Path(__file__)]',1)
s=s.replace('Reconstruct every source hull interval and rectangle,', 'Reconstruct every source hull interval and rectangle; bind every strengthened pair exclusion to the independent relative-hull cover audit;')
s=s.replace("'certified_subset_subsumption_verified':True", "'certified_subset_subsumption_verified':True,'relative_pair_exclusions_verified':len(extra_bad),'relative_pair_preparation_seconds_charged':opened['relative_pair_preparation_seconds_charged']")
write('audit_h5_relative_bracket_counts_20261104.py',s)
