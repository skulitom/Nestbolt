from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('filter_h5_higher_bracket_counts_20261104.py','filter_h5_direct_bracket_counts_20261104.py'),('audit_h5_higher_bracket_counts_20261104.py','audit_h5_direct_bracket_count_filter_20261104.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    s=s.replace('h5-first55-higher-bracket-filtered-20261104','h5-first55-direct-bracket-filtered-20261104').replace('h5-first55-small-bracket-filtered-20261104','h5-first55-higher-bracket-filtered-20261104')
    s=s.replace('h5-small-bracket-triple-domains-20261104','h5-direct-bracket-count-domains-20261104').replace('h5-bracket-higher-count-domains-20261104','h5-direct-bracket-count-domains-20261104')
    p=ROOT/'output'/new;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
