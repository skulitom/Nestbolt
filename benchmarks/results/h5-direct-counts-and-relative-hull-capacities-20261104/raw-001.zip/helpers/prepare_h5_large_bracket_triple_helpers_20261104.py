from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for original,new in [('bound_h5_small_bracket_triples_20261104.py','bound_h5_large_bracket_triples_20261104.py'),('audit_h5_small_bracket_triples_20261104.py','audit_h5_large_bracket_triples_20261104.py')]:
    s=(ROOT/'output'/original).read_text(encoding='utf-8').replace('h5-small-bracket-triple-domains-20261104','h5-large-bracket-triple-domains-20261104').replace('h5-first55-direct-smaller-block-filtered-20261104','h5-first55-higher-bracket-filtered-20261104').replace('1<=len(keys)<=41','42<=len(keys)<=200').replace('at most41 mode/region options','42to200 mode/region options').replace('small source components','larger source components')
    p=ROOT/'output'/new;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
