"""Direct original-source count proofs with exact integer units and prefix pruning."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
from math import lcm
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-higher-bracket-filtered-20261104';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';OUT=ROOT/'output/h5-relative-bracket-count-domains-20261104'
PAIR=ROOT/'output/h5-relative-bracket-pair-domains-20261104';PAIR_PROCESS=ROOT/'output/h5-relative-bracket-pair-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,separators=(',',':'));f.write('\n')
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()-load(PAIR_PROCESS/'process.json')['complete_process_seconds'];assert load(PAIR/'audit/checks.json')['passed']
inputs=[PAIR/n for n in ['plan.json','checks.json','nodes.json','relative-certificates.json','audit/plan.json','audit/checks.json','audit/retained-pairs.json']]+[PAIR_PROCESS/'process.json']+[Path(__file__),FIRST/'plan.json',PRIOR/'integer-preparation/unary-templates.json',GEN/'source-inner-rectangles.json',GEN/'audit/plan.json',GEN/'audit/checks.json']+[COUNT/n for n in ['plan.json','all-filtered-bounds.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct the complete source bracket domain for empty cog sites13/14 directly. Strengthen pair compatibility with independently audited relative-hull forbidden-rectangle covers, preserving X/Y coupling from the source hulls. Charge the complete pair-preparation process time. Import no earlier count-search certificates. Scale all exact rational interval bounds and contained rectangles into common integer units. Enumerate only prefixes needed to test each demanded multiplicity, pruning incompatible pairs and complete necessary difference-disjunction certificates. Cache exact exclusions across domains. Before solving a prefix, check every proper submultiset for a cached certificate: one impossible subset excludes the whole prefix. This subsumption avoids repeated disjunction searches for supersets of previously disproved combinations. Rebuild directly from original source inputs; import no previous search certificates. A relaxed interval witness is not a placement. Stop discovery at40seconds; record time again after compact evidence serialization. Independently verify every count exclusion with complete canonical-prefix enumeration and full Floyd closure.','discovery_stop_seconds':40,'complete_preparation_target_seconds':60,'shared_process_cap_seconds':90,'gap_mm':'149/1000','packing_solver_calls':0,'native_calls':0})
rows=[r for r in load(COUNT/'all-filtered-bounds.json') if r['empty_sites']==[13,14]];source_unary={(t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions']};inner=load(GEN/'source-inner-rectangles.json');group_uses={}
for row in rows:
    for gi,g in enumerate(row['groups']):
        counts=[d[gi] for d in row['remaining_distributions']]
        if g['family']!='bracket' or max(counts)<3:continue
        keys=tuple(sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi)))
        if not 42<=len(keys)<=200:continue
        group_uses.setdefault(keys,[]).append({'empty_sites':row['empty_sites'],'group':gi,'counts':counts})
all_keys=sorted(set(k for keys in group_uses for k in keys));key_index={k:i for i,k in enumerate(all_keys)};nodes=[];bounds=[];pieces=[]
for family,mode,gid,ri in all_keys:
    hull=[list(map(F,p)) for p in source_unary[(gid,ri)]['hull_vertices']];b=[min(p[k] for p in hull) for k in [0,1]]+[max(p[k] for p in hull) for k in [0,1]];ps=[list(map(F,r)) for r in inner[family][mode]]
    bounds.append(b);pieces.append(ps);nodes.append({'key':[family,mode,gid,ri],'translation_bounds_mm':[str(v) for v in b],'contained_rectangles_mm':[[str(v) for v in r] for r in ps]})
gap=F(149,1000);assert 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
unit=lcm(gap.denominator,*(v.denominator for b in bounds for v in b),*(v.denominator for ps in pieces for r in ps for v in r));q=int(gap*unit)
ib=[[int(v*unit) for v in b] for b in bounds];ip=[[[int(v*unit) for v in r] for r in ps] for ps in pieces]
domains=[{'nodes':[key_index[k] for k in keys],'uses':uses,'targets':sorted(set(c for u in uses for c in u['counts'] if c>=3)),'results':[]} for keys,uses in sorted(group_uses.items(),key=lambda r:(len(r[0]),r[0]))]
needed=sorted({pair for d in domains for pair in combinations_with_replacement(d['nodes'],2)});compatible=set();pair_certs=[]
for a,b in needed:
    A,B=ib[a],ib[b];bad=None
    for ai,r in enumerate(ip[a]):
        for bi,s in enumerate(ip[b]):
            maxima=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
            if max(maxima)<q:bad={'nodes':[a,b],'pieces':[ai,bi],'maximum_gaps_units':maxima};break
        if bad:break
    if bad:pair_certs.append(bad)
    else:compatible.add((a,b))
assert [n['key'] for n in nodes]==[n['key'] for n in load(PAIR/'nodes.json')]
relative_retained={tuple(t) for t in load(PAIR/'audit/retained-pairs.json')};assert relative_retained<=compatible
additional_pairs=compatible-relative_retained;assert additional_pairs=={tuple(r['nodes']) for r in load(PAIR/'relative-certificates.json')}
compatible=relative_retained
prefix_calls=tree_nodes=0;timed_out=False;negative={};positive={}
def matrices_and_clauses(whole):
    bs=[ib[i] for i in whole];ps=[(o,r) for o,i in enumerate(whole) for r in ip[i]];size=len(whole)+1;matrices=[]
    for axis in [0,1]:
        lo=[b[axis] for b in bs]+[0];hi=[b[axis+2] for b in bs]+[0]
        matrices.append([[0 if i==j else hi[i]-lo[j] for j in range(size)] for i in range(size)])
    clauses=[]
    for k,(a,A) in enumerate(ps):
        for b,B in ps[k+1:]:
            if a!=b:clauses.append([(0,a,b,B[0]-A[2]-q),(0,b,a,A[0]-B[2]-q),(1,a,b,B[1]-A[3]-q),(1,b,a,A[1]-B[3]-q)])
    return matrices,clauses
def disjunction(matrices,clauses):
    global tree_nodes,timed_out
    tree_nodes+=1
    if time.perf_counter()-started>=40:timed_out=True;return 'unknown',None
    chosen=None
    for ci,clause in enumerate(clauses):
        if any(matrices[axis][a][b]<=c for axis,a,b,c in clause):continue
        possible=[di for di,(axis,a,b,c) in enumerate(clause) if matrices[axis][b][a]+c>=0]
        if not possible:return 'excluded',{'contradiction_clause':ci}
        if chosen is None or len(possible)<len(chosen[1]):chosen=(ci,possible)
    if chosen is None:return 'relaxed',[[m[i][-1] for m in matrices] for i in range(len(matrices[0])-1)]
    ci,possible=chosen;children=[]
    for di in possible:
        axis,a,b,c=clauses[ci][di];old=matrices[axis];size=len(old);new=[[min(old[i][j],old[i][a]+c+old[b][j]) for j in range(size)] for i in range(size)];assert all(new[i][i]==0 for i in range(size))
        updated=matrices[:];updated[axis]=new;status,evidence=disjunction(updated,clauses)
        if status!='excluded':return status,evidence
        children.append({'direction':di,'proof':evidence})
    return 'excluded',{'split_clause':ci,'children':children}
def search(prefix,choices,target):
    global prefix_calls,timed_out
    prefix_calls+=1
    if time.perf_counter()-started>=40:timed_out=True;return 'unknown',None
    if len(prefix)>=2:
        if prefix in negative:return 'excluded',None
        if any(subset in negative for size in range(2,len(prefix)) for subset in combinations(prefix,size)):return 'excluded',None
        if prefix not in positive:
            status,evidence=disjunction(*matrices_and_clauses(prefix))
            if status=='excluded':negative[prefix]=evidence;return status,None
            if status=='unknown':return status,None
            positive[prefix]=evidence
        if len(prefix)==target:return 'relaxed',{'nodes':list(prefix),'positions_units':positive[prefix]}
    for rank,n in enumerate(choices):
        rest=[v for v in choices[rank:] if (n,v) in compatible]
        status,evidence=search(prefix+(n,),rest,target)
        if status!='excluded':return status,evidence
    return 'excluded',None
for d in domains:
    for target in d['targets']:
        before=prefix_calls;status,witness=search((),d['nodes'],target);r={'target':target,'status':status,'prefixes_visited':prefix_calls-before}
        if witness:r['necessary_interval_witness']=witness
        d['results'].append(r)
        if status=='excluded':d['maximum_brackets_proven_pending_audit']=target-1;break
        if timed_out:break
    if timed_out:break
compute=time.perf_counter()-started
for name,data in [('nodes.json',nodes),('domains.json',domains),('compatible-pairs.json',[list(t) for t in sorted(compatible)]),('pair-certificates.json',pair_certs),('prefix-certificates.json',[{'nodes':list(k),'proof':v} for k,v in sorted(negative.items())])]:write(OUT/name,data)
serialized=time.perf_counter()-started
checks={'passed':True,'discovery_seconds':compute,'seconds_including_evidence_serialization':serialized,'preparation_target_overrun_seconds':max(0,serialized-60),'scan_complete':not timed_out,'source_nodes':len(nodes),'source_domains':len(domains),'rational_unit_denominator':str(unit),'necessary_pairs':len(needed),'pair_exclusions':len(pair_certs),'prefixes_visited':prefix_calls,'exact_disjunction_nodes':tree_nodes,'prefix_exclusion_trees_pending_audit':len(negative),'certified_subset_subsumption_enabled':True,'previous_search_certificates_imported':False,'relative_pair_exclusions_used':len(additional_pairs),'relative_pair_preparation_seconds_charged':load(PAIR_PROCESS/'process.json')['complete_process_seconds'],'relaxed_prefixes':len(positive),'capacity_bounds_pending_audit':[{'nodes':d['nodes'],'maximum_brackets':d['maximum_brackets_proven_pending_audit']} for d in domains if 'maximum_brackets_proven_pending_audit' in d],'independent_audit_required':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print({k:v for k,v in checks.items() if k!='capacity_bounds_pending_audit'}|{'capacity_bounds_pending_audit':len(checks['capacity_bounds_pending_audit'])})
