"""Rebuild source domains and audit exact certificates with rational Floyd closure."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import lcm
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
COUNT=ROOT/'output/h5-first55-higher-bracket-filtered-20261104'
PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
BASE=ROOT/'output/h5-large-bracket-triple-domains-20261104';OUT=BASE/'audit-v2'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
rows=load(COUNT/'all-filtered-bounds.json');nodes=load(BASE/'nodes.json');domains=load(BASE/'domains.json')
key_index={tuple(n['key']):i for i,n in enumerate(nodes)};assert len(key_index)==len(nodes)
unary={ (t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions'] }
inner=load(GEN/'source-inner-rectangles.json');bounds=[];pieces=[]
for n in nodes:
    family,mode,gid,ri=n['key'];assert family=='bracket'
    hull=[tuple(F(v) for v in p) for p in unary[(gid,ri)]['hull_vertices']]
    expected=[min(p[0] for p in hull),min(p[1] for p in hull),max(p[0] for p in hull),max(p[1] for p in hull)]
    assert list(map(F,n['translation_bounds_mm']))==expected and n['contained_rectangles_mm']==inner[family][mode]
    bounds.append(expected);pieces.append([list(map(F,r)) for r in n['contained_rectangles_mm']]);assert len(pieces[-1])==2
expected_domains={}
for row in rows:
    for gi,g in enumerate(row['groups']):
        if g['family']!='bracket' or all(d[gi]<3 for d in row['remaining_distributions']):continue
        keys=tuple(sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi)))
        if not 42<=len(keys)<=200:continue
        expected_domains.setdefault(keys,[]).append({'empty_sites':row['empty_sites'],'group':gi,'counts':[d[gi] for d in row['remaining_distributions']]})
assert len(expected_domains)==len(domains);used=set()
for d,(keys,uses) in zip(domains,sorted(expected_domains.items(),key=lambda r:(len(r[0]),r[0]))):
    assert d['nodes']==[key_index[k] for k in keys] and d['uses']==uses;used.update(d['nodes'])
assert used==set(range(len(nodes)))
gap=F(load(BASE/'plan.json')['gap_mm']);assert gap==F(149,1000) and 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
needed={t for d in domains for t in combinations_with_replacement(d['nodes'],2)};bad=set()
for cert in load(BASE/'pair-certificates.json'):
    a,b=cert['nodes'];ai,bi=cert['pieces'];key=(a,b);assert key in needed and key not in bad
    A,B=bounds[a],bounds[b];r,s=pieces[a][ai],pieces[b][bi]
    maxima=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
    assert list(map(F,cert['maximum_gaps_mm']))==maxima and all(v<gap for v in maxima);bad.add(key)
compatible=needed-bad;assert sorted(compatible)==[tuple(t) for t in load(BASE/'compatible-pairs.json')]
initial=sorted({t for d in domains for t in combinations_with_replacement(d['nodes'],3) if all(p in compatible for p in [(t[0],t[1]),(t[0],t[2]),(t[1],t[2])])})
assert initial==[tuple(t) for t in load(BASE/'initial-triples.json')];initial_set=set(initial)
def close(matrix):
    d=[r[:] for r in matrix]
    for k in range(len(d)):
        for i in range(len(d)):
            for j in range(len(d)):
                if d[i][k] is not None and d[k][j] is not None:
                    v=d[i][k]+d[k][j]
                    if d[i][j] is None or v<d[i][j]:d[i][j]=v
    return d
unit=lcm(gap.denominator,*(v.denominator for b in bounds for v in b),*(v.denominator for ps in pieces for r in ps for v in r))
assert unit>0
scaled_bounds=[[int(v*unit) for v in b] for b in bounds]
scaled_pieces=[[[int(v*unit) for v in r] for r in ps] for ps in pieces]
assert all(F(w,unit)==v for b,bs in zip(bounds,scaled_bounds) for v,w in zip(b,bs))
assert all(F(w,unit)==v for ps,qs in zip(pieces,scaled_pieces) for r,t in zip(ps,qs) for v,w in zip(r,t))
q=int(gap*unit);assert F(q,unit)==gap
trees=leaves=splits=branches=0
def verify(proof,matrices,clauses):
    global trees,leaves,splits,branches
    trees+=1
    if 'contradiction_clause' in proof:
        assert set(proof)=={'contradiction_clause'}
        for axis,a,b,c in clauses[proof['contradiction_clause']]:assert matrices[axis][b][a]+c<0
        leaves+=1;return
    assert set(proof)=={'split_clause','children'};possible=[]
    for di,(axis,a,b,c) in enumerate(clauses[proof['split_clause']]):
        proposed=[r[:] for r in matrices[axis]];proposed[a][b]=min(proposed[a][b],c);closed=close(proposed)
        if all(closed[i][i]>=0 for i in range(len(closed))):possible.append((di,axis,closed))
    assert possible and [di for di,axis,d in possible]==[c['direction'] for c in proof['children']];splits+=1
    for child,(di,axis,closed) in zip(proof['children'],possible):
        assert set(child)=={'direction','proof'};updated=matrices[:];updated[axis]=closed;branches+=1;verify(child['proof'],updated,clauses)
excluded=set()
for cert in load(BASE/'exclusion-certificates.json'):
    whole=tuple(cert['nodes']);assert whole in initial_set and whole not in excluded;matrices=[]
    for axis in [0,1]:
        d=[[0 if i==j else None for j in range(4)] for i in range(4)]
        for i,n in enumerate(whole):d[i][3]=scaled_bounds[n][axis+2];d[3][i]=-scaled_bounds[n][axis]
        matrices.append(close(d))
    ps=[(o,r) for o,n in enumerate(whole) for r in scaled_pieces[n]];clauses=[]
    for k,(a,A) in enumerate(ps):
        for b,B in ps[k+1:]:
            if a!=b:clauses.append([(0,a,b,B[0]-A[2]-q),(0,b,a,A[0]-B[2]-q),(1,a,b,B[1]-A[3]-q),(1,b,a,A[1]-B[3]-q)])
    assert len(clauses)==12;verify(cert['proof'],matrices,clauses);excluded.add(whole)
retained=[list(t) for t in initial if t not in excluded];assert retained==load(BASE/'retained-triples.json')
proved=[]
for di,d in enumerate(domains):
    ns=set(d['nodes']);remaining=[t for t in retained if set(t)<=ns]
    assert d['retained_triples']==remaining and d['maximum_two_brackets_proven_pending_audit']==(not remaining)
    if not remaining:proved.append({'domain':di,'nodes':d['nodes'],'uses':d['uses'],'maximum_brackets':2})
checks=load(BASE/'checks.json');assert checks['cap_overrun_seconds']==0 and len(excluded)<=checks['processed_triples']<=len(initial)
assert checks['scan_complete']==(checks['processed_triples']==len(initial))
assert checks['initial_triples']==len(initial) and checks['retained_triples']==len(retained) and checks['excluded_triples_pending_audit']==len(excluded)
write(OUT/'source-bindings.json',bindings);write(OUT/'maximum-two-bracket-domains.json',proved);write(OUT/'retained-triples.json',retained)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','nodes.json','domains.json','pair-certificates.json','compatible-pairs.json','initial-triples.json','exclusion-certificates.json','retained-triples.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Reconstruct every selected component from the authoritative source count table. Verify exact original hull interval extrema and contained rectangles, every incompatible pair, and complete pair-compatible triple enumeration including repetitions. Use full Floyd-Warshall closure in independently verified exact rational units to audit every branch and contradiction; only components with no surviving triple have capacity at most2.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_nodes_verified':len(nodes),'source_domains_verified':len(domains),'pair_exclusions_verified':len(bad),'complete_disjunction_trees_verified':len(excluded),'tree_nodes_verified':trees,'contradiction_leaves_verified':leaves,'complete_split_nodes_verified':splits,'rational_closed_branches_verified':branches,'retained_necessary_triples':len(retained),'all_unprocessed_triples_retained':True,'producer_scan_complete':checks['scan_complete'],'exact_rational_unit_denominator':str(unit),'maximum_two_bracket_domains':len(proved),'any_placement_proven':False,'count_distribution_application_pending':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
