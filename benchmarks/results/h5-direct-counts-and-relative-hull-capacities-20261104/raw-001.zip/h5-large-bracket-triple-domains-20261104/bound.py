"""Exact necessary three-bracket domains in all remaining larger source components."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import lcm
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
COUNT=ROOT/'output/h5-first55-higher-bracket-filtered-20261104'
PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
OUT=ROOT/'output/h5-large-bracket-triple-domains-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
rows=load(COUNT/'all-filtered-bounds.json');unary=load(PRIOR/'integer-preparation/unary-templates.json');inner=load(GEN/'source-inner-rectangles.json')
q=F(149,1000);assert 2*q*q<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
groups={}
for row in rows:
    for gi,g in enumerate(row['groups']):
        if g['family']!='bracket' or max(d[gi] for d in row['remaining_distributions'])<3:continue
        keys=tuple(sorted({tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi}))
        if not 42<=len(keys)<=200:continue
        groups.setdefault(keys,[]).append({'empty_sites':row['empty_sites'],'group':gi,'counts':[d[gi] for d in row['remaining_distributions']]})
domains=[];nodes=[];node_map={}
for keys,uses in sorted(groups.items(),key=lambda r:(len(r[0]),r[0])):
    ids=[]
    for key in keys:
        if key not in node_map:
            family,mode,gid,ri=key
            hull=[list(map(F,p)) for p in next(r for r in unary[gid]['regions'] if r['region']==ri)['hull_vertices']]
            bounds=[min(p[k] for p in hull) for k in [0,1]]+[max(p[k] for p in hull) for k in [0,1]]
            node_map[key]=len(nodes);nodes.append({'key':list(key),'translation_bounds_mm':[str(v) for v in bounds],'contained_rectangles_mm':inner[family][mode]})
        ids.append(node_map[key])
    domains.append({'nodes':ids,'uses':uses})
bounds=[list(map(F,n['translation_bounds_mm'])) for n in nodes]
pieces=[[list(map(F,r)) for r in n['contained_rectangles_mm']] for n in nodes]
needed=sorted({pair for d in domains for pair in combinations_with_replacement(d['nodes'],2)})
compatible=set();pair_certs=[]
for a,b in needed:
    A,B=bounds[a],bounds[b];bad=None
    for ai,r in enumerate(pieces[a]):
        for bi,s in enumerate(pieces[b]):
            maxima=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
            if max(maxima)<q:bad={'nodes':[a,b],'pieces':[ai,bi],'maximum_gaps_mm':[str(v) for v in maxima]};break
        if bad:break
    if bad:pair_certs.append(bad)
    else:compatible.add((a,b))
initial=sorted({triple for d in domains for triple in combinations_with_replacement(d['nodes'],3) if all((a,b) in compatible for a,b in [(triple[0],triple[1]),(triple[0],triple[2]),(triple[1],triple[2])])})
visited=0;timed_out=False
def domain(whole):
    bs=[bounds[i] for i in whole];ps=[(o,r) for o,i in enumerate(whole) for r in pieces[i]]
    scale=lcm(q.denominator,*(v.denominator for b in bs for v in b),*(v.denominator for o,r in ps for v in r))
    bs=[[int(v*scale) for v in b] for b in bs];ps=[(o,[int(v*scale) for v in r]) for o,r in ps];gap=int(q*scale)
    matrices=[]
    for axis in [0,1]:
        lo=[b[axis] for b in bs]+[0];hi=[b[axis+2] for b in bs]+[0]
        matrices.append([[0 if i==j else hi[i]-lo[j] for j in range(4)] for i in range(4)])
    clauses=[]
    for k,(a,A) in enumerate(ps):
        for b,B in ps[k+1:]:
            if a==b:continue
            clauses.append([(0,a,b,B[0]-A[2]-gap),(0,b,a,A[0]-B[2]-gap),(1,a,b,B[1]-A[3]-gap),(1,b,a,A[1]-B[3]-gap)])
    return matrices,clauses
def search(matrices,clauses):
    global visited,timed_out
    visited+=1
    if time.perf_counter()-started>=58:timed_out=True;return 'unknown',None
    chosen=None
    for ci,clause in enumerate(clauses):
        if any(matrices[axis][a][b]<=c for axis,a,b,c in clause):continue
        possible=[di for di,(axis,a,b,c) in enumerate(clause) if matrices[axis][b][a]+c>=0]
        if not possible:return 'excluded',{'contradiction_clause':ci}
        if chosen is None or len(possible)<len(chosen[1]):chosen=(ci,possible)
    if chosen is None:return 'relaxed',None
    ci,possible=chosen;children=[]
    for di in possible:
        axis,a,b,c=clauses[ci][di];old=matrices[axis]
        new=[[min(old[i][j],old[i][a]+c+old[b][j]) for j in range(4)] for i in range(4)]
        assert all(new[i][i]==0 for i in range(4))
        updated=matrices[:];updated[axis]=new;status,proof=search(updated,clauses)
        if status!='excluded':return status,None
        children.append({'direction':di,'proof':proof})
    return 'excluded',{'split_clause':ci,'children':children}
certs=[];retained=[];processed=0
for whole in initial:
    if time.perf_counter()-started>=58:timed_out=True;break
    status,proof=search(*domain(whole))
    if status=='excluded':certs.append({'nodes':list(whole),'proof':proof})
    else:retained.append(list(whole))
    processed+=1
    if timed_out:break
retained.extend(list(t) for t in initial[processed:]);survivors={tuple(r) for r in retained}
for d in domains:
    n=set(d['nodes']);d['retained_triples']=[list(t) for t in initial if set(t)<=n and t in survivors]
    d['maximum_two_brackets_proven_pending_audit']=not d['retained_triples']
elapsed=time.perf_counter()-started
inputs=[Path(__file__),FIRST/'plan.json',PRIOR/'integer-preparation/unary-templates.json',GEN/'source-inner-rectangles.json',GEN/'audit/plan.json',GEN/'audit/checks.json']+[COUNT/n for n in ['plan.json','all-filtered-bounds.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Extract every remaining source bracket component with 42to200 mode/region options and a required count at least3. Preserve mode aliases and repeated options. Exclude pairs only by an impossible149/1000mm axis-gap disjunction between contained source rectangles. Enumerate every pair-compatible triple and prove impossible difference-bound disjunctions using exact scaled integers. Keep every relaxed or unprocessed triple. Separate exact rational Floyd closure must audit every proof before count filtering.','gap_mm':str(q),'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'packing_solver_calls':0,'native_calls':0})
for name,data in [('nodes.json',nodes),('domains.json',domains),('pair-certificates.json',pair_certs),('compatible-pairs.json',[list(t) for t in sorted(compatible)]),('initial-triples.json',[list(t) for t in initial]),('exclusion-certificates.json',certs),('retained-triples.json',retained)]:write(OUT/name,data)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':not timed_out and processed==len(initial),'source_nodes':len(nodes),'source_domains':len(domains),'domain_uses':sum(len(d['uses']) for d in domains),'necessary_pairs':len(needed),'incompatible_pairs':len(pair_certs),'initial_triples':len(initial),'processed_triples':processed,'excluded_triples_pending_audit':len(certs),'retained_triples':len(retained),'maximum_two_bracket_domains_pending_audit':sum(d['maximum_two_brackets_proven_pending_audit'] for d in domains),'exact_search_nodes':visited,'independent_audit_required':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
