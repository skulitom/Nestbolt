from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-higher-bracket-filtered-20261104';TRIPLE=ROOT/'output/h5-direct-bracket-count-domains-20261104';BOUND=ROOT/'output/h5-direct-bracket-count-domains-20261104';OUT=ROOT/'output/h5-first55-direct-bracket-filtered-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRIOR/'audit/checks.json')['passed'] and load(BOUND/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'filter.py');started=time.perf_counter()
rows=load(PRIOR/'all-filtered-bounds.json');proved=load(BOUND/'audit/capacity-bounds.json');nodes=load(TRIPLE/'nodes.json');domains={d['domain']:{tuple(nodes[n]['key']) for n in d['nodes']} for d in proved}
caps={d['domain']:d['maximum_brackets'] for d in proved}
out=[];removed=[];empty=[]
for row in rows:
    remaining=[]
    for counts in row['remaining_distributions']:
        causes=[]
        for gi,g in enumerate(row['groups']):
            if g['family']!='bracket' or counts[gi]<3:continue
            keys={tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi}
            for di,source in domains.items():
                if keys and keys<=source and counts[gi]>caps[di]:causes.append({'group':gi,'domain':di,'count':counts[gi],'capacity':caps[di]})
        if causes:removed.append({'empty_sites':row['empty_sites'],'counts':counts,'certificates':causes})
        else:remaining.append(counts)
    if remaining:out.append({**row,'remaining_distributions':remaining})
    else:empty.append(row['empty_sites'])
elapsed=time.perf_counter()-started
inputs=[Path(__file__),TRIPLE/'nodes.json']+[PRIOR/n for n in ['plan.json','all-filtered-bounds.json','audit/plan.json','audit/checks.json']]+[BOUND/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','audit/capacity-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Remove a count distribution only when a required bracket count exceeds the independently audited source domain capacity and every original mode/region option of that component is covered. Preserve every other field of surviving original count rows.','packing_solver_calls':0,'native_calls':0})
for name,data in [('all-filtered-bounds.json',out),('removed-distributions.json',removed),('excluded-empty-site-pairs.json',empty)]:write(OUT/name,data)
checks={'passed':True,'seconds':elapsed,'original_site_choices':len(rows),'original_count_distributions':sum(len(r['remaining_distributions']) for r in rows),'removed_count_distributions':len(removed),'excluded_site_choices':empty,'remaining_site_choices':len(out),'remaining_count_distributions':sum(len(r['remaining_distributions']) for r in out),'remaining_allocation_candidates':440,'independent_audit_required':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
