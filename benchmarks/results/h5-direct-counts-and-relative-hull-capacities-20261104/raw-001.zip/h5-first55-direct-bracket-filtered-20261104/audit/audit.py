"""Audit count filtering independently from recorded causes and unchanged source rows."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-higher-bracket-filtered-20261104';TRIPLE=ROOT/'output/h5-direct-bracket-count-domains-20261104';BOUND=ROOT/'output/h5-direct-bracket-count-domains-20261104';BASE=ROOT/'output/h5-first55-direct-bracket-filtered-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(PRIOR/'audit/checks.json')['passed'] and load(BOUND/'audit/checks.json')['passed']
nodes=load(TRIPLE/'nodes.json');proved=load(BOUND/'audit/capacity-bounds.json');domains={d['domain']:set(tuple(nodes[i]['key']) for i in d['nodes']) for d in proved}
caps={d['domain']:d['maximum_brackets'] for d in proved}
original=load(PRIOR/'all-filtered-bounds.json');remaining=load(BASE/'all-filtered-bounds.json');removed=load(BASE/'removed-distributions.json');lookup={tuple(r['empty_sites']):r for r in original};rm={}
for row in removed:
    sites=tuple(row['empty_sites']);source=lookup[sites];counts=tuple(row['counts']);assert list(counts) in source['remaining_distributions']
    assert (sites,counts) not in rm and row['certificates'];rm[(sites,counts)]=row
    for cert in row['certificates']:
        gi=cert['group'];assert source['groups'][gi]['family']=='bracket' and counts[gi]==cert['count']>cert['capacity']==caps[cert['domain']]
        keys={tuple(a[:4]) for a in source['region_component_assignments'] if a[4]==gi};assert keys and keys<=domains[cert['domain']]
expected=[];excluded=[];attributions=0
for row in original:
    sites=tuple(row['empty_sites']);keep=[]
    for counts in row['remaining_distributions']:
        applicable=[]
        for gi,g in enumerate(row['groups']):
            if g['family']=='bracket' and counts[gi]>=3:
                keys={tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi}
                for di,domain in domains.items():
                    if keys and not keys-domain and counts[gi]>caps[di]:applicable.append({'group':gi,'domain':di,'count':counts[gi],'capacity':caps[di]})
        assert bool(applicable)==((sites,tuple(counts)) in rm)
        if applicable:assert rm[(sites,tuple(counts))]['certificates']==applicable
        else:keep.append(counts)
    if keep:expected.append({**row,'remaining_distributions':keep});attributions+=len(row['region_component_assignments'])
    else:excluded.append(row['empty_sites'])
assert remaining==expected and excluded==load(BASE/'excluded-empty-site-pairs.json')
checks=load(BASE/'checks.json');assert checks['remaining_count_distributions']==sum(len(r['remaining_distributions']) for r in expected) and checks['remaining_site_choices']==len(expected) and checks['removed_count_distributions']==len(rm)
write(OUT/'source-bindings.json',bindings);write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in expected])
inputs=[Path(__file__),TRIPLE/'nodes.json']+[BASE/n for n in ['plan.json','checks.json','all-filtered-bounds.json','removed-distributions.json','excluded-empty-site-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'removed_count_distributions_verified':len(rm),'excluded_site_choices_verified':excluded,'remaining_site_choices':len(expected),'remaining_count_distributions':sum(len(r['remaining_distributions']) for r in expected),'remaining_source_mode_attributions_verified':attributions,'all_surviving_source_fields_unchanged':True,'remaining_allocation_candidates':440,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
