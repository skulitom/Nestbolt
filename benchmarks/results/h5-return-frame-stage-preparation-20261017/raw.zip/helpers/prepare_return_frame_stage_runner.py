from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'scripts/h5_complete_stage_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5_complete_set_pilot','h5_return_frame_pilot').replace('h5-complete-set-pilot','h5-return-frame-pilot')
s=s.replace('h5-complete-stage','h5-return-frame-stage')
s=s.replace('Observe proposal filtering and repair stages in the rejected complete-set candidate.',
            'Observe frame legality, returned poses, repair losses and material rejection in the rejected return-frame candidate.')
s=s.replace('import json\n','import json\nimport math\n')
s=s.replace('def read_trace(archive, record):',(root/'output/check_return_frame_trace_snippet.py').read_text(encoding='utf-8')+'\ndef read_trace(archive, record):')
s=s.replace('    for attempt in attempts:\n','    for attempt in attempts:\n        check_frame_attempt(attempt)\n')
s=s.replace("'source_change':'Aggregate sampling eligibility, eligible full sets by returned-area relation, retained proposal counts and repair-stage outcomes; one stderr trace per exchange invocation.'",
            "'source_change':'Previous sampling/repair stages plus incoming/victim/actual/hypothetical poses, per-member orientation legality, frame/fallback mode, initial/final losses and independent before/after material; one stderr trace per exchange invocation.'")
s=s.replace("'proposals':sum(t['proposals'] for t in traces), 'traces':traces}",
            "'frame_modes':dict(Counter(a['frame']['mode'] for a in attempts)),\n        'outcomes_by_frame':{mode:dict(Counter(a['outcome'] for a in attempts if a['frame']['mode']==mode)) for mode in sorted({a['frame']['mode'] for a in attempts})},\n        'proposals':sum(t['proposals'] for t in traces), 'traces':traces}")
p=root/'scripts/h5_return_frame_stage_diagnosis.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared serial four-case observer runner with frame and material trace validation.')
