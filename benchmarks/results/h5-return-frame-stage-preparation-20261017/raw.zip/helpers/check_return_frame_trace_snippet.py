def check_frame_attempt(attempt):
    frame=attempt['frame'];members=frame['members']
    assert len(members)==attempt['victims'] and members
    assert frame['mode'] in ['single','same_frame_translation','reciprocal','forbidden_translation']
    def pose(p):
        assert isinstance(p['reflected'],bool)
        assert len(p['translation'])==2
        assert all(isinstance(x,(float,int)) and math.isfinite(x) for x in [p['rotation'],*p['translation']])
    for p in [frame['incoming_before'],frame['incoming_here']]:pose(p)
    for member in members:
        assert isinstance(member['external_id'],int) and member['external_id']>=0
        assert isinstance(member['hypothetical_allowed'],bool) and member['actual_allowed'] is True
        for key in ['previous','hypothetical','actual']:pose(member[key])
    before,here=frame['incoming_before'],frame['incoming_here']
    same=before['rotation']==here['rotation'] and before['reflected']==here['reflected']
    if len(members)==1:
        assert frame['mode']=='single'
    elif same:
        assert frame['mode']=='same_frame_translation'
    elif all(m['hypothetical_allowed'] for m in members):
        assert frame['mode']=='reciprocal'
        assert all(m['actual']==m['hypothetical'] for m in members)
    else:
        assert frame['mode']=='forbidden_translation'
    if frame['mode'] in ['same_frame_translation','forbidden_translation']:
        for m in members:
            a,p=m['actual'],m['previous']
            assert a['rotation']==p['rotation'] and a['reflected']==p['reflected']
            for axis in [0,1]:
                expected=p['translation'][axis]+before['translation'][axis]-here['translation'][axis]
                # Trace coordinates are serialized f32. This checks the mapping,
                # not geometric validity, which has the unchanged public validator.
                scale=max(1,abs(p['translation'][axis]),abs(before['translation'][axis]),abs(here['translation'][axis]))
                assert abs(a['translation'][axis]-expected)<=5e-7*scale
    assert math.isfinite(attempt['before_material']) and attempt['before_material']>0
    if attempt['after_material'] is not None:
        assert math.isfinite(attempt['after_material']) and attempt['after_material']>0
    if attempt['outcome']=='accepted':
        assert attempt['after_material'] is not None and attempt['after_material']<=attempt['before_material']
        assert attempt['receiver_loss']==attempt['source_loss']==0
    for key in ['receiver_initial_loss','source_initial_loss','receiver_loss','source_loss']:
        value=attempt[key]
        assert value is None or (math.isfinite(value) and value>=0)

