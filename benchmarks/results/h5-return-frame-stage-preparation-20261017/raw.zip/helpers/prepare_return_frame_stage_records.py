from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/seal_h5_complete_stage_preparation.py').read_text(encoding='utf-8')
s=s.replace('h5-complete-stage','h5-return-frame-stage').replace('build_h5_complete_stage','build_h5_return_frame_stage')
s=s.replace('85 passed','90 passed').replace("'optimized_core_tests_passed':85","'optimized_core_tests_passed':90")
s=s.replace('prepare_complete_stage_drivers.py','prepare_return_frame_diagnostic_driver.py')
s=s.replace('out.mkdir(exist_ok=False)',"""reader=load(probe/'authored-trace-reader/checks.json');assert reader['all_checks_pass']
assert reader['reader_sha256']==digest(root/'scripts/h5_return_frame_stage_diagnosis.py')
out.mkdir(exist_ok=False)""")
s=s.replace("inventory={name:","""for name in ['prepare_return_frame_stage_runner.py','prepare_return_frame_stage_records.py',
             'check_return_frame_trace_snippet.py','check_return_frame_stage_reader.py']:
    files['helpers/'+name]=root/'output'/name
files['diagnostic-runner.py']=root/'scripts/h5_return_frame_stage_diagnosis.py'
inventory={name:""")
s=s.replace("'completed_weight_percent':60,'H5_complete':False", "'authored_reader_traces':2,'malformed_records_rejected':5,\n    'completed_weight_percent':60,'H5_complete':False")
start=s.index("(out.parent/(out.name+'.md')).write_text(")
end=s.index("with (root/'.gitattributes')",start)
doc='''# Return-frame decision and repair diagnostic preparation — 2026-10-17

An isolated instrumented copy of the rejected return-frame candidate passes
90 optimized core tests, strict lint and its observer build. It records each
attempt's incoming, original victim, hypothetical and actual return poses;
per-member orientation legality; reciprocal, same-frame, forbidden-orientation
fallback or single-victim mode; initial/final repair losses; and independently
validated before/after material. Earlier sampling and stage counters remain.

Two existing authored tests are captured specifically to verify the new trace
reader. One completes a reciprocal exchange; the other retains the incumbent
when a valid repair raises measured material by 0.0007 mm². Both tests pass and
their traces validate. Five malformed-record mutations are rejected, including
false frame category, forbidden/nonfinite actual poses, unresolved accepted
repair and accepted material increase. The f32-coordinate consistency check
does not change the separate public geometry validator or its tolerances.

Reversing instrumentation restores exact original text before formatting;
every other source file, production and the rejected candidate stay unchanged.
Proposal choices, orientations, repair settings, work charges and deadlines are
unchanged. Logging can perturb wall deadlines, so these observations cannot
establish quality or speed improvement. All source/binary/log/archive members
and CRC are verified.

The rejected 72-outcome pilot retains four failed mechanical material pairs,
11 accepted exchanges from 71 attempts, and none on panel hardware. Four serial
observations are planned only after their plan is committed: both mechanical
jobs, both kerfs, seed zero, 60 seconds, physical CCD0 CPU 8. They locate causes
without repeating the unchanged quality comparison. H2/H5 remain open at 60%.
'''
s=s[:start]+"(out.parent/(out.name+'.md')).write_text("+repr(doc)+",encoding='utf-8',newline='\\n')\n"+s[end:]
start=s.index("with (root/'BENCHMARKS.md')")
end=s.index('print(json.dumps(',start)
note='''

## 2026-10-17 — Prepare return-frame legality and repair-stage observations

[The isolated observer](benchmarks/results/h5-return-frame-stage-preparation-20261017.md)
passes 90 optimized core tests, strict lint and its build. Two existing authored
tests supply real traces to qualify the new reader; five malformed mutations
are rejected, including accepted material increase and false frame categories.
The original guarded 0.0007 mm² increase remains a rejection. Per-attempt poses,
orientation legality/fallback, initial/final repair loss and material metrics
will distinguish causes that aggregate counters cannot identify.

Instrumentation reverses to exact original source before formatting; other
source files and production stay unchanged. Every archive member and CRC verifies.
Four serial 60-second seed-zero observations on the same two mechanical jobs
and kerfs are planned on CCD0 CPU 8 after committing the plan. No quality claim,
relaxed limit, reserved-input access or milestone credit. H2/H5 remain open, 60%.
'''
s=s[:start]+"with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\\n') as f:f.write("+repr(note)+")\n"+s[end:]
p=root/'output/seal_h5_return_frame_stage_preparation.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/finish_h5_complete_stage_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5_complete_stage_diagnosis','h5_return_frame_stage_diagnosis').replace('h5-complete-stage','h5-return-frame-stage')
s=s.replace('Complete-set eligibility and repair diagnosis','Return-frame legality and repair diagnosis')
s=s.replace("write(out/'observed-stages.json',", """frame_modes=dict(Counter(a['frame']['mode'] for a in attempts))
by_frame={mode:dict(Counter(a['outcome'] for a in attempts if a['frame']['mode']==mode)) for mode in sorted(frame_modes)}
write(out/'observed-frames.json',{'frame_modes':frame_modes,'outcomes_by_frame':by_frame,
    'forbidden_member_counts':dict(Counter(str(sum(not m['hypothetical_allowed'] for m in a['frame']['members'])) for a in attempts if a['frame']['mode']=='forbidden_translation')),
    'validated_material_changes':[{'before':a['before_material'],'after':a['after_material'],'outcome':a['outcome']} for a in attempts if a['after_material'] is not None],
    'quality_claim':False})
write(out/'observed-stages.json',""")
s=s.replace("    'retain sample eligibility, returned-area ratios and both repair losses.',", "    'retain sample eligibility, returned-area ratios and both repair losses.',\n    '[Frame observations](h5-return-frame-stage-diagnosis-20261017/observed-frames.json)',\n    'retain orientation modes, per-mode outcomes and validated material changes.',")
s=s.replace("'sampling':dict(sampling),'wall_seconds'", "'sampling':dict(sampling),'frame_modes':frame_modes,'outcomes_by_frame':by_frame,'wall_seconds'")
p=root/'output/finish_h5_return_frame_stage_diagnosis.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared guarded evidence sealing and full stage/frame verification.')
