"""Extend the existing reversible observer with frame legality and material observations."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/prepare_h5_complete_stage_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5-complete-stage','h5-return-frame-stage').replace('h5-complete-set-probe','h5-return-frame-probe')
s=s.replace('bdf31c479b78844075b90333ad33bff79aa50e10d60a0df229fd0411995ed291','17e9c64a28399e42c1212357b93058bf1ea5a4f3d91206432e53adf401a8d912')
assert s.count('impl<F:')==2;s=s.replace('impl<F:','// Only choose')
needle='    receiver_loss: Option<f32>,\n    source_loss: Option<f32>,'
assert s.count(needle)==1
s=s.replace(needle,'''    receiver_loss: Option<f32>,
    source_loss: Option<f32>,
    receiver_initial_loss: Option<f32>,
    source_initial_loss: Option<f32>,
    before_material: f64,
    after_material: Option<f64>,
    frame: serde_json::Value,''')
needle='                        receiver_loss: None, source_loss: None, outcome: "unfinished",'
assert s.count(needle)==1
s=s.replace(needle,'''                        receiver_loss: None, source_loss: None, outcome: "unfinished",
                        receiver_initial_loss: None, source_initial_loss: None,
                        before_material: before.material_area, after_material: None,
                        frame: serde_json::Value::Null,''')
extra='''
frame_helper = r''' + "'''" + '''
fn observed_pose(pose: DTransformation) -> serde_json::Value {
    serde_json::json!({"rotation":pose.rotation(),"reflected":pose.reflected,"translation":pose.translation()})
}

fn observed_return_frame(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    here: DTransformation,
    old: DTransformation,
    actual: &[DTransformation],
) -> serde_json::Value {
    let same = here.rotation() == old.rotation() && here.reflected == old.reflected;
    let frame = here.compose().inverse().transform(&old.compose());
    let hypothetical: Vec<_> = victims.iter().map(|(_,item,previous)| {
        let pose=previous.compose().transform(&frame).decompose();
        (pose,item.allowed_orientations().allows(&pose))
    }).collect();
    let mode = if victims.len()==1 {"single"} else if same {"same_frame_translation"}
        else if hypothetical.iter().all(|(_,allowed)|*allowed) {"reciprocal"} else {"forbidden_translation"};
    let members: Vec<_> = victims.iter().zip(actual).zip(hypothetical).map(|(((_,item,previous),actual),(hypothetical,allowed))| {
        serde_json::json!({"external_id":item.external_id(),"previous":observed_pose(*previous),
            "hypothetical":observed_pose(hypothetical),"hypothetical_allowed":allowed,
            "actual":observed_pose(*actual),"actual_allowed":item.allowed_orientations().allows(actual)})
    }).collect();
    serde_json::json!({"mode":mode,"incoming_before":observed_pose(old),"incoming_here":observed_pose(here),"members":members})
}

''' + "'''" + '''
replace('struct Proposal {',frame_helper+'struct Proposal {')
replace('                    for ((_, victim, _), pose) in victims.iter().zip(returned) {',
        '                    trace.attempts[index].frame = observed_return_frame(&victims, proposal.incoming, incoming_old, &returned);\\n                    for ((_, victim, _), pose) in victims.iter().zip(returned) {')
replace('                    let (receiver_snapshot, receiver_tracker) =',
        '                    trace.attempts[index].receiver_initial_loss = Some(receiver_sep.tracker.total_loss());\\n                    let (receiver_snapshot, receiver_tracker) =')
replace('                    let (source_snapshot, source_tracker) =',
        '                    trace.attempts[index].source_initial_loss = Some(source_sep.tracker.total_loss());\\n                    let (source_snapshot, source_tracker) =')
replace('                    let after = report.metrics.as_ref().expect("valid exchange");',
        '                    let after = report.metrics.as_ref().expect("valid exchange");\\n                    trace.attempts[index].after_material = Some(after.material_area);')
'''
assert s.count('reverse=text')==1;s=s.replace('reverse=text',extra+'\nreverse=text')
s=s.replace('Identify current complete-set eligibility and actual complete/partial repair stages; no quality inference.',
            'Observe reciprocal-frame legality/fallback, actual poses, initial/final repair losses and independently validated material rejection. No quality inference or changed search decisions.')
s=s.replace('complete-set-original','return-frame-original')
target=root/'output/prepare_h5_return_frame_stage_diagnosis.py';assert not target.exists()
compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/build_h5_complete_stage_diagnosis.py').read_text(encoding='utf-8').replace('h5-complete-stage','h5-return-frame-stage')
# Guard production source as well as both isolated source inventories at every stage.
s=s.replace('def guards():\n',"def guards():\n    sys.path.insert(0,str(ROOT/'scripts'))\n    from h2_import_audit import source_digest\n    assert source_digest()==plan['production_digest']\n")
target=root/'output/build_h5_return_frame_stage_diagnosis.py';assert not target.exists()
compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
print('Prepared diagnostic source/build drivers; no diagnostic searches launched.')
