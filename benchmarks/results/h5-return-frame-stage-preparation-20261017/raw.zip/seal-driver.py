from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import sys
import zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-return-frame-stage-diagnosis-20261017'
out=root/'benchmarks/results/h5-return-frame-stage-preparation-20261017'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');assert build['all_passed']
assert digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '90 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
plan=load(probe/'preparation.json')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
reader=load(probe/'authored-trace-reader/checks.json');assert reader['all_checks_pass']
assert reader['reader_sha256']==digest(root/'scripts/h5_return_frame_stage_diagnosis.py')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
files['build-driver.py']=root/'output/build_h5_return_frame_stage_diagnosis.py'
files['seal-driver.py']=Path(__file__)
files['driver-preparation.py']=root/'output/prepare_return_frame_diagnostic_driver.py'
for name in ['prepare_return_frame_stage_runner.py','prepare_return_frame_stage_records.py',
             'check_return_frame_trace_snippet.py','check_return_frame_stage_reader.py']:
    files['helpers/'+name]=root/'output'/name
files['diagnostic-runner.py']=root/'scripts/h5_return_frame_stage_diagnosis.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:
    shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':90,'strict_lint_passed':True,
    'instrumented_observer_build_passed':True,'old_candidate_and_production_unchanged':True,
    'diagnostic_only':True,'quality_claim':False,'measured_search_started':False,
    'authored_reader_traces':2,'malformed_records_rejected':5,
    'completed_weight_percent':60,'H5_complete':False})
(out.parent/(out.name+'.md')).write_text("# Return-frame decision and repair diagnostic preparation — 2026-10-17\n\nAn isolated instrumented copy of the rejected return-frame candidate passes\n90 optimized core tests, strict lint and its observer build. It records each\nattempt's incoming, original victim, hypothetical and actual return poses;\nper-member orientation legality; reciprocal, same-frame, forbidden-orientation\nfallback or single-victim mode; initial/final repair losses; and independently\nvalidated before/after material. Earlier sampling and stage counters remain.\n\nTwo existing authored tests are captured specifically to verify the new trace\nreader. One completes a reciprocal exchange; the other retains the incumbent\nwhen a valid repair raises measured material by 0.0007 mm². Both tests pass and\ntheir traces validate. Five malformed-record mutations are rejected, including\nfalse frame category, forbidden/nonfinite actual poses, unresolved accepted\nrepair and accepted material increase. The f32-coordinate consistency check\ndoes not change the separate public geometry validator or its tolerances.\n\nReversing instrumentation restores exact original text before formatting;\nevery other source file, production and the rejected candidate stay unchanged.\nProposal choices, orientations, repair settings, work charges and deadlines are\nunchanged. Logging can perturb wall deadlines, so these observations cannot\nestablish quality or speed improvement. All source/binary/log/archive members\nand CRC are verified.\n\nThe rejected 72-outcome pilot retains four failed mechanical material pairs,\n11 accepted exchanges from 71 attempts, and none on panel hardware. Four serial\nobservations are planned only after their plan is committed: both mechanical\njobs, both kerfs, seed zero, 60 seconds, physical CCD0 CPU 8. They locate causes\nwithout repeating the unchanged quality comparison. H2/H5 remain open at 60%.\n",encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in ['h5-return-frame-stage-preparation-20261017','h5-return-frame-stage-diagnosis-20261017']:
        f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## 2026-10-17 — Prepare return-frame legality and repair-stage observations\n\n[The isolated observer](benchmarks/results/h5-return-frame-stage-preparation-20261017.md)\npasses 90 optimized core tests, strict lint and its build. Two existing authored\ntests supply real traces to qualify the new reader; five malformed mutations\nare rejected, including accepted material increase and false frame categories.\nThe original guarded 0.0007 mm² increase remains a rejection. Per-attempt poses,\norientation legality/fallback, initial/final repair loss and material metrics\nwill distinguish causes that aggregate counters cannot identify.\n\nInstrumentation reverses to exact original source before formatting; other\nsource files and production stay unchanged. Every archive member and CRC verifies.\nFour serial 60-second seed-zero observations on the same two mechanical jobs\nand kerfs are planned on CCD0 CPU 8 after committing the plan. No quality claim,\nrelaxed limit, reserved-input access or milestone credit. H2/H5 remain open, 60%.\n')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':raw.stat().st_size}))
