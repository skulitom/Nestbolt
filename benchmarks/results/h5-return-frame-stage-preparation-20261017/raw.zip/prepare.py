"""Instrument the rejected complete-set experiment without changing its decisions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib
import json
import shutil
import subprocess
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
out=root/'output/h5-return-frame-stage-diagnosis-20261017'
old=root/'output/h5-return-frame-probe-20261017/candidate'
work=out/'workspace'
out.mkdir(exist_ok=False)
shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs'
path=work/rel
original=path.read_text(encoding='utf-8')
assert sha256((old/rel).read_bytes()).hexdigest()=='17e9c64a28399e42c1212357b93058bf1ea5a4f3d91206432e53adf401a8d912'
text=original
changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,before
    text=text.replace(before,after)
    changes.append((before,after))
types='''// Diagnostic copy: aggregate observations only; no decision or budget changes.
#[derive(Default, serde::Serialize)]
struct ExchangeTrace {
    disabled_or_expired: bool,
    baseline_invalid: bool,
    proposals: usize,
    expired_before_attempt: usize,
    samplings: Vec<SamplingTrace>,
    attempts: Vec<AttemptTrace>,
}
#[derive(Default, serde::Serialize)]
struct SamplingTrace {
    incoming_area: f32,
    samples: usize,
    examined: usize,
    collision_free: usize,
    over_three_collisions: usize,
    non_item_collision: usize,
    multi_eligible_smaller: usize,
    multi_eligible_not_smaller: usize,
    smallest_not_smaller_area_ratio: Option<f32>,
    retained_victim_counts: Vec<usize>,
    retained_blocker_counts: Vec<usize>,
}
#[derive(serde::Serialize)]
struct AttemptTrace {
    incoming_area: f32,
    returned_area: f32,
    victims: usize,
    blockers: usize,
    receiver_loss: Option<f32>,
    source_loss: Option<f32>,
    receiver_initial_loss: Option<f32>,
    source_initial_loss: Option<f32>,
    before_material: f64,
    after_material: Option<f64>,
    frame: serde_json::Value,
    outcome: &'static str,
}
impl Drop for ExchangeTrace {
    fn drop(&mut self) {
        eprintln!("OBSTRUCTION_DIAG {}", serde_json::to_string(self).expect("diagnostic serialization"));
    }
}

'''
replace('struct Proposal {',types+'struct Proposal {')
replace('''    until: f64,
) -> Vec<Proposal> {''','''    until: f64,
    trace: &mut ExchangeTrace,
) -> Vec<Proposal> {
    let mut sampling = SamplingTrace { incoming_area: incoming.area(), ..Default::default() };''')
replace('''    for dt in samples {''','''    sampling.samples = samples.len();
    for dt in samples {''')
replace('''        crate::separate::charge(clock, incoming, 1);
        if collector.is_empty()''','''        crate::separate::charge(clock, incoming, 1);
        sampling.examined += 1;
        sampling.collision_free += usize::from(collector.is_empty());
        sampling.over_three_collisions += usize::from(collector.len() > 3);
        sampling.non_item_collision += usize::from(collector.iter().any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. })));
        if collector.is_empty()''')
replace('''        if blocked.len() > 1 {''','''        if blocked.len() > 1 {
            if area < incoming.area() {
                sampling.multi_eligible_smaller += 1;
            } else {
                sampling.multi_eligible_not_smaller += 1;
                let ratio = area / incoming.area();
                sampling.smallest_not_smaller_area_ratio = Some(sampling.smallest_not_smaller_area_ratio.map_or(ratio, |old| old.min(ratio)));
            }
        }
        if blocked.len() > 1 {''')
replace('''    out
}

// Only choose''','''    sampling.retained_victim_counts = out.iter().map(|p| p.victims.len()).collect();
    sampling.retained_blocker_counts = out.iter().map(|p| p.blockers).collect();
    trace.samplings.push(sampling);
    out
}

// Only choose''')
replace('''        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            return Ok(0);''','''        let mut trace = ExchangeTrace::default();
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            trace.disabled_or_expired = true;
            return Ok(0);''')
replace('''        if !baseline.valid {
            return Ok(0);''','''        if !baseline.valid {
            trace.baseline_invalid = true;
            return Ok(0);''')
replace('''                    proposal_until,
                );
                for proposal in candidates {''','''                    proposal_until,
                    &mut trace,
                );
                trace.proposals += candidates.len();
                for proposal in candidates {''')
replace('''                for proposal in candidates {
                    if self.clock.now() >= self.last_step(until) {
                        return Ok(0);''','''                for proposal in candidates {
                    if self.clock.now() >= self.last_step(until) {
                        trace.expired_before_attempt += 1;
                        return Ok(0);''')
replace('''                    self.stats.directed_exchange_attempts += 1;
                    let victims:''','''                    self.stats.directed_exchange_attempts += 1;
                    let index = trace.attempts.len();
                    trace.attempts.push(AttemptTrace {
                        incoming_area: incoming_item.area(), returned_area: proposal.area,
                        victims: proposal.victims.len(), blockers: proposal.blockers,
                        receiver_loss: None, source_loss: None, outcome: "unfinished",
                        receiver_initial_loss: None, source_initial_loss: None,
                        before_material: before.material_area, after_material: None,
                        frame: serde_json::Value::Null,
                    });
                    let victims:''')
replace('''                    if receiver_tracker.total_loss() > 0.0 {
                        continue;''','''                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());
                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[index].outcome = "receiver_repair_failed";
                        continue;''')
replace('''                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(until)
                    {
                        continue;''','''                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(until)
                    {
                        trace.attempts[index].outcome = if source_tracker.total_loss() > 0.0 { "source_repair_failed" } else { "expired_after_repairs" };
                        continue;''')
replace('''                    if !report.valid {
                        self.stats.rejected_layouts += 1;''','''                    if !report.valid {
                        trace.attempts[index].outcome = "independent_geometry_failed";
                        self.stats.rejected_layouts += 1;''')
replace('''                    {
                        continue;
                    }
                    sep.layout = trial;''','''                    {
                        trace.attempts[index].outcome = if self.clock.now() >= until { "expired_before_acceptance" } else { "material_guard_failed" };
                        continue;
                    }
                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;''')

frame_helper = r'''
fn observed_pose(pose: DTransformation) -> serde_json::Value {
    serde_json::json!({"rotation":pose.rotation(),"reflected":pose.reflected,"translation":pose.translation()})
}

fn observed_return_frame(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    here: DTransformation,
    old: DTransformation,
    actual: &[DTransformation],
) -> serde_json::Value {
    let same = here.rotation() == old.rotation() && here.reflected == old.reflected;
    let frame = here.compose().inverse().transform(&old.compose());
    let hypothetical: Vec<_> = victims.iter().map(|(_,item,previous)| {
        let pose=previous.compose().transform(&frame).decompose();
        (pose,item.allowed_orientations().allows(&pose))
    }).collect();
    let mode = if victims.len()==1 {"single"} else if same {"same_frame_translation"}
        else if hypothetical.iter().all(|(_,allowed)|*allowed) {"reciprocal"} else {"forbidden_translation"};
    let members: Vec<_> = victims.iter().zip(actual).zip(hypothetical).map(|(((_,item,previous),actual),(hypothetical,allowed))| {
        serde_json::json!({"external_id":item.external_id(),"previous":observed_pose(*previous),
            "hypothetical":observed_pose(hypothetical),"hypothetical_allowed":allowed,
            "actual":observed_pose(*actual),"actual_allowed":item.allowed_orientations().allows(actual)})
    }).collect();
    serde_json::json!({"mode":mode,"incoming_before":observed_pose(old),"incoming_here":observed_pose(here),"members":members})
}

'''
replace('struct Proposal {',frame_helper+'struct Proposal {')
replace('                    for ((_, victim, _), pose) in victims.iter().zip(returned) {',
        '                    trace.attempts[index].frame = observed_return_frame(&victims, proposal.incoming, incoming_old, &returned);\n                    for ((_, victim, _), pose) in victims.iter().zip(returned) {')
replace('                    let (receiver_snapshot, receiver_tracker) =',
        '                    trace.attempts[index].receiver_initial_loss = Some(receiver_sep.tracker.total_loss());\n                    let (receiver_snapshot, receiver_tracker) =')
replace('                    let (source_snapshot, source_tracker) =',
        '                    trace.attempts[index].source_initial_loss = Some(source_sep.tracker.total_loss());\n                    let (source_snapshot, source_tracker) =')
replace('                    let after = report.metrics.as_ref().expect("valid exchange");',
        '                    let after = report.metrics.as_ref().expect("valid exchange");\n                    trace.attempts[index].after_material = Some(after.material_area);')

reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1,after
    reverse=reverse.replace(after,before)
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='return-frame-original',tofile='diagnostic-only')),encoding='utf-8',newline='\n')
files=[{'path':p.relative_to(old).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(old.rglob('*')) if p.is_file()]
plan={'utc':datetime.now(timezone.utc).isoformat(),'old_source':str(old),'changed_file':rel,'source_files':files,
    'production_digest':source_digest(),'target':str(root/'output/h5-return-frame-stage-target-20261017'),
    'instrumentation_reversible_to_exact_original_text':True,'proposal_repair_acceptance_settings_unchanged':True,
    'purpose':'Observe reciprocal-frame legality/fallback, actual poses, initial/final repair losses and independently validated material rejection. No quality inference or changed search decisions.',
    'measurement_planned':{'jobs':['m-mechanical-large-plates','m-mechanical-panel-hardware'],'kerfs':[0.2,1.5],'seed':0,'seconds':60,'cpu':8,'serial':True}}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'files':len(files),'production_digest':plan['production_digest']}))
