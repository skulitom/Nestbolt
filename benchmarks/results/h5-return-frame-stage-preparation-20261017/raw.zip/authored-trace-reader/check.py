"""Capture two existing authored tests to exercise the new trace reader, never score quality."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-return-frame-stage-diagnosis-20261017'
sys.path.insert(0,str(root/'scripts'));import h5_return_frame_stage_diagnosis as runner
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_passed']
out=probe/'authored-trace-reader';out.mkdir()
target=Path(load(probe/'preparation.json')['target'])
binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
binary=binaries[0];rows=[];attempts=[]
for name in ['directed_exchange_uses_the_rotated_return_gap','return_frame_keeps_incumbent_when_roundoff_increases_charged_material']:
    command=[str(binary),'--exact','sheets::vstrip::exchange::tests::'+name,'--nocapture']
    result=subprocess.run(command,cwd=probe/'workspace',capture_output=True,timeout=120)
    (out/(name+'-stdout.log')).write_bytes(result.stdout);(out/(name+'-stderr.log')).write_bytes(result.stderr)
    row={'test':name,'command':command,'exit_code':result.returncode}
    rows.append(row)
    assert result.returncode==0,(name,result.stderr.decode(errors='replace'))
    traces=[json.loads(line.removeprefix('OBSTRUCTION_DIAG ')) for line in result.stderr.decode().splitlines() if line.startswith('OBSTRUCTION_DIAG ')]
    assert traces
    observed=[a for t in traces for a in t['attempts']]
    for a in observed:runner.check_frame_attempt(a)
    attempts+=observed;row['attempts']=len(observed)
    row['outcomes']=dict(runner.Counter(a['outcome'] for a in observed));row['modes']=dict(runner.Counter(a['frame']['mode'] for a in observed))
    (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
accepted=next(a for a in attempts if a['outcome']=='accepted')
guarded=next(a for a in attempts if a['outcome']=='material_guard_failed' and a['after_material']>a['before_material'])
assert accepted['frame']['mode']=='reciprocal'
def rejects(name,mutate):
    value=copy.deepcopy(accepted);mutate(value)
    try:runner.check_frame_attempt(value)
    except AssertionError:return name
    raise AssertionError('Trace reader accepted '+name)
rejected=[rejects('accepted material increase',lambda a:a.update(after_material=a['before_material']+1)),
          rejects('accepted unresolved repair',lambda a:a.update(source_loss=1)),
          rejects('false reciprocal frame category',lambda a:a['frame'].update(mode='forbidden_translation')),
          rejects('forbidden actual orientation',lambda a:a['frame']['members'][0].update(actual_allowed=False)),
          rejects('nonfinite actual pose',lambda a:a['frame']['members'][0]['actual'].update(rotation=float('nan')))]
record={'all_checks_pass':True,'purpose':__doc__,'test_binary_sha256':digest(binary),'reader_sha256':digest(root/'scripts/h5_return_frame_stage_diagnosis.py'),
        'authored_test_traces':rows,'malformed_records_rejected':rejected,'strict_material_rejection_observed':True,
        'guarded_material_increase_mm2':guarded['after_material']-guarded['before_material'],
        'measured_development_searches':0,'quality_claim':False}
(out/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check.py')
print(json.dumps(record))
