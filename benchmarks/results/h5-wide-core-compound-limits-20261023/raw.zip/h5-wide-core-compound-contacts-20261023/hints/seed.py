"""Eighty fresh hints preserving the improved original 64-part seed."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations
import gzip,json,shutil,time
from build_h5_wide_core_compound_contacts import ROOT,OUT as BASE,load,write,digest
RED=BASE/'reduced';OUT=BASE/'hints'
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    mp=load(RED/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=[0]*len(ids)
    with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);mask=sum(1<<j for j in row)
            for j in row:adj[j]|=mask^(1<<j)
    weights=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights'];caps={'bracket':12,'insert':21};family=[pool[i]['placement']['part_id'] for i in ids];poses=[pool[i]['placement'] for i in ids]
    orders=[]
    def coordinate(j,kind,reverse):
        p=poses[j];x,y=p['transform']['translation'];sheet=(p['sheet_id']=='sheet-1')^reverse
        if kind=='degree':return (adj[j].bit_count(),sheet,y,x,ids[j])
        return (sheet,-y if kind=='top-left' else y,-x if kind=='bottom-right' else x,ids[j])
    for f in permutations(caps):
        for kind in ['bottom-left','top-left','bottom-right','degree']:
            for reverse in [False,True]:
                rank={name:i for i,name in enumerate(f)};orders.append(({'families':list(f),'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:(rank[family[j]],coordinate(j,kind,reverse)))))
    for kind in ['area','degree-per-area']:
        for reverse in [False,True]:
            orders.append(({'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:((poses[j]['sheet_id']=='sheet-1')^reverse,-weights[family[j]] if kind=='area' else Fraction(adj[j].bit_count(),weights[family[j]]),adj[j].bit_count(),ids[j]))))
    seed=[local[i] for i in mp['seed_candidates']];assert Counter(family[j] for j in seed)==Counter(bracket=10,insert=21)
    starts=[{'kind':'empty','indices':[]},{'kind':'mapped-64','indices':seed}]+[{'kind':'release-'+f,'indices':[j for j in seed if family[j]!=f]} for f in caps];cases=[(s,d,o) for s in starts for d,o in orders];assert len(cases)==80
    inputs=[BASE/n for n in ['plan.json','candidates.json','audit/checks.json']]+[RED/n for n in ['mapping.json','cliques.jsonl.gz','checks.json','substitutions.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_cases':80,'ordering_specs':[d for d,o in orders],'starts':starts,'method':'Try twenty deterministic orders from the empty small set, the exact freshly mapped 64-part seed, and the seed with brackets or inserts released. Add only mutually compatible poses under original quantities. Verify every result from the final ids and keep the original 64-part area unless strictly improved. Preserve all pending cases; no prior census or solver is resumed.'})
    best={'source':'mapped-original-64','selected_small_candidates':mp['seed_candidates'],'counts':dict(Counter(family[j] for j in seed)),'objective':sum(weights[family[j]] for j in seed)};baseline=best['objective'];assert baseline==815800000
    hints=[];start=time.perf_counter()
    for initial,description,order in cases:
        if time.perf_counter()-start>=30:break
        chosen=initial['indices'].copy();counts=Counter(family[j] for j in chosen);mask=sum(1<<j for j in chosen);assert all(not(adj[j]&mask) for j in chosen)
        for j in order:
            if counts[family[j]]>=caps[family[j]] or (mask>>j)&1 or adj[j]&mask:continue
            chosen.append(j);mask|=1<<j;counts[family[j]]+=1
            if counts==caps:break
        r={'index':len(hints),'source':initial['kind'],'ordering':description,'selected_small_candidates':sorted(ids[j] for j in chosen),'counts':dict(counts),'objective':sum(weights[family[j]] for j in chosen)};hints.append(r)
        if r['objective']>best['objective']:best=r
    elapsed=time.perf_counter()-start
    for r in hints+[best]:
        chosen=[local[i] for i in r['selected_small_candidates']];mask=sum(1<<j for j in chosen);counts=Counter(family[j] for j in chosen)
        assert len(chosen)==len(set(chosen)) and dict(counts)==r['counts'] and all(counts[f]<=caps[f] for f in caps) and all(not(adj[j]&mask) for j in chosen) and sum(weights[family[j]] for j in chosen)==r['objective']
    write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best);write(OUT/'pending.json',[{'start':s['kind'],'ordering':d} for s,d,o in cases[len(hints):]])
    checks={'passed':True,'seconds':elapsed,'planned_cases':80,'completed_cases':len(hints),'pending_cases':80-len(hints),'limit_reached':elapsed>=30,'every_result_full_graph_counts_score_checked':True,'original_64_part_seed_score':baseline,'original_seed_preserved':best['objective']>=baseline,'best_hint':{k:v for k,v in best.items() if k!='selected_small_candidates'},'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
