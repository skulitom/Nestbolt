"""Prepare fresh compound contacts against the improved 64-part layout's core."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def renamed(s):
    return s.replace('tall_small_compound','wide_core_compound').replace('h5-tall-small-compound','h5-wide-core-compound').replace('tall-frame-cog-core','wide-frame-cog-core').replace('tall-small-compound-contact','wide-core-compound-contact')
outputs={}
s=renamed((ROOT/'build_h5_tall_small_compound_contacts.py').read_text(encoding='utf-8'))
s=replace(s,"OLD=ROOT/'output/h5-two-sheet-cog-group-choice-20261023';CORE=ROOT/'output/h5-tall-frame-cog-subassembly-20261023'","OLD=ROOT/'output/h5-latest-wide-joint-20261023';CORE=ROOT/'output/h5-latest-wide-compound-core-20261023'")
s=s.replace('tall-frame 8+4+3 core','improved wide-frame 12+3 core').replace('18 tall frames and 15 cogs in an 8+4+3 arrangement','18 wide frames and 15 cogs from the improved 64-part layout, split 12+3 across sheets')
s=replace(s,"CORE/'layout.json',CORE/'checks.json'","CORE/'layout.json',CORE/'checks.json',CORE/'source-seed.json',CORE/'mapping.json'")
s=replace(s,"'hint_cases':20","'hint_cases':80")
s=replace(s,'Compare 20 declared greedy starts from the empty-small 33-part subassembly','Compare 80 declared greedy starts: twenty orders from the empty small-part set, the exact mapped 64-part seed, and that seed with either small-part family released. Preserve the original 64-part score floor of ten brackets and 21 inserts')
s=replace(s,"    fixed=sorted(fixed);assert", "    seed=sorted(keys[identity(p)] for p in load(CORE/'source-seed.json')['placements'] if p['part_id'] in ['bracket','insert'])\n    assert len(seed)==len(set(seed))==31 and Counter(pool[i]['placement']['part_id'] for i in seed)==Counter(bracket=10,insert=21)\n    fixed=sorted(fixed);assert")
s=replace(s,"    pattern_checks=[]","    assert set(seed)<=set(eligible)\n    pattern_checks=[]")
s=replace(s,"'seed_candidates':[]","'seed_candidates':seed")
outputs['build_h5_wide_core_compound_contacts.py']=s

s=renamed((ROOT/'audit_h5_tall_small_compound_contacts.py').read_text(encoding='utf-8'))
s=replace(s," and mp['seed_candidates']==[]", "\n    expected_seed=[]\n    for p in load(CORE/'source-seed.json')['placements']:\n        if p['part_id'] in ['bracket','insert']:\n            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert raw[i]['placement']==p;expected_seed.append(i)\n    assert mp['seed_candidates']==sorted(expected_seed) and len(set(expected_seed))==31 and Counter(pool[i]['placement']['part_id'] for i in expected_seed)==Counter(bracket=10,insert=21)")
s=replace(s,"    assert covered==adj","    assert covered==adj\n    local={i:j for j,i in enumerate(ids)};seed_local=[local[i] for i in expected_seed];mask=sum(1<<j for j in seed_local);assert all(not(adj[j]&mask) for j in seed_local)")
s=replace(s,"'source_prefix_and_fixed_mapping_verified':True","'source_prefix_and_fixed_mapping_verified':True,'original_64_part_seed_mapped_and_full_graph_verified':True")
outputs['audit_h5_wide_core_compound_contacts.py']=s

s=renamed((ROOT/'reduce_h5_tall_small_compound_contacts.py').read_text(encoding='utf-8'))
s=replace(s,'The starting small-part seed is empty; fresh greedy hints follow separately.','Map the original 64-part seed only through these fresh certificates and verify its original counts and complete projected graph; fresh greedy hints follow separately.')
s=replace(s,"    assert mp['seed_candidates']==[]\n    write(OUT/'mapping.json',{**mp,'candidates':kept_global,'seed_candidates':[],'original_seed_candidates':[]})", "    seed=sorted(replacements.get(i,i) for i in mp['seed_candidates']);local2={i:j for j,i in enumerate(kept_global)};chosen=[local2[i] for i in seed];mask=sum(1<<j for j in chosen)\n    assert len(seed)==len(set(seed))==31 and Counter(pool[i]['placement']['part_id'] for i in seed)==Counter(bracket=10,insert=21) and all(not(covered[j]&mask) for j in chosen)\n    write(OUT/'mapping.json',{**mp,'candidates':kept_global,'seed_candidates':seed,'original_seed_candidates':mp['seed_candidates']})")
s=replace(s,"'empty_small_seed_verified':True","'original_64_part_seed_mapped_and_verified':True")
outputs['reduce_h5_wide_core_compound_contacts.py']=s

s=renamed((ROOT/'solve_h5_tall_small_compound_contacts.py').read_text(encoding='utf-8'))
outputs['solve_h5_wide_core_compound_contacts.py']=s

s=renamed((ROOT/'audit_h5_tall_small_compound_layouts.py').read_text(encoding='utf-8'))
s=s.replace('returned tall-frame layout','returned improved wide-core layout')
s=replace(s,"old=SEED;original=load(old/'layout.json')","old=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit';original=load(old/'layout-final.json')")
s=replace(s,"'layout':old/'layout.json','public':old/'public.json','command':old/'command.json'","'layout':old/'layout-final.json','public':old/'public-final.json','command':old/'command-final.json'")
outputs['audit_h5_wide_core_compound_layouts.py']=s
for name,s in outputs.items():
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared improved-core geometry, full-graph audit, seed-preserving reduction, solver and layout audit.')
