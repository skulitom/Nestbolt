"""Prepare only verified reflected compound geometries absent from earlier queries."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def change(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def rename(s):
    return s.replace('wide_core_compound_contacts','reflected_core_contacts').replace('h5-wide-core-compound-contacts','h5-reflected-core-contacts').replace('wide-core-compound-contact','reflected-core-contact')
outputs={}
s=rename((ROOT/'build_h5_wide_core_compound_contacts.py').read_text(encoding='utf-8'))
s=change(s,"OLD=ROOT/'output/h5-latest-wide-joint-20261023'","OLD=ROOT/'output/h5-wide-core-compound-contacts-20261023'")
s=change(s,"CAT=ROOT/'output/h5-cog-lattices-20261018'","CAT=ROOT/'output/h5-reflected-small-compounds-20261023'")
a=s.index('def members(');b=s.index('\n\ndef main():',a)
s=s[:a]+"def members(spec,patterns):\n    assert spec['kind']=='compound' and spec['degrees']==0\n    return copy.deepcopy(patterns[spec['pattern']]['members'])\n"+s[b:]
s=s.replace("CAT/'all-patterns.json'","CAT/'new-patterns.json'").replace("CAT/'audit/checks.json'","CAT/'checks.json'")
s=change(s,'assert len(names)==36','assert len(names)==114')
a=s.index('    single=');b=s.index('    planned=',a)
s=s[:a]+"    single=[]\n    compound=[{'kind':'compound','pattern':n,'degrees':0} for n in names]\n"+s[b:]
s=change(s,"prior_audit['source_hashes_unchanged'] and prior_audit['all_lattice_transforms_reconstructed'] and prior_audit['lattice_pairs']==45360","prior_audit['passed'] and prior_audit['new_reflected_geometries']==114 and prior_audit['completed_cases']==144 and prior_audit['all_equivalence_certificates_rechecked']")
s=change(s,'Query all eight bracket orientations/reflections and both insert classes, plus all 36 saved two-to-four-member bracket/insert compounds at four whole-group quarter turns, on both original target sheets. Compound global reflections are not sampled; each member retains its original allowed reflection.','Query only the 114 verified reflected compound geometries absent from prior rotations and earlier accepted reflections, on both original target sheets. Each catalogue entry already includes its quarter-turn; do not rotate it again or repeat the previous single-part queries. Insert reflections are represented by allowed unmirrored rectangle poses. The earlier equivalence tolerance is 1e-8 mm distance and 1e-6 mm2 area, so this deduplication is not an exhaustive continuous proof.')
s=s.replace('Original-outline small-part and compound contacts for the improved wide-frame 12+3 core.','Fresh reflected actual-compound contacts for the improved wide-frame core.')
outputs['build_h5_reflected_core_contacts.py']=s

s=rename((ROOT/'audit_h5_wide_core_compound_contacts.py').read_text(encoding='utf-8'))
s=s.replace("CAT/'all-patterns.json'","CAT/'new-patterns.json'")
s=change(s,'len(names)==36','len(names)==114')
a=s.index('    singles=');b=s.index('    patternrows=',a)
s=s[:a]+"    singles=[];compounds=[{'kind':'compound','pattern':n,'degrees':0} for n in names];planned=[{'sheet':sheet,**item} for sheet in ['sheet-0','sheet-1'] for item in compounds];assert planned==plan['queries']\n    originals=load(ROOT/'output/h5-cog-lattices-20261018/all-patterns.json')\n    for name in names:\n        record=patterns[name];raw=originals[record['pattern']]['members'];phi=math.radians(record['degrees']);c,s=math.cos(phi),math.sin(phi);assert len(raw)==len(record['members'])\n        for old,p in zip(raw,record['members']):\n            assert p['part_id']==old['part_id'];direct=affine_transform(shape(parts[old['part_id']],old['transform']),[-c,-s,-s,c,0,0]);actual=shape(parts[p['part_id']],p['transform'])\n            assert direct.hausdorff_distance(actual)<1e-8 and direct.symmetric_difference(actual).area<1e-6\n"+s[b:]
a=s.index("        if spec['kind']=='single':");b=s.index('        assert q[',a)
s=s[:a]+"        assert spec['kind']=='compound' and spec['degrees']==0;mm=copy.deepcopy(patterns[spec['pattern']]['members'])\n"+s[b:]
s=change(s,"'source_prefix_and_fixed_mapping_verified':True","'source_prefix_and_fixed_mapping_verified':True,'all_reflected_members_independently_reconstructed':True")
s=change(s,"    originals=load(ROOT/", "    for name,h in load(CAT/'plan.json')['inputs'].items():assert digest(ROOT/name)==h\n    originals=load(ROOT/")
outputs['audit_h5_reflected_core_contacts.py']=s
for source,dest in [('reduce_h5_wide_core_compound_contacts.py','reduce_h5_reflected_core_contacts.py'),('seed_h5_wide_core_compound_contacts.py','seed_h5_reflected_core_contacts.py'),('solve_h5_wide_core_compound_contacts.py','solve_h5_reflected_core_contacts.py'),('audit_h5_wide_core_compound_layouts.py','audit_h5_reflected_core_layouts.py')]:outputs[dest]=rename((ROOT/source).read_text(encoding='utf-8'))
for name,s in outputs.items():
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared 228 fresh reflected-compound queries and seed-preserving selection.')
