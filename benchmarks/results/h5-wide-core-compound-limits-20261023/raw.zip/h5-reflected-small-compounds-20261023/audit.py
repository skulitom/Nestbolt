"""Build allowed reflected compounds and identify geometry absent from prior queries."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations,permutations
import copy,math,shutil,time
from shapely.affinity import affine_transform,translate
from audit_h5_cog_lattices import shape
from build_h5_wide_core_compound_contacts import ROOT,SRC,CAT,OUT as PRIOR,load,write,digest
OUT=ROOT/'output/h5-reflected-small-compounds-20261023'

def normalized(geoms):
    x=min(g.bounds[0] for g in geoms);y=min(g.bounds[1] for g in geoms)
    return [translate(g,-x,-y) for g in geoms], [max(g.bounds[2] for g in geoms)-x,max(g.bounds[3] for g in geoms)-y]

def equal_members(left,right):
    if left['counts']!=right['counts'] or any(abs(a-b)>1e-8 for a,b in zip(left['size'],right['size'])):return None
    for order in permutations(range(len(right['members']))):
        if any(p['part_id']!=right['members'][j]['part_id'] for p,j in zip(left['members'],order)):continue
        distances=[g.hausdorff_distance(right['normalized'][j]) for g,j in zip(left['normalized'],order)]
        if max(distances)>1e-8:continue
        areas=[g.symmetric_difference(right['normalized'][j]).area for g,j in zip(left['normalized'],order)]
        if max(areas)<=1e-6:return {'member_permutation':list(order),'maximum_distance_mm':max(distances),'maximum_area_difference_mm2':max(areas)}
    return None

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    inputs=[CAT/'all-patterns.json',PRIOR/'plan.json',PRIOR/'audit/checks.json',SRC/'job.json']
    assert load(PRIOR/'audit/checks.json')['passed'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_cases':144,'maximum_seconds':30,'equivalence_distance_mm':1e-8,'equivalence_area_mm2':1e-6,
      'method':'Reflect every one of the 36 saved two-to-four-member bracket/insert compounds across x, then apply each quarter-turn. For mirrored brackets use the original allowed reflection flag. For rectangular inserts, which forbid mirror flags, analytically replace x reflection of the 0..180 by 0..110 rectangle with its allowed unmirrored pose translated by the rotated (-180,0) vector. Verify the direct affine reflection of each original outline independently against the reconstructed allowed pose, then all original member-pair distances. Normalize geometry only for equivalence comparisons. Compare member-by-member, preserving family, to all 144 previously queried rotations and earlier accepted reflections. Save every equivalence certificate, every new geometry and any pending suffix. Equivalence within the stated tiny tolerance is diagnostic deduplication, not a continuous completeness proof. No stock placement, contact query, solver, native packing or full-job acceptance occurs.'})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];patterns=load(CAT/'all-patterns.json');names=load(PRIOR/'plan.json')['compound_patterns'];assert len(names)==36
    assert parts['insert']['geometry'][0]['outer']==[[0.,0.],[180.,0.],[180.,110.],[0.,110.]] and not parts['insert']['allow_mirror']
    old=[]
    for name in names:
        for degrees in [0,90,180,270]:
            angle=math.radians(degrees);c,s=math.cos(angle),math.sin(angle);members=[]
            for p in patterns[name]['members']:
                t=copy.deepcopy(p['transform']);x,y=t['translation'];t['rotation_radians']+=angle;t['translation']=[c*x-s*y,s*x+c*y];members.append({'part_id':p['part_id'],'transform':t})
            gs=[shape(parts[p['part_id']],p['transform']) for p in members];ng,size=normalized(gs);old.append({'source':'prior-rotation','index':len(old),'pattern':name,'degrees':degrees,'members':members,'normalized':ng,'size':size,'counts':dict(Counter(p['part_id'] for p in members))})
    cases=[(name,a) for name in names for a in [0,90,180,270]];records=[];fresh=[];maxerror=0.;maxarea=0.;pairchecks=memberschecked=0;start=time.perf_counter()
    for name,degrees in cases:
        if time.perf_counter()-start>=30:break
        phi=math.radians(degrees);c,s=math.cos(phi),math.sin(phi);members=[];gs=[]
        for p in patterns[name]['members']:
            t=copy.deepcopy(p['transform']);theta=-t['rotation_radians'];x,y=t['translation'];x=-x;mir=not t['mirrored']
            if p['part_id']=='insert':
                assert mir and not t['mirrored'];x-=180*math.cos(theta);y-=180*math.sin(theta);mir=False
            new={'rotation_radians':theta+phi,'mirrored':mir,'translation':[c*x-s*y,s*x+c*y]};part=parts[p['part_id']]
            assert not mir or part['allow_mirror'];assert any(abs(math.remainder(new['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
            expected=affine_transform(shape(part,t),[-c,-s,-s,c,0,0]);actual=shape(part,new);error=actual.hausdorff_distance(expected);area=actual.symmetric_difference(expected).area;maxerror=max(maxerror,error);maxarea=max(maxarea,area)
            assert error<1e-8 and area<1e-6 and actual.is_valid;memberschecked+=1;members.append({'part_id':p['part_id'],'transform':new});gs.append(actual)
        minimum=math.inf
        for a,b in combinations(gs,2):pairchecks+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=clear-1e-7
        ng,size=normalized(gs);r={'source':'reflected','index':len(records),'pattern':name,'degrees':degrees,'members':members,'normalized':ng,'size':size,'counts':dict(Counter(p['part_id'] for p in members))};match=None
        for other in old+fresh:
            certificate=equal_members(r,other)
            if certificate is not None:match={'source':other['source'],'index':other['index'],**certificate};break
        record={k:v for k,v in r.items() if k!='normalized'};record['minimum_member_distance_mm']=minimum
        if match is None:
            record['new_pattern_index']=len(fresh);fresh.append(r)
        else:record['equivalent_to']=match
        records.append(record)
    elapsed=time.perf_counter()-start
    # Independently recheck the saved certificates against each referenced geometry.
    for r in records:
        if 'equivalent_to' not in r:continue
        eq=r['equivalent_to'];other=old[eq['index']] if eq['source']=='prior-rotation' else next(x for x in fresh if x['index']==eq['index']);ng,size=normalized([shape(parts[p['part_id']],p['transform']) for p in r['members']])
        for p,g,j in zip(r['members'],ng,eq['member_permutation']):assert p['part_id']==other['members'][j]['part_id'] and g.hausdorff_distance(other['normalized'][j])<=1e-8 and g.symmetric_difference(other['normalized'][j]).area<=1e-6
    newpatterns={f"reflected-{r['pattern']}-r{r['degrees']}":{k:v for k,v in r.items() if k!='normalized'} for r in fresh};write(OUT/'cases.json',records);write(OUT/'new-patterns.json',newpatterns);write(OUT/'pending.json',[{'pattern':n,'degrees':a} for n,a in cases[len(records):]])
    check={'passed':True,'seconds':elapsed,'planned_cases':144,'completed_cases':len(records),'pending_cases':144-len(records),'limit_reached':elapsed>=30,'new_reflected_geometries':len(fresh),'equivalent_to_previous_rotations':sum(r.get('equivalent_to',{}).get('source')=='prior-rotation' for r in records),'equivalent_to_earlier_reflections':sum(r.get('equivalent_to',{}).get('source')=='reflected' for r in records),'original_members_affine_checked':memberschecked,'original_member_pairs':pairchecks,'maximum_affine_reconstruction_distance_mm':maxerror,'maximum_affine_area_difference_mm2':maxarea,'insert_reflections_represented_without_forbidden_mirror_flags':True,'all_equivalence_certificates_rechecked':True,'new_contact_queries':0,'solver_calls':0,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
