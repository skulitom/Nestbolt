"""Independent original-pose, compound exclusion and complete conflict audit."""
from collections import Counter,deque
from itertools import combinations
import copy,gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import box,Polygon,shape as read_geometry
from shapely.affinity import affine_transform
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_reflected_core_contacts import ROOT,SRC,OLD,CORE,CAT,OUT,load,write,digest

def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter();plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');gap.EPS=plan['construction_padding_mm']
    pool=load(OUT/'candidates.json');source=load(OUT/'source-pool.json');raw=copy.deepcopy(load(OLD/'candidates.json'));source_size=len(raw);keys={identity(p['placement']):i for i,p in enumerate(raw)};fixed=[];newfixed=[]
    for p in load(CORE/'layout.json')['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');k=identity(p)
        if k not in keys:
            i=len(raw);raw.append({'index':i,'placement':p,'source':{'kind':'wide-frame-cog-core'},'filled_area_mm2':shape(parts[p['part_id']],p['transform']).area});keys[k]=i;newfixed.append(i)
        fixed.append(keys[k])
    fixed=sorted(fixed);assert source==raw and pool[:len(source)]==source and load(OUT/'fixed-mapping.json')=={'source_pool_size':source_size,'new_fixed_candidates':newfixed,'fixed_candidates':fixed}
    mp=load(OUT/'mapping.json');result=load(OUT/'result.json');assert mp['fixed_candidates']==fixed and mp['new_fixed_candidates']==newfixed
    expected_seed=[]
    for p in load(CORE/'source-seed.json')['placements']:
        if p['part_id'] in ['bracket','insert']:
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert raw[i]['placement']==p;expected_seed.append(i)
    assert mp['seed_candidates']==sorted(expected_seed) and len(set(expected_seed))==31 and Counter(pool[i]['placement']['part_id'] for i in expected_seed)==Counter(bracket=10,insert=21)
    assert Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15)
    gs={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)};here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    patterns=load(CAT/'new-patterns.json');names=sorted(n for n,p in patterns.items() if len(p['members'])>1 and all(v['part_id'] in ['bracket','insert'] for v in p['members']));assert names==plan['compound_patterns'] and len(names)==114
    singles=[];compounds=[{'kind':'compound','pattern':n,'degrees':0} for n in names];planned=[{'sheet':sheet,**item} for sheet in ['sheet-0','sheet-1'] for item in compounds];assert planned==plan['queries']
    for name,h in load(CAT/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    originals=load(ROOT/'output/h5-cog-lattices-20261018/all-patterns.json')
    for name in names:
        record=patterns[name];raw=originals[record['pattern']]['members'];phi=math.radians(record['degrees']);c,s=math.cos(phi),math.sin(phi);assert len(raw)==len(record['members'])
        for old,p in zip(raw,record['members']):
            assert p['part_id']==old['part_id'];direct=affine_transform(shape(parts[old['part_id']],old['transform']),[-c,-s,-s,c,0,0]);actual=shape(parts[p['part_id']],p['transform'])
            assert direct.hausdorff_distance(actual)<1e-8 and direct.symmetric_difference(actual).area<1e-6
    patternrows=[];patternpairs=0
    for n in names:
        gg=[shape(parts[p['part_id']],p['transform']) for p in patterns[n]['members']];minimum=math.inf
        for a,b in combinations(gg,2):d=a.distance(b);minimum=min(minimum,d);patternpairs+=1;assert a.disjoint(b) and d>=clear-1e-7
        patternrows.append({'pattern':n,'members':len(gg),'pairs':len(gg)*(len(gg)-1)//2,'minimum_distance_mm':minimum})
    assert patternrows==load(OUT/'pattern-checks.json');cache={};maxtranslationerror=0.
    for at,r in enumerate(load(OUT/'cache-index.json')):
        saved=load(OUT/'obstacles'/f'{at}.json');assert r=={k:v for k,v in saved.items() if k!='geometry'} and r['index']==at
        g=read_geometry(saved['geometry']);f=shape(parts[r['fixed_part']],r['fixed_zero_transform']);moving=shape(parts[r['moving_part']],r['moving_zero_transform']);assert gap.obstacle(f,moving,clear).equals_exact(g,0)
        fp,mm=r['first_fixed_pose'],r['first_moving_member'];ft,mt=fp['transform'],mm['transform'];direct=gap.obstacle(shape(parts[fp['part_id']],ft),shape(parts[mm['part_id']],mt),clear)
        shifted=affine_transform(g,[1,0,0,1,ft['translation'][0]-mt['translation'][0],ft['translation'][1]-mt['translation'][1]]);error=direct.hausdorff_distance(shifted);maxtranslationerror=max(maxtranslationerror,error);assert error<1e-7 and direct.symmetric_difference(shifted).area<1e-5
        k=(fp['part_id'],float(ft['rotation_radians']).hex(),ft['mirrored'],mm['part_id'],float(mt['rotation_radians']).hex(),mt['mirrored']);assert k not in cache;cache[k]=g
    queries=[];querypairs=0;maxregionerror=0.
    for i in range(result['completed_queries']):
        q=load(OUT/'regions'/f'query-{i}.json');spec=planned[i];assert q['index']==i and all(q[k]==v for k,v in spec.items())
        assert spec['kind']=='compound' and spec['degrees']==0;mm=copy.deepcopy(patterns[spec['pattern']]['members'])
        assert q['members']==mm;gg=[shape(parts[p['part_id']],p['transform']) for p in mm]
        for j,p in enumerate(mm):
            part=parts[p['part_id']];t=p['transform'];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        for a,b in combinations(gg,2):querypairs+=1;assert a.disjoint(b) and a.distance(b)>=clear-1e-7
        a=min(g.bounds[0] for g in gg);b=min(g.bounds[1] for g in gg);c=max(g.bounds[2] for g in gg);d=max(g.bounds[3] for g in gg);h=stock['height'] if q['sheet']=='sheet-0' else target['required_used_height_mm'];bounds=[m['left']+edge+gap.EPS-a,m['bottom']+edge+gap.EPS-b,stock['width']-m['right']-edge-gap.EPS-c,h-m['top']-edge-gap.EPS-d];assert q['domain_bounds']==bounds
        if bounds[0]>=bounds[2] or bounds[1]>=bounds[3]:expected=Polygon()
        else:
            obstacles=[]
            for j in here[q['sheet']]:
                fp=pool[j]['placement'];ft=fp['transform']
                for member in mm:
                    mt=member['transform'];k=(fp['part_id'],float(ft['rotation_radians']).hex(),ft['mirrored'],member['part_id'],float(mt['rotation_radians']).hex(),mt['mirrored']);obstacles.append(affine_transform(cache[k],[1,0,0,1,ft['translation'][0]-mt['translation'][0],ft['translation'][1]-mt['translation'][1]]))
            expected=box(*bounds).difference(unary_union(obstacles))
        region=read_geometry(q['region']);error=expected.symmetric_difference(region).area;maxregionerror=max(maxregionerror,error);assert expected.is_empty==region.is_empty and error<1e-6 and q['proposals']==proposals(region);queries.append(q)
    oldsmall=[i for i,p in enumerate(source) if p['placement']['part_id'] in ['bracket','insert']];filters=load(OUT/'old-filter.json');assert len(filters)==len(oldsmall);eligible=[];oldpairs=0
    for i,r in zip(oldsmall,filters):
        blockers=[]
        for j in here[pool[i]['placement']['sheet_id']]:
            oldpairs+=1
            if gs[i].distance(gs[j])<clear-1e-7:blockers.append(j)
        assert r=={'candidate':i,'fixed_blockers':blockers}
        if not blockers:eligible.append(i)
    assert eligible==mp['old_eligible'];keys={identity(p['placement']):i for i,p in enumerate(source)};queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];counts=Counter();added=[];proposalpairs=duplicates=rejections=0
    for event in load(OUT/'source-events.json'):
        while True:
            qi,at=queue.popleft();q=queries[qi];pi,mi=divmod(at,len(q['members']));member=q['members'][mi];f=member['part_id']
            if counts[f]>=plan['new_pose_caps'][f]:deferred.append([qi,at])
            else:break
        assert (event['query'],event['proposal'],event['member'])==(qi,pi,mi);t=copy.deepcopy(member['transform']);x,y=t['translation'];dx,dy=q['proposals'][pi]['point'];t['translation']=[x+dx,y+dy];p={'part_id':f,'sheet_id':q['sheet'],'transform':t};g=shape(parts[f],t);a,b,c,d=g.bounds;h=stock['height'] if q['sheet']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7
        dd=[g.distance(gs[j]) for j in here[q['sheet']]];proposalpairs+=len(dd);blockers=[j for j,v in zip(here[q['sheet']],dd) if v<clear-1e-7]
        if outside or blockers:rejections+=1;assert event=={'query':qi,'proposal':pi,'member':mi,'added':False,'reason':'geometry','outside':bool(outside),'blockers':blockers}
        elif identity(p) in keys:duplicates+=1;assert event=={'query':qi,'proposal':pi,'member':mi,'added':False,'reason':'duplicate','candidate':keys[identity(p)]}
        else:
            i=len(source)+len(added);assert event=={'query':qi,'proposal':pi,'member':mi,'added':True,'candidate':i} and pool[i]['placement']==p and pool[i]['source']=={'kind':'reflected-core-contact','query':qi,'proposal':pi,'member':mi} and abs(pool[i]['filled_area_mm2']-g.area)<1e-7
            assert min(dd)>=clear+gap.EPS-1e-7 and a>=m['left']+edge+gap.EPS-1e-7 and b>=m['bottom']+edge+gap.EPS-1e-7 and c<=stock['width']-m['right']-edge-gap.EPS+1e-7 and d<=h-m['top']-edge-gap.EPS+1e-7
            keys[identity(p)]=i;added.append(i);counts[f]+=1
        if at+1<len(q['proposals'])*len(q['members']):queue.append((qi,at+1))
    pending=load(OUT/'pending.json');assert pending=={'queries':planned[len(queries):],'member_lists':sorted(deferred+list(map(list,queue)))} and added==mp['new_candidates'] and dict(counts)==result['new_candidates'];ids=mp['candidates'];assert ids==sorted(eligible+added)
    for i in ids+fixed:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];g=gs[i];a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
    fixedpairs=0
    for i,j in combinations(fixed,2):
        if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
        fixedpairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clear-1e-7
    gg=np.asarray([gs[i] for i in ids],dtype=object);bb=shapely.bounds(gg);ss=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=[0]*len(ids);allpairs=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];allpairs+=len(js);dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clear+1e-7];near+=len(js)
        for j in js[shapely.distance(gg[i],gg[js])<clear-1e-7]:j=int(j);adj[i]|=1<<j;adj[j]|=1<<i
    edges=sum(a.bit_count() for a in adj)//2;seen=0;previous=(-1,-1)
    with gzip.open(OUT/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:pair=tuple(json.loads(line));i,j=pair;assert pair>previous and i<j and (adj[i]>>j)&1;previous=pair;seen+=1
    assert seen==edges==result['conflicts'];covered=[0]*len(ids);cliquecount=0
    with gzip.open(OUT/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);assert len(row)==len(set(row));mask=sum(1<<j for j in row);cliquecount+=1
            for j in row:others=mask^(1<<j);assert not(others&~adj[j]);covered[j]|=others
    assert covered==adj
    local={i:j for j,i in enumerate(ids)};seed_local=[local[i] for i in expected_seed];mask=sum(1<<j for j in seed_local);assert all(not(adj[j]&mask) for j in seed_local)
    checks={'passed':True,'seconds':time.perf_counter()-start,'source_prefix_and_fixed_mapping_verified':True,'all_reflected_members_independently_reconstructed':True,'original_64_part_seed_mapped_and_full_graph_verified':True,'fixed_geometry_pairs':fixedpairs,'source_compound_pairs':patternpairs,'rotated_query_compound_pairs':querypairs,'cache_entries':len(cache),'maximum_absolute_translation_error_mm':maxtranslationerror,'queries_reconstructed':len(queries),'maximum_region_area_error_mm2':maxregionerror,'old_fixed_pairs':oldpairs,'proposal_fixed_pairs':proposalpairs,'duplicates':duplicates,'rejections':rejections,'pending_lists_preserved':len(pending['member_lists']),'small_pair_possibilities':allpairs,'small_pair_exact_distances':near,'conflicts':edges,'cliques_including_residual':cliquecount,'full_graph_coverage':True,'all_actual_member_geometry_and_stock_checked':True,'native_margin_qualified':False}
    write(dst/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
