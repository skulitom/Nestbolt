def pose_key(value):
    assert set(value)=={'part_id','transform'} and type(value['part_id']) is str
    transform=value['transform']
    assert set(transform)=={'translation','rotation_radians','mirrored'}
    assert type(transform['mirrored']) is bool
    assert isinstance(transform['translation'],list) and len(transform['translation'])==2
    numbers=[*transform['translation'],transform['rotation_radians']]
    assert all(type(x) in [int,float] and math.isfinite(x) for x in numbers)
    return (value['part_id'],*numbers,transform['mirrored'])


def check_traces(traces, stats=None):
    import h5_frontier_observer as family_reader
    assert isinstance(traces,list)
    for trace in traces:
        assert set(trace)=={'baseline','choices','choice_poses','visits','attempts'}
    result=family_reader.check_traces([{k:v for k,v in t.items() if k!='choice_poses'} for t in traces],stats)
    for trace in traces:
        base=trace['baseline']
        source=[p for p in base['layout']['placements'] if p['sheet_id']==base['source_sheet']]
        inventory=Counter(pose_key({'part_id':p['part_id'],'transform':p['transform']}) for p in source)
        assert inventory and all(count==1 for count in inventory.values()), 'Source physical poses must be unique'
        choices=trace['choices'];poses=trace['choice_poses']
        assert isinstance(poses,list) and len(poses)==len(choices)
        singles=Counter()
        for names,members in zip(choices,poses):
            assert isinstance(members,list) and len(members)==len(names)
            assert [p['part_id'] for p in members]==names
            keys=Counter(pose_key(p) for p in members)
            assert not keys-inventory, 'Choice must identify exact baseline members with correct multiplicity'
            if len(members)==1:singles.update(keys)
        assert singles==inventory, 'Each source copy must occur exactly once in the single choices'
    result['traces']=traces
    result['exact_choice_poses_verified']=True
    return result


def parse_log(log):
    return [json.loads(line.removeprefix('FRONTIER_DIAG ')) for line in log.splitlines() if line.startswith('FRONTIER_DIAG ')]


def read_trace(archive, record):
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        case=json.loads(z.read('case.json'))
        for name,expected in case['artifacts'].items():assert prior.sha256(z.read(name)).hexdigest()==expected
        traces=parse_log(z.read('search-stderr.log').decode('utf-8'))
    assert traces,'No baseline observation from the two-sheet diagnostic'
    return check_traces(traces,record.get('stats') if record['status']=='valid' else None)


