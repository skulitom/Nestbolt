"""Prepare the diagnostic reader after the boundary observer has been created."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-observer-20261018'
assert (out/'preparation.json').exists()
ref=root/'scripts/h5_frontier_observer.py';s=ref.read_text(encoding='utf-8')
s=s.replace('h5_material_profile_pilot','h5_boundary_priority_pilot').replace('h5-material-profile-pilot','h5-boundary-priority-pilot')
s=s.replace('h5_frontier_observer','h5_boundary_observer').replace('h5-frontier-observer','h5-boundary-observer')
s=s.replace('Observe whether exchange choices reach the parts setting charged sheet height.',
    'Observe exact physical copies selected by the boundary-priority candidate.')
s=s.replace("paths = [Path(__file__), ROOT/'scripts/h5_boundary_priority_pilot.py',", "paths = [Path(__file__), ROOT/'scripts/h5_boundary_priority_pilot.py', ROOT/'scripts/h5_frontier_observer.py',")
s=s.replace('original part names for every choice, visited choices', 'original part names and exact public source poses for every choice, visited choices')
start=s.index('def check_traces(');end=s.index('def run(out):',start)
s=s[:start]+(root/'output/boundary_pose_reader.py').read_text(encoding='utf-8')+s[end:]
path=root/'scripts/h5_boundary_observer.py';assert not path.exists();compile(s,str(path),'exec')
path.write_text(s,encoding='utf-8',newline='\n')
def fn(text,name):return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
assert ast.dump(fn(s,'run'))==ast.dump(fn(ref.read_text(encoding='utf-8'),'run'))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
        'measurement_function_AST_exact':True,'case_method_reused_unchanged':True,'runner_sha256':sha256(path.read_bytes()).hexdigest()}
(out/'runner-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(root/'output/check_h5_frontier_source.py').read_text(encoding='utf-8').replace('h5-frontier-observer','h5-boundary-observer').replace('all_123_original_tests_unchanged','all_126_original_tests_unchanged')
(root/'output/check_h5_boundary_observer_source.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/check_h5_frontier_reader.py').read_text(encoding='utf-8').replace('h5-frontier-observer','h5-boundary-observer').replace('h5_frontier_observer','h5_boundary_observer').replace('h5-material-profile-probe','h5-boundary-priority-probe')
needle="different=next(t for t in all_traces"
extra='''def first_pair(t):return next(i for i,c in enumerate(t['choices']) if len(c)==2)
rejected += [
    reject('missing physical poses',lambda t:t.pop('choice_poses')),
    reject('missing physical choice',lambda t:t['choice_poses'].pop()),
    reject('duplicate physical pair member',lambda t:t['choice_poses'][first_pair(t)].__setitem__(1,t['choice_poses'][first_pair(t)][0])),
    reject('nonfinite physical translation',lambda t:t['choice_poses'][0][0]['transform']['translation'].__setitem__(0,float('nan'))),
    reject('unmatched physical pose',lambda t:t['choice_poses'][0][0]['transform']['translation'].__setitem__(0,999999.0)),
]

'''
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
s=s.replace("'actual_profile_branch_counters_exact':True,", "'actual_profile_branch_counters_exact':True,'all_choice_poses_match_unique_baseline_members':True,")
compile(s,'check-reader','exec')
(root/'output/check_h5_boundary_observer_reader.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
