"""Conditional diagnostic: identify exact incoming poses after the boundary pilot."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import difflib, json, shutil, sys

root = Path(__file__).resolve().parents[1]
pilot = root / 'benchmarks/results/h5-boundary-priority-pilot-20261018'
out = root / 'output/h5-boundary-observer-20261018'
old = root / 'output/h5-boundary-priority-probe-20261018/candidate'
work = out / 'workspace'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
assert load(pilot / 'verification.json')['valid'] == 72
assert load(pilot / 'filled-outer-audit.json')['all_holes_reserved']
assert any(not p['candidate_within_original_material_limit'] for p in load(pilot / 'results.json')['summary']['pairs'])
out.mkdir()
shutil.copytree(old, work)
rel = 'crates/core/src/sheets/vstrip/exchange.rs'
path = work / rel
original = path.read_text(encoding='utf-8')
text = original
changes = []

def replace(before, after):
    global text
    assert text.count(before) == 1, (before, text.count(before))
    text = text.replace(before, after)
    changes.append((before, after))

# Reuse all previously qualified terminal observations, then add physical poses.
for before, after in load(root / 'output/h5-frontier-observer-20261018/substitutions.json'):
    replace(before, after)
replace('    choices: Vec<Vec<String>>,\n', '    choices: Vec<Vec<String>>,\n    choice_poses: Vec<Vec<serde_json::Value>>,\n')
replace('            visits: Vec::new(), attempts: Vec::new(),\n', '''            choice_poses: choices.iter().map(|choice| choice.iter().map(|key| {
                let placed = &sep.layout.placed_items()[*key];
                let item = placed.item().idx();
                serde_json::json!({
                    "part_id": self.model.job.parts[self.model.part[item]].id,
                    "transform": self.model.external(item, &shift(placed.d_transf(), -last_offset)),
                })
            }).collect()).collect(),
            visits: Vec::new(), attempts: Vec::new(),
''')
reverse = text
for before, after in reversed(changes):
    assert reverse.count(after) == 1
    reverse = reverse.replace(after, before)
assert reverse == original
assert text.split('#[cfg(test)]', 1)[1] == original.split('#[cfg(test)]', 1)[1]
path.write_text(text, encoding='utf-8', newline='\n')
(out / 'substitutions.json').write_text(json.dumps(changes, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile='boundary-priority/' + rel, tofile='boundary-observer/' + rel)), encoding='utf-8', newline='\n')
sys.path.insert(0, str(root / 'scripts'))
from h2_import_audit import source_digest
plan = {'utc': datetime.now(timezone.utc).isoformat(), 'purpose': __doc__, 'old_source': str(old),
        'source_files': [{'path': p.relative_to(old).as_posix(), 'sha256': digest(p)} for p in sorted(old.rglob('*')) if p.is_file()],
        'changed_file': rel, 'changed_files': [rel], 'production_digest': source_digest(),
        'target': str(root / 'output/h5-boundary-observer-target-20261018'),
        'all_126_prior_tests_unchanged': True, 'exact_preformat_reversal': True,
        'decisions_budgets_work_charges_unchanged': True,
        'exact_source_pose_mapping': 'Use the same sheet-offset subtraction and Model.external conversion as Strip.split and Model.to_layout. The reader requires a unique exact public pose match in the validated baseline.',
        'trace_overhead_can_change_wall_trajectory': True, 'measured_search_started': False}
(out / 'preparation.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copyfile(__file__, out / 'prepare.py')
s = (root / 'output/build_h5_frontier_observer.py').read_text(encoding='utf-8').replace('h5-frontier-observer', 'h5-boundary-observer')
(root / 'output/build_h5_boundary_observer.py').write_text(s, encoding='utf-8', newline='\n')
print(json.dumps({'isolated_observer_prepared': True, 'source_files': len(plan['source_files']), 'changed_files': 1, 'prior_tests_unchanged': 126, 'measurements_started': False}))
