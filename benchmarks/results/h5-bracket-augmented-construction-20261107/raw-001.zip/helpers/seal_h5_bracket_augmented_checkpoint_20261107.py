"""Preserve the augmented model, contact diagnostics and its one closed call."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-bracket-augmented-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-bracket-augmented-model-20261107';F=BASE/'response-audit';D=BASE/'audit-v2'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-bracket-collision-depth-preflight-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==1 and front['best_original_pair_failures']==44 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-bracket-augmented-model-preparation-process-20261107','h5-bracket-augmented-model-audit-process-20261107','h5-bracket-augmented-model-derivative-diagnostic-v2-process-20261107','h5-bracket-augmented-model-audit-v2-process-20261107','h5-bracket-augmented-model-response-audit-process-20261107','h5-bracket-depth-main-sync-20261107']]",
    "['*h5*mixed*mode*20261107.py']":"['*h5*bracket*augmented*20261107.py','*h5*bracket*derivative*20261107.py','prepare_h5_bracket_depth_push_20261107.py','push_h5_bracket_depth_checkpoints_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_bracket_augmented_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']",
    "def add(name,p):\n    assert":"def add(name,p):\n    if p==ROOT/'output/h5-bracket-augmented-model-20261107/derivative-diagnostic/all-original-central-controls.json':\n        failure=load(p.parent/'serialization-failure.json');assert digest(p)==failure['incomplete_output_sha256'];name+='.partial.txt'\n    assert",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'checks.json','model-audit.json'),(D/'all-owner-mode-scores.json','mode-scores.json'),(D/'scalar-gradient-controls.json','scalar-gradient-controls.json'),(D/'central-controls.json','central-controls.json'),(D/'touching-one-sided-controls.json','touching-controls.json'),(D/'negative-controls.json','negative-controls.json'),(D/'closure-controls.json','closure-controls.json'),(BASE/'plan-v2.json','audit-correction.json'),(BASE/'derivative-diagnostic/serialization-failure.json','preserved-serialization-failure.json'),(BASE/'derivative-diagnostic-v2/checks.json','contact-diagnostic.json'),(BASE/'derivative-diagnostic-v2/failing-coordinate-pair-causes.json','contact-pair-causes.json'),(BASE/'derivative-diagnostic-v2/all-original-central-controls.json','preserved-original-central-controls.json'),(F/'checks.json','response-audit.json'),(F/'winner-reconciliation.json','winner-reconciliation.json'),(F/'original-source-checks.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json'),(BASE/'search/closed-problem.json','closed-problem.json'),(BASE/'outcome-diagnostic/checks.json','outcome-diagnostic.json'),(BASE/'outcome-diagnostic/family-failures.json','family-failures.json'),(BASE/'outcome-diagnostic/prior-comparisons.json','prior-comparisons.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-bracket-depth-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage,name in [('preparation','preparation-process.json'),('audit','preserved-failed-audit-process.json'),('derivative-diagnostic-v2','diagnostic-process.json'),('audit-v2','model-audit-process.json'),('response-audit','response-audit-process.json')]:copies.append((ROOT/'output'/f'h5-bracket-augmented-model-{stage}-process-20261107'/'process.json',name))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']},'original_failed_central_samples_preserved':14,'model_unchanged_after_preflight_failure':True})
write(OUT/'next-step.json',{'status':'augmented_conditional_mode_selection_preflight_required','finding':'One fixed-mode augmented call closes with44source collisions and33707.125558mm2overlap. It has zero bracket/bracket failures and no zero available gradient among45positive area terms, but large bracket/insert and companion/cog collisions remain. Four cogs have lower-y negative gradient blocked by hard bounds. These are local observations, not a global exclusion. Earlier unoptimized conditional mode/center selection improved the original area score and is relevant to the unchanged domain restriction.',
    'proposal':'Assess a separately versioned conditional mode/center selector using the complete augmented score. Use only the original W unoptimized initializer and the already frozen9x9 source grid plus clamped controls. Reconcile the old weighted joint/relocation selectors before adapting them: the new auxiliary bracket terms must participate in every center and proposal score and mutual interactions must be counted once. Independently replay all6396nominal center trials and current+78single+2775joint choices before considering a new finite search. No new selector or call exists yet.',
    'requirements':['Preserve every528original/clearance pair,15unweighted auxiliary bracket pairs,81coordinates and all legal hard domains. Coefficient1 stays frozen. All dynamic model fields and complete scores need independent readback.','Exclude the closed augmented key505d69b292c6a48102f20c32619f154cbc0bb3ec4b17f0defed552558a218db3. All7older area-only weighted problems and all older calls remain closed. Do not resume, reseed, reset or extend the current call. New problems must bind complete objective/physical-mode/weight identity.','Use the original unoptimized source initializer only. The saved final candidate and diagnostic interior controls are validation-only and may not seed a new search. Any selected new joint proposal must strictly improve both the current source score and best admissible single choice under the full augmented objective.','Reconcile actual consumed preparation before declaring the contract. The current source-only model lineage costs11.688681099563837s before new selection work. Charge all additional consumed preparation/selection stages; do not silently discard earlier selector work if its results are used. A later search needs a separately frozen finite60/90contract and one attempt per new key.','Retain original contact/near-transition derivative failures and documented conventions. Central controls are not a blanket smoothness guarantee. Keep augmented, original-area and unweighted-area winner streams, full66source acceptance and native validation only after a valid source witness.'],
    'source_only_preparation_seconds_before_new_selector':11.688681099563837,'new_selector_prepared':False,'new_optimizer_calls':0,'closed_augmented_problems':1,'closed_prior_weighted_problems':7,'H5_complete':False})
ci=load(BASE/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Augmented bracket-depth construction — 2026-11-07

The complete augmented objective passes its independent model audit and closes
one bounded optimizer call. Its final candidate still has **44 source-pair
failures** and **33,707.125558 mm²** original overlap. All three recorded winner
streams select the same point. Compared with the preceding conditional search,
it has fewer failing pairs but more overlap area; **no packing improvement or
valid full layout is claimed**. H2/H5 remain open at **60%**.

## Full objective and independent model checks

The model retains33 movers,81 coordinates, all528 positively weighted original
and clearance-area pair losses, and every hard stock/fixed-part domain. It adds
the15 unweighted bracket collision-depth terms at the previously frozen
coefficient1. Source initializer, legal modes and original weights are unchanged.
The objective identity binds the full policy, region bytes and nine executing
source modules. [Closure controls]({NAME}/closure-controls.json) distinguish the
new objective from the already closed area-only problem on the same physical
mode/weight vector. None of the seven earlier weighted calls resumes.

[Model preflight]({NAME}/model-audit.json) checks every field and all **147**
legal owner-mode full scores, with maximum scalar score error1.165e-10mm².
It independently accumulates306 directed source-boundary terms and162 combined
gradient coordinates at the original initializer and the saved flat case;
maximum discrepancy is1.528e-13mm. [Nine corruptions]({NAME}/negative-controls.json)
of identities, coefficients, bounds, pivots, initial coordinates or terms are
rejected. The saved optimized case is validation only and never seeds the run.

## Contact derivatives: preserved failures and limited claims

The [first audit]({NAME}/preserved-failed-audit-process.json) stops when a central
sample at the exact initializer disagrees with the selected area-boundary
convention. A diagnostic retains all **324** original-case central samples,
including **14 failures**: eight at the initializer and six at the saved
candidate. [Pair-level decomposition]({NAME}/contact-pair-causes.json) locates
the discrepancies in source-area contact/near-transition terms. It does not
establish the initial zero-area-contact hypothesis; that false diagnostic
flag remains explicit. The new auxiliary finite differences remain small.

The diagnostic's first output write also fails on a NumPy boolean.
[That serialization failure]({NAME}/preserved-serialization-failure.json),
the original helper and its incomplete JSON bytes remain preserved; the raw
archive stores those incomplete bytes under a `.partial.txt` member while the
record retains their original path and hash. Version2 changes only output
serialization and output location, preserving all numerical controls.

[The versioned model audit]({NAME}/audit-correction.json) retains the original
samples and their failures. It checks independent scalar gradients at those
same points and [one-sided finite-slope enclosures]({NAME}/touching-controls.json)
for all14 failing coordinates. These are finite controls, **not a unique
derivative or a global generalized-gradient certificate**. Separately it checks
324 central samples at the exact two deterministic interior controls already
used by the earlier weighted-model audit. Those points have no shared boundary
and unique auxiliary nearest features; they remain validation only. All pass
the unchanged0.02+3e-6×|gradient| tolerance, including maximum absolute
error0.026538 for the higher-weight control. Model, kernel, actual initializer,
weights and tolerances do not change. The passing model-audit wrapper takes
21.856198s; the first failed wrapper takes6.712762s. All artifacts remain.

## One finite call and complete replay

The new problem opens once, with a36s L-BFGS-B slice inside preparation-inclusive
60/90s algorithm/shared limits and a2GiB process-tree limit. There are no mode
changes, coefficient updates or retries. Existing area-boundary and nearest
feature rules are explicitly treated as nonsmooth search conventions; full
source geometry remains the acceptance test.

[Complete response replay]({NAME}/response-audit.json) verifies **237 evaluation
records**: the initial point and236 optimizer evaluations. It recomputes every
score and gradient, independently reconstructs every scalar source-area and
rational auxiliary score, and checks all **212** retained improvements. The
largest independent score discrepancy is2.329e-10mm². It separately reconstructs
strict winners for augmented score, original overlap area and unweighted
original-plus-clearance sum; [all three select evaluation236]({NAME}/winner-reconciliation.json).
Each winner receives a full66 source readback covering1,380 same-sheet pairs,
264 stock edges,90 holes and10,026 hole vertices. Every fixed-part and stock
check passes. The response-audit wrapper closes in32.861542s.

The36s slice returns at **36.071821s**; its **0.071821s overrun** is retained.
Complete source preparation is **11.688681s**: the previously charged11.002683s
plus the full new0.685998s model-preparation wrapper. Algorithm/shared totals
are **52.962365/53.493153s**. [The process tree closes]({NAME}/closed-search-process.json)
with100,876,288bytes peak aggregate committed memory. This
[new objective key is permanently closed]({NAME}/closed-problem.json); no
native call or allocation exclusion follows.

## Remaining geometry and next preflight

The [44 source failures]({NAME}/source-failures.json) all have positive original
intersection. Their [family composition]({NAME}/family-failures.json) is:

| Families | Failing pairs | Original overlap (mm²) |
| --- | ---: | ---: |
| Bracket / insert | 3 | 9,566.315981 |
| Bracket / cog | 8 | 5,202.561575 |
| Cog / insert | 14 | 10,113.822169 |
| Cog / cog | 19 | 8,824.425832 |

The [read-only diagnostic]({NAME}/outcome-diagnostic.json) finds no bracket/bracket
source failure and zero auxiliary loss at this candidate. All45 positive
original/clearance pair terms have a nonzero available pair gradient; no flat
pair probe is triggered. Four cogs have lower-y descent blocked by hard bounds.
These observations do not prove a global packing obstruction.
[Prior comparisons]({NAME}/prior-comparisons.json) preserve both worse overlap
and the different experimental choices; no causal improvement is attributed
to the added term.

[Next]({NAME}/next-step.json), assess legal conditional mode/center choices using
the complete augmented score, starting only from the original unoptimized
source state. Reconcile the earlier weighted selectors, retain the frozen9-by-9
grid, independently replay all single/joint scores and account for every
consumed preparation stage before any new finite search. The current augmented
key and seven older weighted keys remain closed. No new selector or successor
call exists. Four earlier fixed arrangements and440 allocations remain unresolved.

The preceding two checkpoints reached main cbc49d2c after all six earlier checks
passed, preserving52 protected files. [The receipt]({NAME}/prior-main-push-receipt.json)
records the ordinary atomic push. [At this review]({NAME}/main-ci-at-review.json),
{success} fresh CI jobs pass and{live} native jobs remain live, so this checkpoint
awaits the ordinary push gate. Product code, README claims and releases are unchanged.

[Archive verification]({NAME}/archive-checks.json),
[manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
for a,b in [('retains33','retains 33'),('movers,81','movers, 81'),('all528','all 528'),('the15','the 15'),('coefficient1','coefficient 1'),('error1.','error 1.'),('e-10mm','e-10 mm'),('accumulates306','accumulates 306'),('and162','and 162'),('is1.','is 1.'),('e-13mm','e-13 mm'),('Version2','Version 2'),('all14','all 14'),('unchanged0.','unchanged 0.'),('error0.','error 0.'),('takes6','takes 6'),('a36s','a 36 s'),('60/90s','60/90 s'),('a2GiB','a 2 GiB'),('and236','and 236'),('is2.','is 2.'),('evaluation236','evaluation 236'),('full66','full 66'),('covering1,','covering 1,'),('edges,90','edges, 90'),('and10,','and 10,'),('in32','in 32'),('The36s','The 36 s'),('charged11','charged 11'),('new0.','new 0.'),('with100,','with 100,'),('288bytes','288 bytes'),('All45','All 45'),('frozen9','frozen 9'),('and440','and 440'),('preserving52','preserving 52'),('and2 native','and 2 native')]:report=report.replace(a,b)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 augmented bracket-depth construction:** [independent model and response audits]({link}) verify the unchanged 81-coordinate source model with all 528 weighted area pairs plus 15 coefficient-1 bracket terms. Checks cover 147 legal-mode scores, 306 scalar directed terms, 324 interior central samples and nine corruptions. All 14 original contact/near-transition central failures remain preserved, with one-sided finite controls and explicit nonsmooth limits; the separate NumPy-boolean output failure and corrected serializer also remain. No model, initializer or tolerance changes. One new objective key closes after 236 optimizer evaluations; all 237 records, 212 retained improvements and three full66 winner streams replay. All three select the same invalid candidate: 44 source collisions and 33,707.125558 mm² overlap, worse overlap than the prior conditional result despite fewer failing pairs. Fixed-part and stock checks pass. Complete preparation is 11.688681 s and algorithm/shared totals are 52.962365/53.493153 s; the 0.071821 s slice overrun remains and all monitored descendants close. A separate diagnostic finds no bracket/bracket failure or flat pair gradient among 45 positive area terms, while four cogs have blocked lower-y descent. Next independently preflight conditional mode/center choices under the full augmented objective from the original unoptimized initializer. The new augmented key and all seven older weighted keys remain closed. No native call or exclusion follows. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Prior checkpoints reached main cbc49d2c, preserving 52 files; four fresh CI jobs pass and two native jobs remain live. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [augmented bracket-depth construction](../benchmarks/results/{NAME}.md).
The full source model retains 528 weighted area pairs and adds 15 bracket-depth
terms at coefficient 1. Independent model checks cover 147 legal-mode scores,
combined scalar gradients and interior derivative controls. Original contact
central failures and a diagnostic output failure remain preserved; corrected
verification keeps the model, initializer and tolerances unchanged and makes
the nonsmooth limitations explicit. One new objective key closes after 236
optimizer evaluations. Every evaluation, 212 retained improvements and three
full66 winner streams replay. All three select the same invalid candidate:
44 source collisions and 33,707.125558 mm² overlap. Fewer failed pairs do not
offset its worse overlap than the prior conditional result. Fixed-part and
stock checks pass. Complete preparation is 11.688681 s; algorithm/shared totals
are 52.962365/53.493153 s, with all monitored processes closed and the slice
overrun retained. No bracket/bracket failure or flat area-pair gradient remains
at this candidate, but four cogs have lower-y descent blocked by hard domains.
Next preflight legal conditional mode/center choices under the full augmented
score from the original unoptimized initializer. No successor selector or call
exists. The new augmented key and all seven older weighted keys stay closed.
Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%.
Prior checkpoints reached main cbc49d2c, preserving 52 files. Four fresh CI jobs
pass and two native jobs remain live; this checkpoint awaits the ordinary push
gate. Product code, README and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
