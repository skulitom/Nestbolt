"""Bind the ordinary atomic push to the observed main and completed CI."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'output/push_h5_weighted_joint_checkpoints_20261107.py'
new=ROOT/'output/push_h5_bracket_depth_checkpoints_20261107.py'
source=old.read_text(encoding='utf-8')
changes={
    'h5-weighted-joint-main-sync-20261107':'h5-bracket-depth-main-sync-20261107',
    'd8aa6a90c89b8822fccc0ad6870a343afb876de8':'c7e4b305d1a52bad8449bab8070fe2b82028d084',
    '42366837555':'42369490349',
    "prefixes=('benchmarks/results/h5-weighted-mixed-rows-construction-20261107','benchmarks/results/h5-cross-pair-boundary-preflight-20261107','benchmarks/results/h5-weighted-joint-selection-20261107')":"prefixes=('benchmarks/results/h5-weighted-relocated-construction-20261107','benchmarks/results/h5-bracket-collision-depth-preflight-20261107')",
    "['h5-weighted-mixed-rows-construction-20261107','h5-cross-pair-boundary-preflight-20261107','h5-weighted-joint-selection-20261107']":"['h5-weighted-relocated-construction-20261107','h5-bracket-collision-depth-preflight-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print(new)
