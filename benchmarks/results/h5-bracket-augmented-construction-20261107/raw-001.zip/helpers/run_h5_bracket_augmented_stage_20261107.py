"""Exclusive, bounded stage processes for the augmented objective evidence."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,os,sys
ROOT=Path(__file__).resolve().parents[1]
stage=sys.argv[1]
filename,cap={'preparation':('prepare_h5_bracket_augmented_model_20261107.py',20),'audit':('audit_h5_bracket_augmented_model_20261107.py',180),'response-audit':('audit_h5_bracket_augmented_response_20261107.py',300)}[stage]
SCRIPT=ROOT/'output'/filename;OUT=ROOT/'output'/f'h5-bracket-augmented-model-{stage}-process-20261107'
EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/shop-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,EXE,EXE.parent/'checks.json']},'cap_seconds':cap,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=subprocess.run([str(EXE),str(cap*1000),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(SCRIPT)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap+8,env=env)
(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr)
job=load(OUT/'job.json');passed=r.returncode==0 and job['reason_code']==job['error_code']==0 and job['closed'] and job['active_processes']==0
write(OUT/'process.json',{'closed':True,'complete_seconds':time.perf_counter()-started,'passed':passed,'exit_code':r.returncode,'job':job,'retry_permitted':False});print(load(OUT/'process.json'));sys.exit(0 if passed else 1)
