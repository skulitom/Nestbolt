"""Separate touching-source finite differences from the new auxiliary term."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from h5_bracket_augmented_objective_20261107 import Objective,compile_model
from h5_bracket_augmented_reference_20261107 import Reference
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'derivative-diagnostic-v2';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False,default=lambda obj:obj.item() if isinstance(obj,np.generic) else str(obj));f.write('\n')
OUT.mkdir();started=time.perf_counter();lib=load(BASE/'library.json');identity=load(BASE/'objective-identity.json');regions=load(B/'regions.json');model=load(BASE/'model.json');ref=Reference(lib)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),ROOT/'output/diagnose_h5_bracket_augmented_derivatives_20261107.py',BASE/'derivative-diagnostic/serialization-failure.json',BASE/'plan.json',BASE/'model.json',ROOT/'output/audit_h5_weighted_mixed_rows_model_v2_20261107.py',ROOT/'output/h5-bracket-augmented-model-audit-process-20261107/process.json',ROOT/'output/h5-bracket-augmented-model-audit-process-20261107/stderr.txt']},'method':'Keep original two validation cases. Check all81coordinates at both existing1e-5/1e-6steps, separating exact area and auxiliary finite differences. For every failed combined check independently decompose discrepancy into its source pair terms, retaining zero-area contacts and their actual one-sided overlap. Also check the exact two deterministic interior derivative controls already specified in the earlier weighted-model audit; these are validation only and cannot seed search. No tolerance, kernel, model or initial-state changes.','optimizer_calls':0,'model_changed':False})
flat=load(R/'search/epoch-02/model.json');flat_x=load(R/'search/epoch-02/response.json')['unweighted_best']['values'];flat_m=compile_model(lib,[o['mode'] for o in flat['owners']],flat_x,flat['pair_weights'],identity)
diagnostics=[];causes=[]
for label,m,x in [('source_initializer',model,model['initial']),('closed_flat_case',flat_m,flat_x)]:
    x=np.array(x);obj=Objective(m,regions,identity);v,g,d=obj.evaluate(x,True);aux,auxg,_=ref.auxiliary(m,x,d['auxiliary_terms']);base_losses=obj.pair_losses(x);entries=obj.geometry(x);refvalue,refg,refd=ref.evaluate(m,x,True,d['auxiliary_terms']);assert abs(refvalue-v)<1e-6 and np.max(np.abs(refg-g))<1e-6
    for k in range(81):
        for h in [1e-5,1e-6]:
            xp=x.copy();xm=x.copy();xp[k]+=h;xm[k]-=h;lp=obj.pair_losses(xp);lm=obj.pair_losses(xm);ap=obj.auxiliary.evaluate(m,xp)[0];am=obj.auxiliary.evaluate(m,xm)[0];numeric_area=float(np.asarray(m['pair_weights'])@(lp-lm))/(2*h);numeric_aux=(ap-am)/(2*h);error=abs(numeric_area+numeric_aux-g[k]);tol=.02+3e-6*abs(g[k]);failed=error>=tol
            diagnostics.append({'case':label,'coordinate':k,'step':h,'analytic_combined':float(g[k]),'analytic_area':float(g[k]-auxg[k]),'analytic_auxiliary':float(auxg[k]),'numeric_area':numeric_area,'numeric_auxiliary':numeric_aux,'auxiliary_error':abs(numeric_aux-auxg[k]),'combined_error':error,'frozen_tolerance':tol,'failed':failed})
            if not failed:continue
            own=k//2 if k<66 else 18+k-66;axis=k%2 if k<66 else 2
            local=[]
            for index,(i,j) in enumerate(m['pairs']):
                if own not in [i,j]:continue
                other=j if own==i else i;analytic=0.;levels=[]
                for level in [0,1]:
                    a,b=entries[level][own][1],entries[level][other][1];area=a.intersection(b).area;gg,n,shared=moving_boundary_gradient(a,b,x[2*own:2*own+2])
                    derivative=float(gg[axis])/(m['owners'][own]['angle_scale_mm'] if axis==2 else 1.) if area>0 else 0.
                    analytic+=derivative;levels.append({'kind':['original','clearance'][level],'area_mm2':area,'distance_mm':a.distance(b),'shared_boundary_mm':shared,'selected_area_derivative':derivative})
                weight=m['pair_weights'][index];numeric=weight*(lp[index]-lm[index])/(2*h);analytic*=weight;delta=numeric-analytic
                if abs(delta)>1e-5:local.append({'pair_index':index,'owners':[i,j],'levels':levels,'weighted_analytic':analytic,'weighted_numeric':numeric,'discrepancy':delta,'plus_pair_loss':float(lp[index]),'minus_pair_loss':float(lm[index]),'zero_area_contact_present':any(r['area_mm2']==0 and r['distance_mm']<1e-9 for r in levels)})
            causes.append({'case':label,'coordinate':k,'step':h,'area_difference':float(numeric_area-(g[k]-auxg[k])),'pair_discrepancies':local,'all_large_discrepancies_have_zero_area_contact':all(r['zero_area_contact_present'] for r in local if abs(r['discrepancy'])>tol/4)})
smooth=[];initial=load(BASE/'initial-state.json')
for variation in [0,1]:
    modes=initial['modes'].copy() if variation==0 else [(v+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,v in enumerate(initial['modes'])]
    weights=initial['pair_weights'] if variation==0 else [1.+i%64 for i in range(528)]
    m=compile_model(lib,modes,initial['values'],weights,identity);bb=np.array(m['bounds']);margin=.03+np.arange(81)*.00037
    point=np.clip(np.array(m['initial'])+.137*np.sin(np.arange(81)*2**.5+.2+variation),bb[:,0]+margin,bb[:,1]-margin)
    obj=Objective(m,regions,identity);v,g,d=obj.evaluate(point,True);vv,gg,dd=ref.evaluate(m,point,True,d['auxiliary_terms']);assert abs(v-vv)<1e-6 and np.max(np.abs(g-gg))<1e-6
    errors=[]
    for k in range(81):
        for h in [1e-5,1e-6]:
            xp=point.copy();xm=point.copy();xp[k]+=h;xm[k]-=h;numeric=(obj.score(xp)-obj.score(xm))/(2*h);error=abs(numeric-g[k]);assert error<.02+3e-6*abs(g[k]),(variation,k,h,error);errors.append(error)
    smooth.append({'variation':variation,'model':m,'point':point.tolist(),'max_central_error':max(errors),'scalar_gradient_error':float(np.max(np.abs(g-gg))),'shared_boundary_length_mm':dd['coincident_boundary_length_mm'],'nearest_features_unique':all(t['distinct_closest_points']<=1 for t in dd['auxiliary_terms']),'central_samples':len(errors)})
write(OUT/'all-original-central-controls.json',diagnostics);write(OUT/'failing-coordinate-pair-causes.json',causes);write(OUT/'historical-interior-controls.json',smooth)
checks={'passed':True,'seconds':time.perf_counter()-started,'original_case_central_samples':len(diagnostics),'original_failed_samples':sum(r['failed'] for r in diagnostics),'failed_samples_by_case':{s:sum(r['failed'] for r in diagnostics if r['case']==s) for s in ['source_initializer','closed_flat_case']},'max_auxiliary_central_error':max(r['auxiliary_error'] for r in diagnostics),'all_large_discrepancies_have_zero_area_contact':all(r['all_large_discrepancies_have_zero_area_contact'] for r in causes),'historical_interior_central_samples':sum(r['central_samples'] for r in smooth),'historical_interior_max_error':max(r['max_central_error'] for r in smooth),'all_interior_cases_without_shared_boundary':all(r['shared_boundary_length_mm']==0 for r in smooth),'all_interior_cases_unique_nearest_features':all(r['nearest_features_unique'] for r in smooth),'kernel_changed':False,'model_changed':False,'optimizer_calls':0}
write(OUT/'checks.json',checks);print(checks)
