"""Preserve the NumPy-bool serialization failure and version only its output."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-augmented-model-20261107';OLD=BASE/'derivative-diagnostic'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
script=ROOT/'output/diagnose_h5_bracket_augmented_derivatives_20261107.py';new=ROOT/'output/diagnose_h5_bracket_augmented_derivatives_v2_20261107.py'
partial=OLD/'all-original-central-controls.json'
try:json.loads(partial.read_bytes())
except json.JSONDecodeError:pass
else:raise AssertionError('expected incomplete JSON from interrupted serialization')
record={'failure':'TypeError: Object of type bool is not JSON serializable','cause':'numpy.bool_ from the comparison failed=error>=tol reaches json.dump; the write fails in the first diagnostic record after calculations finish. No completed diagnostic checks exist.','observed_session_id':10143,'observed_exit_code':1,'failed_script':script.relative_to(ROOT).as_posix(),'failed_script_sha256':digest(script),'incomplete_output':partial.relative_to(ROOT).as_posix(),'incomplete_output_sha256':digest(partial),'preservation':'Retain the original incomplete file and original helper. Archive the incomplete JSON under a .partial.txt member while retaining its original path here. Version2 changes only serialization and output directory, not controls or numerical code.','optimizer_calls':0}
with (OLD/'serialization-failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
s=script.read_text(encoding='utf-8');changes={"OUT=BASE/'derivative-diagnostic'":"OUT=BASE/'derivative-diagnostic-v2'","json.dump(v,f,indent=2,allow_nan=False)":"json.dump(v,f,indent=2,allow_nan=False,default=lambda obj:obj.item() if isinstance(obj,np.generic) else str(obj))","[Path(__file__),BASE/'plan.json'":"[Path(__file__),ROOT/'output/diagnose_h5_bracket_augmented_derivatives_20261107.py',BASE/'derivative-diagnostic/serialization-failure.json',BASE/'plan.json'"}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
runner=(ROOT/'output/run_h5_bracket_augmented_stage_20261107.py').read_text(encoding='utf-8')
start=runner.index('stage=sys.argv[1]');end=runner.index('SCRIPT=ROOT',start)
runner=runner[:start]+"stage='derivative-diagnostic-v2'\nfilename,cap='diagnose_h5_bracket_augmented_derivatives_v2_20261107.py',120\n"+runner[end:]
with (ROOT/'output/run_h5_bracket_derivative_diagnostic_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
print({'versioned_output_only':True,'old_failure_preserved':True})
