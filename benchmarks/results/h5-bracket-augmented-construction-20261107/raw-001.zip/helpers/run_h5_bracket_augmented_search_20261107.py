"""One closed augmented-objective call; preserve all evaluations and three winners."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'search';B=ROOT/'output/h5-bracket-collision-depth-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
METRICS={'augmented':'augmented_objective_mm2','original':'original_overlap_area_mm2','unweighted':'unweighted_objective_mm2'}

def child(started):
    import numpy as np,scipy
    from scipy.optimize import minimize
    from h5_bracket_augmented_objective_20261107 import Objective,problem_key
    from h5_bracket_augmented_readback_20261107 import verify
    from h5_hard_cell_compound_modes_20261107 import physical_key,family_classes
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_legacy64_source_readback import audit
    from h5_checked_affinity_20261107 import affinity_mask
    assert scipy.__version__=='1.17.1' and affinity_mask()==4294901760
    assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
    plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
    model=load(BASE/'model.json');identity=load(BASE/'objective-identity.json');initial=load(BASE/'initial-state.json');lib=load(BASE/'library.json');regions=load(B/'regions.json')
    assert verify(model,lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
    key=problem_key(physical_key(lib,family_classes(lib),initial['modes']),initial['pair_weights'],identity)
    assert key==load(BASE/'audit-v2/closure-controls.json')['new_objective_key'] and key not in {r['key'] for r in load(BASE/'closed-prior-problems.json')}
    write(OUT/'model.json',model);assert digest(OUT/'model.json')==digest(BASE/'model.json')
    obj=Objective(model,regions,identity);bounds=np.array(model['bounds']);initial_x=np.array(model['initial']);winners={};saved=0;evaluations=0
    (OUT/'points').mkdir();log=(OUT/'evaluations.jsonl').open('x',encoding='utf-8',newline='\n')
    def record(x,value,g,details,evaluation):
        nonlocal saved
        r={'evaluation':evaluation,'values':x.tolist(),'gradient':g.tolist(),**{field:float(details[field]) for field in ['augmented_objective_mm2','original_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']}}
        assert value==r['augmented_objective_mm2'] and np.all(x>=bounds[:,0]) and np.all(x<=bounds[:,1])
        flags={name:name not in winners or r[field]<winners[name][field] for name,field in METRICS.items()};r['improved']=flags
        r['saved_sequence']=saved if any(flags.values()) else None
        log.write(json.dumps(r,allow_nan=False,separators=(',',':'))+'\n');log.flush()
        if any(flags.values()):
            write(OUT/'points'/f'{saved:05d}.json',r);saved+=1
            for name,improved in flags.items():
                if improved:winners[name]=r
        return r
    value,g,details=obj.evaluate(initial_x,True);record(initial_x,value,g,details,0)
    options=load(BASE/'audit-v2/optimizer-controls.json')['options'];allocated=min(plan['optimizer_slice_seconds'],54-(time.perf_counter()-started));assert allocated>0
    write(OUT/'optimizer-opened.json',{'key':key,'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'nonsmooth_convention':'existing source boundary convention and deterministic bracket nearest branch; not globally differentiable','parameters':81,'allocated_seconds':allocated,'model_sha256':digest(OUT/'model.json'),'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'maximum_calls_for_problem':1,'retry_permitted':False,'algorithm_seconds_including_preparation':time.perf_counter()-started})
    class Deadline(Exception):pass
    def function(x):
        nonlocal evaluations
        if time.perf_counter()>=deadline:raise Deadline()
        value,g,d=obj.evaluate(x,True);evaluations+=1;record(x,value,g,d,evaluations);return value,g
    def callback(x):
        if winners['unweighted']['unweighted_objective_mm2']<=1e-16:raise StopIteration()
    before=time.perf_counter();deadline=before+allocated;numerical=None
    try:
        result=minimize(function,initial_x,jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options)
        status='RETURNED';numerical={'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'objective_mm2':float(result.fun),'values':result.x.tolist()}
    except Deadline:status='TIME_STOP'
    returned=time.perf_counter()-before;log.close();readbacks={};job=load(JOB);valid_witness=None
    for name,r in winners.items():
        value,g,d=obj.evaluate(r['values'],True)
        assert value==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
        rows=source_rows(model,r['values']);write(OUT/(name+'-source66.json'),rows)
        checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])))
        write(OUT/(name+'-source-checks.json'),checked)
        assert checked['stock_failures']==0 and checked['originals']==66
        readbacks[name]={'pair_failures':checked['pair_failures'],'source_valid66':checked['valid'],'original_overlap_mm2':d['original_overlap_area_mm2'],'unweighted_objective_mm2':d['unweighted_objective_mm2'],'augmented_objective_mm2':value,'auxiliary_bracket_depth_mm2':d['auxiliary_bracket_depth_mm2']}
        if checked['valid'] and valid_witness is None:valid_witness={'label':name,'source66_path':(OUT/(name+'-source66.json')).relative_to(ROOT).as_posix()}
    elapsed=time.perf_counter()-started
    response={'closed':True,'status':status,'key':key,'numerical_result':numerical,'allocated_seconds':allocated,'returned_seconds':returned,'slice_overrun_seconds':max(0.,returned-allocated),'function_evaluations':evaluations,'total_evaluation_records':evaluations+1,'saved_points':saved,'winners':winners,'source_readbacks':readbacks,'source_valid66':valid_witness is not None,'valid_witness':valid_witness,'optimizer_calls':1,'mode_changes':0,'coefficient_updates':0,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'complete_preparation_seconds':plan['complete_preparation_seconds'],'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False}
    write(OUT/'response.json',response);write(OUT/'closed-problem.json',{'key':key,'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'closed':True,'retry_permitted':False,'response_sha256':digest(OUT/'response.json')})
    print({k:v for k,v in response.items() if k not in ['winners','numerical_result']})

def main():
    checked=load(BASE/'audit-v2/checks.json');assert checked['passed'];OUT.mkdir();charge=checked['complete_preparation_seconds'];started=time.perf_counter()-charge
    inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','plan-v2.json','model.json','objective-identity.json','initial-state.json','library.json','closed-prior-problems.json','runtime-bindings.json','audit-v2/plan.json','audit-v2/checks.json','audit-v2/closure-controls.json','audit-v2/optimizer-controls.json']]+[B/'regions.json']+[ROOT/'output'/n for n in ['h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_preparation_seconds':charge,'algorithm_seconds':60,'shared_seconds':90,'memory_bytes':2**31,'cpu_affinity_mask':4294901760,'blas_threads':1,'maximum_optimizer_calls':1,'optimizer_slice_seconds':36.,'source_reserve_boundary_seconds':54,'method':'One separately identified augmented objective from the unchanged original W initializer, same legal mode vector and original frozen weights. No mode search, weight update or optimized ancestor seed. At most one36second L-BFGS-B call, shortened to preserve the54second source-check boundary. Preserve every evaluation plus every strict improvement of augmented score, original overlap area or unweighted original+clearance sum. Check all66originals for each of the three winners. Existing area shared-boundary and auxiliary nearest-feature conventions are nonsmooth heuristics; source validity remains authoritative. Stop on numerical return, time, source-zero callback or inconsistency. No old problem may resume and this new problem closes permanently.','retry_permitted':False,'restarts':0})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
    cap=max(1,int((90-(time.perf_counter()-started))*1000))
    write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'complete_preparation_seconds':charge,'maximum_ms':cap,'memory_bytes':2**31,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env)
    (OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json')
    assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'retry_permitted':False})
    print(load(OUT/'process.json'));print(load(OUT/'response.json')['source_readbacks'] if (OUT/'response.json').exists() else 'No completed response; call remains closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
